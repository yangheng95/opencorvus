import fs from 'node:fs'
import assert from 'node:assert/strict'
import { Database } from 'bun:sqlite'
const root=import.meta.dir,tag='config-admitted-discovery-518-after'
const preflight=JSON.parse(fs.readFileSync('C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-22/'+tag+'/evidence/preflight-ready.json','utf8'))
assert.equal(preflight.preflight.actualModel,'gpt-6.1-sol');assert.equal(preflight.preflight.streaming,true)
const db=new Database('C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-22/config-admitted-discovery-518-after/runtime/data/opencorvus.db',{readonly:true,create:false})
try{
 const row=db.query('SELECT id,directory FROM session WHERE id=?').get(preflight.preflight.sessionID);assert(row)
 fs.writeFileSync(root+'/run-reader-selection.json',JSON.stringify(row),{flag:'wx'})
 fs.writeFileSync(root+'/history-run-verified.json',JSON.stringify({schema:db.query('PRAGMA user_version').get(),projects:db.query('SELECT COUNT(*) AS count FROM project').get(),mode:'Direct readonly SQLite; full history retained; no production initializer'},null,2),{flag:'wx'})
}finally{db.close()}
console.log(JSON.stringify({readers:4,history:'complete',selection:'Actual preflight session directory'}))




