import fs from 'node:fs'
import path from 'node:path'
const root='.tmp-product-iteration/source-member-review-425'
const base='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-15'
const bundle=base+'/source-member-review-425-before-bundle/bin'
if(fs.existsSync(bundle))throw Error('Fresh bundle required')
fs.mkdirSync(bundle,{recursive:true})
fs.copyFileSync('.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64/bun.exe',bundle+'/bun.exe')
fs.cpSync('packages/overlay/dist-vite',bundle+'/ui',{recursive:true})
for(const name of ['launch.ps1','settle.ps1','shutdown.ps1']){
 let text=fs.readFileSync('.tmp-product-iteration/literal-reference-click-423/after/'+name,'utf8')
 text=text.replaceAll('literal-reference-click-423-after','source-member-review-425-before')
 text=text.replaceAll('.tmp-product-iteration/literal-reference-click-423/after',root+'/before')
 text=text.replaceAll('18569','18571')
 // Runtime history remains at its original admitted path; only diagnostic/bundle roots move.
 text=text.replaceAll('2026-10-14/source-member-review-425-before','2026-10-15/source-member-review-425-before')
 if(name==='settle.ps1')text=text.replace("$taskBase='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14'","$taskBase='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-15'")
 fs.mkdirSync(root+'/before',{recursive:true});fs.writeFileSync(root+'/before/'+name,text)
}
const record='2026-10-15-source-member-review.md',artifact='2026-10-15-source-member-review'
fs.mkdirSync('specs/artifacts/'+artifact,{recursive:true})
fs.writeFileSync('specs/artifacts/'+artifact+'/README.md','# Sources与成员侧栏体验证据\n\n[方案与Recall](../../records/2026-10/'+record+')。本批为真实交互和原图人工复核，资格与结果在执行后补齐；不包含UI自动化测试或凭据。\n')
for(const [file,line] of [
 ['specs/README.md','- [Sources与成员侧栏继续体验](records/2026-10/'+record+')：当前真实历史的来源与成员阅读。'],
 ['specs/records/2026-10/README.md','- [Sources与成员侧栏继续体验]('+record+')：真实交互、根因调查与当前验收边界。'],
 ['specs/artifacts/README.md','- [Sources与成员侧栏继续体验]('+artifact+'/README.md)：原图、Provider与物理退出事实。'],
]){const text=fs.readFileSync(file,'utf8');if(text.includes(line))throw Error('Index already prepared');fs.writeFileSync(file,text.trimEnd()+'\n\n'+line+'\n')}
console.log(JSON.stringify({bundle,entry:fs.existsSync(bundle+'/ui/index.html'),plannedPort:18571,history:'existing 412',credentialValues:'not read by preparation'}))
