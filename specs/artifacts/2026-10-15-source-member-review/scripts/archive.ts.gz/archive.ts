import fs from 'node:fs'
import path from 'node:path'
import zlib from 'node:zlib'
import assert from 'node:assert/strict'
import {Database} from 'bun:sqlite'
const root=import.meta.dir,dest=path.resolve('specs/artifacts/2026-10-15-source-member-review')
const diagnostic='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-15/source-member-review-425-before'
const runtime='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/member-live-rendering-412-fresh/runtime'
const save=(name:string,value:string)=>{const target=path.join(dest,name);fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,zlib.gzipSync(value))}
const ids=['ses_-zUS0X33CzzWEKMgCk98','ses_-zUS0WzzQzzDOGrIbYwN','ses_hdvEOzMlLHl6S8MoqpRU','ses_ha8862QlAlLJD7Ku0sM0']
const db=new Database(runtime+'/data/opencorvus.db',{readonly:true})
let facts:any
try{
 db.exec('PRAGMA busy_timeout=5000; BEGIN')
 const sessions=ids.flatMap(id=>db.query('SELECT id,project_id,directory,kind,parent_id,title FROM session WHERE id=?').all(id))
 assert.equal(sessions.length,4)
 const messages=ids.flatMap(id=>db.query('SELECT id,session_id,data FROM message WHERE session_id=? ORDER BY time_created,id').all(id)).map((row:any)=>({...JSON.parse(row.data),id:row.id,sessionID:row.session_id}))
 const ownMessages=new Map(messages.map((message:any)=>[message.id,message.sessionID]))
 const sources=db.query('SELECT id,message_id,data FROM part ORDER BY time_created,id').all().filter((row:any)=>ownMessages.has(row.message_id)).map((row:any)=>({...JSON.parse(row.data),id:row.id,messageID:row.message_id,sessionID:ownMessages.get(row.message_id)})).filter((part:any)=>part.type==='source-file')
 assert.deepEqual(sources.filter((source:any)=>source.sessionID===ids[2]).map((source:any)=>source.range),[{startLine:2,endLine:2}])
 assert.deepEqual(sources.filter((source:any)=>source.sessionID===ids[3]).map((source:any)=>source.range),[{startLine:3,endLine:3}])
 assert.equal(db.query('PRAGMA user_version').get()?.user_version,2)
 facts={observedAt:new Date().toISOString(),boundary:'Read-only current persisted real historical Sessions and original Source Parts; no before/after content comparison claimed',schema:db.query('PRAGMA user_version').get(),sessions,messageIdentities:messages.map(({id,sessionID,role,finish,time}:any)=>({id,sessionID,role,finish,time})),sources}
}finally{db.exec('ROLLBACK');db.close(true)}
save('facts/historical-sources.json.gz',JSON.stringify(facts,null,2))
const evidence=diagnostic+'/evidence'
const audits=fs.readdirSync(evidence).filter(name=>/^provider-.*\.json$/.test(name)&&name!=='provider-pair-staging.json').map(name=>({name,value:JSON.parse(fs.readFileSync(evidence+'/'+name,'utf8'))})).filter(entry=>Array.isArray(entry.value.requests)).sort((a,b)=>b.value.requests.length-a.value.requests.length)
const finalAudit=audits[0]
assert(finalAudit,'Actual provider audit required')
const provider=finalAudit.value.requests.map(({model,streaming,status,response_reader}:any)=>({model,streaming,status,response_reader}))
for(const request of provider){assert.equal(request.model,'gpt-6.1-sol');assert.equal(request.streaming,true);assert.equal(request.status,200);assert.equal(request.response_reader.state,'settled')}
save('facts/provider-summary.json.gz',JSON.stringify({source:finalAudit.name,requests:provider,budget:12},null,2))
for(const name of ['native-host-ready.json','native-host-settled.json','physical-terminal-and-pair-cleanup.json','provider-pair-staging.json','preflight-ready.json','public-shutdown.json','launcher-child-exit.json'])save('facts/'+name+'.gz',fs.readFileSync(evidence+'/'+name,'utf8'))
const terminal=JSON.parse(fs.readFileSync(evidence+'/physical-terminal-and-pair-cleanup.json','utf8'))
assert.equal(terminal.physicalCompletion,true);assert.equal(terminal.pairedCleanupComplete,true)
const native=JSON.parse(fs.readFileSync(evidence+'/native-host-settled.json','utf8'))
assert.equal(native.terminal.exitCode,0)
for(const name of ['launch.ps1','settle.ps1','shutdown.ps1'])save('scripts/'+name+'.gz',fs.readFileSync(root+'/before/'+name,'utf8'))
save('scripts/prepare.mjs.gz',fs.readFileSync(root+'/prepare.mjs','utf8'))
save('scripts/archive.ts.gz',fs.readFileSync(root+'/archive.ts','utf8'))
save('checks/launch.log.gz',fs.readFileSync(root+'/before/launch.log','utf8'))
const review={observedAt:new Date().toISOString(),sessions:ids,sources:facts.sources.length,requests:provider.length,readerTerminals:provider.map((r:any)=>r.response_reader.terminal),native:native.terminal,physicalCompletion:true,pairedCleanupComplete:true,screenshots:fs.readdirSync(dest).filter(name=>name.endsWith('.jpg')),clipboardBoundary:'Copy button feedback observed; browser virtual clipboard paste rejected, no paste success claimed'}
fs.writeFileSync(root+'/review-result.json',JSON.stringify(review,null,2));save('facts/review-result.json.gz',JSON.stringify(review,null,2));console.log(JSON.stringify(review,null,2))
