import fs from 'node:fs'
const root=import.meta.dirname,tag='config-write-cost-436-after'
const bundle='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-20/'+tag+'-bundle/bin'
if(fs.existsSync(bundle))throw Error('Fresh immutable publication required')
fs.mkdirSync(bundle,{recursive:true});fs.copyFileSync('.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64/bun.exe',bundle+'/bun.exe');fs.cpSync('packages/overlay/dist-vite',bundle+'/ui',{recursive:true})
fs.mkdirSync(root+'/after',{recursive:true})
for(const name of ['launch.ps1','settle.ps1','shutdown.ps1']){
 const source=fs.readFileSync(root+'/'+name,'utf8').replaceAll('config-write-cost-436-before',tag)
 .replaceAll(tag+'-authority','config-write-cost-436-before-authority')
 .replaceAll('.tmp-product-iteration/config-write-cost-436/settle.ps1','.tmp-product-iteration/config-write-cost-436/after/settle.ps1')
 .replaceAll('18639','18641')
 fs.writeFileSync(root+'/after/'+name,source)
}
const writer=fs.readFileSync(root+'/config-write-check.ts','utf8')
 .replace('assert(phase === "before")','assert(phase === "after")')
 .replace('const port = 18639','const port = 18641')
 .replaceAll('qa-cost-436','qa-cost-436-after')
 .replace('`${root}/canonical-write-check.json`','`${root}/canonical-write-after.json`')
fs.writeFileSync(root+'/config-write-after.ts',writer)
console.log(JSON.stringify({tag,port:18641,businessInputs:0}))
