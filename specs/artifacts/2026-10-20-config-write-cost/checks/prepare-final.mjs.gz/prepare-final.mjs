import fs from 'node:fs'
const root=import.meta.dirname,tag='config-write-cost-436-final'
const bundle='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-20/'+tag+'-bundle/bin'
if(fs.existsSync(bundle))throw Error('Fresh immutable publication required')
fs.mkdirSync(bundle,{recursive:true});fs.copyFileSync('.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64/bun.exe',bundle+'/bun.exe');fs.cpSync('packages/overlay/dist-vite',bundle+'/ui',{recursive:true})
fs.mkdirSync(root+'/final',{recursive:true})
for(const name of ['launch.ps1','settle.ps1','shutdown.ps1']){
 const source=fs.readFileSync(root+'/verified/'+name,'utf8').replaceAll('config-write-cost-436-verified',tag)
 .replaceAll('.tmp-product-iteration/config-write-cost-436/verified/settle.ps1','.tmp-product-iteration/config-write-cost-436/final/settle.ps1')
 .replaceAll('18643','18645')
 fs.writeFileSync(root+'/final/'+name,source)
}
const writer=fs.readFileSync(root+'/config-write-verified.ts','utf8')
 .replace('assert(phase === "verified")','assert(phase === "final")')
 .replace('const port = 18643','const port = 18645')
 .replaceAll('qa-cost-436-verified','qa-cost-436-final')
 .replace('`${root}/canonical-write-verified.json`','`${root}/canonical-write-final.json`')
fs.writeFileSync(root+'/config-write-final.ts',writer)
console.log(JSON.stringify({tag,port:18645,businessInputs:0}))
