import fs from 'node:fs'
const source='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/member-live-rendering-412-fresh/runtime/log/dev.log'
const facts=JSON.parse(fs.readFileSync('.tmp-product-iteration/permission-config-435/verified-request-facts.json','utf8'))
const entries=fs.readFileSync(source,'utf8').split('\n').filter(Boolean).flatMap(line=>{try{return [JSON.parse(line)]}catch{return []}})
const requests=facts.requests.filter(r=>r.path==='/global/config'&&r.method==='PATCH'&&r.status==='completed')
const results=requests.map(request=>{
 const rows=entries.filter(e=>e.service==='skill-read-diagnostics'&&e.data?.http?.requestID===request.requestID)
 const summary=new Map()
 for(const row of rows){const d=row.data,item=summary.get(d.phase)||{phase:d.phase,count:0,totalMs:0,maxMs:0,first:row.time,last:row.time};item.count++;item.totalMs+=d.duration||0;item.maxMs=Math.max(item.maxMs,d.duration||0);item.last=row.time;summary.set(d.phase,item)}
 return {request,summary:[...summary.values()].sort((a,b)=>b.totalMs-a.totalMs),spans:rows.map(({time,data})=>({time,phase:data.phase,spanID:data.spanID,parentSpanID:data.parentSpanID,outcome:data.outcome,status:data.status,duration:data.duration,disposition:data.disposition,stateLabel:data.stateLabel,origin:data.origin}))}
})
const result={source,occurrence:facts.occurrence,boundary:'Original 435 completed server requests and their existing diagnostic spans; selected fields only',requests:results}
fs.writeFileSync(import.meta.dirname+'/baseline-435.json',JSON.stringify(result,null,2),{flag:'wx'})
console.log(JSON.stringify(results.map(({request,summary,spans})=>({request,phases:summary.slice(0,24),spans:spans.length})),null,2))
