import fs from 'node:fs'
const root=import.meta.dirname,tag='config-write-cost-436-before'
const bundle='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-20/'+tag+'-bundle/bin'
if(fs.existsSync(bundle))throw Error('Fresh immutable publication required')
fs.mkdirSync(bundle,{recursive:true});fs.copyFileSync('.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64/bun.exe',bundle+'/bun.exe');fs.cpSync('packages/overlay/dist-vite',bundle+'/ui',{recursive:true})
for(const name of ['launch.ps1','settle.ps1','shutdown.ps1']){
 const source=fs.readFileSync('.tmp-product-iteration/permission-config-435/'+name,'utf8')
 .replaceAll('permission-config-435-after',tag)
 .replaceAll('.tmp-product-iteration/permission-config-435','.tmp-product-iteration/config-write-cost-436')
 .replaceAll('2026-10-19','2026-10-20').replaceAll('18635','18639')
 fs.writeFileSync(root+'/'+name,source)
}
fs.writeFileSync(root+'/prepare-authority.mjs',fs.readFileSync('.tmp-product-iteration/permission-config-435/prepare-authority.mjs','utf8').replaceAll('permission-config-435-after-authority',tag+'-authority').replaceAll('2026-10-19','2026-10-20'))
const writer=fs.readFileSync('.tmp-product-iteration/permission-config-435/config-write-check.ts','utf8')
 .replace('assert(phase === "after")','assert(phase === "before")')
 .replace('const port = 18635','const port = 18639')
 .replaceAll('permission-config-435-','config-write-cost-436-').replaceAll('qa-scope-435','qa-cost-436')
 .replaceAll('2026-10-19','2026-10-20')
fs.writeFileSync(root+'/config-write-check.ts',writer)
console.log(JSON.stringify({tag,port:18639,businessInputs:0}))
