import fs from 'node:fs'
const root=import.meta.dirname,tag='config-write-cost-436-verified'
const bundle='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-20/'+tag+'-bundle/bin'
if(fs.existsSync(bundle))throw Error('Fresh immutable publication required')
fs.mkdirSync(bundle,{recursive:true});fs.copyFileSync('.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64/bun.exe',bundle+'/bun.exe');fs.cpSync('packages/overlay/dist-vite',bundle+'/ui',{recursive:true})
fs.mkdirSync(root+'/verified',{recursive:true})
for(const name of ['launch.ps1','settle.ps1','shutdown.ps1']){
 const source=fs.readFileSync(root+'/after/'+name,'utf8').replaceAll('config-write-cost-436-after',tag)
 .replaceAll('.tmp-product-iteration/config-write-cost-436/after/settle.ps1','.tmp-product-iteration/config-write-cost-436/verified/settle.ps1')
 .replaceAll('18641','18643')
 fs.writeFileSync(root+'/verified/'+name,source)
}
const writer=fs.readFileSync(root+'/config-write-after.ts','utf8')
 .replace('assert(phase === "after")','assert(phase === "verified")')
 .replace('const port = 18641','const port = 18643')
 .replaceAll('qa-cost-436-after','qa-cost-436-verified')
 .replace('`${root}/canonical-write-after.json`','`${root}/canonical-write-verified.json`')
fs.writeFileSync(root+'/config-write-verified.ts',writer)
console.log(JSON.stringify({tag,port:18643,businessInputs:0}))
