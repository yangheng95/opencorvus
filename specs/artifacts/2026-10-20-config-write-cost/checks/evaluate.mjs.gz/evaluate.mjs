import fs from 'node:fs'
import assert from 'node:assert/strict'
const root=import.meta.dirname,receipt=JSON.parse(fs.readFileSync(root+'/canonical-write-final.json','utf8'))
const costs=JSON.parse(fs.readFileSync(root+'/final-cost.json','utf8'))
const requests=JSON.parse(fs.readFileSync(root+'/final-config-requests.json','utf8'))
assert.equal(receipt.accepted,true);assert.equal(receipt.restored,true);assert.equal(receipt.permissionMode,'ask')
const reads=requests.filter(r=>r.method==='GET'&&r.status==='completed'&&r.duration>0)
const requirements={coldWriteWithin10Seconds:receipt.writeMs<=10000,warmRestoreWithin5Seconds:receipt.restoreMs<=5000,
 observedConfigReadsWithin20Seconds:reads.every(r=>r.statusCode===200&&r.duration<=20000),canonicalAcceptedAndRestored:true}
const result={observedAt:new Date().toISOString(),boundary:receipt.boundary,projects:costs.requests[0].inventory[0].projects,
 coldWriteMs:receipt.writeMs,warmRestoreMs:receipt.restoreMs,observedReadDurations:reads.map(r=>r.duration),requirements,
 status:Object.values(requirements).every(Boolean)?'passed':'failed',remaining:'Cold writer still exceeds 10 seconds; shared Project directory admission needs further phase attribution. No threshold relaxation.'}
fs.writeFileSync(root+'/benchmark-result.json',JSON.stringify(result,null,2),{flag:'wx'})
console.log(JSON.stringify(result,null,2));if(result.status==='failed')process.exitCode=1
