const fs=require('node:fs'),path=require('node:path'),zlib=require('node:zlib'),assert=require('node:assert/strict');
const scratch=path.resolve('.tmp-product-iteration/clipboard-first-observation-411');
const out=path.resolve('specs/artifacts/2026-10-14-clipboard-first-observation');
const read=p=>JSON.parse(fs.readFileSync(p,'utf8').replace(/^\uFEFF/,''));
const json=(p,value)=>fs.writeFileSync(p,JSON.stringify(value,null,2)+'\n',{flag:'wx'});
const copy=(source,target)=>{fs.mkdirSync(path.dirname(target),{recursive:true});fs.copyFileSync(source,target,fs.constants.COPYFILE_EXCL)};
const zip=(source,target)=>{fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,zlib.gzipSync(fs.readFileSync(source)),{flag:'wx'})};
const original=read('.tmp-product-iteration/source-reading-405/data-facts.json');
const current=read(path.join(scratch,'data-facts.json'));
for(const key of ['databaseVersion','sessions','sources','messages','tools'])assert.deepEqual(current[key],original[key],key);
json(path.join(out,'persisted-facts-check.json'),{databaseVersion:current.databaseVersion,sourceSessions:current.sessions.length,messages:current.messages.length,sources:current.sources.length,tools:current.tools.length,comparison:'Exact original IDs, source payload fields, message state and tool bindings from the read-only production database match original 405 facts.',fields:['databaseVersion','sessions','sources','messages','tools']});
copy(path.join(scratch,'data-facts.json'),path.join(out,'data-facts.json'));
copy(path.join(scratch,'observations.json'),path.join(out,'observations.json'));
for(const name of fs.readdirSync(scratch).filter(x=>/^\d\d-.*\.jpg$/.test(x)))copy(path.join(scratch,name),path.join(out,name));
for(const name of ['launch.log','launch-replay.log','ui-build.log','launch.ps1','settle.ps1','launch-replay.ps1','settle-replay.ps1','read-facts.ts'])zip(path.join(scratch,name),path.join(out,'execution',name+'.gz'));
zip('.tmp-product-iteration/live-sol-source-navigation-410.ts',path.join(out,'execution/live-sol-source-navigation-410.ts.gz'));
const scopes=[];
for(const suffix of ['live','replay']){
 const dir=`C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/clipboard-first-observation-411-${suffix}/evidence`;
 const target=path.join(out,suffix);fs.mkdirSync(target,{recursive:true});
 for(const name of ['existing-history-admitted.json','native-host-ready.json','native-host-settled.json','physical-terminal-and-pair-cleanup.json','preflight-ready.json'])copy(path.join(dir,name),path.join(target,name));
 const audits=fs.readdirSync(dir).filter(x=>x.startsWith('provider-')&&x.endsWith('.json')).map(name=>({name,data:read(path.join(dir,name))})).filter(x=>Array.isArray(x.data.requests)&&typeof x.data.observedAt==='string').sort((a,b)=>Date.parse(a.data.observedAt)-Date.parse(b.data.observedAt));
 assert.ok(audits.length>0,'Production provider audit exists');
 const audit=audits.at(-1);copy(path.join(dir,audit.name),path.join(target,'provider-audit.json'));
 const native=read(path.join(dir,'native-host-settled.json')),cleanup=read(path.join(dir,'physical-terminal-and-pair-cleanup.json'));
 assert.equal(native.physicalCompletion,true);assert.equal(native.outputDrainComplete,true);assert.equal(native.requestCleanupComplete,true);assert.equal(cleanup.pairedCleanupComplete,true);
 for(const r of audit.data.requests){assert.equal(r.model,'gpt-6.1-sol');assert.equal(r.streaming,true);assert.equal(r.status,200);assert.equal(r.response_reader.state,'settled');assert.equal(r.response_reader.terminal.kind,'eof')}
 if(suffix==='replay')copy(path.join(dir,'public-shutdown.json'),path.join(target,'public-shutdown.json'));
 scopes.push({scope:suffix,occurrence:native.occurrence,requests:audit.data.requests.length,requestModel:'gpt-6.1-sol',streaming:true,readerTerminal:'eof',nativeTerminal:native.terminal,physicalCompletion:native.physicalCompletion,outputDrainComplete:native.outputDrainComplete,requestCleanupComplete:native.requestCleanupComplete,pairedCleanupComplete:cleanup.pairedCleanupComplete});
}
json(path.join(out,'execution-summary.json'),{scopes,toolHandleBoundary:{live:{handle:14978,exitCode:1},replay:{handle:13147,state:'Original join was called before context compression; its exit field is unavailable in retained model-visible tool output. A subsequent poll returns Unknown process id. Physical production settlement exitCode 0 is separately preserved, without inventing the wrapper tool receipt.'}},uiBuild:{handle:91895,exitCode:0},checks:{docs:'345 ops, 26 groups',architectureIndex:'19 current documents indexed, every link live'},screenshots:14});
const carry=path.join(out,'previous-410');fs.mkdirSync(carry,{recursive:true});
for(const name of ['push.log','push-exit.json','fetch-after-race.log','merge-after-race.log','push-after-race.log','push-after-race-exit.json','remote-after-race.txt'])zip(path.join('.tmp-product-iteration/source-navigation-410',name),path.join(carry,name+'.gz'));
console.log(JSON.stringify({scopes,screenshots:14,facts:{sessions:current.sessions.length,messages:current.messages.length,sources:current.sources.length,tools:current.tools.length}},null,2));
