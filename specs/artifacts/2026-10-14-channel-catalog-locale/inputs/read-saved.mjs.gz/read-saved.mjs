import fs from 'node:fs/promises'
import path from 'node:path'
import assert from 'node:assert/strict'
const stage='after',root=path.resolve('.tmp-codex-channel-catalog-locale-01a133',stage),ready=JSON.parse(await fs.readFile(root+'/ready.json','utf8')),authority=JSON.parse(await fs.readFile(root+'/project-authorities.json','utf8')),route='/config?'+new URLSearchParams({directory:authority.defaultDirectory})
const label=process.argv[2]??'saved';assert.match(label,/^(saved|current)$/)
const response=await fetch(`http://127.0.0.1:${ready.port}`+route),raw=await response.text(),config=JSON.parse(raw),irc=config.channel?.irc
const selected={method:'GET',route,status:response.status,originalResponseBytes:Buffer.byteLength(raw),selection:'Only exact non-secret IRC field keys and enabled/host/nickname/TLS values; full config and credential-shaped fields are not retained.',keys:Object.keys(irc??{}).sort(),irc:{enabled:irc?.enabled,host:irc?.host,nick:irc?.nick,tls:irc?.tls}}
await fs.writeFile(root+'/read-'+label+'-irc.json',JSON.stringify(selected,null,2)+'\n')
assert.equal(response.status,200);assert.deepEqual(selected.keys,['enabled','host','nick','tls']);assert.deepEqual(selected.irc,{enabled:true,host:'127.0.0.1',nick:'owned-local-reviewed',tls:true})
console.log(JSON.stringify(selected))
