import fs from 'node:fs'
import {execFileSync} from 'node:child_process'
import ts from 'typescript'
const root='.tmp-codex-channel-catalog-locale-01a133',file='packages/channel-config/src/index.ts'
const catalog=JSON.parse(execFileSync('.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64/bun.exe',['-e','import {ChannelCatalog} from "./packages/channel-config/src/index.ts"; console.log(JSON.stringify(ChannelCatalog))'],{encoding:'utf8'}))
const labels={
 'Slack Bot Token':'Slack 机器人令牌','Slack App Token':'Slack 应用令牌','Signing Secret':'签名密钥','Telegram Bot Token':'Telegram 机器人令牌','Discord Bot Token':'Discord 机器人令牌','App ID':'应用 ID','App Secret':'应用密钥','Verification Token':'验证令牌','Webhook Host':'Webhook 监听地址','Webhook Port':'Webhook 端口','Webhook Path':'Webhook 路径','Access Token':'访问令牌','Phone Number ID':'电话号码 ID','Verify Token':'验证令牌','Service Account JSON':'服务账号 JSON','Auth Audience':'认证受众','Channel Access Token':'通道访问令牌','Channel Secret':'通道密钥','Homeserver URL':'主服务器 URL','Since Token':'同步游标令牌','Server URL':'服务器 URL','Bot Token':'机器人令牌','Webhook Token':'Webhook 令牌','Service URL':'服务 URL','Account':'账号','Corp ID':'企业 ID','Secret':'密钥','Agent ID':'应用 Agent ID','Callback Token':'回调令牌','EncodingAESKey':'EncodingAESKey 加密密钥','App Key':'应用标识 App Key','Default Webhook':'默认 Webhook','Base URL':'基地址 URL','Workspace':'工作区','imsg CLI Path':'imsg 命令行工具路径','Messages Database':'消息数据库','Service':'服务类型','Server Host':'服务器主机','Nickname':'昵称','Port':'端口','Use TLS':'使用传输层安全协议（TLS）','Server Password':'服务器密码','Channels':'通道列表','Nextcloud URL':'Nextcloud URL','Bot Secret':'机器人密钥','Public Webhook URL':'公网 Webhook URL','Private Key':'私钥','Relays':'中继服务器','Client Secret':'客户端密钥','Profile':'配置档案','Handle':'账号名称','Email':'电子邮箱','Relay URL':'中继 URL','Guard Provider':'守卫模型服务商','Guard Model':'守卫模型','Guard API Key Environment':'守卫 API 密钥环境变量','Guard Policy Version':'守卫策略版本','Guard Timeout':'守卫超时（毫秒）','Friend Request Policy':'好友请求策略','Account SID':'账号 SID','Auth Token':'认证令牌','From Number':'发送号码','Default Recipient':'默认接收号码','Outgoing Token':'出站令牌','Incoming Webhook URL':'入站 Webhook URL','NAS Host':'NAS 主机','Ship':'Urbit 舰名','Ship URL':'Urbit 舰地址 URL','Login Code':'登录码','Group Channels':'群组通道','Direct Message Allowlist':'私信允许名单','Authorized Group Ships':'获准访问群组的 Urbit 舰名','Username':'用户名','Client ID':'客户端 ID','Channel':'通道','Allowed User IDs':'允许的用户 ID','Require Mention':'要求提及机器人','Webhook Secret':'Webhook 密钥','Webhook URL':'Webhook URL'
}
const hints={
 'Optional':'可选','Discord token':'Discord 令牌','App secret':'应用密钥','Phone number ID':'电话号码 ID','Verify token':'验证令牌','JSON or file path':'JSON 内容或文件路径','Application ID':'应用 ID','Channel access token':'通道访问令牌','Channel secret':'通道密钥','Matrix token':'Matrix 令牌','Mattermost token':'Mattermost 令牌','Outgoing webhook token':'出站 Webhook 令牌','Corp ID':'企业 ID','Callback token':'回调令牌','43-character EncodingAESKey':'43 个字符的 EncodingAESKey','App key':'应用标识 App Key','Bot token':'机器人令牌','App ID':'应用 ID','Client secret':'客户端密钥'
}
const en={},zh={},descriptors=new Map()
for(const item of catalog)for(const field of item.fields){
 const key=`channel.field.${item.id}.${field.key}`,translated=field.key==='enabled'?`启用 ${item.name}`:labels[field.label]
 if(!translated)throw Error('Unreviewed field label '+item.id+'.'+field.key+' '+field.label)
 en[key]=field.label;zh[key]=translated
 let placeholder
 if(field.placeholder){if(Object.hasOwn(hints,field.placeholder)){const hintKey=`channel.placeholder.${item.id}.${field.key}`;en[hintKey]=field.placeholder;zh[hintKey]=hints[field.placeholder];placeholder={kind:'hint',key:hintKey}}else placeholder={kind:'example',value:field.placeholder}}
 descriptors.set(item.id+'.'+field.key,{key,placeholder})
}
const descriptions={
 missing:['Add the required settings to configure this channel.','请填写所需设置以配置此通道。'],
 partial:['Some settings are present. Complete the required fields.','已填写部分设置，请补齐所需字段。'],
 configured:['Required settings are present. Connection status is shown separately.','所需设置已填写，实际连接情况请查看运行状态。'],
 disabled:['This channel is disabled in configuration.','此通道已在配置中禁用。'],
}
for(const [status,values]of Object.entries(descriptions)){en['channel.description.'+status]=values[0];zh['channel.description.'+status]=values[1]}
const text=fs.readFileSync(file,'utf8'),source=ts.createSourceFile(file,text,ts.ScriptTarget.Latest,true),edits=[]
const prop=(object,name)=>(ts.isTypeLiteralNode(object)?object.members:object.properties).find(p=>p.name?.getText(source).replaceAll('"','')===name)
const edit=(node,value)=>edits.push({start:node.getStart(source),end:node.end,value})
const dropProperty=node=>edits.push({start:node.getFullStart(),end:node.end+(text[node.end]===','?1:0),value:''})
for(const node of source.statements){
 if(ts.isTypeAliasDeclaration(node)&&node.name.text==='ChannelField'){
  const label=prop(node.type,'label'),placeholder=prop(node.type,'placeholder');edit(label.name,'labelKey');edit(placeholder.type,'z.infer<typeof ChannelFieldPlaceholder>')
  edits.push({start:node.getStart(source),end:node.getStart(source),value:'export const ChannelFieldPlaceholder = z.discriminatedUnion("kind", [\n  z.object({ kind: z.literal("example"), value: z.string() }),\n  z.object({ kind: z.literal("hint"), key: z.string() }),\n])\n\n'})
 }
 if(ts.isTypeAliasDeclaration(node)&&node.name.text==='Spec')dropProperty(prop(node.type,'summaries'))
 if(ts.isVariableStatement(node))for(const declaration of node.declarationList.declarations)if(declaration.name.getText(source)==='ChannelCatalog'){
  for(const call of declaration.initializer.expression.elements){
   const object=call.arguments[0],id=prop(object,'id').initializer.text;dropProperty(prop(object,'summaries'))
   for(const field of prop(object,'fields').initializer.elements){
    const key=prop(field,'key').initializer.text,descriptor=descriptors.get(id+'.'+key)
    edit(prop(field,'label'),'labelKey: '+JSON.stringify(descriptor.key))
    if(descriptor.placeholder)edit(prop(field,'placeholder').initializer,JSON.stringify(descriptor.placeholder))
   }
  }
 }
 if(ts.isFunctionDeclaration(node)&&node.name?.text==='channelState')for(const statement of node.body.statements){
  if(ts.isVariableStatement(statement)&&statement.declarationList.declarations.some(d=>d.name.getText(source)==='summary'))edits.push({start:statement.getFullStart(),end:statement.end,value:''})
  if(ts.isReturnStatement(statement))dropProperty(prop(statement.expression,'summary'))
 }
}
let after=text
for(const e of edits.sort((a,b)=>b.start-a.start))after=after.slice(0,e.start)+e.value+after.slice(e.end)
const localePatches=[]
for(const [locale,entries]of [['en-US',en],['zh-CN',zh]]){
 const target=`packages/overlay/src/i18n/${locale}.json`,old=fs.readFileSync(target,'utf8'),current=JSON.parse(old)
 for(const key of Object.keys(entries))if(Object.hasOwn(current,key))throw Error('Existing locale key '+key)
 const anchor='  "channel.status.configured":',paragraph=Object.entries(entries).map(([k,v])=>'  '+JSON.stringify(k)+': '+JSON.stringify(v)+',').join('\n')+'\n'
 if(!old.includes(anchor))throw Error('Locale insertion anchor missing')
 localePatches.push({file:target,anchor,paragraph,after:old.replace(anchor,paragraph+anchor)})
}
fs.appendFileSync('specs/records/2026-10/2026-10-14-channel-catalog-locale.md',`\n\n## 修前真实确认与实施细化\n\nbefore PID88848、18690/91、occurrencee2da0306-59da-4349-ab74-fe6b442c3a34。真实PATCH200后GET200完整catalog19552字节/27项：Slack missing/disabled runtime，Telegram disabled/disabled，Matrix partial/disabled，IRC configured/unavailable。Root实际查看01中文Not configured/Disabled、02Matrix英文partial、03Matrix原英文label/Optional、04IRC原planned英文reason/已配置/不可用、05IRC原英文表单、06/07长Reef顶部和底部。只查看/取消表单，未写凭据或保存channel编辑。\n\nMatrix原native AX省略switch名称，但实际DOM明确switch Enable Matrix；只保存原观测，不判定缺失名称，也不因此改共享Switch。已有primitive label children自然含当前t。placeholder判别结构由channel-config新唯一Zod ChannelFieldPlaceholder定义，经core/catalog原reexport复用到Registry.Info，避免两份协议schema。AST一次性codemod仅迁移既定catalog定义和原语言文案，不在生产运行时按英文匹配；所有label已逐项翻译检查后才写入。完整源/SDK/locale diff和实际页面复核仍须完成。\n\ntab40已关闭，正常父实际exit0/双口0后假auth/models整对移除，完整backend101664字节、stdout/stderr0/隐私0，模型请求0。修前七原图保留，不称最终新协议资格。\n`)
fs.writeFileSync(root+'/packages__opencorvus__src__channel__catalog.ts.before',fs.readFileSync('packages/opencorvus/src/channel/catalog.ts'))
fs.writeFileSync(file,after)
for(const item of localePatches)fs.writeFileSync(item.file,item.after)
fs.writeFileSync(root+'/locale-patches.json',JSON.stringify(localePatches.map(({after,...rest})=>rest),null,2)+'\n')
fs.writeFileSync(root+'/catalog-original.json',JSON.stringify(catalog,null,2)+'\n')
console.log(JSON.stringify({fields:descriptors.size,newLocaleKeys:Object.keys(en).length,hints:Object.keys(en).filter(k=>k.startsWith('channel.placeholder.')).length,astEdits:edits.length}))
