import fs from 'node:fs/promises'
import path from 'node:path'
import assert from 'node:assert/strict'
const [stage,action]=process.argv.slice(2)
assert.match(stage??'',/^(before|after)([0-9]{2})?$/);assert.match(action??'',/^(seed|catalog)$/)
const root=path.resolve('.tmp-codex-channel-catalog-locale-01a133',stage),deadline=Date.now()+30_000
while(!await fs.access(root+'/ready.json').then(()=>true,()=>false)){assert.ok(Date.now()<deadline,'Bounded original own readiness');await new Promise(r=>setTimeout(r,250))}
const ready=JSON.parse(await fs.readFile(root+'/ready.json','utf8')),authority=JSON.parse(await fs.readFile(root+'/project-authorities.json','utf8')),query=new URLSearchParams({directory:authority.defaultDirectory}),base=`http://127.0.0.1:${ready.port}`
if(action==='seed'){
 const body={channel:{telegram:{enabled:false},matrix:{homeserver:`http://127.0.0.1:${ready.participantPort}`},irc:{host:'127.0.0.1',nick:'owned-local'}}},route='/config?'+query
 const response=await fetch(base+route,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}),raw=await response.text()
 await fs.writeFile(root+'/catalog-seed.json',JSON.stringify({method:'PATCH',route,body,status:response.status,responseBytes:Buffer.byteLength(raw),selection:'Only exact non-secret owned input, HTTP status and original response length. Full configuration response is not retained.'},null,2)+'\n')
 assert.equal(response.status,200)
 console.log(JSON.stringify({stage,action,status:response.status,selection:'Actual config preparation: disabled Telegram, partial Matrix without token, configured planned IRC; no native channel can start.'}))
}else{
 const route='/channel?'+query,response=await fetch(base+route),raw=await response.text()
 await fs.writeFile(root+'/catalog.body.json',raw)
 const catalog=JSON.parse(raw),expected={slack:'missing',telegram:'disabled',matrix:'partial',irc:'configured'}
 assert.equal(response.status,200);assert.equal(catalog.length,27)
 const selections=Object.keys(expected).map(id=>{const item=catalog.find(c=>c.id===id);assert.ok(item,'Current catalog identity');assert.equal(item.status,expected[id]);return{id,status:item.status,runtimeStatus:item.runtime_status,fields:item.fields.length}})
 const receipt={method:'GET',route,status:response.status,originalResponseBytes:Buffer.byteLength(raw),selection:'Complete actual public channel catalog response retained, containing only catalog metadata, configured status and runtime diagnostics; not configuration values/authentication.',count:catalog.length,selections}
 await fs.writeFile(root+'/catalog-receipt.json',JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify({stage,...receipt}))
}
