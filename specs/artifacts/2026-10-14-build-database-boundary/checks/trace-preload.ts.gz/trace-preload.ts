import fs from 'node:fs'
const output=process.env.OPENCORVUS_BUILD_TRACE_FILE!
const emit=(fact:unknown)=>fs.appendFileSync(output,JSON.stringify({at:new Date().toISOString(),pid:process.pid,...fact as object})+'\n')
const instrument=(source:string,needle:string,replacement:string)=>{
 const end=source.startsWith('#!')?source.indexOf('\n')+1:0
 const prefix=source.slice(0,end)
 return prefix+`import {appendFileSync as __appendBuildTrace424} from "node:fs"\nconst __recordBuildTrace424 = (fact: object) => __appendBuildTrace424(${JSON.stringify(output)},JSON.stringify({at:new Date().toISOString(),pid:process.pid,...fact})+"\\n")\n`+source.slice(end).replace(needle,replacement)
}
emit({kind:'process',cwd:process.cwd(),argv:process.argv,root:process.env.OPENCORVUS_HOME})
Bun.plugin({name:'passive-build-database-observation',setup(builder){
 builder.onLoad({filter:/[\\/]src[\\/]global[\\/]index\.ts$/},async({path})=>{
  const original=await Bun.file(path).text()
  return {loader:'ts',contents:instrument(original,'await initializeOpenCorvusRuntimeDirectories(runtimePaths())',`__recordBuildTrace424({kind:"runtime-initialization",root:Global.Path.root,argv:process.argv})
await initializeOpenCorvusRuntimeDirectories(runtimePaths())
console.error("BUILD_RUNTIME_OBSERVATION", JSON.stringify({pid:process.pid,root:Global.Path.root,argv:process.argv}))`)}
 })
 builder.onLoad({filter:/[\\/]src[\\/]storage[\\/]db\.ts$/},async({path})=>{
  const original=await Bun.file(path).text()
  return {loader:'ts',contents:instrument(original,'const dbPath = Path()','const dbPath = Path()\n    __recordBuildTrace424({kind:"database-open",path:dbPath,stack:new Error().stack})\n    console.error("BUILD_DATABASE_OBSERVATION", JSON.stringify({pid:process.pid,path:dbPath,stack:new Error().stack}))')}
 })
 builder.onLoad({filter:/[\\/]src[\\/]storage[\\/]schema-migration\.ts$/},async({path})=>{
  const original=await Bun.file(path).text()
  return {loader:'ts',contents:instrument(original,'const expected = new SQLite(":memory:")','__recordBuildTrace424({kind:"migration-check",database:":memory:",root:process.env.OPENCORVUS_HOME})\n  console.error("BUILD_MIGRATION_CHECK_OBSERVATION", JSON.stringify({pid:process.pid,database:":memory:",root:process.env.OPENCORVUS_HOME}))\n  const expected = new SQLite(":memory:")')}
 })
 builder.onLoad({filter:/[\\/]script[\\/]check-packaged-first-run\.ts$/},async({path})=>{
  const original=await Bun.file(path).text()
  return {loader:'ts',contents:instrument(original,'process.chdir(root)','process.chdir(root)\n__recordBuildTrace424({kind:"packaged-first-run",root:process.env.OPENCORVUS_HOME,realProvider})\nconsole.error("BUILD_FIRST_RUN_OBSERVATION", JSON.stringify({pid:process.pid,root:process.env.OPENCORVUS_HOME,realProvider}))')}
 })
}})
