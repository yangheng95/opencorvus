import fs from 'node:fs'
import path from 'node:path'
import {Database as SQLite} from 'bun:sqlite'
const root=import.meta.dir+'/migration-runtime',file=root+'/data/opencorvus.db'
fs.mkdirSync(path.dirname(file),{recursive:true})
if(fs.existsSync(file))throw Error('Fresh controlled runtime required')
fs.copyFileSync(import.meta.dir+'/sample-user/data/opencorvus.db',file)
const control=new SQLite(file);control.exec('PRAGMA journal_mode=WAL');control.close(true)
process.env.OPENCORVUS_HOME=root
const {Database}=await import('../../packages/opencorvus/src/storage/db')
try {
 const identity=Database.Identity()
 const version=Database.allFinalized('PRAGMA user_version')
 const rows=Database.allFinalized('SELECT id,worktree,name,time_created,time_updated,sandboxes,generation FROM project')
 const backups=fs.readdirSync(root+'/data/migration-backups')
 const receipt={identity,version,rows,backups}
 fs.writeFileSync(import.meta.dir+'/runtime-migration-result.json',JSON.stringify(receipt,null,2));console.log(JSON.stringify(receipt,null,2))
}finally{Database.close()}
