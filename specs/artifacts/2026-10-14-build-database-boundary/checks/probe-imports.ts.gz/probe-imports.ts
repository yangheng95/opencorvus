import fs from 'node:fs'
import path from 'node:path'
const root=path.resolve(import.meta.dir,'sample-user')
fs.mkdirSync(root+'/cache',{recursive:true})
fs.writeFileSync(root+'/cache/version','0')
fs.writeFileSync(root+'/cache/build-preservation-marker.txt','original-user-cache-marker-424')
process.env.OPENCORVUS_HOME=root
const {generateOpencorvusGeneratedBuildArtifacts}=await import('../../packages/opencorvus/script/generate-build-artifacts')
console.log('GENERATORS_IMPORTED',JSON.stringify({runtime:process.env.OPENCORVUS_HOME,cacheVersion:fs.readFileSync(root+'/cache/version','utf8'),marker:fs.existsSync(root+'/cache/build-preservation-marker.txt')?'present':'removed'}))
const {preparePackageBuildEnvironment}=await import('../../script/package-build-environment')
const env=await preparePackageBuildEnvironment(path.resolve('.'),process.env)
console.log('PREPARED_BUILD_ROOT',env.OPENCORVUS_HOME)
await generateOpencorvusGeneratedBuildArtifacts({repoRoot:path.resolve('.'),log:console.log})
console.log('GENERATORS_COMPLETED')
