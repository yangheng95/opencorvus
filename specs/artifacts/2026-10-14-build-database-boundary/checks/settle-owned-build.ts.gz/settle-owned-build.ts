import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
const root=import.meta.dir
process.env.OPENCORVUS_HOME=path.join(root,'cleanup-observer-runtime')
const {observeRuntimeProcessOccurrence}=await import('../../packages/opencorvus/src/runtime/process-occurrence')
const scope='C:/Users/hengu/AppData/Local/Temp/opencorvus-test-run-RQUEZb/runner-87288-mnija8/runtime-root/tmp/supervisor-raLFuc'
const request=JSON.parse(fs.readFileSync(scope+'/request.json','utf8'))
const ready=JSON.parse(fs.readFileSync(scope+'/ready.json','utf8'))
const helper=JSON.parse(fs.readFileSync(scope+'/helper.json','utf8'))
assert.equal(request.request_id,'d28c5a44-3857-46d6-b539-73538aba0fbe')
assert.equal(request.runtime_occurrence_id,'a8d9f878-920a-4d03-94fe-9ea9b30251c0')
assert.equal(request.owner_pid,87288)
assert.equal(helper.helper_pid,90380)
assert.equal(ready.target_process_instance_id,'win32:639275891575710586')
assert.equal(path.resolve(request.cancel_file),path.resolve(scope,'cancel'))
const observe=(pid:number,processInstanceID:string)=>observeRuntimeProcessOccurrence({pid,processInstanceID,occurrenceID:request.runtime_occurrence_id})
const observations={owner:observe(request.owner_pid,request.owner_process_instance_id),helper:observe(helper.helper_pid,helper.helper_process_instance_id),target:observe(ready.target_pid,ready.target_process_instance_id)}
assert.deepEqual(observations,{owner:'exact_live',helper:'exact_live',target:'dead_or_reused'})
const evidence={at:new Date().toISOString(),action:'cancel exact owned Job after successful build target exit; retain root terminal and native physical receipt',requestID:request.request_id,runtimeOccurrenceID:request.runtime_occurrence_id,ownerPID:request.owner_pid,ownerInstance:request.owner_process_instance_id,helper,ready,observations,cancelFile:request.cancel_file}
fs.writeFileSync(root+'/owned-build-teardown.json',JSON.stringify(evidence,null,2))
fs.writeFileSync(request.cancel_file,'owned benchmark cleanup after complete build output')
console.log(JSON.stringify(evidence,null,2))
