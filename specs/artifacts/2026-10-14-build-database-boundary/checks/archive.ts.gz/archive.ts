import fs from 'node:fs'
import path from 'node:path'
import zlib from 'node:zlib'
const root=import.meta.dir,dest=path.resolve('specs/artifacts/2026-10-14-build-database-boundary')
const save=(name:string,value:string)=>{const target=path.join(dest,name);fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,zlib.gzipSync(value))}
const defaultLog='C:/Users/hengu/AppData/Local/opencorvus/log'
const logs=fs.readdirSync(defaultLog).filter(name=>name.endsWith('.log')).map(name=>{
 const file=path.join(defaultLog,name),stat=fs.statSync(file)
 const dbEvents=fs.readFileSync(file,'utf8').split('\n').flatMap(line=>{
  if(!/opening database|schema applied|database migration completed|SCHEMA_MIGRATION/.test(line))return[]
  try{const e=JSON.parse(line);if(e.service!=='db')return[];return[{time:e.time,message:e.message,path:e.data?.path??e.path,from:e.data?.from,to:e.data?.to,backupPath:e.data?.backupPath}]}catch{return[]}
 })
 return {name,length:stat.size,modified:stat.mtime.toISOString(),dbEvents}
})
save('facts/default-log-inventory.json.gz',JSON.stringify(logs,null,2))
for(const name of fs.readdirSync(root)){
 const full=path.join(root,name);if(!fs.statSync(full).isFile())continue
 if(name.endsWith('.before'))save('before/'+name+'.gz',fs.readFileSync(full,'utf8'))
 else if(/\.(log|json|jsonl|ts|cjs)$/.test(name))save((name.endsWith('.json')?'facts/':'checks/')+name+'.gz',fs.readFileSync(full,'utf8'))
}
console.log(JSON.stringify({dest,files:fs.readdirSync(root).filter(n=>fs.statSync(path.join(root,n)).isFile()).length,defaultLogs:logs.length,boundary:'Only logs, scripts, schema/physical facts and controlled marker rows; no database files, credentials, auth/models or user message content archived'}))
