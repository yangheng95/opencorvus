const fs=require('node:fs');
for(const [file,line] of [
 ['specs/README.md','- [构建数据库边界](records/2026-10/2026-10-14-build-database-boundary.md)：完整Overlay构建链与用户运行数据隔离审计。'],
 ['specs/records/2026-10/README.md','- [构建数据库边界](2026-10-14-build-database-boundary.md)：真实调用链、内存迁移检查与独立构建运行目录。'],
 ['specs/artifacts/README.md','- [构建数据库边界](2026-10-14-build-database-boundary/README.md)：隔离复现、完整构建与实际用户库只读观察。'],
]){const text=fs.readFileSync(file,'utf8');if(!text.includes(line))fs.writeFileSync(file,text.trimEnd()+'\n\n'+line+'\n');}
fs.mkdirSync('specs/artifacts/2026-10-14-build-database-boundary',{recursive:true});
fs.writeFileSync('specs/artifacts/2026-10-14-build-database-boundary/README.md','# 构建数据库边界证据\n\n[方案与Recall](../../records/2026-10/2026-10-14-build-database-boundary.md)。本轮为构建及数据库路径审计，无UI改动或UI自动化验收。修改前样本缓存写入已实际复现；完整构建和状态保留以执行后的归档回执为准。\n');
