import fs from 'node:fs'
import path from 'node:path'
import {bootstrapIsolatedTestRuntime, removeIsolatedTestRuntime} from '../../packages/util/src/test-runtime-environment'
import {prepareTestProcessSupervisor} from '../../packages/opencorvus/script/prepare-test-process-supervisor'
const taskRoot=import.meta.dir,repo=path.resolve('.'),hostEnv={...process.env}
const supervisor=prepareTestProcessSupervisor()
const runtime=await bootstrapIsolatedTestRuntime('runner')
if(supervisor)process.env.OPENCORVUS_PROCESS_SUPERVISOR=supervisor
let settled=false
try {
 const {runHostCommandWithInactivity}=await import('../../packages/opencorvus/src/shell/command-inactivity')
 const env={...hostEnv,OPENCORVUS_HOME:taskRoot+'/sample-user',LOCALAPPDATA:taskRoot+'/default-localappdata',APPDATA:taskRoot+'/default-appdata',OPENCORVUS_BUILD_TRACE_FILE:taskRoot+'/trace-full.jsonl',BUN_OPTIONS:'--preload='+taskRoot.replaceAll('\\','/')+'/trace-preload.ts'}
 for(const key of Object.keys(env))if(key.startsWith('OPENCORVUS_TEST_')||key.startsWith('OPENCORVUS_NATIVE_'))delete env[key]
 const result=await runHostCommandWithInactivity({executable:process.execPath,args:['run','build:overlay'],cwd:repo,env,deadlineAt:Date.now()+1_800_000,inactivityTimeoutMs:600_000,onStdout:chunk=>process.stdout.write(chunk),onStderr:chunk=>process.stderr.write(chunk)})
 settled=result.settlementConfirmed
 fs.writeFileSync(taskRoot+'/full-build-result.json',JSON.stringify({observedAt:new Date().toISOString(),executable:process.execPath,args:['run','build:overlay'],settlementConfirmed:settled,exitCode:result.exitCode,failure:result.failure},null,2))
 if(result.failure)throw result.failure
 if(result.exitCode!==0)process.exitCode=result.exitCode??1
}finally{if(settled)await removeIsolatedTestRuntime(runtime)}

