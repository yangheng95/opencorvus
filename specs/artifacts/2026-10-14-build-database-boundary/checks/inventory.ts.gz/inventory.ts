import fs from 'node:fs'
import path from 'node:path'
import {Database as SQLite} from 'bun:sqlite'
const root=import.meta.dir,phase=process.argv[2]||'before'
function inspect(file:string){
 const db=new SQLite(file,{readonly:true})
 try {
  const version=db.query('PRAGMA user_version').get()
  const objects=db.query("SELECT type,name,tbl_name,sql FROM sqlite_schema WHERE name NOT LIKE 'sqlite_%' ORDER BY type,name").all()
  const tables=db.query("SELECT name FROM sqlite_schema WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").all() as {name:string}[]
  const counts=tables.map(({name})=>({table:name,count:(db.query(`SELECT COUNT(*) AS n FROM "${name.replaceAll('"','""')}"`).get() as {n:number}).n}))
  return {path:file,metadata:fs.statSync(file),version,objects,counts}
 }finally{db.close(true)}
}
const user='C:/Users/hengu/AppData/Local/opencorvus/data/opencorvus.db'
if(phase==='before'){
 const sample=root+'/sample-user';fs.mkdirSync(sample+'/data',{recursive:true});fs.mkdirSync(sample+'/cache',{recursive:true})
 const file=sample+'/data/opencorvus.db'
 const db=new SQLite(file)
 if((db.query('PRAGMA user_version').get() as {user_version:number}).user_version!==0)throw Error('Owned incomplete sample version 0 required')
 db.exec(fs.readFileSync('packages/opencorvus/src/storage/migrations/0001-baseline.sql','utf8'))
 db.query('INSERT INTO project(id,worktree,name,time_created,time_updated,sandboxes,generation) VALUES(?,?,?,?,?,?,?)').run('build-preservation-424',sample+'/project','Original user database marker',100,100,'[]','40b07244-f5ed-4fcf-b876-c94957bcb444')
 db.exec('PRAGMA user_version=1');db.close(true)
 fs.writeFileSync(sample+'/cache/version','0');fs.writeFileSync(sample+'/cache/build-preservation-marker.txt','original-user-cache-marker-424')
}
const facts={at:new Date().toISOString(),actualUser:inspect(user),sample:inspect(root+'/sample-user/data/opencorvus.db'),sampleCache:{version:fs.readFileSync(root+'/sample-user/cache/version','utf8'),marker:fs.readFileSync(root+'/sample-user/cache/build-preservation-marker.txt','utf8')}}
const db=new SQLite(root+'/sample-user/data/opencorvus.db',{readonly:true});const sampleRows=db.query('SELECT * FROM project').all();db.close(true)
const value={...facts,sampleRows};fs.writeFileSync(root+'/inventory-'+phase+'.json',JSON.stringify(value,null,2))
console.log(JSON.stringify({phase,actualUser:{version:facts.actualUser.version,modified:facts.actualUser.metadata.mtime,nonemptyTables:facts.actualUser.counts.filter(c=>c.count>0)},sample:{version:facts.sample.version,rows:sampleRows,cache:facts.sampleCache}},null,2))
