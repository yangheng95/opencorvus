import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import {Database as SQLite} from 'bun:sqlite'
const root=import.meta.dir
const before=JSON.parse(fs.readFileSync(root+'/inventory-before.json','utf8'))
const after=JSON.parse(fs.readFileSync(root+'/inventory-after.json','utf8'))
const build=JSON.parse(fs.readFileSync(root+'/full-build-result.json','utf8'))
const generator=JSON.parse(fs.readFileSync(root+'/root-generate-result.json','utf8'))
const runtime=JSON.parse(fs.readFileSync(root+'/runtime-migration-result.json','utf8'))
const schemaObjects=(file:string)=>{
 const db=new SQLite(':memory:')
 try{db.exec(fs.readFileSync(file,'utf8'));return db.query("SELECT type,name,tbl_name,sql FROM sqlite_schema WHERE name NOT LIKE 'sqlite_%' ORDER BY type,name").all()}finally{db.close(true)}
}
const baselineObjects=schemaObjects('packages/opencorvus/src/storage/migrations/0001-baseline.sql')
const revisionObjects=schemaObjects('packages/opencorvus/src/storage/migrations/0002-grant-decision-index.sql')
assert.deepEqual(revisionObjects,baselineObjects)
const retained=(v:any)=>({version:v.version,objects:v.objects,counts:v.counts,physical:{ino:v.metadata.ino,dev:v.metadata.dev,size:v.metadata.size,mtimeMs:v.metadata.mtimeMs}})
assert.deepEqual(retained(after.actualUser),retained(before.actualUser))
assert.deepEqual(after.actualUser.version,{user_version:1})
assert.deepEqual(retained(after.sample),retained(before.sample))
assert.deepEqual(after.sampleRows,before.sampleRows)
assert.deepEqual(after.sample.version,{user_version:1})
assert.deepEqual(after.sampleCache,{version:'0',marker:'original-user-cache-marker-424'})
assert.deepEqual({exitCode:build.exitCode,settled:build.settlementConfirmed},{exitCode:0,settled:true})
assert.deepEqual({exitCode:generator.exitCode,settled:generator.settlementConfirmed},{exitCode:0,settled:true})
assert.deepEqual(runtime.version,[{user_version:2}])
const expected=before.sampleRows.map(({id,worktree,name,time_created,time_updated,sandboxes,generation}:any)=>({id,worktree,name,time_created,time_updated,sandboxes,generation}))
assert.deepEqual(runtime.rows,expected)
const backup=path.join(root,'migration-runtime/data/migration-backups',runtime.backups[0])
const db=new SQLite(backup,{readonly:true})
try {
 assert.deepEqual(db.query('PRAGMA user_version').get(),{user_version:1})
 assert.deepEqual(db.query('SELECT * FROM project').all(),before.sampleRows)
}finally{db.close(true)}
const trace=fs.readFileSync(root+'/trace-full.jsonl','utf8').trim().split('\n').map(line=>JSON.parse(line))
const runtimeRoots=trace.filter(e=>e.kind==='runtime-initialization').map(e=>({entry:path.basename(e.argv[1]),root:e.root}))
const firstRuns=trace.filter(e=>e.kind==='packaged-first-run')
const checks=trace.filter(e=>e.kind==='migration-check')
assert.deepEqual(checks.map(e=>e.database),[':memory:'])
assert.deepEqual(firstRuns.map(e=>e.realProvider),[false])
const receipt={reviewedAt:new Date().toISOString(),migrationVersions:{firstBaseline:1,currentFormat:2,physicalSchemaObjects:baselineObjects.length,dataMigration:'Historical saved-grant decision-index audit records; original authorizations/results retained'},actualUser:{version:after.actualUser.version,physical:retained(after.actualUser).physical,businessCounts:after.actualUser.counts.filter((e:any)=>['project','session','message','task'].includes(e.table))},sample:{version:after.sample.version,rows:after.sampleRows,cache:after.sampleCache},normalRuntimeMigration:{version:runtime.version,rows:runtime.rows,backupVersion:1},build,generator,runtimeRoots,firstRuns,migrationChecks:checks}
fs.writeFileSync(root+'/review-result.json',JSON.stringify(receipt,null,2));console.log(JSON.stringify(receipt,null,2))
