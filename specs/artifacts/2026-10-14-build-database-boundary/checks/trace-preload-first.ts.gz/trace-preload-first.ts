import fs from 'node:fs'
const output=process.env.OPENCORVUS_BUILD_TRACE_FILE!
const emit=(fact:unknown)=>fs.appendFileSync(output,JSON.stringify({at:new Date().toISOString(),pid:process.pid,...fact as object})+'\n')
emit({kind:'process',cwd:process.cwd(),argv:process.argv,root:process.env.OPENCORVUS_HOME})
Bun.plugin({name:'passive-build-database-observation',setup(builder){
 builder.onLoad({filter:/[\\/]src[\\/]global[\\/]index\.ts$/},async({path})=>{
  const original=await Bun.file(path).text()
  return {loader:'ts',contents:original.replace('await initializeOpenCorvusRuntimeDirectories(runtimePaths())',`await initializeOpenCorvusRuntimeDirectories(runtimePaths())
console.error("BUILD_RUNTIME_OBSERVATION", JSON.stringify({pid:process.pid,root:Global.Path.root,argv:process.argv}))`)}
 })
 builder.onLoad({filter:/[\\/]src[\\/]storage[\\/]db\.ts$/},async({path})=>{
  const original=await Bun.file(path).text()
  return {loader:'ts',contents:original.replace('function openOwnedSqlite(dbPath: string, options:',`function openOwnedSqlite(dbPath: string, options:`).replace('const dbPath = Path()','const dbPath = Path()\n    console.error("BUILD_DATABASE_OBSERVATION", JSON.stringify({pid:process.pid,path:dbPath,stack:new Error().stack}))')}
 })
 builder.onLoad({filter:/[\\/]src[\\/]storage[\\/]schema-migration\.ts$/},async({path})=>{
  const original=await Bun.file(path).text()
  return {loader:'ts',contents:original.replace('const expected = new SQLite(":memory:")','console.error("BUILD_MIGRATION_CHECK_OBSERVATION", JSON.stringify({pid:process.pid,database:":memory:",root:process.env.OPENCORVUS_HOME}))\n  const expected = new SQLite(":memory:")')}
 })
 builder.onLoad({filter:/[\\/]script[\\/]check-packaged-first-run\.ts$/},async({path})=>{
  const original=await Bun.file(path).text()
  return {loader:'ts',contents:original.replace('process.chdir(root)','process.chdir(root)\nconsole.error("BUILD_FIRST_RUN_OBSERVATION", JSON.stringify({pid:process.pid,root:process.env.OPENCORVUS_HOME,realProvider}))')}
 })
}})
