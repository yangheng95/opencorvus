import fs from 'node:fs'
import zlib from 'node:zlib'
import path from 'node:path'
const root=import.meta.dirname,artifact='specs/artifacts/2026-10-19-goal-home-discoverability'
fs.appendFileSync('specs/records/2026-10/2026-10-19-goal-home-discoverability.md',`\n## 最终资格与交付边界\n\nverified 18625使用最终50.34秒正式构建。11/12为最终英文/中文默认首页，英文三列正文对齐，标题改为通用工作；13为原Work真实创建表单，创建按钮突出、明确当前owner及启用含义。14为打开右dock后转到新对话过程的早期截图，dock被正常导航关闭，不能当成打开dock的首页资格；15动画完成但鼠标停留新对话显示tooltip。16/17把真实桌面左栏拉宽，使工作区缩窄，三步骤自动单列且完整可达。18/19首次拖动没有命中手柄，不能作增高资格；读取真实手柄位置后20实际增高输入，21真实滚轮将Goal全部内容与按钮滚入视野。22最终帮助，23回到常规输入和原左栏宽度后的首页。未扩大到移动端/平板。\n\n填写按钮实际聚焦chatTextarea（after只读activeElement观察），草稿可编辑且未发送，清空后恢复既有历史。创建表单只打开和阅读，未提交Goal；本批不宣称目标创建/暂停/自动续跑全链新增资格。UI只用真实交互/截图人工复核，没有新增或运行UI自动化测试。最终overlay typecheck、i18n（两语言2501顶层key）、CSS token checker、官方Node Vite和renderer surface checker、docs:check及architecture-index exit0。首次CSS checker指出自定义line-height脱离公共字体角色，已改用canonical normal角色，原失败日志保留；非UI业务逻辑及schema未改变。\n\n三个scope均公开shutdown200、原59082/24757/99962 joined exit0、native physical/output/request完整结算、auth/models成对退休。每scope两次真实gpt-6.1-sol流预检、200和reader EOF，共6次，无业务输入。额外私有authority两个文件也精确退休；原Codex authority文件尺寸及mtime保持准备前。after/verified原server request只读事实保留，before原共享dev.log时间段未留存，不把空集合当作无请求或无异常。截图、原源码、检查及选定物理回执归档；凭据、DB和Provider完整body不入库。下一批继续查全局首页Settings/General的project config错误，不把该问题包装为已解决。\n`)
fs.writeFileSync(artifact+'/README.md',`# Goal用法与默认首页视觉证据（2026-10-19）\n\n对应[Recall与调查](../../records/2026-10/2026-10-19-goal-home-discoverability.md)。正式开发入口/ui，三个独立不可变scope，未操作用户18571页面。\n\n|图|人工观察|\n|---|---|\n|01—03|原首页孤立Goal条、误标题帮助、已有Work真实创建表单|\n|04—06|首版英文首页、真实输入草稿与聚焦、帮助|\n|07—10|首版中文首页/帮助、已有Work创建入口与表单|\n|11—13|最终中英文首页（正文对齐及通用工作标题）、真实创建表单|\n|14—15|新对话导航中早期宽度及结束后的hover提示；未证明dock保持开启|\n|16—17|真实桌面拉宽左栏后，Goal步骤单列完整显示；内容此时未溢出|\n|18—19|首次拖动未命中手柄，输入高度未变；不能作增高或滚动成功证据|\n|20—21|真实增高输入及滚轮滚到完整Goal操作|\n|22—23|最终中文帮助、回到常规输入及原左栏宽度的首页|\n\nchecks/保存原源码、方案脚本、构建与检查日志、after/verified原请求事实；before共享原日志在后续启动后已改写，其空读取不代表零请求。runtime/保存3次公开shutdown200、原生物理结算、成对清理和选定Provider摘要（每scope2次实际gpt-6.1-sol流预检、200、reader EOF）。不保存完整Provider body、auth/models或数据库。创建表单未提交，本批为可发现性/视觉资格，不宣称新增Goal自动续跑端到端资格。\n`)
fs.writeFileSync(artifact+'/checks/finish.mjs.gz',zlib.gzipSync(fs.readFileSync(root+'/finish.mjs')))
const walk=dir=>fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(dir,e.name)):[path.join(dir,e.name)])
const values=[]
function collect(obj){for(const [key,value] of Object.entries(obj)){if(value&&typeof value==='object')collect(value);else if(typeof value==='string'&&value.length>16&&/access|refresh|token|key|secret|password|account/i.test(key))values.push(value)}}
for(const file of ['C:/Users/hengu/.codex/auth.json','C:/Users/hengu/AppData/Local/opencorvus/data/auth.json'])collect(JSON.parse(fs.readFileSync(file,'utf8')))
if(!values.length)throw Error('Actual credential material required for memory-only disclosure review')
for(const file of walk(artifact)){
 if(file.endsWith('.jpg'))continue
 const bytes=fs.readFileSync(file),body=(file.endsWith('.gz')?zlib.gunzipSync(bytes):bytes).toString('utf8')
 for(const value of values)if(body.includes(value))throw Error('Credential disclosure: '+file)
}
console.log(JSON.stringify({artifactFiles:walk(artifact).length,disclosureReview:'passed',screenshots:23,scopes:3}))
