import fs from 'node:fs'
import path from 'node:path'
import zlib from 'node:zlib'
import assert from 'node:assert/strict'
const root=import.meta.dirname,dest=path.resolve('specs/artifacts/2026-10-19-goal-home-discoverability')
const phases=['before','after','verified'],read=file=>JSON.parse(fs.readFileSync(file,'utf8'))
const save=(name,bytes)=>{const file=path.join(dest,name);fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,zlib.gzipSync(bytes))}
const summaries=[]
for(const phase of phases){
 const base=`C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-19/goal-home-433-${phase}/evidence`
 const native=read(base+'/native-host-settled.json'),clean=read(base+'/physical-terminal-and-pair-cleanup.json')
 for(const key of ['physicalCompletion','outputDrainComplete','requestCleanupComplete'])assert.equal(native[key],true)
 assert.equal(clean.pairedCleanupComplete,true);assert.equal(native.terminal.exitCode,0)
 assert.equal(read(base+'/launcher-child-exit.json').childExitCode,0);assert.equal(read(base+'/public-shutdown.json').statusCode,200)
 for(const name of ['native-host-ready.json','native-host-settled.json','physical-terminal-and-pair-cleanup.json','launcher-child-exit.json','public-shutdown.json','preflight-ready.json','provider-pair-staging.json'])save(`runtime/${phase}/${name}.gz`,fs.readFileSync(base+'/'+name))
 const audits=fs.readdirSync(base).filter(name=>/^provider-.*\.json$/.test(name)&&name!=='provider-pair-staging.json').map(name=>({name,value:read(base+'/'+name)})).filter(entry=>Array.isArray(entry.value.requests)).sort((a,b)=>b.value.requests.length-a.value.requests.length||Date.parse(b.value.observedAt)-Date.parse(a.value.observedAt))
 const last=audits[0];assert(last)
 const requests=last.value.requests.map(({model,streaming,status,response_reader})=>({model,streaming,status,response_reader}))
 for(const r of requests){assert.equal(r.model,'gpt-6.1-sol');assert.equal(r.streaming,true);assert.equal(r.status,200);assert.equal(r.response_reader.state,'settled');assert.equal(r.response_reader.terminal.kind,'eof')}
 save(`runtime/${phase}/provider-summary.json.gz`,JSON.stringify({source:last.name,observedAt:last.value.observedAt,requests},null,2))
 summaries.push({phase,requests:requests.length,readers:requests.map(r=>r.response_reader.terminal.kind)})
}
const prep=read(root+'/authority-preparation.json'),privateRoot=path.resolve(prep.privateAuthority)
assert.equal(fs.realpathSync(privateRoot).toLowerCase(),privateRoot.toLowerCase());assert.equal(fs.lstatSync(privateRoot).isSymbolicLink(),false)
const retired=[]
for(const name of ['auth.json','models.json']){
 const file=path.resolve(privateRoot,name);assert.equal(path.dirname(file),privateRoot)
 assert.equal(fs.lstatSync(file).isSymbolicLink(),false);fs.unlinkSync(file);retired.push({name,outcome:'retired'})
}
const original=fs.statSync(prep.source)
const receipt={observedAt:new Date().toISOString(),privateAuthority:privateRoot,retired,sourceBytes:original.size,sourceModifiedAtMs:original.mtimeMs,sourceUnchanged:original.size===prep.sourceBytes&&original.mtimeMs===prep.sourceModifiedAtMs,physicalScopes:phases.length,provider:summaries}
fs.writeFileSync(root+'/authority-retired.json',JSON.stringify(receipt,null,2))
const walk=dir=>fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(dir,e.name)):[path.join(dir,e.name)])
for(const file of walk(root)){
 if(!/\.(ts|mjs|ps1|json|log|tsx|css)$/.test(file)||file.includes('conversation-format-discarded'))continue
 save('checks/'+path.relative(root,file)+'.gz',fs.readFileSync(file))
}
console.log(JSON.stringify(receipt,null,2))
