import fs from 'node:fs'
for(const [locale,copy] of Object.entries({
 'zh-CN':{
  'chat.home_subtitle':'描述你想完成的事情，从一次对话开始。',
  'continuous_goal.home.title':'用持续目标（Goal）推进长期工作',
  'continuous_goal.home.body':'让会话跨轮次持续推进，并保留明确的完成标准与预算。',
  'continuous_goal.home.begin':'填写第一条需求',
  'continuous_goal.guide.start.title':'先开始一次会话',
  'continuous_goal.guide.start.body':'在上方发送需求，或从左侧打开已有 Chat、Task 或 Mission。',
  'continuous_goal.guide.define.title':'创建持续目标',
  'continuous_goal.guide.define.body':'点击会话顶部的“创建目标”，填写成果、验收标准和可选预算。',
  'continuous_goal.guide.manage.title':'查看进度，随时暂停',
  'continuous_goal.guide.manage.body':'创建后可自动续跑。在顶部查看用量、调整预算、暂停或标记完成。',
  'continuous_goal.activation_hint':'点击“创建目标”即启用自动续跑；预算留空表示不设上限。',
 },
 'en-US':{
  'chat.home_subtitle':'Describe the outcome you need. Start with a conversation.',
  'continuous_goal.home.title':'Keep going with a continuous goal',
  'continuous_goal.home.body':'Work across turns with clear completion criteria and an optional budget.',
  'continuous_goal.home.begin':'Write your first request',
  'continuous_goal.guide.start.title':'Start a conversation',
  'continuous_goal.guide.start.body':'Send a request above, or open an existing Chat, Task, or Mission from the sidebar.',
  'continuous_goal.guide.define.title':'Create its goal',
  'continuous_goal.guide.define.body':'Choose Create goal at the top of the conversation. Add an outcome, acceptance criteria, and optional budgets.',
  'continuous_goal.guide.manage.title':'Track progress and pause',
  'continuous_goal.guide.manage.body':'Creation enables automatic continuation. Use the top bar to review usage, adjust budgets, pause, or mark complete.',
  'continuous_goal.activation_hint':'Create goal enables automatic continuation. A blank budget means no limit.',
 }
})){
 const file=`packages/overlay/src/i18n/${locale}.json`,body=fs.readFileSync(file,'utf8'),tail=body.lastIndexOf('}')
 fs.writeFileSync(file,body.slice(0,tail).trimEnd()+',\n'+Object.entries(copy).map(([k,v])=>'  '+JSON.stringify(k)+': '+JSON.stringify(v)).join(',\n')+'\n}\n')
}
for(const file of ['packages/overlay/src/styles/surfaces/conversation.css','packages/overlay/src/styles/surfaces/continuous-goal.css']){
 const body=fs.readFileSync(file,'utf8').replaceAll('--ui-line-height-body','--ui-line-height-normal').replace('font-size: calc(28px * var(--ui-scale));','font-size: var(--ui-font-page);');fs.writeFileSync(file,body)
}
fs.appendFileSync('specs/records/2026-10/2026-10-19-goal-home-discoverability.md',`\n## Before真实观察与实施决定\n\n18621正式当前bundle截图01确认Goal状态条孤立于顶端，输入和示例居中、上下大块留白；02确认“About goals”竟打开标题为“Create a continuous goal”的无owner说明框，没有可操作创建入口。03为已有原Work上的真实创建表单，未填写/提交。before已关闭自有页并公开shutdown200、原59082 joined exit0。原Provider预检通过，未发业务。\n\n决定默认页移除顶端无owner状态条，把同一ContinuousGoalControl以home呈现放到输入/示例之后，提供三步骤、帮助与仅聚焦输入框的按钮。已有真实owner仍使用同一Control/HTTP数据源；Help无owner时标题改为真实帮助标题，表单补充创建即启用及预算空值的实际含义。首页使用已有page字体角色、靠上有界留白，整体可滚动以容纳说明；不伪造owner或新目标。没有新增后端行为。\n`)
