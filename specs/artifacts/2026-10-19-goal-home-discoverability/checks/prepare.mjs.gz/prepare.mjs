import fs from 'node:fs'
const root='.tmp-product-iteration/goal-home-433',phase=process.argv[2]
if(!['before','after','verified'].includes(phase))throw Error('Explicit phase required')
const base='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-19',tag='goal-home-433-'+phase,port=phase==='before'?18621:phase==='after'?18623:18625,bundle=base+'/'+tag+'-bundle/bin'
if(fs.existsSync(bundle))throw Error('Fresh immutable publication required')
fs.mkdirSync(bundle,{recursive:true});fs.copyFileSync('.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64/bun.exe',bundle+'/bun.exe');fs.cpSync('packages/overlay/dist-vite',bundle+'/ui',{recursive:true})
fs.mkdirSync(root+'/'+phase,{recursive:true})
for(const name of ['launch.ps1','settle.ps1','shutdown.ps1']){
 let text=fs.readFileSync('.tmp-product-iteration/workspace-location-read-failure-432/paired-after/'+name,'utf8')
 text=text.replaceAll('workspace-location-read-failure-432-paired-after',tag).replaceAll('.tmp-product-iteration/workspace-location-read-failure-432/paired-after',root+'/'+phase).replaceAll('workspace-location-read-failure-432-authority','goal-home-433-authority').replaceAll('18617',String(port))
 fs.writeFileSync(root+'/'+phase+'/'+name,text)
}
if(phase==='before'){
 for(const file of ['components/App.tsx','components/ContinuousGoalControl.tsx','components/Conversation.tsx','styles/surfaces/conversation.css','styles/surfaces/continuous-goal.css','i18n/en-US.json','i18n/zh-CN.json']){const target=root+'/original/'+file;fs.mkdirSync(target.slice(0,target.lastIndexOf('/')),{recursive:true});fs.copyFileSync('packages/overlay/src/'+file,target)}
 const spec='specs/records/2026-10/2026-10-19-goal-home-discoverability.md'
 fs.writeFileSync(spec,`# Goal使用路径与默认首页布局\n\n## Recall\n\n用户最新要求“我现在完全看不到goal怎么用的，而且默认页布局很怪”。持续单agent、真实页面人工视觉验收后提交推送，不使用子agent、UI自动化测试或独立Vite。保留原.bun和packages/opencorvus/bun。上一批432已完成根因修复和真实验证并提交f23fc7ad4；推送结果另核对。本批不改schema、调度、目标API或真实用户数据，不触碰18571用户页面。\n\n## 修改前分析与已读资料\n\n已读continuous-goal当前架构全部、07-panel公开合同、App/Conversation/ContinuousGoalControl、continuous-goal service及样式、双语翻译、main全局launcher、真实Conversation create/select入口及store/controller定义。全仓搜索Control两处生产挂载（主会话、SideChat）、home portal/composition、目标选择epoch与owner投影。可观察反馈是Goal用法难发现和默认布局异常；当前App无条件把owner为空的状态条放在顶端，文案只说先打开会话，其learn对话框也只有三段泛化解释。首页本体是absolute居中三行grid，overflow hidden；说明和输入区分离，增加内容后有裁剪风险。旧实现确保了真实owner与预算控制，却没有清晰的使用路径。这是UI信息架构问题，尚无调度/队列/终态机制异常证据。\n\n目标后端唯一实现及用户授权语义保持不变：Goal属于已有会话，创建/恢复可能开启自动续跑；不能为了首页入口造临时owner、影子Goal草稿或合成消息。预计调整主会话/默认页Control挂载、首页布局、同一Control的空态与帮助、双语文案；SideChat仍使用同一组件紧凑投影。无公共API、数据、LLM调用或持久格式修改，非UI正向测试不适用；构建和类型检查只作工具验证，不能代替视觉。\n\n## 实施前方案\n\n1. 新独立before/after不可变publication，端口18621/18623，复用成熟413 NativeService/ProcessFacade、600秒物理期限、完整auth/models绑定与真实gpt-6.1-sol预检。只读现有QA历史，不发送业务、不创建或改写目标。原授权凭据仅私有副本，最终精确退休。\n2. before真实首页、已有Work目标创建表单截图，确认入口与布局。UI改动必须以截图观察补充决定。\n3. 默认页将无owner Goal引导与输入区放在同一内容区，展示发送需求→创建目标/验收标准/可选预算→查看进度及暂停的明确步骤；开始填写仅聚焦真实composer，不发送或改写内容。真实owner仍只有唯一HTTP Control，突出创建按钮；帮助展示相同步骤及暂停语义，所有新增可见/无障碍内容双语。首页调整宽度、纵向位置、间距和溢出行为，不扩大到移动端。\n4. 官方隔离构建后在after真实页面复核默认页、中英文、帮助、聚焦后可编辑草稿、已有Work创建表单及返回历史。不把未提交表单当成真实Goal创建/执行验收。若视觉失败迭代再截图，不用DOM断言或截图比较程序。\n5. 自有页关闭，公开shutdown、原句柄join及物理清理，证据脱敏归档、同步三索引/架构、文档检查、范围提交、fresh fetch/merge及完整pending审查后正常push。持续goal保留active。\n`)
 const artifact='specs/artifacts/2026-10-19-goal-home-discoverability';fs.mkdirSync(artifact,{recursive:true});fs.writeFileSync(artifact+'/README.md','# Goal与首页视觉证据\n\n对应[Recall](../../records/2026-10/2026-10-19-goal-home-discoverability.md)。验收结果待真实观察后记录。\n')
 for(const [file,line] of [['specs/README.md','- [Goal与默认首页](records/2026-10/2026-10-19-goal-home-discoverability.md)：使用路径及首页布局。'],['specs/records/2026-10/README.md','- [Goal与默认首页](2026-10-19-goal-home-discoverability.md)：单agent真实视觉迭代。'],['specs/artifacts/README.md','- [Goal与默认首页](2026-10-19-goal-home-discoverability/README.md)：独立页面截图及结算证据。']])fs.appendFileSync(file,'\n'+line+'\n')
 let auth=fs.readFileSync('.tmp-product-iteration/workspace-location-read-failure-432/prepare-authority.mjs','utf8').replaceAll('workspace-location-read-failure-432-authority','goal-home-433-authority');fs.writeFileSync(root+'/prepare-authority.mjs',auth)
 fs.copyFileSync('.tmp-product-iteration/workspace-location-read-failure-432/build-ui.ts',root+'/build-ui.ts')
}
console.log(JSON.stringify({phase,port,tag,businessInputs:0}))
