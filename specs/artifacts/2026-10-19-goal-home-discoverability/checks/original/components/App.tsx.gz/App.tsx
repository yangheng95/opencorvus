import { Show, createMemo, createSignal, onCleanup, type JSX } from "solid-js"
import { AppDialogHost } from "./AppDialogHost"
import { CommandPalette } from "./CommandPalette"
import { ConnectionBadge } from "./ConnectionBadge"
import { ConfigDialogHost } from "./ConfigDialogHost"
import { ConnectionBanner } from "./ConnectionBanner"
import { ProjectMemoryBanner } from "./ProjectMemoryBanner"
import { ChatHeaderRightDockToggle } from "./ChatHeaderRightDockToggle"
import { ConversationAgentRail } from "./ConversationAgentRail"
import { GoalDialogHost } from "./GoalDialogHost"
import { Icon } from "./ui/Icon"
import { ImagePreviewHost } from "./ImagePreview"
import { InteractionDialogHost } from "./InteractionDialogHost"
import { SidebarVersionLabel } from "./SidebarVersionLabel"
import { SidebarUpdateButton } from "./SidebarUpdateButton"
import { SessionDialogHost } from "./SessionDialogHost"
import { TaskStatusHeader } from "./TaskStatusHeader"
import { ContinuousGoalControl } from "./ContinuousGoalControl"
import { TaskOutcomeBadge } from "./TaskOutcomeBadge"
import { TitlebarBrand } from "./titlebar/TitlebarBrand"
import { TitlebarMenubar } from "./titlebar/TitlebarMenubar"
import { TitlebarNavigation } from "./titlebar/TitlebarNavigation"
import { WindowControls } from "./WindowControls"
import { WorkspaceEditorLaunchers, workspaceEditorLaunchersAvailable } from "./WorkspaceEditorLaunchers"
import { ProjectRuntimeToolbarActions } from "./TaskDirBar"
import { Button } from "./ui/Button"
import { Feedback } from "./ui/Feedback"
import { formatErrorDetails } from "../services/diagnostics"
import { DropdownMenu } from "./ui/DropdownMenu"
import { Tooltip } from "./ui/Tooltip"
import { t } from "../utils/i18n"
import { debugCopyFailureMessage } from "../utils/debug-info"
import { conversationExperienceIcon } from "../services/conversation-experience"
import { formatUsageStrip } from "../utils/format-usage"
import type { RightDockPanel } from "./RightDock"
import { boardStore } from "../store/board"
import { appStore } from "../store/app"
import { cardTreeStore } from "../store/card-tree"
import { dialogStore } from "../store/dialog"
import { openConfigDialog } from "../services/config-dialog-control"
import type { AutomationRunSession } from "../services/automations"
import type { WorkLedgerItemRow, WorkLedgerMissionRow, WorkLedgerTaskRow } from "../services/work-ledger"

const MAILBOX_HOVER_OPEN_DELAY_MILLISECONDS = 180

function workLedgerRenameLabel(row: WorkLedgerItemRow): string {
  if (row.kind === "mission") return t("work_ledger.action.rename_mission")
  if (row.kind === "chat") return t("work_ledger.action.rename_chat")
  return t("task.rename_button_title")
}

function workLedgerArchiveLabel(row: WorkLedgerItemRow): string {
  if (row.kind === "mission") return t("mission.ledger.archive_title")
  if (row.kind === "chat") return t("coding_assistant.ledger.archive_title")
  return t("task.archive_button_title")
}

function ChatViewTitle(props: {
  title: () => string
  item: () => WorkLedgerItemRow | null
  onCopyDebug: () => Promise<void>
  onPinnedChange: (row: WorkLedgerItemRow, pinned: boolean) => void | Promise<void>
  onRename: (row: WorkLedgerItemRow) => void | Promise<void>
  onArchive: (row: WorkLedgerItemRow) => void | Promise<void>
}) {
  const usageText = createMemo(() => formatUsageStrip(cardTreeStore.usageAggregate))
  const [copyFeedback, setCopyFeedback] = createSignal<
    { kind: "copied" } | { kind: "failed"; message?: string } | null
  >(null)
  const copyFeedbackText = createMemo(() => {
    const feedback = copyFeedback()
    if (feedback?.kind === "copied") return t("chat.debug_copy_success")
    if (feedback?.kind === "failed") return feedback.message || t("markdown.copy_failed")
    return ""
  })
  let copyFeedbackTimer: number | undefined

  onCleanup(() => {
    if (copyFeedbackTimer !== undefined) window.clearTimeout(copyFeedbackTimer)
  })

  async function copyDebugInfo(): Promise<void> {
    if (copyFeedbackTimer !== undefined) window.clearTimeout(copyFeedbackTimer)
    try {
      await props.onCopyDebug()
      setCopyFeedback({ kind: "copied" })
    } catch (error) {
      console.error("[chat-view-title dblclick] clipboard write failed", error)
      setCopyFeedback({
        kind: "failed",
        message: debugCopyFailureMessage(error, t("markdown.copy_failed")),
      })
    }
    copyFeedbackTimer = window.setTimeout(() => {
      setCopyFeedback(null)
      copyFeedbackTimer = undefined
    }, 4000)
  }

  return (
    <div class="chat-title-group">
      <Tooltip.Root openDelay={160} closeDelay={80} placement="bottom-start" gutter={8} fitViewport>
        <Tooltip.Trigger
          as="span"
          class="chat-title chat-title-usage-trigger oc-surface-header__title"
          id="chatViewTitle"
          data-copy-feedback={copyFeedback()?.kind}
          onDblClick={() => void copyDebugInfo()}
        >
          {copyFeedbackText() || props.title()}
        </Tooltip.Trigger>
        <Tooltip.Portal>
          <Tooltip.Content class="chat-title-usage-tooltip" data-ui="chat-title-usage-tooltip">
            <Show when={usageText()}>
              <span class="chat-title-usage-tooltip__label">{t("chat.usage_aria")}</span>
              <strong class="chat-title-usage-tooltip__value" id="chatTitleUsage">
                {usageText()}
              </strong>
            </Show>
            <span class="chat-title-usage-tooltip__debug-hint">{copyFeedbackText() || t("chat.debug_copy_hint")}</span>
          </Tooltip.Content>
        </Tooltip.Portal>
      </Tooltip.Root>
      <span class="chat-title-copy-feedback-a11y" role="status" aria-live="polite" aria-atomic="true">
        {copyFeedbackText()}
      </span>
      <Show when={props.item()}>
        {(item) => (
          <DropdownMenu.Root placement="bottom-start" gutter={6} fitViewport>
            <DropdownMenu.Trigger
              as={Button}
              type="button"
              variant="ghost"
              size="icon"
              tone="neutral"
              data-chrome="icon-action"
              data-ui="chat-title-more"
              title={t("project.more_actions")}
              aria-label={t("project.more_actions")}
            >
              <Icon name="more-horizontal" size="medium" />
            </DropdownMenu.Trigger>
            <DropdownMenu.Portal>
              <DropdownMenu.Content class="chat-title-menu" data-ui="chat-title-menu">
                <DropdownMenu.Item
                  as="button"
                  type="button"
                  data-ui="chat-title-copy-debug"
                  onSelect={() => void copyDebugInfo()}
                >
                  <Icon name="copy" size="medium" />
                  <span>{t("chat.debug_copy_action")}</span>
                </DropdownMenu.Item>
                <DropdownMenu.Item
                  as="button"
                  type="button"
                  data-ui="chat-title-pin"
                  data-pinned={item().pinned ? "true" : "false"}
                  onSelect={() => props.onPinnedChange(item(), !item().pinned)}
                >
                  <Icon name="pin" size="medium" />
                  <span>{item().pinned ? t("work_ledger.action.unpin") : t("work_ledger.action.pin")}</span>
                </DropdownMenu.Item>
                <DropdownMenu.Item
                  as="button"
                  type="button"
                  data-ui="chat-title-rename"
                  onSelect={() => props.onRename(item())}
                >
                  <Icon name="edit" size="medium" />
                  <span>{workLedgerRenameLabel(item())}</span>
                </DropdownMenu.Item>
                <DropdownMenu.Item
                  as="button"
                  type="button"
                  data-ui="chat-title-archive"
                  onSelect={() => props.onArchive(item())}
                >
                  <Icon name="archive" size="medium" />
                  <span>{workLedgerArchiveLabel(item())}</span>
                </DropdownMenu.Item>
              </DropdownMenu.Content>
            </DropdownMenu.Portal>
          </DropdownMenu.Root>
        )}
      </Show>
    </div>
  )
}

export interface AppProps {
  sidebarToggle: JSX.Element
  leftPanelActions: JSX.Element
  workLedger: (navigationMount: HTMLDivElement) => JSX.Element
  mailbox: JSX.Element
  primarySurface: () => "conversation" | "mission-board"
  missionBoard: JSX.Element
  conversation: (container: HTMLDivElement) => JSX.Element
  composer: JSX.Element
  homeActive: boolean
  rightDock: JSX.Element
  logViewer: JSX.Element
  onOpenRightDockPanel: (panel: RightDockPanel) => void
  onOpenSubagentConversation: (sessionID: string) => void
  onOpenRightDockAddMenu: () => void
  onNewChat: () => Promise<void>
  onSelectMission: (row: WorkLedgerMissionRow) => Promise<void>
  onSelectTask: (taskID: string, directory: string) => Promise<void>
  onSelectChat: (sessionID: string, directory: string, experience: "chat" | "work") => Promise<void>
  conversationExperience: () => "chat" | "work" | undefined
  conversationTitle: () => string
  conversationItem: () => WorkLedgerItemRow | null
  onCopyConversationDebug: () => Promise<void>
  onConversationPinnedChange: (row: WorkLedgerItemRow, pinned: boolean) => void | Promise<void>
  onRenameConversationItem: (row: WorkLedgerItemRow) => void | Promise<void>
  onArchiveConversationItem: (row: WorkLedgerItemRow) => void | Promise<void>
  onOpenAutomationSession: (session: AutomationRunSession) => Promise<void>
}

export function App(props: AppProps) {
  const [navigationMount, setNavigationMount] = createSignal<HTMLDivElement>()
  let chatScroll!: HTMLDivElement
  let mailboxHoverOpenTimer: number | undefined
  let mailboxHoverCloseTimer: number | undefined
  const [mailboxHoverPreview, setMailboxHoverPreview] = createSignal(false)
  const [mailboxPinned, setMailboxPinned] = createSignal(false)
  const mailboxVisible = () => mailboxPinned() || mailboxHoverPreview()

  function cancelMailboxHoverOpen(): void {
    if (mailboxHoverOpenTimer !== undefined) window.clearTimeout(mailboxHoverOpenTimer)
    mailboxHoverOpenTimer = undefined
  }

  function cancelMailboxHoverClose(): void {
    if (mailboxHoverCloseTimer !== undefined) window.clearTimeout(mailboxHoverCloseTimer)
    mailboxHoverCloseTimer = undefined
  }

  function scheduleMailboxHoverPreview(): void {
    cancelMailboxHoverClose()
    cancelMailboxHoverOpen()
    mailboxHoverOpenTimer = window.setTimeout(() => {
      openMailboxHoverPreview()
    }, MAILBOX_HOVER_OPEN_DELAY_MILLISECONDS)
  }

  function scheduleMailboxHoverPreviewClose(): void {
    cancelMailboxHoverOpen()
    cancelMailboxHoverClose()
    mailboxHoverCloseTimer = window.setTimeout(() => {
      mailboxHoverCloseTimer = undefined
      setMailboxHoverPreview(false)
    }, MAILBOX_HOVER_OPEN_DELAY_MILLISECONDS)
  }

  function openMailboxHoverPreview(): void {
    cancelMailboxHoverOpen()
    setMailboxHoverPreview(true)
  }

  function toggleMailbox(): void {
    cancelMailboxHoverOpen()
    cancelMailboxHoverClose()
    if (mailboxPinned()) {
      setMailboxPinned(false)
      setMailboxHoverPreview(false)
      return
    }
    setMailboxPinned(true)
  }

  onCleanup(() => {
    cancelMailboxHoverOpen()
    cancelMailboxHoverClose()
  })

  return (
    <>
      <header class="titlebar oc-material-glass" id="titlebar">
        <div class="titlebar-top-row" data-tauri-drag-region>
          <div class="titlebar-left" data-tauri-drag-region>
            <div id="solidSidebarToggle">{props.sidebarToggle}</div>
            <div id="solidTitlebarNavigation">
              <TitlebarNavigation />
            </div>
            <div id="solidTitlebarMenu">
              <TitlebarMenubar onNewChat={props.onNewChat} />
            </div>
          </div>
          <div class="titlebar-spacer" data-tauri-drag-region />
          <WindowControls />
        </div>
      </header>

      <main class="panel">
        <div class="panel-body" id="panelBody">
          <nav class="workspace-navigation" id="workspaceNavigation" aria-label={t("work_ledger.shortcuts")}>
            <div ref={setNavigationMount} class="workspace-navigation-primary" />
            <div class="workspace-navigation-bottom">
              <Button
                type="button"
                variant="ghost"
                size="icon"
                tone="neutral"
                title={t("about.title")}
                aria-label={t("about.title")}
                onClick={() => openConfigDialog("about")}
              >
                <Icon name="interaction-question" size="medium" />
              </Button>
              <SidebarVersionLabel />
            </div>
          </nav>
          <div class="workspace-page-stack" id="workspacePageStack">
            <div
              class="workspace-primary-page"
              data-active={String(!dialogStore.config.open)}
              inert={dialogStore.config.open}
            >
              <div
                class="left-activity-shell oc-material-glass"
                id="leftActivityShell"
                onMouseEnter={cancelMailboxHoverClose}
                onMouseLeave={scheduleMailboxHoverPreviewClose}
              >
                <div class="workspace-contextbar" id="workspaceContextbar" data-tauri-drag-region>
                  <div class="titlebar-brand">
                    <div id="solidTitlebarBrand">
                      <TitlebarBrand />
                    </div>
                  </div>
                  <div class="titlebar-context-spacer" data-tauri-drag-region />
                  <div class="workspace-context-actions" data-no-drag="true">
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      tone="neutral"
                      class="workspace-command-action workspace-command-search"
                      data-chrome="icon-action"
                      data-ui="work-ledger-search-toggle"
                      hidden={mailboxVisible()}
                      title={t("cmdk.placeholder")}
                      aria-label={t("cmdk.placeholder")}
                      onClick={() => window.dispatchEvent(new CustomEvent("oc:open-command-palette"))}
                    >
                      <Icon name="search" size="medium" />
                    </Button>
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      tone="neutral"
                      class="workspace-command-action workspace-command-mailbox"
                      data-chrome="icon-action"
                      data-ui="mailbox-toggle"
                      data-active={String(mailboxVisible())}
                      title={t("mailbox.title")}
                      aria-label={t("mailbox.title")}
                      aria-controls="leftPanelMailbox"
                      aria-expanded={mailboxVisible()}
                      onMouseEnter={scheduleMailboxHoverPreview}
                      onClick={toggleMailbox}
                    >
                      <Icon name="mailbox" size="medium" />
                    </Button>
                  </div>
                </div>
                <aside class="sidebar" id="sidebar" data-collapsed="false">
                  <div class="side-panel-content sidebar-content">
                    <div class="sidebar-header oc-surface-header">
                      <div class="sidebar-title oc-surface-header__title" id="leftPanelTitle">
                        {mailboxVisible() ? t("mailbox.title") : t("work_ledger.title")}
                      </div>
                      <div
                        class="sidebar-header-actions oc-surface-header__actions"
                        id="solidLeftPanelActions"
                        data-active={String(!mailboxVisible())}
                        hidden={mailboxVisible()}
                      >
                        {props.leftPanelActions}
                      </div>
                    </div>
                    <div
                      class="side-activity-body sidebar-activity-body"
                      id="leftPanelWork"
                      data-side-activity="work"
                      data-active={String(!mailboxVisible())}
                    >
                      <div class="sidebar-body">
                        <div class="sidebar-list session-list-panel work-ledger-panel" id="workLedgerPanel">
                          <Show when={navigationMount()}>{(mount) => props.workLedger(mount())}</Show>
                        </div>
                      </div>
                    </div>
                    <div
                      class="side-activity-body sidebar-activity-body"
                      id="leftPanelMailbox"
                      data-side-activity="mailbox"
                      data-active={String(mailboxVisible())}
                    >
                      <div id="solidMailboxMount" class="mailbox-panel-mount">
                        {props.mailbox}
                      </div>
                    </div>
                    <footer class="sidebar-footer" aria-label={t("titlebar.connection_diagnostics")}>
                      <span class="sidebar-connection" id="solidConnBadge">
                        <ConnectionBadge />
                      </span>
                      <SidebarUpdateButton />
                    </footer>
                  </div>
                </aside>
              </div>
              <div
                class="pane-resizer pane-resizer-left"
                id="leftPaneResizer"
                role="separator"
                aria-orientation="vertical"
                aria-label={t("workspace.resize_left_panel")}
                aria-controls="sidebar workspaceMain"
                aria-valuemin="0"
                aria-valuemax="0"
                aria-valuenow="0"
                tabIndex={0}
              />
              <div class="workspace-main" id="workspaceMain">
                <div class="conversation-workspace" id="conversationWorkspace">
                  <section class="center-workbench" id="centerWorkbench" data-open="false">
                    <div class="center-workbench-body">
                      <div
                        class="center-workbench-view"
                        id="centerWorkbenchConversation"
                        data-workbench-view="conversation"
                        data-open={String(props.primarySurface() === "conversation")}
                        data-active={String(props.primarySurface() === "conversation")}
                      >
                        <div id="solidConversationAgentRailMount" class="conversation-agent-rail-host">
                          <ConversationAgentRail onOpenSubagentConversation={props.onOpenSubagentConversation} />
                        </div>
                        <div class="center-workbench-activity chat-conversation-activity">
                          <section class="chat" id="chatSection" data-empty-chat-home={String(props.homeActive)}>
                            <div
                              class="task-switch-progress"
                              id="taskSwitchProgress"
                              aria-label={t("workspace.loading_task")}
                              aria-busy="false"
                              data-active="false"
                            />
                            <header class="chat-header oc-surface-header">
                              <div class="chat-header-main oc-surface-header__main">
                                <span class="chat-title-icon" id="solidChatTitleIcon" aria-hidden="true">
                                  <Icon
                                    name={
                                      props.conversationExperience()
                                        ? conversationExperienceIcon(props.conversationExperience()!)
                                        : "file-document"
                                    }
                                    size="medium"
                                  />
                                </span>
                                <ChatViewTitle
                                  title={props.conversationTitle}
                                  item={props.conversationItem}
                                  onCopyDebug={props.onCopyConversationDebug}
                                  onPinnedChange={props.onConversationPinnedChange}
                                  onRename={props.onRenameConversationItem}
                                  onArchive={props.onArchiveConversationItem}
                                />
                                <Show
                                  when={
                                    props.conversationItem()?.kind === "task"
                                      ? (props.conversationItem() as WorkLedgerTaskRow)
                                      : undefined
                                  }
                                >
                                  {(task) => <TaskOutcomeBadge status={task().lifecycleStatus} />}
                                </Show>
                                <div class="chat-header-status" id="solidTaskStatusMount">
                                  <TaskStatusHeader />
                                </div>
                              </div>
                              <div class="chat-header-meta oc-surface-header__actions">
                                <div class="chat-header-actions" data-no-drag="true">
                                  <Show when={boardStore.selectedSource}>
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      tone="neutral"
                                      onClick={() => props.onOpenRightDockPanel("side-chat")}
                                      aria-label={t("side_chat.title")}
                                      title={t("side_chat.title")}
                                      data-ui="open-side-chat"
                                    >
                                      <Icon name="side-chat" size="medium" />
                                    </Button>
                                  </Show>
                                  <Show when={workspaceEditorLaunchersAvailable()}>
                                    <div id="solidChatHeaderEditorLaunchers">
                                      <WorkspaceEditorLaunchers />
                                    </div>
                                  </Show>
                                  <div id="solidChatHeaderRuntimeActions">
                                    <ProjectRuntimeToolbarActions
                                      anchorVisible={
                                        props.primarySurface() === "conversation" &&
                                        !props.homeActive &&
                                        !dialogStore.config.open
                                      }
                                      onOpenRightDockPanel={props.onOpenRightDockPanel}
                                      onOpenSubagentConversation={props.onOpenSubagentConversation}
                                      onOpenRightDockAddMenu={props.onOpenRightDockAddMenu}
                                      trailingAction={
                                        <div id="solidChatHeaderRightDockToggle">
                                          <ChatHeaderRightDockToggle />
                                        </div>
                                      }
                                    />
                                  </div>
                                </div>
                              </div>
                            </header>
                            <ContinuousGoalControl
                              selectionEpoch={boardStore.selectEpoch}
                              owner={(() => {
                                const item = props.conversationItem()
                                return item
                                  ? { kind: item.kind, id: item.kind === "task" ? item.id : item.sessionID, directory: item.directory }
                                  : undefined
                              })()}
                            />
                            <div class="chat-content-frame" id="chatContentFrame">
                              <div class="chat-message-pane" id="chatMessagePane">
                                <Show when={appStore.workspaceLocationError}>
                                  {(error) => (
                                    <Feedback
                                      tone="error"
                                      title={t("workspace.location_open_failed_title")}
                                      details={formatErrorDetails(error())}
                                    >
                                      {t("workspace.location_open_failed_message")}
                                    </Feedback>
                                  )}
                                </Show>
                                <div class="conversation-body" id="conversationBody">
                                  <div class="conversation-scroll-shell">
                                    <div
                                      class="chat-scroll session-content"
                                      id="chatScroll"
                                      aria-label={t("chat.title")}
                                      tabIndex={0}
                                      ref={chatScroll}
                                    >
                                      {props.conversation(chatScroll)}
                                    </div>
                                    <div class="chat-home-composition" id="chatHomeComposition">
                                      <div id="solidChatHomePromptMount" />
                                      <div id="solidChatComposer">{props.composer}</div>
                                      <div id="solidChatHomeAfterMount" />
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </section>
                        </div>
                      </div>
                      <div
                        class="center-workbench-view"
                        id="centerWorkbenchMissionBoard"
                        data-workbench-view="mission-board"
                        data-open={String(props.primarySurface() === "mission-board")}
                        data-active={String(props.primarySurface() === "mission-board")}
                      >
                        <div class="center-workbench-activity mission-board-activity">{props.missionBoard}</div>
                      </div>
                    </div>
                  </section>
                </div>
                <div
                  class="right-dock-resizer"
                  id="rightDockResizer"
                  data-open="false"
                  role="separator"
                  aria-orientation="vertical"
                  aria-label={t("workspace.resize_right_panel")}
                  aria-controls="rightDock"
                  aria-hidden="true"
                  tabIndex={-1}
                />
                <aside
                  class="right-dock"
                  id="rightDock"
                  data-open="false"
                  aria-label={t("right_dock.tools_panel")}
                  aria-hidden="true"
                >
                  {props.rightDock}
                </aside>
              </div>
            </div>
            <ConfigDialogHost onOpenAutomationSession={props.onOpenAutomationSession} />
          </div>
        </div>
      </main>

      <div id="connectionBannerHost">
        <ConnectionBanner />
      </div>
      <ProjectMemoryBanner />
      <div id="commandPaletteHost">
        <CommandPalette
          onNewChat={props.onNewChat}
          onSelectMission={props.onSelectMission}
          onSelectTask={props.onSelectTask}
          onSelectChat={props.onSelectChat}
        />
      </div>
      <div id="appDialogHost">
        <AppDialogHost />
      </div>
      <div id="sessionDialogHost">
        <SessionDialogHost />
      </div>
      <div id="interactionDialogHost">
        <InteractionDialogHost />
      </div>
      <div id="goalDialogHost">
        <GoalDialogHost />
      </div>
      <div id="imagePreviewHost">
        <ImagePreviewHost />
      </div>
      <div id="solidLogViewer">{props.logViewer}</div>
    </>
  )
}
