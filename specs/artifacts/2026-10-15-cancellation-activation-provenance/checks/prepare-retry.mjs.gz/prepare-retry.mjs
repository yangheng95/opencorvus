import fs from 'node:fs'
const root='.tmp-product-iteration/cancellation-activation-426'
const prior='cancellation-activation-426-after',tag='cancellation-activation-426-retry'
const base='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-15'
const bundle=base+'/'+tag+'-bundle/bin'
if(fs.existsSync(bundle))throw Error('Fresh retry occurrence required')
fs.mkdirSync(bundle,{recursive:true})
fs.copyFileSync('.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64/bun.exe',bundle+'/bun.exe')
fs.cpSync('packages/overlay/dist-vite',bundle+'/ui',{recursive:true})
fs.mkdirSync(root+'/retry',{recursive:true})
for(const name of ['launch.ps1','settle.ps1','shutdown.ps1']){
 let source=fs.readFileSync(root+'/after/'+name,'utf8').replaceAll(prior,tag).replaceAll(root+'/after',root+'/retry').replaceAll('18573','18575')
 fs.writeFileSync(root+'/retry/'+name,source)
}
for(const [from,to] of [['task-request.json','failed-task-request.json'],['task-accepted.json','task-accepted-http500.json'],['task-create.log','task-create-http500.log'],['create-driver.log','create-driver-http500.log']]){
 if(fs.existsSync(root+'/'+to))throw Error('Original observation already preserved')
 fs.copyFileSync(root+'/'+from,root+'/'+to)
}
let driver=fs.readFileSync(root+'/create-task.ps1','utf8').replaceAll(prior,tag).replaceAll('18573','18575')
driver=driver.replace("$taskRequestID=[Guid]::NewGuid().ToString()",`$taskRetryOriginal=Get-Content -Raw -LiteralPath "$taskScratch/failed-task-request.json"|ConvertFrom-Json
if($taskRetryOriginal.request -cne $taskRequest){throw 'Exact original retry message required'}
$taskRequestID=$taskRetryOriginal.requestID`)
fs.writeFileSync(root+'/create-task-retry.ps1',driver)
const artifact='specs/artifacts/2026-10-15-unicode-workspace-path'
fs.mkdirSync(artifact,{recursive:true})
fs.writeFileSync(artifact+'/README.md','# Unicode空白文件身份证据\n\n[方案与Recall](../../records/2026-10/2026-10-15-unicode-workspace-path.md)。真实Task HTTP500、公开路径及真实Git快照正向合同与同请求重试原件。完整验收结果在执行后补齐。\n')
for(const [file,line] of [
 ['specs/README.md','- [Unicode空白文件身份](records/2026-10/2026-10-15-unicode-workspace-path.md)：修复真实Task源树对合法文件名的误拒绝。'],
 ['specs/records/2026-10/README.md','- [Unicode空白文件身份](2026-10-15-unicode-workspace-path.md)：原创建500、唯一路径合同与同请求重试。'],
 ['specs/artifacts/README.md','- [Unicode空白文件身份](2026-10-15-unicode-workspace-path/README.md)：实际快照、路径/字节身份及Task验收。'],
]){const text=fs.readFileSync(file,'utf8');if(text.includes(line))throw Error('Already indexed');fs.writeFileSync(file,text.trimEnd()+'\n\n'+line+'\n')}
console.log(JSON.stringify({bundle,tag,port:18575,requestID:JSON.parse(fs.readFileSync(root+'/failed-task-request.json','utf8')).requestID}))
