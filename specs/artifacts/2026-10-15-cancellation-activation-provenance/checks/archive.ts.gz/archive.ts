import fs from 'node:fs'
import path from 'node:path'
import zlib from 'node:zlib'
import assert from 'node:assert/strict'
import {Database} from 'bun:sqlite'
const root=import.meta.dir,dest=path.resolve('specs/artifacts/2026-10-15-cancellation-activation-provenance')
const save=(name:string,value:string)=>{const target=path.join(dest,name);fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,zlib.gzipSync(value))}
const facts=JSON.parse(fs.readFileSync(root+'/facts-stopped.json','utf8'))
const streaming=JSON.parse(fs.readFileSync(root+'/facts-streaming.json','utf8'))
const original=JSON.parse(fs.readFileSync(root+'/failed-task-request.json','utf8'))
const selection=JSON.parse(fs.readFileSync(root+'/task-selection.json','utf8'))
assert.equal(selection.requestID,original.requestID)
const request=facts.events.find((e:any)=>e.type==='task.cancellation.requested')
const terminal=facts.events.find((e:any)=>e.type==='task.cancelled')
assert(request&&terminal,'Actual cancellation request and terminal required')
assert.equal(request.payload.execution_epoch,1);assert.equal(terminal.payload.execution_epoch,1)
assert.equal(terminal.correlation_id,request.correlation_id)
const assistant=facts.messages.find((m:any)=>m.role==='assistant')
assert(assistant)
assert.equal(assistant.error.name,'MessageAbortedError')
const expectedOrigin={actor:'user',source:'task.cancel',surface:'overlay.composer_stop',requestID:request.correlation_id,reason:request.payload.reason,taskID:selection.taskID,causationEventID:request.id}
assert.deepEqual(assistant.error.data.cancellation,expectedOrigin)
assert.equal(assistant.error.data.message,`Task-root activation ${assistant.activationID} is inapplicable under Task ${selection.taskID} cancellation ${request.id}`)
assert.equal(streaming.messages.find((m:any)=>m.id===assistant.id).time.completed,undefined)
assert.deepEqual(facts.sessions.map((s:any)=>s.kind),['root','orchestrator'])
const scopes=[]
for(const phase of ['after','retry']){
 const tag='cancellation-activation-426-'+phase
 const evidence='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-15/'+tag+'/evidence'
 const clean=JSON.parse(fs.readFileSync(evidence+'/physical-terminal-and-pair-cleanup.json','utf8'))
 const native=JSON.parse(fs.readFileSync(evidence+'/native-host-settled.json','utf8'))
 assert.equal(clean.physicalCompletion,true);assert.equal(clean.pairedCleanupComplete,true);assert.equal(native.terminal.exitCode,0)
 const audits=fs.readdirSync(evidence).filter(name=>/^provider-.*\.json$/.test(name)&&name!=='provider-pair-staging.json').map(name=>({name,value:JSON.parse(fs.readFileSync(evidence+'/'+name,'utf8'))})).filter(entry=>Array.isArray(entry.value.requests)).sort((a,b)=>b.value.requests.length-a.value.requests.length||Date.parse(b.value.observedAt)-Date.parse(a.value.observedAt))
 const last=audits[0];assert(last)
 const requests=last.value.requests.map(({model,streaming,status,response_reader}:any)=>({model,streaming,status,response_reader}))
 for(const r of requests){assert.equal(r.model,'gpt-6.1-sol');assert.equal(r.streaming,true);assert.equal(r.status,200);assert.equal(r.response_reader.state,'settled')}
 for(const name of ['native-host-ready.json','native-host-settled.json','physical-terminal-and-pair-cleanup.json','preflight-ready.json','provider-pair-staging.json','public-shutdown.json','launcher-child-exit.json'])save(phase+'/'+name+'.gz',fs.readFileSync(evidence+'/'+name,'utf8'))
 save(phase+'/provider-summary.json.gz',JSON.stringify({source:last.name,requests},null,2))
 for(const name of ['launch.ps1','settle.ps1','shutdown.ps1','launch.log'])save(phase+'/'+name+'.gz',fs.readFileSync(root+'/'+phase+'/'+name,'utf8'))
 scopes.push({phase,requests,terminal:native.terminal,physicalCompletion:true,pairedCleanupComplete:true})
}
const business=scopes[1].requests.filter((r:any)=>r.response_reader.requestContext?.sessionID===assistant.sessionID)
assert.equal(business.length,1);assert.equal(business[0].response_reader.terminal.kind,'aborted')
const db=new Database('C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/member-live-rendering-412-fresh/runtime/data/opencorvus.db',{readonly:true})
db.exec('PRAGMA busy_timeout=5000')
const taskRows=db.query('SELECT id,request_id FROM engine_task WHERE request_id=?').all(original.requestID)
assert.deepEqual(taskRows,[{id:selection.taskID,request_id:original.requestID}]);db.close(true)
const userPath='C:/Users/hengu/AppData/Local/opencorvus/data/opencorvus.db'
const userDB=new Database(userPath,{readonly:true});const userVersion=userDB.query('PRAGMA user_version').get();userDB.close(true)
const userMetadata=fs.statSync(userPath)
const receipt={at:new Date().toISOString(),selectedTask:selection,originalFailedCreation:JSON.parse(fs.readFileSync(root+'/failed-creation-observation.json','utf8')),acceptedTaskRows:taskRows,request,terminal,assistant:{id:assistant.id,sessionID:assistant.sessionID,activationID:assistant.activationID,error:assistant.error,finish:assistant.finish,time:assistant.time},scopes,defaultUserObservation:{version:userVersion,size:userMetadata.size,mtime:userMetadata.mtime},boundary:'Actual public CLI retry, real Provider streaming, manual UI Stop, production cancellation fence and persisted origin; no UI assertions'}
for(const name of fs.readdirSync(root)){
 const full=path.join(root,name);if(!fs.statSync(full).isFile())continue
 if(/\.(ts|mjs|ps1|log|json|jsonl|before)$/.test(name))save('checks/'+name+'.gz',fs.readFileSync(full,'utf8'))
}
fs.writeFileSync(root+'/review-result.json',JSON.stringify(receipt,null,2));save('facts/review-result.json.gz',JSON.stringify(receipt,null,2))
console.log(JSON.stringify({taskID:selection.taskID,acceptedTaskRows:taskRows,assistant:receipt.assistant,scopes:scopes.map(s=>({phase:s.phase,requests:s.requests.length,readerTerminals:s.requests.map((r:any)=>r.response_reader.terminal.kind),terminal:s.terminal,physicalCompletion:true,pairedCleanupComplete:true})),defaultUserObservation:receipt.defaultUserObservation},null,2))
