import fs from 'node:fs'
const root='.tmp-product-iteration/cancellation-activation-426',tag='cancellation-activation-426-after'
const base='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-15'
const bundle=base+'/'+tag+'-bundle/bin'
if(fs.existsSync(bundle))throw Error('Fresh diagnostic bundle required')
fs.mkdirSync(bundle,{recursive:true})
fs.copyFileSync('.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64/bun.exe',bundle+'/bun.exe')
fs.cpSync('packages/overlay/dist-vite',bundle+'/ui',{recursive:true})
fs.mkdirSync(root+'/after',{recursive:true})
for(const name of ['launch.ps1','settle.ps1','shutdown.ps1']){
 let source=fs.readFileSync('.tmp-product-iteration/source-member-review-425/before/'+name,'utf8')
 source=source.replaceAll('source-member-review-425-before',tag).replaceAll('.tmp-product-iteration/source-member-review-425/before',root+'/after').replaceAll('18571','18573')
 if(name==='launch.ps1')source=source.replace('"NativeService"','"NativeServiceCancellation"')
 fs.writeFileSync(root+'/after/'+name,source)
}
let driver=fs.readFileSync('.tmp-product-iteration/live-member-switching-417/create-task.ps1','utf8')
driver=driver.replaceAll('2026-10-14/live-member-switching-417-live','2026-10-15/'+tag)
driver=driver.replaceAll('live-member-switching-417',tag).replaceAll('18545','18573')
driver=driver.replaceAll('.tmp-product-iteration/'+tag,root)
driver=driver.replaceAll('流中成员切换 417','取消原因回归 426').replaceAll('product-experience-417','product-cancellation-426')
const request='只由当前执行者直接回答，不创建或调用任何其他成员，不委派，不搜索、不运行shell、不修改文件。请先连续写一篇约3000字的中文长文，解释在日常项目中如何把材料事实、尚待确认的信息和展示建议清楚分开。分成18个有编号的小节，每节用完整段落说明一个实际可用的方法。可以使用README中已有的“仅用于界面测试”价格和交付文字作为示例，但不要把它们写成真实报价或承诺。每个小节都有自己的具体例子，最后附一个核对表。直接持续输出正文，不人为等待、不请求澄清；正文完成后再说明结果。'
driver=driver.replace(/^\$taskRequest='[^\r\n]*'$/m,"$taskRequest='"+request+"'")
if(driver.includes('同时启动两位'))throw Error('Obsolete test request remains')
fs.writeFileSync(root+'/create-task.ps1',driver)
let reader=fs.readFileSync('.tmp-product-iteration/live-member-switching-417/read-facts.ts','utf8')
fs.writeFileSync(root+'/read-facts.ts',reader)
const artifact='specs/artifacts/2026-10-15-cancellation-activation-provenance'
fs.mkdirSync(artifact,{recursive:true})
fs.writeFileSync(artifact+'/README.md','# 取消激活原因传播证据\n\n[方案与Recall](../../records/2026-10/2026-10-15-cancellation-activation-provenance.md)。聚焦正向后端合同及真实Stop验收将在执行后补齐；不含凭据、UI自动化或完整数据库文件。\n')
for(const [file,line] of [
 ['specs/README.md','- [取消激活原因传播](records/2026-10/2026-10-15-cancellation-activation-provenance.md)：原取消请求与Task-root围栏错误分类。'],
 ['specs/records/2026-10/README.md','- [取消激活原因传播](2026-10-15-cancellation-activation-provenance.md)：共享取消审计、正向合同及真实Stop。'],
 ['specs/artifacts/README.md','- [取消激活原因传播](2026-10-15-cancellation-activation-provenance/README.md)：确定性复现、原事件和实际资源收尾。'],
]){const text=fs.readFileSync(file,'utf8');if(text.includes(line))throw Error('Already indexed');fs.writeFileSync(file,text.trimEnd()+'\n\n'+line+'\n')}
console.log(JSON.stringify({bundle,port:18573,tag,driverRequest:request,qualification:'NativeServiceCancellation',maxRequests:12}))
