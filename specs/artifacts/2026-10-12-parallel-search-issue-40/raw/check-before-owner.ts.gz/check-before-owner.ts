import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'
import assert from 'node:assert/strict'
import {createRequire} from 'node:module'
import {pathToFileURL} from 'node:url'
const repo=path.resolve(import.meta.dir,'..')
const privateRoot=path.join(repo,'.tmp-issue40-parallel')
const require=createRequire(path.join(repo,'packages/opencorvus/package.json'))
const {parse}=require('jsonc-parser')
const documentPaths=['packages/web/src/content/docs/mcp-servers.mdx','packages/web/src/content/docs/zh-cn/mcp-servers.mdx']
const configs=documentPaths.map(name=>{
 const blocks=[...fs.readFileSync(path.join(repo,name),'utf8').matchAll(/```jsonc\r?\n([\s\S]*?)```/g)]
 const candidates=blocks.map(b=>({raw:b[1]!,config:parse(b[1]!)})).filter(b=>b.config?.mcp?.parallel)
 assert.equal(candidates.length,1)
 return candidates[0]!
})
assert.deepEqual(configs[0]!.config,configs[1]!.config)
const root=fs.mkdtempSync(path.join(os.tmpdir(),'opencorvus-issue40-'))
const project=path.join(root,'project')
const allow=new Set(['PATH','Path','SystemRoot','WINDIR','COMSPEC','ComSpec','PATHEXT','HTTP_PROXY','HTTPS_PROXY','NO_PROXY'])
for(const name of Object.keys(process.env))if(!allow.has(name))delete process.env[name]
for(const [name,dir] of Object.entries({HOME:'home',USERPROFILE:'home',APPDATA:'appdata',LOCALAPPDATA:'localappdata',TEMP:'temp',TMP:'temp',XDG_CONFIG_HOME:'xdg-config',XDG_DATA_HOME:'xdg-data',XDG_CACHE_HOME:'xdg-cache',XDG_STATE_HOME:'xdg-state',OPENCORVUS_TEST_HOME:'home',OPENCORVUS_HOME:'runtime'})){
 process.env[name]=path.join(root,dir);fs.mkdirSync(process.env[name]!,{recursive:true})
}
process.env.OPENCORVUS_DISABLE_AUTOUPDATE='1'
process.env.OPENCORVUS_DISABLE_EXTERNAL_SKILLS='1'
process.env.OPENCORVUS_TEST_PROCESS_ROOT=root
fs.mkdirSync(path.join(project,'.opencorvus'),{recursive:true})
fs.writeFileSync(path.join(project,'.opencorvus/opencorvus.jsonc'),configs[0]!.raw)
const mode=process.argv[2]??'search'
const evidence=path.join(privateRoot,(process.argv[3]??mode)+'-run')
fs.mkdirSync(evidence,{recursive:false})
const save=(name:string,data:unknown)=>fs.writeFileSync(path.join(evidence,name+'.json'),JSON.stringify(data,null,2)+'\n')
const credentialInventory=()=>['auth.json','models.json','mcp-auth.json'].map(name=>({name,present:fs.existsSync(path.join(root,'runtime/data',name))}))
save('admission',{root,project,mode,startedAt:new Date().toISOString(),credentialInventory:credentialInventory(),documentPaths})
const load=(name:string)=>import(pathToFileURL(path.join(repo,'packages/opencorvus/src',name)).href)
const {installProcessShims}=await load('runtime/shims.ts');installProcessShims()
const {Config}=await load('config/config.ts')
const {MCP}=await load('mcp/index.ts')
const {Database}=await load('storage/db.ts')
const {Instance}=await load('project/instance.ts')
const {Session}=await load('session/index.ts')
const {Identifier}=await load('id/id.ts')
const {PermissionAuthority}=await load('permission/authority.ts')
try{
 await Instance.provide({directory:project,fn:async()=>{
 const config=await Config.get()
 const session=await Session.create({kind:'assistant',title:'Issue 40 anonymous MCP integration check'})
 assert.deepEqual(config.mcp.parallel,configs[0]!.config.mcp.parallel)
 save('loaded-config',{parallel:config.mcp.parallel})
 const input={key:'parallel',mcp:config.mcp.parallel,cwd:project,processAuthority:MCP.hostProcessAuthority(project)}
 const snapshot=await MCP.inspectScopedCapabilitySnapshot(input)
 save('discovered-tools',snapshot.tool_definitions)
 assert.equal(snapshot.tool_definitions.find((t:any)=>t.name==='web_search').name,'web_search')
 assert.equal(snapshot.tool_definitions.find((t:any)=>t.name==='web_fetch').name,'web_fetch')
 const args=mode==='search'?{objective:'Find the official MDN documentation explaining URL relative reference resolution.',search_queries:['site:developer.mozilla.org URL relative resolution']}:JSON.parse(fs.readFileSync(path.join(privateRoot,'fetch-input.json'),'utf8'))
 const toolName=mode==='search'?'web_search':'web_fetch'
 save('tool-input',{toolName,args})
 const binding=MCP.catalogToolBindings('parallel',config.mcp.parallel,snapshot).find((value:any)=>value.tool_name===toolName)
 const tool=await MCP.exactScopedCatalogTool({...input,binding})
 const invocation={projectID:Instance.project.id,sessionID:session.id,messageID:Identifier.ascending('message'),toolCallID:'issue40-'+mode,providerKind:'mcp',providerID:'parallel',providerDigest:binding.config_digest,toolName:binding.runtime_name,args}
 const result=await PermissionAuthority.authorizeAndExecute(invocation,()=>tool.execute(args,{toolCallId:invocation.toolCallID,messages:[]}))
 save('permission-history',await PermissionAuthority.history())
 save('tool-result',result)
 if(result.isError)throw Error('Remote MCP tool returned an error; original result retained')
 const texts=result.content.filter((c:any)=>c.type==='text').map((c:any)=>c.text)
 assert.ok(texts.some((text:string)=>text.trim().length>100))
 save('result',{outcome:'completed',toolName,textChars:texts.reduce((sum:number,s:string)=>sum+s.length,0),completedAt:new Date().toISOString(),credentialInventory:credentialInventory(),cleanup:'Production scoped calls await their own transport closure before resolving'})
 console.log(JSON.stringify({mode,root,tools:snapshot.tool_definitions.map((t:any)=>t.name),text:texts.join('\n').slice(0,9000)}))
 }})
}catch(error){save('failure',{name:(error as Error).name,message:(error as Error).message});throw error}
finally{await Instance.disposeAll();await Database.awaitEffectIdle(30000);Database.close()}