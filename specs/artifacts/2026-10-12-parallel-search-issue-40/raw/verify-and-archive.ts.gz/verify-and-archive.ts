import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import {gzipSync,gunzipSync} from 'node:zlib'
const root=path.resolve('specs/artifacts/2026-10-12-parallel-search-issue-40')
const scratch=path.resolve('.tmp-issue40-parallel')
const read=(name:string)=>JSON.parse(fs.readFileSync(path.join(scratch,name),'utf8'))
const result=read('all2-run/result.json'), admission=read('all2-run/admission.json')
const search=JSON.parse(read('all2-run/search-result.json').content.find((c:any)=>c.type==='text').text)
const fetched=JSON.parse(read('all2-run/fetch-result.json').content.find((c:any)=>c.type==='text').text)
const entry=fetched.results.find((v:any)=>v.url===result.selectedURL)
assert.ok(search.results.some((v:any)=>v.url===entry.url))
assert.ok(entry.title.length>0)
assert.ok(entry.excerpts.some((v:string)=>v.length>100))
const history=read('all2-run/permission-history.json')
const succeeded=history.filter((r:any)=>r.event_type==='execution_succeeded').map((r:any)=>{
 const request=history.find((q:any)=>q.request_id===r.request_id&&q.event_type==='requested')
 assert.equal(request.session_id,result.sessionID)
 assert.equal(request.provider_kind,'mcp')
 return {requestID:r.request_id,toolName:request.tool_name,event:r.event_type}
}).sort((a:any,b:any)=>a.toolName.localeCompare(b.toolName))
assert.deepEqual(succeeded.map((v:any)=>v.toolName),['parallel_web_fetch','parallel_web_search'])
const summary={checkedAt:new Date().toISOString(),runtimeRoot:admission.root,projectID:result.projectID,sessionID:result.sessionID,searchResults:search.results.length,selectedURL:entry.url,title:entry.title,fetchExcerptChars:entry.excerpts.reduce((n:number,s:string)=>n+s.length,0),permissions:succeeded,credentialInventory:result.credentialInventory,ownerClosed:read('all2-run/owner-closed.json'),processExitCode:0,limits:['Real production config, discovery, exact MCP materialization and permission authority; no model call','Anonymous provider quotas may change','Documentation preview is local, not a website deployment']}
fs.writeFileSync(path.join(root,'verification.json'),JSON.stringify(summary,null,2)+'\n',{flag:'wx'})
const inputs=['check.ts','check-attempt-1.ts','check-attempt-2.ts','check-before-owner.ts','verify-and-archive.ts','all2.log','search3.log','fetch.log','all.log','docs-check.log','astro-node-owner.json',...fs.readdirSync(path.join(scratch,'all2-run')).map(n=>'all2-run/'+n),'search-run/failure.json','search2-run/failure.json','fetch-run/failure.json','all-run/failure.json']
const archives=[]
fs.mkdirSync(path.join(root,'raw'),{recursive:true})
for(const name of inputs){
 const bytes=fs.readFileSync(path.join(scratch,name)),archive=gzipSync(bytes),dest=name.replaceAll('/','--')+'.gz'
 assert.equal(gunzipSync(archive).equals(bytes),true)
 fs.writeFileSync(path.join(root,'raw',dest),archive,{flag:'wx'})
 archives.push({source:name,archive:'raw/'+dest,bytes:bytes.length,integrity:'Full decompressed bytes equal actual input'})
}
fs.writeFileSync(path.join(root,'archives.json'),JSON.stringify(archives,null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify(summary))