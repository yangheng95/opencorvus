import fs from 'node:fs'
import path from 'node:path'
import zlib from 'node:zlib'
import {createRequire} from 'node:module'
import {Database} from 'bun:sqlite'
import {CredentialRedactor} from '../../packages/opencorvus/script/real-provider-audit'
import {completedToolOutcomeOutput} from '../../packages/opencorvus/src/session/tool-outcome-facts'
const root=import.meta.dir,dest=path.resolve('specs/artifacts/2026-10-14-literal-file-targets')
const base='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14'
const material=JSON.parse(fs.readFileSync(root+'/material.json','utf8'))
const redactor=new CredentialRedactor()
redactor.collect(JSON.parse(fs.readFileSync('C:/Users/hengu/AppData/Local/opencorvus/data/auth.json','utf8')))
const save=(name:string,value:string)=>{const target=path.join(dest,name);fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,zlib.gzipSync(redactor.redact(value)))}
const requireProduction=createRequire(path.resolve('packages/opencorvus/package.json'))
const {drizzle}=await import(requireProduction.resolve('drizzle-orm/bun-sqlite'))
const db=new Database(base+'/member-live-rendering-412-fresh/runtime/data/opencorvus.db',{readonly:true})
const outputDB=drizzle({client:db})
let facts:any
try{
 db.exec('BEGIN')
 const sessionID='ses_-zURzTlJFzzacrP6FufN'
 const sessions=db.query('SELECT id,project_id,directory,kind,parent_id,title,metadata FROM session WHERE id=?').all(sessionID)
 const messages=db.query('SELECT id,session_id,data FROM message WHERE session_id=? ORDER BY time_created,id').all(sessionID).map((r:any)=>({...JSON.parse(r.data),id:r.id,sessionID:r.session_id}))
 const ids=new Set(messages.map((m:any)=>m.id))
 const parts=db.query('SELECT id,message_id,data FROM part ORDER BY time_created,id').all().filter((r:any)=>ids.has(r.message_id)).map((r:any)=>({...JSON.parse(r.data),id:r.id,messageID:r.message_id}))
 const tools=db.query('SELECT id,message_id,data FROM tool_part_request ORDER BY time_created,id').all().filter((r:any)=>ids.has(r.message_id)).map((r:any)=>({...JSON.parse(r.data),id:r.id,messageID:r.message_id}))
 const toolIDs=new Set(tools.map((t:any)=>t.id))
 const outcomes=db.query('SELECT request_part_id,data FROM tool_part_outcome ORDER BY time_created,id').all().filter((r:any)=>toolIDs.has(r.request_part_id)).map((r:any)=>{const data=JSON.parse(r.data);return {...data,requestPartID:r.request_part_id,output:completedToolOutcomeOutput(outputDB as any,data,()=>r.request_part_id)}})
 facts={boundary:'Canonical read-only SQLite facts for the existing single main session; not native IDE window acceptance',observedAt:new Date().toISOString(),schema:db.query('PRAGMA user_version').get(),sessions,messages,parts,tools,outcomes}
}finally{db.exec('ROLLBACK');db.close()}
save('facts/final.json.gz',JSON.stringify(facts,null,2))
save('facts/material.json.gz',JSON.stringify({...material,files:material.files.map((file:any)=>({...file,observedContent:fs.readFileSync(path.join(material.project,file.path),'utf8'),displayEscapedPath:file.path.replaceAll('\u00a0','\\u00a0')}))},null,2))
const local=root+'/ui',evidence=base+'/literal-file-targets-422-ui/evidence'
for(const name of fs.readdirSync(local)){
 if(/\.(png|jpg)$/.test(name)){fs.mkdirSync(dest+'/ui',{recursive:true});fs.copyFileSync(local+'/'+name,dest+'/ui/'+name)}
 else if(/\.(log|json|jsonl|ps1)$/.test(name))save('ui/'+name+'.gz',fs.readFileSync(local+'/'+name,'utf8'))
}
const audits=fs.readdirSync(evidence).filter(n=>/^provider-.*\.json$/.test(n)&&!n.startsWith('provider-pair')).map(name=>({name,data:JSON.parse(fs.readFileSync(evidence+'/'+name,'utf8'))})).sort((a,b)=>String(a.data.observedAt).localeCompare(String(b.data.observedAt)))
const latest=audits.at(-1)!
const provider={file:latest.name,observedAt:latest.data.observedAt,requests:latest.data.requests.map((r:any)=>({model:r.model,streaming:r.streaming,status:r.status,reader:r.response_reader}))}
for(const name of fs.readdirSync(evidence)){
 if(name.startsWith('provider-')&&name!==latest.name&&name!=='provider-pair-staging.json')continue
 if(name.endsWith('.json'))save('ui/native/'+name+'.gz',fs.readFileSync(evidence+'/'+name,'utf8'))
}
save('facts/provider-summary.json.gz',JSON.stringify(provider,null,2))
for(const name of ['build.log','ts-before.log','editor-before.log','ts-after.log','ts-final.log','rust-before.log','rust-before-argv.log','rust-after.log','rust-after-complete.log','rust-final.log','docs-check.log','architecture-check.log','archive.ts','prepare.cjs','prepare-ui.cjs'])if(fs.existsSync(root+'/'+name))save('checks/'+name+'.gz',fs.readFileSync(root+'/'+name,'utf8'))
for(const name of ['workspace.ts.before','main.rs.before','reveal-path-host-action.test.ts.before','workspace-file-identity.test.ts.before'])save('before/'+name+'.gz',fs.readFileSync(root+'/'+name,'utf8'))
console.log(JSON.stringify({schema:facts.schema,sessions:facts.sessions.map((s:any)=>({id:s.id,parentID:s.parent_id})),latest:facts.messages.slice(-3).map((m:any)=>({id:m.id,role:m.role,time:m.time,finish:m.finish})),latestTool:facts.tools.at(-1),latestSources:facts.parts.filter((p:any)=>p.type==='source-file'&&p.path.includes('identity-422.md')),provider:provider.requests.map((r:any)=>({model:r.model,streaming:r.streaming,status:r.status,state:r.reader?.state,terminal:r.reader?.terminal?.kind}))},null,2))
