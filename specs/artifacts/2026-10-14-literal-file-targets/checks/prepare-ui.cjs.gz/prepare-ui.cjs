const fs=require('node:fs'),path=require('node:path');
const root='.tmp-product-iteration/literal-file-targets-422';fs.mkdirSync(root+'/ui',{recursive:true});
const project='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/member-live-rendering-412-fresh/project';
const names=['identity-422.md\u00a0','identity-422.md'];
const texts=['# IDENTITY_LITERAL_NBSP_422\n这是末尾保留不间断空格的原始文件，仅用于界面验收。\n','## IDENTITY_NORMAL_422\n这是没有末尾空格的另一文件，仅用于界面验收。\n'];
for(let i=0;i<names.length;i++)fs.writeFileSync(path.join(project,'source-reading',names[i]),texts[i]);
fs.writeFileSync(root+'/material.json',JSON.stringify({project,files:names.map((name,i)=>({path:'source-reading/'+name,content:texts[i]}))},null,2));
for(const name of ['launch.ps1','settle.ps1','shutdown.ps1']){
 const text=fs.readFileSync('.tmp-product-iteration/sources-reading-421/after/'+name,'utf8')
  .replaceAll('sources-reading-421-after','literal-file-targets-422-ui')
  .replaceAll('.tmp-product-iteration/sources-reading-421/after','.tmp-product-iteration/literal-file-targets-422/ui')
  .replaceAll('sources-reading-421-','literal-file-targets-422-')
  .replaceAll('18563','18565');
 fs.writeFileSync(root+'/ui/'+name,text);
}
