import fs from "node:fs/promises"
import path from "node:path"
import assert from "node:assert/strict"
const run = "C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/text-unicode-380-after"
const out = "D:/myhexin-local/opencorvus/.tmp-explorer-380/recovery"
process.env.OPENCORVUS_HOME = path.join(run, "runtime")
process.env.OPENCORVUS_TEST_HOME = path.join(run, "home")
process.env.OPENCORVUS_TEST_PROCESS_ROOT = run
const { installProcessShims } = await import("../packages/opencorvus/src/runtime/shims")
installProcessShims()
const { Global } = await import("../packages/opencorvus/src/global")
const { currentRuntimeProcessOccurrence, observeRuntimeProcessOccurrence } = await import("../packages/opencorvus/src/runtime/process-occurrence")
const { ProcessSupervisor } = await import("../packages/opencorvus/src/shell/process-supervisor")
assert.equal(path.resolve(Global.Path.temporary), path.resolve(run, "runtime/tmp"))
const dirs = (await fs.readdir(Global.Path.temporary, { withFileTypes: true })).filter(x => x.isDirectory() && x.name.startsWith("supervisor-")).map(x => x.name)
assert.deepEqual(dirs, ["supervisor-gB7cBm"])
const launch = JSON.parse(await fs.readFile(path.join(run, "launch-owner.json"), "utf8"))
const helper = JSON.parse(await fs.readFile(path.join(out, "private-supervisor-original/helper.json"), "utf8"))
const owners = [launch.host, launch.nativeTarget, {pid:helper.helper_pid, processInstanceID:helper.helper_process_instance_id, occurrenceID:helper.runtime_occurrence_id}]
const observe = () => owners.map(owner => ({ owner, state: observeRuntimeProcessOccurrence(owner) }))
const before = observe()
await fs.writeFile(path.join(out,"before.json"),JSON.stringify(before,null,2),{flag:"wx"})
for (const item of before) assert.equal(item.state,"dead_or_reused")
const recoveryOwner = currentRuntimeProcessOccurrence()
const result = await ProcessSupervisor.recoverOrphanedWindowsRequests({ currentOccurrenceID: recoveryOwner.occurrenceID })
const receipt = { observedAtUtc: new Date().toISOString(), recoveryOwner, result, after:observe(), boundary:"Production orphan recovery only. Original native output drain and exit result remain unverified." }
await fs.writeFile(path.join(out,"recovered.json"),JSON.stringify(receipt,null,2),{flag:"wx"})
assert.deepEqual(result,{inspected:1,removed:1,retainedCurrent:0,retainedLive:0,retainedUnknown:0,quarantined:0,unreconciled:[]})
for(const item of receipt.after) assert.equal(item.state,"dead_or_reused")
console.log(JSON.stringify(receipt))
