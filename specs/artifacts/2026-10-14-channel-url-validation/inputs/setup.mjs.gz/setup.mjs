import fs from 'node:fs'
import {gzipSync} from 'node:zlib'
import {execFileSync} from 'node:child_process'
const root='.tmp-codex-channel-url-01a133',prior='.tmp-codex-network-feedback-01a133',artifact='specs/artifacts/2026-10-14-channel-url-validation'
fs.mkdirSync(root,{recursive:true});fs.mkdirSync(artifact+'/screenshots',{recursive:true});fs.mkdirSync(artifact+'/previous-delivery',{recursive:true})
for(const name of ['runtime.ts','launch.ps1','privacy.ts','run.mjs'])fs.writeFileSync(root+'/'+name,fs.readFileSync(prior+'/'+name,'utf8').replaceAll(prior,root).replaceAll('network feedback locale','channel URL validation').replaceAll('18678','18682').replaceAll('18679','18683').replaceAll('18680','18684').replaceAll('18681','18685'))
for(const name of ['commit-final.log','commit-final.exit','commit-final-created.json','commit-final-receipt.json','pending-final-review.json','push-final.log','push-final.exit','push-final-receipt.json','push-final.mjs','fetch-current.log','fetch-current.exit','merge-current.log','merge-current.exit','fetch-final.log','fetch-final.exit','exact-module.log','exact-module.exit','exact-release.log','exact-release.exit','reconcile-check.log','reconcile-check.exit'])fs.writeFileSync(artifact+'/previous-delivery/'+name+'.gz',gzipSync(fs.readFileSync(prior+'/'+name)))
const head=execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim()
for(const file of ['packages/overlay/src/components/settings/ChannelsPanel.tsx','packages/overlay/src/i18n/en-US.json','packages/overlay/src/i18n/zh-CN.json'])fs.writeFileSync(root+'/'+file.split('/').at(-1)+'.before',execFileSync('git',['show',head+':'+file]))
fs.writeFileSync(root+'/baseline.json',JSON.stringify({head,at:new Date().toISOString()},null,2)+'\n')
fs.writeFileSync(artifact+'/previous-delivery/README.md','# 第26批正常交付\n\n9ad499424正常commit/push0，131路径、一个组件与两语言各一个键；原全部hook及fresh upstream确认，精确module1164/5943/4clean imports。16原图/7明确部分GET选择与两轮正常退出/配对/隐私资格保持。\n')
console.log(JSON.stringify({root,head,before:[18682,18683],after:[18684,18685]}))
