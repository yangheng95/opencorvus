import fs from "node:fs"
import path from "node:path"
import { randomUUID } from "node:crypto"
const root = path.resolve(process.argv[2]!)
const uiDirectory = process.argv[3]!
const started = Date.now()
const sampleKey = randomUUID()
const { installProcessShims } = await import("../packages/opencorvus/src/runtime/shims")
installProcessShims()
const { Log } = await import("../packages/opencorvus/src/util/log")
await Log.init({ print: false })
const requests: unknown[] = []
const model = (id: string) => ({ id, name: id, release_date: "2026-10-13", attachment: false, reasoning: false, temperature: true, tool_call: true, modalities: { input: ["text"], output: ["text"] }, cost: { input: 1, output: 2 }, limit: { context: 10000, output: 1000 }, options: {} })
const participant = Bun.serve({hostname:"127.0.0.1",port:0,fetch(request){
  const url=new URL(request.url)
  const prefix=url.pathname.split('/')[1]!
  const matches=request.headers.get('authorization')===`Bearer ${sampleKey}`
  const ids=prefix==='project' ? ['project-discovered-a','project-discovered-b'] : prefix==='product-project' ? ['project-live-a'] : prefix==='product-global' ? ['global-live-a','global-live-b'] : prefix==='ready' ? ['ready-known'] : ['global-discovered-a','global-discovered-b']
  const status=matches?200:401
  requests.push({method:request.method,path:url.pathname,status,sampleCredentialMatched:matches})
  fs.writeFileSync(path.join(root,'participant-requests.json'),JSON.stringify(requests,null,2))
  if(!matches)return Response.json({error:'Owned sample credential required'}, {status})
  return Response.json({data:url.pathname.endsWith('/model/info')?ids.map(model):ids.map(id=>({id}))})
}})
const endpoint=(prefix:string)=>new URL(`${prefix}/v1`,participant.url).href.replace(/\/$/,'')
const catalog={opencorvus:{id:'opencorvus',name:'OpenCorvus',env:[],npm:'@ai-sdk/openai-compatible',api:endpoint('product-global'),models:{}},kilo:{id:'kilo',name:'Kilo Gateway',env:[],npm:'@ai-sdk/openai-compatible',api:endpoint('kilo'),models:{}}}
fs.mkdirSync(path.join(root,'runtime','data'),{recursive:true})
fs.writeFileSync(path.join(root,'runtime','data','models.json'),JSON.stringify(catalog,null,2))
const { ModelsDev }=await import('../packages/opencorvus/src/provider/models')
ModelsDev.validateExplicitCatalog(catalog)
const { Config }=await import('../packages/opencorvus/src/config/config')
const { Auth }=await import('../packages/opencorvus/src/auth')
await Config.updateGlobalPatch({provider:{'owned-bootstrap':{name:'Bootstrap without models',api:endpoint('global'),npm:'@ai-sdk/openai-compatible',env:[],models:{}},'owned-ready':{name:'Known model provider',api:endpoint('ready'),npm:'@ai-sdk/openai-compatible',env:[],models:{'ready-known':model('ready-known')}}},prompt_profile:{active:'base'},experimental:{memory:{enabled:false}}})
for(const id of ['owned-bootstrap','owned-ready','opencorvus'])await Auth.set(id,{type:'api',key:sampleKey})
const directory=path.join(root,'project')
fs.mkdirSync(directory,{recursive:true})
const git=(args:string[])=>{const r=Bun.spawnSync(['git','-C',directory,...args],{stdout:'pipe',stderr:'pipe'});if(r.exitCode!==0)throw Error(`Owned project Git ${args[0]} exit ${r.exitCode}`)}
git(['init']);git(['config','user.name','Owned discovery qualification']);git(['config','user.email','owned-discovery@example.invalid'])
fs.writeFileSync(path.join(directory,'README.md'),'# Owned discovery project\n');git(['add','README.md']);git(['commit','-m','Owned discovery qualification'])
fs.mkdirSync(path.join(directory,'.opencorvus'),{recursive:true})
fs.writeFileSync(path.join(directory,'.opencorvus','opencorvus.jsonc'),JSON.stringify({provider:{'owned-bootstrap':{api:endpoint('project')},opencorvus:{api:endpoint('product-project'),whitelist:['owned-filtered-model']}}},null,2))
const { Instance }=await import('../packages/opencorvus/src/project/instance')
const { freezeOverlayUiDirectory }=await import('../packages/opencorvus/src/server/overlay-ui')
const { listenWithRecoveredServerRuntime }=await import('../packages/opencorvus/src/cli/server-runtime')
const { recoverStartedTaskExecutions,assertStartedTaskProjectRecoverySucceeded }=await import('../packages/opencorvus/src/engine/host-recovery')
const runtime=await listenWithRecoveredServerRuntime({options:{hostname:'127.0.0.1',port:18578,overlayUiSource:freezeOverlayUiDirectory({directory:uiDirectory})},recover:async()=>{const r=await recoverStartedTaskExecutions({scopeProjectWorktree:directory});assertStartedTaskProjectRecoverySucceeded(r)},disposeInstances:()=>Instance.disposeAll()})
await runtime.recovery
await Instance.provide({directory,fn:()=>Instance.project.id})
const read=async(route:string,body?:unknown)=>{const r=await fetch(`http://127.0.0.1:18578${route}`,body===undefined?{}:{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});return {status:r.status,body:await r.json()}}
const projectSuffix=`?directory=${encodeURIComponent(directory)}`
const outcomes={globalSavedZero:await read('/global/providers/discover-models',{api:endpoint('global'),providerID:'owned-bootstrap'}),projectSavedZero:await read('/provider/discover-models'+projectSuffix,{api:endpoint('project'),providerID:'owned-bootstrap'}),globalExplicitZero:await read('/global/providers/discover-models',{api:endpoint('global'),providerID:'owned-bootstrap',apiKey:sampleKey}),globalSavedKnown:await read('/global/providers/discover-models',{api:endpoint('ready'),providerID:'owned-ready'}),globalLiveRefresh:await read('/global/providers/models/refresh',{}),projectLiveRefresh:await read('/provider/models/refresh'+projectSuffix,{})}
fs.writeFileSync(path.join(root,'outcomes.json'),JSON.stringify({boundary:'Actual production HTTP using isolated generated sample credential and loopback participant; no private credential, online provider or model inference',outcomes},null,2))
fs.writeFileSync(path.join(root,'ready.json'),JSON.stringify({pid:process.pid,started,port:runtime.server.port,participantPort:participant.port,project:directory,endpoints:{global:endpoint('global'),project:endpoint('project')},occurrence:runtime.occurrence},null,2))
let stopping=false
let poll:ReturnType<typeof setInterval>
let deadline:ReturnType<typeof setTimeout>
const stop=async(reason:string)=>{if(stopping)return;stopping=true;clearInterval(poll);clearTimeout(deadline);try{await participant.stop(true);await runtime.server.stop(true);await runtime.recovery;fs.writeFileSync(path.join(root,'terminal.json'),JSON.stringify({pid:process.pid,reason,elapsed:Date.now()-started,productionStop:'settled'},null,2));await Log.close();process.exit(0)}catch(e){console.error(e);process.exit(1)}}
poll=setInterval(()=>{if(fs.existsSync(path.join(root,'stop-requested')))void stop('Own discovery page completed')},500)
deadline=setTimeout(()=>void stop('Owned 40min lifetime'),2400000)
