const fs=require('node:fs/promises');
(async()=>{
const base='.tmp-codex-provider-discovery-01a133/after';
const ready=JSON.parse(await fs.readFile(base+'/ready.json','utf8'));
const projection=async(route)=>{
const r=await fetch('http://127.0.0.1:18578'+route);const b=await r.json();
const catalog=route.startsWith('/global/') ? b.catalog : b;
if(r.status!==200||!catalog)throw Error('Expected catalog contract: '+route+' '+r.status);
return{route,status:r.status,connected:catalog.connected,providers:catalog.all.map(p=>({id:p.id,models:Object.keys(p.models)})),issues:b.issues??catalog.issues??[]};
};
const global=await projection('/global/providers');
const project=await projection('/provider?directory='+encodeURIComponent(ready.project));
const all=JSON.parse(await fs.readFile(base+'/runtime/data/models.json','utf8'));
const config=JSON.parse(await fs.readFile(ready.project+'/.opencorvus/opencorvus.jsonc','utf8'));
const evidence={boundary:'Actual production HTTP catalog, durable live catalog and owned project config; exact model IDs only; credentials excluded',global,project,durableLive:Object.keys(all.opencorvus.models),projectBootstrap:Object.keys(config.provider['owned-bootstrap'].models),projectWhitelist:config.provider.opencorvus.whitelist};
await fs.writeFile(base+'/post-ui-projection.json',JSON.stringify(evidence,null,2));
console.log(JSON.stringify(evidence,null,2));
})().catch(e=>{console.error(e.message);process.exitCode=1});

