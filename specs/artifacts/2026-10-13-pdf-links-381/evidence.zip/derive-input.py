from pathlib import Path
from pypdf import PdfReader, PdfWriter
from pypdf.generic import DictionaryObject, NameObject, ArrayObject, FloatObject, TextStringObject
source=Path('specs/artifacts/2026-10-13-pdf-links-381/inputs/link-navigation.pdf')
writer=PdfWriter(clone_from=source)
writer.pages[0].rotate(90)
writer.write(source.with_name('rotated-links.pdf'))
writer=PdfWriter(clone_from=source)
a=writer.pages[0]['/Annots'][0].get_object()
a[NameObject('/Dest')]=TextStringObject('missing-section')
writer.write(source.with_name('unresolved-link.pdf'))
print('Authored rotated-page and unresolved-destination documents from the same two-page source.')
