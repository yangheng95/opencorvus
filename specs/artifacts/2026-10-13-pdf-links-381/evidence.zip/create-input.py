from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor
from pathlib import Path
from pypdf import PdfReader
import json

out=Path('specs/artifacts/2026-10-13-pdf-links-381/inputs/link-navigation.pdf')
c=canvas.Canvas(str(out),pagesize=(612,792),invariant=1)
c.setTitle('Document links - reading review')
c.setAuthor('OpenCorvus review')
def heading(number,title,subtitle):
    c.setFillColor(HexColor('#16373D')); c.rect(0,686,612,106,fill=1,stroke=0)
    c.setFillColor(HexColor('#BFE4D8')); c.setFont('Helvetica-Bold',10); c.drawString(48,750,'OPENCORVUS / DOCUMENT READING')
    c.setFillColor(HexColor('#FFFFFF')); c.setFont('Helvetica-Bold',24); c.drawString(48,710,title)
    c.setFillColor(HexColor('#43595E')); c.setFont('Helvetica',12); c.drawString(48,651,subtitle)
    c.setFont('Helvetica',10); c.drawString(48,35,f'Public review input | Page {number} of 2')
def link(text,y,dest=None,url=None):
    c.setFillColor(HexColor('#146350')); c.setFont('Helvetica-Bold',14); c.drawString(48,y,text)
    width=c.stringWidth(text,'Helvetica-Bold',14)
    c.setStrokeColor(HexColor('#146350')); c.line(48,y-3,48+width,y-3)
    if dest:c.linkRect('',dest,(48,y-4,48+width,y+15),relative=0,thickness=0)
    else:c.linkURL(url,(48,y-4,48+width,y+15),relative=0,thickness=0)

c.bookmarkPage('overview',fit='Fit')
heading(1,'A document worth following','The links below are actual PDF annotations.')
link('Read the details on page 2',577,dest='details')
link('Open the OpenCorvus project',519,url='https://github.com/yangheng95/opencorvus')
c.setFillColor(HexColor('#43595E')); c.setFont('Helvetica',12)
for i,line in enumerate(['This paragraph remains selectable as ordinary document text.',
                          'Navigation should keep the document open and retain its zoom.',
                          'The next page has a return link and a section destination.']):c.drawString(48,440-i*20,line)
c.showPage()
heading(2,'Details and references','Internal navigation resolves the original document destination.')
c.bookmarkPage('details',fit='XYZ',left=48,top=610,zoom=0)
c.setFillColor(HexColor('#E9F3ED')); c.roundRect(40,385,532,225,8,fill=1,stroke=0)
c.setFillColor(HexColor('#16373D')); c.setFont('Helvetica-Bold',18); c.drawString(56,577,'Destination section')
c.setFont('Helvetica',12)
for i,line in enumerate(['This heading is the named target on the first page.',
                          'The PDF stores a page reference and an XYZ position.',
                          'The linked text, canvas, and selection layer share one scale.']):c.drawString(56,538-i*22,line)
link('Return to the overview',320,dest='overview')
c.showPage();c.save()
reader=PdfReader(out)
facts=[]
for i,page in enumerate(reader.pages):
    for ref in page.get('/Annots',[]):
        a=ref.get_object()
        facts.append({'page':i+1,'subtype':str(a['/Subtype']),'rect':[float(n) for n in a['/Rect']],
                      'uri':str(a.get('/A',{}).get('/URI','')),'destination':str(a.get('/Dest',''))})
Path('specs/artifacts/2026-10-13-pdf-links-381/inputs/annotations.json').write_text(json.dumps(facts,indent=2),encoding='utf8')
print(json.dumps({'pages':len(reader.pages),'annotations':facts}))
