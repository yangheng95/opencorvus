# 并发文件发布与搜索读取：只读审计和待授权验证方案

## Recall 与本轮资格

2026-10-13，root 确认上一批 `83ee0d843` 正常 push、全部交付检查 0、upstream ancestor 0 后，授权一层只读并发审计。重读 `specs/records/2026-10/2026-10-13-explorer-tab-owner-search.md` Recall、最终事实及“补充并发审计资格”；重读 66 outcome 的 required/search 回执合同。上一批单例 Upload 当前 query 自然更新已有真实页面和 API/完整字节证明，但规格明确未证明逆序 upload 或 inflight scan。本轮不复用其截图当并发证据。

本轮只读取仓库和权威资料，只将此报告保存本人 scratch。未修改产品/spec/test/Git，未启动服务/应用/测试实例，未使用 UI、模型、凭据，未委托。root 负责正式计划与任何后续运行授权。

## 已读定义、调用、历史与事实来源

- `FileExplorerPanel.tsx`：唯一 upload operation token、mutation token、三个 scope effects、close/disposed、normal/required 两个目录 token Map、search source/resource、search latest/published/loading、全部动作/Refresh/Retry/poll/drop/picker。
- `file-workbench.ts`：FileOperationScope、上传 bytes 捕获/编码、真实成功 API 后修订，所有 create/copy/move/delete、唯一 collectFileRefreshReceipts。`events.ts:236` 只在 file.watcher.updated bump 修订；TaskDirBar:360 是该计数当前消费者。Explorer search 不读该修订。
- `File/index.ts`：File.UploadRequest、base64/name/scope 验证、upload keyed lock、staging/link/cleanup、create/copy/move/remove/writeText 实体提交与真实通知，File.search/file-index state/files()/scan()/fetching。
- HTTP `/file/upload`、`/file/item` create/copy/move/delete、`PATCH /file/content`、`/find/file` 的唯一 File 调用；debug `file search` 也是 File.search。model glob/ls 使用各自 Ripgrep.filesForTask/filesForHost，不经这个 File.search 的 fetching；本轮没有模型执行。
- `createInstanceState` 复用 State.create(currentProjectDirectory)，key 来自当前目录的 Filesystem.resolve；共享 Project ID 不会把不同当前 directory 扫描合并。Server project-directory middleware 在真实目录上下文中执行 FileRoutes。
- `Ripgrep.filesForHost` 真实 Native ProcessSupervisor host 命令、argv、NUL 输出、exited/outputSettled/dispose；Windows 原 request/ready/settled 具名事实及请求目录清理。

83 的产品修改只有 Explorer 既有 forceMount 与上传 search opt-out 删除，未改 upload token 或 backend fetching。66 的历史 spec 明确保留独立 upload 并发及旧搜索范围；83 修单例 scope/mount/搜索请求，不声称修完所有并发。最初 fetching 共用/上传最新 token 的设计理由在这些记录没有证据，标未知；本轮没有 Git 历史操作。

## 两条边界与可观察触发

### A. 同一个 Explorer 中旧 upload token 最后发布

当前 picker 菜单在 uploading 时 disabled；真实 external file drop 则由 dragTargetStatus 直接给 upload，handleExplorerDrop 调用 uploadFiles。uploadFiles 只检查当前 scope/file editor reservation，没有 uploading 准入条件。第二次 drop 因而可以取得新的 uploadOperationSequence/token；两次 payload 捕获仍各自真实进行。

`uploadDroppedFiles` 先 Promise.all(file.arrayBuffer + base64)，然后 POST；成功响应后 bumpFileWorkbenchRevision，返回真实上传回执。组件随即 `if (!ownsUploadOperation()) return`，所以 token1 的实际 200 如果在 token2 后回来，会跳过 expanded/目录/当前 query 重读和旧反馈。token2 完成后还将 uploadOperation 置 null。后台 15 秒仅补目录，不重查搜索。

所需时序是：UI A 开始 → 同组件 B 开始 → B 实体发布/200 → B 的 current query 已 loaded → A 实体发布/200 → A 因 token 已退休而跳过读取。A/B 文件名必须不同，否则 409 是另一个合同。

同一 targetDir 的 backend keyed lock 不能排除这个时序：它在完整 HTTP JSON 解析、base64 decode/准入之后才进入，按实际进入锁的顺序串行 staging/publication；UI 开始顺序不等于 body 完整/锁进入顺序。不同 targetDir 的 uploads 没有共享该锁。旧 feedback 退休是正确所有权行为，但不能自动证明该 scope 的数据已涵盖后来的实体发布。

**当前资格：代码有真实生产入口；尚无本轮实际逆序 drop/网络/实体证据。** root 已确认 CUA native apps disabled、browser drag 只有坐标；真实 external OS file drop 能力未证明。不得用 dispatchEvent、注入 DataTransfer/File、调用隐藏函数、两页同 Project 或重新启用 pending picker冒充同组件真实 drop。两页是两个独立 token owner，不验证这个缺口。现阶段保留未实证，不强迫人为复现或盲修 UI guard。

### B. 发布后新 HTTP 搜索复用发布前扫描

File.index 的实际实现：每个 directory state 有一个 fetching；refresh() 用新 Entry 开始 scan，保存 tracked Promise；只有 tracked.finally 完成且 fetching 仍是这个 Promise 才清空。files() 返回 `fetching ?? refresh()`。所有查询和 limit/type 共享同一完整 files/dirs 数据，之后各自 fuzzy filter。

因此 Q1 在 publication 前取得 scan，publication 200 后才 dispatch 的 Q2 仍可能 await Q1 的同一 scan。此时 Q2 是真实新 HTTP，不是组件缓存请求，但它的数据采集边界仍旧。UI 的 source/scope、result===resource 和 loading 校验只证明“当前 owner 发布了这个响应”，不会识别其 scan 的开始时间。

没有持久化 file index；无 in-flight 时每次 files() 都重新扫描。初次 state 初始化还先 await 一次 refresh，再供调用者执行 files()，所以验证应先 warm 并等待基线请求完成，避免把初始化扫描与交叠扫描混为一谈。

Ripgrep.filesForHost argv 为 `--files --null --glob=!.git/*`，默认还加 `--hidden`，不 follow terminal links。扫描从完整目录枚举文件，不是原子快照。特别注意，scan 还等待原 proc.exited、stderr、outputSettled，并调用 dispose；Native target 已退出，不等于 fetching 已清。发布与 Q2 可能落在 filesystem 枚举完成、原 Native 收尾尚未完成的阶段；不能只在 PID live 时认为有窗口。

**当前资格：确定代码复用路径；特定 scan 是否漏发布文件/是否能在当前真实 runtime 重现仍未知。** 不以第一扫描启动时间、最后错误或文件名猜已发生。必须记录完整事件链和原结果。

## 所有生产路径、正常/退休/失败与隔离

| 路径 | 发布/读资格 | 与候选关系 |
| --- | --- | --- |
| create/copy/move/delete、rename、拖放 move | 真实成功 API 后，原 mutation owner 当前时通过 refreshFileViews 重读实际目录+当前非空 query；部分成功保原数组 | token 基本由 commandBusy 串行保护，但仍可与独立 upload/手动 Refresh/query 请求交叠；共享 backend scan 候选适用 |
| picker/drop upload | 独立 upload token；成功先 bump 修订，组件需最新 token 才重读 | A 候选仅同组件真实重叠入口；B 候选适用 |
| PATCH text write | 真实目标内容/原 opaque revision、physical commit；通知 Files | 普通写现文件通常不改文件名集合；不是可靠“新增成员”探针。不能改写 revision/内容 writer 为扫描协调器 |
| HTTP/readers、debug file search | File.search 唯一入口，按输入 directory 上下文取 state | 同目录查询共用 fetching，不论 query/type/limit；不同 directory state 独立 |
| model glob/ls/外部编辑 | 各自真实 filesystem/process contract；不经 File.search fetching | 外部实际新增/删除可能影响同目录 HTTP 搜索，但没有本轮模型/任务证据，不混称 Task/Mission/Session 调度缺陷 |
| normal/15 秒 poll/目录 Retry | 普通读取可用已载目录或 required 正在读取时跳过；poll/Retry force；只目录 | 它们不会补 query；不得改成全局搜索轮询掩盖 publication 资格 |
| required 目录读 | 每次真实发新 HTTP；按 path token 与 scope 当前发布 loaded/failed；较晚 required 替换较早读，旧读 retired | 目录 Map 仍唯一状态。已 superseded 的读取不能判成功，也不能使当前状态退休 |
| required 搜索/Refresh | 原 search source、scope、published identity、loading 决定 loaded/failed/retired；refetch undefined 是 not-started | 新 client request 并不自动证明 backend scan 始于 publication 后 |
| Query 改变 | createDeferred/query 产生新 source，旧返回不得成为新 source 的数据；原退休错误可保持在自己的 target.query | 不需新 query cache；同 backend scan 可以被不同真实 query 消费 |
| tool tab 视觉选择/隐藏 Dock | 83 保持逻辑 open owner，scope没有退休 | 不再把视觉切换当取消操作；不能以关闭/重开刷新代替当前 query 收敛 |
| Close Explorer/project/authority/selectEpoch/disposed | 原 guards/reset 清理；ApiJson dispatch/response 再验 authority | 旧结果不挂新 scope。不同 Project/不同当前 directory 必须各取自己的真实路径/内容/进程证据 |
| scan 正常失败/重试 | tracked.finally 清 fetching；当前 fresh 请求再扫描；读错误走真实 UnknownError500 | 第二个读若复用旧失败也可能承受其错误；不得用 catch→empty/unignored fallback。故障类型本轮未实测 |

HTTP upload 的 200 在 staging bytes 校验、真实 no-overwrite link、staging unlink与通知 allSettled 后产生。upload 不参与 file index 的 fetching；普通 File mutation 通知也没有使 index 取得 publication 之后的新采集边界。文件 watcher 更新 frontend 的 global revision，只用于 TaskDirBar 数量，既不是 per-directory publication 序列，也不是 Explorer query 资格。

这两条是 Files 的 operation/read-data 共性边界。Task/Mission/Session 的 durable occurrence/重试/重启调度没有被它们改动，model glob/ls 的 task capsule 也有独立实际 owner；不能以它们修后单例通过排除 Native输出机制，或反过来认定一次 query 旧数据就是 Task scheduler 异常。原 Native 输出问题仍由另一限定审计推进。

## 请求大小与网络条件

File.UploadRequest 仅 min(1) 与字段形状，没有文件 bytes/count 的独立上限；base64 decoder验证编码后完整 Buffer decode。browser/tauri transport 是实际 fetch，前端整文件 arrayBuffer+base64+JSON，没有流式上传或分块协议。原文件 n bytes 的 base64 长度为 4*ceil(n/3)，完整 UTF-8 JSON body 还包含 name/mimeType/targetDir 等实际字节，不能拿 raw file size当 HTTP body。

生产 Server.bind:972 只传 hostname/idleTimeout=0/fetch/websocket/port，没有 maxRequestBodySize，也没有查到 Hono bodyLimit。安装的一手 Bun types 1.4.2 `serve.d.ts:762` 声明默认 1024*1024*128（128 MiB）；[Bun Serve 官方 API](https://bun.com/reference/bun/Serve)说明此选项限制整个请求 body 字节。当前验收 runtime 是 Bun1.4.0，不将1.4.2类型注释冒称其真实极限验收；定版源码尝试路径返回404，公共新版文档未给默认值。确切 runtime 边界仍待允许后验证。

**backend overlap 方案不需要大型上传或网络降速**：使用16–64字节的唯一普通 txt marker，记录实际序列化 JSON body length；HTTP成功、真实 bytes和回执本身证明这次准入。延长自然 scan 只能采用自有正常文件树，在正式方案中先给资源数量/总字节/时限封顶，不改 serve 上限，不暂停 rg，不塞 fake 输出、不安装代理/测试 gate。大文件逆序 UI 网络方案暂缓，因为真实 drop 能力未证明；不先制造一个理论上低于128 MiB但实际 UI不可完成的实验。

## 待 root 落盘、授权后的最小 backend 实验

1. 本人全新 managed 项目、正常源码 CLI/API 服务、原 Native Host/Target PID+birth+occurrence、固定截止和普通收尾；不复制凭据、auth/models、消息或数据库。只在该实体命名空间创建数据。普通 root 与 child scope 两类分开；marker 必须置于当前 directory 可扫描的 root，不能在 child 的 ../父目录发布后期待 child scan命中。
2. 在正常项目创建 unique-query 原 marker 和少量真实 fanout filler，先 saved fixture记录原 marker完整 bytes/dev/inode与每个阶段的实际数据数量。先 warm GET/find/file并等待其 200/完整数组。可从约3000文件/64目录尝试；若窗口不足再按正式限额一次扩大（例如总16000文件/128目录、总file content≤1 MiB），不无限增大、不把数量本身当正确性验收。空 filler仍有实际元数据成本，需记录准备/scan用时和真实目录归属。
3. 启动外部只读观察器，限定这个 runRoot/runtime/tmp。捕获原 durable `request.json`、`ready.json`、`settled.json`，只选择 executable实际为rg、argv含原--files/--null、cwd==被审计 scope、runtime occurrence==原服务的请求。保原request ID、helper/target PID、target processInstanceID、原raw records与观察时间。不改observer factory/handle，不读消费者stdout，不暂停或控制现进程。fs.watch/短只读目录扫描只能捕获原文件；Native正常dispose会移除目录，未及时捕获要记录缺证据，不推断身份或空结果。
4. Q1用相同unique-query真实GET触发一次scan；取得对应原ready身份后，以正常 POST/file/upload发布另一个tiny唯一marker，等待真实200并保存method/url/request/body/headers/requestID/时间。无需把时间线建立在随机sleep或Native PID一定still-live上。
5. **POST200之后立即 dispatch Q2**（同 directory、相同 query/type/limit），不先等待physical/content/list读取而消耗真实重叠窗口。这些独立只读事实可以与Q2并行采集：physical regular file/dev/inode/full bytes、公开content200准确bytes和原目录list。Q1和Q2完整返回后，Q3相同查询作fresh对照。全部原rawBody、status、request ID、dispatch/headers/body完成时间保留。目录list/content的实体事实不能更新/替代 UI搜索。完整响应断言应要求已发布 marker 的准确成员集合，不写“不包含某marker/没启动另一个rg”的负向核心测试。
6. 形成证据链才算重现：Q1的原scan获取在publication前；publication 200及physical/content正确；Q2确在此后发出且仍落入原scan的实际未完成阶段；Q2公开结果与已发布集合不一致；原Native请求身份、server原request日志与Q1/Q2/Q3关联一致，Q3新的采集准确包含该marker。仅相同数组、PID标题或缺少第二条日志不单独证明共享scan。若Q1在POST前已经settle、不能捕获原Native身份或Q2实际结果fresh，则明确本次未取得候选故障证据，保所有成功/失败，不伪造时序。
7. 限定最多2–3次独立marker/有身份的尝试，先普通收尾/drain/request cleanup/parentjoin再做独立分析。初次 warm与single-request after-publication是control，另一个真正独立Project用相同名字不同内容作scope control；不是两页复现A。错误/重试/项目退役的实际运行矩阵若没发生则未知，不能拿服务正常结束冒称排除。

## 若取得真实证据后的最小设计方向（非授权实现）

B的根是当前 File.search请求可以使用此前取得的采集。优先在唯一 files()/scan owner纠正 fresh acquisition：每个需要当前文件事实的HTTP读必须取这个读开始之后的真实scan；复用成熟scan/native过程所有者，不造另一reader、cache、epoch配置、串行gate或HTTP旁路。直接移除fetching读复用是一个小候选，但会增加并发真实rg工作，须基于得到的时序证据和同scope/多scope负载考虑，不能现在凭候选改产品。不要盲目await原失败scan后再给新请求旧错误，或吞原错误造空数组。

A只在同组件真实逆序publication被证实时实施：数据刷新资格可与最新反馈token分开，仍用原scope/search/required owner；已发布、同scope的旧操作可更新当前数据，但旧feedback/选择/展开不得盖过新动作。现能力不能完成真实drop，所以这个方向先保持候选，不新造全局revision触发器或禁止并发按钮。

本轮没有运行验证。以上所有执行均待正式 spec 与 root 独立授权；本报告不能当成 backend/桌面或并发验收通过。
