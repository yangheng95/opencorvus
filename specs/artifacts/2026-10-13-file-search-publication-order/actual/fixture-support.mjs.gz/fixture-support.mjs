/** Prepared only. Importing this module performs no filesystem or network work. */
import assert from "node:assert/strict"
import fs from "node:fs/promises"
import path from "node:path"
import { fileURLToPath } from "node:url"

export const scratch = path.dirname(fileURLToPath(import.meta.url))
export const evidence = path.join(scratch, "before")
export const runRoot = path.resolve("C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/file-search-overlap-before-01a133")
export const port = 18451
export const baseURL = `http://127.0.0.1:${port}`
export const preparedPath = path.join(runRoot, "prepared-fixture.json")
export const scopes = {
  root: path.join(runRoot, "project"),
  child: path.join(runRoot, "project", "scoped-project"),
  secondary: path.join(runRoot, "second-project"),
}
export const queryFor = (role) => `overlap-01a133-${role === "secondary" ? "root" : role}-`
export const stamp = () => ({ utc: new Date().toISOString(), wallMs: Date.now(), monotonicNs: String(process.hrtime.bigint()) })
export const samePath = (left, right) => path.resolve(left).toLowerCase() === path.resolve(right).toLowerCase()
export const serializeError = (error) => ({ name: error?.name ?? typeof error, code: error?.code, message: error?.message ?? String(error), stack: error?.stack })
export const readJSON = async (filename) => JSON.parse(await fs.readFile(filename, "utf8"))

export async function save(name, value) {
  assert.equal(path.basename(name), name, "Evidence filename must be one segment")
  await fs.mkdir(evidence, { recursive: true })
  const full = path.join(evidence, name)
  await fs.writeFile(full, JSON.stringify(value, null, 2), { flag: "wx" })
  return full
}

export async function assertOwnedPhysical(full, allowMissing = false) {
  const normalized = path.resolve(full)
  const relative = path.relative(runRoot, normalized)
  assert.ok(relative === "" || (!relative.startsWith("..") && !path.isAbsolute(relative)), "Path escaped this exact owned run")
  let current = normalized
  for (;;) {
    try {
      const entry = await fs.lstat(current)
      assert.equal(entry.isSymbolicLink(), false, `Owned namespace has a terminal link: ${current}`)
    } catch (error) {
      if (!(allowMissing && error.code === "ENOENT")) throw error
    }
    if (samePath(current, runRoot)) break
    current = path.dirname(current)
  }
  const root = await fs.lstat(runRoot)
  assert.equal(root.isDirectory(), true)
  assert.equal(samePath(await fs.realpath(runRoot), runRoot), true, "Run root has a physical ancestor alias")
  return normalized
}

export async function physical(full) {
  await assertOwnedPhysical(full)
  const entry = await fs.lstat(full, { bigint: true })
  const result = { full, at: stamp(), file: entry.isFile(), directory: entry.isDirectory(), symbolicLink: entry.isSymbolicLink(), device: String(entry.dev), inode: String(entry.ino), size: Number(entry.size) }
  if (entry.isFile()) result.bytesBase64 = (await fs.readFile(full)).toString("base64")
  return result
}

export async function loadPrepared() {
  let fixture = await readJSON(preparedPath)
  assert.equal(fixture.schema, "file-search-overlap.fixture/v1")
  assert.equal(samePath(fixture.runRoot, runRoot), true)
  assert.equal(fixture.port, port)
  // Immutable original setup and one actual completed expansion are evidence stages,
  // not alternate products or filesystem caches. Only known absence means no expansion.
  let expansion
  try { expansion = await readJSON(path.join(runRoot, "expansion-receipt.json")) } catch (error) {
    if (error.code !== "ENOENT") throw error
  }
  if (expansion) {
    assert.equal(expansion.schema, "file-search-overlap.expansion/v1")
    assert.equal(expansion.fixture.fixtureID, fixture.fixtureID)
    assert.equal(expansion.fixture.fanout.fileCount, 16000)
    assert.equal(expansion.fixture.fanout.directoryCount, 128)
    fixture = expansion.fixture
  }
  for (const [role, full] of Object.entries(scopes)) {
    assert.equal(samePath(fixture.scopes[role].directory, full), true)
    await assertOwnedPhysical(full)
    const actual = await physical(full)
    assert.equal(actual.device, fixture.scopes[role].identity.device)
    assert.equal(actual.inode, fixture.scopes[role].identity.inode)
  }
  return fixture
}

export async function loadOwner(fixture) {
  const owner = await readJSON(path.join(runRoot, "launch-owner.json"))
  assert.equal(samePath(owner.runRoot, runRoot), true)
  assert.equal(samePath(owner.runtime, path.join(runRoot, "runtime")), true)
  assert.equal(samePath(owner.project, scopes.root), true)
  assert.equal(samePath(owner.settlementEvidenceRoot, evidence), true)
  assert.equal(owner.port, port)
  assert.equal(owner.fixtureID, fixture.fixtureID)
  assert.ok(owner.nativeTarget.pid > 0 && owner.nativeTarget.processInstanceID && owner.nativeTarget.occurrenceID)
  assert.ok(owner.host.pid > 0 && owner.host.processInstanceID && owner.host.occurrenceID)
  assert.ok(owner.nativeDeadline > Date.now(), "Owned service execution deadline has already elapsed; preserve it, do not replace the instance")
  assert.equal(path.basename(owner.ripgrepExecutable).toLowerCase(), "rg.exe")
  return owner
}

/** Client observation budget. Expiry never asserts a service/process terminal state. */
export function inactivityBudget(milliseconds = 120_000) {
  const controller = new AbortController()
  let latest = Date.now()
  let lastActivity = { label: "client-budget-start", at: stamp() }
  const tick = setInterval(() => {
    if (Date.now() - latest < milliseconds) return
    const error = new Error(`No new original HTTP/native evidence for ${milliseconds}ms; service state remains unknown/pending`)
    error.name = "ObservationInactivityError"
    error.code = "OBSERVATION_PENDING"
    error.lastActivity = lastActivity
    controller.abort(error)
  }, 250)
  return {
    signal: controller.signal,
    activity(label) { latest = Date.now(); lastActivity = { label, at: stamp() } },
    current: () => lastActivity,
    close: () => clearInterval(tick),
  }
}

/** Saves exact request JSON and complete response bytes, including errors. */
export function httpClient(budget, records) {
  let sequence = 0
  return async function request(label, route, directory, query = {}, body) {
    const url = new URL(route, baseURL)
    url.searchParams.set("directory", directory)
    for (const [key, value] of Object.entries(query)) url.searchParams.set(key, String(value))
    const requestBody = body === undefined ? undefined : JSON.stringify(body)
    const record = { sequence: ++sequence, label, method: body === undefined ? "GET" : "POST", url: url.toString(), requestBody, requestBodyByteLength: requestBody === undefined ? 0 : Buffer.byteLength(requestBody), dispatchedAt: stamp(), chunks: [] }
    records.push(record)
    budget.activity(`dispatch:${label}`)
    try {
      const response = await fetch(url, { method: record.method, headers: body === undefined ? undefined : { "content-type": "application/json" }, body: requestBody, signal: budget.signal })
      record.headersAt = stamp()
      record.status = response.status
      record.headers = Object.fromEntries(response.headers)
      record.requestID = response.headers.get("x-opencorvus-request-id")
      budget.activity(`headers:${label}`)
      const bytes = []
      if (response.body) {
        for await (const chunk of response.body) {
          bytes.push(Buffer.from(chunk))
          record.chunks.push({ at: stamp(), bytes: chunk.byteLength, bytesBase64: Buffer.from(chunk).toString("base64") })
          budget.activity(`body:${label}`)
        }
      }
      const complete = Buffer.concat(bytes)
      record.rawBodyBase64 = complete.toString("base64")
      record.rawBody = complete.toString("utf8")
      record.bodyCompleteAt = stamp()
      try { record.body = JSON.parse(record.rawBody) } catch (error) { record.parseError = serializeError(error) }
      return record
    } catch (error) {
      record.error = serializeError(error)
      record.failedAt = stamp()
      throw error
    }
  }
}
