/** Read-only original durable-file observer. No product hooks, process control or stream reads. */
import assert from "node:assert/strict"
import fs from "node:fs/promises"
import path from "node:path"
import { fileURLToPath, pathToFileURL } from "node:url"
import { runRoot, scopes, scratch, stamp, save, samePath, serializeError, assertOwnedPhysical, loadPrepared, loadOwner, inactivityBudget } from "./fixture-support.mjs"

const fileNames = ["request.json", "helper.json", "ready.json", "settled.json"]
const fileKeys = { "request.json": "request", "helper.json": "helper", "ready.json": "ready", "settled.json": "settled" }
const exactArgs = ["--files", "--null", "--glob=!.git/*", "--hidden"]
const sleep = (milliseconds) => new Promise((resolve) => setTimeout(resolve, milliseconds))
const object = (value) => value !== null && typeof value === "object" && !Array.isArray(value)
const exactKeys = (value, expected) => assert.deepEqual(Object.keys(value).sort(), expected.toSorted())

async function readOriginal(full) {
  try {
    const entry = await fs.lstat(full)
    assert.equal(entry.isFile(), true, `Original durable marker is not a file: ${full}`)
    assert.equal(entry.isSymbolicLink(), false, `Original durable marker is a link: ${full}`)
    const bytes = await fs.readFile(full)
    const observedAt = stamp()
    return { full, observedAt, rawBodyBase64: bytes.toString("base64"), rawBody: bytes.toString("utf8") }
  } catch (error) {
    if (error.code === "ENOENT") return undefined
    throw error
  }
}

function validateRequest(value, root, owner, nativeRuntimeOccurrenceID) {
  assert.ok(object(value))
  exactKeys(value, ["kind", "executable", "args", "detached", "cwd", "ready_file", "request_id", "launch_failed_file", "cancel_file", "settled_file", "owner_pid", "owner_process_instance_id", "runtime_occurrence_id", ...(Object.hasOwn(value, "terminate_children_on_root_exit") ? ["terminate_children_on_root_exit"] : [])])
  assert.equal(value.kind, "command")
  assert.deepEqual(value.args, exactArgs)
  assert.equal(value.detached, false)
  assert.equal(value.owner_pid, owner.nativeTarget.pid)
  assert.equal(value.owner_process_instance_id, owner.nativeTarget.processInstanceID)
  assert.equal(typeof value.runtime_occurrence_id, "string")
  assert.ok(value.runtime_occurrence_id.length > 0)
  if (nativeRuntimeOccurrenceID !== undefined) assert.equal(value.runtime_occurrence_id, nativeRuntimeOccurrenceID)
  assert.equal(samePath(value.executable, owner.ripgrepExecutable), true)
  assert.ok(Object.values(scopes).some((cwd) => samePath(cwd, value.cwd)))
  assert.equal(typeof value.request_id, "string")
  assert.ok(value.request_id.length > 0)
  for (const [key, name] of Object.entries({ ready_file: "ready.json", launch_failed_file: "launch-failed.json", cancel_file: "cancel", settled_file: "settled.json" })) assert.equal(samePath(value[key], path.join(root, name)), true)
  return value
}

function validateMarker(key, value, request, captured) {
  assert.ok(object(value))
  assert.equal(value.request_id, request.request_id)
  assert.equal(value.runtime_occurrence_id, request.runtime_occurrence_id)
  assert.ok(Number.isInteger(value.helper_pid) && value.helper_pid > 0)
  if (key === "helper") {
    exactKeys(value, ["protocol", "request_id", "helper_pid", "helper_process_instance_id", "runtime_occurrence_id"])
    assert.equal(value.protocol, 1)
    assert.match(value.helper_process_instance_id, /^win32:[0-9]+$/)
  }
  if (key === "ready") {
    exactKeys(value, ["protocol", "detached", "request_id", "helper_pid", "target_pid", "target_process_instance_id", "runtime_occurrence_id", ...(Object.hasOwn(value, "terminate_children_on_root_exit") ? ["terminate_children_on_root_exit"] : [])])
    assert.equal(value.protocol, 3)
    assert.equal(value.detached, false)
    assert.ok(Number.isInteger(value.target_pid) && value.target_pid > 0)
    assert.match(value.target_process_instance_id, /^win32:[0-9]+$/)
  }
  if (key === "settled") {
    exactKeys(value, ["protocol", "request_id", "helper_pid", "target_pid", "active_processes", "runtime_occurrence_id"])
    assert.equal(value.protocol, 1)
    assert.equal(value.active_processes, 0)
    assert.ok(Number.isInteger(value.target_pid) && value.target_pid > 0)
  }
  for (const marker of [captured.helper?.body, captured.ready?.body, captured.settled?.body].filter(Boolean)) assert.equal(marker.helper_pid, value.helper_pid)
  if (captured.ready && key === "settled") assert.equal(value.target_pid, captured.ready.body.target_pid)
  if (captured.settled && key === "ready") assert.equal(value.target_pid, captured.settled.body.target_pid)
}

export async function createRgObserver(owner, label, budget) {
  // Pure current primitive only: importing Global would initialize/mutate its cache.
  const { resolveOpenCorvusRuntimePaths } = await import(pathToFileURL(path.join(scratch, "../packages/util/src/runtime-paths.ts")).href)
  const paths = resolveOpenCorvusRuntimePaths({ env: { OPENCORVUS_HOME: owner.runtime }, platform: "win32", home: path.join(runRoot, "home") })
  const temporary = paths.temporary
  await assertOwnedPhysical(temporary)
  const derivation = { primitive: "packages/util/src/runtime-paths.ts:resolveOpenCorvusRuntimePaths", inputs: { env: { OPENCORVUS_HOME: owner.runtime }, platform: "win32", home: path.join(runRoot, "home") }, temporary, externallyObservedOwner: owner.nativeTarget, runtimeBindingPolicy: "First original Target-self-published rg request, after exact PID/birth/cwd/argv/executable/path/schema validation; all later records must use its same runtime UUID. External observation UUID is a distinct fact.", exactArgs, exactExecutable: owner.ripgrepExecutable, exactCwds: Object.values(scopes), at: stamp(), pollMilliseconds: 10, requestDirectoryCap: 128 }
  await save(`native-observer-inputs-${label}.json`, derivation)
  const captures = new Map()
  const events = []
  let running = true
  let failure
  let sweepSequence = 0
  let stopPromise
  let nativeRuntimeOccurrenceID
  let nativeRuntimeBinding
  async function captureFile(record, name, original) {
    const key = fileKeys[name]
    if (record[key]) {
      assert.equal(original.rawBodyBase64, record[key].rawBodyBase64, "An immutable original durable marker changed")
      return
    }
    // Preserve malformed original bytes before reporting validation failure.
    await save(`native-${label}-${record.requestID}-${name}`, original)
    const body = JSON.parse(original.rawBody)
    if (key !== "request") validateMarker(key, body, record.request.body, record)
    record[key] = { ...original, body }
    events.push({ kind: "original-marker", requestID: record.requestID, key, observedAt: original.observedAt })
    budget.activity(`native:${record.requestID}:${key}`)
  }
  async function sweep() {
    sweepSequence++
    const directories = (await fs.readdir(temporary, { withFileTypes: true })).filter((item) => item.name.startsWith("supervisor-"))
    assert.ok(directories.length <= 128, "Unexpected owned Native request volume; preserve unknown rather than broad scan")
    const current = new Set()
    for (const directory of directories) {
      assert.equal(directory.isDirectory(), true)
      assert.equal(directory.isSymbolicLink(), false)
      const root = path.join(temporary, directory.name)
      current.add(root)
      const original = await readOriginal(path.join(root, "request.json"))
      if (!original) continue
      let body
      try { body = JSON.parse(original.rawBody) } catch (error) {
        await save(`native-${label}-${directory.name}-malformed-request.json`, original)
        throw error
      }
      // Ignore other owned commands without retaining their arguments or reading their streams.
      if (body.kind !== "command" || !samePath(body.executable, owner.ripgrepExecutable) || !Array.isArray(body.args) || body.args.length !== exactArgs.length || body.args.some((arg, index) => arg !== exactArgs[index]) || !Object.values(scopes).some((cwd) => typeof body.cwd === "string" && samePath(body.cwd, cwd))) continue
      try { validateRequest(body, root, owner, nativeRuntimeOccurrenceID) } catch (error) {
        await save(`native-${label}-${directory.name}-invalid-request.json`, original)
        throw error
      }
      let record = captures.get(body.request_id)
      if (!record) {
        record = { requestID: body.request_id, root, firstObservedAt: original.observedAt }
        captures.set(body.request_id, record)
      }
      assert.equal(record.root, root)
      await captureFile(record, "request.json", original)
      if (nativeRuntimeOccurrenceID === undefined) {
        nativeRuntimeOccurrenceID = body.runtime_occurrence_id
        nativeRuntimeBinding = {
          at: stamp(), requestID: body.request_id, originalRequest: record.request,
          runtimeOwner: { pid: body.owner_pid, processInstanceID: body.owner_process_instance_id, occurrenceID: nativeRuntimeOccurrenceID },
          externalObservation: owner.nativeTarget,
          evidenceSource: "Original request published by ProcessSupervisor using currentRuntimeProcessOccurrence() inside this Target; observedProcessOccurrence(pid) outside it only supplies PID/birth plus a separate observation UUID",
          boundary: "A Target-self-published single runtime source bound to exact external PID/birth. This is not an independently observed runtime UUID or permission to accept another runtime ID.",
        }
        await save(`native-runtime-binding-${label}.json`, nativeRuntimeBinding)
      }
      for (const name of fileNames.slice(1)) {
        const marker = await readOriginal(path.join(root, name))
        if (marker) await captureFile(record, name, marker)
      }
    }
    for (const record of captures.values()) {
      if (record.removedAt || current.has(record.root)) continue
      record.removedAt = stamp()
      events.push({ kind: "original-directory-removed", requestID: record.requestID, observedAt: record.removedAt, markersCaptured: fileNames.filter((name) => Boolean(record[fileKeys[name]])) })
      budget.activity(`native:${record.requestID}:directory-removed`)
    }
  }
  await sweep()
  const loop = (async () => {
    try {
      while (running && !budget.signal.aborted) { await sleep(10); await sweep() }
    } catch (error) {
      failure = error
      events.push({ kind: "observer-failed", at: stamp(), error: serializeError(error) })
    }
  })()
  return {
    derivation,
    captures,
    events,
    error: () => failure,
    checkpoint: () => [...captures.keys()],
    snapshot: () => ({ at: stamp(), sweepSequence, nativeRuntimeBinding, requests: [...captures.values()], events: [...events], error: failure && serializeError(failure) }),
    async inspectOriginal(record, inspectionLabel) {
      const inspection = { requestID: record.requestID, root: record.root, startedAt: stamp(), files: {} }
      for (const name of fileNames) {
        const original = await readOriginal(path.join(record.root, name))
        if (original) {
          const key = fileKeys[name]
          const body = JSON.parse(original.rawBody)
          if (key === "request") validateRequest(body, record.root, owner, nativeRuntimeOccurrenceID)
          else validateMarker(key, body, record.request.body, record)
          inspection.files[name] = { ...original, body }
        } else inspection.files[name] = { state: "known-missing", observedAt: stamp() }
      }
      inspection.completeAt = stamp()
      await save(`native-inspection-${label}-${inspectionLabel}.json`, inspection)
      return inspection
    },
    async readyAfter(cwd, excludedIDs, q1State) {
      for (;;) {
        if (failure) throw failure
        budget.signal.throwIfAborted()
        const candidates = [...captures.values()].filter((record) => !excludedIDs.includes(record.requestID) && record.ready && record.helper && samePath(record.request.body.cwd, cwd))
        assert.ok(candidates.length <= 1, "Concurrent unrelated scan in this scope; original Q1 attribution is unknown")
        if (candidates.length === 1) return candidates[0]
        if (q1State.settled) return undefined
        await sleep(1)
      }
    },
    stop() {
      return stopPromise ??= (async () => {
        running = false
        await loop
        const result = { ...derivation, completedAt: stamp(), ...this.snapshot(), boundary: "Read-only original durable files. Missing markers are unknown; directory removal is observed cleanup, not output-EOF proof." }
        await save(`native-observer-result-${label}.json`, result)
        return result
      })()
    },
  }
}

if (process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1])) {
  assert.equal(process.argv[2], "observe", "Explicit observe required; this prepares no service")
  const fixture = await loadPrepared()
  const owner = await loadOwner(fixture)
  const budget = inactivityBudget()
  const observer = await createRgObserver(owner, `standalone-${Date.now()}`, budget)
  process.once("SIGINT", () => { budget.close(); void observer.stop().then(() => process.exit(0)) })
  try {
    while (!budget.signal.aborted && !observer.error()) await sleep(100)
    if (observer.error()) throw observer.error()
    budget.signal.throwIfAborted()
  } finally { await observer.stop(); budget.close() }
}
