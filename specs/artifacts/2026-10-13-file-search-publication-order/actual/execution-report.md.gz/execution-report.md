# 原实例真实搜索调查与收尾

## Recall 与范围

按 `specs/records/2026-10/2026-10-13-file-search-publication-order.md` 和 root 分阶段明确授权，先 prepare-only/root逐文件审查，再在唯一新 owned run 执行。只修改本 scratch caller；没有产品/spec/test/Git mutation、UI脚本、模型、凭据、SQL、再委托或重新启动实例。root 独立进行真实页面和截图复核。

实际 source HEAD 为 `4f4dd49b42a492e9f8ee95cadad8863a2e9af517`，不是预先猜测值；相关 File.index/ripgrep/监督器/ProcessFacade/Explorer/workbench working diff为0，原观测保存 `before/launch-source-*` 与 `launch-relevant-working.diff`。这些是来源事实，不是可变源码哈希门槛。

## 实际输入与实例

- run `C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/file-search-overlap-before-01a133`，source CLI `/ui`18451，借83 immutable captured UI，没有 Vite。
- fixtureID `33bf9f53-5360-409d-8d3d-d2be75dd6403`；3000 filler/64目录，0或1byte，原3005用户文件完整bytes/dev/inode重新读取一致，总1615bytes；prepare及physical-readback exit0。
- occurrence `before-282a33e4-eae3-4e11-b49c-a04e4bbfddbf`；Host66012/birth `win32:639274993786374224`；Target88896/birth `win32:639274993797714178`。launcher parent exec session98384从首次启动一直保持，未重开。
- 原900000ms deadline `1791903478518`，即2026-10-13 14:57:58.518UTC；没有因caller修复、观测或UI延长。
- Target自产 Native runtime UUID `95054259-2bc4-4ce3-9ff5-677c20f83a10` 由原真实rg request在PID/birth/argv/executable/cwd/schema/path检查之后绑定。外部物理观察 UUID `f48cb01e-8e96-4445-b331-312d52ee8fc7` 是另一种事实；没有声称独立观测到Target runtime UUID。

## 保留的首次失败及有限修正

`setup-project.mjs register` 原exit1，原root Project200/空Chat201后，child/project/current409 `NonCanonicalConfigFileError`。canonical为child `.opencorvus/opencorvus.jsonc`，conflict为祖先root canonical配置。原请求ID `696e2b05-5cac-479e-b01d-217c16c98dc0`；完整 `before/register-failed-1791902639271.json`/原stdout/exit仍在。没有删移配置、改Flag、假ProjectID、换实例或重建原root Session。

root先补规格、完整审查修后caller并另授执行。唯一registrar替换为 `register-secondary`，从首次实际200/201恢复原root资格，只正常注册第二Git Project/空Chat，actual exit0。root真实ID `prj_hWtk7jQUoXtOpbFkaKt2`/Chat `ses_-zUS3b8kRzzbRvU67fE1`；secondary真实ID `prj_h5F2pIl2XylfYi42X31w`/Chat `ses_-zUS3Zmbmzz9835NK53y`。child409和same-Project current-directory search未完成明确保在fixture，不冒称child200或同scope隔离已实测。

第一 `probe root 3 expand` 原exit1、attempts=[]，只有4个GET200（warm/root完整bytes/独立Project查询及完整bytes），没有POST或扩大。根因是observer错误要求外部 `observedProcessOccurrence(pid)` 每次随机生成的观察UUID等于Target内缓存的 `currentRuntimeProcessOccurrence()` UUID；源码及原request证实二者只可按PID/birth互证。原 `probe-root-1791902962276.json`、`first-failure-root-1791902962276.json`、invalid-request原3095bytes、script旧版及scope admission均保留。

root先补正式修正，再审查v2并另授一次执行。observer在exact owned tmp第一份真实rg request验证完整物理与协议事实，保存原request自产runtime与external observation分栏receipt；以后所有request/helper/ready/settled严格同自产runtime。透明v2新admission保原失误，仍最多3实际attempt。未增加产品API/emit/factory/采集gate/流冻结/代理或并行事实源。

## 真实结果和资格

`probe root 3 expand native-owner-v2`（checker session16531）实际exit0，2026-10-13 14:56:14.270–14:56:46.629。22个真实HTTP全部200、8个原rg request捕获；3个原marker每个19bytes，physical完整bytes/dev/inode、content200和list准确。第一次3000/64，之后一次扩大至16000/128；完整原扩展manifest约9.31MB，真实filler用户bytes仅8000，未越1MiB。最大3个actual attempt，未重试失败或unknown。

POST完整200后同一客户端同步dispatch Q2，再并行取实体/content/list/原Native文件，Q3作fresh对照。三Q1自身均已经包含本次marker，Q2/Q3准确包含全部已成功发布成员。三次采样都未取得original request仍可读且晚于Q2 server started的强pending事实。**结果仅bounded-controls-complete-fault-not-reproduced，不能排除File.files fetching候选或当作根因修复证据。** 不因本轮对照准确而删fetching、改File.index或扩大负载。

主证据：

- `before/probe-root-native-owner-v2-1791903374246.json`、`attempt-root-native-owner-v2-1791903374246-1/2/3.json`。
- `before/native-runtime-binding-root-native-owner-v2-1791903374246.json`、同label原request/helper/ready/settled与native-observer-result。
- `before/expanded-fixture-root-native-owner-v2-1791903374246.json`、run原 `expansion-receipt.json`、`before/outcome-summary-v2.json`。
- 全checker阶段共31HTTP：28×200、2×201、1×409（只计这些JSON checker；不混入launcher资产绑定或root真实UI请求）。原失败/修后controls全部保留。

## 真实UI与原截止收尾

root本人Tab20实际看root搜索4成员并保存3张原截图；picker正逢原deadline，第三图保真实 `TypeError: Failed to fetch/Offline`。本 agent没有UI自动化，也没有以API对照冒充picker成功。root已close该tab后另授成熟shutdown。

原Native在14:57:58.635UTC实际 `outcome=settled`、`terminal.reason=deadline_exceeded`、`exitCode=1`；whole Job physicalCompletion、outputDrainComplete、requestCleanupComplete实际fulfilled。成熟 `shutdown.ps1 -PageClosed -Reason original-execution-deadline-followup` helper exit0，Target已dead所以 `dispatch=false`，没有伪造普通shutdown200。Host/Target依原birth均dead_or_reused、18451无listener；auth/models一直already_absent，未复制或读取其内容。

parent exec98384 actualjoin **exit1**，`before/before-launcher-joined.json`、`launcher-parent-error.json`及`launcher-original.exit.txt`保原1。helper cleanup0不能覆盖原Native/parent deadline1，绝不称normal0。

picker target `project/overlap-01a133-root-ui.txt` 只读physical实际ENOENT；原chooser输入21bytes和identity保在 `before/ui-picker-target-physical-after-deadline.json`，检查器exit0仅这项真实物理资格。未unlink target、未重新创建文件、未发后续API或启动新实例。

本轮剩余资格：UI正常picker成功未满足；child同Project directory search未完成；A真实external drop能力未证；B实际旧scan遗漏未复现。下一明确UI接受轮次由root另落计划，不重用此截止失败当成功。
