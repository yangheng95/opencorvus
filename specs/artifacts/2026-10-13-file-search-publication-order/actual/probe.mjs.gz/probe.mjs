/** Prepared only. Normal tiny public upload is the sole publication operation. */
import assert from "node:assert/strict"
import fs from "node:fs/promises"
import path from "node:path"
import { runRoot, scopes, evidence, stamp, save, readJSON, physical, assertOwnedPhysical, samePath, loadPrepared, loadOwner, inactivityBudget, httpClient, serializeError } from "./fixture-support.mjs"
import { createRgObserver } from "./native-rg-observer.mjs"
import { expandForProbe } from "./setup-project.mjs"

const [role = "root", requestedAttempts = "1", expansion = "no-expand", checkerStage] = process.argv.slice(2)
assert.equal(role, "root", "This occurrence qualifies root only; original child admission is typed409")
const maxAttempts = Number(requestedAttempts)
assert.ok(Number.isInteger(maxAttempts) && maxAttempts >= 1 && maxAttempts <= 3, "At most three original attempts")
assert.ok(["expand", "no-expand"].includes(expansion), "Expansion must be an explicit reviewed input")
assert.equal(checkerStage, "native-owner-v2", "Explicit repaired checker stage required; original failure/admission remain immutable")
const label = `${role}-${checkerStage}-${Date.now()}`
let fixture = await loadPrepared()
const registered = await readJSON(path.join(evidence, "fixture.json"))
assert.equal(registered.fixtureID, fixture.fixtureID)
const owner = await loadOwner(fixture)
assert.equal(registered.owner.occurrence, owner.occurrence)
const originalProbePath = path.join(evidence, "probe-root-1791902962276.json")
const originalProbe = await readJSON(originalProbePath)
assert.equal(originalProbe.fixtureID, fixture.fixtureID)
assert.equal(originalProbe.owner.occurrence, owner.occurrence)
assert.equal(originalProbe.owner.nativeTarget.processInstanceID, owner.nativeTarget.processInstanceID)
assert.equal(originalProbe.exitCode, 1)
assert.equal(originalProbe.attempts.length, 0, "Original checker failed before actual attempts; this stage has the original total maximum of three")
assert.deepEqual(originalProbe.requests.map(({ label, method, status }) => ({ label, method, status })), [
  { label: "warm", method: "GET", status: 200 },
  { label: "content:project:overlap-01a133-root-original.txt", method: "GET", status: 200 },
  { label: "independent-project-control", method: "GET", status: 200 },
  { label: "content:second-project:overlap-01a133-root-original.txt", method: "GET", status: 200 },
])
const directory = scopes[role]
const query = fixture.scopes[role].query
const budget = inactivityBudget(120_000)
const requests = []
const request = httpClient(budget, requests)
const summary = { schema: "file-search-overlap.probe/v1", label, checkerStage, originalProbePath, originalAttemptCount: originalProbe.attempts.length, role, directory, query, maxAttempts, expansion, fixtureID: fixture.fixtureID, owner, startedAt: stamp(), originalRegisterFailure: registered.registration.originalFailurePath, unfulfilledControls: registered.registration.unfulfilledControls, requests, controls: [], attempts: [], productSource: "Original source CLI /find/file -> File.search -> existing Ripgrep/ProcessSupervisor", uiQualification: "No UI used; root owns actual page interaction and screenshots" }
let observer
let exitCode = 0

function positiveStatus(response, expected = 200) {
  assert.equal(response.status, expected, `${response.label}: ${response.rawBody}`)
  assert.equal(typeof response.requestID, "string", "Every actual response must expose its original request ID")
}
function members(response) {
  positiveStatus(response)
  assert.ok(Array.isArray(response.body) && response.body.every((value) => typeof value === "string"))
  return response.body.map((value) => value.replaceAll("\\", "/")).toSorted()
}
function contract(response, expected) {
  const actual = members(response)
  const required = expected.map((value) => value.replaceAll("\\", "/")).toSorted()
  return JSON.stringify(actual) === JSON.stringify(required)
    ? { outcome: "accurate", expected: required, actual }
    : { outcome: "mismatch", name: "SearchPublishedMembersMismatch", expected: required, actual }
}
function search(label, scope = directory) {
  return request(label, "/find/file", scope, { query, type: "file", limit: 100 })
}
async function captureOriginalLogs() {
  const logRoot = path.join(owner.runtime, "log")
  await assertOwnedPhysical(logRoot)
  const entries = (await fs.readdir(logRoot, { withFileTypes: true })).filter((entry) => entry.isFile() && entry.name.endsWith(".log"))
  assert.ok(entries.length <= 8, "Unexpected owned log generation count")
  const result = []
  for (const entry of entries) {
    const full = path.join(logRoot, entry.name)
    await assertOwnedPhysical(full)
    const bytes = await fs.readFile(full)
    assert.ok(bytes.byteLength <= 4 * 1024 * 1024, "Original owned log exceeds reviewed capture limit; evidence incomplete")
    const raw = bytes.toString("utf8")
    const parsed = []
    const parseErrors = []
    for (const [index, line] of raw.split(/\r?\n/).entries()) {
      if (!line) continue
      try { parsed.push(JSON.parse(line)) } catch (error) {
        parseErrors.push({ lineNumber: index + 1, rawLine: line, error: serializeError(error), boundary: "Original malformed or incomplete append preserved; do not infer a missing request from this line" })
      }
    }
    const ids = requests.map((record) => record.requestID).filter(Boolean)
    result.push({ full, at: stamp(), rawBodyBase64: bytes.toString("base64"), rawBody: raw, parseErrors, matchingRequests: parsed.filter((record) => record.message === "request" && ids.includes(record.data?.requestID)) })
  }
  return result
}
async function bytesContract(scope, name, expectedBytes, originalIdentity) {
  const full = path.join(scope, name)
  const identity = await physical(full)
  assert.equal(identity.file, true)
  assert.equal(identity.symbolicLink, false)
  assert.equal(identity.bytesBase64, expectedBytes)
  if (originalIdentity) {
    assert.equal(identity.device, originalIdentity.device)
    assert.equal(identity.inode, originalIdentity.inode)
  }
  const content = await request(`content:${path.basename(scope)}:${name}`, "/file/content", scope, { path: name })
  positiveStatus(content)
  assert.equal(content.body.type, "text")
  assert.equal(Buffer.from(content.body.content, "utf8").toString("base64"), expectedBytes)
  assert.equal(typeof content.body.revision, "string")
  return { identity, content }
}
async function retainFirst(kind, data) {
  const filename = `first-${kind}-${label}.json`
  if (summary[`first${kind}`]) return
  const fact = { at: stamp(), label, original: data, boundary: "First original result retained; subsequent controls do not erase it" }
  await save(filename, fact)
  summary[`first${kind}`] = filename
}

try {
  await save(`probe-${role}-${checkerStage}-admission.json`, { label, checkerStage, originalProbePath, originalAttemptCount: 0, role, maxAttempts, expansion, owner, fixtureID: fixture.fixtureID, at: stamp(), boundary: "Transparent checker repair after original pre-attempt owner-schema failure. Original admission/error remains intact; total actual attempt limit remains three in this same occurrence." })
  observer = await createRgObserver(owner, label, budget)
  // First complete request absorbs state initialization/preload; it is not Q1.
  const original = fixture.markers.find((marker) => marker.role === role)
  const expected = [original.name]
  const warm = await search("warm")
  const warmContract = contract(warm, expected)
  assert.equal(warmContract.outcome, "accurate")
  summary.controls.push({ label: "warm", result: warmContract, physical: await bytesContract(directory, original.name, original.bytesBase64, original) })
  // Same public basename/query, different owned physical bytes and actual second Project.
  const secondary = fixture.markers.find((marker) => marker.role === "secondary")
  if (role === "root") {
    const second = await search("independent-project-control", scopes.secondary)
    const secondContract = contract(second, [secondary.name])
    assert.equal(secondContract.outcome, "accurate")
    summary.controls.push({ label: "independent-project-control", projectID: registered.registration.scopes.secondary.projectID, result: secondContract, physical: await bytesContract(scopes.secondary, secondary.name, secondary.bytesBase64, secondary) })
  }
  for (let index = 1; index <= maxAttempts; index++) {
    budget.signal.throwIfAborted()
    if (observer.error()) throw observer.error()
    const attempt = { index, at: stamp(), fixtureCount: fixture.fanout.fileCount, fixtureDirectories: fixture.fanout.directoryCount, nativeCheckpoint: observer.checkpoint(), q1State: { settled: false } }
    summary.attempts.push(attempt)
    const q1 = search(`attempt${index}-Q1`)
    // Attach settlement immediately. Both rejection and original response are preserved.
    const q1Tracked = q1.then((value) => { attempt.q1State.settled = true; attempt.q1State.outcome = "fulfilled"; attempt.q1State.at = stamp(); return value }, (error) => { attempt.q1State.settled = true; attempt.q1State.outcome = "rejected"; attempt.q1State.error = serializeError(error); attempt.q1State.at = stamp(); throw error })
    void q1Tracked.catch(() => undefined)
    const native = await observer.readyAfter(directory, attempt.nativeCheckpoint, attempt.q1State)
    if (attempt.q1State.outcome === "rejected") await q1Tracked
    if (!native) {
      attempt.q1 = await q1Tracked
      attempt.classification = "unknown-ready-or-helper-not-captured"
      attempt.native = observer.snapshot()
      await retainFirst("unknown", attempt)
      await save(`attempt-${label}-${index}.json`, attempt)
      exitCode = 3
      break
    }
    attempt.nativeRequestID = native.requestID
    attempt.nativeReady = native.ready
    attempt.nativeHelper = native.helper
    const name = `${query}published-${label}-${index}.txt`
    const bytes = Buffer.from(`PUB ${role} ${index} 01a133\r\n`)
    assert.ok(bytes.length >= 16 && bytes.length <= 64)
    attempt.publication = await request(`attempt${index}-publication`, "/file/upload", directory, {}, { targetDir: "", files: [{ name, contentBase64: bytes.toString("base64"), mimeType: "text/plain" }] })
    positiveStatus(attempt.publication)
    assert.deepEqual(attempt.publication.body, [{ name, path: name, bytes: bytes.byteLength }])
    expected.push(name)
    // Q2 dispatch occurs synchronously here before any independent filesystem/content/list await.
    const q2 = search(`attempt${index}-Q2`)
    const entityProof = bytesContract(directory, name, bytes.toString("base64"))
    const directoryProof = request(`attempt${index}-list`, "/file", directory, { path: "" })
    const nativeProof = observer.inspectOriginal(native, `attempt${index}-after-Q2-dispatch`)
    const results = await Promise.allSettled([q1Tracked, q2, entityProof, directoryProof, nativeProof])
    attempt.parallel = results.map((result, position) => ({ position, status: result.status, ...(result.status === "fulfilled" ? { value: result.value } : { error: serializeError(result.reason) }) }))
    const failure = results.find((result) => result.status === "rejected")
    if (failure) throw failure.reason
    ;[attempt.q1, attempt.q2, attempt.entity, attempt.list, attempt.nativeInspection] = results.map((result) => result.value)
    positiveStatus(attempt.q1)
    positiveStatus(attempt.list)
    assert.ok(Array.isArray(attempt.list.body))
    const listed = attempt.list.body.find((node) => node.path.replaceAll("\\", "/") === name)
    assert.deepEqual(listed, { name, path: name, absolute: path.join(directory, name), type: "file", ignored: false })
    assert.ok(BigInt(attempt.q2.dispatchedAt.monotonicNs) > BigInt(attempt.publication.bodyCompleteAt.monotonicNs))
    attempt.q2Contract = contract(attempt.q2, expected)
    attempt.q3 = await search(`attempt${index}-Q3`)
    attempt.q3Contract = contract(attempt.q3, expected)
    attempt.native = observer.snapshot()
    attempt.originalLogs = await captureOriginalLogs()
    const q2Started = attempt.originalLogs.flatMap((log) => log.matchingRequests).find((record) => record.data.requestID === attempt.q2.requestID && record.data.status === "started")
    const presence = attempt.nativeInspection.files["request.json"]
    attempt.overlapFacts = {
      q1Identity: { requestID: native.requestID, runtimeOccurrenceID: native.request.body.runtime_occurrence_id, ownerPID: native.request.body.owner_pid, helperPID: native.helper.body.helper_pid, helperBirth: native.helper.body.helper_process_instance_id, targetPID: native.ready.body.target_pid, targetBirth: native.ready.body.target_process_instance_id },
      q1StartedBeforePublication: BigInt(native.ready.observedAt.monotonicNs) < BigInt(attempt.publication.dispatchedAt.monotonicNs),
      q2OriginalServerStarted: q2Started ?? null,
      originalRequestPresentAfterQ2ServerStarted: Boolean(q2Started && presence.body && presence.observedAt.wallMs > Date.parse(q2Started.time) && attempt.originalLogs.every((log) => log.parseErrors.length === 0)),
      boundary: "An observed original request still present after the server's Q2 start supports disposal still pending. A later poll removal timestamp by itself does not prove pending acquisition.",
    }
    if (attempt.q3Contract.outcome === "mismatch") {
      attempt.classification = "fresh-control-contract-mismatch"
      await retainFirst("failure", attempt)
      exitCode = 1
    } else if (attempt.q2Contract.outcome === "mismatch") {
      attempt.classification = attempt.overlapFacts.q1StartedBeforePublication && attempt.overlapFacts.originalRequestPresentAfterQ2ServerStarted ? "publication-order-candidate-with-original-overlap-evidence" : "publication-order-mismatch-overlap-identity-pending-unknown"
      await retainFirst("failure", attempt)
      exitCode = 1
    } else attempt.classification = "accurate-control-no-fault-reproduced"
    await save(`attempt-${label}-${index}.json`, attempt)
    if (exitCode) break
    if (index < maxAttempts && expansion === "expand" && !fixture.fanout.expanded) {
      fixture = await expandForProbe(fixture, label, (progress) => { (summary.expansionProgress ??= []).push(progress); budget.activity("actual-owned-filler-publication-progress") })
      budget.activity("bounded-owned-fixture-expansion-complete")
    }
  }
  summary.completedAt = stamp()
  summary.outcome = exitCode === 0 ? "bounded-controls-complete-fault-not-reproduced" : exitCode === 3 ? "unknown-observation-retained" : "original-public-contract-mismatch-retained"
} catch (error) {
  summary.error = serializeError(error)
  summary.failedAt = stamp()
  summary.lastOriginalActivity = budget.current()
  await retainFirst(error.code === "OBSERVATION_PENDING" ? "unknown" : "failure", { error: summary.error, requests, attempts: summary.attempts })
  exitCode = error.code === "OBSERVATION_PENDING" ? 3 : 1
  summary.outcome = "checker-failure-or-pending-retained-service-not-stopped"
} finally {
  try {
    if (observer) summary.native = await observer.stop()
  } catch (error) {
    summary.observerCompletionError = serializeError(error)
    exitCode = 1
  } finally { budget.close() }
  summary.exitCode = exitCode
  summary.finalizedAt = stamp()
  await save(`probe-${label}.json`, summary)
  console.log(JSON.stringify({ label, outcome: summary.outcome, exitCode, evidence: path.join(evidence, `probe-${label}.json`), attempts: summary.attempts.map((attempt) => ({ index: attempt.index, classification: attempt.classification, nativeRequestID: attempt.nativeRequestID })) }))
}
process.exitCode = exitCode
