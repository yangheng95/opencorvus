# PREPARED ONLY. Root must read exact inputs and authorize one launch separately.
param(
  [string]$RunRoot='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/file-search-publication-ui-after-01a133',
  [string]$EvidenceRoot=(Join-Path $PSScriptRoot 'after-ui'),
  [int]$Port=18452,
  [string]$Prefix='after-ui',
  [string]$Binary='D:/myhexin-local/opencorvus/.tmp-codex-owner-search-01a133/after-bundle/bin/bun.exe'
)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'owned-launch-functions.ps1')
$ownedRun=[IO.Path]::GetFullPath($RunRoot)
$ownedEvidence=[IO.Path]::GetFullPath($EvidenceRoot)
$ownedBinary=[IO.Path]::GetFullPath($Binary)
if($ownedRun -ne [IO.Path]::GetFullPath('C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/file-search-publication-ui-after-01a133')){throw 'Only this reviewed owned run is allowed'}
if($ownedEvidence -ne [IO.Path]::GetFullPath((Join-Path $PSScriptRoot 'after-ui')) -or $Port -ne 18452 -or $Prefix -cne 'after-ui'){throw 'Exact prepared-only evidence/port/prefix inputs required'}
if($ownedBinary -ne [IO.Path]::GetFullPath('D:/myhexin-local/opencorvus/.tmp-codex-owner-search-01a133/after-bundle/bin/bun.exe')){throw 'Exact immutable 83 after Bun/UI pair required'}
$fixture=Get-Content -Raw -LiteralPath (Join-Path $ownedRun 'prepared-fixture.json')|ConvertFrom-Json
if($fixture.schema -cne 'file-search-publication-ui.fixture/v1' -or [IO.Path]::GetFullPath($fixture.runRoot) -ne $ownedRun -or $fixture.port -ne $Port -or !$fixture.fixtureID){throw 'Exact prepared physical fixture required'}
if($fixture.qualification -cne 'real-desktop-file-search-and-picker-upload' -or $fixture.prefix -cne $Prefix){throw 'Only this independent UI integration fixture is admitted'}
$ownedProject=Join-Path $ownedRun 'project'
if([IO.Path]::GetFullPath($fixture.scopes.root.directory) -ne $ownedProject){throw 'Prepared root Project mismatch'}
foreach($directory in @($ownedRun,$ownedProject,(Join-Path $ownedRun 'runtime'))){
  $item=Get-Item -LiteralPath $directory -ErrorAction Stop
  if(!$item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Direct owned physical directory required'}
}
if(Test-Path -LiteralPath (Join-Path $ownedRun 'launch-owner.json')){throw 'Owned run already launched; no reuse or restart permitted'}
if(!(Test-Path -LiteralPath (Join-Path (Split-Path $ownedBinary -Parent) 'ui/index.html'))){throw 'Private immutable bin/ui required'}
if(@(Get-NetTCPConnection -State Listen -ErrorAction Stop|Where-Object LocalPort -eq $Port).Count){throw 'Owned port occupied; preserve existing process'}
$ownedRg=(Get-Command rg -CommandType Application -ErrorAction Stop|Select-Object -First 1).Source
if(!$ownedRg -or [IO.Path]::GetFileName($ownedRg) -ine 'rg.exe'){throw 'Source-mode actual rg.exe in preserved PATH required'}
[IO.Directory]::CreateDirectory($ownedEvidence)|Out-Null
$ownedOccurrence=$Prefix+'-'+[Guid]::NewGuid().ToString()
$ownedDeadline=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()+900000
$sourceCLI='D:/myhexin-local/opencorvus/packages/opencorvus/src/index.ts'
$ownedArgs=@((Join-Path $PSScriptRoot 'native-host.ts'),'--owned-host',(Join-Path $ownedRun 'evidence'),$ownedOccurrence,[string]$ownedDeadline,$ownedBinary,$sourceCLI,'serve','--hostname','127.0.0.1','--port',[string]$Port,'--project-dir',$ownedProject,'--startup-receipt',(Join-Path $ownedRun 'startup.json'),'--startup-occurrence',$ownedOccurrence,'--log-level','INFO')
$ownedStart=[Diagnostics.ProcessStartInfo]::new()
$ownedStart.FileName=$ownedBinary
$ownedStart.WorkingDirectory=$ownedRun
$ownedStart.UseShellExecute=$false
$ownedStart.CreateNoWindow=$true
$ownedStart.RedirectStandardOutput=$true
$ownedStart.RedirectStandardError=$true
$ownedStart.Environment.Clear()
foreach($environmentName in @('PATH','SystemRoot','WINDIR','ComSpec','PATHEXT','LANG','LC_ALL','LC_CTYPE')){
  if(Test-Path -LiteralPath "Env:$environmentName"){$ownedStart.Environment[$environmentName]=[Environment]::GetEnvironmentVariable($environmentName)}
}
foreach($mapping in @(@('HOME','home'),@('USERPROFILE','home'),@('APPDATA','appdata'),@('LOCALAPPDATA','localappdata'),@('TEMP','temp'),@('TMP','temp'),@('TMPDIR','temp'),@('XDG_CONFIG_HOME','xdg-config'),@('XDG_DATA_HOME','xdg-data'),@('XDG_CACHE_HOME','xdg-cache'),@('XDG_STATE_HOME','xdg-state'),@('OPENCORVUS_HOME','runtime'))){$ownedStart.Environment[$mapping[0]]=Join-Path $ownedRun $mapping[1]}
$ownedStart.Environment['HOMEDRIVE']='C:'
$ownedStart.Environment['HOMEPATH']=$ownedStart.Environment['HOME'].Substring(2).Replace('/','\')
$ownedStart.Environment['OPENCORVUS_TASK_PROCESS_MODE']='native'
$ownedStart.Environment['OPENCORVUS_DISABLE_EXTERNAL_SKILLS']='1'
$ownedStart.Environment['OPENCORVUS_DISABLE_AUTOUPDATE']='1'
foreach($argument in $ownedArgs){$ownedStart.ArgumentList.Add($argument)}
Write-OwnedLaunchFact (Join-Path $ownedEvidence ($Prefix+'-inputs.json')) @{fixtureID=$fixture.fixtureID;fixtureQualification=$fixture.qualification;query=$fixture.query;original=$fixture.original;chooser=$fixture.chooser;runRoot=$ownedRun;project=$ownedProject;port=$Port;nativeDeadline=$ownedDeadline;nativeMaximumMilliseconds=900000;sourceCLI=$sourceCLI;executable=$ownedBinary;arguments=$ownedArgs;environmentNames=@($ownedStart.Environment.Keys);ripgrepExecutable=$ownedRg;modelCalls='None requested; no credential/catalog staging';ui=(Join-Path (Split-Path $ownedBinary -Parent) 'ui');qualification='Independent real-desktop UI integration; root owns screenshots and picker outcome. Not B concurrent scan acceptance.'}
$ownedProcess=[Diagnostics.Process]::new()
$ownedProcess.StartInfo=$ownedStart
if(!$ownedProcess.Start()){throw 'Native Host failed to start'}
$ownedStdout=[IO.File]::Open((Join-Path $ownedRun 'stdout.log'),[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read)
$ownedStderr=[IO.File]::Open((Join-Path $ownedRun 'stderr.log'),[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read)
$ownedOutDrain=$ownedProcess.StandardOutput.BaseStream.CopyToAsync($ownedStdout)
$ownedErrDrain=$ownedProcess.StandardError.BaseStream.CopyToAsync($ownedStderr)
$ownedFailure=$null
$owner=$null
try {
  $readyDeadline=[DateTime]::UtcNow.AddSeconds(45)
  do{
    if(Test-Path -LiteralPath (Join-Path $ownedRun 'evidence/native-host-error.json')){throw 'Original native Host error retained'}
    if((Test-Path -LiteralPath (Join-Path $ownedRun 'evidence/native-host-ready.json')) -and (Test-Path -LiteralPath (Join-Path $ownedRun 'startup.json'))){break}
    if($ownedProcess.HasExited){throw 'Original Host exited before startup'}
    Start-Sleep -Milliseconds 100
  }while([DateTime]::UtcNow -lt $readyDeadline)
  $ready=Get-Content -Raw -LiteralPath (Join-Path $ownedRun 'evidence/native-host-ready.json')|ConvertFrom-Json
  $startup=Get-Content -Raw -LiteralPath (Join-Path $ownedRun 'startup.json')|ConvertFrom-Json
  if($ready.occurrence -cne $ownedOccurrence -or $ready.host.pid -ne $ownedProcess.Id -or $startup.occurrenceID -cne $ownedOccurrence -or $startup.pid -ne $ready.target.pid -or $startup.outcome -cne 'listening' -or ([Uri]$startup.url).Port -ne $Port){throw 'Actual Host/listener occurrence binding failed'}
  if((Get-OwnedNativeState $ready.host) -cne 'exact_live' -or (Get-OwnedNativeState $ready.target) -cne 'exact_live'){throw 'Exact native Host/Target ownership required'}
  if([long]$ready.deadlineAt -ne $ownedDeadline){throw 'Actual fixed native deadline differs from original input'}
  $owner=@{fixtureID=$fixture.fixtureID;occurrence=$ownedOccurrence;runRoot=$ownedRun;runtime=(Join-Path $ownedRun 'runtime');project=$ownedProject;evidence=(Join-Path $ownedRun 'evidence');evidencePrefix=$Prefix;settlementEvidenceRoot=$ownedEvidence;port=$Port;host=$ready.host;nativeTarget=$ready.target;targetBirthAtMs=$ready.targetBirthAtMs;owner=@{ProcessId=$ready.target.pid;processInstanceID=$ready.target.processInstanceID};nativeDeadline=$ownedDeadline;ripgrepExecutable=$ownedRg;qualification='real-desktop-file-search-and-picker-upload';sourceCLI=$sourceCLI;ui=(Join-Path (Split-Path $ownedBinary -Parent) 'ui')}
  Write-OwnedLaunchFact (Join-Path $ownedRun 'launch-owner.json') $owner
  Write-OwnedLaunchFact (Join-Path $ownedEvidence ($Prefix+'-launch-owner.json')) $owner
  $ui=Invoke-WebRequest -NoProxy -Uri "http://127.0.0.1:$Port/ui" -TimeoutSec 15
  $asset=[regex]::Match($ui.Content,'assets/main-[^" ]+\.js').Value
  $expected=Get-Content -Raw -LiteralPath (Join-Path $owner.ui 'index.html')
  if(!$asset -or !$expected.Contains($asset)){throw 'Actual private immutable UI asset binding mismatch'}
  Write-OwnedLaunchFact (Join-Path $ownedEvidence ($Prefix+'-ui-binding.json')) @{status=[int]$ui.StatusCode;sourceHeader=[string]$ui.Headers['x-opencorvus-ui-source'];asset=$asset;privateIndex=(Join-Path $owner.ui 'index.html');occurrence=$ownedOccurrence}
  Write-Output ($owner|ConvertTo-Json -Depth 6)
} catch {
  $ownedFailure=$_
  Write-OwnedLaunchFact (Join-Path $ownedEvidence ($Prefix+'-launcher-error.json')) @{occurrence=$ownedOccurrence;errorType=$_.Exception.GetType().Name;message=$_.Exception.Message;boundary='First original setup failure retained; same parent continues native output/job join'}
  if($owner){
    try { & (Join-Path $PSScriptRoot 'shutdown.ps1') -RunRoot $ownedRun -EvidenceRoot $ownedEvidence -EvidencePrefix $Prefix -Reason setup-failure }
    catch { Write-OwnedLaunchFact (Join-Path $ownedEvidence ($Prefix+'-setup-settlement-error.json')) @{occurrence=$ownedOccurrence;message=$_.Exception.Message;boundary='Same Host and parent remain; no kill or replacement instance'} }
  }
}
while(!$ownedProcess.WaitForExit(500)){}
$ownedProcess.WaitForExit()
$null=$ownedOutDrain.GetAwaiter().GetResult();$null=$ownedErrDrain.GetAwaiter().GetResult()
$ownedStdout.Dispose();$ownedStderr.Dispose()
if(!$owner){throw 'Original setup did not admit the native owner; inspect immutable error and Host records'}
$settled=Get-OwnedNativeSettlement $owner
Write-OwnedLaunchFact (Join-Path $ownedEvidence ($Prefix+'-launcher-joined.json')) @{occurrence=$ownedOccurrence;exitCode=$ownedProcess.ExitCode;settlement=$settled;stdoutDrained=$true;stderrDrained=$true;firstLauncherFailure=if($ownedFailure){$ownedFailure.Exception.Message}else{$null}}
if($ownedFailure){throw $ownedFailure}
if(!$settled -or $ownedProcess.ExitCode -ne 0){throw 'Original native settlement was not successful; first outcome retained'}
