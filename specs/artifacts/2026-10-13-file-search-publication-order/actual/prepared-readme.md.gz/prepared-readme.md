# Prepared-only 原输入与审查清单

本批正式规格：`specs/records/2026-10/2026-10-13-file-search-publication-order.md`。以下文件只有准备和语法检查资格；本 agent 未执行其中任何准备实体、API、服务、observer、模型或 UI 操作。root 必须读完整文件、原参数和现仓库定义后，再明确授权执行。

## 精确绑定

- run：`C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/file-search-overlap-before-01a133`；port 18451；evidence 是本 scratch 的 `before/`。
- 私有 immutable UI/Bun：`.tmp-codex-owner-search-01a133/after-bundle/bin/bun.exe` 及同目录 `ui/`；source CLI 是 `packages/opencorvus/src/index.ts serve`，没有 Vite 或第二 backend。
- root Git 在 `run/project`；child 为其 `scoped-project`，仅用正常 `.git` pointer/core.worktree 指向父 Git；第二 Git 在 `run/second-project`。正常 `/project/current` 返回真实 ID，`POST /coding/chat/session {}` 返回公开空 Chat，验证 root/child 归属和第二独立 Project；不编造 ID 或注入消息/数据库。
- 初始 3000 个真实 filler/64 个目录，文件 0 或 1 byte；只允许一次增至总16000/128，完整用户文件内容≤1MiB。初始 manifest 保全每个 filler、marker、chooser 输入的完整 bytes/dev/inode，扩大时保存真实同样完整事实。Git metadata 不计为用户文件 bytes。
- 原 launcher 身份/Native Job API 保留；固定原900秒 native deadline。没有 ExistingOwnedReceipt、旧项目复用、先前fixture参数、Provider/Task qualification caller。environment 从空表建立，只保 system/PATH 与本 run 的 HOME/runtime 等；不复制 auth/models、用户消息或 Provider catalog，不保 API-key 环境。

## 文件与最小 caller

1. `fixture-support.mjs`：纯声明/工具，import 本身没有 IO；精确 owned 物理准入、完整字节/身份、wx evidence、原 HTTP JSON/原完整 response/chunk bytes/requestID 和120秒客户端无新证据预算。
2. `setup-project.mjs prepare`：只能新建本 run；本地新 Git init，无远端调用；全bytes/inodes与数量事实。
3. `launch.ps1`：只承认步骤2的精确新 fixture；原 source CLI 前台 Job/Host/Target、两输出与parentjoin，实际UI资产绑定。`owned-launch-functions.ps1` 从前批成熟文件只裁出 write/native physical observer/settlement；`native-host.ts` 原成熟单一 ProcessFacade caller，只有注释改变。
4. `setup-project.mjs register`：服务实际 ready 后正常项目/空Chat API。每原成功/失败HTTP保留，不自动重试；完整原fixture写 `before/fixture.json`。
5. `probe.mjs root 1 no-expand`：默认一项有身份尝试；`root 3 expand` 才显式允许最多3个原marker及一次扩大。`child 1 no-expand` 为另一当前directory，仍同实例；同scope admission文件wx拒绝盲重跑。扩大完整receipt是已完成的审计阶段，不是 File index 的新增缓存/协议。
6. `native-rg-observer.mjs`：probe正常import这个唯一实现。纯 `resolveOpenCorvusRuntimePaths` 推导原 `Global.Path.temporary`，不import有初始化副作用的 Global。当前实现固定10ms读取原owned tmp、最多128个请求目录；仅观察原文件。只接实际PATH中的exact rg.exe、当前 --files/--null/--glob=!.git/*/--hidden argv、exact root/child/secondary cwd、CLI nativeTarget的pid/birth/runtime occurrence。保原 request、helper、ready、settled 全字节，不读/冻结stdout/stderr，不注factory/emit，不spawn rg或suspend。ready protocol3，helper/settled protocol1；request没有protocol字段。
7. `shutdown.ps1`：root单独在关本人页面后调用成熟普通shutdown；精确原Host/Target/native output/request/owner/port和parentjoin资格保持。旧脚本的已复制 pair 清理仅在 owned runtime/data 内；本轮从未 staging 此pair，不因观察120秒截止制造terminal或换实例。

## 请求和观察顺序

warm完整200→原bytes/identity及第二Project/child scope对照→Q1真实GET→原ready+helper出生身份→正常tiny POST上传→**POST完整200之后同步dispatch Q2**→并行完整physical/content/list与原Native request存在性采样→Q1/Q2完整结算→Q3。

原响应按准确成员集合评估；Q1前采集允许原数组，Q2须与此前成功发布后的完整集合一致，Q3是fresh正向对照。Q2先 dispatch，任何实体/list/content读取都不能抢在它前面。

原server日志保存全bytes（每文件≤4MiB、最多8代），按实际requestID提取其 started/completed原记录；Q2的server started必须比同identity request仍可读采样更早，才提供disposal仍pending的支持证据。同毫秒不能证明先后。轮询观察较晚remove时间、Target状态、同数组、没有第二条日志均不能独立判复用。

首次mismatch或unknown均wx保存并停止继续尝试；仍尽可能完成本次Q3/实体对照。超时只保 `ObservationInactivityError/OBSERVATION_PENDING`、原partial chunks和最后实际活动，不shutdown/kill/restart、不改Native终态。准确对照exit0仅“本轮未复现”，错误exit1保原错误，缺身份/观察pending exit3不声称通过。脚本没有UI qualification。

## 当前纯语法结果

4个 `.mjs` 和成熟 `native-host.ts` 的 `node --check` 均exit0；`validation/*.syntax-final.log` 和 `.syntax-final.exit.txt` 已保存。PowerShell Parser::ParseFile检查3个 `.ps1` 的errors=[]，没有dot source/Invoke任何脚本，保存 `validation/powershell.syntax.json`。读取Node可执行文件VersionInfo为25.7.0，支持纯util TypeScript模块；module import/路由/Native实际运行仍未验收。精确runRoot的Test-Path在本轮准备结束时为False。

root 执行前还须确认run/port新鲜、当前 source/Native owner边界，以及审查上述脚本。不把语法检查包装API或并发通过。
