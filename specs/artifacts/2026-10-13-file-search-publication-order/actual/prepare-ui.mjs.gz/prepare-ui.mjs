/** Prepared only. Root must review then authorize this new UI qualification run. */
import assert from "node:assert/strict"
import fs from "node:fs/promises"
import path from "node:path"
import { randomUUID } from "node:crypto"
import { execFile } from "node:child_process"
import { promisify } from "node:util"
import { fileURLToPath } from "node:url"

const execute = promisify(execFile)
const scratch = path.dirname(fileURLToPath(import.meta.url))
const evidence = path.join(scratch, "after-ui")
const runRoot = path.resolve("C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/file-search-publication-ui-after-01a133")
const project = path.join(runRoot, "project")
const port = 18452
const at = () => new Date().toISOString()
async function identity(full) {
  const entry = await fs.lstat(full, { bigint: true })
  assert.equal(entry.isSymbolicLink(), false, "This UI fixture has only direct physical entries")
  const result = { full, observedAt: at(), device: String(entry.dev), inode: String(entry.ino), size: Number(entry.size), file: entry.isFile(), directory: entry.isDirectory(), symbolicLink: entry.isSymbolicLink() }
  if (entry.isFile()) result.bytesBase64 = (await fs.readFile(full)).toString("base64")
  return result
}
async function save(name, value) {
  assert.equal(path.basename(name), name)
  await fs.mkdir(evidence, { recursive: true })
  await fs.writeFile(path.join(evidence, name), JSON.stringify(value, null, 2), { flag: "wx" })
}
assert.equal(process.argv[2], "prepare", "Only explicit fresh prepare is supported; there is no prior-instance reuse")
assert.equal(path.resolve(await fs.realpath(path.dirname(runRoot))).toLowerCase(), path.dirname(runRoot).toLowerCase())
const fixture = {
  schema: "file-search-publication-ui.fixture/v1", qualification: "real-desktop-file-search-and-picker-upload",
  fixtureID: randomUUID(), runRoot, port, prefix: "after-ui", project, preparedAt: at(),
  query: "publication-ui-", scopes: {}, files: [],
  productSource: "Current source CLI including root-owned Phase A5; immutable captured83 UI",
  boundary: "Independent UI integration qualification. No concurrent scan workload, old owned receipt, task/model/auth staging or SQL injection; previous B failures remain distinct.",
}
// mkdir without recursive requires one genuinely new exact run; never replace or clean a prior one.
await fs.mkdir(runRoot)
try {
  for (const name of ["runtime", "project", "evidence", "home", "appdata", "localappdata", "temp", "xdg-config", "xdg-data", "xdg-cache", "xdg-state", "inputs"]) await fs.mkdir(path.join(runRoot, name))
  assert.equal(path.resolve(await fs.realpath(runRoot)).toLowerCase(), runRoot.toLowerCase())
  fixture.scopes.root = { directory: project, identity: await identity(project) }
  const git = await execute("git", ["-C", project, "init", "--initial-branch=main"], { windowsHide: true, timeout: 15_000 })
  fixture.git = { directory: project, args: ["init", "--initial-branch=main"], stdout: git.stdout, stderr: git.stderr, at: at() }
  const original = { name: "publication-ui-original.txt", full: path.join(project, "publication-ui-original.txt"), bytes: Buffer.from("UI ORIGINAL 01a133\r\n") }
  const chooser = { name: "publication-ui-uploaded.txt", full: path.join(runRoot, "inputs", "publication-ui-uploaded.txt"), bytes: Buffer.from("UI PICKER 01a133\r\n") }
  assert.ok(chooser.bytes.length >= 16 && chooser.bytes.length <= 64)
  await fs.writeFile(original.full, original.bytes, { flag: "wx" })
  await fs.writeFile(chooser.full, chooser.bytes, { flag: "wx" })
  fixture.original = { name: original.name, ...(await identity(original.full)) }
  fixture.chooser = { name: chooser.name, target: path.join(project, chooser.name), ...(await identity(chooser.full)) }
  assert.equal(fixture.original.bytesBase64, original.bytes.toString("base64"))
  assert.equal(fixture.chooser.bytesBase64, chooser.bytes.toString("base64"))
  fixture.files = [fixture.original, fixture.chooser]
  fixture.completeInputBytes = original.bytes.length + chooser.bytes.length
  fixture.preparationCompletedAt = at()
  await fs.writeFile(path.join(runRoot, "prepared-fixture.json"), JSON.stringify(fixture, null, 2), { flag: "wx" })
  await save("prepared-fixture.json", fixture)
  console.log(JSON.stringify(fixture, null, 2))
} catch (error) {
  await save(`prepare-ui-first-error-${Date.now()}.json`, { fixture, at: at(), error: { name: error.name, code: error.code, message: error.message, stack: error.stack }, boundary: "First preparation error retained; no cleanup/reuse or replacement instance" })
  throw error
}
