/** Prepared only: root must separately authorize prepare/register/expand execution. */
import assert from "node:assert/strict"
import fs from "node:fs/promises"
import path from "node:path"
import { randomUUID } from "node:crypto"
import { execFile } from "node:child_process"
import { promisify } from "node:util"
import { fileURLToPath } from "node:url"
import { runRoot, port, scopes, evidence, queryFor, preparedPath, stamp, save, readJSON, samePath, physical, assertOwnedPhysical, loadPrepared, loadOwner, inactivityBudget, httpClient, serializeError } from "./fixture-support.mjs"

const execute = promisify(execFile)
const MAX_CONTENT_BYTES = 1024 * 1024
async function git(directory, args, records) {
  await assertOwnedPhysical(directory)
  assert.ok([scopes.root, scopes.secondary].includes(directory), "Git is restricted to these two new owned roots")
  const result = await execute("git", ["-C", directory, ...args], { windowsHide: true, timeout: 15_000 })
  records.push({ directory, args, stdout: result.stdout, stderr: result.stderr, at: stamp() })
}

export async function addFillers(fixture, targetCount, directoryCount, progress = () => {}) {
  assert.ok([[3000, 64], [16000, 128]].some(([count, dirs]) => count === targetCount && dirs === directoryCount))
  assert.ok(targetCount >= fixture.fanout.files.length)
  const startedAt = stamp()
  const root = path.join(scopes.child, "fanout")
  await assertOwnedPhysical(root, true)
  await fs.mkdir(root, { recursive: true })
  for (let index = 0; index < directoryCount; index++) await fs.mkdir(path.join(root, `d${String(index).padStart(3, "0")}`), { recursive: true })
  for (let index = fixture.fanout.files.length; index < targetCount; index++) {
    const relative = `fanout/d${String(index % directoryCount).padStart(3, "0")}/f${String(index).padStart(5, "0")}.txt`
    const full = path.join(scopes.child, relative)
    const bytes = index % 2 ? Buffer.from("x") : Buffer.alloc(0)
    await fs.writeFile(full, bytes, { flag: "wx" })
    fixture.fanout.files.push({ relative, ...(await physical(full)) })
    fixture.fanout.contentBytes += bytes.byteLength
    assert.ok(fixture.fanout.contentBytes + fixture.markerContentBytes <= MAX_CONTENT_BYTES)
    if (index % 100 === 0) progress({ actualCompletedFiles: fixture.fanout.files.length, at: stamp() })
  }
  fixture.fanout.fileCount = fixture.fanout.files.length
  fixture.fanout.directoryCount = directoryCount
  fixture.fanout.phases.push({ targetCount, directoryCount, startedAt, completeAt: stamp(), contentBytes: fixture.fanout.contentBytes })
  return fixture
}

async function prepare() {
  const fixture = { schema: "file-search-overlap.fixture/v1", fixtureID: randomUUID(), runRoot, port, preparedAt: stamp(), scopes: {}, markers: [], markerContentBytes: 0, fanout: { files: [], phases: [], contentBytes: 0, expanded: false }, caps: { fileCount: 16000, directoryCount: 128, contentBytes: MAX_CONTENT_BYTES }, git: [] }
  // Parent must already exist and be its direct physical identity; this exact run must be fresh.
  const parent = path.dirname(runRoot)
  assert.equal(path.resolve(await fs.realpath(parent)).toLowerCase(), path.resolve(parent).toLowerCase())
  await fs.mkdir(runRoot)
  try {
    for (const name of ["runtime", "project", "second-project", "evidence", "home", "appdata", "localappdata", "temp", "xdg-config", "xdg-data", "xdg-cache", "xdg-state", "inputs"]) await fs.mkdir(path.join(runRoot, name))
    await fs.mkdir(scopes.child)
    for (const directory of [scopes.root, scopes.secondary]) await git(directory, ["init", "--initial-branch=main"], fixture.git)
    await git(scopes.root, ["config", "core.worktree", scopes.root], fixture.git)
    await fs.writeFile(path.join(scopes.child, ".git"), `gitdir: ${path.join(scopes.root, ".git").replaceAll("\\", "/")}\n`, { flag: "wx" })
    for (const [role, directory] of Object.entries(scopes)) {
      fixture.scopes[role] = { directory, query: queryFor(role), identity: await physical(directory) }
      const name = `${queryFor(role)}original.txt`
      const bytes = Buffer.from(`ORIGINAL ${role.toUpperCase()} 01a133\r\n`, "utf8")
      await fs.writeFile(path.join(directory, name), bytes, { flag: "wx" })
      fixture.markers.push({ role, name, ...(await physical(path.join(directory, name))) })
      fixture.markerContentBytes += bytes.byteLength
    }
    for (const role of ["root", "child"]) {
      const name = `${queryFor(role)}ui.txt`
      const full = path.join(runRoot, "inputs", name)
      const bytes = Buffer.from(`CHOOSER ${role.toUpperCase()} 01a133\r\n`)
      await fs.writeFile(full, bytes, { flag: "wx" })
      fixture.markerContentBytes += bytes.byteLength
      ;(fixture.chooserInputs ??= []).push({ role, name, ...(await physical(full)) })
    }
    await addFillers(fixture, 3000, 64)
    await fs.writeFile(preparedPath, JSON.stringify(fixture, null, 2), { flag: "wx" })
    await save("prepared-fixture.json", fixture)
    console.log(JSON.stringify({ outcome: "prepared", fixtureID: fixture.fixtureID, runRoot, scopes, files: 3000, directories: 64, contentBytes: fixture.fanout.contentBytes + fixture.markerContentBytes }))
  } catch (error) {
    await save(`prepare-failed-${Date.now()}.json`, { fixture, error: serializeError(error), at: stamp(), retained: true })
    throw error
  }
}

async function registerSecondaryFromOriginal() {
  const fixture = await loadPrepared()
  const owner = await loadOwner(fixture)
  const originalFailurePath = path.join(evidence, "register-failed-1791902639271.json")
  const originalFailure = await readJSON(originalFailurePath)
  assert.equal(originalFailure.fixtureID, fixture.fixtureID)
  assert.equal(originalFailure.owner.occurrence, owner.occurrence)
  assert.equal(originalFailure.owner.nativeTarget.processInstanceID, owner.nativeTarget.processInstanceID)
  assert.equal(originalFailure.owner.nativeTarget.occurrenceID, owner.nativeTarget.occurrenceID)
  const root = originalFailure.scopes.root
  assert.equal(samePath(root.directory, scopes.root), true)
  assert.equal(root.project.status, 200)
  assert.equal(root.chat.status, 201)
  assert.equal(root.project.body.id, root.projectID)
  assert.equal(root.chat.body.session.id, root.chatID)
  assert.equal(root.chat.body.session.projectID, root.projectID)
  assert.equal(samePath(root.chat.body.session.directory, scopes.root), true)
  const childFailure = originalFailure.requests.find((record) => record.label === "child-project")
  assert.equal(childFailure.status, 409)
  assert.equal(childFailure.body.name, "NonCanonicalConfigFileError")
  assert.equal(samePath(childFailure.body.data.canonical, path.join(scopes.child, ".opencorvus", "opencorvus.jsonc")), true)
  assert.deepEqual(childFailure.body.data.conflicts.map((value) => path.resolve(value)), [path.join(scopes.root, ".opencorvus", "opencorvus.jsonc")])
  const budget = inactivityBudget()
  const records = []
  const request = httpClient(budget, records)
  const result = {
    fixtureID: fixture.fixtureID, owner, startedAt: stamp(), originalFailurePath,
    rootQualification: "Original actual root200 and emptyChat201 receipts; this repair never recreates that Session or reissues root registration",
    scopes: {
      root,
      child: { directory: scopes.child, outcome: "rejected", project: childFailure, errorType: "NonCanonicalConfigFileError", status: 409 },
    },
    unfulfilledControls: [{ name: "same-Project-current-directory-search", directory: scopes.child, outcome: "not-qualified", reason: "Original public child admission is typed409; no child Chat/search result or actual ProjectID is claimed", originalRequestID: childFailure.requestID }],
    requests: records,
  }
  try {
    const directory = scopes.secondary
    const project = await request("secondary-project", "/project/current", directory)
    assert.equal(project.status, 200, project.rawBody)
    assert.equal(typeof project.body?.id, "string")
    const chat = await request("secondary-empty-chat", "/coding/chat/session", directory, {}, {})
    assert.equal(chat.status, 201, chat.rawBody)
    assert.equal(chat.body.session.projectID, project.body.id)
    assert.equal(samePath(chat.body.session.directory, directory), true)
    result.scopes.secondary = { directory, projectID: project.body.id, chatID: chat.body.session.id, project, chat }
    assert.equal(new Set([result.scopes.secondary.projectID, result.scopes.root.projectID]).size, 2, "Public second Project must have its own actual identity")
    result.completedAt = stamp()
    await save("fixture.json", { ...fixture, owner, registration: result })
    console.log(JSON.stringify({ outcome: "two-real-projects-qualified-original-child409-retained", originalFailurePath, scopes: Object.fromEntries(Object.entries(result.scopes).map(([role, value]) => [role, { directory: value.directory, projectID: value.projectID, chatID: value.chatID, status: value.status }])), unfulfilledControls: result.unfulfilledControls }))
  } catch (error) {
    await save(`register-secondary-failed-${Date.now()}.json`, { ...result, error: serializeError(error), at: stamp(), retained: true })
    throw error
  } finally { budget.close() }
}

export async function expandForProbe(fixture, label, progress) {
  assert.equal(fixture.fanout.expanded, false, "One bounded expansion only")
  await addFillers(fixture, 16000, 128, progress)
  fixture.fanout.expanded = true
  await fs.writeFile(path.join(runRoot, "expansion-receipt.json"), JSON.stringify({ schema: "file-search-overlap.expansion/v1", label, completedAt: stamp(), fixture }, null, 2), { flag: "wx" })
  await save(`expanded-fixture-${label}.json`, fixture)
  return fixture
}

if (process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1])) {
  const mode = process.argv[2]
  assert.ok(["prepare", "register-secondary"].includes(mode), "Expected explicit prepare or register-secondary mode; no original registration retry/recreation")
  await (mode === "prepare" ? prepare() : registerSecondaryFromOriginal())
}
