import fs from 'node:fs'
const root=import.meta.dirname
const tag='permission-config-435-after'
const base='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-19'
const bundle=base+'/'+tag+'-bundle/bin'
if(fs.existsSync(bundle))throw Error('Fresh immutable publication required')
fs.mkdirSync(bundle,{recursive:true})
fs.copyFileSync('.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64/bun.exe',bundle+'/bun.exe')
fs.cpSync('packages/overlay/dist-vite',bundle+'/ui',{recursive:true})
for(const name of ['launch.ps1','settle.ps1','shutdown.ps1']){
 const source=fs.readFileSync('.tmp-product-iteration/home-settings-scope-434/final/'+name,'utf8')
  .replaceAll('home-settings-scope-434-final',tag)
  .replaceAll('.tmp-product-iteration/home-settings-scope-434/final','.tmp-product-iteration/permission-config-435')
  .replaceAll('18633','18635')
 fs.writeFileSync(root+'/'+name,source)
}
const authority=fs.readFileSync('.tmp-product-iteration/home-settings-scope-434/prepare-authority-final.mjs','utf8')
 .replaceAll('home-settings-scope-434-final-authority',tag+'-authority')
 .replaceAll('authority-preparation-final.json','authority-preparation.json')
fs.writeFileSync(root+'/prepare-authority.mjs',authority)
const writer=fs.readFileSync('.tmp-product-iteration/home-settings-scope-434/config-write-check.ts','utf8')
 .replace('assert(phase === "after" || phase === "verified" || phase === "final")','assert(phase === "after")')
 .replace('const port = phase === "after" ? 18629 : phase === "verified" ? 18631 : 18633','const port = 18635')
 .replaceAll('home-settings-scope-434-','permission-config-435-')
 .replaceAll('qa-scope-434','qa-scope-435')
 .replace('`${root}/${phase}/canonical-write-check.json`','`${root}/canonical-write-check.json`')
fs.writeFileSync(root+'/config-write-check.ts',writer)
console.log(JSON.stringify({tag,port:18635,businessInputs:0,publication:'fresh immutable'}))
