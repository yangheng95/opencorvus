import fs from 'node:fs'
import crypto from 'node:crypto'
import path from 'node:path'
const root='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-19/permission-config-435-after-authority'
if(fs.existsSync(root))throw Error('Fresh private authority scope required')
const source='C:/Users/hengu/.codex/auth.json',catalog='C:/Users/hengu/AppData/Local/opencorvus/data/models.json'
const stat=fs.statSync(source),authority=JSON.parse(fs.readFileSync(source,'utf8')),tokens=authority.tokens
if(typeof tokens?.access_token!=='string'||typeof tokens?.refresh_token!=='string')throw Error('Existing Codex OAuth source required')
const claims=JSON.parse(Buffer.from(tokens.access_token.split('.')[1],'base64url').toString('utf8'))
if(!Number.isFinite(claims.exp)||claims.exp*1000<=Date.now())throw Error('Existing copied access must be current; no refresh allowed')
fs.mkdirSync(root,{recursive:true})
// Map the existing user-authorized token fields to the current Auth.Entry contract; no exchange or refresh.
const info={type:'oauth',access:tokens.access_token,refresh:tokens.refresh_token,expires:claims.exp*1000,accountId:tokens.account_id}
fs.writeFileSync(path.join(root,'auth.json'),JSON.stringify({openai:{generation:crypto.randomUUID(),info}}),{flag:'wx',mode:0o600})
fs.copyFileSync(catalog,path.join(root,'models.json'),fs.constants.COPYFILE_EXCL)
const current=fs.statSync(source)
if(current.size!==stat.size||current.mtimeMs!==stat.mtimeMs)throw Error('Source authority changed during the read')
const receipt={source,sourceBytes:stat.size,sourceModifiedAtMs:stat.mtimeMs,catalogSource:catalog,privateAuthority:root,copiedAccessExpiresAt:new Date(claims.exp*1000).toISOString(),operation:'Existing authorized access copied and mapped to current Auth.Entry; complete catalog paired; no token exchange, refresh or source write',observedAt:new Date().toISOString()}
fs.writeFileSync(import.meta.dirname+'/authority-preparation.json',JSON.stringify(receipt,null,2),{flag:'wx'})
console.log(JSON.stringify({scope:'private paired diagnostic authority',access:'current',catalog:'complete adjacent copy',source:'unchanged',refresh:'not performed'}))
