import fs from 'node:fs'
const root=import.meta.dirname,tag='permission-config-435-verified'
const bundle='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-19/'+tag+'-bundle/bin'
if(fs.existsSync(bundle))throw Error('Fresh immutable publication required')
fs.mkdirSync(bundle,{recursive:true})
fs.copyFileSync('.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64/bun.exe',bundle+'/bun.exe')
fs.cpSync('packages/overlay/dist-vite',bundle+'/ui',{recursive:true})
fs.mkdirSync(root+'/verified',{recursive:true})
for(const name of ['launch.ps1','settle.ps1','shutdown.ps1']){
 const source=fs.readFileSync(root+'/'+name,'utf8')
  .replaceAll('permission-config-435-after','permission-config-435-verified')
  .replaceAll('permission-config-435-verified-authority','permission-config-435-after-authority')
  .replaceAll(".tmp-product-iteration/permission-config-435/settle.ps1",".tmp-product-iteration/permission-config-435/verified/settle.ps1")
  .replaceAll('18635','18637')
 fs.writeFileSync(root+'/verified/'+name,source)
}
const writer=fs.readFileSync(root+'/config-write-check.ts','utf8')
 .replace('assert(phase === "after")','assert(phase === "verified")')
 .replace('const port = 18635','const port = 18637')
 .replaceAll('qa-scope-435','qa-scope-435-verified')
 .replace('`${root}/canonical-write-check.json`','`${root}/canonical-write-verified.json`')
fs.writeFileSync(root+'/config-write-verified.ts',writer)
console.log(JSON.stringify({tag,port:18637,businessInputs:0}))
