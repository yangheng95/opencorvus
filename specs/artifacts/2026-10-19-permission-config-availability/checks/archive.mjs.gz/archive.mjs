import fs from 'node:fs'
import path from 'node:path'
import zlib from 'node:zlib'
import assert from 'node:assert/strict'
const root=import.meta.dirname,dest=path.resolve('specs/artifacts/2026-10-19-permission-config-availability')
const read=file=>JSON.parse(fs.readFileSync(file,'utf8'))
const save=(name,bytes)=>{const file=path.join(dest,name);fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,zlib.gzipSync(bytes))}
const provider=[]
for(const phase of ['after','verified']){
 const base=`C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-19/permission-config-435-${phase}/evidence`
 const native=read(base+'/native-host-settled.json'),clean=read(base+'/physical-terminal-and-pair-cleanup.json')
 for(const key of ['physicalCompletion','outputDrainComplete','requestCleanupComplete'])assert.equal(native[key],true)
 assert.equal(clean.pairedCleanupComplete,true);assert.equal(native.terminal.exitCode,0)
 assert.equal(read(base+'/launcher-child-exit.json').childExitCode,0)
 assert.equal(read(base+'/public-shutdown.json').statusCode,200)
 for(const name of ['native-host-ready.json','native-host-settled.json','physical-terminal-and-pair-cleanup.json','launcher-child-exit.json','public-shutdown.json','preflight-ready.json','provider-pair-staging.json'])save(`runtime/${phase}/${name}.gz`,fs.readFileSync(base+'/'+name))
 const audits=fs.readdirSync(base).filter(name=>/^provider-.*\.json$/.test(name)&&name!=='provider-pair-staging.json')
  .map(name=>({name,value:read(base+'/'+name)})).filter(e=>Array.isArray(e.value.requests))
  .sort((a,b)=>b.value.requests.length-a.value.requests.length||Date.parse(b.value.observedAt)-Date.parse(a.value.observedAt))
 const last=audits[0];assert(last)
 const requests=last.value.requests.map(({model,streaming,status,response_reader})=>({model,streaming,status,response_reader}))
 for(const r of requests){assert.equal(r.model,'gpt-6.1-sol');assert.equal(r.streaming,true);assert.equal(r.status,200);assert.equal(r.response_reader.state,'settled');assert.equal(r.response_reader.terminal.kind,'eof')}
 save(`runtime/${phase}/provider-summary.json.gz`,JSON.stringify({source:last.name,observedAt:last.value.observedAt,requests},null,2))
 provider.push({phase,requests:requests.length,readers:requests.map(r=>r.response_reader.terminal.kind)})
}
const prep=read(root+'/authority-preparation.json'),privateRoot=path.resolve(prep.privateAuthority)
assert.equal(privateRoot,path.resolve('C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-19/permission-config-435-after-authority'))
assert.equal(fs.realpathSync(privateRoot).toLowerCase(),privateRoot.toLowerCase())
const retired=[]
for(const name of ['auth.json','models.json']){
 const file=path.resolve(privateRoot,name);assert.equal(path.dirname(file),privateRoot)
 assert.equal(fs.lstatSync(file).isSymbolicLink(),false);fs.unlinkSync(file);retired.push({name,outcome:'retired'})
}
const original=fs.statSync(prep.source)
assert.equal(original.size,prep.sourceBytes);assert.equal(original.mtimeMs,prep.sourceModifiedAtMs)
const receipt={observedAt:new Date().toISOString(),privateAuthority:privateRoot,retired,sourceBytes:original.size,sourceModifiedAtMs:original.mtimeMs,sourceStatMatchesPreparation:true,physicalScopes:2,provider}
fs.writeFileSync(root+'/authority-retired.json',JSON.stringify(receipt,null,2),{flag:'wx'})
for(const name of ['prepare.mjs','prepare-verified.mjs','prepare-authority.mjs','archive.mjs','log-facts.mjs','build-ui.ts','config-write-check.ts','config-write-verified.ts','launch.ps1','settle.ps1','shutdown.ps1','launch.log','verified/launch.ps1','verified/settle.ps1','verified/shutdown.ps1','verified/launch.log','contract-tests.log','typecheck.log','typecheck-final.log','build.log','build-final.log','build-verified.log','format.log','i18n.log','i18n-final.log','docs-check.log','architecture-check.log','canonical-write.log','canonical-write-verified.log','canonical-write-check.json','canonical-write-verified.json','after-request-facts.json','verified-request-facts.json','verified-console.json','authority-preparation.json','authority-retired.json']){
 save('checks/'+name+'.gz',fs.readFileSync(root+'/'+name))
}
// Actual credential values stay in memory; output contains only the audit result.
const source=read(prep.source),secretValues=[source.tokens?.access_token,source.tokens?.refresh_token,source.tokens?.id_token].filter(v=>typeof v==='string'&&v.length>30)
const walk=dir=>fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(dir,e.name)):[path.join(dir,e.name)])
for(const file of walk(dest)){
 const bytes=fs.readFileSync(file),text=file.endsWith('.gz')?zlib.gunzipSync(bytes).toString('utf8'):bytes.toString('utf8')
 for(const secret of secretValues)assert.equal(text.includes(secret),false,'Sensitive value found in selected artifact')
}
console.log(JSON.stringify({pairedAuthority:'retired',sourceStatMatchesPreparation:true,physicalScopes:2,provider,selectedArtifactDisclosureCheck:'passed'}))
