import fs from 'node:fs'
const phase=process.argv[2]
if(!['after','verified'].includes(phase))throw Error('Explicit phase required')
const evidence=`C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-19/permission-config-435-${phase}/evidence`
const read=name=>JSON.parse(fs.readFileSync(evidence+'/'+name,'utf8'))
const ready=read('native-host-ready.json'),end=read('native-host-settled.json').observedAtUtc
const source='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/member-live-rendering-412-fresh/runtime/log/dev.log'
const entries=fs.readFileSync(source,'utf8').split('\n').filter(Boolean).flatMap(line=>{try{return [JSON.parse(line)]}catch{return []}})
 .filter(entry=>Date.parse(entry.time)>=Date.parse(ready.observedAtUtc)&&Date.parse(entry.time)<=Date.parse(end))
const requests=entries.filter(e=>e.service==='server'&&e.message==='request').map(({time,data})=>({time,requestID:data.requestID,method:data.method,path:data.path,status:data.status,statusCode:data.statusCode,duration:data.duration}))
const result={source,occurrence:ready.occurrence,start:ready.observedAtUtc,end,boundary:'Original owned server request lifecycle only; no body or credential; no UI assertion',requests}
fs.writeFileSync(import.meta.dirname+'/'+phase+'-request-facts.json',JSON.stringify(result,null,2),{flag:'wx'})
console.log(JSON.stringify({phase,requestEvents:requests.length,configWrites:requests.filter(r=>r.method==='PATCH'&&r.path==='/global/config'&&r.status==='completed')}))
