import fs from 'node:fs';
const root='.tmp-design-dialog-close-locale-401';
const target=root+'/observations/final-review.json';
if(fs.existsSync(target))throw Error('Keep the original manual review timestamp');
const observationFiles=fs.readdirSync(root+'/observations').sort();
const review={iteration:401,reviewedAt:new Date().toISOString(),kind:'Root manual CUA desktop interaction and original JPEG review, not UI automation',
  runtime:'Original 387 canonical workbook runtime reused after paired credential cleanup; no fresh DB or new model publication',
  identity:{sessionID:'ses_h0VKkCl7hbz3BKHVW2Xp',artifactID:'art_g0VXv65e1004ErsrwSJs',title:'Desk budget',originalSheet:'清单'},
  before:{tab:'42',nativePID:82420,launcher:38715,exitCode:0,closeAt:'2026-10-13T17:17:31.408Z',startedAt:1791911595142,deadlineAt:1791912795142,closeBy:1791912735142,
    observed:'Chinese normal and fullscreen Range/Delete dialogs named Close; mouse, Enter and Space closed; own empty 工作表1 actually deleted; original English/System/100% restored'},
  after:{tab:'43',nativePID:88800,launcher:50144,exitCode:0,closeAt:'2026-10-13T17:30:39.897Z',startedAt:1791912281003,deadlineAt:1791913481003,closeBy:1791913421003,
    range:'English/Chinese normal and fullscreen names Close/关闭; one open radix-_r_8_ dialog and title _r_9_ retained A1:B2 through actual EN→ZH settings and fullscreen transitions; Chinese Enter closed; form Cancel discarded the unconfirmed draft',
    deletion:'English/Chinese normal and fullscreen names Close/关闭; Chinese fullscreen mouse and normal Space, English normal Enter and fullscreen mouse closed while preserving own 工作表1; actual Delete+OK cleaned it afterwards',
    restored:'Original 清单 selected, visible 7/5/12; English/System/100%; artifact returned to ordinary view before tab close'},
  independentDeliveryReview:'Root read four runtime ConfigContext/ConfigProvider/DialogContent implementations and UMD React/children binding; complete default comes from published en-US resource; no new Host locale source. Typecheck and private build exited 0.',
  failures:[{kind:'Capture file helper',fact:'First writeFileSync call on fs/promises failed after capture; original retained JPEG was then saved with writeFile and manually viewed'},
    {kind:'Read-only source review helper',fact:'Initial TypeScript require had an incorrect two-level relative path; corrected to the actual one-level path and original read completed'},
    {kind:'Dependency preparation',fact:'First PATH-selected Bun1.3.14 prepare exited0 without changing source/package/lock; repeated approved prepare/commit/frozen install with Bun1.4.0, original log retained'}],
  limits:['Actual product languages en-US/zh-CN; other17 resources and CJS/root/UMD are delivery/code review, not all-format browser qualification',
    'No independent consumer without locale, raw manually-created Context.Provider, Mobile, Docs or unregistered plugin page was presented',
    'Only representative Range/Delete dialogs; no claim for every installed service consumer, 399 focus return or 400 Escape hierarchy',
    'Original cell values were visible; no cell edit, formula recalculation, CSV export or model republishing in this batch',
    'AX files may be diff snippets; screenshots are original JPEG without editing; no UI automated tests or screenshot baseline assertions'],
  observations:observationFiles.map(name=>({file:name,bytes:fs.statSync(root+'/observations/'+name).size,savedAt:fs.statSync(root+'/observations/'+name).mtime.toISOString(),kind:name.endsWith('.jpg')?'Root manually viewed original JPEG':'Original AX output or scope observation'}))};
fs.writeFileSync(target,JSON.stringify(review,null,2)+'\n');
console.log(JSON.stringify({reviewedAt:review.reviewedAt,observations:observationFiles.length,jpeg:observationFiles.filter(x=>x.endsWith('.jpg')).length}));
