import fs from 'node:fs';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url);
const ts=require('../node_modules/typescript');
const root='node_modules/@univerjs/design';
for(const format of ['','es/','cjs/','umd/']){
 const file=root+'/lib/'+format+'index.js',source=fs.readFileSync(file,'utf8');
 const tree=ts.createSourceFile(file,source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
 const names=new Set(format==='umd/'?['G','Rt','va']:['ConfigContext','ConfigProvider','DialogContent']);
 const shown=new Set();
 function walk(n){
  if((ts.isVariableDeclaration(n)||ts.isFunctionDeclaration(n))&&n.name&&names.has(n.name.getText(tree))&&!shown.has(n.name.getText(tree))){
   shown.add(n.name.getText(tree));console.log(JSON.stringify({file,definition:n.name.getText(tree),source:n.getText(tree).slice(0,3600)}));
  }
  ts.forEachChild(n,walk);
 }
 walk(tree);
}
for(const name of ['installed-review','preparation-review','apply-result']){
 const value=JSON.parse(fs.readFileSync('.tmp-design-dialog-close-locale-401/'+name+'.json','utf8'));
 console.log(JSON.stringify({review:name,keys:Object.keys(value),actual:value.actual,actualEntry:value.actualEntry,fileCount:value.files?.length,summary:value.summary}));
}

