import fs from 'node:fs';
import path from 'node:path';
import ts from '../node_modules/typescript/lib/typescript.js';
const scratch=path.resolve('.tmp-design-dialog-close-locale-401');
const plan=JSON.parse(fs.readFileSync(path.join(scratch,'vendor-files.json'),'utf8'));
const result={mode:'Read-only scope/AST binding review of scratch preview; not UI acceptance.',actualEntry:plan.actualEntry,runtimes:[],counts:{runtime:0,locale:0,type:0},sourceIdentity:{workCopyMatchesSaved:true,presetMatchesSaved:true},patchState:{},sameLocaleResourceConsumerNotes:[],previewScope:[]};
function nodes(node,predicate){const found=[];const visit=n=>{if(predicate(n))found.push(n);ts.forEachChild(n,visit);};visit(node);return found;}
for(const item of plan.files){
 const before=fs.readFileSync(path.join(scratch,'vendor-before',item.file));
 const work=fs.readFileSync(item.target);
 const consumer=fs.readFileSync(path.join(plan.actual,item.file));
 result.sourceIdentity.workCopyMatchesSaved&&=before.equals(work);
 result.sourceIdentity.presetMatchesSaved&&=before.equals(consumer);
 result.counts[item.details.kind]++;
 result.previewScope.push({file:item.file,kind:item.details.kind,editCount:item.edits.length,edits:item.edits.map(edit=>({purpose:edit.purpose,start:edit.start,end:edit.end,oldBytes:Buffer.byteLength(edit.before),newBytes:Buffer.byteLength(edit.after)}))});
 if(item.details.kind!=='runtime')continue;
 const text=fs.readFileSync(path.join(scratch,'vendor-planned',item.file),'utf8');
 const source=ts.createSourceFile(item.file,text,99,true,1);
 const declarations=nodes(source,node=>(ts.isVariableDeclaration(node)&&['defaultDesignLocale',item.details.contextName,item.details.contentName].includes(node.name?.text))||(ts.isFunctionDeclaration(node)&&['projectDesignLocale',item.details.providerName].includes(node.name?.text)));
 const content=declarations.find(node=>node.name?.text===item.details.contentName);
 const refs=nodes(content,node=>ts.isIdentifier(node)&&['t','dialogChildren','dialogLocale'].includes(node.text));
 result.runtimes.push({file:item.file,declarations:declarations.map(node=>({name:node.name.text,code:node.getText(source)})),bindingReferences:refs.map(node=>({name:node.text,parent:node.parent.getText(source).slice(0,200)})),parseDiagnostics:source.parseDiagnostics.length});
}
const patch=fs.readFileSync('patches/@univerjs%2Fdesign@0.25.1.patch');
result.patchState={unchangedSincePrepare:patch.equals(fs.readFileSync(path.join(scratch,'design.patch-before'))),headers:patch.toString().split('\n').filter(line=>line.startsWith('diff --git '))};
result.sameLocaleResourceConsumerNotes=['ESM/root import the same adjacent existing en-US locale module.','CJS require reads its actual direct module.exports object.','UMD has one defaultDesignLocale object generated from that same planned English resource; factory dependencies are unchanged.','Projection happens within original ConfigProvider useMemo; raw Context Provider bypass is outside the approved config entry.'];
fs.writeFileSync(path.join(scratch,'preparation-review.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({counts:result.counts,sourceIdentity:result.sourceIdentity,patchState:result.patchState,runtimes:result.runtimes.map(item=>({file:item.file,parseDiagnostics:item.parseDiagnostics,names:item.declarations.map(item=>item.name),bindings:item.bindingReferences}))},null,2));
