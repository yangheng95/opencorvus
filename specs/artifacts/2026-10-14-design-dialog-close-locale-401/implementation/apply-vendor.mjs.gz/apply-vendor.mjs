import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';

// Prepared for execution only after root explicitly authorizes implementation following real before-state review.
const scratch=path.resolve('.tmp-design-dialog-close-locale-401');
const plan=JSON.parse(fs.readFileSync(path.join(scratch,'vendor-files.json'),'utf8'));
const target=path.resolve('node_modules/@univerjs/design');
const preset=createRequire(fs.realpathSync('packages/overlay/node_modules/@univerjs/preset-sheets-core/package.json'));
const actual=path.dirname(path.dirname(path.dirname(preset.resolve('@univerjs/design'))));
if(plan.files.length!==81)throw Error('Unexpected approved publication scope.');
const patch=fs.readFileSync('patches/@univerjs%2Fdesign@0.25.1.patch');
if(!patch.equals(fs.readFileSync(path.join(scratch,'design.patch-before'))))throw Error('Tracked Design patch changed since preparation; review it before applying.');
const changes=plan.files.map(item=>{
 const destination=path.resolve(target,item.file);
 if(!destination.startsWith(target+path.sep))throw Error('Vendor path escaped the authorized package.');
 const before=fs.readFileSync(path.join(scratch,'vendor-before',item.file));
 if(!before.equals(fs.readFileSync(destination)))throw Error(`Work copy changed since preparation: ${item.file}`);
 if(!before.equals(fs.readFileSync(path.join(actual,item.file))))throw Error(`Preset consumer changed since preparation: ${item.file}`);
 const next=fs.readFileSync(path.join(scratch,'vendor-planned',item.file));
 return{file:item.file,destination,next};
});
for(const item of changes)fs.writeFileSync(item.destination,item.next);
const report={appliedAt:new Date().toISOString(),files:changes.map(item=>item.file),fileCount:changes.length,actualConsumerBeforeApply:actual,note:'Applied reviewed bounded vendor changes only. Bun patch commit/install, independent review, build and real desktop UI acceptance remain root-owned.'};
fs.writeFileSync(path.join(scratch,'apply-result.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({fileCount:changes.length,patchWritten:false,installRun:false},null,2));
