import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { execFileSync } from 'node:child_process';
import ts from '../node_modules/typescript/lib/typescript.js';

// Offline, bounded patch preparation only. This script never writes node_modules or a tracked patch.
const cwd=process.cwd();
const scratch=path.resolve('.tmp-design-dialog-close-locale-401');
const target=path.resolve('node_modules/@univerjs/design');
const presetPath=fs.realpathSync('packages/overlay/node_modules/@univerjs/preset-sheets-core/package.json');
const presetRequire=createRequire(presetPath);
const actualEntry=presetRequire.resolve('@univerjs/design');
const actual=path.dirname(path.dirname(path.dirname(actualEntry)));
const runtimeFiles=['lib/index.js','lib/es/index.js','lib/cjs/index.js','lib/umd/index.js'];
const localeDirs=['lib/locale','lib/es/locale','lib/cjs/locale','lib/umd/locale'];
const ownRequire=createRequire(import.meta.url);
const localeInventory=JSON.parse(fs.readFileSync(path.join(scratch,'locale-audit.json'),'utf8'));
const translations=Object.fromEntries(localeInventory.closeResources.filter(row=>row.pkg==='sheets-ui'&&row.key==='sheets-ui.button.close').map(row=>[row.locale,row.value]));
const languages=Object.keys(translations).sort();
if(languages.length!==19)throw Error('Preparation requires the reviewed 19 existing close translations.');
const originalEnglish=ownRequire(path.join(actual,'lib/cjs/locale/en-US.js'));
const defaultDesign={Dialog:{close:translations['en-US']},...originalEnglish.design};
const plans=[];

function all(node,predicate){const found=[];function visit(n){if(predicate(n))found.push(n);ts.forEachChild(n,visit);}visit(node);return found;}
function one(nodes,label){if(nodes.length!==1)throw Error(`${label}: expected one scoped syntax node, got ${nodes.length}`);return nodes[0];}
function propName(node){return node.name?.text;}
function parse(file,text){const source=ts.createSourceFile(file,text,ts.ScriptTarget.Latest,true,file.endsWith('.d.ts')?ts.ScriptKind.TS:ts.ScriptKind.JS);if(source.parseDiagnostics.length)throw Error(`Source parse failed: ${file}`);return source;}
function edit(start,end,before,after,purpose){return{start,end,before,after,purpose};}
function applyEdits(text,edits){let end=text.length,next=text;for(const item of [...edits].sort((a,b)=>b.start-a.start||b.end-a.end)){if(item.end>end||text.slice(item.start,item.end)!==item.before)throw Error(`Overlapping or stale bounded edit: ${item.purpose}`);next=next.slice(0,item.start)+item.after+next.slice(item.end);end=item.start;}return next;}
function load(file){const original=fs.readFileSync(path.join(target,file),'utf8');const consumer=fs.readFileSync(path.join(actual,file),'utf8');if(original!==consumer)throw Error(`Patch work copy differs from current preset consumer: ${file}`);return{original,source:parse(file,original)};}
function finish(file,original,edits,details){const next=applyEdits(original,edits);parse(file,next);plans.push({file,target:path.join(target,file),original,next,edits,details});}
function replacement(node,source,text,after,purpose){return edit(node.getStart(source),node.end,text.slice(node.getStart(source),node.end),after,purpose);}

for(const directory of localeDirs){
 for(const language of languages){
  const file=`${directory}/${language}.js`;
  const {original,source}=load(file);
  const design=one(all(source,node=>ts.isPropertyAssignment(node)&&propName(node)==='design'&&ts.isObjectLiteralExpression(node.initializer)),`${file} design resource`);
  const object=design.initializer;
  if(object.properties.some(node=>propName(node)==='Dialog'))throw Error(`Design Dialog resource already exists: ${file}`);
  const position=object.getStart(source)+1;
  const newProperty=(directory==='lib/umd/locale'?'':'\n\t')+`Dialog: { close: ${JSON.stringify(translations[language])} },`;
  finish(file,original,[edit(position,position,'',newProperty,'Add reviewed close resource to existing design locale')],{kind:'locale',language,close:translations[language]});
 }
}

for(const file of runtimeFiles){
 const {original,source}=load(file);
 const umd=file==='lib/umd/index.js',cjs=file==='lib/cjs/index.js';
 const contextName=umd?'G':'ConfigContext';
 const providerName=umd?'Rt':'ConfigProvider';
 const contentName=umd?'va':'DialogContent';
 for(const fresh of ['designEnUS','defaultDesignLocale','projectDesignLocale','dialogLocale','dialogChildren']){
  if(all(source,node=>ts.isIdentifier(node)&&node.text===fresh).length)throw Error(`Fresh binding is occupied: ${file} ${fresh}`);
 }
 const context=one(all(source,node=>ts.isVariableDeclaration(node)&&node.name.text===contextName),`${file} context`);
 const contextObject=one(all(context.initializer,node=>ts.isObjectLiteralExpression(node)),`${file} context default`);
 let contextStatement=context;while(contextStatement&&!ts.isVariableStatement(contextStatement))contextStatement=contextStatement.parent;
 if(!contextStatement)throw Error(`${file} context statement not found`);
 const helper=`function projectDesignLocale(locale) {\n\tconst configured = locale ?? defaultDesignLocale;\n\treturn { ...configured, Dialog: { ...configured.Dialog, close: configured.Dialog?.close ?? defaultDesignLocale.Dialog.close } };\n}\n`;
 const declaration=umd?`const defaultDesignLocale=${JSON.stringify(defaultDesign)};\n`:'const defaultDesignLocale = designEnUS.design;\n';
 const edits=[edit(contextStatement.getStart(source),contextStatement.getStart(source),'',declaration+helper,'Use the single existing English resource and config projection')];
 if(!umd)edits.push(edit(0,0,'',cjs?'const designEnUS = require("./locale/en-US.js");\n':'import designEnUS from "./locale/en-US.js";\n','Import existing English locale; CJS directly exports its object'));
 const objectStart=contextObject.getStart(source)+1;
 edits.push(edit(objectStart,objectStart,'',umd?'locale:defaultDesignLocale,':' locale: defaultDesignLocale,','Complete default locale for use without a provider'));
 const provider=one(all(source,node=>ts.isFunctionDeclaration(node)&&node.name?.text===providerName),`${file} provider`);
 const localeProperty=one(all(provider,node=>(ts.isPropertyAssignment(node)||ts.isShorthandPropertyAssignment(node))&&propName(node)==='locale'),`${file} memo locale projection`);
 const localeInput=ts.isShorthandPropertyAssignment(localeProperty)?'locale':localeProperty.initializer.getText(source);
 edits.push(replacement(localeProperty,source,original,`locale: projectDesignLocale(${localeInput})`,'Normalize only locale/default Dialog in the original ConfigProvider memo'));
 const content=one(all(source,node=>ts.isVariableDeclaration(node)&&node.name.text===contentName),`${file} content`);
 const arrow=one(all(content.initializer,node=>ts.isArrowFunction(node)),`${file} forwardRef callback`);
 if(ts.isBlock(arrow.body))throw Error(`${file} unexpected pre-existing callback body`);
 const body=arrow.body;
 const bodyStart=body.pos;
 const bodyEdits=[];
 const closeProperty=one(all(body,node=>ts.isPropertyAssignment(node)&&propName(node)==='children'&&ts.isStringLiteralLike(node.initializer)&&node.initializer.text==='Close'),`${file} original sr-only close`);
 bodyEdits.push(replacement(closeProperty.initializer,source,original,'dialogLocale.Dialog.close','Consume the projected locale field at the shared Close span'));
 if(umd){
  const children=one(all(arrow.parameters[0],node=>ts.isBindingElement(node)&&node.propertyName?.text==='children'&&node.name.text==='t'),`${file} children binding`);
  edits.push(replacement(children.name,source,original,'dialogChildren','Preserve outer t React namespace by renaming the children binding'));
  const childrenUse=one(all(body,node=>ts.isIdentifier(node)&&node.text==='t'),`${file} bound children reference`);
  if(!ts.isArrayLiteralExpression(childrenUse.parent))throw Error('Unexpected UMD children reference position');
  bodyEdits.push(replacement(childrenUse,source,original,'dialogChildren','Rename the matching bound child reference only'));
 }
 const expression=applyEdits(original.slice(bodyStart,body.end),bodyEdits.map(item=>({...item,start:item.start-bodyStart,end:item.end-bodyStart})));
 const contextCall=umd?'(0,t.useContext)(G)':cjs?'(0, react.useContext)(ConfigContext)':'useContext(ConfigContext)';
 const callback=` { const { locale: dialogLocale } = ${contextCall}; return ${expression.trimStart()}; }`;
 edits.push(edit(bodyStart,body.end,original.slice(bodyStart,body.end),callback,'Unconditional hook at the original forwardRef callback; preserve its rendered expression'));
 finish(file,original,edits,{kind:'runtime',contextName,providerName,contentName,englishResource:umd?'One inline object generated from updated en-US design resource':'./locale/en-US.js',hook:contextCall,bodyEdits,umdChildrenBinding:umd?'children:t -> children:dialogChildren; one matching array reference':null});
}

{
 const file='lib/types/locale/en-US.d.ts';
 const {original,source}=load(file);
 const design=one(all(source,node=>ts.isPropertySignature(node)&&node.name.text==='design'&&ts.isTypeLiteralNode(node.type)),`${file} design type`);
 if(design.type.members.some(node=>node.name?.text==='Dialog'))throw Error('Locale type already includes Dialog');
 const start=design.type.getStart(source)+1;
 finish(file,original,[edit(start,start,'','\n        Dialog: { close: string; };','Declare the required resource field completed in all 19 locales')],{kind:'type',aliasConsumers:18});
}

if(plans.length!==81)throw Error('Unexpected publication scope count.');
const writeNew=(file,content)=>{fs.mkdirSync(path.dirname(file),{recursive:true});if(fs.existsSync(file)){if(!fs.readFileSync(file).equals(Buffer.from(content)))throw Error(`Existing immutable snapshot differs: ${file}`);return;}fs.writeFileSync(file,content,{flag:'wx'});};
const writePreview=(file,content)=>{fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,content);};
for(const plan of plans){writeNew(path.join(scratch,'vendor-before',plan.file),plan.original);writePreview(path.join(scratch,'vendor-planned',plan.file),plan.next);}
writeNew(path.join(scratch,'design.patch-before'),fs.readFileSync('patches/@univerjs%2Fdesign@0.25.1.patch'));
writeNew(path.join(scratch,'design.patch-worktree-before.diff'),execFileSync('git',['diff','--','patches/@univerjs%2Fdesign@0.25.1.patch']));
writeNew(path.join(scratch,'design.patch-index-before.diff'),execFileSync('git',['diff','--cached','--','patches/@univerjs%2Fdesign@0.25.1.patch']));
writePreview(path.join(scratch,'vendor-files.json'),JSON.stringify({mode:'scratch preview only',presetPath,actualEntry,actual,target,files:plans.map(({file,target,edits,details})=>({file,target,edits,details})),note:'AST-bounded patch preparation and parse checks, not UI tests or functional acceptance. Production and patch files are unchanged.'},null,2)+'\n');
console.log(JSON.stringify({mode:'scratch preview only',fileCount:plans.length,localeCount:languages.length,actualEntry,productionWrites:0,patchWrites:0},null,2));
