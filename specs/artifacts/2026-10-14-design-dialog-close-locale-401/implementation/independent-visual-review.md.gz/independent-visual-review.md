# 401 独立人工读图

audit_ui 按 Root 要求使用 `view_image` 实际打开原始 JPEG；没有启动页面、使用自动化测试、编辑像素或计算截图差异。此次只写本 scratch 意见，未修改产品、spec 或共享文档。

实际查看后态：

- `observations/after-zh-same-open-range-settings.jpg`
- `observations/after-zh-range-fullscreen-draft.jpg`（另以 original detail 复看）
- `observations/after-zh-delete-fullscreen.jpg`

实际查看对应前态：

- `observations/before-zh-range-normal.jpg`
- `observations/before-zh-range-fullscreen.jpg`
- `observations/before-zh-delete-fullscreen.jpg`

## 可见结论

1. Settings 后态图中“选择一个数据范围”Dialog 完整浮在中文外观设置页面上；标题、右上角关闭叉号、A1:B2 输入框、添加范围、取消/确认均可辨识，没有看到裁断、重叠遮挡或文字挤出。设置语言值可见“简体中文”。这张图证明当时 Dialog 及其草稿可见；单张截图不能独立证明它与切换前是同一个 DOM 实例。
2. 全屏范围后态图中，Dialog、输入 A1:B2 和底部动作保持完整，右上角关闭叉号清楚可见。右侧权限面板、底部工作表标签与100%缩放也在画面内。与前态相同组件相比，没有看到新增布局或控件异常；前态输入是A1，后态是Root主动输入的A1:B2，不能把数据差异称为回归。两张图视口尺寸不同，因此没有做位置/尺寸一致性或像素级结论。
3. 全屏删除后态图中，遮罩、居中的“删除工作表”Dialog、关闭叉号、正文、取消与确定均完整可见。人工看对应前态，组件层级和可见排列一致，没有发现本次改名造成的溢出、缺控件或全屏弹层丢失。正文颜色本来较浅灰；本轮没有做对比度测量或宣称 WCAG 合规。

## 名称证据及严格边界

屏幕阅读文本是 sr-only，不能从截图看见“Close→关闭”。为区分视觉与名称证据，另外只读了 `after-zh-range-fullscreen-draft.ax.txt`：其Dialog `_r_8_`、标题 `_r_9_`、输入A1:B2与“button 关闭”被明确列出。相同挂载实例 EN→ZH、点击/Enter/Space关闭、临时工作表实际删除、语言/主题/缩放恢复及两个Native正常收尾的行为结论来自Root真实操作与 `final-review.json`；本独立复核没有重新执行这些动作。

当前独立读图结论限于上述六张原图与一个辅助AX片段：未见401目标Dialog的明显新增视觉缺陷。没有逐一打开全部16图，也没有验收其他17语言、无locale独立使用、裸Context.Provider、其他发布格式浏览器、全部服务消费者、Mobile、Docs、399焦点返回或400 Escape层级。没有重验单元格编辑、公式、CSV或模型发布。37个观察文件/16 JPEG及全批行为通过仍是Root的原验收范围，不能扩为本agent独立重跑全部项目。
