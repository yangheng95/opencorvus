# Root cause and complete current Handle contract

## Recall and evidence boundary

User requires continuing parallel product batches: analyze depth and impact, write the formal spec, implement supported root fixes, enter real desktop pages and focused positive functional checks, then scoped commit/upstream merge/push. The current child assignment is read-only analysis and new owned scratch only. No implementation, tests, User Interface automation, Provider call, credentials, process launch/shutdown, staging, commit or further delegation is authorized here.

Read the Native root Recall; original failed and v1/v2 facts; prior runtime-matrix and settlement-boundary reports; current and `83ee0d843` Facade/Supervisor/Node adapters; generic Process types/controls/run/errors; all Supervisor spawn/factory definitions and all repository TypeScript Handle consumers; all corresponding non-UI test factories; normal test runner/preload; current server-runtime-readiness and Task-control/runtime architecture; optional-field introduction history; Task Capsule binding/wrapper/OCI (Open Container Initiative) file lifecycle and existing Linux checkers. Search results and sources below are the reviewable evidence. Static reads that guessed nonexistent document paths returned path errors; those are lookup mistakes, not product or checker failures. No such result is counted as validation.

## Confirmed current failure and old unknown

Original Explorer before-failed launcher dot-source overwrote the requested port with 0 and actual Target bound 7878 instead of 18439; the parent exited. That launcher bug is proven. The later Host AggregateError at whole-job-output-request-settlement omitted nested causes and raw/native request facts. Neither its label nor later ordinary/deadline success identifies its cause or proves complete request cleanup.

New close-reader v2 has an independently bound occurrence: experiment `6b4e0ab5-9513-4091-a797-37c4ac72cf0f`, Host PID (Process Identifier) 81060/birth `win32:639274940018663884`, Target 13496/birth `win32:639274940031306768`, request `ca047e46-c804-404b-9f6c-907720ac13c6`. Controller only destroyed its own Host.stdout reader. One real shutdown returned 200; Target exited 0. Host write returned false, then the original drain wait rejected EPIPE. Async iterator unwinding produced source ABORT_ERR, wrapped as original Error ref14. It was not a synchronous write throw.

The original journal at `C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/native-sink-reader-01a133-v2/evidence/host-events.jsonl` gives:

| Original event | Sequence | UTC time | Actual fact |
| --- | --- | --- | --- |
| Facade output rejected | 26 | 13:13:23.619 | Promise ID5, Error ref14; aliases original raw output |
| Raw physical exited | 27 | .621 | fulfilled 0 |
| Raw terminalFact | 29 | .622 | fulfilled original normalized exit fact |
| Facade terminal | 30 | .623 | fulfilled exited/0 |
| Public Facade settled | 31 | .624 | rejected ref14 |
| Native external wholeAllSettled | 32 | .624 | fulfilled collector; its members include failures |
| Host error | 33 | .626 | AggregateError with ref14 and external EPIPE ref13 |
| Original raw Supervisor settled | 34 | .629 | rejected same ref14, after actual request cleanup |
| Request directory observation | 35 | .630 | absent, ENOENT |
| Registry retirement observation | 36 | .647 | retired, remaining count 0 |

Baseline v2 was a distinct bound Host/Target occurrence with original raw/public/native/parent branches fulfilled, complete 65,536-byte stdout/61-byte stderr, normal terminal/Host/controller exit 0, actual active-zero marker, request ENOENT and owner retirement. Fault Host/controller exit 1, Target exit 0, Native stderr and parent stderr fulfilled, parent stdout ERR_STREAM_PREMATURE_CLOSE/0 bytes; both independent post-run physical observers exited 0 and named the original births dead_or_reused. All are preserved in the preceding artifact. Neither baseline nor subsequent normal shutdown excludes external sink faults. Scratch finally observed metrics for up to one second, providing this Host about 20 ms extra lifetime; it cannot prove an immediate-exit production-style caller would have waited.

## Direct shared root and why prior paths missed it

`packages/opencorvus/src/util/process-facade.ts:69–74` is one shared Host/Task spawner. Authority differs only at spawnTaskCommand/spawnHostCommand; thereafter the adapter builds public settled with `Promise.all([terminal, outputSettled, supervisorSettled])`. Any rejection ends this adapter Promise before other original members finish. The v2 output rejection took exactly that path.

Raw Windows `process-supervisor.ts:1940–1951` instead allSettled-collects physical and output, conditionally joins its unique request cleanup only with fulfilled physical proof and non-detached ownership, then combines final failures. The adapter's early rejection can precede request cleanup and can omit a later cleanup error. v2 proves the early order with successful cleanup; it did not induce a cleanup Input/Output error, so that cause-omission branch is code evidence, not a claimed real reproduction.

Generic `packages/util/src/process.ts:390–410` already uses allSettled for adapter output/settled and recursively combines errors. Its `raw.settled` is the prematurely rejected adapter Promise, not the original Supervisor Promise; its correct collector cannot reconstruct a reference it was never given. Normal success waits every adapter member and hid the bug. `runProcess` finally at 650 and explicit adapter terminate/dispose at 102/106 join strict Supervisor cleanup, so those stronger owners also reduce the exposure of a spawn-only caller. They do not repair the exposed public settled contract.

Task lease and registry retirement still use the original tracked Handle through Supervisor 224–226, 349–351/403–405/452–454 and 1217–1219. They do not retire solely on the early public rejection. Unknown physical proof keeps ownership/lease; no counter-based fake unregister is proposed. Request cleanup failure remains an error even after the physical owner can lawfully retire. The generic shared 5000 ms settlement budget can still report uncertainty before a genuinely pending original operation settles; a typed uncertainty error is not proof of complete cleanup. Keep that bounded contract and original pending facts explicit.

## Existing error combination; minimal adapter repair

Use existing `ProcessSupervisor.combineFailures` on the already lazy-imported concrete Supervisor. It expands one AggregateError level, preserves insertion order, deduplicates original references through Set, returns the original sole reason, and produces an AggregateError only for multiple distinct reasons. A rejected `undefined` is a legitimate reason; collect by status, never by truthiness.

Generic util's private uniqueFailures/combinedFailure at 263–281 recursively expands nested AggregateError graphs and deduplicates leaf references. Differences are real: Supervisor flattens one level and supplies a new Error for zero reasons; generic util recursively flattens and supplies an empty AggregateError for zero. Messages and argument order also differ. The adapter only calls combineFailures for a nonempty rejected result set. Current raw Supervisor physical/output/request aggregates use the existing one-level shape; generic public settlement retains its existing recursive final layer. Do not export/copy a new collector or broaden this batch into unrelated aggregation rewrites. Supervisor rethrowWithCleanup preserves primary+cleanup phase order and is not a second settlement fact source.

Minimal product change at the shared adapter is allSettled over the existing original terminal/output/Handle.settled references, collect every rejected reason in that stable member order through combineFailures, and project the original fulfilled terminal receipt only after collection. No replacement raw Promise, extra state cache, timer, gate, forced unregister, stream-error swallowing, route or coordinator is needed. Original Handle.settled remains the sole authority for physical/output/request closure; independently projected terminal/output are observable branches, not fallback replacement authorities. Keeping these already exposed branches also retains their explicit error contract.

Parent root selected all three current Handle fields required: terminalFact, outputSettled and settled. Remove every corresponding consumer fallback in the same cut; old factories must implement the current contract. Windows terminalFact keeps its existing validated exitCode and signal:null, not a new OS (Operating System) signal probe.

## Exact producers and public entry points

There are two physical Handle constructors and three propagation wrappers, all supplying all three fields:

| Producer / wrapper | Current source | terminalFact / output / authoritative settlement |
| --- | --- | --- |
| childHandle | Supervisor 1997, return 2067–2083 | actual Node exit(code,signal) at 2006; child close at 2019; existing joinPhysicalAndOutputSettlement at 2027 |
| Windows native request | 1589, return 1957–1994 | validated exited→{exitCode,signal:null} at 1954; helper close plus source output failures at 1857; physical/output/request allSettled at 1940 |
| tracked ownership wrapper | return 1184–1207 | original three references forwarded; optional-settled fallback is unnecessary |
| Task Capsule wrapper | return 533–549 | spreads the real base three fields; separate process-file defect is in capsule-boundary-audit.md |
| POSIX detached ownership wrapper | return 1147–1158 | spreads initialized child three fields; transfer contract retained |

initializedChildHandle 1503–1509 admits childHandle, Unix shell/command 1512/1527 use it, Windows shell/command 1542/1560 use the native constructor, defaultSpawnShell/defaultSpawnCommand 1120/1125 select those actual implementations. Six public spawn entry points—Task Shell 325, Host Shell 360, Task Gated Shell 364, Host Gated Shell 414, Task Command 422, Host Command 463—return these tracked handles. awaitSpawnAdmission preserves actual handles and strictly cleans a late admitted Handle; it currently misses late Capsule wrapping files, separately analyzed.

The ForTest factories at 1006/1014 are the only replacement factory setters found by whole-repository tracked/default-ignored source search. All production calls use the above constructors; no actual production missing-field backend was found. External consumers of package wildcard exports cannot be exhaustively observed from this repository, but no runtime compatibility branch is justified by that unknown.

## Exact fallback removal scope

Five product files contain 13 same-contract fallback uses: output 8, settled 4, terminalFact 1. Another optional output catch is in one affected test. Keep the live joinPhysicalAndOutputSettlement constructor primitive; delete only its optional-output bypass and its uses as a missing-settled substitute.

| Product file | Lines / changes needed |
| --- | --- |
| src/util/process-facade.ts | 18 terminalFact??exited; 72 output??exited; 73 settled??Promise.all; 74 failure barrier |
| src/shell/process-supervisor.ts | 187/189/192 required fields; 215 optional-output bypass in live child constructor primitive; 226/1182/1297 missing-settled replacements; 1292/1857 output replacements |
| src/shell/shell.ts | 150 output??exited in absolute cleanup path; Handle comes from ShellSpawner |
| src/file/ripgrep.ts | 244 output??resolved; 261 optional.catch??resolved; proc comes from Task/Host Supervisor 210/211 |
| src/expert-squad/package-tool-capsule.ts | 599 output??resolved; handle comes from spawnTaskCommand 500 |

`test/process-supervisor-control-plane.test.ts:579` optional output catch should become a direct catch on the required original Promise. `src/server/server.ts:56` is **PendingRuntimeRollbackReceipt.settled**, an independent rollback Promise cache; it is excluded. OAuth, credential exchange and skill diagnostic similarly named business fields are excluded. NodeProcess uses ProcessSpawnedHandle, whose output/settled are already required, not this optional Handle interface.

## Exact test factory impact

Seven non-UI files contain 15 distinct Handle constructions and 15 factory registrations (three search-code registrations share one constructor). Fourteen constructions lack terminalFact, actually spread across **six files requiring field migration**. Three lack outputSettled. Nine lack settled; the union missing output/settled is nine. The seventh reviewed file, plugin-process-facade.test.ts, has a complete signal constructor and needs focused regression, not a field edit. Earlier shorthand 'seven files/fourteen old constructors' was imprecise; this table is the corrected count. Current field flags below are F=terminalFact, O=outputSettled, S=settled. No affected test was run.

| File | Construction location(s) | Current fields | Required migration count |
| --- | --- | --- | --- |
| command-inactivity-settlement.test.ts | 10,49,120 | O,S at all three; missing F | 3 |
| file/ripgrep-protocol.test.ts | factory67/return72 | O,S; missing F | 1 |
| process-authority-runtime.test.ts | factory397/return403, factory443/return447 | all three missing | 2 |
| process-supervisor-control-plane.test.ts | 164,187,219,248,365, factory518/return523 | O only at 164/187/219/248/523; all missing at365 | 6 |
| shell-deadline.test.ts | 78 | O only; missing F,S | 1 |
| tool/search-code-bounded-execution.test.ts | helper105/return126; used by factories530/607/727 | O,S; missing F | 1 |
| plugin-process-facade.test.ts | 50 | F,O,S; exact SIGTERM positive projection | 0; focused regression |

Do not add fields as arbitrary always-resolved placeholders when the fixture has delayed output/physical proof. Office output must join its real test streams; checkpoint terminate/dispose must close its owned fixture streams and expose a truthful physical/output settlement; delayed-output/early-failure fixtures must preserve original failure objects and allSettled completion. The auxiliary physical-only disposal case at365 has already completed physical/output state while its separate auxiliary disposal Promise waits; preserve this distinction. The command byte-source fixture at120 currently supplies immediately fulfilled output/settled while its source later fails: migration should keep its explicit retained-bytes/original-error contract and make the new Handle closure facts truthful, rather than retain an inconsistent factory just because fields typecheck.

Searched these seven files for `.not.`, toBeNull, toBeUndefined, toHaveLength(0) and absence/call-negative wording: no negative assertion matches. Two keyword matches are explicit settlement-proof error contracts, not negative tests. This is a source review, not an executed static acceptance test. No DOM (Document Object Model), component render, snapshot or browser assertion in these seven files was used. A newly encountered UI-automation branch in a separate OCI fixture is reported in the Capsule audit and must not run.

## Shared entry / termination / recovery qualification

| Production path | Actual source boundary | This batch evidence and remaining gap |
| --- | --- | --- |
| Facade Host/Task spawn and run | Facade69/70, util Process119/188/199; plugin181/543; inactivity34/40 | one common adapter bug; v2 actual Host pipe only; Task and inherit unexecuted |
| standalone spawn caller/pager | util Child107 projects only physical terminal; cli/cmd/session208–221 inherit | does not expose/join public settled; independent caller-completion review still open |
| Shell/bash/Session shell | Shell188/198/377/387, bash384/385, shell-exec583/588; strict finally176/595/654 | original Supervisor handles, not this adapter bug; shared raw owner/output/request remains relevant |
| browser executor | node-executor220/244, result149/exited+output, dispose199 | distinct Promise.all does not by itself prove same missing-request root; failure and role matrix open |
| browser MCP (Model Context Protocol) launcher | node-launcher44/193; actual .pipe58/59; strict112/214 | distinct destination sink and transport boundary; no actual broken inherit run |
| MCP transport | index1781/1785; protocol stdout1788; custom/inherit stderr1797/1799; exit notification1805; strictclose1853/1858 | exit notification is not complete close; actual destination fault/Task authority open |
| codebase/file broker/ripgrep | codebase202/220/221; file-broker104/114/116; ripgrep210/211/244/264 | direct raw different disposal combinations; original File.search/ripgrep checker would add real value |
| package/plugin tools | package-tool500/614; plugin-tool-host152/205 | strict physical/output/request disposal; Capsule file boundary also applies when configured |
| Task lifecycle | Supervisor596/627/639/666, TaskAPI3203; mandatory and auxiliary leases | normal/cancel/terminal/checkpoint source audit only; actual failed-sink Task occurrence/retry remains open |
| orphan/restart | Supervisor853; restart-handoff126/168; immutable transfer | raw exact PID/birth/request ownership; not proven by non-detached v2 |
| Task/Mission/Session recovery | task-session-lineage158; prompt/owner287; mission/process-recovery135/199; server363 | independent durable generation/occurrence and exact physical owner; no actual new lifecycle run |
| same backend two Projects | one Global temporary base, UUID request; per-Task lease/Capsule identity | source isolation only; real serial/retry/parallel one-fault-one-peer remains open |
| Node owned_process/detached / POSIX | Node adapter / Host detached Facade48 | different raw ProcessSpawnedHandle contract; all required output/settled; qualify separately |

Facade inherit 83 merely pipes original source to process.stdout/stderr and returns null; original output settled does not explicitly join destination sink errors. Browser launcher pipes with end:false; MCP stderr writes without drain. The v2 caller-for-await EPIPE→source abort chain is not evidence of inherit behavior. No new swallow/global error handler or destination-settlement implementation is justified before its real matrix.

Node Windows owned-tree raw settlement at process-node464 allSettled-collects terminal/output and request removal before throwing. It is a correct contrast. Direct Node/POSIX baseSettled631 uses Promise.all but has no separate request cleanup; generic controlledHandle still separately awaits actual output closure after terminal failure, and failed spawn waits close. Do not rewrite it merely because the keyword matches; runtime output-fault cases remain unqualified.

## History, data, delivery and risks

outputSettled optional entered with `652597357` (2026-08-10); its real child and Windows returns already supplied output. authoritative settled optional and raw allSettled cleanup entered `76132f342` (2026-08-12), while old test handles could omit it. `08d9445e2` (2026-08-28) introduced terminalFact optional, supplied it in both real constructors, and introduced current adapter Promise.all/fallbacks. Later restart `db479ca18`, bounds `814540e1a` and foreground policy/deadline `2f63b697f` preserved this barrier. No explicit durable decision requiring real product missing-field adapters was found; the reason for keeping optional syntax is historically unknown, not proof of compatibility requirements.

This Handle cut changes internal TypeScript guarantees and error-barrier timing. It changes no database schema, HTTP route, persisted Task/Mission/Session occurrence, output bytes, ownership root, restart protocol, deadline, root-exit policy, signal observation or model request. It may expose a previously omitted later cleanup error and wait the already-owned cleanup phase before error publication, which is the intended contract. Pending/unknown cleanup retains evidence and reports the existing bounded uncertainty; it does not become success. Capsule command specs contain actual args/environment and should not be dumped into reports or copied as credentials. The separately discovered Capsule resource cleanup requires its own full analysis and true Linux qualification before a whole-shared-root completion claim.

No version bump/release is proposed. Parent must write the formal Recall before implementation, update current architecture with the settled error/uncertainty contract, run selected positive tests/typecheck/docs/checks, record actual v3 results, then scoped commit/fetch/upstream merge/full outgoing review/normal push. Unknown old AggregateError and unrun matrices must stay explicit.
