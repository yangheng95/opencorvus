# Task Capsule command-file shared settlement audit

Read-only extension requested immediately after discovering a second shared resource boundary. This is not downgraded to a Windows/local/fixture problem. No Capsule, WSL (Windows Subsystem for Linux), container, model, service or user process was started; no code/test/spec was edited. Linux runtime availability is unknown until a separately authorized real capability probe/run. Existing checker source is read evidence, not a successful run.

## Observed code defect and data/owner

The only production `createOciTaskExec` caller is execution-capsule/runtime.ts:229 in wrapTaskCapsuleCommand; the only production wrapper caller is Supervisor spawnTaskCapsuleCommand:504. OCI is Open Container Initiative. `createOciTaskExec:667–694` ensures the current Task container, allocates random command UUID (Universally Unique Identifier), writes a unique process spec with flag wx at686, and returns real runc argv containing that exact file. The file contains executable/arguments/environment/cwd/resource metadata. Evidence must not dump its actual environment/arguments indiscriminately or expose any credentials.

`containerPaths:205–217` places it at descriptor.outerSourceRoot/control/task-containers/hash(controllerUnit+TaskID)/bundle/processes/<command UUID>.json. Actual container ID/unit are bound to controllerUnit+TaskID. This is per-Task/per-controller command-file authority, distinct from the Windows unique supervisor request directory and from a Project workspace. The existing hash is a naming identity primitive, not a proposed mutable-source acceptance hash. Simultaneous commands create separate UUID files; same Task/container startup shares the `starts` map, while Task IDs/controller identities define separate container roots.

Supervisor:503–506 wraps the async file-producing operation in awaitWithAbort. When cancellation wins this await, original wrapping can still finish and publish its file. The outer awaitSpawnAdmission waits the already rejected spawnTaskCapsuleCommand Promise, not the lost wrapping Promise, so its otherwise correct late-Handle cleanup cannot see or remove this file.

After wrapping returns, :507 signal.throwIfAborted or :508–517 defaultSpawnCommand can reject before a Handle is returned. No exact process-file cleanup joins those paths. After a successful spawn, :519–524 runs base.exited.finally, sets a local boolean and performs **void fs.unlink(processFile).catch(()=>undefined)**. It neither waits nor preserves the original unlink failure. Return :533 spreads base—including the three real fields—so settled remains only the base child physical/output settlement; it can finish before its Capsule process-file release. A caller error exit can cut off that unjoined unlink. Requiring fields and fixing the public adapter Promise.all alone cannot repair this wrapper resource boundary.

All three fields genuinely exist in the spread base; this fact does not prove their current settlement includes the wrapper-created file. Their required contract must explicitly cover owned wrapper resources or retain this unresolved scope; do not claim complete shared settlement merely because it typechecks.

## Complete shared production admission and lifecycle coverage

Three Task entry families all select the same wrapper after the canonical persisted binding reader:

| Entry | Resolution/wrapper | Consumers and impact |
| --- | --- | --- |
| Task shell | Supervisor325–357: resolve331, Capsule335–345 | Shell.runTask198 / launchTask387, bash384; affects foreground/background/mandatory/auxiliary based on original caller role |
| Task gated shell | 364–411: resolve371, Capsule375–395 | Session shell-exec583; file prepared before real shell-start admission; later admission/cancel failure can share the leak |
| Task command | 422–459: resolve431, Capsule435–445 | Task Facade69; Process.runTask199, Git/metrics; browser244; ripgrep210; codebase202; file-broker104; package-tool500; plugin-tool-host152; MCP1781 |

`resolveTaskProcessExecution`248–274 and activeTaskExecutionCapsule214–241 read the immutable Task binding and explicit configured deployment mode/descriptor. Native binding requires native deployment and no active Capsule descriptor; Capsule binding requires capsule deployment and the current descriptor identity/root. `wrapTaskCapsuleCommand:189` explicitly requires Linux; root/cwd/visible-source mapping is verified before file creation. Windows native tasks do not enter this file path; that is a platform distinction, not exclusion of the shared contract.

Task read leases/registrations at Supervisor329/369/429 survive the admitted Handle until waitForOwnedPhysicalSettlement. Because Capsule currently propagates base settled, file unlink is outside that lease retirement. Mandatory cancellation/terminalization610 and checkpoint678 call disposeTaskExecutionCapsule, but it delegates runtime268→disposeOciTaskContainer697. That owner waits pending container start, replays terminal evidence or stops the systemd unit and validates inactive746–753; it does **not** delete command process files. Unit terminal evidence and runc inventory are physical/container facts, not file cleanup receipts. Auxiliary process disposal alone also does not add a process-file join.

| Lifecycle branch | Current code evidence | Qualification/risk |
| --- | --- | --- |
| normal admitted exit | void unlink after base.exited, base settled returned | unjoined deletion/error swallowing proven in code; timing/filesystem result unexecuted |
| output/control failure with known physical exit | same base settled can reject; finally unlink launched independently | failure publication can precede file cleanup; original cleanup error lost |
| physical unknown | base physical failure; current finally still schedules unlink | exact safely releasable resource boundary needs explicit contract; do not erase evidence while physical ownership unknown |
| cancellation during wrapping | awaitWithAbort rejects while wrap continues | late UUID file can appear without any returned Handle |
| cancellation after wrapping/before spawn | throwIfAborted507 | already published exact file lacks cleanup owner |
| failed default spawn | defaultSpawnCommand rejection | no wrapper catch releases file; no Handle is tracked |
| cancellation during/after admission | outer awaitSpawnAdmission strict late disposal of returned Handle | physical/output cleanup works; file unlink is still unjoined |
| retry/continued Task epoch | fresh command UUID, same Task/controller container | each new occurrence does not reclaim a previous unknown/unjoined file |
| restart/controller death | systemd BindsTo stops container; persisted unit terminal evidence replay | no command-file reader/recovery sweep found; prior root files can remain, replacement controller names a different root |
| serial/parallel commands | UUID file per command, same Task/container; starts map per Task | no demonstrated name collision; accumulated or failed cleanup is still per-resource; no actual new parallel run |
| multiple Projects | immutable Task binding + controller/Task root | taskID uniqueness/source-root authority governs physical separation; source audit only, true shared-runtime two-Project run missing |

Repository search found the one processFile creation, the Supervisor one unlink and no production process-file recovery enumeration/removal. Whole Task/Project runtime deletion may eventually release broader directories under another operation, but no such exact command cleanup guarantee has been established; do not borrow eventual directory deletion as command settled success. Preserve original command UUID/controller/Task/resource association and unknown facts in any future recovery design; do not use a broad rm, a Task title or a timestamp to adopt/delete old command files.

## Obsolete per-command stop branch

wrapTaskCapsuleCommand's sole current return at runtime256–262 spreads actual runc exec fields and explicitly sets unitName/systemctl undefined. createOciTaskExec returns containerUnit at693, not those fields. No alternate production wrapper or factory was found. Therefore Supervisor stopUnit527 always returns Promise.resolve and its sole runSystemctlStop529 call is statically unreachable under current production wrapper. runSystemctlStop467–492 has no other caller; the wrapper boolean/stop Promise/control overrides exist only to support this obsolete per-command systemd shape.

This is evidence of dead code in the touched path, not authorization to remove it now. The **actual** OCI Task container systemdRun/systemctl lifecycle in oci-task-container.ts and disposeTaskExecutionCapsule is active and must remain. Do not rename containerUnit into per-command unitName to revive the old path, duplicate stop policy or stop the shared Task container merely to clean one command.

Historical processFile unlink exists since `65d0bfc98` (2026-08-07); OCI runtime files last changed in `354a7305f` (2026-08-27) and initial `65d0bfc98`. Existing older architecture cancellation paths aimed to stop shared unit/physical Task processes, not to join every command-file release. A single prior Task/container or Windows test passing is not evidence of this file's settlement.

## Existing real Linux checkers and important gaps

Real runc/rootless-systemd source checkers exist: execution-capsule-oci.test.ts (loopback two-Task isolation, immutable unexpected-terminal/recovery), execution-capsule-oci-controller-exit.test.ts (owned controller physical kill settles its bound Task container), and execution-capsule-systemd-lifecycle.test.ts. The OCI helper paths are fixtures/execution-capsule-oci-probe.ts and fixtures/execution-capsule-oci-controller-exit.ts.

They call createOciTaskExec directly and run its returned command through Bun.spawn. They do not enter persisted Task binding→spawnTaskCapsuleCommand→track/Facade original Handle. Their finally recursively removes the entire helper root; it can hide retained command files. Thus even genuine successful runs would not prove wrapper admission/file barrier or original Promise order. Controller-exit's own SIGKILL is a separate bounded fixture case, not ordinary shutdown or user-process authority.

`fixture/linux-runtime.ts` availability check probes requested Bun/Node executables, systemd-run and user systemd environment; it does not validate runc executable/rootless ability, required kernel/network namespaces, actual controller containment or this repository path. Tests can skip; skipped is unavailable, not passed. Windows helper path conversion in OCI tests rewrites only `C:` to `/mnt/c`, while this workspace is on `D:`; current static route cannot supply a valid Linux path without proper path translation. No capability probe or WSL invocation was executed here; installed availability is unknown, not definitively absent.

**Encountered prohibited UI automation:** OCI probe269–287 has a frozen-toolchain branch that launches Playwright, opens a page, goto localhost and reads body text. No such branch or test was run. Under current user rules the touched branch and any solely-serving presentation expectation/config must be deleted by an authorized owner before this fixture is selected. Removing only the branch does not turn the remaining direct OCI test into the missing Supervisor acceptance. The systemd-lifecycle fixture also uses fixed unit names and preemptive stop; it should not be run against a shared user environment without a newly scoped owned fixture/authorization.

## Minimal repair shape and qualification needed before broad completion

Use the same owned wrapper operation/resource, not a second cleanup registry. Retain the original wrapping Promise so an abort cannot discard a late published file; settle that original operation/resource before releasing admission. Once a Handle exists, build one wrapper settlement from the original base physical/output/settled and exact process-file cleanup, preserving original errors through existing combination. Remove void unlink and swallowed errors as the current cleanup implementation when a replacement is authorized. Failed pre-spawn/late-wrap paths need the same exact release semantics and original primary+cleanup cause ordering, with no fabricated physical success. Retain evidence when ownership cannot be proven. ENOENT/error policy must be formally decided and positively checked, not catch-all false success. No proposal to reintroduce obsolete systemd command stop or change whole Task container authority is needed.

Before product editing, parent must select a complete contract and a real Linux qualification plan. A local pure wrapper/file primitive test can validate original Promise/resource/error ordering, but cannot be sold as true runc or Task/Mission end-to-end. To enter the real checker:

1. Authorize a fresh Linux owned root and unique controller scope; correctly resolve this D: checkout into the chosen Linux environment. Preserve current frozen descriptor, actual runc/systemd paths and real containment. Independently verify actual required executable and rootless/container capability; retain raw command statuses rather than skipped green.
2. Create a genuine current persisted Task Capsule binding with matching real descriptor/runtime/root and enter the actual public Supervisor Task command/shell/gated APIs. No factory override, fake runc or synthetic OS/output error. Observe original base/wrapped/Facade Promise IDs, real runc parent/target birth/unit/Task occurrence, exact command file metadata path (no environment dump), output, physical/container facts and cleanup syscall outcome.
3. Run finite normal exit first; then explicitly authorized exact cancellation during preparation/after file publication and genuine failed spawn/error cases, plus original cancellation/deadline. A real owned permission/IO error case needs separate exact resource/role authority; rootless uid and directory ownership must actually cause the intended syscall, not infer it from chmod text. Keep all first failures, unknown states and raw primary+cleanup causes.
4. Verify exact same Task/container serial subsequent command and two current Projects/Tasks parallel in one backend/descriptor base, one fault and one healthy peer; assert actual resource and lease receipts. Controller interruption/restart/recovery must keep exact resource ownership and preserve immutable terminal evidence. A process-only checker does not establish Mission/Session occurrence reducers; add real lifecycle acceptance separately if claimed.

Current result is a proven shared source-level defect with a concrete reachable resource lifecycle; no new actual Linux reproduction was performed. A Windows Native v3 can qualify the adapter error barrier only. Keep Capsule admission/settlement/recovery and all unexecuted lifecycle/destination matrices open until genuine current checker evidence exists.
