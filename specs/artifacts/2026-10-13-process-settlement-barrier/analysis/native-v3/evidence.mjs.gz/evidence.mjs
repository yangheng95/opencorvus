// Prepared scratch only. No process is started by importing this module.
import assert from "node:assert/strict"
import fs from "node:fs"
import path from "node:path"
import { performance } from "node:perf_hooks"
import { randomUUID } from "node:crypto"

export function argumentsFor(names) {
  const input = process.argv.slice(2)
  const result = {}
  assert.equal(input.length % 2, 0, "Expected named argument/value pairs")
  for (let index = 0; index < input.length; index += 2) {
    const name = input[index]
    assert(names.includes(name) && !(name in result), `Unknown or repeated argument: ${name}`)
    result[name] = input[index + 1]
  }
  return result
}

export function isolateEnvironment(runRoot, executable) {
  const allowed = ["PATH", "SystemRoot", "WINDIR", "ComSpec", "PATHEXT", "LANG", "LC_ALL", "LC_CTYPE"]
  const result = Object.fromEntries(allowed.flatMap((name) => process.env[name] ? [[name, process.env[name]]] : []))
  result.PATH = [path.dirname(executable), result.PATH].filter(Boolean).join(path.delimiter)
  for (const [name, relative] of [
    ["HOME", "home"], ["USERPROFILE", "home"], ["APPDATA", "appdata"], ["LOCALAPPDATA", "localappdata"],
    ["TEMP", "temp"], ["TMP", "temp"], ["TMPDIR", "temp"], ["XDG_CONFIG_HOME", "xdg-config"],
    ["XDG_DATA_HOME", "xdg-data"], ["XDG_CACHE_HOME", "xdg-cache"], ["XDG_STATE_HOME", "xdg-state"],
    ["OPENCORVUS_HOME", "runtime"],
  ]) result[name] = path.join(runRoot, relative)
  result.HOMEDRIVE = path.parse(result.HOME).root.slice(0, 2)
  result.HOMEPATH = result.HOME.slice(2)
  result.OPENCORVUS_TASK_PROCESS_MODE = "native"
  result.OPENCORVUS_DISABLE_EXTERNAL_SKILLS = "1"
  result.OPENCORVUS_DISABLE_AUTOUPDATE = "1"
  return result
}

export function applyIsolatedEnvironment(runRoot, executable) {
  const result = isolateEnvironment(runRoot, executable)
  for (const name of Object.keys(process.env)) delete process.env[name]
  Object.assign(process.env, result)
}

export function exclusiveJson(file, value) {
  const stage = `${file}.${process.pid}-${randomUUID()}.stage`
  fs.writeFileSync(stage, JSON.stringify(value, null, 2), { flag: "wx" })
  // Publish one complete same-volume receipt atomically, with EEXIST instead of replacing an older fact.
  fs.linkSync(stage, file)
  fs.unlinkSync(stage)
}

export function makeRecorder(file, role, experimentID) {
  fs.writeFileSync(file, "", { flag: "wx" })
  const started = performance.now()
  const objects = new WeakMap()
  let nextID = 1
  let sequence = 0
  const states = {}
  const objectID = (value) => {
    if ((typeof value !== "object" || value === null) && typeof value !== "function") return null
    if (!objects.has(value)) objects.set(value, nextID++)
    return objects.get(value)
  }
  const errorFact = (value, seen = new Set(), depth = 0) => {
    if ((typeof value !== "object" || value === null) && typeof value !== "function")
      return { kind: typeof value, value: value === undefined ? "<undefined>" : String(value) }
    const id = objectID(value)
    if (seen.has(value) || depth > 12) return { referenceID: id, truncated: true }
    seen.add(value)
    const result = { referenceID: id, kind: value instanceof Error ? "Error" : typeof value }
    for (const name of ["name", "message", "code", "errno", "syscall", "path", "stack"])
      if (name in value) result[name] = typeof value[name] === "bigint" ? String(value[name]) : value[name]
    if ("cause" in value) result.cause = errorFact(value.cause, seen, depth + 1)
    if (value instanceof AggregateError) result.errors = value.errors.map((error) => errorFact(error, seen, depth + 1))
    return result
  }
  const event = (kind, value = {}) => {
    fs.appendFileSync(file, JSON.stringify({ sequence: ++sequence, role, experimentID, kind,
      observedAtUtc: new Date().toISOString(), observedAtMs: Date.now(), elapsedMs: performance.now() - started, ...value }) + "\n")
  }
  const observe = (name, promise, project = () => undefined, after = () => undefined) => {
    if (!promise) {
      states[name] = { status: "unavailable" }
      event("promise-unavailable", { name })
      return promise
    }
    const promiseID = objectID(promise)
    states[name] = { status: "pending", promiseID }
    event("promise-started", { name, promiseID })
    // A passive branch only: callers keep the exact original Promise and reason.
    // Journal I/O errors are not swallowed and may fail this scratch observer.
    void promise.then((value) => {
      states[name] = { status: "fulfilled", promiseID, value: project(value) }
      event("promise-fulfilled", { name, ...states[name] })
      after()
    }, (error) => {
      states[name] = { status: "rejected", promiseID, error: errorFact(error) }
      event("promise-rejected", { name, ...states[name] })
      after()
    })
    return promise
  }
  return { event, observe, states, errorFact, objectID }
}

export function readObservation(file) {
  try {
    const entry = fs.lstatSync(file)
    return { status: "present", file, regular: entry.isFile(), directory: entry.isDirectory(),
      value: entry.isFile() ? JSON.parse(fs.readFileSync(file, "utf8")) : undefined }
  } catch (error) {
    if (error?.code === "ENOENT") return { status: "absent", file, code: "ENOENT" }
    return { status: "unknown", file, error: { name: error?.name, message: error?.message, code: error?.code,
      errno: error?.errno, syscall: error?.syscall, stack: error?.stack } }
  }
}

export function tailBytes(experimentID) {
  const first = Buffer.from(`NATIVE_SINK_STDOUT_BEGIN:${experimentID}\n`, "utf8")
  const last = Buffer.from(`\nNATIVE_SINK_STDOUT_END:${experimentID}\n`, "utf8")
  return Buffer.concat([first, Buffer.alloc(65_536 - first.length - last.length, 0x78), last])
}

export async function until(promise, deadlineAt, label) {
  let timer
  try {
    return await Promise.race([promise, new Promise((_, reject) => {
      timer = setTimeout(() => {
        const error = new Error(`Observation deadline exceeded: ${label}`)
        error.code = "SCRATCH_OBSERVATION_TIMEOUT"
        reject(error)
      }, Math.max(1, deadlineAt - Date.now()))
    })])
  } finally { clearTimeout(timer) }
}

export const pause = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

export async function observeSettlement(promise, deadlineAt, label, record) {
  try {
    return await until(promise, deadlineAt, label)
  } catch (error) {
    if (error?.code !== "SCRATCH_OBSERVATION_TIMEOUT") throw error
    record.event("settlement-observation-window-elapsed", { label, error: record.errorFact(error), states: record.states,
      boundary: "Only an observation window elapsed; continue the same original Promise. No exit, restart, replacement or fabricated terminal fact" })
    return await promise
  }
}
