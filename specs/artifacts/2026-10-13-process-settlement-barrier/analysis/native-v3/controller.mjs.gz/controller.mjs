// PREPARED, NOT EXECUTED. Run only after root's complete spec and explicit execution authorization.
import assert from "node:assert/strict"
import fs from "node:fs"
import path from "node:path"
import { spawn } from "node:child_process"
import { randomUUID } from "node:crypto"
import { fileURLToPath } from "node:url"
import { argumentsFor, exclusiveJson, isolateEnvironment, makeRecorder, pause, readObservation, tailBytes, until, observeSettlement } from "./evidence.mjs"

const args = argumentsFor(["--case", "--run-root", "--executable"])
assert(process.platform === "win32" && args["--run-root"] && args["--executable"])
assert(["baseline", "close-stdout-reader"].includes(args["--case"]))
const scriptRoot = path.dirname(fileURLToPath(import.meta.url))
const workspace = path.resolve(scriptRoot, "../..")
const ownedBase = path.resolve("C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13")
const runRoot = path.resolve(args["--run-root"])
const executable = path.resolve(args["--executable"])
assert.equal(path.dirname(runRoot).toLowerCase(), ownedBase.toLowerCase(), "Exact previously established owned fixture base required")
const ownedRunNames = { baseline: "native-sink-baseline-01a133-v3", "close-stdout-reader": "native-sink-reader-01a133-v3" }
assert.equal(path.basename(runRoot), ownedRunNames[args["--case"]], "Exact fresh authorized occurrence required")
assert.equal(fs.realpathSync.native(ownedBase).toLowerCase(), ownedBase.toLowerCase(), "Fixture parent must be a direct physical path")
assert(fs.statSync(executable).isFile())
fs.mkdirSync(runRoot) // EEXIST is fatal; never recycle an old occurrence or mutate it.
for (const name of ["runtime", "project", "evidence", "home", "appdata", "localappdata", "temp", "xdg-config", "xdg-data", "xdg-cache", "xdg-state"])
  fs.mkdirSync(path.join(runRoot, name))
const experimentID = randomUUID()
const input = { experimentID, facadeOccurrenceID: `native-sink-${randomUUID()}`, case: args["--case"], runRoot,
  projectRoot: path.join(runRoot, "project"), scriptRoot, packageRoot: path.join(workspace, "packages/opencorvus"),
  executable, expectedBunVersion: "1.4.0", controllerPID: process.pid, deadlineAt: Date.now() + 45_000,
  qualification: "Owned Host/finite-producer native facade primitive. No application Task, Mission, Session, browser or model E2E claim" }
exclusiveJson(path.join(runRoot, "prepared-run.json"), input)
fs.writeFileSync(path.join(runRoot, "expected-tail-stdout.bin"), tailBytes(experimentID), { flag: "wx" })
const record = makeRecorder(path.join(runRoot, "evidence", "controller-events.jsonl"), "node-controller", experimentID)
record.event("controller-started", { input, nodeVersion: process.version })
const child = spawn(executable, [path.join(scriptRoot, "native-host.mjs"), "--run-root", runRoot], {
  cwd: runRoot, env: isolateEnvironment(runRoot, executable), stdio: ["ignore", "pipe", "pipe"], windowsHide: true,
})
assert(child.stdout && child.stderr)
const stdoutReader = child.stdout
const stderrReader = child.stderr
const exited = new Promise((resolve, reject) => {
  child.once("exit", (code, signal) => resolve({ pid: child.pid, code, signal }))
  child.once("error", reject) // Child launch error only; no stdout/error or global listener.
})
const closed = new Promise((resolve, reject) => {
  child.once("close", (code, signal) => resolve({ pid: child.pid, code, signal }))
  child.once("error", reject)
})
record.observe("controller.hostExited", exited, (value) => value)
record.observe("controller.hostClosed", closed, (value) => value)
const output = { stdout: [], stderr: [] }
const drain = async (stream, channel) => {
  const target = path.join(runRoot, `${channel}.log`)
  fs.writeFileSync(target, "", { flag: "wx" })
  let bytes = 0
  for await (const value of stream) {
    const chunk = Buffer.from(value)
    bytes += chunk.length
    assert(bytes <= 8 * 1024 * 1024, "Finite scratch producer exceeded output evidence bound")
    output[channel].push(chunk)
    fs.appendFileSync(target, chunk)
  }
  return { bytes, ended: true, readerDestroyed: stream.destroyed }
}
const stdoutDrain = drain(stdoutReader, "stdout")
const stderrDrain = drain(stderrReader, "stderr")
record.observe("controllerExternal.stdoutDrain", stdoutDrain, (value) => value)
record.observe("controllerExternal.stderrDrain", stderrDrain, (value) => value)
let hostReady
let producerReady
let mutation
let controllerFailure
let parentResults
let ownershipBound = false
let shutdownDispatched = false
const waitFact = async (name) => {
  const deadlineAt = Math.min(input.deadlineAt - 5_000, Date.now() + 20_000)
  while (Date.now() < deadlineAt) {
    const observed = readObservation(path.join(runRoot, "evidence", name))
    if (observed.status === "present") return observed.value
    if (observed.status === "unknown") throw new Error(`Unknown evidence I/O: ${JSON.stringify(observed)}`)
    if (child.exitCode !== null || child.signalCode !== null) throw new Error(`Host exited before ${name}`)
    await pause(20)
  }
  throw new Error(`Ready observation deadline: ${name}`)
}
const normalShutdown = async () => {
  assert(ownershipBound && hostReady && producerReady && !shutdownDispatched)
  const url = new URL(`/shutdown/${experimentID}`, producerReady.url)
  shutdownDispatched = true
  record.event("normal-shutdown-dispatched", { url: url.href, producer: producerReady.producer, shutdownDispatched })
  const response = await fetch(url, { method: "POST", headers: { "content-type": "application/json" },
    body: JSON.stringify({ experimentID, producerOccurrenceID: producerReady.producer.occurrenceID }),
    signal: AbortSignal.timeout(5_000) })
  record.event("normal-shutdown-http-response-received", { status: response.status, shutdownDispatched,
    bodyQualification: "Pending original response JSON read" })
  const body = await response.json()
  mutation = { status: response.status, body, observedAtUtc: new Date().toISOString() }
  record.event("normal-shutdown-response", mutation)
  assert.equal(response.status, 200)
  assert.equal(body.outcome, "normal-shutdown-admitted")
  assert.equal(body.producer.pid, hostReady.target.pid)
  assert.equal(body.producer.processInstanceID, hostReady.target.processInstanceID)
}
try {
  hostReady = await waitFact("host-ready.json")
  producerReady = await waitFact("producer-ready.json")
  assert.equal(hostReady.experimentID, experimentID)
  assert.equal(producerReady.experimentID, experimentID)
  assert.equal(hostReady.host.pid, child.pid)
  assert.equal(hostReady.parent.pid, process.pid)
  assert.equal(producerReady.producer.pid, hostReady.target.pid)
  assert.equal(producerReady.producer.processInstanceID, hostReady.target.processInstanceID)
  assert.equal(producerReady.actualBunVersion, input.expectedBunVersion)
  const endpoint = new URL(producerReady.url)
  assert.equal(endpoint.hostname, "127.0.0.1")
  assert.equal(endpoint.protocol, "http:")
  assert(Number(endpoint.port) > 0)
  if (hostReady.request) {
    assert.equal(hostReady.request.owner_pid, child.pid)
    assert.equal(hostReady.request.owner_process_instance_id, hostReady.host.processInstanceID)
    assert.equal(hostReady.request.runtime_occurrence_id, hostReady.host.occurrenceID)
  } else record.event("native-request-observation-unavailable", { scope: "Do not infer raw/request settlement from facade" })
  if (hostReady.durableRequest?.status === "present")
    assert.deepEqual(hostReady.durableRequest.value, hostReady.request)
  if (hostReady.nativeHelper?.status === "present") {
    assert.equal(hostReady.nativeHelper.value.request_id, hostReady.request.request_id)
    assert.equal(hostReady.nativeHelper.value.runtime_occurrence_id, hostReady.host.occurrenceID)
    assert.equal(producerReady.parent.pid, hostReady.nativeHelper.value.helper_pid)
    assert.equal(producerReady.parent.processInstanceID, hostReady.nativeHelper.value.helper_process_instance_id)
  } else record.event("native-helper-birth-observation-unavailable", { scope: "No inferred helper identity" })
  ownershipBound = true
  const health = await fetch(new URL(`/health/${experimentID}`, producerReady.url), { signal: AbortSignal.timeout(5_000) })
  assert.equal(health.status, 200)
  assert.deepEqual((await health.json()).producer, producerReady.producer)
  record.event("identity-and-real-health-bound", { hostReady, producerReady,
    identityRelation: "Facade experiment occurrence, Host runtime occurrence, request UUID and observed Target occurrence are distinct identities" })
  if (input.case === "close-stdout-reader") {
    assert.equal(stdoutReader, child.stdout)
    assert.equal(stdoutReader.destroyed, false)
    const readerClosed = new Promise((resolve) => stdoutReader.once("close", resolve))
    record.event("owned-host-stdout-reader-destroy-dispatched", { host: hostReady.host,
      injectedError: false, scope: "Only this controller's ChildProcess.stdout reader; stderr reader remains intact" })
    stdoutReader.destroy() // Real reader endpoint closure. No synthetic Error, source hook or log-file-only closure.
    await until(readerClosed, Date.now() + 5_000, "owned Host stdout reader close")
    record.event("owned-host-stdout-reader-closed", { destroyed: stdoutReader.destroyed, closed: stdoutReader.closed,
      stderrDestroyed: stderrReader.destroyed })
    assert.equal(stderrReader.destroyed, false)
  }
  await normalShutdown()
} catch (error) {
  controllerFailure = record.errorFact(error)
  record.event("controller-action-error", { error: controllerFailure })
  // If ready was fully bound, attempt the same normal shutdown once. Never guess a port/PID or send to another owner.
  if (ownershipBound && !shutdownDispatched && child.exitCode === null && child.signalCode === null) {
    try { await normalShutdown() } catch (cleanupError) {
      record.event("normal-shutdown-attempt-error", { error: record.errorFact(cleanupError) })
    }
  }
}
try {
  parentResults = await observeSettlement(Promise.allSettled([exited, closed, stdoutDrain, stderrDrain]), input.deadlineAt + 20_000,
    "owned Host exit/close and both controller output drains", record)
} catch (error) {
  controllerFailure ??= record.errorFact(error)
  record.event("controller-join-error", { error: record.errorFact(error), states: record.states,
    boundary: "No process is killed and no unresolved branch is marked successful; root must inspect exact retained owner" })
}
const hostFinal = readObservation(path.join(runRoot, "evidence", "host-final.json"))
const request = hostReady?.request
let requestFacts
if (request) {
  const directory = path.dirname(request.ready_file)
  // A Host crash can precede its native helper's final durable marker. Observe only this request, without cleanup or cancellation.
  const markerDeadline = Math.min(input.deadlineAt + 20_000, Date.now() + 5_000)
  while (readObservation(directory).status === "present" && readObservation(request.settled_file).status === "absent"
    && Date.now() < markerDeadline) await pause(20)
  requestFacts = { requestID: request.request_id, directory: readObservation(directory),
    markers: ["ready.json", "helper.json", "settled.json", "launch-failed.json"].map((name) =>
      ({ name, ...readObservation(path.join(directory, name)) })) }
}
const observedStdout = Buffer.concat(output.stdout)
const observedStderr = Buffer.concat(output.stderr)
const expectedPromiseNames = ["rawSupervisor.exited", "rawSupervisor.terminalFact", "rawSupervisor.outputSettled", "rawSupervisor.settled",
  "facade.terminal", "facade.outputSettled", "facade.settled", "nativeExternal.stdoutDrain", "nativeExternal.stderrDrain"]
const allHostNamedBranchesFulfilled = hostFinal.status === "present"
  && expectedPromiseNames.every((name) => hostFinal.value.states[name]?.status === "fulfilled")
const facadeTerminal = hostFinal.status === "present" ? hostFinal.value.states["facade.terminal"]?.value : undefined
const rawSpawn = hostFinal.status === "present" ? hostFinal.value.states["rawSupervisor.spawnPromise"] : undefined
const rawObservation = hostFinal.status === "present" ? hostFinal.value.rawObservation : undefined
const publicSettlementObservation = hostFinal.status === "present" ? hostFinal.value.publicSettlementObservation : undefined
const originalBarrierQualification = Boolean(publicSettlementObservation
  && ["fulfilled", "rejected"].includes(publicSettlementObservation.rawSettlement?.status)
  && publicSettlementObservation.rawSettlement.promiseID === hostFinal.value.states["rawSupervisor.settled"]?.promiseID
  && publicSettlementObservation.requestID === hostReady?.request?.request_id
  && publicSettlementObservation.requestDirectory?.status === "absent"
  && publicSettlementObservation.requestDirectory.code === "ENOENT")
const rawRequestAssociation = Boolean(rawObservation?.status === "available" && rawObservation.rawCallCount === 1
  && rawSpawn?.status === "fulfilled" && rawSpawn.value.handleID === rawObservation.handleID
  && rawObservation.handleID === hostReady?.rawHandleID && rawObservation.pid === hostReady?.target.pid
  && rawObservation.requestID === hostReady?.request?.request_id
  && rawSpawn.promiseID === rawObservation.originalSpawnPromiseID
  && hostReady?.durableRequest?.status === "present"
  && hostReady.nativeReady?.status === "present" && hostReady.nativeHelper?.status === "present"
  && hostReady.nativeReady.value.request_id === rawObservation.requestID
  && hostReady.nativeHelper.value.request_id === rawObservation.requestID)
const baselineQualification = input.case === "baseline" && parentResults?.every((value) => value.status === "fulfilled")
  && child.exitCode === 0 && hostFinal.status === "present" && hostFinal.value.exitCode === 0
  && observedStdout.equals(tailBytes(experimentID)) && mutation?.status === 200 && !controllerFailure
  && allHostNamedBranchesFulfilled && requestFacts?.directory.status === "absent"
  && facadeTerminal?.reason === "exited" && facadeTerminal.exitCode === 0 && facadeTerminal.pid === hostReady.target.pid
  && facadeTerminal.occurrenceID === input.facadeOccurrenceID
  && hostFinal.value.ownerRetirement.observation === "retired" && hostFinal.value.ownerRetirement.remainingCount === 0
  && hostFinal.value.targetPhysicalObservation === "dead_or_reused" && rawRequestAssociation && originalBarrierQualification
  && observedStderr.includes(Buffer.from(`NATIVE_SINK_STDERR_TAIL:${experimentID}\n`))
exclusiveJson(path.join(runRoot, "evidence", "controller-final.json"), {
  input, hostPID: child.pid, hostOSExit: { code: child.exitCode, signal: child.signalCode },
  states: record.states, parentResults: parentResults?.map((value, index) => ({
    name: ["controller.hostExited", "controller.hostClosed", "controllerExternal.stdoutDrain", "controllerExternal.stderrDrain"][index],
    status: value.status, ...(value.status === "rejected" ? { error: record.errorFact(value.reason) } : { value: value.value }),
  })), mutation, controllerFailure, hostFinal, requestFacts,
  stdoutBytes: observedStdout.length, stdoutExactlyFiniteTail: observedStdout.equals(tailBytes(experimentID)),
  stderrBytes: observedStderr.length, stderrHasProducerTail: observedStderr.includes(Buffer.from(`NATIVE_SINK_STDERR_TAIL:${experimentID}\n`)),
  shutdownDispatched, ownershipBound, allHostNamedBranchesFulfilled, rawRequestAssociation, facadeTerminal, baselineQualification,
  publicSettlementObservation, originalBarrierQualification,
  faultQualification: input.case === "close-stdout-reader" ? "Observed facts require root review; no auto-pass" : "not-applicable",
  observedAtUtc: new Date().toISOString(),
  boundary: "A controller ChildProcess exit proves its exact owned Host exit. Target physical proof needs production raw marker/settlement or separate birth-identity observation; absence of listener is not proof",
})
record.event("controller-report-persisted", { baselineQualification, hostOSExit: child.exitCode, states: record.states })
process.exitCode = input.case === "baseline" ? (baselineQualification ? 0 : 1)
  : (!controllerFailure && child.exitCode === 0 && parentResults?.every((value) => value.status === "fulfilled") ? 0 : 1)
// No kill, unref, stdout error swallowing or global exception handler: unexpected unresolved ownership remains visible.
