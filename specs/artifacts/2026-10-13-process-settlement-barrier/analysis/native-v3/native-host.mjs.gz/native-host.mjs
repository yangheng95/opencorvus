// PREPARED, NOT EXECUTED. Exact production facade/Windows supervisor with passive scratch observations.
import assert from "node:assert/strict"
import fs from "node:fs"
import path from "node:path"
import { pathToFileURL } from "node:url"
import { once } from "node:events"
import { argumentsFor, exclusiveJson, makeRecorder, pause, readObservation, observeSettlement } from "./evidence.mjs"

const args = argumentsFor(["--run-root"])
assert(process.platform === "win32" && args["--run-root"])
const runRoot = path.resolve(args["--run-root"])
const input = JSON.parse(fs.readFileSync(path.join(runRoot, "prepared-run.json"), "utf8"))
assert.equal(runRoot, input.runRoot)
assert.equal(process.env.OPENCORVUS_HOME, path.join(runRoot, "runtime"))
assert.equal(Bun.version, input.expectedBunVersion)
const record = makeRecorder(path.join(runRoot, "evidence", "host-events.jsonl"), "native-host", input.experimentID)
const source = (name) => pathToFileURL(path.join(input.packageRoot, name)).href
const { installProcessShims } = await import(source("src/runtime/shims.ts"))
installProcessShims()
const physical = await import(source("src/runtime/process-occurrence.ts"))
const { Global } = await import(source("src/global/index.ts"))
const { ProcessSupervisor } = await import(source("src/shell/process-supervisor.ts"))
const { supervisedHostProcessFacade } = await import(source("src/util/process-facade.ts"))
const host = physical.currentRuntimeProcessOccurrence()
const parent = physical.observedProcessOccurrence(process.ppid)
assert(parent && parent.pid === input.controllerPID)
const owner = `scratch-native-sink:${input.experimentID}`
const originalSpawn = ProcessSupervisor.spawnHostCommand
let request
let rawHandle
let capturedRawPromise
let rawCallCount = 0
const requestFields = ["request_id", "ready_file", "settled_file", "launch_failed_file", "cancel_file",
  "owner_pid", "owner_process_instance_id", "runtime_occurrence_id", "terminate_children_on_root_exit"]
const durableRequestObservation = () => {
  if (!request) return { status: "unavailable" }
  const observation = readObservation(path.join(path.dirname(request.ready_file), "request.json"))
  return observation.status === "present" ? { ...observation,
    value: Object.fromEntries(requestFields.map((name) => [name, observation.value[name]])) } : observation
}

const requestSnapshot = (reason) => {
  if (!request) return record.event("request-observation-unavailable", { reason })
  const directory = path.dirname(request.ready_file)
  record.event("request-directory-observed", { reason, requestID: request.request_id,
    durableRequest: durableRequestObservation(),
    observation: readObservation(directory), markers: ["ready.json", "helper.json", "settled.json", "launch-failed.json"].map((name) =>
      ({ name, ...readObservation(path.join(directory, name)) })) })
}
const restoreRequestObserver = ProcessSupervisor.setWindowsRequestObserverForTest((actual) => {
  // Memory capture only: no assertion, filesystem operation or error injection in native admission.
  request = Object.fromEntries(requestFields.map((name) => [name, actual[name]]))
})
ProcessSupervisor.spawnHostCommand = function (...originalArguments) {
  // Deliberately NOT async: return the original Promise, never a substitute handle.
  const originalPromise = Reflect.apply(originalSpawn, this, originalArguments)
  capturedRawPromise = originalPromise
  rawCallCount += 1
  void originalPromise.then((sameOriginalHandle) => {
    record.event("transparent-supervisor-tap", { returnedPromiseID: record.objectID(originalPromise),
      returnedOriginalPromise: true, argumentCount: originalArguments.length,
      contract: "Original function invoked once with unchanged arguments and receiver; no assertion or I/O before returning original Promise" })
    record.observe("rawSupervisor.spawnPromise", originalPromise, (value) => ({ pid: value.pid, handleID: record.objectID(value) }))
    rawHandle = sameOriginalHandle
    record.event("original-raw-handle-observed", { handleID: record.objectID(sameOriginalHandle), pid: sameOriginalHandle.pid })
    record.observe("rawSupervisor.exited", sameOriginalHandle.exited, (value) => value, () => requestSnapshot("raw-exited"))
    record.observe("rawSupervisor.terminalFact", sameOriginalHandle.terminalFact, (value) => value)
    record.observe("rawSupervisor.outputSettled", sameOriginalHandle.outputSettled, () => undefined,
      () => requestSnapshot("raw-outputSettled"))
    record.observe("rawSupervisor.settled", sameOriginalHandle.settled, () => undefined,
      () => requestSnapshot("raw-settled"))
  }, (error) => {
    record.states["rawSupervisor.spawnPromise"] = { status: "rejected", promiseID: record.objectID(originalPromise),
      error: record.errorFact(error) }
    record.event("raw-supervisor-spawn-rejected", record.states["rawSupervisor.spawnPromise"])
  }) // Observation branch; original spawn rejection remains unchanged and is consumed by facade.
  return originalPromise
}
record.event("host-identity", { host, parent, temporaryRoot: Global.Path.temporary,
  actualBunVersion: Bun.version, initialOwnerMetrics: ProcessSupervisor.metricsSnapshot() })
let handle
let target
let exitCode = 1
let outcomes
let nativeReady
let nativeHelper
let publicSettlementObservation
try {
  handle = await supervisedHostProcessFacade(owner, true).spawn({
    command: { executable: input.executable, args: [path.join(input.scriptRoot, "producer.mjs"), "--run-root", runRoot] },
    cwd: input.projectRoot, env: process.env, stdin: "ignore", stdout: "pipe", stderr: "pipe",
    ownership: "owned_tree", deadlineAt: input.deadlineAt, occurrenceID: input.facadeOccurrenceID,
  })
  if (!rawHandle) {
    record.event("raw-handle-observation-unavailable", { rawCallCount })
    for (const name of ["rawSupervisor.exited", "rawSupervisor.terminalFact", "rawSupervisor.outputSettled", "rawSupervisor.settled"])
      record.observe(name, undefined)
  }
  if (rawHandle) assert.equal(rawHandle.pid, handle.pid)
  if (request) {
    assert.equal(request.owner_pid, host.pid)
    assert.equal(request.owner_process_instance_id, host.processInstanceID)
    assert.equal(request.runtime_occurrence_id, host.occurrenceID)
    assert.equal(path.dirname(request.ready_file), path.dirname(request.settled_file))
    assert.equal(path.dirname(path.dirname(request.ready_file)), Global.Path.temporary)
    record.event("native-request-admitted-in-memory", { request,
      boundary: "Memory observation before native write, checked only after returned production handle; durable marker snapshot supplies independent facts" })
    nativeReady = readObservation(request.ready_file)
    nativeHelper = readObservation(path.join(path.dirname(request.ready_file), "helper.json"))
  }
  target = physical.observedProcessOccurrence(handle.pid)
  assert(target && physical.observeRuntimeProcessOccurrence(target) === "exact_live")
  if (nativeReady?.status === "present") {
    assert.equal(nativeReady.value.request_id, request.request_id)
    assert.equal(nativeReady.value.runtime_occurrence_id, host.occurrenceID)
    assert.equal(nativeReady.value.target_pid, target.pid)
    assert.equal(nativeReady.value.target_process_instance_id, target.processInstanceID)
  }
  record.observe("facade.terminal", handle.terminal, (value) => value)
  record.observe("facade.outputSettled", handle.outputSettled, () => undefined)
  record.observe("facade.settled", handle.settled, (value) => value, () => {
    // Observe this publication point before Host catch/finally and its later bounded metrics wait.
    publicSettlementObservation = {
      requestID: request?.request_id ?? null,
      rawSettlement: record.states["rawSupervisor.settled"] ?? { status: "unavailable" },
      requestDirectory: request ? readObservation(path.dirname(request.ready_file)) : { status: "unavailable" },
      ownerMetrics: ProcessSupervisor.metricsSnapshot(),
      observedAtUtc: new Date().toISOString(),
      boundary: "Original raw Promise outcome and exact request filesystem state at public settlement callback; no extra join or forced cleanup",
    }
    record.event("public-settlement-original-barrier-observed", publicSettlementObservation)
    requestSnapshot("public-settled-callback")
  })
  const drain = async (stream, destination, channel) => {
    assert(stream)
    let chunks = 0
    let bytes = 0
    for await (const chunk of stream) {
      chunks += 1
      bytes += chunk.byteLength
      record.event("native-drain-write-attempt", { channel, chunks, bytes, chunkBytes: chunk.byteLength })
      const writable = destination.write(chunk)
      record.event("native-drain-write-returned", { channel, chunks, bytes, writable })
      if (!writable) await once(destination, "drain")
    }
    return { chunks, bytes }
  }
  const stdoutDrain = drain(handle.stdout, process.stdout, "stdout")
  const stderrDrain = drain(handle.stderr, process.stderr, "stderr")
  record.observe("nativeExternal.stdoutDrain", stdoutDrain, (value) => value)
  record.observe("nativeExternal.stderrDrain", stderrDrain, (value) => value)
  outcomes = Promise.allSettled([handle.settled, stdoutDrain, stderrDrain])
  record.observe("nativeExternal.wholeAllSettled", outcomes, (values) => values.map((value, index) => ({
    name: ["facade.settled", "nativeExternal.stdoutDrain", "nativeExternal.stderrDrain"][index],
    status: value.status, ...(value.status === "rejected" ? { error: record.errorFact(value.reason) } : {}),
  })))
  requestSnapshot("actual-ready-before-shutdown")
  exclusiveJson(path.join(runRoot, "evidence", "host-ready.json"), {
    experimentID: input.experimentID, host, parent, target, owner, request, nativeReady, nativeHelper,
    durableRequest: durableRequestObservation(), deadlineAt: input.deadlineAt,
    facadeOccurrenceID: input.facadeOccurrenceID, rawHandleID: record.objectID(rawHandle), rawCallCount,
    publicHandleID: record.objectID(handle), observedAtUtc: new Date().toISOString(),
    boundary: "Public facade adapter and raw supervisor handle are different objects; output Promise aliases are recorded by IDs",
  })
  const result = await observeSettlement(outcomes, input.deadlineAt + 10_000, "Host whole three-branch settlement", record)
  const errors = result.flatMap((value) => value.status === "rejected" ? [value.reason] : [])
  if (errors.length) throw new AggregateError(errors, "Native Host physical/output/request settlement failed")
  const terminal = await handle.terminal
  exitCode = terminal.reason === "exited" ? terminal.exitCode ?? 1 : 1
  record.event("whole-settlement-fulfilled", { terminal, exitCode })
} catch (error) {
  record.event("host-observed-failure", { error: record.errorFact(error), states: record.states })
} finally {
  // Metrics observation only, never force-unregister, dispose, or claim terminal state from registry absence.
  const retirementDeadline = Math.min(input.deadlineAt + 10_000, Date.now() + 1_000)
  while ((ProcessSupervisor.metricsSnapshot().owners[owner]?.count ?? 0) && Date.now() < retirementDeadline) await pause(20)
  const metrics = ProcessSupervisor.metricsSnapshot()
  const ownerRetirement = { owner, remainingCount: metrics.owners[owner]?.count ?? 0,
    remainingPIDs: metrics.owners[owner]?.pids ?? [], observation: metrics.owners[owner] ? "retained" : "retired" }
  record.event("owner-retirement-observed", { owner, metrics,
    ...ownerRetirement, boundary: "Host registry only; no Task lease or Mission terminal claim" })
  requestSnapshot("before-host-exit")
  exclusiveJson(path.join(runRoot, "evidence", "host-final.json"), {
    experimentID: input.experimentID, host, parent, target, request, owner, exitCode,
    states: record.states, metrics, ownerRetirement, publicSettlementObservation, observedAtUtc: new Date().toISOString(),
    rawObservation: rawHandle ? { status: "available", handleID: record.objectID(rawHandle), pid: rawHandle.pid,
      originalSpawnPromiseID: record.objectID(capturedRawPromise), rawCallCount, requestID: request?.request_id ?? null }
      : { status: "unavailable", rawCallCount },
    targetPhysicalObservation: target ? physical.observeRuntimeProcessOccurrence(target) : "unavailable",
    boundary: "Pending/unavailable states stay unresolved. Observation window expiration keeps the original outcomes alive; actual failures/controlled uncertainty remain distinct from ordinary shutdown0",
  })
  ProcessSupervisor.spawnHostCommand = originalSpawn
  restoreRequestObserver()
}
// If a native output error is globally fatal before this point, its original stderr/OS exit survive in the controller.
// No stdout.error, uncaughtException, unhandledRejection or global swallowing listener is installed.
process.exit(exitCode)
