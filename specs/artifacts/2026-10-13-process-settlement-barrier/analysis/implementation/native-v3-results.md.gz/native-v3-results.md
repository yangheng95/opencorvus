# Native v3 original settlement observations

All five prepared scripts were checked with the exact installed Node executable, with each syntax exit0 preserved in native-v3/syntax-results.json and implementation/native-v3-*.syntax.log*. Root completely read the final five files and two inputs before separately authorizing each occurrence. Neither input was retried or replaced. Only owned Host/producer/parent processes and one post-settlement physical observer per run were started. There was no model, credential, user-window, UI automation, WSL (Windows Subsystem for Linux), VM (Virtual Machine) or Capsule operation.

Inputs retain the actual production Facade deadline45,000ms,65536-byte unique finite stdout tail and61-byte stderr tail. The Node controller uses the mature run-with-inactivity driver120,000ms with its original900,000ms execution budget. Observation-window notices keep awaiting the same original outcomes; they do not cause terminal, cancellation, restart or replacement. The ordinary single shutdown response is200 in both runs. Fault intervention is only destruction of this controller's original Host.stdout reader without an injected Error; stderr stays independent.

## Baseline

Original run C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/native-sink-baseline-01a133-v3, experiment3d423824-1112-4bdc-a8c7-0fc0da4e8197. Controller88100, Host81060 birthwin32:639275005988004170, Target85688 birthwin32:639275005997454617, requestf3505861-857d-47ad-9360-e4dd2e350aa4, supervisor-5GmdxJ. Numeric Host PID81060 happens to repeat a prior v2 PID; the birth identifies a different occurrence.

Actual driver/controller0, Host0, original Target exited0/terminalFact0 with signal:null. Every original raw/public/native branch and both external parent drains fulfilled. Original raw output and public output are the same Promise ID5; raw settlement ID6 completes before public ID8. At the public callback15:03:20.204Z, original raw settlement is fulfilled, that exact request directory is ENOENT, owner metrics live0. Parent receives all65536stdout and61stderr bytes and exact finite tail. Controller baselineQualification=true, originalBarrierQualification=true, rawRequestAssociation=true. These positive qualifiers include actual original raw outcomes and request cleanup; they are not inferred from Host exit alone.

The separately authorized same-run physical observer completed actual0 at15:08:00.650Z, and reports both exact original Host/Target births dead_or_reused plus the original request directory ENOENT. Driver/observer stdout, exact input and actual exit are native-v3-baseline-driver.log* and native-v3-baseline-observer.log*. These observations do not replace delivery/request facts.

## Closed stdout reader

Original run C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/native-sink-reader-01a133-v3, experimenta81f5548-2a7e-420c-9cc9-98fe3ff529d6. Controller87484, Host78584 birthwin32:639275011513871947, Target89136 birthwin32:639275011521632581, requestd53ec252-2746-4d23-82b4-aa6a5c00b996, supervisor-LVx9sB. Native helper89228 birthwin32:639275011521193771 is captured in the original durable marker journal.

Actual driver/controller1, Host1, original Target exited0 and terminalFact0 with signal:null. Host native stdout drain rejects original EPIPE/Error ref13, errno-4047/syscallwrite; leaving its original for-await source produces ABORT_ERR ref15 wrapped in the original Supervisor output Error ref14. Native stderr and parent stderr both deliver61bytes and fulfill. Parent stdout records original ERR_STREAM_PREMATURE_CLOSE ref5 and zero received bytes. Parent Host-exit and Host-close Promises fulfill with the actual exit1; fulfilled collection is not success of all collected members. Host AggregateError ref16 retains original members[ref14,ref13]. Complete stacks/cause/aggregate members and original source-file coordinates are native-v3-reader-causes.json; raw durable journals are unchanged.

Original Host journal order in UTC:

| Sequence | Time15:12:32 UTC | Original fact |
| --- | --- | --- |
|22|.606|Native stdout drain EPIPE ref13|
|24|.627|Raw output Promise ID5 rejects ref14|
|26|.629|Public output same Promise ID5/ref14|
|27|.631|Raw exited fulfills0|
|29–30|.634|Raw terminalFact and public terminal fulfill0|
|31|.636|Original raw settlement ID6 rejects ref14|
|32|.637|That original request directory observed ENOENT|
|33|.638|Public settlement ID8 rejects same ref14|
|34|.638|Public callback observes raw ID6 rejected, same request ENOENT, metrics live0|
|36|.640|Whole collector fulfills with separately rejected members|
|37|.640|Host preserves AggregateError ref16|
|38|.641|Original Host owner retirement observed|

The public callback occurs before Host catch/finally and any final metrics wait. It therefore supplies the new barrier qualification directly from the original raw Promise and original request; no extra cleanup or synthetic join was introduced. Controller originalBarrierQualification=true and rawRequestAssociation=true. Fault is preserved as actual failure1, with baselineQualification=false and root-review qualification, not rewritten ordinary0. The separately authorized same-run physical observer completed actual0 at15:15:26.999Z and reports the exact Host/Target births dead_or_reused and original request ENOENT. Original driver/observer logs are native-v3-reader-driver.log* and native-v3-reader-observer.log*.

## Evidence and limits

native-v3-observed-results.json is a derived read-only digest of the original two final reports, journals, parent exit receipts and physical observers; it names source run paths. Full original files remain under each run's evidence directory. Object reference IDs belong to one process and one occurrence only; they are not cross-process/cross-run identities. The producer's self-published occurrence UUID is separately recorded in producer-ready and shutdown response; an external observedProcessOccurrence UUID in Host/physical evidence must not be called the Target's self-generated identity.

These two occurrences qualify the current Windows Host owned-tree primitive's ordinary and real reader-error publication barriers. The existing positive adapter Task test qualifies its actual production adaptor against a local durable Task binding and original Promise causes; it is not natural Provider, Mission or Session end-to-end evidence. Inherit/MCP/browser destinations, actual Task/Mission/Session execution generations, retry/restart/recovery, parallel same-backend two-Project lifecycle, POSIX/detached transfer and Capsule/Linux cleanup remain the separate documented matrix. Phase B process-file preparation/cleanup and unresolved Linux runtime qualification remain open. The old Explorer before-failed AggregateError nested cause is still unknown; these new EPIPE facts do not retroactively identify it.
