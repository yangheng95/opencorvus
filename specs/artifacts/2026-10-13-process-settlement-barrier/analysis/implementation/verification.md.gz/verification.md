# Phase A implementation and verification

Owned scope only: five product files, six migrated factory test files, one new positive adapter contract test, and19-line removal of the discovered OCI UI automation branch. No specs, docs, Git index/commit, credentials, Capsule Phase B or unrelated product files were modified by this agent. preexisting.diff was empty for the12 old authorized files; preexisting-status preserves other owners' existing changes. Current tracked scope is thirteen paths, including the new positive test. Root owns docs, actual UI, archival and Git delivery.

Product changes require terminalFact/outputSettled/settled in the single Supervisor Handle contract; remove13 same-contract fallback uses across the five current producers/consumers; preserve the live childHandle joinPhysicalAndOutputSettlement primitive; replace the Host/Task public adaptor's early-reject Promise.all with allSettled plus existing ProcessSupervisor.combineFailures. A rejected undefined reason is preserved by status; original sole Error and distinct late causes are retained. Terminal receipt consumes only terminalFact. No new collector, lifecycle gate, output swallowing or implicit signal inference was introduced.

Six selected old test files migrate14 factories to the actual current stream/terminal/raw cleanup contract. closed output uses real finished(stream), pending cleanup remains pending and is finally released/joined, original errors are retained. Adjacent static contracts are reported separately in test-typecheck-repairs.md: await the declared asynchronous zip Writer.getData and preserve the existing source-file discriminator literal. OCI fixture removal is only its old Playwright page launch/goto/DOM branch; the non-UI runc/loopback and actual production browser paths remain. OCI tests were not run because their availability evaluation can enter unauthorized WSL and their current fixture does not qualify the production Capsule spawner.

## Original checks

Every named log has its exact executable/cwd/args/start input and original exit/end receipt alongside it. Bun executable is the fixed bun1.4.0 under .tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64 with its parent prepended to PATH. Official backend run-tests.ts retains its unchanged60000ms testcase, --parallel=1/file isolation,360000ms inactivity and900000ms per-file execution inputs.

| Check | Original result | Evidence |
| --- | --- | --- |
|New adapter test before product repair|2pass/3fail/14expect, exit1|adapter-before.log*|
|Official after nine selected files|81tests/140expect, all file exits0|focused-after.log*|
|Backend product typecheck, initial and final product state|exit0/0|typecheck-after.log*, typecheck-final.log*|
|Auxiliary disposal correction, original control-plane rerun|16pass/1fail/35expect, exit1; corrected auxiliary itself passed|control-plane-final.log*|
|Corrected selected-test typecheck with real installed node types and actual source ambient declarations|exit0|test-types-complete-config.log*|
|Real authority test after adjacent async ZIP helper repair|1pass/13expect, exit0|authority-after-zip-await.log*|
|Final control-plane after authorized original-ready/OS-root qualification|17pass/38expect, exit0|control-plane-os-root-final.log*|
|Selected-test typecheck for this final exact state|exit0|test-types-os-root-final.log*|
|Scoped diff whitespace check|exit0|actual tool output; final scoped-diff-check.log*|
|Native v3 baseline and same-run observer|actual driver0 / observer0|native-v3-baseline-driver.log*, native-v3-baseline-observer.log*|
|Native v3 reader fault and same-run observer|actual driver1 / observer0; Target0 and original barrier qualified|native-v3-reader-driver.log*, native-v3-reader-observer.log*|

The nine-file after count belongs to that earlier run, not a newly repeated suite. Only the subsequently changed authority helper/control-plane checker and selected test types were rerun. New5 adapter cases prove stable event order, original error identity, late cleanup multi-cause, successful original signal/receipt and the actual Task adaptor with local durable binding. No local fixture is claimed as UI/Provider/Mission end-to-end evidence.

## Background checker and tooling faults

Original background test had fixed250ms plus registry count1 before disposal and expected7 but returned1. Its original Target state and cancel instant were not captured; that original branch remains unknown. Source audit shows native Rust freezes GetExitCode after root signal and before Job active-zero collection, so there was no evidence to change production policy or expected7. Root recorded and authorized the exact positive checker repair after the full shared Host/Task normal/cancel audit in background-root-cancel-boundary.md.

The final checker captures the original request before spawn (restores on admission failure and all finally paths), binds actual protocol3 ready TargetPID/birth/request/runtime owner and helper birth, and uses the non-cached production OS observer to admit disposal only after dead_or_reused. unknown/window-insufficient is an explicit qualification error. Request-owner occurrence UUID is labelled as that owner source; it is not a fabricated Target self-identity. The final actual request96f9d982-fc6e-4e6d-a68d-41a26740bb55 links owner89756/runtime45a73409-25c0-44e7-a7e1-281a71d5ea82, Target84348 birthwin32:639275022797348739 and Helper87360 birthwin32:639275022796198659. Root observation dead_or_reused/helper exact_live and registered owner{count:1,pids:[84348]} are original recorded facts, not proof of individual descendant availability. Strict disposal returns7, actual terminal7/null and both output/rawsettled fulfill. There is no increased fixed delay, expected1, fake Promise, private lifecycle state or Rust/source change.

Preserved intermediate checker failures: control-plane-os-root.log* exit1 at captured request read; control-plane-os-root-holder.log* exit1 at readFile; control-plane-os-root-capture.log* exit1 establishes exact callbackCount1 and original ready_file string before toMatchObject, then ready_file/request_id become asymmetric matcher objects immediately after that assertion, followed by ERR_INVALID_ARG_TYPE. This is actual evidence for this assertion boundary, not a claim about all Bun versions or a retrospectively guessed cause. The repair passes assertion projections, preserving canonical request/ready/helper sources for filesystem/OS operations. Final logs record ready_file still string after validation. Their original bytes/input/exits are retained.

Original scratch typecheck failures are also preserved: test-types-final.log* TS2688 missing real node typeRoot; test-types-node-resolved.log* actual ambient omissions and selected helper contracts; test-types-os-root.log* unknown Record identity fields in typed expectations. The current scratch checker uses only actual installed declarations and guards real string identities; no replacement declaration or source compatibility fallback was introduced.

## Remaining qualification

See native-v3-results.md, native-v3-reader-causes.json and native-v3-observed-results.json for both real Native occurrences and all original raw/public/request/parent/physical/error evidence. These prove the specified owned Windows Host barrier branches. Old before-failed Aggregate nested causes, actual Capsule/Linux cleanup/preparation and crash recovery, inherit/MCP/browser sink destinations, natural Provider Task/Mission/Session execution and restart/parallel two-Project matrix remain explicitly open. Parent's real UI smoke remains separate and must not be inferred from these tests/types. No user process was killed or restarted. This agent has not staged or committed; parent must include the exact authorized paths in its reviewed delivery.
