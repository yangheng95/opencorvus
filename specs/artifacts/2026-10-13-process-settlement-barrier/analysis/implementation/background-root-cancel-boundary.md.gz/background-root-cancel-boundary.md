# Background natural root exit and later Job cancellation

Read-only additional analysis after the real control-plane-final.log failure. No further background instance, test readiness change or production change is authorized in this note. Parent root must record the analysis/spec before separately authorizing the exact positive checker repair. This is a shared normal/cancel boundary, not a flaky/local downgrade.

## Original failure and qualification

The first official nine-file after run passed81 tests/140 assertions including the original background case. Following the independent auxiliary fixture correction, the same control-plane file was run once:16 pass/1 fail,35 assertions, actual exit1. The auxiliary case itself passed. Failure is background case test/process-supervisor-control-plane.test.ts:47: expected7, received1 from strict dispose. Original full stdout/input/exit remain control-plane-final.log*. No fixed deadline was shortened; there was no observation timeout or recreated Native experiment.

That case admits a real Host shell `sleep 30 & exit 7` with terminateChildrenOnRootExit=false, sleeps250ms, sees registry count1 and calls strict dispose. Count1 is an ownership projection;250ms is elapsed time. Neither establishes the root's natural exit7 before cancellation. The failure lacks a captured original ready/helper/Target PID (Process Identifier)/birth timeline, so its exact cancel/exit branch is still unknown. Passing the earlier same case or either Native v3 ordinary producer cannot fill this gap.

## Actual shared Windows mechanism

Rust native/process-supervisor/src/main.rs:729–741 publishes original ready protocol3 Target PID+process_instance_id before ResumeThread. The helper retains the actual Target process HANDLE and its exact Job object, not a recycled numeric PID. run_request:753–780 waits original Target20ms: a signaled result breaks first. Only an unsignaled Target proceeds to owner-death/cancel-file handling and terminate_job_once. That function:468–478 invokes TerminateJobObject(job,1) once; a Target still alive at cancellation can therefore correctly exit1.

After the Target is signaled, GetExitCodeProcess:781–790 freezes its original code. Only then :791–803 applies foreground root-exit policy and waits Job active-process-zero. Background false retains descendants until ordinary cancellation/owner death in wait_for_job_active_process_zero:481–498. That later Job kill does not assign or overwrite `code`; publish_settlement_marker804 and Ok(code)806 return the frozen original value. Thus source logic preserves an already exited root7 across later descendant cancellation. A GetExitCodeProcess/wait/marker failure is a separately surfaced helper error, not a guessed natural root result. The old failure has insufficient original facts to exclude such branches, even though strict disposal returned a number.

Supervisor spawnWindowsShell1542–1557 and spawnWindowsCommand1560–1579 share this one request/helper path and emit the flag only for true. Native Ready admission verifies the requested policy; helperExited/exited1845–1855 validates durable active-zero proof before exposing exit. dispose/cancel1706–1722/1900 onward requests the original request cancel file and joins original helper exit; it does not implement a second root-code rewrite. Strict dispose1271 allSettled-collects dispose/exited/output/settled. Original settlement1940 joins request cleanup and keeps output errors. The Phase A public error barrier change does not select natural-vs-cancel root code.

## Complete policy / authority audit

| Production entry | Root policy / actual owner | Current evidence |
| --- | --- | --- |
| Supervisor Host Shell360 / Command463 | original caller option, default false | same Windows helper; original failing background case entered Host Shell false |
| Supervisor Task Shell325 / Command422 / Gated364 | canonical binding + Task read lease; forwards native opts | same native helper when native; Capsule is a different Linux owner, still unresolved Phase B |
| Host Gated Shell414 | original option, same command/helper | same target code/Job mechanism |
| Shell.runHost188/runTask198 | runWithSpawner108 true | real foreground root7/control-plane and deadline tests passed; does not prove background cancel order |
| Shell.launchHost377/launchTask387 | launch opts250–257 omit flag, current false | background owner retained; lease/deadline disposal independent of root-exit receipt |
| Bash384/385 | !params.background at381 | foreground true, background false, Host/Task native same helper; direct raw Supervisor, not adapter error barrier |
| Session shell-exec583/588 | true at512 | gated Host/Task foreground, strict final cleanup |
| Shared Facade69/70 | explicit Host policy; Task facade125 false | Task production callers use run/finally strict dispose; local Task adapter positive test only, not natural Task E2E |
| Plugin/Process/inactivity | Host explicitly false except chosen foreground capability | public spawn/run vary in completion owner; original root-code mechanism unchanged |
| Browser/MCP/ripgrep/codebase/file-broker/package tools | command opts normally omit flag/current false | same original native owner, per-caller disposal/output contracts; no new natural/cancel run of every consumer |
| Supervisor POSIX child2015–2017 | root fact first, optional foreground terminate then normalized code | source order preserves root fact; no new cross-platform actual run |
| Node owned_process/detached and restart detached | separate Node adapter / native transfer authority | retain original meaning; do not use ordinary background data to qualify transfer or inherit destinations |

Task registry1217 and read leases349/403/452 wait original exited plus settled. Native background exited is helper/tree settlement, not a separate early root-only exit. Thus waiting Handle.exited to decide when to dispose can wait the30-second descendant and defeat this positive checker. Mandatory cancellation608, auxiliary632 and checkpoints678 use original physical/strict owners; none treats250ms as Task terminal authority. Task lifecycle and retry status are decided from durable occurrence/control facts, not root exit number alone. Fresh requests/Task occurrence and unique request files prevent reusing the first case as retry evidence. Orphan/restart source preserves exact original request/owner birth and live/unknown dispositions; no fresh actual recovery or two-Project cancellation run is claimed.

## Minimal positive checker proposal

Preserve the original real shell/background policy and expected natural code7. No fake Promise, increased fixed sleep, changed expected1, synthetic error or private lifecycle state is needed.

1. Before this one spawn, install the existing Windows request observer solely to capture the original request in memory. Save/restore its previous observer in finally. The official per-file runner is isolated and --parallel=1; no user process/global listener is involved. Do not assert, read files or alter controls inside the admission callback.
2. After the actual Handle is returned, read that original ready.json and helper.json. Validate protocol3, request_id/runtime owner, Target PID===Handle.pid, original Target birth string, helper PID/birth and terminate_children_on_root_exit=false. The Target can already be dead when returned; do not replace missing observedProcessOccurrence(handle.pid) with a guessed birth. Use the actual native Ready birth.
3. Construct only a **labelled external observation** coordinate for the original Target PID/birth. Its UUID is this checker's observation identity, not a fabricated Target self-generated runtime UUID. Record native Ready source, exact request and observation role. If direct live OS birth is available, it must agree with Ready; a query failure remains unknown, never authority from a bare PID.
4. With one finite observation deadline, repeatedly call production observeRuntimeProcessOccurrence on that original birth until the positive `dead_or_reused` result. Polling may use20ms intervals, but elapsed time is not the oracle. unknown_live stays unknown; deadline produces an explicit recorded error, not skip/success. Do not await Handle.exited for this readiness condition.
5. At that positive root fact, capture current registry owner count/pids and exact helper birth `exact_live`, request identity and original ready facts. Those establish retained owned helper/registration; they are not a fake active-process count or a claim that every descendant has been independently observed. Only now call original strict dispose, assert returned7, join output/settled, and record real native physical/request/owner final facts. Consume or deliberately drain the original stdout/stderr so output delivery itself is truthful.
6. Finally strictly dispose only the admitted owned Handle if needed and restore the observer even on a check failure. Retain full first error/cause and cleanup outcomes. The original failed log stays independent; new7 would verify the intended after-dead-root behavior, not retroactively identify the old cancel instant.

This uses current helper preservation logic and repairs an unsound checker precondition. If the new correctly bound real case still returns1, preserve its original target/helper/request/OS facts and expand the product root-cause plan before any source change. Do not infer that an earlier passed9-file run excludes shared order/race paths. Real Task/Mission/Session epochs, inherited sink failures, restart and same-backend multi-Project cancellation remain their explicitly unrun matrix.
