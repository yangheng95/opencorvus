const fs=require('node:fs'),path=require('node:path'),zlib=require('node:zlib'),assert=require('node:assert/strict');
const scratch=path.resolve('.tmp-product-iteration/source-navigation-410');
const output=path.resolve('specs/artifacts/2026-10-14-source-navigation');
const nativeBase='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14';
fs.mkdirSync(output,{recursive:true});
for(const name of fs.readdirSync(scratch)){
 if(/^\d\d-.*\.jpg$/.test(name)||['actual-side-chats.json','actual-side-chats-after.json','scroll-observations.json','focus-before-fix.json','focus-after-fix.json','clipboard-after-observation.json','data-facts.json','prepared.json'].includes(name))fs.copyFileSync(path.join(scratch,name),path.join(output,name));
 if(name.endsWith('.log'))fs.writeFileSync(path.join(output,name+'.gz'),zlib.gzipSync(fs.readFileSync(path.join(scratch,name))));
}
for(const name of ['push-receipt.log','push-receipt-exit.json']){
 const src=path.resolve('.tmp-product-iteration/command-search-409',name);
 if(name.endsWith('.log'))fs.writeFileSync(path.join(output,'previous-'+name+'.gz'),zlib.gzipSync(fs.readFileSync(src)));
 else fs.copyFileSync(src,path.join(output,'previous-'+name));
}
const runs=[];
for(const [name,handle] of [['before',32933],['after',29447]]){
 const dir=path.join(nativeBase,'source-navigation-410-'+name,'evidence');
 const dest=path.join(output,'native-'+name);fs.mkdirSync(dest,{recursive:true});
 const read=name=>JSON.parse(fs.readFileSync(path.join(dir,name),'utf8').replace(/^\uFEFF/,''));
 for(const file of ['preflight-ready.json','native-host-ready.json','native-host-settled.json','physical-terminal-and-pair-cleanup.json','public-shutdown.json'])fs.copyFileSync(path.join(dir,file),path.join(dest,file));
 const latest=fs.readdirSync(dir).filter(x=>x.startsWith('provider-')&&x.endsWith('.json')).map(file=>({file,data:read(file)})).filter(x=>Array.isArray(x.data.requests)&&typeof x.data.observedAt==='string').sort((a,b)=>Date.parse(a.data.observedAt)-Date.parse(b.data.observedAt)).at(-1);
 assert.ok(latest);
 fs.copyFileSync(path.join(dir,latest.file),path.join(dest,'provider-final.json'));
 const ready=read('preflight-ready.json'),settled=read('native-host-settled.json'),cleanup=read('physical-terminal-and-pair-cleanup.json');
 assert.equal(ready.preflight.credential,'usable');assert.equal(ready.preflight.catalog,'projected');assert.equal(ready.preflight.actualModel,'gpt-6.1-sol');
 assert.equal(settled.physicalCompletion,true);assert.equal(settled.outputDrainComplete,true);assert.equal(settled.requestCleanupComplete,true);assert.equal(settled.terminal.exitCode,0);assert.equal(cleanup.pairedCleanupComplete,true);
 const requests=latest.data.requests.map(r=>{
   assert.equal(r.model,'gpt-6.1-sol');assert.equal(r.streaming,true);assert.equal(r.status,200);assert.equal(r.response_reader.terminal.kind,'eof');
   return {model:r.model,status:r.status,streaming:r.streaming,reader:r.response_reader};
 });
 runs.push({name,occurrence:ready.occurrence,pid:ready.pid,preflight:ready.preflight,requests,originalHandle:handle,originalHandleExitCode:0,handleEvidence:'Original tool execution joined during this manual qualification; native original settlement is preserved separately.',pairedCleanupComplete:true});
}
const data=JSON.parse(fs.readFileSync(path.join(scratch,'data-facts.json'),'utf8'));
const original=JSON.parse(fs.readFileSync('.tmp-product-iteration/source-reading-405/data-facts.json','utf8'));
assert.deepEqual(data.databaseVersion,[{user_version:1}]);
assert.deepEqual(data.sessions,original.sessions);
assert.deepEqual(data.sources,original.sources);
assert.deepEqual(data.messages,original.messages);
assert.deepEqual(data.tools,original.tools);
const facts={runs,originalSourceSessions:data.sessions,sourceCount:data.sources.length,messageCount:data.messages.length,toolCount:data.tools.length,originalHistory:'Exact canonical identities, URL/path, Source-to-Tool bindings, completed Tool outcomes and message facts equal the retained real 405 history.',boundary:'Real SQLite/provider/native facts only; visual and keyboard observations were reviewed manually, without UI automated assertions.'};
fs.writeFileSync(path.join(output,'checked-facts.json'),JSON.stringify(facts,null,2)+'\n');
console.log(JSON.stringify({runs:runs.map(r=>({name:r.name,pid:r.pid,requests:r.requests.length,physicalCompletion:true,pairedCleanupComplete:true})),sourceSessions:data.sessions.length,sourceCount:data.sources.length,messages:data.messages.length,result:'passed'}));
