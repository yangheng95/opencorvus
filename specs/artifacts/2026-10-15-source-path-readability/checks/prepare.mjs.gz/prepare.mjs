import fs from 'node:fs'
const phase=process.argv[2]
if(!['before','after'].includes(phase))throw Error('Explicit phase required')
const root='.tmp-product-iteration/source-path-readability-429',tag='source-path-readability-429-'+phase,port=phase==='before'?18583:18585
const base='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-15',bundle=base+'/'+tag+'-bundle/bin'
if(fs.existsSync(bundle))throw Error('Fresh native publication required')
fs.mkdirSync(bundle,{recursive:true});fs.copyFileSync('.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64/bun.exe',bundle+'/bun.exe');fs.cpSync('packages/overlay/dist-vite',bundle+'/ui',{recursive:true})
fs.mkdirSync(root+'/'+phase,{recursive:true})
for(const name of ['launch.ps1','settle.ps1','shutdown.ps1']){
 let source=fs.readFileSync('.tmp-product-iteration/source-member-review-425/before/'+name,'utf8')
 source=source.replaceAll('source-member-review-425-before',tag).replaceAll('.tmp-product-iteration/source-member-review-425/before',root+'/'+phase).replaceAll('18571',String(port))
 fs.writeFileSync(root+'/'+phase+'/'+name,source)
}
if(phase==='before'){
 for(const [name,source] of [['SourceParts.tsx.before','packages/overlay/src/components/SourceParts.tsx'],['messages.css.before','packages/overlay/src/styles/surfaces/messages.css'],['en-US.json.before','packages/overlay/src/i18n/en-US.json'],['zh-CN.json.before','packages/overlay/src/i18n/zh-CN.json']]){
  if(fs.existsSync(root+'/'+name))throw Error('Original source already preserved');fs.copyFileSync(source,root+'/'+name)
 }
 const artifact='specs/artifacts/2026-10-15-source-path-readability';fs.mkdirSync(artifact,{recursive:true});fs.writeFileSync(artifact+'/README.md','# Sources路径辨识证据\n\n[方案与Recall](../../records/2026-10/2026-10-15-source-path-readability.md)。真实Source页面与原文件身份，结果在执行后补齐；无凭据或UI自动化。\n')
 for(const [file,line] of [
  ['specs/README.md','- [Sources路径辨识](records/2026-10/2026-10-15-source-path-readability.md)：原文件身份、特殊空白与真实阅读体验。'],
  ['specs/records/2026-10/README.md','- [Sources路径辨识](2026-10-15-source-path-readability.md)：实际前后截图及原路径打开/复制语义。'],
  ['specs/artifacts/README.md','- [Sources路径辨识](2026-10-15-source-path-readability/README.md)：真实页面、原文件及物理收尾。'],
 ]){const text=fs.readFileSync(file,'utf8');if(text.includes(line))throw Error('Already indexed');fs.writeFileSync(file,text.trimEnd()+'\n\n'+line+'\n')}
}
console.log(JSON.stringify({phase,port,tag,budget:'600s / 180s inactivity / 12 streams',qualification:'NativeService history reader'}))
