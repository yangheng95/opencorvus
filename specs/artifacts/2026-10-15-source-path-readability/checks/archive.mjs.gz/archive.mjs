import fs from 'node:fs'
import path from 'node:path'
import zlib from 'node:zlib'
import assert from 'node:assert/strict'
const root=import.meta.dirname,dest=path.resolve('specs/artifacts/2026-10-15-source-path-readability')
const save=(name,bytes)=>{const target=path.join(dest,name);fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,zlib.gzipSync(bytes))}
const before=JSON.parse(fs.readFileSync(root+'/material-before.json','utf8'))
const after=JSON.parse(fs.readFileSync(root+'/original-material.json','utf8'))
assert.deepEqual(after.files,before.files)
assert.deepEqual(after.sources,before.sources)
assert.equal(after.sources.length,7)
assert.equal(after.version.user_version,2)
const scopes=[]
for(const phase of ['before','after']){
 const evidence=`C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-15/source-path-readability-429-${phase}/evidence`
 const clean=JSON.parse(fs.readFileSync(evidence+'/physical-terminal-and-pair-cleanup.json','utf8'))
 const native=JSON.parse(fs.readFileSync(evidence+'/native-host-settled.json','utf8'))
 assert.equal(clean.physicalCompletion,true);assert.equal(clean.pairedCleanupComplete,true)
 assert.equal(native.terminal.exitCode,0)
 const audits=fs.readdirSync(evidence).filter(name=>/^provider-.*\.json$/.test(name)&&name!=='provider-pair-staging.json').map(name=>({name,value:JSON.parse(fs.readFileSync(evidence+'/'+name,'utf8'))})).filter(entry=>Array.isArray(entry.value.requests)).sort((a,b)=>b.value.requests.length-a.value.requests.length||Date.parse(b.value.observedAt)-Date.parse(a.value.observedAt))
 const last=audits[0];assert(last)
 const requests=last.value.requests.map(({model,streaming,status,response_reader})=>({model,streaming,status,response_reader}))
 for(const request of requests){assert.equal(request.model,'gpt-6.1-sol');assert.equal(request.streaming,true);assert.equal(request.status,200);assert.equal(request.response_reader.state,'settled')}
 for(const name of ['native-host-ready.json','native-host-settled.json','physical-terminal-and-pair-cleanup.json','preflight-ready.json','provider-pair-staging.json','public-shutdown.json','launcher-child-exit.json'])save(phase+'/'+name+'.gz',fs.readFileSync(evidence+'/'+name))
 save(phase+'/provider-summary.json.gz',JSON.stringify({source:last.name,requests},null,2))
 for(const name of ['launch.ps1','settle.ps1','shutdown.ps1','launch.log'])save(phase+'/'+name+'.gz',fs.readFileSync(root+'/'+phase+'/'+name))
 scopes.push({phase,requestCount:requests.length,terminal:native.terminal,physicalCompletion:clean.physicalCompletion,pairedCleanupComplete:clean.pairedCleanupComplete})
}
for(const name of fs.readdirSync(root)){
 const file=path.join(root,name)
 if(fs.statSync(file).isFile()&&/\.(ts|mjs|json|log|before)$/.test(name))save('checks/'+name+'.gz',fs.readFileSync(file))
}
const result={at:new Date().toISOString(),sources:after.sources.length,originalFileCount:after.files.length,sourceIdentity:'Original source IDs, paths, titles and ranges and actual original file contents matched the before read',scopes,screenshots:fs.readdirSync(dest).filter(name=>name.endsWith('.jpg')),clipboard:'Actual Copy feedback observed, session clipboard read returned empty; original clipboard payload remains unqualified',reload:'Reload opened project landing; original conversation was explicitly reselected; screenshot 13 is partially covered by its sidebar tooltip'}
fs.writeFileSync(root+'/review-result.json',JSON.stringify(result,null,2));save('checks/review-result.json.gz',JSON.stringify(result,null,2))
console.log(JSON.stringify(result,null,2))
