import { preparePackageBuildEnvironment } from "../../script/package-build-environment"
const env = await preparePackageBuildEnvironment(process.cwd(), process.env)
console.log(JSON.stringify({ buildRuntime: env.OPENCORVUS_HOME, command: "bun run --cwd packages/overlay build" }))
const child = Bun.spawn({
  cmd: [process.execPath, "run", "--cwd", "packages/overlay", "build"],
  cwd: process.cwd(), env, stdin: "ignore", stdout: "inherit", stderr: "inherit",
})
const exitCode = await child.exited
console.log(JSON.stringify({ exitCode }))
process.exit(exitCode)
