import fs from "node:fs"
import path from "node:path"
import assert from "node:assert/strict"
import { Database } from "bun:sqlite"
const root=import.meta.dir,project="C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/member-live-rendering-412-fresh/project"
const material=JSON.parse(fs.readFileSync(path.resolve(root,"../literal-reference-click-423/material.json"),"utf8"))
const files=material.files.map((file:any)=>{
 const content=fs.readFileSync(path.join(project,file.path),"utf8")
 assert.equal(content,file.content)
 return {path:file.path,codePoints:[...file.path].map(char=>char.codePointAt(0)),content}
})
const reference=JSON.parse(fs.readFileSync(path.resolve(root,"../literal-reference-click-423/facts-current.json"),"utf8"))
const sessionID=reference.sessions[0].id
const db=new Database(path.resolve(project,"../runtime/data/opencorvus.db"),{readonly:true})
db.exec("PRAGMA busy_timeout=5000")
const sources=db.query("SELECT p.id,p.message_id,p.data FROM part p JOIN message m ON m.id=p.message_id WHERE m.session_id=? AND json_extract(p.data,'$.type')='source-file' ORDER BY p.time_created,p.id").all(sessionID).map((row:any)=>{
 const part=JSON.parse(row.data)
 return {id:row.id,messageID:row.message_id,sourceId:part.sourceId,path:part.path,title:part.title,range:part.range}
})
const version=db.query("PRAGMA user_version").get();db.close(true)
const receipt={at:new Date().toISOString(),project,sessionID,version,files,sources,boundary:"Read-only original 423 Source identities and actual unchanged file bytes; no synthetic message or UI assertion"}
fs.writeFileSync(root+"/original-material.json",JSON.stringify(receipt,null,2))
console.log(JSON.stringify(receipt,null,2))
