import fs from "node:fs"
import { Database } from "bun:sqlite"
const filename = "C:/Users/hengu/AppData/Local/opencorvus/data/opencorvus.db"
const sqlite = new Database(filename, { readonly: true })
try {
  const version = sqlite.query("PRAGMA user_version").get()
  const metadata = fs.statSync(filename)
  const baseline = fs.readFileSync("packages/opencorvus/src/storage/migrations/0001-baseline.sql", "utf8")
  const second = fs.readFileSync("packages/opencorvus/src/storage/migrations/0002-grant-decision-index.sql", "utf8")
  const receipt = { observedAt: new Date().toISOString(), filename, version, size: metadata.size, mtime: metadata.mtime.toISOString(), declaredPhysicalDdlEqual: baseline === second, boundary: "Raw read-only SQLite inspection; product runtime and migration code were not imported" }
  fs.writeFileSync(import.meta.dir + "/schema-status.json", JSON.stringify(receipt, null, 2))
  console.log(JSON.stringify(receipt, null, 2))
} finally { sqlite.close(true) }
