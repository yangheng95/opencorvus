import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import {gzipSync,gunzipSync} from 'node:zlib'
import {execFileSync} from 'node:child_process'
const root='.tmp-task-git-question-reconnect-404', archive='specs/artifacts/2026-10-14-task-git-question-reconnect-404'
const group='completion', capture=root+'/public-completion-capture01'
assert(!fs.existsSync(capture)&&!fs.existsSync(archive+'/'+group),'Keep original captures')
const allowed=/\.(json|jsonl|jsonc|mjs|cjs|ts|tsx|md|txt|log|csv|exit|patch|jpg|ps1|toml)$/
const skip=new Set(['project','public-project','runtime','owned-data','node_modules','.git','bootstrap-project','ui-after','ui-before','native-sol-assets'])
function walk(dir){return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?(skip.has(e.name)||e.name.startsWith('git-read-')?[]:walk(path.join(dir,e.name))):allowed.test(e.name)?[path.join(dir,e.name)]:[])}
const groups=['implementation','question-implementation','frontend','sdk-before','sdk-final01','sdk-final02','session-local-projection','question-empty-expiry01','question-empty-expiry01-relay','task-git-public01','task-git-public02',...Array.from({length:7},(_,i)=>'question-crash-red-0'+(i+1))]
const files=groups.flatMap(dir=>walk(root+'/'+dir))
const reports=['manual-extra-facts.json','check-empty-expiry.ts','manual-empty-expiry-driver.ts','manual-empty-expiry-server.ts','task-git-driver.ts','task-git-server.ts','task-git-facts.ts','task-git-control.mjs','task-git-profile-review.md','task-git-public-harness-plan.md','question-crash-recovery-review.md','question-crash-recovery-source-evidence.json','question-crash-results-and-minimal-contract.md','question-crash-final-facts.json','task-question-recovery-authority-review.md','native-cwd-boundary-readonly.md','sdk-runner.ts','formal-runner.ts','question-formal-runner.ts','freeze-completion.mjs']
for(const name of reports)files.push(root+'/'+name)
for(const suffix of ['launch.json','physical-terminal.json','relay-config.json','relay-launch.json','relay-physical-terminal.json','relay-stdout.log','runtime-owner.json','stderr.log','stdout.log'])files.push(root+'/question-empty-expiry01.'+suffix)
const patterns=[/\bsk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{24,}\b/g,/\b(?:ghp|gho|ghu|ghs|github_pat)_[A-Za-z0-9_]{20,}\b/g,/\bBearer\s+[A-Za-z0-9._-]{24,}\b/g,/-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/g]
let fixtures=0,texts=0,jpegs=0
const inputs=[...new Set(files)].sort().map(source=>{
 assert(!/(^|[\\/])(auth|models)\.json$/.test(source),'Private pair excluded')
 const bytes=fs.readFileSync(source)
 if(source.endsWith('.jpg')){assert.equal(bytes[0],255);assert.equal(bytes[1],216);jpegs++}
 else{const text=bytes.toString('utf8');assert(Buffer.from(text).equals(bytes));texts++;for(const p of patterns){p.lastIndex=0;assert.equal([...text.matchAll(p)].length,0,'Credential family: '+source)}fixtures+=(text.match(/apiKey\s*(?:"\s*:|:)\s*["']local-controlled-provider["']/g)||[]).length}
 return {source,bytes,relative:path.relative(root,source).replaceAll('\\','/')}
})
const entries=[]
for(const {source,bytes,relative} of inputs){
 const original=capture+'/'+relative,destination=archive+'/'+group+'/'+relative+(source.endsWith('.jpg')?'':'.gz')
 fs.mkdirSync(path.dirname(original),{recursive:true});fs.writeFileSync(original,bytes,{flag:'wx'})
 fs.mkdirSync(path.dirname(destination),{recursive:true});fs.writeFileSync(destination,source.endsWith('.jpg')?bytes:gzipSync(bytes),{flag:'wx'})
 const retained=source.endsWith('.jpg')?fs.readFileSync(destination):gunzipSync(fs.readFileSync(destination))
 assert(retained.equals(fs.readFileSync(original)))
 entries.push({originalSource:source,capturedSource:original,archive:destination,bytes:bytes.length,format:source.endsWith('.jpg')?'original JPEG':'gzip of original bytes'})
}
const boundary='Identity of immutable original public captures only. No source digest, functional, UI or Task-completion verdict. Task crash red03 stays failed; controlled local Provider is not GPT-6.1 Sol.'
fs.writeFileSync(archive+'/completion-manifest.json',JSON.stringify({capturedAt:new Date().toISOString(),head:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),boundary,entries},null,2),{flag:'wx'})
const result={validatedAt:new Date().toISOString(),entries:entries.length,texts,jpegs,fixtureAssignments:fixtures,credentialFamilyHits:0,originalBytes:entries.reduce((n,x)=>n+x.bytes,0),boundary}
fs.writeFileSync(archive+'/completion-archive-check.json',JSON.stringify(result,null,2),{flag:'wx'})
console.log(JSON.stringify(result))
