# 404 public01 profile failure — read-only diagnosis and fresh input proposal

## Scope and preserved facts

Root public01 admitted real Task `tsk_g00VXyNpAy00jyiGA5rx` under product PID 69264 / original NodeProcess occurrence `f275910e-59dc-49a9-a39d-1e5879573265`. Original start 1791931933084, deadline 1791932533084, closeBy 1791932473084. Baseline checker `da3bfd63-1f28-487e-92e6-2cad492b4484` physically joined exit 0; original cwd was 219 UTF-8 bytes, Git directory 224, and original 35 CSV bytes were read from the real baseline commit. These are actual Root/checker facts, not inferred from a later helper source.

The Task subsequently failed before any Task Provider business request: exact failure `Active expert squad projects default MCP server default/mcp/browser, which configuration has disabled.` Root reported original terminal 1791931951561. Current public01 terminal/driver files confirm original service exit 1, physical/output joined, all Provider stop awaits, and original parent runtime cleanup at 1791932077099. This exit 1 is the correct preserved unfinished baseline/read/cancel scenario: the Task was failed, not user-cancelled. Do not release or reuse it and do not backfill Tool success.

Only source/public logs were read for this report. No service/Provider, model, browser, DB opening, test, source/SDK edit or delegation. Original `task-git-public01/helper-source` is preserved. AGENTS, scope spec and existing profile/resolver contracts were reread; source status remains mixed with other authorized tasks and untouched.

## Exact fixture conflict

The copied 403 `phaseBConfig()` intentionally supplies both `mcp.browser={enabled:false}` and `mcp.computer={enabled:false}`, plus `prompt_profile.active='base'`. The first Task helper also explicitly sets body `promptProfile:'base'`. Public01's `public-global-config.json` proves these actual values reached the server.

Current Base `src/expert-squad/builtin/base/expert-squad.jsonc:18-43` declares a package capability set containing 17 exact `default/mcp/browser/tool/*` references. Scheduler lines 45-67 consumes that set; Base Developer and Tester consume it as well. This is Base's actual capability assignment, not merely inventory or a tool the model chose to use.

`prompt-profile-resolver.ts:1112-1135 defaultMcpServersForRefs` resolves those exact configured servers. Missing declaration is an explicit error. A browser declaration without `type` is the current disabled configuration shape and throws the exact observed error at 1128. Computer has its own enabled-declaration validator. `resolveSchedulerCapabilityForContext:1403-1437` materializes the manifest and reaches that check before Provider execution. There is no intended fallback that removes unavailable projected tools.

Therefore leaving Base selected while disabling its assigned Browser MCP is an invalid helper configuration. The legal resolution is choose a complete existing profile whose declared capabilities match this explicitly read-only CSV exercise, or provide Base's real configured browser. This narrow harness should use the former; it must not alter Base's manifest, inject reduced package capabilities, override Task metadata, enable/control the user's browser, or treat the failed Task as Git failure.

## Recommended exact existing profile

Use existing embedded `research-studio` **for both** the global active selection and Task immutable body selection:

```ts
const taskProfile = 'research-studio'
const config = phaseBConfig(seedProvider.apiURL)
config.prompt_profile.active = taskProfile
// Existing synthetic Provider IDs/models and disabled MCP declarations unchanged.
const taskRequest = { /* same genuine input and model */, promptProfile: taskProfile }
```

This value is the normal creator-selected public identity. It is not another expert package or a metadata override. Keep `productPillar:'work'`, exact actual GlobalProject directory, unique `task-fixture/session-prompt-owner-model`, Ask policy and all original long-path/input/owner contracts unchanged. The CSV request is a bounded data/source inspection, within the research profile's stated surface; this exercise does not claim completion of its full research-report workflow.

Complete source basis:

- `builtin/research-studio/expert-squad.jsonc:27-38`: scheduler explicitly has `read`, existing `orchestrator-base`, `scheduler-transport`, `dispatch_agent` and platform `browser_preview_capture`.
- Its five worker projections at 39-92 are Planner (`delegated-worker-base`), Researcher (`deep-research-base`), Analyst (`delegated-worker-base` + package Skill), Fact Checker (`fact-check-base` + same package Skill), Writer (`build-base` + package Skill + platform `design-taste-frontend`). Entire manifest has no MCP capability ref. Its only package capability set (18-25) contains one package Skill.
- `agent/platform-capability-sets.ts:17-39,51-81` creates every platform set member via `toolRef`, explicitly `kind:'tool', source:'platform', owner_ref:'tool-registry'`. These sets cannot implicitly expand into `mcp_tool`, `mcp_prompt`, `mcp_resource` or a default MCP declaration. The worker transport also consists of platform Tool refs.
- `expert-squad/capability-grants.ts:77-127,181-224` classifies platform Tool leaves separately from default MCP leaves; materialization does not treat a platform Tool with browser in its name as a default Browser MCP ref.
- `prompt-profile-resolver.ts:518-525` universal-build only declares platform build-base. `resolvePackageCapabilitySet:1765-1777` evaluates the scheduler, universal-build, and all five workers; therefore this review covered the whole resolved capability set rather than only read's immediate scheduler.
- `builtin/index.ts:138-157` embeds Research Studio and its complete Skill/template/schema closure. Writer's default design Skill is present in `skill/builtin-payload.ts` and is product-maintained, distinct from the external skill scanning that the fixture disables. This is source evidence, not a new current HTTP preflight result.
- `includeMcpTools:false` in the resolved scheduler/worker objects is the normal exact manifest projection contract, not a proposed suppression patch.
- Platform `browser_preview_capture` is its own Tool contract; it is not `default/mcp/browser`. It remains declared unchanged. This read-only controlled Provider emits only its real read call; no browser preview is called by the harness, and no full research visual-delivery qualification is claimed.
- Frozen 402 Scope08's actual `task-create-request.json` used `promptProfile:'research-studio'` and did reach a real read Permission. That is corroboration only: its external target later failed the Task root boundary and it never proved a complete Task.

## General skills/mounts/catalog 500: exact same source, not inferred parent Git

Public01 `stderr.log` has exact request IDs and stacks:

- Line 356, request `51e7608f-3b03-4b8f-8efe-2ee68a4be775`, `GET /skill/mounts`, status 500: `defaultMcpServersForRefs:1128` → `resolveSchedulerCapabilityForContext:1433` → `resolvePackageCapabilitySet:1773` → `resolveSkillProjectionForContext:2566` → `SkillMount.matrix:476` → `server/routes/skill.ts:71`.
- Line 377, request `4fc2acac-aca9-474a-8178-036e1a38c014`, `GET /expert-squad/catalog`, status 500: same resolver failure → `catalog:3385` → `resolvedCatalog:308` (project config) → route.
- Lines 429/449 repeat this for the selected actual long Task directory, including the Session-specific catalog branch `resolvedCatalog:323`. Overlay's two explicit directory/error facts appear at 410 and 451; both bootstrap and real Task directory failed on the same browser declaration.
- `GET /mission-skill/catalog` returned 200 separately (log 283/445); do not label all catalogs broken.

Source `SkillMount.matrix:456-485` picks active config or exact Task package revision, then resolves the entire capability set before assembling rows. `expert-squad` project catalog branch uses `Config.get()` and its active profile; Session branch uses EffectiveConfig plus Task frozen revision. Thus changing **only Task body** would leave General/project active Base invalid and preserve 500. Both public global active and Task creator profile must agree on Research Studio from the start of a fresh scope. The stack is conclusive for these observed requests; there is no need to guess a parent Git discovery cause or claim every future 500 shares this cause.

## Proposed helper-only delta and fresh verification (not yet applied)

Only `task-git-server.ts` needs the profile input delta above; preserve public01 source copies and every original failure. Recommended additionally record public positive readiness reads after PATCH config / accepted GlobalProject and before Task POST:

1. `GET /expert-squad/catalog` under bootstrap and then actual allocated directory: HTTP 200 and `active.effective === taskProfile`.
2. `GET /skill/mounts` under those same scopes: HTTP 200; retain returned current matrix, without guessing labels or asserting UI strings.
3. Save named public receipts even when a read fails; do not admit a Task with a known invalid chosen profile. This is a harness technical preflight, not a new product LLM routing gate.
4. Continue original 600s/new owner only after Root authorization: same true long root and original CSV creation-before-binding; public Task202; baseline checker; real Task page; manual first stream release; actual UI Allow Once if needed; completed Tool output; original Stop → real cancelled lifecycle; page close; stop; physical/output/request settlement/parent cleanup.

Do not claim read/cancel or catalog success before this fresh run. No runtime/Provider was started during this diagnosis. Root will add the approved delta to 404 spec before authorizing helper edits.
