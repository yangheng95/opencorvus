import fs from "node:fs/promises"
import path from "node:path"
import { NodeProcess } from "../packages/util/src/process-node"
import { expectedTestProcessSupervisor } from "../packages/opencorvus/script/test-process-supervisor"

const [output, ...selected] = process.argv.slice(2)
if (!output || !path.isAbsolute(output) || path.dirname(output) !== path.resolve(".tmp-task-git-question-reconnect-404/implementation")) throw Error("Own formal output required")
const typecheck = selected.length === 1 && selected[0] === "typecheck"
if (!typecheck && (selected.length === 0 || selected.some((file) => !/^test\/engine-git-[a-z-]+\.test\.ts$/.test(file)))) throw Error("Focused declared package checks only")
await fs.mkdir(output, { recursive: false })
const supervisor = expectedTestProcessSupervisor()
if (!supervisor || !(await fs.stat(supervisor)).isFile()) throw Error("Existing supervisor required")
process.env.OPENCORVUS_PROCESS_SUPERVISOR = supervisor
const startedAt = Date.now(), deadlineAt = startedAt + 600000
const args = ["run", "--cwd", "packages/opencorvus", ...(typecheck ? ["typecheck"] : ["test", ...selected])]
const facts: any = { startedAt, deadlineAt, parentPID: process.pid, executable: process.execPath, args, cwd: process.cwd() }
let handle: any
await fs.writeFile(path.join(output, "owner-start.json"), JSON.stringify(facts, null, 2))
try {
  const result = await NodeProcess.run({ command: { executable: process.execPath, args }, cwd: process.cwd(), ownership: "owned_tree", windowsHide: true, stdin: "ignore", deadlineAt, nothrow: true, onSpawned(h) { handle = h; facts.pid = h.pid; facts.occurrenceID = h.occurrenceID } })
  await fs.writeFile(path.join(output, "command.log"), Buffer.concat([Buffer.from(result.stdout), Buffer.from(result.stderr)]))
  await fs.writeFile(path.join(output, "stdout.log"), result.stdout)
  await fs.writeFile(path.join(output, "stderr.log"), result.stderr)
  facts.receipt = result.receipt
  await handle.outputSettled
  await handle.settled
  facts.physicalJoined = true; facts.outputJoined = true; facts.requestSettled = true
  process.exitCode = result.receipt.exitCode ?? 1
} catch (error) {
  facts.error = String(error); process.exitCode = 1
  if (handle) { facts.receipt = await handle.settled; await handle.outputSettled; facts.physicalJoined = true; facts.outputJoined = true }
} finally {
  facts.endedAt = Date.now()
  await fs.writeFile(path.join(output, "owner.json"), JSON.stringify(facts, null, 2))
  console.log(JSON.stringify(facts))
}
