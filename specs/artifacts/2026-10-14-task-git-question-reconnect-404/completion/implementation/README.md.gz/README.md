# 404 Git 实施交接

本范围已完成并冻结，等待 Root 独立复核和真实页面/需要的模型验收。没有修改共享 spec、架构、CHANGELOG 或 SDK，没有提交/push。精确 tracked/untracked 源范围为 `files.json`：**1 个生产文件、1 个新增后台测试、2 个既有后台测试的正向合同更新**。

## 实施结果

唯一生产变化：`engine/git-process.ts` 的 `execute` 在 repository 目标分支统一使用 `-C dirname(frozen gitDir) + --git-dir=basename(frozen gitDir) + --work-tree=absolute workspace`。Process cwd、closed command/参数、exactEnv、冻结权威和 discovery 分支不变。没有长路径阈值 gate、fallback、版本分支或失败重试。

新增 `engine-git-frozen-directory.test.ts` 使用成熟 memoryProject/Task fixture 进入真实 production binding、EngineGit.prepare/complete、真实 Git、SQLite checkpoint request/outcome 及 replay。两 Project 并行由 Promise.allSettled 完整 join，再校验各 Project/Task/工作树的独立内容。第三项进入真实产品 `Worktree.create`、`WorktreeReadiness`，随后对真实 managed `.git` file/external admin 进行同一 checkpoint 验证；没有用手工 no-checkout 冒充产品入口。

既有 `engine-git-batched-transaction.test.ts` 中 5 个“error undefined”旁断言改成明确 successful checkpoint receipt；`engine-git-fact-reconciliation.test.ts` 中成功检查改成同 receipt，旧失败 baseline 缺失断言改为真实 immutable outcome 的原精确 error/time/request 行。公共数据合同和实际错误原因不变，未保留这些已触及的负向断言。

## 正式红绿与原失败

全程实际 Bun 1.4.0，通过包声明 `bun run --cwd packages/opencorvus test <files>`，没有直接调用内部 isolated host。`formal-runner.ts` 只为该完整公开命令增加固定 600000 ms 的原 owned_tree deadline，保留原标准 runner 的内部隔离/清理。各原 scope 独立，不延长、不覆盖日志。

| Scope | 结果 | 解释与 owner |
| --- | --- | --- |
| `red` | 0 pass / 2 fail，exit 1 | ASCII ≥310 的 fixture git init 在 Git target 出生前得到 CreateProcessW267/helper125，不算 Git 红；原源码 `preimage/new-test-original-ascii310.ts`。runner73104，原父46336，原期限1791928070251，1791927475247已结束，三项join=true |
| `red02` | 0 pass / 2 fail / 18 assertions，exit 1 | 合法独立 Unicode 路径 UTF-8 330–332、UTF-16 186–188，真实 EngineGit.prepare 返回原 `$GIT_DIR too big`，这是目标生产红。runner90344/exec44823已join，原期限1791928209167，1791927624995结束 |
| `green` | 2 pass / 69 assertions，exit 0 | 唯一生产 hunk 后，两个真实 baseline/result/parallel/replay 用例通过。runner90536/exec42115已join，原期限1791928285421，1791927712033结束 |
| `green02` | 新文件2 pass/1 fail/94 assertions；其余4文件全绿；整体exit1 | 产品 Worktree.create/Ready/baseline/result 已成功，新增测试把正常 Windows checkout 的 identity.txt CRLF 错预期为 LF；原 source `preimage/new-test-green02-identity-line-ending.ts` 与失败保留。runner44964/exec77152已join，原期限1791928360918，1791927896432结束 |
| `green03` | 新文件 **3 pass / 104 assertions**，exit 0 | 只修测试 oracle：checkpoint 前采集合法公开 checkout 的真实字节并确认 PUBLIC-label 身份，Git结果精确保留同字节；显式 raw.bin 二进制期望完全未变。runner84244/exec10487已join，原期限1791928580425，1791928039396结束 |
| `core-typecheck` | 包声明核心类型检查exit0 | `bun run --cwd packages/opencorvus typecheck`，展开为 package 的 Node/tsc 命令。runner83804/exec70263已join，原期限1791928469889，1791927908084结束 |

所有 owner receipt reason=`exited`，physicalJoined/outputJoined/requestSettled=true；没有 own 活跃服务/模型/页面或未 join command。独立 runtime 的实际清理由未修改的正式 runner 执行，失败也保留本次错误，不把 exit1装成成功。

## 最终去重覆盖

| 文件 | tests | assertions | 证据 |
| --- | ---: | ---: | --- |
| engine-git-frozen-directory | 3 | 104 | green03 |
| engine-git-safe-environment | 2 | 24 | green02 |
| engine-git-batched-raw-import | 2 | 7 | green02 |
| engine-git-batched-transaction | 6 | 69 | green02 |
| engine-git-fact-reconciliation | 3 | 11 | green02 |
| **合计** | **16** | **215** | 重复红绿不额外累计 |

原 transaction/reconciliation 回归真实覆盖 post-CAS rollback、owning-ref 变化、外部 winner ref/index、unborn-ref、unknown outcome 与 exact reconciliation、同 epoch settled failure replay。safe environment 覆盖 SHA-256 object format及原始字节。这些既有测试含其既定故障注入，证明后台合同，不冒充真实进程崩溃、HTTP或模型验收。

原有三轮 Git probe保持冻结；其第一轮默认 `git worktree add` checkout失败是实际 Git 输入事实。**当前产品 Worktree.create 原本就采用 no-checkout + cwd-only reset，所以新正式第三项进入产品实现并通过；不能用 probe01 默认命令失败宣称产品 Worktree 路径同样失败。** 产品入口与 raw Git 命令必须分别命名。

## 文件与证据

- `preimage/git-process.ts`：原生产源码；`preexisting.patch` 当时三 tracked 文件没有并行差异；`head-before.txt` 记录原 HEAD。
- `preimage/engine-git-*.test.ts`：原既有后台测试；两版新测试失败输入也保留。
- `tracked-changes.patch`：1 production +2 existing tests 的自有差异；新增测试由 `files.json` 明确列出并保存到 `final-sources/`。
- 每个 formal scope 都有独立 stdout/stderr/command.log/owner.json 与外部 launch log/exit；command.log是stdout后接stderr的完整分区汇总，**不冒称原始跨流时间顺序**。原分流日志可独立读。
- `../git-probe-results.md` / `git-probe-01..03`：真实 argv/executable/环境名/marker/字节/退出/owner；`../native-cwd-boundary-readonly.md`：ASCII310共享物理入口限制。

## 未满足、风险与下一步

- ASCII ≥310 cwd 仍在当前 Windows native CreateProcessW 边界失败，未修 ProcessSupervisor。Unicode ≥300 UTF-8 字节、UTF-16<260的成功不能外推 ASCII300 字符。原红与共享入口调查完整保留，下一批需要自己的方案。
- 至今未完成本批真实 HTTP Task lifecycle、模型/页面/截图验收；由 Root 统一安排。正式测试的 Task fixture 不是自然用户/模型消息，不将它冒称端到端。
- UNC、单个 admin basename本身超过上游阈值、POSIX实机与冻结目录运行中替换未新增实证；Snapshot/build-observation消费者没有改动，仍按先前横审边界交付。
- 旧持久化失败 outcome 未被重写，参数修复不等于同 epoch 自动恢复。Core typecheck和16项后台通过只能支持当前限定 source diff。
