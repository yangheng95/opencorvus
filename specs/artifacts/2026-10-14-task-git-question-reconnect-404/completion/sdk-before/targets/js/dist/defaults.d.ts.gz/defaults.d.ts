export declare const DEFAULT_SERVER_HOST = "127.0.0.1";
export declare const DEFAULT_SERVER_PORT = 7878;
export declare const DEFAULT_SERVER_URL = "http://127.0.0.1:7878";
