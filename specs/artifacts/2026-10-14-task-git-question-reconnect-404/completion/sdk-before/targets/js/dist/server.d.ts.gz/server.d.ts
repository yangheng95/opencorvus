import { type ConfigGetResponse } from "./gen/types.gen.js";
type Config = ConfigGetResponse;
export type ServerOptions = {
    hostname?: string;
    port?: number;
    signal?: AbortSignal;
    timeout?: number;
    config?: Config;
};
export type OpenCorvusServer = {
    url: string;
    close(): Promise<void>;
};
export declare function combineServerStartupFailures(primary: unknown, cleanupFailures: readonly unknown[]): unknown;
export declare function createOpenCorvusServer(options?: ServerOptions): Promise<OpenCorvusServer>;
export {};
