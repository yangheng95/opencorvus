export declare const EXPERT_SQUAD_ARCHIVE_IMPORT_LIMITS: {
    readonly base64Characters: number;
    readonly archiveBytes: number;
    readonly entries: 512;
    readonly fileBytes: number;
    readonly totalUnpackedBytes: number;
};
