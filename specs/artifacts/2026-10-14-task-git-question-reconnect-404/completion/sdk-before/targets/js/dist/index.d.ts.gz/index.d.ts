export * from "./client.js";
export * from "./server.js";
export type { ProcessFacade } from "@opencorvus-ai/util/process";
import { createOpenCorvusClient as createOpenCorvusClientImpl, type OpenCorvusClientConfig, OpenCorvusClient } from "./client.js";
import { createOpenCorvusServer as createOpenCorvusServerImpl, type ServerOptions } from "./server.js";
export type OpenCorvusOptions = ServerOptions & OpenCorvusClientConfig & {
    initGit?: boolean;
};
export type { OpenCorvusClientConfig, ServerOptions };
export { OpenCorvusClient };
export declare const createOpenCorvusClient: typeof createOpenCorvusClientImpl;
export declare const createOpenCorvusServer: typeof createOpenCorvusServerImpl;
export declare function createOpenCorvus(options?: OpenCorvusOptions): Promise<{
    client: OpenCorvusClient;
    server: import("./server.js").OpenCorvusServer;
}>;
