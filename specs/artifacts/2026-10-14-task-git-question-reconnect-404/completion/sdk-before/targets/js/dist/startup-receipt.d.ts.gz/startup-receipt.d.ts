/**
 * The framed machine startup fact a managed server publishes for its launcher.
 *
 * Readiness used to be a regex over a human console line — so changed wording,
 * a localized message or an unrelated matching stdout line could time the
 * launcher out, fail to parse, or hand back a URL the process never bound.
 * The receipt is the protocol instead: stdout stays diagnostics, and exactly
 * one of `url` or `error` settles the startup.
 */
export type StartupReceipt = {
    schemaVersion: 1;
    occurrenceID: string;
    outcome: "listening";
    url: string;
    pid: number;
} | {
    schemaVersion: 1;
    occurrenceID: string;
    outcome: "failed";
    error: string;
};
export declare function parseStartupReceipt(raw: string, occurrenceID: string): StartupReceipt | undefined;
/** A private directory for one launch's receipt; the launcher owns its life. */
export declare function createStartupReceiptChannel(occurrenceID: string): Promise<{
    path: string;
    read(): Promise<StartupReceipt | undefined>;
    wait(signal: AbortSignal): Promise<StartupReceipt>;
    dispose(): Promise<void>;
}>;
