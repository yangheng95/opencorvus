import { type Client, type Options as Options2, type TDataShape } from "./client/index.js";
import type { AppAgentsResponses, AppLogErrors, AppLogResponses, AppSkillsResponses, AttachmentCreateDirectoryReferenceErrors, AttachmentCreateDirectoryReferenceResponses, AttachmentCreateErrors, AttachmentCreateResponses, AttachmentGetErrors, AttachmentGetResponses, Auth as Auth5, AuthRemoveErrors, AuthRemoveResponses, AuthSetErrors, AuthSetResponses, BrowserPreviewCaptureTaskTargetErrors, BrowserPreviewCaptureTaskTargetResponses, BrowserPreviewCompareTaskTargetRegionsErrors, BrowserPreviewCompareTaskTargetRegionsResponses, BrowserPreviewReadTaskEvidenceArtifactErrors, BrowserPreviewReadTaskEvidenceArtifactResponses, BrowserPreviewReadTaskEvidenceCaptureErrors, BrowserPreviewReadTaskEvidenceCaptureResponses, BrowserPreviewReadTaskEvidenceErrors, BrowserPreviewReadTaskEvidenceResponses, BrowserPreviewSelectTaskTargetErrors, BrowserPreviewSelectTaskTargetResponses, BrowserPreviewTaskTargetErrors, BrowserPreviewTaskTargetResponses, ChannelAttachmentCreateErrors, ChannelAttachmentCreateResponses, ChannelAttachmentGetErrors, ChannelAttachmentGetResponses, ChannelListResponses, ChannelMessageResponses, ChannelRuntimeResponses, ChannelRuntimeRestartResponses, ChatCapabilityGetErrors, ChatCapabilityGetResponses, ChatCapabilityUpdateErrors, ChatCapabilityUpdateResponses, CodingChatSessionAbortErrors, CodingChatSessionAbortResponses, CodingChatSessionCreateErrors, CodingChatSessionCreateResponses, CodingChatSessionDeleteErrors, CodingChatSessionDeleteResponses, CodingChatSessionGetErrors, CodingChatSessionGetResponses, CodingChatSessionSelectionUpdateErrors, CodingChatSessionSelectionUpdateResponses, CodingChatSessionSetArchivedErrors, CodingChatSessionSetArchivedResponses, CodingChatSessionsListErrors, CodingChatSessionsListResponses, CodingChatSessionUpdateErrors, CodingChatSessionUpdateResponses, CodingCliOpenErrors, CodingCliOpenResponses, CodingCliProfilesErrors, CodingCliProfilesResponses, CodingWorkSessionAbortErrors, CodingWorkSessionAbortResponses, CodingWorkSessionCreateErrors, CodingWorkSessionCreateResponses, CodingWorkSessionDeleteErrors, CodingWorkSessionDeleteResponses, CodingWorkSessionGetErrors, CodingWorkSessionGetResponses, CodingWorkSessionSelectionUpdateErrors, CodingWorkSessionSelectionUpdateResponses, CodingWorkSessionSetArchivedErrors, CodingWorkSessionSetArchivedResponses, CodingWorkSessionsListErrors, CodingWorkSessionsListResponses, CodingWorkSessionUpdateErrors, CodingWorkSessionUpdateResponses, CommandListErrors, CommandListResponses, ComputerReturnErrors, ComputerReturnResponses, ComputerStatusErrors, ComputerStatusResponses, ComputerTakeoverErrors, ComputerTakeoverResponses, ConfigGetErrors, ConfigGetResponses, ConfigPromptErrors, ConfigPromptResponses, ConfigProvidersErrors, ConfigProvidersResponses, ConfigProxyTestErrors, ConfigProxyTestResponses, ConfigUpdateErrors, ConfigUpdateResponses, ContinuousGoalCreateErrors, ContinuousGoalCreateResponses, ContinuousGoalGetErrors, ContinuousGoalGetResponses, ContinuousGoalUpdateErrors, ContinuousGoalUpdateResponses, ConversationCapabilityUpdate, CreateQuickNoteRequest, EventSubscribeResponse, EventSubscribeResponses, ExperimentalEventscheduleCreateErrors, ExperimentalEventscheduleCreateResponses, ExperimentalEventscheduleDeleteErrors, ExperimentalEventscheduleDeleteResponses, ExperimentalEventscheduleListErrors, ExperimentalEventscheduleListResponses, ExperimentalMemoryGetErrors, ExperimentalMemoryGetResponses, ExperimentalProjectMemoryAcknowledgeNoticeResponses, ExperimentalProjectMemoryGetResponses, ExperimentalProjectMemoryOrganizeResponses, ExperimentalResourceListErrors, ExperimentalResourceListResponses, ExperimentalTaskplanListErrors, ExperimentalTaskplanListResponses, ExperimentalWorkspaceCreateErrors, ExperimentalWorkspaceCreateResponses, ExperimentalWorkspaceListResponses, ExperimentalWorkspaceRemoveErrors, ExperimentalWorkspaceRemoveResponses, ExpertSquadCatalogErrors, ExpertSquadCatalogResponses, ExpertSquadConfigurationGetErrors, ExpertSquadConfigurationGetResponses, ExpertSquadConfigurationUpdateErrors, ExpertSquadConfigurationUpdateResponses, ExpertSquadDiagnosticsErrors, ExpertSquadDiagnosticsResponses, ExpertSquadEvolutionAuthorizationErrors, ExpertSquadEvolutionAuthorizationResponses, ExpertSquadEvolutionHistoryDetailErrors, ExpertSquadEvolutionHistoryDetailResponses, ExpertSquadEvolutionHistoryErrors, ExpertSquadEvolutionHistoryResponses, ExpertSquadEvolutionMutationErrors, ExpertSquadEvolutionMutationResponses, ExpertSquadExportErrors, ExpertSquadExportResponses, ExpertSquadImportExactFileErrors, ExpertSquadImportExactFileResponses, ExpertSquadImportFileErrors, ExpertSquadImportFileResponses, ExpertSquadImportFolderErrors, ExpertSquadImportFolderResponses, ExpertSquadInspectErrors, ExpertSquadInspectResponses, ExpertSquadInstallPayloadErrors, ExpertSquadInstallPayloadResponses, ExpertSquadInventoryStatusErrors, ExpertSquadInventoryStatusResponses, ExpertSquadMarketDetailErrors, ExpertSquadMarketDetailResponses, ExpertSquadMarketErrors, ExpertSquadMarketResponses, ExpertSquadMulticaPreviewErrors, ExpertSquadMulticaPreviewResponses, ExpertSquadMulticaSquadsErrors, ExpertSquadMulticaSquadsResponses, ExpertSquadReleasePayloadErrors, ExpertSquadReleasePayloadResponses, ExpertSquadRepairBundledErrors, ExpertSquadRepairBundledResponses, ExpertSquadSearchErrors, ExpertSquadSearchResponses, ExpertSquadSettingsDetailErrors, ExpertSquadSettingsDetailResponses, ExpertSquadUninstallErrors, ExpertSquadUninstallResponses, ExpertSquadUpdateErrors, ExpertSquadUpdateResponses, ExpertSquadValidateFolderErrors, ExpertSquadValidateFolderResponses, ExportSessionErrors, ExportSessionResponses, FileCopyErrors, FileCopyResponses, FileCreateErrors, FileCreateResponses, FileDeleteErrors, FileDeleteResponses, FileListResponses, FileMoveErrors, FileMoveResponses, FilePartInput, FilePartSource, FileReadErrors, FileReadResponses, FileReadSourceErrors, FileReadSourceResponses, FileStatusResponses, FileUploadErrors, FileUploadResponses, FileWriteErrors, FileWriteResponses, FindFilesErrors, FindFilesResponses, FindTextErrors, FindTextResponses, FormatterStatusResponses, GatewayCapabilitiesResponses, GatewayChannelMessageResponses, GatewayControlActionErrors, GatewayControlActionResponses, GatewayControlMessageResponses, GatewayStatsResponses, GlobalAgentsListResponses, GlobalAutomationsCreateErrors, GlobalAutomationsCreateResponses, GlobalAutomationsDeleteErrors, GlobalAutomationsDeleteResponses, GlobalAutomationsFiresErrors, GlobalAutomationsFiresResponses, GlobalAutomationsListErrors, GlobalAutomationsListResponses, GlobalAutomationsRunErrors, GlobalAutomationsRunResponses, GlobalAutomationsRunsErrors, GlobalAutomationsRunsResponses, GlobalAutomationsUpdateErrors, GlobalAutomationsUpdateResponses, GlobalChatCreateErrors, GlobalChatCreateResponses, GlobalChatStartErrors, GlobalChatStartResponses, GlobalComposerExpertSquadsErrors, GlobalComposerExpertSquadsResponses, GlobalComposerReferencesErrors, GlobalComposerReferencesResponses, GlobalConfigGetErrors, GlobalConfigGetResponses, GlobalConfigUpdateErrors, GlobalConfigUpdateResponses, GlobalDisposeErrors, GlobalDisposeResponses, GlobalEventResponse, GlobalEventResponses, GlobalHealthResponses, GlobalProjectsAnonymousResponses, GlobalProjectsDiscoverErrors, GlobalProjectsDiscoverResponses, GlobalProvidersAccountUsageErrors, GlobalProvidersAccountUsageResponses, GlobalProvidersAuthExecuteErrors, GlobalProvidersAuthExecuteResponses, GlobalProvidersAuthPromptsErrors, GlobalProvidersAuthPromptsResponses, GlobalProvidersAuthResponses, GlobalProvidersDiscoverModelsErrors, GlobalProvidersDiscoverModelsResponses, GlobalProvidersListResponses, GlobalProvidersModelsRefreshErrors, GlobalProvidersModelsRefreshResponses, GlobalProvidersOauthAuthorizeErrors, GlobalProvidersOauthAuthorizeResponses, GlobalProvidersOauthCallbackErrors, GlobalProvidersOauthCallbackResponses, GlobalProvidersOauthCancelErrors, GlobalProvidersOauthCancelResponses, GlobalProvidersRefreshResponses, GlobalProvidersRemoveErrors, GlobalProvidersRemoveResponses, GlobalProvidersTestErrors, GlobalProvidersTestResponses, GlobalSkillInstallErrors, GlobalSkillInstallResponses, GlobalSkillMarketDetailErrors, GlobalSkillMarketDetailResponses, GlobalSkillMarketInstallErrors, GlobalSkillMarketInstallResponses, GlobalSkillMarketResponses, GlobalSkillMarketSearchErrors, GlobalSkillMarketSearchResponses, GlobalUsageErrors, GlobalUsageResponses, GlobalWorkCreateErrors, GlobalWorkCreateResponses, GoalDeleteErrors, GoalDeleteResponses, GoalUpdateTitleErrors, GoalUpdateTitleResponses, InstanceDisposeErrors, InstanceDisposeResponses, InteractionRejectErrors, InteractionRejectResponses, InteractionReplyErrors, InteractionReplyResponses, InteractiveArtifactEventsMcpAppResponse, InteractiveArtifactEventsMcpAppResponses, InteractiveArtifactReadSessionArtifactErrors, InteractiveArtifactReadSessionArtifactResponses, InteractiveArtifactRequestMcpAppErrors, InteractiveArtifactRequestMcpAppResponses, LogExportResponses, LogFilesResponses, LogReadErrors, LogReadResponses, LogTailErrors, LogTailResponses, MailboxAcknowledgeErrors, MailboxAcknowledgeResponses, MailboxDeleteErrors, MailboxDeleteManyErrors, MailboxDeleteManyResponses, MailboxDeleteResponses, MailboxListErrors, MailboxListResponses, MailboxReadAllResponses, McpAddErrors, McpAddResponses, McpAppHostRequest, McpAuthAuthenticateErrors, McpAuthAuthenticateResponses, McpAuthCallbackErrors, McpAuthCallbackResponses, McpAuthRemoveErrors, McpAuthRemoveResponses, McpAuthStartErrors, McpAuthStartResponses, McpConnectErrors, McpConnectResponses, McpDisconnectErrors, McpDisconnectResponses, McpLocalConfig, McpProjectStatusResponses, McpRemoteConfig, McpRemoveConfiguredInput, McpRemoveErrors, McpRemoveResponses, McpStatusResponses, MissionAbortErrors, MissionAbortResponses, MissionActivityCursorErrors, MissionActivityCursorResponses, MissionCreateDraftErrors, MissionCreateDraftResponses, MissionDeleteErrors, MissionDeleteResponses, MissionDispatchErrors, MissionDispatchResponses, MissionEditDraftErrors, MissionEditDraftResponses, MissionListResponses, MissionProjectArchiveErrors, MissionProjectArchiveResponses, MissionRenameErrors, MissionRenameResponses, MissionSetArchivedErrors, MissionSetArchivedResponses, MissionSkillCatalogErrors, MissionSkillCatalogResponses, MissionSkillDirectoryErrors, MissionSkillDirectoryResponses, MissionSkillSettingsErrors, MissionSkillSettingsResponses, MissionStatusErrors, MissionStatusResponses, MissionWakeErrors, MissionWakeResponses, NetworkProxyTestRequest, OutputFormat, PanelCapabilitiesResponses, PanelKnowledgeMemoryDeleteErrors, PanelKnowledgeMemoryDeleteResponses, PanelKnowledgeMemoryGetErrors, PanelKnowledgeMemoryGetResponses, PanelKnowledgeMemoryListResponses, PanelKnowledgeMemorySearchResponses, PanelMessageErrors, PanelMessageResponses, PanelMessageStreamResponse, PanelMessageStreamResponses, Part as Part2, PartDeleteErrors, PartDeleteResponses, PartUpdateErrors, PartUpdateResponses, PathGetResponses, PermissionDecision, PermissionGrantsResponses, PermissionHistoryResponses, PermissionIdentity, PermissionListResponses, PermissionReplyErrors, PermissionReplyResponses, PermissionRevokeErrors, PermissionRevokeResponses, ProjectCurrentCleanupCandidatesErrors, ProjectCurrentCleanupCandidatesResponses, ProjectCurrentDeleteErrors, ProjectCurrentDeleteResponses, ProjectCurrentInitGitErrors, ProjectCurrentInitGitResponses, ProjectCurrentPromoteAnonymousErrors, ProjectCurrentPromoteAnonymousResponses, ProjectCurrentResponses, ProjectCurrentUpdateErrors, ProjectCurrentUpdateResponses, ProjectCurrentWorktreesDeleteErrors, ProjectCurrentWorktreesDeleteResponses, ProjectCurrentWorktreesErrors, ProjectCurrentWorktreesResponses, ProjectListResponses, ProjectUpdateErrors, ProjectUpdateResponses, ProviderAccountUsageErrors, ProviderAccountUsageResponses, ProviderAuthExecuteErrors, ProviderAuthExecuteResponses, ProviderAuthPromptsErrors, ProviderAuthPromptsResponses, ProviderAuthResponses, ProviderDiscoverModelsErrors, ProviderDiscoverModelsResponses, ProviderListResponses, ProviderModelsRefreshErrors, ProviderModelsRefreshResponses, ProviderOauthAuthorizeErrors, ProviderOauthAuthorizeResponses, ProviderOauthCallbackErrors, ProviderOauthCallbackResponses, ProviderOauthCancelErrors, ProviderOauthCancelResponses, ProviderRefreshResponses, ProviderRemoveErrors, ProviderRemoveResponses, ProviderTestErrors, ProviderTestResponses, PtyCreateErrors, PtyCreateResponses, PtyGetErrors, PtyGetResponses, PtyInputErrors, PtyInputResponses, PtyListResponses, PtyOutputResponse, PtyOutputResponses, PtyRemoveErrors, PtyRemoveResponses, PtyUpdateErrors, PtyUpdateResponses, QuestionAnswer, QuestionListResponses, QuestionRejectErrors, QuestionRejectResponses, QuestionReplyErrors, QuestionReplyResponses, QuicknoteCreateErrors, QuicknoteCreateResponses, ServerLifecycleErrors, ServerLifecycleResponses, ServerRestartErrors, ServerRestartResponses, ServerShutdownErrors, ServerShutdownResponses, SessionAbortErrors, SessionAbortResponses, SessionChildrenErrors, SessionChildrenResponses, SessionCommandErrors, SessionCommandResponses, SessionConfigGetErrors, SessionConfigGetResponses, SessionConfigUpdateErrors, SessionConfigUpdateResponses, SessionConversationErrors, SessionConversationHistoryErrors, SessionConversationHistoryResponses, SessionConversationResponses, SessionCreateErrors, SessionCreateResponses, SessionCreateSideChatErrors, SessionCreateSideChatResponses, SessionDeleteErrors, SessionDeleteMessageErrors, SessionDeleteMessageResponses, SessionDeleteResponses, SessionDiffResponses, SessionEventsResponse, SessionEventsResponses, SessionForkErrors, SessionForkResponses, SessionGetErrors, SessionGetResponses, SessionInitErrors, SessionInitResponses, SessionListGlobalErrors, SessionListGlobalResponses, SessionListResponses, SessionMessageErrors, SessionMessagePartErrors, SessionMessagePartResponses, SessionMessageResponses, SessionMessagesErrors, SessionMessagesResponses, SessionPromptErrors, SessionPromptResponses, SessionShellErrors, SessionShellResponses, SessionSideChatsErrors, SessionSideChatsResponses, SessionStatusErrors, SessionStatusResponses, SessionSummarizeErrors, SessionSummarizeResponses, SessionTodoErrors, SessionTodoResponses, SessionTraceResponses, SessionTurnArtifactsErrors, SessionTurnArtifactsResponses, SessionUpdateErrors, SessionUpdateResponses, SkillDirectoriesResponses, SkillImportFileResponses, SkillInstalledResponses, SkillInstallResponses, SkillIssuesResponses, SkillMarketDetailErrors, SkillMarketDetailResponses, SkillMarketInstallErrors, SkillMarketInstallResponses, SkillMarketResponses, SkillMarketSearchErrors, SkillMarketSearchResponses, SkillMountsResponses, SkillPolicyResponses, SkillRemoveResponses, SkillSetMountOverrideResponses, SkillUpdateResponses, TaskBindingsResponses, TaskBoardErrors, TaskBoardResponses, TaskBriefErrors, TaskBriefResponses, TaskBuildObservationContentErrors, TaskBuildObservationContentResponses, TaskCancelErrors, TaskCancelResponses, TaskClearRewindCursorErrors, TaskClearRewindCursorResponses, TaskConversationErrors, TaskConversationEventsErrors, TaskConversationEventsResponses, TaskConversationHistoryErrors, TaskConversationHistoryResponses, TaskConversationResponses, TaskConversationSessionErrors, TaskConversationSessionResponses, TaskCreateErrors, TaskCreateResponses, TaskDebugTaskRootIngressesErrors, TaskDebugTaskRootIngressesResponses, TaskDeleteErrors, TaskDeleteResponses, TaskEventsResponse, TaskEventsResponses, TaskGetErrors, TaskGetResponses, TaskGlobalCreateErrors, TaskGlobalCreateResponses, TaskGlobalListResponses, TaskInjectErrors, TaskInjectResponses, TaskInteractionsErrors, TaskInteractionsResponses, TaskListResponses, TaskMessageErrors, TaskMessageResponses, TaskOperatorModelContextErrors, TaskOperatorModelContextResponses, TaskProgressErrors, TaskProgressResponses, TaskProjectArchiveErrors, TaskProjectArchiveResponses, TaskReadConversationArtifactErrors, TaskReadConversationArtifactResponses, TaskRewindErrors, TaskRewindResponses, TaskSessionCancelErrors, TaskSessionCancelResponses, TaskSessionOperatorSteerErrors, TaskSessionOperatorSteerResponses, TaskSetArchivedErrors, TaskSetArchivedResponses, TaskStatusErrors, TaskStatusResponses, TaskTraceErrors, TaskTraceResponses, TaskTranscriptErrors, TaskTranscriptResponses, TaskTurnArtifactsErrors, TaskTurnArtifactsResponses, TaskUpdateBudgetErrors, TaskUpdateBudgetResponses, TaskUpdateTitleErrors, TaskUpdateTitleResponses, TerminalOpenErrors, TerminalOpenResponses, TerminalProfilesErrors, TerminalProfilesResponses, TextPartInput, ToolIdsErrors, ToolIdsResponses, ToolListErrors, ToolListResponses, UsagePeriod, VcsBranchesErrors, VcsBranchesResponses, VcsCommitErrors, VcsCommitMessageStreamResponse, VcsCommitMessageStreamResponses, VcsCommitResponses, VcsDiffErrors, VcsDiffResponses, VcsGetErrors, VcsGetResponses, VcsPushErrors, VcsPushResponses, VcsSwitchBranchErrors, VcsSwitchBranchResponses, WorkCapabilityGetErrors, WorkCapabilityGetResponses, WorkCapabilityUpdateErrors, WorkCapabilityUpdateResponses, WorkLedgerEventsResponse, WorkLedgerEventsResponses, WorkLedgerListArchivedErrors, WorkLedgerListArchivedResponses, WorkLedgerListErrors, WorkLedgerListResponses, WorkLedgerSetItemPinnedErrors, WorkLedgerSetItemPinnedResponses, WorkLedgerSetProjectPinnedErrors, WorkLedgerSetProjectPinnedResponses, WorktreeCreateErrors, WorktreeCreateInput, WorktreeCreateResponses, WorktreeListResponses, WorktreeRemoveErrors, WorktreeRemoveInput, WorktreeRemoveResponses, WorktreeResetErrors, WorktreeResetInput, WorktreeResetResponses } from "./types.gen.js";
export type Options<TData extends TDataShape = TDataShape, ThrowOnError extends boolean = boolean, TResponse = unknown> = Options2<TData, ThrowOnError, TResponse> & {
    /**
     * You can provide a client instance returned by `createClient()` instead of
     * individual options. This might be also useful if you want to implement a
     * custom client.
     */
    client?: Client;
    /**
     * You can pass arbitrary values through the `meta` object. This can be
     * used to access values that aren't defined as part of the SDK function.
     */
    meta?: Record<string, unknown>;
};
declare class HeyApiClient {
    protected client: Client;
    constructor(args?: {
        client?: Client;
    });
}
declare class HeyApiRegistry<T> {
    private readonly defaultKey;
    private readonly instances;
    get(key?: string): T;
    set(value: T, key?: string): void;
}
export declare class App extends HeyApiClient {
    /**
     * List primary assistants
     *
     * Get the product-facing primary assistants available for direct user sessions.
     */
    agents<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<AppAgentsResponses, unknown, ThrowOnError, "fields">;
    /**
     * Write log batch
     *
     * Write one bounded ordered batch of log entries to the server logs.
     */
    log<ThrowOnError extends boolean = false>(parameters: {
        entries: Array<{
            /**
             * Additional metadata for the log entry
             */
            extra?: {
                [key: string]: unknown;
            };
            /**
             * Log level
             */
            level: "debug" | "info" | "error" | "warn";
            /**
             * Log message
             */
            message: string;
            /**
             * Service name for the log entry
             */
            service: string;
        }>;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<AppLogResponses, AppLogErrors, ThrowOnError, "fields">;
    /**
     * List skills
     *
     * Get a list of all available skills in the OpenCorvus system.
     */
    skills<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<AppSkillsResponses, unknown, ThrowOnError, "fields">;
}
export declare class Quicknote extends HeyApiClient {
    /**
     * Create QuickNote
     *
     * Create a quick note from plain text content.
     */
    create<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        createQuickNoteRequest: CreateQuickNoteRequest;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<QuicknoteCreateResponses, QuicknoteCreateErrors, ThrowOnError, "fields">;
}
export declare class Attachment extends HeyApiClient {
    /**
     * Upload a conversation attachment
     *
     * Store raw attachment bytes in the current project's content-addressed attachment store and return the canonical reference.
     */
    create<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        filename: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<AttachmentCreateResponses, AttachmentCreateErrors, ThrowOnError, "fields">;
    /**
     * Reference a local directory
     *
     * Validate one local directory and store a canonical reference manifest without enumerating or uploading descendants.
     */
    createDirectoryReference<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        path: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<AttachmentCreateDirectoryReferenceResponses, AttachmentCreateDirectoryReferenceErrors, ThrowOnError, "fields">;
    /**
     * Fetch a task attachment
     */
    get<ThrowOnError extends boolean = false>(parameters: {
        projectID: string;
        name: string;
        variant?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<AttachmentGetResponses, AttachmentGetErrors, ThrowOnError, "fields">;
}
export declare class Auth extends HeyApiClient {
    /**
     * Remove auth credentials
     *
     * Remove authentication credentials
     */
    remove<ThrowOnError extends boolean = false>(parameters: {
        providerID: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<AuthRemoveResponses, AuthRemoveErrors, ThrowOnError, "fields">;
    /**
     * Set auth credentials
     *
     * Set authentication credentials
     */
    set<ThrowOnError extends boolean = false>(parameters: {
        providerID: string;
        auth: Auth5;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<AuthSetResponses, AuthSetErrors, ThrowOnError, "fields">;
}
export declare class Attachment2 extends HeyApiClient {
    /**
     * Create a temporary channel attachment URL
     *
     * Store a temporary attachment and return a signed public URL for channels that require remote image URLs.
     */
    create<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        data: string;
        filename: string;
        mime: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ChannelAttachmentCreateResponses, ChannelAttachmentCreateErrors, ThrowOnError, "fields">;
    /**
     * Read a temporary channel attachment
     *
     * Read a previously created temporary channel attachment by signed URL.
     */
    get<ThrowOnError extends boolean = false>(parameters: {
        id: string;
        e?: string;
        s?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ChannelAttachmentGetResponses, ChannelAttachmentGetErrors, ThrowOnError, "fields">;
}
export declare class Runtime extends HeyApiClient {
    /**
     * Restart managed channel runtime
     *
     * Restart the managed channel runtime with the current config.
     */
    restart<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ChannelRuntimeRestartResponses, unknown, ThrowOnError, "fields">;
}
export declare class Channel extends HeyApiClient {
    /**
     * List channels
     *
     * Get available channel integrations, configuration status, and runtime status.
     */
    list<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ChannelListResponses, unknown, ThrowOnError, "fields">;
    /**
     * Handle channel message
     *
     * Bridge an external channel message into the task board and panel control workflow.
     */
    message<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        allow_create?: boolean;
        allow_session_mutation?: boolean;
        attachments?: Array<{
            data?: string;
            filename: string;
            mime: string;
            url?: string;
        }>;
        bind?: boolean;
        channel: string;
        model?: string;
        platform: "slack" | "telegram" | "discord" | "feishu" | "whatsapp" | "googlechat" | "msteams" | "line" | "matrix" | "mattermost" | "signal" | "wecom" | "dingtalk" | "clickclack" | "imessage" | "irc" | "nextcloud-talk" | "nostr" | "qqbot" | "raft" | "reef" | "sms" | "synology-chat" | "tlon" | "twitch" | "zalo" | "zalouser";
        request_id: string;
        source?: string;
        task_id?: string;
        text: string;
        thread: string;
        user_id?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ChannelMessageResponses, unknown, ThrowOnError, "fields">;
    /**
     * Get managed channel runtime
     *
     * Get managed channel runtime status for configured channel integrations.
     */
    runtime<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ChannelRuntimeResponses, unknown, ThrowOnError, "fields">;
    private _attachment?;
    get attachment(): Attachment2;
    private _runtime?;
    get runtime2(): Runtime;
}
export declare class Capability extends HeyApiClient {
    /**
     * Inspect native Chat capabilities
     *
     * Returns the fixed native Chat harness tool declaration and its project-owned Skill and MCP assignments. This route never reads an active Expert Squad or session overlay.
     */
    get<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ChatCapabilityGetResponses, ChatCapabilityGetErrors, ThrowOnError, "fields">;
    /**
     * Update native Chat capability assignments
     *
     * Atomically assigns or unassigns one project-owned Skill or MCP server reference for the fixed native Chat harness.
     */
    update<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        conversationCapabilityUpdate: ConversationCapabilityUpdate;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ChatCapabilityUpdateResponses, ChatCapabilityUpdateErrors, ThrowOnError, "fields">;
}
export declare class Chat extends HeyApiClient {
    private _capability?;
    get capability(): Capability;
}
export declare class Selection extends HeyApiClient {
    /**
     * Update right sidebar Chat task selection
     *
     * Persist the selected project task for a right sidebar Chat session. The selected task is stored in session metadata and remains project-bound.
     */
    update<ThrowOnError extends boolean = false>(parameters: {
        sessionID: string;
        directory?: string;
        taskID: string | null;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<CodingChatSessionSelectionUpdateResponses, CodingChatSessionSelectionUpdateErrors, ThrowOnError, "fields">;
}
export declare class Session extends HeyApiClient {
    /**
     * Create right sidebar Chat session
     *
     * Create a project-bound Chat session for the right sidebar. Prompting and history use canonical /session routes.
     */
    create<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
        model?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<CodingChatSessionCreateResponses, CodingChatSessionCreateErrors, ThrowOnError, "fields">;
    /**
     * Delete right sidebar Chat session
     *
     * Retire a project-bound right sidebar Chat session. Domain-owned sessions retain immutable audit history; standalone sessions report their physical cleanup disposition.
     */
    delete<ThrowOnError extends boolean = false>(parameters: {
        sessionID: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<CodingChatSessionDeleteResponses, CodingChatSessionDeleteErrors, ThrowOnError, "fields">;
    /**
     * Claim right sidebar Chat session
     *
     * Validate and return an existing project-bound right sidebar Chat session.
     */
    get<ThrowOnError extends boolean = false>(parameters: {
        sessionID: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<CodingChatSessionGetResponses, CodingChatSessionGetErrors, ThrowOnError, "fields">;
    /**
     * Update right sidebar Chat session
     *
     * Update a project-bound right sidebar Chat session.
     */
    update<ThrowOnError extends boolean = false>(parameters: {
        sessionID: string;
        directory?: string;
        title?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<CodingChatSessionUpdateResponses, CodingChatSessionUpdateErrors, ThrowOnError, "fields">;
    /**
     * Abort right sidebar Chat session
     *
     * Stop active processing for a project-bound right sidebar Chat session.
     */
    abort<ThrowOnError extends boolean = false>(parameters: {
        sessionID: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<CodingChatSessionAbortResponses, CodingChatSessionAbortErrors, ThrowOnError, "fields">;
    /**
     * Archive or restore right sidebar Chat session
     *
     * Stop and archive a Chat session, or restore it without restarting execution.
     */
    setArchived<ThrowOnError extends boolean = false>(parameters: {
        sessionID: string;
        directory?: string;
        archived: boolean;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<CodingChatSessionSetArchivedResponses, CodingChatSessionSetArchivedErrors, ThrowOnError, "fields">;
    private _selection?;
    get selection(): Selection;
}
export declare class Sessions extends HeyApiClient {
    /**
     * List right sidebar Chat sessions
     *
     * List project-bound right sidebar Chat sessions. Prompting and history use canonical /session routes.
     */
    list<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
        limit?: number;
        cursorUpdated?: number;
        cursorSessionID?: string;
        search?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<CodingChatSessionsListResponses, CodingChatSessionsListErrors, ThrowOnError, "fields">;
}
export declare class Chat2 extends HeyApiClient {
    private _session?;
    get session(): Session;
    private _sessions?;
    get sessions(): Sessions;
}
export declare class Cli extends HeyApiClient {
    /**
     * Open coding CLI
     *
     * Open an installed coding command-line interface in the operating system terminal application.
     */
    open<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        cliID: string;
        cwd: string;
        terminalProfileID: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<CodingCliOpenResponses, CodingCliOpenErrors, ThrowOnError, "fields">;
    /**
     * List installed coding CLIs
     *
     * List installed coding command-line interfaces launchable in the system terminal.
     */
    profiles<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<CodingCliProfilesResponses, CodingCliProfilesErrors, ThrowOnError, "fields">;
}
export declare class Selection2 extends HeyApiClient {
    /**
     * Update right sidebar Work task selection
     *
     * Persist the selected project task for a right sidebar Work session. The selected task is stored in session metadata and remains project-bound.
     */
    update<ThrowOnError extends boolean = false>(parameters: {
        sessionID: string;
        directory?: string;
        taskID: string | null;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<CodingWorkSessionSelectionUpdateResponses, CodingWorkSessionSelectionUpdateErrors, ThrowOnError, "fields">;
}
export declare class Session2 extends HeyApiClient {
    /**
     * Create right sidebar Work session
     *
     * Create a project-bound Work session for the right sidebar. Prompting and history use canonical /session routes.
     */
    create<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
        model?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<CodingWorkSessionCreateResponses, CodingWorkSessionCreateErrors, ThrowOnError, "fields">;
    /**
     * Delete right sidebar Work session
     *
     * Retire a project-bound right sidebar Work session. Domain-owned sessions retain immutable audit history; standalone sessions report their physical cleanup disposition.
     */
    delete<ThrowOnError extends boolean = false>(parameters: {
        sessionID: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<CodingWorkSessionDeleteResponses, CodingWorkSessionDeleteErrors, ThrowOnError, "fields">;
    /**
     * Claim right sidebar Work session
     *
     * Validate and return an existing project-bound right sidebar Work session.
     */
    get<ThrowOnError extends boolean = false>(parameters: {
        sessionID: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<CodingWorkSessionGetResponses, CodingWorkSessionGetErrors, ThrowOnError, "fields">;
    /**
     * Update right sidebar Work session
     *
     * Update a project-bound right sidebar Work session.
     */
    update<ThrowOnError extends boolean = false>(parameters: {
        sessionID: string;
        directory?: string;
        title?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<CodingWorkSessionUpdateResponses, CodingWorkSessionUpdateErrors, ThrowOnError, "fields">;
    /**
     * Abort right sidebar Work session
     *
     * Stop active processing for a project-bound right sidebar Work session.
     */
    abort<ThrowOnError extends boolean = false>(parameters: {
        sessionID: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<CodingWorkSessionAbortResponses, CodingWorkSessionAbortErrors, ThrowOnError, "fields">;
    /**
     * Archive or restore right sidebar Work session
     *
     * Stop and archive a Work session, or restore it without restarting execution.
     */
    setArchived<ThrowOnError extends boolean = false>(parameters: {
        sessionID: string;
        directory?: string;
        archived: boolean;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<CodingWorkSessionSetArchivedResponses, CodingWorkSessionSetArchivedErrors, ThrowOnError, "fields">;
    private _selection?;
    get selection(): Selection2;
}
export declare class Sessions2 extends HeyApiClient {
    /**
     * List right sidebar Work sessions
     *
     * List project-bound right sidebar Work sessions. Prompting and history use canonical /session routes.
     */
    list<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
        limit?: number;
        cursorUpdated?: number;
        cursorSessionID?: string;
        search?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<CodingWorkSessionsListResponses, CodingWorkSessionsListErrors, ThrowOnError, "fields">;
}
export declare class Work extends HeyApiClient {
    private _session?;
    get session(): Session2;
    private _sessions?;
    get sessions(): Sessions2;
}
export declare class Coding extends HeyApiClient {
    private _chat?;
    get chat(): Chat2;
    private _cli?;
    get cli(): Cli;
    private _work?;
    get work(): Work;
}
export declare class Command extends HeyApiClient {
    /**
     * List commands
     *
     * Get a list of all available commands in the OpenCorvus system.
     */
    list<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<CommandListResponses, CommandListErrors, ThrowOnError, "fields">;
}
export declare class Computer extends HeyApiClient {
    /**
     * Return the current desktop to Agent automation
     *
     * Issue a new Agent run capability for the preserved desktop session. The next adapter starts without observation authority.
     */
    return<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        computerID: string;
        displayID: string;
        sessionID: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ComputerReturnResponses, ComputerReturnErrors, ThrowOnError, "fields">;
    /**
     * Get Computer desktop ownership
     *
     * Read the exact host-owned desktop session identity and current input owner.
     */
    status<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        computerID: string;
        displayID: string;
        sessionID: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ComputerStatusResponses, ComputerStatusErrors, ThrowOnError, "fields">;
    /**
     * Take over the current desktop
     *
     * Revoke the exact Agent run and disconnect its adapter while preserving the native desktop session for the user.
     */
    takeover<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        computerID: string;
        displayID: string;
        sessionID: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ComputerTakeoverResponses, ComputerTakeoverErrors, ThrowOnError, "fields">;
}
export declare class Proxy_ extends HeyApiClient {
    /**
     * Test network proxy
     *
     * Run a single HTTP request through the submitted network.proxy settings. This uses the edited proxy draft directly and never falls back to a direct request.
     */
    test<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        networkProxyTestRequest: NetworkProxyTestRequest;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ConfigProxyTestResponses, ConfigProxyTestErrors, ThrowOnError, "fields">;
}
export declare class Config extends HeyApiClient {
    /**
     * Get configuration
     *
     * Retrieve the current OpenCorvus configuration settings and preferences.
     */
    get<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ConfigGetResponses, ConfigGetErrors, ThrowOnError, "fields">;
    /**
     * Update configuration (JSON Merge Patch)
     *
     * Partially update OpenCorvus configuration per RFC 7396. Only include fields to change; set a field to null to delete it.
     */
    update<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
        body?: {
            [key: string]: unknown;
        };
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ConfigUpdateResponses, ConfigUpdateErrors, ThrowOnError, "fields">;
    /**
     * List prompt catalog
     *
     * Returns all configurable prompt slots (system-scope and agent-scope) with their defaults and any user overrides from config.
     */
    prompt<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
        sessionID?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ConfigPromptResponses, ConfigPromptErrors, ThrowOnError, "fields">;
    /**
     * List config providers
     *
     * Get a list of all configured AI providers and their default models.
     */
    providers<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ConfigProvidersResponses, ConfigProvidersErrors, ThrowOnError, "fields">;
    private _proxy?;
    get proxy(): Proxy_;
}
export declare class ContinuousGoal extends HeyApiClient {
    /**
     * Read continuous goal
     *
     * Read the ongoing goal for a Chat Session, Task or Mission Session in the selected Project. Separate from Delivery Slice Goals.
     */
    get<ThrowOnError extends boolean = false>(parameters: {
        kind: "chat" | "task" | "mission";
        ownerID: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ContinuousGoalGetResponses, ContinuousGoalGetErrors, ThrowOnError, "fields">;
    /**
     * Update continuous goal
     *
     * Pause, explicitly resume, block, complete or change explicit budgets using the exact current goal ID and revision. Usage remains cumulative.
     */
    update<ThrowOnError extends boolean = false>(parameters: {
        kind: "chat" | "task" | "mission";
        ownerID: string;
        directory?: string;
        expectedRevision: string;
        goalID: string;
        reason: string;
        requestID: string;
        status: "active" | "paused" | "blocked" | "complete";
        tokenBudget?: number;
        turnBudget?: number;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ContinuousGoalUpdateResponses, ContinuousGoalUpdateErrors, ThrowOnError, "fields">;
    /**
     * Create continuous goal
     *
     * Explicitly authorize an ongoing goal on an existing owner. requestID is idempotent; one unresolved goal per execution scope.
     */
    create<ThrowOnError extends boolean = false>(parameters: {
        kind: "chat" | "task" | "mission";
        ownerID: string;
        directory?: string;
        objective: string;
        requestID: string;
        tokenBudget?: number;
        turnBudget?: number;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ContinuousGoalCreateResponses, ContinuousGoalCreateErrors, ThrowOnError, "fields">;
}
export declare class Event_ extends HeyApiClient {
    /**
     * Subscribe to events
     *
     * Get events
     */
    subscribe<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError, EventSubscribeResponse>): Promise<import("./core/serverSentEvents.gen.js").ServerSentEventsResult<EventSubscribeResponses>>;
}
export declare class Eventschedule extends HeyApiClient {
    /**
     * List event-triggered tasks
     */
    list<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ExperimentalEventscheduleListResponses, ExperimentalEventscheduleListErrors, ThrowOnError, "fields">;
    /**
     * Create event-triggered task
     */
    create<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        cooldownMs?: number;
        eventType: string;
        match?: {
            [key: string]: string | number | boolean;
        };
        name: string;
        oneShot?: boolean;
        prompt: string;
        sessionId?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ExperimentalEventscheduleCreateResponses, ExperimentalEventscheduleCreateErrors, ThrowOnError, "fields">;
    /**
     * Cancel event-triggered task
     */
    delete<ThrowOnError extends boolean = false>(parameters: {
        id: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ExperimentalEventscheduleDeleteResponses, ExperimentalEventscheduleDeleteErrors, ThrowOnError, "fields">;
}
export declare class Memory extends HeyApiClient {
    /**
     * Get the Session MEMORY.MD document
     */
    get<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        sessionId: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ExperimentalMemoryGetResponses, ExperimentalMemoryGetErrors, ThrowOnError, "fields">;
}
export declare class ProjectMemory extends HeyApiClient {
    /**
     * Get the organized Project MEMORY.MD context
     */
    get<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ExperimentalProjectMemoryGetResponses, unknown, ThrowOnError, "fields">;
    /**
     * Acknowledge a Project MEMORY.MD notice
     */
    acknowledgeNotice<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        generation: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ExperimentalProjectMemoryAcknowledgeNoticeResponses, unknown, ThrowOnError, "fields">;
    /**
     * Request Project MEMORY.MD organization
     */
    organize<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ExperimentalProjectMemoryOrganizeResponses, unknown, ThrowOnError, "fields">;
}
export declare class Resource extends HeyApiClient {
    /**
     * Get MCP resources
     *
     * Get all available MCP resources from connected servers. Optionally filter by name.
     */
    list<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ExperimentalResourceListResponses, ExperimentalResourceListErrors, ThrowOnError, "fields">;
}
export declare class Taskplan extends HeyApiClient {
    /**
     * List tasks for a session
     */
    list<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        sessionId: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ExperimentalTaskplanListResponses, ExperimentalTaskplanListErrors, ThrowOnError, "fields">;
}
export declare class Workspace extends HeyApiClient {
    /**
     * List workspaces
     *
     * List all workspaces.
     */
    list<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ExperimentalWorkspaceListResponses, unknown, ThrowOnError, "fields">;
    /**
     * Remove workspace
     *
     * Remove an existing workspace.
     */
    remove<ThrowOnError extends boolean = false>(parameters: {
        id: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ExperimentalWorkspaceRemoveResponses, ExperimentalWorkspaceRemoveErrors, ThrowOnError, "fields">;
    /**
     * Create workspace
     *
     * Create a workspace for the current project.
     */
    create<ThrowOnError extends boolean = false>(parameters: {
        id: string;
        directory?: string;
        body?: {
            [key: string]: never;
        };
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ExperimentalWorkspaceCreateResponses, ExperimentalWorkspaceCreateErrors, ThrowOnError, "fields">;
}
export declare class Experimental extends HeyApiClient {
    private _eventschedule?;
    get eventschedule(): Eventschedule;
    private _memory?;
    get memory(): Memory;
    private _projectMemory?;
    get projectMemory(): ProjectMemory;
    private _resource?;
    get resource(): Resource;
    private _taskplan?;
    get taskplan(): Taskplan;
    private _workspace?;
    get workspace(): Workspace;
}
export declare class Tool extends HeyApiClient {
    /**
     * List tools
     *
     * Get built-in core registry tool definitions for a provider and model. Active package and MCP tools are projected separately at runtime.
     */
    list<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        provider: string;
        model: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ToolListResponses, ToolListErrors, ThrowOnError, "fields">;
    /**
     * List tool IDs
     *
     * Get the built-in core registry tool IDs. This is not an active runtime capability projection.
     */
    ids<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ToolIdsResponses, ToolIdsErrors, ThrowOnError, "fields">;
}
export declare class Worktree extends HeyApiClient {
    /**
     * Remove worktree
     *
     * Remove a git worktree and delete its branch.
     */
    remove<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        worktreeRemoveInput: WorktreeRemoveInput;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<WorktreeRemoveResponses, WorktreeRemoveErrors, ThrowOnError, "fields">;
    /**
     * List worktrees
     *
     * List all sandbox worktrees for the current project.
     */
    list<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<WorktreeListResponses, unknown, ThrowOnError, "fields">;
    /**
     * Create worktree
     *
     * Create a new git worktree for the current project and run any configured startup scripts.
     */
    create<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
        worktreeCreateInput?: WorktreeCreateInput;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<WorktreeCreateResponses, WorktreeCreateErrors, ThrowOnError, "fields">;
    /**
     * Reset worktree
     *
     * Reset a worktree branch to the primary default branch.
     */
    reset<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        worktreeResetInput: WorktreeResetInput;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<WorktreeResetResponses, WorktreeResetErrors, ThrowOnError, "fields">;
}
export declare class Configuration extends HeyApiClient {
    /**
     * Get expert squad configuration
     *
     * Returns declared configuration fields and redacted configured state for one installed expert squad. Secret values are never returned.
     */
    get<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        id: string;
        installationScope: "project" | "global";
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ExpertSquadConfigurationGetResponses, ExpertSquadConfigurationGetErrors, ThrowOnError, "fields">;
    /**
     * Update expert squad configuration
     *
     * Atomically updates or clears declared user-global configuration fields for one installed expert squad. Secret values remain write-only.
     */
    update<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        id: string;
        installationScope: "project" | "global";
        updates: {
            [key: string]: string | boolean | null;
        };
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ExpertSquadConfigurationUpdateResponses, ExpertSquadConfigurationUpdateErrors, ThrowOnError, "fields">;
}
export declare class ExpertSquad extends HeyApiClient {
    /**
     * Resolve the active expert-squad capability projection
     *
     * Returns only the active runtime projection for the current project or session. Use bounded search and exact inspection for inactive packages. Task sessions remain pinned to their creation-time package revision.
     */
    catalog<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
        sessionID?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ExpertSquadCatalogResponses, ExpertSquadCatalogErrors, ThrowOnError, "fields">;
    /**
     * Page Expert Squad discovery diagnostics
     *
     * Returns at most 20 discovery issues or override warnings from the current catalog snapshot.
     */
    diagnostics<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
        cursor?: string;
        limit?: number;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ExpertSquadDiagnosticsResponses, ExpertSquadDiagnosticsErrors, ThrowOnError, "fields">;
    /**
     * Authorize an expert squad evolution mutation
     *
     * Revalidates immutable evolution evidence, records the exact confirmation as one ordinary visible Task-root user Turn, and wakes the existing Orchestrator conversation.
     */
    evolutionAuthorization<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        confirmationText: string;
        intent: {
            campaignSpecLocator: {
                artifact_id: string;
                catalog_revision: number;
                expected_sha256: string;
                source: "engine_artifact";
            };
            candidateRevisionLocator: {
                artifact_id: string;
                catalog_revision: number;
                expected_sha256: string;
                source: "engine_artifact";
            };
            comparisonResultLocator: {
                artifact_id: string;
                catalog_revision: number;
                expected_sha256: string;
                source: "engine_artifact";
            };
            expectedCurrentPackageDigest: string;
            operation: "promotion";
        } | {
            expectedCurrentPackageDigest: string;
            operation: "restoration";
            priorReceiptLocator: {
                artifact_id: string;
                catalog_revision: number;
                expected_sha256: string;
                source: "engine_artifact";
            };
            restorePackageDigest: string;
        } | {
            candidateRevisionLocator: {
                artifact_id: string;
                catalog_revision: number;
                expected_sha256: string;
                source: "engine_artifact";
            };
            expectedCurrentPackageDigest: string;
            operation: "feedback_revision";
        };
        sessionID: string;
        taskID: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ExpertSquadEvolutionAuthorizationResponses, ExpertSquadEvolutionAuthorizationErrors, ThrowOnError, "fields">;
    /**
     * Read expert squad evolution history
     *
     * Reads one current Project's immutable Evolution Artifact graph for an exact installed project or global expert-squad target at a frozen Artifact Catalog revision.
     */
    evolutionHistory<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        namespace: string;
        id: string;
        installationScope: "project" | "global";
        limit?: number;
        catalogRevisionUpper?: number;
        beforeCatalogRevision?: number;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ExpertSquadEvolutionHistoryResponses, ExpertSquadEvolutionHistoryErrors, ThrowOnError, "fields">;
    /**
     * Read one exact expert squad evolution campaign
     *
     * Validates one current-Project Campaign root before reading its exact Candidate, Comparison, run, evaluation, scorer, integrity, and mutation receipt graph inside one frozen Artifact Catalog snapshot.
     */
    evolutionHistoryDetail<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        campaignLocator: {
            artifact_id: string;
            catalog_revision: number;
            expected_sha256: string;
            source: "engine_artifact";
        };
        campaignTaskID: string;
        candidateLocator: {
            artifact_id: string;
            catalog_revision: number;
            expected_sha256: string;
            source: "engine_artifact";
        };
        catalogRevisionUpper: number;
        comparisonLocator: {
            artifact_id: string;
            catalog_revision: number;
            expected_sha256: string;
            source: "engine_artifact";
        };
        id: string;
        installationScope: "project" | "global";
        namespace: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ExpertSquadEvolutionHistoryDetailResponses, ExpertSquadEvolutionHistoryDetailErrors, ThrowOnError, "fields">;
    /**
     * Execute an authorized expert squad evolution mutation
     *
     * Verifies one exact visible user confirmation and immutable evolution evidence, performs one package-manager compare-and-swap promotion or restoration, and publishes the Core-owned receipt.
     */
    evolutionMutation<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        body: {
            authorization: {
                messageID: string;
                sessionID: string;
                taskID: string;
            };
            campaignSpecLocator: {
                artifact_id: string;
                catalog_revision: number;
                expected_sha256: string;
                source: "engine_artifact";
            };
            candidateRevisionLocator: {
                artifact_id: string;
                catalog_revision: number;
                expected_sha256: string;
                source: "engine_artifact";
            };
            comparisonResultLocator: {
                artifact_id: string;
                catalog_revision: number;
                expected_sha256: string;
                source: "engine_artifact";
            };
            expectedCurrentPackageDigest: string;
            operation: "promotion";
        } | {
            authorization: {
                messageID: string;
                sessionID: string;
                taskID: string;
            };
            expectedCurrentPackageDigest: string;
            operation: "restoration";
            priorReceiptLocator: {
                artifact_id: string;
                catalog_revision: number;
                expected_sha256: string;
                source: "engine_artifact";
            };
            restorePackageDigest: string;
        } | {
            authorization: {
                messageID: string;
                sessionID: string;
                taskID: string;
            };
            candidateRevisionLocator: {
                artifact_id: string;
                catalog_revision: number;
                expected_sha256: string;
                source: "engine_artifact";
            };
            expectedCurrentPackageDigest: string;
            operation: "feedback_revision";
        };
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ExpertSquadEvolutionMutationResponses, ExpertSquadEvolutionMutationErrors, ThrowOnError, "fields">;
    /**
     * Export an expert squad ZIP archive
     *
     * Validate and pack a canonical expert-squad package discovered from the global or current-project expert-squad catalog.
     */
    export<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        id: string;
        installationScope: "project" | "global";
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ExpertSquadExportResponses, ExpertSquadExportErrors, ThrowOnError, "fields">;
    /**
     * Import an exact hosted expert squad ZIP revision
     *
     * Validate and install one downloaded ZIP only when its exact namespace, id, version, and canonical package digest match the web-to-client handoff target.
     */
    importExactFile<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        archiveBase64: string;
        expectedCurrentPackageDigest?: string;
        expectedID: string;
        expectedNamespace: string;
        expectedPackageDigest: string;
        expectedVersion: string;
        filename?: string;
        installationScope: "project" | "global";
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ExpertSquadImportExactFileResponses, ExpertSquadImportExactFileErrors, ThrowOnError, "fields">;
    /**
     * Import an expert squad ZIP archive
     *
     * Validate and install a dropped expert-squad ZIP archive into the explicitly selected project or user-global expert-squad catalog.
     */
    importFile<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        archiveBase64: string;
        expectedCurrentPackageDigest?: string;
        filename?: string;
        installationScope: "project" | "global";
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ExpertSquadImportFileResponses, ExpertSquadImportFileErrors, ThrowOnError, "fields">;
    /**
     * Import an expert squad folder
     *
     * Validate and install a local expert-squad package folder into the explicitly selected project or user-global expert-squad catalog.
     */
    importFolder<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        expectedCurrentPackageDigest?: string;
        installationScope: "project" | "global";
        sourceDirectory: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ExpertSquadImportFolderResponses, ExpertSquadImportFolderErrors, ThrowOnError, "fields">;
    /**
     * Inspect one expert-squad declaration
     *
     * Returns bounded selector and workflow guidance for one exact effective or physical installation identity.
     */
    inspect<ThrowOnError extends boolean = false>(parameters: {
        directory: string;
        id: string;
        installationScope?: "built_in" | "project" | "global";
        namespace?: string;
        workflowCursor?: string;
        agentCursor?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ExpertSquadInspectResponses, ExpertSquadInspectErrors, ThrowOnError, "fields">;
    /**
     * Install one bundled expert squad
     *
     * Installs the selected bundled expert-squad payload package into the explicitly selected project or user-global catalog without activating or overwriting it. If that scope already contains the package, installed is false and version/packageDigest describe the existing bytes at targetRoot.
     */
    installPayload<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        id: string;
        installationScope: "project" | "global";
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ExpertSquadInstallPayloadResponses, ExpertSquadInstallPayloadErrors, ThrowOnError, "fields">;
    /**
     * Get expert-squad inventory status
     *
     * Returns declaration and diagnostic counts without package bodies or unbounded diagnostic arrays.
     */
    inventoryStatus<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ExpertSquadInventoryStatusResponses, ExpertSquadInventoryStatusErrors, ThrowOnError, "fields">;
    /**
     * Browse bundled expert squads
     *
     * Returns a bounded manifest-derived page of bundled expert-squad payload packages. Rich package and update detail is loaded only for an exact selection.
     */
    market<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
        query?: string;
        availability?: "all" | "available" | "installed";
        productPillar?: "code" | "work";
        cursor?: string;
        limit?: number;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ExpertSquadMarketResponses, ExpertSquadMarketErrors, ThrowOnError, "fields">;
    /**
     * Inspect one bundled expert squad
     *
     * Returns digest, selector, agents, capability counts, and exact installation revisions for one selection.
     */
    marketDetail<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        id: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ExpertSquadMarketDetailResponses, ExpertSquadMarketDetailErrors, ThrowOnError, "fields">;
    /**
     * Preview a Multica squad import
     *
     * Fetches and validates the selected Multica squad graph and returns its canonical target identity, source digest, blockers, and non-portable evidence without writing project state.
     */
    multicaPreview<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        mapping: {
            agents: {
                [key: string]: {
                    base_role: "delegated-worker" | "intent-analysis" | "requirements" | "architect" | "goal-workload-analyst" | "build" | "explore" | "deep-research" | "frontend-research" | "frontend-design" | "visual-qa" | "integrity" | "fact-check";
                };
            };
            mcp_omissions: Array<{
                reason: string;
                source_agent_id: string;
                source_server_name: string;
            }>;
            mcp_replacements: Array<{
                source_agent_id: string;
                source_server_name: string;
                target: "opencorvus-browser";
            }>;
            virtual_workflows?: {
                [key: string]: {
                    description: string;
                    guidance?: string;
                    label: string;
                    nodes?: {
                        [key: string]: {
                            depends_on: Array<string>;
                            description: string;
                            repeat_until?: string;
                            source_agent_id: string;
                            when?: string;
                        };
                    };
                    strategy?: "adaptive" | "dag" | "loop" | "choice";
                };
            };
        };
        squadID: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ExpertSquadMulticaPreviewResponses, ExpertSquadMulticaPreviewErrors, ThrowOnError, "fields">;
    /**
     * List Multica squads with expert-squad installation status
     *
     * Reads the official default local Multica configuration server-side and lists every workspace squad with complete members and authoritative exact-ID installation status from the global and current-project catalog, without exposing the personal access token to Overlay.
     */
    multicaSquads<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ExpertSquadMulticaSquadsResponses, ExpertSquadMulticaSquadsErrors, ThrowOnError, "fields">;
    /**
     * Release bundled expert-squad packages
     *
     * Explicitly provisions bundled expert-squad payload packages into the current project's namespaced .opencorvus expert-squads catalog without overwriting existing packages.
     */
    releasePayload<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ExpertSquadReleasePayloadResponses, ExpertSquadReleasePayloadErrors, ThrowOnError, "fields">;
    /**
     * Replace obsolete bundled Expert Squad installations
     *
     * Replaces older-schema bundled installations in project and global scope with the validated application payload. Preserves prior bytes by digest and returns exact receipts for the client reminder; current-schema and third-party installations retain their contents.
     */
    repairBundled<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ExpertSquadRepairBundledResponses, ExpertSquadRepairBundledErrors, ThrowOnError, "fields">;
    /**
     * Search expert-squad declarations
     *
     * Returns at most twenty manifest-derived entries and an opaque cursor. Rich selector guidance and full package detail require exact follow-up requests.
     */
    search<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
        view?: "effective" | "installations";
        query?: string;
        productPillar?: "code" | "work";
        cursor?: string;
        limit?: number;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ExpertSquadSearchResponses, ExpertSquadSearchErrors, ThrowOnError, "fields">;
    /**
     * Load one full expert-squad settings declaration
     *
     * Loads README, selector instructions, digest, and runtime declaration only for one exact selected identity.
     */
    settingsDetail<ThrowOnError extends boolean = false>(parameters: {
        directory: string;
        id: string;
        installationScope: "built_in" | "project" | "global";
        namespace?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ExpertSquadSettingsDetailResponses, ExpertSquadSettingsDetailErrors, ThrowOnError, "fields">;
    /**
     * Uninstall an expert squad package
     *
     * Explicitly replaces exact global, registered-project, and root-session references with Base, then deletes one non-built-in package from its exact project or user-global installation scope.
     */
    uninstall<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        id: string;
        installationScope: "project" | "global";
        replacementID: "base";
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ExpertSquadUninstallResponses, ExpertSquadUninstallErrors, ThrowOnError, "fields">;
    /**
     * Update an installed expert squad
     *
     * Atomically replaces one exact installed expert-squad package from the current application payload or configured update server without changing prompt_profile.active.
     */
    update<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        expectedCurrentPackageDigest: string;
        id: string;
        installationScope: "project" | "global";
        source: "builtin" | "server";
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ExpertSquadUpdateResponses, ExpertSquadUpdateErrors, ThrowOnError, "fields">;
    /**
     * Validate an expert squad source folder
     *
     * Validates a local expert-squad source folder through the runtime registry without installing, activating, or mutating a project package.
     */
    validateFolder<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        sourceDirectory: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ExpertSquadValidateFolderResponses, ExpertSquadValidateFolderErrors, ThrowOnError, "fields">;
    private _configuration?;
    get configuration(): Configuration;
}
export declare class Export extends HeyApiClient {
    /**
     * Export session messages
     */
    session<ThrowOnError extends boolean = false>(parameters: {
        sessionID: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ExportSessionResponses, ExportSessionErrors, ThrowOnError, "fields">;
}
export declare class File_ extends HeyApiClient {
    /**
     * List files
     *
     * List files and directories in a specified path.
     */
    list<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        path: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<FileListResponses, unknown, ThrowOnError, "fields">;
    /**
     * Read file
     *
     * Read the content of a specified file.
     */
    read<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        path: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<FileReadResponses, FileReadErrors, ThrowOnError, "fields">;
    /**
     * Write file
     *
     * Write text content to an existing editable file only when expectedRevision matches its loaded content and physical identity.
     */
    write<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        content: string;
        expectedRevision: string;
        path: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<FileWriteResponses, FileWriteErrors, ThrowOnError, "fields">;
    /**
     * Delete file item
     *
     * Delete one project file or directory recursively. The project root cannot be deleted.
     */
    delete<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        path: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<FileDeleteResponses, FileDeleteErrors, ThrowOnError, "fields">;
    /**
     * Move file item
     *
     * Move or rename one file or directory within the project directory without overwriting.
     */
    move<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        newPath: string;
        path: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<FileMoveResponses, FileMoveErrors, ThrowOnError, "fields">;
    /**
     * Create file item
     *
     * Create one file or directory under an existing project directory without overwriting.
     */
    create<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        content?: string;
        path: string;
        type: "file" | "directory";
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<FileCreateResponses, FileCreateErrors, ThrowOnError, "fields">;
    /**
     * Copy file item
     *
     * Copy one file or directory within the project directory without overwriting.
     */
    copy<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        newPath: string;
        path: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<FileCopyResponses, FileCopyErrors, ThrowOnError, "fields">;
    /**
     * Read an absolute source file
     *
     * Read the exact absolute file represented by a persisted source-file citation.
     */
    readSource<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        path: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<FileReadSourceResponses, FileReadSourceErrors, ThrowOnError, "fields">;
    /**
     * Get file status
     *
     * Get the git status of all files in the project.
     */
    status<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<FileStatusResponses, unknown, ThrowOnError, "fields">;
    /**
     * Upload files
     *
     * Write dropped files into an existing project directory without overwriting existing files.
     */
    upload<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        files: Array<{
            contentBase64: string;
            mimeType?: string;
            name: string;
        }>;
        targetDir: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<FileUploadResponses, FileUploadErrors, ThrowOnError, "fields">;
}
export declare class Find extends HeyApiClient {
    /**
     * Find text
     *
     * Search for text patterns across files in the project using ripgrep.
     */
    text<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        pattern: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<FindTextResponses, FindTextErrors, ThrowOnError, "fields">;
    /**
     * Find files
     *
     * Search for files or directories by name or pattern in the project directory.
     */
    files<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        query: string;
        dirs?: "true" | "false";
        type?: "file" | "directory";
        limit?: number;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<FindFilesResponses, FindFilesErrors, ThrowOnError, "fields">;
}
export declare class Formatter extends HeyApiClient {
    /**
     * Get formatter status
     *
     * Get formatter status
     */
    status<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<FormatterStatusResponses, unknown, ThrowOnError, "fields">;
}
export declare class Channel2 extends HeyApiClient {
    /**
     * Handle gateway channel message
     *
     * Bridge an external channel message through gateway routing into the shared channel ingress path.
     */
    message<ThrowOnError extends boolean = false>(parameters: {
        path_platform: string;
        directory?: string;
        allow_create?: boolean;
        allow_session_mutation?: boolean;
        attachments?: Array<{
            data?: string;
            filename: string;
            mime: string;
            url?: string;
        }>;
        bind?: boolean;
        channel: string;
        model?: string;
        body_platform?: "slack" | "telegram" | "discord" | "feishu" | "whatsapp" | "googlechat" | "msteams" | "line" | "matrix" | "mattermost" | "signal" | "wecom" | "dingtalk" | "clickclack" | "imessage" | "irc" | "nextcloud-talk" | "nostr" | "qqbot" | "raft" | "reef" | "sms" | "synology-chat" | "tlon" | "twitch" | "zalo" | "zalouser";
        request_id: string;
        source?: string;
        task_id?: string;
        text: string;
        thread: string;
        user_id?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<GatewayChannelMessageResponses, unknown, ThrowOnError, "fields">;
}
export declare class Control extends HeyApiClient {
    /**
     * Run gateway control action
     *
     * Execute a structured gateway capability action without LLM interpretation.
     */
    action<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        body: {
            action: "expert_squad_inspect";
            /**
             * Opaque next_agent_cursor from this exact candidate inspection.
             */
            agentCursor?: string;
            /**
             * Exact installed Expert Squad manifest ID returned by capability_search; Mission must hold it.
             */
            id: string;
            /**
             * Opaque next_workflow_cursor returned by the preceding inspection of this exact Squad.
             */
            workflowCursor?: string;
        } | {
            action: "multica_catalog";
        } | {
            action: "query_task";
            /**
             * Additional details for explicit taskIDs.
             */
            include?: Array<"board" | "plan">;
            /**
             * Include pending interaction counts for each requested task.
             */
            includeInteractions?: boolean;
            /**
             * Exact Task IDs to inspect; omit to list Tasks.
             */
            taskIDs?: Array<string>;
        } | {
            action: "query_task_artifacts";
            queries: Array<{
                /**
                 * Optional exact namespaced Artifact-type filter.
                 */
                artifact_types?: Array<string>;
                /**
                 * Optional inclusive lower creation-time bound in Unix milliseconds.
                 */
                created_at_or_after_ms?: number;
                /**
                 * Optional exclusive upper creation-time bound in Unix milliseconds.
                 */
                created_before_ms?: number;
                /**
                 * Opaque cursor returned by the preceding page; omit it for the first page.
                 */
                cursor?: string;
                /**
                 * Optional exact logical Goal-subject filter.
                 */
                goal_ids?: Array<string>;
                /**
                 * Optional exact source-Task lineage filter for imported Engine Artifacts. Non-imported entries never match.
                 */
                import_source_task_ids?: Array<string>;
                /**
                 * Optional exact persisted Artifact-kind filter.
                 */
                kinds?: Array<string>;
                /**
                 * Optional exact stable Artifact-label filter.
                 */
                labels?: Array<string>;
                /**
                 * Optional exact resource media-type filter.
                 */
                media_types?: Array<string>;
                /**
                 * Start at 1; continue using next_queries.
                 */
                page_number: number;
                /**
                 * Optional exact projected producer Agent-identity filter. Core-owned typed projections never match this filter; select those by label, kind, artifact type, or Goal.
                 */
                producer_agent_ids?: Array<string>;
                /**
                 * Optional exact projected or Mission producer Session identity filter. Core-owned typed projections never match this filter.
                 */
                producer_session_ids?: Array<string>;
                /**
                 * Optional exact projected producer Expert Squad identity filter. Core-owned typed projections never match this filter.
                 */
                producer_squad_ids?: Array<string>;
                /**
                 * Optional hierarchical candidate query over bounded catalog identity, label, type, producer, Goal, and resource metadata. Fuzzy mode is explicit and never selects evidence. Omit query to enumerate.
                 */
                query?: {
                    mode?: "substring" | "fuzzy";
                    text: string;
                };
                /**
                 * Explicit candidate order. Defaults to relevance when query is present and newest otherwise.
                 */
                sort?: "relevance" | "newest" | "oldest" | "name";
                /**
                 * Optional authoritative-store filter. Omit it to include every catalog provider.
                 */
                sources?: Array<"engine_artifact" | "task_artifact">;
                /**
                 * Source Task whose immutable Artifact catalog should be queried.
                 */
                taskID: string;
                /**
                 * Engine version scope at the frozen catalog revision. Task Artifact snapshots are immutable.
                 */
                version_scope?: "current" | "historical" | "all";
            }>;
        } | {
            action: "read_task_artifact";
            reads: Array<{
                /**
                 * Host-minted reference to one exact locator emitted earlier in this Session Turn.
                 */
                artifact_locator_ref: string;
                artifact_transport_version: 2;
                /**
                 * Zero-based byte offset within the exact locator identified by artifact_locator_ref.
                 */
                byte_offset?: number;
                /**
                 * inline returns one bounded content chunk. materialized_file verifies one complete text resource and returns an immutable local cache path for bounded command-line inspection.
                 */
                delivery?: "inline" | "materialized_file";
                /**
                 * Maximum UTF-8 text bytes to return in this exact-read chunk. Binary resources use one complete attachment and ignore text pagination.
                 */
                max_bytes?: number;
                taskID: string;
            }>;
        } | {
            action: "read_task_message";
            /**
             * Aggregate UTF-8 text byte window for this batch call; defaults to 30,000.
             */
            max_bytes?: number;
            /**
             * One to eight exact Completion Decision Message identities or Host-returned continuations, each Message listed once.
             */
            messages: Array<{
                /**
                 * UTF-8 offset. Omit it or use 0 for an initial Message identity; a positive continuation offset requires the exact text_part_id returned in next_messages.
                 */
                byte_offset?: number;
                /**
                 * Exact Message ID named by the current Completion Decision.
                 */
                messageID: string;
                /**
                 * Exact Session ID named by the current Completion Decision.
                 */
                sessionID: string;
                /**
                 * Exact text Part ID returned in next_messages.
                 */
                text_part_id?: string;
            }>;
            /**
             * Terminal source Task in the current Mission lineage.
             */
            taskID: string;
        } | {
            action: "read_task_dispatch_evidence";
            /**
             * Optional exact visible text, Tool input, output, or failure chunks from the selected sources' causal Part inventory in this or an earlier call. Use field='text' for a text Part, including narration in earlier assistant Messages. Keep sources anchored to the settled final; earlier message_id values are chunk targets, not dispatch_result anchors. Copy returned message_id and part_id values exactly. Each omitted limit requests 8000 characters, even for a short field. The sum of every effective limit in one call must be at most 30000 characters. At most 3 reads fit with all limits omitted. For 4–8 reads, explicitly allocate limits within that total; eight reads can each request 3750 characters. Follow next_offset until null.
             */
            evidence_reads?: Array<{
                field: "text" | "input" | "output" | "failure";
                /**
                 * Requested character budget for this chunk; omission consumes 8000 of the 30000-character aggregate call budget.
                 */
                limit?: number;
                message_id: string;
                offset?: number;
                part_id: string;
            }>;
            /**
             * Optional older-page cursors returned by a prior causal Part Message inventory.
             */
            inventory_before?: Array<{
                before_message_id: string;
                before_part_id: string;
                source: {
                    kind: "dispatch_result";
                    message_id: string;
                } | {
                    dispatch_id: string;
                    kind: "dispatch_origin";
                };
            }>;
            /**
             * One to eight ordered Task evidence sources: an exact physically settled worker final report or the root Tool facts preceding an exact dispatch.
             */
            sources: Array<{
                kind: "dispatch_result";
                message_id: string;
            } | {
                dispatch_id: string;
                kind: "dispatch_origin";
            }>;
            /**
             * Current failed child Task in this Mission lineage.
             */
            taskID: string;
        } | {
            action: "complete_mission";
            /**
             * Concise user-facing summary of the accepted Mission outcome.
             */
            summary: string;
            /**
             * Complete current Mission child-Task acceptance set. Empty is valid only when Mission completed bounded coordination without child Tasks.
             */
            task_acceptances: Array<{
                /**
                 * Complete supplied reference set whose persisted chunks cover every byte of each accepted Artifact in this Task's exact current terminal occurrence.
                 */
                evidence_read_refs: Array<string>;
                /**
                 * Current child Task accepted by this Mission decision.
                 */
                task_id: string;
            }>;
        } | {
            action: "block_mission";
            /**
             * Truthful user-facing summary of the blocked Mission.
             */
            summary: string;
            /**
             * Complete current child-Task set and exact fully read evidence for each terminal occurrence.
             */
            task_reviews: Array<{
                /**
                 * Complete supplied reference set whose persisted chunks cover every byte of each accepted Artifact in this Task's exact current terminal occurrence.
                 */
                evidence_read_refs: Array<string>;
                /**
                 * Current terminal child Task reviewed before blocking this Mission.
                 */
                task_id: string;
            }>;
            /**
             * Original outcome obligations that remain unmet because of the evidenced external authority or capability boundary.
             */
            unresolved_criteria: Array<string>;
        } | {
            action: "create_task";
            /**
             * Set false to return without creating a task.
             */
            allow_create?: boolean;
            /**
             * External channel identifier to bind to the new task.
             */
            channel?: string;
            /**
             * Host verification check configuration for the new task.
             */
            checks?: {
                artifact?: {
                    min_changed_files?: number;
                    mode?: "soft" | "strict";
                    require_changed_files?: boolean;
                    require_diff?: boolean;
                    require_summary?: boolean;
                };
                /**
                 * Explicit build commands, or false to disable discovered build commands.
                 */
                build?: Array<string> | false;
                code_quality?: {
                    enabled?: boolean;
                    max_diffs?: number;
                    mode?: "soft" | "strict";
                    prompt?: string;
                };
                code_review?: {
                    enabled?: boolean;
                    max_diffs?: number;
                    mode?: "soft" | "strict";
                    prompt?: string;
                };
                dead_code_review?: {
                    enabled?: boolean;
                    max_diffs?: number;
                    mode?: "soft" | "strict";
                    prompt?: string;
                };
                judge?: {
                    enabled?: boolean;
                    mode?: "soft" | "strict";
                    prompt?: string;
                };
                /**
                 * Explicit lint commands, or false to disable discovered lint commands.
                 */
                lint?: Array<string> | false;
                /**
                 * Host-authored named check definitions keyed by stable check name.
                 */
                named?: {
                    [key: string]: {
                        /**
                         * Executable shell commands for this named check.
                         */
                        commands: Array<string>;
                        /**
                         * Optional project-relative working directory for the commands.
                         */
                        cwd?: string;
                        /**
                         * Whether this named check is enabled.
                         */
                        enabled?: boolean;
                        /**
                         * Check result family used for acceptance reporting.
                         */
                        family?: "build" | "test" | "lint" | "verify_cmd";
                        /**
                         * Human-readable check label.
                         */
                        label?: string;
                    };
                };
                playwright?: {
                    browser?: "chrome" | "edge" | "chromium";
                    executable_path?: string;
                    full_page?: boolean;
                    mode?: "soft" | "strict";
                    require_text?: Array<string>;
                    require_title?: string;
                    target: "web";
                    timeout_ms?: number;
                    url: string;
                    viewport?: {
                        height?: number;
                        width?: number;
                    };
                    wait_for_selector?: string;
                    wait_for_text?: string;
                };
                spec_check?: {
                    enabled?: boolean;
                    mode?: "soft" | "strict";
                    prompt?: string;
                };
                startup?: {
                    command: string;
                    mode?: "soft" | "strict";
                    ready_text?: string;
                    ready_url?: string;
                    require_exit_zero?: boolean;
                    timeout_ms?: number;
                    warmup_ms?: number;
                };
                /**
                 * Explicit test commands, or false to disable discovered test commands.
                 */
                test?: Array<string> | false;
                timeout_ms?: number;
                ui_review?: {
                    focus?: Array<"layout" | "hierarchy" | "clarity" | "navigation" | "feedback" | "accessibility">;
                    mode?: "soft" | "strict";
                    prompt?: string;
                    target: "web";
                    timeout_ms?: number;
                    url?: string;
                };
                /**
                 * Explicit end-to-end verification commands, or false to disable them.
                 */
                verify_cmd?: Array<string> | false;
                visual?: {
                    mode?: "soft" | "strict";
                    require_text?: Array<string>;
                    require_title?: string;
                    target: "web";
                    timeout_ms?: number;
                    url: string;
                };
            };
            /**
             * Absolute execution repository for the new Task. Sessions, tools, artifacts, and git operations use this directory while Task storage remains in the caller project.
             */
            directory?: string;
            /**
             * Optional compare-and-swap assertion for the exact immutable expert-squad package revision resolved at Task creation.
             */
            expectedPackageDigest?: string;
            /**
             * Structured metadata to attach to the new task. Creator identity fields are server-owned.
             */
            metadata?: {
                actor?: unknown;
                actor_session_id?: unknown;
                mission?: unknown;
                [key: string]: unknown;
            };
            /**
             * Model reference in provider/model format for the new task.
             */
            model?: string;
            /**
             * Channel platform for an external task binding.
             */
            platform?: "slack" | "telegram" | "discord" | "feishu" | "whatsapp" | "googlechat" | "msteams" | "line" | "matrix" | "mattermost" | "signal" | "wecom" | "dingtalk" | "clickclack" | "imessage" | "irc" | "nextcloud-talk" | "nostr" | "qqbot" | "raft" | "reef" | "sms" | "synology-chat" | "tlon" | "twitch" | "zalo" | "zalouser";
            /**
             * Product pillar for direct panel-UI creation. Mission and conversation callers inherit their persisted pillar.
             */
            productPillar?: "code" | "work";
            /**
             * Exact expert-squad manifest ID that owns the new Task for its full lifetime. Preserve an explicit operator selection. Otherwise search installed candidates and inspect promising identities before choosing; use Dynamic only when none is very well matched. Mission stays within its held set. No creator omits this exact identity.
             */
            promptProfile: string;
            /**
             * Full user request to execute in the new task.
             */
            request: string;
            /**
             * External request ID used for idempotent task creation.
             */
            request_id?: string;
            /**
             * Business source label for the new task.
             */
            source?: string;
            /**
             * External thread identifier to bind to the new task.
             */
            thread?: string;
            /**
             * Short task title shown in the project board.
             */
            title?: string;
        } | {
            action: "wake_mission";
            /**
             * Complete user-visible popup question, in the user's language, that explains why durable Mission orchestration is recommended for this request and asks whether to route there.
             */
            reason: string;
            /**
             * Full workflow request to hand to Mission.
             */
            request: string;
            /**
             * Short Mission title shown in the Work Ledger.
             */
            title?: string;
        } | {
            action: "wake_work";
            /**
             * Complete user-visible popup question, in the user's language, that restates the user's explicit request to continue in Work and asks for confirmation.
             */
            reason: string;
            /**
             * Full request to hand to Work.
             */
            request: string;
            /**
             * Short title shown for the new Work conversation.
             */
            title?: string;
        } | {
            action: "send_task_message";
            /**
             * Explicit provider/model reference for this Task continuation.
             */
            model?: string;
            /**
             * Business source label for the follow-up message.
             */
            source: string;
            /**
             * Task ID that should receive the follow-up message.
             */
            taskID: string;
            /**
             * Follow-up message text to append to the task.
             */
            text: string;
            /**
             * External user ID associated with the follow-up message.
             */
            user_id?: string;
        } | {
            /**
             * Full next ledger, retaining the original reviewed occurrence and all open grants; current_ledger_revision_artifact_id must name the active execution's exact current ledger. Use complete reads bound to the current active Task observation.
             */
            acceptance_gap: {
                criteria: Array<{
                    criterion_id: string;
                    disposition: "failed" | "unresolved" | "stale_evidence";
                    finding: string;
                    invalidating_evidence_read_refs: Array<string>;
                    irreducible_blocker_evidence_read_refs: Array<string>;
                    observation_evidence_read_refs: Array<string>;
                    repair_action: {
                        expected_evidence_kind: string;
                        operation: string;
                        parameters: {
                            [key: string]: unknown;
                        };
                        target: string;
                    };
                    repair_evidence_read_refs: Array<string>;
                    resolution_evidence_read_refs: Array<string>;
                    responsibility: {
                        /**
                         * The accountable owner of this exact reviewed Task. Use for root-produced work; no worker lineage is invented.
                         */
                        kind: "task_owner";
                    } | {
                        /**
                         * Exact failed terminal reference from the reviewed Task before its first dispatch. Use this responsibility when execution failed before any workflow or worker lineage was established; never invent a dispatch lineage. Retain this original reference in later ledger revisions.
                         */
                        failure_reference: {
                            terminalEventID: string;
                        };
                        kind: "task_initialization";
                    } | {
                        kind: "workflow_node";
                        workflow_id: string;
                        workflow_node_id: string;
                    } | {
                        agent_id: string;
                        dispatch_lineage_id: string;
                        kind: "direct_dispatch";
                        package_revision: {
                            id: string;
                            namespace: string;
                            package_digest: string;
                            project_id: string | null;
                            scope: "built_in" | "project" | "global";
                            version: string;
                        };
                    };
                    state: "open";
                } | {
                    criterion_id: string;
                    finding: string;
                    invalidating_evidence_read_refs: Array<string>;
                    irreducible_blocker_evidence_read_refs: Array<string>;
                    observation_evidence_read_refs: Array<string>;
                    repair_evidence_read_refs: Array<string>;
                    resolution_evidence_read_refs: Array<string>;
                    responsibility: {
                        /**
                         * The accountable owner of this exact reviewed Task. Use for root-produced work; no worker lineage is invented.
                         */
                        kind: "task_owner";
                    } | {
                        /**
                         * Exact failed terminal reference from the reviewed Task before its first dispatch. Use this responsibility when execution failed before any workflow or worker lineage was established; never invent a dispatch lineage. Retain this original reference in later ledger revisions.
                         */
                        failure_reference: {
                            terminalEventID: string;
                        };
                        kind: "task_initialization";
                    } | {
                        kind: "workflow_node";
                        workflow_id: string;
                        workflow_node_id: string;
                    } | {
                        agent_id: string;
                        dispatch_lineage_id: string;
                        kind: "direct_dispatch";
                        package_revision: {
                            id: string;
                            namespace: string;
                            package_digest: string;
                            project_id: string | null;
                            scope: "built_in" | "project" | "global";
                            version: string;
                        };
                    };
                    state: "accepted";
                } | {
                    criterion_id: string;
                    finding: string;
                    invalidating_evidence_read_refs: Array<string>;
                    irreducible_blocker_evidence_read_refs: Array<string>;
                    observation_evidence_read_refs: Array<string>;
                    repair_evidence_read_refs: Array<string>;
                    resolution_evidence_read_refs: Array<string>;
                    responsibility: {
                        /**
                         * The accountable owner of this exact reviewed Task. Use for root-produced work; no worker lineage is invented.
                         */
                        kind: "task_owner";
                    } | {
                        /**
                         * Exact failed terminal reference from the reviewed Task before its first dispatch. Use this responsibility when execution failed before any workflow or worker lineage was established; never invent a dispatch lineage. Retain this original reference in later ledger revisions.
                         */
                        failure_reference: {
                            terminalEventID: string;
                        };
                        kind: "task_initialization";
                    } | {
                        kind: "workflow_node";
                        workflow_id: string;
                        workflow_node_id: string;
                    } | {
                        agent_id: string;
                        dispatch_lineage_id: string;
                        kind: "direct_dispatch";
                        package_revision: {
                            id: string;
                            namespace: string;
                            package_digest: string;
                            project_id: string | null;
                            scope: "built_in" | "project" | "global";
                            version: string;
                        };
                    };
                    state: "blocked";
                }>;
                current_ledger_revision_artifact_id: string | null;
                gap_id: string;
            };
            action: "extend_task_acceptance";
            taskID: string;
        } | {
            /**
             * Exact failed or unresolved criteria, preserved acceptances, current ledger revision, workflow ownership, and completely read evidence for the next execution epoch. The Host renders the visible Mission repair Message from this single structure.
             */
            acceptance_gap: {
                criteria: Array<{
                    criterion_id: string;
                    disposition: "failed" | "unresolved" | "stale_evidence";
                    finding: string;
                    invalidating_evidence_read_refs: Array<string>;
                    irreducible_blocker_evidence_read_refs: Array<string>;
                    observation_evidence_read_refs: Array<string>;
                    repair_action: {
                        expected_evidence_kind: string;
                        operation: string;
                        parameters: {
                            [key: string]: unknown;
                        };
                        target: string;
                    };
                    repair_evidence_read_refs: Array<string>;
                    resolution_evidence_read_refs: Array<string>;
                    responsibility: {
                        /**
                         * The accountable owner of this exact reviewed Task. Use for root-produced work; no worker lineage is invented.
                         */
                        kind: "task_owner";
                    } | {
                        /**
                         * Exact failed terminal reference from the reviewed Task before its first dispatch. Use this responsibility when execution failed before any workflow or worker lineage was established; never invent a dispatch lineage. Retain this original reference in later ledger revisions.
                         */
                        failure_reference: {
                            terminalEventID: string;
                        };
                        kind: "task_initialization";
                    } | {
                        kind: "workflow_node";
                        workflow_id: string;
                        workflow_node_id: string;
                    } | {
                        agent_id: string;
                        dispatch_lineage_id: string;
                        kind: "direct_dispatch";
                        package_revision: {
                            id: string;
                            namespace: string;
                            package_digest: string;
                            project_id: string | null;
                            scope: "built_in" | "project" | "global";
                            version: string;
                        };
                    };
                    state: "open";
                } | {
                    criterion_id: string;
                    finding: string;
                    invalidating_evidence_read_refs: Array<string>;
                    irreducible_blocker_evidence_read_refs: Array<string>;
                    observation_evidence_read_refs: Array<string>;
                    repair_evidence_read_refs: Array<string>;
                    resolution_evidence_read_refs: Array<string>;
                    responsibility: {
                        /**
                         * The accountable owner of this exact reviewed Task. Use for root-produced work; no worker lineage is invented.
                         */
                        kind: "task_owner";
                    } | {
                        /**
                         * Exact failed terminal reference from the reviewed Task before its first dispatch. Use this responsibility when execution failed before any workflow or worker lineage was established; never invent a dispatch lineage. Retain this original reference in later ledger revisions.
                         */
                        failure_reference: {
                            terminalEventID: string;
                        };
                        kind: "task_initialization";
                    } | {
                        kind: "workflow_node";
                        workflow_id: string;
                        workflow_node_id: string;
                    } | {
                        agent_id: string;
                        dispatch_lineage_id: string;
                        kind: "direct_dispatch";
                        package_revision: {
                            id: string;
                            namespace: string;
                            package_digest: string;
                            project_id: string | null;
                            scope: "built_in" | "project" | "global";
                            version: string;
                        };
                    };
                    state: "accepted";
                } | {
                    criterion_id: string;
                    finding: string;
                    invalidating_evidence_read_refs: Array<string>;
                    irreducible_blocker_evidence_read_refs: Array<string>;
                    observation_evidence_read_refs: Array<string>;
                    repair_evidence_read_refs: Array<string>;
                    resolution_evidence_read_refs: Array<string>;
                    responsibility: {
                        /**
                         * The accountable owner of this exact reviewed Task. Use for root-produced work; no worker lineage is invented.
                         */
                        kind: "task_owner";
                    } | {
                        /**
                         * Exact failed terminal reference from the reviewed Task before its first dispatch. Use this responsibility when execution failed before any workflow or worker lineage was established; never invent a dispatch lineage. Retain this original reference in later ledger revisions.
                         */
                        failure_reference: {
                            terminalEventID: string;
                        };
                        kind: "task_initialization";
                    } | {
                        kind: "workflow_node";
                        workflow_id: string;
                        workflow_node_id: string;
                    } | {
                        agent_id: string;
                        dispatch_lineage_id: string;
                        kind: "direct_dispatch";
                        package_revision: {
                            id: string;
                            namespace: string;
                            package_digest: string;
                            project_id: string | null;
                            scope: "built_in" | "project" | "global";
                            version: string;
                        };
                    };
                    state: "blocked";
                }>;
                current_ledger_revision_artifact_id: string | null;
                gap_id: string;
            };
            action: "resume_task";
            /**
             * Completed or failed source Task in the current Mission lineage.
             */
            taskID: string;
        } | {
            action: "respond_interaction";
            /**
             * Pending interaction ID.
             */
            interactionID: string;
            response: {
                kind: "answer";
                message: string;
            } | {
                kind: "allow_once";
            } | {
                kind: "allow_project";
            } | {
                kind: "reject";
                message?: string;
            };
        } | {
            action: "cancel_task";
            /**
             * Why the task is being cancelled.
             */
            reason: string;
            /**
             * Task ID to cancel.
             */
            taskID: string;
        } | {
            action: "update_checks";
            /**
             * Complete replacement Host verification check configuration.
             */
            checks: {
                artifact?: {
                    min_changed_files?: number;
                    mode?: "soft" | "strict";
                    require_changed_files?: boolean;
                    require_diff?: boolean;
                    require_summary?: boolean;
                };
                /**
                 * Explicit build commands, or false to disable discovered build commands.
                 */
                build?: Array<string> | false;
                code_quality?: {
                    enabled?: boolean;
                    max_diffs?: number;
                    mode?: "soft" | "strict";
                    prompt?: string;
                };
                code_review?: {
                    enabled?: boolean;
                    max_diffs?: number;
                    mode?: "soft" | "strict";
                    prompt?: string;
                };
                dead_code_review?: {
                    enabled?: boolean;
                    max_diffs?: number;
                    mode?: "soft" | "strict";
                    prompt?: string;
                };
                judge?: {
                    enabled?: boolean;
                    mode?: "soft" | "strict";
                    prompt?: string;
                };
                /**
                 * Explicit lint commands, or false to disable discovered lint commands.
                 */
                lint?: Array<string> | false;
                /**
                 * Host-authored named check definitions keyed by stable check name.
                 */
                named?: {
                    [key: string]: {
                        /**
                         * Executable shell commands for this named check.
                         */
                        commands: Array<string>;
                        /**
                         * Optional project-relative working directory for the commands.
                         */
                        cwd?: string;
                        /**
                         * Whether this named check is enabled.
                         */
                        enabled?: boolean;
                        /**
                         * Check result family used for acceptance reporting.
                         */
                        family?: "build" | "test" | "lint" | "verify_cmd";
                        /**
                         * Human-readable check label.
                         */
                        label?: string;
                    };
                };
                playwright?: {
                    browser?: "chrome" | "edge" | "chromium";
                    executable_path?: string;
                    full_page?: boolean;
                    mode?: "soft" | "strict";
                    require_text?: Array<string>;
                    require_title?: string;
                    target: "web";
                    timeout_ms?: number;
                    url: string;
                    viewport?: {
                        height?: number;
                        width?: number;
                    };
                    wait_for_selector?: string;
                    wait_for_text?: string;
                };
                spec_check?: {
                    enabled?: boolean;
                    mode?: "soft" | "strict";
                    prompt?: string;
                };
                startup?: {
                    command: string;
                    mode?: "soft" | "strict";
                    ready_text?: string;
                    ready_url?: string;
                    require_exit_zero?: boolean;
                    timeout_ms?: number;
                    warmup_ms?: number;
                };
                /**
                 * Explicit test commands, or false to disable discovered test commands.
                 */
                test?: Array<string> | false;
                timeout_ms?: number;
                ui_review?: {
                    focus?: Array<"layout" | "hierarchy" | "clarity" | "navigation" | "feedback" | "accessibility">;
                    mode?: "soft" | "strict";
                    prompt?: string;
                    target: "web";
                    timeout_ms?: number;
                    url?: string;
                };
                /**
                 * Explicit end-to-end verification commands, or false to disable them.
                 */
                verify_cmd?: Array<string> | false;
                visual?: {
                    mode?: "soft" | "strict";
                    require_text?: Array<string>;
                    require_title?: string;
                    target: "web";
                    timeout_ms?: number;
                    url: string;
                };
            };
            /**
             * Task ID whose verification checks should change.
             */
            taskID: string;
        } | {
            action: "capture_overlay_screenshot";
            /**
             * Optional window title or process match hint for the screenshot.
             */
            match?: string;
        } | {
            action: "select_workspace";
            target: {
                /**
                 * ID of the Task or Session to focus.
                 */
                id: string;
                kind: "task" | "session";
            };
        } | {
            action: "create_session";
        } | {
            action: "fork_session";
            /**
             * Session ID to fork.
             */
            sessionID: string;
        } | {
            action: "delete_session";
            /**
             * Session ID to delete.
             */
            sessionID: string;
        } | {
            /**
             * Complete replacement acceptance specs for the goal.
             */
            acceptance_specs: Array<{
                /**
                 * Stable spec ID, e.g. 'acc-login-3s'.
                 */
                id: string;
                /**
                 * Gherkin Given/When/Then scenario. Optional — omit for pure code checks.
                 */
                scenario?: {
                    given: Array<string>;
                    then: Array<string>;
                    when: Array<string>;
                };
                /**
                 * At least one scorer — a spec without a scorer is untestable.
                 */
                scorers: Array<{
                    expect?: {
                        exit_code?: number;
                    };
                    name: string;
                    spec: {
                        /**
                         * Shell command. Exit 0 = pass unless expect.exit_code set.
                         */
                        cmd: string;
                        cwd?: string;
                        /**
                         * shell — run an inline command. Requires: cmd; optional cwd.
                         */
                        kind: "shell";
                    } | {
                        args?: Array<string>;
                        /**
                         * script_ref — run an existing repo script. Requires: path; optional args. Not for contract_audit; contract_audit is its own scorer type.
                         */
                        kind: "script_ref";
                        /**
                         * Repo-relative script path that already exists at registration time.
                         */
                        path: string;
                    };
                    /**
                     * heuristic — deterministic shell/script check, pass/fail by exit code. Requires: name, spec{kind}.
                     */
                    type: "heuristic";
                } | {
                    /**
                     * Single-criterion evaluation question in natural language.
                     */
                    criteria: string;
                    /**
                     * Which parts of the acceptance to feed the judge. Default: acceptance_summary. LLM judges cannot consume visual feedback; final rendered reference parity uses prebuilt visual-feedback-verification.
                     */
                    inputs?: Array<"acceptance_summary" | "changed_files" | "requirement_text">;
                    name: string;
                    /**
                     * Ordinal anchors, 2-5 levels. Omit for binary MET/UNMET.
                     */
                    rubric?: Array<{
                        /**
                         * Behavioral description: what earns this score.
                         */
                        anchor: string;
                        /**
                         * Short level label, e.g. 'fully met'.
                         */
                        label: string;
                        /**
                         * Does this level count as pass for binary verdict?
                         */
                        passes: boolean;
                        /**
                         * Integer score for this level.
                         */
                        score: number;
                    }>;
                    /**
                     * llm_judge — natural-language rubric evaluation. Requires: name, criteria; optional rubric, inputs.
                     */
                    type: "llm_judge";
                } | {
                    /**
                     * Exact executable prebuilt scorer identity for rendered visual feedback verification.
                     */
                    name: "visual-feedback-verification";
                    /**
                     * prebuilt — the platform-owned rendered visual feedback verification scorer.
                     */
                    type: "prebuilt";
                } | {
                    expect: {
                        status: "passed";
                    };
                    name: string;
                    spec: {
                        contract_ids: Array<string>;
                        kind: "contract_graph";
                    };
                    /**
                     * contract_audit — static audit of typed-contract field literals and graph artifact path materialization against registered graph contract_ids. This is a scorer type, not a script_ref path. Requires: name, spec.contract_ids, expect.status='passed'.
                     */
                    type: "contract_audit";
                }>;
                severity: "essential" | "important" | "optional" | "pitfall";
                /**
                 * Optional origin of this atomic acceptance contract. This is not a runtime evidence reference.
                 */
                source?: {
                    /**
                     * Source-local contract identity.
                     */
                    id: string;
                    /**
                     * Source contract kind. Core preserves this value without interpreting it.
                     */
                    kind: string;
                };
                title: string;
            }>;
            action: "update_goal";
            /**
             * Goal ID to update.
             */
            goalID: string;
            /**
             * Replacement goal title.
             */
            title: string;
        } | {
            action: "delete_goal";
            /**
             * Goal ID to delete.
             */
            goalID: string;
        };
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<GatewayControlActionResponses, GatewayControlActionErrors, ThrowOnError, "fields">;
    /**
     * Handle gateway control message
     *
     * Route a remote/mobile natural-language control message through the shared control plane.
     */
    message<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        allow_create?: boolean;
        attachments?: Array<{
            filename?: string;
            mime: string;
            url: string;
        }>;
        channel?: string;
        model?: string;
        request_id?: string;
        sessionID?: string;
        source?: string;
        surface?: "gateway";
        taskID?: string;
        text: string;
        thread?: string;
        user_id?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<GatewayControlMessageResponses, unknown, ThrowOnError, "fields">;
}
export declare class Gateway extends HeyApiClient {
    /**
     * List gateway capabilities
     *
     * Return control-plane actions available to remote/mobile gateway clients.
     */
    capabilities<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<GatewayCapabilitiesResponses, unknown, ThrowOnError, "fields">;
    /**
     * Get gateway stats
     *
     * Read-only project/task/channel summary for gateway panels.
     */
    stats<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
        limit?: number;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<GatewayStatsResponses, unknown, ThrowOnError, "fields">;
    private _channel?;
    get channel(): Channel2;
    private _control?;
    get control(): Control;
}
export declare class Agents extends HeyApiClient {
    /**
     * List primary assistants for global configuration
     *
     * Resolve primary assistants from global configuration without requiring an active project.
     */
    list<ThrowOnError extends boolean = false>(options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<GlobalAgentsListResponses, unknown, ThrowOnError, "fields">;
}
export declare class Automations extends HeyApiClient {
    /**
     * List scheduled automations
     */
    list<ThrowOnError extends boolean = false>(options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<GlobalAutomationsListResponses, GlobalAutomationsListErrors, ThrowOnError, "fields">;
    /**
     * Create a scheduled automation
     */
    create<ThrowOnError extends boolean = false>(parameters: {
        executionMode?: "local" | "worktree";
        model?: {
            modelID: string;
            providerID: string;
        };
        name: string;
        prompt: string;
        reasoningEffort?: string;
        recurrence: string;
        target: {
            scope: "session";
            sessionId: string;
        } | {
            projectIds: Array<string>;
            scope: "project";
        } | {
            scope: "global";
        };
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<GlobalAutomationsCreateResponses, GlobalAutomationsCreateErrors, ThrowOnError, "fields">;
    /**
     * Delete a scheduled automation
     */
    delete<ThrowOnError extends boolean = false>(parameters: {
        id: string;
        expectedRevisionId: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<GlobalAutomationsDeleteResponses, GlobalAutomationsDeleteErrors, ThrowOnError, "fields">;
    /**
     * Update a scheduled automation
     */
    update<ThrowOnError extends boolean = false>(parameters: {
        id: string;
        executionMode?: "local" | "worktree";
        expectedRevisionId: string;
        model?: {
            modelID: string;
            providerID: string;
        } | null;
        name?: string;
        prompt?: string;
        reasoningEffort?: string | null;
        recurrence?: string;
        status?: "active" | "paused";
        target?: {
            scope: "session";
            sessionId: string;
        } | {
            projectIds: Array<string>;
            scope: "project";
        } | {
            scope: "global";
        };
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<GlobalAutomationsUpdateResponses, GlobalAutomationsUpdateErrors, ThrowOnError, "fields">;
    /**
     * List scheduled automation Fire history
     *
     * Lists logical Fire occurrences with immutable target-run receipts, including terminal Fires that reserved no target runs.
     */
    fires<ThrowOnError extends boolean = false>(parameters: {
        id: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<GlobalAutomationsFiresResponses, GlobalAutomationsFiresErrors, ThrowOnError, "fields">;
    /**
     * Run a scheduled automation now
     */
    run<ThrowOnError extends boolean = false>(parameters: {
        id: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<GlobalAutomationsRunResponses, GlobalAutomationsRunErrors, ThrowOnError, "fields">;
    /**
     * List scheduled automation target executions
     */
    runs<ThrowOnError extends boolean = false>(parameters: {
        id: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<GlobalAutomationsRunsResponses, GlobalAutomationsRunsErrors, ThrowOnError, "fields">;
}
export declare class Chat3 extends HeyApiClient {
    /**
     * Create Chat in a temporary project
     *
     * Create one dated UUID project under the OpenCorvus data directory and one right-sidebar Chat session owned by it.
     */
    create<ThrowOnError extends boolean = false>(parameters?: {
        model?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<GlobalChatCreateResponses, GlobalChatCreateErrors, ThrowOnError, "fields">;
    /**
     * Start a global Chat
     *
     * Create one visible global Chat, durably accept and schedule its first user message, and return canonical Session streaming coordinates. Retry the same requestID to converge on the same Chat turn.
     */
    start<ThrowOnError extends boolean = false>(parameters: {
        attachments?: Array<{
            data: string;
            filename?: string;
            mime: string;
        }>;
        model?: string;
        requestID: string;
        text: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<GlobalChatStartResponses, GlobalChatStartErrors, ThrowOnError, "fields">;
}
export declare class Config2 extends HeyApiClient {
    /**
     * Get global configuration
     *
     * Retrieve the current global OpenCorvus configuration settings and preferences.
     */
    get<ThrowOnError extends boolean = false>(options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<GlobalConfigGetResponses, GlobalConfigGetErrors, ThrowOnError, "fields">;
    /**
     * Update global configuration
     *
     * Update global OpenCorvus configuration settings and preferences.
     */
    update<ThrowOnError extends boolean = false>(parameters?: {
        body?: {
            [key: string]: unknown;
        };
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<GlobalConfigUpdateResponses, GlobalConfigUpdateErrors, ThrowOnError, "fields">;
}
export declare class Projects extends HeyApiClient {
    /**
     * Create an anonymous project
     *
     * Create a dated anonymous Git project under the server-owned OpenCorvus application-data directory for a connected UI without an explicit project.
     */
    anonymous<ThrowOnError extends boolean = false>(options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<GlobalProjectsAnonymousResponses, unknown, ThrowOnError, "fields">;
    /**
     * Discover local OpenCorvus projects
     *
     * List registered OpenCorvus project directories together with projects discovered in the server launch directory and its direct children. This is a control-plane discovery route and does not require an active project directory.
     */
    discover<ThrowOnError extends boolean = false>(options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<GlobalProjectsDiscoverResponses, GlobalProjectsDiscoverErrors, ThrowOnError, "fields">;
}
export declare class Discover extends HeyApiClient {
    /**
     * Discover global Provider models
     *
     * Fetch an explicit OpenAI-compatible model endpoint using global Provider configuration.
     */
    models<ThrowOnError extends boolean = false>(parameters: {
        api: string;
        apiKey?: string;
        providerID?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<GlobalProvidersDiscoverModelsResponses, GlobalProvidersDiscoverModelsErrors, ThrowOnError, "fields">;
}
export declare class Models extends HeyApiClient {
    /**
     * Refresh global configured provider model lists
     *
     * Refresh live model identities from saved global provider credentials without requiring an active project or refreshing the provider registry declaration.
     */
    refresh<ThrowOnError extends boolean = false>(options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<GlobalProvidersModelsRefreshResponses, GlobalProvidersModelsRefreshErrors, ThrowOnError, "fields">;
}
export declare class Account extends HeyApiClient {
    /**
     * Get global Provider account usage
     *
     * Fetch normalized account usage with global Provider configuration without requiring an active project.
     */
    usage<ThrowOnError extends boolean = false>(parameters: {
        providerID: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<GlobalProvidersAccountUsageResponses, GlobalProvidersAccountUsageErrors, ThrowOnError, "fields">;
}
export declare class Auth2 extends HeyApiClient {
    /**
     * Execute global Provider API auth
     *
     * Execute a built-in Provider API credential method without a project.
     */
    execute<ThrowOnError extends boolean = false>(parameters: {
        providerID: string;
        inputs?: {
            [key: string]: string;
        };
        method: number;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<GlobalProvidersAuthExecuteResponses, GlobalProvidersAuthExecuteErrors, ThrowOnError, "fields">;
    /**
     * Get global Provider auth prompts
     *
     * Return prompts for a built-in Provider authentication method without a project.
     */
    prompts<ThrowOnError extends boolean = false>(parameters: {
        providerID: string;
        inputs?: {
            [key: string]: string;
        };
        method: number;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<GlobalProvidersAuthPromptsResponses, GlobalProvidersAuthPromptsErrors, ThrowOnError, "fields">;
}
export declare class Oauth extends HeyApiClient {
    /**
     * Authorize a global Provider subscription
     *
     * Start built-in Provider OAuth without requiring an active project.
     */
    authorize<ThrowOnError extends boolean = false>(parameters: {
        providerID: string;
        inputs?: {
            [key: string]: string;
        };
        method: number;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<GlobalProvidersOauthAuthorizeResponses, GlobalProvidersOauthAuthorizeErrors, ThrowOnError, "fields">;
    /**
     * Complete global Provider subscription authorization
     *
     * Complete built-in Provider OAuth without requiring an active project.
     */
    callback<ThrowOnError extends boolean = false>(parameters: {
        providerID: string;
        code?: string;
        flowID: string;
        method: number;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<GlobalProvidersOauthCallbackResponses, GlobalProvidersOauthCallbackErrors, ThrowOnError, "fields">;
    /**
     * Cancel pending Provider authorization
     *
     * Release the exact pending OAuth occurrence before credential exchange starts.
     */
    cancel<ThrowOnError extends boolean = false>(parameters: {
        providerID: string;
        flowID: string;
        method: number;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<GlobalProvidersOauthCancelResponses, GlobalProvidersOauthCancelErrors, ThrowOnError, "fields">;
}
export declare class Providers extends HeyApiClient {
    /**
     * List providers for a new global task
     *
     * Resolve the provider/model catalog from global configuration without requiring an active project.
     */
    list<ThrowOnError extends boolean = false>(options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<GlobalProvidersListResponses, unknown, ThrowOnError, "fields">;
    /**
     * Get global Provider auth methods
     *
     * Retrieve built-in Provider authentication methods without requiring an active project.
     */
    auth<ThrowOnError extends boolean = false>(options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<GlobalProvidersAuthResponses, unknown, ThrowOnError, "fields">;
    /**
     * Refresh the global provider registry
     *
     * Refresh the canonical provider catalog declaration without requiring an active project. Configured live model identities use the separate models refresh route.
     */
    refresh<ThrowOnError extends boolean = false>(options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<GlobalProvidersRefreshResponses, unknown, ThrowOnError, "fields">;
    /**
     * Delete a global provider
     *
     * Commit removal of the global provider declaration, provider model references, enabled or disabled references, and its saved credential under one durable mutation owner.
     */
    remove<ThrowOnError extends boolean = false>(parameters: {
        providerID: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<GlobalProvidersRemoveResponses, GlobalProvidersRemoveErrors, ThrowOnError, "fields">;
    /**
     * Test a global Provider connection
     *
     * Run a minimal live Provider request using global configuration without an active project.
     */
    test<ThrowOnError extends boolean = false>(parameters: {
        providerID: string;
        modelID?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<GlobalProvidersTestResponses, GlobalProvidersTestErrors, ThrowOnError, "fields">;
    private _discover?;
    get discover(): Discover;
    private _models?;
    get models(): Models;
    private _account?;
    get account(): Account;
    private _auth?;
    get auth2(): Auth2;
    private _oauth?;
    get oauth(): Oauth;
}
export declare class Market extends HeyApiClient {
    /**
     * Inspect a global Skill Market candidate
     *
     * Download and validate one exact candidate bundle without installing it.
     */
    detail<ThrowOnError extends boolean = false>(parameters: {
        id: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<GlobalSkillMarketDetailResponses, GlobalSkillMarketDetailErrors, ThrowOnError, "fields">;
    /**
     * Install an inspected global Skill Market candidate
     *
     * Install exactly one candidate only when its current content matches the inspected digest.
     */
    install<ThrowOnError extends boolean = false>(parameters: {
        expected_hash: string;
        id: string;
        policy?: "allow" | "deny";
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<GlobalSkillMarketInstallResponses, GlobalSkillMarketInstallErrors, ThrowOnError, "fields">;
    /**
     * Search the global Skill Market
     *
     * Search exact Skill candidates and project live global installation status.
     */
    search<ThrowOnError extends boolean = false>(parameters: {
        query: string;
        limit?: number;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<GlobalSkillMarketSearchResponses, GlobalSkillMarketSearchErrors, ThrowOnError, "fields">;
}
export declare class Skill extends HeyApiClient {
    /**
     * Install a global Skill market source
     *
     * Install a git or URL Skill source into global configuration without an active project.
     */
    install<ThrowOnError extends boolean = false>(parameters: {
        kind: "url" | "git";
        policy?: "allow" | "deny";
        value: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<GlobalSkillInstallResponses, GlobalSkillInstallErrors, ThrowOnError, "fields">;
    /**
     * List the global Skill market
     *
     * List the single current Skill Market provider without requiring an active project.
     */
    market<ThrowOnError extends boolean = false>(options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<GlobalSkillMarketResponses, unknown, ThrowOnError, "fields">;
    private _market?;
    get market2(): Market;
}
export declare class Work2 extends HeyApiClient {
    /**
     * Create Work in a temporary project
     *
     * Create one dated UUID project under the OpenCorvus data directory and one right-sidebar Work session owned by it.
     */
    create<ThrowOnError extends boolean = false>(parameters?: {
        model?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<GlobalWorkCreateResponses, GlobalWorkCreateErrors, ThrowOnError, "fields">;
}
export declare class Global extends HeyApiClient {
    /**
     * Search global Composer expert squads
     *
     * Returns a bounded page of built-in and user-global Expert Squads without creating a Project or Session.
     */
    composerExpertSquads<ThrowOnError extends boolean = false>(parameters?: {
        view?: "effective" | "installations";
        query?: string;
        productPillar?: "code" | "work";
        cursor?: string;
        limit?: number;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<GlobalComposerExpertSquadsResponses, GlobalComposerExpertSquadsErrors, ThrowOnError, "fields">;
    /**
     * List global Composer references
     *
     * Return the built-in and user-global Skills, Expert Squads, and Mission Skills available before a project-backed Code or Work conversation exists. This read-only route does not create a Project or Session.
     */
    composerReferences<ThrowOnError extends boolean = false>(options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<GlobalComposerReferencesResponses, GlobalComposerReferencesErrors, ThrowOnError, "fields">;
    /**
     * Dispose instance
     *
     * Clean up and dispose all OpenCorvus instances, releasing all resources.
     */
    dispose<ThrowOnError extends boolean = false>(options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<GlobalDisposeResponses, GlobalDisposeErrors, ThrowOnError, "fields">;
    /**
     * Get global events
     *
     * Subscribe to global events from the OpenCorvus system using server-sent events.
     */
    event<ThrowOnError extends boolean = false>(options?: Options<never, ThrowOnError, GlobalEventResponse>): Promise<import("./core/serverSentEvents.gen.js").ServerSentEventsResult<GlobalEventResponses>>;
    /**
     * Get health
     *
     * Get health information about the OpenCorvus server, including its durable database availability, runtime-resolved on-disk paths, and optional evidence that this process backed up a stale database before creating a fresh database. This control-plane route does not open SQLite. The DB path is resolved by `Database.Path()` and is the current SQLite location for this server process — UIs should read this rather than rebuilding the path from a template.
     */
    health<ThrowOnError extends boolean = false>(options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<GlobalHealthResponses, unknown, ThrowOnError, "fields">;
    /**
     * Get natural-period Provider usage
     *
     * Aggregate persisted streamed Provider calls across all projects by their event time for one IANA calendar period.
     */
    usage<ThrowOnError extends boolean = false>(parameters?: {
        period?: UsagePeriod;
        timeZone?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<GlobalUsageResponses, GlobalUsageErrors, ThrowOnError, "fields">;
    private _agents?;
    get agents(): Agents;
    private _automations?;
    get automations(): Automations;
    private _chat?;
    get chat(): Chat3;
    private _config?;
    get config(): Config2;
    private _projects?;
    get projects(): Projects;
    private _providers?;
    get providers(): Providers;
    private _skill?;
    get skill(): Skill;
    private _work?;
    get work(): Work2;
}
export declare class Global2 extends HeyApiClient {
    /**
     * List tasks across projects
     */
    list<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
        q?: string;
        status?: string;
        limit?: number;
        cursor?: number;
        cursorTaskID?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<TaskGlobalListResponses, unknown, ThrowOnError, "fields">;
    /**
     * Create a task in an implicit project
     *
     * Create a concrete Git project under the user-scoped OpenCorvus data directory, then create the task in that project.
     */
    create<ThrowOnError extends boolean = false>(parameters: {
        attachments?: Array<{
            data: string;
            filename?: string;
            mime: string;
        }>;
        budget?: {
            maxExecutorGroups?: number;
        };
        channelBinding?: {
            channel: string;
            payload?: {
                [key: string]: unknown;
            };
            platform: string;
            thread: string;
        };
        checks?: {
            artifact?: {
                min_changed_files?: number;
                mode?: "soft" | "strict";
                require_changed_files?: boolean;
                require_diff?: boolean;
                require_summary?: boolean;
            };
            /**
             * Explicit build commands, or false to disable discovered build commands.
             */
            build?: Array<string> | false;
            code_quality?: {
                enabled?: boolean;
                max_diffs?: number;
                mode?: "soft" | "strict";
                prompt?: string;
            };
            code_review?: {
                enabled?: boolean;
                max_diffs?: number;
                mode?: "soft" | "strict";
                prompt?: string;
            };
            dead_code_review?: {
                enabled?: boolean;
                max_diffs?: number;
                mode?: "soft" | "strict";
                prompt?: string;
            };
            judge?: {
                enabled?: boolean;
                mode?: "soft" | "strict";
                prompt?: string;
            };
            /**
             * Explicit lint commands, or false to disable discovered lint commands.
             */
            lint?: Array<string> | false;
            /**
             * Host-authored named check definitions keyed by stable check name.
             */
            named?: {
                [key: string]: {
                    /**
                     * Executable shell commands for this named check.
                     */
                    commands: Array<string>;
                    /**
                     * Optional project-relative working directory for the commands.
                     */
                    cwd?: string;
                    /**
                     * Whether this named check is enabled.
                     */
                    enabled?: boolean;
                    /**
                     * Check result family used for acceptance reporting.
                     */
                    family?: "build" | "test" | "lint" | "verify_cmd";
                    /**
                     * Human-readable check label.
                     */
                    label?: string;
                };
            };
            playwright?: {
                browser?: "chrome" | "edge" | "chromium";
                executable_path?: string;
                full_page?: boolean;
                mode?: "soft" | "strict";
                require_text?: Array<string>;
                require_title?: string;
                target: "web";
                timeout_ms?: number;
                url: string;
                viewport?: {
                    height?: number;
                    width?: number;
                };
                wait_for_selector?: string;
                wait_for_text?: string;
            };
            spec_check?: {
                enabled?: boolean;
                mode?: "soft" | "strict";
                prompt?: string;
            };
            startup?: {
                command: string;
                mode?: "soft" | "strict";
                ready_text?: string;
                ready_url?: string;
                require_exit_zero?: boolean;
                timeout_ms?: number;
                warmup_ms?: number;
            };
            /**
             * Explicit test commands, or false to disable discovered test commands.
             */
            test?: Array<string> | false;
            timeout_ms?: number;
            ui_review?: {
                focus?: Array<"layout" | "hierarchy" | "clarity" | "navigation" | "feedback" | "accessibility">;
                mode?: "soft" | "strict";
                prompt?: string;
                target: "web";
                timeout_ms?: number;
                url?: string;
            };
            /**
             * Explicit end-to-end verification commands, or false to disable them.
             */
            verify_cmd?: Array<string> | false;
            visual?: {
                mode?: "soft" | "strict";
                require_text?: Array<string>;
                require_title?: string;
                target: "web";
                timeout_ms?: number;
                url: string;
            };
        };
        expectedPackageDigest?: string;
        model?: string;
        priority?: "critical" | "high" | "normal" | "low";
        productPillar: "code" | "work";
        promptProfile: string;
        request: string;
        requestID?: string;
        source?: string;
        title?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<TaskGlobalCreateResponses, TaskGlobalCreateErrors, ThrowOnError, "fields">;
}
export declare class Conversation extends HeyApiClient {
    /**
     * Page task conversation replay events
     *
     * Return a bounded protocol_event slice for rebuilding task conversation history after the initial hydrate.
     */
    events<ThrowOnError extends boolean = false>(parameters: {
        taskID: string;
        after?: number;
        until?: number;
        limit?: number;
        since?: number;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<TaskConversationEventsResponses, TaskConversationEventsErrors, ThrowOnError, "fields">;
    /**
     * Page older task conversation transcript
     *
     * Return a bounded transcript/timeline slice older than a timestamp so the overlay can prepend history without blocking the live tail.
     */
    history<ThrowOnError extends boolean = false>(parameters: {
        taskID: string;
        before: number;
        before_order_key: string;
        before_id?: string;
        limit?: number;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<TaskConversationHistoryResponses, TaskConversationHistoryErrors, ThrowOnError, "fields">;
    /**
     * Get one task conversation session transcript
     *
     * Return the persisted transcript for one task child session so the overlay can hydrate old build-agent output directly instead of paging through the whole task history.
     */
    session<ThrowOnError extends boolean = false>(parameters: {
        taskID: string;
        sessionID: string;
        after_live_sequence?: string;
        after_live_epoch?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<TaskConversationSessionResponses, TaskConversationSessionErrors, ThrowOnError, "fields">;
}
export declare class Debug extends HeyApiClient {
    /**
     * Get Task-root ingress debug projection
     */
    taskRootIngresses<ThrowOnError extends boolean = false>(parameters: {
        taskID: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<TaskDebugTaskRootIngressesResponses, TaskDebugTaskRootIngressesErrors, ThrowOnError, "fields">;
}
export declare class Session3 extends HeyApiClient {
    /**
     * Cancel a task agent session
     *
     * Abort the active SessionLoop for a non-orchestrator task agent session. For projected child sessions, also cancel their owned SessionPrompt and durable Task ingress delivery.
     */
    cancel<ThrowOnError extends boolean = false>(parameters: {
        taskID: string;
        sessionID: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<TaskSessionCancelResponses, TaskSessionCancelErrors, ThrowOnError, "fields">;
    /**
     * Steer a task agent session through operator coordination
     *
     * Accept a human-authored steer message for one target sub-agent session. The route records a durable operator-originated agent_coordination_request and wakes the orchestrator. The caller must generate request_id before the first attempt and reuse it only with the identical task, target session, and canonical message after a lost response; that replay returns the original accepted occurrence, while changed semantics return HTTP 409. The server never generates a replacement ID. It never appends a task-root operator message and never writes a direct child-session reply.
     */
    operatorSteer<ThrowOnError extends boolean = false>(parameters: {
        taskID: string;
        sessionID: string;
        directory?: string;
        message: string;
        request_id: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<TaskSessionOperatorSteerResponses, TaskSessionOperatorSteerErrors, ThrowOnError, "fields">;
}
export declare class Task extends HeyApiClient {
    /**
     * Create task
     */
    create<ThrowOnError extends boolean = false>(parameters: {
        query_directory?: string;
        "init-git"?: boolean;
        artifactSources?: Array<{
            authority: "completion_decision";
            source_task_id: string;
        } | {
            authority: "terminal_lifecycle";
            locator: {
                artifact_id: string;
                catalog_revision: number;
                expected_sha256: string;
                source: "engine_artifact";
            } | {
                snapshot: {
                    manifest_sha256: string;
                    project_id: string;
                    schema_version: 2;
                    snapshot_id: string;
                    task_id: string;
                };
                source: "task_artifact_snapshot";
            } | {
                ref: {
                    bytes: number;
                    media_type: string;
                    path: string;
                    sha256: string;
                    snapshot: {
                        manifest_sha256: string;
                        project_id: string;
                        schema_version: 2;
                        snapshot_id: string;
                        task_id: string;
                    };
                    tree: string;
                };
                source: "task_artifact_resource";
            };
            source_task_id: string;
        }>;
        attachments?: Array<{
            filename?: string;
            mime: string;
            url: string;
        } | {
            data: string;
            filename?: string;
            mime: string;
        }>;
        budget?: {
            maxExecutorGroups?: number;
        };
        channelBinding?: {
            channel: string;
            payload?: {
                [key: string]: unknown;
            };
            platform: string;
            thread: string;
        };
        checks?: {
            artifact?: {
                min_changed_files?: number;
                mode?: "soft" | "strict";
                require_changed_files?: boolean;
                require_diff?: boolean;
                require_summary?: boolean;
            };
            /**
             * Explicit build commands, or false to disable discovered build commands.
             */
            build?: Array<string> | false;
            code_quality?: {
                enabled?: boolean;
                max_diffs?: number;
                mode?: "soft" | "strict";
                prompt?: string;
            };
            code_review?: {
                enabled?: boolean;
                max_diffs?: number;
                mode?: "soft" | "strict";
                prompt?: string;
            };
            dead_code_review?: {
                enabled?: boolean;
                max_diffs?: number;
                mode?: "soft" | "strict";
                prompt?: string;
            };
            judge?: {
                enabled?: boolean;
                mode?: "soft" | "strict";
                prompt?: string;
            };
            /**
             * Explicit lint commands, or false to disable discovered lint commands.
             */
            lint?: Array<string> | false;
            /**
             * Host-authored named check definitions keyed by stable check name.
             */
            named?: {
                [key: string]: {
                    /**
                     * Executable shell commands for this named check.
                     */
                    commands: Array<string>;
                    /**
                     * Optional project-relative working directory for the commands.
                     */
                    cwd?: string;
                    /**
                     * Whether this named check is enabled.
                     */
                    enabled?: boolean;
                    /**
                     * Check result family used for acceptance reporting.
                     */
                    family?: "build" | "test" | "lint" | "verify_cmd";
                    /**
                     * Human-readable check label.
                     */
                    label?: string;
                };
            };
            playwright?: {
                browser?: "chrome" | "edge" | "chromium";
                executable_path?: string;
                full_page?: boolean;
                mode?: "soft" | "strict";
                require_text?: Array<string>;
                require_title?: string;
                target: "web";
                timeout_ms?: number;
                url: string;
                viewport?: {
                    height?: number;
                    width?: number;
                };
                wait_for_selector?: string;
                wait_for_text?: string;
            };
            spec_check?: {
                enabled?: boolean;
                mode?: "soft" | "strict";
                prompt?: string;
            };
            startup?: {
                command: string;
                mode?: "soft" | "strict";
                ready_text?: string;
                ready_url?: string;
                require_exit_zero?: boolean;
                timeout_ms?: number;
                warmup_ms?: number;
            };
            /**
             * Explicit test commands, or false to disable discovered test commands.
             */
            test?: Array<string> | false;
            timeout_ms?: number;
            ui_review?: {
                focus?: Array<"layout" | "hierarchy" | "clarity" | "navigation" | "feedback" | "accessibility">;
                mode?: "soft" | "strict";
                prompt?: string;
                target: "web";
                timeout_ms?: number;
                url?: string;
            };
            /**
             * Explicit end-to-end verification commands, or false to disable them.
             */
            verify_cmd?: Array<string> | false;
            visual?: {
                mode?: "soft" | "strict";
                require_text?: Array<string>;
                require_title?: string;
                target: "web";
                timeout_ms?: number;
                url: string;
            };
        };
        body_directory?: string;
        expectedPackageDigest?: string;
        metadata?: {
            [key: string]: unknown;
        };
        model?: string;
        priority?: "critical" | "high" | "normal" | "low";
        productPillar: "code" | "work";
        project?: string;
        promptProfile: string;
        request: string;
        requestID?: string;
        source?: string;
        title?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<TaskCreateResponses, TaskCreateErrors, ThrowOnError, "fields">;
    /**
     * Delete task
     */
    delete<ThrowOnError extends boolean = false>(parameters: {
        taskID: string;
        directory?: string;
        reason: string;
        surface: "api" | "overlay.work_ledger" | "overlay.selected_task" | "overlay.composer_stop" | "overlay.chat_request_stop" | "overlay.interrupt_task" | "overlay.archive_panel";
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<TaskDeleteResponses, TaskDeleteErrors, ThrowOnError, "fields">;
    /**
     * Get task
     */
    get<ThrowOnError extends boolean = false>(parameters: {
        taskID: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<TaskGetResponses, TaskGetErrors, ThrowOnError, "fields">;
    /**
     * Archive or restore task
     *
     * Stop and archive a task, or restore an archived task without restarting it.
     */
    setArchived<ThrowOnError extends boolean = false>(parameters: {
        taskID: string;
        directory?: string;
        body: {
            archived: true;
            reason: string;
            surface: "api" | "overlay.work_ledger" | "overlay.selected_task" | "overlay.composer_stop" | "overlay.chat_request_stop" | "overlay.interrupt_task" | "overlay.archive_panel";
        } | {
            archived: false;
        };
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<TaskSetArchivedResponses, TaskSetArchivedErrors, ThrowOnError, "fields">;
    /**
     * Read one exact Task deliverable Artifact chunk
     */
    readConversationArtifact<ThrowOnError extends boolean = false>(parameters: {
        taskID: string;
        directory?: string;
        byte_offset?: number;
        locator: {
            artifact_id: string;
            catalog_revision: number;
            expected_sha256: string;
            source: "engine_artifact";
        } | {
            snapshot: {
                manifest_sha256: string;
                project_id: string;
                schema_version: 2;
                snapshot_id: string;
                task_id: string;
            };
            source: "task_artifact_snapshot";
        } | {
            ref: {
                bytes: number;
                media_type: string;
                path: string;
                sha256: string;
                snapshot: {
                    manifest_sha256: string;
                    project_id: string;
                    schema_version: 2;
                    snapshot_id: string;
                    task_id: string;
                };
                tree: string;
            };
            source: "task_artifact_resource";
        };
        max_bytes?: number;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<TaskReadConversationArtifactResponses, TaskReadConversationArtifactErrors, ThrowOnError, "fields">;
    /**
     * List channel bindings for a task
     *
     * Return every (platform, channel, thread) binding that points at this task. Used by the Mission page to surface inbound channel provenance for a selected task.
     */
    bindings<ThrowOnError extends boolean = false>(parameters: {
        taskID: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<TaskBindingsResponses, unknown, ThrowOnError, "fields">;
    /**
     * Get task board
     */
    board<ThrowOnError extends boolean = false>(parameters: {
        taskID: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<TaskBoardResponses, TaskBoardErrors, ThrowOnError, "fields">;
    /**
     * Get task brief
     */
    brief<ThrowOnError extends boolean = false>(parameters: {
        taskID: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<TaskBriefResponses, TaskBriefErrors, ThrowOnError, "fields">;
    /**
     * Update task budget
     */
    updateBudget<ThrowOnError extends boolean = false>(parameters: {
        taskID: string;
        directory?: string;
        budget: {
            maxExecutorGroups?: number;
        } | null;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<TaskUpdateBudgetResponses, TaskUpdateBudgetErrors, ThrowOnError, "fields">;
    /**
     * Read an exact Build observation content range
     *
     * Read one bounded byte range from the before or after Git blob selected by a Task-owned Build Host observation.
     */
    buildObservationContent<ThrowOnError extends boolean = false>(parameters: {
        taskID: string;
        artifactID: string;
        directory?: string;
        file: string;
        side: "before" | "after";
        offset?: number;
        length: number;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<TaskBuildObservationContentResponses, TaskBuildObservationContentErrors, ThrowOnError, "fields">;
    /**
     * Cancel task
     */
    cancel<ThrowOnError extends boolean = false>(parameters: {
        taskID: string;
        directory?: string;
        reason: string;
        surface: "api" | "overlay.work_ledger" | "overlay.selected_task" | "overlay.composer_stop" | "overlay.chat_request_stop" | "overlay.interrupt_task" | "overlay.archive_panel";
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<TaskCancelResponses, TaskCancelErrors, ThrowOnError, "fields">;
    /**
     * Hydrate task conversation state
     *
     * Load the current task board plus the persisted conversation inputs needed to rebuild the overlay conversation tree before SSE resumes.
     */
    conversation<ThrowOnError extends boolean = false>(parameters: {
        taskID: string;
        tail_limit?: number;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<TaskConversationResponses, TaskConversationErrors, ThrowOnError, "fields">;
    /**
     * Subscribe to task events
     */
    events<ThrowOnError extends boolean = false>(parameters: {
        taskID: string;
        after?: string;
        after_live?: string;
        after_live_epoch?: string;
    }, options?: Options<never, ThrowOnError, TaskEventsResponse>): Promise<import("./core/serverSentEvents.gen.js").ServerSentEventsResult<TaskEventsResponses>>;
    /**
     * Inject message into running task
     */
    inject<ThrowOnError extends boolean = false>(parameters: {
        taskID: string;
        directory?: string;
        message: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<TaskInjectResponses, TaskInjectErrors, ThrowOnError, "fields">;
    /**
     * List task interactions
     */
    interactions<ThrowOnError extends boolean = false>(parameters: {
        taskID: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<TaskInteractionsResponses, TaskInteractionsErrors, ThrowOnError, "fields">;
    /**
     * Handle task message
     */
    message<ThrowOnError extends boolean = false>(parameters: {
        taskID: string;
        directory?: string;
        attachments?: Array<{
            filename?: string;
            mime: string;
            url: string;
        } | {
            data: string;
            filename?: string;
            mime: string;
        }>;
        channel?: string;
        metadata?: {
            [key: string]: unknown;
        };
        model?: string;
        resolvedRole?: string;
        source: string;
        text: string;
        user_id?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<TaskMessageResponses, TaskMessageErrors, ThrowOnError, "fields">;
    /**
     * Get task operator model context
     *
     * Return the agent and effective model that a task-level operator message will use. This mirrors the task message append path so overlay model controls do not guess from raw config.
     */
    operatorModelContext<ThrowOnError extends boolean = false>(parameters: {
        taskID: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<TaskOperatorModelContextResponses, TaskOperatorModelContextErrors, ThrowOnError, "fields">;
    /**
     * Get task progress
     */
    progress<ThrowOnError extends boolean = false>(parameters: {
        taskID: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<TaskProgressResponses, TaskProgressErrors, ThrowOnError, "fields">;
    /**
     * Download task project archive
     *
     * Return a ZIP containing the task project's Git-included files plus the task execution flow exported from OpenCorvus task projections.
     */
    projectArchive<ThrowOnError extends boolean = false>(parameters: {
        taskID: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<TaskProjectArchiveResponses, TaskProjectArchiveErrors, ThrowOnError, "fields">;
    /**
     * Rewind the visible Task conversation timeline
     */
    rewind<ThrowOnError extends boolean = false>(parameters: {
        taskID: string;
        directory?: string;
        anchor: {
            anchorEventID?: string;
            cursorTime: number;
            kind: "cursorTime";
        } | {
            kind: "message";
            messageID: string;
            partID?: string;
            sessionID: string;
        };
        reason?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<TaskRewindResponses, TaskRewindErrors, ThrowOnError, "fields">;
    /**
     * Clear the Task conversation visibility cursor
     */
    clearRewindCursor<ThrowOnError extends boolean = false>(parameters: {
        taskID: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<TaskClearRewindCursorResponses, TaskClearRewindCursorErrors, ThrowOnError, "fields">;
    /**
     * Get task status
     *
     * Collect current Task activity from the Task Board projection, including diagnostic lifecycle, Requirement acceptance, and per-Slice fact facets. The Task `status` field is normalized to "running" or "inactive"; each Goal detail independently exposes exact activity associations, review associations, and Completion Decision acceptance. Raw active, completed, failed, and cancelled lifecycle facts remain available only as lifecycleStatus.
     */
    status<ThrowOnError extends boolean = false>(parameters: {
        taskID: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<TaskStatusResponses, TaskStatusErrors, ThrowOnError, "fields">;
    /**
     * Update task title
     */
    updateTitle<ThrowOnError extends boolean = false>(parameters: {
        taskID: string;
        directory?: string;
        title: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<TaskUpdateTitleResponses, TaskUpdateTitleErrors, ThrowOnError, "fields">;
    /**
     * Get task AgentTrace events (all sessions)
     */
    trace<ThrowOnError extends boolean = false>(parameters: {
        taskID: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<TaskTraceResponses, TaskTraceErrors, ThrowOnError, "fields">;
    /**
     * Get task transcript
     */
    transcript<ThrowOnError extends boolean = false>(parameters: {
        taskID: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<TaskTranscriptResponses, TaskTranscriptErrors, ThrowOnError, "fields">;
    /**
     * Project terminal artifacts onto the owning Task turn
     */
    turnArtifacts<ThrowOnError extends boolean = false>(parameters: {
        taskID: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<TaskTurnArtifactsResponses, TaskTurnArtifactsErrors, ThrowOnError, "fields">;
    /**
     * List project tasks
     */
    list<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
        q?: string;
        status?: string;
        limit?: number;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<TaskListResponses, unknown, ThrowOnError, "fields">;
    private _global?;
    get global(): Global2;
    private _conversation?;
    get conversation2(): Conversation;
    private _debug?;
    get debug(): Debug;
    private _session?;
    get session(): Session3;
}
export declare class Goal extends HeyApiClient {
    /**
     * Delete goal
     */
    delete<ThrowOnError extends boolean = false>(parameters: {
        goalID: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<GoalDeleteResponses, GoalDeleteErrors, ThrowOnError, "fields">;
    /**
     * Update goal title
     */
    updateTitle<ThrowOnError extends boolean = false>(parameters: {
        goalID: string;
        directory?: string;
        title: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<GoalUpdateTitleResponses, GoalUpdateTitleErrors, ThrowOnError, "fields">;
}
export declare class Instance extends HeyApiClient {
    /**
     * Dispose instance
     *
     * Clean up and dispose the current OpenCorvus instance, releasing all resources.
     */
    dispose<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<InstanceDisposeResponses, InstanceDisposeErrors, ThrowOnError, "fields">;
}
export declare class Interaction extends HeyApiClient {
    /**
     * Reject interaction
     */
    reject<ThrowOnError extends boolean = false>(parameters: {
        interactionID: string;
        directory?: string;
        message?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<InteractionRejectResponses, InteractionRejectErrors, ThrowOnError, "fields">;
    /**
     * Reply to interaction
     */
    reply<ThrowOnError extends boolean = false>(parameters: {
        interactionID: string;
        directory?: string;
        answers?: Array<QuestionAnswer>;
        decision?: PermissionDecision;
        message?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<InteractionReplyResponses, InteractionReplyErrors, ThrowOnError, "fields">;
}
export declare class Server extends HeyApiClient {
    /**
     * Get a server lifecycle occurrence
     *
     * Return the state of an admitted shutdown or restart occurrence. A completed shutdown is unobservable from inside the process, so `executing` is the last state a successful one shows.
     */
    lifecycle<ThrowOnError extends boolean = false>(parameters: {
        occurrenceID: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ServerLifecycleResponses, ServerLifecycleErrors, ThrowOnError, "fields">;
    /**
     * Restart the server
     *
     * Admit a standalone server replacement with the same arguments. Managed, contained or init processes must restart through their existing launcher.
     */
    restart<ThrowOnError extends boolean = false>(options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ServerRestartResponses, ServerRestartErrors, ThrowOnError, "fields">;
    /**
     * Shutdown the server
     *
     * Gracefully abort live execution state and stop the current process.
     */
    shutdown<ThrowOnError extends boolean = false>(options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ServerShutdownResponses, ServerShutdownErrors, ThrowOnError, "fields">;
}
export declare class Log extends HeyApiClient {
    /**
     * Read logs
     *
     * Read the last N lines from the current or named server log file in the unified log directory.
     */
    read<ThrowOnError extends boolean = false>(parameters?: {
        file?: string;
        n?: number;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<LogReadResponses, LogReadErrors, ThrowOnError, "fields">;
    /**
     * Export log support bundle
     *
     * Download every retained server log as a ZIP containing byte-exact raw files, formatted human-readable copies, and a structured diagnostic manifest.
     */
    export<ThrowOnError extends boolean = false>(options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<LogExportResponses, unknown, ThrowOnError, "fields">;
    /**
     * List log files
     *
     * List server log files from the unified log directory.
     */
    files<ThrowOnError extends boolean = false>(options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<LogFilesResponses, unknown, ThrowOnError, "fields">;
    /**
     * Read recent logs
     *
     * Read the last N lines from the current server log file.
     */
    tail<ThrowOnError extends boolean = false>(parameters?: {
        n?: number;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<LogTailResponses, LogTailErrors, ThrowOnError, "fields">;
}
export declare class Mailbox extends HeyApiClient {
    /**
     * Delete selected mailbox items
     *
     * Append terminal delete acknowledgements for exact project mailbox item IDs while preserving their source Task and protocol history.
     */
    deleteMany<ThrowOnError extends boolean = false>(parameters: {
        messageIDs: Array<string>;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<MailboxDeleteManyResponses, MailboxDeleteManyErrors, ThrowOnError, "fields">;
    /**
     * List the global mailbox
     *
     * Return the durable Mailbox projection across registered projects, with each item carrying its owning project directory. Active and archived views fold acknowledgement events over protocol history.
     */
    list<ThrowOnError extends boolean = false>(parameters?: {
        view?: "active" | "archived";
        limit?: number;
        cursorCreatedAt?: number;
        cursorID?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<MailboxListResponses, MailboxListErrors, ThrowOnError, "fields">;
    /**
     * Mark all active mailbox items as read
     *
     * Append read acknowledgements for every active unread item across the registered-project Mailbox.
     */
    readAll<ThrowOnError extends boolean = false>(options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<MailboxReadAllResponses, unknown, ThrowOnError, "fields">;
    /**
     * Delete a mailbox item
     *
     * Append a terminal delete acknowledgement for one project mailbox item while preserving its source Task and protocol history.
     */
    delete<ThrowOnError extends boolean = false>(parameters: {
        messageID: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<MailboxDeleteResponses, MailboxDeleteErrors, ThrowOnError, "fields">;
    /**
     * Update a mailbox item
     *
     * Append a read, archive, or restore acknowledgement for one project mailbox item.
     */
    acknowledge<ThrowOnError extends boolean = false>(parameters: {
        messageID: string;
        action: "read" | "archive" | "restore";
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<MailboxAcknowledgeResponses, MailboxAcknowledgeErrors, ThrowOnError, "fields">;
}
export declare class Project extends HeyApiClient {
    /**
     * Get project-owned MCP status
     *
     * Get live status for MCP server definitions owned by the current project.
     */
    status<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<McpProjectStatusResponses, unknown, ThrowOnError, "fields">;
}
export declare class Auth3 extends HeyApiClient {
    /**
     * Remove MCP OAuth
     *
     * Remove OAuth credentials for an MCP server
     */
    remove<ThrowOnError extends boolean = false>(parameters: {
        name: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<McpAuthRemoveResponses, McpAuthRemoveErrors, ThrowOnError, "fields">;
    /**
     * Start MCP OAuth
     *
     * Start OAuth authentication flow for a Model Context Protocol (MCP) server.
     */
    start<ThrowOnError extends boolean = false>(parameters: {
        name: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<McpAuthStartResponses, McpAuthStartErrors, ThrowOnError, "fields">;
    /**
     * Authenticate MCP OAuth
     *
     * Start OAuth flow and wait for callback (opens browser)
     */
    authenticate<ThrowOnError extends boolean = false>(parameters: {
        name: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<McpAuthAuthenticateResponses, McpAuthAuthenticateErrors, ThrowOnError, "fields">;
    /**
     * Complete MCP OAuth
     *
     * Complete OAuth authentication for a Model Context Protocol (MCP) server using the authorization code.
     */
    callback<ThrowOnError extends boolean = false>(parameters: {
        name: string;
        directory?: string;
        code: string;
        state: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<McpAuthCallbackResponses, McpAuthCallbackErrors, ThrowOnError, "fields">;
}
export declare class Mcp extends HeyApiClient {
    /**
     * Remove project MCP servers
     *
     * Atomically validates native Chat and Work references, closes live connections, removes OAuth credentials, and deletes the project-owned definitions.
     */
    remove<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        mcpRemoveConfiguredInput: McpRemoveConfiguredInput;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<McpRemoveResponses, McpRemoveErrors, ThrowOnError, "fields">;
    /**
     * Get MCP status
     *
     * Get the status of all Model Context Protocol (MCP) servers.
     */
    status<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<McpStatusResponses, unknown, ThrowOnError, "fields">;
    /**
     * Add MCP server
     *
     * Dynamically add a new Model Context Protocol (MCP) server to the system.
     */
    add<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        config: McpLocalConfig | McpRemoteConfig;
        credentialSecret?: string;
        name: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<McpAddResponses, McpAddErrors, ThrowOnError, "fields">;
    /**
     * Connect an MCP server
     */
    connect<ThrowOnError extends boolean = false>(parameters: {
        name: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<McpConnectResponses, McpConnectErrors, ThrowOnError, "fields">;
    /**
     * Disconnect an MCP server
     */
    disconnect<ThrowOnError extends boolean = false>(parameters: {
        name: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<McpDisconnectResponses, McpDisconnectErrors, ThrowOnError, "fields">;
    private _project?;
    get project(): Project;
    private _auth?;
    get auth(): Auth3;
}
export declare class Mission extends HeyApiClient {
    /**
     * List Missions
     *
     * List Mission records across project directories. Each record is backed by exactly one kind="mission" session and can be opened through the session conversation/event routes. Board lanes are exclusive read-time projections from Mission completion, pending interaction, Task lifecycle, and Mission execution facts.
     */
    list<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
        search?: string;
        limit?: number;
        cursorUpdated?: number;
        cursorSessionID?: string;
        archived?: "true" | "false";
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<MissionListResponses, unknown, ThrowOnError, "fields">;
    /**
     * Create a Mission draft
     *
     * Create a backlog Mission with an immutable Expert Squad snapshot and one pending operator prompt. No model is invoked until the operator dispatches the Mission.
     */
    createDraft<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        expertSquadIDs?: Array<string>;
        productPillar: "code" | "work";
        request: string;
        title: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<MissionCreateDraftResponses, MissionCreateDraftErrors, ThrowOnError, "fields">;
    /**
     * Wake the Mission agent
     *
     * Start (or resume) a Mission agent session and inject a user prompt. Omit `missionID` to start a new mission; supply it to resume an existing one. The route is idempotent for (project, directory, missionID) — exactly one mission session is keyed per mission. Supply requestID to join one exact accepted prompt, model, attachment and config input; reusing it with drift returns a conflict.
     */
    wake<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        attachments?: Array<{
            filename?: string;
            mime: string;
            url: string;
        } | {
            data: string;
            filename?: string;
            mime: string;
        }>;
        expertSquadIDs?: Array<string>;
        missionID?: string;
        model?: string;
        productPillar: "code" | "work";
        requestID?: string;
        text: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<MissionWakeResponses, MissionWakeErrors, ThrowOnError, "fields">;
    /**
     * Delete a Mission
     *
     * Retire the Mission and hide it from current readers while retaining its immutable Task, Session, Message and lifecycle audit history.
     */
    delete<ThrowOnError extends boolean = false>(parameters: {
        missionID: string;
        directory?: string;
        reason: string;
        surface: "api" | "overlay.work_ledger" | "overlay.selected_task" | "overlay.composer_stop" | "overlay.chat_request_stop" | "overlay.interrupt_task" | "overlay.archive_panel";
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<MissionDeleteResponses, MissionDeleteErrors, ThrowOnError, "fields">;
    /**
     * Abort a Mission
     *
     * Abort the active Mission session loop for this Mission.
     */
    abort<ThrowOnError extends boolean = false>(parameters: {
        missionID: string;
        directory?: string;
        reason: string;
        surface: "api" | "overlay.work_ledger" | "overlay.selected_task" | "overlay.composer_stop" | "overlay.chat_request_stop" | "overlay.interrupt_task" | "overlay.archive_panel";
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<MissionAbortResponses, MissionAbortErrors, ThrowOnError, "fields">;
    /**
     * Get Mission durable activity cursor
     *
     * Return the canonical latest durable activity occurrence across the Mission Session tree and all child Task execution trees.
     */
    activityCursor<ThrowOnError extends boolean = false>(parameters: {
        missionID: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<MissionActivityCursorResponses, MissionActivityCursorErrors, ThrowOnError, "fields">;
    /**
     * Archive or restore a Mission
     *
     * Stop and archive a Mission, or restore it without restarting execution.
     */
    setArchived<ThrowOnError extends boolean = false>(parameters: {
        missionID: string;
        directory?: string;
        body: {
            archived: true;
            reason: string;
            surface: "api" | "overlay.work_ledger" | "overlay.selected_task" | "overlay.composer_stop" | "overlay.chat_request_stop" | "overlay.interrupt_task" | "overlay.archive_panel";
        } | {
            archived: false;
        };
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<MissionSetArchivedResponses, MissionSetArchivedErrors, ThrowOnError, "fields">;
    /**
     * Dispatch a Mission draft
     *
     * Consume the Mission's pending operator prompt through the canonical visible user-message and streaming Mission wake path. Supply requestID to replay one exact accepted input; reusing it with changed model or prompt facts returns a conflict.
     */
    dispatch<ThrowOnError extends boolean = false>(parameters: {
        missionID: string;
        directory?: string;
        model?: string;
        requestID?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<MissionDispatchResponses, MissionDispatchErrors, ThrowOnError, "fields">;
    /**
     * Edit a Mission draft
     *
     * Save an existing unarchived Mission draft using its expected current text. An already-saved target text returns the current record without another write. Saving does not start execution or change accepted Messages.
     */
    editDraft<ThrowOnError extends boolean = false>(parameters: {
        missionID: string;
        directory?: string;
        expectedRequest: string;
        request: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<MissionEditDraftResponses, MissionEditDraftErrors, ThrowOnError, "fields">;
    /**
     * Download Mission project archive
     *
     * Return a ZIP containing the Mission project's Git-included files plus Mission execution evidence exported from Mission projections.
     */
    projectArchive<ThrowOnError extends boolean = false>(parameters: {
        missionID: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<MissionProjectArchiveResponses, MissionProjectArchiveErrors, ThrowOnError, "fields">;
    /**
     * Get Mission status
     *
     * Collect current Mission and Task activity with each Task's diagnostic lifecycle, Requirement acceptance, and per-Slice fact facets. Mission and Task `status` fields are normalized to "running" or "inactive"; each Goal detail independently exposes exact activity associations, review associations, and Completion Decision acceptance. Raw active, completed, failed, and cancelled lifecycle facts remain available only as lifecycleStatus.
     */
    status<ThrowOnError extends boolean = false>(parameters: {
        missionID: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<MissionStatusResponses, MissionStatusErrors, ThrowOnError, "fields">;
    /**
     * Rename a Mission
     *
     * Rename the Mission session title. The Mission record remains backed by the same mission session.
     */
    rename<ThrowOnError extends boolean = false>(parameters: {
        missionID: string;
        directory?: string;
        title: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<MissionRenameResponses, MissionRenameErrors, ThrowOnError, "fields">;
}
export declare class MissionSkill extends HeyApiClient {
    /**
     * List Mission Skills
     *
     * Returns the strict built-in, user-global, and current-project Mission Skill summaries available to the native Mission agent.
     */
    catalog<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
        sessionID?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<MissionSkillCatalogResponses, MissionSkillCatalogErrors, ThrowOnError, "fields">;
    /**
     * Prepare Mission Skill Directory
     *
     * Creates one canonical Mission Skill directory on an explicit Settings action and returns its path.
     */
    directory<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        sessionID?: string;
        source: "global" | "project";
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<MissionSkillDirectoryResponses, MissionSkillDirectoryErrors, ThrowOnError, "fields">;
    /**
     * Inspect Mission Skill Settings
     *
     * Returns Mission Skill source metadata and canonical editable roots for the dedicated Settings surface.
     */
    settings<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
        sessionID?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<MissionSkillSettingsResponses, MissionSkillSettingsErrors, ThrowOnError, "fields">;
}
export declare class Memory2 extends HeyApiClient {
    /**
     * List memory files for current project
     */
    list<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<PanelKnowledgeMemoryListResponses, unknown, ThrowOnError, "fields">;
    /**
     * Search memories
     */
    search<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        limit?: number;
        query: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<PanelKnowledgeMemorySearchResponses, unknown, ThrowOnError, "fields">;
    /**
     * Delete memory file
     */
    delete<ThrowOnError extends boolean = false>(parameters: {
        id: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<PanelKnowledgeMemoryDeleteResponses, PanelKnowledgeMemoryDeleteErrors, ThrowOnError, "fields">;
    /**
     * Get memory file content (all chunks)
     */
    get<ThrowOnError extends boolean = false>(parameters: {
        id: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<PanelKnowledgeMemoryGetResponses, PanelKnowledgeMemoryGetErrors, ThrowOnError, "fields">;
}
export declare class Knowledge extends HeyApiClient {
    private _memory?;
    get memory(): Memory2;
}
export declare class Message extends HeyApiClient {
    /**
     * Handle desktop panel message with streaming
     *
     * Route a desktop panel message through the control message service, streaming deltas via SSE.
     */
    stream<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        allow_create?: boolean;
        attachments?: Array<{
            filename?: string;
            mime: string;
            url: string;
        }>;
        channel?: string;
        model?: string;
        request_id?: string;
        sessionID?: string;
        source?: string;
        surface: "panel" | "gateway" | "slack" | "telegram" | "discord" | "feishu" | "whatsapp" | "googlechat" | "msteams" | "line" | "matrix" | "mattermost" | "signal" | "wecom" | "dingtalk" | "clickclack" | "imessage" | "irc" | "nextcloud-talk" | "nostr" | "qqbot" | "raft" | "reef" | "sms" | "synology-chat" | "tlon" | "twitch" | "zalo" | "zalouser";
        taskID?: string;
        text: string;
        thread?: string;
        user_id?: string;
    }, options?: Options<never, ThrowOnError, PanelMessageStreamResponse>): Promise<import("./core/serverSentEvents.gen.js").ServerSentEventsResult<PanelMessageStreamResponses>>;
}
export declare class Panel extends HeyApiClient {
    /**
     * List panel capabilities
     *
     * Return the panel tool actions available on a given surface, including local-action metadata and input schemas.
     */
    capabilities<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
        surface?: "panel" | "gateway" | "slack" | "telegram" | "discord" | "feishu" | "whatsapp" | "googlechat" | "msteams" | "line" | "matrix" | "mattermost" | "signal" | "wecom" | "dingtalk" | "clickclack" | "imessage" | "irc" | "nextcloud-talk" | "nostr" | "qqbot" | "raft" | "reef" | "sms" | "synology-chat" | "tlon" | "twitch" | "zalo" | "zalouser" | "right-sidebar";
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<PanelCapabilitiesResponses, unknown, ThrowOnError, "fields">;
    /**
     * Handle desktop panel message
     *
     * Route a desktop panel chat or button intent through the control message service.
     */
    message<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        allow_create?: boolean;
        attachments?: Array<{
            filename?: string;
            mime: string;
            url: string;
        }>;
        channel?: string;
        model?: string;
        request_id?: string;
        sessionID?: string;
        source?: string;
        surface: "panel" | "gateway" | "slack" | "telegram" | "discord" | "feishu" | "whatsapp" | "googlechat" | "msteams" | "line" | "matrix" | "mattermost" | "signal" | "wecom" | "dingtalk" | "clickclack" | "imessage" | "irc" | "nextcloud-talk" | "nostr" | "qqbot" | "raft" | "reef" | "sms" | "synology-chat" | "tlon" | "twitch" | "zalo" | "zalouser";
        taskID?: string;
        text: string;
        thread?: string;
        user_id?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<PanelMessageResponses, PanelMessageErrors, ThrowOnError, "fields">;
    private _knowledge?;
    get knowledge(): Knowledge;
    private _message?;
    get message2(): Message;
}
export declare class Path extends HeyApiClient {
    /**
     * Get paths
     *
     * Retrieve the current working directory and related path information for the OpenCorvus instance.
     */
    get<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<PathGetResponses, unknown, ThrowOnError, "fields">;
}
export declare class Permission extends HeyApiClient {
    /**
     * List durable pending permission requests
     */
    list<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<PermissionListResponses, unknown, ThrowOnError, "fields">;
    /**
     * List active permission grants
     */
    grants<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<PermissionGrantsResponses, unknown, ThrowOnError, "fields">;
    /**
     * Revoke an active permission grant
     */
    revoke<ThrowOnError extends boolean = false>(parameters: {
        grantID: PermissionIdentity;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<PermissionRevokeResponses, PermissionRevokeErrors, ThrowOnError, "fields">;
    /**
     * List permission ledger history
     */
    history<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<PermissionHistoryResponses, unknown, ThrowOnError, "fields">;
    /**
     * Decide a pending permission request
     */
    reply<ThrowOnError extends boolean = false>(parameters: {
        requestID: PermissionIdentity;
        directory?: string;
        actorID?: string;
        decision: PermissionDecision;
        message?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<PermissionReplyResponses, PermissionReplyErrors, ThrowOnError, "fields">;
}
export declare class Worktrees extends HeyApiClient {
    /**
     * Delete a current project worktree
     *
     * Remove a git worktree registered for the current project.
     */
    delete<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        worktreeRemoveInput: WorktreeRemoveInput;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ProjectCurrentWorktreesDeleteResponses, ProjectCurrentWorktreesDeleteErrors, ThrowOnError, "fields">;
}
export declare class Current extends HeyApiClient {
    /**
     * Delete current project
     *
     * Delete the current project's OpenCorvus state, task history, and project-local runtime directory. Source files in the workspace are not deleted.
     */
    delete<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        reason: string;
        surface: "api" | "overlay.work_ledger" | "overlay.selected_task" | "overlay.composer_stop" | "overlay.chat_request_stop" | "overlay.interrupt_task" | "overlay.archive_panel";
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ProjectCurrentDeleteResponses, ProjectCurrentDeleteErrors, ThrowOnError, "fields">;
    /**
     * Update current project
     *
     * Rename the currently active project record. The source directory on disk is not renamed.
     */
    update<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        name: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ProjectCurrentUpdateResponses, ProjectCurrentUpdateErrors, ThrowOnError, "fields">;
    /**
     * Inspect current project cleanup candidates
     *
     * Read-only inspection of orphan worktree ownership markers and worktree GC candidates. This route does not delete files or mutate markers.
     */
    cleanupCandidates<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ProjectCurrentCleanupCandidatesResponses, ProjectCurrentCleanupCandidatesErrors, ThrowOnError, "fields">;
    /**
     * Initialize git in current directory
     *
     * Run git init in the current working directory and refresh the active project context.
     */
    initGit<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ProjectCurrentInitGitResponses, ProjectCurrentInitGitErrors, ThrowOnError, "fields">;
    /**
     * Convert current anonymous project to a named project
     *
     * Move the complete dated anonymous project into a named destination while preserving its project identity, sessions, tasks, and attachments.
     */
    promoteAnonymous<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        destinationParent: string;
        name: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ProjectCurrentPromoteAnonymousResponses, ProjectCurrentPromoteAnonymousErrors, ThrowOnError, "fields">;
    /**
     * List current project worktrees
     *
     * Read the current project's registered primary and managed Git worktrees with current removal eligibility.
     */
    worktrees<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ProjectCurrentWorktreesResponses, ProjectCurrentWorktreesErrors, ThrowOnError, "fields">;
    private _worktrees?;
    get worktrees2(): Worktrees;
}
export declare class Project2 extends HeyApiClient {
    /**
     * List all projects
     *
     * Get a list of projects that have been opened with OpenCorvus.
     */
    list<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ProjectListResponses, unknown, ThrowOnError, "fields">;
    /**
     * Get current project
     *
     * Retrieve the currently active project that OpenCorvus is working with.
     */
    current<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ProjectCurrentResponses, unknown, ThrowOnError, "fields">;
    /**
     * Update project
     *
     * Update project properties such as name, icon, and commands.
     */
    update<ThrowOnError extends boolean = false>(parameters: {
        projectID: string;
        directory?: string;
        commands?: {
            /**
             * Startup script to run when creating a new workspace (worktree)
             */
            start?: string;
        };
        icon?: {
            color?: string;
            override?: string;
            url?: string;
        };
        name?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ProjectUpdateResponses, ProjectUpdateErrors, ThrowOnError, "fields">;
    private _current?;
    get current2(): Current;
}
export declare class Discover2 extends HeyApiClient {
    /**
     * Discover OpenAI-compatible provider models
     *
     * Fetches the explicit OpenAI-compatible /models endpoint for a user-supplied base URL. This route only runs when requested by the operator; provider startup remains offline-first.
     */
    models<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        api: string;
        apiKey?: string;
        providerID?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ProviderDiscoverModelsResponses, ProviderDiscoverModelsErrors, ThrowOnError, "fields">;
}
export declare class Models2 extends HeyApiClient {
    /**
     * Refresh configured provider model lists
     *
     * Refresh live model identities for configured providers without refreshing the provider registry declaration, then reset provider state so downstream callers see the updated list.
     */
    refresh<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ProviderModelsRefreshResponses, ProviderModelsRefreshErrors, ThrowOnError, "fields">;
}
export declare class Account2 extends HeyApiClient {
    /**
     * Get Provider account usage
     *
     * Fetch the selected Provider's normalized account usage using server-owned credentials without exposing credentials to the Overlay.
     */
    usage<ThrowOnError extends boolean = false>(parameters: {
        providerID: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ProviderAccountUsageResponses, ProviderAccountUsageErrors, ThrowOnError, "fields">;
}
export declare class Auth4 extends HeyApiClient {
    /**
     * Execute Provider API auth method
     *
     * Execute an API credential method with collected inputs.
     */
    execute<ThrowOnError extends boolean = false>(parameters: {
        providerID: string;
        directory?: string;
        inputs?: {
            [key: string]: string;
        };
        method: number;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ProviderAuthExecuteResponses, ProviderAuthExecuteErrors, ThrowOnError, "fields">;
    /**
     * Get auth prompts
     *
     * Return the prompts needed for a specific authentication method.
     */
    prompts<ThrowOnError extends boolean = false>(parameters: {
        providerID: string;
        directory?: string;
        inputs?: {
            [key: string]: string;
        };
        method: number;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ProviderAuthPromptsResponses, ProviderAuthPromptsErrors, ThrowOnError, "fields">;
}
export declare class Oauth2 extends HeyApiClient {
    /**
     * OAuth authorize
     *
     * Initiate OAuth authorization for a specific AI provider to get an authorization URL.
     */
    authorize<ThrowOnError extends boolean = false>(parameters: {
        providerID: string;
        directory?: string;
        inputs?: {
            [key: string]: string;
        };
        method: number;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ProviderOauthAuthorizeResponses, ProviderOauthAuthorizeErrors, ThrowOnError, "fields">;
    /**
     * OAuth callback
     *
     * Handle the OAuth callback from a provider after user authorization.
     */
    callback<ThrowOnError extends boolean = false>(parameters: {
        providerID: string;
        directory?: string;
        code?: string;
        flowID: string;
        method: number;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ProviderOauthCallbackResponses, ProviderOauthCallbackErrors, ThrowOnError, "fields">;
    /**
     * Cancel pending Provider authorization
     *
     * Release the exact pending OAuth occurrence before credential exchange starts.
     */
    cancel<ThrowOnError extends boolean = false>(parameters: {
        providerID: string;
        directory?: string;
        flowID: string;
        method: number;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ProviderOauthCancelResponses, ProviderOauthCancelErrors, ThrowOnError, "fields">;
}
export declare class Provider extends HeyApiClient {
    /**
     * List providers
     *
     * Get a list of all available AI providers, including both available and connected ones.
     */
    list<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ProviderListResponses, unknown, ThrowOnError, "fields">;
    /**
     * Get provider auth methods
     *
     * Retrieve available authentication methods for all AI providers.
     */
    auth<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ProviderAuthResponses, unknown, ThrowOnError, "fields">;
    /**
     * Refresh the provider registry
     *
     * Pulls api.json from the configured registry URL and atomically replaces the durable canonical catalog declaration. Configured live model identities use the separate models refresh route. The runtime never refreshes implicitly.
     */
    refresh<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ProviderRefreshResponses, unknown, ThrowOnError, "fields">;
    /**
     * Delete a project provider
     *
     * Commit removal of the project provider declaration, provider model references, enabled or disabled references, and its saved credential under one durable mutation owner.
     */
    remove<ThrowOnError extends boolean = false>(parameters: {
        providerID: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ProviderRemoveResponses, ProviderRemoveErrors, ThrowOnError, "fields">;
    /**
     * Test provider connection
     *
     * Run a minimal live request against a provider using the selected or default model.
     */
    test<ThrowOnError extends boolean = false>(parameters: {
        providerID: string;
        directory?: string;
        modelID?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<ProviderTestResponses, ProviderTestErrors, ThrowOnError, "fields">;
    private _discover?;
    get discover(): Discover2;
    private _models?;
    get models(): Models2;
    private _account?;
    get account(): Account2;
    private _auth?;
    get auth2(): Auth4;
    private _oauth?;
    get oauth(): Oauth2;
}
export declare class Pty extends HeyApiClient {
    /**
     * List PTY sessions
     *
     * Get active Pseudo Terminal (PTY) sessions managed by OpenCorvus.
     */
    list<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<PtyListResponses, unknown, ThrowOnError, "fields">;
    /**
     * Create PTY session
     *
     * Create a project-bound Pseudo Terminal (PTY) session from a configured terminal profile.
     */
    create<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        cwd?: string;
        profileID: string;
        title?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<PtyCreateResponses, PtyCreateErrors, ThrowOnError, "fields">;
    /**
     * Remove PTY session
     *
     * Remove and terminate a Pseudo Terminal (PTY) session.
     */
    remove<ThrowOnError extends boolean = false>(parameters: {
        ptyID: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<PtyRemoveResponses, PtyRemoveErrors, ThrowOnError, "fields">;
    /**
     * Get PTY session
     *
     * Retrieve a specific Pseudo Terminal (PTY) session.
     */
    get<ThrowOnError extends boolean = false>(parameters: {
        ptyID: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<PtyGetResponses, PtyGetErrors, ThrowOnError, "fields">;
    /**
     * Update PTY session
     *
     * Update title or size for a Pseudo Terminal (PTY) session.
     */
    update<ThrowOnError extends boolean = false>(parameters: {
        ptyID: string;
        directory?: string;
        size?: {
            cols: number;
            rows: number;
        };
        title?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<PtyUpdateResponses, PtyUpdateErrors, ThrowOnError, "fields">;
    /**
     * Write PTY input
     *
     * Write user input to a running Pseudo Terminal (PTY) session.
     */
    input<ThrowOnError extends boolean = false>(parameters: {
        ptyID: string;
        directory?: string;
        data: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<PtyInputResponses, PtyInputErrors, ThrowOnError, "fields">;
    /**
     * Stream PTY output
     *
     * Stream buffered and live Pseudo Terminal (PTY) output through Server-Sent Events (SSE).
     */
    output<ThrowOnError extends boolean = false>(parameters: {
        ptyID: string;
        directory?: string;
        cursor?: number;
    }, options?: Options<never, ThrowOnError, PtyOutputResponse>): Promise<import("./core/serverSentEvents.gen.js").ServerSentEventsResult<PtyOutputResponses>>;
}
export declare class Question extends HeyApiClient {
    /**
     * List pending questions
     *
     * Get all pending question requests across all sessions.
     */
    list<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<QuestionListResponses, unknown, ThrowOnError, "fields">;
    /**
     * Reject question request
     *
     * Reject a question request from the AI assistant.
     */
    reject<ThrowOnError extends boolean = false>(parameters: {
        requestID: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<QuestionRejectResponses, QuestionRejectErrors, ThrowOnError, "fields">;
    /**
     * Reply to question request
     *
     * Provide answers to a question request from the AI assistant.
     */
    reply<ThrowOnError extends boolean = false>(parameters: {
        requestID: string;
        directory?: string;
        answers: Array<QuestionAnswer>;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<QuestionReplyResponses, QuestionReplyErrors, ThrowOnError, "fields">;
}
export declare class Config3 extends HeyApiClient {
    /**
     * Get session effective configuration
     *
     * Return project configuration with the session overlay applied, plus a per-key origin tree for project vs session values.
     */
    get<ThrowOnError extends boolean = false>(parameters: {
        sessionID: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<SessionConfigGetResponses, SessionConfigGetErrors, ThrowOnError, "fields">;
    /**
     * Update session configuration overlay
     *
     * Merge a sparse session-scoped config overlay into session metadata. Project configuration is unchanged.
     */
    update<ThrowOnError extends boolean = false>(parameters: {
        sessionID: string;
        directory?: string;
        agent?: {
            chat?: {
                model?: string | null;
                prompt?: string | null;
                prompt_append?: string | null;
                temperature?: number | null;
                top_p?: number | null;
                variant?: string | null;
            } | null;
            coding?: {
                model?: string | null;
                prompt?: string | null;
                prompt_append?: string | null;
                temperature?: number | null;
                top_p?: number | null;
                variant?: string | null;
            } | null;
            compaction?: {
                model?: string | null;
                prompt?: string | null;
                prompt_append?: string | null;
                temperature?: number | null;
                top_p?: number | null;
                variant?: string | null;
            } | null;
            control?: {
                model?: string | null;
                prompt?: string | null;
                prompt_append?: string | null;
                temperature?: number | null;
                top_p?: number | null;
                variant?: string | null;
            } | null;
            mission?: {
                model?: string | null;
                prompt?: string | null;
                prompt_append?: string | null;
                temperature?: number | null;
                top_p?: number | null;
                variant?: string | null;
            } | null;
            orchestrator?: {
                model?: string | null;
                prompt?: string | null;
                prompt_append?: string | null;
                temperature?: number | null;
                top_p?: number | null;
                variant?: string | null;
            } | null;
            summary?: {
                model?: string | null;
                prompt?: string | null;
                prompt_append?: string | null;
                temperature?: number | null;
                top_p?: number | null;
                variant?: string | null;
            } | null;
            title?: {
                model?: string | null;
                prompt?: string | null;
                prompt_append?: string | null;
                temperature?: number | null;
                top_p?: number | null;
                variant?: string | null;
            } | null;
        } | null;
        expert_squads?: {
            [key: string]: {
                agents?: {
                    [key: string]: {
                        runtime?: {
                            model?: string | null;
                            options?: {
                                [key: string]: unknown;
                            } | null;
                            prompt_append?: string | null;
                            steps?: number | null;
                            temperature?: number | null;
                            top_p?: number | null;
                            variant?: string | null;
                        } | null;
                    } | null;
                } | null;
            } | null;
        } | null;
        model?: string | null;
        prompt?: {
            [key: string]: string | null;
        } | null;
        prompt_profile?: {
            active?: string | null;
        } | null;
        runtime_templates?: {
            [key: string]: {
                model?: string | null;
                options?: {
                    [key: string]: unknown;
                } | null;
                prompt_append?: string | null;
                steps?: number | null;
                temperature?: number | null;
                top_p?: number | null;
                variant?: string | null;
            } | null;
        } | null;
        skill_mounts?: {
            [key: string]: {
                [key: string]: {
                    [key: string]: boolean | null;
                } | null;
            } | null;
        } | null;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<SessionConfigUpdateResponses, SessionConfigUpdateErrors, ThrowOnError, "fields">;
}
export declare class Conversation2 extends HeyApiClient {
    /**
     * Page older session conversation transcript
     *
     * Return a bounded Mission or conversation transcript slice older than the current hydrate tail.
     */
    history<ThrowOnError extends boolean = false>(parameters: {
        sessionID: string;
        directory?: string;
        before: number;
        before_order_key: string;
        before_id?: string;
        limit?: number;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<SessionConversationHistoryResponses, SessionConversationHistoryErrors, ThrowOnError, "fields">;
}
export declare class Session4 extends HeyApiClient {
    /**
     * List sessions
     *
     * Get a list of all OpenCorvus sessions, sorted by most recently updated.
     */
    list<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
        roots?: "true" | "false";
        start?: number;
        search?: string;
        limit?: number;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<SessionListResponses, unknown, ThrowOnError, "fields">;
    /**
     * Create session
     *
     * Create a new OpenCorvus session for interacting with AI assistants and managing conversations.
     */
    create<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        kind: "root" | "orchestrator" | "assistant" | "mission" | "delegated-worker" | "intent-analysis" | "requirements" | "frontend-design" | "architect" | "goal-workload-analyst" | "integrity" | "fact-check" | "build" | "explore" | "deep-research" | "frontend-research" | "visual-qa" | "system";
        metadata?: {
            [key: string]: unknown;
        };
        parentID?: string;
        permission?: Array<{
            action: "allow" | "deny";
            pattern: string;
            permission: string;
        }>;
        title?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<SessionCreateResponses, SessionCreateErrors, ThrowOnError, "fields">;
    /**
     * List sessions across projects
     *
     * List sessions across all projects with compound cursor-based pagination and optional archived inclusion. Sets x-next-cursor-updated and x-next-cursor-session-id response headers when more results are available.
     */
    listGlobal<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
        roots?: "true" | "false";
        start?: number;
        cursorUpdated?: number;
        cursorSessionID?: string;
        search?: string;
        limit?: number;
        archived?: "true" | "false";
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<SessionListGlobalResponses, SessionListGlobalErrors, ThrowOnError, "fields">;
    /**
     * Get session status
     *
     * Retrieve the current status of sessions in the selected Project, including active, idle, and completed states.
     */
    status<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<SessionStatusResponses, SessionStatusErrors, ThrowOnError, "fields">;
    /**
     * Delete session
     *
     * Retire a Task-, Mission-, Panel- or Global-Chat-owned session as an immutable audit tombstone. A standalone session without durable domain ownership is physically deleted with its conversation runtime data.
     */
    delete<ThrowOnError extends boolean = false>(parameters: {
        sessionID: string;
        directory?: string;
        deleteTasks?: "true" | "false";
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<SessionDeleteResponses, SessionDeleteErrors, ThrowOnError, "fields">;
    /**
     * Get session
     *
     * Retrieve detailed information about a specific OpenCorvus session.
     */
    get<ThrowOnError extends boolean = false>(parameters: {
        sessionID: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<SessionGetResponses, SessionGetErrors, ThrowOnError, "fields">;
    /**
     * Update session
     *
     * Update properties of an existing session, such as title or other metadata.
     */
    update<ThrowOnError extends boolean = false>(parameters: {
        sessionID: string;
        directory?: string;
        time?: {
            archived?: number | null;
        };
        title?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<SessionUpdateResponses, SessionUpdateErrors, ThrowOnError, "fields">;
    /**
     * Abort session
     *
     * Abort an active session and stop any ongoing AI processing or command execution.
     */
    abort<ThrowOnError extends boolean = false>(parameters: {
        sessionID: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<SessionAbortResponses, SessionAbortErrors, ThrowOnError, "fields">;
    /**
     * Get session children
     *
     * Retrieve all child sessions that were forked from the specified parent session.
     */
    children<ThrowOnError extends boolean = false>(parameters: {
        sessionID: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<SessionChildrenResponses, SessionChildrenErrors, ThrowOnError, "fields">;
    /**
     * Send command
     *
     * Send a new command to a standalone or Coding Assistant session for execution by the AI assistant. Mission execution uses mission.wake; projected worker guidance uses the task-scoped operator-steer route.
     */
    command<ThrowOnError extends boolean = false>(parameters: {
        sessionID: string;
        directory?: string;
        agent?: string;
        arguments: string;
        command: string;
        messageID: string;
        model?: string;
        parts?: Array<{
            filename?: string;
            id?: string;
            mime: string;
            orderKey?: string;
            presentation?: "attachment-index";
            source?: FilePartSource;
            type: "file";
            url: string;
        }>;
        variant?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<SessionCommandResponses, SessionCommandErrors, ThrowOnError, "fields">;
    /**
     * Hydrate session conversation state
     *
     * Load the persisted conversation inputs needed to rebuild the overlay conversation tree for a supervisor session before SSE resumes.
     */
    conversation<ThrowOnError extends boolean = false>(parameters: {
        sessionID: string;
        directory?: string;
        tail_limit?: number;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<SessionConversationResponses, SessionConversationErrors, ThrowOnError, "fields">;
    /**
     * Get message diff
     *
     * Get the file changes (diff) that resulted from a specific user message in the session.
     */
    diff<ThrowOnError extends boolean = false>(parameters: {
        sessionID: string;
        directory?: string;
        messageID?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<SessionDiffResponses, unknown, ThrowOnError, "fields">;
    /**
     * Subscribe to session events
     */
    events<ThrowOnError extends boolean = false>(parameters: {
        sessionID: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError, SessionEventsResponse>): Promise<import("./core/serverSentEvents.gen.js").ServerSentEventsResult<SessionEventsResponses>>;
    /**
     * Fork session
     *
     * Create a new session by forking an existing session at a specific message point.
     */
    fork<ThrowOnError extends boolean = false>(parameters: {
        sessionID: string;
        directory?: string;
        messageID?: string;
        purpose?: "fork" | "side-chat";
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<SessionForkResponses, SessionForkErrors, ThrowOnError, "fields">;
    /**
     * Initialize session
     *
     * Analyze the current application and create an AGENTS.md file with project-specific agent configurations.
     */
    init<ThrowOnError extends boolean = false>(parameters: {
        sessionID: string;
        directory?: string;
        messageID: string;
        modelID: string;
        providerID: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<SessionInitResponses, SessionInitErrors, ThrowOnError, "fields">;
    /**
     * Get session messages
     *
     * Retrieve all messages in a session, including user prompts and AI responses.
     */
    messages<ThrowOnError extends boolean = false>(parameters: {
        sessionID: string;
        directory?: string;
        limit?: number;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<SessionMessagesResponses, SessionMessagesErrors, ThrowOnError, "fields">;
    /**
     * Send message
     *
     * Create and send a new message to a standalone or Coding Assistant session, waiting until assistant output is complete. Mission execution uses mission.wake; projected worker guidance uses the task-scoped operator-steer route.
     */
    prompt<ThrowOnError extends boolean = false>(parameters: {
        sessionID: string;
        directory?: string;
        agent?: string;
        format?: OutputFormat;
        messageID: string;
        model?: {
            modelID: string;
            providerID: string;
        };
        parts: Array<TextPartInput | FilePartInput>;
        variant?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<SessionPromptResponses, SessionPromptErrors, ThrowOnError, "fields">;
    /**
     * Delete message
     *
     * Permanently delete a specific message (and all of its parts) from a session. This does not revert any file changes that may have been made while processing the message.
     */
    deleteMessage<ThrowOnError extends boolean = false>(parameters: {
        sessionID: string;
        messageID: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<SessionDeleteMessageResponses, SessionDeleteMessageErrors, ThrowOnError, "fields">;
    /**
     * Get message
     *
     * Retrieve a specific message from a session by its message ID.
     */
    message<ThrowOnError extends boolean = false>(parameters: {
        sessionID: string;
        messageID: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<SessionMessageResponses, SessionMessageErrors, ThrowOnError, "fields">;
    /**
     * Get message part
     *
     * Retrieve one exact persisted part from a specific session message.
     */
    messagePart<ThrowOnError extends boolean = false>(parameters: {
        sessionID: string;
        messageID: string;
        partID: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<SessionMessagePartResponses, SessionMessagePartErrors, ThrowOnError, "fields">;
    /**
     * Run shell command
     *
     * Execute a shell command within a standalone or Coding Assistant session context and return the AI's response. Mission execution uses mission.wake; projected worker guidance uses the task-scoped operator-steer route.
     */
    shell<ThrowOnError extends boolean = false>(parameters: {
        sessionID: string;
        directory?: string;
        agent: string;
        command: string;
        messageID: string;
        model?: {
            modelID: string;
            providerID: string;
        };
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<SessionShellResponses, SessionShellErrors, ThrowOnError, "fields">;
    /**
     * List side conversations
     */
    sideChats<ThrowOnError extends boolean = false>(parameters: {
        sessionID: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<SessionSideChatsResponses, SessionSideChatsErrors, ThrowOnError, "fields">;
    /**
     * Open side conversation
     *
     * Create an independent assistant Session with completed source history as visible reference context. The source may continue running.
     */
    createSideChat<ThrowOnError extends boolean = false>(parameters: {
        sessionID: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<SessionCreateSideChatResponses, SessionCreateSideChatErrors, ThrowOnError, "fields">;
    /**
     * Summarize session
     *
     * Generate a concise summary of the session using AI compaction to preserve key information.
     */
    summarize<ThrowOnError extends boolean = false>(parameters: {
        sessionID: string;
        directory?: string;
        auto?: boolean;
        focus?: string;
        modelID: string;
        providerID: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<SessionSummarizeResponses, SessionSummarizeErrors, ThrowOnError, "fields">;
    /**
     * Get session todos
     *
     * Retrieve the todo list associated with a specific session, showing tasks and action items.
     */
    todo<ThrowOnError extends boolean = false>(parameters: {
        sessionID: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<SessionTodoResponses, SessionTodoErrors, ThrowOnError, "fields">;
    /**
     * Get session AgentTrace events
     */
    trace<ThrowOnError extends boolean = false>(parameters: {
        sessionID: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<SessionTraceResponses, unknown, ThrowOnError, "fields">;
    /**
     * Project Mission child Task artifacts onto their owning turns
     */
    turnArtifacts<ThrowOnError extends boolean = false>(parameters: {
        sessionID: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<SessionTurnArtifactsResponses, SessionTurnArtifactsErrors, ThrowOnError, "fields">;
    private _config?;
    get config(): Config3;
    private _conversation?;
    get conversation2(): Conversation2;
}
export declare class InteractiveArtifact extends HeyApiClient {
    /**
     * Read session interactive artifact
     *
     * Return one message-owned interactive artifact from the producing session. The artifact payload is the only renderer content source.
     */
    readSessionArtifact<ThrowOnError extends boolean = false>(parameters: {
        sessionID: string;
        artifactID: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<InteractiveArtifactReadSessionArtifactResponses, InteractiveArtifactReadSessionArtifactErrors, ThrowOnError, "fields">;
    /**
     * Subscribe to MCP App capability changes
     *
     * Authorize with one message-owned MCP App artifact, then stream session artifact lifecycle changes and project MCP capability changes for Overlay-side exact artifact and server filtering.
     */
    eventsMcpApp<ThrowOnError extends boolean = false>(parameters: {
        sessionID: string;
        artifactID: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError, InteractiveArtifactEventsMcpAppResponse>): Promise<import("./core/serverSentEvents.gen.js").ServerSentEventsResult<InteractiveArtifactEventsMcpAppResponses>>;
    /**
     * Forward an MCP App request
     *
     * Forward one stable MCP Apps request through the exact MCP server binding owned by the message artifact. The client cannot select a server.
     */
    requestMcpApp<ThrowOnError extends boolean = false>(parameters: {
        sessionID: string;
        artifactID: string;
        directory?: string;
        mcpAppHostRequest: McpAppHostRequest;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<InteractiveArtifactRequestMcpAppResponses, InteractiveArtifactRequestMcpAppErrors, ThrowOnError, "fields">;
}
export declare class Part extends HeyApiClient {
    /**
     * Delete a part from a message
     */
    delete<ThrowOnError extends boolean = false>(parameters: {
        sessionID: string;
        messageID: string;
        partID: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<PartDeleteResponses, PartDeleteErrors, ThrowOnError, "fields">;
    /**
     * Update a part in a message
     */
    update<ThrowOnError extends boolean = false>(parameters: {
        sessionID: string;
        messageID: string;
        partID: string;
        directory?: string;
        part: Part2;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<PartUpdateResponses, PartUpdateErrors, ThrowOnError, "fields">;
}
export declare class Market2 extends HeyApiClient {
    /**
     * Inspect a Skill Market candidate
     *
     * Download and validate the exact candidate bundle without installing it.
     */
    detail<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        id: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<SkillMarketDetailResponses, SkillMarketDetailErrors, ThrowOnError, "fields">;
    /**
     * Install an inspected Skill Market candidate
     *
     * Install exactly one candidate only when its current content matches the inspected digest.
     */
    install<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        expected_hash: string;
        id: string;
        policy?: "allow" | "deny";
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<SkillMarketInstallResponses, SkillMarketInstallErrors, ThrowOnError, "fields">;
    /**
     * Search the Skill Market
     *
     * Search the current Skill Market and project live installation status for exact candidates.
     */
    search<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        query: string;
        limit?: number;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<SkillMarketSearchResponses, SkillMarketSearchErrors, ThrowOnError, "fields">;
}
export declare class Skill2 extends HeyApiClient {
    /**
     * Get skill directories
     *
     * Get global config, managed skill install, and remote cache directories.
     */
    directories<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<SkillDirectoriesResponses, unknown, ThrowOnError, "fields">;
    /**
     * Import a dropped skill source
     *
     * Write a dropped SKILL.md file, skill directory, or zip archive into the current project's .opencorvus skill directory.
     */
    importFile<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
        archiveBase64?: string;
        content?: string;
        filename?: string;
        files?: Array<{
            content?: string;
            contentBase64?: string;
            path: string;
        }>;
        policy?: "allow" | "deny";
        sourceName?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<SkillImportFileResponses, unknown, ThrowOnError, "fields">;
    /**
     * Install or import a skill source
     *
     * Install a skill source from a local path, remote URL, or git repository into the global skill config.
     */
    install<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        kind: "path" | "url" | "git";
        policy?: "allow" | "deny";
        value: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<SkillInstallResponses, unknown, ThrowOnError, "fields">;
    /**
     * List installed skills
     *
     * Get installed skills with source classification and effective permission policy.
     */
    installed<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<SkillInstalledResponses, unknown, ThrowOnError, "fields">;
    /**
     * List Skill catalog issues
     *
     * Returns source-scoped Skill discovery and validation issues without hiding healthy catalog entries.
     */
    issues<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<SkillIssuesResponses, unknown, ThrowOnError, "fields">;
    /**
     * List skill markets
     *
     * Get the single current Skill Market provider used by OpenCorvus.
     */
    market<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<SkillMarketResponses, unknown, ThrowOnError, "fields">;
    /**
     * Set a qualified skill mount override
     *
     * Set or delete one project/session operator override qualified by expert squad, projected Skill owner, and default skill ref.
     */
    setMountOverride<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        body: {
            agentID: "orchestrator" | string;
            defaultSkillRef: string;
            expertSquadID: string;
            override: boolean | null;
            scope: "project";
        } | {
            agentID: "orchestrator" | string;
            defaultSkillRef: string;
            expertSquadID: string;
            override: boolean | null;
            scope: "session";
            sessionID: string;
        };
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<SkillSetMountOverrideResponses, unknown, ThrowOnError, "fields">;
    /**
     * List agent skill mounts
     *
     * Get the skill pool, known agents, effective per-agent mounts, and unmounted warnings.
     */
    mounts<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
        sessionID?: string;
        expertSquadID?: string;
        refresh?: "true";
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<SkillMountsResponses, unknown, ThrowOnError, "fields">;
    /**
     * Set skill permission policy
     *
     * Set the global allow or deny capability policy for a named skill.
     */
    policy<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        action: "allow" | "deny";
        name: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<SkillPolicyResponses, unknown, ThrowOnError, "fields">;
    /**
     * Remove a skill source
     *
     * Remove a configured skill source from global config and delete managed installs when applicable.
     */
    remove<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        kind?: "path" | "url" | "git" | "market";
        source: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<SkillRemoveResponses, unknown, ThrowOnError, "fields">;
    /**
     * Update an installed skill
     *
     * Refresh a built-in Skill from the current application payload or atomically replace one writable external Skill from the configured update server.
     */
    update<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        name: string;
        source: "builtin" | "server";
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<SkillUpdateResponses, unknown, ThrowOnError, "fields">;
    private _market?;
    get market2(): Market2;
}
export declare class BrowserPreview extends HeyApiClient {
    /**
     * Resolve task browser preview target
     *
     * Return the task-scoped browser preview target. Saved EngineArtifact target records are the only preview target source.
     */
    taskTarget<ThrowOnError extends boolean = false>(parameters: {
        taskID: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<BrowserPreviewTaskTargetResponses, BrowserPreviewTaskTargetErrors, ThrowOnError, "fields">;
    /**
     * Capture browser preview verification evidence
     *
     * Capture Playwright-backed screenshot evidence for the task-scoped browser preview target and persist the evidence artifact.
     */
    captureTaskTarget<ThrowOnError extends boolean = false>(parameters: {
        taskID: string;
        directory?: string;
        targetID: string;
        viewportIDs: Array<"desktop" | "tablet" | "mobile">;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<BrowserPreviewCaptureTaskTargetResponses, BrowserPreviewCaptureTaskTargetErrors, ThrowOnError, "fields">;
    /**
     * Compare browser preview regions against source visual evidence
     *
     * Capture task-scoped local regions from the persisted preview target and persist source/local side-by-side comparison artifacts.
     */
    compareTaskTargetRegions<ThrowOnError extends boolean = false>(parameters: {
        taskID: string;
        directory?: string;
        inlineBindings: Array<{
            crop_intent: "full-region" | "content-well";
            implementation: {
                locator: {
                    kind: "test-id";
                    value: string;
                } | {
                    kind: "data-oc-region";
                    value: string;
                } | {
                    kind: "role";
                    name: string;
                    role: string;
                } | {
                    kind: "selector";
                    owner_file: string;
                    value: string;
                };
                route?: string;
            };
            region_id: string;
            source: {
                bbox: {
                    height: number;
                    width: number;
                    x: number;
                    y: number;
                };
                reference_artifact: {
                    bytes: number;
                    media_type: string;
                    path: string;
                    sha256: string;
                    snapshot: {
                        manifest_sha256: string;
                        project_id: string;
                        schema_version: 2;
                        snapshot_id: string;
                        task_id: string;
                    };
                    tree: string;
                };
            };
            state_id?: string;
            viewport_id: "desktop" | "tablet" | "mobile";
        }>;
        output?: {
            include_diff?: boolean;
        };
        targetID: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<BrowserPreviewCompareTaskTargetRegionsResponses, BrowserPreviewCompareTaskTargetRegionsErrors, ThrowOnError, "fields">;
    /**
     * Read browser preview verification evidence
     *
     * Return the persisted Playwright evidence artifact for a task-scoped browser preview target.
     */
    readTaskEvidence<ThrowOnError extends boolean = false>(parameters: {
        taskID: string;
        evidenceID: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<BrowserPreviewReadTaskEvidenceResponses, BrowserPreviewReadTaskEvidenceErrors, ThrowOnError, "fields">;
    /**
     * Read browser preview region comparison artifact
     *
     * Return a persisted source, implementation, side-by-side, or diff PNG for region comparison evidence.
     */
    readTaskEvidenceArtifact<ThrowOnError extends boolean = false>(parameters: {
        taskID: string;
        evidenceID: string;
        artifactName: "source" | "implementation" | "side-by-side" | "diff";
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<BrowserPreviewReadTaskEvidenceArtifactResponses, BrowserPreviewReadTaskEvidenceArtifactErrors, ThrowOnError, "fields">;
    /**
     * Read browser preview evidence screenshot
     *
     * Return the persisted Playwright PNG screenshot for task-scoped browser preview evidence.
     */
    readTaskEvidenceCapture<ThrowOnError extends boolean = false>(parameters: {
        taskID: string;
        evidenceID: string;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<BrowserPreviewReadTaskEvidenceCaptureResponses, BrowserPreviewReadTaskEvidenceCaptureErrors, ThrowOnError, "fields">;
    /**
     * Set task browser preview target
     *
     * Promote an existing task browser preview target artifact or persist an operator-entered HTTP(S) URL with its explicit task viewport contract.
     */
    selectTaskTarget<ThrowOnError extends boolean = false>(parameters: {
        taskID: string;
        directory?: string;
        body: {
            targetID: string;
        } | {
            url: string;
            viewports: Array<{
                height: number;
                id: "desktop" | "tablet" | "mobile";
                labelKey: string;
                width: number;
            }>;
        };
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<BrowserPreviewSelectTaskTargetResponses, BrowserPreviewSelectTaskTargetErrors, ThrowOnError, "fields">;
}
export declare class Terminal extends HeyApiClient {
    /**
     * Open system terminal
     *
     * Open the active project directory in the operating system terminal application.
     */
    open<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        cwd: string;
        profileID?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<TerminalOpenResponses, TerminalOpenErrors, ThrowOnError, "fields">;
    /**
     * List system terminal profiles
     *
     * List shell profiles launchable in the operating system terminal application.
     */
    profiles<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<TerminalProfilesResponses, TerminalProfilesErrors, ThrowOnError, "fields">;
}
export declare class CommitMessage extends HeyApiClient {
    /**
     * Generate a Git commit message with streaming AI
     *
     * Use the configured helper model to stream one editable Git commit subject from the current project diff and recent subject style.
     */
    stream<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
        sessionID?: string;
        taskID?: string;
    }, options?: Options<never, ThrowOnError, VcsCommitMessageStreamResponse>): Promise<import("./core/serverSentEvents.gen.js").ServerSentEventsResult<VcsCommitMessageStreamResponses>>;
}
export declare class Vcs extends HeyApiClient {
    /**
     * Get VCS info
     *
     * Retrieve version control system (VCS) information for the current project, such as git branch and working tree status.
     */
    get<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<VcsGetResponses, VcsGetErrors, ThrowOnError, "fields">;
    /**
     * Switch local VCS branch
     *
     * Switch the current project checkout to an exact existing local Git branch without discarding working-tree changes.
     */
    switchBranch<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        branch: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<VcsSwitchBranchResponses, VcsSwitchBranchErrors, ThrowOnError, "fields">;
    /**
     * List local VCS branches
     *
     * List the exact local Git branches for the current project and identify the active branch.
     */
    branches<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<VcsBranchesResponses, VcsBranchesErrors, ThrowOnError, "fields">;
    /**
     * Commit current VCS changes
     *
     * Stage every current project working-tree change and create one Git commit with the exact supplied message.
     */
    commit<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        message: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<VcsCommitResponses, VcsCommitErrors, ThrowOnError, "fields">;
    /**
     * Get VCS diff
     *
     * Retrieve the current git diff for the working tree or against the default branch.
     */
    diff<ThrowOnError extends boolean = false>(parameters?: {
        mode?: "git" | "branch";
        context?: number;
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<VcsDiffResponses, VcsDiffErrors, ThrowOnError, "fields">;
    /**
     * Push current VCS branch
     *
     * Push the current Git branch through its configured upstream without creating or changing remotes.
     */
    push<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<VcsPushResponses, VcsPushErrors, ThrowOnError, "fields">;
    private _commitMessage?;
    get commitMessage(): CommitMessage;
}
export declare class WorkLedger extends HeyApiClient {
    /**
     * List Work Ledger rows
     *
     * Return one unified Mission, Task, and Chat/Work ledger projection. Tasks with an exact Mission root are nested inside that Mission; unarchived Tasks without a resolvable Mission root are returned as top-level rows.
     */
    list<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
        search?: string;
        limit?: number;
        cursorUpdated?: number;
        cursorPinned?: "true" | "false";
        cursorRowKey?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<WorkLedgerListResponses, WorkLedgerListErrors, ThrowOnError, "fields">;
    /**
     * List archived Work Ledger rows
     *
     * Return archived Mission, Task, and Chat/Work records for the Settings archive surface.
     */
    listArchived<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
        search?: string;
        limit?: number;
        cursorUpdated?: number;
        cursorPinned?: "true" | "false";
        cursorRowKey?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<WorkLedgerListArchivedResponses, WorkLedgerListArchivedErrors, ThrowOnError, "fields">;
    /**
     * Subscribe to Work Ledger change notifications
     *
     * Unified Work Ledger Server-Sent Events (SSE) stream. Generic Mission, Chat, Work, Task, and Project changes tell clients to refetch /work-ledger; conversation handoffs carry exact caller and target lineage for activation followed by caller archival.
     */
    events<ThrowOnError extends boolean = false>(options?: Options<never, ThrowOnError, WorkLedgerEventsResponse>): Promise<import("./core/serverSentEvents.gen.js").ServerSentEventsResult<WorkLedgerEventsResponses>>;
    /**
     * Pin or unpin a Work Ledger item
     *
     * Persist pin state for a Mission, Task, or Chat shown by the Work Ledger.
     */
    setItemPinned<ThrowOnError extends boolean = false>(parameters: {
        kind: "mission" | "task" | "chat";
        itemID: string;
        directory?: string;
        pinned: boolean;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<WorkLedgerSetItemPinnedResponses, WorkLedgerSetItemPinnedErrors, ThrowOnError, "fields">;
    /**
     * Pin or unpin a Work Ledger project
     *
     * Persist pin state for a Project shown by the Work Ledger.
     */
    setProjectPinned<ThrowOnError extends boolean = false>(parameters: {
        projectID: string;
        pinned: boolean;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<WorkLedgerSetProjectPinnedResponses, WorkLedgerSetProjectPinnedErrors, ThrowOnError, "fields">;
}
export declare class Capability2 extends HeyApiClient {
    /**
     * Inspect native Work capabilities
     *
     * Returns the fixed native Work harness tool declaration and its project-owned Skill and MCP assignments. This route never reads an active Expert Squad or session overlay.
     */
    get<ThrowOnError extends boolean = false>(parameters?: {
        directory?: string;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<WorkCapabilityGetResponses, WorkCapabilityGetErrors, ThrowOnError, "fields">;
    /**
     * Update native Work capability assignments
     *
     * Atomically assigns or unassigns one project-owned Skill or MCP server reference for the fixed native Work harness.
     */
    update<ThrowOnError extends boolean = false>(parameters: {
        directory?: string;
        conversationCapabilityUpdate: ConversationCapabilityUpdate;
    }, options?: Options<never, ThrowOnError>): import("./client/types.gen.js").RequestResult<WorkCapabilityUpdateResponses, WorkCapabilityUpdateErrors, ThrowOnError, "fields">;
}
export declare class Work3 extends HeyApiClient {
    private _capability?;
    get capability(): Capability2;
}
export declare class OpenCorvusClient extends HeyApiClient {
    static readonly __registry: HeyApiRegistry<OpenCorvusClient>;
    constructor(args?: {
        client?: Client;
        key?: string;
    });
    private _app?;
    get app(): App;
    private _quicknote?;
    get quicknote(): Quicknote;
    private _attachment?;
    get attachment(): Attachment;
    private _auth?;
    get auth(): Auth;
    private _channel?;
    get channel(): Channel;
    private _chat?;
    get chat(): Chat;
    private _coding?;
    get coding(): Coding;
    private _command?;
    get command(): Command;
    private _computer?;
    get computer(): Computer;
    private _config?;
    get config(): Config;
    private _continuousGoal?;
    get continuousGoal(): ContinuousGoal;
    private _event?;
    get event(): Event_;
    private _experimental?;
    get experimental(): Experimental;
    private _tool?;
    get tool(): Tool;
    private _worktree?;
    get worktree(): Worktree;
    private _expertSquad?;
    get expertSquad(): ExpertSquad;
    private _export?;
    get export(): Export;
    private _file?;
    get file(): File_;
    private _find?;
    get find(): Find;
    private _formatter?;
    get formatter(): Formatter;
    private _gateway?;
    get gateway(): Gateway;
    private _global?;
    get global(): Global;
    private _task?;
    get task(): Task;
    private _goal?;
    get goal(): Goal;
    private _instance?;
    get instance(): Instance;
    private _interaction?;
    get interaction(): Interaction;
    private _server?;
    get server(): Server;
    private _log?;
    get log(): Log;
    private _mailbox?;
    get mailbox(): Mailbox;
    private _mcp?;
    get mcp(): Mcp;
    private _mission?;
    get mission(): Mission;
    private _missionSkill?;
    get missionSkill(): MissionSkill;
    private _panel?;
    get panel(): Panel;
    private _path?;
    get path(): Path;
    private _permission?;
    get permission(): Permission;
    private _project?;
    get project(): Project2;
    private _provider?;
    get provider(): Provider;
    private _pty?;
    get pty(): Pty;
    private _question?;
    get question(): Question;
    private _session?;
    get session(): Session4;
    private _interactiveArtifact?;
    get interactiveArtifact(): InteractiveArtifact;
    private _part?;
    get part(): Part;
    private _skill?;
    get skill(): Skill2;
    private _browserPreview?;
    get browserPreview(): BrowserPreview;
    private _terminal?;
    get terminal(): Terminal;
    private _vcs?;
    get vcs(): Vcs;
    private _workLedger?;
    get workLedger(): WorkLedger;
    private _work?;
    get work(): Work3;
}
export {};
