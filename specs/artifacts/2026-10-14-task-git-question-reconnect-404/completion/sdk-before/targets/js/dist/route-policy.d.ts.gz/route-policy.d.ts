/**
 * Routes listed here are served before the project-directory middleware
 * or are intentionally global. They must not receive `?directory=`.
 */
export declare const PROJECT_DIRECTORY_BYPASS_PATHS: readonly ["/doc", "/shutdown", "/restart", "/log", "/favicon.ico", "/global/tasks", "/mission", "/mailbox", "/work-ledger", "/work-ledger/archive", "/work-ledger/events", "/task/events"];
/**
 * Whole routers that are global end to end. A prefix may only appear here when
 * every route under it is global: the Work Ledger and attachment routers mix a
 * global reader with project-owned writers, so their global members are listed
 * above and in `GLOBAL_MIXED_ROUTER_ROUTES` one route at a time.
 */
export declare const PROJECT_DIRECTORY_BYPASS_PREFIXES: readonly ["/global/", "/auth/", "/ui/", "/log/", "/mailbox/", "/lifecycle/"];
export declare const REQUEST_METHODS: readonly ["GET", "POST", "PUT", "PATCH", "DELETE"];
export type RequestMethod = (typeof REQUEST_METHODS)[number];
export declare function normalizedServerRoutePath(routePath: string): string;
export declare function routeRequiresProjectDirectory(routePath: string, method?: string): boolean;
