export declare const SERVER_STARTUP_DIAGNOSTIC_LIMIT_BYTES: number;
/** One byte-bounded diagnostic tail shared by stdout and stderr. Human output
 * is evidence for startup failures only; framed receipts own readiness. */
export declare class BoundedDiagnosticTail {
    #private;
    readonly limit: number;
    constructor(limit?: number);
    append(chunk: Buffer | Uint8Array | string): void;
    clear(): void;
    snapshot(): {
        text: string;
        truncated: boolean;
        retainedBytes: number;
    };
}
