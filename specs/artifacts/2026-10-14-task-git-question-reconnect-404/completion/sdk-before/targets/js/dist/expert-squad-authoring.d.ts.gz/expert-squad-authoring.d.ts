import z from "zod";
import { type ExpertSquadManifestV2 } from "./expert-squad-manifest-v2.js";
export declare const EXPERT_SQUAD_MANIFEST_PATH = "expert-squad.jsonc";
export declare const EXPERT_SQUAD_ASSETS_DIRECTORY = "assets";
/**
 * Core-owned, Task-scoped Artifact discovery, exact read, and semantic source
 * selection are projected into every Expert Squad scheduler and worker.
 * Model-facing publication is worker-only. Projected workers publish
 * current-Task files through `artifact_snapshot`, then pass its exact refs to
 * `artifact_publish`. `payload_json` carries the structured evidence as
 * strict JSON text with unique object keys; `resources` is required and is
 * `[]` when there are no files. The Host parses the text once and writes a namespaced
 * `expert_output`. Both snapshot and Engine Artifact exact retries are
 * atomically deduplicated inside the Task and exact Delivery Slice revision
 * subjects; changed bytes, payload, resource, or exact source remain distinct.
 *
 * TypeScript package tools use the separate trusted Host ABI:
 * `context.host.engineArtifacts.publish({ artifact_type, schema_version,
 * label, payload, resources, source_artifact_locators })`. An ordinary
 * package-tool `return string` publishes nothing. A package Engine Artifact
 * publisher declares stable type/schema/label values, canonical JSON payload,
 * explicit resource and source arrays, then returns only the compact `locator`
 * and `sha256` receipt. A package Task Artifact publisher returns its typed
 * immutable snapshot locator instead of inventing an Engine Artifact envelope.
 * The package ToolHost always publishes Engine and Task Artifacts
 * idempotently, so package code cannot weaken stable retry identity.
 * Package ToolHost consumers use `engineArtifacts.search`, `read`, and
 * `select`; `engineArtifacts.publish` reaches the same canonical publisher.
 * A domain Artifact consumed by a deterministic package-tool algorithm is a
 * package ABI: one package-owned codec and typed publisher validate it, and
 * the manifest's optional `artifact_publishers` maps each exact formal type
 * to its projected package Tool CapabilityRef. A null entry reserves a
 * Host-owned type. The canonical Host publisher checks the immutable bound
 * manifest against the real calling Tool; generic or other package Tools
 * receive an explicit authority error. Types absent from that manifest keep
 * the generic contract. Old revisions are not backfilled from newer installs.
 * Every downstream typed publisher completely reads and selects the exact
 * predecessor locator. Those consumed payloads carry canonical structured values,
 * never mutable project paths that a later consumer rereads. Independent
 * resources and source locators are validated before publication side effects.
 * The package ToolHost atomically
 * reuses an existing publication only when owner, type, schema, label, payload,
 * resource content identities, and exact source identities are all equal.
 * A deterministic package-tool consumer requires this typed ABI. Generative
 * Agent-to-Agent evidence may use model-facing `artifact_publish` when the next
 * Agent performs semantic judgment rather than a package algorithm; it still
 * receives Host-atomic Task execution identity, exact Delivery Slice revision
 * subjects, and exact provenance. This is
 * an authoring contract verified by each package's real tool-chain tests; the
 * generic SDK validator does not guess domain semantics from prompts or type names.
 * Package-defined `context.metadata(...)` values are exposed only under the
 * result's `package_metadata` namespace; top-level provenance, truncation, and
 * lifecycle-control metadata remains Host-owned.
 * Every declared publication source must have been completely read
 * and explicitly selected earlier in the same invocation or physical Turn.
 * The Host derives Task,
 * Session, Agent, active Squad, projection, complete-read observation, and
 * publication-specific semantic-source provenance and enforces
 * `<active-squad-id>/...`. Consumers call `artifact_select` only after a
 * complete exact read; unselected reads remain observations and zero
 * selections are valid. Package manifests do not declare or shadow these
 * tools. Ordinary dispatch outcomes and Agent messages never transport domain
 * Artifact inventories, locators, or bodies. Mission selects exact predecessor
 * locators from the source Task catalog; the receiving Task discovers
 * target-owned imported Engine Artifacts whose immutable `import_lineage`
 * preserves the source Artifact's original consumption provenance.
 */
export declare const EXPERT_SQUAD_PLATFORM_ARTIFACT_DISCOVERY_TOOL_IDS: readonly ["artifact_search", "artifact_read", "artifact_select"];
export declare const EXPERT_SQUAD_PLATFORM_ARTIFACT_PUBLISH_TOOL_IDS: readonly ["artifact_snapshot", "artifact_publish"];
export declare const EXPERT_SQUAD_PLATFORM_ARTIFACT_TOOL_IDS: readonly ["artifact_search", "artifact_read", "artifact_select", "artifact_snapshot", "artifact_publish"];
export * from "./expert-squad-manifest-v2.js";
export type ExpertSquadPackageFile = string | Uint8Array;
/**
 * Package prompts extend the platform Agent-fact and physical-Turn protocol
 * selected by each base role. This authoring definition does not own a
 * terminal report/finalizer schema, Host observations, execution liveness, or
 * Task acceptance state.
 */
export interface ExpertSquadPackageDefinition {
    manifest: ExpertSquadManifestV2;
    files: Readonly<Record<string, ExpertSquadPackageFile>>;
}
export declare const ExpertSquadTextPackageDefinitionSchema: z.ZodObject<{
    manifest: z.ZodType<ExpertSquadManifestV2, unknown, z.z.core.$ZodTypeInternals<ExpertSquadManifestV2, unknown>>;
    files: z.ZodRecord<z.ZodString, z.ZodString>;
}, z.z.core.$strict>;
export type ExpertSquadTextPackageDefinition = z.output<typeof ExpertSquadTextPackageDefinitionSchema>;
export interface WriteExpertSquadPackageInput {
    directory: string;
    definition: ExpertSquadPackageDefinition;
}
export interface WriteExpertSquadPackageResult {
    directory: string;
    files: string[];
}
/**
 * ID means Identifier. Evidence keys name visible semantic evidence classes
 * and dependency topology, not concrete inventories, locators, payload
 * transport, hidden workflow state, or tool IDs. Each receiving stage is one
 * fixed-profile Mission Task. Mission imports exact predecessor locators while
 * creating that Task; Agents then discover and read the target-owned imported
 * Engine Artifacts through the platform Artifact tools above.
 */
export interface ExpertSquadCollaborationStage {
    id: string;
    squad_id: string;
    workflow_id?: string;
    depends_on: readonly string[];
    consumes: readonly string[];
    produces: readonly string[];
}
export interface ExpertSquadCollaborationDefinition {
    schema_version: 1;
    stage_execution: "mission_task";
    id: string;
    label: string;
    inputs: readonly string[];
    outputs: readonly string[];
    stages: readonly ExpertSquadCollaborationStage[];
}
export interface ValidateExpertSquadCollaborationInput {
    definition: ExpertSquadCollaborationDefinition;
    manifests: readonly ExpertSquadManifestV2[];
}
export interface ExpertSquadSourceImportedClosure {
    id: string;
    source: string;
    target: string;
    file_count: number;
    source_sha256: string;
    target_sha256: string;
    normalization?: string;
}
export interface ExpertSquadSourceAgentOwner {
    squad_id: string;
    agent_id: string;
}
export interface ExpertSquadSourceNativeReplacement {
    id: string;
    source: string;
    owners: readonly ExpertSquadSourceAgentOwner[];
    surfaces: readonly string[];
}
export interface ExpertSquadSourceRoleCapability {
    id: string;
    source: string;
    owner: ExpertSquadSourceAgentOwner;
    target_skill: string;
}
export type ExpertSquadSourcePipelineOwner = {
    kind: "squad";
    squad_id: string;
} | {
    kind: "collaboration";
    collaboration_id: string;
} | {
    kind: "platform";
    surface_id: string;
};
export interface ExpertSquadSourcePipelineAsset {
    id: string;
    source: string;
    file_count: number;
    sha256: string;
    owners: readonly ExpertSquadSourcePipelineOwner[];
    excluded_globs?: readonly string[];
    disposition?: string;
}
export interface ExpertSquadSourcePipelineGroup {
    id: string;
    source_steps: readonly string[];
    stage_bindings: ReadonlyArray<{
        collaboration_id: string;
        stage_id: string;
    }>;
    platform_surfaces: readonly string[];
    unavailable_ids: readonly string[];
}
export interface ExpertSquadSourceCapabilityContract {
    schema_version: 1;
    source_root_hint: string;
    source_pipeline: {
        path: string;
        version: string;
    };
    excluded_sources: readonly string[];
    platform_surface_definitions: ReadonlyArray<{
        id: string;
        description: string;
    }>;
    imported_closures: readonly ExpertSquadSourceImportedClosure[];
    native_replacements: readonly ExpertSquadSourceNativeReplacement[];
    role_capabilities: readonly ExpertSquadSourceRoleCapability[];
    pipeline_assets: readonly ExpertSquadSourcePipelineAsset[];
    collaborations: ReadonlyArray<{
        id: string;
        definition: string;
    }>;
    pipeline_groups: readonly ExpertSquadSourcePipelineGroup[];
    unavailable: ReadonlyArray<{
        id: string;
        reason: string;
    }>;
}
export interface ValidateExpertSquadSourceCapabilitiesInput {
    definition: ExpertSquadSourceCapabilityContract;
    collaborations: readonly ExpertSquadCollaborationDefinition[];
    manifests: readonly ExpertSquadManifestV2[];
}
export interface ExpertSquadValidationDiagnostic {
    readonly path: string;
    readonly message: string;
}
export declare class ExpertSquadValidationError extends AggregateError {
    readonly diagnostics: readonly ExpertSquadValidationDiagnostic[];
    constructor(diagnostics: readonly ExpertSquadValidationDiagnostic[]);
}
export declare function validateExpertSquadManifestDispatchTopology(input: unknown): ExpertSquadManifestV2;
/** A deterministic read-only view of one dependency depth in a virtual workflow. */
export interface ExpertSquadWorkflowTopologyWave {
    readonly depth: number;
    readonly node_ids: readonly string[];
}
/**
 * Author-facing graph facts derived from manifest v2. These facts are not
 * scheduler state and do not impose a minimum width or a preferred topology.
 */
export interface ExpertSquadWorkflowTopologyAnalysis {
    readonly workflow_id: string;
    readonly node_count: number;
    readonly initial_frontier_node_ids: readonly string[];
    readonly waves: readonly ExpertSquadWorkflowTopologyWave[];
    readonly join_node_ids: readonly string[];
    readonly critical_path_node_count: number | null;
    readonly maximum_parallel_width: number | null;
    readonly structure: "flat_planner_parallel_workers" | "parallel_workers_join" | "dependency_dag" | "adaptive_graph";
    readonly strategy: "adaptive" | "dag" | "loop" | "choice";
    readonly planner_node_id: string | null;
    readonly parallel_worker_node_ids: readonly string[];
}
/**
 * Validate a manifest and describe all dependency-ready depth frontiers.
 * Runtime remains the sole owner of dispatch readiness; this report only helps
 * package authors see joins and accidental serialization before installation.
 */
export declare function analyzeExpertSquadWorkflowTopology(input: unknown): readonly ExpertSquadWorkflowTopologyAnalysis[];
export declare function validateExpertSquadSourceCapabilities(input: ValidateExpertSquadSourceCapabilitiesInput): ExpertSquadSourceCapabilityContract;
/**
 * Validates cross-package identity and evidence contracts. Each collaboration
 * stage names a fixed Squad and its real inputs/outputs; workflow_id is optional
 * reference provenance. Scheduling strategies and independent dispatch counts
 * remain the runtime Orchestrator's judgment. This function does not create
 * Tasks, select a Squad, dispatch an Agent, or execute a workflow.
 */
export declare function validateExpertSquadCollaboration(input: ValidateExpertSquadCollaborationInput): ExpertSquadCollaborationDefinition;
export declare function expertSquadAssetPath(relativePath: string): string;
export declare function validateExpertSquadPackageDefinition(input: unknown): ExpertSquadPackageDefinition;
export declare function renderExpertSquadPackageFiles(definition: ExpertSquadPackageDefinition): Record<string, ExpertSquadPackageFile>;
export declare function writeExpertSquadPackage(input: WriteExpertSquadPackageInput): Promise<WriteExpertSquadPackageResult>;
