export declare const PLATFORM_ARTIFACT_DISCOVERY_TOOL_IDS: readonly ["artifact_search", "artifact_read", "artifact_select"];
export declare const PLATFORM_ARTIFACT_PUBLISH_TOOL_IDS: readonly ["artifact_snapshot", "artifact_publish"];
export declare const PLATFORM_ARTIFACT_TOOL_IDS: readonly ["artifact_search", "artifact_read", "artifact_select", "artifact_snapshot", "artifact_publish"];
