import { z } from "zod";
export declare const PROJECT_RELATIVE_PATH_CONTRACT = "must be an exact canonical cross-platform forward-slash project-relative path";
export declare function isCanonicalProjectRelativePath(value: unknown): value is string;
export declare const ProjectRelativePathSchema: z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>;
