export * from "./gen/types.gen.js";
import { type Config } from "./gen/client/types.gen.js";
import { OpenCorvusClient } from "./gen/sdk.gen.js";
export { OpenCorvusClient };
export type OpenCorvusClientConfig = Config & {
    /** Project path on the server, transmitted exactly regardless of the client's operating system. */
    directory?: string;
    username?: string;
    password?: string;
};
export declare function createOpenCorvusClient(input?: OpenCorvusClientConfig): OpenCorvusClient;
