import z from "zod";
import { ProductPillarSchema, type ProductPillar } from "@opencorvus-ai/util/product-pillar";
export declare const EXPERT_SQUAD_ID_PATTERN: RegExp;
export declare const EXPERT_SQUAD_SCHEMA_VERSION = 2;
export declare const EXPERT_SQUAD_VERSION_PATTERN: RegExp;
export { ProductPillarSchema };
export type { ProductPillar };
export declare const ProductPillarsSchema: z.ZodArray<z.ZodEnum<{
    work: "work";
    code: "code";
}>>;
export declare const ExpertSquadSystemRoleSchema: z.ZodEnum<{
    expert_squad_generator: "expert_squad_generator";
}>;
export type ExpertSquadSystemRole = z.output<typeof ExpertSquadSystemRoleSchema>;
export declare const ExpertSquadIDSchema: z.ZodString;
export declare const ExpertSquadNamespaceSchema: z.ZodString;
export declare const ExpertSquadVersionSchema: z.ZodString;
export declare const ExpertSquadDynamicAgentIDSchema: z.ZodString;
export declare const ExpertSquadConfigurationFieldSchema: z.ZodObject<{
    key: z.ZodString;
    label: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    type: z.ZodEnum<{
        boolean: "boolean";
        text: "text";
        secret: "secret";
    }>;
    required: z.ZodBoolean;
    placeholder: z.ZodOptional<z.ZodString>;
}, z.z.core.$strict>;
export declare const ExpertSquadConfigurationSchema: z.ZodObject<{
    fields: z.ZodArray<z.ZodObject<{
        key: z.ZodString;
        label: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        type: z.ZodEnum<{
            boolean: "boolean";
            text: "text";
            secret: "secret";
        }>;
        required: z.ZodBoolean;
        placeholder: z.ZodOptional<z.ZodString>;
    }, z.z.core.$strict>>;
}, z.z.core.$strict>;
export declare const ExpertSquadCapabilitySetSchema: z.ZodObject<{
    description: z.ZodString;
    member_refs: z.ZodArray<z.ZodString>;
}, z.z.core.$strict>;
export declare const ExpertSquadCapabilitySetsSchema: z.ZodRecord<z.ZodString, z.ZodObject<{
    description: z.ZodString;
    member_refs: z.ZodArray<z.ZodString>;
}, z.z.core.$strict>>;
export declare const ExpertSquadArtifactPublishersSchema: z.ZodRecord<z.ZodString, z.ZodNullable<z.ZodString>>;
export declare const ExpertSquadProjectionCapabilitiesSchema: z.ZodObject<{
    capability_refs: z.ZodArray<z.ZodString>;
}, z.z.core.$strip>;
export declare const ExpertSquadSchedulerProjectionSchema: z.ZodObject<{
    capability_refs: z.ZodArray<z.ZodString>;
    base_role: z.ZodLiteral<"orchestrator">;
    prompt: z.ZodOptional<z.ZodString>;
}, z.z.core.$strict>;
export declare const ExpertSquadAgentProjectionSchema: z.ZodObject<{
    capability_refs: z.ZodArray<z.ZodString>;
    label: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    base_role: z.ZodString;
    execution_contract: z.ZodOptional<z.ZodLiteral<"platform_integrity_review">>;
    prompt: z.ZodOptional<z.ZodString>;
}, z.z.core.$strict>;
export declare const ExpertSquadVirtualWorkflowNodeSchema: z.ZodObject<{
    agent_id: z.ZodString;
    description: z.ZodString;
    depends_on: z.ZodArray<z.ZodString>;
    when: z.ZodOptional<z.ZodString>;
    repeat_until: z.ZodOptional<z.ZodString>;
}, z.z.core.$strict>;
export declare const ExpertSquadVirtualWorkflowSchema: z.ZodType<ExpertSquadVirtualWorkflow>;
export declare const ExpertSquadVirtualWorkflowsSchema: z.ZodType<ExpertSquadVirtualWorkflows>;
export declare const ExpertSquadCapabilityProjectionSchema: z.ZodType<ExpertSquadCapabilityProjection>;
export declare const ExpertSquadManifestV2Schema: z.ZodType<ExpertSquadManifestV2>;
export type ExpertSquadConfiguration = z.output<typeof ExpertSquadConfigurationSchema>;
export type ExpertSquadConfigurationField = z.output<typeof ExpertSquadConfigurationFieldSchema>;
export type ExpertSquadCapabilitySet = z.output<typeof ExpertSquadCapabilitySetSchema>;
export type ExpertSquadCapabilitySets = z.output<typeof ExpertSquadCapabilitySetsSchema>;
export type ExpertSquadSchedulerProjection = z.output<typeof ExpertSquadSchedulerProjectionSchema>;
export type ExpertSquadAgentProjection = z.output<typeof ExpertSquadAgentProjectionSchema>;
export type ExpertSquadVirtualWorkflowNode = z.output<typeof ExpertSquadVirtualWorkflowNodeSchema>;
export interface ExpertSquadVirtualWorkflow {
    label: string;
    description: string;
    strategy?: "adaptive" | "dag" | "loop" | "choice";
    guidance?: string;
    nodes: Record<string, ExpertSquadVirtualWorkflowNode>;
}
export type ExpertSquadVirtualWorkflows = Record<string, ExpertSquadVirtualWorkflow>;
export interface ExpertSquadCapabilityProjection {
    scheduler: ExpertSquadSchedulerProjection;
    agents: Record<string, ExpertSquadAgentProjection>;
    virtual_workflows?: ExpertSquadVirtualWorkflows;
}
export interface ExpertSquadManifestV2 {
    schema_version: typeof EXPERT_SQUAD_SCHEMA_VERSION;
    namespace: string;
    id: string;
    name?: string;
    label: string;
    description?: string;
    version: string;
    product_pillars: ProductPillar[];
    system_role?: ExpertSquadSystemRole;
    readme: "README.md";
    selector: {
        summary: string;
        selection_guidance: string;
        instructions: "selector.md";
    };
    configuration?: ExpertSquadConfiguration;
    /** Exact formal type to package Tool capability; null reserves a Host-owned type. */
    artifact_publishers?: Record<string, string | null>;
    capability_sets: ExpertSquadCapabilitySets;
    capability_projection: ExpertSquadCapabilityProjection;
}
