# Task Question 恢复权威补审（只读，2026-10-14）

## 结论与已执行边界

当前不能把 `projectQuestion` 的所有 pending 分支无条件变成 `Question.restore`。原 Task 的 source-backed Board 行可以在另一个 backend 物化，但该 backend 不自动拥有原 Tool Promise。red03 已证实正常 bootstrap 后存在真实 Board pending / 本地 Question[] / reply404；原 terminal 控制的 occurrence/time/answers/userInput/outcome 均保持。Session 本次修复只令 live pending 与同 Server 的 canonical/reply 集合一致，不隐藏 Task Board、不补 Task continuation。

普通 Task Question 的原 Message.activationID 可以追到精确 Task-root lease 和 runtime occurrence；但是这条链并不覆盖所有 worker、Side、Main、Mission 或无 tool 的合法 Request。不能用 native binding、当前 Session 最新 owner、lease 到期、Map 缺失或 Project 初始化替代原物理权威。建议后续明确扩展**原 Task 恢复 owner**的受权 source enumeration/reconciliation，而不是把恢复塞入任意 live projector；真实普通 Tool 的死进程 continuation 与 A2A 精确可重执行 continuation 必须分开。

本报告没有新增/运行 Task 探针、测试、Provider、服务或生产修复。red03 的 Task 来源是现成 established-Task/backend binding fixture，不是完整 Task admission→Provider→Task-root activation，所以它证明 materialization/reply 缺口，不能替代下述 activation 物理链的真实运行证明。

## 原事实与执行顺序

1. `project/bootstrap.ts:102–139`：注册 Task/Session/Mission bridge → EngineService/Interaction subscriptions → `Bus.resumeDurablePublications()` → cleanup/cancellation stages → `EngineInteraction.reconcileRecoveredPendingWaiters` → Task control bootstrap。resume 返回 void，不 join 全部 publication。
2. `engine/interaction.ts:117–210`：recovery 按 request ID 分页64，只扫已有 `EngineInteractionRequestTable`，投影 pending 并校验 Task.project；Question 分支先 `projectQuestion`，原 terminal 即结束，否则 `Question.restore`。全仓唯一生产 restore caller 在199，唯一该 reconcile caller 在 bootstrap127。该签名只有 Project/time，没有原 physical owner proof。
3. `engine/interaction.ts:401–502`：原 `projectQuestion` 在单事务读取 original Asked/terminal、验证 Task+Project，补原 request source pointer、唯一 outcome 和真实 userInput；它负责 durable projection，不获得任何 Tool continuation。正常/迟到/重试都走同一函数。
4. `bus/index.ts:995–1020`：resume 按原 directory 枚举 outbox occurrence，跳过已完成 phases，并使用原 retry/owner机制；不是专用 Task Question source enumeration。`question/index.ts:120–213` 的 typed publicationFacts 是**精确单请求 reader**，没有 accepted Task Asked 分页枚举。
5. red03 的 source-only Ask 在 producer checkpoint 已接受、Interaction null/phases[]；重启后 Board200/pending，但 canonical[]/reply404。日志证明正常恢复 pass 已运行，未记录逐 SQL 相位，不能臆造精确竞态交错。accepted-terminal控制在同真实重启中保持完整原事实。详见 `question-crash-results-and-minimal-contract.md` 和 red03 原文件。

## 原 Request → Message → 执行权威

| 事实/primitive | 实际能证明 | 不能替代什么 |
|---|---|---|
| Request.tool.messageID/callID；`session.sql.ts` ToolPartRequest / Message | 原工具调用、Message/Session、持久 input/start/outcome | Request.tool 可选；无通用原 process occurrence |
| Message.activationID；`task-root-fact-store.ts:524–623` | 精确 activation lease→accepted ingress→Task/epoch/policy；current lease、consumed assistant/effects fencing | 不是所有 Session Message 都有；lease 到期不等同 OS 死亡 |
| `assertTaskRootAssistantActivationFenceInTransaction` 624+ | 原 Message/session 为该 Task 的 orchestrator、原 parent input 和 accepted activity settlement | 非 Task-root worker 不可假设同 activation |
| `task-root-ingress-delivery.ts:196,1101–1110` | lease.owner_occurrence_id 来自 currentRuntimeOccurrenceID；同事务要求现有 liveness owner | 不证明另一个仍活 backend 已将 Question waiter移交 |
| `engine/process-liveness.ts:88–170` | runtime_process receipt 保存 PID/processInstanceID/occurrence，OS observer真实判断 dead_or_reused；缺/opaque事实明确报错 | heartbeat停止或超过期限不能充当死亡；Project dispose仅release本地引用 |
| `SessionPromptOwner` 当前generation/observe/releaseDead | exact observed authority在原事务CAS释放；red01原owner仍一致且实际dead_or_reused | current owner可被后续输入替换；不能倒推任意历史Question绑定原owner |
| `task-execution-capsule-binding.ts:50–90,124–132` | frozen Task/project/package/native workspace/tree或capsule runtime文件/能力权威 | native v2 binding没有 PID/processInstance/Prompt occurrence，不是活跃执行者身份 |

`task-root-fact-store.ts:408–483` acquire先读取原 ingress/reducer、head-of-line/source事实，再以activationID获得原control lease；`assertControlOwnerInTransaction`由Task driver liveness提供。正当恢复应复用这些约束，不能调用某个read-only API即获得另一backend的pending所有权。

`task-root-ingress-delivery.ts:995–1059` 已有 expired-activation 对**原activationID关联的确切 assistants**做 `SessionLoop.terminalizeRecoveredIncompleteAssistant`；完成时间沿真实 lease expiry。这个入口没有调用 Question.restore/abandonRecovered，也不重建普通Question Tool Promise。

`task-root-ingress-delivery.ts:1640–1715` 的 dispatch恢复比 Project-only 更强：immutable lineage携带 delivery_owner.runtime_process occurrence；先查本进程真实 detached pipeline/SessionPrompt generation，再查原dispatch admission lease、OS liveness；缺失/未知physical事实不声明dead。原 `recordAbandonedDispatchSettlement`先结算精确childSession，写真实 infrastructure outcome后再delivery。它不是通用Question owner API，禁止通过最新Task/最新Message猜它的 lineage。

## 所有生产 Question producer / reply / recovery

全仓检索 `Question.(ask|askAndFormat|restore|abandonRecovered|reply|reject)`：

| 入口 | 原调用及作用域 | 崩溃接续合同 |
|---|---|---|
| Main/Global Chat、Work、Side、非Task子树常规 Tool | `tool/question.ts:12`，真实ctx.sessionID/messageID/callID | 普通物理Promise；没有持久重执行指定requestID |
| Side 发起Work/Mission前确认 | `tool/panel.ts:1718,1859`，仍在caller Session，实际Question决定后才创建工作 | caller的普通Tool；目标Task/Mission尚不存在，不能借目标恢复权限 |
| Task-root `question` | `orchestrator/interaction-tools.ts:166`，requireTaskOrchestratorToolExecutionContext，精确orchestratorMessage/call | 原 activation 可关联，但普通ask未声明跨进程工具重执行身份 |
| Task analyze_intent clarification | `orchestrator/analyze-intent-tool.ts:106`，同原orchestrator tool identity | 有上层分析/写入后续效果，不可只重放Question而伪称已接续整工具 |
| A2A ask_user | `orchestrator/tools.ts:1902`，deterministic Question/Asked、原action/epoch acceptanceEffects、原expiry/time/tool | 明确durable continuation，现成exact reexecution路径 |
| 公开回复 | `server/routes/question.ts:62,100`；`task-api/index.ts:2798,2818,2871,2891` | 同canonical物理集合，真实reply/reject进入唯一terminal writer；Task direct activity gate走自己的独立既有控制分支 |
| startup pending restore | `engine/interaction.ts:199`→`Question.restore` | 唯一caller，当前仅Project分区，尚无原physical owner fence |
| recovered Abandoned | `Question.abandonRecovered`定义仅有，无生产调用 | 不能拿无人调用helper自动终结所有缺失Map项 |

`Question.restore` 415–439 复用原 Request/terminal/time，非terminal安装 durableContinuation=true、waiters=[]、原timer；它**不是恢复旧Promise**。`SessionLoop.recoverInterruptedAgentCoordinationPart` 2605–2662 只重执行真实running `respond_agent_coordination` 的持久input、同Tool ID/Message和exact accepted action；不按普通question名称猜恢复。`SessionLoop.terminalizeRecoveredIncompleteAssistant` 2674+ 则对实际失去owner的其他Tool记录真实interruption。

## Host / 重启 / 并发与项目边界

- `cli/cmd/serve.ts:197,385,451` 初始启动与正常restart恢复、`cli/cmd/acp.ts:20` 共用 `recoverStartedTaskExecutions`。`engine/host-recovery.ts:264–333` 从started Task execution directories、pending scheduler Projects、Mission candidates收集原Project，scopeProjectWorktree明确过滤，再 `runWithInitializedIndependentProject`。这保证Project lifetime，不是对所有旧Question授权接管。
- 普通请求的 runtime bootstrap也走同InstanceBootstrap；identity-only Session snapshot/stream不会凭读取抢owner。Task admission `task-api/index.ts:1647`和原事件/control scan通过现有Task driver，不存在单独Question恢复捷径。
- `task-root-ingress-delivery.ts:1968–2069` 每Project driver持有同backend process liveness reference、bounded discovery/scan/自身Project serving lease；crossProject共享真实process身份，但不共用Task authority。Project ID、Task lineage、原Ask source必须逐项核对。
- 串行再次打开已settled原terminal只能投原terminal；accepted pending重试不能重新mint创建/expiry。并行同Project两个backend中，B缺Map不证明A死；B不能持原durable Board/Project init声称回复A。当前唯一global扫描+restore本身也须受相同审查，而非原路径天然安全。
- Mission恢复 `mission/process-recovery.ts:280–366` 使用lifecycle lease、exact incomplete frontier、原SessionPromptOwner的dead CAS及真实wake；它结算原Message/Tool，再恢复原wake。不能把这个控制的时间/身份移用于不属于它的Question。
- User stop、normal Question reply/reject/expiry、Instance disposer已走本批唯一原terminal事实；后台shutdown等待物理Promise的合同不随本建议改变。正常terminal与crash恢复不能互相补造。

## 最小下一阶段建议与尚需批准的范围

1. **先完善受权恢复的输入事实，不修改任意live projector为自动restore。**在当前Task恢复入口内增加按Project+真实Task ancestry分页枚举accepted Asked的能力，再复用唯一 `projectQuestion`（原事务）处理原terminal或request。这只解决遗漏source的枚举，不能单独授予physical continuation。
2. 对有原tool/activation或dispatch lineage的请求，以原Message/Tool精确定位既有owner receipt，使用已有OS observation/CAS/Task activation fences；仍活/未知的peer保留真实durable pending及明确恢复未接管，不能安装平行waiter或造deny/Abandoned。无tool的合法原Request不能降级到latest owner，必须具有明确既有durable continuation owner后才可恢复。
3. A2A沿当前exact persisted-input recovery接续；普通Task Question若原Tool已真实interruption，产品必须明确新受权Task是否只记录原用户决定并由新真实Turn读取，或需要新的完整普通Tool续作合同。现有 `restore(empty waiters)`只能保证可提交durable decision，不保证原Tool/LLM接续。当前代码和red03不足以授权后一种通用恢复。
4. 若选择原Task continuation恢复点而非Project bootstrap，需同步删除/收敛旧Project-only无fence恢复，不能保留双owner；该变化至少触及 `engine/interaction.ts`、原Question exact reader/enumeration 与现有Task/Session恢复caller，已超本轮Session窄scope，先Root新spec与许可，不能现在落代码。

下一真实checker应分别证明：原ordinary Task-root真实Provider→Question/Message.activation→crash，原worker dispatch Question→crash，A2A精确Tool重执行；accepted source迟物化、已terminal、同Project两个livebackends、两Project并行、原owner死/仍活/unknown、retry与正常restart/stop。来源缺失应有准确integrity/owner合同，而非Mapabsence核心断言。所有original Asked/terminal/time/answers和Tool history保留；Task reply200只是一个子合同，不能冒充完整Task自然completion。

## 本轮最终 Session 调整说明

原 `Question.list` 底层已有 `pendingSnapshotReader`。最终mirror仅Asked先await这个reader准备，随后同步读取 `publicationFacts`，非terminal同步读canonical集合；没有await后继续用旧facts。terminal事件不访问State，因为 `project/state.ts:120–127` 明确拒绝正在dispose的entry访问；disposer已持久的真实terminal仍可原样投影。完整Project/Session/id/time/questions/tool/automatic/expiry保持原Request。

red04 0/1/14完整集合红态（含真正current reply200/Tool/final控制）保留；red05/06/07各1/0/14、原physical/output/request结算。final scope名曾误用green-07，runner原命名准入拒绝在任何scope/child创建前退出1，保存在session-local-projection/final-scope-name-precondition.txt；未修改runnerallowlist，fresh原允许red-07执行绿态。各历史source与错误不覆盖。新正式test/worker迁移等待Root精确范围落盘批准。
