# 404 B Question backend handoff

Status: six production files and three backend test files frozen. Root owns SDK generation, shared documentation, desktop review, real GPT-6.1 Sol acceptance, archive and Git. No credentials, model catalog, user process, UI automation or extra delegation was used here.

## Exact input and patch

- `files.json`: nine exact owned files; `final-sources/` contains their final bytes, including the new untracked test.
- `tracked-changes.patch`: only the nine allowlisted paths, against the actual HEAD recorded in `head-final.txt`. No peer Bus/processor/file/UI/SDK change is included.
- `preimage/`: original six source files, original two touched existing tests, original red contract and peer Bus observation. `format-only-*` records the temporary formatter output before unchanged Question terminal helpers/Permission functions were restored to their original formatting.
- `owners-summary.json`: original parent/runner occurrence, command, deadline, receipt and physical/output/request closure for all eleven local formal scopes. Every recorded owner ended before its fixed original 600000ms deadline. All exec handles were joined.

## Final distinct checks

| Test file | Evidence scope | Tests | Assertions |
|---|---|---:|---:|
| question-publication-projection | expanded06 | 12 | 65 |
| engine-interaction-recovery | related01 | 7 | 74 |
| server/session-event-connection-snapshot | expanded03 | 11 | 37 |
| server/session-permission-projection | related01 | 8 | 39 |
| question-process-recovery | related01 | 1 | 11 |
| **Distinct total** | | **39** | **226** |

Each listed file's actual isolated child exited 0. `related01` overall exited 1 because its snapshot child exposed the old checker cursor race; its three other successful files are individually recorded in stdout/stderr. The corrected complete snapshot file subsequently exited 0 in `expanded03`. Repeated runs do not increase coverage. `types02` is final declared `bun run --cwd packages/opencorvus typecheck`, actual Node `--max-old-space-size=8192 .../tsc --noEmit`, exit 0. Final `git diff --check` for these nine paths also exited 0.

All formal invocations use Bun 1.4 on PATH and `question-formal-runner.ts` to launch the package's ordinary isolated test runner through the existing owned-tree process primitive. The wrapper only selects the explicit files/typecheck and records the original 600000ms deadline; it does not replace the test host, Provider or production behavior. Combined `command.log` is stdout followed by stderr, not a reconstructed chronological stream.

## Real contracts covered

The new file verifies accepted Request visibility before observer delivery; terminal-first/late Asked Task and Session projection; rejected, expired, infrastructure-abandoned and automatic-answer provenance, immutable source occurrence and one Task outcome; original retry and canonical recovery; owner admission rollback with the other actual waiter retained; a user reply committed before a postcommit interruption and subsequent disposal; ordinary dispose's real durable Abandoned delivery; historical accepted terminal identity and an explicit conflicting-identity error. Terminal-first Task reply also captures exactly the original authored user memory. The real separate-process recovery test retains its original crash-23, durable reply, single outcome/memory and restart verification.

The TCP test opens the actual `Server.listen` listener and normal routes for two distinct registered Projects. It verifies cold and connected full Request arrays/order keys, non-Task orchestrator children, new live children, Task's sole Board projection, real SSE disconnects, offline reply/reject/expiry/abandon, child admission at connection cutover and reconnection. It closes each reader then aborts its request and finally calls the ordinary server stop outside any `Instance.provide` callback. Task's backend owner is established using the existing durable Task/native binding fixture. No fake user or assistant messages are inserted by the new file.

This TCP Question case calls the production Question backend method to accept requests; it is not a natural Provider/tool-call or Task scheduler end-to-end acceptance. The separate Permission suite includes the actual public TCP Session Prompt → controlled streaming Provider → read → public approval → completed Tool path. Neither replaces Root's real desktop draft/reconnect or exact Sol acceptance. SideChat/Main visuals, Mission/worker model paths, all operating systems and real Task model orchestration are not established by these tests.

## Original failures retained

- Pre-implementation root red01/red02 remain in the parent scratch. On the current peer Bus source, formal `red03` is **1 pass / 2 fail / 6 assertions**: the accepted observer happened to pass under the newer delivery timing; both actual terminal-before-Asked failures remained. Do not rewrite this as three current failures.
- `green01`: the original three contracts passed, 3/6. `types01`: initial types 0. These are preliminary, not the final coverage claim.
- `expanded01`: 9 pass / 2 fail / 33 assertions. `expanded02`: 8 pass / 3 fail / 32 assertions, original source and input preserved. Actual expiry/automatic Error was `Database.immediateTransaction rejected because its inherited database effect owner is closed`: the new commit effect's timer inherited the completed effect lease. The final new-admission call uses the existing `Database.runOutsideContext` only to arm the same timer, retaining Instance and deadline. No DB/Bus primitive was modified.
- `expanded02` also proved the initial dispose conversion only appended an exact durable occurrence and delivered no Abandoned callback. Current `Bus.publishOwnedExact` returns a dormant accepted publication; final dispose explicitly awaits its original `.retry()` just like the other terminal producers. `expanded03` passed all eleven cases, 46 assertions, including the original timer errors and actual dispose notification.
- `related01` snapshot failure was two simultaneous `next()` calls on one helper reader/cursor. One read can queue the other's frame while the other has already awaited another chunk. The test now consumes each cursor sequentially, retaining concurrency across the two Project streams. Original input/log retained; complete original snapshot suite then passed 11/37 in `expanded03`.
- `expanded04` TCP failure: the new helper created `architect` without the required projected WorkerTurnDescriptor. Production `persistedSessionAgentID` requires that identity for worker kinds. This was an invalid helper input, not authorization to widen worker identity. Original input is retained; the final fixture uses the existing legal non-Task `orchestrator` child. The first new TCP failure was a Question stream timeout, not a directly recorded thrown worker error, so its root diagnosis combines actual input with this exact source contract.
- `expanded05` reached live child delivery, then the helper aborted the fetch before awaiting reader cancellation; real TCP `reader.cancel()` returned the recorded AbortError. The final normal close sequence cancels the reader first and then aborts its original fetch. No product timeout or lifecycle behavior was changed. `expanded06` completed all 12 tests / 65 assertions, original runner exit 0.

All failed scopes preserved their original inputs/receipts where captured. `related01` and `expanded01`–`expanded05` failures are not counted as successful complete runs. All eleven original owners closed physically and settled output/request before their original deadlines. The current scope has no active owned process, server, Provider or browser.

## Source boundaries

Question's one publication-facts reader queries the original Project + Session + request and actual event schemas, at most two matching facts. It does not try a canonical occurrence first and then fall back to historical random IDs. A second terminal identity is an explicit conflict. New terminal producers keep the existing exact slot. The physical waiter set is not a copied terminal store. Task's shared projector commits request/outcome/authored memory in one transaction; direct control-plane gates and Permission authority remain their own current contracts. The old role-specific predicate was renamed in place with its body unchanged. The public connected schema now requires `pendingQuestions`; the fabricated pending-Asked replay path was removed.

One pre-existing private `finalizePending` function in question/index.ts still has no callers, both in the saved preimage and current source. It was not introduced by this change and is not required by the new contract; no extra cleanup was folded into this authorized behavior change.
