import { afterEach, expect, test } from "bun:test"
import { Bus } from "../src/bus"
import { Question } from "../src/question"
import { Session } from "../src/session"
import { Instance } from "../src/project/instance"
import { ProtocolStore } from "../src/protocol/store"
import { ensureSessionProtocolBridge } from "../src/protocol/session-mirror"
import { memoryProject, resetMemoryDatabase } from "./fixture/memory"
import { EngineInteraction } from "../src/engine/interaction"
import { findInteractionByExternal } from "../src/engine/store"
import { prepareTaskProcessBinding } from "../src/engine/task-execution-capsule-binding"
import { persistEstablishedTask } from "./fixture/engine-task"
import { Identifier } from "../src/id/id"

afterEach(async () => {
  await Instance.disposeAll()
  await resetMemoryDatabase()
})

test("an accepted Asked observer reads the complete canonical pending Request at publication time", async () => {
  await using project = await memoryProject()
  await Instance.provide({
    directory: project.path,
    fn: async () => {
      const session = await Session.create({ kind: "assistant", title: "Public canonical Question admission" })
      const readPending = await Question.pendingSnapshotReader()
      let observed: { request: Question.Request; pending: Question.Request[] } | undefined
      let resolveObserved!: () => void
      const received = new Promise<void>((resolve) => {
        resolveObserved = resolve
      })
      const stop = Bus.subscribe(Question.Event.Asked, ({ properties }) => {
        if (properties.sessionID !== session.id) return
        observed = { request: properties, pending: readPending() }
        resolveObserved()
      })
      const answer = Question.ask({
        sessionID: session.id,
        expireOnDeadline: false,
        questions: [{ header: "Admission", question: "Public canonical entry", options: [], custom: true }],
      })
      try {
        await received
        await Question.reply({ requestID: observed!.request.id, answers: [["Public admission completed"]] })
        expect(await answer).toEqual([["Public admission completed"]])
        console.log("PUBLIC_ADMISSION_OBSERVATION", JSON.stringify(observed))
        expect(observed!.pending).toEqual([observed!.request])
      } finally {
        stop()
      }
    },
  })
}, 30_000)

test("Task Question projection retains its committed answer when Asked delivery resumes after terminal", async () => {
  await using project = await memoryProject()
  await Instance.provide({
    directory: project.path,
    fn: async () => {
      const packageRevision = {
        scope: "built_in" as const,
        projectID: null,
        namespace: "builtin",
        id: "interaction-recovery-test",
        version: "2026.08.09.1",
        packageDigest: "a".repeat(64),
      }
      const root = Session.prepareRootNext({
        kind: "root",
        directory: Instance.directory,
        title: "Public Task Question ordering",
        metadata: { configOverlay: { prompt_profile: { active: packageRevision.id } } },
      })
      const taskID = Identifier.ascending("task"),
        now = Date.now()
      persistEstablishedTask({
        taskID,
        rootSession: root,
        now,
        title: root.title,
        request: "Exercise public Task Question ordering",
        productPillar: "work",
        source: "test",
        priority: "normal",
        metadata: {},
        projectID: Instance.project.id,
        packageRevision,
        executionCapsuleBinding: await prepareTaskProcessBinding({
          mode: "native",
          taskID,
          projectID: Instance.project.id,
          rootDirectory: Instance.directory,
          packageRevisionSHA256: packageRevision.packageDigest,
          timeCreated: now,
        }),
      })
      let releaseAsked!: () => void, resolveHeld!: () => void
      const held = new Promise<void>((resolve) => {
        releaseAsked = resolve
      })
      const entered = new Promise<void>((resolve) => {
        resolveHeld = resolve
      })
      let request!: Question.Request,
        occurrence = ""
      const stopGate = Bus.subscribe(
        Question.Event.Asked,
        async (event) => {
          if (event.properties.sessionID !== root.id) return
          request = event.properties
          occurrence = event.occurrenceID
          resolveHeld()
          await held
        },
        { durableID: "question-contract.task-question-delivery-window", effect: "idempotent_by_occurrence" },
      )
      EngineInteraction.subscribe()
      const answer = Question.ask({
        sessionID: root.id,
        expireOnDeadline: false,
        questions: [{ header: "Task ordering", question: "Keep the real Task answer", options: [], custom: true }],
      })
      try {
        await entered
        await Question.reply({ requestID: request.id, answers: [["Public Task committed answer"]] })
        expect(await answer).toEqual([["Public Task committed answer"]])
        releaseAsked()
        await Bus.publishOwnedExact(Question.Event.Asked, request, occurrence).retry()
        const projected = findInteractionByExternal(request.id)
        const pendingBeforeRecovery = await Question.list()
        const recovery = await EngineInteraction.reconcileRecoveredPendingWaiters({
          projectID: Instance.project.id,
          timeResolved: Date.now(),
        })
        const pendingAfterRecovery = await Question.list()
        console.log(
          "PUBLIC_TASK_ORDERING_OBSERVATION",
          JSON.stringify({ taskID, request, projected, pendingBeforeRecovery, recovery, pendingAfterRecovery }),
        )
        expect(projected).toMatchObject({
          task_id: taskID,
          external_id: request.id,
          status: "answered",
          response: { answers: [["Public Task committed answer"]] },
        })
      } finally {
        releaseAsked()
        stopGate()
      }
    },
  })
}, 30_000)

test("a real terminal remains the current Session projection after an earlier Asked delivery resumes", async () => {
  await using project = await memoryProject()
  await Instance.provide({
    directory: project.path,
    fn: async () => {
      const session = await Session.create({ kind: "assistant", title: "Public Question delivery ordering" })
      const readPending = await Question.pendingSnapshotReader()
      let releaseAsked!: () => void
      const held = new Promise<void>((resolve) => {
        releaseAsked = resolve
      })
      let resolveHeld!: () => void
      const entered = new Promise<void>((resolve) => {
        resolveHeld = resolve
      })
      let request: Question.Request | undefined
      let askedOccurrence = ""
      const stopGate = Bus.subscribeAll(
        async (event) => {
          if (event.type !== Question.Event.Asked.type || event.properties.sessionID !== session.id) return
          request = event.properties
          askedOccurrence = event.occurrenceID
          resolveHeld()
          await held
        },
        { durableID: "question-contract.public-question-delivery-window", effect: "idempotent_by_occurrence" },
      )
      ensureSessionProtocolBridge()
      const projections: Array<{ type: string; payload: unknown; pendingAtDelivery: Question.Request[] }> = []
      const stopProjection = ProtocolStore.subscribeEvents(
        (event) => {
          if (event.sessionID !== session.id) return
          projections.push({ type: event.type, payload: event.payload, pendingAtDelivery: readPending() })
        },
        { aggregate: "session", types: ["question.asked", "question.replied"] },
      )
      const answer = Question.ask({
        sessionID: session.id,
        expireOnDeadline: false,
        questions: [{ header: "Ordering", question: "Public ordering choice", options: [], custom: true }],
      })
      try {
        await entered
        await Question.reply({ requestID: request!.id, answers: [["Public terminal wins"]] })
        expect(await answer).toEqual([["Public terminal wins"]])
        await stopProjection.drain()
        releaseAsked()
        // Wait on the original durable Asked publication, not a synthetic event.
        await Bus.publishOwnedExact(Question.Event.Asked, request!, askedOccurrence).retry()
        await stopProjection.drain()
        console.log(
          "PUBLIC_ORDERING_OBSERVATION",
          JSON.stringify({ request, projections, canonicalPending: readPending() }),
        )
        expect(projections.at(-1)).toMatchObject({
          type: "question.replied",
          payload: { requestID: request!.id, answers: [["Public terminal wins"]] },
          pendingAtDelivery: [],
        })
      } finally {
        releaseAsked()
        stopGate()
        stopProjection()
      }
    },
  })
}, 30_000)
