# 404 Question Session 最终交接

截至此次交接，功能agent停止修改本轮Question生产及测试。Root移除question/index.ts无人调用private finalizePending十行已包含在实际源码和最终检查中。本文不替代Root规格/归档/提交。

## 精确文件和差异

`files.json`列11个可审查任务文件：原六后台生产、原三个后台测试、这次批准新增的 `test/question-process-projection.test.ts` 与 `test/fixture/question-process-projection-worker.ts`。`final-sources/**`是交接时的原文；`tracked-changes.patch`仅这11文件中已tracked内容的实际Git差异，新文件完整内容在final-sources，不能误以为patch包含新文件。`head.txt`和`status.txt`记录并行工作树，不将其它路径归本任务。原`question-implementation/final-sources`保持历史冻结，不覆盖。

最新Session-only生产变化在 `protocol/session-mirror.ts`：保持原Project/Task准入与publicationFacts terminal优先；Asked先准备现有pendingSnapshotReader，再同步读facts和canonical完整Request，以同Server reply owner决定pending。terminal不访问正在dispose的state。不加新API/cache/outbox/终态，不伪造旧Tool接续。

新增正式test完全自持隔离目录，命令：`bun run --cwd packages/opencorvus test test/question-process-projection.test.ts`（Bun1.4 PATH、标准isolated runner）。复用原controlled-streaming-provider及NodeProcess owned_tree；普通Session公开HTTP→实际QuestionTool→原Accepted Asked/wildcard未投递hook→producer真实crash23→新child正常bootstrap/SSE→原完整Asked/Tool/精确404→真实current child Question公开reply200、Toolcompleted、自然assistant stop→完整live/canonical Request DTO集合相等。没有Task测试分支/模型stub替换生产代码/手工mirror/伪消息/UI自动化；无外部scratch env前置。

## 最终验证

| 实际范围 | 证据目录 | 结果 |
|---|---|---|
| 原五个聚焦文件 | `../local-projection-regression` | 39 tests / 226 assertions / exit0 |
| 最终reader调整后两个直接投影文件 | `../local-projection-final` | 23 tests / 102 assertions / exit0；属于上行重复覆盖 |
| 新正式双进程测试 | `../process-projection-formal01` | 1 test / 14 assertions / exit0 |
| 核心包声明typecheck | `../types05` | exit0 |
| 同机制scratch最终复验 | `../../question-crash-red-07` | 1 / 0 / 14；属于新正式test相同逻辑覆盖 |

**去重总量40 tests / 240 assertions**，见verification-summary.json。没有把red05/06/07或重复投影检查叠加。原red04为0pass/1fail/14assert：真实current reply/Tool/final及原Ask/Tool合同通过，完整live/canonical集合红。原red01/02/03和原source/helper/logs保持；Task red03仍未满足。

原6个新增formal scope owner均physical/output/request结算，原600000ms未延长：

- `local-projection-regression` PID85144 / e7526f02-a637-4f21-9955-2e10af7aab29 / deadline1791932649749 / exit0。
- `types03` PID90668 / fd4cea6a-5821-4a35-b4ac-03ac64eace6f / deadline1791932649780 / exit0。
- `local-projection-final` PID75384 / bbc0f978-d633-4b7d-9fdf-9643b061d8df / deadline1791932893057 / exit0。
- `types04` PID3264 / a970b8f7-7961-498e-9ef8-1f3902c81e2e / deadline1791932893076 / exit0。
- `process-projection-formal01` PID46396 / 05274d22-6002-4628-bb84-52e0a97cb953 / deadline1791933265089 / exit0。
- `types05` PID82716 / 155ee629-79ae-4dc5-874f-5c080f8d3a62 / deadline1791933275105 / exit0。

`process-observations.json`摘取原正式stdout中的两个结构化观察（完整原Request/Tool/当前reply/final与child owner/原stderr/closed回执）；`owners.json`与`crash-scopes-04-07.json`包含精确原deadline/结束/physical/output/request/provider关闭/运行时删除事实。生产check原输出仍在各scope，摘取不替代原日志。

新增test子进程各≤180000ms、HTTP≤30000ms、总父600000ms、留60000ms收尾。crash23是场景内明确物理退出，不能标为正常业务完成；restart child自然0且普通Server.stop/DB.close后退出，两个Provider listener正常closed。父仅物理join后删除自身runtime，没有操作用户进程或凭据。

## 未满足与只读报告

Task来源迟物化恢复仍为red03真实失败：Board pending、Question[]、reply404。完整原authority/所有producer/Host/Task-root activation/dispatch/OS owner/多Project及多backend横审见 `../../task-question-recovery-authority-review.md`。目前没有可把所有Task pending无条件restore的权威依据；Project-only恢复不是物理owner，A2A exact reexecution不能冒称普通Task Tool接续。下一阶段须Root先落规格，不能将本次Session一致性称为全部Question恢复根治。

真实桌面/草稿/真实GPT-6.1 Sol由Root另有证据；本测试只用公开本地受控streaming Provider。未新增真实模型/凭据或UI自动化。本交接没有任何runtime数据库、auth/models或用户设置复制；final-sources仅11精确公开源码路径。

工具前置失败保留：final scope误命名green-07被原runner创建scope前拒绝，记录在session-local-projection/final-scope-name-precondition.txt；迁移脚本第一次CRLF anchor不匹配在新tracked文件写入前失败，原脚本保留在session-local-projection/migration-preimage.cjs。两者修正本地调用/工具后原验收已真实重跑，不当产品失败或成功。
