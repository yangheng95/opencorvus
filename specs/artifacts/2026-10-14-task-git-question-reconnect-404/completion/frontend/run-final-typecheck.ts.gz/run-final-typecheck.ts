import fs from "node:fs/promises"
import path from "node:path"
import { bootstrapIsolatedTestRuntime, applyIsolatedTestUserEnvironment, removeIsolatedTestRuntime } from "../../packages/util/src/test-runtime-environment"
import { NodeProcess } from "../../packages/util/src/process-node"
import { prepareTestProcessSupervisor } from "../../packages/opencorvus/script/prepare-test-process-supervisor"

const root = path.resolve(import.meta.dir, "../..")
const original = JSON.parse(await fs.readFile(path.join(import.meta.dir, "final-validation/scope-start.json"), "utf8"))
const deadlineAt = original.deadlineAt
const startedAt = Date.now()
if (!Number.isSafeInteger(deadlineAt) || deadlineAt <= startedAt) throw new Error("Original validation deadline has elapsed")
const output = path.join(import.meta.dir, "final-validation/typecheck-retry")
await fs.mkdir(output, { recursive: false })
const isolated = await bootstrapIsolatedTestRuntime("runner")
applyIsolatedTestUserEnvironment(isolated)
const supervisor = prepareTestProcessSupervisor()
if (!supervisor) throw new Error("Declared native process supervisor required")
process.env.OPENCORVUS_PROCESS_SUPERVISOR = supervisor
const pathName = Object.keys(process.env).find(name => name.toLowerCase() === "path") ?? "PATH"
process.env[pathName] = path.dirname(process.execPath) + path.delimiter + (process.env[pathName] ?? "")
const environment = Object.fromEntries(Object.entries(process.env).filter(([name]) => /^(PATH|SystemRoot|WINDIR|ComSpec|PATHEXT|HOME|HOMEDRIVE|HOMEPATH|USERPROFILE|APPDATA|LOCALAPPDATA|TEMP|TMP|TMPDIR|XDG_CONFIG_HOME|XDG_DATA_HOME|XDG_CACHE_HOME|XDG_STATE_HOME|OPENCORVUS_(TEST_|HOME))/i.test(name)))
environment.OPENCORVUS_PROCESS_SUPERVISOR = supervisor
const cwd = path.join(root, "packages/overlay"), args = ["run", "typecheck"]
const facts: any = { originalScopeStartedAt: original.startedAt, originalParentPID: original.parentPID, parentPID: process.pid, startedAt, deadlineAt,
  executable: process.execPath, args, cwd, runtimeOwner: isolated, environmentNames: Object.keys(environment),
  reason: "Original ProvidersPanel diagnostics retained; actual import and three exports now visible. Same original deadline, no source edits or rebuild." }
await fs.writeFile(path.join(output, "owner-start.json"), JSON.stringify(facts, null, 2), { flag: "wx" })
let handle: Awaited<ReturnType<typeof NodeProcess.spawn>> | undefined
try {
  const result = await NodeProcess.run({ command: { executable: process.execPath, args }, cwd, env: environment, ownership: "owned_tree", windowsHide: true, stdin: "ignore", deadlineAt, nothrow: true,
    onSpawned(value) { handle = value; facts.pid = value.pid; facts.occurrenceID = value.occurrenceID; console.log(JSON.stringify({ phase: "started", pid: value.pid, deadlineAt })) } })
  await fs.writeFile(path.join(output, "stdout.log"), result.stdout)
  await fs.writeFile(path.join(output, "stderr.log"), result.stderr)
  facts.receipt = result.receipt
  await handle!.settled; await handle!.outputSettled
  facts.physicalJoined = true; facts.outputJoined = true; facts.requestSettled = true
  await fs.writeFile(path.join(output, "exit"), String(result.receipt.exitCode ?? 1))
  process.exitCode = result.receipt.reason === "exited" ? result.receipt.exitCode ?? 1 : 1
} catch (error) {
  facts.error = String(error); process.exitCode = 1
  if (handle) { facts.receipt = await handle.settled; await handle.outputSettled; facts.physicalJoined = true; facts.outputJoined = true }
} finally {
  await removeIsolatedTestRuntime(isolated)
  facts.runtimeRemoved = true; facts.runtimeRemovedAfterPhysicalJoin = facts.physicalJoined === true && facts.outputJoined === true
  facts.finishedAt = Date.now()
  await fs.writeFile(path.join(output, "owner.json"), JSON.stringify(facts, null, 2), { flag: "wx" })
  console.log(JSON.stringify({ phase: "final", output, receipt: facts.receipt, physicalJoined: facts.physicalJoined, outputJoined: facts.outputJoined, finishedAt: facts.finishedAt, deadlineAt }))
}
