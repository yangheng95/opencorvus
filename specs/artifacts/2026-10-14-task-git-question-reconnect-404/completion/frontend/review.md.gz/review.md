# 404 Overlay 当前实施复核

批准范围：5生产文件（conversation、tree-writer、side-chat、event-policy、新question-interaction）及2现有纯transport/state tests。初始这些tracked文件diff/index diff为空，原字节在before；其它Bus/Git/SDK/shared改动未改。

变化：Question normalizer只保留一份，完整 Request payload包含expiry；规范化字段顺序后结构比较保持原pending对象identity。同ID不同完整Request、或已terminal却收到pending，给明确合同错误，未用前端隐藏迟Asked代替后台事实根治。Main一次替换canonical pending Question+Permission，同时保留有真实terminal的历史；absent只移旧pending、不编造状态/时间。Side仅exact自身，先prepare完整新集合再单次回调，避免Question空数组卸载窗口。四terminal校验原origin/time/answers并明确answered/rejected/expired映射。Main当前Session authority接服务端合法tree，去掉临时root/knownMission二次gate。

删除/搬迁：旧questionTitle/questionBody/standaloneQuestionInteraction/prepareStandaloneQuestionInteractions搬至新utility；无人调用hydrateStandaloneQuestionInteractions wrapper及仅旧Question gate使用的isSelectedStandaloneSession删除。未取消Dialog keyed、未建立共享draft/localStorage。函数全仓调用搜索已完成。

类型：新utility仅type-import当前SDK QuestionRequest，不复制后端Request schema定义或导入Backend runtime。normalize处是前端wire输入字段校验与投影；重复Requested字段的键顺序由同一normalizer固定，JSON.stringify用于结构相等、不是hash/源码门。

语言：按Root独立review，空header不再硬编码产品英文Question。title取原header串或undefined；InteractionCard的整行title+icon随title省略，真实question fieldset/legend仍在，Dialog外标题仍使用当前语言t。没有在normalizer冻结翻译、没有修改用户原header/body或公共header必填schema；未新增文案/DOM测试。

当前检查：transport01原exec4578ea exit0，36tests/90assertions（Side11/27，subagent25/63），标准隔离runner已闭合。typecheck01原exec80651 / join5f2246 exit0，wrapper49704；这是Root新SDK生成前的当前SDK检查。title移除为后续一行UI修正，不把旧type日志写成该修正后的再次运行。最终SDK type/private Node build待Root独占生成窗口结束。

人工UI边界：本agent没有运行页面/截图/任何UI自动化。已有Main/Side before由Root操作；after和inline/双语/终态真实UI都由Root验收。静态读CardParts发现它使用Index而非part引用For，不能仅新parts wrapper判定inline必重挂载，也不能据此宣称inline保稿通过。

现有两test文件已检索，均纯transport/state数据合同；本轮新增正向身份、canonical集合、四terminal、明确错误合同，没有源码文案、DOM、render、snapshot或浏览器测试。SDK生成物/组件/共享dist-vite未写。

## SDK final02 后最终运行

Root SDK事务闭合后，`run-final-validation.ts` 以唯一原600000ms deadline=1791930858188运行3个独立NodeProcess owned_tree，原父PID87512。原exec89788最终join/exit1（c2fccd），完整scope在final-validation/scope-final.json，总95.7s。三个child physical/output/request都结算，原父随后删除自己的isolated runtime。

- transport：PID73816 / 9ffb5619-45cd-428e-8812-efa685ee78f8，exit0，最终仍36tests/90assertions；没有新增测试或扩大检查范围。
- package declaration typecheck：PID81428 / e2d05fd1-cf02-4da2-8382-0098c4e22516，exit2。6个原诊断全在并行开发中的ProvidersPanel.tsx：73/718 ProviderSaveIssue、735/852 ProviderSaveFollowup、764/892 settleProviderSaveFollowups未定义。未越权修复、未把结果写成通过。Root已阅读并确认保留；最终SDK字段和本批5文件没有type诊断，但这不能替代整个Overlay声明typecheck成功。
- Node私有build：PID90848 / 5f3c4ad3-ffba-4ef6-b34e-4e445524a472，exit0，1m33s；输出绝对D:/myhexin-local/opencorvus/.tmp-task-git-question-reconnect-404/ui-after。保留原Radix use-client、大chunk与静动态import warning；未改配置消警。index.html 11891bytes只记实际产物，不作UI验收。

Root SDK生成物、shared dist、其它生产文件未修改。Providers import尚缺时不无目标重复type；若其在原deadline内明确收敛，按Root授权追加同deadline复验并保留上述失败，否则交Root后续当前源复验。Root真实after页面仍未由本agent运行，build0不表示视觉通过。

### 同原期限声明复验完成

只读观察到ProvidersPanel:16实际import及provider-save.ts:3/11/17三个真实export后，按Root授权运行`run-final-typecheck.ts`；使用原deadline1791930858188，没有续期。原exec85227 join/exit0（17105a），PID66160、occurrence0afb5d60-9b08-433a-9dde-559d2b621f4b；physical/output/request均结算，父isolated runtime随后删除。finished1791930596864早于原期限；完整原日志与收据在`final-validation/typecheck-retry/`。首轮类型失败仍保留原exit2。

最终检查结果为当前包声明type0、同当前SDK下纯transport36/90全0、私有Node构建0。注意构建早于并行Providers补import；只读当前源类型复验不会改变已经生成的bundle，本agent未覆盖或重建它。本批五个生产文件在构建与复验之间完全没有后续编辑；Root可用该私有产物做Question指定范围真实UI，不能宣称已重建所有并行Providers变化或UI已通过。
