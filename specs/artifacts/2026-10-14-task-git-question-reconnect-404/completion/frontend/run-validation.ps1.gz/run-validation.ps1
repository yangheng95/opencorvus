param([Parameter(Mandatory=$true)][ValidateSet('transport01','typecheck01','build01')][string]$Check)
$uiRoot = 'D:/myhexin-local/opencorvus'
$uiScratch = Join-Path $uiRoot '.tmp-task-git-question-reconnect-404'
$uiScope = Join-Path $uiScratch 'frontend'
$uiWorkdir = Join-Path $uiRoot 'packages/overlay'
$uiLog = Join-Path $uiScope ($Check + '.log')
$uiExit = Join-Path $uiScope ($Check + '.exit')
$uiCommand = Join-Path $uiScope ($Check + '-command.json')
foreach ($uiOutput in @($uiLog,$uiExit,$uiCommand)) { if (Test-Path -LiteralPath $uiOutput) { throw "Original evidence exists: $uiOutput" } }
$env:PATH = (Join-Path $uiRoot '.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64;') + $env:PATH
Set-Location -LiteralPath $uiWorkdir
if ($Check -eq 'build01') {
  $uiExecutable = (Get-Command node).Source
  $uiArguments = @('--max-old-space-size=8192','./node_modules/vite/bin/vite.js','build','--config','vite.config.ts','--outDir',(Join-Path $uiScratch 'ui-after'))
} else {
  $uiExecutable = (Get-Command bun).Source
  if ($Check -eq 'transport01') { $uiArguments = @('run','test:unit','test/side-chat-transport.test.ts','test/subagent-conversation-service.test.ts') }
  else { $uiArguments = @('run','typecheck') }
}
$uiRecord = [ordered]@{check=$Check;executable=$uiExecutable;arguments=$uiArguments;cwd=$uiWorkdir;wrapperPID=$PID;startedAt=[DateTime]::UtcNow.ToString('o');status='running'}
[System.IO.File]::WriteAllText($uiCommand,($uiRecord|ConvertTo-Json -Depth 5))
& $uiExecutable @uiArguments *> $uiLog
$uiCode=$LASTEXITCODE
$uiRecord.status='exited';$uiRecord.exitCode=$uiCode;$uiRecord.finishedAt=[DateTime]::UtcNow.ToString('o')
[System.IO.File]::WriteAllText($uiCommand,($uiRecord|ConvertTo-Json -Depth 5))
[System.IO.File]::WriteAllText($uiExit,[string]$uiCode)
Get-Content -LiteralPath $uiLog -Tail 65
exit $uiCode
