import fs from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { execFileSync } from 'node:child_process'

const scope = path.dirname(fileURLToPath(import.meta.url))
const root = path.resolve(scope, '../..')
const manifest = JSON.parse(await fs.readFile(path.join(scope, 'source-allowlist.json'), 'utf8'))
const tracked = manifest.files.filter(file => file !== manifest.newFile)
let patch = execFileSync('git', ['diff', '--', ...tracked], { cwd: root, encoding: 'utf8', windowsHide: true })
const added = await fs.readFile(path.join(root, manifest.newFile), 'utf8')
const lines = added.replace(/\n$/, '').split('\n')
patch += `diff --git a/${manifest.newFile} b/${manifest.newFile}\nnew file mode 100644\n--- /dev/null\n+++ b/${manifest.newFile}\n@@ -0,0 +1,${lines.length} @@\n${lines.map(line => '+' + line).join('\n')}\n`
await fs.writeFile(path.join(scope, 'implementation.patch'), patch)
const statuses = execFileSync('git', ['status', '--short', '--', ...manifest.files], { cwd: root, encoding: 'utf8', windowsHide: true })
await fs.writeFile(path.join(scope, 'scope-changes.json'), JSON.stringify({ capturedAt: new Date().toISOString(), files: manifest.files, status: statuses,
  sourceDiff: 'implementation.patch', preimages: 'before/', verification: 'Scope preservation and review material; not a functional acceptance gate' }, null, 2))
console.log(JSON.stringify({ files: manifest.files.length, patch: path.join(scope, 'implementation.patch'), statuses }))
