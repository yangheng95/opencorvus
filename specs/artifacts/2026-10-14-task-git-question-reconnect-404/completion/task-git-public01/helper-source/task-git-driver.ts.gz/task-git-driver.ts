// 404 approved scratch only. Source: manual-permission-driver.ts and git-probe-worker.ts.
// Run only after Root approval: Bun 1.4 task-git-driver.ts <fresh absolute scope> <private absolute UI>.
import fs from 'node:fs/promises'
import path from 'node:path'
import assert from 'node:assert/strict'
import { bootstrapIsolatedTestRuntime, applyIsolatedTestUserEnvironment, removeIsolatedTestRuntime } from '../packages/util/src/test-runtime-environment'
import { NodeProcess } from '../packages/util/src/process-node'
import { prepareTestProcessSupervisor } from '../packages/opencorvus/script/prepare-test-process-supervisor'

const [scope, uiDirectory] = process.argv.slice(2)
const scratch = path.resolve(import.meta.dir)
assert(scope && uiDirectory && path.isAbsolute(scope) && path.isAbsolute(uiDirectory))
assert.equal(path.dirname(path.resolve(scope)), scratch)
const startedAt = Date.now(), deadlineAt = startedAt + 600000, closeBy = deadlineAt - 60000
await fs.mkdir(scope, { recursive: false })
const write = (name: string, value: unknown) => fs.writeFile(path.join(scope, name), JSON.stringify(value, null, 2) + '\n', { flag: 'wx' })
await fs.mkdir(path.join(scope, 'controls'))
await fs.mkdir(path.join(scope, 'helper-source'))
for (const name of ['task-git-driver.ts', 'task-git-server.ts', 'task-git-facts.ts', 'task-git-control.mjs']) {
  await fs.copyFile(path.join(scratch, name), path.join(scope, 'helper-source', name), 1)
}
await write('driver-context.json', { parentPID: process.pid, startedAt, deadlineAt, closeBy, scope, uiDirectory, purpose: '404 public Task baseline/read/cancel, not completed Task qualification' })
const isolated = await bootstrapIsolatedTestRuntime('runner')
applyIsolatedTestUserEnvironment(isolated)
await write('driver-runtime-owner.json', isolated)
let product: Awaited<ReturnType<typeof NodeProcess.spawn>> | undefined
let productDrains: Promise<void[]> | undefined
let productSettled = false
let controlLoop: Promise<void> | undefined
const checkerReceipts: unknown[] = []
let failure: unknown
const bun = path.resolve('.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64/bun.exe')
const drain = async (stream: any, name: string) => { if (stream) for await (const bytes of stream) await fs.appendFile(path.join(scope, name), bytes) }
try {
  const supervisor = prepareTestProcessSupervisor()
  const env = Object.fromEntries(Object.entries(process.env).filter(([name]) => /^(PATH|SystemRoot|WINDIR|ComSpec|PATHEXT|HOME|HOMEDRIVE|HOMEPATH|USERPROFILE|APPDATA|LOCALAPPDATA|TEMP|TMP|TMPDIR|XDG_CONFIG_HOME|XDG_DATA_HOME|XDG_CACHE_HOME|XDG_STATE_HOME|OPENCORVUS_(TEST_|HOME))/i.test(name)))
  if (supervisor) { env.OPENCORVUS_PROCESS_SUPERVISOR = supervisor; process.env.OPENCORVUS_PROCESS_SUPERVISOR = supervisor }
  assert(Date.now() < closeBy, 'Original preparation budget')
  const command = { executable: bun, args: [path.join(scratch, 'task-git-server.ts'), scope, uiDirectory, String(deadlineAt)] }
  product = await NodeProcess.spawn({ command, ownership: 'owned_tree', windowsHide: true, stdin: 'ignore', env, deadlineAt })
  await write('product-launch.json', { command, cwd: process.cwd(), pid: product.pid, occurrence: product.occurrenceID, startedAt, deadlineAt, closeBy, environmentNames: Object.keys(env).sort() })
  productDrains = Promise.all([drain(product.stdout, 'stdout.log'), drain(product.stderr, 'stderr.log')])
  void product.settled.then(() => { productSettled = true })
  controlLoop = (async () => {
    const processed = new Set<string>()
    while (!productSettled && Date.now() < deadlineAt) {
      for (const name of (await fs.readdir(path.join(scope, 'controls'))).filter(name => /^facts-[0-9a-f-]+\.json$/.test(name)).sort()) {
        if (processed.has(name)) continue
        processed.add(name)
        const request = JSON.parse(await fs.readFile(path.join(scope, 'controls', name), 'utf8'))
        const id = name.slice(6, -5)
        const record: any = { id, request, originalDeadline: deadlineAt, startedAt: Date.now() }
        let checker: Awaited<ReturnType<typeof NodeProcess.spawn>> | undefined
        let drains: Promise<void[]> | undefined
        try {
          assert.equal(request.id, id)
          assert.equal(request.deadlineAt, deadlineAt)
          assert.equal(request.productPID, product!.pid)
          assert.equal(request.productOccurrence, product!.occurrenceID)
          assert(['baseline', 'read', 'cancelled'].includes(request.mode))
          assert(Date.now() < closeBy && !productSettled, 'Original live observation window')
          const checkerCommand = { executable: bun, args: [path.join(scratch, 'task-git-facts.ts'), scope, request.mode, id] }
          checker = await NodeProcess.spawn({ command: checkerCommand, ownership: 'owned_tree', windowsHide: true, stdin: 'ignore', env, deadlineAt: closeBy })
          record.command = checkerCommand; record.pid = checker.pid; record.occurrence = checker.occurrenceID
          await write(`facts-${id}.launch.json`, record)
          drains = Promise.all([drain(checker.stdout, `facts-${id}.stdout.log`), drain(checker.stderr, `facts-${id}.stderr.log`)])
          record.receipt = await checker.settled
          await drains; await checker.outputSettled
          record.physicalJoined = true; record.outputJoined = true; record.requestSettled = true
          record.passed = record.receipt.reason === 'exited' && record.receipt.exitCode === 0
        } catch (error) {
          record.error = String(error); record.passed = false
          if (checker) { record.receipt = await checker.settled; await drains; await checker.outputSettled; record.physicalJoined = true; record.outputJoined = true }
        } finally {
          record.finishedAt = Date.now(); checkerReceipts.push(record)
          await write(`facts-${id}.physical-terminal.json`, record)
        }
      }
      if (!productSettled) await new Promise(resolve => setTimeout(resolve, 100))
    }
  })().catch(error => { failure ??= String(error); process.exitCode = 1; console.error('Original driver control loop:', String(error)) })
  const receipt = await product.settled
  await productDrains; await product.outputSettled; await controlLoop
  await write('product-physical-terminal.json', { receipt, physicalJoined: true, outputJoined: true, requestSettled: true })
  if (receipt.reason !== 'exited' || receipt.exitCode !== 0) process.exitCode = 1
} catch (error) {
  failure = String(error); process.exitCode = 1
  await write('driver-failure.json', { error: failure, observedAt: Date.now(), deadlineAt })
} finally {
  if (product) { await product.settled; await productDrains; await product.outputSettled }
  if (controlLoop) await controlLoop.catch(error => { failure ??= String(error); process.exitCode = 1 })
  await removeIsolatedTestRuntime(isolated)
  await write('driver-terminal.json', { startedAt, deadlineAt, closeBy, finishedAt: Date.now(), productPID: product?.pid, productOccurrence: product?.occurrenceID, physicalJoined: Boolean(product), outputJoined: Boolean(product), checkerReceipts, failure, isolatedRuntimeRemovedAfterJoin: true, exitCode: process.exitCode ?? 0 })
}
