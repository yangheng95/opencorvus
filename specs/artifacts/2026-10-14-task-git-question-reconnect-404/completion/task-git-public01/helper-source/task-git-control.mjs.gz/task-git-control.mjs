// Approved 404 local owner control, not a product API and not UI automation.
// Node task-git-control.mjs <scope> status|release|baseline|read|cancelled|cancel|stop
import fs from 'node:fs/promises'
import path from 'node:path'
import assert from 'node:assert/strict'
import { randomUUID } from 'node:crypto'
import { fileURLToPath } from 'node:url'

const [scope, mode] = process.argv.slice(2)
assert(scope && path.isAbsolute(scope)); assert.equal(path.dirname(path.resolve(scope)), path.dirname(fileURLToPath(import.meta.url)))
assert(['status', 'release', 'baseline', 'read', 'cancelled', 'cancel', 'stop'].includes(mode))
const json = async name => JSON.parse(await fs.readFile(path.join(scope, name), 'utf8'))
const ready = await json('ready.json'), driver = await json('driver-context.json'), launch = await json('product-launch.json')
assert.equal(ready.scenario, 'task-git-public'); assert.equal(ready.pid, launch.pid)
assert.equal(ready.deadlineAt, driver.deadlineAt); assert.equal(launch.deadlineAt, driver.deadlineAt)
assert(Date.now() < ready.closeBy, 'Original owned close reserve; no extension')
const id = randomUUID(), observedAt = Date.now()
const control = { id, mode, observedAt, productPID: launch.pid, productOccurrence: launch.occurrence, deadlineAt: ready.deadlineAt }
const write = (name, value) => fs.writeFile(path.join(scope, name), JSON.stringify(value, null, 2) + '\n', { flag: 'wx' })
const api = async (route, method = 'GET', body) => {
  assert(Date.now() < ready.closeBy)
  const response = await fetch(new URL(route, ready.url), { method, headers: { 'content-type': 'application/json', 'x-opencorvus-directory': ready.actualProjectDirectory, 'x-opencorvus-request-id': id }, ...(body === undefined ? {} : { body: JSON.stringify(body) }), signal: AbortSignal.timeout(Math.max(1, Math.min(30000, ready.closeBy - Date.now()))) })
  return { status: response.status, result: await response.json(), observedAt: Date.now() }
}
try {
  if (mode === 'status') {
    const task = await api(`/task/${ready.taskID}`)
    await write(`control-${id}.json`, { ...control, task })
    console.log(JSON.stringify({ id, taskID: ready.taskID, task, remainingMs: ready.closeBy - Date.now() }, null, 2))
  } else if (mode === 'release' || mode === 'stop') {
    await write(mode === 'release' ? 'release-first-task-prompt' : 'stop-requested', control)
    console.log(JSON.stringify({ ...control, boundary: mode === 'stop' ? 'Stop requested, not physical settlement or proof of page closure' : 'Only first Task prompt released; subsequent Task prompts remain held' }))
  } else if (mode === 'cancel') {
    const body = { surface: 'api', reason: 'Operator ended the public 404 baseline/read verification' }
    await write(`cancel-${id}.request.json`, { ...control, taskID: ready.taskID, body })
    const response = await api(`/task/${ready.taskID}/cancel`, 'POST', body)
    await write(`cancel-${id}.response.json`, response)
    assert.equal(response.status, 202)
    console.log(JSON.stringify({ id, response, boundary: '202 is acceptance; use actual UI and cancelled facts to establish terminal settlement' }, null, 2))
  } else {
    const temporary = path.join(scope, 'controls', `.${id}.tmp`)
    await fs.writeFile(temporary, JSON.stringify(control, null, 2) + '\n', { flag: 'wx' })
    await fs.rename(temporary, path.join(scope, 'controls', `facts-${id}.json`))
    const until = Math.min(Date.now() + 45000, ready.closeBy)
    while (Date.now() < until) {
      try {
        const result = await json(`facts-${id}.physical-terminal.json`)
        console.log(JSON.stringify(result, null, 2)); assert.equal(result.passed, true, 'Original driver-owned checker result'); break
      } catch (error) {
        if (error.code !== 'ENOENT') throw error
      }
      await new Promise(resolve => setTimeout(resolve, 100))
    }
    const receipt = await json(`facts-${id}.physical-terminal.json`)
    assert.equal(receipt.passed, true)
  }
} catch (error) {
  await write(`control-${id}.failure.json`, { ...control, error: String(error), finishedAt: Date.now(), boundary: 'Original checker/server continues under its own unchanged deadline; failure is preserved' })
  throw error
}
