import fs from 'node:fs/promises'
import path from 'node:path'
import {bootstrapIsolatedTestRuntime,applyIsolatedTestUserEnvironment,removeIsolatedTestRuntime} from '../packages/util/src/test-runtime-environment'
import {NodeProcess} from '../packages/util/src/process-node'
import {prepareTestProcessSupervisor} from '../packages/opencorvus/script/prepare-test-process-supervisor'
const [requestedOutput]=process.argv.slice(2)
if(!requestedOutput||!path.isAbsolute(requestedOutput))throw Error('Explicit absolute owned SDK output required')
const output=path.resolve(requestedOutput)
if(path.dirname(output)!==path.resolve('.tmp-task-git-question-reconnect-404'))throw Error('Explicit fresh owned SDK output required')
await fs.mkdir(output,{recursive:false})
const isolated=await bootstrapIsolatedTestRuntime('runner');applyIsolatedTestUserEnvironment(isolated)
const supervisor=prepareTestProcessSupervisor();if(!supervisor)throw Error('Declared native process supervisor required')
process.env.OPENCORVUS_PROCESS_SUPERVISOR=supervisor
const pathName=Object.keys(process.env).find(name=>name.toLowerCase()==='path')??'PATH'
process.env[pathName]=path.dirname(process.execPath)+path.delimiter+(process.env[pathName]??'')
const environment=Object.fromEntries(Object.entries(process.env).filter(([name])=>/^(PATH|SystemRoot|WINDIR|ComSpec|PATHEXT|HOME|HOMEDRIVE|HOMEPATH|USERPROFILE|APPDATA|LOCALAPPDATA|TEMP|TMP|TMPDIR|XDG_CONFIG_HOME|XDG_DATA_HOME|XDG_CACHE_HOME|XDG_STATE_HOME|OPENCORVUS_(TEST_|HOME))/i.test(name)))
environment.OPENCORVUS_PROCESS_SUPERVISOR=supervisor
const startedAt=Date.now(),deadlineAt=startedAt+600000
const args=['run','--cwd','packages/sdk/js','build']
const facts:any={startedAt,deadlineAt,parentPID:process.pid,executable:process.execPath,args,cwd:process.cwd(),environmentNames:Object.keys(environment),runtimeOwner:isolated,meaning:'Whole declared six-target local generation transaction; no external publication'}
await fs.writeFile(path.join(output,'owner-start.json'),JSON.stringify(facts,null,2),{flag:'wx'})
let handle:any
try{
 const result=await NodeProcess.run({command:{executable:process.execPath,args},cwd:process.cwd(),env:environment,ownership:'owned_tree',windowsHide:true,stdin:'ignore',deadlineAt,nothrow:true,onSpawned(h){handle=h;facts.pid=h.pid;facts.occurrenceID=h.occurrenceID}})
 await fs.writeFile(path.join(output,'stdout.log'),result.stdout);await fs.writeFile(path.join(output,'stderr.log'),result.stderr)
 facts.receipt=result.receipt;await handle.settled;await handle.outputSettled
 facts.physicalJoined=true;facts.outputJoined=true;facts.requestSettled=true
 process.exitCode=result.receipt.exitCode??1
}catch(error){facts.error=String(error);process.exitCode=1;if(handle){facts.receipt=await handle.settled;await handle.outputSettled;facts.physicalJoined=true;facts.outputJoined=true}}
finally{
 if(handle)await handle.settled
 await removeIsolatedTestRuntime(isolated)
 facts.finishedAt=Date.now();facts.runtimeRemoved=true;facts.runtimeRemovedAfterPhysicalJoin=facts.physicalJoined===true
 await fs.writeFile(path.join(output,'owner.json'),JSON.stringify(facts,null,2),{flag:'wx'})
 console.log(JSON.stringify(facts))
}
