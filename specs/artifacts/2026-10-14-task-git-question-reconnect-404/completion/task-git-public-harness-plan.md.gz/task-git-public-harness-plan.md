# 404 Public Task Git harness — implementation proposal only

## Recall / authority

Root requested the remaining 404 actual public Task API + desktop baseline qualification after the real Main Dialog, Main inline, independent Side Question and native Sol Question scopes had closed. This note only proposes changes to fresh scratch helpers. It does not run a server, controlled/real Provider, browser, checker, Git write, or production edit. Root owns approval, new fixed 600000 ms scope, actual page interaction/screenshots, and final Task cancellation/physical cleanup. Existing 402/404 helpers and failed receipts remain frozen. No delegation.

Read: current AGENTS; 404 Recall/A implementation decision and Task Git reports; current task-runtime-directory/task-control-plane; actual 404 manual-permission driver/server and relay lifecycle; 402 public-entry/task-child entry and Scope08 accepted Task; actual controlled streaming Provider; server public Task admission, task-api creation/root binding, Orchestrator baseline, EngineGit checkpoint facts, read/process-root boundary, Board and Task projections, Overlay task selection/deep link/cancellation. Searches included all EngineGit.project/checkpoint metadata consumers, public routes and Task creation/cancellation callers. Read-only git status captured before/after; unrelated changes preserved. No UI automated test was searched specifically or run.

## Recommendation / exact scope

Create only these new scratch helper files after Root approval, leaving previous helpers untouched:

1. `task-git-driver.ts`: copy mature owned-tree driver lifecycle, use the same outer + child isolated-runtime primitive and original 600000 ms budget; one product process, no relay because this scenario does not cut SSE.
2. `task-git-server.ts`: reuse current development-mode server startup, native shims, recovered runtime, private Overlay source, synthetic public Provider configuration and normal shutdown. Add one purpose-built public Task scenario described below; no product debug route.
3. `task-git-facts.ts`: bounded public HTTP observation + exact selected read-only SQLite checkpoint/binding observation and actual Git object byte read; no database writes or EngineGit.prepare/complete calls.
4. If useful, `task-git-control.mjs`: only original-scope local release/stop file controls and ordinary public Task cancel request; it is not a new product API. Root can instead reuse direct public HTTP and write the existing control file by hand.

Outputs go under a fresh immediate child such as `.tmp-task-git-question-reconnect-404/task-git-public01`; never overwrite original scopes. Commands run only after separate Root approval. No tracked change, SDK generation, broad vendor/runtime copy, or new production/test file is needed.

## Why the old public entry must change

402 `public-entry-402.mjs` reads `public-external.csv` under its evidence directory, but creates the Task with the Global Chat accepted Session directory header. The Task root is therefore inside the canonical isolated runtime, while the CSV is outside the immutable Task process root. `tool/external-directory.ts:79-94` resolves the exact Task binding and rejects that target even after an operator permission. That failure was separate from the earlier `$GIT_DIR too big` baseline failure and must remain recorded.

The source evidence is direct: `task-api/index.ts:1892-1904,2009-2049` binds the provided/selected execution directory; `task-directory.ts:29-72` uses its actual parentless root Session directory; `task-execution-capsule-binding.ts:49-70` stores the real native workspace root; `read.ts:67-84` resolves the Tool target and enters that boundary. Changing Permission policy or marking the Task completed cannot correct an outside-root target.

Do not replace the canonical long directory with `<scratch>/project`, inject padding, move/shorten it, make a junction, or override the Task `directory` to avoid the original Git input. Reuse the exact ordinary public Global Chat allocation path produced by the current mature double-isolation harness. The original Scope08 root was 219 ASCII bytes and its `.git` candidate 224 bytes. A new occurrence's actual lengths must be measured, not assumed or copied from Scope08. If the naturally allocated new path does not exercise that threshold, report that boundary; do not claim an equivalent long-input run.

## Server preparation and real admission sequence

1. Start the mature private development server from the current `ui-after`, installed native shims, recovered runtime and actual isolated project bootstrap. Retain one immutable original deadline + `closeBy = deadlineAt - 60000`. Parent writes actual PID/NodeProcess occurrence; child writes its distinct server occurrence. They must not be conflated.
2. Publicly configure two unique synthetic streaming Providers: seed `shutdown-fixture/session-prompt-owner-model` and Task `task-fixture/session-prompt-owner-model`. Both use the existing `startControlledStreamingProvider`; no credential or model-directory copy. Existing memory handling remains separate. Use the approved built-in profile `base` from `profile-selection.json`; Task body explicitly names it. This is controlled transport evidence, never GPT-6.1 Sol qualification.
3. The seed Provider has no first Tool. Use normal `POST /global/chat/start` to allocate the same product-owned implicit Project/Session path, with a simple public ready message. Release seed and memory requests normally and retain its natural completed reply before Task work. This seed does not spend the Task Provider's first prompt.
4. Prepare `taskFirstPromptToolCall = {name:'read', arguments:{filePath: ...}}` and pass that same object to the separate Task Provider. The installed fixture reads `options.firstPromptToolCall` at its actual first prompt (controlled-streaming-provider.ts:72), so its path can be filled exactly once after Global Chat 202 and before any Task request. No Task is admitted while the path is unresolved. Prefer assigning the actual absolute native CSV path Root requested; relative paths are also legal read inputs, but do not mix forms during this run.
5. Resolve the accepted Session directory, check it is inside this exact child isolated runtime's canonical `data/projects` subtree, and write a new public CSV **inside that directory before POST /task**. Suggested constant bytes: `item,quantity\nCedar404,3\nIris404,4\n`. Use `flag:'wx'`. Save the same original bytes outside the project as evidence, plus `public-fixture-facts.json` containing allocated Project/Session/root, CSV path/relative path/byte length, actual UTF-8/UTF-16 path lengths, and configured Task model. Logs/evidence must stay outside the Task root. Do not change project inputs between Task acceptance and its first execution digest; EngineGit.prepare enforces that immutable creation boundary.
6. Call the real `POST /task?init-git=true` with `x-opencorvus-directory` equal to that actual allocated Session directory and body:

```json
{
  "requestID": "<fresh UUID>",
  "title": "Public Task Git baseline 404",
  "request": "Read the public CSV at <actual inside-root native path> and report its rows.",
  "productPillar": "work",
  "promptProfile": "base",
  "model": "task-fixture/session-prompt-owner-model"
}
```

Do not send a Task directory override, parent/mission metadata, fabricated lifecycle, workplan, typed decision or process binding. `server/server.ts:900-912` validates the body and performs ordinary Git initialization; route `orchestrator.ts:186-249` returns real 202 `{task_id,project_id,directory}`. Save exact request/response/status. Confirm accepted directory and project match the allocation, then retrieve Task/root Session through public APIs.
7. Baseline runs naturally before the Orchestrator decision (`orchestrator/loop.ts:97-139`). Hold the unique Task first Provider reply until Root opens the Task page and initial facts are captured. Manual release permits the real streaming Tool call. Normal Ask policy may produce a real Task interaction; Root uses visible Allow Once if it does. Do not inject Authority answers or typed controls. Assert the actual Tool reaches completed and its output contains all exact original CSV rows; a Permission decision or final plain Provider text alone is insufficient.
8. To keep this deliberately narrow baseline/read scenario stable while Root captures evidence, the fixture may hold its **second non-memory Task prompt** after the read instead of immediately returning the generic `provider reply 2`. This is explicit controlled transport backpressure, not a product orchestration rule. Root then normally cancels the Task. Record the held/aborted request as such, not HTTP200/EOF. If Root chooses to release later generic text instead, actual control exhaustion must be preserved and does not prove natural Task completion. No expectation is based on a fake typed Task decision.

## Baseline/checkpoint evidence: API availability correction

The current public API does **not** guarantee a baseline projection in `metadata.git`:

- `GET /task/:id` → `EngineService.getTask` (task-api/index.ts:2117) → requireTask/listTaskRows/viewTask.
- `GET /task/:id/board` → compileBoard/buildBoard (workbench/board.ts:56-125) → findTask/viewTask.
- `GET /task/:id/progress` → the same Task projection and ordinary progress rows.
- `findTask` → `projectTaskRowInTransaction` (engine/store.ts:227-262) only projects lifecycle; `viewTask:1356-1412` returns the row metadata. None calls EngineGit.project.
- `EngineGit.prepare` returns a locally projected row but persists only immutable request/outcome, not another metadata copy. `EngineProgressSnapshotTable` explicitly excludes kind=git. The only discovered production caller of exported `EngineGit.project` is the plugin Task run evidence collector (`tool/task-run-evidence-host.ts:66-80`), not a generic HTTP endpoint.
- Overlay `utils/git.ts` has metadata.git extraction/formatting definitions, but whole-source search found no current consumer of boardGitCheckpoints/gitCheckpointText. Thus do not promise a visible checkpoint card or treat its absence as this Git execution failure.

Use public APIs for actual admission, root Session, Task status, interaction and Tool transcript. For baseline, use the **same sole durable facts** with a fresh read-only SQLite connection to this owned runtime's `data/opencorvus.db`, following the mature checker pattern (`new Database(path,{readonly:true})`, BEGIN/ROLLBACK/close). Do not import the default database opener, which can initialize/migrate rather than be a strictly selected read.

The minimal selected query is:

```sql
SELECT r.id, r.task_id, r.stage, r.operation_key,
       r.input, r.time_created AS requested_at,
       o.result, o.time_created AS settled_at
FROM engine_git_checkpoint_request r
JOIN engine_git_checkpoint_outcome o ON o.request_id = r.id
JOIN engine_task t ON t.id = r.task_id
WHERE r.task_id = ? AND t.project_id = ?
ORDER BY r.time_created, r.id;
```

Also select the exact owning `engine_task` id/project_id/session_id and its actual root `session` id/project_id/directory/kind/parent_id; select only that Task's `engine_artifact` row with kind `task_execution_capsule_binding` and parse its payload through the current published binding schema if needed. No raw DB copy, auth/models, unrelated artifacts, users, Provider request bodies or whole tables. Record selected public facts to JSON under the occurrence while original owner is alive.

For the fresh epoch, expect actual `stage:'baseline'`, `operation_key:'baseline:1'`; `input.root` equals actual root; outcome has `checkpoint_receipt.task_id`, `checkpoint_stage:'baseline'`, `outcome:'success'`, initialized root repository record, real commit/tree, and authority `workspace/git_dir/common_dir/index_path/object_format/git_marker_kind`. Retain all actual modes/rows and interpret exact result, rather than merely asserting a particular error string disappeared. If no outcome yet, keep waiting only inside the original bounded observation, never call EngineGit.prepare from the checker. Explicit baseline errors remain real failures.

To prove that checkpoint covers the actual input, use the already-owned Git process primitive to read **that actual outcome's commit**: `git show <commit>:public-task-input.csv`, caller cwd=actual root, and compare returned bytes to the original CSV. This object ID is a real Git immutable resource identity, not a mutable source digest gate. Use normal owned process/join and preserve actual command/exit/bytes. Do not create another commit or synthesize outcome. Existing formal EngineGit tests already exercise prepare/complete; this new public scenario adds actual API/UI admission evidence.

## Real desktop steps and public read checks

1. After ready, open the product `/ui?taskID=<actual accepted task_id>` in an isolated Root-owned tab. The exact canonical parameter is `taskID`; **do not add `directory`**: `services/task-deep-link.ts:24-42` explicitly rejects that combination. Normal global task loading resolves owning directory, and `restoreInitialTaskSelection`/`selectTask` performs the actual hydrate/SSE. Alternatively click the exact title in the Work ledger. Root should inspect actual UI before deciding any repair.
2. Record Task title/selected source, original Task request and current running state. Release the Task's first stream, expand its real read Tool, and if present answer the real permission through UI. Capture the actual public rows and any displayed error. Read public `/task/:id/transcript`, `/task/:id/conversation`, `/task/:id/board` using the actual directory header; assert the actual Tool part input/path and state=completed/output, not just a request or approval.
3. Capture baseline selected facts and actual Git-object bytes as above. API 202 + Provider text + screenshot cannot replace checkpoint success evidence.
4. Stop via the real composer Stop (main.tsx:2708-2723, surface overlay.composer_stop) or selected Work ledger Cancel (main.tsx:1231-1240, surface overlay.work_ledger). Both use the same task-cancellation primitive. Record which real UI control was used; do not assign an Overlay surface to a helper-driven request.
5. If Root needs non-UI public API cleanup, `POST /task/:id/cancel` body is `{surface:'api',reason:'Operator ended the public 404 baseline/read verification'}` with a fresh request ID header and actual directory. Route: orchestrator.ts:1542-1574. It returns 202 with status cancelling or cancelled. Observe actual `task.cancellation.status='cancelled'`, requestEventID, terminalEventID/terminalAt and raw Task lifecycle cancelled from GET Task/Board. A 202 acknowledgement alone is not physical or business settlement.
6. Cancellation deliberately skips `EngineGit.complete` (`engine/state.ts:122-133`). This scope is **baseline + real read + real cancelled Task**, not result checkpoint/complete Task qualification. Do not call EngineGit.complete or terminalTask yourself. Do not rewrite cancelling/active to completed, or claim a generic Provider final answer is an orchestrator Completion Decision.

## Original owner closure / output allowlist

New fixed 600000 ms budget starts at driver admission and covers preparation, seed, Task, screenshots, read-only checker and cleanup. Root closes its tab by original closeBy; cancellation must start early enough to obtain actual public terminal projection and join in-flight Prompt. No activity-based renewal, new timeout or replacement owner. Service shutdown is last, after cancellation evidence; if cancellation cannot settle, retain that failure and close original physical scope at its deadline, never label it cancelled-success.

Reuse the mature original NodeProcess owned_tree handle and stdout/stderr drains; record target/server occurrences separately, request/output/physical joins, actual exit and elapsed time, then parent removes its exact isolated runtime only after child physical/output closure. Store original .runtime-owner/.launch/.physical-terminal outside the runtime. One Task Provider + one seed Provider must both stop; fixture abort/completion request states must remain truthful. The driver must not claim child terminal JSON means physical join.

Evidence allowlist: helper source/commands, public synthetic config projection/model IDs, original CSV bytes + manifest, global allocation public response, Task request/202, selected public Task/Board/transcript/interaction/cancel responses, selected checkpoint/root binding JSON, owned Git object read bytes/command/exit, original JPEG screenshots and AX/read-only observations made by Root, owner/ready/terminal/stop and stdout/stderr, final limits. Never archive runtime/database/auth/models or all Provider payloads. No relay or browser automation is necessary for this scope.

## Remaining limits / risks

- This proposal has not been implemented or run. Root's supplied current Question/Sol success facts are separate from Task baseline qualification.
- Actual input-path lengths, Prompt profile availability, Ask interaction presence, Task read completion and normal cancellation remain to be observed. Preserve any real failure; do not promise them from static source.
- Current public Board omits fresh Git projection; that may be an independent presentation gap. It is not necessary to widen 404 production scope for this harness because a selected read-only canonical checkpoint fact is available. Do not silently patch Board/UI to make the acceptance pass.
- No result checkpoint/typed complete, Task workflow correctness, all Mission-created Tasks, recovery/retry/new epoch, multi-Project parallelism, managed worktree, Linux/macOS or Win32 ASCII310 cwd is qualified by this single public page. Those retain existing formal evidence or explicit independent limits.
- The original 402 outside-root read Tool error remains independent history. The original Scope08 Git numeric argv gap is not backfilled by new observations.

Prepared by audit_ui from actual source; no helper/product implementation, service, browser or model was started for this report. Frozen for Root review and approval.
