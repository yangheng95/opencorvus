import { expect, test } from "bun:test"
import fs from "node:fs/promises"
import path from "node:path"
import { NodeProcess } from "../packages/util/src/process-node"
import { createManagedTemporaryDirectory, removeManagedDirectoryTree } from "../packages/util/src/runtime-directories"
import { startControlledStreamingProvider } from "../packages/opencorvus/test/fixture/controlled-streaming-provider"

test("ordinary Question restart live projection agrees with the canonical public pending set", async () => {
  const evidence = process.env.OPENCORVUS_QCRASH_EVIDENCE
  const parentDeadlineAt = Number(process.env.OPENCORVUS_QCRASH_PARENT_DEADLINE)
  const processRoot = process.env.OPENCORVUS_TEST_PROCESS_ROOT
  if (!evidence || !path.isAbsolute(evidence) || !processRoot || !Number.isFinite(parentDeadlineAt)) throw Error("Owned formal evidence/deadline/test runtime required")
  const runtime = await createManagedTemporaryDirectory(processRoot, "question-crash-runtime-")
  const provider = startControlledStreamingProvider({ firstPromptToolCall: { name: "question", arguments: {
    questions: [{ header: "Public recovery", question: "Which public Cedar answer should be retained?", options: [{ value: "cedar", label: "Cedar", description: "Public Cedar example" }], custom: true }],
  } } })
  const release = setInterval(() => { for (const request of provider.requests) request.release() }, 5)
  const children: any[] = []
  let allJoined = true
  async function run(mode: "crash" | "recover") {
    if (Date.now() + 60000 >= parentDeadlineAt) throw Error("Original parent close reserve reached")
    const startedAt = Date.now(), deadlineAt = Math.min(startedAt + 180000, parentDeadlineAt - 60000)
    const cwd = path.resolve(import.meta.dir, "../packages/opencorvus")
    const args = [`--config=${path.join(cwd, "test/empty-bunfig.toml")}`, `--tsconfig-override=${path.join(cwd, "tsconfig.json")}`,
      path.join(import.meta.dir, "question-crash-worker.ts"), mode, runtime, evidence, provider.apiURL, String(deadlineAt)]
    const env = { ...process.env, OPENCORVUS_HOME: runtime }
    const facts: any = { mode, startedAt, deadlineAt, executable: process.execPath, args, cwd, environmentNames: Object.keys(env).sort() }
    children.push(facts)
    await fs.writeFile(path.join(evidence, `${mode}-spawn.json`), JSON.stringify(facts, null, 2))
    let handle: any
    allJoined = false
    try {
      const result = await NodeProcess.run({ command: { executable: process.execPath, args }, cwd, env, ownership: "owned_tree", windowsHide: true, stdin: "ignore", deadlineAt, nothrow: true,
        onSpawned(child) { handle = child; facts.pid = child.pid; facts.occurrenceID = child.occurrenceID } })
      await fs.writeFile(path.join(evidence, `${mode}-stdout.log`), result.stdout)
      await fs.writeFile(path.join(evidence, `${mode}-stderr.log`), result.stderr)
      facts.receipt = result.receipt
      await handle.settled; await handle.outputSettled
      facts.physicalJoined = true; facts.outputJoined = true; facts.requestSettled = true
      allJoined = true
      return result.receipt.exitCode
    } finally {
      if (handle && !facts.physicalJoined) {
        facts.receipt = await handle.terminate("aborted")
        await handle.settled; await handle.outputSettled
        facts.physicalJoined = true; facts.outputJoined = true; facts.emergencyOwnHandle = true
        allJoined = true
      }
      facts.endedAt = Date.now()
      await fs.writeFile(path.join(evidence, `${mode}-process-owner.json`), JSON.stringify(facts, null, 2))
    }
  }
  try {
    expect(await run("crash")).toBe(23)
    const checkpoint = JSON.parse(await fs.readFile(path.join(evidence, "checkpoint.json"), "utf8"))
    expect(checkpoint.tool).toMatchObject({ type: "tool", tool: "question", state: { status: "running" } })
    expect(checkpoint.publication.original.properties).toEqual(checkpoint.request)
    expect(await run("recover")).toBe(0)
    const observed = JSON.parse(await fs.readFile(path.join(evidence, "recover-observation.json"), "utf8"))
    const request = checkpoint.request
    expect(observed.asked.payload).toMatchObject(request)
    expect(observed.reply).toMatchObject({ status: 404, body: { name: "NotFoundError", data: { message: `Question request not found: ${request.id}` } } })
    expect(observed.publication.ownerObservation).toBe("dead_or_reused")
    const liveIDs = observed.connected.payload.conversationSnapshot.pendingQuestions.map((item: any) => item.id)
    if (!liveIDs.includes(observed.asked.payload.id)) liveIDs.push(observed.asked.payload.id)
    const canonicalIDs = observed.after.body.pendingQuestions.map((item: any) => item.id)
    await fs.writeFile(path.join(evidence, "projection-comparison.json"), JSON.stringify({ liveIDs, canonicalIDs, reply: observed.reply, reconnectedIDs: observed.reconnected.payload.conversationSnapshot.pendingQuestions.map((item: any) => item.id) }, null, 2))
    // Positive completeness contract. A real live Asked must name a current
    // canonical pending request; this is the original regression red.
    expect(liveIDs.sort()).toEqual(canonicalIDs.sort())
  } finally {
    clearInterval(release)
    for (const request of provider.requests) request.release()
    await Promise.all(provider.requests.map(request => request.responded))
    await provider.server.stop(true)
    await fs.writeFile(path.join(evidence, "controlled-provider.json"), JSON.stringify(provider.requests.map(request => ({ index: request.index, kind: request.kind, body: request.body })), null, 2))
    const cleanup: any = { children, providerClosed: true, endedAt: Date.now(), originalParentDeadlineAt: parentDeadlineAt, allJoined }
    if (allJoined) { await removeManagedDirectoryTree(runtime); cleanup.runtimeRemovedAfterPhysicalExit = true }
    await fs.writeFile(path.join(evidence, "cleanup.json"), JSON.stringify(cleanup, null, 2))
  }
}, 420000)
