import fs from "node:fs/promises"
import path from "node:path"
import { NodeProcess } from "../packages/util/src/process-node"
import { expectedTestProcessSupervisor } from "../packages/opencorvus/script/test-process-supervisor"
const [output] = process.argv.slice(2)
if (!output || !path.isAbsolute(output) || path.dirname(output) !== path.resolve(".tmp-task-git-question-reconnect-404") || !path.basename(output).startsWith("question-crash-red-")) throw Error("Explicit fresh owned crash scope required")
await fs.mkdir(output, { recursive: false })
const supervisor = expectedTestProcessSupervisor()
if (!supervisor || !(await fs.stat(supervisor)).isFile()) throw Error("Existing supervisor required")
process.env.OPENCORVUS_PROCESS_SUPERVISOR = supervisor
const startedAt = Date.now(), deadlineAt = startedAt + 600000
const args = ["run", "--cwd", "packages/opencorvus", "test", "../../.tmp-task-git-question-reconnect-404/question-crash-contract.test.ts"]
const env = { ...process.env, OPENCORVUS_QCRASH_EVIDENCE: output, OPENCORVUS_QCRASH_PARENT_DEADLINE: String(deadlineAt) }
const facts: any = { startedAt, deadlineAt, parentPID: process.pid, executable: process.execPath, args, cwd: process.cwd() }
for (const name of ["question-crash-worker.ts", "question-crash-contract.test.ts", "question-crash-runner.ts"]) await fs.copyFile(path.join(import.meta.dir, name), path.join(output, `actual-${name}`))
await fs.writeFile(path.join(output, "owner-start.json"), JSON.stringify(facts, null, 2))
let handle: any
try {
  const result = await NodeProcess.run({ command: { executable: process.execPath, args }, cwd: process.cwd(), env, ownership: "owned_tree", windowsHide: true, stdin: "ignore", deadlineAt, nothrow: true,
    onSpawned(child) { handle = child; facts.pid = child.pid; facts.occurrenceID = child.occurrenceID } })
  await fs.writeFile(path.join(output, "stdout.log"), result.stdout)
  await fs.writeFile(path.join(output, "stderr.log"), result.stderr)
  facts.receipt = result.receipt
  await handle.settled; await handle.outputSettled
  facts.physicalJoined = true; facts.outputJoined = true; facts.requestSettled = true
  process.exitCode = result.receipt.exitCode ?? 1
} catch (error) {
  facts.error = String(error); process.exitCode = 1
  if (handle) { facts.receipt = await handle.settled; await handle.outputSettled; facts.physicalJoined = true; facts.outputJoined = true }
} finally {
  facts.endedAt = Date.now()
  await fs.writeFile(path.join(output, "owner.json"), JSON.stringify(facts, null, 2))
  console.log(JSON.stringify(facts))
}
