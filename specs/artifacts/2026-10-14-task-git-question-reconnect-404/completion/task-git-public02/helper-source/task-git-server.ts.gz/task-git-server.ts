// Approved 404 scratch, derived from frozen manual-permission-server.ts.
// Only public Task/Global Chat APIs create data. No fabricated Task control or completion.
import fs from 'node:fs/promises'
import path from 'node:path'
import assert from 'node:assert/strict'
import { randomUUID } from 'node:crypto'
import { bootstrapIsolatedTestRuntime, applyIsolatedTestUserEnvironment } from '../packages/util/src/test-runtime-environment'
import { phaseBConfig } from '../.tmp-native-shutdown-pending-permission-403/phase-b-input'

const [scope, uiDirectory, rawDeadline] = process.argv.slice(2)
assert(scope && uiDirectory && path.isAbsolute(scope) && path.isAbsolute(uiDirectory))
assert.equal(path.dirname(path.resolve(scope)), path.resolve(import.meta.dir))
const driver = JSON.parse(await fs.readFile(path.join(scope, 'driver-context.json'), 'utf8'))
const deadlineAt = Number(rawDeadline), closeBy = deadlineAt - 60000, startedAt = Date.now()
assert.equal(deadlineAt, driver.deadlineAt); assert.equal(uiDirectory, driver.uiDirectory)
assert(Number.isSafeInteger(deadlineAt) && deadlineAt > startedAt && deadlineAt <= startedAt + 600000)
const write = (name: string, value: unknown) => fs.writeFile(path.join(scope, name), JSON.stringify(value, null, 2) + '\n', { flag: 'wx' })
const isolated = await bootstrapIsolatedTestRuntime('runner')
applyIsolatedTestUserEnvironment(isolated)
await write('server-runtime-owner.json', isolated)
const runtime = isolated.runtimeRoot, bootstrapProject = path.join(scope, 'bootstrap-project')
await fs.mkdir(bootstrapProject)
const catalog = path.join(scope, 'public-model-catalog.json')
await fs.writeFile(catalog, '{}\n', { flag: 'wx' })
Object.assign(process.env, { OPENCORVUS_HOME: runtime, OPENCORVUS_MODELS_PATH: catalog, OPENCORVUS_PROJECT_DIR: bootstrapProject, OPENCORVUS_DISABLE_AUTOUPDATE: '1', OPENCORVUS_DISABLE_EXTERNAL_SKILLS: '1', OPENCORVUS_DISABLE_CLAUDE_CODE: '1', OPENCORVUS_RUNTIME_MEMORY_METRICS_INTERVAL_MS: '300000' })
const { startControlledStreamingProvider } = await import('../packages/opencorvus/test/fixture/controlled-streaming-provider')
const seedProvider = startControlledStreamingProvider()
const taskFirstPromptToolCall = { name: 'read', arguments: { filePath: '' } }
const taskProvider = startControlledStreamingProvider({ firstPromptToolCall: taskFirstPromptToolCall })
const providers = [{ id: 'seed', value: seedProvider }, { id: 'task', value: taskProvider }]
const taskProfile = 'research-studio'
const requestFacts = new Map<unknown, any>()
let observed: any, base = '', taskID = '', actualProjectDirectory = ''
let closing = false, polling = false, releaseFirst = false
let poll: ReturnType<typeof setInterval> | undefined
let reserve: ReturnType<typeof setTimeout> | undefined
let prepareFailure: unknown
const release = setInterval(() => {
  for (const { id, value } of providers) {
    let promptOrdinal = 0
    for (const request of value.requests) {
      if (request.kind === 'prompt') promptOrdinal++
      let fact = requestFacts.get(request)
      if (!fact) {
        const body = request.body as any
        fact = { provider: id, index: request.index, kind: request.kind, model: body?.model, stream: body?.stream, observedAt: Date.now(), promptOrdinal: request.kind === 'prompt' ? promptOrdinal : undefined, declaredToolNames: Array.isArray(body?.tools) ? body.tools.map((tool: any) => tool?.function?.name).filter(Boolean) : [] }
        requestFacts.set(request, fact)
        void request.responded.then(() => { fact.fixtureResponseConstructedAt = Date.now() })
      }
      if (id === 'seed' || request.kind === 'memory' || (releaseFirst && promptOrdinal === 1)) {
        fact.commandedReleaseAt ??= Date.now(); request.release()
      }
    }
  }
}, 25)
async function api(route: string, method = 'GET', body?: unknown, directory = actualProjectDirectory || bootstrapProject, maxMs = 15000) {
  assert(Date.now() < closeBy, 'Original public request admission deadline')
  const response = await fetch(base + route, { method, headers: { 'content-type': 'application/json', 'x-opencorvus-directory': directory }, ...(body === undefined ? {} : { body: JSON.stringify(body) }), signal: AbortSignal.timeout(Math.max(1, Math.min(maxMs, closeBy - Date.now()))) })
  return { status: response.status, result: await response.json(), observedAt: Date.now() }
}
async function preflightProfile(label: 'bootstrap' | 'actual', directory: string) {
  const catalog = await api('/expert-squad/catalog', 'GET', undefined, directory)
  await write(`profile-preflight-${label}-catalog.json`, { directory, taskProfile, ...catalog })
  assert.equal(catalog.status, 200, `${label} expert squad catalog`)
  assert.equal((catalog.result as any).active?.effective, taskProfile, `${label} exact active profile`)
  const mounts = await api('/skill/mounts', 'GET', undefined, directory)
  await write(`profile-preflight-${label}-mounts.json`, { directory, taskProfile, ...mounts })
  assert.equal(mounts.status, 200, `${label} skill mounts`)
}
async function close(reason: string, failed = false) {
  if (closing) return
  closing = true; if (poll) clearInterval(poll); if (reserve) clearTimeout(reserve)
  let taskClosure: any, error: unknown
  try {
    if (taskID && Date.now() < closeBy) taskClosure = await api(`/task/${taskID}`, 'GET', undefined, actualProjectDirectory, 3000)
    if (taskID && taskClosure?.result?.cancellation?.status !== 'cancelled') failed = true
    if (observed) { await observed.server.stop(true); await observed.recovery }
    clearInterval(release)
    for (const { value } of providers) { for (const request of value.requests) request.release(); await value.server.stop(true) }
  } catch (caught) { error = String(caught); failed = true }
  finally {
    clearInterval(release)
    for (const { value } of providers) { for (const request of value.requests) request.release(); await value.server.stop(true).catch(() => undefined) }
  }
  await write('terminal.json', { reason, pid: process.pid, occurrence: observed?.occurrence, startedAt, deadlineAt, closeBy, finishedAt: Date.now(), taskID, taskClosure, prepareFailure, error, requests: [...requestFacts.values()], fixtureBoundary: 'Response constructed is not a client EOF receipt. Task prompts after the first are held until natural abort/owned shutdown.', serverAndProvidersStopAwaited: !error, physical: 'Only original driver NodeProcess receipt establishes physical/output join', exitCode: failed ? 1 : 0 })
  process.exit(failed ? 1 : 0)
}
try {
  reserve = setTimeout(() => { void close('Original fixed close reserve reached', true) }, Math.max(1, closeBy - Date.now()))
  const { installProcessShims } = await import('../packages/opencorvus/src/runtime/shims')
  installProcessShims()
  const { freezeOverlayUiDirectory } = await import('../packages/opencorvus/src/server/overlay-ui')
  const { Instance } = await import('../packages/opencorvus/src/project/instance')
  const { listenWithRecoveredServerRuntime } = await import('../packages/opencorvus/src/cli/server-runtime')
  const { recoverStartedTaskExecutions, assertStartedTaskProjectRecoverySucceeded } = await import('../packages/opencorvus/src/engine/host-recovery')
  observed = await listenWithRecoveredServerRuntime({ options: { hostname: '127.0.0.1', port: 0, randomPort: true, overlayUiSource: freezeOverlayUiDirectory({ directory: uiDirectory }) }, recover: async () => { const recovery = await recoverStartedTaskExecutions({ scopeProjectWorktree: bootstrapProject }); assertStartedTaskProjectRecoverySucceeded(recovery) }, disposeInstances: () => Instance.disposeAll() })
  await observed.recovery
  base = `http://127.0.0.1:${observed.server.port}`
  const config = phaseBConfig(seedProvider.apiURL)
  config.prompt_profile.active = taskProfile
  config.enabled_providers.push('task-fixture')
  ;(config.provider as any)['task-fixture'] = { ...config.provider['shutdown-fixture'], name: 'Public 404 Task baseline fixture', api: taskProvider.apiURL }
  const configured = await api('/global/config', 'PATCH', config)
  await write('public-global-config.json', configured); assert.equal(configured.status, 200)
  await preflightProfile('bootstrap', bootstrapProject)
  const seedRequest = { requestID: randomUUID(), model: 'shutdown-fixture/session-prompt-owner-model', text: 'Confirm this public conversation is ready for a separate Task baseline check.' }
  const seed = await api('/global/chat/start', 'POST', seedRequest)
  await write('global-chat-start.json', { request: seedRequest, ...seed }); assert.equal(seed.status, 202)
  const session = (seed.result as any).session; assert(session?.id && session.projectID)
  const projects = await fs.realpath(path.join(runtime, 'data/projects'))
  actualProjectDirectory = await fs.realpath(session.directory)
  const relative = path.relative(projects, actualProjectDirectory)
  assert(relative && !relative.startsWith('..') && !path.isAbsolute(relative), 'Actual owned canonical Global Project directory')
  let seedConversation: any, seedMessages: any
  const seedInputMessageID = (seed.result as any).messageID
  assert(seedInputMessageID, 'Public seed accepted input identity')
  const seedCompleted = () => (seedMessages?.result as any[] | undefined)?.some(message => message.info?.role === 'assistant' && message.info?.parentID === seedInputMessageID && message.info?.finish === 'stop' && Number.isFinite(message.info?.time?.completed))
  const seedUntil = Math.min(Date.now() + 45000, closeBy)
  do {
    seedConversation = await api(`/session/${session.id}/conversation`)
    seedMessages = await api(`/session/${session.id}/message`)
    if ((seedConversation.result as any)?.board?.status === 'idle' && seedCompleted()) break
    await new Promise(resolve => setTimeout(resolve, 100))
  } while (Date.now() < seedUntil)
  await write('seed-conversation.json', seedConversation)
  assert.equal(seedConversation.status, 200); assert.equal(seedConversation.result.board.status, 'idle')
  await write('seed-messages.json', seedMessages)
  assert.equal(seedMessages.status, 200)
  assert(seedCompleted(), 'Natural completion of the exact accepted seed input')
  await preflightProfile('actual', actualProjectDirectory)
  const publicBytes = Buffer.from('item,quantity\nCedar404,3\nIris404,4\n')
  const publicFile = path.join(actualProjectDirectory, 'public-task-input.csv')
  await fs.writeFile(publicFile, publicBytes, { flag: 'wx' })
  await fs.writeFile(path.join(scope, 'public-task-input.csv'), publicBytes, { flag: 'wx' })
  assert.equal(taskProvider.promptRequests().length, 0, 'Bind the Tool input before its real first Task request')
  taskFirstPromptToolCall.arguments.filePath = publicFile
  const fixtureFacts = { projectID: session.projectID, seedSessionID: session.id, actualProjectDirectory, publicFile, relativeFile: path.relative(actualProjectDirectory, publicFile).replaceAll('\\', '/'), bytes: publicBytes.length, directoryUtf8Bytes: Buffer.byteLength(actualProjectDirectory), directoryUtf16CodeUnits: actualProjectDirectory.length, gitMarkerPathUtf8Bytes: Buffer.byteLength(path.join(actualProjectDirectory, '.git')), taskModel: 'task-fixture/session-prompt-owner-model', firstToolCall: taskFirstPromptToolCall, recordedAt: Date.now(), boundary: 'Input prepared before real Task acceptance; no Task directory override' }
  await write('public-fixture-facts.json', fixtureFacts)
  const taskRequest = { requestID: randomUUID(), title: 'Public Task Git baseline 404', request: `Read the public CSV at ${publicFile} and report its rows.`, productPillar: 'work', promptProfile: taskProfile, model: fixtureFacts.taskModel }
  await write('task-create-request.json', taskRequest)
  const accepted = await api('/task?init-git=true', 'POST', taskRequest, actualProjectDirectory, 45000)
  await write('task-created.json', accepted); assert.equal(accepted.status, 202)
  const task = accepted.result as any; taskID = task.task_id
  assert(taskID); assert.equal(task.project_id, session.projectID); assert.equal(await fs.realpath(task.directory), actualProjectDirectory)
  await write('ready.json', { pid: process.pid, occurrence: observed.occurrence, driverStartedAt: driver.startedAt, startedAt, deadlineAt, closeBy, port: observed.server.port, url: `${base}/ui?taskID=${encodeURIComponent(taskID)}`, runtime, uiDirectory, bootstrapProject, actualProjectDirectory, taskID, projectID: task.project_id, seedSessionID: session.id, publicFile, scenario: 'task-git-public', provider: 'Synthetic controlled streaming only; not Sol qualification', pageAcceptance: 'Root manual only', taskPostReadPolicy: 'Subsequent Task prompt responses held for real operator cancellation' })
  console.log(JSON.stringify({ ready: true, url: `${base}/ui?taskID=${taskID}`, taskID, actualProjectDirectory, deadlineAt, closeBy }))
  poll = setInterval(async () => {
    if (polling || closing) return
    polling = true
    try {
      try { await fs.stat(path.join(scope, 'release-first-task-prompt')); releaseFirst = true } catch (error) { if ((error as NodeJS.ErrnoException).code !== 'ENOENT') throw error }
      try { await fs.stat(path.join(scope, 'stop-requested')); await close('Root closed page and requested owned stop') } catch (error) { if ((error as NodeJS.ErrnoException).code !== 'ENOENT') throw error }
    } catch (error) { prepareFailure = String(error); await close('Owned control observation failed', true) }
    finally { polling = false }
  }, 100)
} catch (error) {
  prepareFailure = String(error)
  await write('server-prepare-failure.json', { error: prepareFailure, observedAt: Date.now(), deadlineAt })
  await close('Public preparation failed', true)
}
