import { expect, test } from "bun:test"
import fs from "node:fs/promises"
import path from "node:path"
import { NodeProcess } from "../packages/util/src/process-node"
import { createManagedTemporaryDirectory, removeManagedDirectoryTree } from "../packages/util/src/runtime-directories"
import { startControlledStreamingProvider } from "../packages/opencorvus/test/fixture/controlled-streaming-provider"

const scenario = process.env.OPENCORVUS_QCRASH_SCENARIO ?? "ordinary"
test(scenario === "ordinary" ? "ordinary Question restart live projection agrees with the canonical public pending set" : "normal Task bootstrap restores a source-only Question and preserves its accepted-terminal control", async () => {
  const evidence = process.env.OPENCORVUS_QCRASH_EVIDENCE
  const parentDeadlineAt = Number(process.env.OPENCORVUS_QCRASH_PARENT_DEADLINE)
  const processRoot = process.env.OPENCORVUS_TEST_PROCESS_ROOT
  if (!evidence || !path.isAbsolute(evidence) || !processRoot || !Number.isFinite(parentDeadlineAt)) throw Error("Owned formal evidence/deadline/test runtime required")
  const runtime = await createManagedTemporaryDirectory(processRoot, "question-crash-runtime-")
  const provider = startControlledStreamingProvider({ firstPromptToolCall: { name: "question", arguments: {
    questions: [{ header: "Public recovery", question: "Which public Cedar answer should be retained?", options: [{ value: "cedar", label: "Cedar", description: "Public Cedar example" }], custom: true }],
  } } })
  const controlProvider = startControlledStreamingProvider({ firstPromptToolCall: { name: "question", arguments: {
    questions: [{ header: "Current owner", question: "Which actual current Cedar answer should be recorded?", options: [], custom: true }],
  } } })
  const providers = [provider, controlProvider]
  const release = setInterval(() => { for (const owned of providers) for (const request of owned.requests) request.release() }, 5)
  const children: any[] = []
  let allJoined = true
  async function run(mode: "crash" | "recover") {
    if (Date.now() + 60000 >= parentDeadlineAt) throw Error("Original parent close reserve reached")
    const startedAt = Date.now(), deadlineAt = Math.min(startedAt + 180000, parentDeadlineAt - 60000)
    const cwd = path.resolve(import.meta.dir, "../packages/opencorvus")
    const args = [`--config=${path.join(cwd, "test/empty-bunfig.toml")}`, `--tsconfig-override=${path.join(cwd, "tsconfig.json")}`,
      path.join(import.meta.dir, "question-crash-worker.ts"), mode, runtime, evidence, provider.apiURL, String(deadlineAt)]
    const env = { ...process.env, OPENCORVUS_HOME: runtime, OPENCORVUS_QCRASH_CONTROL_URL: controlProvider.apiURL }
    const facts: any = { mode, startedAt, deadlineAt, executable: process.execPath, args, cwd, environmentNames: Object.keys(env).sort() }
    children.push(facts)
    await fs.writeFile(path.join(evidence, `${mode}-spawn.json`), JSON.stringify(facts, null, 2))
    let handle: any
    allJoined = false
    try {
      const result = await NodeProcess.run({ command: { executable: process.execPath, args }, cwd, env, ownership: "owned_tree", windowsHide: true, stdin: "ignore", deadlineAt, nothrow: true,
        onSpawned(child) { handle = child; facts.pid = child.pid; facts.occurrenceID = child.occurrenceID } })
      await fs.writeFile(path.join(evidence, `${mode}-stdout.log`), result.stdout)
      await fs.writeFile(path.join(evidence, `${mode}-stderr.log`), result.stderr)
      facts.receipt = result.receipt
      await handle.settled; await handle.outputSettled
      facts.physicalJoined = true; facts.outputJoined = true; facts.requestSettled = true
      allJoined = true
      return result.receipt.exitCode
    } finally {
      if (handle && !facts.physicalJoined) {
        facts.receipt = await handle.terminate("aborted")
        await handle.settled; await handle.outputSettled
        facts.physicalJoined = true; facts.outputJoined = true; facts.emergencyOwnHandle = true
        allJoined = true
      }
      facts.endedAt = Date.now()
      await fs.writeFile(path.join(evidence, `${mode}-process-owner.json`), JSON.stringify(facts, null, 2))
    }
  }
  try {
    expect(await run("crash")).toBe(23)
    const checkpoint = JSON.parse(await fs.readFile(path.join(evidence, "checkpoint.json"), "utf8"))
    if (scenario === "task") {
      const source = checkpoint.owners[0], terminal = checkpoint.owners[1]
      expect(source.publication.original).toMatchObject({ event_type: "question.asked", properties: source.request })
      expect(terminal.publication.facts.terminal).toMatchObject({ type: "question.replied", properties: { answers: [["Exact accepted Task answer"]] } })
      expect(await run("recover")).toBe(0)
      const observed = JSON.parse(await fs.readFile(path.join(evidence, "recover-observation.json"), "utf8"))
      expect(observed.originalTerminal.facts.terminal).toEqual(terminal.publication.facts.terminal)
      expect(observed.beforeReply.terminal).toMatchObject({ task_id: terminal.taskID, external_id: terminal.request.id, status: "answered", time_resolved: terminal.publication.facts.terminal.properties.timeResolved })
      expect(observed.outcomes.map((item: any) => item.source_occurrence_id)).toEqual([terminal.publication.facts.terminal.occurrenceID])
      expect(observed.sourceReply).toMatchObject({ status: 200, body: true })
      expect(observed.afterReply).toMatchObject({ task_id: source.taskID, status: "answered", response: { answers: [["Actual recovery control answer"]] } })
      return
    }
    expect(checkpoint.tool).toMatchObject({ type: "tool", tool: "question", state: { status: "running" } })
    expect(checkpoint.publication.original.properties).toEqual(checkpoint.request)
    expect(await run("recover")).toBe(0)
    const observed = JSON.parse(await fs.readFile(path.join(evidence, "recover-observation.json"), "utf8"))
    const request = checkpoint.request
    expect(observed.reply).toMatchObject({ status: 404, body: { name: "NotFoundError", data: { message: `Question request not found: ${request.id}` } } })
    expect(observed.publication.ownerObservation).toBe("dead_or_reused")
    expect(observed.publication.original).toEqual(checkpoint.publication.original)
    expect(observed.originalTool).toEqual(checkpoint.tool)
    expect(observed.control.pending.tool).toMatchObject({ callID: "call_controlled_recovery_next" })
    expect(observed.control.reply).toMatchObject({ status: 200, body: true })
    expect(observed.control.completed).toMatchObject({ status: 200, body: { info: { role: "assistant", finish: "stop" } } })
    expect(observed.control.tool).toMatchObject({ type: "tool", tool: "question", state: { status: "completed", metadata: { answers: [["Actual current Cedar answer"]] } } })
    const liveIDs = observed.connected.payload.conversationSnapshot.pendingQuestions.map((item: any) => item.id)
    for (const event of observed.pendingEvents) {
      if (event.type === "question.asked" && !liveIDs.includes(event.payload.id)) liveIDs.push(event.payload.id)
      if (["question.replied", "question.rejected", "question.expired", "question.abandoned"].includes(event.type)) {
        const index = liveIDs.indexOf(event.payload.requestID); if (index >= 0) liveIDs.splice(index, 1)
      }
    }
    const canonicalIDs = observed.control.canonical.body.pendingQuestions.map((item: any) => item.id)
    expect(canonicalIDs).toEqual([observed.control.pending.id])
    await fs.writeFile(path.join(evidence, "projection-comparison.json"), JSON.stringify({ liveIDs, canonicalIDs, reply: observed.reply, reconnectedIDs: observed.reconnected.payload.conversationSnapshot.pendingQuestions.map((item: any) => item.id) }, null, 2))
    // Positive completeness contract. A real live Asked must name a current
    // canonical pending request; this is the original regression red.
    expect(liveIDs.sort()).toEqual(canonicalIDs.sort())
  } finally {
    clearInterval(release)
    for (const owned of providers) {
      for (const request of owned.requests) request.release()
      await Promise.all(owned.requests.map(request => request.responded))
      await owned.server.stop(true)
    }
    await fs.writeFile(path.join(evidence, "controlled-provider.json"), JSON.stringify(providers.flatMap((owned, providerIndex) => owned.requests.map(request => ({ providerIndex, index: request.index, kind: request.kind, body: request.body }))), null, 2))
    const cleanup: any = { children, providerClosed: true, endedAt: Date.now(), originalParentDeadlineAt: parentDeadlineAt, allJoined }
    if (allJoined) { await removeManagedDirectoryTree(runtime); cleanup.runtimeRemovedAfterPhysicalExit = true }
    await fs.writeFile(path.join(evidence, "cleanup.json"), JSON.stringify(cleanup, null, 2))
  }
}, 420000)
