const fs = require('node:fs');
const base = '.tmp-task-git-question-reconnect-404/';
const testTarget = 'packages/opencorvus/test/question-process-projection.test.ts';
const workerTarget = 'packages/opencorvus/test/fixture/question-process-projection-worker.ts';
for (const target of [testTarget, workerTarget]) if (fs.existsSync(target)) throw Error('Target already exists: ' + target);
function replaceOnce(text, before, after) { if (!text.includes(before)) throw Error('Missing migration anchor: ' + before); return text.replace(before, after); }
let test = fs.readFileSync(base + 'question-crash-contract.test.ts', 'utf8');
test = replaceOnce(test, '"../packages/util/src/process-node"', '"@opencorvus-ai/util/process-node"');
test = replaceOnce(test, '"../packages/util/src/runtime-directories"', '"@opencorvus-ai/util/runtime-directories"');
test = replaceOnce(test, '"../packages/opencorvus/test/fixture/controlled-streaming-provider"', '"./fixture/controlled-streaming-provider"');
const setupStart = test.indexOf('const scenario =');
const setupEnd = test.indexOf('  const provider =', setupStart);
test = test.slice(0, setupStart) + `test("ordinary Question process recovery projects the complete current replyable set", async () => {
  const processRoot = process.env.OPENCORVUS_TEST_PROCESS_ROOT
  if (!processRoot) throw Error("Question process projection requires the repository isolated runtime")
  const parentDeadlineAt = Date.now() + 600000
  const scope = await createManagedTemporaryDirectory(processRoot, "question-process-projection-")
  const runtime = path.join(scope, "runtime")
  const evidence = path.join(scope, "evidence")
  await fs.mkdir(runtime)
  await fs.mkdir(evidence)
` + test.slice(setupEnd);
test = replaceOnce(test, 'path.resolve(import.meta.dir, "../packages/opencorvus")', 'path.resolve(import.meta.dir, "..")');
test = replaceOnce(test, 'path.join(import.meta.dir, "question-crash-worker.ts")', 'path.join(import.meta.dir, "fixture", "question-process-projection-worker.ts")');
test = test.replaceAll('OPENCORVUS_QCRASH_CONTROL_URL', 'OPENCORVUS_QUESTION_PROJECTION_CONTROL_URL');
const branchStart = test.indexOf('    if (scenario === "task") {');
const branchEnd = test.indexOf('    expect(checkpoint.tool)', branchStart);
if (branchStart < 0 || branchEnd < 0) throw Error('Missing ordinary test branch');
test = test.slice(0, branchStart) + test.slice(branchEnd);
test = test.replace(/expect\((checkpoint\.tool|observed\.reply|observed\.control\.pending\.tool|observed\.control\.reply|observed\.control\.completed|observed\.control\.tool)\)/g, 'expect(structuredClone($1))');
test = replaceOnce(test, '      return result.receipt.exitCode', `      if (result.receipt.exitCode !== (mode === "crash" ? 23 : 0)) {
        console.error(JSON.stringify({ mode, receipt: result.receipt, stdout: result.stdout, stderr: result.stderr }))
      }
      return result.receipt.exitCode`);
test = replaceOnce(test, '    expect(liveIDs.sort()).toEqual(canonicalIDs.sort())', `    console.log(JSON.stringify({
      observation: "ordinary Question process projection", originalRequest: request,
      originalTool: observed.originalTool, originalPublication: observed.publication.original,
      currentRequest: observed.control.pending, currentReply: observed.control.reply,
      currentTool: observed.control.tool, currentAssistant: observed.control.completed,
      liveIDs, canonicalIDs, oldReply: observed.reply,
      reconnected: observed.reconnected.payload.conversationSnapshot.pendingQuestions,
    }))
    expect(liveIDs.sort()).toEqual(canonicalIDs.sort())`);
test = replaceOnce(test, '    if (allJoined) { await removeManagedDirectoryTree(runtime); cleanup.runtimeRemovedAfterPhysicalExit = true }\r\n    await fs.writeFile(path.join(evidence, "cleanup.json"), JSON.stringify(cleanup, null, 2))', `    const closed = await fs.readFile(path.join(evidence, "recover-closed.json"), "utf8").then(JSON.parse).catch(() => undefined)
    console.log(JSON.stringify({
      observation: "Question process owners closed", ...cleanup, restartClosed: closed,
      providerRequests: providers.flatMap((owned, providerIndex) => owned.requests.map(request => ({
        providerIndex, index: request.index, kind: request.kind, model: request.body.model, stream: request.body.stream,
      }))),
    }))
    if (allJoined) await removeManagedDirectoryTree(scope)`);
test = replaceOnce(test, '}, 420000)', '}, 600000)');
fs.writeFileSync(testTarget, test);

let worker = fs.readFileSync(base + 'question-crash-worker.ts', 'utf8');
worker = worker.replaceAll('../packages/opencorvus/src/', '../../src/');
const removeImport = [
  'import { persistEstablishedTask }', 'import { prepareTaskProcessBinding }',
  'import { findInteractionByExternal }', 'import { EngineInteractionOutcomeTable }', 'import { hostGit }',
];
worker = worker.split(/\r?\n/).filter(line => !removeImport.some(prefix => line.startsWith(prefix))).join('\n');
worker = replaceOnce(worker, 'Database, and, eq', 'Database, eq');
worker = replaceOnce(worker, 'const scenario = process.env.OPENCORVUS_QCRASH_SCENARIO ?? "ordinary"\nif (!["ordinary", "task"].includes(scenario)) throw Error("Explicit Question crash scenario required")\n', '');
const functionStart = worker.indexOf('async function taskScenario() {');
const functionEnd = worker.indexOf('\ntry {\n  installProcessShims()', functionStart);
if (functionStart < 0 || functionEnd < 0) throw Error('Missing task worker branch');
worker = worker.slice(0, functionStart) + worker.slice(functionEnd);
const gitStart = worker.indexOf('  if (scenario === "task" && mode === "crash") {');
const gitEnd = worker.indexOf('  if (mode === "crash") {', gitStart + 10);
worker = worker.slice(0, gitStart) + worker.slice(gitEnd);
worker = replaceOnce(worker, '  if (scenario === "task") {\n    await taskScenario()\n  } else {\n', '');
worker = replaceOnce(worker, '\n  }\n} catch (error) {', '\n} catch (error) {');
worker = worker.replaceAll('OPENCORVUS_QCRASH_CONTROL_URL', 'OPENCORVUS_QUESTION_PROJECTION_CONTROL_URL');
fs.writeFileSync(workerTarget, worker);
console.log(JSON.stringify({ testTarget, workerTarget, source: ['question-crash-contract.test.ts', 'question-crash-worker.ts'], scenario: 'ordinary' }));
