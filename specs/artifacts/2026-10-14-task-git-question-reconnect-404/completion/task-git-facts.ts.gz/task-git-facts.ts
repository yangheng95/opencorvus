// 404 approved non-UI checker. Invoked only by the original task-git-driver owner.
// Sources: git-probe-worker.ts NodeProcess contract; existing read-only SQLite check-live-402.ts pattern.
import fs from 'node:fs/promises'
import path from 'node:path'
import assert from 'node:assert/strict'
import { Database } from 'bun:sqlite'
import { NodeProcess } from '../packages/util/src/process-node'

const [scope, mode, id] = process.argv.slice(2)
assert(scope && path.isAbsolute(scope)); assert.equal(path.dirname(path.resolve(scope)), path.resolve(import.meta.dir))
assert(['baseline', 'read', 'cancelled'].includes(mode)); assert(/^[0-9a-f-]+$/.test(id))
const json = async (name: string) => JSON.parse(await fs.readFile(path.join(scope, name), 'utf8'))
const write = (name: string, value: unknown) => fs.writeFile(path.join(scope, name), JSON.stringify(value, null, 2) + '\n', { flag: 'wx' })
const startedAt = Date.now(), ready = await json('ready.json'), driver = await json('driver-context.json'), launch = await json('product-launch.json')
const control = await json(`controls/facts-${id}.json`), fixture = await json('public-fixture-facts.json'), accepted = await json('task-created.json')
assert.equal(control.mode, mode); assert.equal(control.productPID, launch.pid); assert.equal(control.productOccurrence, launch.occurrence)
assert.equal(ready.pid, launch.pid); assert.equal(ready.deadlineAt, driver.deadlineAt); assert.equal(control.deadlineAt, driver.deadlineAt)
assert.equal(ready.scenario, 'task-git-public'); assert(Date.now() < ready.closeBy, 'Original live checker budget')
const snapshot: any = { id, mode, startedAt, deadlineAt: driver.deadlineAt, closeBy: ready.closeBy, checkerPID: process.pid, productPID: launch.pid, productOccurrence: launch.occurrence, source: 'Public Task API plus exact selected immutable checkpoint facts; no UI automation' }
let failure: unknown
try {
  const runtime = await fs.realpath(ready.runtime), project = await fs.realpath(ready.actualProjectDirectory)
  const projectsRoot = await fs.realpath(path.join(runtime, 'data/projects'))
  const relative = path.relative(projectsRoot, project)
  assert(relative && !relative.startsWith('..') && !path.isAbsolute(relative))
  assert.equal(project, await fs.realpath(fixture.actualProjectDirectory))
  const original = await fs.readFile(path.join(scope, 'public-task-input.csv'))
  assert.equal(original.length, fixture.bytes); assert.deepEqual(await fs.readFile(fixture.publicFile), original)
  assert.equal(path.relative(project, await fs.realpath(fixture.publicFile)).replaceAll('\\', '/'), fixture.relativeFile)
  const api = async (route: string) => {
    assert(Date.now() < ready.closeBy, 'Original API observation budget')
    const response = await fetch(new URL(route, ready.url), { headers: { 'x-opencorvus-directory': project }, signal: AbortSignal.timeout(Math.max(1, Math.min(15000, ready.closeBy - Date.now()))) })
    return { status: response.status, result: await response.json(), observedAt: Date.now() }
  }
  snapshot.public = Object.fromEntries(await Promise.all([
    ['task', `/task/${ready.taskID}`], ['board', `/task/${ready.taskID}/board`], ['transcript', `/task/${ready.taskID}/transcript`],
  ].map(async ([name, route]) => [name, await api(route)])))
  const db = new Database(path.join(runtime, 'data/opencorvus.db'), { readonly: true })
  try {
    db.exec('BEGIN')
    const task = db.query('SELECT id, project_id, session_id FROM engine_task WHERE id=? AND project_id=?').get(ready.taskID, ready.projectID) as any
    const root = task ? db.query('SELECT id, project_id, directory, kind, parent_id FROM session WHERE id=?').get(task.session_id) : null
    const bindingRows = db.query("SELECT id, task_id, kind, payload FROM engine_artifact WHERE task_id=? AND kind='task_execution_capsule_binding'").all(ready.taskID) as any[]
    const checkpoints = db.query('SELECT r.id, r.task_id, r.stage, r.operation_key, r.input, r.time_created AS requested_at, o.result, o.time_created AS settled_at FROM engine_git_checkpoint_request r LEFT JOIN engine_git_checkpoint_outcome o ON o.request_id=r.id JOIN engine_task t ON t.id=r.task_id WHERE r.task_id=? AND t.project_id=? ORDER BY r.time_created,r.id').all(ready.taskID, ready.projectID) as any[]
    snapshot.canonical = { task, root, bindingRows: bindingRows.map(row => ({ ...row, payload: JSON.parse(row.payload) })), checkpoints: checkpoints.map(row => ({ ...row, input: JSON.parse(row.input), result: row.result === null ? null : JSON.parse(row.result) })) }
  } finally { db.exec('ROLLBACK'); db.close() }
  await write(`facts-${id}.observation.json`, snapshot)
  for (const response of Object.values(snapshot.public) as any[]) assert.equal(response.status, 200)
  assert.equal(accepted.status, 202); assert.equal(accepted.result.task_id, ready.taskID); assert.equal(accepted.result.project_id, ready.projectID)
  assert.equal(await fs.realpath(accepted.result.directory), project)
  const task = snapshot.public.task.result, canonical = snapshot.canonical
  assert.equal(task.id, ready.taskID); assert.equal(task.projectID, ready.projectID); assert.equal(task.sessionID, canonical.root.id)
  assert.equal(canonical.task.project_id, ready.projectID); assert.equal(canonical.root.project_id, ready.projectID)
  assert.equal(canonical.root.kind, 'root'); assert.equal(canonical.root.parent_id, null)
  assert.equal(await fs.realpath(canonical.root.directory), project)
  assert.equal(canonical.bindingRows.length, 1)
  const binding = canonical.bindingRows[0].payload
  assert.equal(binding.protocol, 'task-native-process-binding-v2'); assert.equal(binding.task_id, ready.taskID); assert.equal(binding.project_id, ready.projectID)
  assert.equal(await fs.realpath(binding.workspace_root), project)
  const baseline = canonical.checkpoints.find((row: any) => row.stage === 'baseline' && row.operation_key === 'baseline:1')
  assert(baseline, 'Original epoch has its real baseline request'); assert(baseline.result, 'Original request has a durable outcome')
  assert.equal(await fs.realpath(baseline.input.root), project)
  assert.equal(baseline.result.checkpoint_receipt.task_id, ready.taskID)
  assert.equal(baseline.result.checkpoint_receipt.checkpoint_stage, 'baseline')
  assert.equal(baseline.result.checkpoint_receipt.outcome, 'success')
  const repository = baseline.result.repositories.find((row: any) => row.path === '.' && row.depth === 0)
  assert(repository?.authority && repository.commit, 'Initialized root baseline repository')
  assert.equal(await fs.realpath(repository.authority.workspace), project)
  const gitDirectory = await fs.realpath(repository.authority.git_dir)
  assert(['sha1', 'sha256'].includes(repository.authority.object_format)); assert(/^[0-9a-f]{40}$|^[0-9a-f]{64}$/.test(repository.commit))
  const executable = Bun.which('git'); assert(executable && path.isAbsolute(executable), 'Actual Git executable')
  const gitRuntime = path.join(scope, `git-read-${id}`)
  await fs.mkdir(gitRuntime)
  for (const name of ['home', 'tmp', 'empty-hooks']) await fs.mkdir(path.join(gitRuntime, name))
  for (const name of ['empty-global-config', 'empty-attributes', 'empty-excludes']) await fs.writeFile(path.join(gitRuntime, name), '', { flag: 'wx' })
  const env = Object.fromEntries(Object.entries({
    SystemRoot: process.env.SystemRoot, COMSPEC: process.env.COMSPEC, PATHEXT: process.env.PATHEXT,
    TEMP: path.join(gitRuntime, 'tmp'), TMP: path.join(gitRuntime, 'tmp'), HOME: path.join(gitRuntime, 'home'), USERPROFILE: path.join(gitRuntime, 'home'),
    GIT_CONFIG_NOSYSTEM: '1', GIT_CONFIG_GLOBAL: path.join(gitRuntime, 'empty-global-config'), GIT_ATTR_NOSYSTEM: '1', GIT_TERMINAL_PROMPT: '0', GIT_PAGER: 'cat', LC_ALL: 'C', LANG: 'C',
  }).filter((pair): pair is [string, string] => typeof pair[1] === 'string'))
  const argv = ['--no-pager', '-c', 'core.longPaths=true', '-c', 'core.fsmonitor=false', '-c', 'maintenance.auto=false', '-c', 'maintenance.autoDetach=false', '-c', 'gc.auto=0', '-c', 'gc.autoDetach=false', '-c', 'commit.gpgSign=false', '-c', 'diff.external=', '-c', `core.hooksPath=${path.join(gitRuntime, 'empty-hooks')}`, '-c', `core.attributesFile=${path.join(gitRuntime, 'empty-attributes')}`, '-c', `core.excludesFile=${path.join(gitRuntime, 'empty-excludes')}`, '-C', path.dirname(gitDirectory), `--git-dir=${path.basename(gitDirectory)}`, `--work-tree=${project}`, 'show', `${repository.commit}:${fixture.relativeFile}`]
  const gitFact: any = { executable, argv, cwd: project, environmentNames: Object.keys(env).sort(), startedAt: Date.now(), deadlineAt: Math.min(Date.now() + 15000, ready.closeBy), canonicalAuthority: repository.authority }
  let handle: any
  try {
    assert(gitFact.deadlineAt > Date.now(), 'Original Git observation budget')
    const result = await NodeProcess.run({ command: { executable, args: argv }, cwd: project, env, ownership: 'owned_tree', windowsHide: true, stdin: 'ignore', deadlineAt: gitFact.deadlineAt, nothrow: true, onSpawned(value) { handle = value; gitFact.pid = value.pid; gitFact.occurrence = value.occurrenceID } })
    gitFact.receipt = result.receipt; gitFact.stdoutBytesBase64 = Buffer.from(result.stdout).toString('base64'); gitFact.stderr = Buffer.from(result.stderr).toString()
    await handle.settled; await handle.outputSettled
    gitFact.physicalJoined = true; gitFact.outputJoined = true; gitFact.requestSettled = true
    assert.equal(result.receipt.reason, 'exited'); assert.equal(result.receipt.exitCode, 0, gitFact.stderr)
    assert.deepEqual(Buffer.from(result.stdout), original, 'Actual immutable baseline commit contains original CSV bytes')
    await fs.writeFile(path.join(scope, `facts-${id}.baseline.csv`), Buffer.from(result.stdout), { flag: 'wx' })
  } catch (error) {
    gitFact.error = String(error)
    if (handle) { gitFact.receipt = await handle.settled; await handle.outputSettled; gitFact.physicalJoined = true; gitFact.outputJoined = true }
    throw error
  } finally { gitFact.finishedAt = Date.now(); await write(`facts-${id}.git.json`, gitFact) }
  let readProof: any
  if (mode === 'read' || mode === 'cancelled') {
    const tools = (snapshot.public.transcript.result as any[]).flatMap(message => message.parts.map((part: any) => ({ message: message.info, part })))
    const read = tools.find(({ part }) => part.type === 'tool' && part.tool === 'read' && part.state?.input?.filePath === fixture.publicFile)
    assert(read, 'Natural read Tool has the original exact input'); assert.equal(read.part.state.status, 'completed')
    for (const row of original.toString('utf8').trimEnd().split('\n')) assert(read.part.state.output.includes(row), `Actual read output contains ${row}`)
    readProof = { sessionID: read.message.sessionID, messageID: read.message.id, callID: read.part.callID, input: read.part.state.input, status: read.part.state.status, output: read.part.state.output }
  }
  if (mode === 'cancelled') {
    assert.equal(task.status, 'cancelled'); assert.equal(task.cancellation.status, 'cancelled')
    assert(task.cancellation.requestEventID && task.cancellation.terminalEventID && Number.isFinite(task.cancellation.terminalAt))
  }
  await write(`facts-${id}.check.json`, { passed: true, mode, taskID: ready.taskID, projectID: ready.projectID, rootSessionID: canonical.root.id, requestID: baseline.id, stage: baseline.stage, operationKey: baseline.operation_key, baselineCommit: repository.commit, originalCSVBytes: original.length, directoryUtf8Bytes: Buffer.byteLength(project), directoryUtf16CodeUnits: project.length, gitDirectoryUtf8Bytes: Buffer.byteLength(gitDirectory), readProof, cancellation: mode === 'cancelled' ? task.cancellation : undefined, finishedAt: Date.now(), boundary: 'Baseline/read/cancel only as selected. No result checkpoint, Task completion, UI, or real Sol claim.' })
  console.log(JSON.stringify({ passed: true, mode, id, taskID: ready.taskID, baselineCommit: repository.commit }))
} catch (error) {
  failure = String(error)
  await write(`facts-${id}.failure.json`, { error: failure, mode, startedAt, observedAt: Date.now(), deadlineAt: driver.deadlineAt })
  console.error(failure); process.exitCode = 1
}
