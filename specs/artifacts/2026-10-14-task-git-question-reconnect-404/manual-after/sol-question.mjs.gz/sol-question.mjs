import fs from 'node:fs/promises'
import path from 'node:path'
import assert from 'node:assert/strict'
import {randomUUID} from 'node:crypto'
const [requestedRoot,mode='observe',answer]=process.argv.slice(2)
assert(requestedRoot&&path.isAbsolute(requestedRoot));const root=path.resolve(requestedRoot)
assert.equal(path.dirname(root),import.meta.dirname);assert(['start','observe','check'].includes(mode))
const read=async(name)=>JSON.parse(await fs.readFile(path.join(root,name),'utf8'))
const record=(name,value)=>fs.writeFile(path.join(root,name),JSON.stringify(value,null,2),{flag:'wx'})
const owner=await read('provider-run/launch-owner.json'),preflight=await read('provider-run/evidence/preflight-ready.json')
assert.equal(owner.qualificationKind,'NativeService');assert.equal(owner.requestBudget,20);assert.equal(owner.inactivityMilliseconds,180000)
assert.deepEqual({credential:preflight.preflight.credential,catalog:preflight.preflight.catalog,model:preflight.preflight.actualModel,streaming:preflight.preflight.streaming},{credential:'usable',catalog:'projected',model:'gpt-6.1-sol',streaming:true})
const base=`http://127.0.0.1:${owner.port}`,closeBy=owner.nativeDeadlineAt-60000
const api=async(route,method='GET',body,directory)=>{
 assert(Date.now()<closeBy)
 const response=await fetch(base+route,{method,headers:{'content-type':'application/json',...(directory?{'x-opencorvus-directory':directory}:{})},...(body===undefined?{}:{body:JSON.stringify(body)}),signal:AbortSignal.timeout(Math.min(15000,closeBy-Date.now()))})
 const result=await response.json();return {status:response.status,result,observedAt:new Date().toISOString()}
}
if(mode==='start'){
 assert(owner.nativeDeadlineAt-Date.now()>=240000)
 const request={requestID:randomUUID(),model:'openai/gpt-6.1-sol',text:'请使用问题工具向我询问一次公开样例名称，可选 Cedar 或 Iris，也允许自定义文本。等待我在界面回答后，用中文准确复述我的完整答案，然后结束。本轮仅核对问题交互，不读取或修改文件。'}
 await record('global-chat-start-request.json',request)
 const accepted=await api('/global/chat/start','POST',request);await record('global-chat-start-response.json',accepted)
 assert.equal(accepted.status,202);assert.equal(accepted.result.requestID,request.requestID)
 const session=accepted.result.session
 const ready={occurrence:owner.occurrence,sessionID:session.id,projectID:session.projectID,directory:session.directory,initialMessageID:accepted.result.messageID,nativeDeadlineAt:owner.nativeDeadlineAt,closeBy,url:base+'/ui',request}
 await record('ready.json',ready);console.log(JSON.stringify(ready))
}else{
 const ready=await read('ready.json');assert.equal(ready.occurrence,owner.occurrence)
 const [questions,messages,conversation]=await Promise.all(['/question',`/session/${ready.sessionID}/message`,`/session/${ready.sessionID}/conversation`].map(route=>api(route,'GET',undefined,ready.directory)))
 for(const response of [questions,messages,conversation])assert.equal(response.status,200)
 const output=`observation-${Date.now()}.json`;await record(output,{ready,questions,messages,conversation})
 if(mode==='observe'){console.log(JSON.stringify({output,pending:questions.result.filter(x=>x.sessionID===ready.sessionID),messageStates:messages.result.map(x=>({id:x.info.id,role:x.info.role,finish:x.info.finish})),closeBy}))}else{
 assert(answer)
 const tool=messages.result.flatMap(message=>message.parts.map(part=>({message,part}))).find(x=>x.part.type==='tool'&&x.part.tool==='question')
 assert(tool);assert.equal(tool.message.info.parentID,ready.initialMessageID);assert.equal(tool.part.state.status,'completed');assert.deepEqual(tool.part.state.metadata.answers,[[answer]])
 const final=messages.result.findLast(x=>x.info.role==='assistant'&&x.info.parentID===ready.initialMessageID&&x.info.finish==='stop'&&Number.isFinite(x.info.time.completed))
 assert(final);assert.equal(final.info.providerID,'openai');assert.equal(final.info.modelID,'gpt-6.1-sol');assert.deepEqual(final.info.acceptedInputMessageIDs,[ready.initialMessageID]);assert.equal(conversation.result.board.status,'idle')
 const files=(await fs.readdir(owner.evidence)).filter(x=>/^provider-.*-\d+\.json$/.test(x))
 const audits=await Promise.all(files.map(async name=>({name,value:JSON.parse(await fs.readFile(path.join(owner.evidence,name),'utf8'))})))
 audits.sort((a,b)=>Date.parse(a.value.observedAt)-Date.parse(b.value.observedAt)||Number(a.name.match(/-(\d+)\.json$/)[1])-Number(b.name.match(/-(\d+)\.json$/)[1]))
 const audit=audits.at(-1)?.value;assert(audit);assert.equal(audit.pid,owner.nativeTarget.pid);assert.equal(audit.maxRequests,20);assert.equal(audit.exhausted,false);assert(audit.requests.length>0&&audit.requests.length<=20)
 const requests=audit.requests.map(x=>({model:x.model,streaming:x.streaming,status:x.status,readerState:x.response_reader?.state,terminal:x.response_reader?.terminal?.kind,sessionID:x.response_reader?.requestContext?.sessionID}))
 for(const x of requests)assert.deepEqual({model:x.model,streaming:x.streaming,status:x.status,reader:x.readerState,terminal:x.terminal},{model:'gpt-6.1-sol',streaming:true,status:200,reader:'settled',terminal:'eof'})
 assert(requests.some(x=>x.sessionID===ready.sessionID))
 const check={observedAt:new Date().toISOString(),occurrence:owner.occurrence,sessionID:ready.sessionID,projectID:ready.projectID,toolMessageID:tool.message.info.id,toolCallID:tool.part.callID,answers:tool.part.state.metadata.answers,assistantID:final.info.id,answer:final.parts.filter(x=>x.type==='text').map(x=>x.text).join('\n'),model:'openai/gpt-6.1-sol',requests,status:'idle',boundary:'Actual native HTTP/Question Tool/model final; Root manually reviews answer and page, then original lifecycle must settle'}
 await record('live-check.json',check);console.log(JSON.stringify(check))
 }
}
