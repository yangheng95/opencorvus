# Scope08 Engine Git baseline failure：只读候选调查

## Recall 与范围

Root 在 402 已完成范围提交后授权调查 `manual-after-08` 的真实 `engine-git / prepare-baseline / fatal: '$GIT_DIR' too big`，要求根据实际输入、路径、参数传递、环境名、退出与公共错误合同分析，不以“长路径”名称直接定因，不缩短路径绕行。本轮只写本文；没有运行测试、Git 写操作、服务、模型、浏览器或凭据读取，没有修改生产、配置、helper、SDK 或冻结 402 报告，没有再次委托。

已读原始公开 Task 创建请求/202 回执、ready、完整 entries observation、实际 helper 源码快照、stderr、runtime owner；当前 `engine/git.ts`、`engine/git-process.ts`、`util/git.ts`、`util/process.ts`、`engine/state.ts`、`orchestrator/loop.ts`、GlobalCreationAllocation/ImplicitProject、隔离 runtime primitive、相关 Git 后台测试；全仓搜索 EngineGit/EngineGitProcess、hostGit/taskGit/gitProcessArgs、显式 `--git-dir` 与 GIT_DIR/GIT_WORK_TREE，查相关历史及当前 Task 架构。所有命令只读，唯一执行的 Git 非仓库观察命令为 `git --version`。

## 收敛结论

值得下一批验证的单一候选是：**EngineGit 将已经冻结的 Git 管理目录无条件以绝对 `--git-dir` 传给 Git；Git for Windows 2.45.1 的显式目录启动路径有独立长度拒绝，`core.longPaths=true` 并不控制这条检查。** 这解释了 cwd-only discovery 成功、冻结 authority 后第一批显式 Git 命令失败的阶段差异。Scope08 的双层隔离 runtime 将普通 `.git` 候选推到 224 字节，恰好越过常规 MinGW 的 220 字节阈值。

但本轮**不是已完成的可执行复现**：原 Scope08 没有保存 Git 子进程完整 argv、其 executable/version、原始数值退出码、实际 `.git` marker 与冻结 git_dir。已清理的 runtime 不可再读，本文不会把推导值写成当时观测值，也不会把当前系统 Git 版本当成原 child 的已保存版本。真实 fork/工作树场景尚需下述 checker 验证后才能批准修复。

## 1. 原始事实、时间与输入

可复核文件均在本报告同目录下的 `manual-after-08/`，其 stderr 为本报告同目录的 `manual-after-08.stderr.log`：

| 事实 | 原始证据 |
| --- | --- |
| `POST /task` 的自然请求 | `task-create-request.json`：`requestID=a5bb1f57-33f1-444f-8034-cb5e5fade221`，Work，明确 `research-studio`，公开受控 `task-fixture/session-prompt-owner-model`；不是伪 Task 或 DB 注入 |
| HTTP 202 与真实 Task | `task-created.json`：`tsk_g00VXxmQGn003mlBGdsM`，Project `prj_h1vZ7H8U1sv4ocr8Xsbs`，观察时间 2026-10-13T20:23:51.786Z |
| baseline 真实错误 | `manual-after-08.stderr.log:585`：20:23:53.406Z，`orchestrator-loop`，同 Task 的 `EngineGit.prepare failed` |
| 错误可见持久化投影 | `entries-observation-1791923085819.json` → `task.board.result.artifacts` 中 `art_g0VXxmQrn00IRj7ncHCS`，kind `task-infrastructure-error`，component `engine-git`，operation `prepare-baseline`，time 1791923033406 |
| Permission 在错误之后 | 同 Board 的唯一 interaction `int_g0VXxmR9r00NnSlnaLgZ` / request `per_hXAZOTTXMHNNjqfHIExC` 创建时间 1791923034525；比 Git 错误晚 1119 ms，后续真实回答 allow_once |
| Task 不是已完成 | 同 Board `task.status=active`、execution epoch 1；已有 402 报告区分后续 outside-root Tool error、无 typed 决策的 exhausted，与此 Git 错误不能互相替代 |

完整错误是：

```text
Failed to capture the startup git checkpoint: Repository-tree checkpoint maintenance failed: Error: Git HEAD inspection failed for repository .: fatal: '$GIT_DIR' too big
```

注意 `Git HEAD inspection failed` 是产品错误前缀，**具体触发来自 `symbolic-ref -q HEAD`，不是 `rev-parse --verify HEAD`**。`engine/git.ts:598–606` 并行等待三个命令后只用 `ref` 的非 0/1 退出构造该消息；`repositoryHead:305–309` 另将自己的非零返回表示成 undefined。本轮不能断言三个 Git 子进程中只有一个失败。

## 2. 路径长度与隔离 owner

对保存的 JSON 做纯字符串长度计算，没有访问原已删除目录或运行 Git 探针。路径均为 ASCII，UTF-8 字节数与 UTF-16 code units 相同：

| 字段 | 长度 | 证据性质 |
| --- | ---: | --- |
| `ready.runtime` | 157 | 原回执值 |
| `ready.session.directory` = Task 202 directory = Board Task directory = Permission working_directory | 219 | 多份原公开回执一致 |
| `path.win32.join(directory, '.git')` | 224 | **候选构造**，实际 marker 类型/realpath/git_dir 未保存 |

Task 根原文：

```text
C:\Users\hengu\AppData\Local\Temp\opencorvus-test-run-AxNAak\runner-88400-ofOno1\runtime-root\tmp\opencorvus-test-run-CGCux7\runner-88804-bGTzlT\runtime-root\data\projects\2026\10\14\e09c4484-72b8-41fa-ba4c-075216766262
```

`manual-after-08.runtime-owner.json` 是外层 `runner-88400-ofOno1`；`ready.runtime` 是内层 `runner-88804-bGTzlT`。保存的 driver:10 与 server:11 均调用 `bootstrapIsolatedTestRuntime('runner')`。该 primitive `packages/util/src/test-runtime-environment.ts:121–137` 仅 role=`test` 才复用 inherited owner；新的 runner 在当前 `os.tmpdir()` 下建立 owner，而外层 `:158–160` 已把 TEMP/TMP/TMPDIR 指向自己 runtime 的 tmp。因此嵌套目录是已证实的 helper 输入结构，不是从错误文案猜出的路径。

这证明 helper 增加了前缀长度，但不能把产品拒绝合法长目录降格为 helper-only：用户长目录、managed worktree 管理目录、snapshot Git 目录均可能形成同样显式参数。也不能未经 owner 分析把 inner runner 改成 test，或将路径缩短后宣布 Git 修复；那会改变隔离/清理所有权且绕过原输入。

## 3. 权威 Git 实现与错误边界

本机只读发现当前 executable 为 `C:\Program Files\Git\cmd\git.exe`，版本 `2.45.1.windows.1`。同版官方源码：

- [Git for Windows setup.c](https://github.com/git-for-windows/git/blob/v2.45.1.windows.1/setup.c#L878-L902)：`setup_explicit_git_dir` 在读取 gitfile / 验证目录之前按 `strlen(gitdirenv) > PATH_MAX - 40` 拒绝。此检查不查询 `core.longpaths`。
- [同版 git.c 参数处理](https://github.com/git-for-windows/git/blob/v2.45.1.windows.1/git.c#L189-L202)：`--git-dir` 和 `--git-dir=...` 被写成 Git 自己的 GIT_DIR；因此错误含环境变量名称不证明父进程注入了该变量。
- [MinGW-w64 limits.h](https://github.com/mingw-w64/mingw-w64/blob/v12.0.0/mingw-w64-headers/crt/limits.h#L9-L18)：通常 PATH_MAX=260，所以该分支阈值为 220。该 header 的 POSIX 分支可重定义，原 Git build 宏未直接观测，不能把 header 本身当原 binary 的完整构建证明。
- [同版 usage.c](https://github.com/git-for-windows/git/blob/v2.45.1.windows.1/usage.c#L68-L74)：默认 fatal die 退出 128。**这是源码合同，原 Scope08 数值 exit 未留存，不补造 128 回执。**
- [同版 Windows path handling](https://github.com/git-for-windows/git/blob/v2.45.1.windows.1/compat/mingw.c#L3657-L3717) 另负责文件系统路径展开；启用 longpaths 不能自动消除 setup.c 的字符串阈值。

据此，224 字节的普通目录候选与真实 stderr、discovery→explicit 阶段完全相符，构成高价值验证候选；原实际 argv/marker 与 binary 证据仍须 fresh bounded checker 补齐。

## 4. 生产路径、argv 与环境（只列名称）

### Task 与 Git authority

1. GlobalChat 的正常分配经 `project/global-creation-allocation.ts:101–109,515–522` → `ImplicitProject.create`，`implicit-project.ts:1201` → `Project.initGit`；Task API `index.ts:1313–1331` 对既有 Project 要求真实 Git，再维护项目元数据。Scope08 202 表示 admission 已成功，不保证后续 baseline 成功。
2. `orchestrator/loop.ts:98–139` 在决策前调用 `EngineGit.prepare(task)`；仅 workspace 首次执行身份错误走特定 terminalFailure。普通 baseline failure 写公开 infrastructure fact，继续真实 Orchestrator pass，这与原 Scope08 随后 Permission 一致。
3. `engine/git.ts:1704–1766` 用真实 Task process binding/root、epoch-keyed immutable checkpoint request；`checkpointWithGitMaintenanceOperation:489–537` 在 Task checkpoint lease + 项目 Git lock 内执行，失败恢复项目 metadata 并返回原因。
4. `checkpointRepositoryTree:1221–1231` 先 `symbolicHeadAt(cwd)`，后 `repositoryAuthority:222–275` 用 fs.realpath 和 cwd-only `rev-parse` 冻结 workspace/git_dir/common_dir/index_path/object_format。`repositoryTarget:299–302` 只取这份 authority。
5. `repositoryStatus:598–606` → `EngineGitProcess.symbolicHead:374–375` → `execute:176–208`，此时才加入绝对 `--git-dir=...` 与 `--work-tree=...`。statuses 在 `:1252–1259`，索引事务 `:1260` 才开始；原错误阶段不能冒称已创建 checkpoint commit。

### 可确定的 argv 模板

这是按真实生产路径重建的模板，**不是已捕获的原子 argv 回执**：

```text
<which('git') executable>
--no-pager
-c core.longPaths=true
-c core.fsmonitor=false
-c maintenance.auto=false
-c maintenance.autoDetach=false
-c gc.auto=0
-c gc.autoDetach=false
-c commit.gpgSign=false
-c diff.external=
--git-dir=<frozen authority.git_dir>
--work-tree=<frozen authority.workspace>
-c core.hooksPath=<owned empty-hooks path>
-c core.attributesFile=<owned empty-attributes path>
-c core.excludesFile=<owned empty-excludes path>
symbolic-ref -q HEAD
```

cwd = frozen workspace；stdin ignore；fast inactivity budget 15000 ms；`nothrow=true`，由调用者解释 0/1/其他退出。`util/process.ts:95–97,133–146,187` 将 exactEnv 与数组 executable/args 送入共有进程门面，不做 shell 拼接。没有读取用户 Git config/凭据以解释这个错误。

`git-process.ts:137–175` 的 Windows exactEnv 名称集合：SystemRoot、COMSPEC、PATHEXT、TEMP、TMP、HOME、USERPROFILE、GIT_CONFIG_NOSYSTEM、GIT_ATTR_NOSYSTEM、GIT_TERMINAL_PROMPT、GIT_PAGER、LC_ALL、LANG（只含实际定义的 OS 项）。本次 symbolicHead 没有 indexFile/identity，故额外 GIT_INDEX_FILE 和 GIT_AUTHOR_NAME/GIT_AUTHOR_EMAIL/GIT_COMMITTER_NAME/GIT_COMMITTER_EMAIL 分支不适用。**父输入无 GIT_DIR/GIT_WORK_TREE，Git 由 argv 自行设置。** 本文不采集或写环境值。

## 5. 横向影响与当前恢复合同

| 生产域 | 同一机制/差异 | 本轮可判定边界 |
| --- | --- | --- |
| EngineGit baseline/result/acceptance | `EngineGitProcess` 的显式 repository 词汇包括 HEAD/ref/subject/conflicts、枚举、raw blob 导入、index/tree/commit、CAS ref、恢复删除；全走 execute 同一绝对参数 | Windows 显式 Git 管理目录是共同输入风险，不限 Research Studio |
| Task 正常终态 | `engine/state.ts:122–133` 对非取消、非特定 pre-execution failure 的终态先 prepare，再 complete；错误明确 throw | baseline 缺失会阻止成功/失败结果 checkpoint 收敛，不能靠继续 LLM 输出证明终态已好 |
| Task retry/restart/epoch | `git.ts:1393–1407,1708–1712,1740–1757` 从唯一 request/outcome 重放同 epoch；错误也持久化，非偷偷再执行。新 epoch 重新计算；unknown outcome 要权威对账 | 改 Git 参数不会自动修复已持久失败的同一 epoch；下一阶段要验证当前恢复合同，不清除/改写旧结果 |
| Mission/worker/CLI/Panel/API | Task 创建入口最终共享 Task binding/Orchestrator/terminalTask；Mission 产生的 Task 同样经过；普通 Chat/SideChat 本身不执行 Task baseline | 不把该错误归于单一包/模型；也不外推所有 Chat 都会失败 |
| 串并行/多 Project | Task checkpoint lease 和项目 Git lock 未改变，冻结 authority 绑定具体 root，finally/rollback 源路径明确 | 原发生在 repository status 阶段；无证据说明 queue、epoch 或 owner 混淆。本轮静态横审不能替代多 Project fresh checker |
| 源树枚举 | `execution-capsule/tree-digest.ts:318–332,366–374` 调 EngineGitProcess cwd-only discovery/sourceSnapshotPaths | 不自动加入显式 git-dir，解释为何 source admission 可通过；仍需合法目录/真实字节合同 |
| 其他显式 Git 管理目录 | `snapshot/index.ts` 多处 `--git-dir` 及 init 的 GIT_DIR/GIT_WORK_TREE；`engine/build-observation-ref.ts:17`，`build-observation-cleanup.ts:146–159` | 同样可能触发上游显式目录阈值；当前未实际触发。Build cleanup/recovery 不得因新 workaround 放宽 exact owner |
| 一般 Git 工具链 | 14 个消费文件引用 hostGit/taskGit/gitProcessArgs：config、build/agent、file/index、build-observation-ref/content/cleanup、worktree/index/gc、skill/manager、project/vcs/project、task-project-archive、task-artifact/store、snapshot/index；另 1 个 util/git 定义文件，共 15 个搜索命中文件。EngineGit 独立封闭词汇 | shared util/git:40–49 已给 owned Git 开 longPaths，但不消除显式目录检查。多数 cwd-only 命令不等于已证明同一故障 |

没有发现本 scope 的新调度/恢复异常事实；发现的是 Git 输送表示和已知 checkpoint 错误传播。由于正常 terminalTask 依赖 checkpoint，下一阶段仍须按共享 Task/Mission/epoch/recovery/并行 Project 范围验，而不能仅让一个 standalone `symbolic-ref` 成功就收尾。

## 6. 历史与已有覆盖

- `65d0bfc98` 中 `util/git.ts` 已声明 process-local core.longPaths，非本批权限新增。
- `a94d80c3e`（2026-08-08，`fix(engine): batch raw Git checkpoints`）保留/建立当前封闭 Git vocabulary、raw byte 流式导入、冻结 repository authority 和绝对 `--git-dir`；此次读取该 commit 的 execute 与现路径一致。它解决 filters/环境/raw import 及批量事务，不能据此声称覆盖 Windows 显式路径阈值。
- `627146cc3` 等将 Task 控制/检查点收敛为不可变事实；当前 `specs/current/architecture/task-control-plane.md:296–298` 明确 checkpoint request/outcome 唯一权威与未知结果不可自动重放；`task-runtime-directory.md` 明确目录由单一 owner/path constructor 构造，不能为测试短路径另造产品布局。
- 搜索命中月度索引中 `2026-08-08-engine-git-batched-raw-checkpoint-repair-plan.md` 的条目，但当前文件不存在，Git 路径历史查询也无结果；未重建该旧记录，也不以索引文字当完整历史方案。可验证历史以真实 commit 为准。
- 只读检查了 `engine-git-safe-environment.test.ts`（正常过滤/真实字节/隔离环境）、`engine-git-batched-raw-import`、`batched-transaction`、`batched-scale`、`fact-reconciliation` 的公开合同。当前没有检索到显式 Git 目录的 220/224 边界正向用例；未运行任何测试。
- `engine-git-fact-reconciliation.test.ts:127` 仍有 `baseline.toBeUndefined()` 的负向核心旁断言。若下一阶段触及该测试，应按 AGENTS 改为当前正向 immutable outcome/明确错误合同；本轮禁止测试修改，故仅报告。不涉及 UI 自动测试，本轮没有运行 UI 测试。

## 7. 建议下一阶段 checker（尚未授权或执行）

1. 先落独立 spec，再只建自有公开 scratch 仓库；保留原合法长目录，不改 OS、Git 全局配置、不做短路径/junction/8.3 规避。所有进程进入既有 Process owner，固定总期限及逐 command 原 timeout，finally join output/request/physical，然后由父 owner 清理自己目录。保存 executable/version、exact cwd/argv、**env key names only**、marker 类型、git_dir/common_dir 的真实输出与 UTF-8 长度、每个 exit/stdout/stderr；禁止 env dump。
2. 最小只读链：已正常初始化的公开 repo 中走真实 `EngineGitProcess.symbolicHeadAt`/absoluteGitDirectory，再对同一个真实 authority 调 `symbolicHead`；覆盖 ordinary `.git` directory、managed-worktree `.git` file、nested repo，输入长度在阈值两侧，并有中文路径按 UTF-8 字节数验证。失败必须匹配实际 Git exit 与原错误，不能只匹配文案。
3. 根因成立后，评估**在唯一参数边界表达同一个冻结目录 authority**的可行编码；任何相对表示或改变 Git cwd 的方案必须验证根仓库/外置管理目录/跨盘/全部命令 pathspec 与 recovery 等价。不可删除 frozen target、退回 cwd 搜索、异常时换策略、copy repo、改短路径或把 longPaths 重加一次当修复。本轮没有选定实现，也没有批准新 shared primitive。
4. 正向合同应进入 `EngineGit.prepare`→真实 checkpoint request/outcome→公开 artifact/read bytes，并能正常 `complete`；分别验证原字节、准确 ref/commit 身份及末态。现有 safe-environment/batched-transaction/fact-reconciliation 可提供生产 fixture 原语；fixture 不能伪称 HTTP 或模型端到端。
5. 对全链追加真实普通公开 Task admission→受控流式参与者自然 typed control→正常 terminal checkpoint，至少两 Project 并行、同 epoch replay、new epoch/restart recovery、managed worktree 和取消合同。不得修改老失败 outcome 以制造 pass。是否需要真实 GPT-6.1 Sol/UI 由 Root 在产品修法范围明确后决定。

## 未达成与交接

原 Scope08 已关闭清理。本轮没有重建 runtime、没有读取原 DB/auth/models。**尚未取得原 Git child exact argv/numeric exit/frozen directory，也没有运行 fresh checker；目前是强证据候选，不是产品修复或完整验收。** 本文仅新增一个 scratch 调查文件；冻结 402 文档、产品与测试均未改。所有只读命令已正常返回，较长只读命令 exec 5562 已 join exit 0。
