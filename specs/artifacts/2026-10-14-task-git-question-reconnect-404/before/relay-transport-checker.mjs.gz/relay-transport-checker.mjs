import assert from 'node:assert/strict'
import http from 'node:http'
import fs from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { spawn } from 'node:child_process'
import { randomUUID } from 'node:crypto'
import { gzipSync } from 'node:zlib'
import { sendRelayControl } from './relay-control.mjs'

const directory = path.dirname(fileURLToPath(import.meta.url))
const runID = `relay-check-${Date.now()}`
const evidence = path.join(directory, runID)
const scope = path.join(directory, `${runID}-owner`)
await fs.mkdir(evidence, { recursive: false })
const startedAt = Date.now(), deadlineAt = startedAt + 120_000, closeBy = deadlineAt - 30_000
const requestFacts = []
const activeResponses = new Map()
const upstreamSockets = new Set()
const rawBody = Buffer.from([0, 255, 13, 10, 128, 65, 0, 90])
const chunks = [Buffer.from('event: public\ndata: {"text":"'), Buffer.from('中文🙂'), Buffer.from('"}\n\n')]
const compressed = gzipSync(Buffer.from('public raw compressed bytes 中文\n'))
let sseNumber = 0
const upstream = http.createServer((request, response) => {
  const collected = []
  request.on('data', chunk => collected.push(chunk))
  request.on('end', () => {
    requestFacts.push({ method: request.method, url: request.url, headers: request.headers, rawHeaders: request.rawHeaders,
      body: Buffer.concat(collected).toString('base64') })
    if (request.url.startsWith('/session/')) {
      const number = ++sseNumber
      response.writeHead(200, { 'content-type': 'text/event-stream', 'cache-control': 'no-cache', 'x-public-stream': String(number) })
      activeResponses.set(number, response)
      response.on('close', () => activeResponses.delete(number))
      response.write(chunks[0])
      return
    }
    if (request.url === '/compressed') {
      response.writeHead(200, { 'content-type': 'application/octet-stream', 'content-encoding': 'gzip', 'content-length': compressed.length })
      response.end(compressed); return
    }
    response.writeHead(207, ['Content-Type', 'application/octet-stream', 'X-Public-Response', 'header-value',
      'Set-Cookie', 'public-a=1; Path=/', 'Set-Cookie', 'public-b=2; Path=/'])
    response.end(Buffer.concat(collected))
  })
})
upstream.on('connection', socket => { upstreamSockets.add(socket); socket.on('close', () => upstreamSockets.delete(socket)) })
await new Promise(resolve => upstream.listen(0, '127.0.0.1', resolve))
const upstreamURL = `http://127.0.0.1:${upstream.address().port}`
const config = { scope, upstream: upstreamURL, ownerPID: process.pid, ownerOccurrence: randomUUID(), deadlineAt, closeBy }
const configPath = path.join(evidence, 'relay-config.json')
await fs.writeFile(configPath, JSON.stringify(config, null, 2))
await fs.writeFile(path.join(evidence, 'command.json'), JSON.stringify({ executable: process.execPath, version: process.version,
  cwd: directory, argv: [path.join(directory, 'relay-driver.mjs'), configPath], config }, null, 2))
const child = spawn(process.execPath, [path.join(directory, 'relay-driver.mjs'), configPath], { cwd: directory, windowsHide: true,
  env: Object.fromEntries(['SystemRoot', 'WINDIR', 'PATH', 'TEMP', 'TMP'].flatMap(key => process.env[key] ? [[key, process.env[key]]] : [])), stdio: ['ignore', 'pipe', 'pipe'] })
const stdout = [], stderr = []
child.stdout.on('data', chunk => stdout.push(chunk)); child.stderr.on('data', chunk => stderr.push(chunk))
const joined = new Promise((resolve, reject) => { child.once('error', reject); child.once('close', (code, signal) => resolve({ code, signal, pid: child.pid, at: Date.now() })) })
const requests = new Set()
async function waitForFile(filename) {
  while (Date.now() < closeBy) {
    try { return JSON.parse(await fs.readFile(filename, 'utf8')) } catch (error) { if (error.code !== 'ENOENT') throw error }
    await new Promise(resolve => setTimeout(resolve, 20))
  }
  throw new Error('Original checker closeBy reached before ready')
}
function open(url, options = {}, body) {
  const chunksSeen = []
  let firstResolve, closedResolve, responseResolve
  const first = new Promise(resolve => { firstResolve = resolve })
  const closed = new Promise(resolve => { closedResolve = resolve })
  const responsePromise = new Promise(resolve => { responseResolve = resolve })
  const request = http.request(url, { ...options, agent: false })
  requests.add(request)
  request.on('close', () => requests.delete(request))
  request.on('error', error => closedResolve({ kind: 'request-error', code: error.code }))
  request.on('response', response => {
    responseResolve(response)
    response.on('data', chunk => { chunksSeen.push(chunk); firstResolve() })
    response.on('aborted', () => closedResolve({ kind: 'aborted' }))
    response.on('error', error => closedResolve({ kind: 'response-error', code: error.code }))
    response.on('end', () => closedResolve({ kind: 'ended' }))
  })
  request.end(body)
  return { request, first, closed, responsePromise, bytes: () => Buffer.concat(chunksSeen) }
}
const steps = []
let outcome
try {
  const ready = await waitForFile(path.join(scope, 'ready.json'))
  const ordinary = open(ready.url + '/public/%2Fkeep?value=a%2Bb&second=%E4%B8%AD', {
    method: 'PATCH', headers: { 'content-type': 'application/octet-stream', 'content-length': rawBody.length, 'x-public-request': 'preserve me' } }, rawBody)
  const ordinaryResponse = await ordinary.responsePromise
  assert.equal((await ordinary.closed).kind, 'ended')
  assert.equal(ordinaryResponse.statusCode, 207)
  assert.equal(ordinaryResponse.headers['x-public-response'], 'header-value')
  assert.deepEqual(ordinaryResponse.headers['set-cookie'], ['public-a=1; Path=/', 'public-b=2; Path=/'])
  assert.deepEqual(ordinary.bytes(), rawBody)
  assert.deepEqual(requestFacts[0], { ...requestFacts[0], method: 'PATCH', url: '/public/%2Fkeep?value=a%2Bb&second=%E4%B8%AD', body: rawBody.toString('base64') })
  assert.equal(requestFacts[0].headers['x-public-request'], 'preserve me')
  steps.push({ contract: 'method-path-query-body-end-to-end-headers', status: 'passed', method: 'PATCH', path: requestFacts[0].url, bodyBytes: rawBody.length, responseStatus: 207 })
  const encoded = open(ready.url + '/compressed')
  const encodedResponse = await encoded.responsePromise
  assert.equal((await encoded.closed).kind, 'ended')
  assert.equal(encodedResponse.headers['content-encoding'], 'gzip')
  assert.equal(Number(encodedResponse.headers['content-length']), compressed.length)
  assert.deepEqual(encoded.bytes(), compressed)
  steps.push({ contract: 'compressed-wire-body-preserved', status: 'passed', bytes: compressed.length })
  const target = open(ready.url + '/session/ses_Relay404/events?directory=D%3A%2Fpublic&stream_id=first')
  const targetResponse = await target.responsePromise
  await target.first
  assert.deepEqual(target.bytes(), chunks[0])
  assert.equal(targetResponse.headers['content-type'], 'text/event-stream')
  const unrelated = open(ready.url + '/session/ses_Other404/events?directory=D%3A%2Fpublic')
  const otherResponse = await unrelated.responsePromise
  await unrelated.first
  const targetNumber = Number(targetResponse.headers['x-public-stream'])
  const otherNumber = Number(otherResponse.headers['x-public-stream'])
  const cut = await sendRelayControl(scope, 'cut', 'ses_Relay404')
  assert.equal(cut.result.cutCount, 1)
  assert.equal((await target.closed).kind, 'aborted')
  activeResponses.get(otherNumber).end(Buffer.concat(chunks.slice(1)))
  assert.equal((await unrelated.closed).kind, 'ended')
  assert.deepEqual(unrelated.bytes(), Buffer.concat(chunks))
  steps.push({ contract: 'exact-session-stream-cut-with-other-stream-completion', status: 'passed', cut, targetNumber, otherNumber })
  const reopened = open(ready.url + '/session/ses_Relay404/events?directory=D%3A%2Fpublic&stream_id=second')
  const reopenedResponse = await reopened.responsePromise
  await reopened.first
  assert.deepEqual(reopened.bytes(), chunks[0])
  const nextNumber = Number(reopenedResponse.headers['x-public-stream'])
  assert.equal(nextNumber, 3)
  activeResponses.get(nextNumber).write(chunks[1].subarray(0, 2))
  activeResponses.get(nextNumber).end(Buffer.concat([chunks[1].subarray(2), chunks[2]]))
  assert.equal((await reopened.closed).kind, 'ended')
  assert.deepEqual(reopened.bytes(), Buffer.concat(chunks))
  steps.push({ contract: 'fresh-stream-and-split-unicode-raw-bytes', status: 'passed', nextNumber, bytes: reopened.bytes().length,
    firstChunkObservedBeforeUpstreamCompletion: true })
  const shutdown = await sendRelayControl(scope, 'shutdown')
  assert.equal(shutdown.result.status, 'closed')
  const childResult = await joined
  assert.deepEqual({ code: childResult.code, signal: childResult.signal }, { code: 0, signal: null })
  const terminal = JSON.parse(await fs.readFile(path.join(scope, 'terminal.json'), 'utf8'))
  assert.equal(terminal.status, 'closed')
  assert.equal(terminal.reason, 'manual-control-shutdown')
  assert.ok(terminal.finishedAt < closeBy)
  steps.push({ contract: 'original-owner-normal-shutdown-and-physical-join', status: 'passed', childResult, terminal })
  outcome = { status: 'passed', startedAt, finishedAt: Date.now(), steps, requestFacts, scope, evidence,
    verification: 'Positive Node raw HTTP byte/transport checks only; no browser, DOM, UI, model or credentials' }
} catch (error) {
  outcome = { status: 'failed', startedAt, failedAt: Date.now(), steps, requestFacts, error: { name: error.name, message: error.message, stack: error.stack }, scope, evidence }
  process.exitCode = 1
} finally {
  for (const request of requests) request.destroy()
  try { await fs.access(path.join(scope, 'terminal.json')) }
  catch { await fs.writeFile(path.join(scope, 'stop-requested'), 'Original checker cleanup\n').catch(() => {}) }
  outcome.join = await joined
  for (const response of activeResponses.values()) response.destroy()
  const upstreamClosed = new Promise((resolve, reject) => upstream.close(error => error ? reject(error) : resolve()))
  for (const socket of upstreamSockets) socket.destroy()
  await upstreamClosed
  outcome.upstreamClosedAt = Date.now()
  await fs.writeFile(path.join(evidence, 'stdout.log'), Buffer.concat(stdout))
  await fs.writeFile(path.join(evidence, 'stderr.log'), Buffer.concat(stderr))
  await fs.writeFile(path.join(evidence, 'result.json'), JSON.stringify(outcome, null, 2))
  await fs.writeFile(path.join(directory, 'relay-check-latest.json'), JSON.stringify({ evidence, scope, status: outcome.status }, null, 2))
  console.log(JSON.stringify({ status: outcome.status, contracts: steps.length, evidence, scope, join: outcome.join, upstreamClosedAt: outcome.upstreamClosedAt }))
}
