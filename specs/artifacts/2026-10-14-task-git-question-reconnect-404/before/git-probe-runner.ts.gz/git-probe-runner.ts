import fs from "node:fs/promises"
import path from "node:path"
import os from "node:os"
import { NodeProcess } from "../packages/util/src/process-node"
import { expectedTestProcessSupervisor } from "../packages/opencorvus/script/test-process-supervisor"

const scope = path.resolve(process.argv[2] ?? "")
const parent = path.resolve(".tmp-task-git-question-reconnect-404")
if (path.dirname(scope) !== parent || !path.basename(scope).startsWith("git-probe-")) throw Error("Explicit fresh 404 Git scope required")
await fs.mkdir(scope, { recursive: false })
const supervisor = expectedTestProcessSupervisor()
if (!supervisor || !(await fs.stat(supervisor)).isFile()) throw Error("Existing supervisor required; no build in probe")
process.env.OPENCORVUS_PROCESS_SUPERVISOR = supervisor
const git = Bun.which("git")
if (!git || !path.isAbsolute(git)) throw Error("Installed absolute Git required")
const crossRoot = await fs.mkdtemp(path.join(os.tmpdir(), "opencorvus-404-git-"))
if (path.parse(crossRoot).root.toLowerCase() === path.parse(scope).root.toLowerCase()) throw Error("Actual different-volume owner required")
const startedAt = Date.now(), deadlineAt = startedAt + 300000, workerDeadlineAt = startedAt + 270000
const env = Object.fromEntries(Object.entries(process.env).filter(([key]) => /^(PATH|SystemRoot|WINDIR|ComSpec|PATHEXT|TEMP|TMP|TMPDIR)$/i.test(key)))
env.OPENCORVUS_PROCESS_SUPERVISOR = supervisor
const facts: any = { startedAt, deadlineAt, workerDeadlineAt, controllerPID: process.pid, scope, crossRoot, executable: process.execPath, gitExecutable: git, supervisor, environmentNames: Object.keys(env).sort() }
await fs.writeFile(path.join(scope, "owner.json"), JSON.stringify(facts, null, 2))
let handle: any
try {
  const result = await NodeProcess.run({ command: { executable: process.execPath, args: [path.resolve(".tmp-task-git-question-reconnect-404/git-probe-worker.ts"), scope, crossRoot, git, String(workerDeadlineAt)] }, cwd: process.cwd(), env, ownership: "owned_tree", windowsHide: true, stdin: "ignore", deadlineAt, nothrow: true, onSpawned(h) { handle = h; facts.workerPID = h.pid; facts.workerOccurrence = h.occurrenceID } })
  facts.receipt = result.receipt
  await fs.writeFile(path.join(scope, "worker.stdout.log"), result.stdout)
  await fs.writeFile(path.join(scope, "worker.stderr.log"), result.stderr)
  await handle.outputSettled
  await handle.settled
  facts.physicalJoined = true; facts.outputJoined = true; facts.requestSettled = true
  process.exitCode = result.receipt.exitCode ?? 1
} catch (error) {
  facts.error = String(error)
  process.exitCode = 1
  if (handle) { facts.receipt = await handle.settled; await handle.outputSettled; facts.physicalJoined = true; facts.outputJoined = true }
} finally {
  if (facts.physicalJoined && facts.outputJoined) {
    const data = path.resolve(scope, "owned-data")
    if (path.dirname(data) !== scope || path.dirname(crossRoot) !== path.resolve(os.tmpdir()) || !path.basename(crossRoot).startsWith("opencorvus-404-git-")) throw Error("Cleanup target escaped exact owners")
    await fs.rm(data, { recursive: true, force: true })
    await fs.rm(crossRoot, { recursive: true, force: true })
    facts.cleanup = { ownedDataRemoved: true, crossVolumeRootRemoved: true, afterPhysicalJoin: true }
  }
  facts.endedAt = Date.now()
  await fs.writeFile(path.join(scope, "owner.json"), JSON.stringify(facts, null, 2))
  console.log(JSON.stringify(facts))
}
