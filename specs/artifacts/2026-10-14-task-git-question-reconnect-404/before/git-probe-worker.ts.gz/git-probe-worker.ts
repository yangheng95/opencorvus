import fs from "node:fs/promises"
import path from "node:path"
import assert from "node:assert/strict"
import { NodeProcess } from "../packages/util/src/process-node"

const [scope, crossRoot, git, rawDeadline] = process.argv.slice(2)
if (![scope, crossRoot, git].every((x) => x && path.isAbsolute(x))) throw Error("Explicit absolute owners/executable required")
const deadlineAt = Number(rawDeadline)
if (!Number.isSafeInteger(deadlineAt) || deadlineAt <= Date.now()) throw Error("Original deadline required")
const dataRoot = path.join(scope, "owned-data")
const runtime = path.join(dataRoot, "git-runtime")
await fs.mkdir(runtime, { recursive: true })
for (const name of ["home", "empty-hooks", "tmp"]) await fs.mkdir(path.join(runtime, name))
for (const name of ["empty-attributes", "empty-excludes"]) await fs.writeFile(path.join(runtime, name), "")
const env = Object.fromEntries(Object.entries({
  SystemRoot: process.env.SystemRoot, COMSPEC: process.env.COMSPEC, PATHEXT: process.env.PATHEXT,
  TEMP: path.join(runtime, "tmp"), TMP: path.join(runtime, "tmp"),
  HOME: path.join(runtime, "home"), USERPROFILE: path.join(runtime, "home"),
  GIT_CONFIG_NOSYSTEM: "1", GIT_ATTR_NOSYSTEM: "1", GIT_TERMINAL_PROMPT: "0", GIT_PAGER: "cat", LC_ALL: "C", LANG: "C",
}).filter((entry): entry is [string, string] => typeof entry[1] === "string"))
const fixed = ["--no-pager", "-c", "core.longPaths=true", "-c", "core.fsmonitor=false", "-c", "maintenance.auto=false", "-c", "maintenance.autoDetach=false", "-c", "gc.auto=0", "-c", "gc.autoDetach=false", "-c", "commit.gpgSign=false", "-c", "diff.external=", "-c", `core.hooksPath=${path.join(runtime, "empty-hooks")}`, "-c", `core.attributesFile=${path.join(runtime, "empty-attributes")}`, "-c", `core.excludesFile=${path.join(runtime, "empty-excludes")}`]
const facts: any = { encoding: "git-C-frozen-admin-parent-and-basename", startedAt: Date.now(), deadlineAt, workerPID: process.pid, executable: git, environmentNames: Object.keys(env).sort(), cases: [], commands: [] }
let sequence = 0
const write = () => fs.writeFile(path.join(scope, "facts.json"), JSON.stringify(facts, null, 2))
async function command(label: string, cwd: string, args: string[], options: { input?: Buffer; indexFile?: string; identity?: boolean } = {}) {
  if (Date.now() >= deadlineAt) throw Error("Original worker deadline reached before command admission")
  const commandEnv = { ...env, ...(options.indexFile ? { GIT_INDEX_FILE: options.indexFile } : {}), ...(options.identity ? { GIT_AUTHOR_NAME: "Public 404 Fixture", GIT_AUTHOR_EMAIL: "public-404@example.invalid", GIT_COMMITTER_NAME: "Public 404 Fixture", GIT_COMMITTER_EMAIL: "public-404@example.invalid" } : {}) }
  const item: any = { sequence: ++sequence, label, executable: git, cwd, argv: [...fixed, ...args], environmentNames: Object.keys(commandEnv).sort(), inputBytesBase64: options.input?.toString("base64"), externalIndexPath: options.indexFile, startedAt: Date.now(), deadlineAt: Math.min(deadlineAt, Date.now() + 15000) }
  facts.commands.push(item)
  await write()
  let handle: any
  try {
    const result = await NodeProcess.run({ command: { executable: git, args: item.argv }, cwd, env: commandEnv, ownership: "owned_tree", windowsHide: true, stdin: options.input ? "pipe" : "ignore", input: options.input, deadlineAt: item.deadlineAt, nothrow: true, onSpawned(h) { handle = h; item.pid = h.pid; item.occurrenceID = h.occurrenceID } })
    item.receipt = result.receipt
    item.stdout = Buffer.from(result.stdout).toString()
    item.stdoutBytesBase64 = Buffer.from(result.stdout).toString("base64")
    item.stderr = Buffer.from(result.stderr).toString()
    await handle.outputSettled
    await handle.settled
    item.physicalJoined = true
    item.outputJoined = true
    item.requestSettled = true
    return item
  } catch (error) {
    item.error = String(error)
    if (handle) { item.receipt = await handle.settled; await handle.outputSettled; item.physicalJoined = true; item.outputJoined = true }
    throw error
  } finally { item.endedAt = Date.now(); await write() }
}
async function good(label: string, cwd: string, args: string[], options: { input?: Buffer; indexFile?: string; identity?: boolean } = {}) {
  const result = await command(label, cwd, args, options)
  assert.equal(result.receipt.exitCode, 0, `${label}: ${result.stderr}`)
  return result
}
function padded(base: string, name: string, length = 219) {
  let result = path.join(base, name)
  while (result.length < length) {
    const remaining = length - result.length - 1
    if (remaining < 1) throw Error("Cannot represent exact path length")
    result = path.join(result, "p".repeat(Math.min(remaining, 40)))
  }
  assert.equal(result.length, length)
  return result
}
async function init(cwd: string, admin?: string) {
  await fs.mkdir(cwd, { recursive: true })
  if (admin) await fs.mkdir(path.dirname(admin), { recursive: true })
  await good("init", cwd, ["init", "--initial-branch=main", ...(admin ? [`--separate-git-dir=${admin}`] : [])])
  await fs.mkdir(path.join(cwd, "sub"))
  await fs.writeFile(path.join(cwd, "public.txt"), "PUBLIC-404\n")
  await fs.writeFile(path.join(cwd, "sub", "child.txt"), "CHILD-404\n")
  await good("add-public", cwd, ["add", "--", "public.txt", "sub/child.txt"])
  await good("commit-public", cwd, ["-c", "user.name=Public 404 Fixture", "-c", "user.email=public-404@example.invalid", "commit", "-m", "Public 404 fixture"])
}
async function inspect(label: string, cwd: string, expectedAbsoluteExit: number, expectedCandidateExit = 0) {
  const item: any = { label, cwd, cwdBytes: Buffer.byteLength(cwd) }
  facts.cases.push(item)
  const workspace = await fs.realpath(cwd)
  const marker = path.join(workspace, ".git")
  const stat = await fs.lstat(marker)
  item.marker = { path: marker, kind: stat.isDirectory() ? "directory" : stat.isFile() ? "file" : "other", realpath: await fs.realpath(marker), ...(stat.isFile() ? { contents: await fs.readFile(marker, "utf8") } : {}) }
  const gitdir = await good(`${label}:discover-admin`, workspace, ["rev-parse", "--absolute-git-dir"])
  const common = await good(`${label}:discover-common`, workspace, ["rev-parse", "--git-common-dir"])
  const index = await good(`${label}:discover-index`, workspace, ["rev-parse", "--git-path", "index"])
  const format = await good(`${label}:discover-format`, workspace, ["rev-parse", "--show-object-format"])
  item.authority = { workspace, gitDir: await fs.realpath(path.resolve(workspace, gitdir.stdout.trim())), commonDir: await fs.realpath(path.resolve(workspace, common.stdout.trim())), indexPath: await fs.realpath(path.resolve(workspace, index.stdout.trim())), objectFormat: format.stdout.trim() }
  item.gitDirBytes = Buffer.byteLength(item.authority.gitDir)
  item.relativeGitDir = path.relative(workspace, item.authority.gitDir) || "."
  item.relativeIsAbsolute = path.isAbsolute(item.relativeGitDir)
  assert.equal(path.resolve(workspace, item.relativeGitDir).toLowerCase(), item.authority.gitDir.toLowerCase())
  const discovery = await good(`${label}:discovery-ref`, workspace, ["symbolic-ref", "-q", "HEAD"])
  const original = await command(`${label}:absolute-ref`, workspace, [`--git-dir=${item.authority.gitDir}`, `--work-tree=${workspace}`, "symbolic-ref", "-q", "HEAD"])
  assert.equal(original.receipt.exitCode, expectedAbsoluteExit)
  if (expectedAbsoluteExit === 128) assert.match(original.stderr, /fatal: '\$GIT_DIR' too big/)
  const candidate = ["-C", path.dirname(item.authority.gitDir), `--git-dir=${path.basename(item.authority.gitDir)}`, `--work-tree=${workspace}`]
  item.candidate = { processCwd: workspace, gitDirectoryChange: path.dirname(item.authority.gitDir), gitDirArgument: path.basename(item.authority.gitDir), resolvedTarget: await fs.realpath(path.join(path.dirname(item.authority.gitDir), path.basename(item.authority.gitDir))) }
  assert.equal(item.candidate.resolvedTarget, item.authority.gitDir)
  const encoded = await command(`${label}:candidate-ref`, workspace, [...candidate, "symbolic-ref", "-q", "HEAD"])
  assert.equal(encoded.receipt.exitCode, expectedCandidateExit)
  item.absoluteExit = original.receipt.exitCode
  item.candidateExit = encoded.receipt.exitCode
  if (expectedCandidateExit === 128) {
    assert.match(encoded.stderr, /fatal: '\$GIT_DIR' too big/)
    item.conclusion = "cross-volume path.relative remains absolute; current explicit error preserved, candidate does not solve this boundary"
  } else {
    assert.equal(encoded.stdout, discovery.stdout)
    const paths = await good(`${label}:discovery-pathspec`, workspace, ["ls-files", "--stage", "-z", "--", "."])
    const encodedPaths = await good(`${label}:candidate-pathspec`, workspace, [...candidate, "ls-files", "--stage", "-z", "--", "."])
    assert.equal(encodedPaths.stdout, paths.stdout)
    for (const [file, expected] of [["public.txt", "PUBLIC-404\n"], ["sub/child.txt", "CHILD-404\n"]]) {
      const content = await good(`${label}:candidate-content:${file}`, workspace, [...candidate, "show", `HEAD:${file}`])
      assert.equal(content.stdout, expected)
    }
    const actualAdmin = await good(`${label}:candidate-canonical-admin`, workspace, [...candidate, "rev-parse", "--absolute-git-dir"])
    assert.equal(await fs.realpath(actualAdmin.stdout.trim()), item.authority.gitDir)
    await fs.writeFile(path.join(workspace, "sub", "child.txt"), "CHILD-404-MODIFIED\n")
    const diff = await good(`${label}:discovery-diff`, workspace, ["diff", "--numstat", "HEAD", "--", "."])
    const encodedDiff = await good(`${label}:candidate-diff`, workspace, [...candidate, "diff", "--numstat", "HEAD", "--", "."])
    assert.equal(diff.stdout, "1\t1\tsub/child.txt\n")
    assert.equal(encodedDiff.stdout, diff.stdout)
    const exactPathDiff = await good(`${label}:candidate-exact-pathspec`, workspace, [...candidate, "diff", "--name-only", "HEAD", "--", "sub/child.txt"])
    assert.equal(exactPathDiff.stdout, "sub/child.txt\n")
    await fs.writeFile(path.join(workspace, "sub", "child.txt"), "CHILD-404\n")
    const marks = path.join(runtime, `${label}.marks`)
    const bytes = Buffer.from([0, 1, 10, 255, 65, 13, 10])
    const importInput = Buffer.concat([Buffer.from(`feature done\nblob\nmark :1\ndata ${bytes.length}\n`), bytes, Buffer.from("\ndone\n")])
    await good(`${label}:candidate-fast-import`, workspace, [...candidate, "fast-import", "--quiet", "--done", `--export-marks=${marks}`], { input: importInput })
    const mark = (await fs.readFile(marks, "utf8")).trim().match(/^:1 ([0-9a-f]{40})$/)
    assert.ok(mark)
    const blob = mark[1]
    const checked = await good(`${label}:candidate-cat-file-batch`, workspace, [...candidate, "cat-file", "--batch-check=%(objectname) %(objecttype) %(objectsize)"], { input: Buffer.from(blob + "\n") })
    assert.equal(checked.stdout, `${blob} blob ${bytes.length}\n`)
    const actual = await good(`${label}:candidate-blob-bytes`, workspace, [...candidate, "cat-file", "blob", blob])
    assert.deepEqual(Buffer.from(actual.stdoutBytesBase64, "base64"), bytes)
    const indexFile = path.join(runtime, `${label}.index`)
    await good(`${label}:candidate-read-tree`, workspace, [...candidate, "read-tree", "--empty"], { indexFile })
    await good(`${label}:candidate-update-index`, workspace, [...candidate, "update-index", "-z", "--index-info"], { indexFile, input: Buffer.from(`100644 ${blob}\tgenerated/public.bin\0`) })
    const staged = await good(`${label}:candidate-external-index`, workspace, [...candidate, "ls-files", "--stage", "-z", "--", "."], { indexFile })
    assert.equal(staged.stdout, `100644 ${blob} 0\tgenerated/public.bin\0`)
    const tree = (await good(`${label}:candidate-write-tree`, workspace, [...candidate, "write-tree"], { indexFile })).stdout.trim()
    const parentCommit = (await good(`${label}:candidate-parent`, workspace, [...candidate, "rev-parse", "--verify", "HEAD"])).stdout.trim()
    const commit = (await good(`${label}:candidate-commit-tree`, workspace, [...candidate, "commit-tree", tree, "-p", parentCommit, "-m", "Public 404 object write", "-m", "Explicit frozen target"], { identity: true })).stdout.trim()
    const ref = `refs/opencorvus-probe/${label}`
    const zero = "0".repeat(40)
    await good(`${label}:candidate-ref-write`, workspace, [...candidate, "update-ref", "--no-deref", ref, commit, zero])
    const published = await good(`${label}:candidate-ref-read`, workspace, [...candidate, "show-ref", "--verify", "--hash", ref])
    assert.equal(published.stdout.trim(), commit)
    const publishedTree = await good(`${label}:candidate-tree-read`, workspace, [...candidate, "rev-parse", `${ref}^{tree}`])
    assert.equal(publishedTree.stdout.trim(), tree)
    const publishedBytes = await good(`${label}:candidate-published-bytes`, workspace, [...candidate, "show", `${ref}:generated/public.bin`])
    assert.deepEqual(Buffer.from(publishedBytes.stdoutBytesBase64, "base64"), bytes)
    await good(`${label}:candidate-ref-delete`, workspace, [...candidate, "update-ref", "--no-deref", "-d", ref, commit])
    await good(`${label}:candidate-ref-recreate`, workspace, [...candidate, "update-ref", "--no-deref", ref, commit, zero])
    await good(`${label}:candidate-ref-final-delete`, workspace, [...candidate, "update-ref", "--no-deref", "-d", ref, commit])
    const canonicalIndex = await good(`${label}:candidate-canonical-index`, workspace, [...candidate, "ls-files", "--stage", "-z", "--", "."])
    assert.equal(canonicalIndex.stdout, paths.stdout)
    item.objectWrite = { blob, bytesBase64: bytes.toString("base64"), externalIndex: indexFile, tree, commit, ref, canonicalIndexNames: ["public.txt", "sub/child.txt"] }
    item.conclusion = "same frozen authority/process cwd/ref, exact root pathspec/diff and public bytes; raw import/external index/tree/commit/ref write/read/delete all verified"
  }
  item.checked = true
  await write()
}
async function scenario(label: string, fn: () => Promise<void>) {
  try { await fn() } catch (error) { facts.failures ??= []; facts.failures.push({ label, error: String(error) }); await write() }
}
try {
  facts.version = (await good("version", dataRoot, ["--version"])).stdout.trim()
  const ordinary = padded(dataRoot, "ordinary")
  await scenario("ordinary", async () => { await init(ordinary); await inspect("ordinary", ordinary, 128) })
  await scenario("nested", async () => { const nested = path.join(ordinary, "nested"); await init(nested); await inspect("nested", nested, 128) })
  await scenario("unicode", async () => { const unicode = path.join(dataRoot, "unicode", "机器".repeat(25)); await init(unicode); await inspect("unicode", unicode, 128) })
  await scenario("external-admin", async () => { const cwd = padded(dataRoot, "external-workspace"); const admin = padded(dataRoot, "external-admin", 235); await init(cwd, admin); await inspect("external-admin", cwd, 128) })
  await scenario("managed-worktree", async () => {
    const primary = padded(dataRoot, "managed-primary", 199)
    const linked = padded(dataRoot, "managed-linked", 219)
    await init(primary)
    await fs.mkdir(path.dirname(linked), { recursive: true })
    // Original probe01's default checkout failed inside Git on its own long
    // explicit admin path. Preserve that result. This fixture prepares the
    // same long linked worktree with Git's normal no-checkout admission, then
    // performs the explicit candidate checkout as a separately recorded step.
    await good("create-managed-worktree-without-checkout", primary, ["worktree", "add", "--no-checkout", "-b", "public-managed", linked, "HEAD"])
    const admin = await good("managed-preparation-discover-admin", linked, ["rev-parse", "--absolute-git-dir"])
    const frozenAdmin = await fs.realpath(admin.stdout.trim())
    const encoding = ["-C", path.dirname(frozenAdmin), `--git-dir=${path.basename(frozenAdmin)}`, `--work-tree=${linked}`]
    await good("managed-candidate-preparation-checkout", linked, [...encoding, "reset", "--hard", "HEAD"])
    await inspect("managed-worktree", linked, 128)
  })
  await scenario("cross-volume-admin", async () => { const cwd = padded(dataRoot, "cross-volume-workspace"); const admin = padded(crossRoot, "external-admin", 235); await init(cwd, admin); await inspect("cross-volume-admin", cwd, 128) })
  facts.success = !facts.failures?.length && facts.cases.length === 6 && facts.cases.every((x: any) => x.checked)
  if (!facts.success) process.exitCode = 1
} finally {
  facts.endedAt = Date.now()
  facts.allCommandsPhysicallyJoined = facts.commands.every((x: any) => x.physicalJoined && x.outputJoined && x.requestSettled)
  await write()
  console.log(JSON.stringify({ success: facts.success, cases: facts.cases.map((x: any) => ({ label: x.label, gitDirBytes: x.gitDirBytes, absoluteExit: x.absoluteExit, candidateExit: x.candidateExit, checked: x.checked })), failures: facts.failures, commandCount: facts.commands.length, allCommandsPhysicallyJoined: facts.allCommandsPhysicallyJoined }))
}
