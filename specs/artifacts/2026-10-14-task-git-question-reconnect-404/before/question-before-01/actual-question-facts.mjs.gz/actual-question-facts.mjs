import fs from 'node:fs/promises'
import path from 'node:path'
import assert from 'node:assert/strict'
const [root,mode='observe',answer]=process.argv.slice(2)
assert(root&&path.isAbsolute(root));assert.equal(path.dirname(path.resolve(root)),import.meta.dirname)
assert(['observe','answered'].includes(mode))
const ready=JSON.parse(await fs.readFile(path.join(root,'ready.json'),'utf8'))
assert(Date.now()<ready.closeBy,'Original owned close reserve')
const api=async(route)=>{
 const response=await fetch(new URL(route,ready.url),{headers:{'x-opencorvus-directory':ready.session.directory},signal:AbortSignal.timeout(15000)})
 const body=await response.json();assert.equal(response.status,200,route);return body
}
const [messages,conversation,questions]=await Promise.all([
 '/session/'+ready.sessionID+'/message','/session/'+ready.sessionID+'/conversation','/question',
].map(api))
const facts={observedAt:new Date().toISOString(),ready,messages,conversation,questions}
const output=path.join(root,'question-facts-'+Date.now()+'.json')
await fs.writeFile(output,JSON.stringify(facts,null,2)+'\n',{flag:'wx'})
if(mode==='answered'){
 assert(answer,'Explicit exact public submitted answer required')
 const start=JSON.parse(await fs.readFile(path.join(root,'global-chat-start.json'),'utf8'))
 assert.equal(start.acceptance.session.id,ready.sessionID)
 const user=messages.find(item=>item.info.id===start.acceptance.messageID)
 assert(user);assert.equal(user.info.role,'user');assert.equal(user.info.sessionID,ready.sessionID)
 const call=messages.flatMap(message=>message.parts.map(part=>({message,part}))).find(({part})=>part.type==='tool'&&part.tool==='question')
 assert(call,'Real Question Tool Part');assert.equal(call.part.state.status,'completed')
 assert.equal(call.message.info.sessionID,ready.sessionID);assert.equal(call.message.info.parentID,user.info.id)
 assert.deepEqual(call.part.state.metadata.answers,[[answer]])
 const final=messages.findLast(item=>item.info.role==='assistant'&&item.info.parentID===user.info.id&&item.info.finish==='stop'&&Number.isFinite(item.info.time.completed))
 assert(final,'Natural final streamed response for the original accepted input')
 assert.equal(final.info.sessionID,ready.sessionID);assert.deepEqual(final.info.acceptedInputMessageIDs,[user.info.id])
 assert.deepEqual(final.parts.filter(part=>part.type==='text').map(part=>part.text),['provider reply 2'])
 assert.equal(conversation.board.status,'idle')
 const check={output,sessionID:ready.sessionID,messageID:call.message.info.id,callID:call.part.callID,submittedAnswers:call.part.state.metadata.answers,finalMessageID:final.info.id,finish:final.info.finish,boardStatus:conversation.board.status}
 await fs.writeFile(output.replace('.json','.answered-check.json'),JSON.stringify(check,null,2)+'\n',{flag:'wx'})
 console.log(JSON.stringify(check))
}else console.log(JSON.stringify({output,sessionID:ready.sessionID,pendingQuestionIDs:conversation.pendingQuestions.map(item=>item.id),messageCount:messages.length}))
