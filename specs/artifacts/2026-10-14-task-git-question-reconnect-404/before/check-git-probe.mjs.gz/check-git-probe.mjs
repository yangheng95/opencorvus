import fs from "node:fs/promises"
import path from "node:path"
import assert from "node:assert/strict"

const scope = path.resolve(process.argv[2] ?? "")
if (path.dirname(scope) !== path.resolve(".tmp-task-git-question-reconnect-404")) throw Error("Exact own scope required")
const facts = JSON.parse(await fs.readFile(path.join(scope, "facts.json"), "utf8"))
const owner = JSON.parse(await fs.readFile(path.join(scope, "owner.json"), "utf8"))
assert.equal(facts.encoding, "git-C-frozen-admin-parent-and-basename")
assert.equal(facts.version, "git version 2.45.1.windows.1")
const names = ["ordinary", "nested", "unicode", "external-admin", "managed-worktree", "cross-volume-admin"]
assert.deepEqual(facts.cases.map((x) => x.label), names)
assert.equal(facts.commands.length, 214)
const expectedOriginalFailures = names.map((label) => `${label}:absolute-ref`)
const observedOriginalFailures = []
for (const command of facts.commands) {
  assert.equal(command.receipt.reason, "exited")
  assert.equal(command.pid, command.receipt.pid)
  assert.equal(command.occurrenceID, command.receipt.occurrenceID)
  assert.equal(command.physicalJoined, true)
  assert.equal(command.outputJoined, true)
  assert.equal(command.requestSettled, true)
  assert.ok(command.endedAt <= command.deadlineAt)
  assert.equal(command.executable, facts.executable)
  assert.equal(path.isAbsolute(command.cwd), true)
  if (expectedOriginalFailures.includes(command.label)) {
    assert.equal(command.receipt.exitCode, 128)
    assert.match(command.stderr, /fatal: '\$GIT_DIR' too big/)
    observedOriginalFailures.push(command.label)
  } else assert.equal(command.receipt.exitCode, 0)
}
assert.deepEqual(observedOriginalFailures, expectedOriginalFailures)
for (const item of facts.cases) {
  assert.equal(item.checked, true)
  assert.equal(item.absoluteExit, 128)
  assert.equal(item.candidateExit, 0)
  assert.equal(item.candidate.processCwd, item.authority.workspace)
  assert.equal(item.candidate.resolvedTarget, item.authority.gitDir)
  assert.equal(path.resolve(item.candidate.gitDirectoryChange, item.candidate.gitDirArgument), item.authority.gitDir)
  const commands = facts.commands.filter((x) => x.label.startsWith(item.label + ":candidate-"))
  for (const command of commands) assert.equal(command.cwd, item.authority.workspace)
  const byLabel = (suffix) => {
    const command = commands.find((x) => x.label === `${item.label}:candidate-${suffix}`)
    assert.ok(command, suffix)
    return command
  }
  assert.equal(byLabel("diff").stdout, "1\t1\tsub/child.txt\n")
  assert.equal(byLabel("exact-pathspec").stdout, "sub/child.txt\n")
  assert.equal(byLabel("blob-bytes").stdoutBytesBase64, item.objectWrite.bytesBase64)
  assert.equal(byLabel("published-bytes").stdoutBytesBase64, item.objectWrite.bytesBase64)
  assert.equal(byLabel("ref-read").stdout.trim(), item.objectWrite.commit)
  assert.equal(byLabel("tree-read").stdout.trim(), item.objectWrite.tree)
  assert.equal(byLabel("external-index").stdout, `100644 ${item.objectWrite.blob} 0\tgenerated/public.bin\0`)
  assert.equal(byLabel("read-tree").externalIndexPath, item.objectWrite.externalIndex)
  assert.equal(byLabel("write-tree").externalIndexPath, item.objectWrite.externalIndex)
  assert.equal(path.isAbsolute(item.objectWrite.externalIndex), true)
}
assert.equal(owner.receipt.reason, "exited")
assert.equal(owner.receipt.exitCode, 0)
assert.equal(owner.workerPID, owner.receipt.pid)
assert.equal(owner.workerOccurrence, owner.receipt.occurrenceID)
assert.equal(owner.physicalJoined, true)
assert.equal(owner.outputJoined, true)
assert.equal(owner.requestSettled, true)
assert.ok(owner.endedAt < owner.deadlineAt)
assert.ok(facts.endedAt < owner.workerDeadlineAt)
assert.deepEqual(owner.cleanup, { ownedDataRemoved: true, crossVolumeRootRemoved: true, afterPhysicalJoin: true })
const cleanup = []
for (const target of [path.join(scope, "owned-data"), owner.crossRoot]) {
  try { await fs.lstat(target); throw Error("Owned runtime still present") }
  catch (error) { assert.equal(error.code, "ENOENT"); cleanup.push({ target, observation: "ENOENT after original physical join" }) }
}
const result = { scope, actualGitVersion: facts.version, encoding: facts.encoding, cases: facts.cases.map((x) => ({ label: x.label, gitDirBytes: x.gitDirBytes, originalExit: x.absoluteExit, candidateExit: x.candidateExit, objectCommit: x.objectWrite.commit })), actualGitCommands: facts.commands.length, originalFailuresRetained: observedOriginalFailures.length, allGitPhysicalOutputRequestJoined: true, workerPID: owner.workerPID, workerNaturalExit: owner.receipt.exitCode, originalDeadlineAt: owner.deadlineAt, endedAt: owner.endedAt, cleanup, limits: "Real owned Git boundary probe, not production EngineGit prepare/complete, public Task admission, model, or UI qualification." }
await fs.writeFile(path.join(scope, "checker-result.json"), JSON.stringify(result, null, 2))
console.log(JSON.stringify(result, null, 2))
