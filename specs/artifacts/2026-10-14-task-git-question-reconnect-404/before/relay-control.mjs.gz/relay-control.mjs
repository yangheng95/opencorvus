import fs from 'node:fs/promises'
import path from 'node:path'
import { randomUUID } from 'node:crypto'
import { pathToFileURL } from 'node:url'
import { requireSessionID } from './http-relay.mjs'

export async function sendRelayControl(scope, action, sessionID) {
  if (!['status', 'cut', 'shutdown'].includes(action)) throw new Error('Control must be status, cut or shutdown')
  if (action === 'cut') requireSessionID(sessionID)
  const ready = JSON.parse(await fs.readFile(path.join(scope, 'ready.json'), 'utf8'))
  const id = randomUUID()
  const filename = `${id}.json`
  const destination = path.join(scope, 'control-inbox', filename)
  const temporary = destination + '.tmp'
  await fs.writeFile(temporary, JSON.stringify({ id, occurrence: ready.occurrence, action, ...(action === 'cut' ? { sessionID } : {}) }), { flag: 'wx' })
  await fs.rename(temporary, destination)
  const until = Math.min(Date.now() + 10_000, ready.deadlineAt)
  while (Date.now() < until) {
    try { return JSON.parse(await fs.readFile(path.join(scope, 'control-receipts', filename), 'utf8')) }
    catch (error) { if (error.code !== 'ENOENT') throw error }
    await new Promise(resolve => setTimeout(resolve, 50))
  }
  throw new Error(`Relay ${action} control receipt timed out for occurrence ${ready.occurrence}`)
}

if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  const [scope, action, sessionID] = process.argv.slice(2)
  console.log(JSON.stringify(await sendRelayControl(path.resolve(scope), action, sessionID), null, 2))
}
