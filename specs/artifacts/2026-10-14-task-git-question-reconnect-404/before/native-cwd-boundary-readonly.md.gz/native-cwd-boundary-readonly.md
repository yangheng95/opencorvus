# 404 首红的独立 Windows native cwd 边界

## 原始事实与限制

Root 要求补至少 300 字节 filesystem 路径。本轮第一版正式 `engine-git-frozen-directory.test.ts` 使用 ASCII segment 把自有目录扩展到至少 310 字节/字符，再通过真实 `hostGit(['init'])` 建 fixture。正式包 runner 保留在 `implementation/red/`；原 test source 为 `implementation/preimage/new-test-original-ascii310.ts`。

两 case 都在 **Git target 创建之前**失败：`Windows process supervisor exited before publishing readiness`，helper exit 125，`CreateProcessW ... win32=267`。原 helper PID 8696 / 89380、request ID 和 ready marker 路径均在原 stderr；这不是 Git 的数值退出 128，更不是 EngineGit.prepare 的目标红。原路径字符串未在失败前打印，runtime 随正式 runner 正常清理；不能事后补造其最后随机目录名。原构造逻辑和两次物理调用失败是真实证据，完整目标 argv/cwd 需要将来的独立 native probe 才能补齐。

原外层 controller 46336，正式 runner PID 73104，occurrence 51386a75-243f-42bc-be2c-4d99085d6c57；固定 start 1791927470251 / deadline 1791928070251，1791927475247 自然退出 1，physical/output/request joined 均 true。没有延长、换短目录、重放旧失败或改 OS 设置。

Root 随后批准独立 Unicode case：UTF-8 330/331/332 字节、UTF-16 186/187/188 code units。`implementation/red02` 真实进入 Task binding/EngineGit.prepare，旧参数返回 `$GIT_DIR too big`，0 pass/2 fail/18 assertions；这是本次 Git 修复的有效红。旧 ASCII310 支持仍未满足，不因 Unicode case 或 Git 改法通过而消失。

## 当前共有路径

| 路径 | 实际源 | 行为 |
| --- | --- | --- |
| Host command / shell | `shell/process-supervisor.ts:360,414,463,1121–1127,1542–1575` | Windows 两类入口统一把原 `opts.cwd` 交给 `spawnWindowsRequest`；Unix 有独立实现，不据 Windows 失败推断 POSIX |
| Task native command / shell | `:325,364,422–459` | 先取 exact Task process binding/lease，再将 `identity.cwd` 交同 native adapter；准备失败时 `finishRegistration` + lease dispose 后抛原错误，没有伪造 Task 完成 |
| Process.runHost / runTask / spawnHost | `util/process.ts:115–146,187–201` + `util/process-facade.ts:28–71` | Host 保持 request.cwd；Task 强绑定 identity.cwd。共享进程门面没有 Git 特例，也不改变目录来执行 |
| 直接 NodeProcess owned_tree | `packages/util/src/process-node.ts:352–372,566–568` | Windows 也使用现成 native supervisor，序列化 request.cwd；不是上面 Host facade 的 fallback。owned_process/非 Windows 分支是其他既有合同，未执行 |
| 最终原生边界 | `native/process-supervisor/src/main.rs:597–648` | `request.cwd` 经 `wide_null` 直接传给 CreateProcessW.lpCurrentDirectory；原生错误原样带 Win32 code 返回，未输出成功 ready marker |

生产引用搜索（Process 命令/Host/Task shell 合并谓词，非 UI 测试）覆盖 27 个文件：bun/index、bun/registry、build/agent、engine/codebase-tools、CLI session、browser/runtime/node-executor、engine/build-observation-content、file/ripgrep、execution-capsule/file-broker、expert-squad/package-tool-capsule、format/process、work-artifact/presentation、mcp/index、engine/git-process、task-artifact/store、mcp/browser/node-launcher、snapshot/index、shell/shell、shell/process-supervisor、skill/manager、util/process-facade、util/git、tool/bash、server/restart-handoff、session/shell-exec、tool/grep、tool/plugin-tool-host。搜索范围较早宽谓词包含定义自身共 29 文件，不能将两种 grep 计数混为全部调用数量。

这些入口中，最终走 Windows native 的任何合法长 cwd 都可能遇到同一 OS admission 边界，不限定 Git、专家包或受控模型。普通 Session/SideChat/bash、MCP/plugin/技能/文件辅助进程、Task worker/Build、由 Mission 创建的 Task 都按各自 cwd 和授权进入共有 adapter。Mission 不持有另一种绕开 CreateProcessW 的本地 cwd 合同；Task capsule 分支通过独立 capsule request/`/srv`等运行环境，不能用本轮 Host native 的失败证明它同样失败。

## 正常/终态、重试恢复、串并行与隔离

- 这是 **admission failure**：本例未产生 Git target，所以没有 Tool/Git 正常结束事实，也没有 checkpoint publication。标准 runner 保留 failed error 后正常 join 所有 owner，未发现泄漏或另一个未收敛队列。
- Task spawn 准备期间持有既有 read lease；失败路径释放注册/租约，错误继续由现有 Prompt/Tool/Task owner 处理。当前代码没有将 267 转成业务成功、没有为另一 Project 接管 cwd。具体用户 API 的错误外壳依入口而异，尚未做全入口实际 HTTP 验收。
- 同一路径的串行再请求或重启后仍会把原 cwd 送入同一 Win32 admission；不可通过重试预算或延长 deadline 使非法 OS admission变为成功。已经持久化的 Task/Git 错误仍服从其真实 immutable request/outcome，不能清除后重跑冒称恢复。
- 多 Project 并行分别携带自己的 request cwd/occurrence，没有发现共享 process.chdir 或被一个失败路径覆盖另一 Project 的代码。未运行新的并行 native 边界 probe，因此只说明共性入口与隔离依据，不外推运行结论。
- Native startup error 会传播到 Host/Task 各自然控制面；不能因发生在 fixture 初始化就称它为 helper-only。当前共享 `ProcessSupervisor`、registry、manifest、环境和用户设置均未修改。

## 权威依据与后续候选

Microsoft 对 [SetCurrentDirectory](https://github.com/MicrosoftDocs/sdk-api/blob/docs/sdk-api-src/content/winbase/nf-winbase-setcurrentdirectory.md) 明确说明，过长的当前目录可能导致 CreateProcessW 失败；[CreateProcessW](https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-createprocessw) 定义 lpCurrentDirectory 是新进程的初始目录。本仓直接传入原值，与观察到的 pre-target 267 相符。该资料加本例可确立“当前实现没有证明支持 ASCII310 cwd”，但没有替本机做所有 Win32 长路径/命名空间组合的实际验证。

建议下一批先独立 spec：同一精确自有目录，真实 native/NodeProcess/Host/Task command 入口采集原 argv/cwd UTF-8 与 UTF-16长度、所有物理 child 身份/退出和输入 owner。必须有启动成功 cwd 原文输出与明确 267 的错误合同；若评估 namespace 表示，必须证明同一物理目录/权限且保留原 path authority，不能改短路径、junction、复制、注册表或动态调用失败 fallback。服务/模型/UI非此边界首次复现所必需。真正发现恢复/终态异常再按共享控制机制补全运行证据；目前没有这种新事实。

本报告仅调查并保存限制，不批准或实施 native 修复。404 Git 参数修复和相关正向正式测试可在已批准的 Unicode input 上继续；交付必须同时显式保留 ASCII310 未满足。
