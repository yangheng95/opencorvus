# 404 Question identity / terminal / snapshot 横审

状态：只读分析，生产未实施；relay 已单独完成正向 byte transport checker 并冻结，见 relay-handoff.md。Root 决定正式范围与真实 UI 验收。

## Recall 与新实证

遵循 404 Recall/B/顺序2：同页、同 Request、真实断流；不得 reload/关面板冒充保留，不新增第二草稿来源或产品调试 API，不改 Task Question owner，不伪造 terminal。本报告搜索所有 Question 事件、producer、terminal、pending snapshot、Task/Session/Main/SideChat/CLI/ACP 消费、公开 schema/SDK 与现有非 UI checker。原检索明细在 question-consumer-search.txt，期间未执行产品测试/页面/模型。

Root 已亲自实证（不是本 agent 读图）：404/question-before-01，tab12，经 relay 59484；Session `ses_hqElzdDiO8HYgFV2Kb2V`，Question `que_g0VXy38Oe002YAEFtRnD`。Dialog 输入 `Draft before reconnect Cedar 404`；exact relay cutCount=1，同页未导航，约3s新 stream 后 textarea 变空、焦点回首个选项。原图 `dialog-draft-before.jpg` / `dialog-draft-after-reconnect.jpg`，公开 canonical `question-facts-1791927038019.json`。之后 Root **重新填写** `Recovered after loss Cedar 404` 并通过真实 UI Answer 收尾，只证明重新输入可答，不证明草稿保留。SideChat/inline before 尚未运行。

这使 Main Dialog 同请求 replay 丢稿从候选成为有代码和 Root 实页支持的问题。下面 expired/abandoned 与离线终态仍是源码合同缺口；尚未用真实页面逐个触发，不写成全部已复现。

## 一个 Question 的事实来源与生命周期

`question/index.ts`：

- Request schema 来自 `question/types.ts`，包含 id/sessionID/timeCreated/questions/tool/automatic/expiry。`assertSameQuestionRequest:186–205` 验同 id 的 session、questions、tool、automatic、expiry；ask 使用既有 timeCreated，重复 ask 附着同 pending waiter，不新发 Asked。
- `state:153` 使用 `createInstanceState`，其 key 为 `currentProjectDirectory`（project/instance-state.ts）。`takePending` 删除唯一 pending 项并清 timer；reply/reject/expiry/dispose 共享它，避免多个本地 terminal 回调。
- `ask:301–405` 通过 owned Bus publication 接受 Asked；显式 requestID 表示 durableContinuation。`restore:288` 根据持久完整 Request 恢复 waiter/timer，不发第二个 Asked。
- operator reply/reject 先提交精确 `bus-occurrence:question-terminal:<id>`，再移除 pending，retry durable publication，resolve/reject waiters；用户输入的真实来源保留。`Question.TestHooks.failAfterNextUserOutboxCommit` 和跨进程 checker 验该提交/恢复边界。
- automatic timer 是真实 `Replied`，带 automatic=true、配置的 timeExpires 作为 timeResolved；不是过期或人工答案。
- unanswered expiry（armPendingTimer:252–280）发 `Expired`，origin=deadline、timeExpires/timeResolved 原配置值，然后 reject waiter 为 ExpiredError。askAndFormat:606–655 只有 `config.experimental.auto_question === true` 才给普通问答配置 expiry；不应为了 UI 试验通过擅自改变生产默认。
- `abandon:518` / `abandonRecovered:547` 为 infrastructure，真实 Abandoned；后者目前未发现生产调用。Instance dispose 只对非 durableContinuation 发布 Abandoned，durable Question 留给恢复。不能把进程重启等同“所有 Question 都自动取消”。

生产 Ask 入口除通用 `tool/question.ts` 还包括 orchestrator/interaction-tools、analyze-intent-tool、orchestrator/tools 的 durable coordination、panel_wake_mission / Work 路由确认。它们共同用 Question，故不能只修某一个模型工具的字符串。`orchestrator/tools.ts:2077` 的异常调用 abandon 是真实 infrastructure 入口。Public `/question/:id/reply|reject` 与 CLI 同一来源，不应新增平行 decision writer。

## 所有 terminal 与消费者

| 事件 | canonical fields | Session mirror | Main 当前 | SideChat 当前 | Task 当前 |
| --- | --- | --- | --- | --- | --- |
| asked | 完整 Request/timeCreated | 原 Request + interaction orderKey | 新建对象、替换 Map；触发已实证 Dialog 重挂载 | 新建 interaction | EngineInteraction upsert，原 Task owner |
| replied | answers/timeResolved/automatic? | 正确真实时间/顺序 | answered，真实 answers | 删除 pending | answered + 持久 source/outcome |
| rejected | origin=operator/timeResolved | 正确 | rejected | 删除 pending | rejected + 原 origin |
| expired | origin=deadline/timeExpires/timeResolved | 正确 | **未注册/处理** | **未删除** | expired + origin/time_expires |
| abandoned | origin=infrastructure/timeResolved | 正确 | **未注册/处理** | **未删除** | expired + origin=infrastructure |

证据：`protocol/session-mirror.ts:233–271` 五事件全部映射，`questionResponseOrderKey` 使用 timeResolved；`engine/model.ts:1099–1103` 的 SessionProtocolEventType 已完整列五种。`server/routes/session.ts` 订阅该 enum 并按真实 Project/Session tree 接纳。当前 Main 的 `services/event-policy.ts:93–95` 仅三种，`conversationEventOwner:183` 对无 owner 的类型抛明确错误；`services/events.ts:316` 调它，`sse.ts:494` 收到后记录 dispatch diagnostic。`tree-writer.ts:893` 也只有三种；其 terminal 分支 `2244` 若盲增入口仍会将任何非 rejected 类型误作 answered，必须明确映射，不能只补 enum 名。

SideChat `services/side-chat.ts:126` 只删 replied/rejected；expired/abandoned 经过 transcript reducer也不会删除本地 pending Map。`SideChatPanel.tsx:485` 仍显示可操作 InteractionCard。Main 也不能以 Tool Part 已完成/错误代替删除 Question 控件：interaction Map 是另一份**投影**，必须消费同一 canonical terminal。

Task：`engine/interaction.ts:44–57` 全部订阅；resolveOwner 通过 durable taskIDForSession。`expireQuestion:472` 为 expired；`abandonPendingInteraction:226` 同样 expired，但保留 infrastructure origin；`engine/store.ts:733–755` 从不可变 Question publication 投影真实 status/response/time。`interaction-request.ts` 发既有 interaction.resolved，Board/Task 仍由当前 Task 机制更新。不得为本批增加第二 Task status、进入 resolvePermission、将 abandoned 当 operator rejection。

Task/通用呈现边界：`utils/interaction.ts:60` 只给 pending 交互控件；expired 只保留 request text，不制造 answered/rejected response bubble。下一批若 Main 用 status=expired，应沿这一既有 terminal 呈现合同，并保持真实 origin/time；不能为移卡伪填答案。本轮没实页验证 Task expiry 的所有展示。

CLI：`cli/cmd/question.ts` 用公开 SDK list/reply/reject 单次读/写，没有本地 pending UI/draft 缓存；`cli/cmd/run.ts:359` 和 github 命令默认 deny question，不能拿 run 没弹问答证明终态事件无效。CLI question list 来源为 canonical Question.list，可正向验证终态后的完整数组。

ACP（Agent Client Protocol）：`acp/agent.ts:318–350` 订阅 global events；专门交互分支是 permission.asked，其余按 message.part.updated 投影 tool status；全 acp 目录未找到 Question 专用 pending/draft/terminal UI 消费。因此本次 snapshot/Question UI 改造不应擅自新增 ACP 问答能力。其通用 Tool 输出可能展示 question 完成，但不等于 ACP 原生 Question Dialog 已实现。

## Main / SideChat identity 与 snapshot 的最小完整修法方向

### 为什么不能只 retain Map 或取消 keyed

Main connected 只替换 Permission，Question 随后 Asked replay 每次新建。`standaloneQuestionInteraction:2103` → `interactionToCardSeeds` → 新 parts → collectDialogInteractions 返回新对象 → Host keyed Show 重新创建 InteractionCard；customText/drafts 在 Card 内。Root 实证吻合。即便去掉 replay，新 live Asked 与 snapshot 重叠也可能重复同 Request，仍须正确 upsert。

SideChat connected:92 直接 pending.clear，再 Asked 才补；即使共用 identical normalizer也存在空数组导致卸载，必须一次提交 reconcile 后的整个数组，不先清空通知 UI。

直接取消 Dialog keyed Show 会改变不同 Request 的闭包/草稿隔离；外置 localStorage 或第二 pending 队列更不是根治。本批优先维护同一当前 Request 投影的对象身份。

### 权威快照必须补齐

`SessionConversationHydration` 已有 mandatory `pendingQuestions: SessionPendingQuestion[]`（engine/model.ts:1118）；`SessionConversationConnectionSnapshot:1054` 只有 pendingPermissions / transcript / view / history。离线期间 Question 已 terminal 时，当前连接只重发尚 pending 的 Asked，**没有权威空集/缺项信号**。若永久保留旧 Map，就会留下已终态旧问题。

建议在既有 connection snapshot 增加同类型 mandatory pendingQuestions；复用 SessionPendingQuestion（QuestionRequest + interaction orderKey），不新造 schema/配置。server 在原订阅后、connected 前，从**一次** canonical pending reader捕获并按同一 Session tree/Project 过滤，产生该数组。冷 hydrate 与 connected 共用一份纯 Request→orderKey 投影函数；别另查 HTTP 或另建 pending store。

推荐将 snapshot 作为重连 pending Question 的唯一入口，删除当前手工 pendingQuestionEvents Asked 重放循环；真实 live Asked/terminal 缓冲流继续按原 subscription/serial writes释放。保留两种重连入口只是多一轮无意义替换和协议双源。SDK 是当前公开协议，不留 optional/default[] 兼容层；外部 Session SSE 消费者应读取新版 connected 必有数组，CLI/ACP global event 不受此移除影响。

snapshot reconcile 规则：

1. 校验完整数组、重复 ID、Request immutable identity（id/sessionID/timeCreated/questions/tool/automatic/expiry/orderKey 和持有 directory/authority）后再一次提交。
2. 对当前相同 pending Request 重用原 normalized interaction 对象；新 ID 才新建。不同 immutable payload 不得按同 id 静默复用，给明确数据合同错误。`standaloneQuestionInteraction` 当前 payload **遗漏 expiry**，若把 expiry 纳入身份比较须保留它的真实值，不能只比当前标题/body。
3. pending-only snapshot 缺少旧 pending ID，则移除该 pending投影，不能伪造 answered/rejected/expired 或 timeResolved；已真实 answered/rejected/expired 的历史投影保留。absence只证明当前不再pending，不能猜具体terminal原因。
4. 正常 live 四种 terminal 明确处理；Main replied/rejected 保留原历史，expired/abandoned 采用现有 expired +真实 origin/time；SideChat 只移除该 id。相同 terminal replay保持终态，不被迟到 Asked重新变为pending；最终方案需对 Bus retry/连接 cutover 的顺序做正向 checker。
5. source/directory/API authority/selection epoch 改变仍由原 owner销毁，不跨 Session 保留草稿。Main Dialog/inline 为不同 owner，不承诺两处同步草稿。

### 必須先核定的范围

- Question cold hydrate 目前按整棵 Session tree 过滤；warm Main Asked 仍有 selected root / known Mission / 已有Question 的准入。新 connected 完整 snapshot 若直接按既有 hydrate合同接纳，会让某些 child Question 比旧 warm path更早进入；这不是 Permission predicate可顺手替换的理由。Root 需明确保持当前 Question 准入范围，或在同一正式规格中批准其冷暖一致契约。不要复制 isStandalonePermissionSession 然后宣称 child 全通过。
- Task owner保持原 Board/interaction单源；不能让同一个 Task Question又作为 standalone Request出现。应以公开入口和 durable lineage positive cases辨明，不能只看前端 session map暂缺。
- 自动/过期/基础设施终态之外，更早 Permission恢复可能改变 oldest Dialog；首个同 Request草稿验收应只有一个 pending，之后再核多pending排序，不能以简单例覆盖所有 owner转换。

## 公共与实施文件建议（待 Root 批准）

核心必需：`engine/model.ts`、`server/routes/session.ts`；可直接复用已存在 SessionPendingQuestion/Question.pendingSnapshotReader，不改 Question writer 或 Task owner。前端必需：`services/conversation.ts`（connected强制数组）、`services/tree-writer.ts`（单源 Question reconcile/live身份/四terminal）、`services/side-chat.ts`（一次完整reconcile）、`services/event-policy.ts`（expired/abandoned owners）。Question immutable normalizer可落现有共同 helper；仅在 Main/Side 两个实际消费者证明重复后抽取，避免第二 Request来源。组件本身可能无需改，但 inline CardParts/For身份是否仍导致重挂载要 Root实页确认，不能仅 Main Dialog通过就宣布 inline通过。

SDK：正常唯一 generation transaction 更新 `packages/sdk/js/src/gen/types.gen.ts` + `packages/sdk/openapi.json`，按现有六目标 build/publish/owner join流程，不手改生成物、不改 SDK 请求输入。`SessionConnectedEvent` 和 `SessionStreamEvent` 均间接使用新 mandatory字段；所有外部消费者受该当前公开响应合同影响。

真实生产消费者全检索：Main conversation merge、SideChat；`subagent-conversation.ts:601` 是 transcript-only parser，虽接收相同 snapshot但只消费 transcript/view，不能强塞交互UI；它无需新增Question状态源。其 `test/subagent-conversation-service.test.ts:825` 真实协议fixture和 `test/side-chat-transport.test.ts` 必须补当前完整snapshot；不能为类型通过继续缺字段。

Backend fixture涉及当前构造 connected的 `test/server/session-event-connection-snapshot.test.ts:282`；实际路由读取型tests会自然获得数组，包括 session-permission-projection、global-chat-start、streaming-text-prefix、sse-compression。不宜为本改动无目标重跑全部；过期 literalfixture按新公开合同最小更新。

## 正向 checker / 风险与未证

建议新增/扩展非 UI backend当前真实checker，逐项给完整明确输出：

- pending Question 的 HTTP cold 与 connected完整数组一致，完整immutableRequest/orderKey；同 id duplicate/retry明确同事实，变更payload映射到明确错误。
- 一次真实Ask后读stream → 仅取消HTTPreader → 保持Question waiter → 再connected为同Request；真正 public reply → waiter精确answers、真实terminal事件/time；重复连接后的pending集合为明确空数组。
- 离线期间分别真实reply/reject/expiry/abandon，重连snapshot为正确完整pending集合（含另一个仍pending请求）；live映射四terminal分别保持真实origin/time/answers。自动回答单独真实automatic=true，不当作operator。
- subscribe→snapshot→drain→connected→buffer cutover中Asked与terminal竞争，快照加live合并得到canonical当前集合；特别验证terminal先到后迟到Asked/retry不复活。`ProtocolStore.subscribeEvents().drain()`只等待该subscriber当前tail，不能单凭它的名字宣称所有durable Bus outbox全局排序。当前Bus owned retry可单独发生，必须以真实publication checker证明边界；没有跑过就标未知。
- 两个真实Project及Main/SideChat各自Request，完整数组与终态均归对应Session tree；一个Question结束不抹另一个pending。
- Task原 durable Question restore/terminal仍由EngineInteraction；已有 `test/engine-interaction-recovery.test.ts:269`、`test/question-process-recovery.test.ts`、`test/fixture/question-process-recovery-worker.ts`；shutdown两Project `test/process-shutdown-task-lifecycle.test.ts:106` 真实发布Abandoned。已有覆盖是 backend，不是UI。普通non-Task工具Question与durableTask restore不同，不用重启后端代替网络重连。

前端只允许经 Root批准的纯 transport/state正向合同（既有 SideChat fixture等），严禁 DOM/render/source-copy/snapshot/Playwright UItests。Root真实后态需 Main Dialog、inline、SideChat逐个同页草稿继续编辑精确提交；保留before丢稿图与已重新填写的事实，不改历史。

目前未跑这些产品checker，未改SDK/生产，未实页 expired/abandoned、SideChat/inline、新snapshot或全部重启/多Project UI。若发生真实调度/终态故障，必须按AGENTS共享机制展开，不以模型行为解释。此报告列明共同生产入口和风险，不能把静态终态handler存在当全部恢复正确。
