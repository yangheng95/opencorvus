import http from 'node:http'
import { randomUUID } from 'node:crypto'

const standardHopHeaders = new Set(['connection', 'keep-alive', 'proxy-authenticate', 'proxy-authorization', 'te', 'trailer', 'transfer-encoding', 'upgrade'])
const sessionPattern = /^ses_[A-Za-z0-9_-]+$/

export function requireSessionID(value) {
  if (typeof value !== 'string' || !sessionPattern.test(value)) throw new Error('An exact canonical Session ID is required')
  return value
}

function forwardedHeaders(raw, host) {
  const excluded = new Set(standardHopHeaders)
  for (let index = 0; index < raw.length; index += 2) {
    if (raw[index].toLowerCase() === 'connection') {
      for (const token of raw[index + 1].split(',')) excluded.add(token.trim().toLowerCase())
    }
  }
  if (host !== undefined) excluded.add('host')
  const result = []
  for (let index = 0; index < raw.length; index += 2) {
    if (!excluded.has(raw[index].toLowerCase())) result.push(raw[index], raw[index + 1])
  }
  if (host !== undefined) result.push('Host', host)
  return result
}

/** Owned HTTP/1 relay. No product imports, event decoding, body buffering or UI hooks. */
export async function startHttpRelay({ upstream, onEvent = () => {} }) {
  const base = new URL(upstream)
  if (base.protocol !== 'http:' || !['127.0.0.1', 'localhost', '[::1]'].includes(base.hostname) ||
      base.username || base.password || base.pathname !== '/' || base.search || base.hash) {
    throw new Error('Upstream must be one credential-free loopback HTTP origin')
  }
  const pairs = new Map()
  const sockets = new Set()
  const totals = { opened: 0, completed: 0, cut: 0, upstreamErrors: 0 }
  let closing = false
  let closePromise
  const record = (type, fields = {}) => onEvent({ type, at: Date.now(), ...fields })
  const server = http.createServer((request, response) => {
    if (closing) { response.writeHead(503); response.end('Relay closing'); return }
    if (!request.url?.startsWith('/') || request.url.startsWith('//')) {
      response.writeHead(400); response.end('Origin-form request target required'); return
    }
    const pathname = request.url.split('?', 1)[0]
    const candidate = /^\/session\/(ses_[A-Za-z0-9_-]+)\/events$/.exec(pathname)
    const sessionID = request.method === 'GET' ? candidate?.[1] : undefined
    const id = randomUUID()
    const upstreamRequest = http.request({
      protocol: base.protocol, hostname: base.hostname, port: base.port,
      method: request.method, path: request.url,
      headers: forwardedHeaders(request.rawHeaders, base.host), agent: false,
    })
    const pair = { id, sessionID, request, response, upstreamRequest, upstreamResponse: undefined }
    pairs.set(id, pair)
    totals.opened++
    if (sessionID) record('session-stream-opened', { pairID: id, sessionID })
    const retire = () => {
      if (!pairs.delete(id)) return
      if (sessionID) record('session-stream-closed', { pairID: id, sessionID })
    }
    request.on('aborted', () => upstreamRequest.destroy())
    request.on('error', () => upstreamRequest.destroy())
    response.on('error', () => upstreamRequest.destroy())
    response.on('finish', () => { totals.completed++; retire() })
    response.on('close', () => {
      if (!response.writableEnded) upstreamRequest.destroy()
      pair.upstreamResponse?.destroy()
      retire()
    })
    upstreamRequest.on('error', () => {
      totals.upstreamErrors++
      if (response.destroyed || response.writableEnded) return
      if (response.headersSent) response.destroy()
      else { response.writeHead(502, { 'content-type': 'text/plain' }); response.end('Owned upstream connection failed') }
    })
    upstreamRequest.on('response', incoming => {
      pair.upstreamResponse = incoming
      response.writeHead(incoming.statusCode ?? 502, incoming.statusMessage, forwardedHeaders(incoming.rawHeaders))
      response.flushHeaders()
      incoming.on('error', () => response.destroy())
      incoming.on('aborted', () => response.destroy())
      incoming.pipe(response)
    })
    request.pipe(upstreamRequest)
  })
  server.on('connection', socket => { sockets.add(socket); socket.on('close', () => sockets.delete(socket)) })
  server.on('clientError', (_error, socket) => socket.destroy())
  await new Promise((resolve, reject) => { server.once('error', reject); server.listen(0, '127.0.0.1', resolve) })
  const address = server.address()
  const url = `http://127.0.0.1:${address.port}`
  record('relay-listening', { url, upstream: base.origin })
  return {
    url,
    status() { return { closing, totals: { ...totals }, activePairs: pairs.size, incomingSockets: sockets.size,
      sessionStreams: [...pairs.values()].filter(pair => pair.sessionID).map(({ id, sessionID }) => ({ pairID: id, sessionID })) } },
    cutSessionStreams(sessionID) {
      requireSessionID(sessionID)
      const selected = [...pairs.values()].filter(pair => pair.sessionID === sessionID)
      const pairIDs = selected.map(pair => pair.id)
      for (const pair of selected) {
        pair.response.destroy()
        pair.upstreamResponse?.destroy()
        pair.upstreamRequest.destroy()
      }
      totals.cut += selected.length
      record('session-stream-manual-cut', { sessionID, pairIDs })
      return { sessionID, cutCount: selected.length, pairIDs }
    },
    close(reason) {
      if (closePromise) return closePromise
      closing = true
      closePromise = (async () => {
        const closed = new Promise((resolve, reject) => server.close(error => error ? reject(error) : resolve()))
        for (const pair of pairs.values()) { pair.response.destroy(); pair.upstreamResponse?.destroy(); pair.upstreamRequest.destroy() }
        for (const socket of sockets) socket.destroy()
        await closed
        record('relay-closed', { reason, totals: { ...totals } })
        return { reason, closedAt: Date.now(), totals: { ...totals } }
      })()
      return closePromise
    },
  }
}
