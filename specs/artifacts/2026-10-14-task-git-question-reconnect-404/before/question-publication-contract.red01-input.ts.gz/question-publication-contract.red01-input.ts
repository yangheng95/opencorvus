import { afterEach, expect, test } from 'bun:test'
import { Bus } from '../packages/opencorvus/src/bus'
import { Question } from '../packages/opencorvus/src/question'
import { Session } from '../packages/opencorvus/src/session'
import { Instance } from '../packages/opencorvus/src/project/instance'
import { ProtocolStore } from '../packages/opencorvus/src/protocol/store'
import { ensureSessionProtocolBridge } from '../packages/opencorvus/src/protocol/session-mirror'
import { memoryProject, resetMemoryDatabase } from '../packages/opencorvus/test/fixture/memory'

afterEach(async () => { await Instance.disposeAll(); await resetMemoryDatabase() })

test('an accepted Asked observer reads the complete canonical pending Request at publication time', async () => {
  await using project = await memoryProject()
  await Instance.provide({ directory: project.path, fn: async () => {
    const session = await Session.create({ kind: 'assistant', title: 'Public canonical Question admission' })
    const readPending = await Question.pendingSnapshotReader()
    let observed: { request: Question.Request; pending: Question.Request[] } | undefined
    let resolveObserved!: () => void
    const received = new Promise<void>(resolve => { resolveObserved = resolve })
    const stop = Bus.subscribe(Question.Event.Asked, ({ properties }) => {
      if (properties.sessionID !== session.id) return
      observed = { request: properties, pending: readPending() }
      resolveObserved()
    })
    const answer = Question.ask({ sessionID: session.id, expireOnDeadline: false,
      questions: [{ header: 'Admission', question: 'Public canonical entry', options: [], custom: true }] })
    try {
      await received
      await Question.reply({ requestID: observed!.request.id, answers: [['Public admission completed']] })
      expect(await answer).toEqual([['Public admission completed']])
      console.log('PUBLIC_ADMISSION_OBSERVATION', JSON.stringify(observed))
      expect(observed!.pending).toEqual([observed!.request])
    } finally { stop() }
  } })
}, 30_000)

test('a real terminal remains the current Session projection after an earlier Asked delivery resumes', async () => {
  await using project = await memoryProject()
  await Instance.provide({ directory: project.path, fn: async () => {
    const session = await Session.create({ kind: 'assistant', title: 'Public Question delivery ordering' })
    const readPending = await Question.pendingSnapshotReader()
    let releaseAsked!: () => void
    const held = new Promise<void>(resolve => { releaseAsked = resolve })
    let resolveHeld!: () => void
    const entered = new Promise<void>(resolve => { resolveHeld = resolve })
    let request: Question.Request | undefined
    let askedOccurrence = ''
    const stopGate = Bus.subscribeAll(async event => {
      if (event.type !== Question.Event.Asked.type || event.properties.sessionID !== session.id) return
      request = event.properties
      askedOccurrence = event.occurrenceID
      resolveHeld()
      await held
    }, { durableID: 'scratch404.public-question-delivery-window', effect: 'idempotent_by_occurrence' })
    ensureSessionProtocolBridge()
    const projections: Array<{ type: string; payload: unknown; pendingAtDelivery: Question.Request[] }> = []
    const stopProjection = ProtocolStore.subscribeEvents(event => {
      if (event.sessionID !== session.id) return
      projections.push({ type: event.type, payload: event.payload, pendingAtDelivery: readPending() })
    }, { aggregate: 'session', types: ['question.asked', 'question.replied'] })
    const answer = Question.ask({ sessionID: session.id, expireOnDeadline: false,
      questions: [{ header: 'Ordering', question: 'Public ordering choice', options: [], custom: true }] })
    try {
      await entered
      await Question.reply({ requestID: request!.id, answers: [['Public terminal wins']] })
      expect(await answer).toEqual([['Public terminal wins']])
      await stopProjection.drain()
      releaseAsked()
      // Wait on the original durable Asked publication, not a synthetic event.
      await Bus.publishOwnedExact(Question.Event.Asked, request!, askedOccurrence).retry()
      await stopProjection.drain()
      console.log('PUBLIC_ORDERING_OBSERVATION', JSON.stringify({ request, projections, canonicalPending: readPending() }))
      expect(projections.at(-1)).toMatchObject({ type: 'question.replied', payload: { requestID: request!.id, answers: [['Public terminal wins']] }, pendingAtDelivery: [] })
    } finally { releaseAsked(); stopGate(); stopProjection() }
  } })
}, 30_000)
