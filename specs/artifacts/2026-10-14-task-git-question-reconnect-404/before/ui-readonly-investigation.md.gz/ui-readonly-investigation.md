# 402 后续候选：Work / Mission 根权限与同页 Question 重连

调查日期：2026-10-14。状态：只读候选与验收建议，未启动页面、服务或模型，未执行测试，未修改产品、测试、spec、共享文档或 Git。此文件不是功能验收。402 原手动说明保持冻结。

## Recall

用户持续目标是分批并行调查 UI/UX、功能和缺陷，先根因/影响/spec，再实现、真实桌面交互/人工截图及聚焦正向测试，最后范围提交、上游同步和正常推送。Root 本轮限定：核对 Work、非 Task Mission 各自真实权限入口，以及真正同页断连/重连时 Question 草稿；只写此 scratch，下一批由 Root 写 Recall 并批准范围。禁止再委托、UI 自动化、服务/浏览器/模型操作、凭据读取和生产修改。

Root 提供当前 402 提交身份 b3958bebf / e0ba0bbe5；本轮没有自行执行 Git 命令。已读当前 AGENTS、07-panel、07-panel-reactivity、17-code-work-agent-platform、402 最终记录及 frontend-preparation；追读下列实际源码。402 最终记录明确 Work/Mission 独立桌面入口和 Question 真重连/草稿仍未覆盖。manual-after-03 只证明自定义输入并提交，不能升级为重连验收。

检索覆盖：GlobalConversation/GlobalCreation 创建、Session/Mission 公共路由、Composer Work/Mission 路由、持久 Session lineage、Permission mirror/hydrate、Question snapshot/live replay、Main/SideChat 交互持有者、Dialog/inline 组件身份、SSE transport/reconnect、当前 backend protocol fixture 和现有验收 helper。没有发现可直接调用的产品“仅断开当前 SSE”公共接口；不应为了验收增加产品调试接口。

## 结论与优先级

1. Work 与 Mission 根 Permission 是**尚未逐个实页覆盖的既有合同**，当前代码没有足以直接宣布这两个入口损坏的证据。它们分别有合法创建/启动 API，并共同进入 402 的非 Task 持久 lineage 判定和 Main Session 权限投影。最小下一步是各做一条真实外部公开 CSV read → UI Allow Once → 实际 read 完成 → 自然模型答案。
2. Question 存在更具体的**同请求 replay 改变组件身份**候选：Main 的 `question.asked` 每次新建 interaction，Dialog 使用对象身份 keyed Show，草稿只在 InteractionCard 内。SideChat 在 connected 直接清空所有 pending 后再 replay Question，卸载窗口更直接。应先做真实同页断流证据；没有该实证前，不把静态链写成已确认 UI 故障，也不先改组件。
3. 不用 reload、切 Chat、关闭 SideChat、更换 API URL 或重启后端替代同页网络重连。那些动作可能合法销毁 owner，不能证明本候选。

## Work / Mission：合法入口和数据流

| 目标 | 真实界面入口 | 合法 HTTP 合同 | 身份/投影 |
| --- | --- | --- | --- |
| 新 Work 根会话 | 新请求 Composer：产品选 Work、目标选 Chat，再发送正文 | 有目录：`POST /coding/work/session?directory=...`；无目录：`POST /global/work`。body 仅可选 `{model: "provider/model"}`，严格 schema；均返回 201 `{session}`。随后原 Session prompt 路由发送正文 | `kind: assistant`、conversation metadata 的 `experience: work` / `surface: right-sidebar`；真实持久 Project/directory。Main 选中 `{kind: session, sessionKind: conversation, experience: work}` |
| 新 Mission 根会话 | 新请求 Composer：目标选 Mission；产品 Code/Work 二选一（本轮可选 Work），发送正文 | 无目录先 `POST /global/projects/anonymous`（201，返回真实 directory）；随后 `POST /mission/wake?directory=...`，严格 body `{productPillar:"work",text:"...",model?,requestID?,expertSquadIDs?,attachments?}`，返回 200 `{missionID,sessionID,created,productPillar}` | `kind: mission`；Main `openMissionSession` 选中 `{kind:session,sessionKind:mission}`，经原 `loadConversation`/Session SSE。根 Session 不等于 Task root |
| Mission 草稿后启动 | Missions 面板创建草稿，然后启动 | `POST /mission/draft?directory=...` body `{title,request,productPillar,expertSquadIDs?}` 返回 MissionRecord；`POST /mission/:id/dispatch?directory=...` 可选 `{requestID,model}` | 草稿本身不请求模型；dispatch 才启动原执行 owner。本轮最小 read 验收不必同时扩两条创建路径 |

定义/调用证据：

- `packages/overlay/src/components/ChatComposer.tsx:1268–1294` 两个独立 selector 的值为 `code/work` 与 `chat/mission`；英语真实标签 Work / Chat / Mission 见 en-US.json:236–243。
- `main.tsx:2072–2077,2614–2697` 决定初次提交；`services/conversation-session.ts:265,315,333,353` 创建后应用真实返回 Session/directory 并 hydrate/SSE。不可把现有 Chat 会话的追加消息当成创建 Work。
- `services/workspace.ts:400–479,497–505,1368–1378` 的 global Composer 单 owner 分配匿名 Project；捕获原 model、API authority、selectionEpoch，应用 directory 后 Mission wake。`main.tsx:1518–1570` 为 Mission 打开 Main Session。
- `server/routes/global.ts:63–68,354–426,1129–1149`；`server/routes/right-sidebar-conversation.ts` 的 create schema 同样只有 model。
- `chat/global-chat-service.ts` preflight 使用真实 global Config / model validation；`chat/session.ts:56–95` `prepareRootNext` 原子写 assistant + experience + 初始 overlay。后续 `applyRightSidebarConversationPromptOverlay` 强制相应 work/chat agent 及原通用工具集（含 read/question）。
- `server/routes/mission.ts:91–126,217–230,662–795`；`mission/session.ts:662` 的 durable Mission Session；`mission/public-session-authority.ts` 拒绝公共 Session 创建 `kind:mission`，并把通用 prompt 等操作指向 canonical `mission.wake`。不能 POST `/session` 手造 Mission，再以普通 Session message 运行它。

GlobalCreation 边界必须明确：`project/global-creation-allocation.ts:GlobalCreationKind` 只有 `global_task` / `global_chat_start`。`engine/global-creation-target.ts:assertGlobalChatAcceptedSession` 明确要求 assistant + **chat** experience，并持有 deterministic input identity。当前没有 `/global/work/start` 或 `/global/mission/start`。不得把 `/global/chat/start` body 塞 `experience:work`、把 root Session metadata 自行改成 Work，或以不存在的 GlobalCreation kind 验收 Work。`/global/work` 每次是新建；不应重试该 POST 然后把多个 Session 当同一 occurrence。Mission 如需精确重试应复用真实接受的 requestID/missionID 合同，而不是重复创建。

## 为什么两个根 Permission 理论上可到达

- `agent/tool-pool-data.ts:158–182,320–329`：Mission 已是 full-function primary，`primaryExecutionGlobal` 包含 read/question，Mission 的过滤只去掉特定 skill/transport 项；`agent/role-contract.ts:135–145` 也如此声明。不能沿用旧“Mission 只能协调而不能直接 read”的假设。
- `agent/primary-assistant-registry.ts:116–149`：Work 与 Mission 都有真实默认能力规则。能力授权 allow 与是否需要用户批准是不同层；本 checker 使用当前 Config 的 `permission_mode:"ask"`，不新增 Permission 配置第二源。
- `permission/invocation.ts:341–350`：read 的 filePath 在 carrying Project 外部才分类为 `read_local`；Project 内 read 不保证出现批准。验收必须使用新建的公开无敏感 CSV，在该 Project 外，不能拿没有弹卡的内部 read 推断投影故障。
- `permission/authority.ts:209–233` 从当前 Config 读取 ask mode，并按 Session 固化策略；应在首次 invocation 前设置并经公开有效配置核对。此次未读取任何运行时配置/凭据。
- `engine/task-session-lineage.ts:sessionLineageIdentity/isStandalonePermissionSession` 读取真实祖先链、Project，并由 `taskIDForSession` 排除 Task 所属；不是检查前端 map 或把 `Request.taskID` 为空当唯一依据。
- `protocol/session-mirror.ts:standalonePendingPermission,276–329` 接纳 assistant/mission 的 Session 事件；`server/routes/session.ts:709–715,1148,1320` 用 Session tree + 同一 standalone Request 投影产生 mandatory pendingPermissions；Main 复用同一 Permission normalizer/Map。
- Mission 自己创建的 Task 若之后执行 read，其 Request 归 Task，不能冒充 Mission 根验收。公开事实必须关联 request.sessionID 到该 Mission 根，并在后端 checker 核对 durable lineage；不要为了通过改 Request/taskID 或写假 Task 状态。

## Work / Mission 最小真实桌面 checker 建议

每个入口独立一个新 scope/Session，固定截止和同一配置源，优先复用 402 已成熟受控流式 provider/helper 的生命周期，不复用旧 Session 的 policy。此阶段只是建议，尚未授权启动。

1. 用相应真实 selector 发送明确读取公开 CSV 的请求；若采用 API 预创建，仍必须通过上表各自合法入口创建，并在真实 UI 选中原 Work/Mission，报告“API 创建 + UI 决策”而非“UI 完整创建”。最佳本轮优先完整 Composer 创建。
2. 记录返回 Session/project/directory、Request id/sessionID/toolName/effect、当前 ask 配置来源；真正模型请求必须有 read 且 `stream:true`。受控 provider 只能自然输出合法 Tool call，不能调用 PermissionAuthority 伪造批准气泡。
3. 等真实 pending，人工看 Dialog 的路径/summary/选择（非 Task 不应杜撰 allow_task）；关闭 Dialog 后看 inline，再在一个真实入口点 Allow Once。截图要让请求和实际结果都处于可见区域。
4. 检查真实 read Tool Part 为 completed 且精确 CSV 内容，canonical ledger 对应 allow_once/execution_succeeded，并有自然 assistant final reply / completed；仅卡片消失不能算通过。Mission 不必为了根 read checker 强造整任务完成，但如果发生 owner/终态异常，应按共享机制横审，不归咎模型或“UI已通过”。
5. 用语言切换至少复核用户控件与技术/用户原文分界；恢复原语言，实际关闭独立页与原 scope/join。在允许区只保存 public 输出和生命周期摘要，不读 raw Provider/auth/models/DB。

正向 backend 路径：可在既有 `test/server/session-permission-projection.test.ts` 的真实 TCP read case（466 起）复用 `startControlledStreamingProvider`、Server.listen、外部公开 CSV、公开 permission.reply、最终真实 Tool/result 检查，分别改用合法 Work 创建与 Mission wake；普通 helper 型 Session.create 不能代替这两个 API 合同。扩展前先审下一批 spec；不得运行全量测试。相关现有非 UI 合同还包括 `test/server/session-event-connection-snapshot.test.ts:790`（Work first prompt cutover）、`test/mission-public-session-authority.test.ts`、`test/mission-execution-wake-occurrence.test.ts`、`test/mission/session-initial-overlay.test.ts`。这些已有覆盖并非 Work/Mission 权限桌面验收。

## Question 真重连的已证代码链

### 服务端只有真实 Request 一份

`question/index.ts:186–205` 同 id replay 校验 session/questions/tool/automatic/expiry；`pendingSnapshotReader:572` 捕获原 Project pending store，读取真实 `item.info`。`server/routes/session.ts:1229,1327–1363` 先订阅、读取 pending、发送 `session.connected`，然后发送 pending `question.asked`，最后释放并发事件；重叠可合法重复同 id。旧源码注释“upsert idempotently”只说事实投影，不证明组件 owner 身份不变。

### Main

`conversation.ts:450–480` 同 Session connected 合并 transcript/history，并只替换 Permission；`tree-writer.ts:2161` 保留 Map 中 Question。**随后** `handleStandaloneQuestion:2198–2228` 对 replay 的 Asked 无条件调用 `standaloneQuestionInteraction:2103` 新对象，然后 regroup/rebuild。`interactionToCardSeeds` 将新 interaction 引用装入 parts；`upsertInteractionCard:3849` 替换 parts 数组；`collectDialogInteractions` 原样取 part.interaction。`InteractionDialogHost.tsx:32–64` 选最老 pending，并 `<Show when={current()} keyed>`。

`InteractionCard.tsx:70,116` 的 customText / drafts 是组件局部 signals；没有外置 request 草稿存储。因此相同 Request replay 引用变化可使 keyed Dialog 重挂载、草稿初始化。即使 id、文本和 created 完全相同也不能推出 owner 相同。Solid 官方 `<Show keyed>` 文档明确按引用变化重新创建内容；这是机制依据，仍需要真实 UI 证明该完整路径的可见结果：[Solid Show](https://docs.solidjs.com/reference/components/show)。

此外，新恢复的更早 Permission 会让 `pickDialogInteraction` 改选另一 interaction；那是另一个 owner 转换，不应混入首个只含一 Question 的重连实验。Inline 与 Dialog 也是两个独立 InteractionCard，不应在两处切换输入后声称一个 owner 草稿保留。

### SideChat

`services/side-chat.ts:82–94` 在 connected 执行 `pending.clear()`，只加入当前 Permission；`115–118` 后续 Asked 再创建新 Question。`components/SideChatPanel.tsx:102,279,485–486` 对 signal 数组使用 `<For each={interactions()}>` 渲染 InteractionCard。因此有明确清空/重建窗口；它比 Main 只看 Map 保留更容易遗漏。此处目前为同机制候选，不宣称已真实丢稿，也不擅扩 child Question 准入。

### Transport 不会自然 reload

- `services/tauri-transport.ts:465–590`：无认证 GET 使用 native EventSource；有认证 GET/POST 用原 fetch SSE。第一次 EventSource error 主动 close，让业务层唯一拥有重连；不会双自动重试。
- `services/sse.ts:316–325,342–416,510–523`：原 Session source/directory 在现有 authority/generation 内 3000ms 后 restart；未调用整页刷新或重新 hydrate 清树。`stopSSE` 属主动 consumer-dispose，不是公开“网络断开”API，不应从浏览器注入调用它。
- `services/default-server.ts` 默认从 `/ui` 当前 origin/prefix 取 API base。因此从一开始在同源透明 relay 的 `/ui` 进入，可让自然 UI/API/SSE 全部经过 relay；不需要在草稿出现后切服务器配置。

## 真同页断流方案：只切 transport，保持真实 Question

现仓已有 `HostTransport.openStream`/业务 reconnect 与真实 Session `/events`，但本次搜索的生产/检查脚本没有一个可直接复用的目标 SSE 手动断流控制器。现有代理 fixture `test/fixture/dependency-proxy-contract.mjs` 属 outbound CONNECT/dispatcher 合同，不是当前 UI reverse proxy，不能冒充现成页面工具。

推荐下一批经 Root 方案批准后，给自有人工验收 scope 增加极小 **Node HTTP 透明 relay**，不引入产品 API、不改 UI、不造事件：

1. relay 与原真实开发服务器一起由同一明确 owner/固定 closeBy 管理；页面从 relay `/ui` 打开，所有真实 HTTP 原样流转。保持 method/path/query/body、end-to-end headers 与 SSE 原始数据字节；不 JSON 解析后重写业务事件。Node 原生 `http.request` / IncomingMessage 是成熟 streaming primitive，[Node HTTP](https://nodejs.org/api/http.html#class-httpclientrequest)。避免 fetch 自动解压后又照搬 content-encoding/content-length 的错误。
2. 只登记完整目标 `GET /session/<exact id>/events` 的当前 response/request。Root 输入草稿并截图后，手动给独立本地控制通道一次“断开该连接”指令；销毁该 pair 的 downstream/upstream HTTP stream，让浏览器收到真实 error。其余 UI、global events、模型与 Question waiter 继续运行，不调用 Session abort/stop/delete。
3. 最小 first run 只断一次，随后立刻允许现有业务重连。若需要稳定人工观察 disconnected 状态，可限定短暂拒绝该 exact route 的新连接并手动恢复；记录真实故障响应/时间，不伪造 session.connected/question.asked。不要增加定时清 UI 或自动操作页面。
4. 记录相同 tab、document 未导航、Session/source/directory 不变；relay 出示旧 stream close、新 stream id/open、新真实 connected 与同 Request Asked 的次序；截图重连前/后草稿及可编辑性。Root 只读当前元素身份可作辅助，核心是实际文本仍可继续编辑并提交、最终答案精确返回。
5. 控制/上游 scope 都必须有 owner、停止/join；不要重启真实 server 代替断流。Question pending 当前有进程内 store，重启 backend 会同时引入恢复变量。MDN 说明原生 EventSource 断连通常重连、`.close()` 终止该实例；本产品在此基础上采用上述唯一业务重连：[MDN SSE](https://developer.mozilla.org/en-US/docs/Web/API/Server-sent_events/Using_server-sent_events)。

以上 relay 只是待实现的人工网络故障工具设计，本轮未创建、运行或验证它。其 raw stream 转发正确性应有正向非 UI transport checker（原始流式响应和断开后重新连接的明确事件输出），不能添加 Playwright route、浏览器 fixture、DOM/组件测试或自动填写/截图。若 Root 的现成真实浏览器工具已提供独立 tab 的原生 network offline/online，可以先审其公开能力再选用；本轮没有访问浏览器，不能宣称该能力可用。

## Question 最小人工步骤与正向 backend checker

实际 Tool 参数仅为：

```json
{"questions":[{"header":"Reconnect draft","question":"Enter the public draft to keep across this connection interruption.","options":[],"custom":true}]}
```

`tool/question.ts:7–19` 允许 1–4 个 Question；`question/types.ts:34–42` options 是必有数组且可以为空、custom 可为 true。不发送私造 id/sessionID/timeout 等非 tool 参数。用自然真实 tool call 触发；保持仅一个 pending，公开配置中自动回答/expiry 必须明确，实验在期限内完成。最小场景不依赖其它 Question child 准入。

1. Main Dialog 写入明确自定义字符串（例如 `Draft before reconnect Cedar 404`），先不提交；Root 截图并实际检查输入。只切选中 Session SSE，等待真实新 connected/同 id Asked；确认原字符串可继续追加，再点击 Submit。最后检查真实 `question` tool metadata.answers 和自然模型 reply 包含确切提交值。若先丢稿，把前态失败保存后停止扩大，不靠重新填写宣称保留成功。
2. 单独新请求验证 inline（在开始输入前关闭 Dialog）、同 request 断流；不能把 Dialog 输入同步到 inline 作为本批默认要求。
3. 单独 SideChat root（原 `POST /session/:source/side-chat` 与 UI Side chat 创建路径）同样输入→只断它的 exact Session SSE→继续输入/提交。SideChat 不关闭/重开；这会重建组件，属于另一合同。

backend 正向可复用 `test/server/session-event-connection-snapshot.test.ts` 的 `sessionEventReader` + canonical Question.ask/current routes：打开真实 stream，捕获 Asked 完整 Request；只 cancel reader/HTTP，再 GET 同 events，确认 connected 后同 id/timeCreated/questions/tool/automatic/expiry 的 Asked；向 `/question/:id/reply?directory=...` 发合法 `{answers:[["..."]]}`，确认真实 waiter 得到精确答案与 replied 事件。若要完整执行链，则复用 `test/fixture/controlled-streaming-provider.ts` 通过真实 Question tool 和 HTTP Session Prompt。前者是 backend 协议合同、后者是运行链；二者都不证明 UI 草稿保留。

对 reader 窗口竞态可沿现有 `SessionEventStreamTestHooks.afterConversationSnapshotRead` 验真实重叠 Request；不要将 test hook 暴露成产品接口。当前 `test/server/session-event-connection-snapshot.test.ts:38` 已覆盖冷 stream 真实 Question pending snapshot，`test/server/sse-compression.test.ts:187,227` 已覆盖真实 consumer cancel/reconnect/压缩读；不能把这些已有测试解释为同页 UI 草稿通过。本轮只读，未运行这些测试。

## 若实页证实后的最小修复方向（未批准、未实施）

优先保持单个 canonical Request 的现有投影身份：在 standalone Question upsert/reconcile 入口让同一 immutable Request 的重复 Asked 保留现有对象/owner，终态仍从真实 replied/rejected 更新；SideChat connected 应按同一 Question 生命周期规则处理，而不是无条件清掉未终态 Question。必须核对 absent/expired Question 的真实恢复来源，不能为了保留草稿留下已终态的影子 pending。还要审权威 source/directory 切换和旧 id 被不同 payload 重用的明确错误契约。

不要仅把 Dialog 改成非 keyed Show：其 render closure 对旧 `it` 的捕获、不同 id 切换时草稿串用及清理都需要单独分析。不要新增 localStorage 草稿第二源、按文字匹配、隐藏 replay 或伪造 answered。先取得 Main/SideChat before，再决定共同最小范围；现有 Question 子 Session 准入仍独立边界。

## 未知和准确范围

- 本轮没有任何新增 UI/运行结果；Work/Mission 独立 read/Permission 还待真实 checker，Question 丢稿也仍待完整同页实验。
- 没有声称 Task 全链完成、Mission 调度/恢复全部通过、所有并发队列/终态无误；如真实运行出现上述异常须立即按 AGENTS 横审所有相关入口。
- 主窗口 Dialog/inline、SideChat 草稿分别有 owner；跨页面/切 Session/关闭面板的保留并不在首个网络重连契约内。恢复更早 pending 改选 Dialog、自动 Question 超时、错误/拒绝及多 Question 是后续矩阵，不能偷换为本次简单例通过。
- 未检查/操作浏览器能力，未读取用户凭据、raw Provider 或运行 DB；控制 provider 只能证明真实产品执行路径，不代表 GPT-6.1 Sol 能力验收。若下一批需要真实 Sol，由 Root 按已有配对凭据+模型目录预检、流式及 fixed deadline 授权 scope 执行。
- 本次检索到并读取的测试是非 UI 传输/状态/HTTP 合同；没有新增或运行 UI 自动化。本 scratch 不要求新 spec 索引，Root 后续正式方案单独落盘。
