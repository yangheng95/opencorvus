# 404 人工断流 relay — 可复用交付

状态：2026-10-14，scratch 实现已冻结。只有 Node 原生 HTTP relay 和非 UI transport checker；未启动产品/模型/浏览器，未修改产品或测试目录。

## 文件与实际检查

- `http-relay.mjs`：唯一 byte-stream relay，导出 `startHttpRelay` / `requireSessionID`；Node `http.request` + pipe 保留未解压的 body。只排除 HTTP hop-by-hop/Connection 指定头并为原 upstream 重写 Host，end-to-end 请求/响应头（含重复 Set-Cookie）保留。
- `relay-driver.mjs`：自有 scope owner/ready/events/terminal，原 deadline/closeBy、本地文件 control 收据；不添加产品调试 API。
- `relay-control.mjs`：CLI 及 `sendRelayControl(scope, action, sessionID?)`，原 occurrence 配对、原子发布指令，返回收据。
- `relay-transport-checker.mjs`：Node 原始 HTTP 正向 checker；不含 DOM、浏览器、页面自动化或模型。

第一轮：`relay-check-1791926875094/result.json`，5 合同通过，relay PID 79640 原 spawn `close` code 0 / signal null。随后按 Root 要求将 driver 上限从 20min 精确修为 600000ms，并明确 liveness / physical identity 区分。

**最终运行**：`relay-check-1791926908114/result.json`，5 合同通过；原命令 `C:/Program Files/nodejs/node.exe .tmp-task-git-question-reconnect-404/relay-transport-checker.mjs`，tool exec chunk `99cc01` exit 0。该 checker 的原 Node child PID 61452 `close` code 0 / signal null，at 1791926908475；独立 upstream listener/socket 于 1791926908494 全部正常关闭。`command.json`、完整 child stdout/stderr、scope `owner.json`/`terminal.json`/control 收据保留。此后没有修改四个运行文件。

实际通过的是：PATCH 原 method/encoded path/query/8 binary bytes/header + response207/Set-Cookie；原 gzip wire bytes 与 encoding/length；第一 SSE chunk 在 upstream 尚未写后续段时就到达；exact Session 流被真实断开且另一个 Session 流继续输出并完成；同 Session 新 HTTP stream 返回完整跨 chunk Unicode 字节；手动 shutdown 后由原 checker 父进程等待 child `close`。这些是 transport 合同，不是 Question UI 或产品端到端验收。

## Root 集成方式

Root 必须在成熟 Main driver 的同一 `NodeProcess` owned_tree 内启动 relay child，绑定原 Main PID/occurrence，原 Main `deadlineAt` / `closeBy` 原值直传，不重新计算或续期。不要把下面的 argv 当作另起独立 deadline 的许可。

1. 在 404 scratch 写一个公开 config JSON：

```json
{
  "scope": "D:/myhexin-local/opencorvus/.tmp-task-git-question-reconnect-404/manual-before-01-relay",
  "upstream": "http://127.0.0.1:ACTUAL_PORT",
  "ownerPID": 12345,
  "ownerOccurrence": "ACTUAL_ORIGINAL_OCCURRENCE",
  "deadlineAt": 0,
  "closeBy": 0
}
```

上述数值均为需替换的结构示例。upstream 取原 ready URL 的 **origin**（不含 `/ui`、path、query、auth）。scope 是 404 下尚不存在的直接子目录。driver 严格验证 `now < closeBy < deadlineAt <= now+600000`，但不会证明 deadline 是否来自原 Main；原 Main receipts 和 Root owned driver 是该事实来源。

2. 原 NodeProcess child argv：`["D:/.../.tmp-task-git-question-reconnect-404/relay-driver.mjs", "D:/.../relay-config.json"]`，executable 使用当前 Node，Windows 隐藏窗口。只接受 loopback credential-free HTTP upstream。读取 `<scope>/ready.json` 的 `uiURL`，真实浏览器从该 URL `/ui` 首次进入，之后不换服务器、不 reload。
3. Root 已在真实页面输入草稿并留图后，手动一次：

```powershell
& 'C:/Program Files/nodejs/node.exe' .tmp-task-git-question-reconnect-404/relay-control.mjs <ABSOLUTE_SCOPE> status
& 'C:/Program Files/nodejs/node.exe' .tmp-task-git-question-reconnect-404/relay-control.mjs <ABSOLUTE_SCOPE> cut <EXACT_SESSION_ID>
```

只有 GET `/session/<exact-id>/events`（任意原 query 逐字转发）会匹配，切断的是该 Session 当前所有打开 stream pairs，receipt 给出 `cutCount` 与各 pairID。`cutCount:0` 是没有匹配流的事实，不能称发生重连。其它 Session、global events、普通 HTTP 不被该命令关闭。relay 不伪造任何 connected/Asked/replied，不重启后端；后续真正新 GET 由产品原 3s reconnect 发起。
4. 页面关闭后由原 Root owner调用 `shutdown`（同一 control CLI），或写 `<scope>/stop-requested`。driver 会关闭其 listener、入站/出站连接，写 terminal 并自然退出。最后 **Root 原 NodeProcess 等待 output/join**，再完成整个 Main 原 owner 关闭；不要用 terminal 文件存在代替子进程退出回执。

`kill(ownerPID,0)` 只是低成本只读 liveness 检查，不能验证 PID occurrence/创建时间，PID 复用等物理身份由 Root 父 `owned_tree` 与原 occurrence receipts 负责。relay terminal 明确仅报告 listener 已关闭、physical join 未确认；它不自行报告已 join。原 deadline 不变，closeBy 自动关闭是兜住既有期限的生命周期动作，不是业务 fallback 或页面验收。

## 界限

本 helper 转发普通 HTTP/1 请求与 response entity bytes；未实现 WebSocket/Upgrade，也没有宣称其经过检查。没有压缩解码/重编码、页面脚本注入、事件解码/编辑、自动点击/输入/截图。仅记录 sessionID/pairID/时间/控制结果，不记录 header 或 payload；checker 的 header/body 只用明示公开夹具。Root 的真实服务器/模型关闭责任仍在原 owner。最终 checker 已 join，不留本 agent 活跃服务。
