// ── Entry Point ──
// Self-sufficient Solid.js entry point.
// Mounts all Solid components and initialises the application.
// Self-sufficient — no external script dependencies.

import "@fontsource-variable/geist/index.css"
import "@fontsource-variable/noto-sans-sc/index.css"
import "@fontsource-variable/jetbrains-mono/index.css"
import { insert, render } from "solid-js/web"
import {
  batch,
  createRoot,
  createEffect,
  createMemo,
  createSignal,
  For,
  onCleanup,
  onMount,
  on,
  untrack,
} from "solid-js"
import { App } from "./components/App"
import { Icon, LUCIDE_ICON_NAMES, REGISTERED_ICONS, type IconName } from "./components/ui/Icon"
import { Conversation } from "./components/Conversation"
import { GoalsBoardPanel, RequirementsBoardPanel } from "./components/Board"
import { ChatComposer } from "./components/ChatComposer"
import {
  DEFAULT_COMPOSER_INTENT,
  conversationExperienceFromProductPillar,
  productPillarFromConversationExperience,
  resolveComposerIntentRoute,
  type ComposerIntent,
} from "@opencorvus-ai/transport-protocol"
import { WorkLedger } from "./components/WorkLedger"
import { MissionBoard } from "./components/MissionBoard"
import type { MissionCreateRequest, MissionManualCreateRequest } from "./components/MissionCreateDialog"
import {
  setWorkLedgerItemPinned,
  workLedgerActiveItem,
  workLedgerProjectDirectories,
  workLedgerSessionExecution,
  workLedgerSessionInterruptible,
} from "./services/work-ledger"
import { LogViewer } from "./components/LogViewer"
import { FileExplorerPanel } from "./components/FileExplorerPanel"
import { FileChangesPanel } from "./components/FileChangesPanel"
import { BrowserPreviewPanel, type BrowserPreviewPanelController } from "./components/BrowserPreviewPanel"
import {
  browserPreviewNativeSurfaceAvailable,
  browserPreviewNativeUrlNavigationAvailable,
} from "./services/browser-preview-native"
import { browserPreviewRevision } from "./services/browser-preview"
import { ScreenshotBrowserPanel } from "./components/ScreenshotBrowserPanel"
import { SubagentConversationPanel } from "./components/SubagentConversationPanel"
import { SideChatPanel, type SideChatRequest } from "./components/SideChatPanel"
import { QuotationSelection } from "./components/QuotationSelection"
import { setComposerQuotation } from "./services/composer-draft"
import type { Quotation } from "./services/quotation"
import { RightDock, type RightDockPanel, type RightDockTab } from "./components/RightDock"
import { FileEditorPane } from "./components/FileEditorPane"
import { MailboxPanel } from "./components/MailboxPanel"
import { Button } from "./components/ui/Button"
import { TabPanel } from "./components/ui/Tabs"
import {
  closeFileEditor,
  hasUnsavedFileChanges,
  fileEditorRevealRevision,
  fileWorkbenchOpen,
  fileEditorReserved,
} from "./services/file-workbench"
import { initApp } from "./services/init"
import {
  boardStore,
  activeBrowserPreviewTaskID,
  activeTaskID,
  activeSessionID,
  clearBoard,
  rootTaskSessionID,
  setBoardStore,
  setSelectedSource,
  type BoardSource,
} from "./store/board"
import { abortChatRequest, messageStore, setChatAttachments } from "./store/messages"
import { loadConversationUiStateForSource } from "./store/conversation-ui"
import { appStore } from "./store/app"
import { clearComposerModelProjection, projectComposerModelFromSession } from "./services/composer-model"
import { projectComposerIntent, rememberProjectComposerIntent } from "./services/project-composer-preferences"
import { rightDockOpen, setRightDockVisible } from "./store/right-dock"
import { dialogStore } from "./store/dialog"
import { selectTask, cancelTask, setTaskArchived, renameTask, downloadTaskProjectArchive } from "./services/task"
import { canComposeChat, stopChatRequest } from "./services/chat"
import { isTaskInterruptable } from "./store/board"
import { loadAllLocales, localeTag, setLocale } from "./utils/i18n"
import {
  apiJson,
  configure as configureApi,
  captureApiAuthority,
  assertApiAuthorityCurrent,
  isApiAuthorityCurrent,
  ApiAuthorityChangedError,
} from "./services/api"
import type { AutomationRunSession } from "./services/automations"
import { t } from "./utils/i18n"
import {
  elementFileReference,
  FILE_REFERENCE_PATH_ATTRIBUTE,
  PROJECT_FILE_REFERENCE_PATH_ATTRIBUTE,
} from "./utils/file-reference"
import { applyTheme, applyZoom, handleZoomHotkey, installSystemThemeListener, toggleDevtools } from "./services/theme"
import { bumpWorkspaceEpoch, settingsStore, setSettingsStore, saveSettings } from "./store/settings"
import {
  initPaneResizers,
  cancelPaneResize,
  renderPaneLayout,
  PANEL_PANE_CONFIG,
  type PaneState,
} from "./services/pane"
import { panelMessage } from "./services/chat"
import { loadConversationCapability } from "./services/conversation-capability"
import {
  expertSquadPublicMarketURL,
  inspectExpertSquad,
  installExpertSquadMarketPackage,
  loadExpertSquadCatalog,
  loadExpertSquadMarket,
  searchExpertSquads,
  type ExpertSquadCatalogScope,
  type ExpertSquadMarketIndexItem,
  type ExpertSquadOption,
} from "./services/expert-squad"
import { loadMissionSkillCatalog } from "./services/mission-skill"
import { loadGlobalComposerReferences, searchGlobalComposerExpertSquads } from "./services/global-composer-references"
import { resolveComposerSubmitRoute } from "./services/composer-submit-route"
import {
  VisibleComposerReferences as VisibleComposerReferencesSchema,
  visibleComposerReferences,
  type ProductPillar,
  type VisibleComposerReferences,
} from "@opencorvus-ai/transport-protocol"
import { waitForLogDrain, AppLog } from "./utils/log"
import { teardownApp } from "./services/init"
import { nativeOpen } from "./utils/native"
import { getHostTransport } from "./services/host-transport-runtime"
import { startDesktopUpdateMonitor, stopDesktopUpdateMonitor } from "./services/desktop-update"
import { installNativeWindowCloseLifecycle } from "./services/native-window-lifecycle"
import { showOverlayWindow } from "./services/window"
import { installExpertSquadInstallHandoffBridge } from "./services/expert-squad-install-handoff"
import { hydrateIconPlaceholders, installIconHtmlRenderer } from "./utils/icon-html"
import { installNativeContextMenuSuppression } from "./utils/context-menu"
import {
  reportError,
  reportSuccess,
  reportWarning,
  formatErrorDetails,
  runPostCommitUiEffect,
} from "./services/diagnostics"
import { showAppDialog } from "./services/app-dialog"
import {
  applyDirectory,
  activeDirectory,
  beginWorkspaceSelection,
  requestWorkspaceSelection,
  browseDirectory,
  resolveGlobalComposerProject,
  resolveGlobalComposerSubmissionContext,
  supersedePendingWorkspaceSelection,
  deleteProjectState,
  leaveUnavailableProject,
  openGlobalChatLauncher,
  openDirectory,
  openPathInSelectedEditor,
  openProjectFile,
  ownsWorkspaceSelection,
  pickDirectory,
  promoteAnonymousProject,
  renameProjectRecord,
} from "./services/workspace"
import { openGoalDialog } from "./services/dialog"
import { closeConfigDialog, openConfigDialog } from "./services/config-dialog-control"
import { installClipboardApiKeyPrompt } from "./services/clipboard-api-key-prompt"
import { cardTreeStore } from "./store/card-tree"
import { workspaceComposerDraftKey, composerDraftText, setComposerDraft } from "./services/composer-draft"
import { normalizeDebugDirectory } from "./utils/debug-text"
import {
  cancelConversationReplay,
  loadConversation,
  optionalConversationSourceDirectory,
  resetConversationProjection,
} from "./services/conversation"
import {
  conversationSourceExperience,
  createConversationSession,
  createGlobalConversationSession,
  activeConversationHandoff,
  isConversationSource,
  renameConversationSession,
  selectConversationSession,
  setConversationSessionArchived,
  stopConversationSession,
} from "./services/conversation-session"
import {
  abortMission,
  activeMissionHandoff,
  createMissionDraft,
  deleteMission,
  dispatchMission,
  editMissionDraft,
  downloadMissionProjectArchive,
  renameMission,
  setMissionArchived,
  wakeMission,
  type MissionRecord,
  type MissionWakeResult,
} from "./services/mission"
import type { WorkLedgerChatRow, WorkLedgerMissionRow, WorkLedgerTaskRow } from "./services/work-ledger"
import { setWorkLedgerChangeHandler, startSSE, stopSSE, type WorkLedgerStreamEvent } from "./services/sse"
import { refreshProjectMemory } from "./services/project-memory"
import { openImagePreview } from "./services/image-preview"
import {
  buildChatDebugBlob,
  buildTaskDebugBlob,
  buildTaskSelectionErrorDebugBlob,
  requireDebugProjectDirectory,
  writeDebugClipboard,
} from "./utils/debug-info"
import { taskOwningDirectory } from "./services/task-directory"
import { taskScopedPath } from "./services/task-path"
import { loadPersistedChatDebugProjection } from "./services/session-debug"
import { registerReviewPanelPresenter, requestReviewPanel } from "./services/review-focus"
import { createAnimationFrameScheduler } from "./utils/animation-frame"
import {
  composerReferenceCatalogRequestKey,
  composerReferenceCatalogScope,
  type ComposerReferenceCatalogScopeState,
} from "./services/expert-squad-scope"
import {
  composerExpertSquadCatalogForRequest,
  composerReferenceCatalogError,
  createGlobalComposerReferenceCatalogSnapshot,
  createComposerReferenceCatalogSnapshotFromSettled,
  emptyComposerExpertSquadCatalog,
  failedComposerReferenceCatalogSnapshot,
  updateComposerExpertSquadSearch,
} from "./services/composer-expert-squad-catalog"
import { currentUIScale, layoutTokenPx } from "./utils/layout-tokens"
import { copyText } from "./services/clipboard"

// ── Module teardown ──
// Centralised cleanup for top-level document/window listeners and the Solid root.
// Triggered on final pagehide and on Vite HMR dispose so subsequent module
// re-executions don't stack duplicate handlers and effects.
const moduleTeardown = new AbortController()
const disposers: Array<() => void> = []
function runModuleTeardown() {
  if (moduleTeardown.signal.aborted) return
  moduleTeardown.abort()
  for (const dispose of disposers.splice(0)) dispose()
  teardownApp()
}
if ((import.meta as any).hot) {
  ;(import.meta as any).hot.dispose(runModuleTeardown)
}
const listenerOpts = { signal: moduleTeardown.signal } as const
const REGISTERED_ICON_NAMES = new Set<string>(REGISTERED_ICONS)
const LUCIDE_ICON_NAME_SET = new Set<string>(LUCIDE_ICON_NAMES)

let pendingPaneLayoutState: PaneState | null = null

function flushPaneLayout(): void {
  const state = pendingPaneLayoutState
  pendingPaneLayoutState = null
  if (!state) return
  renderPaneLayout(state, PANEL_PANE_CONFIG)
}

const renderPaneLayoutOnFrame = createAnimationFrameScheduler(flushPaneLayout)
disposers.push(() => renderPaneLayoutOnFrame.cancel())

function schedulePaneLayout(state: PaneState): void {
  pendingPaneLayoutState = { ...state }
  renderPaneLayoutOnFrame.schedule()
}

function iconHtmlName(name: string): IconName {
  if (!REGISTERED_ICON_NAMES.has(name)) throw new Error(`Unknown icon "${name}"`)
  return name as IconName
}

function iconHtmlClassName(name: string, className?: string): string {
  if (LUCIDE_ICON_NAME_SET.has(name)) return className ?? ""
  return ["lucide", `lucide-${name}`, className].filter(Boolean).join(" ")
}

function measureScrollbarGutter(elementIdentifier: string): number {
  const scroll = document.getElementById(elementIdentifier)
  if (!scroll) throw new Error(`Scrollbar gutter measurement requires #${elementIdentifier}.`)
  const gutter = scroll.offsetWidth - scroll.clientWidth
  if (!Number.isFinite(gutter) || gutter < 0) {
    throw new Error(`Scrollbar gutter for #${elementIdentifier} resolved to invalid width: ${gutter}`)
  }
  return gutter
}

function syncScrollbarGutters(): void {
  const rootStyle = document.documentElement.style
  rootStyle.setProperty("--ui-chat-scrollbar-gutter-x", `${measureScrollbarGutter("chatScroll")}px`)
  rootStyle.setProperty("--ui-left-rail-scrollbar-gutter-x", `${measureScrollbarGutter("workLedgerProjectsScroll")}px`)
}

const syncScrollbarGuttersOnFrame = createAnimationFrameScheduler(syncScrollbarGutters)
disposers.push(() => syncScrollbarGuttersOnFrame.cancel())

disposers.push(
  installIconHtmlRenderer(({ name, size, className }) => {
    const resolvedName = iconHtmlName(name)
    const host = document.createElement("span")
    insert(host, Icon({ name: resolvedName, size, class: iconHtmlClassName(resolvedName, className) }))
    return host.innerHTML
  }),
)
installNativeContextMenuSuppression(document, moduleTeardown.signal)
hydrateIconPlaceholders(document)

const BROWSER_RESIZE_OBSERVER_DELIVERY_MESSAGES = new Set([
  "ResizeObserver loop completed with undelivered notifications.",
  "ResizeObserver loop limit exceeded",
])

function runtimeErrorMessage(error: unknown): string {
  return error instanceof Error ? error.message : String(error)
}

function isBrowserResizeObserverDeliveryError(error: unknown): boolean {
  return BROWSER_RESIZE_OBSERVER_DELIVERY_MESSAGES.has(runtimeErrorMessage(error))
}

function reportOverlayRuntimeError(scope: string, error: unknown): void {
  if (!appStore.i18nReady) {
    console.error(`[${scope}]`, error)
    return
  }
  const details = formatErrorDetails(error)
  const message = runtimeErrorMessage(error)
  const diagnosticDetails = details ? `source: ${scope}\n\n${details}` : `source: ${scope}`
  if (isBrowserResizeObserverDeliveryError(error)) {
    AppLog.debug("runtime", scope, {
      message,
      details,
    })
    return
  }
  AppLog.error("runtime", scope, {
    message,
    details,
    diagnosticID: `runtime:${scope}`,
    title: t("common.error"),
    diagnosticMessage: message,
    diagnosticDetails,
  })
}

function runMainAsync(scope: string, action: () => void | Promise<void>): Promise<void> {
  const report = (error: unknown) => {
    if (error instanceof ApiAuthorityChangedError) {
      AppLog.warn(scope, "Operation belongs to a previous connection", {
        phase: error.phase,
        expectedRevision: error.expectedRevision,
        currentRevision: error.currentRevision,
      })
      return
    }
    reportOverlayRuntimeError(scope, error)
  }
  try {
    return Promise.resolve(action()).catch((error) => {
      report(error)
    })
  } catch (error) {
    report(error)
    return Promise.resolve()
  }
}

function runUserNavigation(scope: string, action: () => void | Promise<void>): Promise<void> {
  return runMainAsync(scope, async () => {
    try {
      await action()
    } catch (error) {
      if (error instanceof DOMException && error.name === "AbortError") return
      throw error
    }
  })
}

document.documentElement.dataset.platform = __OPENCORVUS_BUILD_PLATFORM__

if (__OPENCORVUS_BUILD_PLATFORM__ === "darwin" && getHostTransport().kind === "tauri") {
  document.documentElement.dataset.nativeTitlebar = "macos"
}

runMainAsync("native-window.close-lifecycle", async () => {
  const dispose = await installNativeWindowCloseLifecycle()
  if (!dispose) return
  if (moduleTeardown.signal.aborted) {
    dispose()
    return
  }
  disposers.push(dispose)
})

function persistMainSettings(scope: string): void {
  runMainAsync(scope, () => saveSettings())
}

window.addEventListener(
  "error",
  (event) => {
    reportOverlayRuntimeError("window.error", event.error ?? event.message)
  },
  listenerOpts,
)

window.addEventListener(
  "unhandledrejection",
  (event) => {
    reportOverlayRuntimeError("window.unhandledrejection", event.reason)
  },
  listenerOpts,
)

// ── Application-level signals (shared across mount points) ──

const [logOpen, setLogOpen] = createSignal(false)

window.addEventListener("oc:open-logs", () => setLogOpen(true), listenerOpts)

type CenterWorkbenchPanel =
  | "conversation"
  | "requirements"
  | "goals"
  | "explorer"
  | "diff"
  | "browser"
  | "screenshots"
  | "subagent"
  | "side-chat"
  | "file"
type PrimaryCenterPanel = "task" | "mission" | "chat"
type PrimaryWorkspaceSurface = "conversation" | "mission-board"
type CenterWorkbenchTab = {
  id: string
  panel: CenterWorkbenchPanel
  taskPreview?: true
}

const CENTER_WORKBENCH_PANEL_ORDER: readonly CenterWorkbenchPanel[] = [
  "conversation",
  "requirements",
  "goals",
  "explorer",
  "diff",
  "browser",
  "screenshots",
  "subagent",
  "side-chat",
  "file",
]

const [centerWorkbenchPanels, setCenterWorkbenchPanels] = createSignal<CenterWorkbenchTab[]>([
  { id: "conversation", panel: "conversation" },
])
const [selectedCenterWorkbenchTabID, setSelectedCenterWorkbenchTabID] = createSignal("conversation")
const [rightDockAddMenuOpen, setRightDockAddMenuOpen] = createSignal(false)
const [rightDockOverflowMenuOpen, setRightDockOverflowMenuOpen] = createSignal(false)
const [browserPreviewPageTitles, setBrowserPreviewPageTitles] = createSignal<Record<string, string>>({})
let primaryBrowserPreviewController: BrowserPreviewPanelController | undefined
let pendingPrimaryBrowserPreviewNavigation: { url: string } | undefined
const [selectedSubagentSessionID, setSelectedSubagentSessionID] = createSignal("")
const [sideChatRequest, setSideChatRequest] = createSignal<SideChatRequest>()

function sideChatSource() {
  const source = boardStore.selectedSource
  const sessionID = source?.kind === "session" ? source.id : rootTaskSessionID()
  const directory = activeDirectory().trim()
  return sessionID && directory ? { sessionID, directory, authority: captureApiAuthority() } : undefined
}

function quoteInMain(quotation: Quotation) {
  if (fileEditorReserved()) return
  setComposerQuotation(panelComposerDraftKey(), quotation)
  queueMicrotask(() => document.querySelector<HTMLTextAreaElement>("#solidChatComposer textarea")?.focus())
}

function requestSideChat(quotation?: Quotation, prompt?: string) {
  if (fileEditorReserved()) return
  const source = sideChatSource()
  if (!source) throw new Error(t("side_chat.source_required"))
  setSideChatRequest({ source, intent: quotation || prompt?.trim() ? "fork" : "open", quotation, prompt })
  showRightDockForExplicitAction()
  openCenterWorkbenchPanel("side-chat")
}
const [primaryCenterPanel, setPrimaryCenterPanel] = createSignal<PrimaryCenterPanel>("chat")
const [primaryWorkspaceSurface, setPrimaryWorkspaceSurface] = createSignal<PrimaryWorkspaceSurface>("conversation")
const [missionSharedRefreshToken, setMissionSharedRefreshToken] = createSignal(0)
const [missionLauncherSubmitting, setMissionLauncherSubmitting] = createSignal(false)
const [expertSquadLauncherSubmitting, setExpertSquadLauncherSubmitting] = createSignal(false)
const [assistantLauncherSubmitting, setAssistantLauncherSubmitting] = createSignal(false)
setWorkLedgerChangeHandler(handleWorkLedgerStreamEvent)
disposers.push(() => setWorkLedgerChangeHandler(null))
const [composerIntent, setComposerIntent] = createSignal<ComposerIntent>(DEFAULT_COMPOSER_INTENT)

createEffect(() => {
  const directory = activeDirectory()
  const intent = projectComposerIntent(settingsStore.serverUrl, directory)
  if (directory && !boardStore.selectedSource) {
    setComposerIntent(intent)
    setPrimaryCenterPanel(intent.conversationTarget === "mission" ? "mission" : "chat")
  }
})

function isCenterWorkbenchPanelOpen(panel: CenterWorkbenchPanel): boolean {
  return centerWorkbenchPanels().some((tab) => tab.panel === panel)
}

let pendingCenterWorkbenchRevealPanel: CenterWorkbenchPanel | null = null

function revealPendingCenterWorkbenchPanel(): void {
  const panel = pendingCenterWorkbenchRevealPanel
  pendingCenterWorkbenchRevealPanel = null
  if (!panel) return
  getCenterWorkbenchViews()[panel]?.scrollIntoView({ block: "nearest", inline: "nearest" })
}

function resetCenterWorkbenchToPrimaryPanel(panel: PrimaryCenterPanel): void {
  setPrimaryWorkspaceSurface("conversation")
  setRightDockVisible(false)
  setSelectedSubagentSessionID("")
  setPrimaryCenterPanel(panel)
  setCenterWorkbenchPanels([{ id: "conversation", panel: "conversation" }])
  setSelectedCenterWorkbenchTabID("conversation")
  scheduleCenterWorkbenchPanelReveal("conversation")
}

function assertUserNavigationCurrent(selectionEpoch: number): void {
  if (!ownsWorkspaceSelection(selectionEpoch)) throw new DOMException("Workspace navigation superseded", "AbortError")
}

function revealCurrentConversationFromBoard(): void {
  if (primaryWorkspaceSurface() === "mission-board") setPrimaryWorkspaceSurface("conversation")
}

async function selectTaskWithUILifecycle(taskID: string, directory: string): Promise<void> {
  const authority = captureApiAuthority()
  const admission = await requestWorkspaceSelection({ kind: "task", id: taskID, directory })
  assertApiAuthorityCurrent(authority)
  if (admission.kind === "unchanged") {
    revealCurrentConversationFromBoard()
    return
  }
  await closeConfigDialog()
  assertApiAuthorityCurrent(authority)
  assertUserNavigationCurrent(admission.epoch)
  const row = workLedgerActiveItem({ taskID, sessionID: undefined })
  if (row?.kind === "task") {
    setComposerIntent({ productPillar: row.productPillar, conversationTarget: "mission" })
  }
  resetCenterWorkbenchToPrimaryPanel("task")
  await selectTask(taskID, { directory, selectionEpoch: admission.epoch, authority })
  if (!isApiAuthorityCurrent(authority)) return
  assertUserNavigationCurrent(admission.epoch)
}

async function selectConversationWithUILifecycle(
  sessionID: string,
  directory: string,
  experience: "chat" | "work",
): Promise<void> {
  const authority = captureApiAuthority()
  const admission = await requestWorkspaceSelection({
    kind: "session",
    id: sessionID,
    directory,
    sessionKind: "conversation",
    experience,
  })
  assertApiAuthorityCurrent(authority)
  if (admission.kind === "unchanged") {
    revealCurrentConversationFromBoard()
    return
  }
  await closeConfigDialog()
  assertApiAuthorityCurrent(authority)
  assertUserNavigationCurrent(admission.epoch)
  setComposerIntent({ productPillar: productPillarFromConversationExperience(experience), conversationTarget: "chat" })
  bumpWorkspaceEpoch()
  resetCenterWorkbenchToPrimaryPanel("chat")
  await selectConversationSession({ sessionID, directory, experience, selectionEpoch: admission.epoch, authority })
  if (!isApiAuthorityCurrent(authority)) return
  assertUserNavigationCurrent(admission.epoch)
}

async function openAutomationSession(session: AutomationRunSession): Promise<void> {
  if (session.kind === "mission") {
    if (!session.productPillar) throw new Error("Mission automation session is missing its persisted product pillar")
    await openMissionWithUILifecycle({ sessionID: session.id, productPillar: session.productPillar }, session.directory)
    return
  }
  await selectConversationWithUILifecycle(session.id, session.directory, session.experience ?? "chat")
}

function showRightDockForExplicitAction(): void {
  if (primaryWorkspaceSurface() === "mission-board") setPrimaryWorkspaceSurface("conversation")
  setRightDockVisible(true)
}

function openRightDockPanel(panel: RightDockPanel): void {
  if (panel === "side-chat") {
    requestSideChat()
    return
  }
  showRightDockForExplicitAction()
  openCenterWorkbenchPanel(panel)
}

function presentRightDockPanel(panel: RightDockPanel): void {
  if (primaryWorkspaceSurface() !== "conversation") return
  setRightDockVisible(true)
  openCenterWorkbenchPanel(panel)
}

function openSubagentConversation(sessionID: string): void {
  const value = sessionID.trim()
  if (!value) throw new Error("Sub-agent conversation session ID is required")
  setSelectedSubagentSessionID(value)
  openRightDockPanel("subagent")
}

function openRightDockAddMenu(): void {
  showRightDockForExplicitAction()
  setRightDockOverflowMenuOpen(false)
  setRightDockAddMenuOpen(true)
}

function registerPrimaryBrowserPreviewController(controller: BrowserPreviewPanelController): () => void {
  primaryBrowserPreviewController = controller
  const pendingNavigation = pendingPrimaryBrowserPreviewNavigation
  if (pendingNavigation) {
    queueMicrotask(() => {
      if (
        primaryBrowserPreviewController !== controller ||
        pendingPrimaryBrowserPreviewNavigation !== pendingNavigation
      ) {
        return
      }
      pendingPrimaryBrowserPreviewNavigation = undefined
      controller.navigate(pendingNavigation.url)
    })
  }
  return () => {
    if (primaryBrowserPreviewController === controller) primaryBrowserPreviewController = undefined
  }
}

function openBrowserPreviewFromMessage(url: string): void {
  const controller = primaryBrowserPreviewController
  if (controller) {
    pendingPrimaryBrowserPreviewNavigation = undefined
    controller.navigate(url)
    openRightDockPanel("browser")
    return
  }
  pendingPrimaryBrowserPreviewNavigation = { url }
  openRightDockPanel("browser")
}

function isMissionSessionSource(): boolean {
  return boardStore.selectedSource?.kind === "session" && !isConversationSource()
}

function handleWorkLedgerStreamEvent(event: WorkLedgerStreamEvent): void {
  const authority = captureApiAuthority()
  setMissionSharedRefreshToken((value) => value + 1)
  if (event.type === "work-ledger.changed" && event.sourceType === "project.memory.notice.changed") {
    void refreshProjectMemory({ authority }).catch((error) => {
      if (isApiAuthorityCurrent(authority))
        AppLog.warn("project-memory", "Project MEMORY.MD notice refresh failed", { error: String(error) })
    })
  }
  const selectedSource = boardStore.selectedSource
  const missionHandoff = activeMissionHandoff(event, selectedSource)
  if (missionHandoff) {
    runMainAsync("work-ledger.mission-handoff", async () => {
      try {
        const opened = await openMissionSession(
          missionHandoff,
          missionHandoff.directory,
          beginWorkspaceSelection(),
          authority,
        )
        if (!opened) return
      } catch (error) {
        if (error instanceof DOMException && error.name === "AbortError") return
        throw error
      }
      await archiveConversationHandoffCaller(
        {
          sessionID: missionHandoff.callerSessionID,
          directory: missionHandoff.directory,
          experience: missionHandoff.callerExperience,
        },
        authority,
      )
    })
    return
  }
  const conversationHandoff = activeConversationHandoff(event, selectedSource)
  if (!conversationHandoff) return
  runMainAsync("work-ledger.conversation-handoff", async () => {
    const selectionEpoch = beginWorkspaceSelection()
    try {
      await selectConversationSession({
        authority,
        sessionID: conversationHandoff.sessionID,
        directory: conversationHandoff.directory,
        experience: conversationHandoff.experience,
        selectionEpoch,
      })
      if (!ownsWorkspaceSelection(selectionEpoch) || !isApiAuthorityCurrent(authority)) return
      setComposerIntent({
        productPillar: productPillarFromConversationExperience(conversationHandoff.experience),
        conversationTarget: "chat",
      })
      setPrimaryCenterPanel("chat")
    } catch (error) {
      if (error instanceof DOMException && error.name === "AbortError") return
      throw error
    }
    await archiveConversationHandoffCaller(
      {
        sessionID: conversationHandoff.callerSessionID,
        directory: conversationHandoff.directory,
        experience: conversationHandoff.callerExperience,
      },
      authority,
    )
  })
}

async function archiveConversationHandoffCaller(
  target: {
    sessionID: string
    directory: string
    experience: "chat" | "work"
  },
  authority = captureApiAuthority(),
): Promise<void> {
  assertApiAuthorityCurrent(authority)
  const archived = await setConversationSessionArchived({ ...target, authority }, true)
  if (!isApiAuthorityCurrent(authority)) return
  if (!archived) throw new Error(t("coding_assistant.archive_failed"))
  setMissionSharedRefreshToken((value) => value + 1)
}

function focusComposerInput(): void {
  queueMicrotask(() => {
    document.querySelector<HTMLTextAreaElement>("#solidChatComposer textarea")?.focus()
  })
}

async function applyComposerIntent(
  intent: ComposerIntent,
  selectionEpoch: number,
  authority = captureApiAuthority(),
): Promise<void> {
  assertApiAuthorityCurrent(authority)
  assertUserNavigationCurrent(selectionEpoch)
  const currentDraftKey = panelComposerDraftKey()
  const launcherDraftKey = newRequestComposerDraftKey()
  const currentDraft = composerDraftText(currentDraftKey)
  if (currentDraftKey !== launcherDraftKey && currentDraft) setComposerDraft(launcherDraftKey, currentDraft)
  setComposerIntent(intent)
  runMainAsync("composer.remember-project-intent", () => rememberProjectComposerIntent(activeDirectory(), intent))
  resetCenterWorkbenchToPrimaryPanel(intent.conversationTarget === "mission" ? "mission" : "chat")
  await selectTask("", { preserveComposerAttachments: true, selectionEpoch, authority })
  if (!isApiAuthorityCurrent(authority)) return
  assertUserNavigationCurrent(selectionEpoch)
  focusComposerInput()
}

async function handleComposerIntentChange(intent: ComposerIntent): Promise<void> {
  const authority = captureApiAuthority()
  const admission = await requestWorkspaceSelection()
  if (admission.kind === "unchanged") return
  await closeConfigDialog()
  assertApiAuthorityCurrent(authority)
  await applyComposerIntent(intent, admission.epoch, authority)
}

async function selectWorkLedgerTask(row: WorkLedgerTaskRow): Promise<void> {
  await selectTaskWithUILifecycle(row.id, row.directory)
}

async function openWorkLedgerChat(row: WorkLedgerChatRow): Promise<void> {
  await selectConversationWithUILifecycle(row.sessionID, row.directory, row.experience)
}

async function openGlobalComposer(intent: ComposerIntent): Promise<void> {
  const authority = captureApiAuthority()
  const admission = await requestWorkspaceSelection()
  if (admission.kind === "unchanged") return
  await closeConfigDialog()
  assertApiAuthorityCurrent(authority)
  await openGlobalChatLauncher(admission.epoch)
  assertApiAuthorityCurrent(authority)
  await applyComposerIntent(intent, admission.epoch, authority)
}

async function startWorkLedgerMulticaImport(directory: string): Promise<void> {
  const authority = captureApiAuthority()
  const projectDirectory = directory.trim()
  if (!projectDirectory) throw new Error(t("project.new_chat_missing_directory"))
  const model = appStore.composerModel.trim()
  if (!model) {
    await showAppDialog({
      title: t("multica_import.model_required_title"),
      message: t("multica_import.model_required_message"),
      kind: "warning",
    })
    return
  }
  const confirmation = await showAppDialog({
    title: t("multica_import.confirm_title"),
    message: t("multica_import.confirm_message", { directory: projectDirectory }),
    cancel: true,
    okLabel: t("multica_import.confirm_action"),
  })
  if (!confirmation.confirmed) return
  assertApiAuthorityCurrent(authority)
  const admission = await requestWorkspaceSelection()
  assertApiAuthorityCurrent(authority)
  if (admission.kind === "unchanged") return
  const selectionEpoch = admission.epoch
  if (!ownsWorkspaceSelection(selectionEpoch)) throw new DOMException("Mission action superseded", "AbortError")
  resetCenterWorkbenchToPrimaryPanel("mission")
  setMissionLauncherSubmitting(true)
  try {
    const result = await wakeMission({
      authority,
      directory: projectDirectory,
      text: t("multica_import.mission_request"),
      model,
      productPillar: "code",
      expertSquadIDs: [],
    })
    if (!isApiAuthorityCurrent(authority)) return
    await openMissionSession(result, projectDirectory, selectionEpoch, authority)
    if (!isApiAuthorityCurrent(authority)) return
    setMissionSharedRefreshToken((value) => value + 1)
  } finally {
    if (isApiAuthorityCurrent(authority)) setMissionLauncherSubmitting(false)
  }
}

async function selectWorkLedgerProject(directory: string): Promise<void> {
  const authority = captureApiAuthority()
  const projectDirectory = directory.trim()
  if (!projectDirectory) throw new Error(t("project.new_chat_missing_directory"))
  const admission = await requestWorkspaceSelection()
  if (admission.kind === "unchanged") return
  await closeConfigDialog()
  assertApiAuthorityCurrent(authority)
  assertUserNavigationCurrent(admission.epoch)
  const intent = projectComposerIntent(settingsStore.serverUrl, projectDirectory)
  setComposerIntent(intent)
  resetCenterWorkbenchToPrimaryPanel(intent.conversationTarget === "mission" ? "mission" : "chat")
  await applyDirectory(projectDirectory, {
    save: true,
    restoreWorkspace: false,
    selectionEpoch: admission.epoch,
    authority,
  })
  if (!isApiAuthorityCurrent(authority)) return
  assertUserNavigationCurrent(admission.epoch)
  bumpWorkspaceEpoch()
  focusComposerInput()
}

async function deleteWorkLedgerProject(directory: string): Promise<void> {
  const authority = captureApiAuthority()
  const projectDirectory = directory.trim()
  if (!projectDirectory) throw new Error(t("project.delete_missing_directory"))
  const dialog = await showAppDialog({
    title: t("project.delete_title"),
    message: t("project.delete_confirm", { directory: projectDirectory }),
    cancel: true,
    okLabel: t("common.delete"),
    okTone: "danger",
  })
  if (!dialog.confirmed) return
  assertApiAuthorityCurrent(authority)
  const outcome = await deleteProjectState(
    projectDirectory,
    {
      surface: "overlay.work_ledger",
      reason: "Operator deleted the project from Work Ledger",
    },
    authority,
  )
  if (!isApiAuthorityCurrent(authority)) return
  const diagnosticID =
    outcome.status === "deleted"
      ? `project:delete:${outcome.result.projectID}`
      : `project:delete:already-absent:${projectDirectory}`
  runPostCommitUiEffect({ id: `${diagnosticID}:close`, title: "Project deletion committed" }, () => {
    if (activeDirectory().trim() === projectDirectory) {
      void leaveUnavailableProject(projectDirectory).catch((error) => {
        reportError({
          id: `${diagnosticID}:directory-free-workspace`,
          title: "Project deletion committed but workspace transition failed",
          message: error instanceof Error ? error.message : String(error),
          details: formatErrorDetails(error),
        })
      })
    }
  })
  runPostCommitUiEffect({ id: `${diagnosticID}:refresh`, title: "Project deletion committed" }, () => {
    setMissionSharedRefreshToken((value) => value + 1)
  })
  runPostCommitUiEffect({ id: `${diagnosticID}:notification`, title: "Project deletion committed" }, () => {
    const directory = outcome.status === "deleted" ? outcome.result.directory : outcome.directory
    if (outcome.status === "deleted" && outcome.result.status === "committed_with_residue") {
      reportWarning({
        id: diagnosticID,
        title: t("project.delete_cleanup_pending_title"),
        message: t("project.delete_cleanup_pending", {
          directory,
          reason: outcome.result.residue.map((item) => `${item.path}: ${item.message}`).join("; "),
        }),
      })
      return
    }
    reportSuccess({
      id: diagnosticID,
      title: t("project.delete_success_title"),
      message: t("project.delete_success", { directory }),
    })
  })
}

async function openWorkLedgerProjectDirectory(directory: string): Promise<void> {
  const projectDirectory = directory.trim()
  if (!projectDirectory) throw new Error(t("project.open_missing_directory"))
  await openDirectory(projectDirectory)
}

async function renameWorkLedgerProject(directory: string, currentName: string): Promise<void> {
  const authority = captureApiAuthority()
  const projectDirectory = directory.trim()
  if (!projectDirectory) throw new Error(t("project.rename_missing_directory"))
  const dialog = await showAppDialog({
    title: t("project.rename_title"),
    message: t("project.rename_message", { directory: projectDirectory }),
    input: true,
    inputLabel: t("project.rename_input_label"),
    inputValue: currentName.trim(),
    inputPlaceholder: t("project.rename_input_placeholder"),
    inputRequired: true,
    inputRequiredMessage: t("project.rename_name_required"),
    cancel: true,
    okLabel: t("project.rename_menu_label"),
  })
  if (!dialog.confirmed) return
  const name = String(dialog.value || "").trim()
  if (!name) throw new Error(t("project.rename_name_required"))
  if (name === currentName.trim()) return
  assertApiAuthorityCurrent(authority)
  await renameProjectRecord(projectDirectory, name, authority)
  if (!isApiAuthorityCurrent(authority)) return
  setMissionSharedRefreshToken((value) => value + 1)
}

async function promoteWorkLedgerAnonymousProject(directory: string): Promise<void> {
  const authority = captureApiAuthority()
  const source = directory.trim()
  if (!source) throw new Error(t("project.promote_anonymous_missing_directory"))
  const nameDialog = await showAppDialog({
    title: t("project.promote_anonymous_title"),
    message: t("project.promote_anonymous_message"),
    input: true,
    inputLabel: t("project.rename_input_label"),
    inputPlaceholder: t("project.rename_input_placeholder"),
    inputRequired: true,
    inputRequiredMessage: t("project.rename_name_required"),
    cancel: true,
    okLabel: t("common.continue"),
  })
  if (!nameDialog.confirmed) return
  const name = String(nameDialog.value || "").trim()
  if (!name) throw new Error(t("project.rename_name_required"))
  const destinationParent = await pickDirectory()
  if (!destinationParent) return
  assertApiAuthorityCurrent(authority)
  const admission = await requestWorkspaceSelection()
  if (admission.kind === "unchanged") return
  assertApiAuthorityCurrent(authority)
  const result = await promoteAnonymousProject(source, destinationParent, name, authority)
  if (!isApiAuthorityCurrent(authority)) return
  await applyDirectory(result.directory, {
    save: true,
    restoreWorkspace: false,
    selectionEpoch: admission.epoch,
    authority,
  })
  if (!isApiAuthorityCurrent(authority)) return
  setMissionSharedRefreshToken((value) => value + 1)
  if (result.cleanupPending) {
    reportWarning({
      id: `project:promote:${result.project.id}:cleanup`,
      title: t("project.promote_anonymous_success_title"),
      message: t("project.promote_anonymous_cleanup_pending"),
    })
  } else {
    reportSuccess({
      id: `project:promote:${result.project.id}`,
      title: t("project.promote_anonymous_success_title"),
      message: t("project.promote_anonymous_success", { directory: result.directory }),
    })
  }
}

async function openWorkLedgerMission(row: WorkLedgerMissionRow): Promise<void> {
  await openMissionWithUILifecycle(
    {
      missionID: row.missionID,
      sessionID: row.sessionID,
      created: false,
      productPillar: row.productPillar,
      title: row.title,
    },
    row.directory,
  )
}

function openMissionBoard(): void {
  supersedePendingWorkspaceSelection()
  batch(() => {
    setRightDockVisible(false)
    setPrimaryWorkspaceSurface("mission-board")
  })
  queueMicrotask(() => document.getElementById("missionBoardTitle")?.focus())
}

async function openMissionBoardMission(row: MissionRecord): Promise<void> {
  await openMissionWithUILifecycle(
    {
      missionID: row.missionID,
      sessionID: row.sessionID,
      created: false,
      productPillar: row.productPillar,
    },
    row.directory,
  )
}

function missionBoardProjectDirectories(): string[] {
  const currentDirectory = activeDirectory().trim()
  return [...new Set([...(currentDirectory ? [currentDirectory] : []), ...workLedgerProjectDirectories()])]
}

async function createMissionBoardDraft(input: MissionManualCreateRequest): Promise<void> {
  const authority = captureApiAuthority()
  await createMissionDraft({ ...input, authority })
  if (!isApiAuthorityCurrent(authority)) return
  setMissionSharedRefreshToken((value) => value + 1)
}

async function createMissionBoardWithAI(input: MissionCreateRequest): Promise<void> {
  const authority = captureApiAuthority()
  const admission = await requestWorkspaceSelection()
  assertApiAuthorityCurrent(authority)
  if (admission.kind === "unchanged") return
  const selectionEpoch = admission.epoch
  if (!ownsWorkspaceSelection(selectionEpoch)) throw new DOMException("Mission action superseded", "AbortError")
  resetCenterWorkbenchToPrimaryPanel("mission")
  const result = await wakeMission({
    authority,
    directory: input.directory,
    text: input.request,
    productPillar: input.productPillar,
    expertSquadIDs: input.expertSquadIDs,
  })
  setMissionSharedRefreshToken((value) => value + 1)
  assertUserNavigationCurrent(selectionEpoch)
  if (!isApiAuthorityCurrent(authority)) return
  await openMissionSession(result, input.directory, selectionEpoch, authority)
  assertUserNavigationCurrent(selectionEpoch)
}

async function dispatchMissionBoardDraft(mission: MissionRecord): Promise<void> {
  const authority = captureApiAuthority()
  const admission = await requestWorkspaceSelection()
  assertApiAuthorityCurrent(authority)
  if (admission.kind === "unchanged") return
  const selectionEpoch = admission.epoch
  if (!ownsWorkspaceSelection(selectionEpoch)) throw new DOMException("Mission action superseded", "AbortError")
  resetCenterWorkbenchToPrimaryPanel("mission")
  const result = await dispatchMission({ missionID: mission.missionID, directory: mission.directory, authority })
  if (!isApiAuthorityCurrent(authority)) return
  setMissionSharedRefreshToken((value) => value + 1)
  assertUserNavigationCurrent(selectionEpoch)
  await openMissionSession(result, mission.directory, selectionEpoch, authority)
  assertUserNavigationCurrent(selectionEpoch)
}

async function confirmDeleteMissionBoardMission(mission: MissionRecord): Promise<boolean> {
  const confirmation = await showAppDialog({
    title: t("mission_board.delete.title"),
    message: t("mission_board.delete.confirm", { title: mission.title || mission.missionID }),
    cancel: true,
    okLabel: t("common.delete"),
    okTone: "danger",
  })
  return confirmation.confirmed
}

async function deleteMissionBoardMission(mission: MissionRecord): Promise<boolean> {
  const authority = captureApiAuthority()
  const deleted = await deleteMission(
    { missionID: mission.missionID, directory: mission.directory, authority },
    {
      surface: "overlay.work_ledger",
      reason: "Operator permanently deleted the Mission from Mission Board",
    },
  )
  if (!isApiAuthorityCurrent(authority)) return deleted
  if (!deleted) throw new Error(t("mission_board.delete.failed"))

  if (boardStore.selectedSource?.kind === "session" && boardStore.selectedSource.id === mission.sessionID) {
    runPostCommitUiEffect(
      { id: `mission:delete-selection:${mission.missionID}`, title: "Mission deletion committed" },
      () => {
        void selectTask("", { selectionEpoch: beginWorkspaceSelection() }).catch((error) =>
          reportOverlayRuntimeError("mission-board.delete-selection", error),
        )
      },
    )
  }
  setMissionSharedRefreshToken((value) => value + 1)
  reportSuccess({
    id: `mission:delete:${mission.missionID}`,
    title: t("mission_board.delete.succeeded"),
    message: mission.title || mission.missionID,
  })
  return true
}

async function abortWorkLedgerMission(row: WorkLedgerMissionRow): Promise<void> {
  const authority = captureApiAuthority()
  const ok = await abortMission(
    { missionID: row.missionID, directory: row.directory, authority },
    {
      surface: "overlay.work_ledger",
      reason: "Operator aborted the Mission from Work Ledger",
    },
  )
  if (!isApiAuthorityCurrent(authority)) return
  if (!ok) throw new Error(t("mission.error.action.abort"))
  setMissionSharedRefreshToken((value) => value + 1)
}

async function downloadWorkLedgerMission(row: WorkLedgerMissionRow): Promise<void> {
  const authority = captureApiAuthority()
  const ok = await downloadMissionProjectArchive({ missionID: row.missionID, directory: row.directory })
  if (!isApiAuthorityCurrent(authority)) return
  if (!ok) throw new Error(t("work_ledger.action.mission_download_failed"))
  reportSuccess({
    id: `mission:download-project:${row.missionID}`,
    title: t("work_ledger.action.mission_download_started"),
    message: row.title || row.missionID,
  })
}

async function renameWorkLedgerMission(row: WorkLedgerMissionRow): Promise<void> {
  const authority = captureApiAuthority()
  const dialog = await showAppDialog({
    title: t("work_ledger.action.rename_mission"),
    input: true,
    inputLabel: t("work_ledger.action.rename_placeholder"),
    inputPlaceholder: t("work_ledger.action.rename_placeholder"),
    inputValue: row.title || row.missionID,
    inputRequired: true,
    inputRequiredMessage: t("explorer.name_required"),
    cancel: true,
    okLabel: t("common.ok"),
  })
  if (!dialog.confirmed) return
  const title = String(dialog.value || "").trim()
  if (!title || title === (row.title || "").trim()) return
  assertApiAuthorityCurrent(authority)
  await renameMission({ missionID: row.missionID, directory: row.directory, authority }, title)
  if (!isApiAuthorityCurrent(authority)) return
  setMissionSharedRefreshToken((value) => value + 1)
}

async function archiveWorkLedgerMission(row: WorkLedgerMissionRow): Promise<void> {
  const authority = captureApiAuthority()
  await setMissionArchived({ missionID: row.missionID, directory: row.directory, authority }, true, {
    surface: "overlay.work_ledger",
    reason: "Operator archived the Mission from Work Ledger",
  })
  if (!isApiAuthorityCurrent(authority)) return
  if (boardStore.selectedSource?.kind === "session" && boardStore.selectedSource.id === row.sessionID) {
    void selectTask("", { selectionEpoch: beginWorkspaceSelection() }).catch((error) => {
      runPostCommitUiEffect(
        { id: `mission:archive-selection-cleanup:${row.missionID}`, title: "Mission archive committed" },
        () =>
          reportWarning({
            id: `mission:archive-selection-cleanup:${row.missionID}`,
            title: t("common.error"),
            message: error instanceof Error ? error.message : String(error),
            details: formatErrorDetails(error),
          }),
      )
    })
  }
  runPostCommitUiEffect({ id: `mission:archive-refresh:${row.missionID}`, title: "Mission archive committed" }, () =>
    setMissionSharedRefreshToken((value) => value + 1),
  )
}

async function cancelWorkLedgerTask(row: WorkLedgerTaskRow): Promise<void> {
  const authority = captureApiAuthority()
  await cancelTask(row.id, {
    surface: "overlay.work_ledger",
    reason: "Operator cancelled the task from Work Ledger",
  })
  if (!isApiAuthorityCurrent(authority)) return
  setMissionSharedRefreshToken((value) => value + 1)
}

async function downloadWorkLedgerTask(row: WorkLedgerTaskRow): Promise<void> {
  const authority = captureApiAuthority()
  const ok = await downloadTaskProjectArchive({ taskID: row.id, directory: row.directory })
  if (!isApiAuthorityCurrent(authority)) return
  if (!ok) throw new Error(t("task.download_project_failed", { error: row.id }))
  reportSuccess({
    id: `task:download-project:${row.id}`,
    title: t("task.download_project_started_title"),
    message: row.title || row.id,
  })
}

async function renameWorkLedgerTask(row: WorkLedgerTaskRow): Promise<void> {
  const authority = captureApiAuthority()
  const dialog = await showAppDialog({
    title: t("task.rename_button_title"),
    input: true,
    inputLabel: t("task.rename_placeholder"),
    inputPlaceholder: t("task.rename_placeholder"),
    inputValue: row.title || row.id,
    inputRequired: true,
    inputRequiredMessage: t("explorer.name_required"),
    cancel: true,
    okLabel: t("common.ok"),
  })
  if (!dialog.confirmed) return
  const title = String(dialog.value || "").trim()
  if (!title || title === (row.title || "").trim()) return
  assertApiAuthorityCurrent(authority)
  const ok = await renameTask(row.id, title, authority)
  if (!isApiAuthorityCurrent(authority)) return
  if (!ok) throw new Error(t("task.rename_placeholder"))
  setMissionSharedRefreshToken((value) => value + 1)
}

async function archiveWorkLedgerTask(row: WorkLedgerTaskRow): Promise<void> {
  const authority = captureApiAuthority()
  const ok = await setTaskArchived({ taskID: row.id, directory: row.directory, authority }, true, {
    surface: "overlay.work_ledger",
    reason: "Operator archived the task from Work Ledger",
  })
  if (!isApiAuthorityCurrent(authority)) return
  if (!ok) throw new Error(t("task.archive_failed"))
  runPostCommitUiEffect({ id: `task:archive-refresh:${row.id}`, title: "Task archive committed" }, () =>
    setMissionSharedRefreshToken((value) => value + 1),
  )
}

async function stopWorkLedgerChat(row: WorkLedgerChatRow): Promise<void> {
  const authority = captureApiAuthority()
  const ok = await stopConversationSession({
    authority,
    sessionID: row.sessionID,
    directory: row.directory,
    experience: row.experience,
  })
  if (!isApiAuthorityCurrent(authority)) return
  if (!ok) throw new Error("Coding assistant stop failed")
  setMissionSharedRefreshToken((value) => value + 1)
}

async function renameWorkLedgerChat(row: WorkLedgerChatRow): Promise<void> {
  const authority = captureApiAuthority()
  const dialog = await showAppDialog({
    title: t("work_ledger.action.rename_chat"),
    input: true,
    inputLabel: t("work_ledger.action.rename_placeholder"),
    inputPlaceholder: t("work_ledger.action.rename_placeholder"),
    inputValue: row.title || row.sessionID,
    inputRequired: true,
    inputRequiredMessage: t("explorer.name_required"),
    cancel: true,
    okLabel: t("common.ok"),
  })
  if (!dialog.confirmed) return
  const title = String(dialog.value || "").trim()
  if (!title || title === (row.title || "").trim()) return
  assertApiAuthorityCurrent(authority)
  await renameConversationSession(
    { sessionID: row.sessionID, directory: row.directory, experience: row.experience, authority },
    title,
  )
  if (!isApiAuthorityCurrent(authority)) return
  setMissionSharedRefreshToken((value) => value + 1)
}

async function archiveWorkLedgerChat(row: WorkLedgerChatRow): Promise<void> {
  const authority = captureApiAuthority()
  const ok = await setConversationSessionArchived(
    { sessionID: row.sessionID, directory: row.directory, experience: row.experience, authority },
    true,
  )
  if (!isApiAuthorityCurrent(authority)) return
  if (!ok) throw new Error(t("coding_assistant.archive_failed"))
  if (boardStore.selectedSource?.kind === "session" && boardStore.selectedSource.id === row.sessionID) {
    void selectTask("", { selectionEpoch: beginWorkspaceSelection() }).catch((error) => {
      runPostCommitUiEffect(
        { id: `chat:archive-selection-cleanup:${row.sessionID}`, title: "Chat archive committed" },
        () =>
          reportWarning({
            id: `chat:archive-selection-cleanup:${row.sessionID}`,
            title: t("common.error"),
            message: error instanceof Error ? error.message : String(error),
            details: formatErrorDetails(error),
          }),
      )
    })
  }
  runPostCommitUiEffect({ id: `chat:archive-refresh:${row.sessionID}`, title: "Chat archive committed" }, () =>
    setMissionSharedRefreshToken((value) => value + 1),
  )
}

async function setActiveWorkLedgerItemPinned(
  row: WorkLedgerTaskRow | WorkLedgerMissionRow | WorkLedgerChatRow,
  pinned: boolean,
): Promise<void> {
  const authority = captureApiAuthority()
  await setWorkLedgerItemPinned({ row, pinned, authority })
  if (!isApiAuthorityCurrent(authority)) return
  setMissionSharedRefreshToken((value) => value + 1)
}

function assertDebugSelectionCurrent(source: BoardSource): void {
  const current = boardStore.selectedSource
  if (!current || current.kind !== source.kind || current.id !== source.id) {
    throw new Error(`Conversation selection changed while collecting debug information; retry the copy action`)
  }
  const expectedDirectory = normalizeDebugDirectory(source.directory)
  const currentDirectory = normalizeDebugDirectory(current.directory)
  if (expectedDirectory && currentDirectory && expectedDirectory !== currentDirectory) {
    throw new Error(`Conversation directory changed while collecting debug information; retry the copy action`)
  }
}

async function openExpertSquadMarketForProject(projectDirectory?: string): Promise<void> {
  const requestedDirectory = projectDirectory?.trim() ?? ""
  if (requestedDirectory && requestedDirectory !== activeDirectory().trim()) {
    const admission = await requestWorkspaceSelection()
    if (admission.kind === "unchanged") return
    const applied = await applyDirectory(requestedDirectory, {
      selectionEpoch: admission.epoch,
      save: false,
      persist: false,
      restoreWorkspace: false,
    })
    if (!applied) throw new DOMException("Project navigation superseded", "AbortError")
  } else if (!requestedDirectory && !activeDirectory().trim()) {
    const admission = await requestWorkspaceSelection()
    if (admission.kind === "unchanged") return
    await resolveGlobalComposerProject({ kind: "admitted", selectionEpoch: admission.epoch }).promise
  }
  await openConfigDialog("expert-squad-install")
}

async function searchMissionMarketExpertSquads(
  projectDirectory: string,
  query: string,
  productPillar: ProductPillar,
): Promise<readonly ExpertSquadMarketIndexItem[]> {
  const page = await loadExpertSquadMarket(projectDirectory, {
    query: query.trim().slice(0, 500),
    availability: "available",
    productPillar,
    limit: 3,
  })
  return page.entries
}

async function installMissionMarketExpertSquad(
  projectDirectory: string,
  item: ExpertSquadMarketIndexItem,
): Promise<void> {
  await installExpertSquadMarketPackage(projectDirectory, item.id, "project")
}

async function openMissionMarketExpertSquad(item: ExpertSquadMarketIndexItem): Promise<void> {
  const opened = await nativeOpen(
    expertSquadPublicMarketURL({ namespace: item.namespace, id: item.id, locale: localeTag() }),
  )
  if (!opened) throw new Error(t("mission_board.create.market_open_unavailable"))
}
async function copyActiveConversationDebug(): Promise<void> {
  const initialSource = boardStore.selectedSource
  const selectedSource = initialSource ? ({ ...initialSource } as BoardSource) : null
  const taskSelectionError = boardStore.taskSelectionError
  const selectedTaskFailure =
    selectedSource?.kind === "task" && taskSelectionError?.taskID === selectedSource.id ? taskSelectionError : null
  if (!selectedSource) throw new Error("No active Task or Chat")
  selectedSource.directory = requireDebugProjectDirectory(
    String(selectedSource.directory ?? "").trim() ||
      (selectedSource.kind === "session" ? (optionalConversationSourceDirectory(selectedSource) ?? "") : ""),
    t("chat.debug_copy_project_directory_unavailable"),
  )
  assertDebugSelectionCurrent(selectedSource)
  const persistedChat =
    selectedSource.kind === "session"
      ? await loadPersistedChatDebugProjection({
          sessionID: selectedSource.id,
          directory: String(selectedSource.directory),
        })
      : undefined
  assertDebugSelectionCurrent(selectedSource)
  const taskRootIngressDebug =
    selectedSource.kind === "task"
      ? await apiJson<{ status: "available"; entries: any[] } | { status: "unavailable"; error: string }>(
          taskScopedPath(selectedSource.id, String(selectedSource.directory), "/debug/task-root-ingresses"),
        )
      : undefined
  assertDebugSelectionCurrent(selectedSource)
  const debugBoard =
    selectedSource.kind === "session"
      ? { ...boardStore.board }
      : {
          ...boardStore.board,
          ...(taskRootIngressDebug?.status === "available" ? { taskRootIngresses: taskRootIngressDebug.entries } : {}),
          ...(taskRootIngressDebug?.status === "unavailable"
            ? { taskRootIngressDebugError: taskRootIngressDebug.error }
            : {}),
        }
  const debugCardTree =
    selectedSource.kind === "session"
      ? ({ cards: { ...cardTreeStore.cards }, order: [...cardTreeStore.order] } as typeof cardTreeStore)
      : cardTreeStore
  const blob =
    selectedSource.kind === "session"
      ? buildChatDebugBlob(debugBoard, selectedSource, debugCardTree, persistedChat!)
      : selectedTaskFailure
        ? buildTaskSelectionErrorDebugBlob(selectedTaskFailure, appStore.enginePaths)
        : buildTaskDebugBlob(debugBoard, selectedSource, appStore.enginePaths)
  if (!blob) {
    throw new Error(selectedSource.kind === "session" ? "No active chat session" : "No active task")
  }
  await writeDebugClipboard(blob)
}

async function renameActiveWorkLedgerItem(
  row: WorkLedgerTaskRow | WorkLedgerMissionRow | WorkLedgerChatRow,
): Promise<void> {
  if (row.kind === "mission") return renameWorkLedgerMission(row)
  if (row.kind === "chat") return renameWorkLedgerChat(row)
  return renameWorkLedgerTask(row)
}

async function archiveActiveWorkLedgerItem(
  row: WorkLedgerTaskRow | WorkLedgerMissionRow | WorkLedgerChatRow,
): Promise<void> {
  if (row.kind === "mission") return archiveWorkLedgerMission(row)
  if (row.kind === "chat") return archiveWorkLedgerChat(row)
  return archiveWorkLedgerTask(row)
}

async function openMissionWithUILifecycle(
  result: Parameters<typeof openMissionSession>[0],
  directory: string,
): Promise<void> {
  const authority = captureApiAuthority()
  const admission = await requestWorkspaceSelection({
    kind: "session",
    id: result.sessionID,
    directory,
    sessionKind: "mission",
  })
  assertApiAuthorityCurrent(authority)
  if (admission.kind === "unchanged") {
    revealCurrentConversationFromBoard()
    return
  }
  await closeConfigDialog()
  assertApiAuthorityCurrent(authority)
  assertUserNavigationCurrent(admission.epoch)
  resetCenterWorkbenchToPrimaryPanel("mission")
  await openMissionSession(result, directory, admission.epoch, authority)
  if (!isApiAuthorityCurrent(authority)) return
  assertUserNavigationCurrent(admission.epoch)
}

async function openMissionSession(
  result: {
    sessionID: string
    missionID?: string
    created?: boolean
    productPillar: "code" | "work"
    title?: string
  },
  directory: string,
  selectionEpoch: number,
  authority = captureApiAuthority(),
): Promise<boolean> {
  assertApiAuthorityCurrent(authority)
  const owns = () => ownsWorkspaceSelection(selectionEpoch) && isApiAuthorityCurrent(authority)
  const missionDirectory = directory.trim()
  if (!missionDirectory) throw new Error("openMissionSession: directory is required")
  if (!owns()) {
    return false
  }
  const source = {
    kind: "session" as const,
    id: result.sessionID,
    directory: missionDirectory,
    sessionKind: "mission" as const,
  }
  stopSSE()
  abortChatRequest()
  clearComposerModelProjection()
  cancelConversationReplay()
  setChatAttachments([])
  batch(() => {
    loadConversationUiStateForSource(source, authority)
    resetConversationProjection({ scrollIntent: "bottom", cause: "mission-session-switch" })
    setSelectedSource(source)
    clearBoard()
    setBoardStore("taskSwitching", true)
  })
  try {
    const applied = await applyDirectory(missionDirectory, {
      save: true,
      restoreWorkspace: false,
      preserveSelection: true,
      selectionEpoch,
      authority,
    })
    if (!applied || !owns()) {
      return false
    }
    setComposerIntent({ productPillar: result.productPillar, conversationTarget: "mission" })
    await loadConversation(source, {
      scrollIntent: "bottom",
      resetCause: "mission-session-hydrate",
      directory: missionDirectory,
      authority,
    })
    if (!owns()) return false
    startSSE(source, 0, { directory: missionDirectory, authority })
    void projectComposerModelFromSession(
      { sessionID: result.sessionID, directory: missionDirectory, authority },
      () =>
        owns() && boardStore.selectedSource?.kind === "session" && boardStore.selectedSource.id === result.sessionID,
    )
    setPrimaryCenterPanel("mission")
    return true
  } catch (error) {
    if (!owns()) return false
    if (boardStore.selectedSource?.kind === "session" && boardStore.selectedSource.id === result.sessionID) {
      batch(() => {
        resetConversationProjection({ scrollIntent: "bottom", cause: "mission-session-switch-failed" })
        clearBoard()
        setPrimaryCenterPanel("mission")
      })
    }
    throw error
  } finally {
    if (owns()) setBoardStore("taskSwitching", false)
  }
}

function focusInitialRestoredTaskWorkspace(): void {
  if (!activeTaskID() || boardStore.selectedSource?.kind !== "task") return
  setPrimaryCenterPanel("task")
}

function openCenterWorkbenchPanel(panel: CenterWorkbenchPanel): void {
  const tab: CenterWorkbenchTab = {
    id: panel,
    panel,
    ...(panel === "browser" ? { taskPreview: true as const } : {}),
  }
  setCenterWorkbenchPanels((current) => {
    if (current.some((item) => item.id === tab.id)) return current
    return [...current, tab]
  })
  setSelectedCenterWorkbenchTabID(tab.id)
  scheduleCenterWorkbenchPanelReveal(panel)
}

disposers.push(
  registerReviewPanelPresenter(() => {
    presentRightDockPanel("diff")
  }),
)

function openBlankBrowserTab(tabID: string): void {
  const tab: CenterWorkbenchTab = {
    id: tabID,
    panel: "browser",
  }
  showRightDockForExplicitAction()
  setCenterWorkbenchPanels((current) => [...current, tab])
  setSelectedCenterWorkbenchTabID(tab.id)
}

function removeCenterWorkbenchTabs(matches: (tab: CenterWorkbenchTab) => boolean): void {
  const current = untrack(centerWorkbenchPanels)
  const remaining = current.filter((tab) => !matches(tab))
  if (remaining.length === current.length) return

  const selectedID = untrack(selectedCenterWorkbenchTabID)
  if (!remaining.some((tab) => tab.id === selectedID)) {
    const remainingIDs = new Set(remaining.map((tab) => tab.id))
    const selectedIndex = current.findIndex((tab) => tab.id === selectedID)
    const previousDockTab =
      selectedIndex < 0
        ? undefined
        : current
            .slice(0, selectedIndex)
            .reverse()
            .find((tab) => tab.panel !== "conversation" && remainingIDs.has(tab.id))
    const nextDockTab = current
      .slice(Math.max(0, selectedIndex + 1))
      .find((tab) => tab.panel !== "conversation" && remainingIDs.has(tab.id))
    setSelectedCenterWorkbenchTabID(previousDockTab?.id ?? nextDockTab?.id ?? "conversation")
  }

  setCenterWorkbenchPanels(remaining)
}

function closeCenterWorkbenchPanel(panel: CenterWorkbenchPanel): void {
  if (panel === "conversation") return
  if (panel === "file") {
    runUserNavigation("workspace.close-file", async () => {
      await closeFileEditor()
    })
    return
  }
  removeCenterWorkbenchTabs((tab) => tab.panel === panel)
}

async function closeRightDockTab(tabID: string): Promise<boolean> {
  const tab = untrack(centerWorkbenchPanels).find((item) => item.id === tabID)
  if (!tab || tab.panel === "conversation") return false
  if (tab.panel === "file") {
    let closed = false
    await runUserNavigation("workspace.close-file", async () => {
      closed = await closeFileEditor()
    })
    return closed
  }
  removeCenterWorkbenchTabs((item) => item.id === tabID)
  if (tab.panel === "browser") {
    setBrowserPreviewPageTitles((current) => {
      const next = { ...current }
      delete next[tabID]
      return next
    })
  }
  return true
}

function getCenterWorkbenchViews(): Record<CenterWorkbenchPanel, HTMLElement | null> {
  return {
    conversation: document.getElementById("centerWorkbenchConversation"),
    requirements: document.getElementById("centerWorkbenchRequirements"),
    goals: document.getElementById("centerWorkbenchGoals"),
    explorer: document.getElementById("centerWorkbenchExplorer"),
    diff: document.getElementById("centerWorkbenchDiff"),
    browser: document.getElementById("centerWorkbenchBrowser"),
    screenshots: document.getElementById("centerWorkbenchScreenshots"),
    subagent: document.getElementById("centerWorkbenchSubagent"),
    "side-chat": document.getElementById("centerWorkbenchSideChat"),
    file: document.getElementById("centerWorkbenchFile"),
  }
}

function orderedCenterWorkbenchPanels(panels = centerWorkbenchPanels()): CenterWorkbenchPanel[] {
  const open = new Set(panels.map((tab) => tab.panel))
  return CENTER_WORKBENCH_PANEL_ORDER.filter((panel) => open.has(panel))
}

function selectedCenterWorkbenchTab(panels = centerWorkbenchPanels()): CenterWorkbenchTab | null {
  const selectedID = selectedCenterWorkbenchTabID()
  return panels.find((tab) => tab.id === selectedID) ?? null
}

// ── Right dock tab model ──
// The right dock hosts the tool panels as tabs. Tabs are the open panels in
// `centerWorkbenchPanels` excluding "conversation" (which stays in the center).
// `selectedCenterWorkbenchTabID` owns activation without changing insertion order.

function rightDockTabPanels(panels = centerWorkbenchPanels()): RightDockTab[] {
  return panels.filter((tab): tab is CenterWorkbenchTab & { panel: RightDockPanel } => tab.panel !== "conversation")
}

function activateCenterWorkbenchTab(tabID: string): void {
  const tab = untrack(centerWorkbenchPanels).find((item) => item.id === tabID)
  if (!tab) return
  setSelectedCenterWorkbenchTabID(tabID)
  scheduleCenterWorkbenchPanelReveal(tab.panel)
}

function renderRightDockWidth(): void {
  const dock = document.getElementById("rightDock")
  if (!dock) return
  const raw = Number(settingsStore.rightDockWidth)
  if (Number.isFinite(raw) && raw > 0) dock.style.setProperty("--right-dock-width", `${clampRightDockWidth(raw)}px`)
  else dock.style.removeProperty("--right-dock-width")
  renderRightDockHandleSemanticsOnFrame.schedule()
}

function renderRightDockHandleSemantics(): void {
  const dock = document.getElementById("rightDock")
  const handle = document.getElementById("rightDockResizer")
  if (!dock || !handle) return
  if (dock.dataset.open !== "true") {
    handle.removeAttribute("aria-valuemin")
    handle.removeAttribute("aria-valuemax")
    handle.removeAttribute("aria-valuenow")
    return
  }
  const bounds = rightDockResizeBounds()
  handle.setAttribute("aria-valuemin", String(Math.round(bounds.min)))
  handle.setAttribute("aria-valuemax", String(Math.round(bounds.max)))
  handle.setAttribute("aria-valuenow", String(Math.round(clampRightDockWidth(dock.getBoundingClientRect().width))))
}

const renderRightDockHandleSemanticsOnFrame = createAnimationFrameScheduler(renderRightDockHandleSemantics)
disposers.push(() => renderRightDockHandleSemanticsOnFrame.cancel())

const revealPendingCenterWorkbenchPanelOnFrame = createAnimationFrameScheduler(revealPendingCenterWorkbenchPanel)
disposers.push(() => {
  revealPendingCenterWorkbenchPanelOnFrame.cancel()
  pendingCenterWorkbenchRevealPanel = null
})

function scheduleCenterWorkbenchPanelReveal(panel: CenterWorkbenchPanel): void {
  pendingCenterWorkbenchRevealPanel = panel
  revealPendingCenterWorkbenchPanelOnFrame.schedule()
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return !!value && typeof value === "object" && !Array.isArray(value)
}

// Delegate clicks on rendered-markdown file links (see utils/markdown.ts —
// codespans that look like file paths are emitted with data-file-path).
// A single document-level listener keeps this decoupled from the message
// rendering path, which re-runs on every stream tick.
document.addEventListener(
  "click",
  (ev) => {
    const target = ev.target as HTMLElement | null
    if (!target) return
    const imageTrigger = target.closest<HTMLElement>("[data-image-preview-trigger]")
    if (imageTrigger) {
      const src =
        imageTrigger.getAttribute("data-image-preview-src") ||
        imageTrigger.querySelector("img")?.getAttribute("src") ||
        ""
      const alt =
        imageTrigger.getAttribute("data-image-preview-alt") ||
        imageTrigger.querySelector("img")?.getAttribute("alt") ||
        ""
      ev.preventDefault()
      openImagePreview(src, alt)
      return
    }
    const link = target.closest<HTMLElement>(`[${FILE_REFERENCE_PATH_ATTRIBUTE}]`)
    if (link) {
      const reference = elementFileReference(link, FILE_REFERENCE_PATH_ATTRIBUTE)
      if (!reference) return
      ev.preventDefault()
      runMainAsync("workspace.open-file-link", () => openPathInSelectedEditor(reference.path, reference))
      return
    }
    const projectFileLink = target.closest<HTMLElement>(`[${PROJECT_FILE_REFERENCE_PATH_ATTRIBUTE}]`)
    if (!projectFileLink) return
    const projectFile = elementFileReference(projectFileLink, PROJECT_FILE_REFERENCE_PATH_ATTRIBUTE)
    if (!projectFile) return
    ev.preventDefault()
    runMainAsync("workspace.open-project-file", () => openProjectFile(projectFile.path, projectFile))
  },
  listenerOpts,
)

document.addEventListener(
  "click",
  (ev) => {
    const target = ev.target as HTMLElement | null
    if (!target) return
    const anchor = target.closest<HTMLAnchorElement>("a[href]")
    if (!anchor || anchor.hasAttribute(FILE_REFERENCE_PATH_ATTRIBUTE)) return
    const previewUrl = anchor.getAttribute("data-browser-preview-url") || ""
    const href = previewUrl || anchor.getAttribute("href") || ""
    if (!/^https?:\/\//i.test(href)) return
    const canOpenExternalUrl = getHostTransport().capabilities.nativeCommands["open-url"]
    const canOpenBrowserPreview =
      Boolean(previewUrl) && browserPreviewNativeSurfaceAvailable() && browserPreviewNativeUrlNavigationAvailable()
    if (!canOpenBrowserPreview && !canOpenExternalUrl) return
    ev.preventDefault()
    runMainAsync("browser-preview.open-url", async () => {
      try {
        if (canOpenBrowserPreview) {
          openBrowserPreviewFromMessage(previewUrl)
          return
        }
        if (!canOpenExternalUrl) return
        await nativeOpen(previewUrl || href)
      } catch (error) {
        console.error("[ui] Failed to open external link", error)
        reportError({
          id: "browser-preview:open-url",
          title: t("browser_preview.title"),
          message: error instanceof Error ? error.message : String(error),
          details: formatErrorDetails(error),
        })
      }
    })
  },
  listenerOpts,
)

// Code-block copy buttons rendered by utils/markdown.ts wrapCodeBlock.
// markdown HTML lives inside innerHTML on streamed text — wiring per-button
// click handlers in Solid would require re-binding on every stream tick,
// so a single document-level listener keeps the renderer pure.
document.addEventListener(
  "click",
  (ev) => {
    const target = ev.target as HTMLElement | null
    if (!target) return
    const btn = target.closest<HTMLButtonElement>("button[data-md-copy]")
    if (!btn) return
    ev.preventDefault()
    ev.stopPropagation()
    const source = btn.getAttribute("data-md-copy") || ""
    if (!source) return
    const flash = (text: string) => {
      btn.dataset.copied = "true"
      const prev = btn.getAttribute("aria-label") || ""
      btn.setAttribute("aria-label", text)
      btn.title = text
      setTimeout(() => {
        delete btn.dataset.copied
        btn.setAttribute("aria-label", prev || t("markdown.copy_code"))
        btn.title = prev || t("markdown.copy_code")
      }, 1400)
    }
    const decoded = source
      .replace(/&amp;/g, "&")
      .replace(/&lt;/g, "<")
      .replace(/&gt;/g, ">")
      .replace(/&quot;/g, '"')
      .replace(/&#39;/g, "'")
    runMainAsync("markdown.copy-code", async () => {
      try {
        await copyText(decoded)
        flash(t("markdown.copied"))
      } catch (err) {
        console.error("[md-copy] clipboard write failed", err)
        flash(t("markdown.copy_failed"))
      }
    })
  },
  listenerOpts,
)

window.addEventListener("acceptance:focus-changes", requestReviewPanel, listenerOpts)

// Components call strict `t()` at render time. Load the locale bundles before
// mounting any Solid surface so early hosts do not render against an empty
// translation dictionary.
await loadAllLocales()
await setLocale(localeTag())

// ── Mount: Conversation ──

// ── Mount: WorkLedger ──

// ── Mount: ChatComposer ──

const [composerStopping, setComposerStopping] = createSignal(false)
const [composerExpertSquadCatalogSnapshot, setComposerExpertSquadCatalogSnapshot] = createSignal(
  emptyComposerExpertSquadCatalog(),
)
let expertSquadLoadSequence = 0
let expertSquadInFlight: { requestKey: string; promise: Promise<void> } | null = null
let expertSquadLoadedRequestKey = ""
let expertSquadSearchSequence = 0
async function refreshExpertSquads(
  scope: ExpertSquadCatalogScope | Extract<ComposerReferenceCatalogScopeState, { kind: "global" }>,
  requestKey: string,
): Promise<void> {
  const authority = captureApiAuthority()
  const owns = () => isApiAuthorityCurrent(authority) && requestKey === composerReferenceCatalogRequestKey()
  if (requestKey === expertSquadLoadedRequestKey) return
  if (expertSquadInFlight?.requestKey === requestKey) return await expertSquadInFlight.promise
  const sequence = ++expertSquadLoadSequence
  const promise = (async () => {
    try {
      if (scope.kind === "global") {
        const catalog = await loadGlobalComposerReferences(authority)
        if (sequence !== expertSquadLoadSequence || !owns()) return
        setComposerExpertSquadCatalogSnapshot(createGlobalComposerReferenceCatalogSnapshot(requestKey, catalog))
        expertSquadLoadedRequestKey = requestKey
        return
      }
      const catalogPromise = loadExpertSquadCatalog({ ...scope, authority })
      const activeInspectionPromise = catalogPromise.then((catalog) =>
        inspectExpertSquad({ directory: scope.directory, id: catalog.active.effective, authority }),
      )
      const [catalog, squads, missionSkillCatalog, chatCapability, activeInspection] = await Promise.allSettled([
        catalogPromise,
        searchExpertSquads({ directory: scope.directory, productPillar: composerIntent().productPillar, authority }),
        loadMissionSkillCatalog({ ...scope, authority }),
        loadConversationCapability(scope.directory, "chat", authority),
        activeInspectionPromise,
      ])
      if (sequence !== expertSquadLoadSequence || !owns()) return
      setComposerExpertSquadCatalogSnapshot(
        createComposerReferenceCatalogSnapshotFromSettled(requestKey, composerExpertSquadCatalogSnapshot(), {
          catalog,
          squads,
          missionSkills: missionSkillCatalog,
          chatCapability,
          activeInspection,
        }),
      )
      expertSquadLoadedRequestKey = requestKey
      const snapshot = composerExpertSquadCatalogSnapshot()
      const error = composerReferenceCatalogError(snapshot)
      if (!error) return
      AppLog.warn("composer-reference", "Reference catalog unavailable for composer", {
        error,
        requestKey,
      })
    } catch (error) {
      if (sequence !== expertSquadLoadSequence || !owns()) return
      expertSquadLoadedRequestKey = ""
      setComposerExpertSquadCatalogSnapshot(
        failedComposerReferenceCatalogSnapshot(requestKey, runtimeErrorMessage(error)),
      )
      AppLog.warn("composer-reference", "Reference catalog reconciliation failed", {
        error: runtimeErrorMessage(error),
        requestKey,
      })
    } finally {
      if (expertSquadInFlight?.promise === promise) expertSquadInFlight = null
    }
  })()
  expertSquadInFlight = { requestKey, promise }
  await promise
}

function retryComposerReferenceCatalog(): void {
  const requestKey = composerReferenceCatalogRequestKey()
  const scope = composerReferenceCatalogScope()
  if (scope.kind === "pending" || scope.kind === "unavailable") return
  expertSquadLoadedRequestKey = ""
  void refreshExpertSquads(scope, requestKey)
}

/**
 * The Squad Market, reachable from the box the operator is already typing in.
 *
 * Installing writes into the current Project, which is the only scope this
 * composer can speak for: a global reference catalog has no directory to
 * install into, so the market simply is not offered there rather than
 * installing somewhere the operator did not choose.
 */
async function searchComposerMarketExpertSquads(query: string): Promise<readonly ExpertSquadMarketIndexItem[]> {
  const scope = composerReferenceCatalogScope()
  if (scope.kind !== "project" && scope.kind !== "session") return []
  const page = await loadExpertSquadMarket(scope.directory, {
    query: query.trim().slice(0, 500),
    availability: "available",
    productPillar: composerIntent().productPillar,
    limit: 3,
  })
  return page.entries
}

async function installComposerMarketExpertSquad(item: ExpertSquadMarketIndexItem): Promise<void> {
  const scope = composerReferenceCatalogScope()
  if (scope.kind !== "project" && scope.kind !== "session")
    throw new Error(t("chat.references.market_install_scope_unavailable"))
  await installExpertSquadMarketPackage(scope.directory, item.id, "project")
}

async function searchComposerExpertSquads(
  query: string,
  selectedExpertSquadIDs: readonly string[] = [],
): Promise<void> {
  const sequence = ++expertSquadSearchSequence
  const requestKey = composerReferenceCatalogRequestKey()
  const scope = composerReferenceCatalogScope()
  if (scope.kind === "pending" || scope.kind === "unavailable") return
  try {
    const page =
      scope.kind === "global"
        ? await searchGlobalComposerExpertSquads({
            query,
            productPillar: composerIntent().productPillar,
            limit: 20,
          })
        : await searchExpertSquads({
            directory: scope.directory,
            query,
            productPillar: composerIntent().productPillar,
            limit: 20,
          })
    if (sequence !== expertSquadSearchSequence || requestKey !== composerReferenceCatalogRequestKey()) return
    setComposerExpertSquadCatalogSnapshot((current) =>
      updateComposerExpertSquadSearch(
        current,
        requestKey,
        { status: "fulfilled", value: page },
        selectedExpertSquadIDs,
      ),
    )
  } catch (error) {
    if (sequence !== expertSquadSearchSequence || requestKey !== composerReferenceCatalogRequestKey()) return
    const message = `expert squad search: ${runtimeErrorMessage(error)}`
    setComposerExpertSquadCatalogSnapshot((current) =>
      updateComposerExpertSquadSearch(
        current,
        requestKey,
        { status: "rejected", reason: error },
        selectedExpertSquadIDs,
      ),
    )
    AppLog.warn("composer-reference", "Expert Squad search failed", { error: message, requestKey })
  }
}

function newRequestComposerDraftKey(): string {
  return workspaceComposerDraftKey("", "", activeDirectory())
}

const panelComposerDraftKey = () => {
  return workspaceComposerDraftKey(activeTaskID(), activeSessionID(), activeDirectory())
}

function missionSubmitActive(): boolean {
  return composerIntent().conversationTarget === "mission" && !activeTaskID() && !activeSessionID()
}

function conversationSubmitActive(): boolean {
  return composerIntent().conversationTarget === "chat" && !activeTaskID() && !isConversationSource()
}

function resolvedActiveComposerIntent(): ComposerIntent | undefined {
  const item = workLedgerActiveItem({ taskID: activeTaskID(), sessionID: activeSessionID() })
  if (!item) return undefined
  if (item.kind === "chat") {
    return {
      productPillar: productPillarFromConversationExperience(item.experience),
      conversationTarget: "chat",
    }
  }
  return {
    productPillar: item.productPillar,
    conversationTarget: "mission",
  }
}

function launcherHomeActive(): boolean {
  const panel = primaryCenterPanel()
  return (
    (panel === "chat" || panel === "mission") &&
    !activeTaskID() &&
    !activeSessionID() &&
    cardTreeStore.order.length === 0
  )
}

// ── Initialise application ──

const [settingsHydrated, setSettingsHydrated] = createSignal(false)

const paneCallbacks = {
  getState: () => ({
    sidebarCollapsed: settingsStore.sidebarCollapsed,
    sidebarWidth: settingsStore.sidebarWidth,
  }),
  onWidthsChanged: (sidebarWidth: number | null) => {
    setSettingsStore({
      ...(sidebarWidth != null ? { sidebarWidth } : {}),
    })
    persistMainSettings("settings.persist-pane-width")
  },
}

function OverlayRoot() {
  const homeActive = createMemo(launcherHomeActive)
  const composerExpertSquadCatalog = createMemo(() => {
    const catalog = composerExpertSquadCatalogForRequest(
      composerExpertSquadCatalogSnapshot(),
      composerReferenceCatalogRequestKey(),
    )
    return {
      ...catalog,
      squads: catalog.squads.filter((squad) => squad.product_pillars.includes(composerIntent().productPillar)),
    }
  })
  const composerLaunchReferences = createMemo<VisibleComposerReferences>(() => {
    const source = boardStore.selectedSource
    const board = boardStore.board
    if (source?.kind === "task" && board?.task?.id === source.id) {
      return visibleComposerReferences(typeof board.task.request === "string" ? board.task.request : "")
    }
    if (source?.kind === "session" && board?.kind === "session" && board.sessionID === source.id) {
      return VisibleComposerReferencesSchema.parse(board.composerReferences)
    }
    return visibleComposerReferences("")
  })

  onMount(() => {
    const disposePaneResizers = initPaneResizers(paneCallbacks, PANEL_PANE_CONFIG)
    onCleanup(disposePaneResizers)
  })

  createEffect<string>((previousKey) => {
    const requestKey = composerReferenceCatalogRequestKey()
    if (requestKey === previousKey) return previousKey
    const scope = composerReferenceCatalogScope()
    if (scope.kind === "pending" || scope.kind === "unavailable") {
      expertSquadLoadSequence++
      expertSquadInFlight = null
      expertSquadLoadedRequestKey = ""
      setComposerExpertSquadCatalogSnapshot(emptyComposerExpertSquadCatalog())
      return requestKey
    }
    void refreshExpertSquads(scope, requestKey)
    return requestKey
  }, "")

  createEffect(() => {
    const open = rightDockOpen()
    if (!open && rightDockAddMenuOpen()) setRightDockAddMenuOpen(false)
    if (!open && rightDockOverflowMenuOpen()) setRightDockOverflowMenuOpen(false)
    const dock = document.getElementById("rightDock")
    const resizer = document.getElementById("rightDockResizer")
    const focused = document.activeElement
    if (
      !open &&
      (dock?.contains(focused) || focused === resizer) &&
      untrack(primaryWorkspaceSurface) === "conversation" &&
      !untrack(() => dialogStore.config.open)
    ) {
      const toggle = document.querySelector<HTMLButtonElement>('[data-ui="chat-header-right-dock-toggle"]')
      if (toggle?.isConnected && !toggle.disabled && !toggle.closest("[inert]") && toggle.getClientRects().length) {
        toggle.focus({ preventScroll: true })
      }
    }
    if (dock) {
      dock.dataset.open = open ? "true" : "false"
      dock.inert = !open
      dock.setAttribute("aria-hidden", String(!open))
    }
    if (resizer) {
      resizer.dataset.open = open ? "true" : "false"
      resizer.setAttribute("aria-hidden", String(!open))
      resizer.tabIndex = open ? 0 : -1
    }
    renderRightDockWidth()
  })

  createEffect(() => {
    if (primaryWorkspaceSurface() === "mission-board" && rightDockOpen()) setRightDockVisible(false)
  })

  // body.dataset.workspace / .connection writes were dead — no CSS or JS in
  // the codebase reads either attribute. Removed (rule 10). The static
  // initial `data-workspace="offline"` in index.html is also stripped.

  createEffect(() => {
    if (!settingsHydrated()) return
    applyTheme(settingsStore.theme)
    applyZoom(settingsStore.zoom)
  })

  createEffect(() => {
    if (!settingsHydrated()) return
    configureApi({
      directory: activeDirectory(),
    })
  })

  createEffect(
    on(
      () => captureApiAuthority().revision,
      () => {
        setSideChatRequest(undefined)
        setMissionLauncherSubmitting(false)
        setExpertSquadLauncherSubmitting(false)
        setAssistantLauncherSubmitting(false)
        setComposerStopping(false)
      },
    ),
  )

  createEffect(
    on(
      () => settingsStore.workspaceEpoch,
      () => {
        setSelectedSubagentSessionID("")
        pendingPrimaryBrowserPreviewNavigation = undefined
      },
    ),
  )

  createEffect(() => {
    runMainAsync("locale.apply-settings", () => setLocale(settingsStore.locale))
  })

  onMount(() => syncScrollbarGuttersOnFrame.schedule())

  // ── Task-switch progress bar (non-blocking) ──
  // Reflects boardStore.taskSwitching (set synchronously at selectTask entry,
  // cleared when the async load chain completes). The bar lives in a fixed
  // slot above the chat header so user input is never gated on load.
  createEffect(() => {
    const active = boardStore.taskSwitching
    const bar = document.getElementById("taskSwitchProgress")
    if (!bar) return
    bar.setAttribute("data-active", active ? "true" : "false")
    bar.setAttribute("aria-busy", active ? "true" : "false")
  })

  createEffect(() => {
    const panels = centerWorkbenchPanels()
    const primarySurface = primaryWorkspaceSurface()
    const selectedTab = selectedCenterWorkbenchTab(panels)
    const workbench = document.getElementById("centerWorkbench")
    const views = getCenterWorkbenchViews()
    if (views.conversation) {
      views.conversation.dataset.workbenchView = primaryCenterPanel()
      views.conversation.dataset.open = String(primarySurface === "conversation")
      views.conversation.dataset.active = String(primarySurface === "conversation")
    }
    const missionBoard = document.getElementById("centerWorkbenchMissionBoard")
    if (missionBoard) {
      missionBoard.dataset.open = String(primarySurface === "mission-board")
      missionBoard.dataset.active = String(primarySurface === "mission-board")
    }
    if (workbench) {
      workbench.dataset.open = "true"
      workbench.hidden = false
    }
    for (const [panel, body] of Object.entries(views)) {
      if (!body) continue
      if (panel === "conversation") {
        continue
      }
      const open = panels.some((tab) => tab.panel === panel)
      const selected = open && panel === selectedTab?.panel
      body.dataset.open = String(open)
      body.dataset.active = String(selected)
    }
  })

  createEffect(
    on([fileWorkbenchOpen, fileEditorRevealRevision], ([open]) => {
      if (open) {
        openRightDockPanel("file")
      } else {
        removeCenterWorkbenchTabs((tab) => tab.panel === "file")
      }
    }),
  )

  createEffect(() => {
    if (!settingsHydrated()) return
    // Scale changes both pane constraints and default widths. Resolve geometry
    // after the theme effect applies the hydrated scale, not only on dragging.
    void settingsStore.zoom
    const sidebarCollapsed = settingsStore.sidebarCollapsed

    const sidebar = document.getElementById("sidebar")
    const leftActivityShell = document.getElementById("leftActivityShell")

    if (sidebar) {
      sidebar.dataset.collapsed = String(sidebarCollapsed)
      sidebar.hidden = false
    }
    if (leftActivityShell) {
      leftActivityShell.dataset.collapsed = String(sidebarCollapsed)
      leftActivityShell.inert = sidebarCollapsed
      leftActivityShell.setAttribute("aria-hidden", String(sidebarCollapsed))
    }

    schedulePaneLayout({
      sidebarCollapsed,
      sidebarWidth: settingsStore.sidebarWidth,
    })
    renderRightDockWidth()
  })

  return (
    <App
      primarySurface={primaryWorkspaceSurface}
      missionBoard={
        <MissionBoard
          projectDirectories={missionBoardProjectDirectories()}
          defaultProjectDirectory={activeDirectory()}
          onInstallMoreExpertSquads={(directory) =>
            void runUserNavigation("expert-squad.open-market", () => openExpertSquadMarketForProject(directory))
          }
          onMarketExpertSquadQuery={searchMissionMarketExpertSquads}
          onInstallMarketExpertSquad={installMissionMarketExpertSquad}
          onOpenMarketExpertSquad={openMissionMarketExpertSquad}
          canOpenMarketWebPage={getHostTransport().capabilities.nativeCommands["open-url"]}
          onOpenMission={(mission) =>
            runUserNavigation("mission-board.open-mission", () => openMissionBoardMission(mission))
          }
          onCreateManual={createMissionBoardDraft}
          onCreateWithAI={createMissionBoardWithAI}
          onDispatchMission={dispatchMissionBoardDraft}
          onEditMissionDraft={async (input) => {
            await editMissionDraft(input)
            setMissionSharedRefreshToken((value) => value + 1)
          }}
          onConfirmDeleteMission={confirmDeleteMissionBoardMission}
          onDeleteMission={deleteMissionBoardMission}
        />
      }
      onNewChat={() => openGlobalComposer(DEFAULT_COMPOSER_INTENT)}
      onSelectMission={openWorkLedgerMission}
      onSelectTask={selectTaskWithUILifecycle}
      onSelectChat={(sessionID, directory, experience) =>
        selectConversationWithUILifecycle(sessionID, directory, experience)
      }
      conversationExperience={() =>
        conversationSourceExperience() ??
        (conversationSubmitActive()
          ? conversationExperienceFromProductPillar(composerIntent().productPillar)
          : undefined)
      }
      conversationTitle={() => {
        settingsStore.locale
        const activeItem = workLedgerActiveItem({
          taskID: activeTaskID(),
          sessionID: activeSessionID(),
        })
        const selectedTaskTitle =
          boardStore.selectedSource?.kind === "task" && typeof boardStore.board?.task?.title === "string"
            ? boardStore.board.task.title.trim()
            : ""
        return missionSubmitActive()
          ? t("mission.launcher.title")
          : conversationSubmitActive()
            ? composerIntent().productPillar === "work"
              ? t("work.launcher.title")
              : t("coding_assistant.launcher.title")
            : activeItem?.title ||
              (primaryCenterPanel() === "mission"
                ? t("mission.title")
                : primaryCenterPanel() === "chat" || isConversationSource()
                  ? conversationSourceExperience() === "work" || composerIntent().productPillar === "work"
                    ? t("work_ledger.kind.work")
                    : t("chat.panel_title")
                  : selectedTaskTitle || t("task.panel_title"))
      }}
      conversationItem={() =>
        workLedgerActiveItem({
          taskID: activeTaskID(),
          sessionID: activeSessionID(),
        })
      }
      onCopyConversationDebug={copyActiveConversationDebug}
      onConversationPinnedChange={(row, pinned) =>
        runMainAsync("work-ledger.header-pin", () => setActiveWorkLedgerItemPinned(row, pinned))
      }
      onRenameConversationItem={(row) =>
        runMainAsync("work-ledger.header-rename", () => renameActiveWorkLedgerItem(row))
      }
      onArchiveConversationItem={(row) =>
        runMainAsync("work-ledger.header-archive", () => archiveActiveWorkLedgerItem(row))
      }
      onOpenAutomationSession={openAutomationSession}
      sidebarToggle={
        <Button
          variant="ghost"
          size="icon"
          tone="neutral"
          type="button"
          data-ui="titlebar-sidebar-toggle"
          data-chrome="icon-action"
          title={t(settingsStore.sidebarCollapsed ? "titlebar.sidebar_show" : "titlebar.sidebar_hide")}
          aria-label={t(settingsStore.sidebarCollapsed ? "titlebar.sidebar_show" : "titlebar.sidebar_hide")}
          aria-controls="sidebar workspaceMain"
          aria-expanded={!settingsStore.sidebarCollapsed}
          onClick={() => {
            setSettingsStore("sidebarCollapsed", !settingsStore.sidebarCollapsed)
            persistMainSettings("settings.persist-sidebar-collapse")
          }}
        >
          <Icon name="panel-left" />
        </Button>
      }
      leftPanelActions={
        <Button
          variant="ghost"
          size="icon"
          tone="neutral"
          type="button"
          data-ui="left-panel-open-project"
          data-chrome="icon-action"
          title={t("work_ledger.open_project")}
          aria-label={t("work_ledger.open_project")}
          onClick={() => runMainAsync("projects.open-folder", () => browseDirectory())}
        >
          <Icon name="project-add" size="medium" />
        </Button>
      }
      workLedger={(navigationMount) => (
        <WorkLedger
          navigationMount={navigationMount}
          primarySurface={primaryWorkspaceSurface()}
          onOpenConversations={() =>
            runMainAsync("work-ledger.open-conversations", async () => {
              await closeConfigDialog()
              setPrimaryWorkspaceSurface("conversation")
            })
          }
          selectedTaskID={activeTaskID()}
          selectedSessionID={activeSessionID()}
          refreshToken={missionSharedRefreshToken()}
          onOpenMissionBoard={() =>
            runMainAsync("work-ledger.open-mission-board", async () => {
              await closeConfigDialog()
              openMissionBoard()
            })
          }
          onSelectMission={(row) => runUserNavigation("work-ledger.select-mission", () => openWorkLedgerMission(row))}
          onSelectTask={(row) => runUserNavigation("work-ledger.select-task", () => selectWorkLedgerTask(row))}
          onSelectChat={(row) => runUserNavigation("work-ledger.select-chat", () => openWorkLedgerChat(row))}
          onAbortMission={abortWorkLedgerMission}
          onDownloadMission={downloadWorkLedgerMission}
          onRenameMission={renameWorkLedgerMission}
          onArchiveMission={archiveWorkLedgerMission}
          onCancelTask={cancelWorkLedgerTask}
          onDownloadTask={downloadWorkLedgerTask}
          onRenameTask={renameWorkLedgerTask}
          onArchiveTask={archiveWorkLedgerTask}
          onCreateGlobalChat={() => openGlobalComposer(DEFAULT_COMPOSER_INTENT)}
          onCreateChat={(directory) =>
            runUserNavigation("work-ledger.project-new-chat", () => selectWorkLedgerProject(directory))
          }
          onOpenProjectDirectory={(directory) =>
            runMainAsync("work-ledger.project-open-directory", () => openWorkLedgerProjectDirectory(directory))
          }
          onRenameProject={(directory, currentName) =>
            runMainAsync("work-ledger.project-rename", () => renameWorkLedgerProject(directory, currentName))
          }
          onPromoteProject={(directory) =>
            runUserNavigation("work-ledger.project-promote-anonymous", () =>
              promoteWorkLedgerAnonymousProject(directory),
            )
          }
          onStartMulticaImport={(directory) =>
            runUserNavigation("work-ledger.multica-import", () => startWorkLedgerMulticaImport(directory))
          }
          onDeleteProject={(directory) =>
            runMainAsync("work-ledger.project-delete", () => deleteWorkLedgerProject(directory))
          }
          onSelectProject={(directory) =>
            runUserNavigation("work-ledger.project-select", () => selectWorkLedgerProject(directory))
          }
          onStopChat={stopWorkLedgerChat}
          onRenameChat={renameWorkLedgerChat}
          onArchiveChat={archiveWorkLedgerChat}
        />
      )}
      mailbox={<MailboxPanel onSelectTask={selectTaskWithUILifecycle} />}
      conversation={(container) => (
        <QuotationSelection onQuote={quoteInMain} onSideChat={(quotation) => requestSideChat(quotation)}>
          <Conversation
            container={container}
            homeActive={homeActive()}
            launcherIntent={composerIntent()}
            onOpenSubagentConversation={openSubagentConversation}
            onOpenMissionBoard={openMissionBoard}
          />
        </QuotationSelection>
      )}
      homeActive={homeActive()}
      composer={
        <ChatComposer
          onSideChat={async (prompt) => requestSideChat(undefined, prompt)}
          availability={
            !canComposeChat()
              ? "unavailable"
              : missionLauncherSubmitting() || expertSquadLauncherSubmitting() || assistantLauncherSubmitting()
                ? "submitting"
                : "ready"
          }
          busy={
            !!messageStore.chatRequest || isTaskInterruptable() || workLedgerSessionInterruptible(activeSessionID())
          }
          stopping={composerStopping()}
          draftKey={panelComposerDraftKey()}
          placeholder={
            missionSubmitActive()
              ? t("mission.launcher.placeholder")
              : conversationSubmitActive()
                ? composerIntent().productPillar === "work"
                  ? t("work.launcher.placeholder")
                  : t("coding_assistant.launcher.placeholder")
                : undefined
          }
          textareaDataUI={
            missionSubmitActive()
              ? "mission-composer-input"
              : conversationSubmitActive()
                ? composerIntent().productPillar === "work"
                  ? "work-composer-input"
                  : "coding-assistant-composer-input"
                : undefined
          }
          sendDataUI={
            missionSubmitActive()
              ? "mission-composer-submit"
              : conversationSubmitActive()
                ? composerIntent().productPillar === "work"
                  ? "work-composer-submit"
                  : "coding-assistant-composer-submit"
                : undefined
          }
          skills={
            composerIntent().conversationTarget === "chat"
              ? composerExpertSquadCatalog().chatSkills
              : composerExpertSquadCatalog().skills
          }
          missionSkills={composerExpertSquadCatalog().missionSkills}
          referenceCatalogError={composerReferenceCatalogError(composerExpertSquadCatalog())}
          onReferenceCatalogRetry={retryComposerReferenceCatalog}
          expertSquads={composerExpertSquadCatalog().squads}
          onExpertSquadQuery={(query, selectedIDs) => void searchComposerExpertSquads(query, selectedIDs)}
          onMarketExpertSquadQuery={searchComposerMarketExpertSquads}
          onInstallMarketExpertSquad={installComposerMarketExpertSquad}
          onInstallMoreExpertSquads={() =>
            void runUserNavigation("expert-squad.open-market", () => openExpertSquadMarketForProject())
          }
          activeExpertSquadPackage={composerExpertSquadCatalog().activePackage}
          conversationActive={Boolean(activeTaskID() || activeSessionID())}
          launchReferences={composerLaunchReferences()}
          conversationExperience={conversationSourceExperience()}
          composerIntent={composerIntent()}
          activeComposerIntent={resolvedActiveComposerIntent()}
          activeWorkItemKind={workLedgerActiveItem({ taskID: activeTaskID(), sessionID: activeSessionID() })?.kind}
          onComposerIntentChange={(intent) =>
            runUserNavigation("composer.mode-change", () => handleComposerIntentChange(intent))
          }
          resolveAttachmentDirectory={(selectionEpoch, authority) => {
            assertApiAuthorityCurrent(authority)
            const intent = { ...composerIntent() }
            const needsProject = !activeDirectory().trim()
            const sourceDraftKey = panelComposerDraftKey()
            const sourceDraft = composerDraftText(sourceDraftKey)
            const operation = resolveGlobalComposerProject({ kind: "attachment", selectionEpoch, authority })
            return {
              ...operation,
              promise: operation.promise.then((resolution) => {
                assertApiAuthorityCurrent(authority)
                assertUserNavigationCurrent(resolution.selectionEpoch)
                const { directory } = resolution
                if (needsProject)
                  runMainAsync("composer.remember-attachment-project", () =>
                    rememberProjectComposerIntent(directory, intent),
                  )
                const targetDraftKey = panelComposerDraftKey()
                if (sourceDraftKey !== targetDraftKey && sourceDraft && !composerDraftText(targetDraftKey)) {
                  setComposerDraft(targetDraftKey, sourceDraft)
                }
                return resolution
              }),
            }
          }}
          onSubmit={async (text, attachments, webSearch, directives, markDispatched, authority) => {
            assertApiAuthorityCurrent(authority)
            const submittedIntent = { ...composerIntent() }
            const submittedWithoutProject = !activeDirectory().trim()
            const submitRoute = resolveComposerSubmitRoute(directives)
            const intentRoute = resolveComposerIntentRoute(composerIntent(), submitRoute.kind === "mission")
            const metadata = webSearch ? { web_search: true } : {}
            if (intentRoute.kind === "mission" && (submitRoute.kind === "mission" || missionSubmitActive())) {
              setExpertSquadLauncherSubmitting(true)
              try {
                const admission = await requestWorkspaceSelection()
                assertApiAuthorityCurrent(authority)
                if (admission.kind === "unchanged") return
                const selectionEpoch = admission.epoch
                const { directory, model } = await resolveGlobalComposerSubmissionContext(selectionEpoch, authority)
                if (!ownsWorkspaceSelection(selectionEpoch))
                  throw new DOMException("Mission submission superseded", "AbortError")
                resetCenterWorkbenchToPrimaryPanel("mission")
                markDispatched()
                const result = await wakeMission({
                  authority,
                  directory,
                  text,
                  attachments,
                  model,
                  productPillar: intentRoute.productPillar,
                  expertSquadIDs: submitRoute.kind === "mission" ? submitRoute.expertSquadIDs : undefined,
                })
                if (!isApiAuthorityCurrent(authority)) return result
                await openMissionSession(result, directory, selectionEpoch, authority)
                if (!isApiAuthorityCurrent(authority)) return result
                if (submittedWithoutProject)
                  runMainAsync("composer.remember-created-project", () =>
                    rememberProjectComposerIntent(directory, submittedIntent),
                  )
                setMissionSharedRefreshToken((value) => value + 1)
                return result
              } finally {
                if (isApiAuthorityCurrent(authority)) setExpertSquadLauncherSubmitting(false)
              }
            }
            if (conversationSubmitActive()) {
              setAssistantLauncherSubmitting(true)
              try {
                const admission = await requestWorkspaceSelection()
                assertApiAuthorityCurrent(authority)
                if (admission.kind === "unchanged") return
                const selectionEpoch = admission.epoch
                resetCenterWorkbenchToPrimaryPanel("chat")
                const directory = activeDirectory().trim()
                const experience = intentRoute.kind === "conversation" ? intentRoute.experience : undefined
                if (!experience) throw new Error("Conversation submit resolved without a conversation experience")
                if (directory) {
                  await createConversationSession({
                    authority,
                    selectionEpoch,
                    directory,
                    experience,
                    model: appStore.composerModel || undefined,
                  })
                } else
                  await createGlobalConversationSession({
                    authority,
                    selectionEpoch,
                    experience,
                    model: appStore.composerModel || undefined,
                  })
                assertApiAuthorityCurrent(authority)
                if (!ownsWorkspaceSelection(selectionEpoch))
                  throw new DOMException("Conversation submission superseded", "AbortError")
                if (submittedWithoutProject) {
                  const createdDirectory = activeDirectory().trim()
                  runMainAsync("composer.remember-created-project", () =>
                    rememberProjectComposerIntent(createdDirectory, submittedIntent),
                  )
                }
                const result = await panelMessage(text, attachments, metadata, markDispatched, { authority })
                if (!isApiAuthorityCurrent(authority)) return result
                const source = boardStore.selectedSource
                if (
                  source?.kind === "session" &&
                  boardStore.board?.kind === "session" &&
                  boardStore.board.sessionID === source.id
                ) {
                  setBoardStore("board", "composerReferences", visibleComposerReferences(text))
                }
                setMissionSharedRefreshToken((value) => value + 1)
                return result
              } finally {
                if (isApiAuthorityCurrent(authority)) setAssistantLauncherSubmitting(false)
              }
            }
            const refreshMissionLedger = isMissionSessionSource()
            const result = await panelMessage(text, attachments, metadata, markDispatched, { authority })
            if (!isApiAuthorityCurrent(authority)) return result
            if (refreshMissionLedger) setMissionSharedRefreshToken((value) => value + 1)
            return result
          }}
          onStop={() => {
            runMainAsync("chat.stop", async () => {
              if (composerStopping()) return
              setComposerStopping(true)
              try {
                if (messageStore.chatRequest) {
                  await stopChatRequest()
                  return
                }
                const taskID = activeTaskID()
                if (taskID && isTaskInterruptable()) {
                  await cancelTask(taskID, {
                    surface: "overlay.composer_stop",
                    reason: "Operator stopped the active task from the composer",
                  })
                  return
                }
                const execution = workLedgerSessionExecution(activeSessionID())
                if (execution?.kind === "mission") {
                  const ok = await abortMission(
                    { missionID: execution.missionID, directory: execution.directory },
                    {
                      surface: "overlay.composer_stop",
                      reason: "Operator stopped the active Mission from the composer",
                    },
                  )
                  if (!ok) throw new Error(t("mission.error.action.abort"))
                  setMissionSharedRefreshToken((value) => value + 1)
                  return
                }
                if (execution?.kind === "chat") {
                  const ok = await stopConversationSession({
                    sessionID: execution.sessionID,
                    directory: execution.directory,
                    experience: execution.experience,
                  })
                  if (!ok) throw new Error("Coding assistant stop failed")
                  setMissionSharedRefreshToken((value) => value + 1)
                }
              } finally {
                setComposerStopping(false)
              }
            })
          }}
        />
      }
      rightDock={
        <RightDock
          addMenuOpen={rightDockAddMenuOpen}
          tabs={rightDockTabPanels}
          open={rightDockOpen}
          active={() => {
            const selected = selectedCenterWorkbenchTab()
            return selected?.panel === "conversation" ? null : (selected?.id ?? null)
          }}
          onSelect={activateCenterWorkbenchTab}
          onOpen={openRightDockPanel}
          onNewBrowserTab={openBlankBrowserTab}
          onClose={closeRightDockTab}
          onCloseDock={() => setRightDockVisible(false)}
          onAddMenuOpenChange={setRightDockAddMenuOpen}
          overflowMenuOpen={rightDockOverflowMenuOpen}
          onOverflowMenuOpenChange={setRightDockOverflowMenuOpen}
          titleForTab={(tab) => {
            if (tab.panel === "browser") return browserPreviewPageTitles()[tab.id]
            return undefined
          }}
        >
          <TabPanel
            value="explorer"
            forceMount={isCenterWorkbenchPanelOpen("explorer")}
            class="center-workbench-view"
            id="centerWorkbenchExplorer"
            data-workbench-view="explorer"
            data-open={String(isCenterWorkbenchPanelOpen("explorer"))}
            data-active={String(selectedCenterWorkbenchTab()?.id === "explorer")}
          >
            <div id="solidFileExplorerMount" class="center-workbench-activity sidebar-explorer-panel">
              <FileExplorerPanel active={() => isCenterWorkbenchPanelOpen("explorer")} directory={activeDirectory} />
            </div>
          </TabPanel>
          <TabPanel
            value="diff"
            class="center-workbench-view"
            id="centerWorkbenchDiff"
            data-workbench-view="diff"
            data-open={String(isCenterWorkbenchPanelOpen("diff"))}
            data-active={String(selectedCenterWorkbenchTab()?.id === "diff")}
          >
            <div id="solidFileChangesMount" class="center-workbench-activity sidebar-file-changes-panel">
              <FileChangesPanel
                active={() => isCenterWorkbenchPanelOpen("file") || isCenterWorkbenchPanelOpen("diff")}
              />
            </div>
          </TabPanel>
          <TabPanel
            value="browser"
            forceMount={centerWorkbenchPanels().some((tab) => tab.id === "browser")}
            class="center-workbench-view"
            id="centerWorkbenchBrowser"
            data-workbench-view="browser"
            data-open={String(isCenterWorkbenchPanelOpen("browser"))}
            data-active={String(selectedCenterWorkbenchTab()?.id === "browser")}
          >
            <div id="solidBrowserPreviewMount" class="center-workbench-activity chat-browser-preview-activity">
              <BrowserPreviewPanel
                tabID="browser"
                active={() =>
                  rightDockOpen() && !rightDockOverflowMenuOpen() && selectedCenterWorkbenchTab()?.id === "browser"
                }
                directory={activeDirectory}
                refreshKey={browserPreviewRevision}
                scrollElement={() => document.querySelector<HTMLElement>(".right-dock-body")}
                taskID={() => activeBrowserPreviewTaskID() || undefined}
                registerController={registerPrimaryBrowserPreviewController}
                onPageTitleChange={(title) =>
                  setBrowserPreviewPageTitles((current) => ({ ...current, browser: title }))
                }
                onReady={() => presentRightDockPanel("browser")}
                onCommentDraft={(text) => {
                  const key = panelComposerDraftKey()
                  const existing = composerDraftText(key)
                  setComposerDraft(key, existing ? `${existing}\n\n${text}` : text)
                }}
              />
            </div>
          </TabPanel>
          <For each={centerWorkbenchPanels().filter((tab) => tab.panel === "browser" && !tab.taskPreview)}>
            {(tab) => (
              <TabPanel
                value={tab.id}
                forceMount
                class="center-workbench-view"
                id={`centerWorkbenchBrowser-${tab.id}`}
                data-workbench-view="browser"
                data-open="true"
                data-active={String(selectedCenterWorkbenchTab()?.id === tab.id)}
              >
                <div class="center-workbench-activity chat-browser-preview-activity">
                  <BrowserPreviewPanel
                    tabID={tab.id}
                    active={() =>
                      rightDockOpen() && !rightDockOverflowMenuOpen() && selectedCenterWorkbenchTab()?.id === tab.id
                    }
                    directory={activeDirectory}
                    refreshKey={browserPreviewRevision}
                    scrollElement={() => document.querySelector<HTMLElement>(".right-dock-body")}
                    taskID={() => undefined}
                    onPageTitleChange={(title) =>
                      setBrowserPreviewPageTitles((current) => ({ ...current, [tab.id]: title }))
                    }
                    onCommentDraft={(text) => {
                      const key = panelComposerDraftKey()
                      const existing = composerDraftText(key)
                      setComposerDraft(key, existing ? `${existing}\n\n${text}` : text)
                    }}
                  />
                </div>
              </TabPanel>
            )}
          </For>
          <TabPanel
            value="screenshots"
            class="center-workbench-view"
            id="centerWorkbenchScreenshots"
            data-workbench-view="screenshots"
            data-open={String(isCenterWorkbenchPanelOpen("screenshots"))}
            data-active={String(selectedCenterWorkbenchTab()?.id === "screenshots")}
          >
            <div id="solidScreenshotBrowserMount" class="center-workbench-activity screenshot-browser-activity">
              <ScreenshotBrowserPanel active={() => isCenterWorkbenchPanelOpen("screenshots")} />
            </div>
          </TabPanel>
          <TabPanel
            value="side-chat"
            class="center-workbench-view"
            id="centerWorkbenchSideChat"
            data-workbench-view="side-chat"
            data-open={String(isCenterWorkbenchPanelOpen("side-chat"))}
            data-active={String(selectedCenterWorkbenchTab()?.id === "side-chat")}
          >
            <SideChatPanel
              source={sideChatSource()}
              request={sideChatRequest()}
              consumeRequest={(request) => setSideChatRequest((current) => (current === request ? undefined : current))}
              onQuoteInMain={quoteInMain}
            />
          </TabPanel>
          <TabPanel
            value="subagent"
            forceMount
            class="center-workbench-view"
            id="centerWorkbenchSubagent"
            data-workbench-view="subagent"
            data-open={String(isCenterWorkbenchPanelOpen("subagent"))}
            data-active={String(selectedCenterWorkbenchTab()?.id === "subagent")}
          >
            <div id="solidSubagentConversationMount" class="center-workbench-activity subagent-conversation-activity">
              <SubagentConversationPanel
                active={() =>
                  rightDockOpen() &&
                  !rightDockAddMenuOpen() &&
                  !rightDockOverflowMenuOpen() &&
                  selectedCenterWorkbenchTab()?.panel === "subagent"
                }
                sessionID={selectedSubagentSessionID}
                onSessionSelect={setSelectedSubagentSessionID}
              />
            </div>
          </TabPanel>
          <TabPanel
            value="requirements"
            class="center-workbench-view"
            id="centerWorkbenchRequirements"
            data-workbench-view="requirements"
            data-open={String(isCenterWorkbenchPanelOpen("requirements"))}
            data-active={String(selectedCenterWorkbenchTab()?.id === "requirements")}
          >
            <div id="solidRequirementsPanelMount" class="center-workbench-activity task-scope-activity">
              <RequirementsBoardPanel />
            </div>
          </TabPanel>
          <TabPanel
            value="goals"
            class="center-workbench-view"
            id="centerWorkbenchGoals"
            data-workbench-view="goals"
            data-open={String(isCenterWorkbenchPanelOpen("goals"))}
            data-active={String(selectedCenterWorkbenchTab()?.id === "goals")}
          >
            <div id="solidGoalsPanelMount" class="center-workbench-activity task-scope-activity">
              <GoalsBoardPanel />
            </div>
          </TabPanel>
          <TabPanel
            value="file"
            forceMount={fileWorkbenchOpen()}
            class="center-workbench-view"
            id="centerWorkbenchFile"
            data-workbench-view="file"
            data-open={String(isCenterWorkbenchPanelOpen("file"))}
            data-active={String(selectedCenterWorkbenchTab()?.id === "file")}
          >
            <div
              id="solidFileEditorMount"
              class="center-workbench-activity chat-file-editor-activity file-editor-mount"
            >
              <FileEditorPane />
            </div>
          </TabPanel>
        </RightDock>
      }
      onOpenRightDockPanel={openRightDockPanel}
      onOpenSubagentConversation={openSubagentConversation}
      onOpenRightDockAddMenu={openRightDockAddMenu}
      logViewer={<LogViewer open={logOpen()} onClose={() => setLogOpen(false)} />}
    />
  )
}

/**
 * Wait for the frame that paints the mounted application, but never longer
 * than one deadline. `requestAnimationFrame` is only guaranteed to fire while
 * the surface is compositing: a hidden window, a background tab, or a
 * non-displayed embedded pane starves it indefinitely. This await sits in
 * top-level module evaluation, so a starved frame suspends the module before
 * `initApp` is ever reached — the overlay renders its shell, never connects,
 * and reports itself Offline forever with no error to show for it. Showing one
 * frame early is a cosmetic concern; booting at all is not.
 */
function firstPaintedFrame(): Promise<void> {
  const FRAME_DEADLINE_MS = 250
  return new Promise<void>((resolve) => {
    let settled = false
    const settle = () => {
      if (settled) return
      settled = true
      clearTimeout(timer)
      resolve()
    }
    const timer = setTimeout(settle, FRAME_DEADLINE_MS)
    requestAnimationFrame(settle)
  })
}

const overlayAppHost = document.getElementById("overlayAppHost")
if (!overlayAppHost) throw new Error("Overlay application host is missing from index.html")
const startup = (window as Window & { __opencorvusStartup?: { ready: Promise<void>; mounted: () => void } })
  .__opencorvusStartup
if (!startup) throw new Error("Overlay startup lifecycle contract is missing from index.html")
await startup.ready
// The static loading surface is present before this module is evaluated so the
// native window never exposes an empty WebView. Solid appends to its host, so
// remove that one pre-mount child before the application takes ownership.
overlayAppHost.replaceChildren()
disposers.push(render(() => <OverlayRoot />, overlayAppHost))
startup.mounted()
await firstPaintedFrame()
await showOverlayWindow()
disposers.push(installExpertSquadInstallHandoffBridge())
const clipboardApiKeyPrompt = installClipboardApiKeyPrompt()
disposers.push(() => clipboardApiKeyPrompt.dispose())

// ── Right dock width resize ──
// The right dock is resized by dragging `#rightDockResizer`. Width persists to
// `settingsStore.rightDockWidth` and renders through `renderRightDockWidth`.

let rightDockResizeActive = false
let pendingRightDockResizeClientX: number | null = null

function rightDockResizeBounds(): { min: number; max: number } {
  const workspace = document.getElementById("workspaceMain")
  const min = layoutTokenPx("--ui-workbench-panel-min-width")
  const configuredMax = layoutTokenPx("--ui-right-dock-max-width")
  const conversationMin = layoutTokenPx("--ui-chat-min-width")
  const resizerWidth = layoutTokenPx("--oc-border-width")
  const max = workspace
    ? Math.min(configuredMax, workspace.clientWidth - conversationMin - resizerWidth)
    : configuredMax
  return { min, max: Math.max(max, min) }
}

function clampRightDockWidth(raw: number): number {
  const { min, max } = rightDockResizeBounds()
  return Math.max(min, Math.min(max, raw))
}

function applyPendingRightDockResize(): void {
  const clientX = pendingRightDockResizeClientX
  pendingRightDockResizeClientX = null
  if (!rightDockResizeActive || clientX == null) return
  const dock = document.getElementById("rightDock")
  if (!dock) return
  const width = clampRightDockWidth(dock.getBoundingClientRect().right - clientX)
  setSettingsStore("rightDockWidth", width)
  renderRightDockWidth()
}

const applyRightDockResizeOnFrame = createAnimationFrameScheduler(applyPendingRightDockResize)
disposers.push(() => {
  applyRightDockResizeOnFrame.cancel()
  pendingRightDockResizeClientX = null
})

function startRightDockResize(event: PointerEvent): void {
  rightDockResizeActive = true
  document.body.dataset.rightDockResizing = "true"
  event.preventDefault()
}

function updateRightDockResize(event: PointerEvent): void {
  if (!rightDockResizeActive) return
  pendingRightDockResizeClientX = event.clientX
  applyRightDockResizeOnFrame.schedule()
}

function stopRightDockResize(): void {
  if (!rightDockResizeActive) return
  applyRightDockResizeOnFrame.cancel()
  applyPendingRightDockResize()
  rightDockResizeActive = false
  delete document.body.dataset.rightDockResizing
  persistMainSettings("settings.persist-right-dock-resize")
}

function resizeRightDockByKeyboard(event: KeyboardEvent): void {
  const dock = document.getElementById("rightDock")
  if (!dock) return
  const step = 24 * currentUIScale()
  let width = dock.getBoundingClientRect().width
  if (event.key === "ArrowLeft") {
    width += step
  } else if (event.key === "ArrowRight") {
    width -= step
  } else if (event.key === "Home") {
    width = layoutTokenPx("--ui-right-dock-max-width")
  } else if (event.key === "End") {
    width = layoutTokenPx("--ui-workbench-panel-min-width")
  } else {
    return
  }
  event.preventDefault()
  setSettingsStore("rightDockWidth", clampRightDockWidth(width))
  renderRightDockWidth()
  persistMainSettings("settings.persist-right-dock-keyboard")
}

{
  const observer = new ResizeObserver(() => renderRightDockHandleSemanticsOnFrame.schedule())
  for (const id of ["rightDock", "workspaceMain"]) {
    const element = document.getElementById(id)
    if (element) observer.observe(element)
  }
  disposers.push(() => observer.disconnect())
  const resizer = document.getElementById("rightDockResizer")
  if (resizer) {
    resizer.addEventListener(
      "pointerdown",
      (event) => {
        if (event.button != null && event.button !== 0) return
        startRightDockResize(event)
      },
      listenerOpts,
    )
    resizer.addEventListener("keydown", resizeRightDockByKeyboard, listenerOpts)
  }
}
window.addEventListener(
  "pointermove",
  (event) => {
    updateRightDockResize(event)
  },
  listenerOpts,
)
window.addEventListener("pointerup", stopRightDockResize, listenerOpts)
window.addEventListener("pointercancel", stopRightDockResize, listenerOpts)

// ── Global event listeners (

window.addEventListener("keydown", handleZoomHotkey, listenerOpts)
window.addEventListener(
  "keydown",
  (e: KeyboardEvent) => {
    if ((e.ctrlKey || e.metaKey) && e.altKey && e.key.toLowerCase() === "s" && sideChatSource()) {
      e.preventDefault()
      requestSideChat()
      return
    }
    if (e.key === "F12") {
      e.preventDefault()
      runMainAsync("devtools.toggle", () => toggleDevtools())
    }
  },
  listenerOpts,
)
function applyWindowResize(): void {
  applyZoom(settingsStore.zoom)
  syncScrollbarGutters()
  schedulePaneLayout(paneCallbacks.getState())
  renderRightDockWidth()
}

const applyWindowResizeOnFrame = createAnimationFrameScheduler(applyWindowResize)
disposers.push(() => applyWindowResizeOnFrame.cancel())
window.addEventListener("resize", applyWindowResizeOnFrame.schedule, listenerOpts)
if (window.visualViewport)
  window.visualViewport.addEventListener("resize", applyWindowResizeOnFrame.schedule, listenerOpts)
window.addEventListener(
  "blur",
  () => {
    runMainAsync("pane.cancel-resize", () => cancelPaneResize(paneCallbacks))
    stopRightDockResize()
  },
  listenerOpts,
)
function confirmUnsavedPageExit(event: BeforeUnloadEvent): void {
  event.preventDefault()
  event.returnValue = ""
}
disposers.push(
  createRoot((dispose) => {
    createEffect(() => {
      if (!hasUnsavedFileChanges()) return
      window.addEventListener("beforeunload", confirmUnsavedPageExit)
      onCleanup(() => window.removeEventListener("beforeunload", confirmUnsavedPageExit))
    })
    return dispose
  }),
)
window.addEventListener(
  "pagehide",
  (event) => {
    if (!event.persisted) runModuleTeardown()
  },
  listenerOpts,
)
installSystemThemeListener(() => applyTheme(settingsStore.theme))

// ── Init ──
runMainAsync("initApp", async () => {
  startDesktopUpdateMonitor()
  disposers.push(stopDesktopUpdateMonitor)
  try {
    await initApp({
      onSettingsLoaded: () => {
        setSettingsHydrated(true)
      },
      onConnected: async () => {
        await focusInitialRestoredTaskWorkspace()
        void clipboardApiKeyPrompt.checkNow()
      },
    })
  } catch (error) {
    reportOverlayRuntimeError("initApp", error)
  } finally {
    try {
      await waitForLogDrain()
    } catch (error) {
      console.error("[initApp] failed to drain overlay logs", error)
    }
  }
})
