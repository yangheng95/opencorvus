import fs from 'node:fs'
const phase=process.argv[2]
if(!['before','after','final','verified','recovery','feedback'].includes(phase))throw Error('Explicit phase required')
const root='.tmp-product-iteration/workspace-refresh-location-430',tag='workspace-refresh-location-430-'+phase,port=phase==='before'?18587:phase==='after'?18589:phase==='final'?18591:phase==='verified'?18593:phase==='recovery'?18595:18597
const base='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-15',bundle=base+'/'+tag+'-bundle/bin'
if(fs.existsSync(bundle))throw Error('Fresh native publication required')
fs.mkdirSync(bundle,{recursive:true});fs.copyFileSync('.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64/bun.exe',bundle+'/bun.exe');fs.cpSync('packages/overlay/dist-vite',bundle+'/ui',{recursive:true})
fs.mkdirSync(root+'/'+phase,{recursive:true})
for(const name of ['launch.ps1','settle.ps1','shutdown.ps1']){
 let source=fs.readFileSync('.tmp-product-iteration/source-path-readability-429/before/'+name,'utf8')
 source=source.replaceAll('source-path-readability-429-before',tag).replaceAll('.tmp-product-iteration/source-path-readability-429/before',root+'/'+phase).replaceAll('18583',String(port))
 fs.writeFileSync(root+'/'+phase+'/'+name,source)
}
if(phase==='before'){
 for(const file of ['services/task-deep-link.ts','services/init.ts','services/task.ts','services/conversation-session.ts','store/board.ts','main.tsx']){
  const target=root+'/original/'+file;fs.mkdirSync(target.substring(0,target.lastIndexOf('/')),{recursive:true});fs.copyFileSync('packages/overlay/src/'+file,target)
 }
 for(const name of ['task-selection-guard.test.ts','workspace-directory-persistence.test.ts'])fs.copyFileSync('packages/overlay/test/'+name,root+'/'+name+'.before')
 const artifact='specs/artifacts/2026-10-15-workspace-refresh-location';fs.mkdirSync(artifact,{recursive:true});fs.writeFileSync(artifact+'/README.md','# 当前会话刷新定位证据\n\n[方案与Recall](../../records/2026-10/2026-10-15-workspace-refresh-location.md)。实际页面与真实历史，执行后写入明确结果。\n')
 for(const [file,line] of [
  ['specs/README.md','- [当前会话刷新定位](records/2026-10/2026-10-15-workspace-refresh-location.md)：单一URL定位与真实会话恢复。'],
  ['specs/records/2026-10/README.md','- [当前会话刷新定位](2026-10-15-workspace-refresh-location.md)：原刷新丢选择、导航根因与桌面验收。'],
  ['specs/artifacts/README.md','- [当前会话刷新定位](2026-10-15-workspace-refresh-location/README.md)：原页面、位置与资源结算。'],
 ]){const text=fs.readFileSync(file,'utf8');if(text.includes(line))throw Error('Already indexed');fs.writeFileSync(file,text.trimEnd()+'\n\n'+line+'\n')}
}
console.log(JSON.stringify({phase,port,tag,budget:'600s / 180s inactivity / 12 streams',qualification:'NativeService history reader'}))
