import fs from 'node:fs'
import {Database} from 'bun:sqlite'
const filename='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/member-live-rendering-412-fresh/runtime/data/opencorvus.db'
const db=new Database(filename,{readonly:true})
try {
 const kinds=db.query('SELECT kind,COUNT(*) AS count FROM session GROUP BY kind').all()
 const sessions=db.query("SELECT id,project_id,directory,kind,title,metadata FROM session WHERE parent_id IS NULL ORDER BY time_updated DESC LIMIT 35").all().map((row:any)=>({id:row.id,projectID:row.project_id,directory:row.directory,kind:row.kind,title:row.title,conversation:JSON.parse(row.metadata||'{}').conversation,mission:JSON.parse(row.metadata||'{}').mission}))
 const receipt={at:new Date().toISOString(),version:db.query('PRAGMA user_version').get(),kinds,sessions,boundary:'Read-only original owned QA history; no application runtime or synthetic message'}
 fs.writeFileSync(import.meta.dir+'/inventory.json',JSON.stringify(receipt,null,2));console.log(JSON.stringify({kinds,sessions:sessions.map(({id,kind,mission,conversation}:any)=>({id,kind,mission,conversation}))},null,2))
}finally{db.close(true)}
