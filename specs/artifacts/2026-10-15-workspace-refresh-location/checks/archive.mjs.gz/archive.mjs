import fs from 'node:fs'
import path from 'node:path'
import zlib from 'node:zlib'
import assert from 'node:assert/strict'
const root=import.meta.dirname,dest=path.resolve('specs/artifacts/2026-10-15-workspace-refresh-location')
const save=(name,bytes)=>{const target=path.join(dest,name);fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,zlib.gzipSync(bytes))}
const scopes=[]
for(const phase of ['before','after','final','verified','recovery','feedback']){
 const evidence=`C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-15/workspace-refresh-location-430-${phase}/evidence`
 const clean=JSON.parse(fs.readFileSync(evidence+'/physical-terminal-and-pair-cleanup.json','utf8'))
 const native=JSON.parse(fs.readFileSync(evidence+'/native-host-settled.json','utf8'))
 assert.equal(clean.physicalCompletion,true);assert.equal(clean.pairedCleanupComplete,true);assert.equal(native.terminal.exitCode,0)
 const audits=fs.readdirSync(evidence).filter(name=>/^provider-.*\.json$/.test(name)&&name!=='provider-pair-staging.json').map(name=>({name,value:JSON.parse(fs.readFileSync(evidence+'/'+name,'utf8'))})).filter(entry=>Array.isArray(entry.value.requests)).sort((a,b)=>b.value.requests.length-a.value.requests.length||Date.parse(b.value.observedAt)-Date.parse(a.value.observedAt))
 const last=audits[0];assert(last)
 const requests=last.value.requests.map(({model,streaming,status,response_reader})=>({model,streaming,status,response_reader}))
 for(const request of requests){assert.equal(request.model,'gpt-6.1-sol');assert.equal(request.streaming,true);assert.equal(request.status,200);assert.equal(request.response_reader.state,'settled')}
 for(const name of ['native-host-ready.json','native-host-settled.json','physical-terminal-and-pair-cleanup.json','preflight-ready.json','provider-pair-staging.json','public-shutdown.json','launcher-child-exit.json'])save(phase+'/'+name+'.gz',fs.readFileSync(evidence+'/'+name))
 save(phase+'/provider-summary.json.gz',JSON.stringify({source:last.name,requests},null,2))
 for(const name of ['launch.ps1','settle.ps1','shutdown.ps1','launch.log'])save(phase+'/'+name+'.gz',fs.readFileSync(root+'/'+phase+'/'+name))
 scopes.push({phase,requestCount:requests.length,terminal:native.terminal,physicalCompletion:true,pairedCleanupComplete:true})
}
const walk=dir=>fs.readdirSync(dir,{withFileTypes:true}).flatMap(entry=>entry.isDirectory()?walk(path.join(dir,entry.name)):[path.join(dir,entry.name)])
for(const file of walk(root+'/original'))save('original/'+path.relative(root+'/original',file)+'.gz',fs.readFileSync(file))
for(const name of fs.readdirSync(root)){
 const file=path.join(root,name)
 // Removed UI test source remains in Git history, not in this evidence archive.
 if(fs.statSync(file).isFile()&&/\.(ts|mjs|json|log)$/.test(name))save('checks/'+name+'.gz',fs.readFileSync(file))
}
const result={at:new Date().toISOString(),scopes,screenshots:fs.readdirSync(dest).filter(name=>name.endsWith('.jpg')),boundary:'Real history/manual draft and rendered page interactions; no UI automated tests or fixture messages; earlier failed launcher runs retained'}
fs.writeFileSync(root+'/review-result.json',JSON.stringify(result,null,2));save('checks/review-result.json.gz',JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2))
