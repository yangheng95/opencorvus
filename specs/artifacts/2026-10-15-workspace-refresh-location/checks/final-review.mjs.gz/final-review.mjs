import fs from 'node:fs'
import path from 'node:path'
import zlib from 'node:zlib'
const root=import.meta.dirname,artifact=path.resolve('specs/artifacts/2026-10-15-workspace-refresh-location')
for(const name of ['docs-check.log','architecture-check.log','archive.log','typecheck-current.log','i18n-current.log','css-current.log','final-review.mjs'])fs.writeFileSync(artifact+'/checks/'+name+'.gz',zlib.gzipSync(fs.readFileSync(root+'/'+name)))
const walk=dir=>fs.readdirSync(dir,{withFileTypes:true}).flatMap(entry=>entry.isDirectory()?walk(path.join(dir,entry.name)):[path.join(dir,entry.name)])
const files=walk(artifact),values=[]
const collect=obj=>{for(const [key,value] of Object.entries(obj)){if(value&&typeof value==='object')collect(value);else if(typeof value==='string'&&value.length>16&&/access|refresh|token|key|secret|password/i.test(key))values.push(value)}}
collect(JSON.parse(fs.readFileSync('C:/Users/hengu/AppData/Local/opencorvus/data/auth.json','utf8')))
if(values.length===0)throw new Error('Actual credential material required for in-memory disclosure review')
for(const file of files){
 if(file.endsWith('.jpg'))continue
 const bytes=fs.readFileSync(file),text=(file.endsWith('.gz')?zlib.gunzipSync(bytes):bytes).toString('utf8')
 for(const value of values)if(text.includes(value))throw new Error(`Credential disclosure in ${file}`)
}
const review=JSON.parse(fs.readFileSync(root+'/review-result.json','utf8'))
console.log(JSON.stringify({artifactFiles:files.length,credentialDisclosureReview:'passed; credential values remain in memory',scopes:review.scopes.map(({phase,requestCount,physicalCompletion,pairedCleanupComplete})=>({phase,requestCount,physicalCompletion,pairedCleanupComplete})),screenshots:review.screenshots.length,typecheckPackages:8,docs:'345 operations / 26 groups',architecture:'20 current documents',i18n:'2 locales / 2490 keys'}))
