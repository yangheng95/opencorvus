import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import {bootstrapIsolatedTestRuntime,removeIsolatedTestRuntime} from '../../packages/util/src/test-runtime-environment'
import {prepareTestProcessSupervisor} from '../../packages/opencorvus/script/prepare-test-process-supervisor'
const supervisor=prepareTestProcessSupervisor()
const runtime=await bootstrapIsolatedTestRuntime('runner')
if(supervisor)process.env.OPENCORVUS_PROCESS_SUPERVISOR=supervisor
try{
 const {installProcessShims}=await import('../../packages/opencorvus/src/runtime/shims')
 installProcessShims()
 const {executionCapsuleSourceTreeSnapshot}=await import('../../packages/opencorvus/src/execution-capsule/tree-digest')
 const {canonicalWorkspaceTreeJSON}=await import('../../packages/plugin/src/workspace-tree')
 const material=JSON.parse(fs.readFileSync('.tmp-product-iteration/literal-reference-click-423/material.json','utf8'))
 const snapshot=await executionCapsuleSourceTreeSnapshot(material.project)
 const wire=JSON.parse(canonicalWorkspaceTreeJSON(snapshot)) as typeof snapshot
 const files=material.files.map((original:{path:string;content:string})=>{
  const actual=wire.files.find(file=>file.path===original.path)
  assert(actual,'Original named source file retained')
  const content=Buffer.from(actual.bytes_base64,'base64').toString('utf8')
  assert.equal(content,original.content)
  return {path:actual.path,codePoints:Array.from(actual.path).map(char=>char.codePointAt(0)),content}
 })
 const trailing=wire.files.find(file=>file.path==='source-reading/identity-422.md\u00a0')
 assert(trailing,'Original trailing NBSP source file retained')
 const trailingContent=Buffer.from(trailing.bytes_base64,'base64').toString('utf8')
 assert.equal(trailingContent.split('\n')[0],'# IDENTITY_LITERAL_NBSP_422')
 files.push({path:trailing.path,codePoints:Array.from(trailing.path).map(char=>char.codePointAt(0)),content:trailingContent})
 const result={at:new Date().toISOString(),project:material.project,protocol:wire.protocol,totalFiles:wire.files.length,files,boundary:'Actual production Git source snapshot and public canonical codec; original filename/content facts, no source checksum gate or file deletion'}
 fs.writeFileSync(path.join(import.meta.dir,'source-material-result.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2))
}finally{await removeIsolatedTestRuntime(runtime)}
