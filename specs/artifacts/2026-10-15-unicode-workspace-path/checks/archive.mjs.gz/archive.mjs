import fs from 'node:fs'
import path from 'node:path'
import zlib from 'node:zlib'
const root=import.meta.dirname,dest=path.resolve('specs/artifacts/2026-10-15-unicode-workspace-path')
const save=(name,bytes)=>{const target=path.join(dest,name);fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,zlib.gzipSync(bytes))}
const checks=['contracts-before.log','contracts-after.log','sdk-build.log','project-path.ts.before','source-material.ts','source-material.log','archive.mjs']
for(const name of checks)save('checks/'+name+'.gz',fs.readFileSync(path.join(root,name)))
save('facts/source-material-result.json.gz',fs.readFileSync(path.join(root,'source-material-result.json')))
console.log(JSON.stringify({archived:checks.length+1,sourceFacts:'facts/source-material-result.json.gz'}))
