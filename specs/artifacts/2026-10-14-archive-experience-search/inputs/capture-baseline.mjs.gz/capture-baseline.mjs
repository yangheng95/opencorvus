import fs from 'node:fs'
import path from 'node:path'
import {execFileSync} from 'node:child_process'
const root='.tmp-codex-archive-experience-01a133',head=execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim()
for(const file of ['packages/opencorvus/src/work-ledger/projection.ts','packages/opencorvus/test/work-ledger-search.test.ts']){
 const target=root+'/'+path.basename(file)+'.before'
 if(file.endsWith('.test.ts'))fs.copyFileSync(target,root+'/work-ledger-search.test.ts.initial-capture')
 fs.writeFileSync(target,execFileSync('git',['show',head+':'+file]))
}
fs.writeFileSync(root+'/baseline-capture.json',JSON.stringify({head,reason:'Initial preparation captured the new test probe rather than the untouched original test. Corrected before product edits from immutable HEAD, which was clean at start; original capture kept. No runtime/test result changed.'},null,2)+'\n')
console.log('Restored original baseline captures from immutable pre-repair HEAD; preserved the initial probe capture.')
