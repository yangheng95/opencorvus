import fs from 'node:fs/promises'
import assert from 'node:assert/strict'
const root='.tmp-codex-archive-experience-01a133/before',ready=JSON.parse(await fs.readFile(root+'/ready.json','utf8')),base=`http://127.0.0.1:${ready.port}`,directory=ready.projects[0].directory,missionID='ee9dba6ebcfa4b8d',query='?'+new URLSearchParams({directory}),body={archived:true,surface:'root.owned_archive_experience',reason:'Root archived the owned unexecuted diagnostic draft'},receipts=[]
for(const [url,method,data]of [[`/mission/${missionID}/archive`+query,'PATCH',body],['/work-ledger/archive?limit=100','GET'],[`/mission/${missionID}`+query,'GET']]){
 const response=await fetch(base+url,{method,headers:data?{'Content-Type':'application/json'}:undefined,body:data?JSON.stringify(data):undefined}),value=await response.json()
 receipts.push({url,method,body:data,status:response.status,response:value})
}
await fs.writeFile(root+'/failed-input-replay.json',JSON.stringify({scope:'A new real replay of the original invalid checker surface; not a reconstructed original response.',receipts},null,2)+'\n')
assert.equal(receipts[0].status,400);assert.equal(receipts[1].status,200);assert.equal(receipts[2].status,200)
console.log(JSON.stringify({replayedError:receipts[0].response,partialArchive:receipts[1].response.rows.length,mission:receipts[2].response.missionID}))
