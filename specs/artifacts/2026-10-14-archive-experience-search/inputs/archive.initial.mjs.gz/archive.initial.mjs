import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import {gzipSync} from 'node:zlib'
import {execFileSync} from 'node:child_process'
const scratch='.tmp-codex-archive-experience-01a133',artifact='specs/artifacts/2026-10-14-archive-experience-search',files=[],runs=[]
const gz=(from,to)=>{const bytes=fs.readFileSync(from);fs.mkdirSync(path.dirname(to),{recursive:true});fs.writeFileSync(to,gzipSync(bytes));files.push({source:from,saved:to.slice(artifact.length+1),originalBytes:bytes.length})}
for(const stage of ['before','before02','after','after02']){
 const root=`${scratch}/${stage}`,out=`${artifact}/runs/${stage}`,read=name=>JSON.parse(fs.readFileSync(root+'/'+name,'utf8')),ready=read('ready.json'),owner=read('owner.json'),cleanup=read('physical-pair-cleanup.json'),terminal=read('terminal.json')
 assert.equal(ready.pid,owner.pid);assert.equal(owner.pid,cleanup.pid);assert.equal(cleanup.actualExit,0);assert.equal(cleanup.listeners,0)
 assert.deepEqual(cleanup.pair.map(p=>({name:p.name,removed:p.removed})),[{name:'auth.json',removed:true},{name:'models.json',removed:true}])
 assert.equal(terminal.normalRuntimeSettlement,true);assert.equal(terminal.requests,0);assert.equal(terminal.realSolCalls,0)
 for(const name of fs.readdirSync(root))if(name.endsWith('.json')&&name!=='privacy-ready.json')gz(root+'/'+name,out+'/'+name+'.gz')
 for(const name of fs.readdirSync(root+'/redacted-logs'))gz(root+'/redacted-logs/'+name,out+'/logs/'+name+'.gz')
 runs.push({stage,pid:ready.pid,occurrence:ready.occurrence,port:ready.port,participantPort:ready.participantPort,uiDirectory:ready.uiDirectory,physicalExit:cleanup.actualExit,inferenceRequests:terminal.requests,privacy:read('privacy-qualified.json').files})
}
const passed=['before-parent','privacy-before','before02-parent','privacy-before02','data-before02','data-before02-readback','corrected-input-probe','after-parent','privacy-after','data-after','business-after','business-final','focused-typecheck','overlay-typecheck','ui-build','restored-work','restored-both','restored-work-final','restored-both-final','restored-after-open','restored-ui-final','after02-parent','privacy-after02','data-after02','docs-current','architecture-current']
const failed=['data-before','capture-failed-input','business-before','focused-typecheck-first']
for(const [names,expected]of [[passed,'0'],[failed,'1']])for(const name of names){assert.equal(fs.readFileSync(`${scratch}/${name}.exit`,'utf8').trim(),expected,name+' original actual exit');for(const ext of ['log','exit'])gz(`${scratch}/${name}.${ext}`,`${artifact}/checks/${name}.${ext}.gz`)}
for(const name of ['setup.mjs','capture-baseline.mjs','baseline-capture.json','runtime.ts','launch.ps1','privacy.ts','run.mjs','data.mjs','data.initial.mjs','capture-failed-input.mjs','capture-failed-input.initial.mjs','restored.mjs','restored.initial.mjs','typecheck.json','projection.ts.before','work-ledger-search.test.ts.before','work-ledger-search.test.ts.initial-capture','CommandPalette.before.tsx','archive.mjs'])gz(`${scratch}/${name}`,`${artifact}/inputs/${name}.gz`)
const rawGroups=[['before02','data-create-receipts.json'],['before02','data-readback-receipts.json'],['before02','corrected-input-probe.json'],['after','data-create-receipts.json'],['after','restored-work-receipts.json'],['after','restored-both-receipts.json'],['after02','data-create-receipts.json'],['after02','restored-work-receipts.json'],['after02','restored-both-receipts.json']].map(([stage,name])=>({stage,name,count:JSON.parse(fs.readFileSync(`${scratch}/${stage}/${name}`,'utf8')).receipts.length}))
const retained=rawGroups.reduce((n,r)=>n+r.count,0)
fs.writeFileSync(artifact+'/manifest.json',JSON.stringify({capturedAt:new Date().toISOString(),purpose:'Lossless captured evidence and exact resource identity; not a mutable-source checksum or functional hash gate.',runs,retainedHTTPReceipts:retained,rawGroups,limits:['Repeated after02 both reads retain individual command exits/logs; their shared JSON path contains only the final six response bodies.','The first failed preparation/capture scripts did not persist all earlier bodies; none are reconstructed.'],files},null,2)+'\n')
fs.writeFileSync(artifact+'/README.md',`# 第23批：Work体验搜索与归档恢复

对应[Recall、完整实施前分析、失败和最终资格](../../records/2026-10/2026-10-14-archive-experience-search.md)。Root独立实施并亲看22个未编辑原PNG；没有UI自动化、真实凭据或模型请求。

- [screenshots](screenshots/README.md)：01–03修前六项/Work0/Mission2；04–09只改后台时Archive与真实恢复；10/11旧前端活动查询二次过滤的失败，不能冒充通过；12–16最终新UI六项、Work2→1、Mission2→1中文；17真实活动Work匹配和Ctrl+1；18实际打开原Work；19原Mission带hover tooltip、20移开悬浮后完整原请求；21/22最终英文Archive和活动Work查询。22中原本地命令同时存在，18/20保留原体验、身份和草稿内容。
- [runs](runs/README.md)：before失败准备PID35112；before02正确基线PID73816；after后台修复/旧UI诊断PID89284；after02最终新UI PID51424。端口分别18662/63与18664/65。各成功6项由公开API创建/命名/归档，Mission始终真实draft，未派发。最终3次Work读取与最新6次完整读取证明原active/archive身份、experience、Mission原request/backlog/零Task统计；打开和切语言后再读回0。保留可逐条对照的HTTP回执${retained}条，其中一个是正向的预期400输入错误合同；重复both读取仅最后6个body保留，不累计成更多独立原body。UI请求与首次失败请求另计。
- [checks](checks/README.md)：原红4通过/1失败，最终5通过/24断言；扩展core+test类型、overlay类型、Node build54.82s、docs345/26、架构19与所有正式读取/收尾/隐私0。首类型1和准备/诊断1保留。原400来自工具的非法surface值；另一次工具猜测不存在的单条GET而遇文本404/Node25断言，无法保存的原body保持未知。修后原准备和独立输入错误probe均真实重跑0。
- [inputs](inputs/README.md)：修前源、初次误捕probe与正确不可变baseline，唯一正式数据/readback checker与独立服务生命周期。后台仅一条experience条件；前端接受服务器顶层结果并保留原Mission展开相关性，本地动作沿原text filter；无新查询、缓存、写入协议或迁移。
- [previous-delivery](previous-delivery/README.md)：B22产品9fc9fb7bb及文档0ee22c4d6正常提交/精确结算，Root normal push0、全部原hook与fresh upstream确认；原失败保持。

所有自有tab25/26/27均关闭。四轮正常settlement/父exit0、双端口0后精确删除各自假auth/models整对；后台完整日志56049/109854/144875/198163字节，stdout/stderr各0，隐私checker全0。四轮participant inferenceRequests与realSolCalls均0，UI/API请求另计。只资格真实桌面中英Work/Mission查询/恢复/重新打开及当前Ctrl+1；未独立操作Mission子Task执行、真实模型、调度或永久删除。详见[原捕获清单](manifest.json)。范围提交与正常push按后续实际回执结算。
`)
for(const [name,title,description]of [['screenshots','原始桌面证据','22张Root逐一查看的原PNG，10/11为真实缺口，12之后为最终新UI。'],['runs','真实API与进程生命周期','四个独立occurrence；失败准备与诊断不冒充完整通过，凭据内容未归档。'],['checks','原检查输出与退出','失败和通过均保留，源码/类型/分数不替代视觉。'],['inputs','原输入、实现前快照和工具','正式API checker与自己服务生命周期，没有UI自动化测试。']]){fs.mkdirSync(`${artifact}/${name}`,{recursive:true});fs.writeFileSync(`${artifact}/${name}/README.md`,`# ${title}\n\n${description} 见[主说明](../README.md)。\n`)}
const arch='specs/current/architecture/07-panel.md',beforeText='and technical kinds. The shared active/archive projection treats percent,\nunderscore and backslash literally using one escaped SQL LIKE parameter;\narchive visibility and directory boundaries remain unchanged.\n',afterText=`and technical kinds, including each conversation's canonical Chat/Work experience.
The shared active/archive projection treats percent,
underscore and backslash literally using one escaped SQL LIKE parameter;
archive visibility and directory boundaries remain unchanged.

Top-level selectable item membership comes from the Work Ledger response.
The palette keeps its existing parent/child relevance selection when expanding
a Mission's complete Task collection. Accepted ledger items proceed directly
to the visible command list; local action commands retain their text filter.
Conversation experience is read from the same canonical metadata used to
classify that conversation and to produce its public row.
`
if(!fs.readFileSync(arch,'utf8').replaceAll('\r\n','\n').includes(afterText))throw Error('Own current architecture patch unavailable')
const shared=[{file:arch,beforeText,afterText},{file:'CHANGELOG.md',zh:'- 工作记录和归档搜索支持真实的 Work 会话类型，改名后的会话仍可按类型查找；命令面板使用服务器接受的工作项，保留 Mission 子项和本地命令的原筛选规则。',en:'- Work Ledger and Archive searches match the canonical Work conversation experience after renaming. The command palette uses accepted server items while retaining its Mission descendant and local action filters.'}]
fs.writeFileSync(scratch+'/shared-final.json',JSON.stringify(shared,null,2)+'\n')
fs.writeFileSync(scratch+'/status-before-commit.txt',execFileSync('git',['status','--short']))
console.log(JSON.stringify({artifact,capturedFiles:files.length,retainedHTTPReceipts:retained,runs:runs.map(r=>({stage:r.stage,pid:r.pid,exit:r.physicalExit})),shared:shared.map(x=>x.file)}))
