import fs from 'node:fs'
const prior='.tmp-codex-automation-timestamp-locale-01a133',root='.tmp-codex-archive-experience-01a133'
let stage=fs.readFileSync(prior+'/stage-final.mjs','utf8').replaceAll(prior,root).replaceAll('2026-10-14-automation-timestamp-locale','2026-10-14-archive-experience-search')
stage=stage.replace("const sources=['packages/overlay/src/components/settings/ScheduledAutomationsPanel.tsx','packages/overlay/src/services/automation-recurrence.ts','packages/overlay/test/scheduled-automations.test.ts']","const sources=['packages/opencorvus/src/work-ledger/projection.ts','packages/opencorvus/test/work-ledger-search.test.ts','packages/overlay/src/components/CommandPalette.tsx']")
if(stage.includes('ScheduledAutomationsPanel')||stage.includes('automation-recurrence'))throw Error('Foreign product scope')
fs.writeFileSync(root+'/stage-final.mjs',stage)
let commit=fs.readFileSync(prior+'/commit-final.mjs','utf8').replaceAll(prior,root).replace('fix(overlay): localize scheduled dates and recurrence descriptions','fix(work-ledger): preserve conversation experience search through the palette')
fs.writeFileSync(root+'/commit-final.mjs',commit)
console.log('Prepared exact three-source private index and normal commit with own shared patches only.')
