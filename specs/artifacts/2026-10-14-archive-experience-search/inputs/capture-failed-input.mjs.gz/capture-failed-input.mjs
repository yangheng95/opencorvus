import fs from 'node:fs/promises'
import assert from 'node:assert/strict'
async function main(){
const root='.tmp-codex-archive-experience-01a133/before02',ready=JSON.parse(await fs.readFile(root+'/ready.json','utf8')),inputs=JSON.parse(await fs.readFile(root+'/inputs.json','utf8')),mission=inputs.find(i=>i.kind==='mission'&&i.project==='A'),base=`http://127.0.0.1:${ready.port}`,query='?'+new URLSearchParams({directory:mission.directory}),body={archived:true,surface:'root.owned_archive_experience',reason:'Root archived the owned unexecuted diagnostic draft'},receipts=[]
for(const [url,method,data,expected]of [[`/mission/${mission.id}/archive`+query,'PATCH',body,400],['/work-ledger/archive?limit=100','GET',undefined,200],['/mission?'+new URLSearchParams({directory:mission.directory,archived:'true'}),'GET',undefined,200]]){
 const response=await fetch(base+url,{method,headers:data?{'Content-Type':'application/json'}:undefined,body:data?JSON.stringify(data):undefined}),raw=await response.text()
 const receipt={url,method,body:data,status:response.status,raw};receipts.push(receipt)
 await fs.writeFile(root+'/corrected-input-probe.json',JSON.stringify({scope:'A new real input-error probe in the corrected fresh occurrence; not reconstructed original responses.',receipts},null,2)+'\n')
 assert.equal(response.status,expected);receipt.response=JSON.parse(raw)
}
assert.equal(receipts[1].response.rows.length,6);assert.deepEqual(receipts[2].response.map(m=>m.missionID),[mission.id])
console.log(JSON.stringify({inputError:receipts[0].response,actualHTTP:receipts.length,archive:receipts[1].response.rows.length,mission:mission.id}))
}
await main().catch(error=>{console.error(error);process.exitCode=1})
