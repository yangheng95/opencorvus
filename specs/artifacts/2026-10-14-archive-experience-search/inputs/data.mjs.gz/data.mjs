import fs from 'node:fs/promises'
import path from 'node:path'
import assert from 'node:assert/strict'
async function main(){
const [stage,mode='create']=process.argv.slice(2),root=path.resolve('.tmp-codex-archive-experience-01a133',stage),ready=JSON.parse(await fs.readFile(root+'/ready.json','utf8')),base=`http://127.0.0.1:${ready.port}`,receipts=[]
async function call(url,method='GET',body,expected=200){const response=await fetch(base+url,{method,headers:body?{'Content-Type':'application/json'}:undefined,body:body?JSON.stringify(body):undefined});const raw=await response.text();receipts.push({url,method,body,status:response.status,raw});await fs.writeFile(root+`/data-${mode}-progress.json`,JSON.stringify({receipts},null,2)+'\n');assert.equal(response.status,expected,`${method} ${url}`);const value=JSON.parse(raw);receipts.at(-1).response=value;return value}
let items=[]
if(mode==='create'){
 for(const project of ready.projects){
  const q='?'+new URLSearchParams({directory:project.directory})
  for(const [i,experience]of ['work','chat'].entries()){
   const {session}=await call(`/coding/${experience}/session`+q,'POST',{},201),title=`恢复入口 ${project.label}-${i+1}`
   await call(`/coding/${experience}/session/${session.id}`+q,'PATCH',{title})
   const {session:archived}=await call(`/coding/${experience}/session/${session.id}/archive`+q,'PATCH',{archived:true})
   assert.equal(archived.title,title);assert.equal(archived.metadata.conversation.experience,experience)
   items.push({kind:'chat',experience,project:project.label,directory:project.directory,id:session.id,sessionID:session.id,title,archivedAt:archived.time.archived})
  }
  const title=`恢复入口 ${project.label}-3`,request=`仅验证${project.label}项目草稿的归档、恢复和重新打开。保留此真实原请求，不派发执行。`
  const mission=await call('/mission/draft'+q,'POST',{title,request,productPillar:'work',expertSquadIDs:['base']})
  assert.equal(mission.title,title);assert.equal(mission.pendingPrompt.text,request)
  const archived=await call(`/mission/${mission.missionID}/archive`+q,'PATCH',{archived:true,surface:'api',reason:'Root archived the owned unexecuted diagnostic draft'})
  assert.equal(typeof archived.archived,'number');assert.equal(archived.pendingPrompt.text,request)
  items.push({kind:'mission',project:project.label,directory:project.directory,id:mission.missionID,sessionID:mission.sessionID,title,request,archivedAt:archived.archived})
 }
 await fs.writeFile(root+'/inputs.json',JSON.stringify(items,null,2)+'\n')
}else items=JSON.parse(await fs.readFile(root+'/inputs.json','utf8'))
const all=await call('/work-ledger/archive?limit=100'),work=await call('/work-ledger/archive?'+new URLSearchParams({search:'Work',limit:'100'})),mission=await call('/work-ledger/archive?'+new URLSearchParams({search:'mission',limit:'100'}))
assert.deepEqual(all.rows.map(r=>r.id).sort(),items.map(r=>r.id).sort())
assert.deepEqual(mission.rows.map(r=>r.id).sort(),items.filter(r=>r.kind==='mission').map(r=>r.id).sort())
if(stage.startsWith('after'))assert.deepEqual(work.rows.map(r=>({id:r.id,experience:r.experience})).sort((a,b)=>a.id.localeCompare(b.id)),items.filter(r=>r.experience==='work').map(r=>({id:r.id,experience:r.experience})).sort((a,b)=>a.id.localeCompare(b.id)))
await fs.writeFile(root+`/data-${mode}-receipts.json`,JSON.stringify({receipts,all:all.rows.map(r=>({id:r.id,kind:r.kind,experience:r.experience,title:r.title,directory:r.directory})),work:work.rows.map(r=>r.id),mission:mission.rows.map(r=>r.id)},null,2)+'\n')
console.log(JSON.stringify({stage,mode,actualHTTP:receipts.length,all:all.rows.length,work:work.rows.length,mission:mission.rows.length}))
}
await main().catch(error=>{console.error(error);process.exitCode=1})
