import fs from 'node:fs/promises'
import assert from 'node:assert/strict'
async function main(){
 const mode=process.argv[2],root='.tmp-codex-archive-experience-01a133/after',ready=JSON.parse(await fs.readFile(root+'/ready.json','utf8')),inputs=JSON.parse(await fs.readFile(root+'/inputs.json','utf8')),original=JSON.parse(await fs.readFile(root+'/data-create-receipts.json','utf8')),receipts=[]
 async function get(url){const response=await fetch(`http://127.0.0.1:${ready.port}`+url),raw=await response.text();receipts.push({url,status:response.status,raw});await fs.writeFile(root+`/restored-${mode}-progress.json`,JSON.stringify({receipts},null,2)+'\n');assert.equal(response.status,200);const value=JSON.parse(raw);receipts.at(-1).response=value;return value}
 const left=inputs.find(i=>i.experience==='work'&&i.project==='A'),right=inputs.find(i=>i.experience==='work'&&i.project==='B')
 const archived=await get('/work-ledger/archive?search=Work'),active=await get('/work-ledger?search=Work')
 const identity=r=>({id:r.id,sessionID:r.sessionID,title:r.title,experience:r.experience,directory:r.directory})
 assert.deepEqual(archived.rows.map(identity),[identity(right)]);assert.deepEqual(active.rows.map(identity),[identity(left)])
 const {session}=await get(`/coding/work/session/${left.id}?`+new URLSearchParams({directory:left.directory}))
 assert.equal(session.id,left.id);assert.equal(session.metadata.conversation.experience,'work');assert.equal(session.time.archived??null,null)
 let mission
 if(mode==='both'){
  const kept=inputs.find(i=>i.kind==='mission'&&i.project==='A'),restored=inputs.find(i=>i.kind==='mission'&&i.project==='B')
  const archivedM=await get('/work-ledger/archive?search=mission'),activeM=await get('/work-ledger?search=mission')
  assert.deepEqual(archivedM.rows.map(r=>r.id),[kept.id]);assert.deepEqual(activeM.rows.map(r=>r.id),[restored.id])
  const list=await get('/mission?'+new URLSearchParams({directory:restored.directory,archived:'false'}))
  assert.deepEqual(list.map(m=>m.missionID),[restored.id]);mission=list[0]
  const initial=original.receipts.find(r=>r.method==='POST'&&r.url.startsWith('/mission/draft?')&&r.body.title===restored.title).response
  assert.equal(mission.title,restored.title);assert.equal(mission.pendingPrompt.text,restored.request);assert.equal(mission.boardLane,initial.boardLane);assert.equal(mission.archived??null,null)
  assert.deepEqual(mission.taskStats,initial.taskStats)
 }
 await fs.writeFile(root+`/restored-${mode}-receipts.json`,JSON.stringify({receipts,work:{active:left.id,archived:right.id},mission:mission?{id:mission.missionID,title:mission.title,boardLane:mission.boardLane,request:mission.pendingPrompt.text}:null},null,2)+'\n')
 console.log(JSON.stringify({mode,actualHTTP:receipts.length,work:{active:left.id,archived:right.id},mission:mission?{id:mission.missionID,boardLane:mission.boardLane}:null}))
}
await main().catch(error=>{console.error(error);process.exitCode=1})
