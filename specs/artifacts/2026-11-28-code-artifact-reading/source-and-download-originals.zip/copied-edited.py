# 交接临时备注：仅当前视图
"""UTF-8 CSV 销售汇总，仅使用标准库。"""

import argparse
import csv
import json
import sys
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP, localcontext
from pathlib import Path


class SalesDataError(ValueError):
    """输入不符合销售 CSV 契约。"""


def summarize(path):
    """统计每条数据记录；错误时抛出 SalesDataError，不返回部分结果。"""
    records = []
    try:
        with open(path, encoding="utf-8-sig", newline="") as source:
            reader = csv.DictReader(source, strict=True)
            headers = reader.fieldnames
            required = {"订单编号", "区域", "金额", "备注"}
            if headers is None or set(headers) != required or len(headers) != 4:
                raise SalesDataError("表头必须包含且仅包含：订单编号、区域、金额、备注")
            for row in reader:
                if None in row or any(value is None for value in row.values()):
                    raise SalesDataError(f"第 {reader.line_num} 行：列数与表头不一致")
                raw = row["金额"]
                try:
                    amount = Decimal(raw)
                except InvalidOperation:
                    raise SalesDataError(
                        f"第 {reader.line_num} 行：无效金额 {raw!r}"
                    ) from None
                if not amount.is_finite():
                    raise SalesDataError(
                        f"第 {reader.line_num} 行：无效金额 {raw!r}（必须为有限数）"
                    )
                records.append((row["区域"], amount))
    except (csv.Error, UnicodeError) as exc:
        raise SalesDataError(f"CSV 格式或 UTF-8 编码错误：{exc}") from exc

    # 精度覆盖所有输入位数及累加进位，避免默认 28 位上下文截断。
    fractional = max([2] + [-a.as_tuple().exponent for _, a in records])
    integer = max([1] + [a.adjusted() + 1 for _, a in records])
    with localcontext() as context:
        context.prec = integer + fractional + len(str(len(records))) + 3
        total = Decimal(0)
        regions = {}
        for region, amount in records:
            total += amount
            entry = regions.setdefault(
                region, {"order_count": 0, "total_amount": Decimal(0)}
            )
            entry["order_count"] += 1
            entry["total_amount"] += amount

        def money(value):
            rounded = value.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
            return format(abs(rounded) if rounded == 0 else rounded, ".2f")

        return {
            "order_count": len(records),
            "total_amount": money(total),
            "by_region": {
                region: {
                    "order_count": item["order_count"],
                    "total_amount": money(item["total_amount"]),
                }
                for region, item in regions.items()
            },
        }


def markdown_report(summary):
    def cell(value):
        return (
            value.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\\", "&#92;")
            .replace("|", "&#124;")
            .replace("\r", "&#13;")
            .replace("\n", "<br>")
        )

    lines = [
        "# 销售报告",
        "",
        "## 统计口径",
        "",
        "- 每条 CSV 数据记录计为一笔订单，不按订单编号去重；退款及零金额订单均计入订单数。",
        "- 负金额为退款，直接抵减净金额；零金额不改变净金额。",
        "- 金额使用 Decimal 精确累加，不逐笔舍入；总计和各区域分别在输出时按 ROUND_HALF_UP 四舍五入至两位小数。分区显示值相加可能因舍入与总计相差一分。",
        "- 按原区域名分组，不去空格、不规范化；JSON 金额为两位小数字符串。",
        "- 输入使用 UTF-8（兼容 BOM），按标准 CSV 引号、逗号和换行转义读取；不修改原 CSV。",
        "- 可选参数 --regions-csv 区域汇总.csv 导出 UTF-8 区域 CSV，表头为 区域,订单数,净金额；每个原区域一行，按输出的两位小数净金额数值降序，同额按原区域名升序，使用标准 CSV 转义。省略该参数仍按原命令生成 JSON 和报告。",
        "- 无效、空白或非有限金额（NaN、Infinity 等）使整个统计失败：接口抛出 SalesDataError；命令行向标准错误输出“错误：”及行号，以状态码 2 退出，不写入统计输出。",
        "",
        "## 汇总",
        "",
        "| 范围 | 订单数 | 净金额（元） |",
        "| --- | ---: | ---: |",
        f"| 全部 | {summary['order_count']} | {summary['total_amount']} |",
        "",
        "## 各区域汇总",
        "",
        "| 区域 | 订单数 | 净金额（元） |",
        "| --- | ---: | ---: |",
    ]
    for region, item in summary["by_region"].items():
        lines.append(
            f"| {cell(region)} | {item['order_count']} | {item['total_amount']} |"
        )
    return "\n".join(lines) + "\n"


def write_regions_csv(path, summary):
    """以报告的两位小数净金额排序，不改变原汇总及区域键。"""
    rows = sorted(summary["by_region"].items())
    # 分两次稳定排序，避免取负操作受到 Decimal 默认上下文精度影响。
    rows.sort(key=lambda row: Decimal(row[1]["total_amount"]), reverse=True)
    with open(path, "w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["区域", "订单数", "净金额"])
        for region, item in rows:
            writer.writerow([region, item["order_count"], item["total_amount"]])


def main(argv=None):
    parser = argparse.ArgumentParser(description="统计中文 CSV 销售订单和净金额")
    parser.add_argument("input", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--regions-csv", type=Path, help="可选的 UTF-8 区域汇总 CSV")
    args = parser.parse_args(argv)
    try:
        paths = [p.resolve() for p in (args.input, args.output, args.report)]
        if len(set(paths)) != 3:
            raise SalesDataError("输入、JSON 输出和报告必须使用不同路径")
        targets = [args.output, args.report]
        if args.regions_csv is not None:
            targets.append(args.regions_csv)
            if args.regions_csv.resolve() in paths:
                raise SalesDataError("区域 CSV 必须与输入、JSON 输出和报告使用不同路径")
        for target in targets:
            if target.exists() and args.input.samefile(target):
                raise SalesDataError("输出不得覆盖输入 CSV")
        if args.regions_csv is not None and args.regions_csv.exists():
            for target in (args.output, args.report):
                if target.exists() and args.regions_csv.samefile(target):
                    raise SalesDataError("区域 CSV 不得覆盖 JSON 输出或报告")
        summary = summarize(args.input)
        args.output.write_text(
            json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )
        args.report.write_text(markdown_report(summary), encoding="utf-8")
        if args.regions_csv is not None:
            write_regions_csv(args.regions_csv, summary)
    except (SalesDataError, OSError) as exc:
        print(f"错误：{exc}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
