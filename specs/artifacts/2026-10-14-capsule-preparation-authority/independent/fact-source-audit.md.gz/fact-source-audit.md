# Capsule Phase B：描述文件、准备 owner 与持久事实来源审计

审计者：`/root/functional_audit`；日期：2026-10-13 至 2026-10-14；仓库：`D:/myhexin-local/opencorvus`。

## Recall 与证据边界

用户要求持续自主迭代，先完成根因和共享影响分析，再落规格、实施、真实验收、精确提交和正常推送。本次是主 agent 授权的一层只读事实来源专项；内部实施顺序由主 agent 收敛，不是需要用户重新授权普通调查。唯一写入是本 scratch 报告。没有产品、测试、spec、共享索引或 Git 提交修改，没有再次委托，没有运行服务、模型、WSL、Docker、UI 自动化或操作用户进程，没有读取实际环境值、描述文件实例或凭据。

已重读 `specs/records/2026-10/2026-10-13-process-settlement-barrier.md` 的 Recall、实施和最终实际证据，以及前份 `capsule-phase-b-design.txt`。Phase A 的 Windows Native 完整结算已由 root 记录真实结果；它不证明 Linux Capsule 准备 owner、文件清理或恢复已经闭合。

检索覆盖当前 production 源码、测试/fixture、构建和部署脚本、`.github`、所有 tracked Markdown 文档及当前架构，并补查 tracked MDX、reStructuredText 和 AsciiDoc 的 Capsule/descriptor 公开说明。使用定义/调用搜索交叉核对，而不是从函数名称推断其已被生产调用。当前工作区存在其它 owner 的修改，均保留。

历史检索资格：文件历史可确认 runtime.ts 的 `65d0bfc98`、`354a7305f`，OCI 文件当前本地历史入口是 `65d0bfc98`，部署 bootstrap 是 `9a482447a`，process-liveness 最近历史有 `cca50888d`、`58c200e81`、`15b51a394`。一次跨所有 refs 的广历史搜索长时间无结果并报告 Git 自动 packing，已中断该本次读取命令（exit 1）；之后使用 `GIT_NO_LAZY_FETCH=1` 和 `gc.auto=0` 做精确读取。部分旧提交的技能文档 blob 本地不可读，旧 bootstrap 月索引所链接的记录在当前树及所查原提交路径均不存在；没有重建该记录，也不声称已穷尽缺失历史。当前 tracked 内容的搜索不受此限制。

## 1. 结论：有唯一 reader 和合法外部输入，未找到仓库生产 provisioner

现有唯一公开运行时描述 schema 是 `packages/opencorvus/src/execution-capsule/runtime.ts:14–45`。唯一读取函数 `loadDescriptor():89–117` 从 `OPENCORVUS_EXECUTION_CAPSULE_DESCRIPTOR` 指定的位置读取 JSON，严格解析，并校验指定工具及 toolchain 的实际内容身份。它不创建该文件。

不能把“未找到 repository producer”写成“现实 Capsule 部署不存在”。代码明确接纳外部部署输入：

| 事实 | 生产定义/调用 | 能证明什么 |
| --- | --- | --- |
| 外部环境优先于 embedded environment | `runtime/shims.ts:24–40` | 部署方可以在启动前提供 mode 和 descriptor path；没有读取本机实际值 |
| 默认部署选择 | `runtime/task-process-deployment.ts:1–5`，由 `runtime/shims.ts:40` 调用 | 仅 mode 未设置时声明 `native`，保留外部已声明 `capsule` |
| mode 严格读取 | `engine/task-execution-capsule-binding.ts:37–42` | 仅接受 `native` / `capsule`；不是提供描述文件的 writer |
| 泛用 embedded environment 构建入口 | `script/build.ts:65–76,101–104` | 可按声明的 key 嵌入环境字符串；没有 Capsule 专属 descriptor 生成逻辑 |
| runtime descriptor 文件输入 | `execution-capsule/runtime.ts:89–117` | 接纳部署方准备的严格文件，加载时产生该文件的内容身份 |

当前 tracked 全仓搜索这三个精确标识：`OPENCORVUS_EXECUTION_CAPSULE_DESCRIPTOR`、`opencorvus.task-execution-capsule.runtime.v1`、`package_tool_inactivity_ms`，生产命中只落在 runtime reader/投影及 binding 条件中。没有发现写入当前 protocol JSON 的生产函数、HTTP 配置路由、CLI 子命令、安装/provision 脚本或 GitHub workflow。schema 的完整对象构造只有 `test/execution-capsule-runtime-descriptor.test.ts` 的正向 schema fixture；它不是部署 writer。

公开文档搜索：当前架构 `04-extensions.md:71–104` 说明 Host/Task facade 和 Capsule 的底层 adapter 边界，`:646–650` 说明删除 LSP（Language Server Protocol，语言服务器协议）后的严格配置；`task-control-plane.md:504` 说明唯一物理 process receipt；`server-runtime-readiness.md` 当前说明完整 Handle barrier 与 Capsule 的未覆盖边界。所有 tracked Markdown 对 descriptor 环境名/protocol/controller 字段、runtime descriptor/provisioner 的搜索没有找到“由哪个当前生产组件生成完整文件”的公开部署合同。`.github`、root script、Dockerfile、build 脚本亦未发现专属 writer。月索引的 bootstrap repair 条目只表达默认 native、保留严格 Capsule 权限，不能代替缺失正文或生产 provisioner。

因此可交付事实是：**外部 descriptor 是合法配置输入；当前仓库没有已定位的专属生产 provisioner；实际外部维护者、原部署文件和生成程序均未知，未读取。** 若需要产品提供生成/校验工具，这是明确的新能力，不能把测试中拼一个对象称为既有生产 writer。

历史可读证据：`65d0bfc98` 中已经是外部 path reader、同 protocol 和 package-tool inactivity 字段；`354a7305f` 仅删除空 LSP descriptor 字段及投影，没有加入 writer。`9a482447a` 在公共 shims 中加入默认 native 声明，注释明确保留外部/embedded Capsule 选择。没有证据表明这些变更曾提供或迁移外部 descriptor 文件。

## 2. 当前 schema、全部生产投影和期限配置

schema v1 包含：runtime/server-tree 身份、`package_tool_inactivity_ms`、controller `.service` 名称、outer source/visible roots、systemd-run/systemctl/runc/node/ripgrep 文件身份、toolchain tree、secret 名称集合（不是值）、空 child environment 名称集合、network none 和五项资源限制。顶层及嵌套结构严格校验。

`loadDescriptor` 的调用只有：

1. `activeExecutionCapsuleRuntimeFact():120–135`；它投影 descriptor 身份、runtime 身份、网络/资源、visible root、工具路径和 package-tool inactivity。
2. `wrapTaskCapsuleCommand():185–262`；Linux 平台判断后重读 descriptor、校验真实目录映射、形成 broker environment、调用唯一 `createOciTaskExec`。
3. `disposeTaskExecutionCapsule():265–287`；descriptor 配置存在时重新读取当前 descriptor，调用低层 container disposal。

`activeExecutionCapsuleRuntimeFact` 的生产调用方完整清单：

- `engine/task-execution-capsule-binding.ts:72,196`：创建 binding / 当前 admission 匹配。
- `browser/runtime/node-executor.ts:232`：Task Browser Node 工具路径。
- `execution-capsule/file-broker.ts:90`：Task 文件 worker 运行时。
- `expert-squad/package-tool-capsule.ts:477`：package-tool 运行时与 inactivity；实际消费 `packageToolInactivityMs` 在 `:490`。
- `file/ripgrep.ts:183`、`engine/codebase-tools.ts:200`、`tool/grep.ts:136`：Task ripgrep 路径。

没有当前准备/控制绝对期限配置：

| 当前值/能力 | 所在位置 | 边界 |
| --- | --- | --- |
| `package_tool_inactivity_ms` | runtime schema:20 → runtime fact:133 → package-tool-capsule:490 | package 工具 RPC（Remote Procedure Call，远程过程调用）无活动期限，不能借作 container startup |
| `15_000` | oci-task-container:613–644 | 初始化和多个控制命令之后的状态无变化期限，变化会重置；不是全准备绝对期限 |
| `TimeoutStopSec=10s` | oci-task-container:579 | Task systemd unit 停止策略，不是 broker CLI 或准备总期限 |
| shared `PROCESS_SETTLEMENT_TIMEOUT_MS` | util process / Supervisor | 有限收尾观测预算；到期给 uncertainty，不证明原资源完成 |
| `deadlineAt` / signal | 三个 Task spawn 输入 → Capsule wrapper:500–516 | 当前 wrap/create/ensure/control 没有对应参数；deadline 只留给 wrap 之后的物理 spawn |
| Config Provider/MCP/Bash 期限 | 独立子系统 | 未发现与 Capsule 准备的公开映射，不得复用为第二政策来源 |

低层唯一 `controlCommand():85–114` 使用原 child_process.spawn，监听 exit 收集 code/signal；没有 signal、absolute deadline、完整 output close 或原 Handle settlement 能力。所有生产调用都在同文件：诊断 show/status、cleanup stop/reset-failed、unit inspect、controller show、slice set-property、systemd-run、runc state、dispose stop。不存在另一个 production `runCLI` 可直接替换名字使用。

最低限度设计是沿当前单一 descriptor 配置面声明准备 owner 的明确期限，并将一次绝对 deadline 传到它的控制调用；不能每个 CLI 重置期限。数值、schema 变化和外部维护交付需在根规格中确定，不能凭空把当前 package-tool 或 cleanup 期限当既定配置。

## 3. descriptor 身份变化的完整消费者影响

真实创建链：`task-api/index.ts:1579–1584` 冻结 creation seed 中的 process mode；`:2010–2017` 调 `prepareTaskProcessBinding`；`engine/pipeline.ts:151` 在真实创建事务内调 `insertTaskProcessBinding`。Capsule binding schema 在 `engine/task-creation-facts.ts:31–59`，保存 Task/Project/package、整份 descriptor SHA-256、runtime identity、逻辑/物理根、初始树、网络/资源和创建时间。它没有 command ID、writer birth、consumer birth。

`task-execution-capsule-binding.ts:100–151` 将该 binding 作为唯一 `task_execution_capsule_binding` artifact 写入和严格单条读取。真正生产 admission 链为：三 Task spawn → `resolveTaskProcessExecution():248` → Capsule 分支 `activeTaskExecutionCapsule():214` → `assertCurrentRuntimeBinding():195`。这里比较整份 descriptorSHA256、runtime identity、network 和 resources。

- **新 Task**：新 JSON 可解析时冻结新的 descriptor 内容身份；若新增 required 字段而旧 JSON 未升级，创建/加载会直接失败。新 JSON 文件是同一配置面的新输入，不是写旧 Task binding 的授权。
- **已存在 Task 的下一次进程准入**：哪怕仅添加期限字段、工具路径/resources 都相同，整份 bytes 的 descriptorSHA256 也会变化，旧 binding 匹配失败。这是现有不可变身份合同，不应删除比较或重算旧事实来“通过”。
- **已打开的 Handle / 仍在执行的准备**：当前 wrapper 闭包保有其加载结果及物理参数，改文件不会自动让旧资源结算；原 owner 仍需按原结算收齐。
- **Task 取消/检查点/普通 runtime 收尾**：`TaskAPI:3203` 取消调用 `withTaskCancellationBarrier`；`engine/git.ts:491` checkpoint 调 `withTaskCheckpointLease`；`server/server.ts:363` runtime 收尾通过 mandatory gate。三者最终可调用 `disposeTaskExecutionCapsule`，该函数直接重读当前 descriptor，没有读取/核对原 Task binding。只变期限且 controller/root 不变时计算的 unit/path 仍相同；改变 controller/root/toolchain 不能据此宣称原物理资源被清理。缺失 descriptor 时该函数直接 return，也不是原 Capsule 成功清理证据。
- **重启**：`server/restart-handoff.ts:26–29,126–128` 复制现有环境并只移除 supervisor 专属 occurrence 字段，因此 descriptor path 可随环境继承；它没有生成、迁移或冻结一份 descriptor 内容。新 backend 的下一次 admission 仍读路径当时 bytes。当前没有发现启动时统一重验所有 Capsule bindings 的生产调用。
- **replay helper 的实际资格**：`assertTaskExecutionCapsuleRuntime` 和 `assertTaskExecutionCapsuleReplay` 当前全仓只有定义和二者内部互调，没有生产 caller。不能根据其名字声称所有 replay/restart 已覆盖。真正已覆盖的是上面的进程 admission。
- **Git/workspace 消费者**：`engine/git.ts:1233,1714`、activeTaskProcessBindingRoots、目录/文件/网络工具等读取原 binding 的空间或权限事实；这些读取不自动更新 descriptor，不能被当作新运行时准入证明。

这意味着期限 schema 调整需要明确部署切换时机：先收齐旧 owner，保留旧 Task 原事实；新部署/新 Task 绑定新 descriptor。无法安全继承的旧 Task 必须呈现现有明确身份错误，不能隐藏、fallback 或悄悄重绑定。还需在根设计中决定如何使终态清理使用其原物理 authority，不能由当前配置覆盖未收尾资源身份。

## 4. 持久事实确实已有的部分，与缺失的映射

| 已有事实 | 唯一 producer/reader | 实际包含与不包含 |
| --- | --- | --- |
| Task process binding | prepare/insert/readTaskProcessBinding；pipeline 创建事务 | Task/Project/包/运行时配置/空间 authority；没有每 command 的 writer/consumer |
| 当前 backend 物理身份 | `runtime/process-occurrence.ts` 的 currentRuntimeProcessOccurrence | 当前 PID、OS birth、occurrence UUID 的唯一来源 |
| 持久 runtime process receipt | `engine/process-liveness.ts:77–129` join；`:136–151` observe；表定义 `engine.sql.ts:309–349` | 在既有 engine_control_activation_lease 的 runtime_process target 中记录真实 PID/birth/occurrence；不拥有具体命令，不靠过期时间证明死亡 |
| delivery owner→runtime process | `dispatch-lineage-facts.ts:36–41`、`dispatch-lineage.ts:477–479` | worker dispatch 的真实 delivery owner，不是 OCI command writer |
| Project driver 物理登记/恢复消费 | `task-root-ingress-delivery.ts:1977` join；`:1658` observe | 真实 worker/delivery 恢复；只 dead_or_reused 可移交，不能由这个事实推测 OCI 文件 owner |
| Task container 空间命名 | `oci-task-container.ts:191–217` | controllerUnit+taskID 算同一物理 root/unit/container；不是 OS birth 或新 execution epoch |
| Container terminal evidence | `oci-task-container.ts:47–54,222–315` | container_id、unit_name、observation、原 unit properties/status；没有 Task execution epoch、command ID、writer receipt、consumer PID/birth 或 systemd InvocationID |
| Backend/Session interruption evidence | `engine/process-recovery-fact.ts:18–68` | managed backend occurrence 或明确未知，以及 Session/worker/lifecycle subject；没有 processFile |

`process-liveness` 真实 producer 只有 Project Task-control driver 和 Session deletion cleanup 的 join（当前搜索 `task-root-ingress-delivery.ts:1977`、`session/deletion-cleanup.ts:247`）。它适合作为将来所需 writer 的现有物理身份证据，不能未经调用就声称每次 Capsule prepare 已持有该 receipt 或 admission reference。

唯一 OCI command 文件 producer 在 `createOciTaskExec():660–694`：ensure 后生成 command UUID、`bundle/processes/<UUID>.json`、writeFile(wx)、返回 runc exec argv 与路径。JSON 是真实 OCI process spec（args/env/cwd 等），**不是生命周期 ledger**；本审计未读取任何实例内容。仅现有生产调用是 runtime.wrap:229。唯一 production cleanup 在 Supervisor:519–524 的 exited.finally 中 fire-and-forget unlink 并吞错误，原 base.settled 不等待它。没有找到把该 command UUID/processFile 与 writer runtime_process receipt、exec consumer birth、Task epoch 持久关联的写入或恢复 producer。

已有 terminal evidence 的恢复准确边界：ensure:524 与 dispose:705 重读同一 terminal-evidence；`replayTerminalEvidenceFailure` 重放原 properties/status，并再次尝试同名 unit stop/reset。它是按下一次 ensure/dispose 触发的原 container 诊断恢复，不是启动时遍历 command 文件的恢复，也没有把进程文件逐项加入 Task terminal。正常 dispose 最后只证明 unit ActiveState=inactive (:746–753)，没有发布 command cleanup receipt。

不能将 `runtime_process`、Task binding、terminal-evidence 三件已有对象拼称已存在端到端持久映射。也不因此立刻造第二 ledger：本轮先修活着的原 owner 的准备与文件收尾；crash 后 command ownership 仍未知时保留原文件/诊断，不扫 UUID 认领、不把 Task 完成或 backend 死亡单独当作 consumer 已结束。

## 5. 三 Task spawn 的现能力与原 Promise 缺口

共同 owner：`taskProcessReadLease():298–323` 取得 runtime mandatory read admission、注册 Task spawn Promise、取得 Task read lease。`awaitSpawnAdmission():269–281` 在 caller abort 后继续 await **同一个原 operation**，晚到 Handle 要严格 dispose；这只有在 operation 本身没有提前丢失内层准备时才成立。

| 入口 | 成功 | catch |
| --- | --- | --- |
| spawnTaskShell | :347–352 track 原 Handle，结算 registration；原 physical+settled 后释放 Task lease | :353–356 立即 finishRegistration + lease.dispose |
| spawnTaskShellGated | :400–406 track/admit 后相同收尾 | :407–410 立即释放 |
| spawnTaskCommand | :450–455 相同 | :456–459 立即释放 |

当前 `spawnTaskCapsuleCommand:503–507` 用 awaitWithAbort 等 wrap；caller abort 可先拒绝，而原 wrap 仍进行 ensure/文件创建。随后三 catch 已释放 owner。wrap 返回后 abort/defaultSpawn reject 也没有原文件清理 owner。成功返回又只传播 base.settled，unlink 在外面。这些是同一准备资源归属问题，不是单一工具故障。

`starts Map<taskID,Promise>` (:512–657) 已是同 Task prepare 的单一 in-process owner；第二 caller 等同一 operation。首 caller 的 abort 不能终止另一 caller 正常依赖的共享 ensure。`disposeOciTaskContainer:702–703` 已会 await starts pending，但调用它之前 cancellation barrier 会等 Task registrations；新增 deadline/取消要保这一真实序列，不能造 lock/队列或 metrics gate 绕行。

Host facade 的可复用能力和限制：`packages/util/src/process.ts:690–720` 保原 pending spawner；有限 caller 失败后尝试有限 join，`ProcessSettlementUncertainError:179` 只带 message/cause，没有把 original pending capability 返回给下层 owner。`:209–223` 的超时只结束等待，不结束物理资源。直接换成 Host.run 然后让三个 Task catch 释放，仍有同根缺口。

最小 live-owner 设计应保留：一个原 preparation operation/settlement capability 贯穿已有 starts 和 registration，caller 的有界结果只是一种投影；registration/Task lease 由原结算释放。真实 exclusive open 成功才取得该文件删除 authority；写/close/spawn/晚到/自然退出/dispose 的原错误与确切 cleanup 合并，physical unknown 保文件和 owner。无需新持久 ledger 才能修这些 live-owner 路径，也不得以新 ledger 掩盖当前 Promise 失联。

## 6. 聚焦正向验证与真实 Linux 资格

本次没有执行任何测试。可先运行的现有局部合同（待根规格/实施范围确定）：在 `packages/opencorvus` 使用正常 Bun 1.4.0 PATH，经官方 `bun script/run-tests.ts test/execution-capsule-runtime-descriptor.test.ts test/oci-task-container-diagnostics.test.ts`。前者只证明完整对象被严格 schema 接受，后者注入 control 响应证明原 terminal facts 在 cleanup 前取得；都不是真实 Capsule E2E（End-to-End，端到端验收）。相关 Task binding、Host facade、lease tests 应按最终接口影响精确选取，不全量跑。

所需新增/扩展正向契约：

1. 同 Task 两个 caller 同原 ensure 的完整事件序列：A abort 原错误，B 取得真实准备结果；共享 owner 原结算后回收 registration/lease。
2. 有限 caller uncertainty 与原 pending 最终完成的明确两个回执；Task terminal/checkpoint callback 在真实原准备/文件收齐之后，仍保其它 Project 正常输出。
3. 独占创建成功、实际写/close/准入失败、晚返回、真实 command 成功/非零退出、取消、cleanup 原错分别验证准确输出、资源身份与结算事件；EEXIST 映射确切错误，不能靠误删或“未调用”断言通过。
4. descriptor 新字段完整 schema、旧输入明确校验错误、新 Task binding、旧 Task 下一次准入的明确 mismatch，以及终态使用原物理 authority 的真实合同。不得重算旧 binding 期望来消除错误。

现有真实低层 OCI tests：`execution-capsule-oci.test.ts`、`execution-capsule-oci-controller-exit.test.ts`、`execution-capsule-systemd-lifecycle.test.ts`。原 UI 自动化分支已经在 Phase A 删除，本次精确这些路径未检出新的页面/DOM 自动测试，未运行它们。其资格限制必须保留：

- OCI probe 直接构造 `OciTaskContainerDescriptor`，直接 createOciTaskExec+Bun.spawn，绕开 production runtime schema、wrap、Supervisor Task registration/lease。
- `execution-capsule-oci.test.ts:9` controller 是 `.scope`，production runtime schema 要求 `.service`；不能称该 fixture 是完整部署 descriptor 的 producer。
- `fixture/linux-runtime.ts:28–38` 在测试模块 eligibility 求值时就可能启动 WSL/bash；导入不是无副作用只读操作。当前 checker 从 Windows 只转换 C: 路径，D: checkout 尚需成熟 wslpath 路径合同后重跑，skip 不算通过。
- fixture 末尾整 root 清理不能代替 production per-command cleanup 证据。

真实 Linux 验收需先证明当前授权的隔离环境有可执行的匹配工具和 frozen toolchain、可用 user systemd/session bus/runtime directory、符合 schema 的 controller `.service`、rootless runc 所需命名空间/挂载/cgroup 资源权限及正确 source↔visible root 映射。必须真实进入 runtime descriptor → public Task authority → wrap → create/ensure → Supervisor 原 Handle 的路径，并逐项收齐 command/file/controller/Task/parent 原回执。测试 controller 与文件只属于自有隔离输入，不接管用户 WSL/Docker 服务。

root 已有的 Ubuntu CLI `HCS_E_CONNECTION_TIMEOUT` 与后来 list 成功/Ubuntu Stopped、Docker engine linux/amd64，只是原观察，不能推导 Ubuntu 执行或 rootless runc 已合格；本次没重试、更没重启。Windows Native 结果不能替代 Linux。需要自然 Task/Mission/Session Tool 调用证明时，沿已授权 GPT-6.1 Sol 流式路径，分别验证凭据可用、目标模型目录投影、实际请求模型；只保存资格事实，不能复制/输出凭据或造 Task/模型消息。纯服务合同不冒称这一模型验收。

## 7. 根规格尚需确定的最小选择

1. **配置输入交付**：接受现有 external deployment-owned JSON 为唯一输入，并补其生成/校验/维护合同；或在仓库提供真正 production provisioner。当前未定位外部生成器，不应凭测试 fixture 声称已有。新增准备预算保持同 schema，一个 absolute deadline，明确旧 Task/binding 的切换边界。
2. **活跃原 owner 能力**：在现有 adapter/starts/Task registration 上传递原准备及原 control settlement capability。先确保三个 catch 不因有限 caller 结束释放仍活资源；不新建平行队列、缓存、观测 registry 或消息 gate。
3. **原物理 authority**：正在准备、已发布 command file 和终态 disposal 使用原 captured controller/root/consumer 事实，不能换为当前可变 descriptor；未知 physical 保留而非伪结算。
4. **恢复交付边界**：当前没有 command→writer/consumer 的持久映射，本轮不能宣称 crash recovery 完成。先交付完整 live-owner 修复；未来若扩展恢复，复用现有 Task fact owner 与 runtime_process 身份，不新建并行 ledger。须另行明确真正生产 writer/cut-point/recovery consumer 才能回收旧文件。
5. **Linux 实验资格**：取得真实可运行的自有环境后才开始 producer/终态验收；已有用户自动迭代授权不需要被内部分析阶段再次变成用户许可问题，但操作用户现用服务仍不在本只读授权中。

本报告未满足的项目是实际外部 provisioner 身份、Linux 环境资格、live-owner 修复及其真实验收、crash 后 per-command 安全恢复。以上均显式保留，未包装为已完成。
