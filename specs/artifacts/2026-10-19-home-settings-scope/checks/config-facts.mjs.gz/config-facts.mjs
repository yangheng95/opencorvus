import fs from 'node:fs'
const stage=process.argv[2],port=process.argv[3]
if(!stage||!/^186(27|29|31)$/.test(port))throw Error('Named stage and exact owned port required')
const file=import.meta.dirname+'/'+stage+'-config-facts.json'
if(fs.existsSync(file))throw Error('Fresh fact receipt required')
const response=await fetch(`http://127.0.0.1:${port}/global/config`,{signal:AbortSignal.timeout(30000)})
const body=await response.json()
const fact={stage,at:new Date().toISOString(),port,status:response.status,projection:{permission_mode:body.permission_mode,model:body.model,locale:body.locale},scope:'Original GET /global/config; only selected non-credential fields recorded'}
fs.writeFileSync(file,JSON.stringify(fact,null,2));console.log(JSON.stringify(fact))
