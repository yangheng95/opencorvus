import fs from 'node:fs'
import path from 'node:path'
import zlib from 'node:zlib'
const root=import.meta.dirname,artifact='specs/artifacts/2026-10-19-home-settings-scope',record='specs/records/2026-10/2026-10-19-home-settings-scope.md'
let spec=fs.readFileSync(record,'utf8')
spec=spec.replace('实际查看全部目标截图；没有UI自动化测试、新fixture或静态文案断言。','实际查看全部目标截图；未保留新增UI自动化测试或新UI fixture。后续导航测试尝试触及呈现调度，已经删除，失败日志保留；没有添加静态文案断言。')
spec=spec.replace('冷启动第一个未完成读取的短暂帧仍沿既有currentPermissionMode默认显示Full access','未完成读取或读取超时时，仍沿既有currentPermissionMode默认显示Full access')
spec+=`\n## 当前交付构建与四个scope的最终结算\n\n当前实际publication为final 18633，正式Node Vite 50.78秒、renderer checker和typecheck通过；非阻塞导航修改后重新跑原三个合同文件31项通过，另一次原project ownership文件9项重跑通过。未保留不适用的新增导航测试，也没有用Frame polyfill把它伪装成非UI验收。\n\n21为当前构建正常Task原45秒/正文/Ask。原服务PATCH /global/config于15:31:04.025开始，真实New Chat点击15:31:30.445—30.574返回（129ms），22截图实际主输入目标已为Chat并显示首页；当时原写仍未完成。该值是一次人工交互记录，没有自动化UI时间阈值或benchmark分数。配置未加载时仍显示既有Full access是已知未完成项，22不能作权限已加载证据。原写76,031ms后返回接受，恢复16,720ms后完成，生产CLI确认临时username字段与存在性完整恢复、Ask保持。新配置读取未把导航留在旧Task意图。\n\n写完成后再次New Chat重读，23为实际全局Ask；24为当前构建真实鼠标Git开关true，随后外部标签恢复false。25为实际切换中文后的全局General：Ask、Git false。此轮没有再保存代理/通道或更改安全权限。final自有页关闭，公开shutdown200、原39668 joined exit0，native physical/output/request及其auth/models成对结算完成；新私有authority也精确成对退休。与前3scope合计4个scope/8次实际gpt-6.1-sol流预检，全部200和reader EOF；两个源authority准备及退休时原Codex文件尺寸/mtime一致。\n\n导航、数据投影和写结算已获得当前代码的实际证据；配置写入76秒、读取中的默认权限呈现仍是下一批优先问题，不把这两个剩余问题包装为已完成。所有修改按本批范围提交推送，不发布版本或清理用户文件。\n`
fs.writeFileSync(record,spec)
let readme=fs.readFileSync(artifact+'/README.md','utf8')
readme=readme.replace('|20|回到原Work项目，General Ask及Git false|','|20|回到原Work项目，General Ask及Git false|\n|21—22|当前final构建Task→New Chat；原真实写仍在运行时已进入Chat输入意图，未加载的权限占位不计成功|\n|23—25|写完后重读实际Ask，当前鼠标开关true、标签恢复false与中文设置|')
readme+='\n当前交付为final 18633的50.78秒构建；前三scope是保留的调查/中间复验。合计4个scope均shutdown200及物理结算、8个实际gpt-6.1-sol流预检200/reader EOF。final生产CLI写76.0秒、恢复16.7秒仍取得最终回执并恢复原canonical数据；原写期间一次真实New Chat交互129ms已完成Chat意图切换。数值不是UI测试阈值。新增导航unit尝试触及呈现调度已删除，原失败日志保留；没有添加polyfill或UI fixture。\n'
fs.writeFileSync(artifact+'/README.md',readme)
fs.writeFileSync(artifact+'/checks/closeout.mjs.gz',zlib.gzipSync(fs.readFileSync(root+'/closeout.mjs')))
const walk=dir=>fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(dir,e.name)):[path.join(dir,e.name)])
const values=[]
function collect(obj){for(const [key,value] of Object.entries(obj)){if(value&&typeof value==='object')collect(value);else if(typeof value==='string'&&value.length>16&&/access|refresh|token|key|secret|password|account/i.test(key))values.push(value)}}
for(const file of ['C:/Users/hengu/.codex/auth.json','C:/Users/hengu/AppData/Local/opencorvus/data/auth.json'])collect(JSON.parse(fs.readFileSync(file,'utf8')))
if(!values.length)throw Error('Actual credential material required for memory-only disclosure review')
for(const file of walk(artifact)){
 if(file.endsWith('.jpg'))continue
 const bytes=fs.readFileSync(file),body=(file.endsWith('.gz')?zlib.gunzipSync(bytes):bytes).toString('utf8')
 for(const value of values)if(body.includes(value))throw Error('Credential disclosure: '+file)
}
console.log(JSON.stringify({artifactFiles:walk(artifact).length,disclosureReview:'passed',screenshots:25,scopes:4,contractTests:31,expectations:67,goal:'active; continued iteration, single agent'}))
