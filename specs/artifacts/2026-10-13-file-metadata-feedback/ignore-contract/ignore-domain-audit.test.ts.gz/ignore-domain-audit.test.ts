import { afterAll, expect, test } from "bun:test"
import fs from "node:fs/promises"
import path from "node:path"
import ignore from "../packages/opencorvus/node_modules/ignore/index.js"
import { Hono } from "../packages/opencorvus/node_modules/hono/dist/index.js"
import { Instance } from "../packages/opencorvus/src/project/instance"
import { FileRoutes } from "../packages/opencorvus/src/server/routes/file"
import { serverErrorResponse } from "../packages/opencorvus/src/server/error-handler"
import { hostGit } from "../packages/opencorvus/src/util/git"
import { memoryProject, resetMemoryDatabase } from "../packages/opencorvus/test/fixture/memory"

afterAll(resetMemoryDatabase)
const evidence: unknown[] = []
const gitRules = "/root-only.md\n/scoped-project/anchored 资料.md\n/scoped-project/override.md\n/scoped-project/extra.md\n/scoped-project/copied.md\n/scoped-project/moved.md\n/scoped-project/created.md\n/scoped-project/dirs/\n/real-target/\n/moved-terminal/\n/ Source 资料\\[1\\].md\n\\#note.md\n\\!note.md\n"
const extraRules = "!/scoped-project/override.md\n!/scoped-project/extra.md\n/scoped-project/extra.md\n"

async function save(row: unknown) {
  evidence.push(row)
  console.log("[owned ignore domain audit]", JSON.stringify(row))
  await fs.writeFile(path.join(import.meta.dir, "ignore-domain-evidence.json"), JSON.stringify(evidence, null, 2))
}

async function git(directory: string, args: string[]) {
  const result = await hostGit(args, { cwd: directory })
  return { exitCode: result.exitCode, stdout: result.text(), stderr: result.stderr.toString() }
}

async function fixture(seed: string, rules: string) {
  const project = await memoryProject(seed)
  const owner = await fs.realpath(process.env.OPENCORVUS_TEST_PROCESS_ROOT!)
  if (!path.relative(owner, project.path).startsWith(`fixtures${path.sep}memory-`)) throw new Error("No new owned fixture authority")
  expect(await fs.readFile(path.join(project.path, ".opencorvus-test-project-identity"), "utf8")).toBe(seed)
  await fs.writeFile(path.join(project.path, ".gitignore"), rules)
  await fs.writeFile(path.join(project.path, ".ignore"), extraRules)
  const child = path.join(project.path, "scoped-project")
  await fs.mkdir(path.join(child, "dirs"), { recursive: true })
  await fs.mkdir(path.join(project.path, "real-target"))
  await fs.writeFile(path.join(child, ".git"), `gitdir: ${path.join(project.path, ".git").replaceAll("\\", "/")}\n`)
  expect((await git(project.path, ["config", "core.worktree", project.path])).exitCode).toBe(0)
  for (const base of [project.path, child]) {
    for (const name of ["root-only.md", "anchored 资料.md", "override.md", "extra.md", " Source 资料[1].md", "#note.md", "!note.md"]) {
      await fs.writeFile(path.join(base, name), `${seed}:${name}\n`)
    }
  }
  await fs.writeFile(path.join(child, "dirs", "note.md"), `${seed}:directory child\n`)
  await fs.writeFile(path.join(project.path, "real-target", "note.md"), `${seed}:symlink target\n`)
  return { ...project, child }
}

async function api(directory: string) {
  const scope = await Instance.provide({ directory, fn: async () => ({ directory: Instance.directory, worktree: Instance.worktree, projectID: Instance.project.id }) })
  const errors: unknown[] = []
  const app = new Hono().onError((error, c) => {
    errors.push({ name: error.name, message: error.message })
    return serverErrorResponse(error, c)
  }).route("/", FileRoutes())
  const server = Bun.serve({ hostname: "127.0.0.1", port: 0, fetch: request => Instance.provide({ directory, fn: () => app.fetch(request) }) })
  return {
    scope,
    async request(label: string, method: string, route: string, body?: unknown, target?: string) {
      const response = await fetch(new URL(route, server.url), { method, ...(body ? { headers: { "content-type": "application/json" }, body: JSON.stringify(body) } : {}), signal: AbortSignal.timeout(20_000) })
      const targetContent = target ? await fs.readFile(target, "utf8") : undefined
      await save({ label, scope, method, route, input: body, response: { status: response.status, body: await response.json() }, target, targetContent, errors: errors.slice() })
    },
    async [Symbol.asyncDispose]() { await server.stop(true) },
  }
}

async function link(target: string, alias: string) {
  await fs.symlink(target, alias, process.platform === "win32" ? "junction" : "dir")
  return { path: alias, async [Symbol.asyncDispose]() { await fs.unlink(alias) } }
}

test("audit rule-domain facts on normal, scoped, linked and independent owned Projects", async () => {
  await using first = await fixture("ignore-domain-FIRST", gitRules)
  await using second = await fixture("ignore-domain-SECOND", "/scoped-project/root-only.md\n/anchored 资料.md\n")
  await using firstRoot = await api(first.path)
  await using firstChild = await api(first.child)
  await using secondRoot = await api(second.path)
  await using secondChild = await api(second.child)
  expect(firstRoot.scope.projectID).toBe(firstChild.scope.projectID)
  expect(secondRoot.scope.projectID).toBe(secondChild.scope.projectID)
  await save({ label: "independent project identities", first: firstRoot.scope, second: secondRoot.scope, identities: [firstRoot.scope.projectID, secondRoot.scope.projectID] })
  for (const [label, reader] of [["normal FIRST", firstRoot], ["scoped FIRST", firstChild], ["normal SECOND", secondRoot], ["scoped SECOND", secondChild]] as const) {
    await reader.request(label, "GET", "/file?path=")
  }
  for (const alias of [".", "./", "missing/..", "dirs/.."]) await firstChild.request(`scoped dot alias ${alias}`, "GET", `/file?${new URLSearchParams({ path: alias })}`)
  await firstChild.request("parent worktree list", "GET", "/file?path=..")
  for (const [label, method, route, input, target] of [
    ["scoped create root-rule entry", "POST", "/file/item", { path: "missing/../created.md", type: "file", content: "Exact created child\n" }, path.join(first.child, "created.md")],
    ["scoped copy root-rule entry", "POST", "/file/item/copy", { path: "extra.md", newPath: "./copied.md" }, path.join(first.child, "copied.md")],
    ["scoped move root-rule entry", "PATCH", "/file/item", { path: "override.md", newPath: "missing/../moved.md" }, path.join(first.child, "moved.md")],
  ] as const) await firstChild.request(label, method, route, input, target)
  await firstChild.request("scoped list after mutations", "GET", "/file?path=")
  await using scopeLink = await link(first.path, `${first.path}-scope`)
  await using linkedRoot = await api(scopeLink.path)
  await linkedRoot.request("scope itself junction list", "GET", "/file?path=.")
  await using ancestor = await link(path.dirname(first.path), `${first.path}-ancestor`)
  const throughAncestor = path.relative(first.path, path.join(ancestor.path, path.basename(first.path), "scoped-project"))
  await firstRoot.request("ancestor junction child list", "GET", `/file?${new URLSearchParams({ path: throughAncestor })}`)
  const ancestorChild = path.join(ancestor.path, path.basename(first.path), "scoped-project")
  await using linkedChild = await api(ancestorChild)
  await linkedChild.request("child scope through ancestor junction", "GET", "/file?path=.")
  await fs.symlink(path.join(first.path, "real-target"), path.join(first.path, "terminal-dir"), process.platform === "win32" ? "junction" : "dir")
  await firstRoot.request("terminal directory junction list", "GET", "/file?path=")
  await firstRoot.request("terminal junction move receipt", "PATCH", "/file/item", { path: "terminal-dir", newPath: "moved-terminal" })
  await firstRoot.request("terminal junction list after move", "GET", "/file?path=")
  await save({ label: "Git terminal junction entry decision", result: await git(first.path, ["check-ignore", "--no-index", "-v", "-z", "--", "moved-terminal", "real-target"]) })
  try {
    await fs.symlink(path.join(first.path, "real-target", "note.md"), path.join(first.path, "terminal-file.md"), "file")
    await firstRoot.request("terminal file symlink list", "GET", "/file?path=")
    await save({ label: "Git terminal file entry decision", result: await git(first.path, ["check-ignore", "--no-index", "-v", "-z", "--", "terminal-file.md", "real-target/note.md"]) })
  } catch (error) { await save({ label: "terminal file symlink creation limitation", error: { code: (error as NodeJS.ErrnoException).code, message: (error as Error).message } }) }
  const library = ignore().add(gitRules).add(extraRules)
  for (const name of ["root-only.md", "anchored 资料.md", "extra.md", "created.md", "copied.md", "moved.md", " Source 资料[1].md", "#note.md", "!note.md"]) {
    const full = path.join(first.child, name)
    await save({ label: "library rule coordinates", name, rulesRoot: first.path, directoryRelative: path.relative(first.child, full), rootRelative: path.relative(first.path, full), directoryDecision: library.ignores(path.relative(first.child, full)), rootDecision: library.ignores(path.relative(first.path, full)) })
  }
  await save({ label: "ancestor entry coordinates", directory: ancestorChild, worktree: linkedChild.scope.worktree, fullPath: path.join(ancestorChild, "anchored 资料.md"), lexical: path.relative(linkedChild.scope.worktree, path.join(ancestorChild, "anchored 资料.md")), physicalParentEntry: path.relative(await fs.realpath(linkedChild.scope.worktree), path.join(await fs.realpath(ancestorChild), "anchored 资料.md")) })
  await save({ label: "terminal identity coordinates", fullPath: path.join(first.path, "moved-terminal"), parentEntry: path.relative(await fs.realpath(first.path), path.join(await fs.realpath(first.path), "moved-terminal")), fullTarget: path.relative(await fs.realpath(first.path), await fs.realpath(path.join(first.path, "moved-terminal"))), link: (await fs.lstat(path.join(first.path, "moved-terminal"))).isSymbolicLink() })
}, 180_000)
