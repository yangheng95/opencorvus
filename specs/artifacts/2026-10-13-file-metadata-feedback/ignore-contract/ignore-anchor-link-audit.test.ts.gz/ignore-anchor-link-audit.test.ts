import { afterAll, expect, test } from "bun:test"
import fs from "node:fs/promises"
import path from "node:path"
import ignore from "../packages/opencorvus/node_modules/ignore/index.js"
import { Hono } from "../packages/opencorvus/node_modules/hono/dist/index.js"
import { Instance } from "../packages/opencorvus/src/project/instance"
import { FileRoutes } from "../packages/opencorvus/src/server/routes/file"
import { serverErrorResponse } from "../packages/opencorvus/src/server/error-handler"
import { hostGit } from "../packages/opencorvus/src/util/git"
import { memoryProject, resetMemoryDatabase } from "../packages/opencorvus/test/fixture/memory"

afterAll(resetMemoryDatabase)

async function git(directory: string, args: string[]) {
  const result = await hostGit(args, { cwd: directory })
  return { args, exitCode: result.exitCode, stdout: result.text(), stderr: result.stderr.toString() }
}

test("investigate logical Git entries and the proposed continuous physical-root anchor on an owned Project", async () => {
  await using project = await memoryProject("ignore-anchor-link-investigation")
  const owner = await fs.realpath(process.env.OPENCORVUS_TEST_PROCESS_ROOT!)
  if (!path.relative(owner, project.path).startsWith(`fixtures${path.sep}memory-`)) throw new Error("No newly owned fixture authority")
  expect(await fs.readFile(path.join(project.path, ".opencorvus-test-project-identity"), "utf8")).toBe("ignore-anchor-link-investigation")
  await fs.mkdir(path.join(project.path, "sub"))
  await fs.writeFile(path.join(project.path, "sub", "note.md"), "Exact logical entry content\n")
  const reentryDirectory = `back-link/${path.basename(project.path)}/sub`
  const rules = `/alias-child/note.md\n/${reentryDirectory}/note.md\n/moved-terminal/\n`
  await fs.writeFile(path.join(project.path, ".gitignore"), rules)
  for (const [target, name] of [[path.join(project.path, "sub"), "alias-child"], [path.dirname(project.path), "back-link"], [path.join(project.path, "sub"), "terminal-dir"]]) {
    await fs.symlink(target, path.join(project.path, name), process.platform === "win32" ? "junction" : "dir")
  }
  await fs.symlink(path.join(project.path, "sub", "note.md"), path.join(project.path, "terminal-file.md"), "file")
  const errors: unknown[] = []
  const app = new Hono().onError((error, c) => { errors.push({ name: error.name, message: error.message }); return serverErrorResponse(error, c) }).route("/", FileRoutes())
  const scope = await Instance.provide({ directory: project.path, fn: async () => ({ directory: Instance.directory, worktree: Instance.worktree, projectID: Instance.project.id }) })
  const server = Bun.serve({ hostname: "127.0.0.1", port: 0, fetch: request => Instance.provide({ directory: project.path, fn: () => app.fetch(request) }) })
  const rows: unknown[] = []
  async function request(label: string, route: string, method = "GET", body?: unknown) {
    const errorStart = errors.length
    const response = await fetch(new URL(route, server.url), { method, ...(body ? { headers: { "content-type": "application/json" }, body: JSON.stringify(body) } : {}), signal: AbortSignal.timeout(20_000) })
    rows.push({ label, scope, route, method, input: body, response: { status: response.status, body: await response.json() }, errors: errors.slice(errorStart) })
  }
  try {
    await request("internal alias child logical listing", `/file?${new URLSearchParams({ path: "alias-child" })}`)
    await request("internal ancestor outward then inward logical listing", `/file?${new URLSearchParams({ path: reentryDirectory })}`)
    await request("terminal junction move metadata", "/file/item", "PATCH", { path: "terminal-dir", newPath: "moved-terminal" })
    await request("terminal junction and file-link listing", "/file?path=")
    rows.push({ label: "actual Git terminal entry results", result: await git(project.path, ["check-ignore", "--no-index", "-v", "--", "moved-terminal", "terminal-file.md", "sub"]) })
    rows.push({ label: "actual Git ancestor traversal result", result: await git(project.path, ["check-ignore", "--no-index", "-v", "--", "alias-child/note.md"]) })
    const physicalRoot = await fs.realpath(project.path)
    const full = path.join(project.path, reentryDirectory, "note.md")
    let ancestor = path.dirname(full)
    let anchor: string | undefined
    const chain: unknown[] = []
    while (true) {
      const physical = await fs.realpath(ancestor)
      const relative = path.relative(physicalRoot, physical)
      const admitted = relative === "" || (relative !== ".." && !relative.startsWith(`..${path.sep}`) && !path.isAbsolute(relative))
      chain.push({ ancestor, physical, relative, admitted })
      if (!admitted) break
      anchor = ancestor
      const parent = path.dirname(ancestor)
      if (parent === ancestor) break
      ancestor = parent
    }
    const anchorCoordinate = path.join(path.relative(physicalRoot, await fs.realpath(anchor!)), path.relative(anchor!, full))
    const logicalCoordinate = path.relative(project.path, full)
    const library = ignore().add(rules)
    rows.push({ label: "continuous anchor risk", full, chain, anchor, logicalCoordinate, anchorCoordinate, logicalDecision: library.ignores(logicalCoordinate), anchorDecision: library.ignores(anchorCoordinate), content: await fs.readFile(full, "utf8") })
    const target = path.join(project.path, "moved-terminal")
    rows.push({ label: "terminal link filesystem identities", target, statDirectory: (await fs.stat(target)).isDirectory(), lstatSymlink: (await fs.lstat(target)).isSymbolicLink(), terminalFileSymlink: (await fs.lstat(path.join(project.path, "terminal-file.md"))).isSymbolicLink(), targetPhysical: await fs.realpath(target) })
    for (const row of rows) console.log("[owned anchor/link audit]", JSON.stringify(row))
    await fs.writeFile(path.join(import.meta.dir, "ignore-anchor-link-evidence.json"), JSON.stringify(rows, null, 2))
  } finally { await server.stop(true) }
}, 90_000)
