import { afterAll, expect, test } from "bun:test"
import fs from "node:fs/promises"
import path from "node:path"
import { Hono } from "../packages/opencorvus/node_modules/hono/dist/index.js"
import { Instance } from "../packages/opencorvus/src/project/instance"
import { FileRoutes } from "../packages/opencorvus/src/server/routes/file"
import { serverErrorResponse } from "../packages/opencorvus/src/server/error-handler"
import { hostGit } from "../packages/opencorvus/src/util/git"
import { memoryProject, resetMemoryDatabase } from "../packages/opencorvus/test/fixture/memory"

afterAll(resetMemoryDatabase)

test("investigate an explicitly configured directory authority physically outside its Git worktree", async () => {
  await using repository = await memoryProject("outside-rule-root-repository")
  await using directoryOwner = await memoryProject("outside-rule-root-directory")
  const owner = await fs.realpath(process.env.OPENCORVUS_TEST_PROCESS_ROOT!)
  for (const project of [repository, directoryOwner]) {
    if (!path.relative(owner, project.path).startsWith(`fixtures${path.sep}memory-`)) throw new Error("No new managed fixture authority")
  }
  const directory = path.join(directoryOwner.path, "explicit-outside-scope")
  await fs.mkdir(directory)
  await fs.writeFile(path.join(directory, ".git"), `gitdir: ${path.join(repository.path, ".git").replaceAll("\\", "/")}\n`)
  const config = await hostGit(["config", "core.worktree", repository.path], { cwd: repository.path })
  expect(config.exitCode).toBe(0)
  await fs.writeFile(path.join(repository.path, ".gitignore"), "/report.md\n")
  await fs.writeFile(path.join(directory, "report.md"), "Directory-authority exact content\n")
  await fs.writeFile(path.join(repository.path, "report.md"), "Worktree-authority exact content\n")
  const discovery = await hostGit(["rev-parse", "--show-toplevel"], { cwd: directory })
  const errors: unknown[] = []
  const app = new Hono().onError((error, c) => { errors.push({ name: error.name, message: error.message }); return serverErrorResponse(error, c) }).route("/", FileRoutes())
  const scope = await Instance.provide({ directory, fn: async () => ({ directory: Instance.directory, worktree: Instance.worktree, projectWorktree: Instance.project.worktree, projectID: Instance.project.id }) })
  const server = Bun.serve({ hostname: "127.0.0.1", port: 0, fetch: request => Instance.provide({ directory, fn: () => app.fetch(request) }) })
  const rows: unknown[] = [{ label: "explicit root discovery", scope, discovery: { exitCode: discovery.exitCode, stdout: discovery.text(), stderr: discovery.stderr.toString() }, physical: { directory: await fs.realpath(directory), worktree: await fs.realpath(scope.worktree), relative: path.relative(await fs.realpath(scope.worktree), await fs.realpath(directory)) }, rules: await fs.readFile(path.join(repository.path, ".gitignore"), "utf8") }]
  try {
    for (const [label, method, route, body, physical] of [
      ["list directory authority outside rule root", "GET", "/file?path=", undefined, undefined],
      ["list worktree authority from outside directory", "GET", `/file?${new URLSearchParams({ path: path.relative(directory, repository.path) })}`, undefined, undefined],
      ["copy within outside directory authority", "POST", "/file/item/copy", { path: "report.md", newPath: "copied.md" }, path.join(directory, "copied.md")],
    ] as const) {
      const errorStart = errors.length
      const response = await fetch(new URL(route, server.url), { method, ...(body ? { headers: { "content-type": "application/json" }, body: JSON.stringify(body) } : {}), signal: AbortSignal.timeout(20_000) })
      rows.push({ label, scope, method, route, input: body, response: { status: response.status, body: await response.json() }, physical, content: physical ? await fs.readFile(physical, "utf8") : undefined, errors: errors.slice(errorStart) })
    }
    for (const row of rows) console.log("[owned outside rule root audit]", JSON.stringify(row))
    await fs.writeFile(path.join(import.meta.dir, "ignore-outside-root-evidence.json"), JSON.stringify(rows, null, 2))
  } finally { await server.stop(true) }
}, 90_000)
