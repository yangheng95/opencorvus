import { afterAll, expect, test } from "bun:test"
import fs from "node:fs/promises"
import path from "node:path"
import { Hono } from "../packages/opencorvus/node_modules/hono/dist/index.js"
import { Instance } from "../packages/opencorvus/src/project/instance"
import { FileRoutes } from "../packages/opencorvus/src/server/routes/file"
import { serverErrorResponse } from "../packages/opencorvus/src/server/error-handler"
import { hostGit } from "../packages/opencorvus/src/util/git"
import { memoryProject, resetMemoryDatabase } from "../packages/opencorvus/test/fixture/memory"

afterAll(resetMemoryDatabase)

test("audit current sandbox ignore rules in a real detached linked worktree of an owned fixture", async () => {
  await using project = await memoryProject("ignore-linked-worktree-investigation")
  const owner = await fs.realpath(process.env.OPENCORVUS_TEST_PROCESS_ROOT!)
  if (!path.relative(owner, project.path).startsWith(`fixtures${path.sep}memory-`)) throw new Error("No new fixture authority")
  const linked = path.join(project.path, "linked-checkout")
  const added = await hostGit(["worktree", "add", "--detach", linked], { cwd: project.path })
  expect(added.exitCode).toBe(0)
  await fs.writeFile(path.join(project.path, ".gitignore"), "/main-only.md\n")
  await fs.writeFile(path.join(linked, ".gitignore"), "/linked-only.md\n")
  for (const directory of [project.path, linked]) {
    for (const name of ["main-only.md", "linked-only.md"]) await fs.writeFile(path.join(directory, name), `${directory}:${name}\n`)
  }
  const rows: unknown[] = []
  for (const directory of [project.path, linked]) {
    const scope = await Instance.provide({ directory, fn: async () => ({ directory: Instance.directory, worktree: Instance.worktree, projectWorktree: Instance.project.worktree, projectID: Instance.project.id }) })
    const app = new Hono().onError(serverErrorResponse).route("/", FileRoutes())
    const server = Bun.serve({ hostname: "127.0.0.1", port: 0, fetch: request => Instance.provide({ directory, fn: () => app.fetch(request) }) })
    try {
      const response = await fetch(new URL("/file?path=", server.url), { signal: AbortSignal.timeout(20_000) })
      const row = { scope, rules: await fs.readFile(path.join(directory, ".gitignore"), "utf8"), response: { status: response.status, body: await response.json() } }
      rows.push(row)
      console.log("[owned linked worktree rule audit]", JSON.stringify(row))
    } finally { await server.stop(true) }
  }
  await fs.writeFile(path.join(import.meta.dir, "ignore-linked-worktree-evidence.json"), JSON.stringify(rows, null, 2))
}, 90_000)
