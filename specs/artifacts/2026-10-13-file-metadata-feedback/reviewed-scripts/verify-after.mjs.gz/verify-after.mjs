import fs from 'node:fs/promises'
import path from 'node:path'
import assert from 'node:assert/strict'
const run = 'C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/file-feedback-after02-01a133'
const directory = path.join(run, 'project/scoped-project')
const endpoint = 'http://127.0.0.1:18442/'
const evidence = 'specs/artifacts/2026-10-13-file-metadata-feedback/after'
const outputs = []
async function request(route, method = 'GET', body, query = {}) {
  const url = new URL(route, endpoint)
  url.search = new URLSearchParams({ directory, ...query })
  const response = await fetch(url, { method, ...(body ? { headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) } : {}), signal: AbortSignal.timeout(20000) })
  const decoded = await response.json()
  outputs.push({ method, url: String(url), input: body, status: response.status, requestID: response.headers.get('x-opencorvus-request-id'), body: decoded })
  assert.equal(response.status, 200, JSON.stringify(decoded))
  return decoded
}
const createdPath = '../parent-created.md'
const createdContent = 'PARENT CREATED EXACT\r\n'
const node = await request('file/item', 'POST', { path: createdPath, type: 'file', content: createdContent })
assert.equal(node.path, path.relative(directory, path.join(directory, createdPath)))
assert.equal(node.type, 'file')
assert.equal(node.ignored, false)
const own = await request('file', 'GET', undefined, { path: '.' })
assert.equal(own.find(row => row.name === 'child-ignore.txt')?.ignored, true)
assert.equal(own.find(row => row.name === 'note.md')?.ignored, false)
const parent = await request('file', 'GET', undefined, { path: '..' })
assert.equal(parent.find(row => row.name === 'parent-copy.md')?.ignored, true)
assert.equal(parent.find(row => row.name === 'parent-move.md')?.ignored, false)
assert.equal(parent.find(row => row.name === 'parent-created.md')?.ignored, false)
const expected = {
  'note.md': 'SCOPED NOTE\r\n',
  'note-copy.md': 'SCOPED NOTE\r\n',
  'conflict.md': 'EXISTING CONFLICT\r\n',
  'child-ignore.txt': 'IGNORED CHILD\r\n',
  '../parent-copy.md': 'SCOPED NOTE\r\n',
  '../parent-move.md': 'SCOPED MOVE\r\n',
  '../parent-created.md': createdContent,
  'upload-proof.txt': 'UPLOAD PROOF EXACT\r\n',
}
const files = []
for (const [file, content] of Object.entries(expected)) {
  const bytes = await fs.readFile(path.join(directory, file))
  assert.deepEqual(bytes, Buffer.from(content), file)
  const read = await request('file/content', 'GET', undefined, { path: file })
  assert.equal(read.type, 'text')
  assert.equal(read.content, content)
  assert.equal(typeof read.revision, 'string')
  files.push({ file, byteLength: bytes.length, content })
}
await fs.mkdir(evidence, { recursive: true })
await fs.writeFile(path.join(evidence, 'actual-files-and-api.json'), JSON.stringify({ directory, files, outputs, boundary: 'Same production /ui server; published metadata and exact authored bytes, no model or injected messages' }, null, 2) + '\n')
console.log(JSON.stringify({ actualFiles: files.length, requests: outputs.length, verified: true }))
