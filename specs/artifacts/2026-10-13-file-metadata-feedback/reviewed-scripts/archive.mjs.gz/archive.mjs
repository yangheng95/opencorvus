import fs from 'node:fs'
import path from 'node:path'
import zlib from 'node:zlib'
const root = process.cwd()
const scratch = path.join(root, '.tmp-codex-file-feedback-01a133')
const evidence = path.join(root, 'specs/artifacts/2026-10-13-file-metadata-feedback')
function copy(input, output, gzip = false) {
  if (!fs.existsSync(input)) return
  const bytes = fs.readFileSync(input)
  fs.mkdirSync(path.dirname(output), { recursive: true })
  const result = gzip ? zlib.gzipSync(bytes) : bytes
  fs.writeFileSync(output, result)
  const restored = gzip ? zlib.gunzipSync(fs.readFileSync(output)) : fs.readFileSync(output)
  if (!restored.equals(bytes)) throw Error('Archive bytes differ: ' + input)
}
for (const occurrence of ['before02', 'after', 'after02', 'failure']) {
  const run = `C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/file-feedback-${occurrence}-01a133`
  for (const filename of ['startup.json', 'launch-owner.json', 'stdout.log', 'stderr.log']) {
    copy(path.join(run, filename), path.join(evidence, 'runtime', occurrence, filename + (filename.endsWith('.log') ? '.gz' : '')), filename.endsWith('.log'))
  }
  if (fs.existsSync(path.join(run, 'evidence'))) {
    for (const filename of fs.readdirSync(path.join(run, 'evidence'))) {
      if (filename.endsWith('.json')) copy(path.join(run, 'evidence', filename), path.join(evidence, 'runtime', occurrence, filename))
    }
  }
}
for (const filename of ['launch.ps1', 'launch-before.ps1', 'shutdown.ps1', 'native-host.ts', 'archive.mjs', 'verify-after.mjs', 'before-launch-setup-error.txt']) {
  copy(path.join(scratch, filename), path.join(evidence, 'reviewed-scripts', filename + '.gz'), true)
}
for (const filename of fs.readdirSync(scratch)) {
  if (filename.endsWith('.log') || filename.endsWith('.exit.txt')) copy(path.join(scratch, filename), path.join(evidence, 'validation', filename + (filename.endsWith('.log') ? '.gz' : '')), filename.endsWith('.log'))
}
const audit = path.join(root, '.tmp-codex-file-ignore-01a133')
for (const filename of fs.readdirSync(audit)) {
  if (/\.(json|log|txt|md|ts)$/.test(filename)) copy(path.join(audit, filename), path.join(evidence, 'ignore-contract', filename + (filename.endsWith('.log') || filename.endsWith('.ts') ? '.gz' : '')), filename.endsWith('.log') || filename.endsWith('.ts'))
}
const ui = 'C:/Users/hengu/AppData/Local/Temp/opencorvus-explorer-feedback-a0468b8b5b2d4a8d90f27594ae0a1c68'
for (const filename of fs.readdirSync(ui)) {
  if (/\.(log|txt|json|md)$/.test(filename)) copy(path.join(ui, filename), path.join(evidence, 'validation', 'ui-' + filename + (filename.endsWith('.log') ? '.gz' : '')), filename.endsWith('.log'))
}
console.log('Archived exact owned evidence bytes; failed and successful occurrences remain separate.')
