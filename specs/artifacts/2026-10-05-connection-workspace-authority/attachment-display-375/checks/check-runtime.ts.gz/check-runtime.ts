import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
const root=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/attachment-display-375')
const dir=path.join(root,'after'),prefix='attachment-display-375-after',read=(name:string)=>JSON.parse(fs.readFileSync(path.join(dir,name),'utf8'))
const input=read('authored-inputs.json'),canonical=read('canonical-current-conversations.json'),sources=canonical.parts.filter((p:any)=>p.type==='source-file')
assert.equal(sources.length,2);assert.equal(canonical.tools.length,2)
const files=[]
for(const item of input.inputs){
 const original=fs.readFileSync(item.original),actual=fs.readFileSync(item.path)
 assert.deepEqual(actual,original);assert.equal(actual.length,item.bytes)
 const metadata=JSON.parse(fs.readFileSync(item.path+'.metadata.json','utf8'))
 assert.equal(metadata.filename,item.name);assert.equal(metadata.url,item.reference.url)
 files.push({id:item.id,path:item.path,name:metadata.filename,bytes:actual.length,identity:'Complete bytes equal actual uploaded originals; metadata names and canonical URLs match'})
}
assert.deepEqual(fs.readFileSync(input.ordinary.path),Buffer.from(input.ordinary.text))
const calls=[]
for(const item of input.inputs.filter((x:any)=>['first','second'].includes(x.id))){
 const source=sources.find((s:any)=>s.path===item.path);assert.equal(source.provider,'opencorvus-read');assert.equal(source.origin,'attachment');assert.equal(source.title,item.name);assert.deepEqual(source.range,{startLine:1,endLine:1})
 const tool=canonical.tools.find((t:any)=>t.message_id===source.messageID),request=JSON.parse(tool.data)
 assert.equal(request.tool,'read');assert.deepEqual(request.input,{filePath:item.reference.url,offset:1,limit:1})
 const outcome=canonical.outcomes.find((o:any)=>o.requestPartID===tool.id);assert.equal(outcome.outcome,'completed')
 assert.equal(outcome.output,`<path>${item.path}</path>\n<type>file</type>\n<content>1: ${item.text.split(/\r?\n/)[0]}\n\n(Showing lines 1-1 of 3. Use offset=2 to continue.)\n</content>`)
 calls.push({sourceID:source.sourceId,path:source.path,callID:request.callID,outcome:outcome.outcome})
}
assert.equal(new Set(calls.map(c=>c.sourceID)).size,2)
const completed=canonical.messages.filter((m:any)=>m.role==='assistant'&&m.finish==='stop')
assert.equal(completed.length,2);for(const m of completed)assert.equal(typeof m.time.completed,'number')
const preflight=read(prefix+'-preflight-ready.json').preflight
assert.deepEqual({credential:preflight.credential,catalog:preflight.catalog,model:preflight.actualModel,stream:preflight.streaming},{credential:'usable',catalog:'projected',model:'gpt-6.1-sol',stream:true})
const provider=read(prefix+'-final-provider-audit.json');assert.equal(provider.exhausted,false);assert.ok(provider.requests.length>0&&provider.requests.length<=12)
for(const r of provider.requests)assert.deepEqual({model:r.model,stream:r.streaming,status:r.status,reader:r.response_reader.state,terminal:r.response_reader.terminal.kind},{model:'gpt-6.1-sol',stream:true,status:200,reader:'settled',terminal:'eof'})
const settled=read(prefix+'-native-host-settled.json')
for(const key of ['physicalCompletion','outputDrainComplete','requestCleanupComplete'])assert.equal(settled[key],true)
assert.deepEqual({reason:settled.terminal.reason,exit:settled.terminal.exitCode},{reason:'exited',exit:0})
const qualified=read(prefix+'-qualified-surface-completion.json');assert.equal(qualified.qualification,'NativeService');assert.equal(qualified.providerEOFRequests,provider.requests.length)
const cleanup=read(prefix+'-physical-terminal-and-pair-cleanup.json');assert.equal(cleanup.pairedCleanupComplete,true);assert.deepEqual(cleanup.copiedPair.map((e:any)=>e.outcome),['removed','removed'])
const http=read(prefix+'-http-summary.json'),requests=http.requests.filter((r:any)=>r.data?.status==='completed')
const served=requests.find((r:any)=>r.data?.path==='/ui/assets/main-CAo85tzZ.js');assert.equal(served.data.statusCode,200)
const failedOldWorker=requests.find((r:any)=>r.data?.path==='/ui/assets/markdown-render.worker-D_K6Yc7v.js'&&r.data.statusCode===404);assert.ok(failedOldWorker)
const finalWorker=requests.find((r:any)=>r.data?.path==='/ui/assets/markdown-render.worker-CF9y63Km.js');assert.equal(finalWorker.data.statusCode,200)
const birth=Number(BigInt(settled.target.processInstanceID.slice(6))/10000n-62135596800000n)
const result={calls,completed,requests:provider.requests.length,elapsedMs:Date.parse(settled.observedAtUtc)-birth,files,settled,qualified,served,failedOldWorker,finalWorker}
fs.mkdirSync(path.join(root,'checks'),{recursive:true})
fs.writeFileSync(path.join(root,'checks/runtime-qualification.json'),JSON.stringify({result,boundary:'Actual Provider/Native/Source/completed Message/ToolOutcome/full file bytes and HTTP facts. Twelve UI screenshots were manually reviewed; no UI assertions. Old worker 404 after replacing the served bundle is preserved separately from the image-link fix. PNG/PDF are actual UI/backend previews; model read only the two text attachments.'},null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({sources:calls.length,requests:result.requests,elapsedMs:result.elapsedMs,files:files.length,exit:0}))
