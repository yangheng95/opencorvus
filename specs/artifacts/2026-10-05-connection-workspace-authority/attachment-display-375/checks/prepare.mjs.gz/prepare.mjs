import fs from 'node:fs'
import path from 'node:path'
const run='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/attachment-display-375-after'
const project=path.join(run,'project'),evidence=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/attachment-display-375/after')
const ready=JSON.parse(fs.readFileSync(path.join(run,'evidence/preflight-ready.json'),'utf8')).preflight
if(ready.credential!=='usable'||ready.catalog!=='projected'||ready.actualModel!=='gpt-6.1-sol'||!ready.streaming)throw Error('Provider qualification required')
const inputs=[
 {id:'first',name:' Résumé（终版）.txt',mime:'text/plain',text:'第一份附件375\r\nFIRST375\r\n第三行\r\n'},
 {id:'second',name:' Résumé（终版）.txt',mime:'text/plain',text:'第二份附件375\nSECOND375\n第三行\n'},
 {id:'image',name:'研究图（终版）.png',mime:'image/png',source:path.resolve('packages/overlay/src-tauri/icons/128x128@2x.png')},
 {id:'pdf',name:'研究报告（终版）.pdf',mime:'application/pdf',source:path.resolve('packages/web/public/papers/opencorvus-poc.pdf')},
 {id:'missing',name:'缺失元数据.txt',mime:'text/plain',text:'METADATA375\n'},
]
fs.mkdirSync(path.join(run,'media-inputs'),{recursive:true})
for(const input of inputs){
 const bytes=input.source?fs.readFileSync(input.source):Buffer.from(input.text)
 input.original=path.join(run,'media-inputs',input.id+path.extname(input.name));fs.writeFileSync(input.original,bytes,{flag:'wx'})
 const r=await fetch('http://localhost:18382/attachment?'+new URLSearchParams({directory:project,filename:input.name}),{method:'POST',headers:{'Content-Type':input.mime},body:bytes,signal:AbortSignal.timeout(30000)})
 const reference=await r.json();if(r.status!==200)throw Error(JSON.stringify({status:r.status,reference}));input.reference=reference;input.bytes=bytes.length
 const root=path.join(project,'.opencorvus/.r/project/attachments'),name=reference.url.split('/').at(-1)
 const matches=fs.readdirSync(root,{recursive:true,withFileTypes:true}).filter(e=>e.isFile()&&e.name===name).map(e=>path.join(e.parentPath,e.name));if(matches.length!==1)throw Error('One produced blob required')
 input.path=matches[0];input.relative=path.relative(project,input.path).replaceAll('\\','/')
 if(input.id==='missing'){input.metadataBackup=path.join(run,'media-inputs','missing.metadata.json');fs.renameSync(input.path+'.metadata.json',input.metadataBackup)}
}
const ordinary={path:path.join(project,'普通记录.txt'),text:'普通项目文件375\n'};fs.writeFileSync(ordinary.path,ordinary.text,{flag:'wx'})
fs.mkdirSync(evidence,{recursive:true});fs.writeFileSync(path.join(evidence,'authored-inputs.json'),JSON.stringify({project,inputs,ordinary},null,2)+'\n',{flag:'wx'})
const [first,second,image,pdf,missing]=inputs
const prompt='请实际read这两份文本附件，每份offset=1、limit=1，保留各自真实来源：\n'+first.reference.url+'\n'+second.reference.url+'\n然后原样输出下面的Markdown列表。这些是我准备的本轮界面验收链接，媒体不需要read，不要声称已读媒体，不修改文件、不创建任务或调用成员：\n'+[
 '- [第一份绝对引用]('+first.path.replaceAll('\\','/')+':1)',
 '- [第二份相对引用]('+second.relative+':1)',
 '- [图片附件]('+image.relative+')',
 '- [PDF附件]('+pdf.relative+')',
 '- [普通项目文件](普通记录.txt)',
 '- [缺失元数据附件]('+missing.relative+':1)',
].join('\n')
fs.writeFileSync('.tmp-product-iteration/attachment-display-375/after/main-request.txt',prompt,{flag:'wx'})
console.log(JSON.stringify({uploads:inputs.map(x=>({id:x.id,name:x.name,bytes:x.bytes})),prepared:true}))
