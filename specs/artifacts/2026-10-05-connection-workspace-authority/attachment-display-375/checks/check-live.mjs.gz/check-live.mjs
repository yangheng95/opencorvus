import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
const root=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/attachment-display-375/after'),input=JSON.parse(fs.readFileSync(path.join(root,'authored-inputs.json'),'utf8'))
const results=[]
for(const item of input.inputs){
 const response=await fetch('http://localhost:18382/file/content?'+new URLSearchParams({directory:input.project,path:item.relative}),{signal:AbortSignal.timeout(30000)})
 const body=await response.json()
 if(item.id==='missing')assert.deepEqual({status:response.status,body},{status:404,body:{name:'FileNotFoundError',data:{path:item.relative,message:'Attachment metadata not found for file: '+item.relative}}})
 else{
  assert.equal(response.status,200);assert.equal(body.displayName,item.name)
  assert.deepEqual(Buffer.from(body.content,body.encoding==='base64'?'base64':'utf8'),fs.readFileSync(item.original))
 }
 assert.deepEqual(fs.readFileSync(item.path),fs.readFileSync(item.original))
 results.push({id:item.id,status:response.status,...(item.id==='missing'?{body}:{displayName:body.displayName,type:body.type,mimeType:body.mimeType,encoding:body.encoding,bytes:item.bytes,original:item.original,completeContentBytes:'equal to actual uploaded original'})})
}
const r=await fetch('http://localhost:18382/file/content?'+new URLSearchParams({directory:input.project,path:'普通记录.txt'}),{signal:AbortSignal.timeout(30000)}),body=await r.json()
assert.equal(r.status,200);assert.equal(body.content,input.ordinary.text);assert.equal(typeof body.revision,'string')
results.push({id:'ordinary',status:r.status,body})
fs.writeFileSync(path.join(root,'live-content-api.json'),JSON.stringify({results,boundary:'Exact original input bytes are retained privately. Full actual HTTP decoded bytes compared; no UI assertions.'},null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({checks:results.length,metadataError:results.find(x=>x.id==='missing').status}))
