import fs from 'node:fs'
import path from 'node:path'
import {Database} from 'bun:sqlite'
const run='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/side-stream-361'
const label=process.argv[2]
if(!label||!/^[a-z0-9-]+$/.test(label))throw Error('Explicit observation name required')
const db=new Database(path.join(run,'runtime/data/opencorvus.db'),{readonly:true});db.exec('BEGIN')
try{
 const sessions=db.query('SELECT id,project_id,kind,parent_id,title FROM session ORDER BY time_created,id').all()
 const messages=db.query("SELECT m.id,m.session_id,json_extract(m.data,'$.role') AS role,json_extract(m.data,'$.agent') AS agent,json_extract(m.data,'$.time.completed') AS completedAt,json_extract(m.data,'$.finish') AS finish,(SELECT COALESCE(SUM(length(json_extract(p.data,'$.text'))),0) FROM part p WHERE p.message_id=m.id AND json_extract(p.data,'$.type')='text') AS textChars,(SELECT COUNT(*) FROM part p WHERE p.message_id=m.id AND json_extract(p.data,'$.type') IN ('source-file','source-url','source-document')) AS sourceCount FROM message m ORDER BY m.time_created,m.id").all()
 const provider=db.query('SELECT COUNT(*) AS requests,SUM(CASE WHEN o.id IS NULL THEN 1 ELSE 0 END) AS pending FROM provider_activity_request r LEFT JOIN provider_activity_outcome o ON o.request_id=r.id').get()
 const result={observedAt:new Date().toISOString(),label,sessions,messages,provider,boundary:'Manual observation point; readonly actual canonical database, not a UI assertion or substitute for visible screenshots'}
 const output=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/side-stream-361',label+'-canonical-progress.json')
 fs.writeFileSync(output,JSON.stringify(result,null,2)+'\n',{flag:'wx'})
 console.log(JSON.stringify(result))
}finally{db.exec('ROLLBACK');db.close()}
