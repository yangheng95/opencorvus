$ErrorActionPreference='Stop'
$taskRun361='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/side-stream-361'
$taskReady361=Get-Content -Raw -LiteralPath (Join-Path $taskRun361 'evidence/preflight-ready.json')|ConvertFrom-Json
if($taskReady361.preflight.credential -ne 'usable' -or $taskReady361.preflight.catalog -ne 'projected' -or $taskReady361.preflight.actualModel -ne 'gpt-6.1-sol' -or !$taskReady361.preflight.streaming){throw 'Current exact credential/model qualification required'}
$taskFiles361=@()
foreach($taskName361 in @('甲','乙')){
 $taskDirectory361=Join-Path $taskRun361 ('project/资料/流式来源/候选方案'+$taskName361)
 [IO.Directory]::CreateDirectory($taskDirectory361)|Out-Null
 $taskFile361=Join-Path $taskDirectory361 '来源记录_流式正文与阅读位置核对.md'
 if(Test-Path -LiteralPath $taskFile361){throw 'Fresh authored input required'}
 $taskLines361=@(('# '+$taskName361+'目录的原始检索记录'))
 $taskLines361+=1..8|ForEach-Object{ 'STREAM361 {0}记录{1:D2}：本条位于原文件第{2}行。' -f $taskName361,$_ ,($_+1) }
 [IO.File]::WriteAllText($taskFile361,($taskLines361 -join "`n")+"`n",[Text.UTF8Encoding]::new($false))
 $taskFiles361+=@{path=$taskFile361;lines=$taskLines361}
}
$taskEvidence361='D:/myhexin-local/opencorvus/specs/artifacts/2026-10-05-connection-workspace-authority/side-stream-361'
[IO.File]::WriteAllText((Join-Path $taskEvidence361 'authored-inputs.json'),(@{query='STREAM361';files=$taskFiles361}|ConvertTo-Json -Depth 7)+"`n",[Text.UTF8Encoding]::new($false))
[IO.File]::WriteAllText('D:/myhexin-local/opencorvus/.tmp-product-iteration/side-stream-361/main-request.txt','请只回复：侧栏流式检查就绪。不要调用工具。',[Text.UTF8Encoding]::new($false))
$taskPrompt361='请先用 search_code 在当前项目的“资料/流式来源”目录检索字面量 STREAM361，限定 Markdown 文件，保留工具产生的全部真实来源。然后直接在这个侧聊中写一篇约3600至4500汉字的“来源与流式阅读核对说明”，分九节，每节有清晰标题和两三个完整段落，围绕两目录同名文件、来源序号与文件行号、正文与工具证据、展开收起、读点与滚动等主题。中段加入一张至少7行的比较表；后段加入一个不少于18行的 TypeScript 示例代码块，只展示逐行核对思路，不执行代码。避免用清单或重复短句代替长段落；最后明确你实际只做了检索，没有亲自完成网页点击或复制验收。不要读取或修改文件，不创建Task，不调用任何成员，也不要生成独立artifact。只完成这次检索和可见正文。'
[IO.File]::WriteAllText('D:/myhexin-local/opencorvus/.tmp-product-iteration/side-stream-361/side-request.txt',$taskPrompt361,[Text.UTF8Encoding]::new($false))
Write-Output 'Two actual same-name files prepared, with eight original STREAM361 matches each.'
