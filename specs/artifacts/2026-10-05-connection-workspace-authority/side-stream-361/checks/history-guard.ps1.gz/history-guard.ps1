$ErrorActionPreference='Stop'
$taskRepo='D:/myhexin-local/opencorvus'
$taskSource='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/side-stream-361'
$taskEvidence=Join-Path $taskRepo 'specs/artifacts/2026-10-05-connection-workspace-authority/side-stream-361/live'
$taskOut=Join-Path $taskRepo 'specs/artifacts/2026-10-05-connection-workspace-authority/side-stream-361/readiness'
. (Join-Path $taskRepo '.tmp-product-iteration/live-sol-launch.ps1') -FunctionsOnly
$taskOwner=Get-Content (Join-Path $taskSource 'launch-owner.json') -Raw|ConvertFrom-Json -AsHashtable -DateKind String
$taskStates=@(@{expected=$taskOwner.host;state=(Get-OwnedNativeState $taskOwner.host)},@{expected=$taskOwner.nativeTarget;state=(Get-OwnedNativeState $taskOwner.nativeTarget)})
$taskListeners=@(Get-NetTCPConnection -State Listen -ErrorAction Stop|Where-Object {$_.LocalPort -in @($taskOwner.port,18359)})
$taskPair=@('auth.json','models.json'|ForEach-Object{@{name=$_;present=(Test-Path -LiteralPath (Join-Path $taskSource ('runtime/data/'+$_)))}})
$taskNative=Get-OwnedNativeSettlement $taskOwner
$taskQualified=Get-Content (Join-Path $taskEvidence 'side-stream-361-live-physical-terminal-and-pair-cleanup.json') -Raw|ConvertFrom-Json -AsHashtable -DateKind String
$taskSurface=Get-Content (Join-Path $taskEvidence 'side-stream-361-live-qualified-surface-completion.json') -Raw|ConvertFrom-Json -AsHashtable -DateKind String
if(@($taskStates|Where-Object state -ne 'dead_or_reused').Count -or $taskListeners.Count -or @($taskPair|Where-Object present).Count -or !$taskNative -or $taskNative.terminal.exitCode -ne 0 -or $taskQualified.occurrence -cne $taskOwner.occurrence -or !$taskQualified.physicalCompletion -or !$taskQualified.pairedCleanupComplete -or $taskSurface.qualification -cne 'NativeService' -or $taskSurface.providerEOFRequests -ne 8){throw 'Original exact NativeService/Provider closure incomplete'}
Write-OwnedLaunchFact (Join-Path $taskOut 'guard.json') @{readQualified=$true;sourceRun=$taskSource;occurrence=$taskOwner.occurrence;observedAtUtc=[DateTime]::UtcNow.ToString('o');states=$taskStates;listenerCount=$taskListeners.Count;pair=$taskPair;native=$taskNative;originalQualification=$taskQualified;surface=$taskSurface;boundary='Original361 launcher49515 actual exit0 and eight streaming Provider EOFs.'}
$taskManifest=@{sourceRun=$taskSource;sourceEvidence=$taskOwner.settlementEvidenceRoot;sourceProject=$taskOwner.project;caseRun='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/side-stream-361-after';caseEvidence=(Join-Path $taskRepo 'specs/artifacts/2026-10-05-connection-workspace-authority/side-stream-361/after');readinessEvidence=$taskOut;casePort=18359;caseLabel='side-stream-361-after';sourceOccurrence=$taskOwner.occurrence;startupQualified=$false;selectedSubject=@{kind='session';id='ses_-zUS88KDXzzg9EB50qNf';projectID='prj_h2HgKXNTPvc9fpJFH6vS'}}
Write-OwnedLaunchFact (Join-Path $taskRepo '.tmp-product-iteration/side-stream-361/after-manifest.json') $taskManifest
Write-Output 'Original live-02 closure verified; current full source startup observations remain required.'



