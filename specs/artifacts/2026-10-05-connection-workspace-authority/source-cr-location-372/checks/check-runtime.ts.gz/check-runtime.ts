import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
const root=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/source-cr-location-372')
const results=[]
for(const stage of ['before','after']){
 const dir=path.join(root,stage),prefix='source-cr-location-372-'+stage,read=(name:string)=>JSON.parse(fs.readFileSync(path.join(dir,name),'utf8'))
 const inputs=read('authored-inputs.json'),canonical=read('canonical-current-conversations.json'),sources=canonical.parts.filter((p:any)=>p.type==='source-file')
 const original=(name:string)=>inputs.find((i:any)=>i.name===name)
 const source=(name:string,start:number,end:number,column:number|undefined,snippet:string|undefined,provider='opencorvus-search-code')=>({path:original(name).path,range:{startLine:start,endLine:end,...(column===undefined?{}:{startColumn:column})},snippet,provider})
 const expected=stage==='before'?[
  source('bom',1,1,4,'前😀MATCH372_F'),source('crlf',3,3,4,'前😀MATCH372_D'),source('lf',3,3,4,'前😀MATCH372_E'),source('mixed',3,3,4,'前😀MATCH372_C'),
  source('cr',1,1,11,original('cr').text),source('cross',1,1,8,original('cross').text),
 ]:[
  source('bom',1,1,5,'\uFEFF前😀MATCH372_F'),source('crlf',3,3,4,'前😀MATCH372_D'),source('lf',3,3,4,'前😀MATCH372_E'),source('mixed',5,5,4,'前😀MATCH372_C'),
  source('cr',3,3,4,'前😀MATCH372_A'),source('cr',5,5,2,'次MATCH372_B'),source('cross',2,3,undefined,'BEGIN372\nEND372'),
 ]
 expected.push(source('cr',3,3,undefined,undefined,'opencorvus-read'),source('mixed',5,5,undefined,undefined,'opencorvus-read'))
 const simplify=(s:any)=>({path:path.resolve(s.path),range:s.range,snippet:s.snippet,provider:s.provider})
 const sort=(values:any[])=>values.map(simplify).sort((a,b)=>JSON.stringify(a).localeCompare(JSON.stringify(b)))
 assert.deepEqual(sort(sources),sort(expected))
 assert.equal(canonical.tools.length,4)
 const calls=canonical.tools.map((row:any)=>({...row,request:JSON.parse(row.data)}))
 const first=calls.find((r:any)=>r.request.tool==='search_code'&&r.request.input.pattern==='MATCH372_')
 const cross=calls.find((r:any)=>r.request.tool==='search_code'&&r.request.input.pattern==='BEGIN372\\rEND372')
 assert.ok(first);assert.ok(cross)
 assert.equal(first.request.input.path,'格式');assert.equal(cross.request.input.path,'格式/cross.txt')
 for(const call of calls){
  const outcome=canonical.outcomes.find((o:any)=>o.requestPartID===call.id);assert.equal(outcome.outcome,'completed')
  const owned=sources.filter((s:any)=>s.provider==='opencorvus-search-code'&&(call.id===cross.id?path.resolve(s.path)===path.resolve(original('cross').path):path.resolve(s.path)!==path.resolve(original('cross').path)))
  if(call.request.tool==='search_code'){
   const lines=[`Found ${owned.length} matches`];let current=''
   for(const s of owned){if(current!==s.path){if(current)lines.push('');lines.push(s.path+':');current=s.path}const r=s.range;lines.push(`  ${r.endLine===r.startLine?'Line '+r.startLine:'Lines '+r.startLine+'-'+r.endLine}: ${s.snippet}`)}
   assert.equal(outcome.output,lines.join('\n'))
  }else{
   assert.equal(call.request.tool,'read');const name=path.basename(call.request.input.filePath,'.txt'),line=name==='cr'?3:5
   assert.deepEqual(call.request.input,{filePath:`格式/${name}.txt`,offset:line,limit:1})
   assert.ok(outcome.output.includes(`${line}: ${original(name).text.split(/\r\n|\r|\n/)[line-1]}`))
  }
 }
 for(const input of inputs)assert.deepEqual(fs.readFileSync(input.path),Buffer.from(input.text))
 const session=canonical.messages.find((m:any)=>m.id===first.message_id).sessionID
 const completed=canonical.messages.filter((m:any)=>m.sessionID===session&&m.role==='assistant'&&m.finish==='stop');assert.equal(completed.length,1);assert.equal(typeof completed[0].time.completed,'number')
 const preflight=read(prefix+'-preflight-ready.json').preflight
 assert.deepEqual({credential:preflight.credential,catalog:preflight.catalog,model:preflight.actualModel,stream:preflight.streaming},{credential:'usable',catalog:'projected',model:'gpt-6.1-sol',stream:true})
 const provider=read(prefix+'-final-provider-audit.json');assert.equal(provider.exhausted,false);assert.ok(provider.requests.length>0&&provider.requests.length<=12)
 for(const r of provider.requests)assert.deepEqual({model:r.model,stream:r.streaming,status:r.status,reader:r.response_reader.state,terminal:r.response_reader.terminal.kind},{model:'gpt-6.1-sol',stream:true,status:200,reader:'settled',terminal:'eof'})
 const settled=read(prefix+'-native-host-settled.json')
 for(const key of ['physicalCompletion','outputDrainComplete','requestCleanupComplete'])assert.equal(settled[key],true)
 assert.deepEqual({reason:settled.terminal.reason,exit:settled.terminal.exitCode},{reason:'exited',exit:0})
 const qualified=read(prefix+'-qualified-surface-completion.json');assert.equal(qualified.qualification,'NativeService');assert.equal(qualified.providerEOFRequests,provider.requests.length)
 const cleanup=read(prefix+'-physical-terminal-and-pair-cleanup.json');assert.equal(cleanup.pairedCleanupComplete,true);assert.deepEqual(cleanup.copiedPair.map((e:any)=>e.outcome),['removed','removed'])
 const http=read(prefix+'-http-summary.json'),served=http.requests.find((r:any)=>r.data?.path==='/ui/assets/main--IPEAIl1.js'&&r.data?.status==='completed');assert.equal(served.data.statusCode,200)
 const birth=Number(BigInt(settled.target.processInstanceID.slice(6))/10000n-62135596800000n)
 results.push({stage,session,sources,completed,requests:provider.requests.length,elapsedMs:Date.parse(settled.observedAtUtc)-birth,settled,qualified,served})
}
fs.mkdirSync(path.join(root,'checks'),{recursive:true})
fs.writeFileSync(path.join(root,'checks/runtime-qualification.json'),JSON.stringify({results,boundary:'Actual Provider/Native/completed canonical messages, search/read outcomes and unchanged input bytes only. UI activation, visual ranges and cursor positions are separately reviewed manual screenshots; no UI assertions.'},null,2)+'\n')
console.log(JSON.stringify(results.map(r=>({stage:r.stage,sources:r.sources.length,requests:r.requests,elapsedMs:r.elapsedMs,exit:0}))))
