import fs from 'node:fs'
import path from 'node:path'
const stage=process.argv[2]
if(!['before','after'].includes(stage))throw Error('Exact declared stage required')
const run=`C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/source-cr-location-372-${stage}`
const ready=JSON.parse(fs.readFileSync(path.join(run,'evidence/preflight-ready.json'),'utf8')).preflight
if(ready.credential!=='usable'||ready.catalog!=='projected'||ready.actualModel!=='gpt-6.1-sol'||!ready.streaming)throw Error('Provider qualification required')
const values={
 cr:'开头\r未命中\r前😀MATCH372_A\rtail\r次MATCH372_B',
 mixed:'一\r二\n三\r四\r\n前😀MATCH372_C\nend',
 crlf:'header\r\nprefix\r\n前😀MATCH372_D\r\nend',
 lf:'header\nprefix\n前😀MATCH372_E\nend',
 bom:'\uFEFF前😀MATCH372_F\nend',
 cross:'header\rBEGIN372\rEND372\rtail',
}
const inputs=Object.entries(values).map(([name,text])=>{
 const file=path.join(run,'project/格式',name+'.txt')
 fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,text,{flag:'wx'})
 return {name,path:file,text}
})
const evidence=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/source-cr-location-372',stage)
fs.mkdirSync(evidence,{recursive:true});fs.writeFileSync(path.join(evidence,'authored-inputs.json'),JSON.stringify(inputs,null,2)+'\n',{flag:'wx'})
fs.writeFileSync(path.resolve('.tmp-product-iteration/source-cr-location-372',stage,'main-request.txt'),'请实际依次执行四项工具，保留真实文件来源：\n1. search_code，pattern 为 MATCH372_，path 为 格式。\n2. search_code，pattern 为 BEGIN372\\rEND372，path 为 格式/cross.txt（正则中的反斜杠r匹配回车）。\n3. read 文件 格式/cr.txt，offset=3、limit=1。\n4. read 文件 格式/mixed.txt，offset=5、limit=1。\n最后简短总结工具实际结果，不修改文件，不创建任务，不调用成员。',{flag:'wx'})
console.log(JSON.stringify({stage,files:inputs.map(x=>x.path)}))
