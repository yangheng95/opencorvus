import fs from 'node:fs'
import path from 'node:path'
import {gzipSync,gunzipSync} from 'node:zlib'
const root=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/source-cr-location-372')
const custody=path.resolve('.tmp-product-iteration/source-cr-location-372/full-originals')
const entries=[]
for(const stage of ['before','after'])for(const name of fs.readdirSync(path.join(root,stage)).filter(n=>/^\d\d-.*\.txt$/.test(n))){
 const source=path.resolve(root,stage,name),destination=path.resolve(custody,stage,name),archive=source+'.gz'
 if(!source.startsWith(root+path.sep)||!destination.startsWith(custody+path.sep)||fs.existsSync(destination)||fs.existsSync(archive))throw Error('Exact unique evidence custody required')
 const raw=fs.readFileSync(source),compressed=gzipSync(raw,{level:9})
 if(!gunzipSync(compressed).equals(raw))throw Error('Complete original AX bytes differ')
 fs.writeFileSync(archive,compressed,{flag:'wx'});fs.mkdirSync(path.dirname(destination),{recursive:true});fs.renameSync(source,destination)
 entries.push({source,destination,archive,bytes:raw.length,integrity:'Complete decompressed original bytes equal, including native AX trailing whitespace'})
}
const self=fs.readFileSync(new URL(import.meta.url));fs.writeFileSync(path.join(root,'checks/archive-ax.mjs.gz'),gzipSync(self),{flag:'wx'})
fs.writeFileSync(path.join(root,'checks/ax-archive-receipt.json'),JSON.stringify({entries,boundary:'Raw accessibility observations preserved as exact compressed evidence, not trimmed or used as UI assertions'},null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({records:entries.length,integrity:'Full bytes preserved'}))
