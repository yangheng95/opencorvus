import fs from 'node:fs'
import path from 'node:path'
import {gzipSync,gunzipSync} from 'node:zlib'
import {CredentialRedactor} from '../../packages/opencorvus/script/real-provider-audit'
const root=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/source-cr-location-372')
fs.writeFileSync(path.join(root,'checks/scan-final.ts.gz'),gzipSync(fs.readFileSync(import.meta.path)),{flag:'wx'})
const redactor=new CredentialRedactor()
redactor.collect(JSON.parse(fs.readFileSync('C:/Users/hengu/AppData/Local/opencorvus/data/auth.json','utf8')))
let textFiles=0
for(const entry of fs.readdirSync(root,{recursive:true,withFileTypes:true}).filter(x=>x.isFile())){
 if(entry.name.endsWith('.png'))continue
 const raw=fs.readFileSync(path.join(entry.parentPath,entry.name)),text=(entry.name.endsWith('.gz')?gunzipSync(raw):raw).toString('utf8')
 if(redactor.containsCredential(text))throw Error('Credential found in final evidence')
 textFiles++
}
fs.writeFileSync(path.join(root,'checks/final-credential-scan.json'),JSON.stringify({observedAt:new Date().toISOString(),textFiles,credentialMatches:0,archives:'Full decompressed text, including exact AX observations'},null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({textFiles,credentialMatches:0}))
