import fs from 'node:fs'; import path from 'node:path'; import assert from 'node:assert/strict';
const root=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/locale-bootstrap-377'); const scopes=[];
for(const scope of ['after','failure']){
 const dir=path.join(root,scope),prefix='locale-bootstrap-377-'+scope,read=(n)=>JSON.parse(fs.readFileSync(path.join(dir,n),'utf8'));
 const preflight=read(prefix+'-preflight-ready.json').preflight;
 assert.deepEqual({credential:preflight.credential,catalog:preflight.catalog,model:preflight.actualModel,stream:preflight.streaming},{credential:'usable',catalog:'projected',model:'gpt-6.1-sol',stream:true});
 const provider=read(prefix+'-final-provider-audit.json');assert.equal(provider.exhausted,false);assert.ok(provider.requests.length>0&&provider.requests.length<=12);
 for(const r of provider.requests)assert.deepEqual({model:r.model,stream:r.streaming,status:r.status,reader:r.response_reader.state,terminal:r.response_reader.terminal.kind},{model:'gpt-6.1-sol',stream:true,status:200,reader:'settled',terminal:'eof'});
 const settled=read(prefix+'-native-host-settled.json');for(const key of ['physicalCompletion','outputDrainComplete','requestCleanupComplete'])assert.equal(settled[key],true);assert.deepEqual({reason:settled.terminal.reason,exit:settled.terminal.exitCode},{reason:'exited',exit:0});
 const qualified=read(prefix+'-qualified-surface-completion.json');assert.equal(qualified.qualification,'NativeService');assert.equal(qualified.physicalCompletion,true);
 const http=read(prefix+'-http-summary.json').requests.filter(x=>x.data?.status==='completed');
 const locales=http.filter(x=>x.data.path.startsWith('/ui/i18n/'));assert.equal(locales.length,4);
 assert.deepEqual(locales.map(x=>({path:x.data.path,status:x.data.statusCode})),[0,1].flatMap(()=>[{path:'/ui/i18n/zh-CN.json',status:scope==='after'?200:404},{path:'/ui/i18n/en-US.json',status:200}]));
 let source;
 if(scope==='after'){
  const input=read('authored-inputs.json'),canonical=read('canonical-current-conversations.json'); const sources=canonical.parts.filter(p=>p.type==='source-file');assert.equal(sources.length,1);source=sources[0];
  assert.equal(path.resolve(source.path),path.resolve(input.file));assert.equal(source.title,'嵌套页面.txt');assert.deepEqual(source.range,{startLine:2,endLine:3});assert.equal(source.provider,'opencorvus-read');
  assert.deepEqual(fs.readFileSync(input.file),Buffer.from(input.text));assert.equal(canonical.tools.length,1);const request=JSON.parse(canonical.tools[0].data);assert.equal(request.tool,'read');assert.deepEqual(request.input,{filePath:'嵌套页面.txt',offset:2,limit:2});
  assert.equal(canonical.outcomes[0].outcome,'completed');assert.equal(canonical.outcomes[0].output,`<path>${source.path}</path>\n<type>file</type>\n<content>2: 语言资源现在从正确位置加载。\n3: 这是第二条真实来源内容。\n\n(Showing lines 2-3 of 4. Use offset=4 to continue.)\n</content>`);
  const finals=canonical.messages.filter(m=>m.role==='assistant'&&m.finish==='stop');assert.equal(finals.length,2);for(const m of finals)assert.equal(typeof m.time.completed,'number');
 }else{
  const documents=http.filter(x=>x.data.path==='/ui/inspect/resource/');assert.equal(documents.length,2);for(const d of documents)assert.equal(d.data.statusCode,200);
 }
 const birth=Number(BigInt(settled.target.processInstanceID.slice(6))/10000n-62135596800000n),elapsedMs=Date.parse(settled.observedAtUtc)-birth;assert.ok(elapsedMs<600000);
 scopes.push({scope,requests:provider.requests.length,elapsedMs,source,locales,settled,qualified});
}
fs.mkdirSync(root+'/checks',{recursive:true});fs.writeFileSync(root+'/checks/runtime-qualification.json',JSON.stringify({scopes,boundary:'Actual HTTP requests, canonical Source/ToolOutcome, complete file bytes, Provider and Native settlement; five screenshots manually reviewed separately. No DOM, UI text, rendering or screenshot assertions.'},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(scopes.map(({scope,requests,elapsedMs})=>({scope,requests,elapsedMs}))));
