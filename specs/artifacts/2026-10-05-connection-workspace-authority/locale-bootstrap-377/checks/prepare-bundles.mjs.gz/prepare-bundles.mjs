import fs from 'node:fs'; import path from 'node:path'; import assert from 'node:assert/strict';
const root='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/locale-bootstrap-377-bundle';
if(fs.existsSync(root)) throw Error('Unique bundle required');
for(const scope of ['after','failure']) {
 const bin=path.join(root,scope,'bin'); fs.mkdirSync(bin,{recursive:true});
 const src='C:/Users/hengu/.bun/bin/bun.exe',dest=path.join(bin,'bun.exe'); fs.copyFileSync(src,dest,fs.constants.COPYFILE_EXCL); assert.deepEqual(fs.readFileSync(src),fs.readFileSync(dest));
 const original="$taskBun = 'C:/Users/hengu/.bun/bin/bun.exe'";
 const launcher=fs.readFileSync('.tmp-product-iteration/live-sol-launch.ps1','utf8'); assert.equal(launcher.split(original).length,2);
 fs.writeFileSync('.tmp-product-iteration/live-sol-locale-377-'+scope+'.ps1',launcher.replace(original,"$taskBun = '"+dest.replaceAll('\\','/')+"'"),{flag:'wx'});
 const scratch='.tmp-product-iteration/locale-bootstrap-377/'+scope; fs.writeFileSync(scratch+'/builtin.json',JSON.stringify({kind:'builtin',id:'base',namespace:'builtin'}));
 for(const filename of ['archive-live.ts','archive-piles.ps1']) {let text=fs.readFileSync('.tmp-product-iteration/ui-resource-snapshot-376/after/'+filename,'utf8').replaceAll('ui-resource-snapshot-376-after','locale-bootstrap-377-'+scope).replaceAll('ui-resource-snapshot-376','locale-bootstrap-377');fs.writeFileSync(scratch+'/'+filename,text,{flag:'wx'});}
}
console.log(JSON.stringify({root,binaryBytes:fs.statSync(root+'/after/bin/bun.exe').size}));
