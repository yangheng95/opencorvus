import fs from 'node:fs';
const base='specs/artifacts/2026-10-05-connection-workspace-authority/locale-bootstrap-377';
for(const scope of ['after','failure']) {
 const root=base+'/'+scope, p='locale-bootstrap-377-'+scope;
 const c=JSON.parse(fs.readFileSync(root+'/canonical-current-conversations.json','utf8'));
 console.log(JSON.stringify({scope,sources:c.parts.filter(x=>x.type==='source-file'),tools:c.tools.map(x=>JSON.parse(x.data)),outcomes:c.outcomes,finals:c.messages.filter(x=>x.role==='assistant'&&x.finish==='stop').map(x=>({id:x.id,time:x.time}))}));
 const h=JSON.parse(fs.readFileSync(root+'/'+p+'-http-summary.json','utf8'));
 console.log(JSON.stringify({scope,requests:h.requests.filter(x=>x.data?.status==='completed'&&(x.data?.path?.includes('/i18n/')||x.data?.path==='/ui/inspect/resource/')).map(x=>({time:x.time,...x.data}))}));
}
