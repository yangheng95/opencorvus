import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
const root=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/source-persistence-381')
const folder=path.join(root,'after'), prefix='source-persistence-381-after'
const read=name=>JSON.parse(fs.readFileSync(path.join(folder,name),'utf8'))
const c=read('canonical-current-conversations.json'), provider=read(prefix+'-final-provider-audit.json')
const owner=read(prefix+'-launch-owner.json'), native=read(prefix+'-native-host-settled.json')
const closure=read(prefix+'-physical-terminal-and-pair-cleanup.json')
const tools=c.tools.map(row=>({...row,data:JSON.parse(row.data)}))
const completed=tools.map(row=>{
  const outcome=c.outcomes.find(item=>item.requestPartID===row.id)
  assert.equal(outcome.outcome,'completed')
  assert.equal(row.data.tool,'webfetch')
  assert.deepEqual(row.data.input,{url:'https://example.com',format:'markdown'})
  const sources=c.parts.filter(part=>part.messageID===row.message_id&&part.type==='source-url')
  assert.equal(sources.length,1)
  assert.equal(sources[0].title,'Example Domain')
  assert.equal(sources[0].url,'https://example.com/')
  return {messageID:row.message_id,toolRequestID:row.id,sourceID:sources[0].id,sourceIdentity:sources[0].sourceId,title:sources[0].title,url:sources[0].url}
})
assert.equal(native.terminal.exitCode,0)
assert.equal(native.physicalCompletion,true)
assert.equal(native.outputDrainComplete,true)
assert.equal(native.requestCleanupComplete,true)
assert.equal(closure.physicalCompletion,true)
assert.equal(closure.pairedCleanupComplete,true)
const requestAgents={}
for(const request of provider.requests){
  assert.equal(request.model,'gpt-6.1-sol');assert.equal(request.streaming,true)
  assert.equal(request.status,200);assert.equal(request.response_reader.terminal.kind,'eof')
  const name=request.response_reader.requestContext?.streamRequest?.agentID??'unattributed'
  requestAgents[name]=(requestAgents[name]??0)+1
}
const result={
  completedSourceFacts:completed,requestedWebfetchCalls:4,actualCompletedWebfetchCalls:completed.length,
  fullQualification:provider.exhausted===false&&completed.length===4,
  actualLauncherExit:1,qualificationError:'OWNED_PROVIDER_COMPLETION_INVALID',
  providerBudget:provider.maxRequests,providerRequests:provider.requests.length,providerExhausted:provider.exhausted,requestAgents,
  actualAssistantErrors:c.messages.filter(message=>message.error).map(message=>({id:message.id,error:message.error})),
  nativeMilliseconds:Date.parse(native.observedAtUtc)-owner.targetBirthAtMs,
  physicalCompletion:true,outputDrainComplete:true,requestCleanupComplete:true,pairedCleanupComplete:true,
  boundary:'Backend canonical data and actual runtime checker only; screenshots and navigation were reviewed manually. Same-step two-call end-to-end remains unmet after the fixed cumulative request budget was reached.'
}
fs.writeFileSync(path.join(root,'runtime-review.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify(result))
