OpenCorvus Log Support Bundle
==============================

Exported: 2026-10-07T09:18:12.310Z
OpenCorvus: local (local)
Runtime: Bun 1.3.14, win32/x64
Files: 1
Lines: 197 parsed=197 unparsed=0

Contents
--------
- manifest.json: structured bundle metadata and per-file diagnostics.
- logs/raw/: byte-exact retained Pino JSON log files.
- logs/formatted/: deterministic human-readable renderings of the same files.

Unparsed records are preserved and marked with their original line number.
Raw and formatted logs can contain local paths, project content, prompts, and error details.
Review the bundle before sharing it outside your organization.
