import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';import{createRequire}from'node:module';
const require=createRequire(new URL('../../packages/overlay/package.json',import.meta.url));const{marked}=require('marked');
const root=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/source-link-base-379'),scopes=[];
const page='https://www.w3.org/Provider/Style/URI.html';
for(const scope of ['before','after']){
 const dir=path.join(root,scope),prefix='source-link-base-379-'+scope,read=(n)=>JSON.parse(fs.readFileSync(path.join(dir,n),'utf8'));
 const canonical=read('canonical-current-conversations.json'),sources=canonical.parts.filter(p=>p.type==='source-url');assert.equal(sources.length,1);assert.equal(canonical.tools.length,1);assert.equal(canonical.outcomes.length,1);
 assert.deepEqual({url:sources[0].url,title:sources[0].title,provider:sources[0].provider},{url:page,title:"Hypertext Style: Cool URIs don't change.",provider:'opencorvus-webfetch'});
 const request=JSON.parse(canonical.tools[0].data);assert.equal(request.tool,'webfetch');assert.deepEqual(request.input,{url:page,format:'markdown'});
 const outcome=canonical.outcomes[0];assert.equal(outcome.requestPartID,canonical.tools[0].id);assert.equal(outcome.outcome,'completed');
 const links=[];marked.walkTokens(marked.lexer(outcome.output),token=>{if(token.type==='link')links.push({text:token.text,href:token.href})});
 const expected={
  'Etiquette for server administrators':scope==='after'?'https://www.w3.org/Provider/Style/Etiquette.html':'Etiquette.html',
  'Structure of your work':scope==='after'?'https://www.w3.org/Provider/Style/Structure.html':'Structure.html',
  'how?':scope==='after'?page+'#remove':'#remove',
  'Tim BL':scope==='after'?'https://www.w3.org/People/Berners-Lee/':'../../People/Berners-Lee/',
 };
 for(const[text,href]of Object.entries(expected))assert.deepEqual(links.filter(l=>l.text===text),[{text,href}]);
 const complete=canonical.messages.filter(m=>m.role==='assistant'&&m.finish==='stop');assert.equal(complete.length,2);for(const m of complete)assert.equal(typeof m.time.completed,'number');
 const final=complete.at(-1);const reply=canonical.parts.filter(p=>p.type==='text'&&p.messageID===final.id).map(p=>p.text).join('');assert.equal(reply,`[Etiquette for server administrators](${expected['Etiquette for server administrators']})`);
 const preflight=read(prefix+'-preflight-ready.json').preflight;assert.deepEqual({credential:preflight.credential,catalog:preflight.catalog,model:preflight.actualModel,stream:preflight.streaming},{credential:'usable',catalog:'projected',model:'gpt-6.1-sol',stream:true});
 const provider=read(prefix+'-final-provider-audit.json');assert.equal(provider.exhausted,false);assert.ok(provider.requests.length>0&&provider.requests.length<=12);for(const r of provider.requests)assert.deepEqual({model:r.model,stream:r.streaming,status:r.status,reader:r.response_reader.state,terminal:r.response_reader.terminal.kind},{model:'gpt-6.1-sol',stream:true,status:200,reader:'settled',terminal:'eof'});
 const settled=read(prefix+'-native-host-settled.json');for(const key of ['physicalCompletion','outputDrainComplete','requestCleanupComplete'])assert.equal(settled[key],true);assert.deepEqual({reason:settled.terminal.reason,exit:settled.terminal.exitCode},{reason:'exited',exit:0});const qualified=read(prefix+'-qualified-surface-completion.json');assert.equal(qualified.qualification,'NativeService');assert.equal(qualified.physicalCompletion,true);
 const birth=Number(BigInt(settled.target.processInstanceID.slice(6))/10000n-62135596800000n),elapsedMs=Date.parse(settled.observedAtUtc)-birth;assert.ok(elapsedMs<600000);
 scopes.push({scope,sources,links,reply,requests:provider.requests.length,elapsedMs,settled,qualified});
}
fs.mkdirSync(root+'/checks',{recursive:true});fs.writeFileSync(root+'/checks/runtime-qualification.json',JSON.stringify({scopes,boundary:'Real canonical Source/ToolRequest/ToolOutcome and model reply link data, parsed by the existing Markdown library, plus Provider/Native settlement. Four screenshots and click results reviewed manually. No DOM/render/screenshot UI assertions.'},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(scopes.map(({scope,requests,elapsedMs})=>({scope,requests,elapsedMs}))));
