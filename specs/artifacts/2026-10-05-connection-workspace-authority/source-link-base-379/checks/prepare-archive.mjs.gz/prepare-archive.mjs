import fs from 'node:fs';
const old='.tmp-product-iteration/source-charset-378/archive.ts',file='.tmp-product-iteration/source-link-base-379/archive.ts';
fs.writeFileSync(file,fs.readFileSync(old,'utf8').replaceAll('source-charset-378','source-link-base-379'),{flag:'wx'});
