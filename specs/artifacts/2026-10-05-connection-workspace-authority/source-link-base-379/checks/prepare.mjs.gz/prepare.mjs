import fs from 'node:fs';
for(const scope of ['before','after']){
 const p='.tmp-product-iteration/source-link-base-379/'+scope;
 fs.writeFileSync(p+'/builtin.json',JSON.stringify({kind:'builtin',id:'base',namespace:'builtin'}));
 for(const f of ['archive-live.ts','archive-piles.ps1']){const s=fs.readFileSync('.tmp-product-iteration/source-charset-378/'+scope+'/'+f,'utf8').replaceAll('source-charset-378','source-link-base-379');fs.writeFileSync(p+'/'+f,s,{flag:'wx'});}
 fs.copyFileSync('.tmp-product-iteration/live-sol-locale-377-after.ps1',p+'/launcher.ps1',fs.constants.COPYFILE_EXCL);
}
