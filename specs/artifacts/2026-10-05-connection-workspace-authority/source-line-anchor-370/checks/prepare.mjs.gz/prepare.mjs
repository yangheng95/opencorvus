import fs from 'node:fs'
import path from 'node:path'
const stage=process.argv[2]
if(!['before','after'].includes(stage))throw Error('Exact declared stage required')
const run=`C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/source-line-anchor-370-${stage}`
const ready=JSON.parse(fs.readFileSync(path.join(run,'evidence/preflight-ready.json'),'utf8'))
if(ready.preflight.credential!=='usable'||ready.preflight.catalog!=='projected'||ready.preflight.actualModel!=='gpt-6.1-sol'||!ready.preflight.streaming)throw Error('Actual credential/catalog/model/stream qualification required')
const file=path.join(run,'project/资料/行号示例.txt')
const text=Array.from({length:40},(_,i)=>i===29?'before中😀MATCH370_首行':i===30?'范围内第二行':i===31?'范围内第三行':`记录第${i+1}行`).join('\n')
fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,text,{flag:'wx'})
const evidence=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/source-line-anchor-370',stage)
fs.mkdirSync(evidence,{recursive:true});fs.writeFileSync(path.join(evidence,'authored-inputs.json'),JSON.stringify({path:file,text,line:30,column:10,web:'https://github.com/microsoft/vscode/blob/main/README.md#L1-L3'},null,2)+'\n',{flag:'wx'})
const scratch=path.resolve('.tmp-product-iteration/source-line-anchor-370',stage)
fs.writeFileSync(path.join(scratch,'main-request.txt'),'请实际用 search_code 在“资料/行号示例.txt”搜索 MATCH370，保留真实来源。随后输出下面四项Markdown列表，保留其引用格式和目标：\n- 行内引用：`资料/行号示例.txt#L30`\n- [行范围](资料/行号示例.txt#L30-L32)\n- [冒号对照](资料/行号示例.txt:30:10)\n- [外部网页](https://github.com/microsoft/vscode/blob/main/README.md#L1-L3)\n不要访问外部网页、不修改文件、不创建任务、不调用成员。',{flag:'wx'})
fs.writeFileSync(path.join(scratch,'side-request.txt'),'请在本侧聊实际用 search_code 在“资料/行号示例.txt”搜索 MATCH370，保留真实来源。最终只输出Markdown链接 [侧聊范围](资料/行号示例.txt#L30-L32)。不要修改文件、创建任务或调用成员。',{flag:'wx'})
console.log(JSON.stringify({stage,file,line:30,column:10}))
