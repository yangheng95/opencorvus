import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import {Database} from 'bun:sqlite'
const root=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/source-line-anchor-370')
const stages=[
 {name:'before',handle:48162,asset:'main-BR2lLe8z.js',requests:5,messages:['msg_g0VXsi2Kw00xR4Z0orpu'],finals:['msg_g0VXsi3SL00I73pcJ226']},
 {name:'after',handle:66181,asset:'main-w4chjmbj.js',requests:9,messages:['msg_g0VXsjWxz00bq62ftSiZ','msg_g0VXsjo8C0128PQ5kzbX','msg_g0VXsjuFV00hd1ObzQEC'],finals:['msg_g0VXsjY7i00JjGbJvMhg','msg_g0VXsjo8C02Pa1Rg9lv8','msg_g0VXsjvGW00Yt4oJNrmZ']},
]
const results=[]
for(const stage of stages){
 const folder=path.join(root,stage.name),label='source-line-anchor-370-'+stage.name
 const read=(name:string)=>JSON.parse(fs.readFileSync(path.join(folder,name),'utf8'))
 const canonical=read('canonical-current-conversations.json'),input=read('authored-inputs.json')
 assert.deepEqual(fs.readFileSync(input.path),Buffer.from(input.text))
 const run=`C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/${label}`
 const db=new Database(path.join(run,'runtime/data/opencorvus.db'),{readonly:true})
 let rows:any[]
 try{db.exec('BEGIN');rows=(db.query("SELECT p.id,p.message_id,m.session_id,p.data FROM part p JOIN message m ON m.id=p.message_id WHERE json_extract(p.data,'$.type')='source-file' ORDER BY p.time_created,p.id").all() as any[]).map(r=>({...r,data:JSON.parse(r.data)}))}finally{db.exec('ROLLBACK');db.close()}
 assert.equal(rows.length,stage.messages.length);assert.deepEqual(rows.map(r=>r.message_id),stage.messages)
 assert.equal(canonical.tools.length,stage.messages.length)
 const calls=[]
 for(const row of rows){
  const source=row.data;assert.equal(source.path,path.resolve(input.path));assert.equal(source.provider,'opencorvus-search-code')
  assert.deepEqual(source.range,{startLine:30,endLine:30,startColumn:10});assert.equal(source.snippet,input.text.split('\n')[29])
  assert.deepEqual(canonical.parts.find((p:any)=>p.id===row.id).range,source.range)
  const tool=canonical.tools.find((t:any)=>t.message_id===row.message_id),request=JSON.parse(tool.data)
  assert.equal(request.tool,'search_code');assert.deepEqual(request.input,{pattern:'MATCH370',path:'资料/行号示例.txt'})
  const outcome=canonical.outcomes.find((o:any)=>o.requestPartID===tool.id)
  assert.equal(outcome.outcome,'completed');assert.equal(outcome.output,`Found 1 matches\n${source.path}:\n  Line 30: ${source.snippet}`)
  calls.push({sourcePartID:row.id,sourceID:source.sourceId,sessionID:row.session_id,messageID:row.message_id,callID:request.callID,range:source.range})
 }
 if(stage.name==='after'){
  const payload=(r:any)=>({sourceId:r.data.sourceId,path:r.data.path,range:r.data.range,snippet:r.data.snippet})
  assert.deepEqual(payload(rows[0]),payload(rows[1]));assert.equal(calls[0]!.callID,calls[1]!.callID)
 }
 const completed=stage.finals.map(id=>canonical.messages.find((m:any)=>m.id===id))
 for(const message of completed){assert.equal(message.finish,'stop');assert.equal(typeof message.time.completed,'number')}
 const preflight=read(label+'-preflight-ready.json').preflight
 assert.deepEqual({credential:preflight.credential,catalog:preflight.catalog,model:preflight.actualModel,stream:preflight.streaming},{credential:'usable',catalog:'projected',model:'gpt-6.1-sol',stream:true})
 const provider=read(label+'-final-provider-audit.json');assert.deepEqual({count:provider.requests.length,exhausted:provider.exhausted},{count:stage.requests,exhausted:false})
 for(const r of provider.requests)assert.deepEqual({model:r.model,stream:r.streaming,status:r.status,reader:r.response_reader.state,terminal:r.response_reader.terminal.kind},{model:'gpt-6.1-sol',stream:true,status:200,reader:'settled',terminal:'eof'})
 const settled=read(label+'-native-host-settled.json')
 for(const key of ['physicalCompletion','outputDrainComplete','requestCleanupComplete'])assert.equal(settled[key],true)
 assert.deepEqual({reason:settled.terminal.reason,exit:settled.terminal.exitCode},{reason:'exited',exit:0})
 const qualified=read(label+'-qualified-surface-completion.json');assert.equal(qualified.qualification,'NativeService');assert.equal(qualified.providerEOFRequests,stage.requests);assert.equal(qualified.physicalCompletion,true)
 const cleanup=read(label+'-physical-terminal-and-pair-cleanup.json');assert.equal(cleanup.pairedCleanupComplete,true);assert.deepEqual(cleanup.copiedPair.map((e:any)=>e.outcome),['removed','removed'])
 const http=read(label+'-http-summary.json'),served=http.requests.find((r:any)=>r.data?.path==='/ui/assets/'+stage.asset&&r.data?.status==='completed');assert.equal(served.data.statusCode,200)
 const birth=Number(BigInt(settled.target.processInstanceID.slice(6))/10000n-62135596800000n)
 results.push({...stage,launcherExit:0,calls,completed,modelTexts:canonical.parts.filter((p:any)=>stage.finals.includes(p.messageID)&&p.type==='text'),elapsedMs:Date.parse(settled.observedAtUtc)-birth,qualified,settled,served})
}
fs.mkdirSync(path.join(root,'checks'),{recursive:true})
fs.writeFileSync(path.join(root,'checks/runtime-qualification.json'),JSON.stringify({results,boundary:'Actual Source/ToolOutcome/completed Message, full authored file bytes and provider/native receipts only. Before UI navigation failure and after manual line/range activation are separate screenshots, without UI assertions. External landing was later manually confirmed in actual new tab 192; see after/07-external-page, without a replacement goto.'},null,2)+'\n')
console.log(JSON.stringify(results.map(r=>({stage:r.name,sources:r.calls.length,requests:r.requests,elapsedMs:r.elapsedMs,exit:0}))))
