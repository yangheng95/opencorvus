import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'

const root=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/source-surfaces-356')
const read=(name:string)=>JSON.parse(fs.readFileSync(path.join(root,name),'utf8'))
const canonical=read('live-02/canonical-current-conversations.json')
const prefix='live-02/source-surfaces-356-live-02-'
const qualification=read(prefix+'qualified-surface-completion.json')
const provider=read(prefix+'final-provider-audit.json')
const preflight=read(prefix+'preflight-ready.json').preflight
const physical=read(prefix+'physical-terminal-and-pair-cleanup.json')
const inputs=read('input-documents-live-02.json')
const copies=read('copy-observations-live-02.json')
const main=canonical.sessions.find((s:any)=>s.id==='ses_-zUS8zzerzzqG425PLRl')
const side=canonical.sessions.find((s:any)=>s.id==='ses_-zUS8zD0VzzphcUQjhbC')
assert.equal(JSON.parse(side.metadata).sideChat.sourceSessionID,main.id)
assert.equal(side.project_id,main.project_id)
assert.equal(side.directory,main.directory)
assert.deepEqual(preflight,{sessionID:'ses_hZHFq7t60BvtxAtXtrL9',credential:'usable',catalog:'projected',actualModel:'gpt-6.1-sol',streaming:true})
assert.equal(qualification.qualification,'NativeService')
assert.equal(qualification.physicalCompletion,true)
assert.equal(qualification.providerEOFRequests,9)
assert.equal(physical.physicalCompletion,true)
assert.equal(physical.pairedCleanupComplete,true)
assert.equal(provider.requests.length,9)
for(const request of provider.requests){
  assert.equal(request.model,'gpt-6.1-sol')
  assert.equal(request.streaming,true)
  assert.equal(request.status,200)
  assert.equal(request.response_reader.state,'settled')
  assert.equal(request.response_reader.terminal.kind,'eof')
}
for(const input of inputs){
  const lines=fs.readFileSync(input.path,'utf8').trimEnd().split(/\r?\n/)
  assert.deepEqual(lines,input.lines)
  assert.equal(lines.length,33)
  assert.equal(input.matches,32)
}
const reports=[]
for(const [surface,session,toolID,finalID] of [
  ['main',main,'prt_g0VXr04eN00xdfWRnt5H','msg_g0VXr050D00YReL7dCiK'],
  ['side',side,'prt_g0VXr0uLd00bkTRmqq2J','msg_g0VXr0uaY00dJpvLU7ii'],
] as const){
  const tool=canonical.tools.find((t:any)=>t.id===toolID)
  const request=JSON.parse(tool.data)
  assert.equal(request.tool,'search_code')
  assert.deepEqual(request.input,{pattern:'SOURCE356',path:'资料/研究记录',include:'*.md'})
  const message=canonical.messages.find((m:any)=>m.id===tool.message_id)
  assert.equal(message.sessionID,session.id)
  const sources=canonical.parts.filter((p:any)=>p.messageID===message.id&&p.type==='source-file')
  assert.equal(sources.length,64)
  const outcome=canonical.outcomes.find((o:any)=>o.requestPartID===toolID)
  assert.equal(outcome.outcome,'completed')
  assert.equal(outcome.metadata.matches,64)
  const files=inputs.map((input:any)=>{
    const group=sources.filter((s:any)=>s.path===input.path)
    assert.equal(group.length,32)
    assert.deepEqual(group.map((s:any)=>s.range).sort((a:any,b:any)=>a.startLine-b.startLine),Array.from({length:32},(_,i)=>({startLine:i+2,endLine:i+2})))
    for(const source of group){
      assert.equal(source.provider,'opencorvus-search-code')
      assert.equal(source.title,path.basename(input.path))
      assert.ok(outcome.output.includes(`Line ${source.range.startLine}: ${input.lines[source.range.startLine-1]}`))
    }
    const clipboard=copies.find((c:any)=>c.surface===surface&&c.value===input.path+':20')
    assert.equal(clipboard.value,input.path+':20')
    return {path:input.path,sourceCount:group.length,range:{startLine:2,endLine:33},clipboard:clipboard.value,line20:input.lines[19]}
  })
  const final=canonical.messages.find((m:any)=>m.id===finalID)
  assert.equal(final.sessionID,session.id)
  assert.equal(final.providerID,'openai')
  assert.equal(final.modelID,'gpt-6.1-sol')
  assert.equal(final.finish,'stop')
  assert.ok(final.time.completed>=final.time.created)
  const assistantRequests=provider.requests.filter((r:any)=>r.response_reader.requestContext?.sessionID===session.id&&[message.id,final.id].includes(r.response_reader.requestContext?.activity?.assistantMessageID))
  assert.equal(assistantRequests.length,2)
  assert.deepEqual(assistantRequests.map((r:any)=>r.response_reader.requestContext.activity.assistantMessageID).sort(),[message.id,final.id].sort())
  for(const request of assistantRequests)assert.equal(request.response_reader.requestContext.streamRequest.agentID,final.agent)
  reports.push({surface,sessionID:session.id,projectID:session.project_id,toolID,sourceMessageID:message.id,finalMessageID:final.id,sourceCount:sources.length,files,assistantRequestCount:assistantRequests.length})
}
const result={observedAtUtc:new Date().toISOString(),result:'passed',boundary:'Actual canonical completed tool outcomes and Source Parts, original authored disk inputs, native clipboard receipts, actual streaming provider and physical settlement. UI layout was manually observed separately; this checker makes no UI assertions.',mainAndSide:reports,sideInheritance:{sourceSessionID:main.id,inheritedMessageIDs:JSON.parse(side.metadata).sideChat.inheritedMessageIDs,qualification:'Inherited context remains canonical; fresh Side sources are qualified by its own actual search request and assistant Message.'},providerRequestCount:provider.requests.length,preflight,qualification,physicalCompletion:physical.physicalCompletion,pairedCleanupComplete:physical.pairedCleanupComplete}
fs.writeFileSync(path.join(root,'actual-sources-check.json'),JSON.stringify(result,null,2)+'\n')
console.log(JSON.stringify({result:result.result,sources:reports.map(r=>({surface:r.surface,count:r.sourceCount})),providerRequestCount:result.providerRequestCount,physicalCompletion:true}))
