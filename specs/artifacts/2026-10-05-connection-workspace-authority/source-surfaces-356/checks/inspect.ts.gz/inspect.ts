import fs from 'node:fs'
import {Database} from 'bun:sqlite'
const which=process.argv[2]??'02'
if(!['01','02'].includes(which))throw Error('Exact owned source scope required')
const run=`C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/source-surfaces-356-live-${which}`
const owner=JSON.parse(fs.readFileSync(run+'/launch-owner.json','utf8'))
const db=new Database(run+'/runtime/data/opencorvus.db',{readonly:true})
db.exec('BEGIN')
try{
 const sessions=db.query('SELECT id,project_id,parent_id,directory,kind,title,metadata FROM session ORDER BY time_created,id').all()
 const messages=(db.query('SELECT id,session_id,data FROM message ORDER BY time_created,id').all() as any[]).map(m=>({id:m.id,sessionID:m.session_id,...JSON.parse(m.data)}))
 const sources=(db.query("SELECT id,message_id,data FROM part WHERE json_extract(data,'$.type')='source-file' ORDER BY time_created,id").all() as any[]).map(p=>({id:p.id,messageID:p.message_id,...JSON.parse(p.data)}))
 const tools=(db.query('SELECT r.id,r.message_id,r.data,o.data AS outcome FROM tool_part_request r LEFT JOIN tool_part_outcome o ON o.request_part_id=r.id ORDER BY r.time_created,r.id').all() as any[]).map(p=>({id:p.id,messageID:p.message_id,data:JSON.parse(p.data),outcome:p.outcome?JSON.parse(p.outcome):null}))
 const result={observedAtUtc:new Date().toISOString(),secondsLeft:Math.round((owner.nativeDeadlineAt-Date.now())/1000),sessions,messages,sources,tools}
 fs.appendFileSync(`D:/myhexin-local/opencorvus/.tmp-product-iteration/source-surfaces-356/observations-${which}.jsonl`,JSON.stringify(result)+'\n')
 console.log(JSON.stringify({at:result.observedAtUtc,secondsLeft:result.secondsLeft,sessions,assistants:messages.filter(m=>m.role==='assistant').map(m=>({id:m.id,sessionID:m.sessionID,finish:m.finish,time:m.time,error:m.error})),sourceCounts:[...new Set(sources.map(p=>p.messageID))].map(id=>({messageID:id,count:sources.filter(p=>p.messageID===id).length})),tools:tools.map(p=>({id:p.id,tool:p.data.tool,input:p.data.input,outcome:p.outcome?.outcome}))}))
}finally{db.exec('ROLLBACK');db.close()}
