$ErrorActionPreference='Stop'
$taskRun='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/source-surfaces-356-live-02'
$taskReady=Get-Content (Join-Path $taskRun 'evidence/preflight-ready.json') -Raw|ConvertFrom-Json
if($taskReady.preflight.credential -ne 'usable' -or $taskReady.preflight.catalog -ne 'projected' -or $taskReady.preflight.actualModel -ne 'gpt-6.1-sol' -or !$taskReady.preflight.streaming){throw 'Exact live model preflight required'}
$taskRecords=@()
foreach($taskCase in @(@('候选方案甲','甲'),@('候选方案乙','乙'))){
 $taskDir=Join-Path $taskRun ('project/资料/研究记录/'+$taskCase[0])
 New-Item -ItemType Directory -Path $taskDir -Force|Out-Null
 $taskPath=Join-Path $taskDir '来源记录_同名文件的行号定位_读取范围与复制操作核对_实际来源说明.md'
 if(Test-Path -LiteralPath $taskPath){throw 'Fresh authored input required'}
 $taskLines=@('# 只读资料：来源定位要求与真实操作结果分别核对。')
 $taskLines+=1..32|ForEach-Object{'SOURCE356 '+$taskCase[1]+('记录{0:D2}：同名来源须区分目录，本条原始内容位于第{1}行；复制位置后仍应保持这一范围。' -f $_,($_+1))}
 [IO.File]::WriteAllText($taskPath,($taskLines -join "`n")+"`n",[Text.UTF8Encoding]::new($false))
 $taskRecords+=@{path=$taskPath;lines=$taskLines;matches=32}
}
[IO.File]::WriteAllText('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-05-connection-workspace-authority/source-surfaces-356/input-documents-live-02.json',($taskRecords|ConvertTo-Json -Depth 5)+"`n",[Text.UTF8Encoding]::new($false))
Write-Output 'Two actual Markdown files prepared, 32 search matches each.'
