import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import { gzipSync, gunzipSync } from 'node:zlib'
import { CredentialRedactor } from '../../packages/opencorvus/script/real-provider-audit'
const root=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/source-dense-live-346')
const scratch=path.resolve('.tmp-product-iteration/source-dense-live-346')
const redactor=new CredentialRedactor()
redactor.collect(JSON.parse(fs.readFileSync('C:/Users/hengu/AppData/Local/opencorvus/data/auth.json','utf8')))
fs.mkdirSync(path.join(root,'checks'),{recursive:true})
const save=(name:string,value:unknown)=>fs.writeFileSync(path.join(root,name),redactor.redact(JSON.stringify(value,null,2))+'\n',{flag:'wx'})
const archives:any[]=[]
function archive(original:string,destination:string){
 const text=redactor.redact(fs.readFileSync(original,'utf8')), raw=Buffer.from(text), zipped=gzipSync(raw,{level:9})
 assert.equal(gunzipSync(zipped).equals(raw),true)
 fs.writeFileSync(path.join(root,destination+'.gz'),zipped,{flag:'wx'})
 archives.push({source:original,archive:destination+'.gz',bytes:raw.length,compressedBytes:zipped.length,integrity:'Complete decompressed bytes equal actual credential-redacted original'})
}
const runs=[]
for(const [stage,handle,exitCode] of [['01',3385,1],['02',54052,0]] as const){
 const label=`source-dense-live-346-live-${stage}`, run=`C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-12/${label}`, dir=path.join(root,'live-'+stage)
 const owner=JSON.parse(fs.readFileSync(path.join(run,'launch-owner.json'),'utf8'))
 const settled=JSON.parse(fs.readFileSync(path.join(run,'evidence/native-host-settled.json'),'utf8'))
 const audit=JSON.parse(fs.readFileSync(path.join(dir,label+'-final-provider-audit.json'),'utf8'))
 const canonical=JSON.parse(fs.readFileSync(path.join(dir,'canonical-current-conversations.json'),'utf8'))
 const preflight=JSON.parse(fs.readFileSync(path.join(run,'evidence/preflight-ready.json'),'utf8'))
 assert.equal(preflight.preflight.credential,'usable');assert.equal(preflight.preflight.catalog,'projected');assert.equal(preflight.preflight.actualModel,'gpt-6.1-sol');assert.equal(preflight.preflight.streaming,true)
 assert.equal(settled.physicalCompletion,true);assert.equal(settled.outputDrainComplete,true);assert.equal(settled.requestCleanupComplete,true)
 const pair=JSON.parse(fs.readFileSync(path.join(dir,label+'-physical-terminal-and-pair-cleanup.json'),'utf8'))
 assert.equal(pair.pairedCleanupComplete,true)
 for(const request of audit.requests){assert.equal(request.model,'gpt-6.1-sol');assert.equal(request.streaming,true);assert.equal(request.status,200);assert.equal(request.response_reader.terminal.kind,'eof');assert.equal(request.response_reader.requestContext.streamRequest.apiModelID,'gpt-6.1-sol')}
 const inputFile=path.join(run,'project/资料/来源审阅记录_重复标题与准确行号.md')
 assert.equal(fs.readFileSync(inputFile,'utf8'),fs.readFileSync(path.join(root,'input-document.md'),'utf8'))
 const tools=canonical.tools.map((row:any)=>({id:row.id,messageID:row.message_id,...JSON.parse(row.data)}))
 const sources=canonical.parts.filter((p:any)=>p.type==='source-file')
 for(const source of sources)assert.equal(path.resolve(source.path),path.resolve(inputFile))
 const groups=tools.map((tool:any)=>({messageID:tool.messageID,tool:tool.tool,input:tool.input,lines:sources.filter((p:any)=>p.messageID===tool.messageID).map((p:any)=>p.range?.startLine??null)}))
 if(stage==='01')assert.deepEqual(groups.map((g:any)=>g.lines),[Array.from({length:24},(_,i)=>i+2),[null],Array.from({length:11},(_,i)=>i+11)])
 else assert.deepEqual(groups.map((g:any)=>g.lines),[Array.from({length:11},(_,i)=>i+11),Array.from({length:11},(_,i)=>i+11)])
 const assistants=canonical.messages.filter((m:any)=>m.role==='assistant')
 for(const message of assistants)assert.equal(typeof message.time.completed,'number')
 const nativeBirth=Number(BigInt(owner.nativeTarget.processInstanceID.slice(6))/10000n-62135596800000n)
 const log=fs.readFileSync(path.join(dir,label+'-runtime.log'),'utf8')
 const served=log.split(/\r?\n/).filter(Boolean).map(l=>JSON.parse(l)).filter(x=>x.service==='server'&&x.data?.status==='completed'&&['/ui/assets/main-tuh6dcX2.js','/ui/assets/main-COLMTZiU.js'].includes(x.data.path)).map(x=>({path:x.data.path,statusCode:x.data.statusCode}))
 assert.ok(served.some((x:any)=>x.path==='/ui/assets/main-COLMTZiU.js'&&x.statusCode===200))
 const chainFiles=fs.readdirSync(dir).filter(n=>n.startsWith(label+'-chain-supervision-')&&n.endsWith('.json')).sort()
 const entries=chainFiles.map(name=>{const text=redactor.redact(fs.readFileSync(path.join(dir,name),'utf8'));assert.equal(JSON.parse(text).occurrence,owner.occurrence);return {name,text}})
 const raw=Buffer.from(JSON.stringify(entries)), zipped=gzipSync(raw,{level:9});assert.equal(gunzipSync(zipped).equals(raw),true)
 fs.writeFileSync(path.join(dir,'supervision-chain.json.gz'),zipped,{flag:'wx'})
 const privateChain=path.join(scratch,'original-supervision-'+stage);fs.mkdirSync(privateChain,{recursive:true})
 for(const name of chainFiles)fs.renameSync(path.join(dir,name),path.join(privateChain,name))
 for(const name of [label+'-runtime.log',label+'-stdout.log',label+'-stderr.log',label+'-unknown-timestamp.log']){
  archive(path.join(dir,name),'live-'+stage+'/'+name)
  fs.renameSync(path.join(dir,name),path.join(scratch,name))
 }
 runs.push({stage,initialHandle:handle,actualLauncherExitCode:exitCode,qualification:stage==='01'?'OWNED_QUALIFICATION_BOUNDARY_REACHED':'NativeService completion qualified',occurrence:owner.occurrence,elapsedMs:Date.parse(settled.observedAtUtc)-nativeBirth,providerRequests:audit.requests.length,allActualRequests:'openai/gpt-6.1-sol streaming HTTP200 EOF',groups,assistantTextParts:canonical.parts.filter((p:any)=>p.type==='text'&&assistants.some((m:any)=>m.id===p.messageID)).map((p:any)=>({messageID:p.messageID,chars:p.textChars})),served,supervisionFiles:chainFiles.length,supervisionArchive:'All original credential-redacted file texts retained in gzip entries; exact private originals preserved',native:settled,pairedCleanupComplete:true})
}
for(const [file,stage] of [['copied-line20.json','01'],['copied-line20-pointer.json','01'],['after-copied-line20.json','01'],['second-copied-line20.json','02'],['second-live-copied-line20.json','02']]){
 const fact=JSON.parse(fs.readFileSync(path.join(root,file),'utf8'))
 assert.equal(fact.value,path.normalize(`C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-12/source-dense-live-346-live-${stage}/project/资料/来源审阅记录_重复标题与准确行号.md`)+':20')
}
save('checks/actual-run-qualification.json',{runs,clipboard:'Five actual readbacks equal full source file location and line20. Feedback/reading screenshots manually reviewed, no UI assertions.',limits:['First launcher boundary failure retained separately from actual complete requests','Screenshot08 is static;09 is independent Working-stage evidence','Side chat only; no new product child agent']})
for(const name of fs.readdirSync(scratch).filter(n=>/\.(ts|ps1|json|log)$/.test(n)))archive(path.join(scratch,name),'checks/'+name)
save('checks/archive-receipt.json',archives)
let textFiles=0
for(const entry of fs.readdirSync(root,{recursive:true,withFileTypes:true}).filter(x=>x.isFile())){
 if(entry.name.endsWith('.png'))continue
 const bytes=fs.readFileSync(path.join(entry.parentPath,entry.name)), text=(entry.name.endsWith('.gz')?gunzipSync(bytes):bytes).toString('utf8')
 if(redactor.containsCredential(text))throw Error('Credential in evidence')
 textFiles++
}
save('checks/credential-scan.json',{textFiles,credentialMatches:0,archives:'Full decompressed content scanned'})
console.log(JSON.stringify({runs:runs.map(({stage,actualLauncherExitCode,providerRequests,elapsedMs,supervisionFiles})=>({stage,actualLauncherExitCode,providerRequests,elapsedMs,supervisionFiles})),textFiles,credentialMatches:0}))