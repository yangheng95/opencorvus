import fs from 'node:fs'
import path from 'node:path'
const root=path.resolve('.tmp-product-iteration'),scratch=path.join(root,'activity-input-projection-391')
for(const suffix of ['.ts','-launch.ps1','-shutdown.ps1']){
 const previous=fs.readFileSync(path.join(root,'live-sol-execution-actor-390-live'+suffix),'utf8')
 const next=previous.replaceAll('execution-actor-identity-390-live','activity-input-projection-391-live').replaceAll('live-sol-execution-actor-390-live','live-sol-activity-input-391-live')
 fs.writeFileSync(path.join(root,'live-sol-activity-input-391-live'+suffix),next,{flag:'wx'})
}
const run='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/'
fs.cpSync(run+'execution-actor-identity-390-live-bundle/bin',run+'activity-input-projection-391-live-bundle/bin',{recursive:true,errorOnExist:true,force:false})
fs.mkdirSync(path.join(scratch,'live'),{recursive:true})
fs.mkdirSync(path.join(root,'activity-input-projection-391-live-native-observer'),{recursive:true})
fs.copyFileSync(path.join(root,'execution-actor-identity-390/builtin.json'),path.join(scratch,'builtin.json'),fs.constants.COPYFILE_EXCL)
for(const name of ['read-facts.ts','read-api.mjs']){
 const text=fs.readFileSync(path.join(root,'execution-actor-identity-390',name),'utf8')
 fs.writeFileSync(path.join(scratch,name),text.replaceAll('execution-actor-identity-390','activity-input-projection-391').replaceAll('18419','18421'),{flag:'wx'})
}
console.log('Fresh 391 scope prepared; unchanged formal frontend; credentials will be paired only by the reviewed launch wrapper.')
