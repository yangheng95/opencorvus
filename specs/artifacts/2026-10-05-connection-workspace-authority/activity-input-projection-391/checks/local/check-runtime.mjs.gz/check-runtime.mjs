import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
const scratch=path.resolve('.tmp-product-iteration/activity-input-projection-391')
const evidence=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/activity-input-projection-391')
const run='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/activity-input-projection-391-after'
const read=p=>JSON.parse(fs.readFileSync(p,'utf8').replace(/^\uFEFF/,''))
const facts=read(path.join(scratch,'after-final.json'))
const children=facts.sessions.filter(s=>JSON.parse(s.metadata).delegation?.kind==='session-local')
assert.equal(children.length,1)
const child=children[0],messages=facts.messages.filter(m=>m.sessionID===child.id)
const input=messages.find(m=>m.role==='user'),final=messages.filter(m=>m.role==='assistant').at(-1)
assert.equal(input.agent,'work');assert.equal(final.agent,'work');assert.equal(final.finish,'stop')
assert.equal(typeof final.time.completed,'number')
const finalText=facts.parts.filter(p=>p.messageID===final.id&&p.type==='text').map(p=>p.text).join('\n')
assert.equal(finalText.includes('120')&&/3\s*天/.test(finalText),true)
const sources=facts.parts.filter(p=>p.type==='source-file')
assert.equal(sources.length,1)
const source=sources[0],tool=facts.tools.find(t=>t.id===source.toolPartID)
assert.equal(tool.tool,'read');assert.equal(tool.messageID,source.messageID)
assert.equal(messages.some(m=>m.id===tool.messageID),true)
assert.deepEqual(tool.input,{filePath:'来源材料/方案甲.txt',offset:2,limit:2})
assert.deepEqual(source.range,{startLine:2,endLine:3})
assert.equal(source.path.replaceAll('\\','/'),run+'/project/来源材料/方案甲.txt')
const outcome=facts.outcomes.find(o=>o.requestPartID===tool.id)
assert.equal(outcome.outcome,'completed')
assert.equal(outcome.metadata.preview,fs.readFileSync(source.path,'utf8').split('\n').slice(1,3).join('\n'))
const delegation=facts.outcomes.find(o=>o.requestPartID===facts.tools.find(t=>t.tool==='delegate_agent').id)
assert.equal(delegation.outcome,'completed');assert.equal(JSON.parse(delegation.output).final_message_id,final.id)
assert.equal(facts.tools.length,2)
const parentFinal=facts.messages.filter(m=>m.sessionID===child.parent_id&&m.role==='assistant').at(-1)
assert.equal(parentFinal.finish,'stop')
assert.equal(facts.parts.filter(p=>p.messageID===parentFinal.id&&p.type==='text').map(p=>p.text).join('\n'),'成员记录已完成')
const childAPI=read(path.join(scratch,'after-child-conversation.json'))
const parentAPI=read(path.join(scratch,'after-parent-conversation.json'))
for(const api of [childAPI,parentAPI]){
 const execution=api.agentView.sessions.find(s=>s.sessionID===child.id&&s.inputMessageID===input.id)
 assert(execution,'Exact child occurrence is projected')
 const completeInput=api.transcript.find(m=>m.info.id===input.id)
 const inputText=completeInput.parts.filter(p=>p.type==='text').map(p=>p.text.trim()).filter(Boolean).join('\n\n')
 assert.equal(execution.inputPreview.messageID,input.id)
 assert.equal(execution.inputPreview.text,inputText)
 assert.equal(inputText.length>0,true)
 const outputs=api.transcript.filter(m=>m.info.sessionID===child.id&&m.info.role==='assistant')
   .flatMap(m=>m.parts.filter(p=>['text','tool','source-file'].includes(p.type)))
 assert.deepEqual(execution.activity.map(p=>p.id),outputs.map(p=>p.id))
 assert.equal(execution.activity.find(p=>p.id===source.id).path,source.path)
 assert.deepEqual(execution.activity.find(p=>p.id===source.id).range,source.range)
}
for(const api of [childAPI,parentAPI]){
 const owned=api.transcript.filter(m=>m.info.sessionID===child.id)
 assert.deepEqual(owned.map(m=>m.info.id),messages.map(m=>m.id))
 for(const message of owned)assert.equal(message.info.sessionAgentID,'work')
 assert.equal(api.view.sessions.find(s=>s.sessionID===child.id).agentID,'work')
 const lifecycle=api.events.find(e=>e.type==='agent.execution.lifecycle'&&e.session_id===child.id)
 assert.deepEqual({input:lifecycle.payload.inputMessageID,actor:lifecycle.payload.agentID,status:lifecycle.payload.status},
   {input:input.id,actor:'work',status:{type:'terminal',reason:'completed'}})
}
const stream=fs.readFileSync(path.join(scratch,'after-replay-events.log'),'utf8').split(/\r?\n/).filter(l=>l.startsWith('data: ')).map(l=>JSON.parse(l.slice(6)))
const replay=stream.find(e=>e.type==='agent.execution.lifecycle'&&e.session_id===child.id)
assert.deepEqual(replay,childAPI.events.find(e=>e.type==='agent.execution.lifecycle'))
const owner=read(path.join(run,'launch-owner.json')),native=read(path.join(run,'evidence/native-host-settled.json'))
const preflight=read(path.join(run,'evidence/preflight-ready.json')).preflight
assert.equal(preflight.credential,'usable');assert.equal(preflight.catalog,'projected')
assert.equal(preflight.actualModel,'gpt-6.1-sol');assert.equal(preflight.streaming,true)
const prefix=path.join(scratch,'after/activity391-after')
const provider=read(prefix+'-final-provider-audit.json'),cleanup=read(prefix+'-physical-terminal-and-pair-cleanup.json')
assert.equal(provider.pid,owner.nativeTarget.pid);assert.equal(provider.maxRequests,20)
assert.equal(provider.requests.length>0&&provider.requests.length<=20,true)
for(const request of provider.requests){
 assert.equal(request.model,'gpt-6.1-sol');assert.equal(request.streaming,true)
 assert.equal(request.status,200);assert.equal(request.response_reader.terminal.kind,'eof')
}
assert.equal(native.occurrence,owner.occurrence);assert.equal(cleanup.occurrence,owner.occurrence)
assert.equal(native.terminal.reason,'exited');assert.equal(native.terminal.exitCode,0)
for(const key of ['physicalCompletion','outputDrainComplete','requestCleanupComplete'])assert.equal(native[key],true)
assert.equal(cleanup.pairedCleanupComplete,true)
assert.deepEqual(cleanup.copiedPair.map(p=>p.outcome),['removed','removed'])
const duration=Date.parse(native.observedAtUtc)-owner.targetBirthAtMs
assert.equal(duration<=600000,true)
const result={childSessionID:child.id,parentSessionID:child.parent_id,inputMessageID:input.id,finalMessageID:final.id,
 actor:'work',source:{id:source.id,path:source.path,range:source.range,toolPartID:tool.id},
 requests:provider.requests.length,preflight,native:{terminal:native.terminal,durationMilliseconds:duration,physicalCompletion:true,pairedCleanupComplete:true},
 replayEventID:replay.event_id,boundary:'Canonical DB, public HTTP/SSE, actual streaming Provider, and Native resource checks. UI accepted separately by actual page interaction and manual screenshot review.',
 remaining:['The independent live scope remains a Provider business failure with an incorrectly completed delegated terminal; original failure facts and the shared investigation are retained separately.','Original Research Studio long-history dataset is not covered by this bounded real session-local run.']}
fs.writeFileSync(path.join(evidence,'runtime-review.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify(result))
