import fs from 'node:fs'
import path from 'node:path'
const root=path.resolve('.tmp-product-iteration'),scratch=path.join(root,'activity-input-projection-391')
for(const suffix of ['.ts','-launch.ps1','-shutdown.ps1']){
 const previous=fs.readFileSync(path.join(root,'live-sol-activity-input-391-live'+suffix),'utf8')
 const next=previous.replaceAll('activity-input-projection-391-live','activity-input-projection-391-after').replaceAll('live-sol-activity-input-391-live','live-sol-activity-input-391-after')
 fs.writeFileSync(path.join(root,'live-sol-activity-input-391-after'+suffix),next,{flag:'wx'})
}
const run='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/'
fs.cpSync(run+'activity-input-projection-391-live-bundle/bin',run+'activity-input-projection-391-after-bundle/bin',{recursive:true,errorOnExist:true,force:false})
fs.mkdirSync(path.join(scratch,'after'),{recursive:true})
fs.mkdirSync(path.join(root,'activity-input-projection-391-after-native-observer'),{recursive:true})
const facts=fs.readFileSync(path.join(scratch,'read-facts.ts'),'utf8')
fs.writeFileSync(path.join(scratch,'read-facts-live-used.ts'),facts,{flag:'wx'})
fs.writeFileSync(path.join(scratch,'read-facts.ts'),facts.replace("['live']","['live','after']"))
const api=fs.readFileSync(path.join(scratch,'read-api.mjs'),'utf8').replaceAll('live-final.json','after-final.json').replaceAll('18421','18423').replaceAll('${label}-conversation.json','after-${label}-conversation.json').replaceAll('replay-events.log','after-replay-events.log')
fs.writeFileSync(path.join(scratch,'read-api-after.mjs'),api,{flag:'wx'})
console.log('Separate after scope prepared. Original live provider/business failure retained; no prior Native lifetime extended.')
