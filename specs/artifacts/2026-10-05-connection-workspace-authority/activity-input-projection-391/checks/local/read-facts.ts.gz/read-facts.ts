import fs from 'node:fs'
import path from 'node:path'
import {Database} from 'bun:sqlite'
import {createRequire} from 'node:module'
import {completedToolOutcomeOutput} from '../../packages/opencorvus/src/session/tool-outcome-facts'
import {CredentialRedactor} from '../../packages/opencorvus/script/real-provider-audit'
const phase=process.argv[2]
const capture=process.argv[3]
if(!['initial','failure','recovered','final'].includes(capture))throw Error('Exact capture phase required')
if(!['live','after'].includes(phase))throw Error('Exact diagnostic phase required')
const run='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/activity-input-projection-391-'+phase
const redactor=new CredentialRedactor()
redactor.collect(JSON.parse(fs.readFileSync('C:/Users/hengu/AppData/Local/opencorvus/data/auth.json','utf8')))
const requireProduction=createRequire(path.resolve('packages/opencorvus/package.json'))
const {drizzle}=await import(requireProduction.resolve('drizzle-orm/bun-sqlite'))
const db=new Database(path.join(run,'runtime/data/opencorvus.db'),{readonly:true})
const outputDB=drizzle({client:db})
let facts:any
try{
 db.exec('BEGIN')
 const sessions=db.query('SELECT id,project_id,directory,kind,parent_id,title,metadata FROM session ORDER BY time_created,id').all()
 const messages=db.query('SELECT id,session_id,data FROM message ORDER BY time_created,id').all().map((row:any)=>({...JSON.parse(row.data),id:row.id,sessionID:row.session_id}))
 const parts=db.query('SELECT id,message_id,data FROM part ORDER BY time_created,id').all().map((row:any)=>({...JSON.parse(row.data),id:row.id,messageID:row.message_id}))
 const tools=db.query('SELECT id,message_id,data FROM tool_part_request ORDER BY time_created,id').all().map((row:any)=>({...JSON.parse(row.data),id:row.id,messageID:row.message_id}))
 const outcomes=db.query('SELECT request_part_id,data FROM tool_part_outcome ORDER BY time_created,id').all().map((row:any)=>{
  const data=JSON.parse(row.data)
  return {...data,requestPartID:row.request_part_id,output:completedToolOutcomeOutput(outputDB as any,data,()=>row.request_part_id)}
 })
 facts={phase,observedAt:new Date().toISOString(),boundary:'Read-only canonical SQLite transaction; not UI acceptance',sessions,messages,parts,tools,outcomes}
}finally{db.exec('ROLLBACK');db.close()}
const output=path.resolve('.tmp-product-iteration/activity-input-projection-391',phase+'-'+capture+'.json')
fs.writeFileSync(output,redactor.redact(JSON.stringify(facts,null,2))+'\n',{flag:'wx'})
console.log(JSON.stringify({phase,capture,sessions:facts.sessions.map((s:any)=>({...s,metadata:JSON.parse(s.metadata)})),sources:facts.parts.filter((p:any)=>p.type==='source-file').map((p:any)=>({id:p.id,messageID:p.messageID,toolPartID:p.toolPartID,path:p.path,range:p.range})),tools:facts.tools.map((t:any)=>({id:t.id,messageID:t.messageID,tool:t.tool,input:t.input}))}))


