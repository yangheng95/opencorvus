import fs from 'node:fs'
const prior='.tmp-product-iteration/execution-actor-identity-390/check-runtime.mjs'
let text=fs.readFileSync(prior,'utf8').replaceAll('execution-actor-identity-390','activity-input-projection-391').replaceAll('activity-input-projection-391-live','activity-input-projection-391-after').replaceAll('live-final.json','after-final.json').replaceAll('child-conversation.json','after-child-conversation.json').replaceAll('parent-conversation.json','after-parent-conversation.json').replaceAll('replay-events.log','after-replay-events.log').replaceAll('live/actor390-live','after/activity391-after')
const anchor="const parentAPI=read(path.join(scratch,'after-parent-conversation.json'))\n"
if(!text.includes(anchor))throw Error('Review checker anchor')
text=text.replace(anchor,anchor+`for(const api of [childAPI,parentAPI]){
 const execution=api.agentView.sessions.find(s=>s.sessionID===child.id&&s.inputMessageID===input.id)
 assert(execution,'Exact child occurrence is projected')
 const completeInput=api.transcript.find(m=>m.info.id===input.id)
 const inputText=completeInput.parts.filter(p=>p.type==='text').map(p=>p.text.trim()).filter(Boolean).join('\\n\\n')
 assert.equal(execution.inputPreview.messageID,input.id)
 assert.equal(execution.inputPreview.text,inputText)
 assert.equal(inputText.length>0,true)
 const outputs=api.transcript.filter(m=>m.info.sessionID===child.id&&m.info.role==='assistant')
   .flatMap(m=>m.parts.filter(p=>['text','tool','source-file'].includes(p.type)))
 assert.deepEqual(execution.activity.map(p=>p.id),outputs.map(p=>p.id))
 assert.equal(execution.activity.find(p=>p.id===source.id).path,source.path)
 assert.deepEqual(execution.activity.find(p=>p.id===source.id).range,source.range)
}
`)
text=text.replace("finalText.includes('3天')","/3\\s*天/.test(finalText)")
text=text.replace('After page reload the parent progress preview adds a raw handoff input line; screenshots 03 and 05 retain the difference for the next iteration.','The independent live scope remains a Provider business failure with an incorrectly completed delegated terminal; original failure facts and the shared investigation are retained separately.')
fs.writeFileSync('.tmp-product-iteration/activity-input-projection-391/check-runtime.mjs',text,{flag:'wx'})
console.log('Prepared canonical activity/output/input-context checker; no UI assertions.')
