import fs from 'node:fs'
import path from 'node:path'
import {Database} from 'bun:sqlite'
import {CredentialRedactor} from '../../packages/opencorvus/script/real-provider-audit'
const scratch=path.resolve('.tmp-product-iteration/activity-input-projection-391')
const facts=JSON.parse(fs.readFileSync(path.join(scratch,'live-failure.json'),'utf8'))
const child=facts.sessions.find((s:any)=>s.parent_id)
const run='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/activity-input-projection-391-live'
const redactor=new CredentialRedactor()
redactor.collect(JSON.parse(fs.readFileSync('C:/Users/hengu/AppData/Local/opencorvus/data/auth.json','utf8')))
const db=new Database(path.join(run,'runtime/data/opencorvus.db'),{readonly:true})
const events=db.query('SELECT id,type,source,aggregate_type,aggregate_id,session_id,emitted_at,payload FROM protocol_event WHERE aggregate_id=? OR session_id=? ORDER BY emitted_at,id').all(child.id,child.id).map((r:any)=>({...r,payload:JSON.parse(r.payload)}))
db.close()
const result={child,events,messages:facts.messages.filter((m:any)=>m.sessionID===child.id),tools:facts.tools,outcomes:facts.outcomes,boundary:'Original business failure, copied from real closed Native scope; no event or Message mutation.'}
fs.writeFileSync(path.join(scratch,'live-failure-detail.json'),redactor.redact(JSON.stringify(result,null,2))+'\n',{flag:'wx'})
console.log(JSON.stringify({childID:child.id,messages:result.messages.map((m:any)=>({id:m.id,role:m.role,finish:m.finish,error:m.error})),lifecycle:events.filter((e:any)=>e.type==='agent.execution.lifecycle').map((e:any)=>({id:e.id,status:e.payload.status,at:e.emitted_at})),outcomes:result.outcomes}))
