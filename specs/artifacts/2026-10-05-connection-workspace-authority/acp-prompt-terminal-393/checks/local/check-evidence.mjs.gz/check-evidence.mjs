import fs from 'node:fs'
import assert from 'node:assert/strict'
const scratch='.tmp-product-iteration/acp-prompt-terminal-393'
const evidence='specs/artifacts/2026-10-05-connection-workspace-authority/acp-prompt-terminal-393'
const records=fs.readFileSync(scratch+'/contracts-complete.log','utf8').split(/\r?\n/).filter(l=>l.startsWith('{')).map(l=>JSON.parse(l))
const identities=[]
for(const entry of ['prompt','command']){
 for(const [model,finish,stopReason] of [['normal','stop','end_turn'],['length','length','max_tokens'],['content_filter','content-filter','refusal']]){
  const row=records.find(r=>r.entry===entry&&r.model===model)
  assert(row)
  const final=row.messages.filter(m=>m.info.role==='assistant').at(-1).info
  assert.equal(final.finish,finish)
  assert.equal(row.response.stopReason,stopReason)
  assert.equal(row.response.usage.totalTokens,final.tokens.total)
  assert(row.requests.every(r=>r.stream===true))
  identities.push({entry,model,sessionID:final.sessionID,inputMessageID:final.parentID,finalMessageID:final.id,stopReason})
 }
 const row=records.find(r=>r.entry===entry&&r.model==='error')
 const failed=row.messages.find(m=>m.info.id===row.response.data.finalMessageID).info
 assert.equal(row.response.code,-32603)
 assert.equal(row.response.data.sessionID,failed.sessionID)
 assert.equal(row.response.data.inputMessageID,failed.parentID)
 assert.deepEqual(row.response.data.error,failed.error)
 assert.equal(row.messages.filter(m=>m.info.role==='assistant').at(-1).info.finish,'stop')
 identities.push({entry,model:'error',sessionID:failed.sessionID,inputMessageID:failed.parentID,finalMessageID:failed.id,error:failed.error,subsequentReply:'stop'})
 const cancel=records.find(r=>r.entry===entry&&r.cancellationResult)
 assert.equal(cancel.cancellationResult.stopReason,'cancelled')
 const cancelled=cancel.messages.filter(m=>m.info.role==='assistant').at(-1).info
 assert.equal(cancelled.error.name,'MessageAbortedError')
 assert.equal(cancelled.error.data.cancellation.source,'session.abort')
 assert.equal(typeof cancelled.time.completed,'number')
 identities.push({entry,model:'cancel',sessionID:cancelled.sessionID,inputMessageID:cancelled.parentID,finalMessageID:cancelled.id,stopReason:'cancelled'})
}
const parallel=records.find(r=>r.parallelResults)
assert.deepEqual(parallel.parallelResults.map(r=>r.status),['rejected','fulfilled','fulfilled'])
assert.equal(new Set(parallel.projects.map(r=>r.directory)).size,2)
const compact=fs.readFileSync(scratch+'/compaction-evidence.log','utf8').split(/\r?\n/).filter(l=>l.startsWith('{')).map(l=>JSON.parse(l)).find(r=>r.compactionResult)
assert.equal(compact.compactionResult.code,-32603)
assert.equal(compact.controls.length,1)
assert.equal(compact.controls[0].status,'failed')
assert(compact.controls[0].payload.error.startsWith('SessionCompactionMaterialUnavailableError:'))
const result={qualification:'Backend protocol integration using actual ACP, product HTTP, Session/Provider processing and a controlled local streaming participant. No external-model or visual qualification.',identities,parallel:{sessions:parallel.projects.map(r=>r.sessionID),projectCount:2},compaction:{controlID:compact.controls[0].id,error:compact.controls[0].payload.error},checks:{protocol:14,conversion:12,publicIdentity:13,uniqueTests:39},remaining:['Cancellation before a canonical assistant exists','Cross-process cancellation and full Task/Mission recovery','Complete stream-update/response race ordering','Original Research Studio long-history Sources']}
fs.writeFileSync(evidence+'/runtime-review.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({replies:identities.length,parallelSessions:3,uniqueTests:39,compactionControl:result.compaction.controlID}))
