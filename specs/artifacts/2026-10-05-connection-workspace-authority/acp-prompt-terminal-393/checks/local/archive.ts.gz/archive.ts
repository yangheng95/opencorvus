import fs from 'node:fs'
import path from 'node:path'
import {gzipSync,gunzipSync} from 'node:zlib'
import {CredentialRedactor} from '../../packages/opencorvus/script/real-provider-audit'
const scratch=path.resolve('.tmp-product-iteration/acp-prompt-terminal-393')
const root=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/acp-prompt-terminal-393')
const redactor=new CredentialRedactor()
redactor.collect(JSON.parse(fs.readFileSync('C:/Users/hengu/AppData/Local/opencorvus/data/auth.json','utf8')))
const files:any[]=[]
function pack(source:string,relative:string){
 const raw=Buffer.from(redactor.redact(fs.readFileSync(source,'utf8'))),packed=gzipSync(raw,{level:9})
 if(!gunzipSync(packed).equals(raw))throw Error('Archive bytes changed')
 const target=path.resolve(root,'checks',relative+'.gz')
 if(!target.startsWith(root+path.sep))throw Error('Archive escaped exact root')
 fs.mkdirSync(path.dirname(target),{recursive:true})
 fs.writeFileSync(target,packed,{flag:'wx'})
 files.push({source,archive:path.relative(root,target).replaceAll('\\','/'),redactedBytes:raw.length,compressedBytes:packed.length})
}
for(const entry of fs.readdirSync(scratch,{withFileTypes:true})){
 if(entry.isFile()&&/\.(json|log|ts|mjs|md)$/.test(entry.name))pack(path.join(scratch,entry.name),'local/'+entry.name)
}
for(const name of ['push.log','module-exact.log','release-exact.log'])pack(path.resolve('.tmp-product-iteration/delegate-terminal-392',name),'previous-392/'+name)
fs.writeFileSync(path.join(root,'checks/archive-receipt.json'),JSON.stringify({files,integrity:'Complete redacted inputs equal decompressed archives. This verifies immutable archive bytes, not functional correctness.',qualification:'39 distinct backend checks. Original failures and corrections retained. No UI automation or external model credentials used.'},null,2)+'\n',{flag:'wx'})
let scanned=0
for(const entry of fs.readdirSync(root,{recursive:true,withFileTypes:true})){
 if(!entry.isFile())continue
 const bytes=fs.readFileSync(path.join(entry.parentPath,entry.name))
 if(redactor.containsCredential((entry.name.endsWith('.gz')?gunzipSync(bytes):bytes).toString('utf8')))throw Error('Credential in archive')
 scanned++
}
fs.writeFileSync(path.join(root,'checks/credential-scan.json'),JSON.stringify({scanned,credentialMatches:0,scope:'All full text and decompressed archives'},null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({archives:files.length,scanned,credentialMatches:0}))
