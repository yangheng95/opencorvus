import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import { Database } from 'bun:sqlite'
import { gzipSync, gunzipSync } from 'node:zlib'
import { CredentialRedactor } from '../../packages/opencorvus/script/real-provider-audit'
const scratch=path.resolve('.tmp-product-iteration/activity-occurrence-345')
const root=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/activity-occurrence-345')
const source='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-12/child-live-329-live-01'
const redactor=new CredentialRedactor()
redactor.collect(JSON.parse(fs.readFileSync('C:/Users/hengu/AppData/Local/opencorvus/data/auth.json','utf8')))
fs.mkdirSync(path.join(root,'checks'),{recursive:true})
const save=(name:string,data:unknown)=>fs.writeFileSync(path.join(root,name),redactor.redact(JSON.stringify(data,null,2))+'\n',{flag:'wx'})
const archives:any[]=[]
function archive(from:string,name:string){
 const raw=Buffer.from(redactor.redact(fs.readFileSync(from,'utf8'))), compressed=gzipSync(raw)
 assert.equal(gunzipSync(compressed).equals(raw),true)
 fs.writeFileSync(path.join(root,name+'.gz'),compressed,{flag:'wx'})
 archives.push({source:from,archive:name+'.gz',bytes:raw.length,compressedBytes:compressed.length,integrity:'Complete decompressed bytes equal actual credential-redacted original'})
}
const before=JSON.parse(fs.readFileSync(path.join(root,'before-hydration.json'),'utf8'))
const after=JSON.parse(fs.readFileSync(path.join(root,'after-hydration.json'),'utf8'))
const session=JSON.parse(fs.readFileSync(path.join(root,'after-session-hydration.json'),'utf8'))
assert.deepEqual(after.transcript,before.transcript)
assert.deepEqual(after.view,before.view)
assert.deepEqual(after.board.executionProjection,before.board.executionProjection)
const input='msg_g0VXnHYNh00vQfmcZ1yI'
const parent='msg_task-root-control_art_hrl5KKUEJ5kWYF9kbAbx_art_hrl5KKUEJ5kWYF9kbAbx'
const reply='msg_huE9jYvZb3HfJpmexgNX'
const worker='msg_g0VXnHhvP00LmjMWNYz8'
const final='msg_task-root-control_art_hYD9w3IXY4ZrcLaMSRLQ_art_hYD9w3IXY4ZrcLaMSRLQ'
const shape=(v:any)=>v.agentView.sessions.map((s:any)=>({inputMessageID:s.inputMessageID,status:s.status}))
assert.deepEqual(shape(before),[{inputMessageID:input,status:'pending'},{inputMessageID:parent,status:'idle'},{inputMessageID:worker,status:'completed'},{inputMessageID:final,status:'completed'}])
assert.deepEqual(shape(after),[{inputMessageID:parent,status:'idle'},{inputMessageID:worker,status:'completed'},{inputMessageID:final,status:'completed'}])
assert.deepEqual(shape(session),shape(after))
assert.deepEqual(after.agentView.sessions[0].messageIDs,[input,parent,reply])
assert.equal(after.agentView.messages.find((m:any)=>m.messageID===input).inputMessageID,parent)
save('checks/actual-http-contract.json',{checkedAt:new Date().toISOString(),taskID:'tsk_g00VXnHXUY002nUsxVFT',before:shape(before),after:shape(after),session:shape(session),firstExecutionMessages:after.agentView.sessions[0].messageIDs,transcript:'Complete transport transcript and main view equal before',lifecycle:'Complete durable executionProjection equal before',boundary:'Actual production Task and Session HTTP responses; backend data contract, not UI automation'})
function facts(run:string){
 const db=new Database(path.join(run,'runtime/data/opencorvus.db'),{readonly:true});db.exec('BEGIN')
 try{return {messages:db.query('SELECT id,session_id,data FROM message ORDER BY id').all(),providerIDs:db.query('SELECT id FROM provider_activity_request ORDER BY id').all(),sources:db.query("SELECT p.id,p.message_id,m.session_id,p.data FROM part p JOIN message m ON m.id=p.message_id WHERE json_extract(p.data,'$.type') IN ('source-file','source-url','source-document') ORDER BY p.id").all()}}
 finally{db.exec('ROLLBACK');db.close()}
}
const original=facts(source), runs:any[]=[]
for(const [suffix,handle] of [['01',47270],['02',11378]] as const){
 const run=`C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-12/activity-occurrence-345-history-${suffix}`
 const current=facts(run);assert.deepEqual(current,original)
 const settled=JSON.parse(fs.readFileSync(path.join(run,'evidence/native-host-settled.json'),'utf8'))
 assert.equal(settled.terminal.exitCode,0);assert.equal(settled.physicalCompletion,true);assert.equal(settled.outputDrainComplete,true);assert.equal(settled.requestCleanupComplete,true)
 const requests=fs.readFileSync(path.join(run,'runtime/log/dev.log'),'utf8').split(/\r?\n/).filter(Boolean).map(l=>JSON.parse(l)).filter(x=>x.service==='server'&&x.data?.status==='completed')
 const served=requests.find(x=>x.data.path==='/ui/assets/main-tuh6dcX2.js');assert.equal(served.data.statusCode,200)
 const birth=Number(BigInt(settled.target.processInstanceID.slice(6))/10000n-62135596800000n)
 runs.push({suffix,initialHandle:handle,launcherExitCode:0,settled,elapsedMs:Date.parse(settled.observedAtUtc)-birth,served,messages:current.messages.length,providerIdentities:current.providerIDs.length,sources:current.sources.length,newProviderRequests:0,identity:'Full Message rows, Source rows and Provider request IDs equal closed original'})
 for(const name of ['startup.json','launch-owner.json','evidence/native-host-ready.json','evidence/native-host-settled.json','stdout.log','stderr.log','runtime/log/dev.log'])archive(path.join(run,name),`history-${suffix}/`+path.basename(name))
}
save('checks/runtime-qualification.json',{source,runs,visual:'Five actual screenshots manually reviewed by root; no UI automation',limits:['Historical completed Task; no new stream','No new guidance submitted','Original Research Studio legacy schema not started']})
for(const name of ['before-hydration.json','after-hydration.json','after-session-hydration.json'])archive(path.join(root,name),name)
for(const name of fs.readdirSync(scratch).filter(n=>/\.(ts|ps1|json|log)$/.test(n)))archive(path.join(scratch,name),'checks/'+name)
save('checks/archive-receipt.json',archives)
let textFiles=0
for(const entry of fs.readdirSync(root,{recursive:true,withFileTypes:true}).filter(x=>x.isFile())){
 if(entry.name.endsWith('.png'))continue
 const raw=fs.readFileSync(path.join(entry.parentPath,entry.name)), text=(entry.name.endsWith('.gz')?gunzipSync(raw):raw).toString('utf8')
 if(redactor.containsCredential(text)) throw Error('Credential in evidence')
 textFiles++
}
save('checks/final-scan.json',{textFiles,credentialMatches:0,compressedInputs:'All decompressed archive content scanned'})
console.log(JSON.stringify({runs:runs.map(({suffix,messages,sources,providerIdentities,newProviderRequests,elapsedMs})=>({suffix,messages,sources,providerIdentities,newProviderRequests,elapsedMs})),textFiles,credentialMatches:0}))