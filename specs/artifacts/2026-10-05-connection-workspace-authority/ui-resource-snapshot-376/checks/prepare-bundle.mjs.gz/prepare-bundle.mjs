import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
const root='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/ui-resource-snapshot-376-bundle'
const bin=path.join(root,'bin'),ui=path.join(bin,'ui'),binary=path.join(bin,'bun.exe')
const sourceBinary='C:/Users/hengu/.bun/bin/bun.exe',sourceUI=path.resolve('packages/overlay/dist-vite')
assert.equal(fs.existsSync(root),false,'Unique private bundle root required')
fs.mkdirSync(bin,{recursive:true});fs.copyFileSync(sourceBinary,binary,fs.constants.COPYFILE_EXCL)
const originalBinary=fs.readFileSync(sourceBinary);assert.deepEqual(fs.readFileSync(binary),originalBinary)
fs.cpSync(sourceUI,ui,{recursive:true,force:false,errorOnExist:true})
const files=[]
for(const entry of fs.readdirSync(sourceUI,{recursive:true,withFileTypes:true}).filter(e=>e.isFile())){
 const source=path.join(entry.parentPath,entry.name),relative=path.relative(sourceUI,source),target=path.resolve(ui,relative)
 assert.ok(target.startsWith(path.resolve(ui)+path.sep))
 const bytes=fs.readFileSync(source);assert.deepEqual(fs.readFileSync(target),bytes)
 files.push({path:relative.replaceAll('\\','/'),bytes:bytes.length})
}
const launcher=fs.readFileSync('.tmp-product-iteration/live-sol-launch.ps1','utf8')
const original="$taskBun = 'C:/Users/hengu/.bun/bin/bun.exe'"
assert.equal(launcher.split(original).length,2)
fs.writeFileSync('.tmp-product-iteration/live-sol-resource-launch-376.ps1',launcher.replace(original,"$taskBun = '"+binary.replaceAll('\\','/')+"'"),{flag:'wx'})
const evidence=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/ui-resource-snapshot-376/after')
fs.mkdirSync(evidence,{recursive:true})
fs.writeFileSync(path.join(evidence,'private-bundle-preparation.json'),JSON.stringify({root,bin,ui,binary,sourceBinary,sourceUI,binaryBytes:originalBinary.length,files,totalUIBytes:files.reduce((sum,x)=>sum+x.bytes,0),integrity:'All complete copied binary and UI file bytes equal their actual inputs; no generated digest gate'},null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({root,binaryBytes:originalBinary.length,uiFiles:files.length,uiBytes:files.reduce((sum,x)=>sum+x.bytes,0)}))
