import fs from 'node:fs'
import path from 'node:path'
const run='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/ui-resource-snapshot-376-after'
const evidence=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/ui-resource-snapshot-376/after')
const ready=JSON.parse(fs.readFileSync(path.join(run,'evidence/preflight-ready.json'),'utf8')).preflight
if(ready.credential!=='usable'||ready.catalog!=='projected'||ready.actualModel!=='gpt-6.1-sol'||!ready.streaming)throw Error('Provider qualification required')
const file=path.join(run,'project/资源记录.txt'),text='RESOURCE376\r\n重建前后的真实来源\r\n第三行\r\n第四行\r\n'
fs.writeFileSync(file,text,{flag:'wx'})
fs.writeFileSync(path.join(evidence,'authored-inputs.json'),JSON.stringify({file,text},null,2)+'\n',{flag:'wx'})
fs.writeFileSync('.tmp-product-iteration/ui-resource-snapshot-376/after/main-request.txt','请实际read“资源记录.txt”，offset=1、limit=4，保留真实来源。随后用简短中文说明读到的内容，并附上Markdown链接 [查看资源文件](资源记录.txt:2)。不要修改文件、创建任务或调用成员。',{flag:'wx'})
console.log(JSON.stringify({prepared:true,file}))
