import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import { OverlayUI, freezeOverlayUiDirectory } from '../../packages/opencorvus/src/server/overlay-ui'
const root=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/ui-resource-snapshot-376/after')
const prepared=JSON.parse(fs.readFileSync(path.join(root,'private-bundle-preparation.json'),'utf8'))
const worker=fs.readdirSync(path.join(prepared.ui,'assets')).find(name=>/^markdown-render\.worker-.*\.js$/.test(name))!
assert.ok(worker)
const memoryBefore=process.memoryUsage(),started=performance.now()
const source=freezeOverlayUiDirectory({directory:prepared.ui})
const captureMilliseconds=performance.now()-started,memoryAfter=process.memoryUsage()
const app=OverlayUI.routes(source),server=Bun.serve({hostname:'127.0.0.1',port:0,fetch:app.fetch})
const results=[]
try {
 for(const relative of [...source.assetRefs,`assets/${worker}`]){
  const response=await fetch(new URL('/ui/'+relative,server.url))
  assert.equal(response.status,200);assert.equal(response.headers.get('x-opencorvus-overlay-ui-identity'),source.identity)
  const actual=Buffer.from(await response.arrayBuffer()),expected=fs.readFileSync(path.join(prepared.ui,relative))
  assert.deepEqual(actual,expected)
  results.push({relative,status:response.status,bytes:actual.length,completeBytes:'equal to the new real private build'})
 }
} finally { await server.stop(true) }
fs.writeFileSync(path.join(root,'fresh-capture.json'),JSON.stringify({identity:source.identity,assetCount:source.assetCount,captureMilliseconds,memoryBefore,memoryAfter,results,scope:'Separate real HTTP resource listener; no browser/LLM claims. Snapshot byte total is the resource memory floor, process memory delta includes other allocations.'},null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({assets:source.assetCount,captureMilliseconds,resources:results.length,identity:source.identity}))
