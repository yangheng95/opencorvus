import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
const stage=process.argv[2];assert.ok(['before','after'].includes(stage))
const evidence=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/ui-resource-snapshot-376/after')
const prepared=JSON.parse(fs.readFileSync(path.join(evidence,'private-bundle-preparation.json'),'utf8'))
const response=await fetch('http://localhost:18383/ui/',{signal:AbortSignal.timeout(30000)})
assert.equal(response.status,200)
const identity=response.headers.get('x-opencorvus-overlay-ui-identity')
assert.equal(response.headers.get('x-opencorvus-overlay-ui-source'),'directory')
const refs=response.headers.get('x-opencorvus-overlay-ui-assets').split(',')
const workers=prepared.files.filter(f=>/markdown-render\.worker-.*\.js$/.test(f.path)).map(f=>f.path)
assert.equal(workers.length,1)
const targets=[...refs,...workers,'i18n/en-US.json',prepared.scopeResource.path]
const receipts=[]
for(const target of targets){
 const actual=await fetch('http://localhost:18383/ui/'+target,{signal:AbortSignal.timeout(30000)})
 assert.equal(actual.status,200);assert.equal(actual.headers.get('x-opencorvus-overlay-ui-identity'),identity)
 const bytes=Buffer.from(await actual.arrayBuffer()),original=fs.readFileSync(target===prepared.scopeResource.path?prepared.scopeResource.original:path.join(prepared.sourceUI,target))
 assert.deepEqual(bytes,original)
 receipts.push({target,status:actual.status,bytes:bytes.length,contentType:actual.headers.get('content-type'),completeBytes:'equal to original formal build'})
}
if(stage==='after'){
 const before=JSON.parse(fs.readFileSync(path.join(evidence,'resource-before.json'),'utf8'))
 assert.equal(identity,before.identity)
 const current=fs.readdirSync(path.join(prepared.ui,'assets')).filter(name=>/^markdown-render\.worker-.*\.js$/.test(name))
 assert.equal(current.length,1)
 receipts.push({publishedWorker:current[0],originalWorker:workers[0],publication:'Different real build; source version comparison is recorded, response bytes qualified above'})
}
fs.writeFileSync(path.join(evidence,'resource-'+stage+'.json'),JSON.stringify({stage,identity,receipts},null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({stage,resources:receipts.length,identity}))
