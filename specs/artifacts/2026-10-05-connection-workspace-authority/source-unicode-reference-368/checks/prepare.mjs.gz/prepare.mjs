import fs from 'node:fs'
import path from 'node:path'
const run='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/source-unicode-reference-368'
const evidence=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/source-unicode-reference-368')
const scratch=path.resolve('.tmp-product-iteration/source-unicode-reference-368')
const ready=JSON.parse(fs.readFileSync(path.join(run,'evidence/preflight-ready.json'),'utf8'))
if(ready.preflight.credential!=='usable'||ready.preflight.catalog!=='projected'||ready.preflight.actualModel!=='gpt-6.1-sol'||!ready.preflight.streaming)throw Error('Actual credential, model and stream qualification required')
const files=[
 {name:'中文记录.md',kind:'han',marker:'MATCH368_中文'},
 {name:'cafe\u0301.md',kind:'combining',marker:'MATCH368_combining'},
 {name:'記録٢.md',kind:'script-number',marker:'MATCH368_記録'},
 {name:'ascii.md',kind:'ascii',marker:'MATCH368_ascii'},
].map(file=>({...file,path:path.join(run,'project/资料/代码引用',file.name),reference:'资料/代码引用/'+file.name+':2:10',line:2,column:10,text:'标题\r\nbefore中😀'+file.marker+'\r\n结束\r\n'}))
for(const file of files){fs.mkdirSync(path.dirname(file.path),{recursive:true});fs.writeFileSync(file.path,file.text,{flag:'wx'})}
fs.mkdirSync(evidence,{recursive:true})
fs.writeFileSync(path.join(evidence,'authored-inputs.json'),JSON.stringify({files},null,2)+'\n',{flag:'wx'})
const absolute=files[0].path.replaceAll('\\','/')+':2:10'
const request='请实际用 search_code 在“资料/代码引用”目录以正则 MATCH368 搜索 Markdown，保留真实来源。最后仅输出以下五个引用，每个单独一行，用行内代码格式（反引号）呈现，逐字符保留文件名和行列：\n'+files.map(f=>'`'+f.reference+'`').join('\n')+'\n`'+absolute+'`\n不要修改文件、创建任务或调用成员，不要额外读取文件。'
fs.writeFileSync(path.join(scratch,'main-request.txt'),request,{flag:'wx'})
fs.writeFileSync(path.join(scratch,'side-request.txt'),'请在本侧聊实际用 search_code 在“资料/代码引用”目录搜索正则 MATCH368_中文，限定 Markdown，保留真实来源。最后只用行内代码格式输出 `资料/代码引用/中文记录.md:2:10`。不修改文件，不创建任务，不调用成员。',{flag:'wx'})
console.log(JSON.stringify({files:files.map(f=>({name:f.name,reference:f.reference})),absolute}))
