import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import {Database} from 'bun:sqlite'
const run='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/source-unicode-reference-368'
const evidence=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/source-unicode-reference-368')
const folder=path.join(evidence,'live'),label='source-unicode-reference-368-live'
const read=(name:string)=>JSON.parse(fs.readFileSync(path.join(folder,name),'utf8'))
const canonical=read('canonical-current-conversations.json')
const inputs=JSON.parse(fs.readFileSync(path.join(evidence,'authored-inputs.json'),'utf8'))
for(const file of inputs.files)assert.deepEqual(fs.readFileSync(file.path),Buffer.from(file.text))
const db=new Database(path.join(run,'runtime/data/opencorvus.db'),{readonly:true})
let sources:any[]
try{db.exec('BEGIN');sources=(db.query("SELECT p.id,p.message_id,m.session_id,p.data FROM part p JOIN message m ON m.id=p.message_id WHERE json_extract(p.data,'$.type')='source-file' ORDER BY p.time_created,p.id").all() as any[]).map(r=>({...r,data:JSON.parse(r.data)}))}finally{db.exec('ROLLBACK');db.close()}
assert.equal(sources.length,9)
const surfaces=[
 {name:'main',sessionID:'ses_-zUS7OxAbzz23rpKkhtG',messageID:'msg_g0VXsb38y00g2yzDJM5I',count:4,pattern:'MATCH368',finalID:'msg_g0VXsb4Ew00bAjxSm1Rw'},
 {name:'side-reference',sessionID:'ses_-zUS7Oag0zzqh2nR9gHt',messageID:'msg_g0VXsbPK401iPCoggQys',count:4,pattern:'MATCH368',finalID:'msg_g0VXsbPK402bkII7yPWL'},
 {name:'side-current',sessionID:'ses_-zUS7Oag0zzqh2nR9gHt',messageID:'msg_g0VXsbUrS00D3WN7XUyH',count:1,pattern:'MATCH368_中文',finalID:'msg_g0VXsbVra00Zw3wrjB7E'},
]
const results=[]
for(const surface of surfaces){
 const request=canonical.tools.find((t:any)=>t.message_id===surface.messageID),data=JSON.parse(request.data)
 assert.equal(data.tool,'search_code');assert.deepEqual(data.input,{pattern:surface.pattern,path:'资料/代码引用',include:'*.md'})
 const outcome=canonical.outcomes.find((o:any)=>o.requestPartID===request.id);assert.equal(outcome.outcome,'completed')
 assert.equal(outcome.output.split('\n')[0],`Found ${surface.count} matches`)
 const rows=sources.filter(s=>s.message_id===surface.messageID);assert.equal(rows.length,surface.count)
 for(const row of rows){
  assert.equal(row.session_id,surface.sessionID)
  const source=row.data,file=inputs.files.find((f:any)=>path.resolve(f.path)===source.path);assert.ok(file)
  assert.equal(source.title,file.name);assert.deepEqual(source.range,{startLine:2,endLine:2,startColumn:10})
  assert.equal(source.provider,'opencorvus-search-code');assert.equal(source.snippet,file.text.split('\r\n')[1])
  assert.equal(outcome.output.includes(`  Line 2: ${source.snippet}`),true)
  assert.deepEqual(canonical.parts.find((p:any)=>p.id===row.id).range,source.range)
 }
 const final=canonical.messages.find((m:any)=>m.id===surface.finalID)
 assert.equal(final.finish,'stop');assert.equal(typeof final.time.completed,'number')
 const expected=(surface.name==='side-current'?[inputs.files[0].reference]:[
  ...inputs.files.map((f:any)=>f.reference),inputs.files[0].path.replaceAll('\\','/')+':2:10',
 ]).map((s:string)=>'`'+s+'`').join('\n')
 assert.equal(canonical.parts.find((p:any)=>p.messageID===surface.finalID&&p.type==='text').text,expected)
 results.push({...surface,requestPartID:request.id,outputChars:outcome.output.length,finalText:expected,sources:rows.map(s=>({id:s.id,path:s.data.path,range:s.data.range}))})
}
const payload=(id:string)=>sources.filter(s=>s.message_id===id).map(s=>({sourceId:s.data.sourceId,path:s.data.path,range:s.data.range,snippet:s.data.snippet,title:s.data.title,provider:s.data.provider}))
assert.deepEqual(payload(surfaces[0]!.messageID),payload(surfaces[1]!.messageID))
const preflight=read(label+'-preflight-ready.json')
assert.deepEqual(preflight.preflight,{sessionID:'ses_hOKrfG7mdEpsgumpEbuT',credential:'usable',catalog:'projected',actualModel:'gpt-6.1-sol',streaming:true})
const provider=read(label+'-final-provider-audit.json');assert.deepEqual({requests:provider.requests.length,exhausted:provider.exhausted},{requests:9,exhausted:false})
for(const request of provider.requests){assert.equal(request.model,'gpt-6.1-sol');assert.equal(request.streaming,true);assert.equal(request.status,200);assert.equal(request.response_reader.terminal.kind,'eof');assert.equal(request.response_reader.state,'settled')}
const settled=read(label+'-native-host-settled.json')
for(const key of ['physicalCompletion','outputDrainComplete','requestCleanupComplete'])assert.equal(settled[key],true)
assert.equal(settled.terminal.reason,'exited');assert.equal(settled.terminal.exitCode,0)
const qualified=read(label+'-qualified-surface-completion.json');assert.equal(qualified.qualification,'NativeService');assert.equal(qualified.physicalCompletion,true);assert.equal(qualified.providerEOFRequests,9)
const cleanup=read(label+'-physical-terminal-and-pair-cleanup.json');assert.equal(cleanup.pairedCleanupComplete,true);assert.deepEqual(cleanup.copiedPair.map((e:any)=>e.outcome),['removed','removed'])
const http=read(label+'-http-summary.json'),served=http.requests.find((r:any)=>r.data?.path==='/ui/assets/main-aBfB0VSj.js'&&r.data?.status==='completed');assert.equal(served.data.statusCode,200)
const birth=Number(BigInt(settled.target.processInstanceID.slice(6))/10000n-62135596800000n)
const result={checkedAt:new Date().toISOString(),initialHandle:91532,launcherExitCode:0,sourceResults:results,providerRequests:9,qualification:qualified,elapsedMs:Date.parse(settled.observedAtUtc)-birth,settled,served,boundary:'Real canonical Source and natural model messages retain exact authored Unicode paths and columns. Main/Side copy/current facts distinguished. Complete file bytes, production ToolOutcome output, provider streams and physical closure. No renderer, DOM or screenshot assertions; UI verification is manual.'}
fs.mkdirSync(path.join(evidence,'checks'),{recursive:true});fs.writeFileSync(path.join(evidence,'checks/runtime-qualification.json'),JSON.stringify(result,null,2)+'\n')
console.log(JSON.stringify({sources:9,requests:9,elapsedMs:result.elapsedMs,originalLauncherExit:0}))
