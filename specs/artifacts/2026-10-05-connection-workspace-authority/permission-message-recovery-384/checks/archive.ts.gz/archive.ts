import fs from "node:fs"
import path from "node:path"
import { gzipSync, gunzipSync } from "node:zlib"
import { CredentialRedactor } from "../../packages/opencorvus/script/real-provider-audit"
const scratch=path.resolve(".tmp-product-iteration/permission-message-recovery-384")
const root=path.resolve("specs/artifacts/2026-10-05-connection-workspace-authority/permission-message-recovery-384")
const redactor=new CredentialRedactor()
redactor.collect(JSON.parse(fs.readFileSync("C:/Users/hengu/AppData/Local/opencorvus/data/auth.json","utf8")))
const files: {source:string;archive:string;bytes:number;compressedBytes:number}[]=[]
function pack(source:string,relative:string){
 const raw=Buffer.from(redactor.redact(fs.readFileSync(source,"utf8"))),packed=gzipSync(raw,{level:9})
 if(!gunzipSync(packed).equals(raw))throw Error("Archive bytes differ from complete redacted evidence")
 const destination=path.resolve(root,relative)
 if(!destination.startsWith(root+path.sep))throw Error("Evidence destination escaped root")
 fs.mkdirSync(path.dirname(destination),{recursive:true})
 fs.writeFileSync(destination,packed,{flag:"wx"})
 files.push({source,archive:relative,bytes:raw.length,compressedBytes:packed.length})
}
for(const entry of fs.readdirSync(scratch,{recursive:true,withFileTypes:true})){
 if(!entry.isFile()||! /\.(log|json|ts|mjs)$/.test(entry.name))continue
 const source=path.join(entry.parentPath,entry.name)
 pack(source,path.join("checks",path.relative(scratch,source)+".gz"))
}
for(const name of ["push.log","push-after-merge.log"]){
 pack(path.resolve(".tmp-product-iteration/source-result-commit-383",name),`checks/previous-383-${name}.gz`)
}
fs.writeFileSync(path.join(root,"checks/archive-receipt.json"),JSON.stringify({files,
 integrity:"Every complete redacted log/probe retains exactly its decompressed bytes; private originals preserved",
 qualification:"Two correct-behavior contracts failed; archive integrity is not product acceptance"},null,2)+"\n",{flag:"wx"})
let scanned=0
for(const entry of fs.readdirSync(root,{recursive:true,withFileTypes:true})){
 if(!entry.isFile())continue
 const raw=fs.readFileSync(path.join(entry.parentPath,entry.name))
 const text=(entry.name.endsWith(".gz")?gunzipSync(raw):raw).toString("utf8")
 if(redactor.containsCredential(text))throw Error("Credential present in evidence")
 scanned++
}
fs.writeFileSync(path.join(root,"checks/credential-scan.json"),JSON.stringify({scanned,credentialMatches:0,scope:"All complete text and decompressed archives"},null,2)+"\n",{flag:"wx"})
console.log(JSON.stringify({archives:files.length,scanned,credentialMatches:0}))
