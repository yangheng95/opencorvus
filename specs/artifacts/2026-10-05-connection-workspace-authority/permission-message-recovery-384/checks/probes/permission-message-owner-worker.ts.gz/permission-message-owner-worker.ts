import fs from "node:fs/promises"
import { setTimeout as pause } from "node:timers/promises"
import { Instance } from "../../src/project/instance"
import { declareNativeTaskProcessDeployment } from "../../src/runtime/task-process-deployment"
import { SessionLoop } from "../../src/session/loop"
import { SessionPromptOwner } from "../../src/session/prompt/owner"
import { SessionPromptState } from "../../src/session/prompt/state"
import { MessageStore } from "../../src/session/message-store"
import { Database } from "../../src/storage/db"
import { permissionMessageResult } from "./permission-message-result"

const [mode, directory, filePath, stateFile] = process.argv.slice(2)
if (!mode || !directory || !filePath || !stateFile) throw new Error("Exact owned process inputs required")
declareNativeTaskProcessDeployment()
await Instance.provide({ directory, fn: async () => {
  if (mode === "hold") {
    const value = await permissionMessageResult(filePath)
    const abort = SessionPromptState.start(value.session.id, directory)
    if (!abort) throw new Error("Actual prompt owner required")
    SessionPromptState.bindMessageOwner(value.session.id, value.assistant.id, abort)
    try {
      await fs.writeFile(stateFile, JSON.stringify({ request: value.request,
        owner: SessionPromptOwner.current(value.session.id), pid: process.pid }), { flag: "wx" })
      for await (const input of process.stdin) { if (input.length > 0) break }
    } finally { await SessionPromptState.finish(value.session.id, abort, directory) }
    return
  }
  if (mode !== "inspect") throw new Error(`Unexpected owner probe mode ${mode}`)
  const state = JSON.parse(await fs.readFile(stateFile, "utf8"))
  const identity = { sessionID: state.request.sessionID, messageID: state.request.messageID }
  const before = await MessageStore.get(identity)
  const observed = SessionPromptOwner.observeCurrent(identity.sessionID)
  let outcome: unknown
  try { outcome = await Promise.race([
    SessionLoop.resumePermissionContinuation(state.request),
    pause(5_000).then(() => ({ observation: "continuation-still-pending" })),
  ]) }
  catch (error) { outcome = { error: error instanceof Error ? `${error.name}: ${error.message}` : String(error) } }
  const after = await MessageStore.get(identity)
  const evidence = { state, observed, outcome, before, after,
    currentOwner: SessionPromptOwner.current(identity.sessionID) }
  // The inspector observes a held peer; never join that peer's open Turn just
  // to publish the observation. Its owned process is the bounded probe scope.
  await new Promise<void>((resolve) => process.stdout.write(JSON.stringify(evidence), () => resolve()))
  process.exit(0)
} })
await Instance.disposeAll()
Database.close()
