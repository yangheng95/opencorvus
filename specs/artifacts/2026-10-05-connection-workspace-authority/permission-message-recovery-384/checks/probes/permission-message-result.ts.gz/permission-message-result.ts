import { Bus } from "../../src/bus"
import { PermissionAuthority } from "../../src/permission/authority"
import { completedReadResult } from "./completed-read-result"

export async function permissionMessageResult(filePath: string) {
  let request: PermissionAuthority.Request | undefined
  const stop = Bus.subscribe(PermissionAuthority.Event.Asked, ({ properties }) => { request = properties })
  try {
    const value = await completedReadResult({ mode: "ask", filePath })
    if (!request || request.toolCallID !== value.callID) throw new Error("Actual read permission request required")
    await value.processor.completeRecoveredToolPart({ toolCallID: value.callID, toolInput: value.args, output: value.result })
    return { ...value, request }
  } finally { stop() }
}
