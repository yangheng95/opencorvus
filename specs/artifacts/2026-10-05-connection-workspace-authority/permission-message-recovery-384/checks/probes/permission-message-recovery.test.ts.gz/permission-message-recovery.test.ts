import { afterAll, expect, test } from "bun:test"
import fs from "node:fs/promises"
import path from "node:path"
import { setTimeout as pause } from "node:timers/promises"
import { createManagedTemporaryDirectory, removeManagedDirectoryTree } from "@opencorvus-ai/util/runtime-directories"
import { Instance } from "../../src/project/instance"
import { SessionLoop } from "../../src/session/loop"
import { MessageStore } from "../../src/session/message-store"
import { completedReadResult } from "../fixture/completed-read-result"
import { permissionMessageResult } from "../fixture/permission-message-result"
import { memoryProject, resetMemoryDatabase } from "../fixture/memory"

afterAll(resetMemoryDatabase)

async function withSource(body: (scope: string, filePath: string) => Promise<void>) {
  const root = process.env.OPENCORVUS_TEST_PROCESS_ROOT
  if (!root) throw new Error("Isolated test runtime required")
  const scope = await createManagedTemporaryDirectory(root, "permission-message-")
  try {
    const filePath = path.join(scope, "source.txt")
    await fs.writeFile(filePath, "Permission recovery belongs to its complete message.\n")
    await body(scope, filePath)
  } finally { await removeManagedDirectoryTree(scope) }
}

test("a settled invocation leaves its message available for the remaining accepted Tool", async () => {
  await using project = await memoryProject()
  await withSource(async (_scope, filePath) => {
    await Instance.provide({ directory: project.path, fn: async () => {
      const first = await permissionMessageResult(filePath)
      const second = await completedReadResult({ mode: "ask", filePath, session: first.session, message: first.assistant })
      const identity = { sessionID: first.session.id, messageID: first.assistant.id }
      const before = await MessageStore.get(identity)
      let outcome: unknown
      try { outcome = await SessionLoop.resumePermissionContinuation(first.request) }
      catch (error) { outcome = { error: error instanceof Error ? `${error.name}: ${error.message}` : String(error) } }
      const after = await MessageStore.get(identity)
      console.log("permission-message-evidence " + JSON.stringify({ scenario: "remaining-tool", outcome, before, after }))
      expect(outcome).toBe("resumed")
      expect(after.info).toEqual(before.info)
      expect(after.parts.find((part) => part.id === second.part.id)).toMatchObject({ state: { status: "running" } })
      await second.processor.completeRecoveredToolPart({ toolCallID: second.callID, toolInput: second.args, output: second.result })
      expect((await MessageStore.parts(first.assistant.id)).filter((part) => part.type === "tool")
        .map((part) => part.state.status)).toEqual(["completed", "completed"])
      expect([first.executeCount(), second.executeCount()]).toEqual([1, 1])
    } })
  })
}, 60_000)

test("a live peer process retains the exact message it owns during permission recovery", async () => {
  await using project = await memoryProject()
  await withSource(async (scope, filePath) => {
    const stateFile = path.join(scope, "owner.json")
    const worker = path.resolve(import.meta.dir, "../fixture/permission-message-owner-worker.ts")
    const children: ReturnType<typeof Bun.spawn>[] = []
    const spawn = (mode: string) => {
      const child = Bun.spawn([process.execPath, `--config=${path.resolve(import.meta.dir, "../empty-bunfig.toml")}`,
        worker, mode, project.path, filePath, stateFile], {
        cwd: path.resolve(import.meta.dir, "../.."),
        env: { ...process.env, OPENCORVUS_HOME: path.join(scope, "runtime") },
        stdin: "pipe", stdout: "pipe", stderr: "pipe",
      })
      children.push(child)
      return child
    }
    const holder = spawn("hold")
    const holderOutput = Promise.all([new Response(holder.stdout).text(), new Response(holder.stderr).text()])
    try {
      const deadline = Date.now() + 60_000
      while (true) {
        try { JSON.parse(await fs.readFile(stateFile, "utf8")); break } catch (error) {
          if (holder.exitCode !== null) throw new Error(`Owner exited ${holder.exitCode}: ${(await holderOutput)[1]}`)
          if (Date.now() > deadline) throw new Error("Actual live owner readiness deadline exceeded", { cause: error })
          await pause(20)
        }
      }
      const inspector = spawn("inspect")
      const [stdout, stderr, exitCode] = await Promise.all([
        new Response(inspector.stdout).text(), new Response(inspector.stderr).text(), inspector.exited,
      ])
      expect(exitCode, stderr).toBe(0)
      const evidence = JSON.parse(stdout)
      console.log("permission-message-evidence " + JSON.stringify({ scenario: "live-peer", ...evidence }))
      expect(evidence.observed).toMatchObject({ observation: "exact_live", authority: { owner_pid: holder.pid } })
      expect(evidence.outcome).toBe("live")
      expect(evidence.after).toEqual(evidence.before)
      expect(evidence.currentOwner).toEqual(evidence.state.owner)
    } finally {
      if (holder.exitCode === null) { holder.stdin.write("release\n"); holder.stdin.end() }
      await holder.exited
      await holderOutput
      for (const child of children) if (child.exitCode === null) child.kill()
      await Promise.all(children.map((child) => child.exited))
    }
  })
}, 120_000)
