import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
const scratch=path.resolve('.tmp-product-iteration/permission-message-recovery-384')
const root=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/permission-message-recovery-384')
fs.mkdirSync(root,{recursive:true})
const prefix='permission-message-evidence '
const original=fs.readFileSync(path.join(scratch,'contracts-before-bounded.log'),'utf8')
const evidence=original.split(/\r?\n/).filter(line=>line.startsWith(prefix)).map(line=>JSON.parse(line.slice(prefix.length)))
assert.deepEqual(evidence.map(row=>row.scenario),['remaining-tool','live-peer'])
for(const item of evidence){
 assert.equal(item.before.info.id,item.after.info.id)
 assert.equal(item.before.info.sessionID,item.after.info.sessionID)
 assert.equal(item.before.info.time.created,item.after.info.time.created)
}
const peer=evidence[1]
assert.equal(peer.observed.authority.owner_pid,peer.state.pid)
assert.deepEqual(peer.currentOwner,peer.state.owner)
const result={
 qualification:'failed',correctBehaviorContracts:{passed:0,failed:2},
 observations:evidence.map(item=>({
   scenario:item.scenario,sessionID:item.before.info.sessionID,messageID:item.before.info.id,
   beforeTime:item.before.info.time,afterTime:item.after.info.time,afterFinish:item.after.info.finish,
   outcome:item.outcome,toolStates:item.after.parts.filter(part=>part.type==='tool').map(part=>({id:part.id,status:part.state.status})),
   sourceParts:item.after.parts.filter(part=>part.type==='source-file'),
   ...(item.observed?{owner:item.observed,ownerAfter:item.currentOwner}:{}),
 })),
 originalRunner:{execSession:18798,exitCode:1,observationToolFailure:'Peer inspector joined the held owner; 120000ms test deadline; runner terminated its two owned child processes'},
 boundedRunner:{execSession:34448,exitCode:1,seconds:23.64,peerObservationMilliseconds:5000,childClosure:'Inspector exits after snapshot; holder released by stdin and joined in finally'},
 boundary:'Actual read, Permission receipt, canonical SQLite and physical peer owner. This checker validates evidence identity only; the two expected-correct-behavior tests failed. No real Provider or UI qualification.'
}
fs.writeFileSync(path.join(root,'failure-review.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'})
fs.writeFileSync(path.join(scratch,'canonical-observations.json'),JSON.stringify(evidence,null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({qualification:result.qualification,contracts:result.correctBehaviorContracts,scenarios:result.observations.map(row=>({scenario:row.scenario,outcome:row.outcome,afterFinish:row.afterFinish,toolStates:row.toolStates,ownerObservation:row.owner?.observation}))}))
