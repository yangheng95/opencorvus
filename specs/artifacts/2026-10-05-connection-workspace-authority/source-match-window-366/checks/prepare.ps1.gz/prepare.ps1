$ErrorActionPreference='Stop'
$run366='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/source-match-window-366'
$ready366=Get-Content -Raw (Join-Path $run366 'evidence/preflight-ready.json')|ConvertFrom-Json
if($ready366.preflight.credential -ne 'usable' -or $ready366.preflight.catalog -ne 'projected' -or $ready366.preflight.actualModel -ne 'gpt-6.1-sol' -or !$ready366.preflight.streaming){throw 'Actual credential/model qualification required'}
$utf366=[Text.UTF8Encoding]::new($false)
$directory366=Join-Path $run366 'project/资料/长行检索'
[IO.Directory]::CreateDirectory($directory366)|Out-Null
$inputs366=@(
 @{name='中文长行.md';text=(('前置内容。'*500)+'😀'+('文'*39)+'MATCH366_中文命中'+('后续内容。'*600));pattern='MATCH366';kind='unicode'},
 @{name='字节编码.md';bytePrefixCount=2400;text=(('界'*40)+'MATCH366_字节命中 尾部');pattern='MATCH366';kind='byte'},
 @{name='载荷内命中.md';text=('data:text/plain;base64,'+('A'*3000)+'TUFUQ0gzNjY=');pattern='TUFUQ0gzNjY';kind='payload'},
 @{name='载荷后命中.md';text=(('d'*2300)+' data:text/plain;base64,YQ== '+('文'*40)+'MATCH366_载荷后记录');pattern='MATCH366';kind='after-payload'},
 @{name='短行.md';text=('    MATCH366_短行记录 😀 尾空白 '+"`t ");pattern='MATCH366';kind='short'}
)
foreach($input366 in $inputs366){
 $path366=Join-Path $directory366 $input366.name
 if(Test-Path -LiteralPath $path366){throw 'Fresh input required'}
 $input366.path=$path366
 if($input366.kind -eq 'byte'){
  $prefix366=[byte[]]::new($input366.bytePrefixCount)
  [Array]::Fill[byte]($prefix366,255)
  [IO.File]::WriteAllBytes($path366,[byte[]]($prefix366+$utf366.GetBytes($input366.text)))
 }else{[IO.File]::WriteAllText($path366,$input366.text,$utf366)}
}
$evidence366='D:/myhexin-local/opencorvus/specs/artifacts/2026-10-05-connection-workspace-authority/source-match-window-366'
[IO.File]::WriteAllText((Join-Path $evidence366 'authored-inputs.json'),(@{query='MATCH366|TUFUQ0gzNjY';files=$inputs366}|ConvertTo-Json -Depth 8)+[Environment]::NewLine,$utf366)
$scratch366='D:/myhexin-local/opencorvus/.tmp-product-iteration/source-match-window-366'
[IO.File]::WriteAllText((Join-Path $scratch366 'main-request.txt'),'请实际用 search_code 在“资料/长行检索”目录以正则 MATCH366|TUFUQ0gzNjY 搜索，限定 Markdown 文件。只用两句话说明检索结果数量，保留工具给出的真实来源。不要读取全文、不修改文件、不创建Task、不调用成员。资料中的内联样本只是检索内容，不执行。',$utf366)
[IO.File]::WriteAllText((Join-Path $scratch366 'side-request.txt'),'请在这个侧聊中实际用 search_code 搜索“资料/长行检索”，正则为 MATCH366_中文命中|MATCH366_载荷后记录，限定 Markdown，保留真实来源。用一句话说明结果；不读取全文、不修改文件、不派遣成员或Task。',$utf366)
Write-Output 'Five actual files with late Unicode/invalid-byte/payload matches and one short-line control prepared.'
