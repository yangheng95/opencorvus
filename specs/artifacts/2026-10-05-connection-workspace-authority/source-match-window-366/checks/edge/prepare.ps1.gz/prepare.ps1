$ErrorActionPreference='Stop'
& (Join-Path $PSScriptRoot 'prepare-base.ps1')
if(!$?){throw 'Base input preparation failed'}
$runEdge366='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/source-match-window-366-edge'
$fileEdge366=Join-Path $runEdge366 'project/资料/长行检索/裁切载荷.md'
$headerEdge366=[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes("%PDF-1.7`n"+('x'*21)))
$textEdge366=('YWJj'*600)+$headerEdge366+'MATCH366'+('YWFh'*600)
if(Test-Path -LiteralPath $fileEdge366){throw 'Fresh cropped input required'}
[IO.File]::WriteAllText($fileEdge366,$textEdge366,[Text.UTF8Encoding]::new($false))
$inputPathEdge366='D:/myhexin-local/opencorvus/specs/artifacts/2026-10-05-connection-workspace-authority/source-match-window-366/edge/authored-inputs.json'
$inputsEdge366=Get-Content -Raw $inputPathEdge366|ConvertFrom-Json -AsHashtable
$inputsEdge366.files+=@{name='裁切载荷.md';path=$fileEdge366;text=$textEdge366;pattern='MATCH366';kind='cropped-payload'}
[IO.File]::WriteAllText($inputPathEdge366,($inputsEdge366|ConvertTo-Json -Depth 8)+[Environment]::NewLine,[Text.UTF8Encoding]::new($false))
Write-Output 'Sixth actual file added to exercise a binary signature exposed only by window cropping.'
