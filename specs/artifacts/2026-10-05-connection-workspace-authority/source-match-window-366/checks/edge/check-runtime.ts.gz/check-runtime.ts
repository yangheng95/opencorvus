import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import {Database} from 'bun:sqlite'
const run='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/source-match-window-366-edge'
const evidence=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/source-match-window-366/edge')
const label='source-match-window-366-edge',read=(name:string)=>JSON.parse(fs.readFileSync(path.join(evidence,name),'utf8'))
const inputs=read('authored-inputs.json'),canonical=read('canonical-current-conversations.json')
for(const file of inputs.files){
 const expected=file.kind==='byte'?Buffer.concat([Buffer.alloc(file.bytePrefixCount,255),Buffer.from(file.text)]):Buffer.from(file.text)
 assert.deepEqual(fs.readFileSync(file.path),expected)
}
const db=new Database(path.join(run,'runtime/data/opencorvus.db'),{readonly:true})
let sources:any[]
try{db.exec('BEGIN');sources=(db.query("SELECT p.id,p.message_id,m.session_id,p.data FROM part p JOIN message m ON m.id=p.message_id WHERE json_extract(p.data,'$.type')='source-file' ORDER BY p.time_created,p.id").all() as any[]).map(r=>({...r,data:JSON.parse(r.data)}))}finally{db.exec('ROLLBACK');db.close()}
assert.equal(sources.length,6)
const request=canonical.tools.find((r:any)=>r.message_id==='msg_g0VXsPu5Y00k8OgzbrfL'),data=JSON.parse(request.data)
assert.equal(data.tool,'search_code');assert.deepEqual(data.input,{pattern:'MATCH366|TUFUQ0gzNjY',path:'资料/长行检索',include:'*.md'})
const outcome=canonical.outcomes.find((o:any)=>o.requestPartID===request.id)
assert.equal(outcome.outcome,'completed');assert.equal(outcome.output.split('\n')[0],'Found 6 matches')
for(const row of sources){
 assert.equal(row.session_id,'ses_-zUS7a6D1zzJT6qwYjYl');assert.equal(row.message_id,request.message_id)
 const source=row.data,file=inputs.files.find((f:any)=>f.path===source.path);assert.ok(file)
 assert.deepEqual(source.range,{startLine:1,endLine:1});assert.equal(source.provider,'opencorvus-search-code')
 const expected=file.kind==='unicode'?'...'+file.text.slice(2500,4500)+'...':file.kind==='byte'?'...'+file.text:file.kind==='payload'?'inline_binary_omitted(kind=data_url offset=0 media=text/plain payload_chars=3012)':file.kind==='after-payload'?'...'+'文'.repeat(40)+'MATCH366_载荷后记录':file.kind==='cropped-payload'?'...inline_binary_omitted(kind=raw_base64 offset=3 reason=binary_magic payload_chars=2000)...':file.text
 assert.equal(source.snippet,expected);assert.equal(canonical.parts.find((p:any)=>p.id===row.id).snippet,expected)
 assert.equal(outcome.output.includes(`  Line 1: ${expected}`),true)
}
const preflight=read(label+'-preflight-ready.json');assert.deepEqual(preflight.preflight,{sessionID:'ses_hRptWvSyfI1BCTrz1jTJ',credential:'usable',catalog:'projected',actualModel:'gpt-6.1-sol',streaming:true})
const provider=read(label+'-final-provider-audit.json');assert.equal(provider.requests.length,5)
for(const request of provider.requests){assert.equal(request.model,'gpt-6.1-sol');assert.equal(request.streaming,true);assert.equal(request.status,200);assert.equal(request.response_reader.terminal.kind,'eof');assert.equal(request.response_reader.state,'settled')}
const settled=read(label+'-native-host-settled.json');for(const key of ['physicalCompletion','outputDrainComplete','requestCleanupComplete'])assert.equal(settled[key],true)
assert.equal(settled.terminal.reason,'exited');assert.equal(settled.terminal.exitCode,0)
const qualified=read(label+'-qualified-surface-completion.json');assert.equal(qualified.qualification,'NativeService');assert.equal(qualified.physicalCompletion,true);assert.equal(qualified.providerEOFRequests,5)
const cleanup=read(label+'-physical-terminal-and-pair-cleanup.json');assert.equal(cleanup.pairedCleanupComplete,true);assert.deepEqual(cleanup.copiedPair.map((p:any)=>p.outcome),['removed','removed'])
const http=read(label+'-http-summary.json'),served=http.requests.find((r:any)=>r.data?.path==='/ui/assets/main-C_UK_gz4.js'&&r.data?.status==='completed');assert.equal(served.data.statusCode,200)
const birth=Number(BigInt(settled.target.processInstanceID.slice(6))/10000n-62135596800000n)
const result={at:new Date().toISOString(),initialHandle:98870,launcherExitCode:0,requestCount:provider.requests.length,elapsedMs:Date.parse(settled.observedAtUtc)-birth,settled,qualified,served,sourceCount:sources.length,sourceSnippets:sources.map(r=>({id:r.id,path:r.data.path,snippet:r.data.snippet})),boundary:'Final crop-redaction implementation: actual completed SQLite Source, production ToolOutcome and authored file bytes compared. Six real files, five real streaming gpt-6.1-sol EOF responses and Native closure. Earlier Side coverage is separate; special cropped payload was exercised in Main only.'}
fs.writeFileSync(path.join(evidence,'runtime-qualification.json'),JSON.stringify(result,null,2)+'\n')
console.log(JSON.stringify({sources:sources.length,requests:provider.requests.length,elapsedMs:result.elapsedMs,model:provider.model,exit:0}))
