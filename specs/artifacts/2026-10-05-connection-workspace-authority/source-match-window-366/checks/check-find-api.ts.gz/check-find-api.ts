import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import {createOpenCorvusClient} from '../../packages/sdk/js/src/client'
const root=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/source-match-window-366')
const inputs=JSON.parse(fs.readFileSync(path.join(root,'authored-inputs.json'),'utf8'))
const directory=path.dirname(inputs.files[0].path)
const client=createOpenCorvusClient({baseUrl:'http://localhost:18366',directory})
const response=await client.find.text({pattern:'MATCH366'})
assert.equal(response.response.status,200)
const expected=inputs.files.filter((file:any)=>file.pattern==='MATCH366').map((file:any)=>{
 const bytes=fs.readFileSync(file.path),start=bytes.indexOf(Buffer.from('MATCH366'))
 return {path:{text:file.name},lines:{text:bytes.toString('utf8')},line_number:1,absolute_offset:0,submatches:[{match:{text:'MATCH366'},start,end:start+8}]}
})
const order=(rows:any[])=>[...rows].sort((a,b)=>a.path.text.localeCompare(b.path.text))
fs.writeFileSync(path.join(root,'find-api-response.json'),JSON.stringify({directory,status:response.response.status,data:response.data},null,2)+'\n')
assert.deepEqual(order(response.data!),order(expected))
fs.writeFileSync(path.join(root,'find-api-qualification.json'),JSON.stringify({at:new Date().toISOString(),status:200,matches:expected.length,contract:'Actual SDK find.text endpoint returns original public Match shape, complete decoded line and original byte offsets, compared against exact authored files. Internal parser bytes are used only within the server.'},null,2)+'\n')
console.log(JSON.stringify({status:200,matches:expected.length,contract:'Original complete public Match data preserved'}))
