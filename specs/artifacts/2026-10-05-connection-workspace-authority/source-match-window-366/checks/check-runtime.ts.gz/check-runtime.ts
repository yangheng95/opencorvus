import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import {Database} from 'bun:sqlite'
const run='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/source-match-window-366'
const evidence=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/source-match-window-366')
const folder=path.join(evidence,'live'),label='source-match-window-366-live'
const read=(name:string)=>JSON.parse(fs.readFileSync(path.join(folder,name),'utf8'))
const canonical=read('canonical-current-conversations.json')
const inputs=JSON.parse(fs.readFileSync(path.join(evidence,'authored-inputs.json'),'utf8'))
for(const file of inputs.files){
 const expected=file.kind==='byte'?Buffer.concat([Buffer.alloc(file.bytePrefixCount,255),Buffer.from(file.text)]):Buffer.from(file.text)
 assert.deepEqual(fs.readFileSync(file.path),expected)
}
const db=new Database(path.join(run,'runtime/data/opencorvus.db'),{readonly:true})
let actualSources:any[]
try{db.exec('BEGIN');actualSources=(db.query("SELECT p.id,p.message_id,m.session_id,p.data FROM part p JOIN message m ON m.id=p.message_id WHERE json_extract(p.data,'$.type')='source-file' ORDER BY p.time_created,p.id").all() as any[]).map(r=>({...r,data:JSON.parse(r.data)}))}finally{db.exec('ROLLBACK');db.close()}
assert.equal(actualSources.length,12)
const surfaces=[
 {name:'main',sessionID:'ses_-zUS7cUQEzzse898DTWD',messageID:'msg_g0VXsNVs30051E6w76QA',count:5,pattern:'MATCH366|TUFUQ0gzNjY'},
 {name:'side-reference',sessionID:'ses_-zUS7cES5zzqueXsqKUW',messageID:'msg_g0VXsNlXx01c3xpR2uyz',count:5,pattern:'MATCH366|TUFUQ0gzNjY'},
 {name:'side-current',sessionID:'ses_-zUS7cES5zzqueXsqKUW',messageID:'msg_g0VXsNqAR00aRoy5VpTY',count:2,pattern:'MATCH366_中文命中|MATCH366_载荷后记录'},
]
const results=[]
for(const surface of surfaces){
 const request=canonical.tools.find((t:any)=>t.message_id===surface.messageID),data=JSON.parse(request.data)
 assert.equal(data.tool,'search_code');assert.deepEqual(data.input,{pattern:surface.pattern,path:'资料/长行检索',include:'*.md'})
 const outcome=canonical.outcomes.find((o:any)=>o.requestPartID===request.id)
 assert.equal(outcome.outcome,'completed');assert.equal(outcome.output.split('\n')[0],`Found ${surface.count} matches`)
 const sources=actualSources.filter(s=>s.message_id===surface.messageID);assert.equal(sources.length,surface.count)
 for(const row of sources){
  assert.equal(row.session_id,surface.sessionID)
  const source=row.data,file=inputs.files.find((f:any)=>f.path===source.path);assert.ok(file)
  assert.deepEqual(source.range,{startLine:1,endLine:1});assert.equal(source.provider,'opencorvus-search-code')
  const expected=file.kind==='unicode'?'...'+file.text.slice(2500,4500)+'...':file.kind==='byte'?'...'+file.text:file.kind==='payload'?'inline_binary_omitted(kind=data_url offset=0 media=text/plain payload_chars=3012)':file.kind==='after-payload'?'...'+'文'.repeat(40)+'MATCH366_载荷后记录':file.text
  assert.equal(source.snippet,expected)
  assert.equal(canonical.parts.find((p:any)=>p.id===row.id).snippet,expected)
  assert.equal(outcome.output.includes(`  Line 1: ${expected}`),true)
 }
 results.push({...surface,requestPartID:request.id,toolOutputChars:outcome.output.length,snippets:sources.map(s=>({partID:s.id,path:s.data.path,chars:s.data.snippet.length}))})
}
const payloads=(messageID:string)=>actualSources.filter(s=>s.message_id===messageID).map(s=>({sourceId:s.data.sourceId,path:s.data.path,range:s.data.range,snippet:s.data.snippet,title:s.data.title,provider:s.data.provider}))
assert.deepEqual(payloads(surfaces[0].messageID),payloads(surfaces[1].messageID))
const preflight=read(label+'-preflight-ready.json')
assert.deepEqual(preflight.preflight,{sessionID:'ses_hIB8ew0e7f8RnXcdmXsN',credential:'usable',catalog:'projected',actualModel:'gpt-6.1-sol',streaming:true})
const provider=read(label+'-final-provider-audit.json');assert.equal(provider.requests.length,9)
for(const request of provider.requests){assert.equal(request.model,'gpt-6.1-sol');assert.equal(request.streaming,true);assert.equal(request.status,200);assert.equal(request.response_reader.terminal.kind,'eof');assert.equal(request.response_reader.state,'settled')}
const settled=read(label+'-native-host-settled.json')
for(const key of ['physicalCompletion','outputDrainComplete','requestCleanupComplete'])assert.equal(settled[key],true)
assert.equal(settled.terminal.reason,'exited');assert.equal(settled.terminal.exitCode,0)
const qualified=read(label+'-qualified-surface-completion.json');assert.equal(qualified.qualification,'NativeService');assert.equal(qualified.physicalCompletion,true);assert.equal(qualified.providerEOFRequests,9)
const cleanup=read(label+'-physical-terminal-and-pair-cleanup.json');assert.equal(cleanup.pairedCleanupComplete,true);assert.deepEqual(cleanup.copiedPair.map((entry:any)=>entry.outcome),['removed','removed'])
const http=read(label+'-http-summary.json'),served=http.requests.find((r:any)=>r.data?.path==='/ui/assets/main-C_UK_gz4.js'&&r.data?.status==='completed');assert.equal(served.data.statusCode,200)
const find=JSON.parse(fs.readFileSync(path.join(evidence,'find-api-qualification.json'),'utf8'));assert.equal(find.status,200);assert.equal(find.matches,4)
const birth=Number(BigInt(settled.target.processInstanceID.slice(6))/10000n-62135596800000n)
const result={checkedAt:new Date().toISOString(),initialHandle:35110,launcherExitCode:0,sourceResults:results,requestCount:provider.requests.length,model:provider.model,qualification:qualified,elapsedMs:Date.parse(settled.observedAtUtc)-birth,settled,served,find,boundary:'Actual SQLite Source records, production ToolOutcome output and complete authored file bytes. Side reference copies distinguished from new invocation. Actual provider EOF, API public contract and Native/output/request/authority closure. Visual review is separate manual evidence; no UI assertions.'}
fs.mkdirSync(path.join(evidence,'checks'),{recursive:true});fs.writeFileSync(path.join(evidence,'checks/runtime-qualification.json'),JSON.stringify(result,null,2)+'\n')
console.log(JSON.stringify({sources:results.map(s=>({surface:s.name,count:s.count})),requests:result.requestCount,elapsedMs:result.elapsedMs,model:provider.model,findMatches:find.matches,exit:0}))
