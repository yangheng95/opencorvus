import fs from 'node:fs'
import path from 'node:path'
const root=path.resolve('.tmp-product-iteration')
const scratch=path.join(root,'execution-actor-identity-390')
for(const suffix of ['.ts','-launch.ps1','-shutdown.ps1']){
 const previous=fs.readFileSync(path.join(root,'live-sol-child-refresh-389-final'+suffix),'utf8')
 const next=previous.replaceAll('child-refresh-retention-389-final','execution-actor-identity-390-live').replaceAll('live-sol-child-refresh-389-final','live-sol-execution-actor-390-live')
 // The first replacement changes only the run/bundle identity; wrapper names are separate.
 fs.writeFileSync(path.join(root,'live-sol-execution-actor-390-live'+suffix),next,{flag:'wx'})
}
const prior='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/child-refresh-retention-389-final-bundle/bin'
const next='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/execution-actor-identity-390-live-bundle/bin'
fs.cpSync(prior,next,{recursive:true,errorOnExist:true,force:false})
fs.mkdirSync(path.join(scratch,'live'),{recursive:true})
fs.mkdirSync(path.join(root,'execution-actor-identity-390-live-native-observer'),{recursive:true})
fs.copyFileSync(path.join(root,'child-refresh-retention-389/builtin.json'),path.join(scratch,'builtin.json'),fs.constants.COPYFILE_EXCL)
let facts=fs.readFileSync(path.join(root,'child-refresh-retention-389/read-facts.ts'),'utf8')
facts=facts.replaceAll("['before','after','final']","['live']").replaceAll('child-refresh-retention-389','execution-actor-identity-390')
fs.writeFileSync(path.join(scratch,'read-facts.ts'),facts,{flag:'wx'})
console.log('Prepared fresh 390 Native scope, reused immutable 389 formal frontend (backend-only change). No credentials staged yet.')
