import fs from 'node:fs'
import path from 'node:path'
import {gzipSync,gunzipSync} from 'node:zlib'
import {CredentialRedactor} from '../../packages/opencorvus/script/real-provider-audit'
const scratch=path.resolve('.tmp-product-iteration/execution-actor-identity-390')
const root=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/execution-actor-identity-390')
const redactor=new CredentialRedactor()
redactor.collect(JSON.parse(fs.readFileSync('C:/Users/hengu/AppData/Local/opencorvus/data/auth.json','utf8')))
const files:any[]=[]
function pack(source:string,relative:string){
 const raw=Buffer.from(redactor.redact(fs.readFileSync(source,'utf8'))),packed=gzipSync(raw,{level:9})
 if(!gunzipSync(packed).equals(raw))throw Error('Archive bytes changed')
 const target=path.resolve(root,'checks',relative+'.gz')
 if(!target.startsWith(root+path.sep))throw Error('Archive escaped exact root')
 fs.mkdirSync(path.dirname(target),{recursive:true})
 fs.writeFileSync(target,packed,{flag:'wx'})
 files.push({source,archive:path.relative(root,target).replaceAll('\\','/'),redactedBytes:raw.length,compressedBytes:packed.length})
}
for(const entry of fs.readdirSync(scratch,{recursive:true,withFileTypes:true})){
 if(!entry.isFile()||!/\.(json|jsonl|log|ts|mjs|ps1|patch)$/.test(entry.name))continue
 pack(path.join(entry.parentPath,entry.name),'local/'+path.relative(scratch,path.join(entry.parentPath,entry.name)))
}
const run='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/execution-actor-identity-390-live'
for(const name of ['stdout.log','stderr.log','startup.json','launch-owner.json','runtime/log/dev.log'])pack(path.join(run,name),'runtime/'+name)
for(const entry of fs.readdirSync(path.join(run,'evidence'),{withFileTypes:true})){
 if(entry.isFile()&&entry.name.endsWith('.json'))pack(path.join(run,'evidence',entry.name),'runtime/evidence/'+entry.name)
}
for(const suffix of ['.ts','-launch.ps1','-shutdown.ps1']){
 const name='live-sol-execution-actor-390-live'+suffix
 pack(path.resolve('.tmp-product-iteration',name),'launcher/'+name)
}
pack(path.join(run,'project/来源材料/方案甲.txt'),'input/方案甲.txt')
pack(path.join(run+'-bundle/bin/ui/index.html'),'static-ui/index.html')
pack(path.resolve('.tmp-product-iteration/child-refresh-retention-389/push.log'),'previous-389/push.log')
fs.writeFileSync(path.join(root,'checks/archive-receipt.json'),JSON.stringify({files,integrity:'Every complete redacted input equals its decompressed archive. Integrity check is not functional acceptance.',ui:'Immutable 389-final formal bundle copied for this backend-only change; same main-hq8_CedM.js. Manual screenshots 01–05 are the visual evidence.'},null,2)+'\n',{flag:'wx'})
let scanned=0
for(const entry of fs.readdirSync(root,{recursive:true,withFileTypes:true})){
 if(!entry.isFile()||entry.name.endsWith('.png'))continue
 const bytes=fs.readFileSync(path.join(entry.parentPath,entry.name))
 if(redactor.containsCredential((entry.name.endsWith('.gz')?gunzipSync(bytes):bytes).toString('utf8')))throw Error('Credential in archive')
 scanned++
}
fs.writeFileSync(path.join(root,'checks/credential-scan.json'),JSON.stringify({scanned,credentialMatches:0,scope:'All full text and decompressed archives; credential files excluded'},null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({archives:files.length,scanned,credentialMatches:0}))
