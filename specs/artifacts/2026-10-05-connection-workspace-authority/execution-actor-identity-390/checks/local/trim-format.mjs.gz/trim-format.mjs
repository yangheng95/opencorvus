import fs from 'node:fs'
import {execFileSync} from 'node:child_process'
const bridge='packages/opencorvus/src/orchestrator/protocol/message-bridge.ts'
const test='packages/opencorvus/test/task-event-projection-contract.test.ts'
for(const name of [bridge,test]){
 const diff=execFileSync('git',['diff','--',name],{encoding:'utf8'})
 fs.writeFileSync('.tmp-product-iteration/execution-actor-identity-390/'+name.split('/').at(-1)+'.formatted.patch',diff,{flag:'wx'})
}
const diff=execFileSync('git',['diff','--',bridge],{encoding:'utf8'})
const [header,...hunks]=diff.split(/(?=^@@ )/m)
const unrelated=hunks.filter(h=>Number(h.match(/^@@ -(\d+)/)[1])>1000)
execFileSync('git',['apply','--reverse','-'],{input:header+unrelated.join('')})
// Entire test diff reviewed: one added assertion plus formatter-only changes.
execFileSync('git',['restore','--',test])
