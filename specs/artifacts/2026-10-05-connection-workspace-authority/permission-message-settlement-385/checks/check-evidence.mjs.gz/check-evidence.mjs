import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
const scratch=path.resolve('.tmp-product-iteration/permission-message-settlement-385')
const root=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/permission-message-settlement-385')
fs.mkdirSync(root,{recursive:true})
const parse=(name,prefix)=>fs.readFileSync(path.join(scratch,name),'utf8').split(/\r?\n/)
 .filter(line=>line.startsWith(prefix)).map(line=>JSON.parse(line.slice(prefix.length)))
const stream=parse('stream-interruption.log','permission-message-evidence ')
const peer=stream.find(row=>row.scenario==='live-peer')
assert.equal(peer.outcome,'live');assert.equal(peer.observed.observation,'exact_live')
assert.deepEqual(peer.before,peer.after);assert.deepEqual(peer.currentOwner,peer.state.owner)
const handoff=stream.find(row=>row.scenario==='approval-during-release')
assert.equal(handoff.peerOutcome,'live');assert.equal(new Set(handoff.generations).size,2)
const fresh=stream.filter(row=>row.scenario==='fresh-streaming-tool')
assert.deepEqual(fresh.map(row=>row.abandonedProvider),[false,true])
const streaming=fresh.map(row=>{
 const old=row.messages.find(message=>message.parts.filter(part=>part.type==='tool').length===2)
 assert.deepEqual(old.parts.filter(part=>part.type==='tool').map(part=>part.state.status),['completed','completed'])
 assert.equal(old.info.finish,row.abandonedProvider?'error':'tool-calls')
 const next=row.messages.flatMap(message=>message.parts).find(part=>part.type==='tool'&&part.callID==='call_controlled_recovery_next')
 assert.equal(next.state.status,'completed')
 const source=row.messages.flatMap(message=>message.parts).find(part=>part.type==='source-file'&&part.toolPartID===next.id)
 assert.equal(source.messageID,next.messageID);assert.equal(source.path,next.state.input.filePath)
 const requests=row.requests.filter(request=>request.kind==='prompt')
 assert.equal(requests.length,2)
 for(const request of requests){assert.equal(request.body.stream,true);assert.equal(request.body.model,'result-recovery-contract')}
 return {abandonedProvider:row.abandonedProvider,originalMessageID:old.info.id,originalFinish:old.info.finish,
  nextToolID:next.id,nextMessageID:next.messageID,sourceID:source.id,requests:requests.length}
})
const phases=parse('contracts-final.log','permission-process-phase ')
const task=phases.filter(row=>row.mode==='recover').map(row=>{
 const value=row.evidence
 assert.deepEqual(value.first,value.second)
 assert.equal(value.first.assistant.finish,'tool-calls');assert.equal(value.first.part.status,'completed')
 assert.equal(value.first.executionStarts,1);assert.equal(value.first.executionSuccesses,1)
 assert.equal(value.first.automationCount,1);assert.equal(value.first.resultCount,1)
 assert.equal(value.first.requestFacts.filter(event=>event.event_type==='requested').length,1)
 return {cut:row.cut,toolID:value.first.part.id,completedAt:value.first.assistant.completed,effects:1,requestOwners:1}
})
assert.equal(task.length,2)
const mission=phases.find(row=>row.cut==='mission-pending').evidence
assert.equal(mission.observed.observation,'dead_or_reused');assert.equal(mission.outcome,'resumed')
assert.equal(mission.missionRecovery.status,'woken')
const completed=mission.after.parts.find(part=>part.type==='tool'&&part.callID===mission.state.request.toolCallID)
const interrupted=mission.after.parts.find(part=>part.type==='tool'&&part.callID===mission.state.pending.toolCallID)
assert.equal(completed.state.status,'completed');assert.equal(interrupted.state.failure.kind,'process-execution-interrupted')
assert.deepEqual(mission.after.parts.filter(part=>part.type==='source-file'),mission.before.parts.filter(part=>part.type==='source-file'))
const selected=new Map()
for(const name of ['process-contracts.log','regression-contracts.log','mission-and-authority.log','contracts-retirement.log','contracts-final.log','stream-interruption.log']){
 let file,passed,failed,assertions
 for(const line of fs.readFileSync(path.join(scratch,name),'utf8').split(/\r?\n/)){
  let m
  if(m=line.match(/^\[\d+\/\d+\] START (.+)$/)){file=m[1];passed=failed=assertions=undefined}
  if(m=line.match(/^\s+(\d+) pass$/))passed=+m[1]
  if(m=line.match(/^\s+(\d+) fail$/))failed=+m[1]
  if(m=line.match(/^\s+(\d+) expect\(\) calls$/))assertions=+m[1]
  if(line.includes('] DONE ')&&line.includes('exit=0')&&file&&failed===0){selected.set(file,{file,passed,assertions,log:name})}
 }
}
const contracts=[...selected.values()]
const result={qualification:'backend-contracts-passed',contracts,tests:contracts.reduce((n,r)=>n+r.passed,0),assertions:contracts.reduce((n,r)=>n+r.assertions,0),
 streaming,task,mission:{sessionID:mission.state.request.sessionID,ownerPID:mission.state.owner.owner_pid,
  recoveredToolID:completed.id,interruptedToolID:interrupted.id,wake:mission.missionRecovery},
 livePeer:{sessionID:peer.state.request.sessionID,ownerPID:peer.state.pid,outcome:peer.outcome},
 approvalDuringRelease:{generations:handoff.generations,peerOutcome:handoff.peerOutcome},
 boundary:'Real Tool/Permission/SQLite and controlled HTTP streaming SDK contracts; actual OS exit/restart and live peer. Provider interruption in the streaming fixture is injected canonical activity evidence. This is not real Sol or UI qualification.'}
assert.equal(result.tests,72);assert.equal(result.assertions,289)
fs.writeFileSync(path.join(root,'verification.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({qualification:result.qualification,tests:result.tests,assertions:result.assertions,streaming:streaming.length,task:task.length,mission:mission.missionRecovery.status}))
