param([switch]$ResumeCreation)
$ErrorActionPreference='Stop'
$env:PATH='D:/myhexin-local/opencorvus/.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64;'+$env:PATH
$root300='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-12/child-view-retention-353-live-01'
$scratch300='D:/myhexin-local/opencorvus/.tmp-product-iteration/child-view-retention-353'
$owner300=Get-Content -LiteralPath (Join-Path $root300 'launch-owner.json') -Raw|ConvertFrom-Json
$ready300=Get-Content -LiteralPath (Join-Path $root300 'evidence/preflight-ready.json') -Raw|ConvertFrom-Json
if($ready300.occurrence -ne $owner300.occurrence -or $ready300.preflight.actualModel -ne 'gpt-6.1-sol' -or !$ready300.preflight.streaming){throw 'Exact real model preflight required'}
$env:OPENCORVUS_HOME=Join-Path $root300 'client-runtime'
$env:OPENCORVUS_TEST_HOME=Join-Path $root300 'client-home'
$env:OPENCORVUS_TEST_PROCESS_ROOT=$root300
$env:OPENCORVUS_DISABLE_EXTERNAL_SKILLS='1'
$env:OPENCORVUS_DISABLE_AUTOUPDATE='1'
$request300=Get-Content -LiteralPath (Join-Path $scratch300 'request.txt') -Raw
$creationLog300=Join-Path $scratch300 'task-create.log'
if($ResumeCreation){
 $original300=Get-Content -LiteralPath (Join-Path $scratch300 'sent.json') -Raw|ConvertFrom-Json -DateKind String
 $requestId300=$original300.requestID
 if(!$requestId300){throw 'Original request identity required'}
 $creationLog300=Join-Path $scratch300 'task-create-retry.log'
 if(Test-Path -LiteralPath $creationLog300){throw 'Original retry output retained; inspect it'}
}else{
 if(Test-Path -LiteralPath (Join-Path $scratch300 'sent.json')){throw 'Original creation attempt retained; inspect it rather than creating another Task'}
 $requestId300=[guid]::NewGuid().ToString()
}
$sent300=[DateTime]::UtcNow.ToString('o')
@{requestID=$requestId300;requestSentAt=$sent300}|ConvertTo-Json|Set-Content (Join-Path $scratch300 $(if($ResumeCreation){'retry-sent.json'}else{'sent.json'}))
& bun D:/myhexin-local/opencorvus/packages/opencorvus/src/index.ts task create --url http://127.0.0.1:18334 --dir $owner300.project --pillar work --expert-squad base --request $request300 --title '连续网页来源与长子会话阅读' --model openai/gpt-6.1-sol --request-id $requestId300 --format json *> $creationLog300
if($LASTEXITCODE -ne 0){Get-Content $creationLog300 -Tail 8;exit $LASTEXITCODE}
$accepted300=Get-Content -LiteralPath $creationLog300 -Raw|ConvertFrom-Json
$observed300=[DateTime]::UtcNow.ToString('o')
$selected300=@{occurrence=$owner300.occurrence;taskID=$accepted300.task_id;projectID=$accepted300.project_id;directory=$accepted300.directory;productPillar='work';requestID=$requestId300;requestSentAt=$sent300;acceptedObservedAt=$observed300}
$selected300|ConvertTo-Json|Set-Content (Join-Path $root300 'task-selection.pending.json')
Move-Item -LiteralPath (Join-Path $root300 'task-selection.pending.json') -Destination (Join-Path $root300 'task-selection.json')
$selected300|ConvertTo-Json





