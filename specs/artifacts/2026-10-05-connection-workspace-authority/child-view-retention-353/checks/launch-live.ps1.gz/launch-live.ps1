param([Parameter(Mandatory=$true)][string]$RunRoot,[Parameter(Mandatory=$true)][string]$EvidenceRoot,[Parameter(Mandatory=$true)][int]$Port,[Parameter(Mandatory=$true)][string]$EvidencePrefix,[Parameter(Mandatory=$true)][string]$ProfileSelectionPath,[Parameter(Mandatory=$true)][int]$RequestBudget,[Parameter(Mandatory=$true)][ValidateSet('Task')][string]$QualificationKind)
$ErrorActionPreference='Stop'
$taskBun349='D:/myhexin-local/opencorvus/.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64/bun.exe'
& $taskBun349 'D:/myhexin-local/opencorvus/packages/opencorvus/script/prepare-test-process-supervisor.ts'
if($LASTEXITCODE -ne 0){throw 'Current native helper preparation failed before isolated launch'}
& 'D:/myhexin-local/opencorvus/.tmp-product-iteration/live-sol-launch-305.ps1' @PSBoundParameters
