import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import {Database} from 'bun:sqlite'
import {gzipSync,gunzipSync} from 'node:zlib'
import {CredentialRedactor} from '../../packages/opencorvus/script/real-provider-audit'
const root=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/child-view-retention-353')
const scratch=path.resolve('.tmp-product-iteration/child-view-retention-353')
const prefix='child-view-retention-353-live-01'
const run='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-12/'+prefix
const history='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-12/child-view-retention-353-history-01'
const original='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-12/child-history-349-live-01'
const redactor=new CredentialRedactor();redactor.collect(JSON.parse(fs.readFileSync('C:/Users/hengu/AppData/Local/opencorvus/data/auth.json','utf8')))
fs.mkdirSync(path.join(root,'checks'),{recursive:true})
const read=(file:string)=>JSON.parse(fs.readFileSync(path.join(root,file),'utf8'))
const save=(file:string,value:unknown)=>fs.writeFileSync(path.join(root,file),redactor.redact(JSON.stringify(value,null,2))+'\n',{flag:'wx'})
function facts(location:string){const db=new Database(path.join(location,'runtime/data/opencorvus.db'),{readonly:true});db.exec('BEGIN');try{return{messages:db.query('SELECT id,session_id,data FROM message ORDER BY id').all(),sources:db.query("SELECT id,message_id,data FROM part WHERE json_extract(data,'$.type') IN ('source-url','source-file','source-document') ORDER BY id").all(),requests:db.query('SELECT id FROM provider_activity_request ORDER BY id').all()}}finally{db.exec('ROLLBACK');db.close()}}
const historyFacts=facts(history);assert.deepEqual(historyFacts,facts(original))
const historySettled=read('history-01/child-view-retention-353-history-01-native-host-settled.json')
for(const key of ['physicalCompletion','outputDrainComplete','requestCleanupComplete'])assert.equal(historySettled[key],true)
assert.equal(historySettled.terminal.exitCode,0)
const historyHttp=read('history-01/child-view-retention-353-history-01-http-summary.json')
const historyServed=historyHttp.requests.filter((r:any)=>r.data?.status==='completed'&&/^\/ui\/assets\/main-[^/]+\.js$/.test(r.data?.path??''))
assert.equal(historyServed.length,1);assert.equal(historyServed[0].data.statusCode,200)
const diagnostic=read('diagnostic-observations.json')
const owners=[...new Set<number>(diagnostic.records.map((r:any)=>r.owner))].map(owner=>{const rows=diagnostic.records.filter((r:any)=>r.owner===owner);return{owner,createdAt:rows.find((r:any)=>r.event==='create')?.at,textStart:rows.find((r:any)=>r.event==='render')?.textStart,chars:rows.find((r:any)=>r.event==='render')?.chars,disposedAt:rows.find((r:any)=>r.event==='dispose')?.at,lastEventAt:rows.at(-1)?.at}})
save('diagnostic-summary.json',{records:diagnostic.records.length,summaries:diagnostic.summaries,owners,boundary:'Actual lifecycle observations for manual interpretation; no UI assertions'})
const canonical=read('live-01/canonical-current-conversations.json'),observation=read('observed-stream-and-narration-reads.json'),items=read('review-items.json')
const tools=canonical.tools.map((r:any)=>({id:r.id,messageID:r.message_id,...JSON.parse(r.data)}))
const outcome=(id:string)=>canonical.outcomes.find((r:any)=>r.requestPartID===id)
const fetches=tools.filter((t:any)=>t.tool==='webfetch')
assert.deepEqual(fetches.map((t:any)=>t.input.url),items.map((i:any)=>i.url))
for(const t of fetches){assert.equal(t.input.format,'markdown');assert.equal(outcome(t.id).outcome,'completed')}
const workerIDs=[...new Set(observation.workerMessages.map((m:any)=>m.sessionID))];assert.equal(workerIDs.length,1)
const texts=observation.workerMessages.flatMap((m:any)=>m.textParts.map((p:any)=>({...p,messageID:m.messageID})))
const answers=items.map((item:any)=>{const matches=texts.filter((p:any)=>p.headings.some((h:string)=>new RegExp('^### '+item.id+'(?:\\s|$)').test(h)));assert.equal(matches.length,1);return{...item,...matches[0]}})
assert.equal(new Set(answers.map((a:any)=>a.id)).size,36)
const sources=canonical.parts.filter((p:any)=>p.type==='source-url');assert.equal(sources.length,36);assert.deepEqual(sources.map((s:any)=>s.url),items.map((i:any)=>i.url))
for(const s of sources)assert.ok(observation.sources.some((x:any)=>x.part.id===s.id))
for(const c of observation.comparisons)assert.equal(c.canonicalEqualsFinalTrimEnd,true)
const audit=read('live-01/'+prefix+'-final-provider-audit.json')
for(const r of audit.requests){assert.equal(r.model,'gpt-6.1-sol');assert.equal(r.streaming,true);assert.equal(r.status,200);assert.equal(r.response_reader.terminal.kind,'eof');assert.equal(r.response_reader.requestContext.streamRequest.apiModelID,'gpt-6.1-sol')}
const errors=canonical.messages.filter((m:any)=>m.error).map((m:any)=>({id:m.id,sessionID:m.sessionID,agent:m.agent,time:m.time,finish:m.finish,error:m.error}))
const rootError=errors.filter((m:any)=>m.agent==='orchestrator').at(-1)
assert.equal(JSON.parse(rootError.error.data.responseBody).error.code,'server_is_overloaded')
assert.equal(observation.terminal.type,'task.failed')
const settled=read('live-01/'+prefix+'-native-host-settled.json'),pair=read('live-01/'+prefix+'-physical-terminal-and-pair-cleanup.json')
for(const key of ['physicalCompletion','outputDrainComplete','requestCleanupComplete'])assert.equal(settled[key],true)
assert.equal(pair.pairedCleanupComplete,true)
const birth=(s:any)=>Number(BigInt(s.target.processInstanceID.slice(6))/10000n-62135596800000n)
const wire=JSON.parse(fs.readFileSync(path.join(scratch,'live-source-observation.json'),'utf8'))
const workerParts=new Set(texts.map((p:any)=>p.id))
const shots=read('screenshot-times.json').map((shot:any)=>({...shot,withinLiveNativeWindow:Date.parse(shot.at)>=birth(settled)&&Date.parse(shot.at)<=Date.parse(settled.observedAtUtc),actualWorkerReaders:audit.requests.filter((r:any)=>r.response_reader.requestContext.sessionID===workerIDs[0]&&r.response_reader.requestContext.streamRequest.agentID==='base-researcher'&&r.response_reader.boundAt<=Date.parse(shot.at)&&r.response_reader.terminal.at>=Date.parse(shot.at)).map((r:any)=>({context:r.response_reader.requestContext,from:r.response_reader.boundAt,to:r.response_reader.terminal.at})),workerPartsObservedByThisTime:wire.parts.filter((p:any)=>workerParts.has(p.partID)&&Date.parse(p.firstObservedAt)<=Date.parse(shot.at)).length}))
const served=read('live-01/'+prefix+'-http-summary.json').requests.filter((r:any)=>r.data?.status==='completed'&&r.data?.path==='/ui/assets/main-sRwPZ07h.js')
assert.ok(served.some((r:any)=>r.data.statusCode===200))
save('checks/actual-evidence.json',{history:{launcherHandle:66890,launcherActualExit:0,settled:historySettled,elapsedMs:Date.parse(historySettled.observedAtUtc)-birth(historySettled),served:historyServed,messages:historyFacts.messages.length,sources:historyFacts.sources.length,providerIDs:historyFacts.requests.length,identity:'Complete stored rows and request identities equal closed349 original'},live:{taskID:observation.taskID,workerID:workerIDs[0],qualification:'failed',unmet:['Task completed','Orchestrator verified all 36 original narrative texts'],terminal:observation.terminal,launcher:{handle:67543,actualExit:1},observer:{handle:81908,actualExit:0},taskCreateActualExit:0,workerTextParts:texts.length,workerChars:texts.reduce((n:number,p:any)=>n+p.chars,0),answers,sources,sourceStreamEvents:observation.sources.length,streamComparisons:observation.comparisons,actualReadOutcomes:observation.reads,providerRequests:audit.requests.length,requestLimit:audit.maxRequests,requestLimitExhausted:audit.exhausted,errors,rootError,native:settled,nativeElapsedMs:Date.parse(settled.observedAtUtc)-birth(settled),pairedCleanupComplete:true,served,shots},boundary:'Backend identity, stream, source and exact structured error facts only. No UI assertions. Historical and live UI observations do not convert the failed Task qualification into success.'})
console.log(JSON.stringify({historyMessages:historyFacts.messages.length,historySources:historyFacts.sources.length,diagnosticRecords:diagnostic.records.length,task:observation.terminal.type,workerTextParts:texts.length,workerChars:texts.reduce((n:number,p:any)=>n+p.chars,0),sources:sources.length,providerRequests:audit.requests.length,errors:errors.length,sourceError:JSON.parse(rootError.error.data.responseBody).error.code,liveNativeMs:Date.parse(settled.observedAtUtc)-birth(settled)}))
