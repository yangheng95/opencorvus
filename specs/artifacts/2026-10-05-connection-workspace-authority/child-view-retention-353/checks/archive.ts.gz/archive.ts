import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import {gzipSync,gunzipSync} from 'node:zlib'
import {CredentialRedactor} from '../../packages/opencorvus/script/real-provider-audit'
const root=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/child-view-retention-353')
const scratch=path.resolve('.tmp-product-iteration/child-view-retention-353')
const originals=path.join(scratch,'full-originals')
const prefix='child-view-retention-353-live-01'
const live=path.join(root,'live-01')
const redactor=new CredentialRedactor();redactor.collect(JSON.parse(fs.readFileSync('C:/Users/hengu/AppData/Local/opencorvus/data/auth.json','utf8')))
const files:any[]=[]
function preserve(source:string){const relative=path.relative(root,source),dest=path.resolve(originals,relative);if(relative.startsWith('..')||path.isAbsolute(relative)||!dest.startsWith(originals+path.sep)||fs.existsSync(dest))throw Error('Exact unique original required');fs.mkdirSync(path.dirname(dest),{recursive:true});fs.renameSync(source,dest)}
function pack(source:string,relative:string){const raw=Buffer.from(redactor.redact(fs.readFileSync(source,'utf8'))),zip=gzipSync(raw,{level:9});assert.equal(gunzipSync(zip).equals(raw),true);fs.writeFileSync(path.join(root,relative),zip,{flag:'wx'});files.push({source,archive:relative,originalBytes:raw.length,compressedBytes:zip.length,integrity:'Full decompressed bytes equal actual credential-redacted original'})}
const chains=fs.readdirSync(live).filter(x=>x.startsWith(prefix+'-chain-supervision-')&&x.endsWith('.json')).sort()
const owner=JSON.parse(fs.readFileSync(path.join(live,prefix+'-launch-owner.json'),'utf8'))
const entries=chains.map(name=>{const text=redactor.redact(fs.readFileSync(path.join(live,name),'utf8'));assert.equal(JSON.parse(text).occurrence,owner.occurrence);return{name,text}})
const raw=Buffer.from(JSON.stringify(entries)),zip=gzipSync(raw,{level:9});assert.equal(gunzipSync(zip).equals(raw),true)
fs.writeFileSync(path.join(live,'supervision-chain.json.gz'),zip,{flag:'wx'})
for(const name of chains)preserve(path.join(live,name))
const retained=new Set(['checks/actual-evidence.json','diagnostic-summary.json'])
for(const entry of fs.readdirSync(root,{recursive:true,withFileTypes:true})){
 if(!entry.isFile()||! /\.(json|log)$/.test(entry.name))continue
 const source=path.resolve(entry.parentPath,entry.name),relative=path.relative(root,source).replaceAll('\\','/')
 if(retained.has(relative)||entry.name.endsWith('.json')&&fs.statSync(source).size<100000)continue
 pack(source,relative+'.gz');preserve(source)
}
for(const name of fs.readdirSync(scratch).filter(x=>/\.(ts|ps1|json|jsonl|log|patch)$/.test(x)&&x!=='archive.log'))pack(path.join(scratch,name),'checks/'+name+'.gz')
const save=(file:string,value:unknown)=>fs.writeFileSync(path.join(root,file),JSON.stringify(value,null,2)+'\n',{flag:'wx'})
save('checks/archive-receipt.json',{files,supervision:{count:chains.length,archive:'live-01/supervision-chain.json.gz',integrity:'Every actual redacted supervision text retained; exact originals preserved privately'}})
let textFiles=0
for(const entry of fs.readdirSync(root,{recursive:true,withFileTypes:true}).filter(x=>x.isFile())){if(entry.name.endsWith('.png'))continue;const raw=fs.readFileSync(path.join(entry.parentPath,entry.name)),text=(entry.name.endsWith('.gz')?gunzipSync(raw):raw).toString('utf8');if(redactor.containsCredential(text))throw Error('Credential found in final evidence');textFiles++}
save('checks/credential-scan.json',{textFiles,credentialMatches:0,archives:'Full decompressed texts scanned'})
console.log(JSON.stringify({supervisionFiles:chains.length,files:files.length,textFiles,credentialMatches:0}))
