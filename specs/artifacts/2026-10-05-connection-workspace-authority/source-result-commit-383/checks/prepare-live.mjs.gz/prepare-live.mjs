import fs from 'node:fs'
import path from 'node:path'
const scratch=path.resolve('.tmp-product-iteration'), current=path.join(scratch,'source-result-commit-383')
const evidence=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/source-result-commit-383/live')
fs.mkdirSync(evidence,{recursive:true})
fs.mkdirSync(path.join(scratch,'source-result-commit-383-native-observer'),{recursive:true})
let launch=fs.readFileSync(path.join(scratch,'live-sol-sources-381-launch.ps1'),'utf8')
launch=launch.replaceAll('source-persistence-381','source-result-commit-383').replaceAll('live-sol-sources-381','live-sol-results-383')
const old='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/locale-bootstrap-377-bundle/after/bin/bun.exe'
if(!launch.includes(old))throw Error('Reviewed private executable anchor required')
launch=launch.replace(old,'C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/source-result-commit-383-bundle/bin/bun.exe')
fs.writeFileSync(path.join(scratch,'live-sol-results-383-launch.ps1'),launch,{flag:'wx'})
fs.copyFileSync(path.join(scratch,'live-sol-sources-381.ts'),path.join(scratch,'live-sol-results-383.ts'),fs.constants.COPYFILE_EXCL)
const shutdown=fs.readFileSync(path.join(scratch,'live-sol-sources-381-shutdown.ps1'),'utf8').replaceAll('live-sol-sources-381','live-sol-results-383')
fs.writeFileSync(path.join(scratch,'live-sol-results-383-shutdown.ps1'),shutdown,{flag:'wx'})
fs.writeFileSync(path.join(current,'builtin.json'),JSON.stringify({kind:'builtin',id:'base',namespace:'builtin'}),{flag:'wx'})
const archive=fs.readFileSync(path.join(scratch,'source-persistence-381/archive-live.ts'),'utf8').replaceAll('source-persistence-381-after','source-result-commit-383-live')
fs.writeFileSync(path.join(current,'archive-live.ts'),archive,{flag:'wx'})
console.log('Prepared fresh result-383 Native scope with private current-source UI and independent Host/Native/observer directories.')
