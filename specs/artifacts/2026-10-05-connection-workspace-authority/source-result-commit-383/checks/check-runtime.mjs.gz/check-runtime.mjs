import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
const root=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/source-result-commit-383')
const folder=path.join(root,'live'),prefix='source-result-commit-383-live'
const read=name=>JSON.parse(fs.readFileSync(path.join(folder,name),'utf8'))
const c=read('canonical-current-conversations.json'),provider=read(prefix+'-final-provider-audit.json')
const owner=read(prefix+'-launch-owner.json'),native=read(prefix+'-native-host-settled.json')
const closure=read(prefix+'-physical-terminal-and-pair-cleanup.json')
const tools=c.tools.map(row=>({...row,data:JSON.parse(row.data)}))
assert.deepEqual(tools.map(row=>row.data.tool),['glob','read','publish_interactive_artifact'])
for(const tool of tools)assert.equal(c.outcomes.find(row=>row.requestPartID===tool.id)?.outcome,'completed')
const readTool=tools[1],publishTool=tools[2]
assert.equal(readTool.data.input.offset,1);assert.equal(readTool.data.input.limit,2)
const sources=c.parts.filter(part=>part.type==='source-file')
assert.equal(sources.length,1)
const source=sources[0]
assert.equal(source.path,readTool.data.input.filePath)
assert.equal(source.title,'结果来源.txt');assert.deepEqual(source.range,{startLine:1,endLine:2})
assert.equal(source.messageID,readTool.message_id);assert.equal(source.toolPartID,readTool.id)
const displays=c.parts.filter(part=>part.type==='interactive-artifact')
assert.equal(displays.length,1)
const display=displays[0],artifact=c.artifacts.find(row=>row.id===display.artifactID)
assert.equal(display.messageID,publishTool.message_id);assert.equal(display.toolPartID,publishTool.id)
assert.equal(artifact.message_id,display.messageID)
assert.equal(artifact.payload.renderer,'document@1');assert.equal(artifact.payload.title,'结果恢复验证')
assert.equal(artifact.payload.markdown,'结果恢复验证\n\n来源属于产生它的真实工具调用。')
assert.equal(c.outcomes.find(row=>row.requestPartID===readTool.id).metadata.preview,artifact.payload.markdown.replace('\n\n','\n'))
assert.equal(JSON.parse(c.outcomes.find(row=>row.requestPartID===publishTool.id).output).artifactID,artifact.id)
const requestAgents={}
assert.equal(provider.maxRequests,20);assert.equal(provider.exhausted,false)
for(const request of provider.requests){
 assert.equal(request.model,'gpt-6.1-sol');assert.equal(request.streaming,true)
 assert.equal(request.status,200);assert.equal(request.response_reader.terminal.kind,'eof')
 const name=request.response_reader.requestContext?.streamRequest?.agentID??'unattributed'
 requestAgents[name]=(requestAgents[name]??0)+1
}
assert.equal(native.occurrence,owner.occurrence);assert.equal(closure.occurrence,owner.occurrence)
for(const key of ['physicalCompletion','outputDrainComplete','requestCleanupComplete'])assert.equal(native[key],true)
assert.equal(closure.physicalCompletion,true);assert.equal(closure.pairedCleanupComplete,true)
assert.deepEqual(closure.copiedPair.map(row=>row.outcome),['removed','removed'])
const result={
 canonicalToolResults:true,sourceBinding:{partID:source.id,toolPartID:source.toolPartID,messageID:source.messageID,path:source.path,range:source.range},
 documentBinding:{partID:display.id,toolPartID:display.toolPartID,messageID:display.messageID,artifactID:artifact.id,renderer:artifact.payload.renderer},
 requestedToolBehavior:'Read actual first two lines and publish their document; all three actual calls completed',
 providerRequests:provider.requests.length,providerBudget:provider.maxRequests,providerExhausted:provider.exhausted,requestAgents,
 actualAssistantErrors:c.messages.filter(row=>row.error).map(row=>({id:row.id,error:row.error})),
 nativeMilliseconds:Date.parse(native.observedAtUtc)-owner.targetBirthAtMs,nativeTerminal:native.terminal,
 physicalCompletion:true,outputDrainComplete:true,requestCleanupComplete:true,pairedCleanupComplete:true,
 actualLauncherExit:1,qualificationError:'OWNED_NATIVE_COMPLETION_INVALID',fullQualification:false,
 unmet:['Reload/reopen visual verification was not completed before the fixed native deadline.'],
 boundary:'Read-only backend canonical/runtime assertions; actual UI screenshots were reviewed manually. Native deadline failure remains a failure. This healthy Provider run does not prove Provider crash recovery.'
}
fs.writeFileSync(path.join(root,'runtime-review.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify(result))
