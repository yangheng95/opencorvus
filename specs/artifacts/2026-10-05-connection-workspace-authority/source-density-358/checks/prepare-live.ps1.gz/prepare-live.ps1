$ErrorActionPreference='Stop'
$taskRun358='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/source-density-358-live'
$taskReady358=Get-Content -Raw -LiteralPath (Join-Path $taskRun358 'evidence/preflight-ready.json') | ConvertFrom-Json
if($taskReady358.preflight.credential -ne 'usable' -or $taskReady358.preflight.catalog -ne 'projected' -or $taskReady358.preflight.actualModel -ne 'gpt-6.1-sol' -or !$taskReady358.preflight.streaming){throw 'Exact live model preflight required'}
$taskDirectory358=Join-Path $taskRun358 'project/资料/范围核对'
New-Item -ItemType Directory -Path $taskDirectory358 -Force | Out-Null
$taskPath358=Join-Path $taskDirectory358 '  来源范围核对_保留文件名空白_长标题与行号显示_实际读取验证记录.md'
if(Test-Path -LiteralPath $taskPath358){throw 'Fresh authored input required'}
$taskLines358=@('# 真实范围输入：只能以实际读取行作为工具结果。')
$taskLines358+=1..29|ForEach-Object { 'RANGE358 原始第{0}行；记录{1:D2}。行号、文件名空白和来源范围分别核对。' -f ($_+1),$_ }
[IO.File]::WriteAllText($taskPath358,($taskLines358 -join "`n")+"`n",[Text.UTF8Encoding]::new($false))
$taskEvidence358='D:/myhexin-local/opencorvus/specs/artifacts/2026-10-05-connection-workspace-authority/source-density-358'
[IO.File]::WriteAllText((Join-Path $taskEvidence358 'range-input.json'),(@{path=$taskPath358;lines=$taskLines358;expectedRead=@{offset=10;limit=3}}|ConvertTo-Json -Depth 6)+"`n",[Text.UTF8Encoding]::new($false))
$taskRequest358='请直接调用 read，filePath 使用以下完整路径（文件名前有两个空格，必须保留）：'+($taskPath358|ConvertTo-Json -Compress)+'。offset=10、limit=3。只读这三行，之后用一句话报告实际行号和内容。不修改文件，不创建任务或成员。'
[IO.File]::WriteAllText('D:/myhexin-local/opencorvus/.tmp-product-iteration/source-density-358/live-request.txt',$taskRequest358,[Text.UTF8Encoding]::new($false))
Write-Output 'One actual file prepared with preserved two leading filename spaces and 30 authored lines.'
