$ErrorActionPreference='Stop'
$taskRepo='D:/myhexin-local/opencorvus'
$taskSource='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/source-surfaces-356-live-02'
$taskEvidence=Join-Path $taskRepo 'specs/artifacts/2026-10-05-connection-workspace-authority/source-surfaces-356/live-02'
$taskOut=Join-Path $taskRepo 'specs/artifacts/2026-10-05-connection-workspace-authority/source-density-358/final-main-readiness'
. (Join-Path $taskRepo '.tmp-product-iteration/live-sol-launch.ps1') -FunctionsOnly
$taskOwner=Get-Content (Join-Path $taskSource 'launch-owner.json') -Raw|ConvertFrom-Json -AsHashtable -DateKind String
$taskStates=@(@{expected=$taskOwner.host;state=(Get-OwnedNativeState $taskOwner.host)},@{expected=$taskOwner.nativeTarget;state=(Get-OwnedNativeState $taskOwner.nativeTarget)})
$taskListeners=@(Get-NetTCPConnection -State Listen -ErrorAction Stop|Where-Object {$_.LocalPort -in @($taskOwner.port,18352)})
$taskPair=@('auth.json','models.json'|ForEach-Object{@{name=$_;present=(Test-Path -LiteralPath (Join-Path $taskSource ('runtime/data/'+$_)))}})
$taskNative=Get-OwnedNativeSettlement $taskOwner
$taskQualified=Get-Content (Join-Path $taskEvidence 'source-surfaces-356-live-02-physical-terminal-and-pair-cleanup.json') -Raw|ConvertFrom-Json -AsHashtable -DateKind String
$taskSurface=Get-Content (Join-Path $taskEvidence 'source-surfaces-356-live-02-qualified-surface-completion.json') -Raw|ConvertFrom-Json -AsHashtable -DateKind String
if(@($taskStates|Where-Object state -ne 'dead_or_reused').Count -or $taskListeners.Count -or @($taskPair|Where-Object present).Count -or !$taskNative -or $taskNative.terminal.exitCode -ne 0 -or $taskQualified.occurrence -cne $taskOwner.occurrence -or !$taskQualified.physicalCompletion -or !$taskQualified.pairedCleanupComplete -or $taskSurface.qualification -cne 'NativeService' -or $taskSurface.providerEOFRequests -ne 9){throw 'Original exact NativeService/Provider closure incomplete'}
Write-OwnedLaunchFact (Join-Path $taskOut 'guard.json') @{readQualified=$true;sourceRun=$taskSource;occurrence=$taskOwner.occurrence;observedAtUtc=[DateTime]::UtcNow.ToString('o');states=$taskStates;listenerCount=$taskListeners.Count;pair=$taskPair;native=$taskNative;originalQualification=$taskQualified;surface=$taskSurface;boundary='Original live-02 launcher25012 actual exit0 and nine streaming Provider EOFs; live-01 deadline failure remains separate.'}
$taskManifest=@{sourceRun=$taskSource;sourceEvidence=$taskOwner.settlementEvidenceRoot;sourceProject=$taskOwner.project;caseRun='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/source-density-358-final-main';caseEvidence=(Join-Path $taskRepo 'specs/artifacts/2026-10-05-connection-workspace-authority/source-density-358/final-main');readinessEvidence=$taskOut;casePort=18352;caseLabel='source-density-358-final-main';sourceOccurrence=$taskOwner.occurrence;startupQualified=$false;selectedSubject=@{kind='session';id='ses_-zUS8zzerzzqG425PLRl';projectID='prj_hEWVbkdkqzXiCqYcPTRJ'}}
Write-OwnedLaunchFact (Join-Path $taskRepo '.tmp-product-iteration/source-density-358/final-main/history-manifest.json') $taskManifest
Write-Output 'Original live-02 closure verified; current full source startup observations remain required.'



