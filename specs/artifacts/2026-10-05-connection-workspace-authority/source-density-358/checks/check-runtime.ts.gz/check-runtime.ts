import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import { Database } from 'bun:sqlite'
const base='C:/Users/hengu/.codex/opencorvus-product-iteration'
const evidence=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/source-density-358')
fs.mkdirSync(path.join(evidence,'checks'),{recursive:true})
const read=(file:string)=>JSON.parse(fs.readFileSync(path.join(evidence,file),'utf8'))
const mainSource=base+'/2026-10-13/source-surfaces-356-live-02'
const childSource=base+'/2026-10-12/child-dense-348-live-01'
const cases=[
 ['main',mainSource,28889,'main-CjPpEVA4.js',192],
 ['child',childSource,84255,'main-CjPpEVA4.js',66],
 ['child-final',childSource,26045,'main-CjPpEVA4.js',66],
 ['child-final2',childSource,18883,'main-CZ9bd5n2.js',66],
 ['child-final3',childSource,38447,'main-CrFGPI-s.js',66],
 ['final-main',mainSource,20436,'main-CrFGPI-s.js',192],
 ['clipboard',mainSource,53710,'main-CrFGPI-s.js',192],
] as const
function facts(run:string){
 const db=new Database(path.join(run,'runtime/data/opencorvus.db'),{readonly:true});db.exec('BEGIN')
 try{return {
  messages:db.query('SELECT id,session_id,data FROM message ORDER BY id').all(),
  sources:(db.query("SELECT p.id,p.message_id,m.session_id,p.data FROM part p JOIN message m ON m.id=p.message_id WHERE json_extract(p.data,'$.type') IN ('source-file','source-url','source-document') ORDER BY p.id").all() as any[]).map(r=>({...r,data:JSON.parse(r.data)})),
 }}finally{db.exec('ROLLBACK');db.close()}
}
function delivery(scope:string,asset:string){
 const label='source-density-358-'+scope
 const native=read(`${scope}/${label}-native-host-settled.json`)
 assert.equal(native.terminal.exitCode,0);assert.equal(native.terminal.reason,'exited')
 for(const key of ['physicalCompletion','outputDrainComplete','requestCleanupComplete'])assert.equal(native[key],true)
 const http=read(`${scope}/${label}-http-summary.json`)
 const served=http.requests.find((r:any)=>r.data?.path===`/ui/assets/${asset}`&&r.data?.status==='completed')
 assert.equal(served.data.statusCode,200)
 const assets=http.requests.filter((r:any)=>r.data?.status==='completed'&&/^\/ui\/(assets|i18n)\//.test(r.data.path)).map((r:any)=>({path:r.data.path,status:r.data.statusCode}))
 const birth=Number(BigInt(native.target.processInstanceID.slice(6))/10000n-62135596800000n)
 return {native,elapsedMs:Date.parse(native.observedAtUtc)-birth,served,assets}
}
const runs=[]
for(const [scope,source,handle,asset,count] of cases){
 const run=base+'/2026-10-13/source-density-358-'+scope,original=facts(source),current=facts(run)
 assert.deepEqual(current.messages,original.messages);assert.deepEqual(current.sources,original.sources);assert.equal(current.sources.length,count)
 runs.push({scope,source,run,initialHandle:handle,launcherExitCode:0,canonicalMessageCount:current.messages.length,canonicalSourceCount:current.sources.length,...delivery(scope,asset),qualification:'Complete original canonical Message/Source values and actual delivered UI resources/Native settlement. Visual and clipboard outcomes are separately recorded; an intermediate asset is not final visual acceptance.'})
 fs.writeFileSync(path.join(evidence,scope,'canonical-sources.json'),JSON.stringify(current.sources,null,2)+'\n')
}
const input=read('range-input.json'),canonical=read('live/canonical-current-conversations.json')
assert.deepEqual(fs.readFileSync(input.path,'utf8').trimEnd().split(/\r?\n/),input.lines)
const source=canonical.parts.find((p:any)=>p.type==='source-file')
assert.equal(source.path,input.path)
assert.equal(source.title,path.relative(base+'/2026-10-13/source-density-358-live/project',input.path))
assert.deepEqual(source.range,{startLine:10,endLine:12})
const tool=canonical.tools.find((t:any)=>t.message_id===source.messageID),request=JSON.parse(tool.data)
assert.equal(request.tool,'read');assert.deepEqual(request.input,{filePath:input.path,offset:10,limit:3})
const outcome=canonical.outcomes.find((o:any)=>o.requestPartID===tool.id)
assert.equal(outcome.outcome,'completed')
assert.equal(outcome.metadata.preview,input.lines.slice(9,12).join('\n'))
assert.equal(outcome.metadata.offset,10);assert.equal(outcome.metadata.lines,3);assert.equal(outcome.metadata.totalLines,30)
const sourceMessage=canonical.messages.find((m:any)=>m.id===source.messageID)
const final=canonical.messages.find((m:any)=>m.sessionID===sourceMessage.sessionID&&m.role==='assistant'&&m.finish==='stop')
assert.equal(final.modelID,'gpt-6.1-sol');assert.equal(final.providerID,'openai');assert.ok(final.time.completed>=final.time.created)
const audit=read('live/source-density-358-live-final-provider-audit.json')
assert.equal(audit.requests.length,5)
for(const r of audit.requests){assert.equal(r.model,'gpt-6.1-sol');assert.equal(r.streaming,true);assert.equal(r.status,200);assert.equal(r.response_reader.state,'settled');assert.equal(r.response_reader.terminal.kind,'eof')}
const preflight=read('live/source-density-358-live-preflight-ready.json').preflight
assert.equal(preflight.credential,'usable');assert.equal(preflight.catalog,'projected');assert.equal(preflight.actualModel,'gpt-6.1-sol');assert.equal(preflight.streaming,true)
const qualification=read('live/source-density-358-live-qualified-surface-completion.json')
assert.equal(qualification.qualification,'NativeService');assert.equal(qualification.providerEOFRequests,5);assert.equal(qualification.physicalCompletion,true)
const physical=read('live/source-density-358-live-physical-terminal-and-pair-cleanup.json')
assert.equal(physical.physicalCompletion,true);assert.equal(physical.pairedCleanupComplete,true)
const live={scope:'live',initialHandle:55186,launcherExitCode:0,source,toolID:tool.id,sessionID:sourceMessage.sessionID,finalMessageID:final.id,range:{startLine:10,endLine:12},outputPreview:outcome.metadata.preview,preflight,providerRequestCount:5,qualification,pairedCleanupComplete:physical.pairedCleanupComplete,...delivery('live','main-CrFGPI-s.js')}
const result={checkedAt:new Date().toISOString(),runtimeAndCanonical:'passed',runs,live,clipboard:{review:'Manual review only; clipboard receipts are not automated UI assertions.',observedMatchingSamples:['Initial four Main/Side :20 native copy observations','Live partial-range full path and :10-12','Diagnostic source :2 and :3, including final text/plain and text reads'],unresolved:'final-main initially read/pasted the previous live value despite fulfilled UI feedback. The diagnostic initially reproduced it; after an owned native-copy control and later application copies, :2 and :3 matched. Exact browser/tool versus application cause remains unproven. Original mismatches are retained; no clipboard reliability success or production fix is claimed.'},boundary:'Actual readonly SQLite, authored input, canonical read output, real Provider streams and current HTTP/Native facts. No UI/DOM/source-text/screenshot assertions. Manual visual qualifications remain in README.'}
fs.writeFileSync(path.join(evidence,'checks/runtime-qualification.json'),JSON.stringify(result,null,2)+'\n')
console.log(JSON.stringify({historical:runs.map(r=>({scope:r.scope,messages:r.canonicalMessageCount,sources:r.canonicalSourceCount,elapsedMs:r.elapsedMs,exit:r.launcherExitCode})),live:{session:live.sessionID,providerRequests:5,range:live.range,exit:0,elapsedMs:live.elapsedMs},clipboardReliability:'unresolved'}))
