import fs from 'node:fs'
import path from 'node:path'
const run='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-12/main-transition-350-live-01'
const rows=fs.readFileSync(path.join(run,'runtime/log/dev.log'),'utf8').split(/\r?\n/).filter(Boolean).flatMap(line=>{try{return [JSON.parse(line)]}catch{return []}})
const trace=rows.filter(r=>r.service==='overlay:reading-350')
const result={at:new Date().toISOString(),total:trace.length,last:trace.slice(-10).map(r=>({loggedAt:r.time,message:r.message,...r.data})),resizeErrors:rows.filter(r=>r.service==='overlay:runtime').map(r=>({at:r.time,data:r.data}))}
fs.appendFileSync(path.resolve('.tmp-product-iteration/main-transition-350/trace-inspections.jsonl'),JSON.stringify(result)+'\n')
console.log(JSON.stringify({at:result.at,total:result.total,resizeErrors:result.resizeErrors.length,last:result.last.map(r=>({utc:r.utc,message:r.message,reason:r.reason,owner:r.owner,epoch:r.epoch,following:r.following,top:r.top,height:r.height,width:r.width,markdownPending:r.markdownPending,visible:r.visible,cards:r.cards?.map((c:any)=>({id:c.id,top:c.top,height:c.height}))}))}))
