import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import {gzipSync,gunzipSync} from 'node:zlib'
import {CredentialRedactor} from '../../packages/opencorvus/script/real-provider-audit'
const root=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/main-transition-350'),scratch=path.resolve('.tmp-product-iteration/main-transition-350')
const redactor=new CredentialRedactor();redactor.collect(JSON.parse(fs.readFileSync('C:/Users/hengu/AppData/Local/opencorvus/data/auth.json','utf8')))
fs.mkdirSync(path.join(root,'checks'),{recursive:true})
const read=(name:string)=>JSON.parse(fs.readFileSync(path.join(root,name),'utf8'))
const save=(name:string,value:unknown)=>fs.writeFileSync(path.join(root,name),redactor.redact(JSON.stringify(value,null,2))+'\n',{flag:'wx'})
const canonical=read('live-01/canonical-current-conversations.json'),observation=read('observed-stream-and-narration-reads.json'),items=read('review-items.json')
const tools=canonical.tools.map((t:any)=>({id:t.id,messageID:t.message_id,...JSON.parse(t.data)})),outcome=(id:string)=>canonical.outcomes.find((o:any)=>o.requestPartID===id)
assert.deepEqual(tools.filter((t:any)=>t.tool==='dispatch_agent').map((t:any)=>t.input.dispatch.target),['base-researcher'])
const fetches=tools.filter((t:any)=>t.tool==='webfetch');assert.deepEqual(fetches.map((t:any)=>t.input.url),items.map((i:any)=>i.url))
for(const t of fetches){assert.equal(t.input.format,'markdown');assert.equal(outcome(t.id).outcome,'completed')}
const textParts=observation.workerMessages.flatMap((m:any)=>m.textParts.map((p:any)=>({...p,messageID:m.messageID,sessionID:m.sessionID})))
const answers=items.map((item:any)=>{const found=textParts.filter((p:any)=>p.headings.some((h:string)=>new RegExp('^### '+item.id+'(?:\\s|$)').test(h)));assert.equal(found.length,1);return {item:item.id,...found[0]}})
assert.equal(new Set(answers.map((p:any)=>p.id)).size,36)
const readers=tools.filter((t:any)=>t.tool==='read_agent_message').map((t:any)=>({id:t.id,result:JSON.parse(outcome(t.id).output)}))
const narration=answers.map((answer:any)=>{
 const original=canonical.parts.find((p:any)=>p.id===answer.id)
 const receipts=readers.flatMap(({id,result}:any)=>[
  ...(result.evidence_reads??[]).filter((e:any)=>e.part_id===answer.id&&e.field==='text'&&e.content===original.text&&e.next_offset===null).map(()=>({request:id,kind:'complete text evidence'})),
  ...(result.messages??[]).filter((m:any)=>m.message_id===answer.messageID&&m.text.join('\n')===original.text).map(()=>({request:id,kind:'selected complete message'})),
  ...(result.causal_part_message_inventory??[]).flatMap((m:any)=>(m.part_facts??[]).filter((p:any)=>p.part_id===answer.id&&p.part_type==='text'&&p.text_preview===original.text&&p.text_chars===original.text.length&&p.text_preview_truncated===false).map(()=>({request:id,kind:'inventory carries complete original'})))
 ]);assert.ok(receipts.length>0);return {item:answer.item,partID:answer.id,chars:original.text.length,receipts}
})
const sources=canonical.parts.filter((p:any)=>p.type==='source-url');assert.equal(sources.length,36);assert.deepEqual(sources.map((s:any)=>s.url),items.map((i:any)=>i.url))
for(const s of sources)assert.ok(observation.sources.some((e:any)=>e.part.id===s.id))
for(const p of observation.comparisons)assert.equal(p.canonicalEqualsFinalTrimEnd,true)
assert.equal(read('copied-initial-url.json').value,items[0].url)
const task=read('live-01/task-complete.json');assert.equal(task.lifecycle.status,'completed')
const prompt=fs.readFileSync(path.join(root,'user-request-02.txt'),'utf8').trimEnd()
const cases=['01','02','03'].map(number=>{
 const label='main-transition-350-live-'+number,dir='live-'+number,run='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-12/'+label
 const owner=read(dir+'/'+label+'-launch-owner.json'),native=read(dir+'/'+label+'-native-host-settled.json'),pair=read(dir+'/'+label+'-physical-terminal-and-pair-cleanup.json'),audit=read(dir+'/'+label+'-final-provider-audit.json')
 for(const r of audit.requests){assert.equal(r.model,'gpt-6.1-sol');assert.equal(r.streaming,true);assert.equal(r.status,200);assert.equal(r.response_reader.terminal.kind,'eof');assert.equal(r.response_reader.requestContext.streamRequest.apiModelID,'gpt-6.1-sol')}
 assert.equal(native.physicalCompletion,true);assert.equal(native.outputDrainComplete,true);assert.equal(native.requestCleanupComplete,true);assert.equal(pair.pairedCleanupComplete,true)
 let qualification:any,session:any
 if(number==='02'){assert.equal(native.terminal.reason,'deadline_exceeded');assert.equal(native.terminal.exitCode,1);qualification={outcome:'failed',code:'OWNED_QUALIFICATION_BOUNDARY_REACHED',actualLauncherExit:1,handle:81777}}
 else{qualification=read(dir+'/'+label+'-qualified-surface-completion.json');assert.equal(qualification.physicalCompletion,true);assert.equal(qualification.qualification,number==='01'?'Task':'NativeService')}
 if(number!=='01'){
  const c=read(dir+'/canonical-current-conversations.json')
  const actual=c.parts.filter((p:any)=>p.type==='text'&&p.text?.trimEnd()===prompt&&c.messages.some((m:any)=>m.id===p.messageID&&m.role==='user'))
  assert.equal(actual.length,1);const message=c.messages.find((m:any)=>m.id===actual[0].messageID)
  const replies=c.messages.filter((m:any)=>m.sessionID===message.sessionID&&m.role==='assistant');assert.ok(replies.length>0);for(const m of replies)assert.equal(typeof m.time.completed,'number')
  session={sessionID:message.sessionID,userMessageID:message.id,inputChars:actual[0].text.length,assistantMessages:replies}
 }
 const log=fs.readFileSync(path.join(root,dir,label+'-runtime.log'),'utf8').split(/\r?\n/).filter(Boolean).map(s=>JSON.parse(s))
 const assets=log.filter(r=>r.service==='server'&&r.data?.status==='completed'&&/^\/ui\/assets\/main-.*\.js$/.test(r.data.path??'')).map(r=>({path:r.data.path,status:r.data.statusCode,at:r.time}))
 for(const asset of number==='01'?['main-tXbiLIQv.js','main-BlTZ2Fml.js']:number==='02'?['main-BlTZ2Fml.js','main-s7zSjxbC.js']:['main-Byx48Ve-.js'])assert.ok(assets.some(a=>a.path==='/ui/assets/'+asset&&a.status===200))
 const birth=Number(BigInt(owner.nativeTarget.processInstanceID.slice(6))/10000n-62135596800000n)
 if(number==='01'){
  const diagnostic=log.filter(r=>r.service==='overlay:reading-350');save('checks/actual-layout-diagnostic.json',{records:diagnostic,boundary:'Actual bounded temporary frontend geometry/lifecycle records; manual investigation only, no UI assertions'})
 }
 return {number,owner,birth,terminal:Date.parse(native.observedAtUtc),nativeElapsedMs:Date.parse(native.observedAtUtc)-birth,native,qualification,providerRequests:audit.requests.length,pairedCleanupComplete:true,session,assets,overlayErrors:log.filter(r=>r.service.startsWith('overlay:')&&r.level==='error').map(r=>({at:r.time,service:r.service,message:r.message,data:r.data}))}
})
const shots=read('screenshot-times.json').map((s:any)=>{const c=cases.filter(c=>c.birth<=Date.parse(s.at)).at(-1)!;return {...s,run:c.number,beforeNativeTerminal:Date.parse(s.at)<c.terminal}})
save('checks/actual-qualification.json',{taskID:task.selected.taskID,workerID:answers[0].sessionID,taskElapsedMs:task.lifecycle.terminalAt-task.lifecycle.openedAt,workerParts:textParts.length,workerChars:textParts.reduce((n:number,p:any)=>n+p.chars,0),completeNarrationReads:narration,sourceCount:sources.length,streamComparisons:observation.comparisons,cases,shots,actualJoins:{taskCreate:0,observer:{handle:75162,exitCode:0},launchers:[{run:'01',handle:55633,exitCode:0},{run:'02',handle:81777,exitCode:1},{run:'03',handle:26612,exitCode:0}],finalBuild:{handle:59190,exitCode:0},finalTypecheck:{handle:27988,exitCode:0}},boundary:'Actual data/Provider/request/lifetime checks. No UI assertions. Images09 and14 are after owned service termination; run02 is a preserved failed qualification. Final03 actual online image18 includes before-key width860; geometry and screenshots are interpreted manually.'})
const archives:any[]=[]
function pack(from:string,relative:string){const raw=Buffer.from(redactor.redact(fs.readFileSync(from,'utf8'))),zip=gzipSync(raw,{level:9});assert.equal(gunzipSync(zip).equals(raw),true);fs.writeFileSync(path.join(root,relative),zip,{flag:'wx'});archives.push({source:from,archive:relative,bytes:raw.length,compressedBytes:zip.length,integrity:'Full decompressed actual redacted original preserved'})}
for(const c of cases){
 const label='main-transition-350-live-'+c.number,dir=path.join(root,'live-'+c.number),privateDir=path.join(scratch,'original-evidence-'+c.number);fs.mkdirSync(privateDir,{recursive:true})
 const chains=fs.readdirSync(dir).filter(n=>n.startsWith(label+'-chain-supervision-')&&n.endsWith('.json')).sort(),entries=chains.map(name=>{const text=redactor.redact(fs.readFileSync(path.join(dir,name),'utf8'));assert.equal(JSON.parse(text).occurrence,c.owner.occurrence);return {name,text}})
 const raw=Buffer.from(JSON.stringify(entries)),zip=gzipSync(raw,{level:9});assert.equal(gunzipSync(zip).equals(raw),true);fs.writeFileSync(path.join(dir,'supervision-chain.json.gz'),zip,{flag:'wx'});archives.push({archive:'live-'+c.number+'/supervision-chain.json.gz',files:chains.length,integrity:'Complete original redacted text for every supervision file'})
 for(const name of chains){const dest=path.join(privateDir,name);if(fs.existsSync(dest))throw Error('Preserve private original');fs.renameSync(path.join(dir,name),dest)}
 for(const name of fs.readdirSync(dir).filter(n=>n.endsWith('.log')||n.endsWith('.json')&&fs.statSync(path.join(dir,n)).size>100000)){pack(path.join(dir,name),'live-'+c.number+'/'+name+'.gz');const dest=path.join(privateDir,name);if(fs.existsSync(dest))throw Error('Preserve evidence original');fs.renameSync(path.join(dir,name),dest)}
}
for(const name of fs.readdirSync(scratch).filter(n=>/\.(ts|tsx|ps1|json|jsonl|log|patch)$/.test(n)))pack(path.join(scratch,name),'checks/'+name+'.gz')
const diagnostic=path.join(root,'checks/actual-layout-diagnostic.json');pack(diagnostic,'checks/actual-layout-diagnostic.json.gz');fs.renameSync(diagnostic,path.join(scratch,'actual-layout-diagnostic.json'))
save('checks/archive-receipt.json',{files:archives,order:'archive each closed run, analyze first Task, then finalize; large final data uses the exact gzip paths listed above'})
let textFiles=0;for(const entry of fs.readdirSync(root,{recursive:true,withFileTypes:true}).filter(x=>x.isFile())){if(entry.name.endsWith('.png'))continue;const raw=fs.readFileSync(path.join(entry.parentPath,entry.name)),text=(entry.name.endsWith('.gz')?gunzipSync(raw):raw).toString('utf8');if(redactor.containsCredential(text))throw Error('Credential in archived evidence');textFiles++}
save('checks/credential-scan.json',{textFiles,credentialMatches:0,archives:'Full decompressed text scanned'})
console.log(JSON.stringify({taskID:task.selected.taskID,workerParts:textParts.length,workerChars:textParts.reduce((n:number,p:any)=>n+p.chars,0),narrations:narration.length,taskElapsedMs:task.lifecycle.terminalAt-task.lifecycle.openedAt,cases:cases.map(c=>({run:c.number,requests:c.providerRequests,elapsed:c.nativeElapsedMs,qualification:c.qualification})),afterTerminalScreens:shots.filter((s:any)=>!s.beforeNativeTerminal).map((s:any)=>s.file),textFiles,credentialMatches:0}))
