import fs from 'node:fs'
import path from 'node:path'
import {Database} from 'bun:sqlite'
const run='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-12/main-transition-350-live-01'
const selected=JSON.parse(fs.readFileSync(path.join(run,'task-selection.json'),'utf8'))
const db=new Database(path.join(run,'runtime/data/opencorvus.db'),{readonly:true})
let result:any
try{
 db.exec('BEGIN')
 const messages=db.query("SELECT m.id,m.session_id,m.data FROM message m JOIN session s ON m.session_id=s.id WHERE s.project_id=? AND json_extract(m.data,'$.role')='assistant' AND json_extract(m.data,'$.agent')='base-researcher' ORDER BY m.time_created,m.id").all(selected.projectID) as any[]
 const parts=db.query("SELECT p.id,p.message_id,p.data FROM part p JOIN message m ON p.message_id=m.id JOIN session s ON m.session_id=s.id WHERE s.project_id=? AND json_extract(m.data,'$.role')='assistant' AND json_extract(m.data,'$.agent')='base-researcher' ORDER BY p.time_created,p.id").all(selected.projectID) as any[]
 const texts=parts.map(p=>({id:p.id,messageID:p.message_id,...JSON.parse(p.data)})).filter(p=>p.type==='text'&&p.text?.trim())
 const sources=parts.map(p=>JSON.parse(p.data)).filter(p=>p.type==='source-url')
 result={at:new Date().toISOString(),scope:'Canonical assistant role only',taskID:selected.taskID,workerSessions:[...new Set(messages.map(m=>m.session_id))],assistantMessages:messages.length,completedMessages:messages.filter(m=>typeof JSON.parse(m.data).time?.completed==='number').length,textParts:texts.length,sourceURLs:sources.length,latest:texts.slice(-3).map(t=>({id:t.id,chars:t.text.length,headings:t.text.split('\n').filter((s:string)=>s.startsWith('#'))})),totalChars:texts.reduce((n,t)=>n+t.text.length,0)}
 db.exec('COMMIT')
}finally{db.close()}
fs.appendFileSync(path.resolve('.tmp-product-iteration/main-transition-350/live-inspections.jsonl'),JSON.stringify(result)+'\n')
console.log(JSON.stringify(result))
