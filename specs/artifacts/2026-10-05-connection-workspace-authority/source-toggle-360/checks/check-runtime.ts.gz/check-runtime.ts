import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import {Database} from 'bun:sqlite'
const evidence=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/source-toggle-360')
const base='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13'
const read=(relative:string)=>JSON.parse(fs.readFileSync(path.join(evidence,relative),'utf8'))
function facts(root:string){const db=new Database(path.join(root,'runtime/data/opencorvus.db'),{readonly:true});db.exec('BEGIN');try{return{
 messages:db.query('SELECT id,session_id,data FROM message ORDER BY id').all(),
 sources:(db.query("SELECT p.id,p.message_id,m.session_id,p.data FROM part p JOIN message m ON m.id=p.message_id WHERE json_extract(p.data,'$.type') IN ('source-file','source-url','source-document') ORDER BY p.id").all() as any[]).map(r=>({...r,data:JSON.parse(r.data)})),
}}finally{db.exec('ROLLBACK');db.close()}}
function delivery(scope:string){
 const label='source-toggle-360-'+scope,native=read(`${scope}/${label}-native-host-settled.json`),physical=read(`${scope}/${label}-physical-terminal-and-pair-cleanup.json`),http=read(`${scope}/${label}-http-summary.json`)
 assert.equal(native.terminal.exitCode,0);assert.equal(native.terminal.reason,'exited')
 for(const key of ['physicalCompletion','outputDrainComplete','requestCleanupComplete'])assert.equal(native[key],true)
 assert.equal(physical.physicalCompletion,true);assert.equal(physical.pairedCleanupComplete,true)
 const served=http.requests.filter((r:any)=>r.data?.path==='/ui/assets/main-C-GbKPJC.js'&&r.data?.status==='completed')
 assert.equal(served.length>0,true);for(const r of served)assert.equal(r.data.statusCode,200)
 const birth=Number(BigInt(native.target.processInstanceID.slice(6))/10000n-62135596800000n)
 return{native,physical,elapsedMs:Date.parse(native.observedAtUtc)-birth,served}
}
const original=facts(base+'/source-surfaces-356-live-02'),current=facts(base+'/source-toggle-360-history')
assert.deepEqual(current.messages,original.messages);assert.deepEqual(current.sources,original.sources)
assert.equal(current.messages.length,11);assert.equal(current.sources.length,192)
const copy=read('history/source-toggle-360-history-history-copy.json')
assert.equal(copy.completeRows.tableRows.length,90)
assert.equal(read('history/source-toggle-360-history-launcher-native-joined.json').exitCode,0)
const history={initialHandle:95647,launcherExitCode:0,messages:11,sources:192,copiedTables:90,...delivery('history')}
const input=read('search-inputs.json'),canonical=read('live/canonical-current-conversations.json')
const sources=canonical.parts.filter((p:any)=>p.type==='source-file')
assert.equal(sources.length,2);assert.equal(sources[0].messageID,sources[1].messageID)
for(const source of sources){const file=input.files.find((f:any)=>f.path===source.path);assert.equal(typeof file.path,'string');assert.deepEqual(fs.readFileSync(file.path,'utf8').trimEnd().split(/\r?\n/),file.lines);assert.equal(source.title,path.basename(file.path));assert.deepEqual(source.range,{startLine:2,endLine:2});assert.equal(file.lines[1].startsWith(input.query),true)}
const tool=canonical.tools.find((t:any)=>t.message_id===sources[0].messageID),request=JSON.parse(tool.data)
assert.equal(request.tool,'search_code');assert.deepEqual(request.input,{pattern:'SOURCE360',path:'资料/展开核对',include:'*.md'})
const outcome=canonical.outcomes.find((o:any)=>o.requestPartID===tool.id)
assert.equal(outcome.outcome,'completed');assert.equal(outcome.metadata.matches,2)
const expectedOutput='Found 2 matches\n'+sources.map((s:any)=>`${s.path}:\n  Line 2: ${input.files.find((f:any)=>f.path===s.path).lines[1]}`).join('\n\n')
assert.equal(outcome.output,expectedOutput)
const sourceMessage=canonical.messages.find((m:any)=>m.id===sources[0].messageID),final=canonical.messages.find((m:any)=>m.sessionID===sourceMessage.sessionID&&m.role==='assistant'&&m.finish==='stop')
assert.equal(final.modelID,'gpt-6.1-sol');assert.equal(final.providerID,'openai');assert.equal(final.time.completed>=final.time.created,true)
const audit=read('live/source-toggle-360-live-final-provider-audit.json')
assert.equal(audit.requests.length,5)
for(const r of audit.requests){assert.equal(r.model,'gpt-6.1-sol');assert.equal(r.streaming,true);assert.equal(r.status,200);assert.equal(r.response_reader.state,'settled');assert.equal(r.response_reader.terminal.kind,'eof')}
const preflight=read('live/source-toggle-360-live-preflight-ready.json').preflight
assert.equal(preflight.credential,'usable');assert.equal(preflight.catalog,'projected');assert.equal(preflight.actualModel,'gpt-6.1-sol');assert.equal(preflight.streaming,true)
const qualification=read('live/source-toggle-360-live-qualified-surface-completion.json')
assert.equal(qualification.qualification,'NativeService');assert.equal(qualification.providerEOFRequests,5);assert.equal(qualification.physicalCompletion,true)
const live={initialHandle:78524,launcherExitCode:0,session:sourceMessage.sessionID,sourceMessageID:sources[0].messageID,toolID:tool.id,sources,finalMessageID:final.id,preflight,providerRequests:5,qualification,...delivery('live')}
const result={checkedAt:new Date().toISOString(),history,live,boundary:'Actual SQLite, authored inputs, canonical search output, five Provider streams, HTTP delivery and Native facts. Visual states/keyboard outcomes are manual only; no UI assertions or clipboard acceptance.'}
fs.mkdirSync(path.join(evidence,'checks'),{recursive:true})
fs.writeFileSync(path.join(evidence,'checks/runtime-qualification.json'),JSON.stringify(result,null,2)+'\n')
fs.writeFileSync(path.join(evidence,'history/canonical-sources.json'),JSON.stringify(current.sources,null,2)+'\n')
console.log(JSON.stringify({history:{messages:11,sources:192,elapsedMs:history.elapsedMs,exit:0},live:{session:live.session,sources:2,providerRequests:5,elapsedMs:live.elapsedMs,exit:0}}))
