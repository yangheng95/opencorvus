$ErrorActionPreference='Stop'
$taskRun360='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/source-toggle-360-live'
$taskReady360=Get-Content -Raw -LiteralPath (Join-Path $taskRun360 'evidence/preflight-ready.json') | ConvertFrom-Json
if($taskReady360.preflight.credential -ne 'usable' -or $taskReady360.preflight.catalog -ne 'projected' -or $taskReady360.preflight.actualModel -ne 'gpt-6.1-sol' -or !$taskReady360.preflight.streaming){throw 'Exact live model preflight required'}
$taskDirectory360=Join-Path $taskRun360 'project/资料/展开核对'
[IO.Directory]::CreateDirectory($taskDirectory360)|Out-Null
$taskInputs360=@()
foreach($taskName360 in @('甲','乙')){
 $taskPath360=Join-Path $taskDirectory360 ($taskName360+'.md')
 if(Test-Path -LiteralPath $taskPath360){throw 'Fresh authored input required'}
 $taskLines360=@(('# 来源'+$taskName360),('SOURCE360：'+$taskName360+'文件的唯一命中。'))
 [IO.File]::WriteAllText($taskPath360,($taskLines360 -join "`n")+"`n",[Text.UTF8Encoding]::new($false))
 $taskInputs360+=@{path=$taskPath360;lines=$taskLines360}
}
$taskEvidence360='D:/myhexin-local/opencorvus/specs/artifacts/2026-10-05-connection-workspace-authority/source-toggle-360'
[IO.File]::WriteAllText((Join-Path $taskEvidence360 'search-inputs.json'),(@{directory=$taskDirectory360;query='SOURCE360';files=$taskInputs360}|ConvertTo-Json -Depth 7)+"`n",[Text.UTF8Encoding]::new($false))
$taskRequest360='请用 search_code 在当前项目的“资料/展开核对”目录检索字面量 SOURCE360，限定 Markdown 文件，最多返回2条命中。保留工具产生的来源，搜索结束只用一句话报告实际结果。不读取或修改文件，不创建任务或成员。'
[IO.File]::WriteAllText('D:/myhexin-local/opencorvus/.tmp-product-iteration/source-toggle-360/live-request.txt',$taskRequest360,[Text.UTF8Encoding]::new($false))
Write-Output 'Two actual Markdown files prepared, each with one distinct SOURCE360 match.'
