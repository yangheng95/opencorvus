import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import {createRequire} from 'node:module'
const evidence=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/source-toggle-360')
const read=(relative:string)=>JSON.parse(fs.readFileSync(path.join(evidence,relative),'utf8'))
const scope='integrated',label='source-toggle-360-integrated'
const native=read(`${scope}/${label}-native-host-settled.json`),physical=read(`${scope}/${label}-physical-terminal-and-pair-cleanup.json`),http=read(`${scope}/${label}-http-summary.json`)
assert.equal(native.terminal.exitCode,0);assert.equal(native.terminal.reason,'exited')
for(const key of ['physicalCompletion','outputDrainComplete','requestCleanupComplete'])assert.equal(native[key],true)
assert.equal(physical.physicalCompletion,true);assert.equal(physical.pairedCleanupComplete,true)
const served=http.requests.filter((r:any)=>r.data?.path==='/ui/assets/main-GGpG4cxE.js'&&r.data?.status==='completed')
assert.equal(served.length>0,true);for(const r of served)assert.equal(r.data.statusCode,200)
const input=read('integrated-search-inputs.json'),canonical=read('integrated/canonical-current-conversations.json')
const sources=canonical.parts.filter((p:any)=>p.type==='source-file')
assert.equal(sources.length,2);assert.equal(sources[0].messageID,sources[1].messageID)
for(const source of sources){const file=input.files.find((f:any)=>f.path===source.path);assert.equal(typeof file.path,'string');assert.deepEqual(fs.readFileSync(file.path,'utf8').trimEnd().split(/\r?\n/),file.lines);assert.equal(source.title,path.basename(file.path));assert.deepEqual(source.range,{startLine:2,endLine:2});assert.equal(file.lines[1].startsWith(input.query),true)}
const tool=canonical.tools.find((t:any)=>t.message_id===sources[0].messageID),request=JSON.parse(tool.data)
assert.equal(request.tool,'search_code');assert.deepEqual(request.input,{pattern:'SOURCE360',path:'资料/展开核对',include:'*.md'})
const outcome=canonical.outcomes.find((o:any)=>o.requestPartID===tool.id)
assert.equal(outcome.outcome,'completed');assert.equal(outcome.metadata.matches,2)
assert.equal(outcome.output,'Found 2 matches\n'+sources.map((s:any)=>`${s.path}:\n  Line 2: ${input.files.find((f:any)=>f.path===s.path).lines[1]}`).join('\n\n'))
const sourceMessage=canonical.messages.find((m:any)=>m.id===sources[0].messageID),final=canonical.messages.find((m:any)=>m.sessionID===sourceMessage.sessionID&&m.role==='assistant'&&m.finish==='stop')
assert.equal(final.modelID,'gpt-6.1-sol');assert.equal(final.providerID,'openai');assert.equal(final.time.completed>=final.time.created,true)
const audit=read(`integrated/${label}-final-provider-audit.json`)
assert.equal(audit.requests.length,5)
for(const r of audit.requests){assert.equal(r.model,'gpt-6.1-sol');assert.equal(r.streaming,true);assert.equal(r.status,200);assert.equal(r.response_reader.state,'settled');assert.equal(r.response_reader.terminal.kind,'eof')}
const preflight=read(`integrated/${label}-preflight-ready.json`).preflight
assert.equal(preflight.credential,'usable');assert.equal(preflight.catalog,'projected');assert.equal(preflight.actualModel,'gpt-6.1-sol');assert.equal(preflight.streaming,true)
const qualification=read(`integrated/${label}-qualified-surface-completion.json`)
assert.equal(qualification.qualification,'NativeService');assert.equal(qualification.providerEOFRequests,5);assert.equal(qualification.physicalCompletion,true)
const productionRequire=createRequire(path.resolve('packages/opencorvus/package.json'))
const dependencyVersion=JSON.parse(fs.readFileSync(productionRequire.resolve('ai/package.json'),'utf8')).version
assert.equal(dependencyVersion,'7.0.138')
const birth=Number(BigInt(native.target.processInstanceID.slice(6))/10000n-62135596800000n)
const result={checkedAt:new Date().toISOString(),afterMerge:'6d3a6c230',dependencyVersion,initialHandle:40203,launcherExitCode:0,session:sourceMessage.sessionID,sources,toolID:tool.id,finalMessageID:final.id,preflight,providerRequests:5,native,physical,qualification,elapsedMs:Date.parse(native.observedAtUtc)-birth,served,boundary:'Fresh actual canonical search, input files, Provider streams, current dependency package, HTTP asset and Native qualification after upstream SDK 7 merge. UI is manual only, no UI assertions.'}
fs.writeFileSync(path.join(evidence,'checks/integrated-qualification.json'),JSON.stringify(result,null,2)+'\n')
console.log(JSON.stringify({session:result.session,sources:2,providerRequests:5,dependencyVersion,elapsedMs:result.elapsedMs,exit:0}))
