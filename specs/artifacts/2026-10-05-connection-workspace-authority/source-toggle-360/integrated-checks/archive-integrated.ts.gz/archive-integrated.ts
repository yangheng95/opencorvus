import fs from 'node:fs'
import path from 'node:path'
import {gzipSync,gunzipSync} from 'node:zlib'
import {CredentialRedactor} from '../../packages/opencorvus/script/real-provider-audit'
const root=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/source-toggle-360')
const scratch=path.resolve('.tmp-product-iteration/source-toggle-360'),originals=path.join(scratch,'full-originals-integrated')
const folder=path.join(root,'integrated'),checks=path.join(root,'integrated-checks'),prefix='source-toggle-360-integrated'
const redactor=new CredentialRedactor()
redactor.collect(JSON.parse(fs.readFileSync('C:/Users/hengu/AppData/Local/opencorvus/data/auth.json','utf8')))
fs.mkdirSync(checks,{recursive:true})
const files:any[]=[]
function preserve(source:string){const relative=path.relative(root,source),dest=path.resolve(originals,relative);if(relative.startsWith('..')||path.isAbsolute(relative)||!dest.startsWith(originals+path.sep)||fs.existsSync(dest))throw Error('Exact unique original path required');fs.mkdirSync(path.dirname(dest),{recursive:true});fs.renameSync(source,dest)}
function pack(source:string,relative:string){const raw=Buffer.from(redactor.redact(fs.readFileSync(source,'utf8'))),zip=gzipSync(raw,{level:9});if(!gunzipSync(zip).equals(raw))throw Error('Full decompressed bytes differ');fs.mkdirSync(path.dirname(path.join(root,relative)),{recursive:true});fs.writeFileSync(path.join(root,relative),zip,{flag:'wx'});files.push({source,archive:relative,originalBytes:raw.length,compressedBytes:zip.length,integrity:'Full decompressed bytes equal actual credential-redacted original'})}
const owner=JSON.parse(fs.readFileSync(path.join(folder,prefix+'-launch-owner.json'),'utf8'))
const chains=fs.readdirSync(folder).filter(x=>x.startsWith(prefix+'-chain-supervision-')&&x.endsWith('.json')).sort()
const entries=chains.map(name=>{const text=redactor.redact(fs.readFileSync(path.join(folder,name),'utf8'));if(JSON.parse(text).occurrence!==owner.occurrence)throw Error('Current supervision identity mismatch');return{name,text}})
const raw=Buffer.from(JSON.stringify(entries)),zip=gzipSync(raw,{level:9});if(!gunzipSync(zip).equals(raw))throw Error('Complete supervision archive differs')
fs.writeFileSync(path.join(folder,'supervision-chain.json.gz'),zip,{flag:'wx'});for(const name of chains)preserve(path.join(folder,name))
for(const name of fs.readdirSync(folder)){
 if(!/\.(json|log)$/.test(name))continue
 const source=path.join(folder,name)
 if(name.endsWith('.json')&&fs.statSync(source).size<20000)continue
 pack(source,path.join('integrated',name+'.gz'));preserve(source)
}
for(const name of ['prepare-integrated.ps1','integrated-request.txt','install-integrated.log','types-integrated.log','build-integrated.log','launch-integrated.log','shutdown-integrated.log','archive-integrated-live.ts','archive-integrated-live.log','archive-piles-integrated.ps1','check-integrated.ts','integrated-check.log','docs-integrated.log','archive-integrated.ts'])pack(path.join(scratch,name),path.join('integrated-checks',name+'.gz'))
fs.writeFileSync(path.join(checks,'archive-receipt.json'),JSON.stringify({files,supervision:{count:chains.length,archive:'integrated/supervision-chain.json.gz',integrity:'All exact redacted supervision records retained; private originals preserved'},boundary:'Independent evidence after upstream SDK 7 merge; no previous model qualification reused'},null,2)+'\n',{flag:'wx'})
let textFiles=0
for(const entry of fs.readdirSync(root,{recursive:true,withFileTypes:true}).filter(x=>x.isFile())){if(entry.name.endsWith('.png'))continue;const raw=fs.readFileSync(path.join(entry.parentPath,entry.name)),text=(entry.name.endsWith('.gz')?gunzipSync(raw):raw).toString('utf8');if(redactor.containsCredential(text))throw Error('Credential found in final evidence');textFiles++}
fs.writeFileSync(path.join(checks,'credential-scan.json'),JSON.stringify({textFiles,credentialMatches:0,archives:'All original and integrated decompressed evidence text scanned'},null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({files:files.length,supervision:chains.length,textFiles,credentialMatches:0}))
