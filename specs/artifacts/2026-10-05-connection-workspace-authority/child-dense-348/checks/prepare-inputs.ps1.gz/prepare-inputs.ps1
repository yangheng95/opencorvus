$ErrorActionPreference='Stop'
$taskRun='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-12/child-dense-348-live-01'
$taskReady=Get-Content (Join-Path $taskRun 'evidence/preflight-ready.json') -Raw|ConvertFrom-Json
if($taskReady.preflight.credential -ne 'usable' -or $taskReady.preflight.catalog -ne 'projected' -or $taskReady.preflight.actualModel -ne 'gpt-6.1-sol' -or !$taskReady.preflight.streaming){throw 'Exact live model preflight required'}
$taskRecords=@()
foreach($taskCase in @(@('候选方案甲','甲'),@('候选方案乙','乙'))){
 $taskDir=Join-Path $taskRun ('project/资料/研究记录/'+$taskCase[0])
 New-Item -ItemType Directory -Path $taskDir -Force|Out-Null
 $taskPath=Join-Path $taskDir '来源记录_相同名称与不同行号.md'
 if(Test-Path -LiteralPath $taskPath){throw 'Fresh authored input required'}
 $taskLines=@('# 只读场景资料：来源定位要求不等于实测结论。')
 $taskLines+=1..32|ForEach-Object{'STREAM348 '+$taskCase[1]+('记录{0:D2}：标题可以相同，引用仍需区分真实路径和第{1}行。' -f $_,($_+1))}
 [IO.File]::WriteAllText($taskPath,($taskLines -join "`n")+"`n",[Text.UTF8Encoding]::new($false))
 $taskRecords+=@{path=$taskPath;lines=$taskLines;matches=32}
}
[IO.File]::WriteAllText('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-05-connection-workspace-authority/child-dense-348/input-documents.json',($taskRecords|ConvertTo-Json -Depth 5)+"`n",[Text.UTF8Encoding]::new($false))
$taskReady.preflight|ConvertTo-Json
