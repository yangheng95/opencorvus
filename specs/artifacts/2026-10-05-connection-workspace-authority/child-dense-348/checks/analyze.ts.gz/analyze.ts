import fs from "node:fs"
import path from "node:path"
import { Database } from "bun:sqlite"
import { gzipSync, gunzipSync } from "node:zlib"
import assert from "node:assert/strict"
import { CredentialRedactor } from "../../packages/opencorvus/script/real-provider-audit"
const run = "C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-12/child-dense-348-live-01"
const root = path.resolve("specs/artifacts/2026-10-05-connection-workspace-authority/child-dense-348")
const scratch = path.resolve(".tmp-product-iteration/child-dense-348")
const canonical = JSON.parse(fs.readFileSync(path.join(root, "live-01/canonical-current-conversations.json"), "utf8"))
const stream = JSON.parse(fs.readFileSync(path.join(scratch, "live-source-observation.json"), "utf8"))
const redactor = new CredentialRedactor()
redactor.collect(JSON.parse(fs.readFileSync("C:/Users/hengu/AppData/Local/opencorvus/data/auth.json", "utf8")))
const write = (name: string, value: unknown) => fs.writeFileSync(path.join(root, name), redactor.redact(JSON.stringify(value, null, 2)) + "\n", { flag: "wx" })
const tools = canonical.tools.map((row: any) => ({ id: row.id, messageID: row.message_id, ...JSON.parse(row.data) }))
const reads = tools.filter((tool: any) => tool.tool === "read_agent_message").map((tool: any) => {
  const outcome = canonical.outcomes.find((row: any) => row.requestPartID === tool.id)
  const result = outcome?.outcome === "completed" ? JSON.parse(outcome.output) : undefined
  return { requestPartID: tool.id, input: tool.input, outcome: outcome?.outcome, failure: outcome?.failure,
    returnedMessages: result?.messages?.map((message: any) => ({ messageID: message.message_id, textChars: message.text.join("\n").length })),
    inventoryMessageIDs: result?.causal_part_message_inventory?.map((message: any) => message.message_id),
    returnedEvidenceFields: result?.evidence_reads?.map((read: any) => ({ messageID: read.message_id, partID: read.part_id, field: read.field, chars: read.content.length, nextOffset: read.next_offset })) }
})
const db = new Database(path.join(run, "runtime/data/opencorvus.db"), { readonly: true })
let workerMessages: any[]
try {
  workerMessages = db.query("SELECT id,session_id,data FROM message WHERE json_extract(data,'$.role')='assistant' AND json_extract(data,'$.agent')='base-researcher' ORDER BY time_created,id").all().map((row: any) => {
    const info = JSON.parse(row.data)
    return { messageID: row.id, sessionID: row.session_id, parentID: info.parentID, time: info.time, finish: info.finish,
      textParts: canonical.parts.filter((part: any) => part.messageID === row.id && part.type === "text").map((part: any) => ({ id: part.id, chars: part.textChars, headings: part.text.split("\n").filter((line: string) => /^#{1,3} /.test(line)) })) }
  })
} finally { db.close() }
const comparisons = stream.parts.map((part: any) => {
  const actual = canonical.parts.find((candidate: any) => candidate.id === part.partID)
  return { sessionID: part.sessionID, messageID: part.messageID, partID: part.partID, field: part.field, events: part.count,
    wireChars: part.value.length, canonicalChars: actual?.text?.length, exact: actual?.text === part.value,
    canonicalEqualsFinalTrimEnd: actual?.text === part.value.trimEnd(), discontinuities: part.discontinuities }
})
write("observed-stream-and-narration-reads.json", {
  observedAtUtc: new Date().toISOString(), taskID: stream.taskID,
  boundary: "Actual completed public Task stream and readonly canonical storage. This is not a browser-lifetime assertion. Intermediate assistant prose is read from canonical text Parts through exact settled occurrence authority; actual inputs and outputs remain in this evidence.",
  terminal: stream.terminal, events: stream.events, wireBytes: stream.wireBytes, decodedBytes: stream.decodedBytes,
  sources: stream.sources, comparisons, workerMessages, reads,
  dispatches: tools.filter((tool: any) => tool.tool === "dispatch_agent").map((tool: any) => ({ id: tool.id, input: tool.input })),
})
const packed = gzipSync(Buffer.from(redactor.redact(JSON.stringify(stream, null, 2))), { level: 9 })
assert.deepEqual(JSON.parse(gunzipSync(packed).toString()), JSON.parse(redactor.redact(JSON.stringify(stream))))
fs.writeFileSync(path.join(root, "live-source-observation.json.gz"), packed, { flag: "wx" })
for (const name of ["task-boundary-admitted.json", "task-occurrence-admitted.json", "task-complete.json"]) {
  fs.writeFileSync(path.join(root, "live-01", name), redactor.redact(fs.readFileSync(path.join(run, "evidence", name), "utf8")), { flag: "wx" })
}
for (const name of ["sent.json", "task-create.log"]) {
  fs.writeFileSync(path.join(root, name), redactor.redact(fs.readFileSync(path.join(scratch, name), "utf8")), { flag: "wx" })
}
console.log(JSON.stringify({ taskID: stream.taskID, comparisons, sourceEvents: stream.sources.length, workerMessages, readOutcomes: reads.map((read: any) => ({ outcome: read.outcome, returnedMessages: read.returnedMessages })) }))
