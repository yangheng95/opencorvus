import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import {gzipSync,gunzipSync} from 'node:zlib'
import {CredentialRedactor} from '../../packages/opencorvus/script/real-provider-audit'
const root=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/child-dense-348')
const scratch=path.resolve('.tmp-product-iteration/child-dense-348')
const run='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-12/child-dense-348-live-01',label='child-dense-348-live-01',dir=path.join(root,'live-01')
const redactor=new CredentialRedactor();redactor.collect(JSON.parse(fs.readFileSync('C:/Users/hengu/AppData/Local/opencorvus/data/auth.json','utf8')))
fs.mkdirSync(path.join(root,'checks'),{recursive:true})
const read=(name:string)=>JSON.parse(fs.readFileSync(path.join(root,name),'utf8'))
const save=(name:string,value:unknown)=>fs.writeFileSync(path.join(root,name),redactor.redact(JSON.stringify(value,null,2))+'\n',{flag:'wx'})
const canonical=read('live-01/canonical-current-conversations.json'),observation=read('observed-stream-and-narration-reads.json'),inputs=read('input-documents.json')
const tools=canonical.tools.map((r:any)=>({id:r.id,messageID:r.message_id,...JSON.parse(r.data)}))
assert.deepEqual(tools.filter((t:any)=>t.tool==='dispatch_agent').map((t:any)=>t.input.dispatch.target),['base-researcher'])
const sourceParts=canonical.parts.filter((p:any)=>['source-file','source-url'].includes(p.type))
const searches=tools.filter((t:any)=>t.tool==='search_code');assert.equal(searches.length,1);assert.equal(searches[0].input.pattern,'STREAM348')
assert.equal(path.resolve(searches[0].input.path),path.resolve(run,'project/资料'))
const groups=inputs.map((input:any)=>{
  assert.equal(fs.readFileSync(input.path,'utf8'),input.lines.join('\n')+'\n')
  const actual=sourceParts.filter((s:any)=>s.type==='source-file'&&s.provider==='opencorvus-search-code'&&path.resolve(s.path)===path.resolve(input.path))
  assert.deepEqual(actual.map((s:any)=>s.range.startLine).sort((a:number,b:number)=>a-b),Array.from({length:input.matches},(_,i)=>i+2))
  for(const s of actual)assert.equal(s.range.startLine,s.range.endLine)
  return {path:input.path,count:actual.length,ranges:actual.map((s:any)=>s.range),sourceIDs:actual.map((s:any)=>s.sourceId)}
})
assert.equal(sourceParts.length,inputs.reduce((n:number,i:any)=>n+i.matches,0)+2)
const urlSource=sourceParts.filter((s:any)=>s.type==='source-url');assert.equal(urlSource.length,1)
assert.equal(urlSource[0].url,'https://developer.mozilla.org/zh-CN/docs/Web/API/URL/URL#%E5%8F%82%E6%95%B0')
for(const s of sourceParts)assert.ok(observation.sources.some((e:any)=>e.part.id===s.id))
for(const c of observation.comparisons)assert.equal(c.canonicalEqualsFinalTrimEnd,true)
const workerIDs=new Set(observation.workerMessages.map((m:any)=>m.sessionID));assert.equal(workerIDs.size,1)
const workerID=[...workerIDs][0];const workerParts=observation.workerMessages.flatMap((m:any)=>m.textParts)
const outcome=(id:string)=>canonical.outcomes.find((o:any)=>o.requestPartID===id)
const actualReads=tools.filter((t:any)=>t.tool==='read_agent_message').map((t:any)=>({tool:t,result:JSON.parse(outcome(t.id).output)}))
const narrated=workerParts.filter((p:any)=>p.headings.length>0)
for(const p of narrated){
  const original=canonical.parts.find((x:any)=>x.id===p.id)
  assert.ok(actualReads.some(({result}:any)=>result.evidence_reads?.some((e:any)=>e.part_id===p.id&&e.field==='text'&&e.content===original.text&&e.next_offset===null)||result.messages?.some((m:any)=>m.message_id===original.messageID&&m.text.join('\n')===original.text)))
}
const copies=['copied-乙20.json','copied-甲20.json','copied-after-乙20.json','copied-after-甲20.json'].map(name=>{
 const actual=read(name),input=inputs.find((i:any)=>path.basename(path.dirname(i.path))==='候选方案'+actual.file)
 assert.equal(actual.value,path.normalize(input.path)+':20');return {name,...actual}
})
const audit=read('live-01/'+label+'-final-provider-audit.json')
for(const r of audit.requests){assert.equal(r.model,'gpt-6.1-sol');assert.equal(r.streaming,true);assert.equal(r.status,200);assert.equal(r.response_reader.terminal.kind,'eof');assert.equal(r.response_reader.requestContext.streamRequest.apiModelID,'gpt-6.1-sol')}
const shots=read('screenshot-times.json').map((s:any)=>({...s,actualWorkerReaders:audit.requests.filter((r:any)=>r.response_reader.requestContext.sessionID===workerID&&r.response_reader.requestContext.streamRequest.agentID==='base-researcher'&&r.response_reader.boundAt<=Date.parse(s.at)&&r.response_reader.terminal.at>=Date.parse(s.at)).map((r:any)=>({request:r.response_reader.requestContext,from:r.response_reader.boundAt,to:r.response_reader.terminal.at}))}))
const owner=JSON.parse(fs.readFileSync(path.join(run,'launch-owner.json'),'utf8')),settled=JSON.parse(fs.readFileSync(path.join(run,'evidence/native-host-settled.json'),'utf8')),qualification=read('live-01/'+label+'-qualified-surface-completion.json'),task=read('live-01/task-complete.json')
assert.equal(task.lifecycle.status,'completed');assert.equal(qualification.qualification,'Task');assert.equal(qualification.taskID,task.selected.taskID)
assert.equal(settled.physicalCompletion,true);assert.equal(settled.outputDrainComplete,true);assert.equal(settled.requestCleanupComplete,true);assert.equal(qualification.physicalCompletion,true)
const pair=read('live-01/'+label+'-physical-terminal-and-pair-cleanup.json');assert.equal(pair.pairedCleanupComplete,true)
const records=fs.readFileSync(path.join(dir,label+'-runtime.log'),'utf8').split(/\r?\n/).filter(Boolean).map(l=>JSON.parse(l))
const served=records.filter(x=>x.service==='server'&&x.data?.status==='completed'&&['/ui/assets/main-DbppdFkA.js','/ui/assets/main-enuOTKXR.js'].includes(x.data.path)).map(x=>({path:x.data.path,status:x.data.statusCode}))
for(const asset of ['main-DbppdFkA.js','main-enuOTKXR.js'])assert.ok(served.some(x=>x.path==='/ui/assets/'+asset&&x.status===200))
const birth=Number(BigInt(owner.nativeTarget.processInstanceID.slice(6))/10000n-62135596800000n)
save('checks/actual-qualification.json',{taskID:task.selected.taskID,workerID,taskElapsedMs:task.lifecycle.terminalAt-task.lifecycle.openedAt,workerNarration:workerParts,workerTextChars:workerParts.reduce((n:number,p:any)=>n+p.chars,0),groups,sourceCount:sourceParts.length,sourceStreamEvents:observation.sources.length,streamComparisons:observation.comparisons,narrationReadContract:'All three actual narrative blocks equal the complete canonical text returned to the orchestrator',copies,served,shots,providerRequests:audit.requests.length,qualification,nativeElapsedMs:Date.parse(settled.observedAtUtc)-birth,native:settled,pairedCleanupComplete:true,actualJoins:{taskCreate:0,observer:{handle:67376,exitCode:0},launcher:{handle:33182,exitCode:0},build:{handle:94127,exitCode:0},typecheck:{handle:87261,exitCode:0}},boundary:'Actual backend, copied payload and owner checks. No UI assertions. Twelve screenshots require separate manual interpretation; 09 is pending file loading, 10 is the ready file. Initial streamed view uses baseline bundle; copy-label repair reviewed after real-task completion.'})
const archives:any[]=[]
function archive(from:string,name:string){const raw=Buffer.from(redactor.redact(fs.readFileSync(from,'utf8'))),zip=gzipSync(raw,{level:9});assert.equal(gunzipSync(zip).equals(raw),true);fs.writeFileSync(path.join(root,name+'.gz'),zip,{flag:'wx'});archives.push({source:from,archive:name+'.gz',bytes:raw.length,compressedBytes:zip.length,integrity:'Full decompressed bytes equal actual credential-redacted original'})}
const chains=fs.readdirSync(dir).filter(n=>n.startsWith(label+'-chain-supervision-')&&n.endsWith('.json')).sort()
const entries=chains.map(name=>{const text=redactor.redact(fs.readFileSync(path.join(dir,name),'utf8'));assert.equal(JSON.parse(text).occurrence,owner.occurrence);return {name,text}})
const raw=Buffer.from(JSON.stringify(entries)),zip=gzipSync(raw,{level:9});assert.equal(gunzipSync(zip).equals(raw),true);fs.writeFileSync(path.join(dir,'supervision-chain.json.gz'),zip,{flag:'wx'})
const privateDir=path.join(scratch,'original-supervision');fs.mkdirSync(privateDir,{recursive:true});for(const name of chains){const dest=path.join(privateDir,name);if(fs.existsSync(dest))throw Error('Preserve original archive');fs.renameSync(path.join(dir,name),dest)}
for(const name of [label+'-runtime.log',label+'-stdout.log',label+'-stderr.log',label+'-unknown-timestamp.log']){archive(path.join(dir,name),'live-01/'+name);const dest=path.join(scratch,name);if(fs.existsSync(dest))throw Error('Preserve private log');fs.renameSync(path.join(dir,name),dest)}
for(const name of fs.readdirSync(scratch).filter(n=>/\.(ts|ps1|json|log)$/.test(n)))archive(path.join(scratch,name),'checks/'+name)
save('checks/archive-receipt.json',{files:archives,supervision:{count:chains.length,archive:'live-01/supervision-chain.json.gz',integrity:'Each complete redacted original text retained; originals preserved privately'}})
let textFiles=0;for(const entry of fs.readdirSync(root,{recursive:true,withFileTypes:true}).filter(x=>x.isFile())){if(entry.name.endsWith('.png'))continue;const bytes=fs.readFileSync(path.join(entry.parentPath,entry.name)),text=(entry.name.endsWith('.gz')?gunzipSync(bytes):bytes).toString('utf8');if(redactor.containsCredential(text))throw Error('Credential in evidence');textFiles++}
save('checks/credential-scan.json',{textFiles,credentialMatches:0,archives:'Full decompressed text scanned'})
console.log(JSON.stringify({taskID:task.selected.taskID,workerID,sourceCount:sourceParts.length,providerRequests:audit.requests.length,workerTextChars:workerParts.reduce((n:number,p:any)=>n+p.chars,0),streamedScreens:shots.filter((s:any)=>s.actualWorkerReaders.length>0).map((s:any)=>s.file),supervisionFiles:chains.length,textFiles,credentialMatches:0}))
