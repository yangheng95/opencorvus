import fs from 'node:fs'
import path from 'node:path'
import {gzipSync,gunzipSync} from 'node:zlib'
const root=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/task-recovery-355')
const privateRoot=path.resolve('.tmp-product-iteration/task-recovery-355/full-originals')
const files=[]
for(const name of ['08-header-accessibility.txt','09-ordinary-chat-activity.txt']){
 const source=path.resolve(root,name),destination=path.resolve(privateRoot,name)
 if(!source.startsWith(root+path.sep)||!destination.startsWith(privateRoot+path.sep)||fs.existsSync(destination))throw Error('Exact single AX archive paths required')
 const raw=fs.readFileSync(source),zip=gzipSync(raw,{level:9})
 if(!gunzipSync(zip).equals(raw))throw Error('Actual AX full bytes changed')
 fs.writeFileSync(source+'.gz',zip,{flag:'wx'});fs.renameSync(source,destination)
 files.push({source:name,archive:name+'.gz',bytes:raw.length,integrity:'Exact raw AX including original list-marker whitespace retained'})
}
fs.writeFileSync(path.join(root,'checks/ax-archive-receipt.json'),JSON.stringify({files},null,2)+'\n',{flag:'wx'})
