import fs from 'node:fs'
import path from 'node:path'
import {gzipSync,gunzipSync} from 'node:zlib'
import {CredentialRedactor} from '../../packages/opencorvus/script/real-provider-audit'
const root=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/task-recovery-355')
const scratch=path.resolve('.tmp-product-iteration/task-recovery-355')
const originals=path.join(scratch,'full-originals')
const redactor=new CredentialRedactor()
redactor.collect(JSON.parse(fs.readFileSync('C:/Users/hengu/AppData/Local/opencorvus/data/auth.json','utf8')))
fs.mkdirSync(path.join(root,'checks'),{recursive:true})
const files:any[]=[]
function preserve(source:string){const relative=path.relative(root,source),dest=path.resolve(originals,relative);if(relative.startsWith('..')||path.isAbsolute(relative)||!dest.startsWith(originals+path.sep)||fs.existsSync(dest))throw Error('Exact unique original path required');fs.mkdirSync(path.dirname(dest),{recursive:true});fs.renameSync(source,dest)}
function pack(source:string,relative:string){const raw=Buffer.from(redactor.redact(fs.readFileSync(source,'utf8'))),zip=gzipSync(raw,{level:9});if(!gunzipSync(zip).equals(raw))throw Error('Full decompressed bytes differ');fs.mkdirSync(path.dirname(path.join(root,relative)),{recursive:true});fs.writeFileSync(path.join(root,relative),zip,{flag:'wx'});files.push({source,archive:relative,originalBytes:raw.length,compressedBytes:zip.length,integrity:'Full decompressed bytes equal actual credential-redacted original'})}
const live=path.join(root,'live-01'),prefix='task-recovery-355-live-01'
const owner=JSON.parse(fs.readFileSync(path.join(live,prefix+'-launch-owner.json'),'utf8'))
const chains=fs.readdirSync(live).filter(x=>x.startsWith(prefix+'-chain-supervision-')&&x.endsWith('.json')).sort()
const entries=chains.map(name=>{const text=redactor.redact(fs.readFileSync(path.join(live,name),'utf8'));if(JSON.parse(text).occurrence!==owner.occurrence)throw Error('Actual current supervision identity mismatch');return{name,text}})
const raw=Buffer.from(JSON.stringify(entries)),zip=gzipSync(raw,{level:9});if(!gunzipSync(zip).equals(raw))throw Error('Complete supervision archive differs')
fs.writeFileSync(path.join(live,'supervision-chain.json.gz'),zip,{flag:'wx'});for(const name of chains)preserve(path.join(live,name))
for(const entry of fs.readdirSync(root,{recursive:true,withFileTypes:true})){
 if(!entry.isFile()||! /\.(json|log)$/.test(entry.name)||entry.name==='actual-recovery-check.json')continue
 const source=path.resolve(entry.parentPath,entry.name),relative=path.relative(root,source)
 if(entry.name.endsWith('.json')&&fs.statSync(source).size<20000)continue
 pack(source,relative+'.gz');preserve(source)
}
for(const sub of ['', 'history-after'])for(const name of fs.readdirSync(path.join(scratch,sub)).filter(x=>/\.(ts|ps1|json|jsonl|log|txt)$/.test(x)&&x!=='archive.log'))pack(path.join(scratch,sub,name),path.join('checks',sub,name+'.gz'))
for(const name of ['live-sol-recovery-cli-355.ts','live-sol-recovery-launch-355.ps1'])pack(path.resolve('.tmp-product-iteration',name),'checks/'+name+'.gz')
fs.writeFileSync(path.join(root,'checks/archive-receipt.json'),JSON.stringify({files,supervision:{count:chains.length,archive:'live-01/supervision-chain.json.gz',integrity:'All exact redacted supervision records retained; private originals preserved'}},null,2)+'\n',{flag:'wx'})
let textFiles=0
for(const entry of fs.readdirSync(root,{recursive:true,withFileTypes:true}).filter(x=>x.isFile())){if(entry.name.endsWith('.png'))continue;const raw=fs.readFileSync(path.join(entry.parentPath,entry.name)),text=(entry.name.endsWith('.gz')?gunzipSync(raw):raw).toString('utf8');if(redactor.containsCredential(text))throw Error('Credential found in final evidence');textFiles++}
fs.writeFileSync(path.join(root,'checks/credential-scan.json'),JSON.stringify({textFiles,credentialMatches:0,archives:'Full decompressed texts scanned'},null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({supervisionFiles:chains.length,files:files.length,textFiles,credentialMatches:0}))
