import fs from 'node:fs'
import path from 'node:path'
import {gzipSync,gunzipSync} from 'node:zlib'
import {CredentialRedactor} from '../../packages/opencorvus/script/real-provider-audit'
const root=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/task-recovery-355')
const scratch=path.resolve('.tmp-product-iteration/task-recovery-355')
const redactor=new CredentialRedactor()
redactor.collect(JSON.parse(fs.readFileSync('C:/Users/hengu/AppData/Local/opencorvus/data/auth.json','utf8')))
for(const name of ['archive-ax.ts','finalize-evidence.ts']){
 const raw=Buffer.from(redactor.redact(fs.readFileSync(path.join(scratch,name),'utf8'))),zip=gzipSync(raw,{level:9})
 if(!gunzipSync(zip).equals(raw))throw Error('Helper archive roundtrip differs')
 fs.writeFileSync(path.join(root,'checks',name+'.gz'),zip,{flag:'wx'})
}
let textFiles=0
for(const entry of fs.readdirSync(root,{recursive:true,withFileTypes:true}).filter(x=>x.isFile())){
 if(entry.name.endsWith('.png'))continue
 const raw=fs.readFileSync(path.join(entry.parentPath,entry.name)),text=(entry.name.endsWith('.gz')?gunzipSync(raw):raw).toString('utf8')
 if(redactor.containsCredential(text))throw Error('Credential found in final evidence')
 textFiles++
}
fs.writeFileSync(path.join(root,'checks/credential-scan-final.json'),JSON.stringify({textFiles,credentialMatches:0,archives:'Full decompressed texts scanned after AX archive supplement'},null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({textFiles,credentialMatches:0}))
