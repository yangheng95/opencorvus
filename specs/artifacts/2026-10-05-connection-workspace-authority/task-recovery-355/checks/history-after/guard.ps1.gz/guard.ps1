$ErrorActionPreference='Stop'
$taskRepo='D:/myhexin-local/opencorvus'
$taskSource='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-12/task-recovery-355-live-01'
$taskEvidence=Join-Path $taskRepo 'specs/artifacts/2026-10-05-connection-workspace-authority/task-recovery-355/live-01'
$taskOut=Join-Path $taskRepo 'specs/artifacts/2026-10-05-connection-workspace-authority/task-recovery-355/history-after-readiness'
. (Join-Path $taskRepo '.tmp-product-iteration/live-sol-launch.ps1') -FunctionsOnly
$taskOwner=Get-Content (Join-Path $taskSource 'launch-owner.json') -Raw|ConvertFrom-Json -AsHashtable -DateKind String
$taskStates=@(@{expected=$taskOwner.host;state=(Get-OwnedNativeState $taskOwner.host)},@{expected=$taskOwner.nativeTarget;state=(Get-OwnedNativeState $taskOwner.nativeTarget)})
$taskListeners=@(Get-NetTCPConnection -State Listen -ErrorAction Stop|Where-Object {$_.LocalPort -in @($taskOwner.port,18338)})
$taskPair=@('auth.json','models.json'|ForEach-Object{@{name=$_;present=(Test-Path -LiteralPath (Join-Path $taskSource ('runtime/data/'+$_)))}})
$taskNative=Get-OwnedNativeSettlement $taskOwner
$taskComplete=Get-Content (Join-Path $taskEvidence 'task-complete.json') -Raw|ConvertFrom-Json -AsHashtable -DateKind String
$taskQualified=Get-Content (Join-Path $taskEvidence 'task-recovery-355-live-01-physical-terminal-and-pair-cleanup.json') -Raw|ConvertFrom-Json -AsHashtable -DateKind String
if(@($taskStates|Where-Object state -ne 'dead_or_reused').Count -or $taskListeners.Count -or @($taskPair|Where-Object present).Count -or !$taskNative -or $taskNative.terminal.exitCode -ne 0){throw 'Original physical/runtime closure incomplete'}
if($taskComplete.occurrence -cne $taskOwner.occurrence -or $taskComplete.pinned.taskID -cne 'tsk_g00VXqO7wS00Jmf0HdZh' -or $taskComplete.lifecycle.status -cne 'completed' -or $taskComplete.lifecycle.epoch -ne 2 -or $taskQualified.occurrence -cne $taskOwner.occurrence -or !$taskQualified.physicalCompletion -or !$taskQualified.pairedCleanupComplete){throw 'Original exact recovered Task and physical qualification incomplete'}
Write-OwnedLaunchFact (Join-Path $taskOut 'guard.json') @{readQualified=$true;sourceRun=$taskSource;occurrence=$taskOwner.occurrence;observedAtUtc=[DateTime]::UtcNow.ToString('o');states=$taskStates;listenerCount=$taskListeners.Count;pair=$taskPair;native=$taskNative;originalQualification=$taskQualified;originalTask=$taskComplete.pinned;boundary='Fresh exact original Native/Host, port, pair and actual physical/output/request settled receipt; original Task qualification retained. Original recovery launcher99677 actual exit0 and Task epoch2 completed; epoch1 failed history remains intact.'}
$taskManifest=@{sourceRun=$taskSource;sourceEvidence=$taskOwner.settlementEvidenceRoot;sourceProject=$taskOwner.project;caseRun='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-12/task-recovery-355-history-02';caseEvidence=(Join-Path $taskRepo 'specs/artifacts/2026-10-05-connection-workspace-authority/task-recovery-355/history-02');readinessEvidence=$taskOut;casePort=18338;caseLabel='task-recovery-355-history-02';sourceOccurrence=$taskOwner.occurrence;startupQualified=$false;selectedSubject=@{kind='task';id=$taskComplete.pinned.taskID;projectID=$taskComplete.pinned.projectID;sessionID=$taskComplete.pinned.rootSessionID;requestID=$taskComplete.selected.requestID}}
Write-OwnedLaunchFact (Join-Path $taskRepo '.tmp-product-iteration/task-recovery-355/history-after-manifest.json') $taskManifest
Write-Output 'Fresh original closure verified; complete startup observations remain required.'
