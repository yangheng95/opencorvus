import fs from 'node:fs'
import {Database} from 'bun:sqlite'
import {createRequire} from 'node:module'
import {pathToFileURL} from 'node:url'
const repo='D:/myhexin-local/opencorvus'
process.env.OPENCORVUS_HOME=repo+'/.tmp-product-iteration/task-recovery-355/inspection/runtime'
process.env.OPENCORVUS_TEST_HOME=repo+'/.tmp-product-iteration/task-recovery-355/inspection/home'
process.env.OPENCORVUS_TEST_PROCESS_ROOT=repo+'/.tmp-product-iteration/task-recovery-355/inspection'
const require=createRequire(repo+'/packages/opencorvus/package.json')
const {drizzle}=await import(pathToFileURL(require.resolve('drizzle-orm/bun-sqlite')).href)
const {projectToolPartInTransaction}=await import(repo+'/packages/opencorvus/src/session/tool-part-facts.ts')
const root='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-12/task-recovery-355-live-01'
const owner=JSON.parse(fs.readFileSync(root+'/launch-owner.json','utf8'))
const db=new Database(root+'/runtime/data/opencorvus.db',{readonly:true})
db.exec('BEGIN')
try{
 const events=db.query("SELECT id,type,payload,emitted_at FROM protocol_event WHERE aggregate_id=? AND type IN ('task.execution.opened','task.execution.reopened','task.completed','task.failed','task.cancelled') ORDER BY seq").all('tsk_g00VXqO7wS00Jmf0HdZh')
 const messages=db.query("SELECT m.id,m.session_id,m.data FROM message m JOIN session s ON s.id=m.session_id WHERE s.project_id=? AND m.time_created>=? ORDER BY m.time_created,m.id").all('prj_hlWbZXzl9PZEG6Fs17DG',owner.targetBirthAtMs) as any[]
 const ids=new Set(messages.map(m=>m.id))
 const parts=(db.query('SELECT id,message_id,data FROM part ORDER BY time_created,id').all() as any[]).filter(p=>ids.has(p.message_id)).map(p=>({id:p.id,messageID:p.message_id,...JSON.parse(p.data)}))
 const tx=drizzle({client:db})
 parts.push(...(db.query('SELECT * FROM tool_part_request ORDER BY time_created,id').all() as any[]).filter(p=>ids.has(p.message_id)).map(p=>projectToolPartInTransaction(tx,{...p,data:JSON.parse(p.data)})).filter(Boolean))
 const result={at:new Date().toISOString(),events,messages:messages.map(m=>({id:m.id,sessionID:m.session_id,...JSON.parse(m.data)})),parts}
 fs.appendFileSync('D:/myhexin-local/opencorvus/.tmp-product-iteration/task-recovery-355/actual-inspections.jsonl',JSON.stringify(result)+'\n')
 console.log(JSON.stringify({at:result.at,events,assistantMessages:result.messages.filter(m=>m.role==='assistant').map(m=>({id:m.id,agent:m.agent,finish:m.finish,error:m.error,time:m.time})),tools:parts.filter(p=>p.type==='tool').map(p=>({id:p.id,tool:p.tool,status:p.state?.status,error:p.state?.error,outputChars:p.state?.output?.length})),latestTexts:parts.filter(p=>p.type==='text').slice(-2).map(p=>({id:p.id,text:p.text?.slice(-750)}))}))
}finally{db.exec('ROLLBACK');db.close()}
