import fs from 'node:fs'
import path from 'node:path'
import {createRequire} from 'node:module'
import {pathToFileURL} from 'node:url'
import {Database as Sqlite} from 'bun:sqlite'
const repo='D:/myhexin-local/opencorvus'
const scratch=repo+'/.tmp-product-iteration/task-recovery-355'
const run='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-12/task-recovery-355-live-01'
process.env.OPENCORVUS_HOME=scratch+'/pin/runtime'
process.env.OPENCORVUS_TEST_HOME=scratch+'/pin/home'
process.env.OPENCORVUS_TEST_PROCESS_ROOT=scratch+'/pin'
const require=createRequire(repo+'/packages/opencorvus/package.json')
const {drizzle}=await import(pathToFileURL(require.resolve('drizzle-orm/bun-sqlite')).href)
const {taskLifecycleProjectionInTransaction}=await import(repo+'/packages/opencorvus/src/engine/task-lifecycle.ts')
const owner=JSON.parse(fs.readFileSync(run+'/launch-owner.json','utf8'))
const ready=JSON.parse(fs.readFileSync(run+'/evidence/preflight-ready.json','utf8'))
const action=JSON.parse(fs.readFileSync(scratch+'/ui-send.json','utf8'))
if(ready.occurrence!==owner.occurrence||ready.preflight.actualModel!=='gpt-6.1-sol'||!ready.preflight.streaming)throw Error('Exact real streaming preflight required')
const db=new Sqlite(run+'/runtime/data/opencorvus.db',{readonly:true})
db.exec('BEGIN')
try{
 const id='tsk_g00VXqO7wS00Jmf0HdZh'
 const task=db.query('SELECT * FROM engine_task WHERE id=?').get(id) as any
 const lifecycle=taskLifecycleProjectionInTransaction(drizzle({client:db}),id)
 const ingress=db.query("SELECT i.*,m.data AS message_data FROM engine_task_root_ingress i JOIN message m ON m.id=i.source_id WHERE i.task_id=? AND i.source='message' AND i.execution_epoch=2 ORDER BY i.sequence").all(id) as any[]
 if(lifecycle.epoch!==2||ingress.length!==1)throw Error('Await exact real UI epoch2 Message admission')
 const parts=db.query("SELECT data FROM part WHERE message_id=? AND json_extract(data,'$.type')='text' ORDER BY time_created,id").all(ingress[0].source_id) as any[]
 const text=parts.map(p=>JSON.parse(p.data).text).join('\n')
 if(text.trim()!==fs.readFileSync(scratch+'/request.txt','utf8').trim())throw Error('Real operator Message differs from UI request')
 const opened=db.query('SELECT id,type,causation_id,payload FROM protocol_event WHERE id=?').get(lifecycle.openedEventID) as any
 if(opened.type!=='task.execution.reopened'||opened.causation_id!=='pev_g0VXqR1Hl00rlGobCLYi')throw Error('Original failed epoch causation required')
 const selected={occurrence:owner.occurrence,taskID:task.id,projectID:task.project_id,directory:owner.project,productPillar:task.product_pillar,requestID:task.request_id,requestSentAt:action.requestSentAt,acceptedObservedAt:new Date().toISOString(),operatorMessageID:ingress[0].source_id,operatorIngressID:ingress[0].id}
 fs.writeFileSync(run+'/task-selection.json',JSON.stringify(selected,null,2)+'\n',{flag:'wx'})
 fs.writeFileSync(repo+'/specs/artifacts/2026-10-05-connection-workspace-authority/task-recovery-355/live-01/operator-message-admitted.json',JSON.stringify({selected,lifecycle,opened,messageInfo:JSON.parse(ingress[0].message_data),text,identity:'requestID remains original Task creation identity; operatorMessageID and operatorIngressID identify this new real UI input'},null,2)+'\n',{flag:'wx'})
 console.log(JSON.stringify({selected,lifecycle}))
}finally{db.exec('ROLLBACK');db.close()}
