import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import {Database} from 'bun:sqlite'
const repo='D:/myhexin-local/opencorvus'
const evidence=repo+'/specs/artifacts/2026-10-05-connection-workspace-authority/task-recovery-355'
const live=evidence+'/live-01'
const run='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-12/task-recovery-355-live-01'
const canonical=JSON.parse(fs.readFileSync(live+'/canonical-current-conversations.json','utf8'))
const complete=JSON.parse(fs.readFileSync(run+'/evidence/task-complete.json','utf8'))
const provider=JSON.parse(fs.readFileSync(live+'/task-recovery-355-live-01-final-provider-audit.json','utf8'))
const qualified=JSON.parse(fs.readFileSync(live+'/task-recovery-355-live-01-qualified-surface-completion.json','utf8'))
const owner=JSON.parse(fs.readFileSync(run+'/launch-owner.json','utf8'))
const newMessages=canonical.messages.filter((m:any)=>m.time.created>=owner.targetBirthAtMs)
const newIDs=new Set(newMessages.map((m:any)=>m.id))
const tools=canonical.tools.map((r:any)=>({...JSON.parse(r.data),id:r.id,messageID:r.message_id})).filter((r:any)=>newIDs.has(r.messageID))
const reads=tools.filter((p:any)=>p.tool==='read_agent_message').map((p:any)=>({toolPartID:p.id,result:JSON.parse(canonical.outcomes.find((o:any)=>o.requestPartID===p.id).output)}))
const old=new Database('C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-12/child-view-retention-353-live-01/runtime/data/opencorvus.db',{readonly:true})
old.exec('BEGIN')
let original:any[]
try{
 original=(old.query("SELECT p.id,p.message_id,p.data FROM part p JOIN message m ON m.id=p.message_id WHERE m.session_id=? AND json_extract(m.data,'$.role')='assistant' AND json_extract(p.data,'$.type')='text' ORDER BY p.time_created,p.id").all('ses_h9aQ1aKN0qHWqIOhZfo7') as any[]).map(p=>({id:p.id,messageID:p.message_id,text:JSON.parse(p.data).text}))
}finally{old.exec('ROLLBACK');old.close()}
const coverage=original.map(part=>{
 const fullReads:any[]=[]
 for(const read of reads){
  for(const ref of read.result.causal_part_reference_index.refs??[])if(ref.part_id===part.id&&ref.message_id===part.messageID&&ref.text_preview_truncated===false&&ref.text_chars===part.text.length&&ref.text_preview===part.text)fullReads.push({toolPartID:read.toolPartID,channel:'complete reference text',chars:ref.text_chars})
  for(const message of read.result.causal_part_message_inventory??[])if(message.message_id===part.messageID)for(const fact of message.part_facts??[])if(fact.part_id===part.id&&fact.part_type==='text'&&fact.text_preview_truncated===false&&fact.text_chars===part.text.length&&fact.text_preview===part.text)fullReads.push({toolPartID:read.toolPartID,channel:'complete inventory text',chars:fact.text_chars})
  for(const field of read.result.evidence_reads??[])if(field.part_id===part.id&&field.message_id===part.messageID&&field.field==='text'&&field.offset===0&&field.next_offset===null&&field.content===part.text)fullReads.push({toolPartID:read.toolPartID,channel:'complete evidence text',chars:field.content.length})
  for(const message of read.result.messages??[])if(message.message_id===part.messageID&&message.text.includes(part.text))fullReads.push({toolPartID:read.toolPartID,channel:'complete settled message text',chars:part.text.length})
 }
 assert.equal(fullReads.length>0,true,`Actual returned full text required for ${part.id}`)
 assert.equal(canonical.parts.find((p:any)=>p.id===part.id)?.text,part.text,`Original worker text retained ${part.id}`)
 return{messageID:part.messageID,partID:part.id,chars:part.text.length,fullReads}
})
assert.equal(coverage.length,37)
const workerMessages=canonical.messages.filter((m:any)=>m.sessionID==='ses_h9aQ1aKN0qHWqIOhZfo7')
const workerIDs=new Set(workerMessages.map((m:any)=>m.id))
const sources=canonical.parts.filter((p:any)=>workerIDs.has(p.messageID)&&p.type==='source-url')
assert.equal(sources.length,36)
assert.deepEqual(tools.map((p:any)=>p.tool),['read_task_message','read_agent_message','read_agent_message','read_agent_message','read_agent_message','manage_task'])
assert.deepEqual(tools.map((p:any)=>canonical.outcomes.find((o:any)=>o.requestPartID===p.id).outcome),Array(6).fill('completed'))
assert.equal(complete.lifecycle.status,'completed')
assert.equal(complete.lifecycle.epoch,2)
assert.equal(complete.lifecycle.previousTerminal.terminalEventID,'pev_g0VXqR1Hl00rlGobCLYi')
assert.equal(qualified.epoch,2)
assert.equal(qualified.qualification,'Task')
assert.equal(provider.requests.length,10)
assert.equal(provider.requests.every((r:any)=>r.model==='gpt-6.1-sol'&&r.streaming===true&&r.response_reader.state==='settled'),true)
const rootText=canonical.parts.filter((p:any)=>newIDs.has(p.messageID)&&p.type==='text'&&newMessages.find((m:any)=>m.id===p.messageID)?.role==='assistant')
const report=rootText.find((p:any)=>p.text.includes('## R01–R36逐项核对'))
const reportItems=[...report.text.matchAll(/^[-] \*\*(R\d{2})\*\*：(.+)$/gm)].map(m=>({id:m[1],text:m[2]}))
assert.deepEqual(reportItems.map(x=>x.id),Array.from({length:36},(_,i)=>'R'+String(i+1).padStart(2,'0')))
const result={observedAtUtc:new Date().toISOString(),scope:'Actual completed epoch2, original worker Part full content compared with real read_agent_message tool returns; this data checker does not assert UI rendering',task:complete.pinned,lifecycle:complete.lifecycle,operatorMessageID:complete.selected.operatorMessageID,coverage,coverageParts:coverage.length,coverageChars:coverage.reduce((n,p)=>n+p.chars,0),sourceCount:sources.length,newToolSequence:tools.map((p:any)=>({id:p.id,tool:p.tool})),provider:{requests:provider.requests.length,model:provider.model,streaming:true,settlement:'Every provider-source reader settled; exact Task/native qualification also retained'},report:{messageID:report.messageID,partID:report.id,items:reportItems,text:report.text}}
fs.writeFileSync(evidence+'/actual-recovery-check.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({passed:true,epoch:2,coverageParts:result.coverageParts,coverageChars:result.coverageChars,sources:sources.length,providerRequests:provider.requests.length,reportItems:reportItems.length}))
