import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import { gzipSync, gunzipSync } from 'node:zlib'
import { CredentialRedactor } from '../../packages/opencorvus/script/real-provider-audit'
const root=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/source-collapse-351')
const saved=path.resolve('.tmp-product-iteration/source-collapse-351/full-evidence-originals')
const redactor=new CredentialRedactor()
redactor.collect(JSON.parse(fs.readFileSync('C:/Users/hengu/AppData/Local/opencorvus/data/auth.json','utf8')))
const rows=[]
for(const entry of fs.readdirSync(root,{recursive:true,withFileTypes:true})){
 if(!entry.isFile()||! /\.(json|log)$/.test(entry.name))continue
 const source=path.resolve(entry.parentPath,entry.name)
 const relative=path.relative(root,source)
 if(relative.startsWith('..')||path.isAbsolute(relative))throw Error('Exact evidence root required')
 const bytes=fs.readFileSync(source)
 if(bytes.length<150000)continue
 const redacted=Buffer.from(redactor.redact(bytes.toString('utf8')))
 const zipped=gzipSync(redacted)
 assert.equal(gunzipSync(zipped).equals(redacted),true)
 const archive=source+'.gz'
 const privateOriginal=path.resolve(saved,relative)
 if(!privateOriginal.startsWith(saved+path.sep)||fs.existsSync(privateOriginal))throw Error('Unique private original required')
 fs.mkdirSync(path.dirname(privateOriginal),{recursive:true})
 fs.writeFileSync(archive,zipped,{flag:'wx'})
 fs.renameSync(source,privateOriginal)
 rows.push({file:relative.replaceAll('\\','/'),archive:relative.replaceAll('\\','/')+'.gz',bytes:redacted.length,compressedBytes:zipped.length,integrity:'Entire decompressed bytes equal actual redacted original; exact original preserved privately'})
}
fs.writeFileSync(path.join(root,'checks/large-archives.json'),JSON.stringify(rows,null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({compressed:rows.length}))
