import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import { Database } from 'bun:sqlite'
import { gzipSync, gunzipSync } from 'node:zlib'
import { CredentialRedactor } from '../../packages/opencorvus/script/real-provider-audit'
const repo='D:/myhexin-local/opencorvus'
const scratch=path.join(repo,'.tmp-product-iteration/source-collapse-351')
const evidence=path.join(repo,'specs/artifacts/2026-10-05-connection-workspace-authority/source-collapse-351')
const source='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-12/child-dense-348-live-01'
const redactor=new CredentialRedactor()
redactor.collect(JSON.parse(fs.readFileSync('C:/Users/hengu/AppData/Local/opencorvus/data/auth.json','utf8')))
fs.mkdirSync(path.join(evidence,'checks'),{recursive:true})
const save=(file:string,value:unknown)=>fs.writeFileSync(path.join(evidence,file),redactor.redact(JSON.stringify(value,null,2))+'\n',{flag:'wx'})
const archives:any[]=[]
function archive(from:string,to:string){
 const raw=Buffer.from(redactor.redact(fs.readFileSync(from,'utf8')))
 const zipped=gzipSync(raw)
 assert.equal(gunzipSync(zipped).equals(raw),true)
 fs.writeFileSync(path.join(evidence,to+'.gz'),zipped,{flag:'wx'})
 archives.push({source:from,archive:to+'.gz',bytes:raw.length,compressedBytes:zipped.length,integrity:'Complete decompressed bytes equal actual credential-redacted original'})
}
for(const name of ['types.log','i18n.log','build-final.log','css.log','css-final.log','launch-before-retry.log','guard.log','complete-readiness.log','task-readiness.log','frontier.log','admit.log','copy-before.log','launch-before.log','shutdown-before.log','after-guard.log','after-complete-readiness.log','after-task-readiness.log','after-frontier.log','after-admit.log','copy-after.log','launch-after.log','shutdown-after.log'])archive(path.join(scratch,name),'checks/'+name)
function facts(run:string){
 const db=new Database(path.join(run,'runtime/data/opencorvus.db'),{readonly:true});db.exec('BEGIN')
 try{
  return {
   messages:db.query('SELECT id,session_id,data FROM message ORDER BY id').all(),
   providerIDs:db.query('SELECT id FROM provider_activity_request ORDER BY id').all(),
   sources:(db.query("SELECT p.id,p.message_id,m.session_id,p.data FROM part p JOIN message m ON m.id=p.message_id WHERE json_extract(p.data,'$.type') IN ('source-file','source-url','source-document') ORDER BY p.id").all() as any[]).map(r=>({...r,data:JSON.parse(r.data)})),
  }
 }finally{db.exec('ROLLBACK');db.close()}
}
const original=facts(source)
const runs=[]
for(const [suffix,handle,asset] of [['01',55760,'main-Byx48Ve-.js'],['02',68603,'main-qcEW9nAj.js']] as const){
 const run=`C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-12/source-collapse-351-history-${suffix}`
 for(const name of ['startup.json','launch-owner.json','evidence/native-host-ready.json','evidence/native-host-settled.json','stdout.log','stderr.log','runtime/log/dev.log'])archive(path.join(run,name),`history-${suffix}/`+path.basename(name))
 const settled=JSON.parse(fs.readFileSync(path.join(run,'evidence/native-host-settled.json'),'utf8'))
 assert.equal(settled.terminal.exitCode,0);assert.equal(settled.physicalCompletion,true);assert.equal(settled.outputDrainComplete,true);assert.equal(settled.requestCleanupComplete,true)
 const current=facts(run)
 assert.deepEqual(current.messages,original.messages)
 assert.deepEqual(current.providerIDs,original.providerIDs)
 assert.deepEqual(current.sources,original.sources)
 const requests=fs.readFileSync(path.join(run,'runtime/log/dev.log'),'utf8').split(/\r?\n/).filter(Boolean).map(line=>JSON.parse(line)).filter(x=>x.service==='server'&&x.data?.status==='completed')
 const served=requests.find(x=>x.data.path===`/ui/assets/${asset}`);assert.equal(served.data.statusCode,200)
 const birth=Number(BigInt(settled.target.processInstanceID.slice(6))/10000n-62135596800000n)
 runs.push({suffix,initialHandle:handle,launcherExitCode:0,settled,elapsedMs:Date.parse(settled.observedAtUtc)-birth,served,sourceMessages:current.messages.length,sourceProviderRequests:current.providerIDs.length,newProviderRequests:0,sources:current.sources.length,identity:'Complete Message rows, Provider request identities and Source rows equal closed original after actual UI interaction'})
}
save('checks/canonical-sources.json',original.sources)
save('checks/runtime-qualification.json',{checkedAt:new Date().toISOString(),source,runs,visualQualification:'Root manually reviewed eight actual screenshots, mouse collapse, native Space reopen, Tab focus and Return collapse, and dock return. Readonly geometry is explanatory only; no UI automation assertions.',limits:['Historical current Task, no new continuous generation sample','No new original Research Studio209-source history','Main/Side, single remaining Source and source snippets not independently visually sampled','PDF equivalent line-height token has no independent PDF screenshot','No Tauri window interaction']})
save('checks/archive-receipt.json',archives)
console.log(JSON.stringify(runs.map(r=>({run:r.suffix,exit:r.launcherExitCode,messages:r.sourceMessages,sources:r.sources,originalProviderRequests:r.sourceProviderRequests,newProviderRequests:0,elapsedMs:r.elapsedMs}))))
