import fs from 'node:fs'
import path from 'node:path'
import { gzipSync, gunzipSync } from 'node:zlib'
import assert from 'node:assert/strict'
import { CredentialRedactor } from '../../packages/opencorvus/script/real-provider-audit'
const scratch=path.resolve('.tmp-product-iteration/source-collapse-351')
const root=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/source-collapse-351')
const redactor=new CredentialRedactor()
redactor.collect(JSON.parse(fs.readFileSync('C:/Users/hengu/AppData/Local/opencorvus/data/auth.json','utf8')))
const inputs=fs.readdirSync(scratch).filter(name=>/\.(ts|ps1|json)$/.test(name))
const archives=[]
for(const name of [...inputs,'docs-final.log','finalize.log','build.log','prepare-native.log','archive-before.log','archive-after.log','piles-before.log','piles-after.log']){
 const raw=Buffer.from(redactor.redact(fs.readFileSync(path.join(scratch,name),'utf8')))
 const compressed=gzipSync(raw)
 assert.equal(gunzipSync(compressed).equals(raw),true)
 fs.writeFileSync(path.join(root,'checks',name+'.gz'),compressed,{flag:'wx'})
 archives.push({file:name+'.gz',originalBytes:raw.length,compressedBytes:compressed.length,integrity:'Full decompressed bytes equal actual credential-redacted original'})
}
fs.writeFileSync(path.join(root,'checks/helper-archives.json'),JSON.stringify(archives,null,2)+'\n',{flag:'wx'})
let textFiles=0
for(const entry of fs.readdirSync(root,{recursive:true,withFileTypes:true}).filter(x=>x.isFile())){
 if(entry.name.endsWith('.png'))continue
 const raw=fs.readFileSync(path.join(entry.parentPath,entry.name))
 const text=(entry.name.endsWith('.gz')?gunzipSync(raw):raw).toString('utf8')
 if(redactor.containsCredential(text))throw Error('Credential in final evidence')
 textFiles++
}
const result={textFiles,credentialMatches:0,compressedInputs:'Full decompression scanned',uiQualification:'Eight actual screenshots reviewed manually; no UI automation assertions'}
fs.writeFileSync(path.join(root,'checks/final-scan.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify(result))
