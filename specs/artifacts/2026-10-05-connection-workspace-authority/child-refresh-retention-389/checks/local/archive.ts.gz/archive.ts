import fs from 'node:fs'
import path from 'node:path'
import {gzipSync,gunzipSync} from 'node:zlib'
import {CredentialRedactor} from '../../packages/opencorvus/script/real-provider-audit'
const scratch=path.resolve('.tmp-product-iteration/child-refresh-retention-389')
const root=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/child-refresh-retention-389')
const redactor=new CredentialRedactor()
redactor.collect(JSON.parse(fs.readFileSync('C:/Users/hengu/AppData/Local/opencorvus/data/auth.json','utf8')))
const files:any[]=[]
function pack(source:string,relative:string){
 const raw=Buffer.from(redactor.redact(fs.readFileSync(source,'utf8'))),packed=gzipSync(raw,{level:9})
 if(!gunzipSync(packed).equals(raw))throw Error('Complete archive bytes changed')
 const target=path.resolve(root,'checks',relative+'.gz')
 if(!target.startsWith(root+path.sep))throw Error('Archive escaped exact root')
 fs.mkdirSync(path.dirname(target),{recursive:true})
 fs.writeFileSync(target,packed,{flag:'wx'})
 files.push({source,archive:path.relative(root,target).replaceAll('\\','/'),redactedBytes:raw.length,compressedBytes:packed.length})
}
for(const entry of fs.readdirSync(scratch,{recursive:true,withFileTypes:true})){
 if(!entry.isFile()||!/\.(json|jsonl|log|ts|tsx|mjs|ps1|js|patch)$/.test(entry.name))continue
 const source=path.join(entry.parentPath,entry.name)
 pack(source,'local/'+path.relative(scratch,source))
}
const mainFiles={before:'main-BpMSwrCf.js',after:'main-B-sBT3ex.js',final:'main-hq8_CedM.js'}
for(const phase of ['before','after','final'] as const){
 const run='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/child-refresh-retention-389-'+phase
 for(const name of ['stdout.log','stderr.log','startup.json','launch-owner.json','runtime/log/dev.log'])pack(path.join(run,name),phase+'/runtime/'+name)
 for(const entry of fs.readdirSync(path.join(run,'evidence'),{withFileTypes:true})){
  if(entry.isFile()&&entry.name.endsWith('.json'))pack(path.join(run,'evidence',entry.name),phase+'/runtime/evidence/'+entry.name)
 }
 for(const suffix of ['.ts','-launch.ps1','-shutdown.ps1']){
  const name='live-sol-child-refresh-389-'+phase+suffix
  pack(path.resolve('.tmp-product-iteration',name),phase+'/launcher/'+name)
 }
 pack(path.join(run,'project/来源材料/方案甲.txt'),phase+'/input/方案甲.txt')
 const bundle=run+'-bundle/bin/ui'
 pack(path.join(bundle,'index.html'),phase+'/static-ui/index.html')
 pack(path.join(bundle,'assets',mainFiles[phase]),phase+'/static-ui/assets/'+mainFiles[phase])
}
pack(path.resolve('.tmp-product-iteration/history-render-identity-388/push.log'),'previous-388/push.log')
fs.writeFileSync(path.join(root,'checks/archive-receipt.json'),JSON.stringify({files,integrity:'Every full redacted input equals its full decompressed archive; originals retained',qualification:'Archive completeness is separate from manual UI review. Final first model request remains failed; actor mismatch remains unresolved.'},null,2)+'\n',{flag:'wx'})
let scanned=0
for(const entry of fs.readdirSync(root,{recursive:true,withFileTypes:true})){
 if(!entry.isFile()||entry.name.endsWith('.png'))continue
 const bytes=fs.readFileSync(path.join(entry.parentPath,entry.name))
 const text=(entry.name.endsWith('.gz')?gunzipSync(bytes):bytes).toString('utf8')
 if(redactor.containsCredential(text))throw Error('Credential in archived evidence')
 scanned++
}
fs.writeFileSync(path.join(root,'checks/credential-scan.json'),JSON.stringify({scanned,credentialMatches:0,scope:'Full text and complete decompressed archives; credential files excluded'},null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({archives:files.length,scanned,credentialMatches:0}))
