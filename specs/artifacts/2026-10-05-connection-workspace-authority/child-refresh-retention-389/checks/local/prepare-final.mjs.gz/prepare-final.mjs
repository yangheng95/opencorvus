import fs from 'node:fs'
import path from 'node:path'
const root=path.resolve('.tmp-product-iteration'),scratch=path.join(root,'child-refresh-retention-389')
for(const suffix of ['.ts','-launch.ps1','-shutdown.ps1']){
 const previous=fs.readFileSync(path.join(root,'live-sol-child-refresh-389-after'+suffix),'utf8')
 const next=previous.replaceAll('child-refresh-retention-389-after','child-refresh-retention-389-final').replaceAll('live-sol-child-refresh-389-after','live-sol-child-refresh-389-final')
 fs.writeFileSync(path.join(root,'live-sol-child-refresh-389-final'+suffix),next,{flag:'wx'})
}
fs.mkdirSync(path.join(scratch,'final'),{recursive:true})
fs.mkdirSync(path.join(root,'child-refresh-retention-389-final-native-observer'),{recursive:true})
const bin='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/child-refresh-retention-389-final-bundle/bin'
fs.mkdirSync(bin,{recursive:true})
fs.copyFileSync('C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/history-render-identity-388-before-bundle/bin/bun.exe',path.join(bin,'bun.exe'),fs.constants.COPYFILE_EXCL)
fs.copyFileSync(path.join(scratch,'stream-proxy.mjs'),path.join(scratch,'stream-proxy-before-after-used.mjs'),fs.constants.COPYFILE_EXCL)
fs.writeFileSync(path.join(scratch,'stream-proxy.mjs'),fs.readFileSync(path.join(scratch,'stream-proxy.mjs'),'utf8').replace('[18414,18416]','[18414,18416,18418]'))
fs.writeFileSync(path.join(scratch,'read-facts.ts'),fs.readFileSync(path.join(scratch,'read-facts.ts'),'utf8').replace("['before','after']","['before','after','final']"))
console.log('Prepared separate final scope; no prior Native lifetime reopened')
