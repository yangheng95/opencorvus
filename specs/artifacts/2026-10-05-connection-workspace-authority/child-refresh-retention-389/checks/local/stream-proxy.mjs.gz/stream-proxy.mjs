import http from 'node:http'
import fs from 'node:fs'
import path from 'node:path'
const [portText,upstreamText,folder]=process.argv.slice(2)
const port=Number(portText),upstream=Number(upstreamText)
if(![18414,18416,18418].includes(port)||upstream!==port-1||!path.isAbsolute(folder))throw Error('Exact owned proxy inputs required')
fs.mkdirSync(folder,{recursive:true})
const log=fs.createWriteStream(path.join(folder,'proxy-events.jsonl'),{flags:'wx'})
const record=(data)=>log.write(JSON.stringify({time:new Date().toISOString(),pid:process.pid,...data})+'\n')
const connections=new Map(),sockets=new Set()
const observedTranscripts=new Map()
let blockedSessionID=''
let sequence=0,stopping=false,deadline
const close=async(reason)=>{
 if(stopping)return
 stopping=true;clearTimeout(deadline)
 record({kind:'stopping',reason,activeStreams:connections.size})
 for(const entry of connections.values()){entry.upstream.destroy();entry.response.destroy()}
 const ownedSockets=[...sockets]
 const socketsClosed=Promise.all(ownedSockets.map(socket=>new Promise(resolve=>socket.once('close',resolve))))
 const closed=new Promise(resolve=>server.close(resolve))
 for(const socket of ownedSockets)socket.destroy()
 await Promise.all([closed,socketsClosed])
 record({kind:'stopped',reason,activeStreams:connections.size,sockets:sockets.size})
 log.end()
}
const server=http.createServer(async(req,res)=>{
 const url=new URL(req.url,'http://localhost:'+port)
 if(url.pathname.startsWith('/__owned-diagnostic__/')){
  if(req.method!=='POST'||req.headers.origin){res.writeHead(403);res.end();return}
  const chunks=[];let length=0
  for await(const chunk of req){length+=chunk.length;if(length>2048){res.writeHead(413);res.end();return}chunks.push(chunk)}
  let body
  try{body=JSON.parse(Buffer.concat(chunks).toString()||'{}')}catch{res.writeHead(400);res.end();return}
  if(url.pathname==='/__owned-diagnostic__/transcript-interruption'){
   if(typeof body.blocked!=='boolean'||!observedTranscripts.has(body.sessionID)){
    res.writeHead(409,{'Content-Type':'application/json'});res.end(JSON.stringify({observed:[...observedTranscripts.entries()]}));return
   }
   if(blockedSessionID&&blockedSessionID!==body.sessionID){res.writeHead(409);res.end();return}
   blockedSessionID=body.blocked?body.sessionID:''
   record({kind:'explicit-transcript-interruption',sessionID:body.sessionID,blocked:body.blocked,observed:observedTranscripts.get(body.sessionID)})
   res.writeHead(200,{'Content-Type':'application/json'});res.end(JSON.stringify({sessionID:body.sessionID,blocked:body.blocked}));return
  }
  if(url.pathname==='/__owned-diagnostic__/stop'){
   res.writeHead(200,{'Content-Type':'application/json'});res.end(JSON.stringify({stopping:true,pid:process.pid}));res.on('finish',()=>void close('operator-stop'));return
  }
  res.writeHead(404);res.end();return
 }
 const headers={...req.headers,host:'localhost:'+upstream}
 delete headers.connection
 const id=++sequence
 const transcriptSessionID=/^\/session\/([^/]+)\/conversation$/.exec(url.pathname)?.[1]
 if(req.method==='GET'&&transcriptSessionID&&transcriptSessionID===blockedSessionID){
  record({kind:'physical-transcript-disconnect',id,sessionID:transcriptSessionID,path:req.url})
  req.socket.destroy();return
 }
 const outgoing=http.request({hostname:'127.0.0.1',port:upstream,path:req.url,method:req.method,headers},incoming=>{
  const responseHeaders={...incoming.headers};delete responseHeaders.connection
  res.writeHead(incoming.statusCode??502,responseHeaders)
  if(transcriptSessionID){
   record({kind:'transcript-response',id,sessionID:transcriptSessionID,path:req.url,status:incoming.statusCode})
   if(incoming.statusCode===200)observedTranscripts.set(transcriptSessionID,{id,path:req.url,status:incoming.statusCode})
  }
  const sessionID=/^\/session\/([^/]+)\/events$/.exec(url.pathname)?.[1]
  if(sessionID&&incoming.statusCode===200){
   connections.set(id,{id,sessionID,upstream:outgoing,response:res})
   record({kind:'stream-established',id,sessionID,path:url.pathname,status:incoming.statusCode})
  }
  incoming.on('error',error=>{record({kind:'upstream-body-error',id,name:error.name,message:error.message});res.destroy()})
  incoming.pipe(res)
 })
 outgoing.on('error',error=>{record({kind:'upstream-error',id,path:url.pathname,name:error.name,message:error.message});res.destroy()})
 res.on('close',()=>{if(connections.delete(id))record({kind:'stream-closed',id});outgoing.destroy()})
 req.on('aborted',()=>outgoing.destroy())
 req.pipe(outgoing)
})
server.on('connection',socket=>{sockets.add(socket);socket.on('close',()=>sockets.delete(socket))})
await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,'127.0.0.1',resolve)})
record({kind:'ready',port,upstream,deadlineMilliseconds:600000,mode:'Unmodified real HTTP bodies; explicit physical interruption targets an already observed Session transcript GET'})
fs.writeFileSync(path.join(folder,'proxy-ready.json'),JSON.stringify({pid:process.pid,port,upstream,readyAt:new Date().toISOString()},null,2)+'\n',{flag:'wx'})
deadline=setTimeout(()=>void close('resource-deadline'),600000)
console.log(JSON.stringify({ready:true,pid:process.pid,port,upstream}))
