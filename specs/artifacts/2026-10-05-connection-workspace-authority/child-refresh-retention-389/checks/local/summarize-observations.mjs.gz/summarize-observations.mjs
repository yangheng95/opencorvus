import fs from 'node:fs'
const scratch='.tmp-product-iteration/child-refresh-retention-389'
const root='specs/artifacts/2026-10-05-connection-workspace-authority/child-refresh-retention-389'
const read=file=>JSON.parse(fs.readFileSync(`${scratch}/${file}`,'utf8'))
const childRows=file=>read(file).filter(e=>e.message.startsWith('CHILD389 ')).map(e=>({time:e.timestamp,...JSON.parse(e.message.slice(9))}))
const activity=read('after-logs-baseline.json').filter(e=>e.message.startsWith('AG389 ')).map(e=>({time:e.timestamp,...JSON.parse(e.message.slice(6))}))
const firstMissing=activity.find(e=>e.kind==='missing')
const childID=firstMissing?.extra.sessionID
const messageID=firstMissing?.extra.messageID
const result={boundary:'Passive diagnostic observations for manual review, not UI assertions or a score.',lifetimes:{before:childRows('before-logs-recovered.json'),afterBeforeReload:childRows('after-logs-before-reload.json')},identity:{firstMissing,childMessageEvents:activity.filter(e=>e.kind==='MessageUpdated'&&e.event?.messageID===messageID),childLifecycleEvents:activity.filter(e=>e.kind==='SessionStatus'&&e.event?.sessionID===childID),hydrationEvents:activity.filter(e=>e.kind==='hydrate'||e.kind==='merge'),missingReports:activity.filter(e=>e.kind==='missing').length}}
fs.writeFileSync(`${root}/observations.json`,JSON.stringify(result,null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({lifetimes:result.lifetimes,missingReports:result.identity.missingReports,childID,messageID}))
