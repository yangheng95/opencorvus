import fs from 'node:fs'
import path from 'node:path'
const root=path.resolve('.tmp-product-iteration'),scratch=path.join(root,'child-refresh-retention-389')
for(const phase of ['before','after']){
 for(const suffix of ['.ts','-launch.ps1','-shutdown.ps1']){
  const old=fs.readFileSync(path.join(root,'live-sol-history-388-'+phase+suffix),'utf8')
  fs.writeFileSync(path.join(root,'live-sol-child-refresh-389-'+phase+suffix),old.replaceAll('history-render-identity-388','child-refresh-retention-389').replaceAll('live-sol-history-388','live-sol-child-refresh-389'),{flag:'wx'})
 }
 fs.mkdirSync(path.join(scratch,phase),{recursive:true})
 fs.mkdirSync(path.join(root,'child-refresh-retention-389-'+phase+'-native-observer'),{recursive:true})
 const bin='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/child-refresh-retention-389-'+phase+'-bundle/bin'
 fs.mkdirSync(bin,{recursive:true})
 fs.copyFileSync('C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/history-render-identity-388-before-bundle/bin/bun.exe',path.join(bin,'bun.exe'),fs.constants.COPYFILE_EXCL)
}
fs.copyFileSync(path.join(root,'history-render-identity-388/builtin.json'),path.join(scratch,'builtin.json'),fs.constants.COPYFILE_EXCL)
let build=fs.readFileSync(path.join(root,'history-render-identity-388/build-diagnostic.mjs'),'utf8').replaceAll('388','389').replaceAll('history-render-identity','child-refresh-retention')
const start=build.indexOf("  if(file.endsWith('/components/SideChatPanel.tsx')){")
const end=build.indexOf("  if(file.endsWith('/components/text-part-model.ts'))",start)
if(start<0||end<0)throw Error('Inspect existing diagnostic plugin')
const replacement=[
 "  if(file.endsWith('/components/SubagentConversationPanel.tsx')){",
 "   source=replaceOnce(source,'function SubagentConversationScroll(props:', 'let childTraceSequence389 = 0\\nfunction SubagentConversationScroll(props:')",
 "   const anchor='  let scrollElement: HTMLDivElement | undefined'",
 '   return replaceOnce(source,anchor,`${anchor}\\n  const childOwner389 = ++childTraceSequence389\\n  console.debug("CHILD389", JSON.stringify({kind:"create",owner:childOwner389,sessionID:props.conversation().sessionID,at:performance.now()}))\\n  onCleanup(() => console.debug("CHILD389", JSON.stringify({kind:"dispose",owner:childOwner389,at:performance.now()})))`)',
 "  }",
 '',
].join('\n')
build=build.slice(0,start)+replacement+build.slice(end)
fs.writeFileSync(path.join(scratch,'build-diagnostic.mjs'),build,{flag:'wx'})
console.log('Prepared two independent scopes; neither launched; product source unchanged')
