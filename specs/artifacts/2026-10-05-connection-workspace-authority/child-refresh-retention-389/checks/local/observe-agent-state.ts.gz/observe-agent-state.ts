function traceConversationAgent389(kind: string, sourceKey: string, event?: any, extra?: unknown) {
  const props = event?.properties ?? event?.payload ?? {}
  const info = props.info ?? {}
  const part = props.part ?? {}
  console.debug("AG389", JSON.stringify({
    kind, sourceKey, at: performance.now(),
    event: event ? {
      type: event.type, emittedAt: event.emittedAt,
      sessionID: info.sessionID ?? part.sessionID ?? props.sessionID,
      messageID: info.id ?? part.messageID ?? props.messageID,
      partID: part.id ?? props.partID,
      channel: info.channel ?? props.channel, role: info.role ?? props.role,
      agentID: info.agentID ?? props.agentID, sessionAgentID: info.sessionAgentID ?? props.sessionAgentID,
      inputMessageID: info.parentID ?? props.parentMessageID ?? props.inputMessageID,
    } : undefined,
    storeSource: conversationAgentStore.taskID,
    records: conversationAgentStore.records.map(record => ({
      id: record.id, inputMessageID: record.inputMessageID, sessionID: record.sessionID,
      messageIDs: [...(record.messageIDs ?? [])], status: record.status,
      targetMessageID: record.targetMessageID, lastObservedAt: record.lastObservedAt,
    })),
    extra,
  }))
}
