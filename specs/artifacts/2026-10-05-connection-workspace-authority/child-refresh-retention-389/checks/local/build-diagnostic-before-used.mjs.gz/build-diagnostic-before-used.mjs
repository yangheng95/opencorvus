import fs from 'node:fs'
import path from 'node:path'
import {build,loadConfigFromFile} from '../../packages/overlay/node_modules/vite/dist/node/index.js'
const workspace=process.cwd(),phase=process.argv[2]
if(!['before','after'].includes(phase))throw Error('Exact private phase required')
function replaceOnce(source,anchor,next){
 if(source.split(anchor).length!==2)throw Error('Inspect changed diagnostic anchor')
 return source.replace(anchor,next)
}
process.chdir(path.join(workspace,'packages/overlay'))
const loaded=await loadConfigFromFile({command:'build',mode:'production'},path.join(workspace,'packages/overlay/vite.config.ts'))
if(!loaded)throw Error('Existing Vite configuration required')
await build({...loaded.config,configFile:false,plugins:[{
 name:'owned-manual-markdown-lifetimes',enforce:'pre',
 transform(source,id){
  const file=id.replaceAll('\\','/')
  if(file.endsWith('/components/SubagentConversationPanel.tsx')){
   source=replaceOnce(source,'function SubagentConversationScroll(props:', 'let childTraceSequence389 = 0\nfunction SubagentConversationScroll(props:')
   const anchor='  let scrollElement: HTMLDivElement | undefined'
   return replaceOnce(source,anchor,`${anchor}\n  const childOwner389 = ++childTraceSequence389\n  console.debug("CHILD389", JSON.stringify({kind:"create",owner:childOwner389,sessionID:props.conversation().sessionID,at:performance.now()}))\n  onCleanup(() => console.debug("CHILD389", JSON.stringify({kind:"dispose",owner:childOwner389,at:performance.now()})))`)
  }
  if(file.endsWith('/components/text-part-model.ts')){
   source=replaceOnce(source,'export function createStreamingTextPartModel','let textTraceSequence389 = 0\nexport function createStreamingTextPartModel')
   const anchor='  const [error, setError] = createSignal("")'
   return replaceOnce(source,anchor,`${anchor}\n  const traceOwner389 = ++textTraceSequence389\n  console.debug("MD389", JSON.stringify({kind:"create",owner:traceOwner389,at:performance.now()}))\n  createEffect(() => console.debug("MD389", JSON.stringify({kind:"state",owner:traceOwner389,textLength:props.text.length,streaming:props.streaming===true,pending:pending(),blocks:frozenHtml().length,at:performance.now()})))\n  onCleanup(() => console.debug("MD389", JSON.stringify({kind:"dispose",owner:traceOwner389,at:performance.now()})))`)
  }
 },
},...(loaded.config.plugins??[])],build:{...loaded.config.build,minify:false,outDir:`C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/child-refresh-retention-389-${phase}-bundle/bin/ui`}})
