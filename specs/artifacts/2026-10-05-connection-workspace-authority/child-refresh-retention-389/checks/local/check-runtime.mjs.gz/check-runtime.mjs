import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
const scratch=path.resolve('.tmp-product-iteration/child-refresh-retention-389')
const root=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/child-refresh-retention-389')
const read=p=>JSON.parse(fs.readFileSync(p,'utf8').replace(/^\uFEFF/,''))
const phases=[]
for(const phase of ['before','after','final']){
 const run='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/child-refresh-retention-389-'+phase
 const facts=read(path.join(scratch,phase+'-final.json'))
 const initial=read(path.join(scratch,phase+'-initial.json'))
 let originalFailure
 if(phase==='final'){
  const failed=read(path.join(scratch,'final-failure.json')).messages.find(m=>m.id==='msg_g0VXw5bQC00gEr0LP7Tc')
  assert.equal(failed.finish,'error');assert.equal(failed.error.name,'UnknownError')
  assert.deepEqual(facts.messages.find(m=>m.id===failed.id),failed)
  originalFailure={messageID:failed.id,error:failed.error,finish:failed.finish,boundary:'Original model request failed; the later explicit UI user continuation has a separate outcome. HTTP 200 / EOF is only transport completion.'}
 }
 const children=facts.sessions.filter(s=>JSON.parse(s.metadata).delegation?.kind==='session-local')
 assert.equal(children.length,1)
 const child=children[0],meta=JSON.parse(child.metadata).delegation
 assert.equal(meta.parentAgent,'work')
 const childMessages=facts.messages.filter(m=>m.sessionID===child.id)
 const last=childMessages.filter(m=>m.role==='assistant').at(-1)
 assert.equal(last.agent,'work');assert.equal(last.finish,'stop');assert.equal(typeof last.time.completed,'number')
 const sources=facts.parts.filter(p=>p.type==='source-file')
 assert.equal(sources.length,1)
 const source=sources[0],tool=facts.tools.find(t=>t.id===source.toolPartID)
 assert.equal(tool.tool,'read');assert.equal(tool.messageID,source.messageID)
 assert.equal(childMessages.some(m=>m.id===tool.messageID),true)
 assert.deepEqual(tool.input,{filePath:'来源材料/方案甲.txt',offset:2,limit:2})
 assert.deepEqual(source.range,{startLine:2,endLine:3})
 assert.equal(source.path.replaceAll('\\','/'),run+'/project/来源材料/方案甲.txt')
 assert.deepEqual(initial.parts.find(p=>p.id===source.id),source)
 const outcome=facts.outcomes.find(o=>o.requestPartID===tool.id)
 assert.equal(outcome.outcome,'completed')
 assert.equal(outcome.metadata.preview,fs.readFileSync(source.path,'utf8').split('\n').slice(1,3).join('\n'))
 const delegate=facts.tools.find(t=>t.tool==='delegate_agent')
 assert.equal(facts.tools.length,2);assert.equal(meta.parentMessageID,delegate.messageID)
 assert.equal(facts.messages.find(m=>m.id===delegate.messageID).sessionID,child.parent_id)
 assert.equal(facts.outcomes.find(o=>o.requestPartID===delegate.id).outcome,'completed')
 const owner=read(path.join(run,'launch-owner.json')),native=read(path.join(run,'evidence/native-host-settled.json'))
 const preflight=read(path.join(run,'evidence/preflight-ready.json')).preflight
 assert.equal(preflight.credential,'usable');assert.equal(preflight.catalog,'projected')
 assert.equal(preflight.actualModel,'gpt-6.1-sol');assert.equal(preflight.streaming,true)
 const prefix=path.join(scratch,phase,'child-refresh-retention-389-'+phase)
 const provider=read(prefix+'-final-provider-audit.json'),cleanup=read(prefix+'-physical-terminal-and-pair-cleanup.json'),qualified=read(prefix+'-qualified-surface-completion.json')
 assert.equal(provider.pid,owner.nativeTarget.pid);assert.equal(provider.maxRequests,20)
 assert.equal(provider.requests.length>0&&provider.requests.length<=20,true)
 for(const request of provider.requests){
  assert.equal(request.model,'gpt-6.1-sol');assert.equal(request.streaming,true)
  assert.equal(request.status,200);assert.equal(request.response_reader.terminal.kind,'eof')
 }
 assert.equal(native.occurrence,owner.occurrence);assert.equal(cleanup.occurrence,owner.occurrence)
 assert.equal(native.terminal.reason,'exited');assert.equal(native.terminal.exitCode,0)
 for(const key of ['physicalCompletion','outputDrainComplete','requestCleanupComplete'])assert.equal(native[key],true)
 assert.equal(cleanup.pairedCleanupComplete,true)
 assert.deepEqual(cleanup.copiedPair.map(p=>p.outcome),['removed','removed'])
 assert.equal(qualified.qualification,'NativeService');assert.equal(qualified.providerEOFRequests,provider.requests.length)
 const events=fs.readFileSync(path.join(scratch,phase,'proxy-events.jsonl'),'utf8').trim().split('\n').map(JSON.parse)
 const cuts=events.filter(e=>e.kind==='physical-transcript-disconnect')
 assert.equal(cuts.length>0,true)
 for(const cut of cuts)assert.equal(cut.sessionID,child.id)
 const recovery=events.find(e=>e.kind==='transcript-response'&&e.sessionID===child.id&&Date.parse(e.time)>Date.parse(cuts.at(-1).time))
 assert.equal(recovery.status,200)
 assert.equal(events.at(-1).kind,'stopped');assert.equal(events.at(-1).sockets,0)
 phases.push({phase,originalFailure,childSessionID:child.id,parentSessionID:child.parent_id,childMessages:childMessages.map(m=>m.id),source:{id:source.id,messageID:source.messageID,toolPartID:source.toolPartID,path:source.path,range:source.range},preflight,requests:provider.requests.length,providerTransport:'all gpt-6.1-sol streaming / HTTP 200 / EOF; separate Message outcomes retained',native:{terminal:native.terminal,durationMilliseconds:Date.parse(native.observedAtUtc)-owner.targetBirthAtMs,physicalCompletion:true,pairedCleanupComplete:true},transport:{cuts,recovery,terminal:events.at(-1)},qualification:qualified.qualification})
}
const result={phases,boundary:'Canonical backend, actual Provider and physical transport/native facts only; no UI automatic assertions. Root manually reviewed actual screenshots.',remaining:['The separately observed session-local lifecycle actor mismatch still requires a shared identity repair; NativeService qualification does not certify frontend streaming correctness.','Original Research Studio data and all Task/Mission failure scenarios are not covered by these Session-local runs.']}
fs.writeFileSync(path.join(root,'runtime-review.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify(result))
