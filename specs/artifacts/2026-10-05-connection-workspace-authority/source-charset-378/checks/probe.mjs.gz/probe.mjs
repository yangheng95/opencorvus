import fs from 'node:fs';
const results=[];
for(const year of ['2011','2024']) {
 const url=`https://www.stats.gov.cn/sj/ndsj/${year}/indexch.htm`;
 try {const response=await fetch(url,{signal:AbortSignal.timeout(25000)});const bytes=new Uint8Array(await response.arrayBuffer());fs.writeFileSync(`.tmp-product-iteration/source-charset-378/stats-${year}.bin`,bytes);const utf8=new TextDecoder().decode(bytes),gbk=new TextDecoder('gb18030').decode(bytes);results.push({url,finalUrl:response.url,status:response.status,headers:Object.fromEntries(response.headers),length:bytes.length,prefixAscii:Buffer.from(bytes).subarray(0,400).toString('latin1'),utf8Title:utf8.match(/<title>([\s\S]*?)<\/title>/i)?.[1],gbkTitle:gbk.match(/<title>([\s\S]*?)<\/title>/i)?.[1]});}catch(error){results.push({url,error:String(error)})}
}
fs.writeFileSync('.tmp-product-iteration/source-charset-378/public-probe.json',JSON.stringify(results,null,2)+'\n');console.log(JSON.stringify(results));
