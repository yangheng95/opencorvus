import fs from 'node:fs'; import path from 'node:path'; import assert from 'node:assert/strict';import{gzipSync,gunzipSync}from'node:zlib';
const root=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/source-charset-378'),target=path.resolve('.tmp-product-iteration/source-charset-378/full-originals/public-inputs'),files=[];
fs.mkdirSync(target,{recursive:true});
for(const year of ['2011','2024']){const src=path.resolve(root,'public-inputs',`stats-${year}.bin`),dst=path.resolve(target,`stats-${year}.bin`);assert.ok(src.startsWith(root+path.sep)&&dst.startsWith(target+path.sep));const raw=fs.readFileSync(src),zip=gzipSync(raw,{level:9});assert.deepEqual(gunzipSync(zip),raw);fs.writeFileSync(src+'.gz',zip,{flag:'wx'});fs.renameSync(src,dst);files.push({archive:`stats-${year}.bin.gz`,bytes:raw.length,compressedBytes:zip.length,integrity:'Complete gzip decompression equals original HTTP bytes; original whitespace and line endings retained'});}
fs.writeFileSync(root+'/public-inputs/raw-byte-archive.json',JSON.stringify({files},null,2)+'\n',{flag:'wx'});
const doc=root+'/README.md';fs.writeFileSync(doc,fs.readFileSync(doc,'utf8').replaceAll('public-inputs/stats-2011.bin)','public-inputs/stats-2011.bin.gz)').replaceAll('public-inputs/stats-2024.bin)','public-inputs/stats-2024.bin.gz)'));
console.log(JSON.stringify(files));
