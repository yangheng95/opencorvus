import fs from 'node:fs';
import sniffEncoding from '../../packages/opencorvus/node_modules/html-encoding-sniffer';
import {legacyHookDecode} from '../../packages/opencorvus/node_modules/@exodus/bytes/encoding.js';
const bytes=fs.readFileSync(process.argv[2]); const encoding=sniffEncoding(bytes,{defaultEncoding:'UTF-8'});
console.log(JSON.stringify({encoding,content:legacyHookDecode(bytes,encoding.toLowerCase())}));
