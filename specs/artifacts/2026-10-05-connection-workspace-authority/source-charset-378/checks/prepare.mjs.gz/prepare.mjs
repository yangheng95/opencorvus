import fs from 'node:fs';
for(const scope of ['before','after']){
 const p='.tmp-product-iteration/source-charset-378/'+scope;
 fs.writeFileSync(p+'/builtin.json',JSON.stringify({kind:'builtin',id:'base',namespace:'builtin'}));
 for(const f of ['archive-live.ts','archive-piles.ps1']){
  let s=fs.readFileSync('.tmp-product-iteration/locale-bootstrap-377/after/'+f,'utf8').replaceAll('locale-bootstrap-377-after','source-charset-378-'+scope).replaceAll('locale-bootstrap-377/after','source-charset-378/'+scope).replaceAll('locale-bootstrap-377','source-charset-378');
  fs.writeFileSync(p+'/'+f,s,{flag:'wx'});
 }
 fs.copyFileSync('.tmp-product-iteration/live-sol-locale-377-after.ps1',p+'/launcher.ps1',fs.constants.COPYFILE_EXCL);
}
