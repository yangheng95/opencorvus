import fs from 'node:fs';import assert from 'node:assert/strict';
const p='.tmp-product-iteration/source-charset-378',e='specs/artifacts/2026-10-05-connection-workspace-authority/source-charset-378';
const decoded=JSON.parse(fs.readFileSync(p+'/bundled-decoded.json','utf8'));assert.equal(decoded.encoding,'GBK');assert.equal(decoded.content,new TextDecoder('gb18030').decode(fs.readFileSync(p+'/stats-2024.bin')));
fs.mkdirSync(e+'/public-inputs',{recursive:true});for(const f of ['stats-2011.bin','stats-2024.bin','public-probe.json'])fs.copyFileSync(p+'/'+f,e+'/public-inputs/'+f,fs.constants.COPYFILE_EXCL);
for(const scope of ['before','after']){
 const c=JSON.parse(fs.readFileSync(e+'/'+scope+'/canonical-current-conversations.json','utf8'));
 console.log(JSON.stringify({scope,sources:c.parts.filter(x=>x.type==='source-url').map(x=>({sourceId:x.sourceId,url:x.url,title:x.title,provider:x.provider})),tools:c.tools.map(x=>({id:x.id,...JSON.parse(x.data)})),outcomes:c.outcomes.map(x=>({requestPartID:x.requestPartID,outcome:x.outcome,outputChars:x.outputChars}))}));
}
console.log(JSON.stringify({bundledDecoding:'GBK',completeDecodedChars:decoded.content.length,equalToIndependentDecoder:true}));
