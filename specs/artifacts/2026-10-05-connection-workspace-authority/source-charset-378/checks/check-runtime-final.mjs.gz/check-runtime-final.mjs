import {gunzipSync} from 'node:zlib';import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';
const root=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/source-charset-378'),scopes=[];
const normalize=(s)=>s.replace(/\r\n?/g,'\n').replace(/[ \t]+\n/g,'\n').replace(/\n{4,}/g,'\n\n\n').trim();
for(const scope of ['before','after']){
 const dir=path.join(root,scope),prefix='source-charset-378-'+scope,read=(n)=>JSON.parse(fs.existsSync(path.join(dir,n))?fs.readFileSync(path.join(dir,n),'utf8'):gunzipSync(fs.readFileSync(path.join(dir,n)+'.gz')).toString('utf8'));
 const canonical=read('canonical-current-conversations.json'),sources=canonical.parts.filter(p=>p.type==='source-url');assert.equal(sources.length,2);assert.equal(canonical.tools.length,2);assert.equal(canonical.outcomes.length,2);
 const sourcesByUrl=new Map(sources.map(s=>[s.url,s]));
 for(const year of ['2011','2024']){
  const url=`https://www.stats.gov.cn/sj/ndsj/${year}/indexch.htm`,source=sourcesByUrl.get(url);assert.ok(source);assert.equal(source.provider,'opencorvus-webfetch');
  const title=scope==='after'?(year==='2011'?'中国统计年鉴-2011':'中国统计年鉴2024'):(year==='2011'?'�й�ͳ�����-2011':'�й�ͳ�����2024');assert.equal(source.title,title);
  const tool=canonical.tools.find(t=>JSON.parse(t.data).input?.url===url);assert.ok(tool);const request=JSON.parse(tool.data);assert.equal(request.tool,'webfetch');assert.deepEqual(request.input,{url,format:'html'});
  const outcome=canonical.outcomes.find(o=>o.requestPartID===tool.id);assert.ok(outcome);assert.equal(outcome.outcome,'completed');
  const bytes=gunzipSync(fs.readFileSync(path.join(root,'public-inputs',`stats-${year}.bin.gz`))),decoded=new TextDecoder(scope==='after'?'gb18030':'utf-8').decode(bytes);assert.equal(outcome.output,normalize(decoded));assert.equal(outcome.metadata.originalBytes,Buffer.byteLength(outcome.output));assert.equal(outcome.metadata.shownBytes,Buffer.byteLength(outcome.output));
 }
 const completed=canonical.messages.filter(m=>m.role==='assistant'&&m.finish==='stop');assert.equal(completed.length,2);for(const m of completed)assert.equal(typeof m.time.completed,'number');
 const preflight=read(prefix+'-preflight-ready.json').preflight;assert.deepEqual({credential:preflight.credential,catalog:preflight.catalog,model:preflight.actualModel,stream:preflight.streaming},{credential:'usable',catalog:'projected',model:'gpt-6.1-sol',stream:true});
 const provider=read(prefix+'-final-provider-audit.json');assert.equal(provider.exhausted,false);assert.ok(provider.requests.length>0&&provider.requests.length<=12);for(const r of provider.requests)assert.deepEqual({model:r.model,stream:r.streaming,status:r.status,reader:r.response_reader.state,terminal:r.response_reader.terminal.kind},{model:'gpt-6.1-sol',stream:true,status:200,reader:'settled',terminal:'eof'});
 const settled=read(prefix+'-native-host-settled.json');for(const key of ['physicalCompletion','outputDrainComplete','requestCleanupComplete'])assert.equal(settled[key],true);assert.deepEqual({reason:settled.terminal.reason,exit:settled.terminal.exitCode},{reason:'exited',exit:0});const qualified=read(prefix+'-qualified-surface-completion.json');assert.equal(qualified.qualification,'NativeService');assert.equal(qualified.physicalCompletion,true);
 const birth=Number(BigInt(settled.target.processInstanceID.slice(6))/10000n-62135596800000n),elapsedMs=Date.parse(settled.observedAtUtc)-birth;assert.ok(elapsedMs<600000);
 scopes.push({scope,sources,requests:provider.requests.length,elapsedMs,settled,qualified,completeOutputs:canonical.outcomes});
}
const bundled=JSON.parse(fs.readFileSync('.tmp-product-iteration/source-charset-378/bundled-decoded.json','utf8'));assert.equal(bundled.encoding,'GBK');assert.equal(bundled.content,new TextDecoder('gb18030').decode(gunzipSync(fs.readFileSync(root+'/public-inputs/stats-2024.bin.gz'))));
fs.mkdirSync(root+'/checks',{recursive:true});fs.writeFileSync(root+'/checks/runtime-qualification-final.json',JSON.stringify({scopes,bundledEncoding:bundled.encoding,boundary:'Canonical Source titles, exact real ToolRequest/ToolOutcome, complete public response decoded independently with existing output whitespace contract, and Provider/Native closure. Screenshots and navigation reviewed manually; no UI assertions. Library bundle check is not a packaged-product build.'},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(scopes.map(({scope,requests,elapsedMs})=>({scope,requests,elapsedMs}))));
