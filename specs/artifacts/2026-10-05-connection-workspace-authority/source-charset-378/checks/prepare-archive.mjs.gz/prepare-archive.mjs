import fs from 'node:fs';
let s=fs.readFileSync('.tmp-product-iteration/locale-bootstrap-377/archive.ts','utf8').replaceAll('locale-bootstrap-377','source-charset-378').replace("['after','failure']","['before','after']").replace("['','after','failure']","['','before','after']");
fs.writeFileSync('.tmp-product-iteration/source-charset-378/archive.ts',s,{flag:'wx'});
