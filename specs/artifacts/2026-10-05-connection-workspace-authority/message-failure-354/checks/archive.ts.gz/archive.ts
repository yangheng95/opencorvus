import fs from 'node:fs'
import path from 'node:path'
import {gzipSync,gunzipSync} from 'node:zlib'
import {CredentialRedactor} from '../../packages/opencorvus/script/real-provider-audit'
const root=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/message-failure-354')
const scratch=path.resolve('.tmp-product-iteration/message-failure-354')
const originals=path.join(scratch,'full-originals')
const redactor=new CredentialRedactor()
redactor.collect(JSON.parse(fs.readFileSync('C:/Users/hengu/AppData/Local/opencorvus/data/auth.json','utf8')))
fs.mkdirSync(path.join(root,'checks'),{recursive:true})
const files:any[]=[]
function pack(source:string,relative:string){
 const raw=Buffer.from(redactor.redact(fs.readFileSync(source,'utf8'))),zip=gzipSync(raw,{level:9})
 if(!gunzipSync(zip).equals(raw))throw Error('Full archive roundtrip bytes differ')
 fs.writeFileSync(path.join(root,relative),zip,{flag:'wx'})
 files.push({source,archive:relative,originalBytes:raw.length,compressedBytes:zip.length,integrity:'Full decompressed bytes equal actual credential-redacted original'})
}
for(const entry of fs.readdirSync(root,{recursive:true,withFileTypes:true})){
 if(!entry.isFile()||! /\.(json|log)$/.test(entry.name))continue
 const source=path.resolve(entry.parentPath,entry.name),relative=path.relative(root,source)
 if(entry.name.endsWith('.json')&&fs.statSync(source).size<100000)continue
 const destination=path.resolve(originals,relative)
 if(relative.startsWith('..')||path.isAbsolute(relative)||!destination.startsWith(originals+path.sep)||fs.existsSync(destination))throw Error('Exact original archive paths required')
 pack(source,relative+'.gz')
 fs.mkdirSync(path.dirname(destination),{recursive:true});fs.renameSync(source,destination)
}
for(const name of fs.readdirSync(scratch).filter(name=>/\.(ts|ps1|json|log)$/.test(name)&&name!=='archive.log'))pack(path.join(scratch,name),'checks/'+name+'.gz')
fs.writeFileSync(path.join(root,'checks/archive-receipt.json'),JSON.stringify({files},null,2)+'\n',{flag:'wx'})
let textFiles=0
for(const entry of fs.readdirSync(root,{recursive:true,withFileTypes:true}).filter(x=>x.isFile())){
 if(entry.name.endsWith('.png'))continue
 const raw=fs.readFileSync(path.join(entry.parentPath,entry.name)),text=(entry.name.endsWith('.gz')?gunzipSync(raw):raw).toString('utf8')
 if(redactor.containsCredential(text))throw Error('Credential found in final evidence')
 textFiles++
}
fs.writeFileSync(path.join(root,'checks/credential-scan.json'),JSON.stringify({textFiles,credentialMatches:0,archives:'Full decompressed texts scanned'},null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({files:files.length,textFiles,credentialMatches:0}))
