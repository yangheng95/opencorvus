import fs from 'node:fs'
import {Database} from 'bun:sqlite'
const root='D:/myhexin-local/opencorvus/specs/artifacts/2026-10-05-connection-workspace-authority/message-failure-354'
const db=new Database('C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-12/child-view-retention-353-live-01/runtime/data/opencorvus.db',{readonly:true})
db.exec('BEGIN')
try {
 const worker='ses_h9aQ1aKN0qHWqIOhZfo7'
 const messages=db.query('SELECT id,time_created,data FROM message WHERE session_id=? ORDER BY time_created,id').all(worker) as any[]
 const parts=db.query('SELECT p.id,p.message_id,p.data FROM part p JOIN message m ON m.id=p.message_id WHERE m.session_id=? ORDER BY p.time_created,p.id').all(worker) as any[]
 const decoded=parts.map(p=>({...p,role:JSON.parse(messages.find(m=>m.id===p.message_id).data).role,data:JSON.parse(p.data)}))
 const failures=messages.filter(m=>JSON.parse(m.data).error).map(m=>({id:m.id,createdAt:m.time_created,error:JSON.parse(m.data).error,parts:decoded.filter(p=>p.message_id===m.id).map(p=>({id:p.id,type:p.data.type}))}))
 const latest=messages.at(-1)
 const fact={observedAtUtc:new Date().toISOString(),access:'Original canonical SQLite readonly BEGIN/ROLLBACK; actual persisted rows',worker,failures,latestMessage:{id:latest.id,info:JSON.parse(latest.data)},sourceCount:decoded.filter(p=>p.data.type==='source-url').length,textParts:decoded.filter(p=>p.data.type==='text').map(p=>({id:p.id,messageID:p.message_id,text:p.data.text})),task:db.query('SELECT id,project_id,session_id,request_id FROM engine_task').all(),boundary:'These are stored data facts. Actual screenshots and manual review separately establish rendering.'}
 const assistantText=decoded.filter(p=>p.role==='assistant'&&p.data.type==='text').map(p=>({id:p.id,messageID:p.message_id,text:p.data.text}))
 fs.writeFileSync(root+'/actual-message-facts-qualified.json',JSON.stringify({...fact,assistantText},null,2)+'\n',{flag:'wx'})
 console.log(JSON.stringify({failures:failures.map(f=>f.id),sourceCount:fact.sourceCount,assistantTextParts:assistantText.length,assistantChars:assistantText.reduce((n,p)=>n+p.text.length,0),latestID:latest.id,latestFinish:JSON.parse(latest.data).finish}))
}finally{db.exec('ROLLBACK');db.close()}
