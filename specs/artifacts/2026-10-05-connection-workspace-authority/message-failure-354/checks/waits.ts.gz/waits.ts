import fs from 'node:fs'
import { createRequire } from 'node:module'
import { pathToFileURL } from 'node:url'
import { Database } from 'bun:sqlite'
const repo='D:/myhexin-local/opencorvus'
const require=createRequire(repo+'/packages/opencorvus/package.json')
const {drizzle}=await import(pathToFileURL(require.resolve('drizzle-orm/bun-sqlite')).href)
const {projectTaskWaitInTransaction,dueTaskWaitsInTransaction}=await import(repo+'/packages/opencorvus/src/engine/task-wait.ts')
const db=new Database('C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-12/child-view-retention-353-live-01/runtime/data/opencorvus.db',{readonly:true})
db.exec('BEGIN')
try {
 const tx=drizzle({client:db})
 const rows=db.query('SELECT * FROM engine_task_wait_registration').all() as any[]
 const result={observedAtUtc:new Date().toISOString(),projections:rows.map(row=>projectTaskWaitInTransaction(tx,row)),settlements:db.query('SELECT * FROM engine_task_wait_settlement').all(),due:dueTaskWaitsInTransaction(tx,{taskID:'tsk_g00VXqO7wS00Jmf0HdZh',executionEpoch:1,now:Date.now()}),access:'Original readonly BEGIN/ROLLBACK, canonical current wait projection and due reader'}
 fs.writeFileSync(repo+'/specs/artifacts/2026-10-05-connection-workspace-authority/message-failure-354/history-readiness/result-waits.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'})
 console.log(JSON.stringify(result))
}finally{db.exec('ROLLBACK');db.close()}
