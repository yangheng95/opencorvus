import fs from 'node:fs'
const scratch='.tmp-product-iteration/delegate-terminal-392'
const facts=JSON.parse(fs.readFileSync(scratch+'/live-final.json','utf8'))
const child=facts.sessions.find(s=>s.parent_id)
if(!child)throw Error('Actual child Session required')
const headers={'x-opencorvus-directory':child.directory}
for(const [label,id] of [['parent',child.parent_id],['child',child.id]]){
 const response=await fetch(`http://localhost:18425/session/${id}/conversation`,{headers,signal:AbortSignal.timeout(15000)})
 if(response.status!==200)throw Error(`${label} HTTP ${response.status}`)
 const body=await response.json()
 fs.writeFileSync(`${scratch}/${label}-conversation.json`,JSON.stringify(body,null,2)+'\n',{flag:'wx'})
}
const abort=new AbortController(),timer=setTimeout(()=>abort.abort(),10000)
let chunks=[],outcome='eof'
try{
 const response=await fetch(`http://localhost:18425/session/${child.parent_id}/events`,{headers,signal:abort.signal})
 if(response.status!==200)throw Error(`Events HTTP ${response.status}`)
 for await(const chunk of response.body)chunks.push(Buffer.from(chunk))
}catch(error){if(!abort.signal.aborted)throw error;outcome='bounded-read-complete'}finally{clearTimeout(timer)}
fs.writeFileSync(`${scratch}/replay-events.log`,Buffer.concat(chunks),{flag:'wx'})
console.log(JSON.stringify({child:child.id,parent:child.parent_id,outcome,bytes:Buffer.concat(chunks).length}))
