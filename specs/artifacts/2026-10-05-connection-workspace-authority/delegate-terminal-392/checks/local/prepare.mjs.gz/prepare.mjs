import fs from 'node:fs'
import path from 'node:path'
const root=path.resolve('.tmp-product-iteration'),scratch=path.join(root,'delegate-terminal-392')
for(const suffix of ['.ts','-launch.ps1','-shutdown.ps1']){
 const previous=fs.readFileSync(path.join(root,'live-sol-activity-input-391-after'+suffix),'utf8')
 const next=previous.replaceAll('activity-input-projection-391-after','delegate-terminal-392-live').replaceAll('live-sol-activity-input-391-after','live-sol-delegate-terminal-392-live').replaceAll('2026-10-13','2026-10-14')
 fs.writeFileSync(path.join(root,'live-sol-delegate-terminal-392-live'+suffix),next,{flag:'wx'})
}
const source='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/activity-input-projection-391-after-bundle/bin'
const target='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/delegate-terminal-392-live-bundle/bin'
fs.cpSync(source,target,{recursive:true,errorOnExist:true,force:false})
fs.mkdirSync(path.join(scratch,'live'),{recursive:true})
fs.mkdirSync(path.join(root,'delegate-terminal-392-live-native-observer'),{recursive:true})
fs.copyFileSync(path.join(root,'activity-input-projection-391/builtin.json'),path.join(scratch,'builtin.json'),fs.constants.COPYFILE_EXCL)
let facts=fs.readFileSync(path.join(root,'activity-input-projection-391/read-facts.ts'),'utf8')
facts=facts.replaceAll('activity-input-projection-391','delegate-terminal-392').replaceAll('2026-10-13','2026-10-14').replaceAll("['live','after']","['live']")
const anchor=" facts={phase,observedAt:new Date().toISOString(),boundary:'Read-only canonical SQLite transaction; not UI acceptance',sessions,messages,parts,tools,outcomes}"
if(!facts.includes(anchor))throw Error('Inspect canonical reader anchor')
facts=facts.replace(anchor," const events=db.query('SELECT id,type,source,aggregate_type,aggregate_id,session_id,seq,emitted_at,payload FROM protocol_event ORDER BY emitted_at,id').all().map((r:any)=>({...r,payload:JSON.parse(r.payload)}))\n"+anchor.replace('tools,outcomes}','tools,outcomes,events}'))
fs.writeFileSync(path.join(scratch,'read-facts.ts'),facts,{flag:'wx'})
console.log('Prepared fresh 2026-10-14 scope with immutable formal UI; credentials will be paired by the reviewed wrapper.')
