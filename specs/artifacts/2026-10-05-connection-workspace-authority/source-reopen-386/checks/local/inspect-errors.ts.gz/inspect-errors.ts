import fs from 'node:fs'
import {CredentialRedactor} from '../../packages/opencorvus/script/real-provider-audit'
const root='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/source-reopen-386-live'
const redactor=new CredentialRedactor()
redactor.collect(JSON.parse(fs.readFileSync('C:/Users/hengu/AppData/Local/opencorvus/data/auth.json','utf8')))
const rows=[]
for(const line of fs.readFileSync(root+'/runtime/log/dev.log','utf8').split(/\r?\n/)){
 if(!line)continue
 try{
  const row=JSON.parse(line)
  if(/error|fail|retry/i.test(row.level+' '+row.message+' '+JSON.stringify(row.data??{})))rows.push(row)
 }catch{}
}
const text=redactor.redact(JSON.stringify(rows,null,2))
fs.writeFileSync('.tmp-product-iteration/source-reopen-386/runtime-errors.json',text+'\n',{flag:'wx'})
console.log(redactor.redact(JSON.stringify(rows.map((row:any)=>({time:row.time,service:row.service,level:row.level,message:row.message,data:row.data})),null,2)))
