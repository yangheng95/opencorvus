import fs from 'node:fs'
import path from 'node:path'
const root=path.resolve('.tmp-product-iteration'),scratch=path.join(root,'source-reopen-386')
for(const suffix of ['launch.ps1','shutdown.ps1']){
 const old=fs.readFileSync(path.join(root,'live-sol-results-383-'+suffix),'utf8')
 const next=old.replaceAll('source-result-commit-383','source-reopen-386').replaceAll('live-sol-results-383','live-sol-sources-386')
 if(old===next)throw Error('Expected reviewed launcher path replacements')
 fs.writeFileSync(path.join(root,'live-sol-sources-386-'+suffix),next,{flag:'wx'})
}
fs.copyFileSync(path.join(root,'live-sol-results-383.ts'),path.join(root,'live-sol-sources-386.ts'),fs.constants.COPYFILE_EXCL)
fs.writeFileSync(path.join(scratch,'builtin.json'),JSON.stringify({kind:'builtin',id:'base',namespace:'builtin'}),{flag:'wx'})
fs.mkdirSync(path.join(scratch,'live'),{recursive:true})
fs.mkdirSync(path.join(root,'source-reopen-386-native-observer'),{recursive:true})
console.log('Prepared independent 386 launcher paths; native wrapper and budgets unchanged.')
