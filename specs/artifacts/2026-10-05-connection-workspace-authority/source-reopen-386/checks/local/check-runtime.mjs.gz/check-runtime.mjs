import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
const scratch=path.resolve('.tmp-product-iteration/source-reopen-386')
const run='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/source-reopen-386-live'
const read=p=>JSON.parse(fs.readFileSync(p,'utf8'))
const before=read(path.join(scratch,'before-refresh.json')),after=read(path.join(scratch,'after-refresh.json')),final=read(path.join(scratch,'final.json'))
const names=['方案甲.txt','方案乙.txt','来源显示与刷新后定位验证——较长的中文补充说明文件.txt']
const expected=['价格：120\n交付：3天','价格：180\n交付：2天','比较范围：价格与交付日期\n选择原则：按真实文件内容比较']
const sources=before.parts.filter(p=>p.type==='source-file')
assert.equal(sources.length,3)
assert.equal(before.tools.length,3)
assert.equal(new Set(before.tools.map(t=>t.messageID)).size,3)
for(let i=0;i<3;i++){
 const tool=before.tools[i],source=sources[i],outcome=before.outcomes.find(o=>o.requestPartID===tool.id)
 assert.equal(tool.tool,'read')
 assert.deepEqual(tool.input,{filePath:'来源材料/'+names[i],offset:2,limit:2})
 assert.equal(outcome.outcome,'completed')
 assert.equal(outcome.metadata.preview,expected[i])
 assert.equal(source.toolPartID,tool.id)
 assert.equal(source.messageID,tool.messageID)
 assert.equal(source.path.replaceAll('\\','/'),run+'/project/来源材料/'+names[i])
 assert.deepEqual(source.range,{startLine:2,endLine:3})
 assert.equal(before.messages.find(m=>m.id===tool.messageID).agent,'work')
 for(const snapshot of [after,final]){
  assert.deepEqual(snapshot.parts.find(p=>p.id===source.id),source)
  assert.deepEqual(snapshot.tools.find(t=>t.id===tool.id),tool)
  assert.deepEqual(snapshot.outcomes.find(o=>o.requestPartID===tool.id),outcome)
  assert.deepEqual(snapshot.messages.find(m=>m.id===tool.messageID),before.messages.find(m=>m.id===tool.messageID))
 }
}
const selectedSession=before.messages.find(m=>m.id===before.tools[0].messageID).sessionID
const response=before.parts.filter(p=>p.type==='text'&&before.messages.some(m=>m.id===p.messageID&&m.role==='assistant'&&m.sessionID===selectedSession)).map(p=>p.text).join('\n')
assert.equal(response,'方案甲价格为120，方案乙为180，甲比乙便宜60。\n方案甲交付时间为3天，方案乙为2天，乙比甲快1天。')
const owner=read(path.join(run,'launch-owner.json')),native=read(path.join(run,'evidence/native-host-settled.json'))
const provider=read(path.join(scratch,'live/source-reopen-386-live-final-provider-audit.json'))
const cleanup=read(path.join(scratch,'live/source-reopen-386-live-physical-terminal-and-pair-cleanup.json'))
assert.equal(native.occurrence,owner.occurrence)
assert.equal(native.terminal.reason,'exited');assert.equal(native.terminal.exitCode,0)
for(const flag of ['physicalCompletion','outputDrainComplete','requestCleanupComplete'])assert.equal(native[flag],true)
assert.equal(cleanup.occurrence,owner.occurrence)
assert.equal(cleanup.pairedCleanupComplete,true)
assert.deepEqual(cleanup.copiedPair.map(p=>p.outcome),['removed','removed'])
assert.deepEqual(cleanup.chain.map(p=>p.state),['dead_or_reused','dead_or_reused'])
assert.equal(provider.maxRequests,20);assert.equal(provider.requests.length,8)
for(const request of provider.requests){assert.equal(request.model,'gpt-6.1-sol');assert.equal(request.streaming,true)}
assert.equal(provider.requests[0].response_reader.state,'fetch_failed')
for(const request of provider.requests.slice(1)){assert.equal(request.status,200);assert.equal(request.response_reader.terminal.kind,'eof')}
const errors=read(path.join(scratch,'runtime-errors.json'))
const fetchFailure=errors.find(row=>row.service==='llm'&&row.message==='stream error')
assert.equal(fetchFailure.data.agent,'memory')
assert.equal(fetchFailure.data.sessionID,read(path.join(run,'evidence/preflight-ready.json')).preflight.sessionID)
assert.equal(fetchFailure.data.error.name,'APIError')
assert.equal(fetchFailure.data.error.data.isRetryable,true)
const deliveryErrors=errors.filter(row=>row.service==='overlay:runtime'&&row.message==='window.error')
const result={canonicalSourceAndResultChecks:'passed',sources:sources.map(p=>({id:p.id,toolPartID:p.toolPartID,messageID:p.messageID,path:p.path,range:p.range})),
 actualAgent:'work',actualReadMessages:3,selectedSession,refreshComparison:'Original Source, Tool, outcome and Message facts preserved across before/after/final snapshots',
 visualEvidence:['01-three-sources.png','02-long-file-lines.png','03-after-reload.png','04-after-reload-file-lines.png'],visualReview:'Manually inspected real screenshots; UI not asserted by this checker',
 provider:{requests:8,budget:20,eof200:7,fetchFailed:1,failedAgent:fetchFailure.data.agent,error:fetchFailure.data.error},
 native:{terminal:native.terminal,physicalCompletion:true,pairedCleanupComplete:true,durationMilliseconds:Date.parse(native.observedAtUtc)-owner.targetBirthAtMs},
 launcher:{exitCode:1,error:'OWNED_PROVIDER_REQUEST_INVALID',qualification:false},
 resizeObserver:{deliveryErrors:deliveryErrors.length,rootCause:'unknown; synchronous textarea/toolbar callbacks are investigation candidates, not attributed causes'},
 remaining:['Full scope Provider qualification failed on the original memory fetch attempt.','Repeated ResizeObserver delivery diagnostics require exact callback investigation.','This run does not qualify OS-crash recovery, collapsed multi-source groups, Chinese UI or subagent-side rendering.']}
fs.writeFileSync(path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/source-reopen-386/runtime-review.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify(result))
