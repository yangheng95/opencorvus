import fs from 'node:fs'
import path from 'node:path'
const run='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/source-file-identity-374-after'
const evidence=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/source-file-identity-374/after')
const ready=JSON.parse(fs.readFileSync(path.join(run,'evidence/preflight-ready.json'),'utf8')).preflight
if(ready.credential!=='usable'||ready.catalog!=='projected'||ready.actualModel!=='gpt-6.1-sol'||!ready.streaming)throw Error('Provider qualification required')
const project=path.join(run,'project'),file=path.join(project,'资料/编辑记录.txt'),outside=path.join(run,'外部记录.txt')
const text='第一行\r\n前😀IDENTITY374\r\n第三行\r\n',externalText='外部只读来源374\n',attachmentText='原始附件374\r\n附件第二行\r\n'
fs.mkdirSync(path.dirname(file),{recursive:true})
for(const [target,body] of [[file,text],[outside,externalText]]){
 if(fs.existsSync(target)){if(!fs.readFileSync(target).equals(Buffer.from(body)))throw Error('Owned input differs')}
 else fs.writeFileSync(target,body,{flag:'wx'})
}
const upload=await fetch('http://localhost:18381/attachment?'+new URLSearchParams({directory:project,filename:'研究附件374.txt'}),{method:'POST',headers:{'Content-Type':'text/plain'},body:attachmentText,signal:AbortSignal.timeout(30000)})
const reference=await upload.json();if(upload.status!==200)throw Error(JSON.stringify({status:upload.status,reference}))
const root=path.join(project,'.opencorvus/.r/project/attachments'),name=reference.url.split('/').at(-1)
const matches=fs.readdirSync(root,{recursive:true,withFileTypes:true}).filter(e=>e.isFile()&&e.name===name).map(e=>path.join(e.parentPath,e.name))
if(matches.length!==1)throw Error('One actual uploaded blob required')
const attachment=matches[0],relativeAttachment=path.relative(project,attachment).replaceAll('\\','/')
fs.mkdirSync(evidence,{recursive:true});fs.writeFileSync(path.join(evidence,'authored-inputs.json'),JSON.stringify({file,text,outside,externalText,attachment,attachmentText,relativeAttachment,reference,uploadStatus:upload.status},null,2)+'\n',{flag:'wx'})
const prompt='请实际读取三个文件并保留真实来源：资料/编辑记录.txt（offset=2,limit=1），附件 '+reference.url+'（offset=1,limit=2），外部文件 '+outside+'（offset=1,limit=1）。这些是我创建的本轮验收文件，可以读取。然后原样输出下列Markdown列表，不改文件，不创建任务或调用成员：\n'+[
 '- [相对项目引用](资料/编辑记录.txt:2:4)',
 '- [绝对项目引用]('+file+':2:4)',
 '- [附件绝对引用]('+attachment.replaceAll('\\','/')+':1-2)',
 '- [附件相对引用]('+relativeAttachment+':1-2)',
 '- [外部引用]('+outside+':1)',
].join('\n')
fs.writeFileSync('.tmp-product-iteration/source-file-identity-374/after/main-request.txt',prompt,{flag:'wx'})
console.log(JSON.stringify({prepared:true,uploadStatus:upload.status,file,reference,attachment}))
