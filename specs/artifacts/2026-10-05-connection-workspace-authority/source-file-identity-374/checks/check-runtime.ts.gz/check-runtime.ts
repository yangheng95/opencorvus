import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
const root=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/source-file-identity-374')
const dir=path.join(root,'after'),prefix='source-file-identity-374-after',read=(name:string)=>JSON.parse(fs.readFileSync(path.join(dir,name),'utf8'))
const input=read('authored-inputs.json'),canonical=read('canonical-current-conversations.json'),sources=canonical.parts.filter((p:any)=>p.type==='source-file')
assert.equal(sources.length,3);assert.equal(canonical.tools.length,3)
const expectedBytes=Buffer.from(input.text.replace('前😀IDENTITY374','前😀yxIDENTITY374'))
assert.deepEqual(fs.readFileSync(input.file),expectedBytes)
assert.deepEqual(fs.readFileSync(input.attachment),Buffer.from(input.attachmentText))
assert.deepEqual(fs.readFileSync(input.outside),Buffer.from(input.externalText))
const expected=[
 {file:input.file,request:{filePath:'资料/编辑记录.txt',offset:2,limit:1},body:'2: 前😀IDENTITY374\n\n(Showing lines 2-2 of 3. Use offset=3 to continue.)'},
 {file:input.attachment,request:{filePath:input.reference.url,offset:1,limit:2},body:'1: 原始附件374\n2: 附件第二行\n\n(End of file - total 2 lines)'},
 {file:input.outside,request:{filePath:input.outside,offset:1,limit:1},body:'1: 外部只读来源374\n\n(End of file - total 1 lines)'},
]
const calls=[]
for(const value of expected){
 const source=sources.find((s:any)=>s.path===value.file);assert.equal(source.provider,'opencorvus-read')
 const tool=canonical.tools.find((t:any)=>t.message_id===source.messageID),request=JSON.parse(tool.data)
 assert.equal(request.tool,'read');assert.deepEqual(request.input,value.request)
 const outcome=canonical.outcomes.find((o:any)=>o.requestPartID===tool.id);assert.equal(outcome.outcome,'completed')
 assert.equal(outcome.output,`<path>${value.file}</path>\n<type>file</type>\n<content>${value.body}\n</content>`)
 calls.push({sourceID:source.sourceId,path:source.path,callID:request.callID,outcome:outcome.outcome})
}
assert.deepEqual(sources.find((s:any)=>s.path===input.file).range,{startLine:2,endLine:2})
assert.equal(sources.find((s:any)=>s.path===input.attachment).origin,'attachment')
assert.equal(sources.find((s:any)=>s.path===input.attachment).title,'研究附件374.txt')
const completed=canonical.messages.filter((m:any)=>m.role==='assistant'&&m.finish==='stop')
assert.equal(completed.length,3);for(const m of completed)assert.equal(typeof m.time.completed,'number')
const preflight=read(prefix+'-preflight-ready.json').preflight
assert.deepEqual({credential:preflight.credential,catalog:preflight.catalog,model:preflight.actualModel,stream:preflight.streaming},{credential:'usable',catalog:'projected',model:'gpt-6.1-sol',stream:true})
const provider=read(prefix+'-final-provider-audit.json');assert.equal(provider.exhausted,false);assert.ok(provider.requests.length>0&&provider.requests.length<=12)
for(const r of provider.requests)assert.deepEqual({model:r.model,stream:r.streaming,status:r.status,reader:r.response_reader.state,terminal:r.response_reader.terminal.kind},{model:'gpt-6.1-sol',stream:true,status:200,reader:'settled',terminal:'eof'})
const settled=read(prefix+'-native-host-settled.json')
for(const key of ['physicalCompletion','outputDrainComplete','requestCleanupComplete'])assert.equal(settled[key],true)
assert.deepEqual({reason:settled.terminal.reason,exit:settled.terminal.exitCode},{reason:'exited',exit:0})
const qualified=read(prefix+'-qualified-surface-completion.json');assert.equal(qualified.qualification,'NativeService');assert.equal(qualified.providerEOFRequests,provider.requests.length)
const cleanup=read(prefix+'-physical-terminal-and-pair-cleanup.json');assert.equal(cleanup.pairedCleanupComplete,true);assert.deepEqual(cleanup.copiedPair.map((e:any)=>e.outcome),['removed','removed'])
const http=read(prefix+'-http-summary.json')
const served=http.requests.find((r:any)=>r.data?.path==='/ui/assets/main-Hg2zJLcN.js'&&r.data?.status==='completed');assert.equal(served.data.statusCode,200)
const birth=Number(BigInt(settled.target.processInstanceID.slice(6))/10000n-62135596800000n)
const result={calls,completed,requests:provider.requests.length,elapsedMs:Date.parse(settled.observedAtUtc)-birth,settled,qualified,served,files:{savedText:expectedBytes.toString('utf8'),attachment:input.attachmentText,external:input.externalText}}
fs.mkdirSync(path.join(root,'checks'),{recursive:true})
fs.writeFileSync(path.join(root,'checks/runtime-qualification.json'),JSON.stringify({result,boundary:'Actual Provider/Native/Source/completed Message/ToolOutcome/full file bytes and HTTP facts. Nine UI screenshots were manually reviewed; no UI assertions. Explicit Markdown backslash escaping required an authored correction message. Native external editor and first-use clipboard are outside this qualification.'},null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({sources:calls.length,requests:result.requests,elapsedMs:result.elapsedMs,savedBytes:expectedBytes.length,exit:0}))
