import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
const root=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/source-file-identity-374/after')
const input=JSON.parse(fs.readFileSync(path.join(root,'authored-inputs.json'),'utf8'))
const directory=path.resolve(path.dirname(input.file),'..')
const results=[]
async function api(route,query={},init={}){
 const r=await fetch('http://localhost:18381/'+route+'?'+new URLSearchParams({directory,...query}),{...init,signal:AbortSignal.timeout(30000)})
 const body=await r.json(),result={route,query,status:r.status,body};results.push(result);return result
}
const ordinary=await api('file/content',{path:'资料/编辑记录.txt'})
assert.equal(ordinary.status,200);assert.equal(typeof ordinary.body.revision,'string')
for(const [route,file,content] of [['file/content',input.relativeAttachment,input.attachmentText],['file/source-content',input.attachment,input.attachmentText],['file/source-content',input.outside,input.externalText]]){
 const r=await api(route,{path:file});assert.deepEqual({status:r.status,body:r.body},{status:200,body:{type:'text',content}})
}
const rejected=await api('file/content',{}, {method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({path:input.relativeAttachment,content:'attempted attachment edit',expectedRevision:ordinary.body.revision})})
assert.deepEqual({status:rejected.status,body:rejected.body},{status:400,body:{name:'FileInvalidPathError',data:{path:input.relativeAttachment,message:'Cannot edit read-only file: '+input.relativeAttachment}}})
assert.deepEqual(fs.readFileSync(input.attachment),Buffer.from(input.attachmentText))
assert.deepEqual(fs.readFileSync(input.outside),Buffer.from(input.externalText))
fs.writeFileSync(path.join(root,'live-file-api.json'),JSON.stringify({results,attachmentBytes:'exact original',externalBytes:'exact original'},null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({checks:results.length,attachmentSave:rejected.status}))
