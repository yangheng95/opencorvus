import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import { Database } from 'bun:sqlite'
const base='C:/Users/hengu/.codex/opencorvus-product-iteration'
const evidence=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/closed-history-363')
fs.mkdirSync(path.join(evidence,'checks'),{recursive:true})
const specs=[
 {scope:'before',source:base+'/2026-10-13/source-surfaces-356-live-02',label:'closed-history-363-before',handle:26239,asset:'main-Fa0QkExU.js',sources:192},
 {scope:'after',source:base+'/2026-10-13/source-surfaces-356-live-02',label:'closed-history-363-after',handle:96378,asset:'main-DuDwFuGN.js',sources:192},
 {scope:'child',source:base+'/2026-10-12/child-dense-348-live-01',label:'closed-history-363-child',handle:31168,asset:'main-DuDwFuGN.js',sources:66},
]
function facts(run:string){
 const db=new Database(path.join(run,'runtime/data/opencorvus.db'),{readonly:true});db.exec('BEGIN')
 try{return {
  messages:db.query('SELECT id,session_id,data FROM message ORDER BY id').all(),
  sources:(db.query("SELECT p.id,p.message_id,m.session_id,p.data FROM part p JOIN message m ON m.id=p.message_id WHERE json_extract(p.data,'$.type') IN ('source-file','source-url','source-document') ORDER BY p.id").all() as any[]).map(r=>({...r,data:JSON.parse(r.data)})),
 }}finally{db.exec('ROLLBACK');db.close()}
}
const runs=[]
for(const spec of specs){
 const original=facts(spec.source),run=base+'/2026-10-13/'+spec.label,current=facts(run)
 assert.deepEqual(current.messages,original.messages)
 assert.deepEqual(current.sources,original.sources)
 assert.equal(current.sources.length,spec.sources)
 const folder=path.join(evidence,spec.scope)
 const settled=JSON.parse(fs.readFileSync(path.join(folder,spec.label+'-native-host-settled.json'),'utf8'))
 for(const key of ['physicalCompletion','outputDrainComplete','requestCleanupComplete'])assert.equal(settled[key],true)
 assert.equal(settled.terminal.reason,'exited');assert.equal(settled.terminal.exitCode,0)
 const http=JSON.parse(fs.readFileSync(path.join(folder,spec.label+'-http-summary.json'),'utf8'))
 const served=http.requests.find((r:any)=>r.data?.path===`/ui/assets/${spec.asset}`&&r.data?.status==='completed')
 assert.equal(served.data.statusCode,200)
 const provider=JSON.parse(fs.readFileSync(path.join(folder,spec.label+'-final-provider-audit.json'),'utf8'))
 const birth=Number(BigInt(settled.target.processInstanceID.slice(6))/10000n-62135596800000n)
 runs.push({scope:spec.scope,source:spec.source,run,initialHandle:spec.handle,launcherExitCode:0,settled,elapsedMs:Date.parse(settled.observedAtUtc)-birth,served,canonicalMessageCount:current.messages.length,canonicalSourceCount:current.sources.length,providerAudit:provider,qualification:'Complete canonical Message and Source rows match the closed original by full actual content; actual UI asset HTTP200 and production Native/output/request closure verified. Visual layout remains separate manual evidence. The credentialless history audit does not assert new model acceptance.'})
 fs.writeFileSync(path.join(folder,'canonical-sources.json'),JSON.stringify(current.sources,null,2)+'\n')
}
fs.writeFileSync(path.join(evidence,'checks/runtime-qualification.json'),JSON.stringify({checkedAt:new Date().toISOString(),runs,boundary:'Actual readonly SQLite transactions and current production HTTP/native receipts. No DOM, source-text, component or screenshot assertions.'},null,2)+'\n')
console.log(JSON.stringify(runs.map(r=>({scope:r.scope,messages:r.canonicalMessageCount,sources:r.canonicalSourceCount,asset:r.served.data.path,exit:r.launcherExitCode,elapsedMs:r.elapsedMs}))))
