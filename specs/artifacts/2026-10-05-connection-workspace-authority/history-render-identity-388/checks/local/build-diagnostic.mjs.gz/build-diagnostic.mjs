import fs from 'node:fs'
import path from 'node:path'
import {build,loadConfigFromFile} from '../../packages/overlay/node_modules/vite/dist/node/index.js'
const workspace=process.cwd(),phase=process.argv[2]
if(!['before','after'].includes(phase))throw Error('Exact private phase required')
function replaceOnce(source,anchor,next){
 if(source.split(anchor).length!==2)throw Error('Inspect changed diagnostic anchor')
 return source.replace(anchor,next)
}
process.chdir(path.join(workspace,'packages/overlay'))
const loaded=await loadConfigFromFile({command:'build',mode:'production'},path.join(workspace,'packages/overlay/vite.config.ts'))
if(!loaded)throw Error('Existing Vite configuration required')
await build({...loaded.config,configFile:false,plugins:[{
 name:'owned-manual-markdown-lifetimes',enforce:'pre',
 transform(source,id){
  const file=id.replaceAll('\\','/')
  if(file.endsWith('/components/SideChatPanel.tsx')){
   const anchor='function SideMessage(props: { message: SubagentTranscriptMessage }) {'
   return replaceOnce(source,anchor,`let sideTraceSequence388 = 0\n${anchor}\n  const traceOwner388 = ++sideTraceSequence388\n  console.debug("SIDE388", JSON.stringify({kind:"create",owner:traceOwner388,messageID:props.message.messageID,at:performance.now()}))\n  onCleanup(() => console.debug("SIDE388", JSON.stringify({kind:"dispose",owner:traceOwner388,messageID:props.message.messageID,at:performance.now()})))`)
  }
  if(file.endsWith('/components/text-part-model.ts')){
   source=replaceOnce(source,'export function createStreamingTextPartModel','let textTraceSequence388 = 0\nexport function createStreamingTextPartModel')
   const anchor='  const [error, setError] = createSignal("")'
   return replaceOnce(source,anchor,`${anchor}\n  const traceOwner388 = ++textTraceSequence388\n  console.debug("MD388", JSON.stringify({kind:"create",owner:traceOwner388,at:performance.now()}))\n  createEffect(() => console.debug("MD388", JSON.stringify({kind:"state",owner:traceOwner388,textLength:props.text.length,streaming:props.streaming===true,pending:pending(),blocks:frozenHtml().length,at:performance.now()})))\n  onCleanup(() => console.debug("MD388", JSON.stringify({kind:"dispose",owner:traceOwner388,at:performance.now()})))`)
  }
 },
},...(loaded.config.plugins??[])],build:{...loaded.config.build,minify:false,outDir:`C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/history-render-identity-388-${phase}-bundle/bin/ui`}})
