import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
const scratch=path.resolve('.tmp-product-iteration/history-render-identity-388')
const evidence=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/history-render-identity-388')
const read=p=>JSON.parse(fs.readFileSync(p,'utf8').replace(/^\uFEFF/,''))
const phases=[]
for(const phase of ['before','after']){
 const run='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/history-render-identity-388-'+phase
 const initial=read(path.join(scratch,phase+'-initial.json'))
 const final=read(path.join(scratch,phase+'-final.json'))
 const side=final.sessions.find(s=>JSON.parse(s.metadata).sideChat)
 const history=JSON.parse(side.metadata).sideChat
 assert.equal(history.inheritedMessageIDs.length,3)
 const selectHistory=f=>({messages:f.messages.filter(m=>history.inheritedMessageIDs.includes(m.id)),parts:f.parts.filter(p=>history.inheritedMessageIDs.includes(p.messageID)),tools:f.tools.filter(t=>history.inheritedMessageIDs.includes(t.messageID))})
 assert.deepEqual(selectHistory(final),selectHistory(initial))
 const sources=final.parts.filter(p=>p.type==='source-file')
 assert.equal(sources.length,2)
 for(const source of sources){
  const tool=final.tools.find(t=>t.id===source.toolPartID)
  assert.equal(tool.messageID,source.messageID);assert.equal(tool.tool,'read')
  assert.equal(tool.input.offset,2);assert.equal(tool.input.limit,2)
  assert.deepEqual(source.range,{startLine:2,endLine:3})
  assert.equal(source.path.replaceAll('\\','/'),run+'/project/'+tool.input.filePath)
  const outcome=final.outcomes.find(o=>o.requestPartID===tool.id)
  assert.equal(outcome.outcome,'completed')
  assert.equal(outcome.metadata.preview,fs.readFileSync(source.path,'utf8').split('\n').slice(1,3).join('\n'))
 }
 const preflight=read(path.join(run,'evidence/preflight-ready.json'))
 assert.equal(preflight.preflight.credential,'usable');assert.equal(preflight.preflight.catalog,'projected')
 assert.equal(preflight.preflight.actualModel,'gpt-6.1-sol');assert.equal(preflight.preflight.streaming,true)
 const owner=read(path.join(run,'launch-owner.json')),native=read(path.join(run,'evidence/native-host-settled.json'))
 const prefix=path.join(scratch,phase,'history-render-identity-388-'+phase)
 const provider=read(prefix+'-final-provider-audit.json'),cleanup=read(prefix+'-physical-terminal-and-pair-cleanup.json'),qualified=read(prefix+'-qualified-surface-completion.json')
 assert.equal(provider.pid,owner.nativeTarget.pid);assert.equal(provider.maxRequests,20);assert.equal(provider.requests.length,8)
 for(const r of provider.requests){assert.equal(r.model,'gpt-6.1-sol');assert.equal(r.streaming,true);assert.equal(r.status,200);assert.equal(r.response_reader.terminal.kind,'eof')}
 assert.equal(native.occurrence,owner.occurrence);assert.equal(cleanup.occurrence,owner.occurrence)
 assert.equal(native.terminal.reason,'exited');assert.equal(native.terminal.exitCode,0)
 for(const key of ['physicalCompletion','outputDrainComplete','requestCleanupComplete'])assert.equal(native[key],true)
 assert.equal(cleanup.pairedCleanupComplete,true)
 assert.deepEqual(cleanup.copiedPair.map(p=>p.outcome),['removed','removed'])
 assert.equal(qualified.qualification,'NativeService');assert.equal(qualified.providerEOFRequests,8)
 const events=fs.readFileSync(path.join(scratch,phase,'proxy-events.jsonl'),'utf8').trim().split('\n').map(JSON.parse)
 const cut=events.find(e=>e.kind==='explicit-stream-disconnect')
 assert.equal(cut.sessionID,side.id)
 const resumed=events.find(e=>e.kind==='stream-established'&&e.sessionID===side.id&&Date.parse(e.time)>Date.parse(cut.time))
 assert.equal(resumed.status,200)
 phases.push({phase,sourceSessionID:history.sourceSessionID,sideSessionID:side.id,inheritedMessageIDs:history.inheritedMessageIDs,canonicalHistory:'retained',sourceBindings:sources.map(s=>({id:s.id,messageID:s.messageID,toolPartID:s.toolPartID,path:s.path,range:s.range})),preflight:preflight.preflight,requests:provider.requests.length,model:'gpt-6.1-sol',streaming:true,providerCompletion:'all HTTP 200 / EOF',native:{terminal:native.terminal,durationMilliseconds:Date.parse(native.observedAtUtc)-owner.targetBirthAtMs,physicalCompletion:true,pairedCleanupComplete:true},transport:{cut,resumed,terminal:events.at(-1)},qualification:qualified.qualification})
}
const result={phases,boundary:'Backend canonical data, actual Provider and native/transport receipts only; screenshots and passive component observations are manually reviewed, never UI automation assertions.',remaining:['Original subagent Rendering flicker remains independently unproven.','Before text selection was not established.','386 original fetch_failed remains its original failed scope.']}
fs.writeFileSync(path.join(evidence,'runtime-review.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify(result))
