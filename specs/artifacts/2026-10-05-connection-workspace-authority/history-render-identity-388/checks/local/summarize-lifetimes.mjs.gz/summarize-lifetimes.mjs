import fs from 'node:fs'
const root='.tmp-product-iteration/history-render-identity-388'
const phases=['before','after'].map(phase=>{
 const logs=JSON.parse(fs.readFileSync(`${root}/${phase}-lifetimes-reconnected.json`,'utf8'))
 const rows=logs.filter(e=>e.message.startsWith('SIDE388 ')).map(e=>({time:e.timestamp,...JSON.parse(e.message.slice(8))}))
 return {phase,rows}
})
const result={boundary:'Descriptive passive diagnostic timeline for manual causal review; no UI assertion, score or pass/fail.',phases}
fs.writeFileSync('specs/artifacts/2026-10-05-connection-workspace-authority/history-render-identity-388/lifetime-observations.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify(result))
