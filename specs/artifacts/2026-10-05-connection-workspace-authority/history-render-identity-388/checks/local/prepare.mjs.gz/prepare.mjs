import fs from 'node:fs'
import path from 'node:path'
const root=path.resolve('.tmp-product-iteration'),scratch=path.join(root,'history-render-identity-388')
for(const phase of ['before','after']){
 for(const suffix of ['launch.ps1','shutdown.ps1']){
  const old=fs.readFileSync(path.join(root,'live-sol-sources-386-'+suffix),'utf8')
  fs.writeFileSync(path.join(root,'live-sol-history-388-'+phase+'-'+suffix),old.replaceAll('source-reopen-386','history-render-identity-388-'+phase).replaceAll('live-sol-sources-386','live-sol-history-388-'+phase),{flag:'wx'})
 }
 fs.copyFileSync(path.join(root,'live-sol-sources-386.ts'),path.join(root,'live-sol-history-388-'+phase+'.ts'),fs.constants.COPYFILE_EXCL)
 fs.mkdirSync(path.join(scratch,phase),{recursive:true})
 fs.mkdirSync(path.join(root,'history-render-identity-388-'+phase+'-native-observer'),{recursive:true})
}
fs.writeFileSync(path.join(scratch,'builtin.json'),JSON.stringify({kind:'builtin',id:'base',namespace:'builtin'}),{flag:'wx'})
console.log('Prepared independent 388 scopes; no product source edits')
