import http from 'node:http'
import fs from 'node:fs'
import path from 'node:path'
const [portText,upstreamText,folder]=process.argv.slice(2)
const port=Number(portText),upstream=Number(upstreamText)
if(![18410,18412].includes(port)||upstream!==port-1||!path.isAbsolute(folder))throw Error('Exact owned proxy inputs required')
fs.mkdirSync(folder,{recursive:true})
const log=fs.createWriteStream(path.join(folder,'proxy-events.jsonl'),{flags:'wx'})
const record=(data)=>log.write(JSON.stringify({time:new Date().toISOString(),pid:process.pid,...data})+'\n')
const connections=new Map(),sockets=new Set()
let sequence=0,stopping=false,deadline
const close=async(reason)=>{
 if(stopping)return
 stopping=true;clearTimeout(deadline)
 record({kind:'stopping',reason,activeStreams:connections.size})
 for(const entry of connections.values()){entry.upstream.destroy();entry.response.destroy()}
 const closed=new Promise(resolve=>server.close(resolve))
 for(const socket of sockets)socket.destroy()
 await closed
 record({kind:'stopped',reason,activeStreams:connections.size,sockets:sockets.size})
 log.end()
}
const server=http.createServer(async(req,res)=>{
 const url=new URL(req.url,'http://localhost:'+port)
 if(url.pathname.startsWith('/__owned-diagnostic__/')){
  if(req.method!=='POST'||req.headers.origin){res.writeHead(403);res.end();return}
  const chunks=[];let length=0
  for await(const chunk of req){length+=chunk.length;if(length>2048){res.writeHead(413);res.end();return}chunks.push(chunk)}
  let body
  try{body=JSON.parse(Buffer.concat(chunks).toString()||'{}')}catch{res.writeHead(400);res.end();return}
  if(url.pathname==='/__owned-diagnostic__/close-stream'){
   const selected=[...connections.values()].filter(entry=>entry.sessionID===body.sessionID)
   if(selected.length!==1){res.writeHead(409,{'Content-Type':'application/json'});res.end(JSON.stringify({matches:selected.length,streams:[...connections.values()].map(e=>({id:e.id,sessionID:e.sessionID}))}));return}
   const entry=selected[0]
   record({kind:'explicit-stream-disconnect',id:entry.id,sessionID:entry.sessionID})
   entry.upstream.destroy();entry.response.destroy()
   res.writeHead(200,{'Content-Type':'application/json'});res.end(JSON.stringify({closedStream:entry.id,sessionID:entry.sessionID}));return
  }
  if(url.pathname==='/__owned-diagnostic__/stop'){
   res.writeHead(200,{'Content-Type':'application/json'});res.end(JSON.stringify({stopping:true,pid:process.pid}));res.on('finish',()=>void close('operator-stop'));return
  }
  res.writeHead(404);res.end();return
 }
 const headers={...req.headers,host:'localhost:'+upstream}
 delete headers.connection
 const id=++sequence
 const outgoing=http.request({hostname:'127.0.0.1',port:upstream,path:req.url,method:req.method,headers},incoming=>{
  const responseHeaders={...incoming.headers};delete responseHeaders.connection
  res.writeHead(incoming.statusCode??502,responseHeaders)
  const sessionID=/^\/session\/([^/]+)\/events$/.exec(url.pathname)?.[1]
  if(sessionID&&incoming.statusCode===200){
   connections.set(id,{id,sessionID,upstream:outgoing,response:res})
   record({kind:'stream-established',id,sessionID,path:url.pathname,status:incoming.statusCode})
  }
  incoming.on('error',error=>{record({kind:'upstream-body-error',id,name:error.name,message:error.message});res.destroy()})
  incoming.pipe(res)
 })
 outgoing.on('error',error=>{record({kind:'upstream-error',id,path:url.pathname,name:error.name,message:error.message});res.destroy()})
 res.on('close',()=>{if(connections.delete(id))record({kind:'stream-closed',id});outgoing.destroy()})
 req.on('aborted',()=>outgoing.destroy())
 req.pipe(outgoing)
})
server.on('connection',socket=>{sockets.add(socket);socket.on('close',()=>sockets.delete(socket))})
await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,'127.0.0.1',resolve)})
record({kind:'ready',port,upstream,deadlineMilliseconds:600000,mode:'Unmodified real HTTP bodies; explicit disconnect targets one established Session stream'})
fs.writeFileSync(path.join(folder,'proxy-ready.json'),JSON.stringify({pid:process.pid,port,upstream,readyAt:new Date().toISOString()},null,2)+'\n',{flag:'wx'})
deadline=setTimeout(()=>void close('resource-deadline'),600000)
console.log(JSON.stringify({ready:true,pid:process.pid,port,upstream}))
