import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import {Database} from 'bun:sqlite'
const evidence=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/clipboard-boundary-359')
const source='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/source-surfaces-356-live-02'
const run='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/clipboard-boundary-359'
function facts(root:string){const db=new Database(path.join(root,'runtime/data/opencorvus.db'),{readonly:true});db.exec('BEGIN');try{return {
 messages:db.query('SELECT id,session_id,data FROM message ORDER BY id').all(),
 sources:(db.query("SELECT p.id,p.message_id,m.session_id,p.data FROM part p JOIN message m ON m.id=p.message_id WHERE json_extract(p.data,'$.type') IN ('source-file','source-url','source-document') ORDER BY p.id").all() as any[]).map(r=>({...r,data:JSON.parse(r.data)})),
}}finally{db.exec('ROLLBACK');db.close()}}
const original=facts(source),current=facts(run)
assert.deepEqual(current.messages,original.messages);assert.deepEqual(current.sources,original.sources)
assert.equal(current.messages.length,11);assert.equal(current.sources.length,192)
const read=(name:string)=>JSON.parse(fs.readFileSync(path.join(evidence,'history','clipboard-boundary-359-'+name+'.json'),'utf8'))
const native=read('native-host-settled'),physical=read('physical-terminal-and-pair-cleanup'),http=read('http-summary'),copy=read('history-copy')
assert.equal(native.terminal.exitCode,0);assert.equal(native.terminal.reason,'exited')
for(const key of ['physicalCompletion','outputDrainComplete','requestCleanupComplete'])assert.equal(native[key],true)
assert.equal(physical.physicalCompletion,true);assert.equal(physical.pairedCleanupComplete,true)
assert.equal(copy.completeRows.tableRows.length,90)
const served=http.requests.filter((r:any)=>r.data?.path==='/ui/assets/main-CrFGPI-s.js'&&r.data?.status==='completed')
assert.equal(served.length>0,true);for(const r of served)assert.equal(r.data.statusCode,200)
const birth=Number(BigInt(native.target.processInstanceID.slice(6))/10000n-62135596800000n)
const result={checkedAt:new Date().toISOString(),source,run,initialHandle:76574,launcherExitCode:0,canonicalMessageCount:11,canonicalSourceCount:192,copiedTables:90,native,elapsedMs:Date.parse(native.observedAtUtc)-birth,served,boundary:'Actual canonical SQLite, full copy custody and current HTTP/Native facts only. Clipboard/UI results are manually reviewed separately; no UI assertions.'}
fs.mkdirSync(path.join(evidence,'checks'),{recursive:true})
fs.writeFileSync(path.join(evidence,'checks/runtime-qualification.json'),JSON.stringify(result,null,2)+'\n')
fs.writeFileSync(path.join(evidence,'history/canonical-sources.json'),JSON.stringify(current.sources,null,2)+'\n')
console.log(JSON.stringify({messages:11,sources:192,copiedTables:90,asset:served[0].data.path,elapsedMs:result.elapsedMs,exitCode:0,clipboardRootCause:'unresolved; cross-application first-copy mismatch reproduced manually'}))
