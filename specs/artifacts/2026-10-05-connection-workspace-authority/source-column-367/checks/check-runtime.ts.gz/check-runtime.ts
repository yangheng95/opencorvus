import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import {Database} from 'bun:sqlite'
const run='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/source-column-367'
const evidence=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/source-column-367')
const folder=path.join(evidence,'live'),label='source-column-367-live'
const read=(name:string)=>JSON.parse(fs.readFileSync(path.join(folder,name),'utf8'))
const canonical=read('canonical-current-conversations.json')
const inputs=JSON.parse(fs.readFileSync(path.join(evidence,'authored-inputs.json'),'utf8'))
for(const file of inputs.files)assert.deepEqual(fs.readFileSync(file.path),Buffer.from(file.text))
const db=new Database(path.join(run,'runtime/data/opencorvus.db'),{readonly:true})
let actualSources:any[]
try{db.exec('BEGIN');actualSources=(db.query("SELECT p.id,p.message_id,m.session_id,p.data FROM part p JOIN message m ON m.id=p.message_id WHERE json_extract(p.data,'$.type')='source-file' ORDER BY p.time_created,p.id").all() as any[]).map(r=>({...r,data:JSON.parse(r.data)}))}finally{db.exec('ROLLBACK');db.close()}
assert.equal(actualSources.length,9)
const surfaces=[
 {name:'main-first',sessionID:'ses_-zUS7SK5YzzhcENRFlhH',messageID:'msg_g0VXsXgDM008zVmCeBdX',count:2,pattern:'ALPHA367|SHORT367'},
 {name:'main-second',sessionID:'ses_-zUS7SK5YzzhcENRFlhH',messageID:'msg_g0VXsXhVp00myGenTzCx',count:1,pattern:'BETA367'},
 {name:'main-read',sessionID:'ses_-zUS7SK5YzzhcENRFlhH',messageID:'msg_g0VXsXioe00HO0axUmc0',count:1},
 {name:'side-reference-first',sessionID:'ses_-zUS7RhlFzzCtKthbQqI',messageID:'msg_g0VXsYIEn01x0m93dUKM',count:2,pattern:'ALPHA367|SHORT367'},
 {name:'side-reference-second',sessionID:'ses_-zUS7RhlFzzCtKthbQqI',messageID:'msg_g0VXsYIEn02Y5jESdzSI',count:1,pattern:'BETA367'},
 {name:'side-reference-read',sessionID:'ses_-zUS7RhlFzzCtKthbQqI',messageID:'msg_g0VXsYIEn03Y8z5qHEtK',count:1},
 {name:'side-current',sessionID:'ses_-zUS7RhlFzzCtKthbQqI',messageID:'msg_g0VXsYLQS00IM484s6ZN',count:1,pattern:'BETA367'},
]
const results=[]
for(const surface of surfaces){
 const request=canonical.tools.find((t:any)=>t.message_id===surface.messageID),data=JSON.parse(request.data)
 assert.equal(data.tool,surface.pattern?'search_code':'read')
 assert.deepEqual(data.input,surface.pattern?{pattern:surface.pattern,path:'资料/列定位',include:'*.md'}:{filePath:'资料/列定位/范围.md',offset:2,limit:2})
 const outcome=canonical.outcomes.find((o:any)=>o.requestPartID===request.id)
 assert.equal(outcome.outcome,'completed')
 const sources=actualSources.filter(s=>s.message_id===surface.messageID);assert.equal(sources.length,surface.count)
 for(const row of sources){
  assert.equal(row.session_id,surface.sessionID)
  const source=row.data,file=inputs.files.find((f:any)=>path.resolve(f.path)===source.path);assert.ok(file)
  if(surface.pattern){
   const expected=file.matches.find((m:any)=>surface.pattern!.split('|').includes(m.pattern));assert.ok(expected)
   assert.deepEqual(source.range,{startLine:expected.line,endLine:expected.line,startColumn:expected.column})
   assert.equal(file.text.split(/\r?\n/)[expected.line-1].slice(expected.column-1).startsWith(expected.pattern),true)
   assert.equal(source.provider,'opencorvus-search-code')
   const snippet=expected.pattern==='ALPHA367'?'...'+file.text.slice(2500,4500)+'...':expected.pattern==='BETA367'?'...'+file.text.slice(5013):file.text.split('\r\n')[1]
   assert.equal(source.snippet,snippet)
   assert.equal(outcome.output.includes(`  Line ${expected.line}: ${snippet}`),true)
  }else assert.deepEqual(source.range,{startLine:2,endLine:3})
  assert.deepEqual(canonical.parts.find((p:any)=>p.id===row.id).range,source.range)
 }
 results.push({...surface,requestPartID:request.id,toolOutputChars:outcome.output.length,sources:sources.map(s=>({partID:s.id,sourceID:s.data.sourceId,path:s.data.path,range:s.data.range}))})
}
const payload=(messageID:string)=>actualSources.filter(s=>s.message_id===messageID).map(s=>({sourceId:s.data.sourceId,path:s.data.path,range:s.data.range,snippet:s.data.snippet,title:s.data.title,provider:s.data.provider}))
for(let i=0;i<3;i++)assert.deepEqual(payload(surfaces[i]!.messageID),payload(surfaces[i+3]!.messageID))
const preflight=read(label+'-preflight-ready.json')
assert.deepEqual(preflight.preflight,{sessionID:'ses_h5QOcc1OTjw733QXMwGm',credential:'usable',catalog:'projected',actualModel:'gpt-6.1-sol',streaming:true})
const provider=read(label+'-final-provider-audit.json');assert.equal(provider.requests.length,12);assert.equal(provider.exhausted,true)
for(const request of provider.requests){assert.equal(request.model,'gpt-6.1-sol');assert.equal(request.streaming,true);assert.equal(request.status,200);assert.equal(request.response_reader.terminal.kind,'eof');assert.equal(request.response_reader.state,'settled')}
assert.deepEqual(canonical.messages.filter((m:any)=>m.error).map((m:any)=>({id:m.id,finish:m.finish,error:m.error})),[{id:'msg_g0VXsYMSY00Bb8uNmmLL',finish:'error',error:{name:'UnknownError',data:{message:'Error: E2E_REQUEST_BUDGET_EXHAUSTED'}}}])
const settled=read(label+'-native-host-settled.json')
for(const key of ['physicalCompletion','outputDrainComplete','requestCleanupComplete'])assert.equal(settled[key],true)
assert.equal(settled.terminal.reason,'exited');assert.equal(settled.terminal.exitCode,0)
const cleanup=read(label+'-physical-terminal-and-pair-cleanup.json');assert.equal(cleanup.pairedCleanupComplete,true);assert.deepEqual(cleanup.copiedPair.map((entry:any)=>entry.outcome),['removed','removed'])
const http=read(label+'-http-summary.json'),served=http.requests.find((r:any)=>r.data?.path==='/ui/assets/main-Du3_bV1a.js'&&r.data?.status==='completed');assert.equal(served.data.statusCode,200)
const birth=Number(BigInt(settled.target.processInstanceID.slice(6))/10000n-62135596800000n)
const result={checkedAt:new Date().toISOString(),initialHandle:10710,launcherExitCode:1,qualification:'incomplete',qualificationError:'OWNED_PROVIDER_COMPLETION_INVALID',sourceResults:results,requestCount:provider.requests.length,model:provider.model,exhausted:provider.exhausted,elapsedMs:Date.parse(settled.observedAtUtc)-birth,settled,served,boundary:'Actual SQLite Source records, production ToolOutcome output and complete authored file bytes. Side reference copies distinguished from actual invocation. 12 real provider EOF; final Side reply blocked by fixed cumulative request budget. Physical/output/request/authority cleanup complete, but original launcher qualification failed and is not converted to success. Visual review is separate manual evidence; no UI assertions.'}
fs.mkdirSync(path.join(evidence,'checks'),{recursive:true});fs.writeFileSync(path.join(evidence,'checks/runtime-observations.json'),JSON.stringify(result,null,2)+'\n')
console.log(JSON.stringify({sources:9,requests:12,elapsedMs:result.elapsedMs,model:provider.model,sourceContracts:'passed',qualification:'incomplete',originalLauncherExit:1}))
