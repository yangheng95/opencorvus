$ErrorActionPreference='Stop'
$run367='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/source-column-367'
$ready367=Get-Content -Raw (Join-Path $run367 'evidence/preflight-ready.json')|ConvertFrom-Json
if($ready367.preflight.credential -ne 'usable' -or $ready367.preflight.catalog -ne 'projected' -or $ready367.preflight.actualModel -ne 'gpt-6.1-sol' -or !$ready367.preflight.streaming){throw 'Actual credential/model qualification required'}
$utf367=[Text.UTF8Encoding]::new($false)
$directory367=Join-Path $run367 'project/资料/列定位'
[IO.Directory]::CreateDirectory($directory367)|Out-Null
$prefix367=('前置内容。'*500)+'😀'+('文'*39)
$first367='ALPHA367_第一处'
$middle367=('中段内容。'*500)
$inputs367=@(
 @{name='同一长行.md';text=($prefix367+$first367+$middle367+'BETA367_第二处'+('末尾。'*100));matches=@(@{pattern='ALPHA367';line=1;column=($prefix367.Length+1)},@{pattern='BETA367';line=1;column=($prefix367.Length+$first367.Length+$middle367.Length+1)})},
 @{name='短行.md';text=("标题`r`nbefore中😀SHORT367_普通行`r`n结束`r`n");matches=@(@{pattern='SHORT367';line=2;column=10})},
 @{name='范围.md';text="标题`n第二行记录`n第三行记录`n结束`n";matches=@()}
)
foreach($input367 in $inputs367){
 $path367=Join-Path $directory367 $input367.name
 if(Test-Path -LiteralPath $path367){throw 'Fresh input required'}
 $input367.path=$path367
 [IO.File]::WriteAllText($path367,$input367.text,$utf367)
}
$evidence367='D:/myhexin-local/opencorvus/specs/artifacts/2026-10-05-connection-workspace-authority/source-column-367'
[IO.Directory]::CreateDirectory($evidence367)|Out-Null
[IO.File]::WriteAllText((Join-Path $evidence367 'authored-inputs.json'),(@{files=$inputs367}|ConvertTo-Json -Depth 8)+[Environment]::NewLine,$utf367)
$scratch367='D:/myhexin-local/opencorvus/.tmp-product-iteration/source-column-367'
$main367='请实际执行三步：1. 用 search_code 在“资料/列定位”目录以正则 ALPHA367|SHORT367 搜索 Markdown；2. 再单独用 search_code 搜索同目录 BETA367；3. 用 read 读取“资料/列定位/范围.md”的第2和第3行。保留所有真实来源。最后只列出三个实际匹配位置，写成可点击的代码格式文件引用：`资料/列定位/同一长行.md:1:'+($prefix367.Length+1)+'`、`资料/列定位/同一长行.md:1:'+($prefix367.Length+$first367.Length+$middle367.Length+1)+'`、`资料/列定位/短行.md:2:10`。这些位置来自输入文件的实际字符计数。不修改文件，不创建任务，不调用成员。'
[IO.File]::WriteAllText((Join-Path $scratch367 'main-request.txt'),$main367,$utf367)
[IO.File]::WriteAllText((Join-Path $scratch367 'side-request.txt'),'请在本侧聊实际用 search_code 在“资料/列定位”目录搜索正则 BETA367，限定 Markdown。保留真实来源，只用一句话回复。不修改文件，不调用成员，不创建任务。',$utf367)
Write-Output ($inputs367|ForEach-Object{@{name=$_.name;matches=$_.matches}}|ConvertTo-Json -Depth 6)
