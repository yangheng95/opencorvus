import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import {Database} from 'bun:sqlite'
import {gzipSync,gunzipSync} from 'node:zlib'
import {CredentialRedactor} from '../../packages/opencorvus/script/real-provider-audit'
const root=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/markdown-lifetime-352')
const scratch=path.resolve('.tmp-product-iteration/markdown-lifetime-352')
const source='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-12/child-history-349-live-01'
const run='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-12/markdown-lifetime-352-history-01'
const redactor=new CredentialRedactor()
redactor.collect(JSON.parse(fs.readFileSync('C:/Users/hengu/AppData/Local/opencorvus/data/auth.json','utf8')))
fs.mkdirSync(path.join(root,'checks'),{recursive:true})
const save=(file:string,value:unknown)=>fs.writeFileSync(path.join(root,file),redactor.redact(JSON.stringify(value,null,2))+'\n',{flag:'wx'})
function facts(location:string){
 const db=new Database(path.join(location,'runtime/data/opencorvus.db'),{readonly:true});db.exec('BEGIN')
 try{return{
  messages:db.query('SELECT id,session_id,data FROM message ORDER BY id').all(),
  sources:db.query("SELECT id,message_id,data FROM part WHERE json_extract(data,'$.type') IN ('source-url','source-file','source-document') ORDER BY id").all(),
  requests:db.query('SELECT id FROM provider_activity_request ORDER BY id').all(),
 }}finally{db.exec('ROLLBACK');db.close()}
}
const original=facts(source),current=facts(run)
assert.deepEqual(current,original)
const settled=JSON.parse(fs.readFileSync(path.join(run,'evidence/native-host-settled.json'),'utf8'))
assert.equal(settled.terminal.reason,'exited');assert.equal(settled.terminal.exitCode,0)
assert.equal(settled.physicalCompletion,true);assert.equal(settled.outputDrainComplete,true);assert.equal(settled.requestCleanupComplete,true)
const http=JSON.parse(fs.readFileSync(path.join(root,'history-01/markdown-lifetime-352-history-01-http-summary.json'),'utf8'))
const served=http.requests.filter((x:any)=>/^\/ui\/assets\/main-[^/]+\.js$/.test(x.data?.path??'')&&x.data?.status==='completed')
assert.equal(served.length,1);assert.equal(served[0].data.statusCode,200)
const observed=JSON.parse(fs.readFileSync(path.join(root,'diagnostic-observations.json'),'utf8'))
save('diagnostic-summary.json',{observedAt:observed.observedAt,records:observed.records.length,firstSequence:observed.records[0]?.sequence,lastSequence:observed.records.at(-1)?.sequence,summaries:observed.summaries,qualification:observed.qualification})
const birth=Number(BigInt(settled.target.processInstanceID.slice(6))/10000n-62135596800000n)
save('checks/runtime-qualification.json',{source,run,launcherHandle:85478,launcherActualExit:0,settled,elapsedMs:Date.parse(settled.observedAtUtc)-birth,served,messages:current.messages.length,sources:current.sources.length,persistedProviderRequests:current.requests.length,identity:'All complete Message and Source rows and Provider request identities equal the original after real page use',boundaries:['Actual screenshots are separate; runtime and diagnostic data are not a visual assertion','Historical completed Task, no new streaming generation','Temporary instrumentation affects timing; no causal claim for continuous in-place rendering']})
const archives:any[]=[]
function archive(from:string,to:string){const raw=Buffer.from(redactor.redact(fs.readFileSync(from,'utf8')));const zipped=gzipSync(raw);assert.equal(gunzipSync(zipped).equals(raw),true);fs.writeFileSync(path.join(root,to+'.gz'),zipped,{flag:'wx'});archives.push({file:to+'.gz',bytes:raw.length,compressedBytes:zipped.length,integrity:'Full decompressed bytes equal actual redacted original'})}
for(const name of ['guard','complete-readiness','task-readiness','frontier','admit','copy-before','launch-before','shutdown-before','archive-before','piles-before','build-diagnostic','types-diagnostic','build-final','types-final','inspect','inspect-final'])archive(path.join(scratch,name+'.log'),'checks/'+name+'.log')
for(const name of ['stdout.log','stderr.log','runtime/log/dev.log'])archive(path.join(run,name),'history-01/'+path.basename(name))
save('checks/archive-receipt.json',archives)
console.log(JSON.stringify({messages:current.messages.length,sources:current.sources.length,persistedRequests:current.requests.length,records:observed.records.length,elapsedMs:Date.parse(settled.observedAtUtc)-birth,served:served[0].data.path,exit:0}))
