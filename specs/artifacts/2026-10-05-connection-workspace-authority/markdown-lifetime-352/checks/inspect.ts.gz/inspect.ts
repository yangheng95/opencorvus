import fs from 'node:fs'
import path from 'node:path'
const evidence=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/markdown-lifetime-352')
const run='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-12/markdown-lifetime-352-history-01'
const records=fs.readFileSync(path.join(run,'runtime/log/dev.log'),'utf8').split(/\r?\n/).filter(Boolean).map(x=>JSON.parse(x)).filter(x=>x.service==='overlay:markdown-352').map(x=>({event:x.message,...x.data})).sort((a,b)=>a.sequence-b.sequence)
const actions=JSON.parse(fs.readFileSync(path.join(evidence,'action-times.json'),'utf8'))
const summaries=actions.map((action:any,index:number)=>{
 const start=Date.parse(action.at),end=index+1<actions.length?Date.parse(actions[index+1].at):Infinity
 const rows=records.filter(x=>Date.parse(x.at)>=start&&Date.parse(x.at)<end)
 const counts=Object.fromEntries(['create','render','cache-hit','scheduled','reply','mount','dispose'].map(event=>[event,rows.filter(x=>x.event===event).length]))
 const waitOwners=rows.filter(x=>x.event==='scheduled'&&x.blocks===0).map(x=>{const mounted=records.find(m=>m.owner===x.owner&&m.revision===x.revision&&m.event==='mount'&&m.blocks>0&&m.sequence>x.sequence);return{owner:x.owner,textStart:x.textStart,chars:x.chars,scheduledAt:x.at,firstMountedAt:mounted?.at,elapsedMs:mounted?Date.parse(mounted.at)-Date.parse(x.at):null}})
 return{...action,counts,emptyScheduledOwners:waitOwners,sequenceStart:rows[0]?.sequence,sequenceEnd:rows.at(-1)?.sequence}
})
fs.writeFileSync(path.join(evidence,'diagnostic-observations.json'),JSON.stringify({observedAt:new Date().toISOString(),records,summaries,qualification:'Actual AppLog records only; pending or a scheduled empty model does not prove a painted placeholder. See the actual screenshots separately.'},null,2)+'\n')
console.log(JSON.stringify(summaries.map((x:any)=>({...x,emptyScheduledOwners:x.emptyScheduledOwners.map((y:any)=>({owner:y.owner,chars:y.chars,ms:y.elapsedMs,text:y.textStart.slice(0,25)}))}))))
