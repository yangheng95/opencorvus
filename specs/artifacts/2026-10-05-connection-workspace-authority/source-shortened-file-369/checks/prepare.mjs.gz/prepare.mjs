import fs from 'node:fs'
import path from 'node:path'
const stage=process.argv[2]
if(!['before','after'].includes(stage))throw Error('Exact declared stage required')
const run=`C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/source-shortened-file-369-${stage}`
const evidence=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/source-shortened-file-369',stage)
const ready=JSON.parse(fs.readFileSync(path.join(run,'evidence/preflight-ready.json'),'utf8'))
if(ready.preflight.credential!=='usable'||ready.preflight.catalog!=='projected'||ready.preflight.actualModel!=='gpt-6.1-sol'||!ready.preflight.streaming)throw Error('Actual qualification required')
const file=path.join(run,'project/资料/历史引用.md')
const original=Array.from({length:39},(_,i)=>`原始记录${i+1}`).join('\n')+'\nbefore中😀MATCH369_历史来源'
const shortened='顶部可编辑。\n末尾记录。'
fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,original,{flag:'wx'})
fs.mkdirSync(evidence,{recursive:true});fs.writeFileSync(path.join(evidence,'authored-inputs.json'),JSON.stringify({stage,path:file,original,shortened,line:40,column:10},null,2)+'\n',{flag:'wx'})
fs.writeFileSync(path.resolve('.tmp-product-iteration/source-shortened-file-369',stage,'main-request.txt'),'请实际用 search_code 在“资料/历史引用.md”搜索 MATCH369，保留工具返回的真实来源。用一句话说明找到了几行，不修改文件、不创建任务、不调用成员，也不再读取其他内容。',{flag:'wx'})
console.log(JSON.stringify({stage,file,line:40,column:10}))
