import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import {Database} from 'bun:sqlite'
const evidence=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/source-shortened-file-369')
const results=[]
for(const [stage,handle,asset] of [['before',11707,'main-aBfB0VSj.js'],['after',17567,'main-BR2lLe8z.js']] as const){
 const folder=path.join(evidence,stage),label='source-shortened-file-369-'+stage
 const read=(name:string)=>JSON.parse(fs.readFileSync(path.join(folder,name),'utf8'))
 const input=read('authored-inputs.json'),change=read('owned-file-change.json'),canonical=read('canonical-current-conversations.json')
 assert.equal(change.original,input.original);assert.equal(change.shortened,input.shortened)
 assert.equal(input.original.split('\n').length,40);assert.equal(input.shortened.split('\n').length,2)
 const expectedDisk=stage==='after'?read('owned-file-restore.json').restored:input.shortened
 assert.equal(expectedDisk,stage==='after'?input.original:input.shortened)
 assert.deepEqual(fs.readFileSync(input.path),Buffer.from(expectedDisk))
 const run=`C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/${label}`
 const db=new Database(path.join(run,'runtime/data/opencorvus.db'),{readonly:true})
 let rows:any[]
 try{db.exec('BEGIN');rows=(db.query("SELECT p.id,p.message_id,m.session_id,p.data FROM part p JOIN message m ON m.id=p.message_id WHERE json_extract(p.data,'$.type')='source-file'").all() as any[]).map(r=>({...r,data:JSON.parse(r.data)}))}finally{db.exec('ROLLBACK');db.close()}
 assert.equal(rows.length,1);assert.deepEqual(rows[0],change.source)
 const source=rows[0].data
 assert.equal(source.path,path.resolve(input.path));assert.deepEqual(source.range,{startLine:40,endLine:40,startColumn:10})
 assert.equal(source.snippet,input.original.split('\n')[39]);assert.equal(source.provider,'opencorvus-search-code')
 assert.deepEqual(canonical.parts.find((p:any)=>p.id===rows[0].id).range,source.range)
 assert.equal(canonical.tools.length,1)
 const tool=canonical.tools[0],request=JSON.parse(tool.data)
 assert.equal(tool.message_id,rows[0].message_id);assert.equal(request.tool,'search_code')
 assert.deepEqual(request.input,{pattern:'MATCH369',path:'资料/历史引用.md'})
 const outcome=canonical.outcomes.find((o:any)=>o.requestPartID===tool.id)
 assert.equal(outcome.outcome,'completed');assert.equal(outcome.output,`Found 1 matches\n${source.path}:\n  Line 40: ${source.snippet}`)
 const completed=canonical.messages.filter((m:any)=>m.sessionID===rows[0].session_id&&m.role==='assistant'&&m.finish==='stop')
 assert.equal(completed.length,1);assert.equal(typeof completed[0].time.completed,'number')
 assert.equal(completed[0].time.completed<=Date.parse(change.beforeAt),true)
 const preflight=read(label+'-preflight-ready.json').preflight
 assert.deepEqual({credential:preflight.credential,catalog:preflight.catalog,actualModel:preflight.actualModel,streaming:preflight.streaming},{credential:'usable',catalog:'projected',actualModel:'gpt-6.1-sol',streaming:true})
 const provider=read(label+'-final-provider-audit.json');assert.deepEqual({requests:provider.requests.length,exhausted:provider.exhausted},{requests:5,exhausted:false})
 for(const r of provider.requests)assert.deepEqual({model:r.model,stream:r.streaming,status:r.status,reader:r.response_reader.state,terminal:r.response_reader.terminal.kind},{model:'gpt-6.1-sol',stream:true,status:200,reader:'settled',terminal:'eof'})
 const settled=read(label+'-native-host-settled.json')
 for(const key of ['physicalCompletion','outputDrainComplete','requestCleanupComplete'])assert.equal(settled[key],true)
 assert.deepEqual({reason:settled.terminal.reason,exit:settled.terminal.exitCode},{reason:'exited',exit:0})
 const qualified=read(label+'-qualified-surface-completion.json');assert.equal(qualified.qualification,'NativeService');assert.equal(qualified.providerEOFRequests,5);assert.equal(qualified.physicalCompletion,true)
 const cleanup=read(label+'-physical-terminal-and-pair-cleanup.json');assert.equal(cleanup.pairedCleanupComplete,true);assert.deepEqual(cleanup.copiedPair.map((e:any)=>e.outcome),['removed','removed'])
 const http=read(label+'-http-summary.json'),served=http.requests.find((r:any)=>r.data?.path==='/ui/assets/'+asset&&r.data?.status==='completed');assert.equal(served.data.statusCode,200)
 const birth=Number(BigInt(settled.target.processInstanceID.slice(6))/10000n-62135596800000n)
 results.push({stage,handle,launcherExit:0,sourceID:source.sourceId,sourcePartID:rows[0].id,sessionID:rows[0].session_id,range:source.range,originalFileChars:input.original.length,finalFileChars:expectedDisk.length,fileChangeAt:change.beforeAt,completedReplyAt:completed[0].time.completed,providerRequests:5,elapsedMs:Date.parse(settled.observedAtUtc)-birth,qualified,settled,served})
}
fs.mkdirSync(path.join(evidence,'checks'),{recursive:true})
fs.writeFileSync(path.join(evidence,'checks/runtime-qualification.json'),JSON.stringify({results,boundary:'Real canonical Source, completed ToolOutcome and reply precede owned file mutation; exact original Source remains after file mutation. Before disk remains shortened, after restored original for ordinary-reference control. Native qualification is separate from manual UI failure before and success after. No DOM/render/pixel assertions.'},null,2)+'\n')
console.log(JSON.stringify(results.map(r=>({stage:r.stage,requests:r.providerRequests,elapsedMs:r.elapsedMs,exit:r.launcherExit}))))
