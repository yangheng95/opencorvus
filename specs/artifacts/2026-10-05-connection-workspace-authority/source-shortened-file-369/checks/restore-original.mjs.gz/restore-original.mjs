import fs from 'node:fs'
import path from 'node:path'
const folder=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/source-shortened-file-369/after')
const input=JSON.parse(fs.readFileSync(path.join(folder,'authored-inputs.json'),'utf8'))
const root=path.resolve('C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/source-shortened-file-369-after/project')
const target=path.resolve(input.path)
if(!target.startsWith(root+path.sep)||fs.readFileSync(target,'utf8')!==input.shortened)throw Error('Exact owned shortened file required')
const beforeAt=new Date().toISOString()
fs.writeFileSync(target,input.original)
if(fs.readFileSync(target,'utf8')!==input.original)throw Error('Exact original file required')
fs.writeFileSync(path.join(folder,'owned-file-restore.json'),JSON.stringify({target,beforeAt,afterAt:new Date().toISOString(),restored:input.original},null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({target,lines:40,restored:true}))
