import fs from 'node:fs'
import path from 'node:path'
import {Database} from 'bun:sqlite'
const stage=process.argv[2]
if(!['before','after'].includes(stage))throw Error('Exact declared stage required')
const folder=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/source-shortened-file-369',stage)
const input=JSON.parse(fs.readFileSync(path.join(folder,'authored-inputs.json'),'utf8'))
const root=path.resolve(`C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/source-shortened-file-369-${stage}/project`)
const target=path.resolve(input.path)
if(!target.startsWith(root+path.sep)||fs.readFileSync(target,'utf8')!==input.original)throw Error('Exact owned original file required')
const db=new Database(path.join(path.dirname(root),'runtime/data/opencorvus.db'),{readonly:true})
let source
try{
 const rows=db.query("SELECT p.id,p.message_id,m.session_id,p.data FROM part p JOIN message m ON m.id=p.message_id WHERE json_extract(p.data,'$.type')='source-file' AND json_extract(p.data,'$.path')=?").all(target)
 if(rows.length!==1)throw Error('Exactly one real matching Source required before changing file')
 source={...rows[0],data:JSON.parse(rows[0].data)}
 if(source.data.range.startLine!==40||source.data.range.startColumn!==10)throw Error('Real original Source coordinate required')
 const completed=db.query("SELECT id FROM message WHERE session_id=? AND json_extract(data,'$.role')='assistant' AND json_extract(data,'$.finish')='stop' AND json_extract(data,'$.time.completed') IS NOT NULL").all(source.session_id)
 if(completed.length!==1)throw Error('Real completed reply required before file change')
}finally{db.close()}
const beforeAt=new Date().toISOString()
fs.writeFileSync(target,input.shortened)
if(fs.readFileSync(target,'utf8')!==input.shortened)throw Error('Exact shortened file required')
fs.writeFileSync(path.join(folder,'owned-file-change.json'),JSON.stringify({target,beforeAt,afterAt:new Date().toISOString(),source,original:input.original,shortened:input.shortened},null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({target,lines:2,changed:true}))
