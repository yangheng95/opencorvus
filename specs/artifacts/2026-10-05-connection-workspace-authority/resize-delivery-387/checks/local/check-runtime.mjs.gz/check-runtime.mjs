import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
const scratch=path.resolve('.tmp-product-iteration/resize-delivery-387')
const run='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/resize-delivery-387-before'
const read=p=>JSON.parse(fs.readFileSync(p,'utf8'))
const facts=read(path.join(scratch,'final.json'))
const sources=facts.parts.filter(p=>p.type==='source-file')
assert.equal(facts.tools.length,3);assert.equal(sources.length,3)
for(const tool of facts.tools){
 assert.equal(tool.tool,'read')
 assert.equal(tool.input.offset,2);assert.equal(tool.input.limit,2)
 const source=sources.find(s=>s.toolPartID===tool.id)
 assert.equal(source.messageID,tool.messageID)
 assert.equal(source.path.replaceAll('\\','/'),run+'/project/'+tool.input.filePath)
 assert.deepEqual(source.range,{startLine:2,endLine:3})
 const outcome=facts.outcomes.find(o=>o.requestPartID===tool.id)
 assert.equal(outcome.outcome,'completed')
 assert.equal(outcome.metadata.preview,fs.readFileSync(source.path,'utf8').split('\n').slice(1,3).join('\n'))
 const message=facts.messages.find(m=>m.id===tool.messageID)
 assert.equal(message.agent,'work')
 assert.equal(message.modelID,'gpt-6.1-sol')
 assert.equal(typeof message.time.completed,'number')
}
const preflight=read(path.join(run,'evidence/preflight-ready.json'))
assert.equal(preflight.preflight.credential,'usable');assert.equal(preflight.preflight.catalog,'projected')
assert.equal(preflight.preflight.actualModel,'gpt-6.1-sol');assert.equal(preflight.preflight.streaming,true)
const owner=read(path.join(run,'launch-owner.json')),native=read(path.join(run,'evidence/native-host-settled.json'))
const prefix=path.join(scratch,'before/resize-delivery-387-before')
const provider=read(prefix+'-final-provider-audit.json'),cleanup=read(prefix+'-physical-terminal-and-pair-cleanup.json'),qualified=read(prefix+'-qualified-surface-completion.json')
assert.equal(provider.maxRequests,20);assert.equal(provider.requests.length,7)
for(const r of provider.requests){assert.equal(r.model,'gpt-6.1-sol');assert.equal(r.streaming,true);assert.equal(r.status,200);assert.equal(r.response_reader.terminal.kind,'eof')}
assert.equal(native.occurrence,owner.occurrence);assert.equal(cleanup.occurrence,owner.occurrence)
assert.equal(native.terminal.reason,'exited');assert.equal(native.terminal.exitCode,0)
for(const key of ['physicalCompletion','outputDrainComplete','requestCleanupComplete'])assert.equal(native[key],true)
assert.equal(cleanup.pairedCleanupComplete,true)
assert.deepEqual(cleanup.copiedPair.map(p=>p.outcome),['removed','removed'])
assert.equal(qualified.qualification,'NativeService');assert.equal(qualified.providerEOFRequests,7)
const result={backendCanonicalSources:'passed',actualAgent:'work',toolCalls:3,sourceBindings:sources.map(s=>({id:s.id,messageID:s.messageID,toolPartID:s.toolPartID,path:s.path,range:s.range})),
 provider:{model:'gpt-6.1-sol',requests:7,stream:true,allHTTP200andEOF:true,budget:20},
 native:{terminal:native.terminal,physicalCompletion:true,pairedCleanupComplete:true,durationMilliseconds:Date.parse(native.observedAtUtc)-owner.targetBirthAtMs},
 launcherExit:0,qualified,
 visualBoundary:'Real page screenshots manually reviewed; this checker does not assert UI, callback diagnostics or original subagent flicker',
 remaining:['Original subagent Rendering placeholder flicker was not reproduced or resolved in this run.','386 first memory fetch failure remains its original failed scope.']}
fs.writeFileSync(path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/resize-delivery-387/runtime-review.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify(result))
