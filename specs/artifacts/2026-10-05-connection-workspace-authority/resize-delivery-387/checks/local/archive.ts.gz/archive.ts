import fs from 'node:fs'
import path from 'node:path'
import {gzipSync,gunzipSync} from 'node:zlib'
import {CredentialRedactor} from '../../packages/opencorvus/script/real-provider-audit'
const scratch=path.resolve('.tmp-product-iteration/resize-delivery-387')
const root=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/resize-delivery-387')
const run='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/resize-delivery-387-before'
const redactor=new CredentialRedactor()
redactor.collect(JSON.parse(fs.readFileSync('C:/Users/hengu/AppData/Local/opencorvus/data/auth.json','utf8')))
const files:any[]=[]
function pack(source:string,relative:string){
 const raw=Buffer.from(redactor.redact(fs.readFileSync(source,'utf8'))),packed=gzipSync(raw,{level:9})
 if(!gunzipSync(packed).equals(raw))throw Error('Complete archive bytes changed')
 const target=path.resolve(root,'checks',relative+'.gz')
 if(!target.startsWith(root+path.sep))throw Error('Archive escaped exact root')
 fs.mkdirSync(path.dirname(target),{recursive:true})
 fs.writeFileSync(target,packed,{flag:'wx'})
 files.push({source,archive:path.relative(root,target).replaceAll('\\','/'),redactedBytes:raw.length,compressedBytes:packed.length})
}
for(const entry of fs.readdirSync(scratch,{recursive:true,withFileTypes:true})){
 if(!entry.isFile()||!/\.(json|log|ts|mjs|ps1|js)$/.test(entry.name))continue
 const source=path.join(entry.parentPath,entry.name)
 pack(source,'local/'+path.relative(scratch,source))
}
for(const name of ['stdout.log','stderr.log','startup.json','launch-owner.json','runtime/log/dev.log'])pack(path.join(run,name),'runtime/'+name)
for(const entry of fs.readdirSync(path.join(run,'evidence'),{withFileTypes:true})){
 if(entry.isFile()&&entry.name.endsWith('.json'))pack(path.join(run,'evidence',entry.name),'runtime/evidence/'+entry.name)
}
for(const name of ['live-sol-resize-387-before.ts','live-sol-resize-387-before-launch.ps1','live-sol-resize-387-before-shutdown.ps1'])pack(path.resolve('.tmp-product-iteration',name),'launcher/'+name)
for(const name of ['push.log'])pack(path.resolve('.tmp-product-iteration/source-reopen-386',name),'previous-386/'+name)
for(const name of fs.readdirSync(path.join(run,'project/来源材料')))pack(path.join(run,'project/来源材料',name),'inputs/'+name)
pack('C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/resize-delivery-387-before-bundle/bin/ui/index.html','static-ui/index.html')
pack('C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/resize-delivery-387-before-bundle/bin/ui/assets/main-B704oHnd.js','static-ui/assets/main-B704oHnd.js')
for(const name of ['package.json','README.md','lib/solid/index.jsx'])pack(path.resolve('packages/overlay/node_modules/virtua',name),'installed-virtua/'+name)
fs.writeFileSync(path.join(root,'checks/archive-receipt.json'),JSON.stringify({files,integrity:'Every full redacted input equals its full decompressed archive; originals retained',qualification:'Archive completeness is separate from page review; native and Provider qualification passed; callback logs remain descriptive and original Rendering flicker is unresolved'},null,2)+'\n',{flag:'wx'})
let scanned=0
for(const entry of fs.readdirSync(root,{recursive:true,withFileTypes:true})){
 if(!entry.isFile()||entry.name.endsWith('.png'))continue
 const bytes=fs.readFileSync(path.join(entry.parentPath,entry.name))
 const text=(entry.name.endsWith('.gz')?gunzipSync(bytes):bytes).toString('utf8')
 if(redactor.containsCredential(text))throw Error('Credential in archived evidence')
 scanned++
}
fs.writeFileSync(path.join(root,'checks/credential-scan.json'),JSON.stringify({scanned,credentialMatches:0,scope:'Full text and complete decompressed archives; no credential files archived'},null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({archives:files.length,scanned,credentialMatches:0}))

