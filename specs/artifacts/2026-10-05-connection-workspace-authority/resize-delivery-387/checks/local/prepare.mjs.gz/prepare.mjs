import fs from 'node:fs'
import path from 'node:path'
const root=path.resolve('.tmp-product-iteration'),scratch=path.join(root,'resize-delivery-387')
for(const phase of ['before','after']){
 for(const suffix of ['launch.ps1','shutdown.ps1']){
  const old=fs.readFileSync(path.join(root,'live-sol-sources-386-'+suffix),'utf8')
  fs.writeFileSync(path.join(root,'live-sol-resize-387-'+phase+'-'+suffix),old.replaceAll('source-reopen-386','resize-delivery-387-'+phase).replaceAll('live-sol-sources-386','live-sol-resize-387-'+phase),{flag:'wx'})
 }
 fs.copyFileSync(path.join(root,'live-sol-sources-386.ts'),path.join(root,'live-sol-resize-387-'+phase+'.ts'),fs.constants.COPYFILE_EXCL)
 fs.mkdirSync(path.join(scratch,phase),{recursive:true})
 fs.mkdirSync(path.join(root,'resize-delivery-387-'+phase+'-native-observer'),{recursive:true})
}
fs.writeFileSync(path.join(scratch,'builtin.json'),JSON.stringify({kind:'builtin',id:'base',namespace:'builtin'}),{flag:'wx'})
console.log('Prepared fresh before/after native scopes; same reviewed lifecycle and Provider qualification')
