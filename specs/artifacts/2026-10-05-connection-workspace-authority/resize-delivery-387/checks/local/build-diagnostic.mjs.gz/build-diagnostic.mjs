import fs from 'node:fs'
import path from 'node:path'
import {build} from '../../packages/overlay/node_modules/vite/dist/node/index.js'
const workspace=process.cwd()
const phase=process.argv[2]
if(!['before','after'].includes(phase))throw Error('Exact private phase required')
const diagnostic=fs.readFileSync(path.join(workspace,'.tmp-product-iteration/resize-delivery-387/observe-resize.js'),'utf8')
process.chdir(path.join(workspace,'packages/overlay'))
await build({
 configFile:path.join(workspace,'packages/overlay/vite.config.ts'),
 plugins:[{name:'owned-manual-resize-observation',transformIndexHtml:{order:'pre',handler(html){return html.replace('<head>','<head><script>'+diagnostic+'</script>')}}}],
 build:{minify:false,outDir:`C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/resize-delivery-387-${phase}-bundle/bin/ui`},
})
