import fs from 'node:fs'
import path from 'node:path'
const scratch=path.resolve('.tmp-product-iteration/resize-delivery-387')
const raw=JSON.parse(fs.readFileSync(path.join(scratch,'before-observations-final.json'),'utf8'))
const callbacks=raw.filter(row=>row.message.startsWith('RO387_CALLBACK')).map(row=>JSON.parse(row.message.slice(row.message.indexOf('{'))))
const origins=Object.fromEntries(callbacks.filter(row=>row.creation).map(row=>[row.observer,{creation:row.creation,callback:row.callback,firstTargets:row.after}]))
const deliveries=raw.filter(row=>row.message.startsWith('RO387_DELIVERY')).map(row=>{
 const fact=JSON.parse(row.message.slice(row.message.indexOf('{')))
 const latest=fact.history.at(-1)
 return {at:fact.at,message:fact.message,lastCallback:latest?.observer,lastCallbackAt:latest?.at,
  millisecondsAfterCallback:latest?fact.at-latest.end:undefined,
  observedTargets:latest?.after,
  recentCallbacks:fact.history.filter(callback=>callback.at>fact.at-30).map(callback=>({observer:callback.observer,at:callback.at,changed:callback.changed,before:callback.before,after:callback.after}))}
})
const lastCallbacks={}
for(const row of deliveries)lastCallbacks[row.lastCallback]=(lastCallbacks[row.lastCallback]??0)+1
const result={boundary:'Descriptive analysis of passive logs from manually operated real page; no UI assertions, pass score or automated driver',
 logEntries:raw.length,callbackOrigins:origins,deliveryEvents:deliveries,lastCallbackFrequencies:lastCallbacks,
 callbacksWithSynchronousObservedBoxChange:callbacks.filter(row=>row.changed),
 phaseObservations:['start','file','resize','final'].map(phase=>{
  const rows=JSON.parse(fs.readFileSync(path.join(scratch,'before-observations-'+phase+'.json'),'utf8'))
  return {phase,entries:rows.length,deliveryEvents:rows.filter(row=>row.message.startsWith('RO387_DELIVERY')).length}
 }),
 inference:'Every observed delivery error follows the current Virtua resizer callback. Its synchronous store update publishes virtual list sizes. This agrees with the installed library code and upstream documented behavior; the trace does not demonstrate the original Rendering placeholder flicker.',
 limitations:['Recording layout boxes adds measurement overhead.','Observed box equality cannot rule out every descendant mutation or future callback path.','No production implementation change was justified by these notifications alone.']}
fs.writeFileSync(path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/resize-delivery-387/resize-observations.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({logEntries:raw.length,deliveries:deliveries.length,lastCallbackFrequencies:lastCallbacks,phases:result.phaseObservations}))
