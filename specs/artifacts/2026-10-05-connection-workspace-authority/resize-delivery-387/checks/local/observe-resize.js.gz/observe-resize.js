(() => {
  const NativeObserver = window.ResizeObserver
  let next = 0
  const history = []
  const describe = (target) => {
    const rect = target.getBoundingClientRect()
    return { node: target.tagName, id: target.id, class: typeof target.className === 'string' ? target.className : '',
      width: rect.width, height: rect.height, styleHeight: target.style?.height, connected: target.isConnected }
  }
  const record = (fact) => {
    history.push(fact)
    if (history.length > 40) history.shift()
  }
  window.ResizeObserver = class ObservedNativeResizeObserver extends NativeObserver {
    constructor(callback) {
      const observer = ++next
      const creation = new Error('Observer creation').stack
      let first = true
      super((entries, owner) => {
        const before = entries.map((entry) => ({ delivered: {width:entry.contentRect.width,height:entry.contentRect.height}, box:describe(entry.target) }))
        const started = performance.now()
        try { callback(entries, owner) }
        finally {
          const after = entries.map((entry) => describe(entry.target))
          const changed = before.some((entry,index) => entry.box.width !== after[index].width || entry.box.height !== after[index].height || entry.box.styleHeight !== after[index].styleHeight)
          const fact = { observer, at:started, end:performance.now(), before, after, changed }
          record(fact)
          if (first || changed) console.debug('RO387_CALLBACK', JSON.stringify({...fact, creation:first?creation:undefined,callback:first?String(callback):undefined}))
          first = false
        }
      })
    }
  }
  window.addEventListener('error', (event) => {
    if (event.message?.startsWith('ResizeObserver')) console.debug('RO387_DELIVERY', JSON.stringify({at:performance.now(),message:event.message,history}))
  })
  console.debug('RO387_READY', JSON.stringify({url:location.href,at:performance.now(),mode:'Observational callback logging; native API and original callbacks retained; manual UI only'}))
})()
