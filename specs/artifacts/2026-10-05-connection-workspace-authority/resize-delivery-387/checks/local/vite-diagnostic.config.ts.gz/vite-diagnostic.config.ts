import fs from 'node:fs'
import path from 'node:path'
import {mergeConfig} from 'vite'
import base from '../../packages/overlay/vite.config'
const diagnostic=fs.readFileSync(path.resolve(import.meta.dirname,'observe-resize.js'),'utf8')
export default mergeConfig(base,{
 plugins:[{name:'owned-manual-resize-observation',transformIndexHtml:{order:'pre',handler(html:string){return html.replace('<head>','<head><script>'+diagnostic+'</script>')}}}],
 build:{minify:false},
})
