import fs from 'node:fs'
import path from 'node:path'
const stage=process.argv[2]
if(!['before','after'].includes(stage))throw Error('Exact declared stage required')
const run=`C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/source-colon-range-373-${stage}`
const ready=JSON.parse(fs.readFileSync(path.join(run,'evidence/preflight-ready.json'),'utf8')).preflight
if(ready.credential!=='usable'||ready.catalog!=='projected'||ready.actualModel!=='gpt-6.1-sol'||!ready.streaming)throw Error('Provider qualification required')
const file=path.join(run,'project/资料/范围示例.txt')
const text=Array.from({length:40},(_,i)=>i===19?'前😀RANGE373_BEGIN':i===20?'范围第二行':i===21?'RANGE373_END':`记录第${i+1}行`).join('\n')
fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,text,{flag:'wx'})
const evidence=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/source-colon-range-373',stage)
fs.mkdirSync(evidence,{recursive:true});fs.writeFileSync(path.join(evidence,'authored-inputs.json'),JSON.stringify({path:file,text,range:{startLine:20,endLine:22}},null,2)+'\n',{flag:'wx'})
const scratch=path.resolve('.tmp-product-iteration/source-colon-range-373',stage)
fs.writeFileSync(path.join(scratch,'main-request.txt'),'请实际read文件“资料/范围示例.txt”，offset=20、limit=3，保留真实来源。随后输出下面五项Markdown列表，保留格式和目标：\n- 行内范围：`资料/范围示例.txt:20-22`\n- [正文范围](资料/范围示例.txt:20-22)\n- 绝对范围：`'+file+':20-22`\n- [锚点对照](资料/范围示例.txt#L20-L22)\n- [列号对照](资料/范围示例.txt:20:4)\n不要修改文件、不创建任务、不调用成员。',{flag:'wx'})
fs.writeFileSync(path.join(scratch,'side-request.txt'),'请在本侧聊实际read“资料/范围示例.txt”，offset=20、limit=3，保留真实来源。最后只输出：`资料/范围示例.txt:20-22` 和Markdown链接 [侧聊范围](资料/范围示例.txt:20-22)。不要修改文件、创建任务或调用成员。',{flag:'wx'})
console.log(JSON.stringify({stage,file,range:{startLine:20,endLine:22}}))
