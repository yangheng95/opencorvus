import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
const root=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/source-colon-range-373')
const results=[]
for(const stage of ['before','after']){
 const dir=path.join(root,stage),prefix='source-colon-range-373-'+stage,read=(name:string)=>JSON.parse(fs.readFileSync(path.join(dir,name),'utf8'))
 const input=read('authored-inputs.json'),canonical=read('canonical-current-conversations.json'),sources=canonical.parts.filter((p:any)=>p.type==='source-file')
 assert.equal(sources.length,stage==='before'?1:3);assert.equal(canonical.tools.length,sources.length)
 assert.deepEqual(fs.readFileSync(input.path),Buffer.from(input.text))
 const sessions=new Set<string>(),calls=[]
 for(const source of sources){
  assert.equal(source.path,path.resolve(input.path));assert.deepEqual(source.range,{startLine:20,endLine:22});assert.equal(source.provider,'opencorvus-read')
  const tool=canonical.tools.find((t:any)=>t.message_id===source.messageID),request=JSON.parse(tool.data)
  assert.equal(request.tool,'read');assert.deepEqual(request.input,{filePath:'资料/范围示例.txt',offset:20,limit:3})
  const outcome=canonical.outcomes.find((o:any)=>o.requestPartID===tool.id);assert.equal(outcome.outcome,'completed')
  assert.equal(outcome.output,`<path>${input.path}</path>\n<type>file</type>\n<content>20: 前😀RANGE373_BEGIN\n21: 范围第二行\n22: RANGE373_END\n\n(Showing lines 20-22 of 40. Use offset=23 to continue.)\n</content>`)
  const message=canonical.messages.find((m:any)=>m.id===source.messageID);assert.ok(message);sessions.add(message.sessionID)
  calls.push({sourceID:source.sourceId,partID:source.id,messageID:source.messageID,sessionID:message.sessionID,callID:request.callID})
 }
 assert.equal(sessions.size,stage==='before'?1:2)
 if(stage==='after'){assert.equal(new Set(calls.map(c=>c.sourceID)).size,1);assert.equal(new Set(calls.map(c=>c.callID)).size,2)}
 const completed=canonical.messages.filter((m:any)=>sessions.has(m.sessionID)&&m.role==='assistant'&&m.finish==='stop')
 assert.equal(completed.length,stage==='before'?1:3)
 for(const message of completed)assert.equal(typeof message.time.completed,'number')
 const preflight=read(prefix+'-preflight-ready.json').preflight
 assert.deepEqual({credential:preflight.credential,catalog:preflight.catalog,model:preflight.actualModel,stream:preflight.streaming},{credential:'usable',catalog:'projected',model:'gpt-6.1-sol',stream:true})
 const provider=read(prefix+'-final-provider-audit.json');assert.equal(provider.exhausted,false);assert.ok(provider.requests.length>0&&provider.requests.length<=12)
 for(const r of provider.requests)assert.deepEqual({model:r.model,stream:r.streaming,status:r.status,reader:r.response_reader.state,terminal:r.response_reader.terminal.kind},{model:'gpt-6.1-sol',stream:true,status:200,reader:'settled',terminal:'eof'})
 const settled=read(prefix+'-native-host-settled.json')
 for(const key of ['physicalCompletion','outputDrainComplete','requestCleanupComplete'])assert.equal(settled[key],true)
 assert.deepEqual({reason:settled.terminal.reason,exit:settled.terminal.exitCode},{reason:'exited',exit:0})
 const qualified=read(prefix+'-qualified-surface-completion.json');assert.equal(qualified.qualification,'NativeService');assert.equal(qualified.providerEOFRequests,provider.requests.length)
 const cleanup=read(prefix+'-physical-terminal-and-pair-cleanup.json');assert.equal(cleanup.pairedCleanupComplete,true);assert.deepEqual(cleanup.copiedPair.map((e:any)=>e.outcome),['removed','removed'])
 const http=read(prefix+'-http-summary.json'),asset=stage==='before'?'main--IPEAIl1.js':'main-B5ENb1Oe.js'
 const served=http.requests.find((r:any)=>r.data?.path==='/ui/assets/'+asset&&r.data?.status==='completed');assert.equal(served.data.statusCode,200)
 const birth=Number(BigInt(settled.target.processInstanceID.slice(6))/10000n-62135596800000n)
 results.push({stage,sessions:[...sessions],calls,completed,requests:provider.requests.length,elapsedMs:Date.parse(settled.observedAtUtc)-birth,settled,qualified,served})
}
fs.mkdirSync(path.join(root,'checks'),{recursive:true})
fs.writeFileSync(path.join(root,'checks/runtime-qualification.json'),JSON.stringify({results,boundary:'Actual Provider/Native/Source/completed Message/ToolOutcome/input file and HTTP facts. Main and sequential product Side UI activation are independently reviewed screenshots, not UI assertions. Native external editor and first-use clipboard behavior are outside this qualification.'},null,2)+'\n')
console.log(JSON.stringify(results.map(r=>({stage:r.stage,sources:r.calls.length,requests:r.requests,elapsedMs:r.elapsedMs,exit:0}))))
