import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
const root=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/source-line-endings-371/after')
const input=JSON.parse(fs.readFileSync(path.join(root,'authored-inputs.json'),'utf8')).find(x=>x.name==='mixed')
const expected=Buffer.from('x'+input.text),actual=fs.readFileSync(input.path)
assert.deepEqual(actual,expected)
const next=Buffer.from(actual.toString('utf8').replace(/\r\n|\r/g,'\n'))
const staged=input.path+'.371-format-reload'
fs.writeFileSync(staged,next,{flag:'wx'});fs.renameSync(staged,input.path)
fs.writeFileSync(path.join(root,'format-only-external-write.json'),JSON.stringify({path:input.path,before:actual.toString('utf8'),after:next.toString('utf8'),observedAt:new Date().toISOString()},null,2)+'\n',{flag:'wx'})
console.log('Owned mixed file rewritten to LF after full prior-byte equality; text unchanged.')
