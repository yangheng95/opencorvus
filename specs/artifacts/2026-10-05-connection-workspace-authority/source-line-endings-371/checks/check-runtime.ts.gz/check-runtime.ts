import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
const root=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/source-line-endings-371')
const results=[]
for(const stage of ['before','after']){
 const dir=path.join(root,stage),prefix='source-line-endings-371-'+stage,read=(name:string)=>JSON.parse(fs.readFileSync(path.join(dir,name),'utf8'))
 const inputs=read('authored-inputs.json'),canonical=read('canonical-current-conversations.json'),sources=canonical.parts.filter((p:any)=>p.type==='source-file')
 assert.equal(sources.length,4);assert.equal(canonical.tools.length,1)
 const request=JSON.parse(canonical.tools[0].data)
 assert.deepEqual({tool:request.tool,input:request.input},{tool:'search_code',input:{pattern:'MATCH371',path:'格式'}})
 for(const source of sources){
  const input=inputs.find((i:any)=>path.resolve(i.path)===path.resolve(source.path));assert.ok(input)
  assert.equal(source.provider,'opencorvus-search-code')
  assert.deepEqual(source.range,input.name==='cr'?{startLine:1,endLine:1,startColumn:10}:{startLine:2,endLine:2,startColumn:1})
  assert.equal(source.snippet,input.name==='cr'?input.text:`MATCH371 ${input.name}`)
 }
 const outcome=canonical.outcomes.find((o:any)=>o.requestPartID===canonical.tools[0].id)
 assert.equal(outcome.outcome,'completed');assert.equal(outcome.output,'Found 4 matches\n'+sources.map((s:any)=>`${s.path}:\n  Line ${s.range.startLine}: ${s.snippet}`).join('\n\n'))
 const session=canonical.messages.find((m:any)=>m.id===sources[0].messageID).sessionID
 const completed=canonical.messages.filter((m:any)=>m.sessionID===session&&m.role==='assistant'&&m.finish==='stop')
 assert.equal(completed.length,1);assert.equal(typeof completed[0].time.completed,'number')
 const preflight=read(prefix+'-preflight-ready.json').preflight
 assert.deepEqual({credential:preflight.credential,catalog:preflight.catalog,model:preflight.actualModel,stream:preflight.streaming},{credential:'usable',catalog:'projected',model:'gpt-6.1-sol',stream:true})
 const provider=read(prefix+'-final-provider-audit.json');assert.equal(provider.exhausted,false);assert.equal(provider.requests.length,5)
 for(const r of provider.requests)assert.deepEqual({model:r.model,stream:r.streaming,status:r.status,reader:r.response_reader.state,terminal:r.response_reader.terminal.kind},{model:'gpt-6.1-sol',stream:true,status:200,reader:'settled',terminal:'eof'})
 const settled=read(prefix+'-native-host-settled.json')
 for(const key of ['physicalCompletion','outputDrainComplete','requestCleanupComplete'])assert.equal(settled[key],true)
 assert.deepEqual({reason:settled.terminal.reason,exit:settled.terminal.exitCode},{reason:'exited',exit:0})
 const qualified=read(prefix+'-qualified-surface-completion.json');assert.equal(qualified.qualification,'NativeService');assert.equal(qualified.providerEOFRequests,5)
 const cleanup=read(prefix+'-physical-terminal-and-pair-cleanup.json');assert.equal(cleanup.pairedCleanupComplete,true);assert.deepEqual(cleanup.copiedPair.map((e:any)=>e.outcome),['removed','removed'])
 const saved=read(stage==='before'?'saved-files.json':'01-saved-files.json')
 for(const record of saved.results){const input=inputs.find((i:any)=>i.name===record.name);const expected='x'+(stage==='before'?input.text.replace(/\r\n|\r/g,'\n'):input.text);assert.deepEqual(Buffer.from(record.base64,'base64'),Buffer.from(expected))}
 const historyFiles=[]
 if(stage==='after'){
  const input=inputs.find((i:any)=>i.name==='mixed'),original='x'+input.text
  const expectations={
   '02-deleted-files':original.replace('\r\n',''),
   '03-undo-files':original,
   '04-redo-files':original.replace('\r\n',''),
   '05-inserted-files':original.replace('\r\n','\r\nz\r\n'),
   '06-insert-undone-files':original,
   '07-format-undo-files':original,
   '08-format-redo-files':original.replace(/\r\n|\r/g,'\n'),
   '09-final-files':original,
  }
  for(const [name,expected] of Object.entries(expectations)){
   const receipt=read(name+'.json'),record=receipt.results.find((r:any)=>r.name==='mixed')
   assert.deepEqual(Buffer.from(record.base64,'base64'),Buffer.from(expected))
   historyFiles.push({name,observedAt:receipt.observedAt,record})
  }
  const external=read('format-only-external-write.json');assert.equal(external.before,original);assert.equal(external.after,original.replace(/\r\n|\r/g,'\n'))
 }
 for(const input of inputs){const expected='x'+(stage==='before'?input.text.replace(/\r\n|\r/g,'\n'):input.text);assert.deepEqual(fs.readFileSync(input.path),Buffer.from(expected))}
 const http=read(prefix+'-http-summary.json'),asset=stage==='before'?'main-w4chjmbj.js':'main--IPEAIl1.js'
 const served=http.requests.find((r:any)=>r.data?.path==='/ui/assets/'+asset&&r.data?.status==='completed');assert.equal(served.data.statusCode,200)
 const birth=Number(BigInt(settled.target.processInstanceID.slice(6))/10000n-62135596800000n)
 results.push({stage,session,sources,completed,requests:provider.requests.length,elapsedMs:Date.parse(settled.observedAtUtc)-birth,settled,qualified,saved,historyFiles,served})
}
fs.mkdirSync(path.join(root,'checks'),{recursive:true})
fs.writeFileSync(path.join(root,'checks/runtime-qualification.json'),JSON.stringify({results,boundary:'Actual Provider/Native/completed canonical messages and search outcomes plus complete file bytes only. Screenshots and keyboard history are manual evidence, without UI assertions. CR-only source location retains ripgrep coordinates; separate unresolved coordinate candidate.'},null,2)+'\n')
console.log(JSON.stringify(results.map(r=>({stage:r.stage,sources:r.sources.length,requests:r.requests,elapsedMs:r.elapsedMs,exit:0}))))
