import fs from 'node:fs'
import path from 'node:path'
const [stage,label]=process.argv.slice(2)
if(!['before','after'].includes(stage)||!label||!/^[a-z0-9-]+$/.test(label))throw Error('Exact stage and receipt required')
const root=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/source-line-endings-371',stage)
const inputs=JSON.parse(fs.readFileSync(path.join(root,'authored-inputs.json'),'utf8'))
const results=inputs.map(input=>{const bytes=fs.readFileSync(input.path),text=bytes.toString('utf8');return {name:input.name,path:input.path,bytes:bytes.length,base64:bytes.toString('base64'),text,separators:text.match(/\r\n|\r|\n/g)||[],equalsOriginal:bytes.equals(Buffer.from(input.text)),equalsSingleEdit:bytes.equals(Buffer.from('x'+input.text))}})
fs.writeFileSync(path.join(root,label+'.json'),JSON.stringify({observedAt:new Date().toISOString(),results},null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify(results.map(({name,separators,equalsOriginal,equalsSingleEdit})=>({name,separators,equalsOriginal,equalsSingleEdit}))))
