import fs from 'node:fs'
import path from 'node:path'
const stage=process.argv[2]
if(!['before','after'].includes(stage))throw Error('Exact declared stage required')
const run=`C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/source-line-endings-371-${stage}`
const ready=JSON.parse(fs.readFileSync(path.join(run,'evidence/preflight-ready.json'),'utf8')).preflight
if(ready.credential!=='usable'||ready.catalog!=='projected'||ready.actualModel!=='gpt-6.1-sol'||!ready.streaming)throw Error('Provider qualification required')
const endings={crlf:['\r\n','\r\n','\r\n'],lf:['\n','\n','\n'],cr:['\r','\r','\r'],mixed:['\r\n','\n','\r']}
const inputs=Object.entries(endings).map(([name,separators])=>{
 const text=`alpha ${name}${separators[0]}MATCH371 ${name}${separators[1]}gamma${separators[2]}omega`
 const file=path.join(run,'project/格式',name+'.txt')
 fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,text,{flag:'wx'})
 return {name,path:file,text,separators}
})
const evidence=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/source-line-endings-371',stage)
fs.mkdirSync(evidence,{recursive:true});fs.writeFileSync(path.join(evidence,'authored-inputs.json'),JSON.stringify(inputs,null,2)+'\n',{flag:'wx'})
fs.writeFileSync(path.resolve('.tmp-product-iteration/source-line-endings-371',stage,'main-request.txt'),'请实际使用 search_code 在“格式”目录搜索 MATCH371，保留真实文件来源。只需简短回复找到的文件；不要修改文件，不创建任务，不调用成员。',{flag:'wx'})
console.log(JSON.stringify({stage,files:inputs.map(x=>x.path)}))
