$ErrorActionPreference='Stop'
$repo365='D:/myhexin-local/opencorvus'
$source365='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-09/source-stream-review-238-live-01'
$out365=Join-Path $repo365 'specs/artifacts/2026-10-05-connection-workspace-authority/source-excerpt-hidden-365/readiness'
. (Join-Path $repo365 '.tmp-product-iteration/live-sol-launch.ps1') -FunctionsOnly
$owner365=Get-Content -Raw (Join-Path $source365 'launch-owner.json')|ConvertFrom-Json -AsHashtable -DateKind String
$states365=@(@{expected=$owner365.host;state=(Get-OwnedNativeState $owner365.host)},@{expected=$owner365.nativeTarget;state=(Get-OwnedNativeState $owner365.nativeTarget)})
$listeners365=@(Get-NetTCPConnection -State Listen -ErrorAction Stop|Where-Object {$_.LocalPort -in @($owner365.port,18365)})
$pair365=@('auth.json','models.json'|ForEach-Object{@{name=$_;present=(Test-Path -LiteralPath (Join-Path $source365 ('runtime/data/'+$_)))}})
$native365=Get-OwnedNativeSettlement $owner365
$physical365=Get-Content -Raw (Join-Path $owner365.settlementEvidenceRoot ($owner365.evidencePrefix+'-physical-terminal-and-pair-cleanup.json'))|ConvertFrom-Json -AsHashtable -DateKind String
if(@($states365|Where-Object state -ne 'dead_or_reused').Count -or $listeners365.Count -or @($pair365|Where-Object present).Count -or !$native365 -or $physical365.occurrence -cne $owner365.occurrence -or !$native365.physicalCompletion -or !$native365.outputDrainComplete -or !$native365.requestCleanupComplete -or !$physical365.pairedCleanupComplete){throw 'Original complete physical closure required'}
Write-OwnedLaunchFact (Join-Path $out365 'guard.json') @{readQualified=$true;sourceRun=$source365;occurrence=$owner365.occurrence;observedAtUtc=[DateTime]::UtcNow.ToString('o');states=$states365;listenerCount=$listeners365.Count;pair=$pair365;native=$native365;physical=$physical365;boundary='Original238 current closed runtime, complete history readonly review only; original UI failure and original native terminal retained'}
Write-Output 'Exact original238 closure qualified for readonly startup review.'
