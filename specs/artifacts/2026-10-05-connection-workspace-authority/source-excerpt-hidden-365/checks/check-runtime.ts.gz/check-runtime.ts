import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import {Database} from 'bun:sqlite'
const source='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-09/source-stream-review-238-live-01'
const run='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/source-excerpt-hidden-365-before'
const root=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/source-excerpt-hidden-365')
const folder=path.join(root,'before'),label='source-excerpt-hidden-365-before'
function facts(root:string){const db=new Database(path.join(root,'runtime/data/opencorvus.db'),{readonly:true});try{db.exec('BEGIN');return{
 messages:db.query('SELECT id,session_id,data FROM message ORDER BY id').all(),
 sources:db.query("SELECT p.id,p.message_id,m.session_id,p.data FROM part p JOIN message m ON m.id=p.message_id WHERE json_extract(p.data,'$.type') IN ('source-file','source-url','source-document') ORDER BY p.id").all(),
 provider:db.query('SELECT * FROM provider_activity_request ORDER BY id').all(),
}}finally{db.exec('ROLLBACK');db.close()}}
const original=facts(source),current=facts(run)
assert.deepEqual(current,original);assert.equal(current.sources.length,12);assert.equal(current.messages.length,12)
const read=(file:string)=>JSON.parse(fs.readFileSync(path.join(folder,file),'utf8'))
const settled=read(label+'-native-host-settled.json')
for(const key of ['physicalCompletion','outputDrainComplete','requestCleanupComplete'])assert.equal(settled[key],true)
assert.equal(settled.terminal.reason,'exited');assert.equal(settled.terminal.exitCode,0)
const http=read(label+'-http-summary.json')
const served=http.requests.find((r:any)=>r.data?.path==='/ui/assets/main-C_UK_gz4.js'&&r.data?.status==='completed')
assert.equal(served.data.statusCode,200)
const cleanup=read(label+'-physical-terminal-and-pair-cleanup.json');assert.equal(cleanup.physicalCompletion,true);assert.equal(cleanup.pairedCleanupComplete,true)
const baseline=JSON.parse(fs.readFileSync(path.join(root,'readiness/result-task-startup.json'),'utf8'))
function inventory(root:string):any[]{const info=fs.lstatSync(root);if(info.isSymbolicLink())throw Error('Original project link requires review');return info.isDirectory()?[{path:root,type:'directory',mtimeMs:info.mtimeMs},...fs.readdirSync(root).sort().flatMap(name=>inventory(path.join(root,name)))]:[{path:root,type:'file',bytes:info.size,mtimeMs:info.mtimeMs}]}
const projects=baseline.projectObservations.map((p:any)=>{
 const after=inventory(p.worktree),left=new Map(p.inventory.map((x:any)=>[x.path,x])),changes=after.filter(x=>JSON.stringify(x)!==JSON.stringify(left.get(x.path)))
 assert.deepEqual(after.map(x=>({path:x.path,type:x.type,bytes:x.bytes})),p.inventory.map((x:any)=>({path:x.path,type:x.type,bytes:x.bytes})))
 return {id:p.id,path:p.worktree,entries:after.length,attributeChanges:changes.map(x=>({before:left.get(x.path),after:x}))}
})
const birth=Number(BigInt(settled.target.processInstanceID.slice(6))/10000n-62135596800000n)
const result={checkedAt:new Date().toISOString(),source,run,initialHandle:32275,launcherExitCode:0,canonicalMessageCount:current.messages.length,canonicalSourceCount:current.sources.length,providerRequestRows:current.provider.length,elapsedMs:Date.parse(settled.observedAtUtc)-birth,settled,served,projects,boundary:'Actual readonly SQLite complete rows equal the original: Message, Source and Provider requests. Same actual frontend asset HTTP200 and production Native/output/request/credentialless closure. Project names/types/lengths equal; full attribute differences listed for manual review, not content-integrity evidence. Manual UI screenshots are separate and have no assertions.'}
fs.mkdirSync(path.join(root,'checks'),{recursive:true})
fs.writeFileSync(path.join(root,'checks/runtime-qualification.json'),JSON.stringify(result,null,2)+'\n')
fs.writeFileSync(path.join(folder,'canonical-sources.json'),JSON.stringify(current.sources,null,2)+'\n')
console.log(JSON.stringify({messages:current.messages.length,sources:current.sources.length,providerRequestRows:current.provider.length,elapsedMs:result.elapsedMs,projects:projects.map(p=>({id:p.id,entries:p.entries,changes:p.attributeChanges})),exit:0}))
