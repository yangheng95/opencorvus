import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import { Database } from 'bun:sqlite'
const run='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/source-preview-364'
const evidence=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/source-preview-364')
const folder=path.join(evidence,'live'),label='source-preview-364-live'
const read=(name:string)=>JSON.parse(fs.readFileSync(path.join(folder,name),'utf8'))
const canonical=read('canonical-current-conversations.json')
const inputs=JSON.parse(fs.readFileSync(path.join(evidence,'authored-inputs.json'),'utf8'))
for(const file of inputs.files) assert.equal(fs.readFileSync(file.path,'utf8'),file.lines.join('\n')+'\n')
const db=new Database(path.join(run,'runtime/data/opencorvus.db'),{readonly:true})
let actualSources:any[]
try {
  db.exec('BEGIN')
  actualSources=(db.query("SELECT p.id,p.message_id,m.session_id,p.data FROM part p JOIN message m ON m.id=p.message_id WHERE json_extract(p.data,'$.type')='source-file' ORDER BY p.time_created,p.id").all() as any[]).map(row=>({...row,data:JSON.parse(row.data)}))
} finally {db.exec('ROLLBACK');db.close()}
assert.equal(actualSources.length,22)
const surfaces=[
  {name:'main',sessionID:'ses_-zUS7lxeLzzLvY0MZQ5S',messageID:'msg_g0VXsE2iz00dLzm9wksR',count:10,pattern:'SOURCE364'},
  {name:'side-reference',sessionID:'ses_-zUS7krmIzzCecO34wil',messageID:'msg_g0VXsF8Di01XKYo8ghPA',count:10,pattern:'SOURCE364'},
  {name:'side-current',sessionID:'ses_-zUS7krmIzzCecO34wil',messageID:'msg_g0VXsFCBj00XpL6vV5Lw',count:2,pattern:'SOURCE364.*记录01'},
]
const sourceResults=[]
for(const surface of surfaces){
  const request=canonical.tools.find((t:any)=>t.message_id===surface.messageID)
  const data=JSON.parse(request.data)
  assert.equal(data.tool,'search_code')
  assert.deepEqual(data.input,{pattern:surface.pattern,path:'资料/匹配预览',include:'*.md'})
  const outcome=canonical.outcomes.find((o:any)=>o.requestPartID===request.id)
  assert.equal(outcome.outcome,'completed')
  assert.equal(outcome.output.split('\n')[0],`Found ${surface.count} matches`)
  const sources=actualSources.filter(s=>s.message_id===surface.messageID)
  assert.equal(sources.length,surface.count)
  for(const row of sources){
    assert.equal(row.session_id,surface.sessionID)
    const source=row.data,file=inputs.files.find((f:any)=>f.path===source.path)
    assert.ok(file)
    assert.deepEqual(source.range,{startLine:source.range.startLine,endLine:source.range.startLine})
    assert.equal(source.provider,'opencorvus-search-code')
    const line=source.range.startLine,raw=file.lines[line-1]
    let expected=raw
    if(line===5) expected=raw.slice(0,2000)+'...'
    if(line===6) expected=raw.replace('data:text/plain;base64,YQ==','inline_binary_omitted(kind=data_url offset=21 media=text/plain payload_chars=4)')
    assert.equal(source.snippet,expected)
    const archived=canonical.parts.find((part:any)=>part.id===row.id)
    assert.equal(archived.snippet,source.snippet)
    assert.equal(outcome.output.includes(`  Line ${line}: ${expected}`),true)
  }
  sourceResults.push({...surface,requestPartID:request.id,toolOutputChars:outcome.output.length,files:[...new Set(sources.map(s=>s.data.path))],snippets:sources.map(s=>({partID:s.id,line:s.data.range.startLine,chars:s.data.snippet.length}))})
}
const projectSnippet=(rows:any[])=>rows.map(s=>({sourceId:s.data.sourceId,path:s.data.path,range:s.data.range,snippet:s.data.snippet}))
assert.deepEqual(projectSnippet(actualSources.filter(s=>s.message_id===surfaces[1].messageID)),projectSnippet(actualSources.filter(s=>s.message_id===surfaces[0].messageID)))
const preflight=read(label+'-preflight-ready.json')
assert.deepEqual(preflight.preflight,{sessionID:'ses_h5rpMHqJ9vJK8YfwiJHq',credential:'usable',catalog:'projected',actualModel:'gpt-6.1-sol',streaming:true})
const provider=read(label+'-final-provider-audit.json')
assert.equal(provider.requests.length,9)
for(const request of provider.requests){
  assert.equal(request.model,'gpt-6.1-sol');assert.equal(request.streaming,true);assert.equal(request.status,200)
  assert.equal(request.response_reader.terminal.kind,'eof');assert.equal(request.response_reader.state,'settled')
}
const settled=read(label+'-native-host-settled.json')
for(const key of ['physicalCompletion','outputDrainComplete','requestCleanupComplete'])assert.equal(settled[key],true)
assert.equal(settled.terminal.reason,'exited');assert.equal(settled.terminal.exitCode,0)
const qualified=read(label+'-qualified-surface-completion.json')
assert.equal(qualified.qualification,'NativeService');assert.equal(qualified.physicalCompletion,true);assert.equal(qualified.providerEOFRequests,9)
const cleanup=read(label+'-physical-terminal-and-pair-cleanup.json')
assert.equal(cleanup.pairedCleanupComplete,true)
assert.deepEqual(cleanup.copiedPair.map((entry:any)=>entry.outcome),['removed','removed'])
const http=read(label+'-http-summary.json')
const served=http.requests.find((r:any)=>r.data?.path==='/ui/assets/main-C_UK_gz4.js'&&r.data?.status==='completed')
assert.equal(served.data.statusCode,200)
const birth=Number(BigInt(settled.target.processInstanceID.slice(6))/10000n-62135596800000n)
const result={checkedAt:new Date().toISOString(),initialHandle:82701,launcherExitCode:0,sourceResults,requestCount:provider.requests.length,model:provider.model,qualification:qualified,elapsedMs:Date.parse(settled.observedAtUtc)-birth,settled,served,boundary:'Actual SQLite Source records, production ToolOutcome output and exact authored input files. Inherited Side reference copies distinguished from the new tool invocation. Actual provider reader EOF and production Native/output/request/authority closure. Visual review is separate manual evidence; no UI assertions.'}
fs.mkdirSync(path.join(evidence,'checks'),{recursive:true})
fs.writeFileSync(path.join(evidence,'checks/runtime-qualification.json'),JSON.stringify(result,null,2)+'\n')
console.log(JSON.stringify({sources:sourceResults.map(s=>({surface:s.name,count:s.count})),requests:result.requestCount,elapsedMs:result.elapsedMs,model:provider.model,exit:0}))
