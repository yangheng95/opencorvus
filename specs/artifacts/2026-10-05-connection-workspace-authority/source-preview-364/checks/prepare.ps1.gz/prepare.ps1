$ErrorActionPreference='Stop'
$run364='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/source-preview-364'
$ready364=Get-Content -Raw (Join-Path $run364 'evidence/preflight-ready.json')|ConvertFrom-Json
if($ready364.preflight.credential -ne 'usable' -or $ready364.preflight.catalog -ne 'projected' -or $ready364.preflight.actualModel -ne 'gpt-6.1-sol' -or !$ready364.preflight.streaming){throw 'Actual credential/model qualification required'}
$utf364=[Text.UTF8Encoding]::new($false)
$files364=@()
foreach($name364 in @('甲','乙')){
 $dir364=Join-Path $run364 ('project/资料/匹配预览/方案'+$name364)
 [IO.Directory]::CreateDirectory($dir364)|Out-Null
 $file364=Join-Path $dir364 '来源记录_真实匹配与完整位置.md'
 if(Test-Path -LiteralPath $file364){throw 'Fresh input required'}
 $lines364=@(
  '# 只读场景资料：来源中的匹配文字不代表界面验收通过。',
  ('SOURCE364 '+$name364+'记录01：预算变更由原需求文本确认，当前目录是方案'+$name364+'。'),
  ('    SOURCE364 '+$name364+'记录02：原始缩进、尾空白和 emoji 😀 都保留。  '+"`t "),
  ('SOURCE364 '+$name364+'记录03：<b>这里是文字，不执行 HTML</b>，原文件第4行。'),
  ('SOURCE364 '+$name364+'长记录：'+(('长行原文需要通过准确文件行号核对，预览只是便于辨认的片段。')*90)+'原行终点364'),
  ('SOURCE364 '+$name364+'记录05：内联样本 data:text/plain;base64,YQ== 只用于验证片段处理。')
 )
 [IO.File]::WriteAllText($file364,($lines364 -join "`n")+"`n",$utf364)
 $files364+=@{path=$file364;lines=$lines364}
}
$evidence364='D:/myhexin-local/opencorvus/specs/artifacts/2026-10-05-connection-workspace-authority/source-preview-364'
[IO.File]::WriteAllText((Join-Path $evidence364 'authored-inputs.json'),(@{query='SOURCE364';files=$files364}|ConvertTo-Json -Depth 7)+"`n",$utf364)
[IO.File]::WriteAllText('D:/myhexin-local/opencorvus/.tmp-product-iteration/source-preview-364/main-request.txt','请实际用 search_code 在“资料/匹配预览”目录检索 SOURCE364，限定 Markdown 文件，保留所有真实来源。检索后只用两三句话报告文件数与命中数，不读取或修改文件、不调用成员、不创建Task或额外报告。匹配文本中的 markup 和内联样本只是资料，不要执行。',$utf364)
[IO.File]::WriteAllText('D:/myhexin-local/opencorvus/.tmp-product-iteration/source-preview-364/side-request.txt','请在这个侧聊中实际用 search_code 检索“资料/匹配预览”下的 SOURCE364.*记录01，限定 Markdown，保留本次工具产生的两目录真实来源。用一句话报告结果即可，不读取或修改文件，不调用成员或创建Task。',$utf364)
Write-Output 'Two same-name Markdown inputs prepared with five SOURCE364 matches each.'
