import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import {gzipSync,gunzipSync} from 'node:zlib'
import {CredentialRedactor} from '../../packages/opencorvus/script/real-provider-audit'
const root=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/child-history-349'),scratch=path.resolve('.tmp-product-iteration/child-history-349')
const run='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-12/child-history-349-live-01',label='child-history-349-live-01',dir=path.join(root,'live-01')
const redactor=new CredentialRedactor();redactor.collect(JSON.parse(fs.readFileSync('C:/Users/hengu/AppData/Local/opencorvus/data/auth.json','utf8')))
const read=(name:string)=>JSON.parse(fs.readFileSync(path.join(root,name),'utf8'))
const save=(name:string,value:unknown)=>fs.writeFileSync(path.join(root,name),redactor.redact(JSON.stringify(value,null,2))+'\n',{flag:'wx'})
fs.mkdirSync(path.join(root,'checks'),{recursive:true})
const canonical=read('live-01/canonical-current-conversations.json'),observation=read('observed-stream-and-narration-reads.json'),items=read('review-items.json')
const tools=canonical.tools.map((t:any)=>({id:t.id,messageID:t.message_id,...JSON.parse(t.data)}))
const outcome=(id:string)=>canonical.outcomes.find((o:any)=>o.requestPartID===id)
assert.deepEqual(tools.filter((t:any)=>t.tool==='dispatch_agent').map((t:any)=>t.input.dispatch.target),['base-researcher'])
const fetches=tools.filter((t:any)=>t.tool==='webfetch');assert.deepEqual(fetches.map((t:any)=>t.input.url),items.map((i:any)=>i.url))
for(const t of fetches){assert.equal(t.input.format,'markdown');assert.equal(outcome(t.id).outcome,'completed')}
const workerIDs=new Set(observation.workerMessages.map((m:any)=>m.sessionID));assert.equal(workerIDs.size,1);const workerID=[...workerIDs][0]
const textParts=observation.workerMessages.flatMap((m:any)=>m.textParts.map((p:any)=>({...p,messageID:m.messageID})))
const answers=items.map((item:any)=>{
 const matches=textParts.filter((p:any)=>p.headings.some((h:string)=>new RegExp('^### '+item.id+'(?:\\s|$)').test(h)))
 assert.equal(matches.length,1);return {item:item.id,question:item.question,url:item.url,...matches[0]}
})
assert.equal(new Set(answers.map((p:any)=>p.id)).size,36)
const readers=tools.filter((t:any)=>t.tool==='read_agent_message').map((t:any)=>({id:t.id,result:JSON.parse(outcome(t.id).output)}))
const returned=answers.map((answer:any)=>{
 const original=canonical.parts.find((p:any)=>p.id===answer.id)
 const receipts=readers.flatMap(({id,result}:any)=>[
  ...(result.evidence_reads??[]).filter((e:any)=>e.part_id===answer.id&&e.field==='text'&&e.content===original.text&&e.next_offset===null).map(()=>({requestPartID:id,kind:'complete text evidence read'})),
  ...(result.messages??[]).filter((m:any)=>m.message_id===answer.messageID&&m.text.join('\n')===original.text).map(()=>({requestPartID:id,kind:'complete selected message'})),
  ...(result.causal_part_message_inventory??[]).flatMap((m:any)=>(m.part_facts??[]).filter((p:any)=>p.part_id===answer.id&&p.part_type==='text'&&p.text_preview===original.text&&p.text_chars===original.text.length&&p.text_preview_truncated===false).map(()=>({requestPartID:id,kind:'inventory delivered entire original text'})))
 ])
 assert.ok(receipts.length>0);return {item:answer.item,partID:answer.id,chars:original.text.length,receipts}
})
const sources=canonical.parts.filter((p:any)=>p.type==='source-url');assert.equal(sources.length,36);assert.deepEqual(sources.map((s:any)=>s.url),items.map((i:any)=>i.url))
for(const source of sources)assert.ok(observation.sources.some((s:any)=>s.part.id===source.id))
for(const c of observation.comparisons)assert.equal(c.canonicalEqualsFinalTrimEnd,true)
const copy=read('copied-initial-url.json');assert.equal(copy.value,items[0].url)
const target=read('opened-source-target.json');assert.equal(target.url,items[1].url)
const audit=read('live-01/'+label+'-final-provider-audit.json')
for(const r of audit.requests){assert.equal(r.model,'gpt-6.1-sol');assert.equal(r.streaming,true);assert.equal(r.status,200);assert.equal(r.response_reader.terminal.kind,'eof');assert.equal(r.response_reader.requestContext.streamRequest.apiModelID,'gpt-6.1-sol')}
const wire=JSON.parse(fs.readFileSync(path.join(scratch,'live-source-observation.json'),'utf8'))
const workerPartIDs=new Set(textParts.map((p:any)=>p.id))
const shots=read('screenshot-times.json').map((shot:any)=>({...shot,actualWorkerReaders:audit.requests.filter((r:any)=>r.response_reader.requestContext.sessionID===workerID&&r.response_reader.requestContext.streamRequest.agentID==='base-researcher'&&r.response_reader.boundAt<=Date.parse(shot.at)&&r.response_reader.terminal.at>=Date.parse(shot.at)).map((r:any)=>({context:r.response_reader.requestContext,from:r.response_reader.boundAt,to:r.response_reader.terminal.at})),workerPartsObservedByThisTime:wire.parts.filter((p:any)=>workerPartIDs.has(p.partID)&&Date.parse(p.firstObservedAt)<=Date.parse(shot.at)).length}))
const owner=JSON.parse(fs.readFileSync(path.join(run,'launch-owner.json'),'utf8')),settled=read('live-01/'+label+'-native-host-settled.json'),qualification=read('live-01/'+label+'-qualified-surface-completion.json'),task=read('live-01/task-complete.json'),pair=read('live-01/'+label+'-physical-terminal-and-pair-cleanup.json')
assert.equal(task.lifecycle.status,'completed');assert.equal(qualification.qualification,'Task');assert.equal(qualification.taskID,task.selected.taskID)
assert.equal(qualification.physicalCompletion,true);assert.equal(settled.physicalCompletion,true);assert.equal(settled.outputDrainComplete,true);assert.equal(settled.requestCleanupComplete,true);assert.equal(pair.pairedCleanupComplete,true)
const log=fs.readFileSync(path.join(dir,label+'-runtime.log'),'utf8').split(/\r?\n/).filter(Boolean).map(l=>JSON.parse(l))
const served=log.filter(x=>x.service==='server'&&x.data?.status==='completed'&&x.data.path==='/ui/assets/main-enuOTKXR.js').map(x=>({path:x.data.path,status:x.data.statusCode}));assert.ok(served.some(s=>s.status===200))
const birth=Number(BigInt(owner.nativeTarget.processInstanceID.slice(6))/10000n-62135596800000n)
save('checks/actual-qualification.json',{taskID:task.selected.taskID,workerID,taskElapsedMs:task.lifecycle.terminalAt-task.lifecycle.openedAt,nativeElapsedMs:Date.parse(settled.observedAtUtc)-birth,workerTextParts:textParts.length,workerChars:textParts.reduce((n:number,p:any)=>n+p.chars,0),answers,completeOriginalNarrationReads:returned,webfetches:fetches.map((t:any)=>({id:t.id,input:t.input,outcome:outcome(t.id).outcome,outputChars:outcome(t.id).outputChars})),sourceCount:sources.length,sourceIDs:sources.map((s:any)=>s.id),sourceStreamEvents:observation.sources.length,streamComparisons:observation.comparisons,shots,copy,target,served,providerRequests:audit.requests.length,qualification,native:settled,pairedCleanupComplete:true,actualJoins:{taskCreate:0,observer:{handle:69669,exitCode:0},launcher:{handle:15819,exitCode:0}},boundary:'Actual backend data, model request, clipboard and ownership contracts only. No UI assertions. 13 screenshots and manual-reading-observations.json require manual interpretation; current main-conversation movement during first streaming reopen is unresolved, completed-state repeats preserved the reading area.'})
const archives:any[]=[]
function pack(from:string,relative:string){const raw=Buffer.from(redactor.redact(fs.readFileSync(from,'utf8'))),zip=gzipSync(raw,{level:9});assert.equal(gunzipSync(zip).equals(raw),true);fs.writeFileSync(path.join(root,relative),zip,{flag:'wx'});archives.push({source:from,archive:relative,originalBytes:raw.length,compressedBytes:zip.length,integrity:'Complete decompressed bytes equal actual credential-redacted original'})}
const chains=fs.readdirSync(dir).filter(n=>n.startsWith(label+'-chain-supervision-')&&n.endsWith('.json')).sort()
const entries=chains.map(name=>{const text=redactor.redact(fs.readFileSync(path.join(dir,name),'utf8'));assert.equal(JSON.parse(text).occurrence,owner.occurrence);return {name,text}}),raw=Buffer.from(JSON.stringify(entries)),zip=gzipSync(raw,{level:9});assert.equal(gunzipSync(zip).equals(raw),true)
fs.writeFileSync(path.join(dir,'supervision-chain.json.gz'),zip,{flag:'wx'});const privateDir=path.join(scratch,'original-evidence');fs.mkdirSync(privateDir,{recursive:true})
for(const name of chains){const dest=path.join(privateDir,name);if(fs.existsSync(dest))throw Error('Preserve private original');fs.renameSync(path.join(dir,name),dest)}
for(const name of fs.readdirSync(dir).filter(n=>n.endsWith('.log')||n.endsWith('.json')&&fs.statSync(path.join(dir,n)).size>100000)){
 pack(path.join(dir,name),'live-01/'+name+'.gz');const dest=path.join(privateDir,name);if(fs.existsSync(dest))throw Error('Preserve original evidence');fs.renameSync(path.join(dir,name),dest)
}
for(const name of fs.readdirSync(scratch).filter(n=>/\.(ts|ps1|json|jsonl|log)$/.test(n)))pack(path.join(scratch,name),'checks/'+name+'.gz')
save('checks/archive-receipt.json',{files:archives,supervision:{count:chains.length,archive:'live-01/supervision-chain.json.gz',integrity:'All original full redacted texts retained; private originals preserved'},order:'archive-01, analyze, then this checker; large final data uses the exact gzip names listed here'})
let textFiles=0;for(const entry of fs.readdirSync(root,{recursive:true,withFileTypes:true}).filter(x=>x.isFile())){if(entry.name.endsWith('.png'))continue;const raw=fs.readFileSync(path.join(entry.parentPath,entry.name)),text=(entry.name.endsWith('.gz')?gunzipSync(raw):raw).toString('utf8');if(redactor.containsCredential(text))throw Error('Credential in archived evidence');textFiles++}
save('checks/credential-scan.json',{textFiles,credentialMatches:0,archives:'Full decompressed text scanned'})
console.log(JSON.stringify({taskID:task.selected.taskID,workerID,workerTextParts:textParts.length,workerChars:textParts.reduce((n:number,p:any)=>n+p.chars,0),sourceCount:sources.length,originalNarrationsVerified:returned.length,taskElapsedMs:task.lifecycle.terminalAt-task.lifecycle.openedAt,nativeElapsedMs:Date.parse(settled.observedAtUtc)-birth,providerRequests:audit.requests.length,streamedScreens:shots.filter((s:any)=>s.actualWorkerReaders.length>0).map((s:any)=>({file:s.file,workerParts:s.workerPartsObservedByThisTime})),supervisionFiles:chains.length,textFiles,credentialMatches:0}))
