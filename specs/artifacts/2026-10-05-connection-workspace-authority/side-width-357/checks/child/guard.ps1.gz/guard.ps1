$ErrorActionPreference='Stop'
$taskRepo='D:/myhexin-local/opencorvus'
$taskSource='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-12/child-dense-348-live-01'
$taskEvidence=Join-Path $taskRepo 'specs/artifacts/2026-10-05-connection-workspace-authority/child-dense-348/live-01'
$taskOut=Join-Path $taskRepo 'specs/artifacts/2026-10-05-connection-workspace-authority/side-width-357/child-readiness'
. (Join-Path $taskRepo '.tmp-product-iteration/live-sol-launch.ps1') -FunctionsOnly
$taskOwner=Get-Content (Join-Path $taskSource 'launch-owner.json') -Raw|ConvertFrom-Json -AsHashtable -DateKind String
$taskStates=@(@{expected=$taskOwner.host;state=(Get-OwnedNativeState $taskOwner.host)},@{expected=$taskOwner.nativeTarget;state=(Get-OwnedNativeState $taskOwner.nativeTarget)})
$taskListeners=@(Get-NetTCPConnection -State Listen -ErrorAction Stop|Where-Object {$_.LocalPort -in @($taskOwner.port,18345)})
$taskPair=@('auth.json','models.json'|ForEach-Object{@{name=$_;present=(Test-Path -LiteralPath (Join-Path $taskSource ('runtime/data/'+$_)))}})
$taskNative=Get-OwnedNativeSettlement $taskOwner
$taskComplete=Get-Content (Join-Path $taskEvidence 'task-complete.json') -Raw|ConvertFrom-Json -AsHashtable -DateKind String
$taskQualified=Get-Content (Join-Path $taskEvidence 'child-dense-348-live-01-physical-terminal-and-pair-cleanup.json') -Raw|ConvertFrom-Json -AsHashtable -DateKind String
if(@($taskStates|Where-Object state -ne 'dead_or_reused').Count -or $taskListeners.Count -or @($taskPair|Where-Object present).Count -or !$taskNative -or $taskNative.terminal.exitCode -ne 0){throw 'Original physical/runtime closure incomplete'}
if($taskComplete.occurrence -cne $taskOwner.occurrence -or $taskComplete.pinned.taskID -cne 'tsk_g00VXpiXcz00KjYqx3vV' -or $taskComplete.lifecycle.status -cne 'completed' -or $taskQualified.occurrence -cne $taskOwner.occurrence -or !$taskQualified.physicalCompletion -or !$taskQualified.pairedCleanupComplete){throw 'Original exact Task qualification incomplete'}
Write-OwnedLaunchFact (Join-Path $taskOut 'guard.json') @{readQualified=$true;sourceRun=$taskSource;occurrence=$taskOwner.occurrence;observedAtUtc=[DateTime]::UtcNow.ToString('o');states=$taskStates;listenerCount=$taskListeners.Count;pair=$taskPair;native=$taskNative;originalQualification=$taskQualified;originalTask=$taskComplete.pinned;boundary='Fresh exact original Native/Host, port, pair and actual physical/output/request settled receipt; original Task qualification retained. Parent33182 actual exit0 was observed in batch348; no new parent execution claimed.'}
$taskManifest=@{sourceRun=$taskSource;sourceEvidence=$taskOwner.settlementEvidenceRoot;sourceProject=$taskOwner.project;caseRun='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/side-width-357-child';caseEvidence=(Join-Path $taskRepo 'specs/artifacts/2026-10-05-connection-workspace-authority/side-width-357/child');readinessEvidence=$taskOut;casePort=18345;caseLabel='side-width-357-child';sourceOccurrence=$taskOwner.occurrence;startupQualified=$false;selectedSubject=@{kind='task';id=$taskComplete.pinned.taskID;projectID=$taskComplete.pinned.projectID;sessionID=$taskComplete.pinned.rootSessionID;requestID=$taskComplete.selected.requestID}}
Write-OwnedLaunchFact (Join-Path $taskRepo '.tmp-product-iteration/side-width-357/child/history-manifest.json') $taskManifest
Write-Output 'Fresh original closure verified; complete startup observations remain required.'

