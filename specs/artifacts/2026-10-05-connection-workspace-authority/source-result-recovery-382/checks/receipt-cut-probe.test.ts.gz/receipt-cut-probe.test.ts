import { afterAll, expect, test } from "bun:test"
import fs from "node:fs/promises"
import path from "node:path"
import { createManagedTemporaryDirectory, removeManagedDirectoryTree } from "../../packages/util/src/runtime-directories"
import { Bus } from "../../packages/opencorvus/src/bus"
import { Config } from "../../packages/opencorvus/src/config/config"
import { resolveSessionExecutionAuthority } from "../../packages/opencorvus/src/engine/task-session-lineage"
import { Identifier } from "../../packages/opencorvus/src/id/id"
import { PermissionAuthority } from "../../packages/opencorvus/src/permission/authority"
import { PermissionExecutionResultTable } from "../../packages/opencorvus/src/permission/permission.sql"
import { Instance } from "../../packages/opencorvus/src/project/instance"
import type { Provider } from "../../packages/opencorvus/src/provider/provider"
import { Session } from "../../packages/opencorvus/src/session"
import { MessageStore } from "../../packages/opencorvus/src/session/message-store"
import { SessionLoop } from "../../packages/opencorvus/src/session/loop"
import { SessionProcessor } from "../../packages/opencorvus/src/session/processor"
import { Database, eq } from "../../packages/opencorvus/src/storage/db"
import { ReadTool } from "../../packages/opencorvus/src/tool/read"
import { withTaskToolInvocation } from "../../packages/opencorvus/src/tool/task-tool-invocation"
import { Tool } from "../../packages/opencorvus/src/tool/tool"
import { memoryProject, resetMemoryDatabase } from "../../packages/opencorvus/test/fixture/memory"

afterAll(resetMemoryDatabase)
const evidence="D:/myhexin-local/opencorvus/specs/artifacts/2026-10-05-connection-workspace-authority/source-result-recovery-382"
const model={
  id:"source-recovery-probe",providerID:"local-contract",name:"Local contract",
  api:{id:"source-recovery-probe",npm:"@ai-sdk/anthropic"},options:{},
  limit:{context:100000,input:90000,output:4096},cost:{available:true,input:0,output:0,cache:{read:0,write:0}},
  capabilities:{toolcall:true,attachment:false,reasoning:false,temperature:true,
    input:{text:true,image:false,audio:false,video:false},output:{text:true,image:false,audio:false,video:false}},
} as Provider.Model

for(const mode of ["full_access","ask"] as const) test(`${mode}: durable successful read is restored as a completed tool`,async()=>{
  await using project=await memoryProject(`source-recovery-${mode}`)
  const root=process.env.OPENCORVUS_TEST_PROCESS_ROOT
  if(!root)throw Error("Isolated test root required")
  const external=await createManagedTemporaryDirectory(path.join(root,"fixtures"),`source-recovery-external-${mode}-`)
  try{
    const target=path.join(external,"source-boundary.txt")
    await fs.writeFile(target,"actual source boundary evidence\nsecond line\n")
    await Instance.provide({directory:project.path,fn:async()=>{
      await Config.updateProjectPatch({permission_mode:mode})
      const session=await Session.create({kind:"assistant",title:`Source recovery ${mode}`})
      const user=await Session.updateMessage({id:Identifier.ascending("message"),sessionID:session.id,role:"user",author:"user",agent:"build",time:{created:Date.now()},model:{providerID:model.providerID,modelID:model.id}})
      const message=await Session.updateMessage({id:Identifier.ascending("message"),sessionID:session.id,parentID:user.id,role:"assistant",author:"build",agent:"build",time:{created:Date.now()},modelID:model.id,providerID:model.providerID,path:{cwd:project.path,root:project.path},cost:0,tokens:{total:0,input:0,output:0,reasoning:0,cache:{read:0,write:0}}})
      if(message.role!=="assistant")throw Error("Assistant required")
      const abort=new AbortController().signal
      const processor=SessionProcessor.create({assistantMessage:message,sessionID:session.id,model,abort})
      const args={filePath:target,offset:1,limit:1},callID=`source-${mode}`
      const tool=await processor.ensureToolPart(callID,"read",args)
      const executionSurface=Tool.executionSurface(["read"],[])
      const ctx:Tool.Context={sessionID:session.id,messageID:message.id,callID,agent:"build",abort,messages:[],executionSurface,metadata(){},executionAuthority:await resolveSessionExecutionAuthority({sessionID:session.id,projectID:Instance.project.id,expected:{kind:"conversation"}})}
      const reader=await ReadTool.init()
      let executeCount=0
      let askedResolve!:(request:PermissionAuthority.Request)=>void
      const asked=new Promise<PermissionAuthority.Request>(resolve=>askedResolve=resolve)
      const stopAsked=Bus.subscribe(PermissionAuthority.Event.Asked,({properties})=>{if(properties.toolCallID===callID)askedResolve(properties)})
      let result:Awaited<ReturnType<typeof reader.execute>>
      try{
        const running=withTaskToolInvocation({projectID:Instance.project.id,sessionID:session.id,messageID:message.id,toolCallID:callID,toolPartID:tool.id,providerName:"read",providerKind:"builtin",providerID:"builtin",args},executionSurface,async()=>{executeCount++;return reader.execute(args,ctx)})
        if(mode==="ask"){
          const request=await asked
          await PermissionAuthority.reply({requestID:request.id,decision:"allow_once",actorID:"isolated-source-probe"})
        }
        result=await running
      }finally{stopAsked()}
      const history=await PermissionAuthority.history()
      const request=history.find(row=>row.event_type==="requested"&&row.tool_call_id===callID&&row.session_id===session.id)
      if(!request)throw Error("Actual outside-project permission request required")
      const attempt=Identifier.deterministic("permission",`attempt\0${request.request_id}`)
      const receipt=Database.use(db=>db.select().from(PermissionExecutionResultTable).where(eq(PermissionExecutionResultTable.attempt_id,attempt)).get())
      if(!receipt||receipt.result.kind!=="json")throw Error("Actual durable read result required")
      const stages:unknown[]=[]
      async function snapshot(stage:string,detail?:unknown){
        const persisted=await MessageStore.get({sessionID:session.id,messageID:message.id})
        stages.push({stage,detail,executeCount,message:persisted.info,parts:persisted.parts,permissionHistory:(await PermissionAuthority.history()).filter(row=>row.request_id===request!.request_id),receipt})
      }
      await snapshot("actual-read-receipt-before-completion")
      const settled=await SessionLoop.terminalizeRecoveredIncompleteAssistant(session.id)
      await snapshot("session-interruption-settlement",{settled})
      const recovery=await PermissionAuthority.resumeApprovedContinuations()
      await snapshot("approved-continuation-recovery",{recovery})
      const final=await MessageStore.get({sessionID:session.id,messageID:message.id})
      await fs.writeFile(path.join(evidence,`${mode}-receipt-cut-stages.json`),JSON.stringify({mode,projectID:Instance.project.id,sessionID:session.id,messageID:message.id,actualResult:result,stages,boundary:"Actual file read, permission APIs, canonical database and recovery entrypoints. Durable permission-result boundary before Tool completion; no Provider, UI or operating-system crash."},null,2)+"\n",{flag:"wx"})
      expect((receipt.result.value as {sources:unknown}).sources).toEqual(result.sources)
      expect(final.parts.filter(part=>part.type==="tool")).toMatchObject([{state:{status:"completed",output:result.output}}])
    }})
  }finally{await removeManagedDirectoryTree(external)}
},60_000)

