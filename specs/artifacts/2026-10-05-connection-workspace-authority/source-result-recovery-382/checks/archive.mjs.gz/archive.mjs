import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import {gzipSync,gunzipSync} from 'node:zlib'
const root=path.resolve('specs/artifacts/2026-10-05-connection-workspace-authority/source-result-recovery-382')
const scratch=path.resolve('.tmp-product-iteration/source-result-recovery-382')
const originals=path.join(scratch,'originals')
fs.mkdirSync(originals,{recursive:true})
fs.mkdirSync(path.join(root,'checks'),{recursive:true})
const cases=[],files=[]
for(const mode of ['full_access','ask'])for(const kind of ['canonical','receipt-cut']){
  const name=`${mode}-${kind}-stages.json`,source=path.join(root,name)
  const data=JSON.parse(fs.readFileSync(source,'utf8')),first=data.stages[0],last=data.stages.at(-1)
  assert.equal(first.executeCount,1);assert.equal(last.executeCount,1)
  assert.deepEqual(first.receipt.result.value.sources,data.actualResult.sources)
  assert.ok(last.permissionHistory.some(row=>row.event_type==='execution_succeeded'))
  const tool=last.parts.find(part=>part.type==='tool')
  cases.push({mode,cut:kind,executeCount:last.executeCount,durableSourceCount:last.receipt.result.value.sources.length,
    finalToolStatus:tool.state.status,finalSourceCount:last.parts.filter(part=>part.type==='source-file').length,
    toolContractSatisfied:tool.state.status==='completed',sourceContractSatisfied:last.parts.some(part=>part.type==='source-file'&&part.sourceId===data.actualResult.sources[0].sourceId),
    recovery:last.detail.recovery,original:name+'.gz'})
  const raw=fs.readFileSync(source),zipped=gzipSync(raw,{level:9})
  assert.ok(gunzipSync(zipped).equals(raw))
  fs.writeFileSync(source+'.gz',zipped,{flag:'wx'})
  const destination=path.resolve(originals,name)
  if(!destination.startsWith(originals+path.sep))throw Error('Exact original scope required')
  fs.renameSync(source,destination)
  files.push({name:name+'.gz',originalBytes:raw.length,archivedBytes:zipped.length})
}
for(const name of ['source-commit-probe.test.ts','receipt-cut-probe.test.ts','probe-tooling.log','probe-before.log','receipt-cut-before.log','source-contracts.log','archive.mjs']){
  const raw=fs.readFileSync(path.join(scratch,name)),zipped=gzipSync(raw,{level:9})
  assert.ok(gunzipSync(zipped).equals(raw))
  fs.writeFileSync(path.join(root,'checks',name+'.gz'),zipped,{flag:'wx'})
  files.push({name:'checks/'+name+'.gz',originalBytes:raw.length,archivedBytes:zipped.length})
}
fs.writeFileSync(path.join(root,'recorded-failures.json'),JSON.stringify({cases,productionFixed:false,scope:'Actual ReadTool, permission APIs, database and recovery functions; explicit source-write fault or durable-result cut, not an operating-system crash or Provider/UI acceptance.'},null,2)+'\n',{flag:'wx'})
fs.writeFileSync(path.join(root,'archive-receipt.json'),JSON.stringify({files,integrity:'Each full decompressed archive equals the exact original bytes; originals preserved privately.',credentials:'Probe inputs contain only the owned temporary text file; no Provider credentials were read or used.'},null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({cases,archiveFiles:files.length,productionFixed:false}))
