# 405 Task Question 崩溃恢复：实施前只读分析

## Recall 与本轮范围

Root要求继续处理404真实Task red03：原Asked已接受但尚未物化，进程退出后正常bootstrap产生Board pending，而当前Question集合为空、真实reply404。本轮只读生产/测试/架构/历史；只在本独立scratch写分析及公开源码摘录。不改产品、测试、spec、共享文档，不运行服务/Provider/模型/UI/测试，不读取凭据，不提交或委托。404代码和原失败不覆盖。

已重读404完整 `task-question-recovery-authority-review.md`、`question-crash-results-and-minimal-contract.md`、404规格C、03-control物理owner合同、task-control-plane occurrence/immutable事实/恢复合同。`source-excerpts.json`保存18个精确源码文件的相关区间，`callers.txt`是当前全仓生产调用搜索，`history-restore.txt`是627146cc3原变更；这些是定位依据，不是功能验收。捕获时HEAD见JSON，当前并行host-recovery/bootstrap有Mission discovery增量，见peer-recovery-diff.patch，本任务未编辑它们。

## 结论先行

现有缺陷有三层，不能只补一行restore：

1. **source发现不完整**：恢复仅扫描已物化Interaction request，不扫描已接受的Question Asked；原outbox可在它之后正常物化，产生reply404。这是red03已证实的部分。
2. **恢复准入缺权威**：Project-only初始化对每个pending Question调用restore，没有证明原执行者死亡，也没有竞争取得同一Session的物理Prompt owner。同数据库另一个仍活backend可以被错误安装第二个空waiter。
3. **普通Promise与durable action混淆**：restore只安装waiters=[]，不会恢复旧Tool Promise；Task driver随后会对原过期activation中的普通Tool记录真实ProcessExecutionInterruptedError。只有A2A `respond_agent_coordination` 有原action/epoch/Tool/input的精确重执行合同。

**推荐当前最小正确合同**：源事实先完整物化；恢复工作只在原Tool/Session的既有物理owner准入和Task occurrence fence下执行。普通Question跟随该原Tool的真实interruption结算，若因此产生Question infrastructure terminal，必须由真实恢复参与者、已落盘的原Tool interruption及其实际时间支撑，不能由Map缺失/目录启动/租约到期猜出。A2A沿原精确Tool接续恢复可回答pending。仍活、unknown、缺绑定必须保留原事实并返回明确未接管/完整性结果。

这会删除旧无条件Project-only restore，不增加另一个Question缓存或假消息。不能承诺所有历史无绑定Request都安全恢复为reply200；red03原fixture正好缺Tool/activation/原进程持久绑定，该限制必须保留而不是换预期掩盖失败。

## 可观察现象与事实来源

404 red03：source Task `tsk_g00VXyLAVc00zkkBYiIg`，Question `que_g0VXyLAw000chOlmiMsH`，原producer29060真实exit23；checkpoint中Asked存在、Interaction为null、delivery phases空。新child82796正常Project bootstrap后Board200/pending，Question[]，精确reply404。该scope的原terminal控制则正确保持原Replied/time1791931313635/answers/userInput/唯一outcome。两个child都已物理/output/request结算，未延长原期限。

red03使用现有persistEstablishedTask+native binding，再直接调用Question.ask(fixed requestID)，**没有Provider→Task-root Message.activation→QuestionTool**。它是真实跨进程source/projection/reply检查，足以证明枚举缺口；但不能用其没有保存的执行身份推出“此时有权重建某个原Tool”。404 ordinary过程测试则真实有Tool/原SessionPromptOwner，但它属于非Task，本轮只引用其机制，不把它冒成Task绿态。

`bus/bus.sql.ts:15–30` 唯一outbox保存 occurrence/project/directory/type/properties/causation/time，没有publisher PID或physical occurrence。Request schema（question/types.ts:64–100）只有id/session/time/questions及optional tool/automatic/expiry，没有Task activation或process owner。不能把outbox的逻辑occurrenceID当OS进程occurrenceID，也不能把causation字段挪作另一个owner来源。

## 历史为什么没有根治

- 627146cc3（2026-08-15）引入 `Question.restore`，将原“非A2A recovered abandonment”改成所有Question都retain+restore，并将A2A actionID从必有改为optional。其目标是避免丢弃durable输入，但实际只由已物化Interaction构造Request，没有source遗漏/物理owner的完整闭环。
- 551733a68把coordination occurrence收敛为immutable；31ba6344c调整Interaction outcome writer准入；b3958bebf处理Permission投影/拒绝续步，都没有提供通用Question跨进程Tool重执行。
- 404修复唯一original Asked/terminal reader、Task单事务物化、terminal-first/lateAsked、Session当前local canonical集合。它保留旧Project-only restore，故不能宣称Task崩溃恢复已根治。
- 现有 `engine-interaction-recovery.test.ts:269` 名为ordinary durable的测试调用fixed requestID、无真实Tool；仅Instance.dispose/reopen再手动reconcile。`Question.ask:527` 实际以 `input.requestID !== undefined` 设置durableContinuation；disposer286遇该标记保留。真实普通QuestionTool/Orchestrator question/analyze_intent都不传requestID。固定ID本身不等于一个可以重执行的业务continuation。
- 现有A2A测试有完整action/Tool lineage；`question-process-recovery.test.ts`覆盖已commit真实Replied的process replay+一条memory，不覆盖未terminal普通Tool的死owner恢复。不能用这些绿态外推。

## 全部生产入口与统一影响矩阵

| 生产入口 | 精确事实/调用 | 当前正常/崩溃合同与405影响 |
|---|---|---|
| Main/Global Chat、Work、Side、合法非Task child | tool/question.ts:12→askAndFormat，真实Tool ctx；公开SessionPrompt/GlobalChat后续同loop | 普通物理Promise，404已统一本Server live/cold/reply；405不得把这些都变成Task恢复 |
| Side发起Work/Mission前确认 | tool/panel.ts:1718/1859，Question仍属于caller Session | 目标工作尚未创建；不得借未来Task/Mission取得恢复权威 |
| Task-root question | orchestrator/interaction-tools.ts:156–178，requireTaskOrchestratorToolExecutionContext→message/call | 可经原Message.activation关联Task-root lease；普通Question无deterministic replay ID |
| Task analyze_intent clarification | orchestrator/analyze-intent-tool.ts:106，原orchestratorTool binding | 还包含分析结果/slot持久化等后续效果，不可只重答Question就声称整工具续作 |
| Task worker question | 通用QuestionTool、Task ancestry、原WorkerTurnDescriptor/dispatch lineage | 不是Task-root activation；不能强套orchestrator parent假设 |
| A2A ask_user | orchestrator/tools.ts:1784,1902：确定Question/Asked ID、原Tool/action/epoch、acceptanceEffects、原expiry/time | 唯一明确的durable Question Tool接续，已有SessionLoop精确重执行 |
| 公开Question回复/拒绝 | server/routes/question.ts:62/100 | 当前本Server waiter→原唯一terminal writer，真实参与者userInput/原时间 |
| Task回复/拒绝 | task-api/index.ts:2798/2818/2871/2891 | 常规Question仍调用同reply/reject；direct activity-reconciliation gate有自己原控制合同，不能恢复成Question |
| Server/CLI/ACP启动与restart | serve.ts初始/restore分支、acp.ts20→host-recovery264→IndependentProject/InstanceBootstrap | 所有入口最终进入同原Project初始化；不要另做路由恢复或CLI旁路 |
| Mission原恢复/close | mission/process-recovery340、bindMissionClosingAssistantTerminalizer | 原lifecycle lease+exact frontier+dead Prompt generation，结算原Tool；不得由通用Question恢复抢先消耗Mission dead-owner证据 |
| 正常Stop/dispose | Question唯一terminal writer，Runtime/Session原settlement | 原正常期限/取消/权限合同保持，405不增加超时或隐藏Promise |

`callers.txt`覆盖上述全部Question ask/format/reply/reject/restore/abandon及Session terminalizer caller。全仓只有engine/interaction199生产调用restore，只有bootstrap127调用该恢复pass；abandonRecovered目前无生产caller。

## 原Asked未materialize时的精确发现

唯一source是 `BusPublicationOutboxTable`，不可扫UI标题、最新Tool名称或仅扫Interaction。

建议在Question现有publication-facts边界新增**一个**有界accepted-Asked页面reader：按确切Project/event_type=question.asked及稳定 `(time_created, occurrence_id)`游标读取原行（每页复用既有64上限）；每项用现有Request schema、publicationFacts(original occurrence)核对Project/Session/id及四terminal，返回原occurrence/完整Request/实际terminal。调用者以durable Session ancestry严格筛Task。若按exact Task读，可用Session lineage的原事实join；不按Request ID前缀推Task。

在现有bootstrap的Interaction reconcile阶段，先投影这些accepted sources，再做既有Permission/direct gate处理；原projectQuestion仍是单个request/outcome/userInput writer，不另写镜像数据。先有terminal便物化原terminal，不创建物理waiter。页面只是一轮事实发现，不是持久队列；新Accepted事件继续由原subscriber同函数处理。每次重启重新从canonical source读取，旧scan cursor不当事实。

只靠一次启动枚举还不够：晚提交/迟投递的Task Asked，其原projectQuestion成功提交后应请求现有Task control scan（与现有terminal scan同owner）；Task scan依据**当前真实physical/occurrence**决定保留或恢复。不能让live projector直接执行restore。正常原进程仍活时scan只是观察原owner，不接管/重复提问。

Bus.resumeDurablePublications按directory枚举所有原outbox并处理delivery phases；它不是Question-specific reader，也不证明执行所有权。不能改成启动等待整个Bus排空的全局gate。

## 原Task/Tool到physical owner的可复用链

### Task-root

Request.tool(messageID,callID)→原Message及唯一ToolPartRequest→assistant.activationID→EngineControlActivationLease精确id/target=task_root_ingress→accepted ingress/task/epoch→lease.owner_occurrence_id→现有runtime_process receipt→OS PID/processInstance/occurrence观察。

`task-root-fact-store.ts:524–729`已核current lease、Task lifecycle/epoch、accepted parent input与唯一assistant、活动结算fence；`process-liveness.ts:88–170`提供exact OS observation，不以heartbeat/lease时钟猜dead。恢复必须读原activation，不可选最新Task lease或最新assistant。

**额外已确认风险**：task-root-ingress-delivery992–1059/1868当前先按lease expiry选exact messages调用terminalizer，再reduce；该helper自身没有OS owner观察。lease expiry是写入fence失效，不能在405新增Question terminal时直接拿它当物理进程死亡证明。应在这个共享恢复caller补原lease.owner_occurrence的观察/同Session owner准入，活或unknown保留，不为过期增加假Abandoned。

### Worker dispatch

优先原Tool所属Message→原accepted user Message/WorkerTurnDescriptor的确切dispatch身份，再读取原DispatchLineage与它的delivery_owner、dispatch-admission lease、runtime process receipt；复用 `dispatchDeliveryOwnerRecheckAt` 的精确原owner原则。`findDispatchLineageBySession`当前按time DESC选择一项，不能未经验证直接当历史Tool身份reader；必须核对该Message实际已接受输入/descriptor和原dispatch，而不是“该Session最新lineage”。

`recordAbandonedDispatchSettlement`已有真实infrastructure outcome和exact Task occurrence；这个结果足以支持该原worker执行中断，不等于允许恢复任意新Tool或另一轮Question。原current epoch被reopen/terminal更替时，只能结算原accepted活动，不获得新epoch授权。

### Session物理准入

不要新增Question host lock。现有 `SessionPromptState.start`→`SessionPromptOwner.acquire`以完整generation/PID/processInstance/occurrence观察及immediate transaction CAS竞争；live/unknown peer拒绝接管，local真实owned Prompt不被重复恢复。通过现有 `withPromptOwnerCapture` 的preflight绑定原Question/Message/Task fences，取得后保持同owner直到真实Tool/Question结果和runtime settlement完成。Mission仍走自己的原recoveryFence，不走通用start捷径。

这证明当前恢复者能写**同Session下一段真实恢复工作**，并不自动证明每个历史Question的创建者；原tool/activation或dispatch绑定仍须先成立。native process binding只有workspace/package/tree/capsule身份，没有PID，不可替代它。

## 普通与durable分别怎样恢复才正确

### 推荐：普通Question结算真实中断；A2A续作原action

普通Promise已经随进程死亡，当前仓库没有可以恢复其JavaScript调用栈的primitive。直接重执行 `question` 与重执行 `analyze_intent`/`panel`也不是同一效果合同。最小正确做法是在**已经取得原执行恢复权威**、原Tool真实持久化 `ProcessExecutionInterruptedError` 的边界，将绑定该Tool的未terminal Question按唯一既有terminal writer结算为infrastructure Abandoned；timeResolved取这个真正的interruption事实时间，已经存在的answered/rejected/expired/abandoned始终保持原payload/time/occurrence。真实模型后续从原Tool错误/Task上下文自主决定是否再问，host不替模型选择下一步。

这是建议改变目前缺失的事实收敛，不是用“本机Map没有”猜一个终态；没有原Tool interruption的请求绝不能走此分支。若用户决定保留普通Task Question跨进程回答而不关闭旧Tool，则必须另立原Tool continuation合同、原Request冻结owner及模型接续，并非本次四行修复，不能把empty-waiter当作已实现。

A2A则复用 `SessionLoop.recoverInterruptedAgentCoordinationPart:2605–2662`，从原running respond_agent_coordination ToolPart/persisted input恢复同action/Question/Asked/原deadline。原action/Task epoch准入继续由原工具acceptanceEffects验证；新物理owner拿到same Request后重新等待真实用户，reply仍原API，原Tool真实result/outcome才算完成。不复制整个Permission continuation loop，也不绕过catalog/Task action authority。

现有Question.restore可以被这个真正获权恢复边界调用，但更窄的方向是让原A2A exact Question.ask本身安装同原waiter（它已有fixed occurrence/time/expiry并绑定真实Promise），从而删除通用empty-waiter restore。选择后必须只有一个实现，不能两者都保留。需要在正式checker证明原A2A accepted-but-unmaterialized时也先materialize原Request，避免重建原time/expiry。

### 未知/无绑定的合法历史数据

Request.tool是optional，red03就是无tool的fixed-ID输入；原outbox也没记录physical publisher，不能恢复丢失的authority。正确返回应是显式 `unreconciled`/typed missing-continuation-authority（包含原Request/Task定位），保留Board/Asked，不造terminal、不静默安装waiter。原red03失败继续保留，不能把“换成404预期”称为bug修复。

若405验收要求**这些无绑定输入也必须安全可回答**，还需要一次原Accepted Question合约扩展：接受时冻结真实continuation类别/执行owner，而不是把任意requestID当durable。现有schema无此事实，当前代码无法无损补推历史值。该扩展会触及Request/producer/SDK/现存数据准入，明显超出最小方案；应由Root单独落盘批准，不能通过prefix/最新owner/fallback避开。

## 必须删除/替换的旧路径

- 删除 `EngineInteraction.reconcileRecoveredPendingWaiters` Question分支中的无条件restore及“所有pending都retainedRecoverableQuestions”的结果声明。Permission ledger恢复和direct activity gates保留自己的合同。
- 收敛/删除仅为旧Project-only恢复服务的 `recoverableAgentCoordinationQuestion` 分类与前置批量action读取；真正A2A已经由原exact工具验证完整action/epoch/Tool，不保留第二套恢复判定。
- 若A2A直接重入原ask已提供完整waiter，删除Question.restore通用入口及仅验证无fence restore的过期测试；不留旧wrapper。若实证它仍为同一获权流程必需，则改成只在该流程调用，不能仍由Project启动裸调用。
- `durableContinuation = input.requestID !== undefined`是被证实过宽的生命周期标记。生产唯一固定ID调用是带acceptanceEffects+exact occurrence的A2A；应以该真实owner-admitted continuation事实收敛，删除fixed-ID等同可恢复的旧推断，而非配置白名单。
- 本轮不删除Bus outbox、已接受Question/Tool历史、不伪造Task/Message，不改变Question四terminal公开语义。

## 建议最小生产路径（先Root规格，不是实施授权）

1. `question/index.ts`：唯一accepted source分页/按原Tool精确读取；原terminal writer复用；收敛restore/durable标记。保持Request公开字段，不能在本最小范围伪补历史owner。
2. `engine/interaction.ts`：accepted源物化复用projectQuestion；删除Project-only物理restore；Asked/terminal向现有Task scan发同事实通知。
3. `engine/task-root-ingress-delivery.ts`：原Task-root recovery选择exact activation的OS owner，保护live/unknown；按现有Task/Session权威进入真正恢复边界。dispatch不复制另一套检测。
4. `session/loop.ts`：原terminalizer在真实ordinary Tool interruption之后绑定精确Question terminal；A2A保留原exact continuation。不要额外制造assistant result、loop gate或宿主工具选择。
5. `project/bootstrap.ts`：仅若将现有reconcile改名/拆分需要，继续一个有界source reconciliation入口；保留peer新Mission discovery，不改Host目录发现或服务预算。

如果需要新增纯authority reader模块，应优先将上述原exact读取封装成一个内部函数；全仓证明重复前不抽象另一个恢复框架。若不可避免需要修改SessionPromptOwner或公共Question schema，先向Root报告具体缺失的事实/调用合同，本方案不隐式授权。

## 正向验收计划与原600s物理边界

先新建真正Task过程red，再实施。复用现有标准Bun1.4 isolated runner、controlled streaming Provider、NodeProcess owned_tree及成熟Task公开HTTP/CLI admission；不fake Task/Message/Tool，只有原commit未delivery hook。父原600s、两个顺序child各≤180s、HTTP≤30s、留60s关闭；需要同时live backend控制则单独fresh原600s scope，明确两个真实occurrence，不能延长原scope。

| 用例 | 正向完整结果 |
|---|---|
| 正常Task-root Provider→普通Question、无terminal crash | 原Task/Message.activation/Tool/Asked完整；正常新owner有精确dead证据；原Tool真实interruption与Question真实infrastructure terminal对应；Board相同terminal/time；后续真实Task控制可以推进，不宣称旧Tool成功 |
| A2A accepted Asked未materialize crash | 原accepted action/epoch/Tool冻结；重启原source物化；取得exact owner后可public reply200，原Question identity/expiry不变，原Tool/action/outcome和真实模型续步自然完成 |
| 已terminal但未delivery crash | 四terminal原payload/time/origin/answers/userInput和唯一outcome；replay后相同完整事实 |
| 两个backend、原owner仍活 | B真实观察exact_live并返回未接管；A仍实际public reply200及原Tool/final；两者事实集合按各自owner合同检查，不以“不调用”作核心 |
| OS unknown owner | 用现成observer边界的正向typed result验证保留精确owner/Request；不冒称真实OS死场景 |
| 两Project/多Task/多个Question串并行 | 每个原source→Task/Project/Tool/epoch精确绑定，完整projected集合及实际终态；不以单case排除共享根因 |
| Task worker/Mission | worker exact dispatch lineage/原Tool；Mission原lifecycle恢复和close owner；各自真实中断结果，不能强套Task-root lease |
| retry、正常Stop/restart、Task reopened | 相同原source幂等，原terminal不变；当前epoch保护、原pending取消/期限真事实；旧Question不获得新epoch执行权 |
| 无Tool/无原owner数据（含原red03） | 保留原失败与原Asked/Board；明确unreconciled missing authority。只有Root批准新的accepted contract后，才另验新合法输入的恢复，不能给旧数据造owner |

直接相关现有聚焦套件：question-publication-projection、question-process-projection、question-process-recovery、engine-interaction-recovery；真实Task-root/dispatch/A2A恢复对应已有fixture与控制tests按最终改动选取。触及旧fixed-ID Project-only restore用例必须按新真实owner合同修正，不保留负向absence或以mock替真实过程。未检索/运行UI自动化；真实Task页面与必要GPT-6.1 Sol验收由Root在生产修复后另行授权/执行。

## 当前尚未达成

没有运行405新Task过程red，没有405生产修复/正式绿测/真实UI/真实模型；red03仍失败。源码已证明为何仅补restore不够，也明确最小实现可使用的原source和物理owner primitive。普通Question真实中断分支与无绑定历史数据的产品合同需要Root依据本报告落盘决定，才能实施；不把此分析包装为恢复完成。

交接前复核：HEAD已随Root404提交推进至e70e3dc55cc7c9627b81fc3f6b12274394240f64。另有peer修改Bus.resume筛选为SQL unfinishedPublication（原三phase判定），仍为void且不建立Question恢复权威；此变化不修复source/materialization与physical continuation缺口。本报告提出的Question source发现不能复用“仅unfinished outbox”，因为delivery已结束但Question本身仍pending的原source也必须可见。本任务未编辑这些peer文件。
