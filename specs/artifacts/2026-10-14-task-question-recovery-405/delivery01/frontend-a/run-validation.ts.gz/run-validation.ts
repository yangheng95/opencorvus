import fs from "node:fs/promises"
import path from "node:path"
import { bootstrapIsolatedTestRuntime, applyIsolatedTestUserEnvironment, removeIsolatedTestRuntime } from "../../packages/util/src/test-runtime-environment"
import { NodeProcess } from "../../packages/util/src/process-node"
import { prepareTestProcessSupervisor } from "../../packages/opencorvus/script/prepare-test-process-supervisor"

const root = path.resolve(import.meta.dir, "../..")
const output = path.join(import.meta.dir, "validation-01")
const uiDirectory = path.join(root, ".tmp-task-question-recovery-405/ui-after-final")
const cwd = path.join(root, "packages/overlay")
const startedAt = Date.now(), deadlineAt = startedAt + 600000
await fs.mkdir(output, { recursive: false })
try { await fs.stat(uiDirectory); throw new Error("Preserve an existing private UI output") }
catch (error) { if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error }
const isolated = await bootstrapIsolatedTestRuntime("runner")
applyIsolatedTestUserEnvironment(isolated)
const supervisor = prepareTestProcessSupervisor()
if (!supervisor) throw new Error("Declared native process supervisor required")
process.env.OPENCORVUS_PROCESS_SUPERVISOR = supervisor
const pathName = Object.keys(process.env).find(name => name.toLowerCase() === "path") ?? "PATH"
process.env[pathName] = path.dirname(process.execPath) + path.delimiter + (process.env[pathName] ?? "")
const environment = Object.fromEntries(Object.entries(process.env).filter(([name]) => /^(PATH|SystemRoot|WINDIR|ComSpec|PATHEXT|HOME|HOMEDRIVE|HOMEPATH|USERPROFILE|APPDATA|LOCALAPPDATA|TEMP|TMP|TMPDIR|XDG_CONFIG_HOME|XDG_DATA_HOME|XDG_CACHE_HOME|XDG_STATE_HOME|OPENCORVUS_(TEST_|HOME))/i.test(name)))
environment.OPENCORVUS_PROCESS_SUPERVISOR = supervisor
const checks = [
  { name: "typecheck", executable: process.execPath, args: ["run", "typecheck"] },
  { name: "transport", executable: process.execPath, args: ["run", "test:unit", "test/side-chat-transport.test.ts", "test/subagent-conversation-service.test.ts"] },
  { name: "build", executable: "C:/Program Files/nodejs/node.exe", args: ["--max-old-space-size=8192", "./node_modules/vite/bin/vite.js", "build", "--config", "vite.config.ts", "--outDir", uiDirectory] },
]
const manifest: any = { parentPID: process.pid, startedAt, deadlineAt, cwd, uiDirectory, ownership: "owned_tree", environmentNames: Object.keys(environment), runtimeOwner: isolated,
  declarations: "Overlay tsconfig has no source customCondition; SDK package types export selects current dist declarations. Vite source condition remains its declared build contract.",
  checks: [] }
await fs.writeFile(path.join(output, "scope-start.json"), JSON.stringify(manifest, null, 2), { flag: "wx" })
try {
  const results = await Promise.allSettled(checks.map(async check => {
    const facts: any = { ...check, cwd, deadlineAt, startedAt: Date.now() }
    let handle: Awaited<ReturnType<typeof NodeProcess.spawn>> | undefined
    try {
      const result = await NodeProcess.run({ command: { executable: check.executable, args: check.args }, cwd, env: environment,
        ownership: "owned_tree", windowsHide: true, stdin: "ignore", deadlineAt, nothrow: true,
        onSpawned(value) { handle = value; facts.pid = value.pid; facts.occurrenceID = value.occurrenceID; console.log(JSON.stringify({ phase: "started", check: check.name, pid: value.pid, deadlineAt })) },
      })
      await fs.writeFile(path.join(output, check.name + ".stdout.log"), result.stdout)
      await fs.writeFile(path.join(output, check.name + ".stderr.log"), result.stderr)
      await handle!.settled
      await handle!.outputSettled
      facts.receipt = result.receipt
      facts.physicalJoined = true; facts.outputJoined = true; facts.requestSettled = true
      await fs.writeFile(path.join(output, check.name + ".exit"), String(result.receipt.exitCode ?? 1))
      if (result.receipt.reason !== "exited" || result.receipt.exitCode !== 0) process.exitCode = 1
    } catch (error) {
      facts.error = String(error); process.exitCode = 1
      if (handle) { facts.receipt = await handle.settled; await handle.outputSettled; facts.physicalJoined = true; facts.outputJoined = true }
      throw error
    } finally {
      facts.finishedAt = Date.now()
      await fs.writeFile(path.join(output, check.name + "-owner.json"), JSON.stringify(facts, null, 2), { flag: "wx" })
      manifest.checks.push(facts)
      console.log(JSON.stringify({ phase: "settled", check: check.name, exitCode: facts.receipt?.exitCode, physicalJoined: facts.physicalJoined, outputJoined: facts.outputJoined }))
    }
  }))
  manifest.results = results.map((result, index) => ({ name: checks[index]!.name, status: result.status, ...(result.status === "rejected" ? { error: String(result.reason) } : {}) }))
} finally {
  await removeIsolatedTestRuntime(isolated)
  manifest.runtimeRemoved = true
  manifest.runtimeRemovedAfterPhysicalJoin = manifest.checks.every((check: any) => check.physicalJoined && check.outputJoined)
  manifest.finishedAt = Date.now()
  manifest.exitCode = Number(process.exitCode ?? 0)
  await fs.writeFile(path.join(output, "scope-final.json"), JSON.stringify(manifest, null, 2), { flag: "wx" })
  console.log(JSON.stringify({ phase: "final", output, uiDirectory, exitCode: manifest.exitCode, finishedAt: manifest.finishedAt, deadlineAt }))
}
