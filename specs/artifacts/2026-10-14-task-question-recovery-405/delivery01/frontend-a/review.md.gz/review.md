# 405 A implementation and bounded validation handoff

The Root-authorized A scope is frozen: two production files and one existing pure transport/state test file. The previously approved C implementation remains unchanged. These checks do not constitute UI or visual acceptance; Root owns the real post-change Side Chat and expiry-page review.

## Exact implementation

- `packages/overlay/src/services/side-chat.ts`: the existing owned stream `onError` records a warning through `AppLog` with the captured Session, directory, stream generation, and original formatted diagnostic, then performs the original `close("transport-error")`. The existing close/retry path remains authoritative. Transport interruptions no longer enter the persistent business-feedback callback. No blanket clearing of errors was introduced. Existing protocol, Session, action, list/read/send/abort error paths remain in place.
- The same service's `refreshActivity` failure branch now uses its already captured `lifecycleVersion`, matching the successful response guard. A retired observation cannot replace the current connection's outcome; a current observation still delivers its actual error.
- `packages/overlay/src/components/SideChatPanel.tsx`: the existing footer gives disconnected/connecting status precedence, then actual running activity, then connected idle/private status. No new state, timeout, translation, or error map was added.
- `packages/overlay/test/side-chat-transport.test.ts`: two positive pure transport/state cases exercise the existing 3-second retry, identical full Question object reuse, captured route/directory, connection transitions, original AppLog diagnostic, current activity, current business error, and current activity-read failure. No UI, DOM, render, snapshot, source-text, or formatter test was added or run.

## Source preservation

`before/` and `after/` contain the exact three scoped source files. `source-before.patch` and `index-before.patch` were both empty when captured. `source-allowlist.json` lists the exact scope; `implementation.patch` preserves the implementation delta. `status-before.txt` and `status-after.txt` record unrelated concurrent changes without modifying them. C's five source files and evidence remain in `../frontend-c/`.

## Actual validation

One original fixed 600-second owned scope ran all checks. `run-validation.ts` retains the commands and mature NodeProcess ownership/cleanup logic; `validation-01/scope-start.json`, per-check owner files, full stdout/stderr logs, exits and `scope-final.json` preserve the actual receipts.

- Original exec session 20926, start chunk `4a16f6`, final join chunk `5c3e32`, exit 0.
- Parent PID 88500; start 1791935661078; original deadline 1791936261078; finished 1791935791102. Runtime cleanup happened after all physical/output joins.
- Overlay package-declaration typecheck: PID 79540, occurrence `5283c92c-b7b7-40f6-8d4a-998df98f6ae8`, exit 0.
- Standard isolated unit runner, only `side-chat-transport.test.ts` and `subagent-conversation-service.test.ts`: PID 48636, occurrence `7b45a1ea-0e9d-44ba-b833-6e465300a2af`, exit 0. Results are 13 tests / 34 assertions plus 25 tests / 63 assertions: **38 pass, 97 assertions**. These are local transport/state contracts, not end-to-end acceptance.
- Independent Node/Vite private build: PID 79780, occurrence `c91fa7df-c34a-43c9-a3fe-f054130e3d1a`, exit 0; Vite reports 2m 7s. Output is `D:/myhexin-local/opencorvus/.tmp-task-question-recovery-405/ui-after-final`, whose `index.html` is 11891 bytes. The C `ui-after`, original 404 output and shared `dist-vite` were not overwritten.
- Existing Radix `use client`, mixed static/dynamic `file-workbench` import, and large-chunk warnings are retained in the original build stderr; they did not fail the build.

## Remaining acceptance and boundaries

Root must exercise real Side stream cut/reconnect, same Question draft and exact submission, natural completion, footer and attention-banner state, plus the C historical expiry labels in both product languages. Current business errors must remain visible. This implementation does not modify Task empty-header title producers, Question lifecycle/backend facts, SDK, Provider configuration, shared documentation, or Git. No new page, model, service, or UI automation was started by this implementation validation.
