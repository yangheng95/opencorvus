# 405 manual UI helper handoff — frozen, not started

The Root-approved five scratch helpers are ready for source review. No service, Provider, browser, model, UI automation or production edit was run by audit_ui. Existing 404 sources and all original scopes remain unchanged.

## Exact files / source preservation

| New 405 helper | Original 404 source | Allowed changes |
| --- | --- | --- |
| `manual-side-question-driver.ts` | `manual-permission-driver.ts` | 405 immediate-child scope guard, new server/relay paths, truthful Side Question purpose |
| `manual-side-question-server.ts` | `manual-permission-server.ts` | 405 immediate-child scope guard/error description only |
| `manual-empty-expiry-driver.ts` | `manual-empty-expiry-driver.ts` | 405 guard, new server/relay paths, truthful empty-header expiry purpose |
| `manual-empty-expiry-server.ts` | `manual-empty-expiry-server.ts` | 405 immediate-child scope guard/error description only |
| `relay-driver.mjs` | `relay-driver.mjs` | import original `../.tmp-task-git-question-reconnect-404/http-relay.mjs`, truthful 405 guard description |

`ui-helper-source/` contains all five original byte copies. `ui-helper-changes.patch` contains the actual exact no-index diffs (exit 1 means a diff, not a failed functional check). `ui-helper-scope.json` records source/destination scope and changes. `ui-helper-static-review.json` records four TypeScript transpile syntax checks and Node `--check` of the relay, all 0; this is not runtime or UI acceptance. `ui-helper-scope.pre-relay.json` retains the initial report before Root expanded the fifth relay adapter.

Original relay-driver rejects a scope outside its own immediate parent, so reusing it directly would reject 405. Root explicitly approved the fifth adapter; it retains the same check rather than removing it. Raw HTTP byte forwarding, exact-session stream cut, owner liveness limitation, control occurrence binding and deadlines all remain the existing 404 implementation. The original 404 relay-control has no scope-parent restriction and can be reused unchanged.

## Start commands (Root only, after review)

Run from `D:/myhexin-local/opencorvus`. Both target scope directories must be absent. Both drivers use repository Bun 1.4 and Node-owned product + Node relay; neither starts standalone Vite. The actual page is served by the product `/ui` with Root's already-built 404 private before UI.

```powershell
& 'D:/myhexin-local/opencorvus/.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64/bun.exe' 'D:/myhexin-local/opencorvus/.tmp-task-question-recovery-405/manual-side-question-driver.ts' 'D:/myhexin-local/opencorvus/.tmp-task-question-recovery-405/side-question-before01' 'D:/myhexin-local/opencorvus/.tmp-task-git-question-reconnect-404/ui-after' 'side-question'
```

```powershell
& 'D:/myhexin-local/opencorvus/.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64/bun.exe' 'D:/myhexin-local/opencorvus/.tmp-task-question-recovery-405/manual-empty-expiry-driver.ts' 'D:/myhexin-local/opencorvus/.tmp-task-question-recovery-405/empty-expiry-before01' 'D:/myhexin-local/opencorvus/.tmp-task-git-question-reconnect-404/ui-after' 'warm-question'
```

These are independent fresh runs, not continuation of any 404 deadline. Root may use another fresh immediate-child name but must retain the exact scenario arguments. The original allowed-scenario list/default was intentionally not rewritten; invoking these without the specified final scenario would test the old default read input instead.

Each product `scope/ready.json` supplies actual Session/Project/directory. Each `scope-relay/ready.json` supplies the **relay `uiURL` Root should open**. Read those actual ready files, not a predicted port. Driver metadata are adjacent `scope.launch.json` and `scope.relay-launch.json`; product server and NodeProcess occurrence IDs are distinct and should be kept distinct in evidence.

## Side Question flow / exact public inputs

1. Use the relay page. Root creates/opens the independent Side Chat through real UI, preserving its actual `metadata.sideChat.sourceSessionID` relation.
2. Under `ready.session.directory`, ordinary public `GET /session` locates that UI-created side root (`parentID` absent, matching `metadata.sideChat.sourceSessionID=ready.sessionID`, same Project/directory). Prompt it using normal `POST /session/<actual-side-id>/message` with fresh `messageID`, `agent:'chat'`, and `model:{providerID:'side-fixture',modelID:'session-prompt-owner-model'}`. Exact text from original 404 helper: `Ask me the public reconnect draft question in this independent Side Chat, then record my exact answer.` Preserve request/HTTP receipt; all requests remain inside original closeBy. This targets the unique Side Provider whose first response is the actual Question Tool, not the seed model.
3. Write a new empty `scope/release-public-prompt` control file once (no overwrite) when Root is ready to see the Question. Main seed/memory have their original automatic release; this file releases the original Side prompt and subsequent natural response.
4. Enter a draft on the real page, capture before. Cut only the actual Side Session stream with the existing control:

```powershell
& 'C:/Program Files/nodejs/node.exe' 'D:/myhexin-local/opencorvus/.tmp-task-git-question-reconnect-404/relay-control.mjs' 'D:/myhexin-local/opencorvus/.tmp-task-question-recovery-405/side-question-before01-relay' 'cut' '<actual-side-session-id>'
```

Read `status` before/after if useful. Do not replace the placeholder with Main. Root records actual stream pair/reconnect identity, expands persistent Feedback Details, and captures its precise error rather than inferring it from the title. Continue editing and answer via actual UI, then retain public Tool answer/final idle facts.

**Existing entry/checker path boundary:** original 404 `side-question-entry.mjs` and `question-facts.mjs` assert that the supplied scope is a direct child of their own 404 directory. They cannot be called directly with a 405 scope. This preparation does not silently widen those validators or create an unapproved sixth helper. Root can use the exact public calls above with its owned API observation process, or separately authorize a copied path-only adapter. The four server/driver helpers and relay do not send that independent Side prompt by themselves; it follows the real UI-created Side Session.

## Empty header / real deadline flow

The supplied warm-question helper retains the exact original empty header, original public question/options/custom flag, `OPENCORVUS_QUESTION_TIMEOUT_MS=30000` and public `experimental.auto_question=true`. It retains the original config/profile, synthetic Provider/model, main Global Chat input and native runtime. No profile/tool choice was changed. The `30s` is the genuine Question business deadline after Ask; it does not replace or extend the service's original `600s`.

Set the actual UI language/target view before creating `scope/release-public-prompt`; then the original Provider naturally calls Question. Capture pending Dialog/inline; wait original deadline, capture actual terminal receipt/Tool completed + metadata.status expired + answers null and natural final. Move pointer away from Project rows before the historical screenshot so the caption is not hidden by a tooltip. The source still says the same original model-authored question/header text (including 404 in the Side header); do not translate or rename that content as a helper cleanup.

This helper is the original nonTask Main input. It does not create a Task or use the Research Studio Task-only setup introduced for 404 public02. The old phaseB profile/MCP input is preserved as requested; any unrelated catalog diagnostic should be captured and distinguished from the target Side transport/expiry caption rather than silently changing this before input.

## Fixed scope / controls / normal closure

- Original driver start → deadline +600000, `closeBy=deadlineAt-60000`; product validates inherited deadline. Relay receives the same deadline/closeBy and original product PID + NodeProcess occurrence. Its kill0 observation is liveness only; original driver receipt owns physical identity/settlement.
- Product/provider start or ready failure does not authorize a renewed scope. Drivers preserve original launch/stdout/stderr/terminal files. Original parent awaits product physical/output and relay physical/output before `removeIsolatedTestRuntime`.
- Root closes the actual page before closeBy, requests relay shutdown via original `relay-control.mjs <scope-relay> shutdown`, then creates new `scope/stop-requested` once. The existing product owner stops server/providers and the driver joins both original handles before deleting its isolated runtime. Do not infer physical join from child terminal JSON or control acknowledgement.
- Read original driver exec completion/exit, `.physical-terminal.json`, `.relay-physical-terminal.json` and runtime cleanup evidence. No user process or page is operated by these preparation steps.
- Existing relay controls remain `status`, `cut`, `shutdown`; they manipulate exact owned transport only. There is no added product debug endpoint, event rewrite, fake terminal, automatic browser action or screenshot script.

## Current handoff status

Five sources and exact adaptation patch are frozen. Syntax checks passed without evaluating the helper modules; no real scope has been started by this agent. Root first reviews and runs the two before pages, then provides actual visual findings and explicit production authorization. UI candidate changes have not been made.
