import fs from 'node:fs/promises'
import path from 'node:path'
import assert from 'node:assert/strict'
import {Database} from 'bun:sqlite'
const root=path.resolve(process.argv[2]??'')
assert.equal(path.dirname(root),path.resolve('.tmp-task-question-recovery-405'))
const read=async(name:string)=>JSON.parse(await fs.readFile(path.join(root,name),'utf8'))
const pendingObservation=process.argv[3];assert(pendingObservation&&path.basename(pendingObservation)===pendingObservation,'Explicit original pending observation basename required')
const ready=await read('ready.json'),original=await read(pendingObservation)
assert(Date.now()<ready.closeBy)
const request=original.conversation.pendingQuestions[0];assert(request);assert.equal(request.questions[0].header,'');assert.equal(request.expiry.timeoutMs,30000)
const get=async(route:string)=>{const response=await fetch(new URL(route,ready.url),{headers:{'x-opencorvus-directory':ready.session.directory},signal:AbortSignal.timeout(15000)});assert.equal(response.status,200);return response.json()}
const [messages,conversation]=await Promise.all([get(`/session/${ready.sessionID}/message`),get(`/session/${ready.sessionID}/conversation`)]) as any[]
const db=new Database(path.join(ready.runtime,'data/opencorvus.db'),{readonly:true})
let facts:any[]
try{db.exec('BEGIN');facts=db.query("SELECT occurrence_id,event_type,properties,time_created FROM bus_publication_outbox WHERE project_id=? AND json_extract(properties,'$.sessionID')=? AND (json_extract(properties,'$.id')=? OR json_extract(properties,'$.requestID')=?) ORDER BY time_created,occurrence_id").all(ready.session.projectID,ready.sessionID,request.id,request.id).map((x:any)=>({...x,properties:JSON.parse(x.properties)}))}finally{db.exec('ROLLBACK');db.close()}
const expired=facts.find(x=>x.event_type==='question.expired');assert(expired);assert.equal(expired.properties.requestID,request.id);assert.equal(expired.properties.origin,'deadline');assert.equal(expired.properties.timeExpires,request.expiry.timeExpires);assert(expired.properties.timeResolved>=request.expiry.timeExpires)
const tool=messages.flatMap((m:any)=>m.parts.map((p:any)=>({message:m,part:p}))).find((x:any)=>x.part.type==='tool'&&x.part.tool==='question');assert(tool);assert.equal(tool.part.callID,request.tool.callID);assert.equal(tool.message.info.id,request.tool.messageID);assert.equal(tool.part.state.status,'completed')
assert.deepEqual({status:tool.part.state.metadata.status,answers:tool.part.state.metadata.answers,requestID:tool.part.state.metadata.requestID,timeExpires:tool.part.state.metadata.timeExpires,timeResolved:tool.part.state.metadata.timeResolved},{status:'expired',answers:null,requestID:request.id,timeExpires:expired.properties.timeExpires,timeResolved:expired.properties.timeResolved})
const final=messages.findLast((x:any)=>x.info.role==='assistant'&&x.info.parentID===tool.message.info.parentID&&x.info.finish==='stop'&&Number.isFinite(x.info.time.completed));assert(final);assert.deepEqual(final.parts.filter((p:any)=>p.type==='text').map((p:any)=>p.text),['provider reply 2']);assert.equal(conversation.board.status,'idle');assert.deepEqual(conversation.pendingQuestions,[])
const result={observedAt:new Date().toISOString(),request,facts,tool,final,boardStatus:conversation.board.status,meaning:'Real completed Tool with typed expired result and original Expired publication; Root separately reviews actual Chinese page'}
await fs.writeFile(path.join(root,'expiry-check.json'),JSON.stringify(result,null,2),{flag:'wx'});console.log(JSON.stringify({questionID:request.id,expiry:expired.properties,toolStatus:tool.part.state.status,finalMessageID:final.info.id,status:conversation.board.status}))
