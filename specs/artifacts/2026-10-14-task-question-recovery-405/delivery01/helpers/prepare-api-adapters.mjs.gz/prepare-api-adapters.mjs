import fs from 'node:fs'
import assert from 'node:assert/strict'
const root='.tmp-task-question-recovery-405',old='.tmp-task-git-question-reconnect-404'
for(const name of ['question-facts.mjs','side-question-entry.mjs','check-empty-expiry.ts']){
 const bytes=fs.readFileSync(old+'/'+name)
 fs.writeFileSync(root+'/ui-helper-source/'+name,bytes,{flag:'wx'})
 let text=bytes.toString('utf8')
 if(name==='check-empty-expiry.ts'){
  text=text.replace("path.resolve('.tmp-task-git-question-reconnect-404')","path.resolve('.tmp-task-question-recovery-405')")
  const anchor="const ready=await read('ready.json'),original=await read('question-facts-1791931366703.json')"
  assert(text.includes(anchor))
  text=text.replace(anchor,"const pendingObservation=process.argv[3];assert(pendingObservation&&path.basename(pendingObservation)===pendingObservation,'Explicit original pending observation basename required')\nconst ready=await read('ready.json'),original=await read(pendingObservation)")
 }
 fs.writeFileSync(root+'/'+name,text,{flag:'wx'})
}
console.log('Three exact public API/checker adapters prepared; original assertions retained')
