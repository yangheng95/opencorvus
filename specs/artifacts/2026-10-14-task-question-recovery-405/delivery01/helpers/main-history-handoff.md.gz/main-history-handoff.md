# 405 Main Answer / Skip history — prepared, not started

Root-approved scope is limited to two fresh manual Main runs. No service, Provider, browser, model, public request, UI automation, or production change was started by this preparation.

## Frozen helper sources

- `manual-main-history-driver.ts`: copy of current `manual-empty-expiry-driver.ts`; only child-server path and the truthful Main Answer/Skip purpose changed.
- `manual-main-history-server.ts`: byte-identical copy of current `manual-empty-expiry-server.ts`. It retains the same Global Chat creation, exact empty header/body/options/custom flag, controlled streaming Provider/model, profile, public configuration, genuine 30000ms Question expiry, original 600000ms driver deadline and 60000ms close reserve.
- `main-history-facts.mjs`: new **read-only public API** observer/checker for the actual Main request. It calls only GET message, conversation and question. It never replies, rejects, stops, disposes, injects an event, edits a fact, or accesses the database. Raw HTTP status/body observations are saved before contract assertions.
- Original source copies: `main-history-helper-source/`. Exact existing-source delta: `main-history-helper-changes.patch`; source inventory: `main-history-helper-scope.json`. `prepare-main-history.mjs` produced these files; do not rerun it over the frozen outputs.

The first preparation stopped at an exact purpose-literal mismatch **before either target helper existed**. `main-history-prepare-failed01.json` and the original preparation script preserve that failure. Reading the actual longer `controlled streaming` literal resolved it; only preparation was rerun. No real scope budget was consumed or renewed.

## Root start commands

Run from `D:/myhexin-local/opencorvus`, one independent scope at a time. Target directories must not exist. The scenario argument must be `warm-question` rather than the preserved legacy default `read`.

```powershell
& 'D:/myhexin-local/opencorvus/.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64/bun.exe' 'D:/myhexin-local/opencorvus/.tmp-task-question-recovery-405/manual-main-history-driver.ts' 'D:/myhexin-local/opencorvus/.tmp-task-question-recovery-405/main-answer-after01' 'D:/myhexin-local/opencorvus/.tmp-task-question-recovery-405/ui-after-final' 'warm-question'
```

```powershell
& 'D:/myhexin-local/opencorvus/.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64/bun.exe' 'D:/myhexin-local/opencorvus/.tmp-task-question-recovery-405/manual-main-history-driver.ts' 'D:/myhexin-local/opencorvus/.tmp-task-question-recovery-405/main-skip-after01' 'D:/myhexin-local/opencorvus/.tmp-task-question-recovery-405/ui-after-final' 'warm-question'
```

Keep the original driver exec and its original fixed deadline. Open the actual relay `uiURL` from `<scope>-relay/ready.json`, select the actual Main Session from `<scope>/ready.json`, and prepare language/view before releasing the original pending Provider response. The opaque product `ready.occurrence` is an object `{pid,processInstanceID,occurrenceID}` and is distinct from the parent NodeProcess occurrence. The observer compares its complete original object with deep equality, not cross-JSON reference identity.

Once the real page is ready, create `<scope>/release-public-prompt` with `flag:'wx'`. The existing owner releases the original controlled streaming response; the actual Tool creates the Question. Immediately capture the actual pending API facts, then perform the real page decision before its unchanged 30-second expiry:

```powershell
& 'C:/Program Files/nodejs/node.exe' 'D:/myhexin-local/opencorvus/.tmp-task-question-recovery-405/main-history-facts.mjs' 'D:/myhexin-local/opencorvus/.tmp-task-question-recovery-405/main-answer-after01' 'pending'
```

Use `main-skip-after01` for the independent Skip run. The observer prints the exact `main-history-pending-<time>.json` basename; save that original filename. It verifies the selected Session, original accepted user message, canonical current Question, empty header, exact 30-second expiry and real running Tool binding. Conversation adds `orderKey`; only that declared transport field is separated when comparing the same Request to GET `/question`.

## Answer run

On the real Main page, enter the public custom answer `Cedar Main answered history 405` and click the actual Answer button. After the natural response reaches idle, run:

```powershell
& 'C:/Program Files/nodejs/node.exe' 'D:/myhexin-local/opencorvus/.tmp-task-question-recovery-405/main-history-facts.mjs' 'D:/myhexin-local/opencorvus/.tmp-task-question-recovery-405/main-answer-after01' 'answered' '<exact-original-pending-json-basename>' 'Cedar Main answered history 405'
```

This checks original message/call ownership, completed Tool with `metadata.status=answered`, the exact submitted answer, and the natural final `provider reply 2` bound to the original accepted input, with board idle. Root separately reviews the historical request and answer text, then uses actual Settings language switching to review English/Chinese labels while the authored answer/body remain literal. It does not require a second model request or page reload.

## Skip run

In the independent fresh Main run, capture pending as above and click the actual Skip button. After natural completion/idle, run:

```powershell
& 'C:/Program Files/nodejs/node.exe' 'D:/myhexin-local/opencorvus/.tmp-task-question-recovery-405/main-history-facts.mjs' 'D:/myhexin-local/opencorvus/.tmp-task-question-recovery-405/main-skip-after01' 'rejected' '<exact-original-pending-json-basename>'
```

The positive contract is completed original Tool with `metadata.status=rejected`, `answers=null`, natural original final response and idle. Root separately screenshots the historical request and rejected response, and checks current language rendering. API truth cannot substitute for that actual UI action or visual review. A late expiry or any API failure must remain its actual outcome; do not relabel it rejected or restart the same scope.

## Public call chain and excluded Stop path

`InteractionCard` uses actual Answer/Skip actions; `interaction-reply.ts` maps question Answer to `POST /question/:requestID/reply` with `{answers:[[...]]}` and Skip to `POST /question/:requestID/reject`. The routes call the real `Question.reply`/`Question.reject` and capture `http.question` user input. `Question.askAndFormat` and `Tool/question` produce the positive status/answers checked here. This API observer does **not** prove durable publication `timeResolved` or origin directly and makes no such assertion.

Read-only Stop finding: `services/chat.ts` stops its captured current chat request through `POST /session/:id/abort`; the public route invokes `cancelSessionPromptInScope` and awaits the actual Prompt finish. It does not directly call `Question.abandon`, and ordinary `Tool/question` does not forward a cancellation signal to `askAndFormat`. The explicit `Question.abandon` caller is the orchestrator A2A setup-failure path; Question Instance disposal has its own terminal publication behavior, and public global disposal is fenced by real owned Prompt admission. **Do not start a Stop test, bypass disposal, directly call internals, or claim infrastructure history from ordinary Stop.** C infrastructure visual acceptance remains unmet for the separately investigated real Task terminal path.

## Original closure and accurate boundaries

Close the actual page before original `closeBy`, request original relay shutdown with the existing 404 `relay-control.mjs <scope-relay> shutdown`, then create the product `stop-requested` once. Preserve original driver completion, both physical receipts, output joins, server terminal and parent runtime cleanup. Control acknowledgement alone is not a physical join. Do not reuse or extend a finished scope.

405 Side post-change recovery already passed Root's exact-draft/submission/natural-idle check, but the 3-second Connecting visual window was not captured. This preparation does not change that delay or claim that missing screenshot. The present helpers do not cover Task, Mission, infrastructure termination, Question reconnect, real Provider qualification, or all terminal paths; they target only actual Main Answer and Skip history.
