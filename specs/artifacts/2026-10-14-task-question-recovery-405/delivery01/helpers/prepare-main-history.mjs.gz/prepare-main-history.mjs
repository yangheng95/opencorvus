import fs from 'node:fs/promises'
import path from 'node:path'
import { spawnSync } from 'node:child_process'

const root = import.meta.dirname
const originals = path.join(root, 'main-history-helper-source')
await fs.mkdir(originals, { recursive: true })
const changes = [
  {
    source: 'manual-empty-expiry-driver.ts', target: 'manual-main-history-driver.ts',
    replacements: [
      ['manual-empty-expiry-server.ts', 'manual-main-history-server.ts'],
      ['Own manual controlled streaming empty-header Question expiry UI; no real Provider qualification', 'Own manual Main Question Answer or Skip history UI; no real Provider qualification'],
    ],
  },
  { source: 'manual-empty-expiry-server.ts', target: 'manual-main-history-server.ts', replacements: [] },
]
const scope = []
let diff = ''
for (const change of changes) {
  const source = path.join(root, change.source), target = path.join(root, change.target)
  const original = await fs.readFile(source)
  try { await fs.writeFile(path.join(originals, change.source), original, { flag: 'wx' }) }
  catch (error) {
    if (error.code !== 'EEXIST' || !original.equals(await fs.readFile(path.join(originals, change.source)))) throw error
  }
  let content = original.toString('utf8')
  for (const [before, after] of change.replacements) {
    if (content.split(before).length !== 2) throw new Error('Exact unique helper adaptation required: ' + before)
    content = content.replace(before, after)
  }
  await fs.writeFile(target, content, { flag: 'wx' })
  const result = spawnSync('git', ['diff', '--no-index', '--', source, target], { encoding: 'utf8', windowsHide: true })
  if (result.status !== 0 && result.status !== 1) throw new Error(result.stderr)
  diff += result.stdout
  scope.push({ source, target, changes: change.replacements, originalBytes: original.length, targetBytes: Buffer.byteLength(content), sameByteSource: change.replacements.length === 0 })
}
await fs.writeFile(path.join(root, 'main-history-helper-changes.patch'), diff, { flag: 'wx' })
await fs.writeFile(path.join(root, 'main-history-helper-scope.json'), JSON.stringify({ preparedAt: new Date().toISOString(), scope, boundary: 'Preparation only. Main Answer/Skip; warm-question explicit. Original 600s owner/60s close reserve/30s Question deadline/config/profile/controlled streaming inputs retained. No service, Provider, browser, test or production startup.' }, null, 2) + '\n', { flag: 'wx' })
