import assert from 'node:assert/strict'
import fs from 'node:fs/promises'
import path from 'node:path'
import {randomUUID} from 'node:crypto'
const [root,mode='prompt',answer]=process.argv.slice(2)
assert(root&&path.isAbsolute(root));assert.equal(path.dirname(path.resolve(root)),import.meta.dirname)
assert(['prompt','observe','answered'].includes(mode))
const ready=JSON.parse(await fs.readFile(path.join(root,'ready.json'),'utf8'))
assert.equal(ready.scenario,'side-question');assert(Date.now()<ready.closeBy)
const api=async(route,method='GET',body)=>{
 const response=await fetch(new URL(route,ready.url),{method,headers:{'content-type':'application/json','x-opencorvus-directory':ready.session.directory},...(body?{body:JSON.stringify(body)}:{}),signal:AbortSignal.timeout(Math.min(180000,ready.closeBy-Date.now()))})
 const result=await response.json();assert.equal(response.status,200,route);return result
}
const sessions=await api('/session')
const side=sessions.find(item=>item.parentID===undefined&&item.metadata?.sideChat?.sourceSessionID===ready.sessionID)
assert(side,'Real UI-created independent Side Chat root');assert.equal(side.projectID,ready.session.projectID);assert.equal(path.resolve(side.directory),path.resolve(ready.session.directory))
if(mode==='prompt'){
 const body={messageID:'msg_'+randomUUID(),agent:'chat',model:{providerID:'side-fixture',modelID:'session-prompt-owner-model'},parts:[{type:'text',text:'Ask me the public reconnect draft question in this independent Side Chat, then record my exact answer.'}]}
 await fs.writeFile(path.join(root,'side-question-prompt.json'),JSON.stringify({side,body},null,2),{flag:'wx'})
 console.log(JSON.stringify({sideSessionID:side.id,mainSessionID:ready.sessionID,purpose:'Visible public API prompt in real UI-created Side Chat'}))
 const response=await api('/session/'+side.id+'/message','POST',body)
 await fs.writeFile(path.join(root,'side-question-prompt-response.json'),JSON.stringify(response,null,2),{flag:'wx'})
}else{
 const [conversation,messages,questions]=await Promise.all([api('/session/'+side.id+'/conversation'),api('/session/'+side.id+'/message'),api('/question')])
 const facts={observedAt:new Date().toISOString(),ready,side,conversation,messages,questions}
 const output=path.join(root,'side-question-facts-'+Date.now()+'.json');await fs.writeFile(output,JSON.stringify(facts,null,2),{flag:'wx'})
 if(mode==='answered'){
  assert(answer)
  const call=messages.flatMap(message=>message.parts.map(part=>({message,part}))).find(({part})=>part.type==='tool'&&part.tool==='question')
  assert(call);assert.equal(call.message.info.sessionID,side.id);assert.equal(call.part.state.status,'completed');assert.deepEqual(call.part.state.metadata.answers,[[answer]])
  const final=messages.findLast(message=>message.info.role==='assistant'&&message.info.finish==='stop'&&Number.isFinite(message.info.time.completed))
  assert(final);assert.equal(final.info.sessionID,side.id);assert.equal(final.info.parentID,call.message.info.parentID);assert.deepEqual(final.parts.filter(part=>part.type==='text').map(part=>part.text),['provider reply 2']);assert.equal(conversation.board.status,'idle')
  const check={output,sideSessionID:side.id,toolCallID:call.part.callID,answers:call.part.state.metadata.answers,finalMessageID:final.info.id,status:conversation.board.status}
  await fs.writeFile(output.replace('.json','.answered-check.json'),JSON.stringify(check,null,2),{flag:'wx'});console.log(JSON.stringify(check))
 }else console.log(JSON.stringify({output,sideSessionID:side.id,pendingQuestionIDs:conversation.pendingQuestions.map(item=>item.id)}))
}
