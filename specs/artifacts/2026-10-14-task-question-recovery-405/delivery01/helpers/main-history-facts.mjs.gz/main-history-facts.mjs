import fs from 'node:fs/promises'
import path from 'node:path'
import assert from 'node:assert/strict'

// Public API observations only. Decisions remain real Root page actions.
// This script never calls reply, reject, abort, dispose, or a product debug API.
const [scope, mode, pendingName, answer] = process.argv.slice(2)
assert(scope && path.isAbsolute(scope), 'Explicit absolute owned scope required')
assert.equal(path.dirname(path.resolve(scope)), import.meta.dirname, 'Direct 405 scope required')
assert(['pending', 'answered', 'rejected'].includes(mode), 'Exact public observation mode required')
const ready = JSON.parse(await fs.readFile(path.join(scope, 'ready.json'), 'utf8'))
assert.equal(ready.scenario, 'warm-question')
assert.equal(ready.session.id, ready.sessionID)
assert(Date.now() < ready.closeBy, 'Original owned close reserve reached')
const start = JSON.parse(await fs.readFile(path.join(scope, 'global-chat-start.json'), 'utf8'))
assert.equal(start.status, 202)
assert.equal(start.acceptance.session.id, ready.sessionID)
const get = async route => {
  const remaining = ready.closeBy - Date.now()
  assert(remaining > 0, 'Original owned close reserve reached')
  const response = await fetch(new URL(route, ready.url), {
    headers: { 'x-opencorvus-directory': ready.session.directory },
    signal: AbortSignal.timeout(Math.min(30000, remaining)),
  })
  const text = await response.text()
  let body
  try { body = JSON.parse(text) } catch { body = text }
  return { route, status: response.status, body }
}
const responses = await Promise.all([
  `/session/${encodeURIComponent(ready.sessionID)}/message`,
  `/session/${encodeURIComponent(ready.sessionID)}/conversation`,
  '/question',
].map(get))
const [messagesResponse, conversationResponse, questionResponse] = responses
const output = path.join(scope, `main-history-${mode}-${Date.now()}.json`)
await fs.writeFile(output, JSON.stringify({ observedAt: new Date().toISOString(), ready, mode, responses }, null, 2) + '\n', { flag: 'wx' })
for (const response of responses) assert.equal(response.status, 200, response.route)
const messages = messagesResponse.body, conversation = conversationResponse.body, questions = questionResponse.body
assert(Array.isArray(messages)); assert(Array.isArray(questions)); assert(Array.isArray(conversation.pendingQuestions))
const user = messages.find(item => item.info.id === start.acceptance.messageID)
assert(user, 'Original publicly accepted user input')
assert.equal(user.info.role, 'user'); assert.equal(user.info.sessionID, ready.sessionID)
let request
if (mode === 'pending') {
  const pending = conversation.pendingQuestions.filter(item => item.sessionID === ready.sessionID)
  assert.equal(pending.length, 1, 'Exact current Main Question count')
  request = pending[0]
  const { orderKey, ...canonical } = request
  assert.equal(typeof orderKey, 'string')
  assert.deepEqual(questions.find(item => item.id === request.id), canonical)
  assert.equal(request.questions[0].header, '')
  assert.equal(request.expiry.origin, 'deadline'); assert.equal(request.expiry.timeoutMs, 30000)
  assert.equal(request.expiry.timeExpires, request.timeCreated + 30000)
  assert(Date.now() < request.expiry.timeExpires, 'Observe the real pending Question before its original expiry')
} else {
  assert(pendingName && path.basename(pendingName) === pendingName, 'Explicit original pending observation basename required')
  const original = JSON.parse(await fs.readFile(path.join(scope, pendingName), 'utf8'))
  assert.equal(original.mode, 'pending'); assert.equal(original.ready.sessionID, ready.sessionID)
  assert.equal(original.ready.deadlineAt, ready.deadlineAt)
  assert.deepEqual(original.ready.occurrence, ready.occurrence)
  request = original.responses[1].body.pendingQuestions.find(item => item.sessionID === ready.sessionID)
  assert(request, 'Actual original pending Question')
}
assert.equal(request.sessionID, ready.sessionID)
assert(request.tool?.messageID && request.tool?.callID, 'Original public Tool binding')
const toolMessage = messages.find(item => item.info.id === request.tool.messageID)
assert(toolMessage, 'Actual original Question assistant message')
assert.equal(toolMessage.info.sessionID, ready.sessionID); assert.equal(toolMessage.info.parentID, user.info.id)
const tool = toolMessage.parts.find(item => item.type === 'tool' && item.tool === 'question' && item.callID === request.tool.callID)
assert(tool, 'Actual original Question Tool Part')
let final
if (mode === 'pending') {
  assert.equal(tool.state.status, 'running')
} else {
  assert.equal(tool.state.status, 'completed')
  assert.equal(tool.state.metadata.status, mode)
  if (mode === 'answered') {
    assert(answer, 'Explicit exact UI-submitted custom answer required')
    assert.deepEqual(tool.state.metadata.answers, [[answer]])
  } else assert.equal(tool.state.metadata.answers, null)
  final = messages.findLast(item => item.info.role === 'assistant' && item.info.parentID === user.info.id && item.info.finish === 'stop' && Number.isFinite(item.info.time.completed))
  assert(final, 'Natural final streamed response for the original accepted input')
  assert.equal(final.info.sessionID, ready.sessionID)
  assert.deepEqual(final.info.acceptedInputMessageIDs, [user.info.id])
  assert.deepEqual(final.parts.filter(item => item.type === 'text').map(item => item.text), ['provider reply 2'])
  assert.equal(conversation.board.status, 'idle')
}
const result = { output, mode, sessionID: ready.sessionID, questionID: request.id, originalTimeCreated: request.timeCreated,
  originalExpiry: request.expiry, toolMessageID: toolMessage.info.id, callID: tool.callID, toolState: tool.state,
  finalMessageID: final?.info.id, boardStatus: conversation.board.status,
  boundary: 'Public API + original Tool positive contract only. Real UI action/screenshots are Root evidence. No durable publication origin/timeResolved assertion, no infrastructure terminal claim.' }
await fs.writeFile(output.replace('.json', '.check.json'), JSON.stringify(result, null, 2) + '\n', { flag: 'wx' })
console.log(JSON.stringify(result))
