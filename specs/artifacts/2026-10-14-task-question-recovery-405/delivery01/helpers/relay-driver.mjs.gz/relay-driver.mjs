import fs from 'node:fs/promises'
import { appendFileSync } from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { randomUUID } from 'node:crypto'
import { startHttpRelay } from '../.tmp-task-git-question-reconnect-404/http-relay.mjs'

const parentDirectory = path.dirname(fileURLToPath(import.meta.url))
const configPath = path.resolve(process.argv[2] ?? '')
const config = JSON.parse(await fs.readFile(configPath, 'utf8'))
const scope = path.resolve(config.scope)
if (path.dirname(scope) !== parentDirectory) throw new Error('Scope must be a direct new child of owned 405 scratch')
const startedAt = Date.now()
for (const name of ['ownerPID', 'deadlineAt', 'closeBy']) if (!Number.isSafeInteger(config[name])) throw new Error(`Explicit ${name} required`)
if (config.ownerPID < 1 || config.closeBy <= startedAt || config.deadlineAt <= config.closeBy || config.deadlineAt > startedAt + 600_000 ||
    typeof config.ownerOccurrence !== 'string' || !config.ownerOccurrence) throw new Error('Original fixed owner and at most 600000ms physical deadline required')
await fs.mkdir(scope, { recursive: false })
await fs.mkdir(path.join(scope, 'control-inbox'))
await fs.mkdir(path.join(scope, 'control-receipts'))
const occurrence = randomUUID()
const owner = { pid: process.pid, launcherPID: process.ppid, occurrence, ownerPID: config.ownerPID,
  ownerOccurrence: config.ownerOccurrence, startedAt, deadlineAt: config.deadlineAt, closeBy: config.closeBy,
  ownerObservation: 'kill(pid, 0) checks liveness only; parent owned_tree and original occurrence receipts establish physical identity' }
await fs.writeFile(path.join(scope, 'owner.json'), JSON.stringify(owner, null, 2), { flag: 'wx' })
const relay = await startHttpRelay({ upstream: config.upstream,
  onEvent: event => appendFileSync(path.join(scope, 'events.jsonl'), JSON.stringify(event) + '\n') })
await fs.writeFile(path.join(scope, 'ready.json'), JSON.stringify({ ...owner, url: relay.url, uiURL: relay.url + '/ui', upstream: config.upstream,
  controls: ['status', 'cut', 'shutdown'], purpose: 'Manual exact Session SSE transport interruption; no UI automation' }, null, 2), { flag: 'wx' })
console.log(JSON.stringify({ ready: true, scope, occurrence, url: relay.url, closeBy: config.closeBy }))
let closing
let polling = false
let poll
let timer
async function close(reason) {
  if (closing) return closing
  clearInterval(poll); clearTimeout(timer)
  closing = (async () => {
    const result = await relay.close(reason)
    await fs.writeFile(path.join(scope, 'terminal.json'), JSON.stringify({ ...owner, ...result, finishedAt: Date.now(),
      status: 'closed', underlyingProductServer: 'untouched; original product owner remains responsible', physical: 'Listener closed only; physical process join is unconfirmed until original parent owned_tree receipt' }, null, 2), { flag: 'wx' })
    console.log(JSON.stringify({ closed: true, reason, occurrence }))
  })()
  return closing
}
async function controlPass() {
  if (polling || closing) return
  polling = true
  try {
    try { process.kill(config.ownerPID, 0) }
    catch (error) { if (error.code === 'ESRCH') { await close('original-owner-exited'); return } throw error }
    try { await fs.stat(path.join(scope, 'stop-requested')); await close('original-owner-stop-requested'); return }
    catch (error) { if (error.code !== 'ENOENT') throw error }
    const names = (await fs.readdir(path.join(scope, 'control-inbox'))).filter(name => /^[a-f0-9-]+\.json$/.test(name)).sort()
    for (const name of names) {
      const receiptPath = path.join(scope, 'control-receipts', name)
      try { await fs.stat(receiptPath); continue } catch (error) { if (error.code !== 'ENOENT') throw error }
      const input = JSON.parse(await fs.readFile(path.join(scope, 'control-inbox', name), 'utf8'))
      if (input.occurrence !== occurrence) throw new Error('Control occurrence does not own this relay')
      let result
      if (input.action === 'status') result = relay.status()
      else if (input.action === 'cut') result = relay.cutSessionStreams(input.sessionID)
      else if (input.action === 'shutdown') { await close('manual-control-shutdown'); result = { status: 'closed' } }
      else throw new Error('Unknown owned relay control')
      await fs.writeFile(receiptPath, JSON.stringify({ id: input.id, occurrence, action: input.action, at: Date.now(), result }, null, 2), { flag: 'wx' })
      if (closing) break
    }
  } catch (error) {
    console.error(error)
    process.exitCode = 1
    await close('control-error')
  } finally { polling = false }
}
poll = setInterval(() => { void controlPass() }, 100)
timer = setTimeout(() => { void close('original-closeBy') }, config.closeBy - Date.now())
process.on('SIGINT', () => { void close('original-owner-signal') })
process.on('SIGTERM', () => { void close('original-owner-signal') })
