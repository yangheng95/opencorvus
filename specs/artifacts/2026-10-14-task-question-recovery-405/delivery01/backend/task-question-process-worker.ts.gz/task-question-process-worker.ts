import fs from "node:fs/promises"
import path from "node:path"
import assert from "node:assert/strict"
import { randomUUID } from "node:crypto"
import { phaseBConfig } from "../.tmp-native-shutdown-pending-permission-403/phase-b-input"
import { Database, eq, and } from "../packages/opencorvus/src/storage/db"
import { Instance } from "../packages/opencorvus/src/project/instance"
import { Bus } from "../packages/opencorvus/src/bus"
import { BusPublicationOutboxTable, BusPublicationPhaseReceiptTable } from "../packages/opencorvus/src/bus/bus.sql"
import { Question } from "../packages/opencorvus/src/question"
import { Identifier } from "../packages/opencorvus/src/id/id"
import { PermissionRequest } from "../packages/opencorvus/src/permission/types"
import { SessionPromptOwner } from "../packages/opencorvus/src/session/prompt/owner"
import { MessageTable } from "../packages/opencorvus/src/session/session.sql"
import { EngineControlActivationLeaseTable, EngineGitCheckpointRequestTable, EngineGitCheckpointOutcomeTable, EngineTaskTable } from "../packages/opencorvus/src/engine/engine.sql"
import { currentControlLeaseInTransaction } from "../packages/opencorvus/src/engine/control-lease"
import { observeProcessLiveness } from "../packages/opencorvus/src/engine/process-liveness"
import { findInteractionByExternal } from "../packages/opencorvus/src/engine/store"
import { currentRuntimeProcessOccurrence } from "../packages/opencorvus/src/runtime/process-occurrence"
import { declareNativeTaskProcessDeployment } from "../packages/opencorvus/src/runtime/task-process-deployment"
import { installProcessShims } from "../packages/opencorvus/src/runtime/shims"
import { installDefaultControlPlaneToolLoaders } from "../packages/opencorvus/src/tool/control-plane-tool-composition"
import { listenWithRecoveredServerRuntime } from "../packages/opencorvus/src/cli/server-runtime"
import { recoverStartedTaskExecutions, assertStartedTaskProjectRecoverySucceeded } from "../packages/opencorvus/src/engine/host-recovery"

const [mode, runtime, evidence, providerURL, rawDeadline] = process.argv.slice(2)
const deadlineAt = Number(rawDeadline), closeBy = deadlineAt - 15000
assert(["crash", "recover", "live-a", "live-b"].includes(mode!) && runtime && evidence && path.isAbsolute(runtime) && path.isAbsolute(evidence))
assert(Number.isSafeInteger(deadlineAt) && deadlineAt > Date.now() && deadlineAt <= Date.now() + 180000)
assert.equal(process.env.OPENCORVUS_HOME, runtime)
const directory = path.join(runtime, "public-project")
const headers = { "content-type": "application/json", "x-opencorvus-directory": directory }
const write = (name: string, value: unknown) => fs.writeFile(path.join(evidence, `${mode}-${name}.json`), JSON.stringify(value, null, 2))
let observed: Awaited<ReturnType<typeof listenWithRecoveredServerRuntime>> | undefined
let stopAskedObserver: (() => void) | undefined, releaseAskedDelivery: (() => void) | undefined, deliberateCrash = false
let admittedTaskID: string | undefined
let currentControlPrompt: Promise<any> | undefined
const http: any[] = []
async function api(route: string, method = "GET", body?: unknown) {
  assert(Date.now() < closeBy, "Original request admission deadline")
  const response = await fetch(new URL(route, observed!.server.url), { method, headers, ...(body === undefined ? {} : { body: JSON.stringify(body) }), signal: AbortSignal.timeout(Math.min(30000, closeBy - Date.now())) })
  const raw = await response.text()
  const result = { route, method, status: response.status, body: JSON.parse(raw), observedAt: Date.now() }
  http.push(result)
  return result
}
async function until(check: () => Promise<boolean>, label: string, end = Math.min(Date.now() + 30000, closeBy)) {
  while (!(await check())) { if (Date.now() >= end) throw Error(`Prerequisite timed out: ${label}`); await Bun.sleep(100) }
}
async function publishReady(name: string, value: unknown) {
  const temporary = path.join(evidence, `${name}.pending`), final = path.join(evidence, name)
  await fs.writeFile(temporary, JSON.stringify(value, null, 2), { flag: "wx" })
  await fs.rename(temporary, final)
}
async function waitForMarker(name: string) {
  for (;;) {
    try { await fs.stat(path.join(evidence, "live-stop-requested")); throw Error("Original parent requested live scope closure") }
    catch (error) { if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error }
    try { await fs.stat(path.join(evidence, name)); return }
    catch (error) { if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error }
    if (Date.now() >= closeBy - 10000) throw Error(`Original live child reserve reached waiting for ${name}`)
    await Bun.sleep(100)
  }
}
async function selected(taskID: string, request?: Question.Request) {
  const transcript = await api(`/task/${taskID}/transcript`)
  assert.equal(transcript.status, 200)
  return Instance.provideProjectIdentity({ directory, fn: () => Database.use(db => {
    const task = db.select().from(EngineTaskTable).where(eq(EngineTaskTable.id, taskID)).get()
    assert(task && task.project_id === Instance.project.id)
    const baseline = db.select({ request: EngineGitCheckpointRequestTable, outcome: EngineGitCheckpointOutcomeTable }).from(EngineGitCheckpointRequestTable).leftJoin(EngineGitCheckpointOutcomeTable, eq(EngineGitCheckpointOutcomeTable.request_id, EngineGitCheckpointRequestTable.id)).where(and(eq(EngineGitCheckpointRequestTable.task_id, taskID), eq(EngineGitCheckpointRequestTable.stage, "baseline"))).all()
    if (!request) return { task, baseline, transcript }
    assert(request.tool, "Actual Question requires original physical Tool binding")
    const ownerMessage = db.select().from(MessageTable).where(and(eq(MessageTable.id, request.tool.messageID), eq(MessageTable.session_id, request.sessionID))).get()
    assert(ownerMessage && ownerMessage.data.role === "assistant")
    const assistant = { ...ownerMessage.data, id: ownerMessage.id, sessionID: ownerMessage.session_id } as any
    assert.equal(typeof assistant.activationID, "string", "Actual Task-root activation required")
    const lease = db.select().from(EngineControlActivationLeaseTable).where(eq(EngineControlActivationLeaseTable.id, assistant.activationID)).get()
    assert(lease && lease.target === "task_root_ingress")
    const runtimeReceipt = currentControlLeaseInTransaction(db, "runtime_process", lease.owner_occurrence_id)
    assert(runtimeReceipt, "Exact original runtime process receipt")
    const runtimeIdentity = JSON.parse(runtimeReceipt.owner_occurrence_id)
    const tool = transcript.body.flatMap((entry: any) => entry.parts).find((part: any) => part.type === "tool" && part.messageID === request.tool!.messageID && part.callID === request.tool!.callID)
    assert(tool && tool.tool === "question", "Actual Question Tool from public transcript")
    const facts = Question.publicationFacts({ projectID: task.project_id, sessionID: request.sessionID, requestID: request.id })
    const original = db.select().from(BusPublicationOutboxTable).where(eq(BusPublicationOutboxTable.occurrence_id, facts.askedOccurrenceID)).get()
    const phases = db.select().from(BusPublicationPhaseReceiptTable).where(eq(BusPublicationPhaseReceiptTable.occurrence_id, facts.askedOccurrenceID)).all()
    return { task, baseline, transcript, assistant, tool, lease, runtimeReceipt, runtimeIdentity, osObservation: observeProcessLiveness(lease.owner_occurrence_id), promptOwner: SessionPromptOwner.current(request.sessionID), publication: { facts, original, phases }, interaction: findInteractionByExternal(request.id) }
  }) })
}
try {
  installProcessShims(); installDefaultControlPlaneToolLoaders(); declareNativeTaskProcessDeployment()
  await fs.mkdir(directory, { recursive: true })
  await write("owner", { mode, pid: process.pid, occurrence: currentRuntimeProcessOccurrence(), deadlineAt, closeBy, directory, runtime })
  observed = await listenWithRecoveredServerRuntime({ options: { hostname: "127.0.0.1", port: 0, randomPort: true }, recover: async () => { assertStartedTaskProjectRecoverySucceeded(await recoverStartedTaskExecutions({ scopeProjectWorktree: directory })) }, disposeInstances: () => Instance.disposeAll() })
  await observed.recovery
  await write("listener", { url: observed.server.url.toString(), occurrence: observed.occurrence, deadlineAt })
  if (mode === "crash" || mode === "live-a") {
    const config = phaseBConfig(providerURL)
    config.prompt_profile.active = "research-studio"
    if (mode === "live-a") {
      assert(process.env.OPENCORVUS_TASK_QUESTION_CONTROL_URL, "Explicit independent current-control Provider required")
      config.enabled_providers.push("question-control-405")
      ;(config.provider as any)["question-control-405"] = { ...config.provider["shutdown-fixture"], name: "Public backend B Question control", api: process.env.OPENCORVUS_TASK_QUESTION_CONTROL_URL }
    }
    const configured = await api("/global/config", "PATCH", config)
    await write("config", configured); assert.equal(configured.status, 200)
    const profile = [await api("/expert-squad/catalog"), await api("/skill/mounts")]
    await write("preflight", profile)
    assert.deepEqual(profile.map(x => x.status), [200, 200])
    assert.equal(profile[0].body.active.effective, "research-studio")
    await fs.writeFile(path.join(directory, "public-source.csv"), "source,quantity\nCedar,3\nIris,4\n", { flag: "wx" })
    const input = { requestID: randomUUID(), title: "Public Question recovery 405", request: "Prepare a short comparison of the public Cedar and Iris research samples. Ask me which source to focus on before drafting the report.", productPillar: "work", promptProfile: "research-studio", model: "shutdown-fixture/session-prompt-owner-model" }
    const accepted = await api("/task?init-git=true", "POST", input)
    await write("task-accepted", { input, accepted }); assert.equal(accepted.status, 202)
    const taskID = accepted.body.task_id
    admittedTaskID = taskID
    assert.equal(accepted.body.directory, directory)
    let baseline: any
    await until(async () => { baseline = await selected(taskID); return baseline.baseline.some((item: any) => item.outcome) }, "natural Task baseline")
    const rootBaseline = baseline.baseline.find((item: any) => item.request.operation_key === "baseline:1")
    await write("baseline", baseline)
    assert.equal(rootBaseline?.outcome?.result?.checkpoint_receipt?.outcome, "success", "Actual baseline checkpoint receipt")
    const askedDelivery = Promise.withResolvers<void>()
    releaseAskedDelivery = askedDelivery.resolve
    stopAskedObserver = await Instance.provideProjectIdentity({ directory, fn: () => Bus.subscribeAll((event) => {
      if (event.type !== Question.Event.Asked.type) return
      return askedDelivery.promise
    }) })
    await fs.writeFile(path.join(evidence, "release-first-question"), "Original Task baseline ready; release actual first Provider response.\n", { flag: "wx" })
    let permission: PermissionRequest | undefined, permissionTool: any
    await until(async () => {
      const listed = await api("/permission")
      assert.equal(listed.status, 200)
      const candidates = PermissionRequest.array().parse(listed.body).filter(item => item.projectID === accepted.body.project_id && item.taskID === taskID && item.providerKind === "projected" && item.providerID === "question" && item.toolName === "question")
      assert(candidates.length <= 1, "One exact projected Question permission")
      permission = candidates[0]
      if (!permission) return false
      const current = await selected(taskID)
      permissionTool = current.transcript.body.flatMap((entry: any) => entry.parts).find((part: any) => part.type === "tool" && part.sessionID === permission!.sessionID && part.messageID === permission!.messageID && part.callID === permission!.toolCallID)
      assert(permissionTool && permissionTool.tool === "question" && permissionTool.state.status === "running")
      assert.deepEqual((permission.scope.resource as { arguments: unknown }).arguments, permissionTool.state.input)
      return true
    }, "exact public Task Question permission")
    const permissionDecision = await api(`/permission/${permission!.id}/reply`, "POST", { decision: "allow_once", message: "Approve this public research clarification Tool once for the 405 recovery check." })
    await write("permission", { request: permission, tool: permissionTool, decision: permissionDecision })
    assert.equal(permissionDecision.status, 200)
    assert.equal(permissionDecision.body.request.id, permission!.id)
    assert.equal(permissionDecision.body.decision, "allow_once")
    let request: Question.Request | undefined
    await until(async () => { const listed = await api("/question"); assert.equal(listed.status, 200); request = listed.body.find((item: Question.Request) => item.tool); return Boolean(request) }, "actual ordinary Task Question admission")
    const snapshot: any = await selected(taskID, request)
    assert.equal(snapshot.tool.state.status, "running")
    assert.equal(snapshot.runtimeIdentity.occurrenceID, currentRuntimeProcessOccurrence().occurrenceID)
    assert.equal(snapshot.osObservation, "exact_live")
    assert.equal(snapshot.publication.original.event_type, "question.asked")
    assert.deepEqual(snapshot.publication.original.properties, request)
    assert.equal(snapshot.publication.phases.filter((phase: any) => phase.phase === "wildcard").length, 0, "Accepted Asked before wildcard delivery")
    const checkpoint = { input, accepted, profile, permission, permissionDecision, taskID, request, snapshot, recordedAt: Date.now() }
    await fs.writeFile(path.join(evidence, "checkpoint.json"), JSON.stringify(checkpoint, null, 2))
    await write("http", http)
    if (mode === "crash") {
      deliberateCrash = true
      console.log(JSON.stringify({ checkpoint: "actual public Task Question accepted", taskID, requestID: request!.id, activationID: snapshot.assistant.activationID, exitCode: 23 }))
      process.exit(23)
    }
    await publishReady("live-a-ready.json", checkpoint)
    await waitForMarker("live-answer-questions")
    releaseAskedDelivery?.()
    stopAskedObserver?.()
    const reply = await api(`/question/${request!.id}/reply`, "POST", { answers: [["cedar"]] })
    let after: any
    await until(async () => { after = await selected(taskID, request); return after.tool.state.status === "completed" }, "A actual Question Tool completion")
    await publishReady("live-a-answered.json", { reply, snapshot: after, answeredAt: Date.now() })
    await waitForMarker("live-b-answered.json")
  }
  if (mode === "recover" || mode === "live-b") {
  const original = JSON.parse(await fs.readFile(path.join(evidence, "checkpoint.json"), "utf8"))
  const request = Question.Request.parse(original.request)
  const originalOwnerObservation = observeProcessLiveness(original.snapshot.lease.owner_occurrence_id)
  if (mode === "live-b") {
    admittedTaskID = original.taskID
    assert.equal(originalOwnerObservation, "exact_live", "Original A process remains alive")
    const before = await selected(original.taskID, request)
    const created = await api("/session", "POST", { kind: "assistant", title: "Actual independent backend B Question control 405" })
    assert.equal(created.status, 200)
    const controlSession = created.body
    assert.equal(controlSession.parentID, undefined, "Public control is a genuine independent root")
    const controlModel = { providerID: "question-control-405", modelID: "session-prompt-owner-model" }
    const messageID = Identifier.ascending("message")
    currentControlPrompt = api(`/session/${controlSession.id}/message`, "POST", { messageID, agent: "chat", model: controlModel, parts: [{ type: "text", text: "Ask the public Maple question so I can answer through this backend's normal Question interface." }] })
    void currentControlPrompt.catch(() => undefined)
    let controlRequest: Question.Request | undefined
    await until(async () => {
      const pending = await api("/question")
      assert.equal(pending.status, 200)
      controlRequest = Question.Request.array().parse(pending.body).find(item => item.sessionID === controlSession.id)
      return Boolean(controlRequest)
    }, "Actual backend B root Session Question")
    const messages = await api(`/session/${controlSession.id}/message`)
    const controlTool = messages.body.flatMap((entry: any) => entry.parts).find((part: any) => part.type === "tool" && part.callID === controlRequest!.tool!.callID && part.messageID === controlRequest!.tool!.messageID)
    assert(controlTool && controlTool.tool === "question" && controlTool.state.status === "running")
    const controlOwnership = await Instance.provideProjectIdentity({ directory, fn: () => {
      const promptOwner = SessionPromptOwner.current(controlSession.id)
      assert(promptOwner)
      assert.equal(promptOwner.owner_pid, process.pid)
      assert.equal(promptOwner.owner_occurrence_id, currentRuntimeProcessOccurrence().occurrenceID)
      return { promptOwner, osObservation: SessionPromptOwner.observation(promptOwner) }
    } })
    const canonical = await api("/question")
    const originalAtReady = await selected(original.taskID, request)
    assert.equal(originalAtReady.osObservation, "exact_live")
    await publishReady("live-b-ready.json", { backend: currentRuntimeProcessOccurrence(), original: { before, snapshot: originalAtReady }, canonical, control: { session: controlSession, inputMessageID: messageID, request: controlRequest, tool: controlTool, ...controlOwnership }, readyAt: Date.now() })
    await waitForMarker("live-answer-questions")
    const reply = await api(`/question/${controlRequest!.id}/reply`, "POST", { answers: [["Actual backend B Maple answer"]] })
    const completed = await currentControlPrompt
    const afterMessages = await api(`/session/${controlSession.id}/message`)
    const tool = afterMessages.body.flatMap((entry: any) => entry.parts).find((part: any) => part.id === controlTool.id)
    await publishReady("live-b-answered.json", { reply, completed, tool, answeredAt: Date.now() })
    await waitForMarker("live-a-answered.json")
    await write("live-final", { original: await selected(original.taskID, request), canonical: await api("/question"), observedAt: Date.now() })
  } else {
  assert.equal(originalOwnerObservation, "dead_or_reused")
  let snapshot: any, toolSettled = false
  // Production lease is 120s. Observe its actual existing timer, never shorten it.
  const observations: any[] = []
  while (Date.now() < closeBy - 10000) {
    snapshot = await selected(original.taskID, request)
    observations.push({ at: Date.now(), toolStatus: snapshot.tool.state.status, assistantCompleted: snapshot.assistant.time.completed, leaseExpiry: snapshot.lease.expires_at, questionTerminal: snapshot.publication.facts.terminal, interaction: snapshot.interaction })
    if (["error", "completed"].includes(snapshot.tool.state.status)) { toolSettled = true; break }
    await Bun.sleep(500)
  }
  const board = await api(`/task/${original.taskID}/board`)
  const pending = await api("/question")
  await write("observation", { originalOwnerObservation, snapshot, board, pending, toolSettled, observations, observedAt: Date.now(), timestampBoundary: "Tool end/lease expiry are actual stored fields; OS death is separately observed, no Question terminal synthesized" })
  }
  }
} catch (error) {
  await write("failure", { name: error instanceof Error ? error.name : "unknown", message: String(error), stack: error instanceof Error ? error.stack : undefined })
  console.error(error); process.exitCode = 1
  if (observed && admittedTaskID && Date.now() < closeBy) {
    try { await write("failed-task-observation", { selected: await selected(admittedTaskID), board: await api(`/task/${admittedTaskID}/board`), pending: await api("/question") }) }
    catch (observationError) { await write("failure-observation-error", { error: String(observationError) }) }
  }
} finally {
  if (!deliberateCrash) {
    releaseAskedDelivery?.()
    stopAskedObserver?.()
    await observed?.server.stop(true)
    await observed?.recovery
    await currentControlPrompt?.catch(() => undefined)
    await Instance.disposeAll(); await Database.awaitEffectIdle(5000); Database.close()
    await write("http", http)
    await write("closed", { pid: process.pid, endedAt: Date.now(), deadlineAt, serverStopped: true, databaseClosed: true })
  }
}
