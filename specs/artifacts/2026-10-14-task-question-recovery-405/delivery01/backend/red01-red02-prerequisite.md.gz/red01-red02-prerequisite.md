# 原Task红态前置01/02（目标恢复尚未到达）

两个scope均保留实际helper/source-at-launch、输入、公开回执、Provider公开fixture请求、stderr及原owner。没有producer crash23或新recover child；首正式断言均是预期23而实际正常错误退出1，不能称Question恢复红。

| Scope | 原父开始/截止/结束 | 实际child | 结算 |
|---|---|---|---|
| task-process-red-01 | 1791934916323 / 1791935516323 / 1791934967465 | PID89160，runtime occurrence56715782-e2be-4741-8d68-d92db6c9aec9，NodeProcess occurrence17376b57-2155-49bf-a6c9-99fdce67e15a，exit1 | parent exec87628 exit1；physical/output/request全部true、Provider关闭、runtime在child退出后父删除 |
| task-process-red-02 | 1791935135314 / 1791935735314 / 1791935200904 | PID39436，runtime occurrence84fb3d34-d85c-4d3b-bcca-a77b9adeec94，原childdeadline1791935322261，exit1 | parent exec3535 exit1；全部物理/输出/请求及Provider/runtime闭合，见原cleanup |

两轮都以实际公共PATCH选择完整research-studio，catalog/mounts200、Task202、真实baseline成功。原firstPrompt正确声明question；成熟fixture产生真实streaming Tool call。known memory fixture返回organized/empty markdown触发真实schema拒绝，独立记录，不归Question根因。

red01未记录parent的release时刻或失败前的最终Tool状态，不能从其最后timeout判断响应未释放/产品失败。red02只增加这些观察，未改任何生产、fixture响应、deadline或预期。实际provider-release-observation：marker在1791935169679可见，首prompt在1791935172119释放并构造响应。因此不是Provider未释放。

red02/crash-failed-task-observation.json保存失败前的真实公开transcript：running Question Tool prt_g0VXybMha00jTsFUhUwq，call_controlled_recovery_next，原assistant msg_hPcpOK61XrwEcmiMqt5d，activation act_g0VXybJto00IRIVJPsSQ，正确question输入和time.start1791935172126；Question公开集合仍[]，原task-tools question执行日志尚未出现。只读ToolPartRequest原SQL未在此失败分支保存，不能虚称已核其表行；原公开Part与Message保持。

helper目前在baseline成功后、Question之前调用全局suppressAutomaticDurableDrain，实际影响所有随后Task/Message durable发布。源Bus该hook仅全局boolean（1305），publishForProjectInTransaction的effect（1098）对任意type提前return。故这不是授权目标的“仅原Asked delivery hold”。当前证据排除了Provider未释放并定位到Question执行前的window；确切哪个upstream durable-await仍需更窄运行确认，不能凭最后running Tool推导任意业务故障。

已报告Root的最小调整候选（未实施/未启动03）：移除早global suppression；使用已有Bus.subscribeAll注册只对原type=question.asked的观察回调返回自己的hold Promise，其余事件同步返回。只有真实Question已提交并到达该原publication wildcard阶段才持有，原Task/Tool之前事实照常流动。成功checkpoint后原process exit23；失败finally先release该observer再普通stop/join。这个合同可能允许Task exact物化先完成，需如实保留当前row，不能把它当source-only未物化。源Bus没有event-specific acceptance TestHook，不能自行改production加debuggate。等Root审API/时序后调整。

## red03后因果纠正（原推断不得冒充证据）

Root批准的Asked-only观察者已用于fresh red03，原Model响应已释放但仍同样Question准入超时。原scope开始1791935454493、截止1791936054493、结束1791935506730；producer84692/runtime8eaaae27-3059-4d35-8df9-232e6167978d正常stop后exit1，父exec63960 exit1，physical/output/request/provider/runtime均闭合。没有crash23或recover child。

对red02/03保存的完整Board复核，明确都有pending **Permission**，不是Question：red02 per_hkRyfcTMr6uTRZnhNJFb；red03 per_huhUXxZX3dCgZGswk4da。payload.providerKind=projected、providerID/toolName=question、effectClass=external_effect、mode=ask，精确tool.messageID/callID绑定同running Tool。该合法投影工具需要先经过正常Ask权限准入；helper只轮询/question，遗漏了这个公开交互。故当前**已证实原因是缺少Permission批准**。此前global suppression会触及其它事实只是代码风险，不能宣称它已实际造成这两次阻塞。Asked-only仍是更精确的授权hold范围，但其替换不能当成已修本次前置失败。

最小helper输入修正：从GET/permission选择精确原Task/Project对应的question projected Request，核对公开Task transcript的原message/call/input，以及scope.resource.arguments；随后只对这个ID调用正式POST/permission/:id/reply，body decision=allow_once及明确公开测试理由。该route经过原PermissionAuthority.replyUser并产生真实http.permission用户输入；不改变全局Ask、不allow_task、不直接调用Authority、不绕过权限、不生成Tool结果。之后继续原Question/crash流程，原120s/180s/600s边界与期待不变。旧三个scope和错误保留。
