import fs from "node:fs/promises"
import path from "node:path"
import { NodeProcess } from "../packages/util/src/process-node"
import { expectedTestProcessSupervisor } from "../packages/opencorvus/script/test-process-supervisor"

const [scope, scenario = "crash"] = process.argv.slice(2)
if (scenario !== "crash" || !scope || !path.isAbsolute(scope) || path.dirname(scope) !== path.resolve(import.meta.dir) || !path.basename(scope).startsWith("task-process-red-")) throw Error("Explicit fresh approved Task crash scope required")
await fs.mkdir(scope)
const startedAt = Date.now(), deadlineAt = startedAt + 600000
const supervisor = expectedTestProcessSupervisor()
if (!supervisor) throw Error("Existing formal process supervisor required")
process.env.OPENCORVUS_PROCESS_SUPERVISOR = supervisor
const names = ["task-question-process-runner.ts", "task-question-process.test.ts", "task-question-process-worker.ts"]
for (const name of names) await fs.copyFile(path.join(import.meta.dir, name), path.join(scope, `actual-${name}`))
await fs.copyFile(path.resolve(".tmp-native-shutdown-pending-permission-403/phase-b-input.ts"), path.join(scope, "actual-phase-b-input.ts"))
const sourceFiles = [
  "question/index.ts", "question/types.ts", "engine/interaction.ts", "engine/task-root-ingress-delivery.ts",
  "engine/task-root-fact-store.ts", "engine/control-lease.ts", "engine/process-liveness.ts", "engine/host-recovery.ts",
  "project/bootstrap.ts", "session/loop.ts", "session/compaction.ts", "session/prompt/owner.ts", "session/prompt/state.ts",
  "protocol/session-mirror.ts", "bus/index.ts", "storage/db.ts", "cli/server-runtime.ts", "orchestrator/interaction-tools.ts",
]
for (const file of sourceFiles) {
  const target = path.join(scope, "source-at-launch", file)
  await fs.mkdir(path.dirname(target), { recursive: true })
  await fs.copyFile(path.join("packages/opencorvus/src", file), target)
}
await fs.writeFile(path.join(scope, "source-observation.json"), JSON.stringify({ capturedAt: Date.now(), sourceFiles, boundary: "Observed current source at launcher admission; peer files retained for provenance only" }, null, 2))
const args = ["run", "--cwd", "packages/opencorvus", "test", "../../.tmp-task-question-recovery-405/task-question-process.test.ts"]
const env = { ...process.env, OPENCORVUS_TASK_QUESTION_EVIDENCE: scope, OPENCORVUS_TASK_QUESTION_DEADLINE: String(deadlineAt) }
const owner: any = { scenario, startedAt, deadlineAt, executable: process.execPath, args, cwd: process.cwd(), parentPID: process.pid }
await fs.writeFile(path.join(scope, "owner-start.json"), JSON.stringify(owner, null, 2))
let handle: any
try {
  const result = await NodeProcess.run({ command: { executable: process.execPath, args }, cwd: process.cwd(), env, ownership: "owned_tree", windowsHide: true, stdin: "ignore", deadlineAt, nothrow: true, onSpawned(h) { handle = h; owner.pid = h.pid; owner.occurrenceID = h.occurrenceID } })
  await fs.writeFile(path.join(scope, "stdout.log"), result.stdout)
  await fs.writeFile(path.join(scope, "stderr.log"), result.stderr)
  owner.receipt = result.receipt
  await handle.settled; await handle.outputSettled
  owner.physicalJoined = true; owner.outputJoined = true; owner.requestSettled = true
  process.exitCode = result.receipt.exitCode ?? 1
} catch (error) {
  owner.error = String(error); process.exitCode = 1
  if (handle) { owner.receipt = await handle.settled; await handle.outputSettled; owner.physicalJoined = true; owner.outputJoined = true }
} finally {
  owner.endedAt = Date.now()
  await fs.writeFile(path.join(scope, "owner.json"), JSON.stringify(owner, null, 2))
  console.log(JSON.stringify(owner))
}
