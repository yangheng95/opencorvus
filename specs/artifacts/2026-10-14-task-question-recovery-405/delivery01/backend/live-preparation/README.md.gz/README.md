# 405 still-live scope 首次运行前交接

当前只准备，未创建 `task-process-live-01`，没有本任务活动进程、监听器或 Provider。Root 全文审阅并批准首次启动后才运行；生产和正式测试文件不改。原 red01–04 全部冻结，最新 red04 的 13 断言红和未执行第 14 断言不被本控制覆盖。

## 三个精确 helper

- [runner 全源](task-question-process-runner.ts) / [相对原 preimage 差异](task-question-process-runner.ts.patch)：新增显式 `live` 场景、目录准入与场景环境变量；原 NodeProcess owned_tree、固定 600 秒、正式 runner、source-at-launch 与物理/输出 join 保持。
- [正式 scratch 测试全源](task-question-process.test.ts) / [差异](task-question-process.test.ts.patch)：启动两个独立成熟 controlled streaming Provider；A ready 后才启动 B；B 真实 control Question ready 后父命令两边答复；等待两个自然 child 完成后才检查完整集合，finally 按确切 handle 和原期限收尾。
- [worker 全源](task-question-process-worker.ts) / [差异](task-question-process-worker.ts.patch)：A 是原 public Task + 精确 public Allow Once；B 是正常同 runtime Host/bootstrap + 独立 root public Session/message，没有 Task parent。两边只通过各自公开 Question reply 答复，观察真实 Tool 输出。

上级目录三个 `*-before-live-control.ts` 是实施前原像；本目录源是当前可审阅快照，启动时 runner 再把实际三个源原样留在 fresh scope。`../live-helper-syntax.json` 仅 TypeScript transpile 语法检查，三文件 diagnostics 均空；没有实际运行测试或把它称类型/功能通过。

## 原始启动命令

在仓库根 PowerShell 执行一次，先确保新 scope 不存在：

```powershell
$env:PATH = 'D:\myhexin-local\opencorvus\.tmp-product-iteration\sse-compression-305\bun140\bun-windows-x64;' + $env:PATH
bun .tmp-task-question-recovery-405/task-question-process-runner.ts D:\myhexin-local\opencorvus\.tmp-task-question-recovery-405\task-process-live-01 live
```

runner 内唯一正式测试命令：`bun run --cwd packages/opencorvus test ../../.tmp-task-question-recovery-405/task-question-process.test.ts`。原父 deadline 在启动时确定为 now+600000；每 child deadline 为 min(now+180000,parentDeadline-60000)，HTTP 至多 30000，child 停止准入比自己的 deadline 早 15000。文件协调也检查原 child reserve，不因日志活动续期。沿用受控公开 Provider fixture，不读任何真实凭据/models。

## 输入与检查的完整边界

A 在实际 Task 接纳前，一次 public global config PATCH 明确两个公开 fixture Provider：原 `shutdown-fixture/session-prompt-owner-model` 保持原 Task 模型；独立 `question-control-405/session-prompt-owner-model` 只供 B control。Research Studio、Ask、原 120 秒 lease 保持；catalog/mounts 仍须真实 200。原 baseline 从实际 Git request/outcome 确认。A 原 projected/question Permission 必须通过 transcript 全 arguments、Project/Task/Session/message/call 身份后才向该 ID public Allow Once。原 Asked-only observer 只持真实 wildcard phase，exact Interaction 可能已物化，不能声称 source-only。

B 正常 Host 恢复，读到 A activation→lease→runtime_process→OS exact_live 后创建同 Project 的独立 root Session，public SessionPrompt 使用自己的第二 Provider。B control Tool message/call 必须对应真正当前 Question，SessionPromptOwner 必须是 B PID/occurrence 且 OS exact_live。保存 B `GET /question` 完整实际集合与 control Request，正向预期全集等于 `[controlRequest]`；若实际 B 错误恢复 A 的 waiter，原集合将形成真实红，不能删掉它或只按 ID 过滤后验收。

父收到 B ready 才允许 A、B 各自实际 public reply。A 回答 cedar 并观察原 Tool completed；B 回答公开 Maple 文本，观察原 Tool 的精确答案及真实 assistant stop。两边在对方 answered 文件就绪后进入正常 Server.stop→recovery join→DB effect idle/close，父再 join 原两个 physical/output/request，关闭两个 Provider 后才清理自己的临时 runtime。没有将 plain Provider 文本当作 Task typed completion。

## 当前未知与失败保留

两个 backend 的真实共享 DB/Host 行为仍待运行；B 的独立 root Session 不保证事先推导为成功，任何实际 config/Permission/Tool/Host 前置失败均保留为工具输入或实际产品证据，不冒目标红。原 red04 的 Permission recovery outcome unknown 与 memory fixture schema 错误分别保留，不能从命名推导本控制 clean。若 parent/child 提前失败，写 stop marker、释放 observer、观察原 handles；不会延长期限或结束非本任务进程。

完整公开元数据见 [handoff.json](handoff.json)。本次只是 Root 所批准三 helper 的可审准备，尚未交付本控制运行结论。
