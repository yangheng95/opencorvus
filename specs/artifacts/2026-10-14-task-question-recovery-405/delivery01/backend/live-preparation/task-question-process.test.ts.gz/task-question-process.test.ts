import { expect, test } from "bun:test"
import fs from "node:fs/promises"
import path from "node:path"
import { NodeProcess } from "../packages/util/src/process-node"
import { createManagedTemporaryDirectory, removeManagedDirectoryTree } from "../packages/util/src/runtime-directories"
import { startControlledStreamingProvider } from "../packages/opencorvus/test/fixture/controlled-streaming-provider"

const scenario = process.env.OPENCORVUS_TASK_QUESTION_SCENARIO ?? "crash"
if (!["crash", "live"].includes(scenario)) throw Error("Explicit approved Task process scenario required")
test(scenario === "live" ? "two live backends retain exact Question owners and a complete current control set" : "public Task Question crash preserves the original Tool and truthful infrastructure terminal", async () => {
  const evidence = process.env.OPENCORVUS_TASK_QUESTION_EVIDENCE
  const parentDeadlineAt = Number(process.env.OPENCORVUS_TASK_QUESTION_DEADLINE)
  const processRoot = process.env.OPENCORVUS_TEST_PROCESS_ROOT
  if (!evidence || !path.isAbsolute(evidence) || !processRoot || !Number.isFinite(parentDeadlineAt)) throw Error("Original owned scope required")
  const runtime = await createManagedTemporaryDirectory(processRoot, "task-question-runtime-")
  const provider = startControlledStreamingProvider({ firstPromptToolCall: { name: "question", arguments: {
    reason: "Clarify the public research sample before preparing the report.",
    questions: [{ header: "Public research", question: "Which public source, Cedar or Iris, should this report cover?", options: [{ value: "cedar", label: "Cedar", description: "Public Cedar sample" }, { value: "iris", label: "Iris", description: "Public Iris sample" }], custom: true }],
  } } })
  const controlProvider = scenario === "live" ? startControlledStreamingProvider({ firstPromptToolCall: { name: "question", arguments: {
    questions: [{ header: "Current backend", question: "Which public Maple answer should backend B record?", options: [], custom: true }],
  } } }) : undefined
  const providers = [{ id: "task", value: provider }, ...(controlProvider ? [{ id: "control", value: controlProvider }] : [])]
  let firstReleased = false, releaseBusy = false
  const releaseFacts: any[] = []
  const trackedRequests = new Set<unknown>()
  const release = setInterval(async () => {
    if (releaseBusy) return
    releaseBusy = true
    try {
      if (!firstReleased) {
        firstReleased = await fs.stat(path.join(evidence, "release-first-question")).then(() => true).catch(error => {
          if ((error as NodeJS.ErrnoException).code !== "ENOENT") releaseFacts.push({ at: Date.now(), statError: String(error) })
          return false
        })
        if (firstReleased) releaseFacts.push({ at: Date.now(), markerObserved: true })
      }
      for (const owned of providers) for (const request of owned.value.requests) {
        if (!trackedRequests.has(request)) {
          trackedRequests.add(request)
          const fact: any = { at: Date.now(), provider: owned.id, index: request.index, kind: request.kind }
          releaseFacts.push(fact)
          void request.responded.then(() => { fact.responseConstructedAt = Date.now() })
        }
        if (owned.id === "control" || request.kind === "memory" || firstReleased) {
          const fact = releaseFacts.find(item => item.provider === owned.id && item.index === request.index)
          fact.releasedAt ??= Date.now()
          request.release()
        }
      }
      await fs.writeFile(path.join(evidence, "provider-release-observation.json"), JSON.stringify(releaseFacts, null, 2))
    } finally { releaseBusy = false }
  }, 25)
  const children: any[] = []
  const operations: Promise<number | null | undefined>[] = []
  async function run(mode: "crash" | "recover" | "live-a" | "live-b") {
    if (Date.now() + 60000 >= parentDeadlineAt) throw Error("Original parent reserve reached")
    const startedAt = Date.now(), deadlineAt = Math.min(startedAt + 180000, parentDeadlineAt - 60000)
    // The formal test cwd is the package, so resolve the package from this source.
    const packageDirectory = path.resolve(import.meta.dir, "../packages/opencorvus")
    const args = [`--config=${path.join(packageDirectory, "test/empty-bunfig.toml")}`, `--tsconfig-override=${path.join(packageDirectory, "tsconfig.json")}`, path.join(import.meta.dir, "task-question-process-worker.ts"), mode, runtime, evidence, provider.apiURL, String(deadlineAt)]
    const env = { ...process.env, OPENCORVUS_HOME: runtime, OPENCORVUS_RUNTIME_MEMORY_METRICS_INTERVAL_MS: "300000", ...(controlProvider ? { OPENCORVUS_TASK_QUESTION_CONTROL_URL: controlProvider.apiURL } : {}) }
    const owner: any = { mode, startedAt, deadlineAt, executable: process.execPath, args, cwd: packageDirectory, environmentNames: Object.keys(env).sort() }
    children.push(owner)
    let handle: any
    await fs.writeFile(path.join(evidence, `${mode}-spawn.json`), JSON.stringify(owner, null, 2))
    try {
      const result = await NodeProcess.run({ command: { executable: process.execPath, args }, cwd: packageDirectory, env, ownership: "owned_tree", windowsHide: true, stdin: "ignore", deadlineAt, nothrow: true, onSpawned(h) { handle = h; owner.pid = h.pid; owner.occurrenceID = h.occurrenceID } })
      await fs.writeFile(path.join(evidence, `${mode}-stdout.log`), result.stdout)
      await fs.writeFile(path.join(evidence, `${mode}-stderr.log`), result.stderr)
      owner.receipt = result.receipt
      await handle.settled; await handle.outputSettled
      owner.physicalJoined = true; owner.outputJoined = true; owner.requestSettled = true
      return result.receipt.exitCode
    } finally {
      if (handle && !owner.physicalJoined) { owner.receipt = await handle.terminate("aborted"); await handle.settled; await handle.outputSettled; owner.physicalJoined = true; owner.outputJoined = true; owner.emergencyOwnHandle = true }
      owner.endedAt = Date.now()
      await fs.writeFile(path.join(evidence, `${mode}-process-owner.json`), JSON.stringify(owner, null, 2))
    }
  }
  function start(mode: "crash" | "recover" | "live-a" | "live-b") {
    const operation = run(mode)
    operations.push(operation)
    void operation.catch(() => undefined)
    return operation
  }
  async function waitForFile(name: string, mode: string) {
    const end = Math.min(Date.now() + 120000, parentDeadlineAt - 60000)
    for (;;) {
      try { return JSON.parse(await fs.readFile(path.join(evidence, name), "utf8")) }
      catch (error) { if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error }
      if (children.find(child => child.mode === mode)?.endedAt) throw Error(`${mode} ended before ${name}; inspect original child output`)
      if (Date.now() >= end) throw Error(`Original live scope preparation exceeded: ${name}`)
      await Bun.sleep(100)
    }
  }
  try {
    if (scenario === "live") {
      const runA = start("live-a")
      const original = await waitForFile("live-a-ready.json", "live-a")
      const runB = start("live-b")
      const peer = await waitForFile("live-b-ready.json", "live-b")
      await fs.writeFile(path.join(evidence, "live-answer-questions"), "Both actual Question owners observed. Answer through each original public API.\n", { flag: "wx" })
      const exits = await Promise.all([runA, runB])
      expect(exits).toEqual([0, 0])
      const answeredA = JSON.parse(await fs.readFile(path.join(evidence, "live-a-answered.json"), "utf8"))
      const answeredB = JSON.parse(await fs.readFile(path.join(evidence, "live-b-answered.json"), "utf8"))
      expect(original.snapshot.osObservation).toBe("exact_live")
      expect(peer.original.snapshot.osObservation).toBe("exact_live")
      expect(peer.original.snapshot.runtimeIdentity).toEqual(original.snapshot.runtimeIdentity)
      expect(peer.original.snapshot.publication.original).toEqual(original.snapshot.publication.original)
      expect(peer.control.osObservation).toBe("exact_live")
      expect(peer.control.promptOwner.owner_pid).toBe(peer.backend.pid)
      expect(peer.control.promptOwner.owner_occurrence_id).toBe(peer.backend.occurrenceID)
      expect(structuredClone(peer.control.session)).toMatchObject({ kind: "assistant", projectID: original.accepted.body.project_id, directory: original.accepted.body.directory })
      expect(structuredClone(answeredA.reply)).toMatchObject({ status: 200, body: true })
      expect(structuredClone(answeredA.snapshot.tool)).toMatchObject({ id: original.snapshot.tool.id, state: { status: "completed", output: expect.stringContaining("cedar") } })
      expect(structuredClone(answeredB.reply)).toMatchObject({ status: 200, body: true })
      expect(structuredClone(answeredB.tool)).toMatchObject({ id: peer.control.tool.id, state: { status: "completed", metadata: { answers: [["Actual backend B Maple answer"]] } } })
      expect(structuredClone(answeredB.completed)).toMatchObject({ status: 200, body: { info: { role: "assistant", finish: "stop" } } })
      // Full positive collection with a real, non-empty current control.
      expect(peer.canonical.body).toEqual([peer.control.request])
      return
    }
    expect(await start("crash")).toBe(23)
    const original = JSON.parse(await fs.readFile(path.join(evidence, "checkpoint.json"), "utf8"))
    expect(original.accepted.status).toBe(202)
    expect(original.profile.map((x: any) => x.status)).toEqual([200, 200])
    expect(structuredClone(original.permissionDecision)).toMatchObject({ status: 200, body: { request: { id: original.permission.id }, decision: "allow_once" } })
    expect(original.snapshot.osObservation).toBe("exact_live")
    expect(original.snapshot.lease.id).toBe(original.snapshot.assistant.activationID)
    expect(original.snapshot.lease.owner_occurrence_id).toBe(original.snapshot.runtimeIdentity.occurrenceID)
    expect(original.snapshot.publication.original.properties).toEqual(original.request)
    expect(await start("recover")).toBe(0)
    const observed = JSON.parse(await fs.readFile(path.join(evidence, "recover-observation.json"), "utf8"))
    expect(observed.originalOwnerObservation).toBe("dead_or_reused")
    expect(observed.snapshot.publication.original).toEqual(original.snapshot.publication.original)
    expect(structuredClone(observed.snapshot.tool)).toMatchObject({ id: original.snapshot.tool.id, callID: original.request.tool.callID, state: { status: "error", failure: { kind: "process-execution-interrupted" } } })
    // Positive truthful terminal contract. A lost ordinary Promise is not a
    // successful empty-waiter continuation; the original interruption is real.
    expect(structuredClone(observed.snapshot.publication.facts.terminal)).toMatchObject({ type: "question.abandoned", properties: { sessionID: original.request.sessionID, requestID: original.request.id, origin: "infrastructure", timeResolved: observed.snapshot.tool.state.time.end } })
    expect(structuredClone(observed.snapshot.interaction)).toMatchObject({ task_id: original.taskID, external_id: original.request.id, status: "expired", response: { origin: "infrastructure" }, time_resolved: observed.snapshot.publication.facts.terminal.properties.timeResolved })
  } finally {
    if (scenario === "live") await fs.writeFile(path.join(evidence, "live-stop-requested"), "Original parent is closing this owned live scope.\n")
    await Promise.allSettled(operations)
    clearInterval(release)
    for (const owned of providers) {
      for (const request of owned.value.requests) request.release()
      await Promise.all(owned.value.requests.map(request => request.responded))
      await owned.value.server.stop(true)
    }
    await fs.writeFile(path.join(evidence, "provider-release-observation.json"), JSON.stringify(releaseFacts, null, 2))
    await fs.writeFile(path.join(evidence, "controlled-provider.json"), JSON.stringify(providers.flatMap(owned => owned.value.requests.map(request => ({ provider: owned.id, index: request.index, kind: request.kind, body: request.body }))), null, 2))
    const allJoined = children.every(child => child.physicalJoined && child.outputJoined)
    const cleanup: any = { children, allJoined, providerClosed: true, parentDeadlineAt, endedAt: Date.now() }
    if (allJoined) { await removeManagedDirectoryTree(runtime); cleanup.runtimeRemovedAfterPhysicalExit = true }
    await fs.writeFile(path.join(evidence, "cleanup.json"), JSON.stringify(cleanup, null, 2))
  }
}, 540000)
