const fs=require('node:fs');
const p='.tmp-task-question-recovery-405/task-process-red-04/';
const read=n=>JSON.parse(fs.readFileSync(p+n,'utf8'));
const original=read('checkpoint.json'), current=read('recover-observation.json'), owner=read('owner.json'), cleanup=read('cleanup.json');
const facts={
 scope:'task-process-red-04', formal:{pass:0,fail:1,assertions:13,exit:1,failedContract:'Original ordinary Question lacks its infrastructure terminal after actual Tool interruption'},
 task:{id:original.taskID,projectID:original.accepted.body.project_id,accepted:original.accepted.status,profileStatuses:original.profile.map(x=>x.status)},
 approval:{requestID:original.permission.id,status:original.permissionDecision.status,decision:original.permissionDecision.body.decision,request:original.permission,receipt:original.permissionDecision},
 request:original.request,
 original:{assistantID:original.snapshot.assistant.id,tool:original.snapshot.tool,activationID:original.snapshot.assistant.activationID,lease:original.snapshot.lease,runtimeIdentity:original.snapshot.runtimeIdentity,os:original.snapshot.osObservation,publication:original.snapshot.publication,interaction:original.snapshot.interaction},
 recovered:{os:current.originalOwnerObservation,tool:current.snapshot.tool,assistant:current.snapshot.assistant,publication:current.snapshot.publication,interaction:current.snapshot.interaction,pending:current.pending,boardQuestions:current.board.body.interactions.filter(x=>x.type==='question'),observedAt:current.observedAt},
 times:{leaseExpiresAt:original.snapshot.lease.expires_at,toolEnd:current.snapshot.tool.state.time.end,meaning:'Equality is actual stored data. Original process death is independently observed; no Question terminal is synthesized.'},
 owner,children:cleanup.children,providerClosed:cleanup.providerClosed,runtimeRemovedAfterPhysicalExit:cleanup.runtimeRemovedAfterPhysicalExit,
 limits:['Task exact Asked phase was already materialized; not source-only recovery.','No real model or UI acceptance; local controlled streaming Provider only.','No ordinary Tool success/Task business completion claim.','Permission recovery independently logged execution outcome unknown; memory fixture empty Markdown refusal is retained.','Original red01/red02/red03 are helper permission-precondition failures, not product recovery reds.'],
};
for(const x of [owner,...cleanup.children]) if(!x.physicalJoined||!x.outputJoined||!x.requestSettled||x.endedAt>x.deadlineAt)throw Error('Original physical closure mismatch');
if(cleanup.children[0].receipt.exitCode!==23||cleanup.children[1].receipt.exitCode!==0||!cleanup.providerClosed||!cleanup.runtimeRemovedAfterPhysicalExit)throw Error('Unexpected closure');
fs.writeFileSync('.tmp-task-question-recovery-405/red04-facts.json',JSON.stringify(facts,null,2));
console.log(JSON.stringify({formal:facts.formal,taskID:facts.task.id,requestID:facts.request.id,toolEnd:facts.times.toolEnd,leaseExpiry:facts.times.leaseExpiresAt,questionStatus:current.snapshot.interaction.status,pendingCount:current.pending.body.length,ownersJoined:cleanup.children.length+1}));
