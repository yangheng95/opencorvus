# 405 live-01 精确结果与关闭事实（冻结）

本 scope 正式 **0 pass / 1 fail / 1 expect，退出 1**。唯一执行的 expect 是双 child 退出码，实际 `[1,1]`，预期 `[0,0]`；其后的 Tool/全集断言全部未执行。B 的完整 canonical 同时包含 A 和自己，是独立真实公开 API 观察，不称正式全集断言已经失败。原完整 stdout/stderr、每个 source 与 receipt 保持，不修改期望。

## 原执行与参与者

- 原 tools exec `69526` 已实际 `write_stdin` join，exit 1。launcher PID91056；formal owner PID78760 / NodeProcess occurrence `f85eb965-222d-435e-810f-1fbec20ef8a5`，start1791937257437/deadline1791937857437/end1791937441475（184.038 秒）。
- A PID86572 / runtime occurrence `62e6355f-0f33-4cda-a0ec-afc657ac92a8` / OS processInstance `win32:639275340610980892`；其 NodeProcess occurrence `2cdef13d-d028-4bb7-8968-a3ff3c527eeb`。start1791937260982/deadline1791937440982/end1791937322093，自然 exit1。
- B PID68708 / runtime occurrence `6f31006f-11be-411b-8feb-623e042582c9` / OS processInstance `win32:639275340860648495`；NodeProcess occurrence `5335648c-fa78-4e7f-8311-61566706c58e`。start1791937285588/deadline1791937465588/end1791937441151，自然 exit1。
- 三个 owner 的 physicalJoined/outputJoined/requestSettled 均 true。A/B closed 记录原 Server.stop 和 DB.close；父 cleanup 记录两 Provider closed、原物理退出后 runtimeRemovedAfterPhysicalExit=true。没有新期限、强杀用户进程、遗留 scope。

## 既定 Question owner 问题的实际观察

A 正常 public Task202、Research Studio catalog/mounts200、自然 Git baseline success；Project `prj_hy2kVCPQuV48ug2juSkb`，Task `tsk_g00VXykB5R004Ugozxvx`，Session `ses_-zUS1FmfyzzMCRVBDOcz`。其原 Question `que_g0VXykEQe00vD1YaYAO0` / Tool `prt_g0VXykEKa00D1bGc13vO` / assistant `msg_hCmui2UOzy6qqASU9bGz` / call `call_controlled_recovery_next` 由真实 Provider→projected Question 自然产生，原 timeCreated1791937285276。

B 正常同 runtime Host/bootstrap 后，原 A owner 仍为 **exact_live**；B `/question` 原完整集合为 A 的上述 Request 加自己的真实 control `que_g0VXykG1o00CATWZiooI`。B control 是独立 public root Session `ses_-zUS1FkDuzzNJAdOiCG4`，原 Tool `prt_g0VXykG1X00u7COuXBQQ`、PromptOwner PID/occurrence 精确 B、OS exact_live；不是伪 Request 或 Task parent。

B 自己的 public Question reply200，Tool 实际 completed、metadata.answers=`[["Actual backend B Maple answer"]]`，随后真实 assistant `msg_g0VXykG6C00QoZ2dQIcJ` finish=stop/time.completed1791937292032。原文件 `live-b-ready.json` 和 `live-b-answered.json` 保存全对象，未用模型自述替代事实。

## 新发现的 Permission 共享终态冲突（不能降为 Question 单点）

A 的原 Permission `per_hH5RlBJY02BuIhy7nBef` 经完整 Project/Task/Session/message/call/arguments 匹配后 public allow_once200。实际 ledger 只有以下四行：

| event | id | time_created | exact attempt/outcome |
|---|---|---:|---|
| requested | per_g0VXykELq00dFRCiVE3p | 1791937284978 | canonical request owner |
| allowed_once | per_g0VXykEMX006sb7b1ROS | 1791937285021 | decision_slot=原 request |
| execution_started | per_g0VXykEQG00ErZxNg3co | 1791937285252 | attempt=per_h7QpS5pCf0kh4Bt0jMFu |
| outcome_unknown | per_g0VXykFfg001XHw8m5B2 | 1791937290052 | outcome_slot=同 attempt，source=原 execution_started |

最后一行 reason 原文为 `Runtime restarted before a terminal Tool outcome was recorded`，但 A 此时仍 exact_live。B stderr 同时记录该 attempt 的 recovery outcome unknown。B bootstrap 先写 unknown；随后 A 自己 public Question reply200、Board Question answered/Cedar/time1791937291555；A 原 Tool 提交结果却在1791937291757成为 `tool-execution / SQLiteError / UNIQUE constraint failed: permission_ledger.outcome_slot`。A 的 30 秒 completed 轮询因此超时，保存真实 error 后普通关闭。不得把这个 Tool error 说成 Question 用户答案丢失：原 Question/Board answer 已持久化；丢失的是合法运行者的 Permission execution success/Tool result 收敛。

`permission-ledger-readonly.json` 在 B 原 owner 尚存活、runtime 清理前以 bun:sqlite `{readonly:true}` 读取自己的 `permission_ledger ORDER BY time_created,id`，保存四选定公开事实后立即 close；没有复制 DB/runtime/auth/models。未在原 runtime 删除前读取 effect lease 行，因此该 scope 的 exact effect lease 实际 ID/owner 未取证，不能从当前代码反填。当前生产 source 明确 effect owner 是新 `call` ID而非 physical process occurrence，reconcile 未读取 effect lease/OS；完整 406 只读分析另 scope 交付。

B 等待 `live-a-answered.json`（A 未成功写该标记）至其原 reserve，得到明确 `Original live child reserve reached waiting for live-a-answered.json` 后正常关闭，不延长预算。这是固定辅助协调失败，不能把 B control 的真实成功误说成双 owner 完整成功。

## 尚未完成

未修复任何生产代码；普通 Task red04 的 Tool interruption/Question pending 缺口仍存在；live01 跨 backend Question waiter 与 Permission outcome 竞争均尚未修复。未完成本 scope 的正式完整集合/双 Tool 成功验收、Task typed completion、A2A/worker/Mission/crossProject 实际过程验收或真实模型。所有这些需下一 406 原共享机制方案与授权，不在405 UI交付中冒称解决。
