# 405 第一阶段真实Task过程红态：待Root首次启动确认

授权来源：405 spec Recall/第一阶段授权，Root随后明确先准备三个scratch文件并审读后才启动。当前仅写scratch；没有运行服务、测试、Provider或模型。

## 文件与命令

- `task-question-process-runner.ts`：沿404成熟NodeProcess owned_tree运行正式包测试，父原600000ms；每个fresh scope复制实际三个source及原公开phase-b-input；原stdout/stderr/owner-start/owner终态全保留。
- `task-question-process.test.ts`：标准isolated preload下，一个成熟controlled streaming Provider，两个顺序真实child；每个≤180000ms，父保留60000ms；父物理/output/request join后才移除自己runtime。
- `task-question-process-worker.ts`：普通listenWithRecoveredServerRuntime及recoverStartedTaskExecutions；原Config公共PATCH、catalog/mounts、publicTask202、自然baseline、实际QuestionTool/activation链、crash/recover观察；没有Task/Message手写、Question.ask/restore/reconcile调用。

首次命令（只有Root确认后执行；不会复用结束的scope）：

```powershell
$env:PATH='D:\myhexin-local\opencorvus\.tmp-product-iteration\sse-compression-305\bun140\bun-windows-x64;'+$env:PATH
bun .tmp-task-question-recovery-405/task-question-process-runner.ts D:\myhexin-local\opencorvus\.tmp-task-question-recovery-405\task-process-red-01 crash
```

## 已核实的输入/输出

1. 全局配置从成熟403 `phaseBConfig`产生，只将active改为完整builtin research-studio；原公开fixture apiKey字面值local-controlled-provider。无auth/models复制/读取；模型目录使用正式test preload公开目录。
2. 实际公共PATCH `/global/config`返回200；同真实目录GET `/expert-squad/catalog` effective research-studio及GET `/skill/mounts`各200，才创建Task。全包Research Studio没有default MCP依赖，不启Browser/Computer。公开CSV写自有project且在Task接纳之前，不写Task过程中绑定的原tree。
3. Task body requestID/title/request/productPillar work/promptProfile research-studio/model shutdown-fixture/session-prompt-owner-model；`POST /task?init-git=true`返回202原task_id/project_id/directory。没有Task directory override、伪metadata或typed完工控制。
4. baseline读原EngineGitCheckpointRequestTable+OutcomeTable，要求baseline:1实际success；不看Board metadata.git，不从checker调用EngineGit.prepare/complete。
5. 原Provider first prompt暂hold；真实baseline成功后安装既有suppressAutomaticDurableDrain，再释放Provider首条Question。实际orchestrator Question schema的reason是optional string，questions含正常header/正文/options/custom；无需自造schema或调整工具声明。
6. 原公开Question列表及Task transcript给Request/Tool；只读精确原Message查assistant.activationID→同id target task_root_ingress lease→owner_occurrence_id→runtime_process receipt，OS observeProcessLiveness必须exact_live，且runtimeIdentity等于原child真正runtime occurrence。任一缺失为前置失败，不算目标红。
7. 原Asked内容逐字段相等，wildcard尚未结算；仅此现成hook制造commit后delivery前窗口。保存checkpoint后producer真实exit23，父join后启动新child，正常Host恢复，无手工mirror/终态/时钟修改。
8. 原Task-root lease是生产120000ms，helper不缩短/设置测试override。新child按其原≤180s期限观察原Toolerror/completed，保存原expiry与实际Tool.state.time.end。OS原owner已dead_or_reused单独保存；不拿leaseexpiry替OS死亡。
9. formal期待原普通Tool真实process-execution-interrupted及同Question/Board原infrastructure终态和对应实际时间。worker只观察原产品结果，绝不生成Question terminal；当前不满足则原红保留。先保存canonical/pending/Board/原Asked与过程观察，然后普通Server.stop、recovery join、Instance/DB闭合，parent最后停Provider及删runtime。

## 静态准备检查与未知

`helper-syntax-review.json`是TypeScript transpileModule对三个scratch源的语法诊断（全空），不是运行或全类型验收。实际表名/JSON result shape、Task202字段、真实Question reason schema、Tool.failure.kind与mtime边界已逐一对照当前源及404真实baseline数据。

本轮尚未启动，Task是否能在当前peer工作树完成全部准入/原Question是否自然到达目标尚未知。既有controlled memory fixture返回empty markdown可能产生已知实际memory拒绝；保留日志，不改fixture/不归Question根因。没有真实GPT-6.1 Sol、完整Task业务完成或UI验收承诺。live backend保护控制另外fresh600s双owner准备，不与此顺序crash scope混算。
