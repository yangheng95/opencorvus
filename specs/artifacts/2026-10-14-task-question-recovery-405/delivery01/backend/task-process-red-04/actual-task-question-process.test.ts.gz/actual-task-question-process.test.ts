import { expect, test } from "bun:test"
import fs from "node:fs/promises"
import path from "node:path"
import { NodeProcess } from "../packages/util/src/process-node"
import { createManagedTemporaryDirectory, removeManagedDirectoryTree } from "../packages/util/src/runtime-directories"
import { startControlledStreamingProvider } from "../packages/opencorvus/test/fixture/controlled-streaming-provider"

test("public Task Question crash preserves the original Tool and truthful infrastructure terminal", async () => {
  const evidence = process.env.OPENCORVUS_TASK_QUESTION_EVIDENCE
  const parentDeadlineAt = Number(process.env.OPENCORVUS_TASK_QUESTION_DEADLINE)
  const processRoot = process.env.OPENCORVUS_TEST_PROCESS_ROOT
  if (!evidence || !path.isAbsolute(evidence) || !processRoot || !Number.isFinite(parentDeadlineAt)) throw Error("Original owned scope required")
  const runtime = await createManagedTemporaryDirectory(processRoot, "task-question-runtime-")
  const provider = startControlledStreamingProvider({ firstPromptToolCall: { name: "question", arguments: {
    reason: "Clarify the public research sample before preparing the report.",
    questions: [{ header: "Public research", question: "Which public source, Cedar or Iris, should this report cover?", options: [{ value: "cedar", label: "Cedar", description: "Public Cedar sample" }, { value: "iris", label: "Iris", description: "Public Iris sample" }], custom: true }],
  } } })
  let firstReleased = false, releaseBusy = false
  const releaseFacts: any[] = []
  const trackedRequests = new Set<unknown>()
  const release = setInterval(async () => {
    if (releaseBusy) return
    releaseBusy = true
    try {
      if (!firstReleased) {
        firstReleased = await fs.stat(path.join(evidence, "release-first-question")).then(() => true).catch(error => {
          if ((error as NodeJS.ErrnoException).code !== "ENOENT") releaseFacts.push({ at: Date.now(), statError: String(error) })
          return false
        })
        if (firstReleased) releaseFacts.push({ at: Date.now(), markerObserved: true })
      }
      for (const request of provider.requests) {
        if (!trackedRequests.has(request)) {
          trackedRequests.add(request)
          const fact: any = { at: Date.now(), index: request.index, kind: request.kind }
          releaseFacts.push(fact)
          void request.responded.then(() => { fact.responseConstructedAt = Date.now() })
        }
        if (request.kind === "memory" || firstReleased) {
          const fact = releaseFacts.find(item => item.index === request.index)
          fact.releasedAt ??= Date.now()
          request.release()
        }
      }
      await fs.writeFile(path.join(evidence, "provider-release-observation.json"), JSON.stringify(releaseFacts, null, 2))
    } finally { releaseBusy = false }
  }, 25)
  const children: any[] = []
  let allJoined = true
  async function run(mode: "crash" | "recover") {
    if (Date.now() + 60000 >= parentDeadlineAt) throw Error("Original parent reserve reached")
    const startedAt = Date.now(), deadlineAt = Math.min(startedAt + 180000, parentDeadlineAt - 60000)
    // The formal test cwd is the package, so resolve the package from this source.
    const packageDirectory = path.resolve(import.meta.dir, "../packages/opencorvus")
    const args = [`--config=${path.join(packageDirectory, "test/empty-bunfig.toml")}`, `--tsconfig-override=${path.join(packageDirectory, "tsconfig.json")}`, path.join(import.meta.dir, "task-question-process-worker.ts"), mode, runtime, evidence, provider.apiURL, String(deadlineAt)]
    const env = { ...process.env, OPENCORVUS_HOME: runtime, OPENCORVUS_RUNTIME_MEMORY_METRICS_INTERVAL_MS: "300000" }
    const owner: any = { mode, startedAt, deadlineAt, executable: process.execPath, args, cwd: packageDirectory, environmentNames: Object.keys(env).sort() }
    children.push(owner)
    let handle: any
    await fs.writeFile(path.join(evidence, `${mode}-spawn.json`), JSON.stringify(owner, null, 2))
    allJoined = false
    try {
      const result = await NodeProcess.run({ command: { executable: process.execPath, args }, cwd: packageDirectory, env, ownership: "owned_tree", windowsHide: true, stdin: "ignore", deadlineAt, nothrow: true, onSpawned(h) { handle = h; owner.pid = h.pid; owner.occurrenceID = h.occurrenceID } })
      await fs.writeFile(path.join(evidence, `${mode}-stdout.log`), result.stdout)
      await fs.writeFile(path.join(evidence, `${mode}-stderr.log`), result.stderr)
      owner.receipt = result.receipt
      await handle.settled; await handle.outputSettled
      owner.physicalJoined = true; owner.outputJoined = true; owner.requestSettled = true; allJoined = true
      return result.receipt.exitCode
    } finally {
      if (handle && !owner.physicalJoined) { owner.receipt = await handle.terminate("aborted"); await handle.settled; await handle.outputSettled; owner.physicalJoined = true; owner.outputJoined = true; owner.emergencyOwnHandle = true; allJoined = true }
      owner.endedAt = Date.now()
      await fs.writeFile(path.join(evidence, `${mode}-process-owner.json`), JSON.stringify(owner, null, 2))
    }
  }
  try {
    expect(await run("crash")).toBe(23)
    const original = JSON.parse(await fs.readFile(path.join(evidence, "checkpoint.json"), "utf8"))
    expect(original.accepted.status).toBe(202)
    expect(original.profile.map((x: any) => x.status)).toEqual([200, 200])
    expect(structuredClone(original.permissionDecision)).toMatchObject({ status: 200, body: { request: { id: original.permission.id }, decision: "allow_once" } })
    expect(original.snapshot.osObservation).toBe("exact_live")
    expect(original.snapshot.lease.id).toBe(original.snapshot.assistant.activationID)
    expect(original.snapshot.lease.owner_occurrence_id).toBe(original.snapshot.runtimeIdentity.occurrenceID)
    expect(original.snapshot.publication.original.properties).toEqual(original.request)
    expect(await run("recover")).toBe(0)
    const observed = JSON.parse(await fs.readFile(path.join(evidence, "recover-observation.json"), "utf8"))
    expect(observed.originalOwnerObservation).toBe("dead_or_reused")
    expect(observed.snapshot.publication.original).toEqual(original.snapshot.publication.original)
    expect(structuredClone(observed.snapshot.tool)).toMatchObject({ id: original.snapshot.tool.id, callID: original.request.tool.callID, state: { status: "error", failure: { kind: "process-execution-interrupted" } } })
    // Positive truthful terminal contract. A lost ordinary Promise is not a
    // successful empty-waiter continuation; the original interruption is real.
    expect(structuredClone(observed.snapshot.publication.facts.terminal)).toMatchObject({ type: "question.abandoned", properties: { sessionID: original.request.sessionID, requestID: original.request.id, origin: "infrastructure", timeResolved: observed.snapshot.tool.state.time.end } })
    expect(structuredClone(observed.snapshot.interaction)).toMatchObject({ task_id: original.taskID, external_id: original.request.id, status: "expired", response: { origin: "infrastructure" }, time_resolved: observed.snapshot.publication.facts.terminal.properties.timeResolved })
  } finally {
    clearInterval(release)
    for (const request of provider.requests) request.release()
    await Promise.all(provider.requests.map(request => request.responded))
    await provider.server.stop(true)
    await fs.writeFile(path.join(evidence, "provider-release-observation.json"), JSON.stringify(releaseFacts, null, 2))
    await fs.writeFile(path.join(evidence, "controlled-provider.json"), JSON.stringify(provider.requests.map(request => ({ index: request.index, kind: request.kind, body: request.body })), null, 2))
    const cleanup: any = { children, allJoined, providerClosed: true, parentDeadlineAt, endedAt: Date.now() }
    if (allJoined) { await removeManagedDirectoryTree(runtime); cleanup.runtimeRemovedAfterPhysicalExit = true }
    await fs.writeFile(path.join(evidence, "cleanup.json"), JSON.stringify(cleanup, null, 2))
  }
}, 540000)
