/** PREPARED ONLY. GET/file inspection after actual manual desktop actions; no UI access/assertions. */
import assert from "node:assert/strict"
import path from "node:path"
import { projects, unicodeDirectory, at, save, loadPrepared, loadOwner, httpClient, physical, assertIdentity, errorFact, uniqueLabel } from "./fixture-support.mjs"

const [mode, phase, role, expectedJSON] = process.argv.slice(2)
assert.equal(mode, "read")
assert.equal(process.argv.length, 6, "Usage: read <phase> <a|b> <JSON-array-of-all-current-root-label-file-paths>")
assert.match(phase, /^[a-z0-9-]+$/)
assert.ok(["a", "b"].includes(role))
const expectedPaths = JSON.parse(expectedJSON)
assert.ok(Array.isArray(expectedPaths) && expectedPaths.length > 0 && expectedPaths.every((value) => typeof value === "string"))
assert.equal(new Set(expectedPaths).size, expectedPaths.length)
const label = uniqueLabel(`readback-${phase}-${role}`)
const result = { label, phase, role, expectedPaths, readOnly: true, qualification: "Original bytes/physical identity and public File API readback after manual desktop actions; no UI or language assertions", startedAt: at(), requests: [], physical: [] }
try {
  const fixture = await loadPrepared()
  const owner = await loadOwner(fixture)
  result.fixtureID = fixture.fixtureID
  result.owner = owner
  const declared = fixture.expected[role]
  for (const value of expectedPaths) assert.ok(Object.hasOwn(declared, value), `Path was not predeclared: ${value}`)
  const request = httpClient(result.requests, owner)
  for (const value of fixture.pickerInputs) {
    const actual = await physical(value.full)
    assertIdentity(actual, value)
    assert.equal(actual.bytesBase64, value.bytesBase64)
    result.physical.push(actual)
  }
  for (const relative of expectedPaths) {
    const expected = declared[relative]
    const actual = await physical(path.join(projects[role], relative))
    assert.equal(actual.file, true)
    assert.equal(actual.bytesBase64, expected.bytesBase64)
    assert.equal(actual.size, expected.size)
    assert.equal(actual.device, fixture.scopes[role].identity.device)
    if (expected.sourceIdentity) assertIdentity(actual, expected.sourceIdentity)
    if (expected.movedFromIdentity) assertIdentity(actual, expected.movedFromIdentity)
    result.physical.push({ relative, ...actual })
    const response = await request(`content:${relative}`, role, "/file/content", { path: relative })
    assert.equal(response.status, 200, response.rawBody)
    assert.equal(typeof response.requestID, "string")
    assert.equal(response.body.type, "text")
    assert.equal(Buffer.from(response.body.content, "utf8").toString("base64"), expected.bytesBase64)
    assert.equal(typeof response.body.revision, "string")
  }
  const directoryKeys = role === "a" ? ["", unicodeDirectory] : [""]
  for (const directoryKey of directoryKeys) {
    const listing = await request(`list:${directoryKey || "root"}`, role, "/file", { path: directoryKey })
    assert.equal(listing.status, 200, listing.rawBody)
    assert.equal(typeof listing.requestID, "string")
    const wanted = expectedPaths.filter((value) => (path.posix.dirname(value) === "." ? "" : path.posix.dirname(value)) === directoryKey).sort()
    const actual = listing.body.filter((node) => node.name.startsWith("root-label-")).map((node) => node.path.replaceAll("\\", "/")).sort()
    assert.deepEqual(actual, wanted)
    for (const relative of wanted) {
      const node = listing.body.find((value) => value.path.replaceAll("\\", "/") === relative)
      assert.deepEqual({ ...node, path: node.path.replaceAll("\\", "/") }, { name: path.posix.basename(relative), path: relative, absolute: path.join(projects[role], relative), type: "file", ignored: false })
    }
    if (role === "a" && directoryKey === "") {
      const node = listing.body.find((value) => value.path.replaceAll("\\", "/") === unicodeDirectory)
      assert.deepEqual(node, { name: unicodeDirectory, path: unicodeDirectory, absolute: path.join(projects.a, unicodeDirectory), type: "directory", ignored: false })
    }
  }
  const search = await request("current-query", role, "/find/file", { query: fixture.query, type: "file", limit: 100 })
  assert.equal(search.status, 200, search.rawBody)
  assert.equal(typeof search.requestID, "string")
  assert.deepEqual(search.body.map((value) => value.replaceAll("\\", "/")).sort(), [...expectedPaths].sort())
  result.outcome = "exact-declared-file-bytes-list-and-search"
  result.completedAt = at()
  result.exitCode = 0
} catch (error) {
  result.outcome = "original-readback-error-retained"
  result.error = errorFact(error)
  result.failedAt = at()
  result.exitCode = 1
} finally {
  const target = await save(`${label}.json`, result)
  console.log(JSON.stringify({ label, outcome: result.outcome, exitCode: result.exitCode, requests: result.requests.length, evidence: target }))
}
process.exitCode = result.exitCode
