/** PREPARED ONLY. Register actual projects and empty Chat sessions through normal public APIs. */
import assert from "node:assert/strict"
import path from "node:path"
import { evidence, projects, at, samePath, save, loadPrepared, loadOwner, httpClient, errorFact } from "./fixture-support.mjs"

assert.equal(process.argv[2], "register")
assert.equal(process.argv.length, 3)
const fixture = await loadPrepared()
const owner = await loadOwner(fixture)
// Claim once before sending any mutating request; an ambiguous outcome never causes an automatic retry.
await save("registration-admission.json", { fixtureID: fixture.fixtureID, occurrence: owner.occurrence, admittedAt: at(), requested: "Two real Projects and one ordinary empty Chat for each; no messages or models", credentialCatalogStaging: "none" })
const result = { fixtureID: fixture.fixtureID, owner, startedAt: at(), scopes: {}, requests: [] }
const request = httpClient(result.requests, owner)
try {
  for (const role of ["a", "b"]) {
    const project = await request(`${role}-project`, role, "/project/current")
    await save(`registration-${role}-project-response.json`, project)
    assert.equal(project.status, 200, project.rawBody)
    assert.equal(typeof project.requestID, "string")
    assert.ok(typeof project.body?.id === "string" && project.body.id.length)
    const chat = await request(`${role}-empty-chat`, role, "/coding/chat/session", {}, {})
    await save(`registration-${role}-chat-response.json`, chat)
    assert.equal(chat.status, 201, chat.rawBody)
    assert.equal(typeof chat.requestID, "string")
    assert.ok(typeof chat.body?.session?.id === "string" && chat.body.session.id.length)
    assert.equal(chat.body.session.projectID, project.body.id)
    assert.equal(samePath(chat.body.session.directory, projects[role]), true)
    result.scopes[role] = { directory: projects[role], projectID: project.body.id, chatID: chat.body.session.id }
  }
  assert.equal(new Set(Object.values(result.scopes).map((value) => value.projectID)).size, 2)
  assert.equal(new Set(Object.values(result.scopes).map((value) => value.chatID)).size, 2)
  result.outcome = "two-real-projects-and-empty-chats"
  result.completedAt = at()
  await save("registered-projects.json", result)
  console.log(JSON.stringify({ outcome: result.outcome, fixtureID: fixture.fixtureID, scopes: result.scopes, requests: result.requests.length }, null, 2))
} catch (error) {
  result.outcome = "original-registration-error-retained"
  result.error = errorFact(error)
  result.failedAt = at()
  await save("registration-first-error.json", result)
  process.exitCode = 1
  console.error(JSON.stringify({ outcome: result.outcome, evidence: path.join(evidence, "registration-first-error.json"), error: result.error }))
}
