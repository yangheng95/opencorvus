/** Prepared only. Run explicit read only after root confirms its actual UI actions/screenshots completed. */
import assert from "node:assert/strict"
import fs from "node:fs/promises"
import path from "node:path"
import { fileURLToPath } from "node:url"

assert.equal(process.argv[2], "read", "Explicit root-authorized read mode required; no service/fixture/API publication is implemented")
const scratch = path.dirname(fileURLToPath(import.meta.url))
const evidence = path.join(scratch, "after-ui")
const runRoot = path.resolve("C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/file-search-publication-ui-after-01a133")
const project = path.join(runRoot, "project")
const port = 18452
const baseURL = `http://127.0.0.1:${port}`
const samePath = (left, right) => path.resolve(left).toLowerCase() === path.resolve(right).toLowerCase()
const at = () => new Date().toISOString()
const label = `ui-readback-${Date.now()}`
const result = { label, readOnly: true, qualification: "Independent real-desktop integration readback; does not prove B concurrent scan contract or perform any UI action", startedAt: at(), requests: [], physical: [] }
let exitCode = 0
async function ownedPhysical(full) {
  const relative = path.relative(runRoot, path.resolve(full))
  assert.ok(relative === "" || (!relative.startsWith("..") && !path.isAbsolute(relative)), "Only this exact owned namespace may be read")
  let current = path.resolve(full)
  for (;;) {
    const entry = await fs.lstat(current)
    assert.equal(entry.isSymbolicLink(), false, `Owned UI entry has a physical link: ${current}`)
    if (samePath(current, runRoot)) break
    current = path.dirname(current)
  }
  assert.equal(samePath(await fs.realpath(runRoot), runRoot), true)
  const entry = await fs.lstat(full, { bigint: true })
  const fact = { full, at: at(), file: entry.isFile(), directory: entry.isDirectory(), symbolicLink: entry.isSymbolicLink(), device: String(entry.dev), inode: String(entry.ino), size: Number(entry.size) }
  if (entry.isFile()) fact.bytesBase64 = (await fs.readFile(full)).toString("base64")
  result.physical.push(fact)
  return fact
}
async function get(label, route, query) {
  const url = new URL(route, baseURL)
  for (const [key, value] of Object.entries({ directory: project, ...query })) url.searchParams.set(key, value)
  const record = { label, method: "GET", url: url.toString(), dispatchedAt: at() }
  result.requests.push(record)
  try {
    const response = await fetch(url, { signal: AbortSignal.timeout(20_000) })
    record.headersAt = at()
    record.status = response.status
    record.headers = Object.fromEntries(response.headers)
    record.requestID = response.headers.get("x-opencorvus-request-id")
    const bytes = Buffer.from(await response.arrayBuffer())
    record.rawBodyBase64 = bytes.toString("base64")
    record.rawBody = bytes.toString("utf8")
    record.completedAt = at()
    record.body = JSON.parse(record.rawBody)
    assert.equal(record.status, 200, record.rawBody)
    assert.equal(typeof record.requestID, "string")
    return record
  } catch (error) {
    record.error = { name: error.name, code: error.code, message: error.message }
    record.failedAt = at()
    throw error
  }
}

try {
  const fixture = JSON.parse(await fs.readFile(path.join(runRoot, "prepared-fixture.json"), "utf8"))
  const owner = JSON.parse(await fs.readFile(path.join(runRoot, "launch-owner.json"), "utf8"))
  result.fixture = fixture
  result.owner = owner
  assert.equal(fixture.schema, "file-search-publication-ui.fixture/v1")
  assert.equal(fixture.qualification, "real-desktop-file-search-and-picker-upload")
  assert.equal(owner.qualification, fixture.qualification)
  assert.equal(owner.fixtureID, fixture.fixtureID)
  assert.equal(samePath(owner.runRoot, runRoot), true)
  assert.equal(samePath(owner.project, project), true)
  assert.equal(samePath(owner.settlementEvidenceRoot, evidence), true)
  assert.equal(owner.evidencePrefix, "after-ui")
  assert.equal(owner.port, port)
  assert.equal(samePath(owner.runtime, path.join(runRoot, "runtime")), true)
  assert.ok(owner.nativeDeadline > Date.now(), "Original execution deadline already reached; preserve it, do not replace this instance")
  const directory = await ownedPhysical(project)
  assert.equal(directory.directory, true)
  assert.equal(directory.device, fixture.scopes.root.identity.device)
  assert.equal(directory.inode, fixture.scopes.root.identity.inode)
  const original = await ownedPhysical(fixture.original.full)
  assert.equal(original.file, true)
  assert.equal(original.device, fixture.original.device)
  assert.equal(original.inode, fixture.original.inode)
  assert.equal(original.bytesBase64, fixture.original.bytesBase64)
  assert.equal(original.size, 20)
  const chooser = await ownedPhysical(fixture.chooser.full)
  assert.equal(chooser.file, true)
  assert.equal(chooser.device, fixture.chooser.device)
  assert.equal(chooser.inode, fixture.chooser.inode)
  assert.equal(chooser.bytesBase64, fixture.chooser.bytesBase64)
  assert.equal(chooser.size, 18)
  const uploaded = await ownedPhysical(fixture.chooser.target)
  assert.equal(uploaded.file, true)
  assert.equal(uploaded.device, directory.device)
  assert.equal(uploaded.bytesBase64, fixture.chooser.bytesBase64)
  assert.equal(uploaded.size, 18)
  for (const expected of [fixture.original, { name: fixture.chooser.name, bytesBase64: fixture.chooser.bytesBase64 }]) {
    const content = await get(`content:${expected.name}`, "/file/content", { path: expected.name })
    assert.equal(content.body.type, "text")
    assert.equal(Buffer.from(content.body.content, "utf8").toString("base64"), expected.bytesBase64)
    assert.equal(typeof content.body.revision, "string")
  }
  const search = await get("find-current-query", "/find/file", { query: fixture.query, type: "file", limit: 100 })
  assert.deepEqual(search.body.map((value) => value.replaceAll("\\", "/")).toSorted(), [fixture.original.name, fixture.chooser.name].toSorted())
  const list = await get("list-root", "/file", { path: "" })
  for (const name of [fixture.original.name, fixture.chooser.name]) {
    const node = list.body.find((node) => node.path.replaceAll("\\", "/") === name)
    assert.deepEqual(node, { name, path: name, absolute: path.join(project, name), type: "file", ignored: false })
  }
  result.outcome = "accurate-original-and-real-ui-upload-full-bytes-query-and-nodes"
  result.completedAt = at()
} catch (error) {
  result.outcome = "first-readback-error-retained"
  result.error = { name: error.name, code: error.code, message: error.message, stack: error.stack }
  result.failedAt = at()
  exitCode = 1
} finally {
  result.exitCode = exitCode
  await fs.writeFile(path.join(evidence, `${label}.json`), JSON.stringify(result, null, 2), { flag: "wx" })
  console.log(JSON.stringify({ label, outcome: result.outcome, exitCode, requests: result.requests.length, evidence: path.join(evidence, `${label}.json`) }))
}
process.exitCode = exitCode
