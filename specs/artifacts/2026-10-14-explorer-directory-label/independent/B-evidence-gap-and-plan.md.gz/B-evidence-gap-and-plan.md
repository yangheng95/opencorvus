# 文件发布后搜索采集 B：原证据缺口与有限下一轮方案

## Recall 与本次权限

2026-10-14，root 授权一层只读调查，禁止再次委托、产品/测试/spec/共享索引修改、服务/probe/模型/用户进程运行、UI 自动化、重开前轮实例或复用其 receipt。本报告只写本人 ignored scratch；不是正式实施 spec 或执行授权。用户要求持续批次迭代、先根因/影响落盘、真实页面与人工截图、正向功能检查和范围提交/正常推送。主 agent 负责正式方案、页面与 Git；本轮没有任何产品改动。

已重读 `specs/records/2026-10/2026-10-13-file-search-publication-order.md` Recall/三次实际结果/原 deadline 终态/独立 after-ui 最终结果，以及 `2026-10-13-explorer-tab-owner-search.md`、`2026-10-13-file-operation-outcomes.md`、`2026-10-13-file-link-entry-contract.md` 的相关边界。直接解压正式归档的三份 attempt、observer result、原 request/helper/ready/settled 和完整原日志；没有只依据旧 summary 的 false 字段。当前 File.index、Ripgrep、Native supervisor/helper、project State/bootstrap、全部 File.search/init/publication 调用和触及测试已复核。07-panel 的 entry/target/规则坐标公开合同已读。

开始和结束检查 git status；其它 owner 的 Provider、配置、compaction、delegate、Explorer label、本地化及共享索引改动均保留。2026-10-14 本次读到 HEAD `9438501d5d6eaa627cd7276d481f1dfc2696b7b1`，File/index、ripgrep、process-supervisor 和 Native main.rs 当前 working diff 均空。该 HEAD 是调查上下文，不是验收门。目标 scratch 已由 `git check-ignore` 确认 ignored。

## 结论与边界

1. B 的复用控制流确定存在：同 directory 的新 File.search 在已有 `fetching` 时返回同一 Promise。三次实际正常请求没有产生已发布成员遗漏；这是有限未复现，不能排除 B。
2. 前轮以 `ready` 触发 POST 太早。Native helper 在 `publish_ready_marker` 后才调用 `ResumeThread`，ready 证明启动身份，不证明枚举已开始或完成。三个 POST 在 ready 捕获后 1–5 毫秒 dispatch，三个 Q1 本身均纳入新 marker，不能成为“枚举完才发布”的旧集合对照。
3. 原 `originalRequestPresentAfterQ2ServerStarted=false` 不证明 request 已被删除。三次原 request 都实际可读，但采样各比 Q2 server started 早 6/7/12 毫秒；false 是未取得字段要求的晚于入口正事实。
4. 自然 `settled.json` 比 ready 更适合后续触发：它是原 rg target/Job 的物理终态事实，可以证明其枚举已结束。它不公开 stdout 消费完成、File.index.cache 赋值或 fetching 清除。唯一捕获 settled 到下一次观察目录已删除相差 59 毫秒，不是“fetching 仍 pending 59 毫秒”，也不保证足够容纳 POST200→Q2。
5. 当前公开 API 和原 Native 文件没有精确的 File.index fetching 状态或采集 Promise 身份。只读原事实能缩小时间区间，不能承诺自然窗口一定满足。建议最多一个新 occurrence、三个有界原尝试，使用原 settled 触发；未取得窗口则保留精确 unknown，暂不改 File.index，不继续增大负载。

## 原归档及精确时序

主证据目录：`specs/artifacts/2026-10-13-file-search-publication-order/actual/before/`。

- `attempt-root-native-owner-v2-1791903374246-{1,2,3}.json.gz`：所有 HTTP 原输入、完整响应 bytes、requestID、客户端 wall/monotonic 时刻、实体 bytes/dev/inode、原日志全文。
- `native-observer-result-root-native-owner-v2-1791903374246.json.gz`：8 个原 rg 请求；10 毫秒 poll、128 request-directory 上限。
- `native-inspection-root-native-owner-v2-1791903374246-attempt{1,2,3}-after-Q2-dispatch.json.gz`：逐个原文件采样时间。
- `native-root-native-owner-v2-1791903374246-488db16b-b25e-4332-affc-1eb5e9453020-settled.json.gz`：唯一实际捕获的原 settled protocol 1。
- 首次 register409、observer occurrence UUID 误判、首 probe attempts=[]/exit1、原 deadline_exceeded/parent1 均仍在正式归档；本报告不覆盖。

以下短时间全属于 **2026-10-13T14:56 UTC**，单位秒.毫秒。客户端时刻与 server 原日志分别保留，不能把跨来源 1 毫秒差异解释为时钟倒流或内部因果。

| 原 attempt | Q1 dispatch / File.search 入口 | ready 捕获 | POST dispatch / server complete / client body200 | Q2 dispatch / File.search入口、server started | Q1 server complete / client body | Q2 client body | Q3 client body |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1，3000/64 | 15.178 / 15.180 | 15.283 | 15.288 / 15.381 / 15.383 | 15.383 / 15.397 | 15.531 / 15.532 | 15.534 | 15.860 |
| 2，16000/128 | 45.277 / 45.285 | 45.370 | 45.371 / 45.407 / 45.418 | 45.419 / 45.431 | 45.501 / 45.501 | 45.501 | 45.908 |
| 3，16000/128 | 45.914 / 45.917 | 46.031 | 46.033 / 46.070 / 46.079 | 46.079 / 46.093 | 46.130 / 46.129 | 46.130 | 46.622 |

POST server duration 89/29/35 毫秒。POST client 完整 body 后到 Q2 dispatch 的原 monotonic 差为 **0.2184/0.2662/0.1657 毫秒**。原 checker 已立即 dispatch Q2；下一轮不应以“先完成实体/list/content检查”延迟 Q2。Q2 dispatch 到 server started 仍需约 12–14 毫秒，不能只按 JavaScript dispatch 认作后端采集已进入。

| attempt | 原 Native requestID | request 实际可读采样 | helper / ready 可读采样 | settled 当次采样 | Q2 server started 减 request采样 |
| --- | --- | --- | --- | --- | --- |
| 1 | `488db16b-b25e-4332-affc-1eb5e9453020` | 15.391 | 15.392 / 15.394 | 15.394 known-missing | +6毫秒 |
| 2 | `5adc2348-7d5e-43fd-9a96-f9a42d82b231` | 45.424 | 45.425 / 45.427 | 45.428 known-missing | +7毫秒 |
| 3 | `306e144f-e98e-48b9-b7ef-249f92dc0dc4` | 46.081 | 46.082 / 46.084 | 46.085 known-missing | +12毫秒 |

原完整日志 `rawBody` 另含 service=file 的 `search` 入口/结果日志。旧 `matchingRequests` 只筛 server/request，若只读该数组会遗漏 File.search 的已保存入口事实。三次 Q2 search 入口与 server started 同毫秒，Q1/Q2 结果日志分别为 15.529/15.531、45.497/45.500、46.126/46.130。search 日志只有 query/kind/results，没有 requestID、cwd 或 fetching identity；此次受控顺序及各 HTTP requestID 区间支持归属，不能把它当通用多项目精确 trace 协议。

| Q1 Native | request 捕获 | ready 捕获 | settled 捕获 | request目录移除首次观察 | 后续 Q1 server complete |
| --- | --- | --- | --- | --- | --- |
| 488db… | 15.199 | 15.283 | 15.478 | 15.537 | 15.531 |
| 5adc… | 45.292 | 45.370 | 未捕获 | 45.459 | 45.501 |
| 306e… | 45.936 | 46.031 | 未捕获 | 46.122 | 46.130 |

attempt1 原 settled 内容：`protocol=1, request_id=488db…, helper_pid=78888, target_pid=89340, active_processes=0, runtime_occurrence_id=95054259-2bc4-4ce3-9ff5-677c20f83a10`。其原 helper birth `win32:639275001751898714`、target birth `win32:639275001752515582` 已分别捕获；原 runtime owner Target88896 与自己发布的 runtime UUID 单源绑定。外部 observed occurrence UUID 是另一次物理观察 ID，不要求和 runtime UUID 相等。

settled 捕获15.478发生于原 POST200的15.383之后95毫秒；即便其后 request目录仍可观察，也已经错过“settled后才首次发布”的条件。15.537是第一次看到删除，实际删除和 fetching 清理都可能更早；两个后续 attempt 的目录移除观察甚至早于 Q1 HTTP 完成42/8毫秒。不能将 HTTP pending 或目录存在/删除任一单事实等同于 index Promise pending/cleared。后两次 settled 未捕获只说明采样未取得文件，不证明该自然阶段不存在。

三次原 Q1/Q2/Q3 的明确成员集合均正确，marker 为三个19bytes真实文件 `PUB root N 01a133\r\n`，各 POST200、独立物理 bytes/dev/inode、content200完整正文/revision、目录Node均保留。Q1已含marker是有效正事实；“没有第二个rg”或“数组相同”不是复用根因证明。最多16000/128的一次扩展已经完成，不允许为未复现继续无界扩大。

## 当前唯一实现、影响与历史

`packages/opencorvus/src/file/index.ts:699–797` 是唯一 File index：

- createInstanceState 保存 Entry cache 与 fetching；正常 scan 消费 `Ripgrep.filesForHost({cwd:Instance.directory})` 的全部 NUL 文件名，构造 files/dirs，generator 完成之后才赋 cache。
- refresh 创建新 Entry，将 `request.finally` 作为 tracked，finally清 fetching；`files()` 返回 `fetching ?? refresh()`。新 query 的 fuzzy filter 不改变采集边界。
- 工厂先 await refresh；扫描初次失败被 warn后工厂仍返回 accessor，正常后续 files 会重新 refresh。不是持久化索引；不能从这个初次 catch 扩大本批未知错误策略。
- `Instance.directory===path.parse(directory).root` 时扫描返回当前空 cache，不启动 rg。home exact `Filesystem.resolve(directory)===Filesystem.resolve(Global.Path.home)` 时只枚举非隐藏的两层目录，并有平台排除；files保持空，readdir已有catch→[]。这是独立既有合同，本轮未真实验收、不修改。
- `createInstanceState`→`State.create(currentProjectDirectory,…)`，key为 `Filesystem.resolve(ProjectInstanceContext.use().directory)`；相同 Project ID的两个directory不能直接判一份state。State保 initialization Promise、失败移除、正常 disposal/reset；没有新增跨请求index cache。

全仓 `File.init` 唯一生产调用是 `project/bootstrap.ts:74` 的 `ProjectOpenLifecycle.stage("file.init",…)`。File.search生产调用为 `server/routes/file.ts:79` 和 `cli/cmd/debug/file.ts:18`。HTTP GET/find/file公开“按名称/模式搜索项目目录的文件或目录”，query/type/dirs/limit现schema不含acquisition/version字段；type file/directory，limit1–200，默认10。debug命令走相同 File.search；model glob/ls 使用 Ripgrep 的 host/task owner，不经这个 fetching，不能据B控制流宣称这些同样复用。

`file/ripgrep.ts:173–267` 保单一成熟枚举：真实exe、`--files --null --glob=!.git/* --hidden`，默认不follow终端link；完整stdout NUL消费后，await `[proc.exited, stderr, proc.outputSettled]`；成功 finally仍await proc.dispose，然后 generator才结束。Native helper `main.rs:729–741`先原ready再Resume；795–804等待Job active0再原settled；889–915以真实临时文件、sync_all、rename发布原settled。settled描述物理进程/Job，不包含consumer EOF/index Promise。

`shell/process-supervisor.ts:1870–1955` 单一 request cleanup Promise在物理settlement验证后fs.rm。自动settled路径等exited/output后开始cleanup；dispose路径也等待同cleanup。故cleanup可与文件名consumer处理异步重叠，request目录移除不是 File.index finally清 fetching 的精确事件。正常Q1若同原Native的request在较晚时刻仍确实存在，结合正常dispose等待关系，可支持该时刻采集尚未完成；它仍不是Q2实际调用files瞬间的内部读值证明。server started日志在项目context/route/validator之前，File.search入口日志又在 `state().then(x=>x.files())` 之前；二者都只是接近采集准入的外部时间界。

全部发布者已复核：

| 生产入口 | 实体发布与通知 | 对File.index的关系 |
| --- | --- | --- |
| HTTP create/copy/move/remove/writeText | File/index唯一权限/root/noReplace/staging/锁/真实fs发布；notifyEdited在提交后等待Bus结果，失败保已完成实体事实 | 没有index失效订阅；随后GET/search按同files合同 |
| HTTP upload | 完整decode、target锁、wx staging/readback、hardlink最终发布、unlink staging、真实Edited通知后200 | 同一GET/search采集边界；前端现83 owner统一required search refresh |
| model write/edit/apply_patch | executionFiles真实发布；真实Edited与FileWatcher.Updated | 不调用File.search/init，不自动改index cache |
| 文件watcher/外部正常编辑 | 现FileWatcher/format/UI事实流 | File.index没有事件订阅；无法用watch事件猜每次采集边界 |

Format.init订阅真实File.Edited并可运行格式器。未来tiny `.txt`应核真实配置，保存其完整字节；不能忽略通知/formatter耗时或先猜POST是纯write延迟。普通/Refresh/query切换/自动poll/retry前端没有第二后端index；15秒poll仍只目录。83修复的是Explorer owner连续性和原upload search opt-out，没有根治B的后端复用，也不授权本批并发UI guard。

`git log -G`及 `git show 65d0bfc98:file/index.ts`证明 root/home/preload/fetching在2026-08-07的v0.0.35beta基线已存在。该commit与已读相关spec没有给出coalescing/home特殊设计原因，标unknown；不由旧名字或“性能”想当然解释。当前ripgrep原output/settlement修复commit为`c4b5ad38f`，会改变后处理尾段时序，所以旧59毫秒不能直接套到新运行。现`test/file/ripgrep-protocol.test.ts`验证真实NUL/Unicode/空白与明确协议错误，但没有B重叠资格；本任务未运行任何测试，尤其不运行检索到的UI测试。

## 有限新checker建议：只准备方案，尚未授权或执行

先由root将新调查输入写入正式B补充方案，逐个读caller/observer/launcher，再另授一次全新run。没有理由重开18451、借旧receipt、复用原已dead PID/birth或增加产品hook。此方案不要求改product logging、冻结/暂停rg、改变消费者流、模拟index Promise、setFactory、SQL、模型或凭据。

### 单一新输入与预算

- 新严格bound本人runRoot、scratch、可用独立端口、fixtureID、occurrence与900秒原执行input；具体新路径/端口尚待root明确，不能由本报告假称已创建。新/current源+正式immutable UI；source HEAD/相关diff读档，不作为功能hash gate。
- 两个真实独立Git Project，同服务正常公开注册；各原marker16–64bytes及全bytes/dev/inode。不要再造child `.git` pointer控制来撞已知canonical config409；如果后续确需同Project child资格，须单独先解决真实准入输入，不删除原配置/Flag绕行。
- 使用filler总16000/128目录以内的既定cap，独立正常项目/config/marker文件另外准确计数；最多一个新run、3原attempt、3唯一16–64bytes marker、内容总≤1MiB；没有继续扩容分支。filler只是正常filesystem枚举输入，不把单纯变长枚举当尾段保证。原准备耗时/全部数量/bytes/inode保留。
- observer沿现只读原Global.Path.temporary路径推导，10毫秒有界poll、最多128 request目录、原文件严格上限及120秒inactivity；不增加fs.watch平行事实源、不触任何其它runtime目录。原Native execution deadline与观察inactivity分别记，观察timeout不认terminal、不换实例或延deadline。
- 第一份原request验证exe/argv/exactcwd/schema/path/ownerPID+birth后绑定Target自产runtime UUID；原helper protocol1、ready3、settled1按真实schema分别校验。helper/target PID+birth实际捕获，否则missing；外部观察UUID独立保留，不再次要求与runtimeUUID相等。

### 最少正常API顺序

1. 正常注册两Git Project；root同scope warm一次完整 GET/find/file200并确认baseline成员，second查询/content作为真实隔离控制。初始化File.init已完成才开始attempt。无warm失效/新run重试。
2. 同一个明确query/type=file/limit100 dispatch Q1；仅观察它新原Native request/ready/helpers。不是ready立即POST，而是等待**本request合法原settled(protocol1,active0,exact runtime/helper/target)**实际可读；此时记录Q1客户端settled状态、server/search原日志时间。如果Q1已完成或原settled未捕获，记本attempt未取得自然尾段，停止该attempt，不补造marker/假missing事实。
3. 若取得原settled且Q1尚pending，立即普通 **POST/file/upload**发布本次tiny marker；仍选同一个既有publication producer，不同时加create作为fallback。保原request/body/status/requestID、dispatch/headers/fullbody时刻。正常通知/严格发布都保留；若200未成立，第一failure原保并停止。
4. POST完整200后立即dispatch Q2相同query；实体lstat/完整bytes、GET/content、GET/file和持续原request只读采样并行。采样不能迟dispatchQ2，不等日志出现才发Q2。原request/settled已captured只写一次完整bytes，而对该已知原request有界继续取存在采样时间，目标取得晚于Q2 server/search入口的**正存在事实**；knownmissing只记录准确时刻，不据其推断fetching已清。
5. 收齐原Q1/Q2响应、既有日志原全文和Native事实之后Q3同query fresh对照。必要最后second同query/content再一次，证明当前两个真实Project各自正确成员与bytes。每attempt仅Q1、1POST、Q2、Q3、1content、1list（6HTTP）；3attempt上限18，固定warm/跨Project控制额外≤6、两项目正常注册/空Chat≤4，即调查caller最多28HTTP（不含launcher正常ready/收尾）；不加试探API、循环search或无意义read。

此改变只移动checker触发点到自然settled，不控制product继续执行，也不制造可用窗口。前轮POST server29–89毫秒与Q2网络准入12–14毫秒可能长于尾段；tinyupload在新实例仍可能错过。选择create可能减少staging流程，但目前没有同窗口真实延迟证据，故不把它设成第二策略或宣称必快。

### 明确原输出、正向资格与停止规则

- 原HTTP输入/完整raw response/bodybytes/requestID/时间，Q1/Q2/Q3明确排序后成员集合，publication真实Node或UploadResult/bytes；target真实lstat dev/inode/fullbytes和独立content200/revision；第二Project身份/内容/成员；全部原Native文件bytes、外部birth观察、准确requestscope和第一capture来源；原server及File.search日志全文/parseerrors；launcher普通shutdown/物理/output/request/parent原结算。
- 最强可观察缺陷合同：Q1原rg物理settled在publication之前；正常marker POST200/bytes完整；Q2在200后dispatch且同scope；Q1/Q2明确集合仍为旧成员，Q3新的实际采集含完整当前成员。query专有且marker≤4、limit100，排除截断/fuzzy排序冒充缺项。若此合同发生，即已证“正常新查询未包含已发布成员”，无需用absence代替功能结果。
- 同原request在Q2原server/search入口之后的正可读事实，配合当前normaldispose等待链，可支持原采集仍未结算；但exact `fetching` read/Promise归属没有public trace，需将“功能缺陷已证”和“内部同Promise归属推断”分别写明。仅HTTPpending、旧request仍在、相同数组或少一次rg记录都不是单独cause证明。
- 若settled后马上Q1完成，或POST200后Q2得到准确新集合，记录unqualified/accurate-control，不改称排除B。错scope/schema/birth/未知I/O/原HTTP失败立即保first failure/unknown并停止；不能吞I/O为空/false。三次仍未得窗口则本方案终止，不扩大负载/添gate/新run盲retry。
- 任何成功checker不替代真实桌面与截图；本轮没有页面资格。后续真实UI单query/picker可独立smoke，但不能冒同component并发drop，也不能用dispatchEvent/DataTransfer/隐藏函数注入。

## 未满足与下一项真实证据候选

当前不能证明：新/current源的自然尾段有多长；其是否容得下完整publication200+Q2后端准入；三前轮Q2是否在files调用瞬间读同fetching；第二/第三原settled存在持续时间；同Project child准入后的隔离；真实同Explorer逆序external-drop A。没有这些事实之前，不删fetching或增加index revision/cache/队列/延迟清理/观察hook。

若上述有界自然窗口仍未取得，建议保B unknown，转向已有物理/API证据的 **健康目录链接浏览能力**。这只是后续功能候选，未经root spec授权不得实施或盲改type。

`specs/artifacts/2026-10-13-file-operation-outcomes/parallel-link-audit/link-node-evidence.json` 的真实junction-root与absolute-dir-symlink两案例：moved terminal entry均lstat symlink，inode分别`4785074608157002`/`5066549584867657`；followed target为真实目录，inode`5910974514999605`/`11258999072502069`；直接GET/file?path=moved-dir-link均200，返回实际`marker.md` entry。14案例报告与原readlink/真实目标身份都保留。这证明后端已有允许范围内显式浏览路径；不外推旧报告未独立读取的目录成员全bytes。

链接批现合同刻意使terminal junction/symlink的Node.type=file，FileExplorer现1773/1829/1837只对type=directory toggle/expand，其它openFile。故健康目录link当前不具自然展开能力，属于上次明确排除的未完能力，不是把已修entry回执说成新回归。真实healthy目录link点击后的最新桌面行为尚未复现，本次只读不能宣称完成UI根因验收。

最小后续调查应保持entrykind与Git逻辑规则坐标/ignored hint，独立定义allowed browsable target事实，由后端一个成熟stat+权限owner提供；healthy allowed directory、file target、broken、denied与unknown I/O分别明确合同。不能list一律followedstat翻转entrykind，不能canonical terminal改变Git身份，不能吞未知target I/O为不可浏览。需要事先审计HTTP/SDK/debug/Overlay所有Node消费者、root/terminal/ancestor/dotalias、创建/上传/drop目的目录、递归selfguard、selection/key/重试/多Project与Windows/POSIX边界，并以健康link真实桌面展开+子file完整bytes验收。该能力会扩公共字段/导航合同，root应另落spec；本报告不提供双源临时实现。

home-type=file空结果与root禁scan亦可列代码候选，但没有本轮真实运行/设计原因，证据资格弱于上述actual linked-directory API，不优先以“明显bug”命名。

## 本次工具与结果

只读rg/精确代码读、git status/diff/log/show/check-ignore、Node25.7.0解压正式gzip JSON。没有服务/API/probe/模型/用户进程/UI/测试执行或产品/spec/索引修改。

资料提取中保留真实工具失败：首次宽输出被截断，后改为字段摘要；一次把nativeInspection.files误当array与一次把observer.requests猜为records导致解析exit1，均未触runtime，随后先读真实keys、按object/requests修正只读解析成功0。PowerShell brace路径及缺失spec/test路径检索的错误已纠正到精确现路径；不把提取失败当B行为失败或绿色功能验收。原三attempt/8Native和rawlog全文随后成功复核，所有原状态保持。

本任务最终仅上述scratch报告，未创建tracked产品或测试文件；没有暂存/commit/push动作，由主agent继续正式交付。
