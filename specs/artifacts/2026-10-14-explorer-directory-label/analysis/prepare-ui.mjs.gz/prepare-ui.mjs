/** PREPARED ONLY. This script creates fixture data only when root separately authorizes `prepare`. */
import assert from "node:assert/strict"
import fs from "node:fs/promises"
import path from "node:path"
import { randomUUID } from "node:crypto"
import { execFile } from "node:child_process"
import { promisify } from "node:util"
import { scratch, runRoot, projects, unicodeDirectory, port, prefix, schema, qualification, at, save, assertDirectDirectory, physical, errorFact, uniqueLabel } from "./fixture-support.mjs"

assert.equal(process.argv[2], "prepare", "Explicit new-run preparation required; no reuse/cleanup mode")
assert.equal(process.argv.length, 3)
const execute = promisify(execFile)
const fixture = { schema, qualification, fixtureID: randomUUID(), runRoot, port, prefix, project: projects.a, projectB: projects.b, query: "root-label-", preparedAt: at(), modelCallsRequested: "none", credentialCatalogStaging: "none", scopes: {}, files: [], pickerInputs: [], git: [], expected: { a: {}, b: {} } }
const tiny = (label) => Buffer.from(`${label} 01a133\r\n`, "utf8")
const originals = [
  { role: "a", path: "root-label-original.txt", bytes: tiny("ROOT ORIGINAL") },
  { role: "a", path: `${unicodeDirectory}/root-label-copy-a.txt`, bytes: tiny("COPY A") },
  { role: "a", path: `${unicodeDirectory}/root-label-copy-b.txt`, bytes: tiny("COPY B") },
  { role: "a", path: `${unicodeDirectory}/root-label-move-a.txt`, bytes: tiny("MOVE A") },
  { role: "a", path: `${unicodeDirectory}/root-label-move-b.txt`, bytes: tiny("MOVE B") },
  { role: "b", path: "root-label-project-b.txt", bytes: tiny("PROJECT B") },
]
const pickers = [
  { name: "root-label-upload-one.txt", target: "root-label-upload-one.txt", bytes: tiny("PICKER ONE") },
  { name: "root-label-upload-plural-a.txt", target: "root-label-upload-plural-a.txt", bytes: tiny("PICKER PLURAL A") },
  { name: "root-label-upload-plural-b.txt", target: "root-label-upload-plural-b.txt", bytes: tiny("PICKER PLURAL B") },
  { name: "root-label-upload-sub-all.txt", target: `${unicodeDirectory}/root-label-upload-sub-all.txt`, bytes: tiny("PICKER SUB ALL") },
]
try {
  const day = path.dirname(runRoot)
  await assertDirectDirectory(path.dirname(day))
  try { await fs.lstat(day) } catch (error) { if (error.code !== "ENOENT") throw error; await fs.mkdir(day) }
  await assertDirectDirectory(day)
  await fs.mkdir(runRoot) // Exclusive fresh run. EEXIST is retained, never cleaned/reused.
  await assertDirectDirectory(runRoot)
  for (const name of ["runtime", "project", "project-b", "evidence", "home", "appdata", "localappdata", "temp", "xdg-config", "xdg-data", "xdg-cache", "xdg-state", "inputs"]) await fs.mkdir(path.join(runRoot, name))
  await fs.mkdir(path.join(projects.a, unicodeDirectory))
  for (const role of ["a", "b"]) {
    const directory = projects[role]
    const record = { role, directory, args: ["-C", directory, "init", "--initial-branch=main"], startedAt: at() }
    fixture.git.push(record)
    try { const outcome = await execute("git", record.args, { windowsHide: true, timeout: 15_000 }); Object.assign(record, { stdout: outcome.stdout, stderr: outcome.stderr, exitCode: 0, completedAt: at() }) }
    catch (error) { Object.assign(record, { error: errorFact(error), stdout: error.stdout, stderr: error.stderr, exitCode: error.code }); throw error }
    fixture.scopes[role] = { directory, identity: await physical(directory, false), gitIdentity: await physical(path.join(directory, ".git"), false) }
  }
  fixture.scopes.root = fixture.scopes.a
  fixture.scopes.child = { directory: path.join(projects.a, unicodeDirectory), key: unicodeDirectory, identity: await physical(path.join(projects.a, unicodeDirectory), false) }
  for (const input of originals) {
    const full = path.join(projects[input.role], input.path)
    await fs.writeFile(full, input.bytes, { flag: "wx" })
    const fact = { role: input.role, path: input.path, ...(await physical(full)) }
    assert.equal(fact.bytesBase64, input.bytes.toString("base64"))
    fixture.files.push(fact)
    fixture.expected[input.role][input.path] = { bytesBase64: fact.bytesBase64, size: fact.size, sourcePath: input.path, sourceIdentity: fact }
    if (input.role === "a" && input.path.startsWith(`${unicodeDirectory}/`)) {
      const rootTarget = path.posix.basename(input.path)
      const operation = rootTarget.includes("-copy-") ? "copy" : "move"
      fixture.expected.a[rootTarget] = { bytesBase64: fact.bytesBase64, size: fact.size, sourcePath: input.path, operation, ...(operation === "move" ? { movedFromIdentity: fact } : {}) }
    }
  }
  for (const input of pickers) {
    const full = path.join(runRoot, "inputs", input.name)
    await fs.writeFile(full, input.bytes, { flag: "wx" })
    const fact = { name: input.name, target: input.target, ...(await physical(full)) }
    assert.equal(fact.bytesBase64, input.bytes.toString("base64"))
    fixture.pickerInputs.push(fact)
    fixture.expected.a[input.target] = { bytesBase64: fact.bytesBase64, size: fact.size, sourcePath: full, operation: "upload" }
  }
  fixture.expected.a["root-label-created.txt"] = { bytesBase64: "", size: 0, operation: "optional-manual-create" }
  fixture.initialPaths = Object.fromEntries(["a", "b"].map((role) => [role, originals.filter((file) => file.role === role).map((file) => file.path)]))
  fixture.finalPaths = { a: [...fixture.initialPaths.a.filter((value) => !value.startsWith(`${unicodeDirectory}/root-label-move-`)), ...pickers.map((value) => value.target), "root-label-copy-a.txt", "root-label-copy-b.txt", "root-label-move-a.txt", "root-label-move-b.txt"].sort(), b: [...fixture.initialPaths.b] }
  fixture.completeInputBytes = fixture.files.reduce((sum, value) => sum + value.size, 0) + fixture.pickerInputs.reduce((sum, value) => sum + value.size, 0)
  assert.ok(fixture.completeInputBytes < 1024)
  // Reuse only the verified passive observer directories; no service/Task owner is reused.
  await assertDirectDirectory(path.join(scratch, "native-observer"))
  await assertDirectDirectory(path.join(scratch, "native-observer", "runtime"))
  fixture.preparationCompletedAt = at()
  await fs.writeFile(path.join(runRoot, "prepared-fixture.json"), JSON.stringify(fixture, null, 2), { flag: "wx" })
  await save("prepared-fixture.json", fixture)
  console.log(JSON.stringify({ outcome: "prepared", fixtureID: fixture.fixtureID, runRoot, projects, pickerInputs: fixture.pickerInputs.map(({ full, target }) => ({ full, target })), initialPaths: fixture.initialPaths, finalPaths: fixture.finalPaths, completeInputBytes: fixture.completeInputBytes }, null, 2))
} catch (error) {
  await save(`${uniqueLabel("prepare-first-error")}.json`, { fixture, error: errorFact(error), at: at(), boundary: "Original failure retained. No fixture deletion, replacement run or automatic retry." })
  throw error
}
