# Explorer 根目录标签：已准备、尚未执行的真实验收工具

2026-10-14 Asia/Shanghai。已完整读取 `specs/records/2026-10/2026-10-14-explorer-directory-label.md` 的 Recall 和成熟 `.tmp-codex-concurrent-search-01a133` 的六个指定文件；注册 API 另参考其原 `setup-project.mjs` / `fixture-support.mjs`。本次只写本目录的新工具、备份、差异及 syntax 日志，未改任何产品、测试、spec、索引或 Git 内容，未委托。

**尚未执行 prepare、launch、register、readback、fault create/restore 或 shutdown。** 新 run 数据、Git 项目、Project/Chat IDs、HTTP（Hypertext Transfer Protocol，超文本传输协议）响应与桌面视觉结果均尚未产生。Root 要先逐个读代码，再按原计划授权动作；这里的准备不代表运行成功。

## 固定输入与文件清单

- 唯一新 run：`C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/explorer-directory-label-01a133`。
- 端口：`18453`；证据 prefix：`root-label`；证据目录：本目录的 `root-label/`。
- 私有 Bun/UI：`D:/myhexin-local/opencorvus/.tmp-codex-next-feedback-01a133/ui-bundle/bin/bun.exe` 与其同级 `ui/index.html`；build 由 Root 负责。
- 开发入口：原 `packages/opencorvus/src/index.ts serve ... /ui`；没有独立 Vite server。
- A=`<run>/project`，B=`<run>/project-b`，分别执行一次 `git init --initial-branch=main`，没有 commit/remote/SQL（Structured Query Language，结构化查询语言）注入。
- A 子目录原字符串为 `资料 Mix`。API 根目录 key 始终是 `""`；语言标签不会进入数据输入。

准备阶段写入的文件均为独立 UTF-8（Unicode Transformation Format，统一码转换格式）文本、原结尾 CRLF（Carriage Return/Line Feed，回车换行），每项完整 bytesBase64 和 dev/inode/birthtimeNs 存入不可覆盖 manifest：

| 位置 | 文件 | 原正文（最后另有 CRLF） |
| --- | --- | --- |
| A 根 | root-label-original.txt | ROOT ORIGINAL 01a133 |
| A/资料 Mix | root-label-copy-a.txt | COPY A 01a133 |
| A/资料 Mix | root-label-copy-b.txt | COPY B 01a133 |
| A/资料 Mix | root-label-move-a.txt | MOVE A 01a133 |
| A/资料 Mix | root-label-move-b.txt | MOVE B 01a133 |
| B 根 | root-label-project-b.txt | PROJECT B 01a133 |
| inputs | root-label-upload-one.txt | PICKER ONE 01a133 |
| inputs | root-label-upload-plural-a.txt | PICKER PLURAL A 01a133 |
| inputs | root-label-upload-plural-b.txt | PICKER PLURAL B 01a133 |
| inputs | root-label-upload-sub-all.txt | PICKER SUB ALL 01a133 |

前三个 picker 预声明到 A 根，第四个到 `资料 Mix/`。预声明复制/移动的目标是 A 根同 basename；可选手工新建文件仅预声明 `root-label-created.txt` 的空 bytes，准备脚本不会创建它。Root 可以只打开/取消新建对话框，届时不要把该文件放进 expected paths。

最终预期（只有 Root 实际完成这些动作后才适用）：A 共 11 个 `root-label-` 文件，根 8 个、子目录 3 个；B 只有自己的 marker。两条 Copy 源仍在子目录，两条 Move 的真实目标在根。manifest 同时保存 initialPaths、finalPaths 和每个候选路径的原 bytes；它们是预声明输入，不是已发生的 UI 结果。

Move 目标预声明的 `movedFromIdentity` 直接引用准备时的原源身份；Copy 不使用该字段。源码依据是 `file/index.ts:1398` → `util/filesystem.ts:265` → `util/rename-no-replace.ts:105,176` 的 Windows `MoveFileExW` flags=0，当前同卷移动没有 copy/delete 替代路径。读回使用原预声明 dev/inode/birth，不重算期望身份。

## 工具及成熟差异

| 文件 | 行为和差异 |
| --- | --- |
| `native-host.ts` | 与成熟原件完全相同；原 foreground Native Job、公开 facade、原两个 output drains、原 allSettled、原 ready/birth、原错误和 terminal 事实 |
| `owned-launch-functions.ps1` | 与成熟原件完全相同；原生产 occurrence observer、原 native settlement 验证和独占 receipt writer |
| `launch-ui.ps1` | 只更新新 namespace/port/prefix/private bin/fixture schema 和资格正文，增加 B project/.git 的物理准入，owner/input 记录加入 projectB 与四个 picker；原环境清理、900000 deadline、45 秒 ready、原父进程双 drain/最终 join 不变 |
| `shutdown.ps1` | 保原一次 shutdown admission、原 owner 胜者/其它 caller join、原 birth/port/physical settlement。按 Root 补充授权删除 provider JSON 读取及 auth/models pair 删除末段；加入新 namespace/fixture 准入。当前终态 receipt 名为 `root-label-physical-terminal-and-credential-free.json`，join 验 `credentialHandling=not-applicable-never-staged-by-checker`，没有伪造 pairedCleanupComplete |
| `prepare-ui.mjs` | 基于成熟 fresh-run prepare 改为上述 A/B 小输入。仅允许新建缺失日期父目录；精确 run mkdir 非 recursive、所有输入 wx；每个已有物理 namespace 及原字节/身份验证；失败保留原路径和第一错误，不清理/重用 |
| `fixture-support.mjs` | 当前工具共用的固定 namespace、物理准入、manifest/owner 读取和原 HTTP 字节保存；import 不执行 I/O（Input/Output，输入输出）或网络 |
| `register-projects.mjs` | 新的正常 API（Application Programming Interface，应用程序接口）caller。先写一次性 admission，再 A/B 各 GET `/project/current`（200）与 POST `/coding/chat/session` 空对象（201）；保存每个原请求/响应全字节、headers、request ID、实际 Project/Chat IDs；不发消息/模型请求。不自动重试可能已提交的 POST |
| `ui-readback.mjs` | 基于成熟只读 checker，支持阶段、A/B 和完整 expected paths。只 GET `/file/content`、`/file`、`/find/file`，外加本人物理路径读取；完整 bytes、原源/Move inode、目录节点和独立 scoped search 正向验证。Windows Node.path 按既有 API 的原路径分隔符投影为 `/` 作比较，原响应字节完整保留 |
| `root-ignore-fault.mjs` | 新的最小自有故障代码，仅 create/restore 两种显式模式；详见下节。没有 CLI/service/API 调用 |
| `check-tool-syntax.ps1` | 只语法解析的实际检查入口；不会执行或 import 上述 entrypoints |

成熟原六文件完整保留在 `mature-original/`，仅供审阅，绝不是执行 fallback。逐文件实际 `git diff --no-index` 保存于 `mature-diffs/`；原 Host/functions 的 diff exit 0，其余 exit 1 表示可审查的预期差异，均非功能通过结论。

## 物理 namespace 与 `.ignore` 故障

prepare 检查日期父的上一级实际目录，允许新建 `2026-10-14`，随后非 recursive mkdir 唯一新 run。文件与目录 lstat、realpath 排除链接/别名；A/B/两 Git 目录及子目录记录 dev/inode/birthtimeNs。Node API/故障/读回在使用前核原 manifest 的这些身份。run 已存在、输入已存在或 observer 目录冲突都保原失败，不删除再试。

`root-ignore-fault.mjs create`：先验证原 run/A/B/两 Git/子目录与 active owner；仅检查 A 根 `<project>/.ignore` 的实际 ENOENT，写一次性 admission，然后 `mkdir` 精确 target，保存该空目录的 dev/inode/birth。若原目标已存在即停止并保留，不能移动整个 Project 或替换文件。

`restore`：只读取本工具原 created receipt，核 fixture/occurrence/path 与该目录 dev/inode/birth，`readdir` 精确为空后调用非 recursive `rmdir`；若目录换身份或出现成员就失败保留，绝不递归删除。restore 仅依赖原文件 authority，允许服务已结算后仍清理该确切自有空目录；它不会再发 HTTP 或延長/重启服务。create/restore 的首错和准入都保存，Root 必须另授实际动作。

本工具不合成 refresh 错误，不强求某个 upload error type。真实目录失败/Details/语言投影只能由 Root 实页观察；typed 根 upload 错误未取得时仍应明确未验。

## 实际语法检查与预算资格

已运行 **syntax only**：Node `v25.7.0` 的 5 个 `--check`、Bun `1.4.0` Transpiler 对 Native Host 的纯语法解析、PowerShell Parser 对 4 个 PS 文件的 AST（Abstract Syntax Tree，抽象语法树）解析。最终 10 项 exit 全 0，检查器自身 exit 0。没有运行产品 entrypoint、fixture、API、模型、UI 或 fault。

原第一轮日志在 `tool-validation/syntax-20261013T161906366/`；随后实际改了 owner/readback 的准入和 Move 身份比较，必要的第二轮最终日志在 `tool-validation/syntax-20261013T162031662/`。每项完整 stdout/stderr 及独立 `.exit.json`、总 `results.json` 均保留，不由口述重建。

真实预算只能按代码和将来的启动输入描述：

- launcher 原 Native execution deadline：启动时 `DateTimeOffset.UtcNow + 900000ms`，同时写 input，ready 时核原 deadline 相同。未启动，尚无实际时间点。
- startup ready observation：45 秒；父进程随后继续 join 同一个原进程，不能因为观察窗口结束就创建替代实例。
- shutdown winner 的 native/port observation：45 秒；其它 caller join 75 秒。失败保存，不能发第二次 shutdown；父 launcher 仍等待同原 Host/drains。
- API client：每请求最多 20000ms，且不超过剩余原 Native deadline。超时只表示该 HTTP 调用观察失败，不能宣布服务/物理进程终止，也不自动重试 POST。
- 两次自有 Git init 各 15000ms 工具 deadline。它是准备输入，不是 runtime/Native deadline。
- **没有在此 PowerShell launcher 中加入或实际执行 120000ms inactivity driver。** 上游工具若另包一层需另记录原输入；不能凭旧文档宣称当前已经实际采用 120000，也不能把工具 yield 观察窗口当 execution budget。

无 auth/models/provider 内容复制、读取、输出或删除。`modelCallsRequested=none` / `credentialCatalogStaging=none` 是本 checker 的输入合同，不代表对可能自动生成文件的内容、存在性或 Provider 可用性做了验收。

## Root 审阅后可用的显式命令（当前未执行）

以下相对目录均从仓库根运行；每个阶段都应保存原 stdout/stderr/exit。先确保 PATH 使用当前 Bun 1.4.0；Node 用于文件/API checker，没有 Playwright。

```powershell
$env:PATH='D:/myhexin-local/opencorvus/.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64;'+$env:PATH
node .tmp-codex-next-feedback-01a133/prepare-ui.mjs prepare
```

prepare 经审阅实际成功后，Root 单独启动 `launch-ui.ps1` 并保留其原工具 session/父进程，ready 后单独注册：

```powershell
& ./.tmp-codex-next-feedback-01a133/launch-ui.ps1
node .tmp-codex-next-feedback-01a133/register-projects.mjs register
```

launch 是阻塞到实际终态的原 parent，不要把这两条当同一个前后相接 shell invocation；register 应在 root 已取得 ready owner 的另一普通工具调用中执行。

桌面真实动作、截图人工检查后，传入该时刻 A 所有当前 `root-label-` 文件的 JSON 数组；这些路径必须属于 fixture 预声明 map。示例仅是初始 A / B 的读取输入，不能用初始数组验操作后的状态：

```powershell
$expectedPaths=@('root-label-original.txt','资料 Mix/root-label-copy-a.txt','资料 Mix/root-label-copy-b.txt','资料 Mix/root-label-move-a.txt','资料 Mix/root-label-move-b.txt')|ConvertTo-Json -Compress
node .tmp-codex-next-feedback-01a133/ui-readback.mjs read initial-a a $expectedPaths
node .tmp-codex-next-feedback-01a133/ui-readback.mjs read project-b b '["root-label-project-b.txt"]'
```

实际完成全部计划且未新建可选文件时，可从原 manifest 的 `finalPaths.a` 取得预声明数组给读回；它仍要逐项验证现场 bytes/list/search，不能从 fixture 直接认定动作已完成。可选 create 已实际执行时显式追加 `root-label-created.txt`。

```powershell
node .tmp-codex-next-feedback-01a133/root-ignore-fault.mjs create
# Root 真实 Refresh、Details、语言切换并截图人工查看。
node .tmp-codex-next-feedback-01a133/root-ignore-fault.mjs restore
# Root 真实 Refresh 恢复后再运行对应阶段的只读检查。
& ./.tmp-codex-next-feedback-01a133/shutdown.ps1 -RunRoot 'C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/explorer-directory-label-01a133' -EvidenceRoot 'D:/myhexin-local/opencorvus/.tmp-codex-next-feedback-01a133/root-label' -EvidencePrefix root-label -Reason root-manual
```

正常 shutdown 的完整 Native/双输出/request/Host+Target/port 原回执与 launcher 的 parent join 才能形成实际收尾资格。脚本不会删 run/project，不会重启或 kill 用户进程。任何实际首错保留；尚无新运行、功能或视觉通过结论。
