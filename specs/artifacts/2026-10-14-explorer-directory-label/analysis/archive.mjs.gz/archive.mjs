/** PREPARED ONLY. Root reviews this exact script and separately authorizes `archive` after all original writers settle. */
import assert from "node:assert/strict"
import fs from "node:fs"
import path from "node:path"
import { fileURLToPath } from "node:url"
import { gzipSync, gunzipSync } from "node:zlib"

assert.equal(process.argv[2], "archive", "Explicit reviewed archive mode required")
assert.equal(process.argv.length, 3)
const scratch = path.dirname(fileURLToPath(import.meta.url))
const repo = path.dirname(scratch)
assert.equal(path.resolve(repo).toLowerCase(), path.resolve("D:/myhexin-local/opencorvus").toLowerCase())
const artifacts = path.join(repo, "specs", "artifacts")
const uiArea = "2026-10-14-explorer-directory-label"
const capsuleArea = "2026-10-14-capsule-preparation-authority"
const day = "C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14"
const runNames = ["explorer-directory-label-01a133", "explorer-directory-label-final-01a133"]
const plans = new Map([[uiArea, []], [capsuleArea, []]])
const aliases = []
const exclusions = []
const blockedDirectories = new Set(["ui-bundle", "bin", "native-observer", "runtime", "node_modules", ".git"])
const mediaExtensions = new Set([".jpg", ".jpeg", ".png", ".webp", ".gif"])
const blockedFile = (name) => /^(auth|models)\.json(?:\..*)?$/i.test(name) || /^provider-/i.test(name) || /(?:\.db|\.sqlite|\.sqlite3)(?:-wal|-shm|-journal)?$/i.test(name) || /\.(pem|key|pfx|p12)$/i.test(name)
const readJSON = (full) => JSON.parse(fs.readFileSync(full, "utf8"))
const originalPath = (relative) => path.join(scratch, "root-label", relative)
const finalPath = (relative) => path.join(scratch, "root-label-final", relative)

function assertDirect(full) {
  const item = fs.lstatSync(full)
  assert.equal(item.isSymbolicLink(), false, `Evidence source is a link: ${full}`)
  assert.equal(path.resolve(fs.realpathSync.native(full)).toLowerCase(), path.resolve(full).toLowerCase(), `Evidence source has a physical alias: ${full}`)
  return item
}

function artifactTarget(area, relative) {
  assert.ok(plans.has(area))
  assert.ok(relative && !path.posix.isAbsolute(relative) && relative.split("/").every((part) => part && part !== "." && part !== ".."))
  const areaRoot = path.join(artifacts, area)
  const target = path.join(areaRoot, ...relative.split("/"))
  assert.equal(path.relative(areaRoot, target).startsWith(".."), false)
  return target
}

function add(area, source, relative) {
  const item = assertDirect(source)
  assert.equal(item.isFile(), true, `Regular original evidence file required: ${source}`)
  assert.equal(blockedFile(path.basename(source)), false, `Excluded credential/database path was selected: ${source}`)
  const media = mediaExtensions.has(path.extname(source).toLowerCase())
  plans.get(area).push({ source, artifact: relative + (media ? "" : ".gz"), media })
}

function tree(area, source, relative, skip = new Set()) {
  assert.equal(assertDirect(source).isDirectory(), true)
  for (const name of fs.readdirSync(source).sort()) {
    const full = path.join(source, name)
    if (skip.has(name) || blockedDirectories.has(name) || blockedFile(name)) {
      exclusions.push({ source: full, reason: skip.has(name) ? "Historical duplicate mapped to canonical original evidence" : "Credential/database/generated runtime or private binary excluded before reading" })
      continue
    }
    const item = assertDirect(full)
    if (item.isDirectory()) tree(area, full, path.posix.join(relative, name))
    else add(area, full, path.posix.join(relative, name))
  }
}

// Preserve every first-occurrence snapshot byte without storing/counting its sixteen JPEGs twice.
function verifyHistoricalReplica(source, relative = "") {
  for (const name of fs.readdirSync(source).sort()) {
    const full = path.join(source, name)
    const key = path.posix.join(relative, name)
    const item = assertDirect(full)
    if (item.isDirectory()) { verifyHistoricalReplica(full, key); continue }
    assert.equal(item.isFile(), true)
    assert.equal(blockedFile(name), false)
    const canonical = originalPath(key)
    assert.equal(assertDirect(canonical).isFile(), true)
    assert.ok(fs.readFileSync(full).equals(fs.readFileSync(canonical)), `Historical evidence diverged; preserve both sources for review: ${key}`)
    const suffix = mediaExtensions.has(path.extname(name).toLowerCase()) ? "" : ".gz"
    aliases.push({ source: full, historicalRelative: `history-first-occurrence/root-label/${key}`, canonicalSource: canonical, artifact: `actual/root-label/${key}${suffix}`, qualification: "The complete historical original bytes are identical to this canonical archived file; no image re-encoding or source digest gate" })
  }
}

function mediaFormat(bytes, source) {
  const extension = path.extname(source).toLowerCase()
  if (extension === ".jpg" || extension === ".jpeg") {
    assert.ok(bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff, `JPEG bytes required: ${source}`)
    return "JPEG original"
  }
  if (extension === ".png") {
    assert.ok(bytes.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10])), `PNG bytes required: ${source}`)
    return "PNG original"
  }
  if (extension === ".webp") {
    assert.equal(bytes.subarray(0, 4).toString("ascii"), "RIFF")
    assert.equal(bytes.subarray(8, 12).toString("ascii"), "WEBP")
    return "WebP original"
  }
  if (extension === ".gif") {
    assert.ok(["GIF87a", "GIF89a"].includes(bytes.subarray(0, 6).toString("ascii")))
    return "GIF original"
  }
  throw new Error(`Unrecognized original media format: ${source}`)
}

// Require original end receipts before archive enumeration. Never require a successful exit to retain evidence.
const firstJoined = readJSON(originalPath("root-label-launcher-joined.json"))
const finalJoined = readJSON(finalPath("root-label-final-launcher-joined.json"))
const firstShutdown = readJSON(originalPath("root-label-shutdown-admission.json"))
const finalShutdown = readJSON(finalPath("root-label-final-shutdown-admission.json"))
const originalSupplementName = "readback-restored-a-a-1791909799288-fc226d26-3627-4fc4-bf15-716850b2b768.json"
const originalSupplement = readJSON(originalPath(originalSupplementName))
const outcomeFacts = {
  first: { occurrence: firstJoined.occurrence, launcherExitCode: firstJoined.exitCode, terminal: firstJoined.settlement?.terminal, shutdownDispatch: firstShutdown.dispatch, shutdownStatus: firstShutdown.status, supplementalReadbackExitCode: originalSupplement.exitCode, supplementalRequests: originalSupplement.requests?.length },
  final: { occurrence: finalJoined.occurrence, launcherExitCode: finalJoined.exitCode, terminal: finalJoined.settlement?.terminal, shutdownDispatch: finalShutdown.dispatch, shutdownStatus: finalShutdown.status },
  qualification: "Direct projections of complete original receipts. First and final occurrences remain independent; failures are not converted into successful completion.",
}

for (const entry of fs.readdirSync(scratch, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name))) {
  if (!entry.isFile()) continue
  if (blockedFile(entry.name)) { exclusions.push({ source: path.join(scratch, entry.name), reason: "Credential/database excluded before reading" }); continue }
  // Archive's own execution log is a future/live output, not a completed source. Root records it after this call.
  if (/^archive-(?:run|execution)/.test(entry.name)) { exclusions.push({ source: path.join(scratch, entry.name), reason: "Current archive invocation output is recorded by Root after completion" }); continue }
  if (!/\.(?:mjs|ps1|ts|md|txt|diff|log|json)(?:\.before-[a-z0-9-]+)?$/i.test(entry.name)) continue
  add(uiArea, path.join(scratch, entry.name), `analysis/${entry.name}`)
}
for (const name of ["root-label", "root-label-final", "tool-validation", "mature-original", "mature-diffs", "final-tool-diffs"]) {
  tree(uiArea, path.join(scratch, name), `actual/${name}`)
}
const history = path.join(scratch, "history-first-occurrence")
tree(uiArea, history, "actual/history-first-occurrence", new Set(["root-label"]))
verifyHistoricalReplica(path.join(history, "root-label"))

for (const name of runNames) {
  const run = path.join(day, name)
  assert.equal(assertDirect(run).isDirectory(), true)
  // Exact admitted files only: never enumerate runtime, databases, auth/models or provider storage.
  for (const file of ["prepared-fixture.json", "launch-owner.json", "startup.json", "stdout.log", "stderr.log"]) {
    add(uiArea, path.join(run, file), `original-runs/${name}/${file}`)
  }
  tree(uiArea, path.join(run, "evidence"), `original-runs/${name}/evidence`)
  // Root admitted this exact completed diagnostic log in each owned run; never enumerate runtime.
  add(uiArea, path.join(run, "runtime", "log", "dev.log"), `original-runs/${name}/runtime/log/dev.log`)
}
add(uiArea, path.join(repo, ".tmp-codex-next-publication-01a133/evidence-gap-and-plan.md"), "independent/B-evidence-gap-and-plan.md")
add(capsuleArea, path.join(repo, ".tmp-codex-next-capsule-01a133/fact-source-audit.md"), "independent/fact-source-audit.md")

// Preflight every target before writing. Existing README/index files belong to Root and remain untouched.
assert.equal(assertDirect(artifacts).isDirectory(), true)
const targets = new Set()
for (const [area, items] of plans) {
  const out = path.join(artifacts, area)
  assert.equal(assertDirect(out).isDirectory(), true)
  for (const item of items) {
    const target = artifactTarget(area, item.artifact)
    assert.equal(targets.has(target.toLowerCase()), false, `Duplicate archive target: ${target}`)
    targets.add(target.toLowerCase())
    assert.equal(fs.existsSync(target), false, `Archive already exists; do not replace: ${target}`)
    let parent = path.dirname(target)
    while (!fs.existsSync(parent)) parent = path.dirname(parent)
    assert.equal(assertDirect(parent).isDirectory(), true)
  }
  assert.equal(fs.existsSync(path.join(out, "manifest.json")), false, `Manifest already exists; preserve previous archive: ${out}`)
}

for (const [area, items] of plans) {
  const archived = []
  for (const item of items) {
    const bytes = fs.readFileSync(item.source)
    const format = item.media ? mediaFormat(bytes, item.source) : "gzip of complete original bytes"
    const stored = item.media ? bytes : gzipSync(bytes)
    const target = artifactTarget(area, item.artifact)
    fs.mkdirSync(path.dirname(target), { recursive: true })
    fs.writeFileSync(target, stored, { flag: "wx" })
    const reloaded = fs.readFileSync(target)
    assert.ok((item.media ? reloaded : gunzipSync(reloaded)).equals(bytes), `Archive byte copy failed: ${item.source}`)
    archived.push({ source: item.source, artifact: item.artifact, originalBytes: bytes.length, archivedBytes: stored.length, format })
  }
  const manifest = {
    createdAt: new Date().toISOString(), area, files: archived.length,
    media: archived.filter((item) => item.format.endsWith(" original")).map(({ artifact, originalBytes, format }) => ({ artifact, originalBytes, format })),
    qualification: area === uiArea ? "Complete original UI/tool/API/raw evidence, preserving first deadline-exceeded/parent1 and zero-request supplemental failure independently of the final run. All JPEG files remain original bytes. Root and the visual-review agent confirmed the final 01 disk JPEG shows the complete A-root baseline; the initial inline-preview doubt is not a disk-frame defect." : "Complete read-only Capsule fact-source analysis. No Linux/model/product/restore acceptance is implied.",
    integrity: "Gzip/direct byte readback proves only archive-copy integrity; no source hash or mutable-code checksum is used as functional acceptance.",
    ...(area === uiArea ? { outcomeFacts, historicalAliases: aliases, exclusions, independentReportBoundary: "B-evidence-gap-and-plan is read-only B follow-up analysis; it is not UI or File.index repair acceptance." } : {}),
    items: archived,
  }
  fs.writeFileSync(path.join(artifacts, area, "manifest.json"), JSON.stringify(manifest, null, 2), { flag: "wx" })
  console.log(JSON.stringify({ area, files: archived.length, originalJPEG: archived.filter((item) => item.format === "JPEG original").length, originalPNG: archived.filter((item) => item.format === "PNG original").length, historicalAliases: area === uiArea ? aliases.length : 0 }))
}
