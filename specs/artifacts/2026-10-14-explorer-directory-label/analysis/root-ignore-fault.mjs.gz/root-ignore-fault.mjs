/** PREPARED ONLY. Root separately authorizes exact mkdir / empty-dir rmdir; no service/API operation. */
import assert from "node:assert/strict"
import fs from "node:fs/promises"
import path from "node:path"
import { evidence, projects, at, save, readJSON, physical, assertIdentity, loadPrepared, loadOwner, errorFact, uniqueLabel } from "./fixture-support.mjs"

const mode = process.argv[2]
assert.ok(["create", "restore"].includes(mode))
assert.equal(process.argv.length, 3)
const fixture = await loadPrepared()
// Restore is an exact filesystem receipt operation, and can remain necessary after service settlement.
const owner = await loadOwner(fixture, mode === "create")
const target = path.join(projects.a, ".ignore")
assert.equal(path.dirname(path.resolve(target)), projects.a)
const result = { fixtureID: fixture.fixtureID, occurrence: owner.occurrence, mode, target, startedAt: at(), authority: "Only A's exact direct .ignore empty directory; no project move, file deletion, root cleanup or runtime command" }
try {
  if (mode === "create") {
    try { await fs.lstat(target); throw new Error("Exact fault target already exists; preserve it") }
    catch (error) { if (error.code !== "ENOENT") throw error; result.prior = { code: error.code, checkedAt: at() } }
    await save("root-ignore-fault-admission.json", result)
    await fs.mkdir(target)
    result.identity = await physical(target, false)
    assert.equal(result.identity.directory, true)
    assert.deepEqual(await fs.readdir(target), [])
    result.outcome = "owned-empty-ignore-directory-created"
    result.completedAt = at()
    await save("root-ignore-fault-created.json", result)
  } else {
    const original = await readJSON(path.join(evidence, "root-ignore-fault-created.json"))
    assert.equal(original.fixtureID, fixture.fixtureID)
    assert.equal(original.occurrence, owner.occurrence)
    assert.equal(original.target, target)
    assert.equal(original.outcome, "owned-empty-ignore-directory-created")
    result.identity = await physical(target, false)
    assertIdentity(result.identity, original.identity)
    assert.equal(result.identity.directory, true)
    const children = await fs.readdir(target)
    assert.deepEqual(children, [], "Only the exact original empty directory may be removed")
    result.verifiedEmptyAt = at()
    await save("root-ignore-fault-restore-admission.json", result)
    await fs.rmdir(target) // Deliberately non-recursive; fails if any member appeared.
    try { await fs.lstat(target); throw new Error("rmdir returned but original target still exists") }
    catch (error) { if (error.code !== "ENOENT") throw error; result.removal = { code: error.code, checkedAt: at() } }
    result.outcome = "owned-empty-ignore-directory-restored"
    result.completedAt = at()
    await save("root-ignore-fault-restored.json", result)
  }
  console.log(JSON.stringify(result, null, 2))
} catch (error) {
  result.outcome = "original-fault-tool-error-retained"
  result.error = errorFact(error)
  result.failedAt = at()
  await save(`${uniqueLabel(`root-ignore-${mode}-first-error`)}.json`, result)
  throw error
}
