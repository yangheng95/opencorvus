# Explorer 根目录显示：独立只读源码复核

## Recall、范围与结论

2026-10-14，root在完整读取B只读报告后另授权本复核：先读 `specs/records/2026-10/2026-10-14-explorer-directory-label.md` Recall、`audit.md`、`implementation.md`、`preexisting-three-files.diff`及当前三文件差异；只核根目录显示helper、五展示、稳定typed目录错误、实际target producer、locale反应/scope/Details/身份。禁止再次委托、产品/测试/spec/共享索引修改、测试/服务/模型/UI操作/Git动作。本任务只写本独立报告，不启动B或任何checker，不评价Provider foreign修改。

**未发现当前精确改动的源码阻断或必须修正项。** 一个私有显示投影只将规范空目录key翻译，五个现展示和一个稳定错误角色共用；非空路径及undefined原值返回；producer提供的真实target、API、Node、editor、scope与Details未变。此结论是独立源码复核，不是本次页面/视觉/端到端验收。

已完整读保存的 `after-three-files.diff` 和 `preexisting-three-files.diff`，并逐个核对当前源中所有修改hunk及其上下游。root已声明三源冻结；本复核没有调用Git命令重生成diff。范围为：

- `packages/overlay/src/components/FileExplorerPanel.tsx`：组件私有helper、原错误摘要、一目录刷新/三成功反馈/一create dialog投影；没有其它本批hunk。
- `packages/overlay/src/i18n/en-US.json:1459`：新增 `explorer.root_directory="Root folder"`。
- `packages/overlay/src/i18n/zh-CN.json:1458`：新增同key `"根目录"`。

两catalog中原Provider的 `models_required` 删除与 `models_hint` 修改在preexisting/after快照保持相同，作为其它owner背景排除；没有审查其产品正确性、修改或运行相关测试。

## 单一投影与精确输入合同

`FileExplorerPanel.tsx:200–202` 的唯一 `explorerDirectoryDisplayPath(path:string|undefined)` 实现为 `path === "" ? t("explorer.root_directory") : path`。

- 精确空串才调用根label；不是truthiness、trim、字符串关键词或重新normalize。
- 非空子路径、空白文件名、大小写、Unicode、Windows separator/POSIX反斜杠、`..`等已提供字串原样返回。调用前已有规范化仍属于原数据流，helper不改变其合同。
- undefined原样返回，未提供目标不宣称当前root。共享 `fillTemplate` 对undefined仍用原空插值；这是现template行为，不是helper把undefined解释为root。
- helper只在渲染/对话框正文生成使用。没有写回outcome.target、directoryMap、选中path、Node/UploadResult、API targetDir、文件系统或editortarget；无第二state/locale effect/缓存/通知/请求/准入gate。

当前Files根是原 `scope.directory` 对应的规范相对空key。该label不承诺Git worktree/Project主工作树字段，没有调用Project basename/custom name命名primitive，没有因展示而新增metadata lookup。`normalizeExplorerPath:370`仍唯一委托 `normalizeProjectFilePath`；server-path的词法空根与真实entry identity合同不变。

## 五个同义展示与typed目录错误

| 当前代码位置 | 原事实来源 | 实际改动及保留边界 |
| --- | --- | --- |
| 273，refreshReceiptMessage | `FileRefreshTarget.kind="directory"` 的规范path | 原directory result摘要只投影path；search分支原query保留。failed/retired的真实状态与cause不变 |
| 294，多项Copy成功 | `feedback.target` | completed===1仍展示真实成功entry path；只有多项目的目录投影 |
| 295，多项Move成功 | 同上 | 单项仍原path，真实completed数量/失败成员不变 |
| 297，Upload成功 | 原Upload outcome.target | tc按真实completed数量，根label在当前语言插入；真实uploaded path不变 |
| 1161，create dialog | 规范targetDir | 只改 `explorer.create_in` 正文变量；requestedPath仍原join，创建成功仍Node.path |
| 210–225，FileUploadInvalidTargetError | 稳定body.name、object data、已验证字符串data.targetDir | generic summary在原typeof检查后只为targetDir调用同helper；当前唯一targetDir调用来自该稳定类型 |

typed摘要仍依 `ApiError`、非数组object body/data、typeof string验证；未知/malformed metadata沿既有operation摘要，没有猜英文错误、复制识别器、合成path或吞后端I/O。FileConflict/UploadConflict/NotFound/InvalidPath 的path、UploadInvalidName/Content的name全部原值；member、postOpen、单项create/rename/delete/search身份未机械替换。

`ExplorerActionFeedback:314–343`仍分别把原error传给共享 `formatErrorDetails`。本批没有改cause、HTTP status/method/path、requestID、body或Details owner。`utils/error-details.ts`以原Error/ApiError metadata形成全文，翻译label只存在摘要变量中。目录refresh失败/退休即使label变化，原Details仍由refreshFailure实际cause提供。

## 实际producer与正常/退休路径

已读实际target生产者，不由optional类型猜根：

- Move `899–934`：先 `normalizeExplorerPath(targetDirInput)`，runMutation内 `outcome.target=targetDir:920`，每成员实际nextPath由原 `joinExplorerPath(targetDir,item.name)`，真实MoveResult收齐后现applyMoveResults。
- Copy `1330–1366`：同一规范targetDir，`outcome.target=targetDir:1352`，每成员真实CopyResult后原refresh。单项copy/move其它producer不需要target，而对应单项反馈也不使用目的目录字段。
- Upload `1534–1590`：picker保存原规范targetDir与scope，input变更读取原Files；uploadFiles再次原规范化，`outcome.target=targetDir:1564`，`uploadDroppedFiles(targetDir,files,scope)`实际成功才赋completed并refresh。
- Create `1151–1209`：同一targetDir只用于dialog正文和原requestedPath构造；本地化根label没有进入 `createFileItem` payload。
- refreshFileViews `1023–1039`：uniquePaths使用既有normalize，原 `{kind:"directory",path}`与真实read Promise送唯一collector；search仍独立原source。空root是合法target，不是新增结果。

backend `File.upload:1514–1533`仍将raw空targetDir解释为 `Instance.directory`，非空path.join；稳定 `FileUploadInvalidTargetError`原data.targetDir保input，显示层不修改。`services/file-workbench.ts:396–416`仍将targetDir原值JSON发送、仅成功返回结果/bump revision；其它create/move/copy API映射、editor admission/commit均未修改。

原 `currentOperationScope:465–470`捕获directory/authority/selectionEpoch；`ownsExplorerOperation:472–480`核disposed、epoch、authority和directory。runMutation:971–995及Upload finally:1574–1580只在同原owner时发布原反馈；两个scope effects:453–463/540–565仍清原query/Map/feedback/token。helper不读scope或触effects，因此没有从前一Project把根字符串存进后一Project状态。逻辑open下手动工具切换/Dock隐藏保owner的83行为也没有新改动。此为源码合同核对，未冒称本次跨项目/late window实际运行。

## 当前语言反应

`utils/i18n.ts:52–61` 的localeValue读取 `appStore.localeSeq`，t/tc取当前catalog；`setLocale:171–184`载入合法locale后切currentLocale并更新store，`store/app.ts:230–234`增加localeSeq。helper在反馈JSX表达式中即时调用t，外层feedbackMessage/refreshReceiptMessage也即时t/tc，数字用 `Intl.NumberFormat(localeTag())`。因此根label、句式、数量都沿既有当前语言反应链；没有将动作发生时翻译字串写进feedback，也没有以语言切换重放动作。

两catalog同一个root key是普通string，原upload plural/目标placeholder和其它现句式未改；helper对于非空path保字符，而外层t仍响应当前locale。根+句式组合实际可能为“Folder Root folder: …”/“文件夹 根目录：…”；是否自然、换行与密度仍需真实截图人工判断，源码审查不能代替该判断。

Create dialog是既有命令式 `showAppDialog`：在打开前调用t形成普通字符串，`services/app-dialog.ts:128–143`存进dialog options/store。打开之后切语言的快照行为没有新增reactivity，本spec已明确排除，不为此扩大共享dialog。正常打开时当前语言已覆盖该处新增label。

## 已读工具证据及未取得资格

只读检查了本批原typecheck input/log/exit：Bun1.4绝对路径、overlay cwd、`bun run typecheck`→`tsc --noEmit`，实际2026-10-13T16:08:39.221Z exit0；三文件diff-check原input/emptylog/exit0。只读私有build日志尾部为 `built in 59.28s`、实际私有main-CL_NGz1d.js；root另报告build0。没有由本agent重跑工具、测试或构建，也不把它们当视觉资格。

本人没有启动服务/操作UI/查看本次后态截图或API checker。本次以下仍unknown/由root按spec另验：根/子目录/单复数真实反馈布局、中英文切换后的原回执、批量Copy/Move实际目标和fullbytes、新建正文、root刷新故障与Details、同backend两Project切换；typed-upload空root错误的实际UI尤其尚无证据。external drop、POSIX实机、late upload窗口、打开dialog后切语言的边界保持spec原范围。没有评价/改Provider foreign hunks，也没有复用B或此前after-ui的旧receipt冒充本次资格。

未发现代码阻断，当前不要求源码修正；root可继续已计划的真实桌面/实体API收敛。如果实际图暴露句式/布局问题，应以原图定位再改，而不是凭此次types/build0直接完成交付。
