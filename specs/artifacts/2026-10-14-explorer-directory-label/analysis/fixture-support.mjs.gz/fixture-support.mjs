/** Prepared tools only. Importing this module performs no filesystem/network/process work. */
import assert from "node:assert/strict"
import fs from "node:fs/promises"
import path from "node:path"
import { randomUUID } from "node:crypto"
import { fileURLToPath } from "node:url"

export const scratch = path.dirname(fileURLToPath(import.meta.url))
export const evidence = path.join(scratch, "root-label-final")
export const runRoot = path.resolve("C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/explorer-directory-label-final-01a133")
export const port = 18454
export const prefix = "root-label-final"
export const schema = "explorer-directory-label.fixture/v1"
export const qualification = "real-desktop-explorer-directory-label"
export const projects = { a: path.join(runRoot, "project"), b: path.join(runRoot, "project-b") }
export const unicodeDirectory = "资料 Mix"
export const at = () => new Date().toISOString()
export const samePath = (left, right) => path.resolve(left).toLowerCase() === path.resolve(right).toLowerCase()
export const errorFact = (error) => ({ name: error?.name ?? typeof error, code: error?.code, message: error?.message ?? String(error), stack: error?.stack })
export const readJSON = async (full) => JSON.parse(await fs.readFile(full, "utf8"))

export async function save(name, value) {
  assert.equal(path.basename(name), name)
  await fs.mkdir(evidence, { recursive: true })
  const full = path.join(evidence, name)
  await fs.writeFile(full, JSON.stringify(value, null, 2), { flag: "wx" })
  return full
}

export async function assertDirectDirectory(full) {
  const item = await fs.lstat(full)
  assert.equal(item.isDirectory(), true, `Directory required: ${full}`)
  assert.equal(item.isSymbolicLink(), false, `Physical directory required: ${full}`)
  assert.equal(samePath(await fs.realpath(full), full), true, `Physical alias is not admitted: ${full}`)
}

export async function assertOwned(full) {
  const target = path.resolve(full)
  const relative = path.relative(runRoot, target)
  assert.ok(relative === "" || (!relative.startsWith("..") && !path.isAbsolute(relative)), "Exact owned namespace required")
  let cursor = target
  for (;;) {
    const item = await fs.lstat(cursor)
    assert.equal(item.isSymbolicLink(), false, `Physical entry required: ${cursor}`)
    if (samePath(cursor, runRoot)) break
    cursor = path.dirname(cursor)
  }
  await assertDirectDirectory(runRoot)
  return target
}

export async function physical(full, includeBytes = true) {
  await assertOwned(full)
  const item = await fs.lstat(full, { bigint: true })
  const fact = { full: path.resolve(full), at: at(), device: String(item.dev), inode: String(item.ino), birthtimeNs: String(item.birthtimeNs), size: Number(item.size), file: item.isFile(), directory: item.isDirectory(), symbolicLink: item.isSymbolicLink() }
  if (item.isFile() && includeBytes) fact.bytesBase64 = (await fs.readFile(full)).toString("base64")
  return fact
}

export function assertIdentity(actual, original) {
  for (const key of ["device", "inode", "birthtimeNs", "file", "directory", "symbolicLink"]) assert.equal(actual[key], original[key], `${key}: ${actual.full}`)
}

export async function loadPrepared() {
  const prepared = path.join(runRoot, "prepared-fixture.json")
  await assertOwned(prepared)
  const fixture = await readJSON(prepared)
  assert.equal(fixture.schema, schema)
  assert.equal(fixture.qualification, qualification)
  assert.equal(fixture.prefix, prefix)
  assert.equal(fixture.port, port)
  assert.equal(samePath(fixture.runRoot, runRoot), true)
  assert.equal(fixture.modelCallsRequested, "none")
  assert.equal(fixture.credentialCatalogStaging, "none")
  for (const role of ["a", "b"]) {
    assert.equal(samePath(fixture.scopes[role].directory, projects[role]), true)
    assertIdentity(await physical(projects[role], false), fixture.scopes[role].identity)
    assertIdentity(await physical(path.join(projects[role], ".git"), false), fixture.scopes[role].gitIdentity)
  }
  assertIdentity(await physical(path.join(projects.a, unicodeDirectory), false), fixture.scopes.child.identity)
  return fixture
}

export async function loadOwner(fixture, requireActive = true) {
  const full = path.join(runRoot, "launch-owner.json")
  await assertOwned(full)
  const owner = await readJSON(full)
  assert.equal(owner.fixtureID, fixture.fixtureID)
  assert.equal(owner.qualification, qualification)
  assert.equal(owner.evidencePrefix, prefix)
  assert.equal(owner.port, port)
  assert.equal(samePath(owner.runRoot, runRoot), true)
  assert.equal(samePath(owner.project, projects.a), true)
  assert.equal(samePath(owner.projectB, projects.b), true)
  assert.equal(samePath(owner.runtime, path.join(runRoot, "runtime")), true)
  assert.equal(samePath(owner.settlementEvidenceRoot, evidence), true)
  if (requireActive) {
    assert.ok(owner.nativeDeadline > Date.now(), "Original deadline expired; retain this run, never restart or extend it")
    for (const name of ["native-host-settled.json", "native-host-error.json"]) {
      try { await fs.lstat(path.join(runRoot, "evidence", name)); throw new Error(`Original service already has ${name}; no further requests admitted`) }
      catch (error) { if (error.code !== "ENOENT") throw error }
    }
  }
  return owner
}

/** Exact JSON request and full response bytes. A client timeout is not process settlement. */
export function httpClient(records, owner) {
  return async (label, role, route, query = {}, body) => {
    assert.ok(Object.hasOwn(projects, role))
    assert.ok(["/project/current", "/coding/chat/session", "/file/content", "/file", "/find/file"].includes(route))
    assert.ok(body === undefined || route === "/coding/chat/session", "Only the explicit empty Chat registration can POST")
    const url = new URL(route, `http://127.0.0.1:${port}`)
    url.searchParams.set("directory", projects[role])
    for (const [key, value] of Object.entries(query)) url.searchParams.set(key, String(value))
    const requestBody = body === undefined ? undefined : JSON.stringify(body)
    const record = { sequence: records.length + 1, label, role, method: body === undefined ? "GET" : "POST", url: url.toString(), requestBody, requestBodyBase64: requestBody === undefined ? undefined : Buffer.from(requestBody).toString("base64"), dispatchedAt: at(), chunks: [] }
    records.push(record)
    try {
      const budget = Math.min(20_000, owner.nativeDeadline - Date.now())
      assert.ok(budget > 0, "Original execution budget has expired")
      const response = await fetch(url, { method: record.method, headers: body === undefined ? undefined : { "content-type": "application/json" }, body: requestBody, signal: AbortSignal.timeout(budget) })
      record.status = response.status
      record.headers = Object.fromEntries(response.headers)
      record.requestID = response.headers.get("x-opencorvus-request-id")
      record.headersAt = at()
      const chunks = []
      if (response.body) for await (const value of response.body) {
        const bytes = Buffer.from(value)
        chunks.push(bytes)
        record.chunks.push({ at: at(), bytes: bytes.length, bytesBase64: bytes.toString("base64") })
      }
      const complete = Buffer.concat(chunks)
      record.rawBodyBase64 = complete.toString("base64")
      record.rawBody = complete.toString("utf8")
      record.completedAt = at()
      try { record.body = JSON.parse(record.rawBody) } catch (error) { record.parseError = errorFact(error) }
      return record
    } catch (error) { record.error = errorFact(error); record.failedAt = at(); throw error }
  }
}

export function uniqueLabel(stem) { return `${stem}-${Date.now()}-${randomUUID()}` }
