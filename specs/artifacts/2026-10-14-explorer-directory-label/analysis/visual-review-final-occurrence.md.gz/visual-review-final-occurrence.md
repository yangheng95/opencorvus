# 根目录展示：最终独立发生实例人工图复核

本轮只读：先读 root-label-final/ui 实际目录文件名、当前正式规格独立剩余验收段、该轮 readback/settlement/shutdown/launcher/physical 回执，再用 view_image original逐张实际呈现并人工查看7个 `.jpg`。没有操作UI（User Interface，用户界面）、启动进程/服务/模型、运行测试、改产品或再次委托。首轮报告与所有失败保持原样。

新独立原发生实例为 root-label-final-a44b2d9e-ac87-4e65-8fa1-5bb8519330f0，run root C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/explorer-directory-label-final-01a133，port18454。它有自己的A/B实体、Project/Chat、原PID（Process Identifier，进程标识符）/birth与请求回执；相同basename或构建不会使其成为首轮的重试/收尾。以下只是这次本人的人工视觉证据，不以图片推定文件字节或进程退出。

## 七张实际图

路径前缀：D:/myhexin-local/opencorvus/.tmp-codex-next-feedback-01a133/root-label-final/ui/。

| 实际文件 | 人工观察及资格 |
| --- | --- |
|01-a-root-before.jpg|本次view_image实际读取的磁盘文件显示完整应用、英语Files根列表、真实`资料 Mix`/root-label-original.txt，不是只可见标题栏。因此不能根据“可能早帧”的提示把当前文件描述为只绘标题；也不猜曾经其它早帧内容。它只是无操作反馈的baseline，不给根label功能证明。|
|02-root-upload-one-en.jpg|完整绿色“Uploaded 1 file to Root folder”，实际basename root-label-upload-one.txt出现在根列表。英语单项/count/根目的地清楚，右側feedback和列表未见裁切或遮挡。|
|03-refresh-root-error-en.jpg|上方原Upload success与独立红色“Unable to refresh the file list.”共存；具名directory receipt为“Folder Root folder: Unable to load files”，其Details可见。下方当前load failure还有自己的Details/Retry，未把上传成功改称失败。根目标可理解且完整可读。|
|04-refresh-root-details-en.jpg|该根directory receipt的Details实际展开。当前可见原HTTP GET500、file?path=&directory=<编码真实final scope>，root API path仍空，技术路径未被Root folder替换。长URL在既有bounded诊断区内换行；更下方在这个滚动位置未全显示，不猜其全部内容。|
|05-refresh-root-details-scroll-en.jpg|同Details的真实后续滚动位置，可见原stack中的localhost:18454/ui/assets/main-CL_NGz1d.js、response body、name:"UnknownError"与data对象开头。它证明原响应body能经滚动到达该位置，不证明单图已展示/读完所有body字段；也不是FileUploadInvalidTargetError。当前长诊断区没有溢出右侧栏或覆盖其它操作区域。|
|06-a-restored-query-en.jpg|恢复后可见独立“Explorer refreshed.”、原英语Upload root成功以及root-label-查询的6个A成员。四个子目录成员旁保持真实`资料 Mix`；这是该全新fixture预声明的6成员，不是首轮11成员丢失。|
|07-project-b-isolated-en.jpg|选中B项目Chat，Files当前query仅root-label-project-b.txt一个真实成员，目标region干净且未呈现A操作反馈。这给普通scope导航的视觉资格，不证明尚未取得的late upload退休窗口。|

当前目标区域整体可读，根/非空目录身份、英语摘要、反馈堆叠、Details与Retry布局未见本批需要整改的具体阻塞。图03/04的实际句式确实组合为“Folder Root folder: …”，来自既有Folder {{path}}框架与既定Root folder标签；这次可见完整目的地，未因这个prefix猜测改label、删除所有directory角色前缀或扩大文案scope。若root以后判断需要润色完整英文句式，应另基于该原图与句子合同作精确决定，而不能在本只读复核中直接改产品。

## 独立原数据与结算核对

只读打开本轮原 readback-restored-single-a-a-1791911271917-79b4daf7-9a46-44dd-84ff-d94b6f5ea5e1.json：actual exit0/outcome exact-declared-file-bytes-list-and-search；9个原GET全部200，6个content、root和`资料 Mix`的list、current-query分别有自己的requestID，completedAt17:07:54.012Z。B的原 readback-final-baseline-b-b-1791911305640-d8aba361-f8ac-4d94-988d-8cc0cb50f96d.json：actual exit0，同outcome，3个原GET全部200，自己的content/root list/current query，completedAt17:08:26.027Z。这些原checker补文件/成员事实，图片06/07是对应人工显示，不把前轮回执借给本轮。

本轮 root-label-final-shutdown-admission.json 保存唯一 dispatch=true/status200，于17:08:45.4856828Z；其pageClosed字段实际为false，不能把这份receipt本身说成页面已关闭证明。root另外已执行Tab23关闭，本agent没有操作或独立UI观察其关闭时刻。Native/parent的原收尾资格来自独立实际回执，不来自页面状态或无listener猜测：

- root-label-final-launcher-joined.json：actual exit0、stdoutDrained/stderrDrained=true、firstLauncherFailure=null；原terminal reason exited/exitCode0/signal:null，physicalCompletion/outputDrainComplete/requestCleanupComplete全部true，17:08:45.747Z。
- 原Host89620 birthwin32:639275079399432697、Target66112 birthwin32:639275079407266422，发生实例UUID与该原settlement一致；root所持父launcher37130正常join0。
- root-label-final-physical-terminal-and-credential-free.json 17:08:49.5226205Z 的原两birth观察均dead_or_reused，原port已释放；credential/model staging为none，未读取其内容。该文件不制造另一份owner或替代输出交付事实。

首轮 root-label-56aad08f-c05f-48aa-864b-957066ff94ef 的900000ms执行期限到期仍是reason deadline_exceeded/exit1、父78721 join1；其后restored-a requests=[]的失败仍保。新ordinary0仅履约本次剩余普通收尾/原readback，不覆盖或重新解释首轮1、原startup hidden.git工具失败与早期未知Native分支。

## 最终视觉边界

英语root directory refresh failure、原Details打开/真实滚动到response-body和独立恢复后准确成员已有此轮对应图，首轮未取得的这部分已补。首轮16图的中英文Upload plural、中文非空目录、Copy/Move到根、Create dialog与恢复展示仍有各自原发生实例证据，本轮未冒称重新运行它们。

typed-upload根错误(data.targetDir=""且稳定FileUploadInvalidTargetError)仍没有真实图，当前图片05的UnknownError不能替代它；该显示分支仅源码/静态类型review资格。完整body逐字段人工阅读、任意长非空路径、真实POSIX（Portable Operating System Interface，可移植操作系统接口）/external drop、late upload退休、dialog打开后切语言与undefined目标真实UI分支仍按正式规格分别未取，不注入DOM（Document Object Model，文档对象模型）/mock facts补齐。Capsule/Task/Mission/Session全生命周期和旧Aggregate根因不由此目录展示验收排除。

本轮7个实际文件均已本人逐张人工看，未改代码；原回执与图片范围精确分开，交给root归档/最终审查。
