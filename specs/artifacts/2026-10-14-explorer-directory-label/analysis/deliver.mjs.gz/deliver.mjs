import fs from 'node:fs'
import path from 'node:path'
import { spawnSync } from 'node:child_process'

const repo=process.cwd(), scratch=path.join(repo,'.tmp-codex-next-feedback-01a133'), normal={...process.env}
function git(args,env=normal,input){
 const r=spawnSync('git',args,{cwd:repo,env,input,encoding:'utf8',windowsHide:true,maxBuffer:128*1024*1024})
 if(args[0]==='commit')fs.writeFileSync(path.join(scratch,'commit-tool-result.json'),JSON.stringify({args,stdout:r.stdout,stderr:r.stderr,exitCode:r.status,observedAtUtc:new Date().toISOString()},null,2))
 if(r.status!==0)throw Error('git '+args.join(' ')+' failed: '+r.stderr+r.stdout)
 return r.stdout
}
const component='packages/overlay/src/components/FileExplorerPanel.tsx'
const locales=['packages/overlay/src/i18n/en-US.json','packages/overlay/src/i18n/zh-CN.json']
const own=[component,
 'specs/records/2026-10/2026-10-14-explorer-directory-label.md',
 'specs/records/2026-10/2026-10-14-capsule-preparation-authority.md',
 'specs/artifacts/2026-10-14-explorer-directory-label',
 'specs/artifacts/2026-10-14-capsule-preparation-authority',
]
const shared=['specs/README.md','specs/records/2026-10/README.md','specs/artifacts/README.md']
const arch='specs/current/architecture/07-panel.md', history='specs/records/2026-10/2026-10-13-file-search-publication-order.md'
const textAt=file=>fs.readFileSync(path.join(repo,file),'utf8').replaceAll('\r\n','\n')
const archBlock='Empty normalized directory keys display the current-language root-folder label\nin Explorer destination, creation and directory-refresh feedback. Nonempty\ndirectory paths remain exact; a missing target is not a root fact. Only the\ntyped upload-target directory field uses this display projection in errors.\nAPI paths, completed receipts and original Details retain their identities.\n\n'
const archAnchor='One Explorer action outcome retains its actual completed receipts, the failed\n'
const historyAnchor='## 证据后才实施和交付\n\n'
const historyText=textAt(history), histBegin=historyText.indexOf('2026-10-14原归档复核补充：'), histEnd=historyText.indexOf('若B实际复现，root先补实际根因与差异决策',histBegin)
if(histBegin<0||histEnd<0||!textAt(arch).includes(archBlock))throw Error('Exact owned shared blocks missing')
const historyBlock=historyText.slice(histBegin,histEnd)
function blob(file,content,env){const oid=git(['hash-object','-w','--stdin'],env,content).trim();git(['update-index','--add','--cacheinfo','100644,'+oid+','+file],env)}
function insertUnique(text,anchor,block){if(text.includes(block))return text;if(text.split(anchor).length!==2)throw Error('Ambiguous exact anchor');return text.replace(anchor,anchor+block)}
if(process.argv.includes('--prepare')){
 const base=git(['rev-parse','HEAD']).trim(),index=path.join(scratch,'delivery-index-'+Date.now()),env={...normal,GIT_INDEX_FILE:index}
 fs.writeFileSync(path.join(scratch,'real-index-before.diff'),git(['diff','--cached','--binary']))
 fs.writeFileSync(path.join(scratch,'status-before-commit.txt'),git(['status','--short']))
 git(['read-tree',base],env);git(['add','-f','--',...own],env)
 for(const file of locales){
  const line=textAt(file).split('\n').filter(value=>value.includes('"explorer.root_directory":'))
  if(line.length!==1)throw Error('Exactly one current locale key required')
  let text=git(['show',base+':'+file]);if(!text.includes(line[0])){
   if(text.includes('"explorer.root_directory":'))throw Error('Base already has a different root contract')
   const anchor=text.split('\n').filter(value=>value.includes('"explorer.search_placeholder":'))
   if(anchor.length!==1)throw Error('Ambiguous locale anchor')
   text=insertUnique(text,anchor[0]+'\n',line[0]+'\n')
  }
  blob(file,text,env)
 }
 for(const file of shared){
  const lines=textAt(file).split('\n').filter(line=>line.startsWith('- [')&&/2026-10-14-(explorer-directory-label|capsule-preparation-authority)/.test(line))
  if(lines.length!==2)throw Error('Exactly two owned index entries required: '+file)
  let text=git(['show',base+':'+file]);for(const line of lines)if(!text.includes(line))text=text.replace('\n','\n\n'+line+'\n')
  blob(file,text,env)
 }
 let archText=git(['show',base+':'+arch]);if(!archText.includes(archBlock)){if(archText.split(archAnchor).length!==2)throw Error('Ambiguous architecture anchor');archText=archText.replace(archAnchor,archBlock+archAnchor)}
 blob(arch,archText,env)
 blob(history,insertUnique(git(['show',base+':'+history]),historyAnchor,historyBlock),env)
 git(['diff','--cached','--check'],env)
 const files=git(['diff','--cached','--name-only'],env).trim().split('\n')
 if(files.some(file=>!own.some(scope=>file===scope||file.startsWith(scope+'/'))&&!locales.includes(file)&&!shared.includes(file)&&file!==arch&&file!==history))throw Error('Escaped task scope')
 fs.writeFileSync(path.join(scratch,'prepared-index.json'),JSON.stringify({base,index,files},null,2))
 fs.writeFileSync(path.join(scratch,'staged-stat.txt'),git(['diff','--cached','--stat'],env))
 fs.writeFileSync(path.join(scratch,'staged-review.diff'),git(['diff','--cached','--',component,...locales,...shared,arch,history,...own.slice(1,3)],env))
 console.log(JSON.stringify({base,index,files:files.length,preparedOnly:true}));process.exit(0)
}
if(process.argv.includes('--reconcile')){
 const data=JSON.parse(fs.readFileSync(path.join(scratch,'delivery-commit.json'),'utf8'))
 if(git(['rev-parse','HEAD']).trim()!==data.commit)throw Error('HEAD changed; audit before exact real-index reconciliation')
 const patch=git(['diff',data.base,data.commit,'--binary'])
 fs.writeFileSync(path.join(scratch,'exact-owned-index.patch'),patch)
 git(['apply','--cached','--check'],normal,patch);git(['apply','--cached'],normal,patch)
 fs.writeFileSync(path.join(scratch,'real-index-after.diff'),git(['diff','--cached','--binary']))
 console.log(JSON.stringify({commit:data.commit,reconciledOnlyOwnedPatch:true,remainingStaged:git(['diff','--cached','--name-only']).trim()}));process.exit(0)
}
if(!process.argv.includes('--commit'))throw Error('Explicit prepare, commit or reconcile mode required')
const prepared=JSON.parse(fs.readFileSync(path.join(scratch,'prepared-index.json'),'utf8')),env={...normal,GIT_INDEX_FILE:prepared.index}
if(git(['rev-parse','HEAD']).trim()!==prepared.base)throw Error('HEAD changed; prepare fresh before commit')
const result=git(['commit','-m','fix(explorer): clarify root directory destinations in the current language'],env)
const match=result.match(/^\[.+ ([a-f0-9]+)\] /m);if(!match)throw Error('Cannot identify successful commit')
const commit=git(['rev-parse',match[1]]).trim()
fs.writeFileSync(path.join(scratch,'delivery-commit.json'),JSON.stringify({base:prepared.base,commit,files:prepared.files,result,observedAtUtc:new Date().toISOString()},null,2))
console.log(JSON.stringify({commit,files:prepared.files.length,reconciliationPending:true}))
