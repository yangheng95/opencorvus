# Explorer 根目录展示：精确实现与自审

已完整重读 specs/records/2026-10/2026-10-14-explorer-directory-label.md Recall、范围和验收边界，按 root 精确授权实施。没有再次委托、Git 暂存/提交/push、产品外扩改或 spec/index/架构编辑，没有启动服务/模型或运行 UI（User Interface，用户界面）自动测试。

## 修改前差异保存与实际范围

开始 git status 已读。preexisting-three-files.diff 保存并人工审阅三个授权文件的原完整差异：FileExplorerPanel 原差异为空；en-US/zh-CN 各有 foreign Provider 删除 provider.form.error.models_required 和修改 provider.form.models_hint。它们保持原样，未重排 JSON、复写 catalog、修改 Provider 文案或进行其它清理。preexisting-status.txt 保存当时其它 owner 资料；结束 implementation-final-status.txt 保留当前工作区状态。

本 agent 仅修改：

- packages/overlay/src/components/FileExplorerPanel.tsx：15行新增/7行删除。
- packages/overlay/src/i18n/en-US.json：只新增一个 explorer.root_directory = Root folder。
- packages/overlay/src/i18n/zh-CN.json：只新增同一个 explorer.root_directory = 根目录。

after-three-files.diff 保存当前完整三文件差异，包含上述已明确排除的 foreign Provider hunks。不能把 locale 整份当前 diff 都当作本 agent 新改动；root 精确提交时须依各 owner 的交付资格处理。

## 单一显示投影与六个目录角色

组件:200–202 一个私有 explorerDirectoryDisplayPath(path:string|undefined)，仅 path === "" 时调用现有当前语言 t("explorer.root_directory")，否则返回原输入，包括undefined。它不trim、lowercase、normalize、realpath或改文件身份，不把未提供目标伪作根；也不保存翻译后字符串或添加locale订阅/通知/state。

既有五个目录展示全部复用这一投影：refreshReceiptMessage:273 的明确directory read path；feedbackMessage:294–297 的多项Copy、多项Move和Upload目标；createEntry:1161 的对话框目标。单项Copy/Move、创建成功、rename/delete、member/post-open、query和真实回执path照旧。

fileErrorSummary:210–215仍由原generic summary做唯一 typeof value === "string" 验证。只有既有稳定 targetDir 字段通过投影；当前唯一传该字段的稳定分支仍是 FileUploadInvalidTargetError:224–225。其它path/name原值照旧，malformed metadata仍走原operation summary，没有复制错误识别、猜英文消息、添加error兜底或重写原cause。共享formatErrorDetails的输入与Details owner没有任何修改。

root label表示当前Files scope.directory根，不宣称Git/Project主工作树根，不复用绝对Project命名primitive。原API targetDir、outcome.completed/target、upload/mutation token、authority/selectionEpoch、producer、selector、目录刷新/搜索发布、editor协调与文件系统不动。render路径仍用当前t/tc/locale数字，语言切换只改变原事实的投影；create dialog保原打开时语言快照合同，未扩共享dialog逻辑。

## 原静态输入与输出

typecheck.log.input.json：cwd packages/overlay，固定Bun1.4 executable为 D:/myhexin-local/opencorvus/.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64/bun.exe，其父路径 prepend PATH；实际命令 bun run typecheck→当前package script tsc --noEmit。typecheck.log 原stdout为 `$ tsc --noEmit`，实际 exit0见typecheck.log.exit.json。没有运行test:unit、i18n测试、UI源码文案assert或DOM（Document Object Model，文档对象模型）/浏览器测试。

diff-check.log.input.json：实际 git diff --check -- 三个授权文件，原stdout为空、实际exit0，元数据保原执行时间。该检查只验证diff格式，不是源码摘要或功能门槛。

## 完整自审与尚未取得资格

已读修改前/后完整差异并逐调用自审：唯一helper为精确空串判断，undefined保真；五目录展示与一个typed目录错误都覆盖，其它身份字段与原Details保持。两语言只有本次单key，Provider foreign差异完整保留。没有state/API/producer/scopes/CSS/backend/监督器/helper协议或测试修改。

真实桌面页面、新私有构建、同backend两个实际Project与File API（Application Programming Interface，应用程序接口）fullbytes checker、root/subdirectory/单复数/Copy/Move/create dialog/原刷新故障/双语/旧scope退休矩阵由 root 负责；本 agent 未启动新页面或服务，没有后态截图，因此不把typecheck/diff检查冒称视觉或端到端完成。typed-upload根错误、外部drop、POSIX（Portable Operating System Interface，可移植操作系统接口）实机、late upload窗口与打开dialog后切语言保持正式spec既有资格边界。当前三个产品文件已ready，等待root真实验收及最终review。
