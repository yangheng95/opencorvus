# 独立最终轮次：准备完成，尚未执行

2026-10-14 Asia/Shanghai。已重读正式 UI 规格 `specs/records/2026-10/2026-10-14-explorer-directory-label.md` 的新末段，当前只做其授权的工具准备。没有产品、测试、spec、共享索引或 Git 修改，没有委托，没有启动服务、运行 fixture、发 API（Application Programming Interface，应用程序接口）请求或操作 UI（User Interface，用户界面）。

## 第一轮事实保持独立

Root 已记录原 16 张人工检查图片、A14+B3 的真实 GET 读回成功、Copy/Move 原完整字节和 Move 源 dev/inode/birth 正确。随后原 900000ms 执行期限到达，Native `deadline_exceeded`/exit1、parent78721 join1。补充 restored-a checker 实际 exit1 且 requests=[]；后续只读收尾实际0、dispatch=false、Host/Target 原 birth 已 dead_or_reused、port 释放。不能把这些改写成普通 shutdown0，也不能重开原实例。

当前工具修改之前，完整副本保存于 `history-first-occurrence/`：

- 当前 8 个执行工具，加共用 `fixture-support.mjs` 和 `check-tool-syntax.ps1`，全部保留原版本；包含 Root 已修正的 `Get-Item -Force`。
- 原准备说明、最初隐藏 `.git` 失败前脚本、准备/启动/注册/故障/读回原日志。
- 原 `root-label/` 下全部 40 个证据文件（含原 JPEG、输入、真实 IDs、HTTP 全字节及首错）。
- 原 run 的精确 `prepared-fixture.json`、`launch-owner.json`、`startup.json`、Native ready/settled receipt；不读取整个 runtime，不复制 auth/models/provider。
- `history-manifest.json` 记录来源和副本，共 27 个单独工具/输入/receipt 文件，另有原证据树。原文件也留在原处。

这些是只读历史证据，不是 fallback，不是可执行的旧实例恢复入口。旧端口18453、旧run和旧Project/Chat不再接受本工具新动作。

## 当前唯一运行输入

- Run：`C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/explorer-directory-label-final-01a133`。
- Port：`18454`；prefix：`root-label-final`；证据：本 scratch 下的 `root-label-final/`。
- 私有 pair 保持原值：`D:/myhexin-local/opencorvus/.tmp-codex-next-feedback-01a133/ui-bundle/bin/bun.exe` 和同级 `ui/`。
- 同一 source CLI（Command-Line Interface，命令行接口）和当前冻结的产品 UI 源；fixture schema、全部文件名/原190 bytes、A/B两独立Git、Unicode目录和预声明内容不变。
- 新 run 仍需 exclusive mkdir，拒绝存在即复用。准备后会形成新 fixture UUID，正常注册后才取得新 Project/Chat IDs；当前这些值尚未产生。
- 原 passive `native-observer` 及其 `runtime` 目录仅由 `assertDirectDirectory` 验 lstat/realpath 为直接物理目录后继续供生产 occurrence 只读 observer 使用。这里不删除文件、不启动或接管旧 service/Task，也不拿此目录代替新 runtime owner。

精确代码修改只有四个文件：

| 文件 | 当前变化 |
| --- | --- |
| `fixture-support.mjs` | 新 run、evidence、port、prefix 常量；fixture schema/资格/query/字节/事实读取不变 |
| `launch-ui.ps1` | 同一新 namespace/port/prefix 的默认值和强校验；Root 修复的 `Get-Item -Force` 保留；私有pair、原900000/ready45秒/原输出和父join不变 |
| `shutdown.ps1` | 同一新 namespace/port/prefix 的强校验；原一次shutdown、credential-free receipt、原birth/port/native/pendingjoin不变 |
| `prepare-ui.mjs` | 原两次 passive observer mkdir 改为两次物理目录验证；新run与两项目数据仍全新创建 |

`native-host.ts`、`owned-launch-functions.ps1`、register、readback、fault、syntax runner 全部不变。差异保存在 `final-tool-diffs/`；每项 stdout及 diff exit 记录在 `results.json`。Host/functions 等六文件 diff exit0；上述四个是限定差异。差异检查不证明新轮次已经运行成功。

## 本轮只做剩余验收

1. Root 审阅后 prepare 新 fixture，首次 launch 新服务，正常注册两 Project/空 Chat；原 HTTP 全字节和真实 IDs 写入新 evidence。
2. A/B各自初始 Files/query 基线；A根真实英文 single picker 使用 `inputs/root-label-upload-one.txt`。
3. A根原 `.ignore` 空目录故障：单独授权 create，真实 Refresh500/原Details及截图，单独 restore 后真实 Refresh恢复，并在原预算内取得 A 读回。
4. 及时普通 shutdown200，等待原 Native physical/output/request、Host/Target birth、port 和原 parent 的完整0回执。随后再做归档和交付分析，不把预算花在服务不需要参与的工作上。

不重跑已由第一轮证明的 Copy/Move、中文或多项上传。原fixture仍保留那些输入和候选 map，**本最终轮次不要采用旧全流程 `fixture.finalPaths.a` 作为当前期望**；A只发生一次根single upload时，明确期望以下6文件，子目录四个源均仍在原处：

```json
[
  "root-label-original.txt",
  "资料 Mix/root-label-copy-a.txt",
  "资料 Mix/root-label-copy-b.txt",
  "资料 Mix/root-label-move-a.txt",
  "资料 Mix/root-label-move-b.txt",
  "root-label-upload-one.txt"
]
```

初始A使用前五个；B始终为 `["root-label-project-b.txt"]`。readback依然只检查预声明原 bytes、物理身份、实际 File content/list/search，不读取 UI、不断言文案、不合成错误。

故障只作用于新A根 `.ignore`：原 ENOENT 后 mkdir；restore凭原 created receipt 的 dev/inode/birth和实际空目录非递归rmdir。不会移动 Project、删除 root 或强求 typed 根 upload error。历史原故障已经 restore 的事实保留。

## 已完成语法检查与真实预算

最终纯syntax实际10项全部exit0，runner exit0：

`tool-validation/syntax-20261013T165446530/results.json`

每项原 stdout/stderr 和独立 `.exit.json` 同目录；Node v25.7.0，Bun1.4.0。仅 Node `--check`、Bun Transpiler 和 PowerShell AST（Abstract Syntax Tree，抽象语法树）解析，没有执行任何准备工具入口。

保留成熟预算：Native execution是将来首次启动时的实际 `now+900000ms` 输入；startup观察45秒；shutdown观察45秒、其它caller join75秒；API每请求20000ms且不超过剩余原Native期限。**当前PS launcher没有外部120000ms inactivity driver，不能虚报已经运行该driver。**工具的yield/观察窗口结束不能更改已传入执行期限、kill或重开实例。若再次达到原执行deadline，要完整保其真实结果，不能改为普通0。

## Root另授后的显式命令

以下均尚未执行，从仓库根运行并保完整原输出/退出码：

```powershell
$env:PATH='D:/myhexin-local/opencorvus/.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64;'+$env:PATH
node .tmp-codex-next-feedback-01a133/prepare-ui.mjs prepare
```

Root核实际准备/原manifest后，启动原阻塞launcher并保留同一个父工具session；ready之后在另一调用正常注册：

```powershell
& ./.tmp-codex-next-feedback-01a133/launch-ui.ps1
# 上条保持原父join；下条在另一个已经取得ready的调用中执行。
node .tmp-codex-next-feedback-01a133/register-projects.mjs register
```

真实桌面动作之后，例示新A单项上传及故障restore后的完整期望：

```powershell
$expectedA=@('root-label-original.txt','资料 Mix/root-label-copy-a.txt','资料 Mix/root-label-copy-b.txt','资料 Mix/root-label-move-a.txt','资料 Mix/root-label-move-b.txt','root-label-upload-one.txt')|ConvertTo-Json -Compress
node .tmp-codex-next-feedback-01a133/ui-readback.mjs read restored-single-a a $expectedA
node .tmp-codex-next-feedback-01a133/ui-readback.mjs read baseline-b b '["root-label-project-b.txt"]'
```

故障 create/restore 各自需Root审阅后的动作授权，不运行原服务命令：

```powershell
node .tmp-codex-next-feedback-01a133/root-ignore-fault.mjs create
# 实际页面 Refresh/Details截图后：
node .tmp-codex-next-feedback-01a133/root-ignore-fault.mjs restore
# 恢复实页并读回后，在原执行期限前：
& ./.tmp-codex-next-feedback-01a133/shutdown.ps1 -RunRoot 'C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/explorer-directory-label-final-01a133' -EvidenceRoot 'D:/myhexin-local/opencorvus/.tmp-codex-next-feedback-01a133/root-label-final' -EvidencePrefix root-label-final -Reason root-manual
```

普通shutdown与原父join0在当前仍未取得。没有 auth/models/provider 读写/删除、模型或SQL注入；没有UI自动测试。当前原第一轮证据和限定新工具可供Root最终逐个复核。
