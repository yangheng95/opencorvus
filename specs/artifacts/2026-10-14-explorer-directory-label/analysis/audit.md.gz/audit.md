# Explorer 根目录目的地显示：只读调查

## Recall 与资格

用户要求持续按批次并行调查 UI（User Interface，用户界面）与功能：先根因/影响分析并落盘，再实施、真实桌面页面交互与截图人工复核、聚焦正向功能检查、必要且已授权的模型端到端验收，精确提交/上游同步/正常推送后继续。Root 本次限定只读调查上一批真实截图的上传目的地可理解性，不是已决定必须修改。禁止再次委托、改产品/测试/spec/共享索引、启动服务或模型、操作用户窗口、运行 UI 自动化。只新增本 owned scratch 报告；root 负责正式方案、实现准入和交付。

开始 git status --short 已读，现有多个 owner 的 config/provider/agent/delegate、locale、ProviderPanel、规格/索引和 untracked 改动均保留。前一批 c4b5ad38 的 pre-push 由 root 持原 session 执行，本 agent 未干预。没有 stage/commit/push，没有新 branch/worktree。

已读相关当前架构07-panel 的文件路径/实体根/反馈/current-language/scope/tab-owner 合同（约487–565、970–1017），07-panel-reactivity 的现行 owner 原则，records 的 file-search-publication-order Recall/真实 after-ui 轮次、file-operation-outcomes Recall/唯一回执合同、file-metadata-feedback Recall/typed facts 与语言修复、explorer-copy-convergence Recall/合法空根准入与单文件完整目标区别，以及原 file-alias/source 身份资料。读了 FileExplorerPanel 反馈 producer/renderer、全部 create/copy/move/delete/refresh/upload 消费者、file-workbench、server-path、project-directory 两不同模块、workspace、i18n t/tc/fillTemplate、两 locale catalog、File.upload/对应 HTTP（Hypertext Transfer Protocol，超文本传输协议）路由、相关纯服务测试及 catalog/loading 检查。

全仓同语义搜索定位到唯一 FileExplorerPanel 调用 main.tsx:2785、唯一 uploadDroppedFiles producer、五处 `|| "."` 目录显示、对应 flat i18n keys 与历史 Git blame/show。没有找到 `explorer.root`/root_directory 或既有规范项目相对空根的显示 primitive。第一次宽泛 specs artifact 内容搜索命中体积极大的归档单行并被工具截断，该输出不用于穷举结论；后续以当前 src、架构/records 明确路径及文件名/有限列宽检索重核。找不到的猜测文件路径不算读过；实际 i18n 文件为 en-US.json/zh-CN.json，workbench 位于 services，目录 label 位于 utils/project-directory.ts。

## 人工可观察现象

已通过 view_image 实际呈现并人工查看两张既有1280×720原 PNG：

- specs/artifacts/2026-10-13-file-search-publication-order/actual/after-ui/ui/06-uploaded-query-zh-clean.png：绿色成功反馈显示“已上传 1 个文件到 .”，查询 publication-ui- 下有两个原真实文件名。
- 同目录02-uploaded-query.png：英文成功反馈显示“Uploaded 1 file to .”，同一真实成员集合。

两者的目的地字符确实是技术相对路径 `.`，不是完全漏掉 {{target}}、翻译缺 key 或 API（Application Programming Interface，应用程序接口）丢目标。句末单独点号容易看成标点，因此这是根目录目的地**可理解性候选**，不是上传发布/文件身份/权限/刷新故障。新页面尚未启动，也没有新的后态图；本报告不能宣称改进已经交付。

原 after-ui 资料只读解压核对：prepared-fixture root directory 是 C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/file-search-publication-ui-after-01a133/project；ui-readback-1791904836759.json.gz 的4个真实 GET 均200，其中 list-root 的 path 为空，Nodes 分别为 publication-ui-original.txt、publication-ui-uploaded.txt，两绝对路径都在这个 root。实际上传目标大小18bytes、inode9851624189024740，原输入全 bytes 与目标一致，独立读回 outcome准确/exit0。原轮次已普通shutdown并完整收尾；不重新启动它，也不以这些成功资料倒填其它并发/Native/Capsule未验资格。

## 触发、唯一数据流与显示根因

1. main.tsx:2785 将 activeDirectory accessor 交给 FileExplorerPanel。workspace.ts:768 只是 activeProjectDirectory()；services/project-directory.ts:6–18 分别从已选 Task owning directory、已选 Session.directory 或当前 workspace settings 取得 scope.directory。它是当前 Files 的工作目录，**不保证等于 Git worktree 根或 Project 主工作树字段**。
2. 当前 Files 背景菜单 FileExplorerPanel:1670–1688 调用 openUploadPicker("")/createEntry(type, "")；选中文件时 contextTargetDirectory(:835)取其父目录，顶层文件父目录也为""。真实 directory 行则返回原 path。拖放目标也走相同 normalizeExplorerPath。
3. normalizeExplorerPath(:362)唯一调用 normalizeProjectFilePath(path,directory())；server-path.ts:52–70 按服务器 Windows/POSIX 语法词法归约。规范空key表示**当前 scope.directory 根**；`.`、folder/.. 等合法原始目录输入归约为空，不是非法空输入。文件名大小写、空白与 POSIX 反斜杠保持真实身份，显示改进不能再 trim、lowercase、realpath 或重新归约这些值。
4. picker 保存原 targetDir 与原 scope；uploadFiles(:1550–1567)保 targetDir 为""，创建唯一 ExplorerOutcome {operation:"upload",completed:[],target:targetDir,...}。uploadDroppedFiles services/file-workbench.ts:396–414 将原 targetDir 直接发 POST /file/upload?directory=<scope.directory>，仅真实200后返回 FileUploadResult[] 和 bump revision。
5. File.upload src/file/index.ts:1514–1517 将空 targetDir 解释为 Instance.directory，否则 path.join(Instance.directory,targetDir)。当前 HTTP 路由 file.ts:322–341 原样 validator→File.upload→200。上传结果 path 为真实文件身份，不含本地化根标签。
6. upload finally 仅在原 upload token 和 ownsExplorerOperation(scope)有效时 publish 原 outcome；completed 只来自真实回执，refresh 保原读资格。feedbackMessage(:269–289)渲染时 tc("explorer.upload_success",completed,{count:当前语言数值,target:feedback.target || "."})，因此规范空目录被**展示**成"."。t/tc/fillTemplate 原样插入这个点；两语言 plural catalog 均包含 {{target}}。

没有发现第二个上传成功提示 producer、第二通知缓存、旧字符串状态或翻译副本。display 操作不该写回 target、scope、API payload、receipt path、editor target 或文件系统。

## 全部同义影响与不应机械替换的身份

| 消费者/精确当前位置 | 目录事实 | 当前显示/受影响资格 |
| --- | --- | --- |
|Upload成功 feedbackMessage:289|uploadOutcome.target，明确字符串，可为""|所有正向完成数量都显示 destination，根为"."；中/英文均有真实图|
|批量Copy :286|copySelectionsToDirectory :1344 在循环前赋 targetDir|completed>1 时显示 target；completed=1 使用实际成功 path，保持文件身份|
|批量Move :287|moveSelectionsToDirectory :912 在循环前赋 targetDir|同上，拖放也复用；部分完成仍按真实 completed 数量，不称全批完成|
|新建对话框 :1153|normalizeExplorerPath 后 targetDir|根正文当前“在 . 中新建”/“Create in .”；创建成功仍展示真实 receipt.path|
|目录刷新回执 :265|FileRefreshTarget.kind=directory 的明确 path|string空根显示“文件夹 .：…”/“Folder .: …”；只显示 failed/retired 独立回执|
|typed FileUploadInvalidTargetError :216–217|已验证 data.targetDir 字符串，明确是目录字段|空根目前 t(error.invalid_upload_target,{path:""}) 省去目的地；属于同一目录显示角色，可复用同一投影，但此错误根场景本次未真实复现|

共五处现有点号显示，另一个明确 typed-directory error 分支可同作用域覆盖。将最后一行纳入同一小 UI 显示作用域是合理的：它已经通过稳定错误类型与字段说明这是目录，不依靠英文错误关键词猜根。这里只改摘要的显示变量；formatErrorDetails 保原 data.targetDir、方法/status/requestID/原诊断。不得因此改 backend stat.catch、权限或错误产生合同，那些并非当前截图所证的问题。

create-file/create-directory/rename、单项 copy/move/delete、批量 delete 数量、member failure、post-open 与 FileConflict/NotFound/InvalidPath/UploadInvalidName/Content 的 path/name 都是实际 entry 身份或通用诊断，不统一替换成根标签。expandedDirectoryFailures(:688)明确只展示非空真实 directory path，因此当前 title directory_load_failed 不会收到根空key；root load 使用既有 generic load_failed。search 则保原 query。全仓未发现其它组件消费上述五展示 keys。

ExplorerOutcome.target 当前类型可选；upload/multi-copy/multi-move 的实际 producer 都会赋字符串，单项或其它 operation 通常不需要它。**undefined 是未提供目标，不能等同规范根""**。候选投影须只判 `path === ""`，非空路径逐字符返回；未提供值保持未提供，不再通过 `||`、trim 或默认根来制造目的地事实。本轮没有真实异常 target=undefined 的页面证据，不为了一个显示改进扩建新的 Outcome state/副本缓存或 throw/retry gate。

## 既有目录 label 与旧路径为何未治

utils/project-directory.ts:38 的 projectDirectoryLabel 输入是完整目录，输出 basename/压缩 parent，另能给 implicit Project 使用专用显示名；projectDisplayName 还可取用户自定义 Project 名。它服务 Conversation、WorkLedger、ProjectLedgerGroup、Mission/Mailbox 和设置中的**Project 命名**。将规范相对空key直接传入只能得到 unknownName；将当前绝对目录塞给它会引入 Project 名/目录名与根概念混淆，且原实现统一反斜杠解释与压缩路径，并非本任务的目录相对 identity 展示合同。当前根显示无需 Project metadata lookup、custom name、更名订阅或新的 scope state；不能生搬它作为空key格式化 primitive。

Git show基线65d0bfc98已含 upload/multi-copy/multi-move/create_in 的 targetDir || "."。2a47af74b 修为 typed facts 与 render-time t/tc，仍保留点号（当时还独立 upload-reload-failed branch）；66b470b3c 统一 actual outcome/refresh receipts，新增目录刷新回执也用了"."；83ee0d843 只修 retained owner 与上传 active search refresh。a0c45a9af 的 Recall 明确纠正原始空输入与合法空根准入，**不增加正文/控件**；2a47 的 Recall 处理语言冻结/原 cause，不选择根目录文案。因此这些旧修复完成其合同后仍展示技术点号，并非前几个数据修复未根治上传。本轮没有找到坚持必须用点号的产品决策，亦不能声称历史作者已决定必须改为新label。

07-panel:530–551 要求只保原facts、当前语言render/count、稳定Details owner；:554–565 保 tool切换/Dock隐藏的同Explorer owner，明确Close/disposed/directory/authority/selectionEpoch退休。新增label若成立应在现有 render 调用 t 取得，语言切换不重发请求、不改 completed/target/refresh/errors、不重建 For issue objects 或 Details owner。

create dialog目前 showAppDialog 接收打开时字符串快照，该共享全仓协议已在 file-metadata-feedback 记录为独立未验边界。此候选只保证打开时使用当前语言；不能顺便声称已解决对话框打开后切语言的所有36处调用。根是当前 Explorer scope.directory 根，故候选文案建议“根目录”/“Root folder”，**不宣称 Git/Project 主工作树根，也不翻译真实 basename**。

## 候选最小唯一实现（未实施）

若 root 判断值得交付：FileExplorerPanel 内一个 render-only directory-display 投影，规范空串→t("explorer.root_directory")，其它原值原样；en-US/zh-CN 同一个新 key 分别“Root folder”/“根目录”。用这个唯一投影替换上述五点号展示，并仅在 FileUploadInvalidTargetError 已知字符串 targetDir 分支同样投影；其它 path/name 不变。没有第二 uploader、fallback root、翻译后的 target state、locale effect 或 Project label alias。

这可以只触组件与两locale的本次精确 key/调用，现两locale存在另一 Provider owner 的foreign修改，实施前必须保存审阅并按exact patch保留。没有必要改 file-workbench/server-path/backend/public SDK（Software Development Kit，软件开发工具包）/route、路径准入、物理保护或权限。因此功能测试不需要为这个纯UI文案改进新建 service 测试，更不能创建rendered DOM（Document Object Model，文档对象模型）、源码文案、截图或浏览器fixture断言。现check:i18n/type/build只提供静态资格，不替代后述真实视觉。

## 真实页面正向验收输入/输出（提案，未运行）

使用全新 owned source CLI 开发 /ui 与正式私有 UI 构建，一台后端下两个真实独立 Git/Project scopes。不得重开原已退出的 after-ui 实例、单独Vite、注入DOM/DataTransfer/隐藏函数，或用两个backend伪称同服务隔离。保原 Native owner/PID（Process Identifier，进程标识符）/birth、真实execution deadline、请求/两output drain/owner退休与一次正常shutdown，另获 root 运行授权后才开始。

| 实际输入 | 本候选预期可见输出与独立事实 |
| --- | --- |
|A scope Files 背景→真实picker上传1个tiny文件，目标空根|中文“已上传 1 个文件到 根目录”、英文“Uploaded 1 file to Root folder”；原目标FileUploadResult.path为原basename，GET内容/fullbytes/rootNodes正确|
|同scope 真实picker上传2文件到根|复数/当前语言数量正确，目的地仍根label；真实2回执/2文件字节，不复用first成功回执|
|展开真实子目录 `资料 Mix`→picker上传|目的地逐字 `资料 Mix`；切英文也保这个真实名称，文件位于该目录，根label不混入子路径|
|多选两个子目录entry，Copy/Move目录表单输入`.`或`folder/..`|合法根准入后显示真实completed数量到根label，实际 root目标Nodes/fullbytes与path正确；单项结果仍原basename/path|
|背景新建file/folder打开真实对话框|打开时当前语言“在 根目录 中新建”/“Create in Root folder”；创建回执显示真实用户文件名，取消只结束对话框|
|本人可审查scope规则读错误→实际Refresh|根 read receipt 明确显示“文件夹 根目录：…”/“Folder Root folder: …”，原read error Details完整；修回规则后正常Refresh成功。只允许本人fixture资源，不能改用户项目文件来造错误|
|如需纳入typed upload root error，使用明确审查的本人fixture物理条件|实际稳定 FileUploadInvalidTargetError/data.targetDir="" 才显示根label，Details原字段不改；若无法安全取得真实资格则记录该error分支仅代码审查，不用mock冒充视觉|
|在已显示成功/partial/read-error反馈时实际Settings切语言，再返回Files|同一facts重新显示当前locale根label和数量，Details展开owner稳定；query与真实文件名保留，没有重复上传/复制的事实|
|同backend从A切到B不同Project/Session，再回来|B显示其自身反馈/空状态；旧A操作不能在B publish，原scope/authority/selectEpoch保护不变。工具切换/Dock隐藏可保持A同owner反馈，明确关闭Files按原契约退休|

逐张人工查看当前目标region绑定的前/后图、目的地可理解性、路径不截成模糊点号、窄Explorer下长子路径换行/滚动与Details可用；不能以DOM文本、locale catalog、typecheck、console clean或API成功替代截图。外部drag尚无本环境能力资格，不伪造drop或声称其已实页验完。对dialog开着切语言、平台POSIX真实不同语法、多Project late upload结算若未实际取得原窗口，分别标未知。

## UI 自动化检索与结论限度

本范围没有运行任何测试。对现overlay/test检索 FileExplorerPanel/file-explorer、Playwright、testing-library、jsdom/happy-dom、render、DOM/page操作和component source读取，未定位到与该Explorer目录显示有关的 UI 自动化测试。i18n-catalog-contract 是数据placeholder mismatch→typed error，i18n-loading 是locale transport/parse/resource data合同；file-workbench-{mutation,refresh,revision} 是非DOM服务/原receipt合同。fixtures/i18n.ts 是这些纯数据/服务catalog注入支持，不是只服务UI自动分支，不能无证据删除。类型-only InteractionCard import和 vega-embed-policy纯数据policy import不构成component渲染。一般名称snapshot在这些检索结果中是业务事实snapshot，不是视觉/DOM snapshot。

若后续精确实现检索到产品UI源码文案、render/DOM或浏览器fixture测试，必须将实际路径和仅服务它的support报告root删除；不能因为没有发现当前Explorer测试而宣称全仓所有UI自动化均已不存在。

已证：原上传根事实正确，两语言真实截图显示技术点号，五展示与一个typed目录角色受同projection影响，原scope/语言/路径合同和历史来源已审。未证：用户对技术点号是否不可接受的量化影响、所有其它真实root/子目录/partial/error/late-scope/UI语言矩阵及新label视觉，均尚未运行。本报告是可审查改进候选，不是数据bug修复或已经交付。
