import fs from 'node:fs'
import {gzipSync} from 'node:zlib'
import {execFileSync} from 'node:child_process'
const root='.tmp-codex-network-feedback-01a133',prior='.tmp-codex-network-draft-01a133',base='.tmp-codex-palette-item-identity-01a133',artifact='specs/artifacts/2026-10-14-network-feedback-locale'
fs.mkdirSync(root,{recursive:true});fs.mkdirSync(artifact+'/screenshots',{recursive:true});fs.mkdirSync(artifact+'/previous-delivery',{recursive:true})
for(const name of ['runtime.ts','launch.ps1','privacy.ts','run.mjs'])fs.writeFileSync(root+'/'+name,fs.readFileSync(base+'/'+name,'utf8').replaceAll(base,root).replaceAll('palette item identity','network feedback locale').replaceAll('18666','18678').replaceAll('18667','18679').replaceAll('18668','18680').replaceAll('18669','18681'))
for(const name of ['commit-final.log','commit-final.exit','commit-final-created.json','commit-final-receipt.json','pending-final-review.json','push-final.log','push-final.exit','push-final-receipt.json','push-final.mjs','fetch-current.log','fetch-current.exit','merge-current.log','merge-current.exit','fetch-final.log','fetch-final.exit','exact-module.log','exact-module.exit','exact-release.log','exact-release.exit','reconcile-check.log','reconcile-check.exit'])fs.writeFileSync(artifact+'/previous-delivery/'+name+'.gz',gzipSync(fs.readFileSync(prior+'/'+name)))
const head=execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim()
for(const file of ['packages/overlay/src/components/settings/NetworkPanel.tsx','packages/overlay/src/i18n/en-US.json','packages/overlay/src/i18n/zh-CN.json'])fs.writeFileSync(root+'/'+file.split('/').at(-1)+'.before',execFileSync('git',['show',head+':'+file]))
fs.writeFileSync(root+'/baseline.json',JSON.stringify({head,at:new Date().toISOString()},null,2)+'\n')
fs.writeFileSync(artifact+'/previous-delivery/README.md','# 第25批真实交付\n\nc6c2bcafb正常commit/push0，127范围路径、产品仅NetworkPanel；原完整hook通过，真实fresh远端与own祖先确认。15原图/15真实CONNECT/7正式HTTP原body和两运行收尾的资格保持，不当本批验收。\n')
console.log(JSON.stringify({root,head,before:[18678,18679],after:[18680,18681]}))
