import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import {gzipSync} from 'node:zlib'
import {execFileSync} from 'node:child_process'
const scratch='.tmp-codex-network-feedback-01a133',artifact='specs/artifacts/2026-10-14-network-feedback-locale',files=[],runs=[]
const gz=(from,to)=>{const bytes=fs.readFileSync(from);fs.mkdirSync(path.dirname(to),{recursive:true});fs.writeFileSync(to,gzipSync(bytes));files.push({source:from,saved:to.slice(artifact.length+1),originalBytes:bytes.length})}
for(const stage of ['before','after']){
 const root=`${scratch}/${stage}`,out=`${artifact}/runs/${stage}`,read=name=>JSON.parse(fs.readFileSync(root+'/'+name,'utf8')),ready=read('ready.json'),owner=read('owner.json'),cleanup=read('physical-pair-cleanup.json'),terminal=read('terminal.json')
 assert.equal(ready.pid,owner.pid);assert.equal(cleanup.pid,owner.pid);assert.equal(cleanup.actualExit,0);assert.equal(cleanup.listeners,0)
 assert.deepEqual(cleanup.pair.map(({name,removed})=>({name,removed})),[{name:'auth.json',removed:true},{name:'models.json',removed:true}]);assert.equal(terminal.normalRuntimeSettlement,true)
 for(const name of fs.readdirSync(root))if(name.endsWith('.json')&&name!=='privacy-ready.json')gz(root+'/'+name,out+'/'+name+'.gz')
 for(const name of fs.readdirSync(root+'/redacted-logs'))gz(root+'/redacted-logs/'+name,out+'/logs/'+name+'.gz')
 runs.push({stage,pid:ready.pid,occurrence:ready.occurrence,port:ready.port,participantPort:ready.participantPort,uiDirectory:ready.uiDirectory,physicalExit:cleanup.actualExit,inferenceRequests:terminal.requests,privacy:read('privacy-qualified.json').files})
}
const passed=['before-parent','privacy-before','after-parent','privacy-after','snapshot-before','snapshot-after-baseline','snapshot-after-saved','snapshot-after-reopened','snapshot-after-deleted','snapshot-after-saved-zh','snapshot-after-deleted-zh','overlay-typecheck','ui-build','i18n-current','docs-current','architecture-current']
for(const name of ['docs-final','architecture-final'])if(fs.existsSync(`${scratch}/${name}.exit`))passed.push(name)
for(const name of passed)assert.equal(fs.readFileSync(`${scratch}/${name}.exit`,'utf8').trim(),'0',name+' original actual exit')
for(const name of passed)for(const ext of ['log','exit'])gz(`${scratch}/${name}.${ext}`,`${artifact}/checks/${name}.${ext}.gz`)
for(const name of ['setup.mjs','runtime.ts','launch.ps1','privacy.ts','run.mjs','snapshot.mjs','NetworkPanel.tsx.before','en-US.json.before','zh-CN.json.before','baseline.json','prepare-git.mjs','stage-final.mjs','commit-final.mjs','shared-final.json','archive.mjs'])gz(`${scratch}/${name}`,`${artifact}/inputs/${name}.gz`)
const selections=[]
for(const stage of ['before','after'])for(const name of fs.readdirSync(`${scratch}/${stage}`).filter(n=>n.startsWith('snapshot-')&&n.endsWith('.json'))){const value=JSON.parse(fs.readFileSync(`${scratch}/${stage}/${name}`,'utf8'));assert.equal(value.status,200);selections.push({stage,name,proxy:value.proxy,originalResponseBytes:value.originalResponseBytes,selection:value.selection})}
assert.equal(selections.length,7)
fs.writeFileSync(artifact+'/manifest.json',JSON.stringify({capturedAt:new Date().toISOString(),purpose:'Lossless original evidence and exact resource identity, not a mutable-source checksum or functional hash gate.',runs,retainedHTTPSelections:selections,limits:['Seven GET records retain only actual network.proxy URL/purpose booleans, status and original body length; full config bodies are intentionally not retained.','Four manual UI PATCH response bodies are not separately retained.','No true backend-throw Details or committed-reconcile409 visual qualification.'],files},null,2)+'\n')
fs.writeFileSync(artifact+'/README.md',`# 第26批：网络设置反馈的当前语言

对应[Recall、实施前分析与实际资格](../../records/2026-10/2026-10-14-network-feedback-locale.md)。Root独立实施并逐张查看16原PNG，没有子agent、聊天消息或UI自动化。

- [screenshots](screenshots/README.md)：01英文错误、02切中文仍旧英文、03新中文错误、04切英文仍旧中文；05–07最终同一原错误随当前EN→ZH→EN即时呈现且原草稿不变，未重新Test/卸载；08空URL、09启用scope缺URL的当前错误；10英文Saved/11原timer后的Save/12重开原值/13英文Deleted/14正常结算；15/16中文Saved/Deleted。全部原图未编辑，不能把01–04当通过。
- [runs](runs/README.md)：before PID89712、18678/79；after PID79112、18680/81。公开GET共7个HTTP200安全选择（URL、两个用途、状态和原body长度），确认两语言自有配置Save/Delete与重开原值。不是完整config正文，不另称保留了4个UI PATCH response body。声明本机URL且两个用途false，无认证输入、不当连通测试。
- [checks](checks/README.md)：overlay类型0，Node build2m2s0/原warnings，i18n2/2301、docs345/26、架构20当前0；两真实父/双端口/假auth-models清理/完整日志隐私0。纯UI功能由真实交互/原图证明，没有源码文案/DOM/渲染/快照/像素测试。
- [inputs](inputs/README.md)：原NetworkPanel/两语言和真实服务/HTTP选择工具。产品保留error key+原details，delete success事实boolean；当前t在render，原B25draft/operation/busy/timer不变。locale只有原delete_failed一key短摘要，原错误走既有Details；没有后台、格式、配置面或迁移变化。
- [previous-delivery](previous-delivery/README.md)：B25 c6c2bcafb normal commit/push0、全部原hook、fresh own/upstream确认，原失败与资格不重写。

tab33/34均关闭。两轮normal settlement/父exit0、双端口0后清理生成auth/models同对；后台完整98604/111547字节，stdout/stderr各0、隐私0，inferenceRequests/realSolCalls0。真实backend-throw Details展开、committed-reconcile409反馈、凭据、切服务/Task/Project未独立验收，后续线索见Recall。当前架构/未发布中英日志/三索引同步；范围commit/push以随后实际回执为准。见[原捕获清单](manifest.json)。
`)
for(const [name,title,description]of [['screenshots','真实页面原图','16张Root逐一人工查看，原缺口与最终双向当前语言、保存/删除和回填分别保留。'],['runs','正式读取与运行生命周期','两个原occurrence和7个明确部分选择，未保存完整配置或凭据/数据库。'],['checks','原检查与退出','全部命令真实退出；类型/构建/目录不代视觉，也没有新增UI测试。'],['inputs','原源与工具','HTTP选择checker只验证真实配置；无mock页面或合成反馈。']]){fs.mkdirSync(`${artifact}/${name}`,{recursive:true});fs.writeFileSync(`${artifact}/${name}/README.md`,`# ${title}\n\n${description} 见[主说明](../README.md)。\n`)}
fs.writeFileSync(scratch+'/status-before-commit.txt',execFileSync('git',['status','--short']))
console.log(JSON.stringify({artifact,capturedFiles:files.length,retainedHTTPSelections:selections.length,runs:runs.map(({stage,pid,physicalExit})=>({stage,pid,physicalExit}))}))
