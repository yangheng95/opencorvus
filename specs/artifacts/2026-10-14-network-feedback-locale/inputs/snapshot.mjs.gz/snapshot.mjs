import fs from 'node:fs/promises'
import path from 'node:path'
import assert from 'node:assert/strict'
async function main(){
 const [stage,label,expected]=process.argv.slice(2);assert.match(stage??'',/^(before|after)([0-9]{2})?$/);assert.match(label??'',/^[a-z-]+$/)
 const root=path.resolve('.tmp-codex-network-feedback-01a133',stage),deadline=Date.now()+30_000
 while(!await fs.access(root+'/ready.json').then(()=>true,()=>false)){assert.ok(Date.now()<deadline,'Bounded own readiness');await new Promise(resolve=>setTimeout(resolve,250))}
 const ready=JSON.parse(await fs.readFile(root+'/ready.json','utf8')),authority=JSON.parse(await fs.readFile(root+'/project-authorities.json','utf8')),route='/config?'+new URLSearchParams({directory:authority.defaultDirectory})
 const response=await fetch(`http://127.0.0.1:${ready.port}`+route),raw=await response.text()
 assert.equal(response.status,200)
 const config=JSON.parse(raw),value=config.network?.proxy
 const proxy=value?{url:value.url,llmProvider:value.llmProvider,webResearch:value.webResearch}:null
 const selected={method:'GET',route,status:response.status,originalResponseBytes:Buffer.byteLength(raw),selection:'Only actual network.proxy URL and purpose booleans; full configuration/credentials not retained.',proxy}
 await fs.writeFile(root+`/snapshot-${label}.json`,JSON.stringify(selected,null,2)+'\n')
 assert.deepEqual(proxy,expected==='saved'?{url:`http://127.0.0.1:${ready.participantPort}`,llmProvider:false,webResearch:false}:null)
 console.log(JSON.stringify({stage,label,status:response.status,proxy,selection:selected.selection}))
}
await main().catch(error=>{console.error(error);process.exitCode=1})
