import fs from 'node:fs'
import path from 'node:path'
import {execFileSync} from 'node:child_process'
import {randomUUID} from 'node:crypto'
import {structuredPatch} from '../node_modules/.bun/diff@8.0.3/node_modules/diff/libesm/index.js'
const scratch='.tmp-codex-network-feedback-01a133',git=(args,options={})=>execFileSync('git',args,{encoding:'utf8',maxBuffer:64*1024*1024,...options})
const head=git(['rev-parse','HEAD']).trim(),index=path.resolve(scratch+'/reviewed-final-'+randomUUID()+'.index'),env={...process.env,GIT_INDEX_FILE:index},run=(args,input)=>git(args,{env,...(input===undefined?{}:{input})})
run(['read-tree',head]);const shared=[]
const addShared=(file,transform)=>{
 const before=git(['show',head+':'+file]).replaceAll('\r\n','\n'),after=transform(before)
 if(after===before)throw Error('Own shared scope missing or already committed '+file)
 run(['update-index','--cacheinfo','100644',run(['hash-object','-w','--stdin'],after).trim(),file])
 shared.push({file,before,after,patch:structuredPatch(file,file,before,after,'','',{context:3})})
}
for(const item of JSON.parse(fs.readFileSync(scratch+'/shared-final.json','utf8'))){
 if(item.beforeText)addShared(item.file,s=>{if(s.includes(item.afterText))throw Error('Own contract already baseline');if(!s.includes(item.beforeText))throw Error('Own contract anchor missing');return s.replace(item.beforeText,item.afterText)})
 else if(item.paragraph)addShared(item.file,s=>{if(s.includes(item.paragraph))throw Error('Own contract already baseline');if(!s.includes(item.anchor))throw Error('Own contract anchor missing');return s.replace(item.anchor,item.paragraph+item.anchor)})
 else addShared(item.file,s=>s.replace('#### 修复\n','#### 修复\n\n'+item.zh+'\n').replace('#### Fixed\n','#### Fixed\n\n'+item.en+'\n'))
}
for(const [file,token]of [['specs/README.md','(records/2026-10/2026-10-14-network-feedback-locale.md)'],['specs/records/2026-10/README.md','(2026-10-14-network-feedback-locale.md)'],['specs/artifacts/README.md','(2026-10-14-network-feedback-locale/README.md)']]){
 const lines=fs.readFileSync(file,'utf8').replaceAll('\r\n','\n').split('\n').filter(x=>x.includes(token));if(lines.length!==1)throw Error('Own index entry required')
 addShared(file,s=>{if(s.includes(token))throw Error('Own index already baseline');return s.replace('- [',lines[0]+'\n\n- [')})
}
const sources=['packages/overlay/src/components/settings/NetworkPanel.tsx'],record='specs/records/2026-10/2026-10-14-network-feedback-locale.md',artifact='specs/artifacts/2026-10-14-network-feedback-locale/'
run(['add','-f','--',...sources,record,artifact]);run(['diff','--cached','--check'])
const files=run(['diff','--cached','--name-only']).trim().split('\n'),allowed=new Set([...sources,...shared.map(x=>x.file),record])
if(files.some(x=>!allowed.has(x)&&!x.startsWith(artifact)))throw Error('Foreign staged path')
if(git(['rev-parse','HEAD']).trim()!==head)throw Error('Concurrent HEAD changed; regenerate review')
fs.writeFileSync(scratch+'/reviewed-final-index.json',JSON.stringify({head,index,files,sources,shared,record,artifact},null,2)+'\n')
fs.writeFileSync(scratch+'/staged-final.diff',run(['diff','--cached','--',...sources,...shared.map(x=>x.file),record]))
fs.writeFileSync(scratch+'/staged-final-stat.txt',run(['diff','--cached','--stat']))
console.log(JSON.stringify({head,scopedPaths:files.length,sources,shared:shared.map(x=>x.file)}))
