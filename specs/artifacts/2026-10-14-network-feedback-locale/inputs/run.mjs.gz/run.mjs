import fs from 'node:fs'
import path from 'node:path'
import {spawnSync} from 'node:child_process'
const scratch='.tmp-codex-network-feedback-01a133'
const [label, cwd, command, ...args]=process.argv.slice(2)
if(!label||!cwd||!command)throw Error('label cwd executable arguments required')
const bun=path.resolve('.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64')
const r=spawnSync(command,args,{cwd,env:{...process.env,PATH:bun+path.delimiter+process.env.PATH},maxBuffer:64*1024*1024})
fs.writeFileSync(`${scratch}/${label}.log`,Buffer.concat([r.stdout??Buffer.alloc(0),r.stderr??Buffer.alloc(0)]))
fs.writeFileSync(`${scratch}/${label}.exit`,String(r.status)+'\n')
process.stdout.write((r.stdout??Buffer.alloc(0)).toString().slice(-4500))
process.stderr.write((r.stderr??Buffer.alloc(0)).toString().slice(-4500))
if(r.error)throw r.error
process.exit(r.status??1)
