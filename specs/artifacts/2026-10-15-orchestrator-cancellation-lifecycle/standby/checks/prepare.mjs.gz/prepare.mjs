import fs from 'node:fs'
const parent='.tmp-product-iteration/orchestrator-cancellation-428',root=parent+'/standby',tag='orchestrator-cancellation-428-standby'
const base='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-15',bundle=base+'/'+tag+'-bundle/bin'
if(fs.existsSync(bundle))throw Error('Fresh native scope required')
fs.mkdirSync(bundle,{recursive:true});fs.copyFileSync('.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64/bun.exe',bundle+'/bun.exe');fs.cpSync('packages/overlay/dist-vite',bundle+'/ui',{recursive:true})
fs.mkdirSync(root+'/native',{recursive:true})
for(const name of ['launch.ps1','settle.ps1','shutdown.ps1']){
 let source=fs.readFileSync(parent+'/after/'+name,'utf8')
 source=source.replaceAll('orchestrator-cancellation-428-after',tag).replaceAll(parent+'/after',root+'/native').replaceAll('18579','18581')
 fs.writeFileSync(root+'/native/'+name,source)
}
let driver=fs.readFileSync(parent+'/create-task.ps1','utf8').replaceAll('orchestrator-cancellation-428-after',tag).replaceAll(parent,root).replaceAll('18579','18581').replaceAll('主动停止体验 428','待机边界复验 428')
fs.writeFileSync(root+'/create-task.ps1',driver)
fs.copyFileSync(parent+'/read-facts.ts',root+'/read-facts.ts')
let publicRead=fs.readFileSync(parent+'/public-message-read.mjs','utf8').replaceAll('18579','18581')
fs.writeFileSync(root+'/public-message-read.mjs',publicRead)
console.log(JSON.stringify({port:18581,tag,budget:'600s / 180s inactivity / 12 streams',source:'current backend and same published UI'}))
