import fs from 'node:fs'
import assert from 'node:assert/strict'
const root=import.meta.dirname
const facts=JSON.parse(fs.readFileSync(root+'/facts-post-stop.json','utf8'))
const assistant=facts.messages.find(m=>m.role==='assistant')
const response=await fetch(`http://127.0.0.1:18581/session/${assistant.sessionID}/message`,{
 headers:{'x-opencorvus-directory':facts.selection.directory},signal:AbortSignal.timeout(15_000),
})
assert.equal(response.status,200)
const messages=await response.json()
const actual=messages.find(m=>m.info.id===assistant.id)
assert(actual)
assert.deepEqual(actual.info.error,assistant.error)
const receipt={at:new Date().toISOString(),status:response.status,sessionID:assistant.sessionID,messageID:assistant.id,error:actual.info.error,boundary:'Actual public session.messages response preserves the persisted original cancellation; no rendered text assertion'}
fs.writeFileSync(root+'/public-message-read.json',JSON.stringify(receipt,null,2))
console.log(JSON.stringify(receipt))
