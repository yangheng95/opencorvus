$ErrorActionPreference='Stop'
$taskRequestPath='C:/Users/hengu/AppData/Local/Temp/opencorvus-test-run-4R6nJD/runner-77140-ElfC1B/runtime-root/tmp/supervisor-LAOJSj/request.json'
$taskRequest=Get-Content -Raw -LiteralPath $taskRequestPath|ConvertFrom-Json
$taskRoot=[IO.Path]::GetDirectoryName([IO.Path]::GetFullPath($taskRequestPath))
if($taskRequest.request_id -cne 'b1174c01-a510-45a8-ab67-d11fb57f2b8f' -or $taskRequest.owner_pid -ne 77140 -or $taskRequest.args -notcontains '--test-name-pattern=standby'){throw 'Exact owned fixture request required'}
foreach($taskPath in @($taskRequest.ready_file,$taskRequest.cancel_file,$taskRequest.settled_file)){if([IO.Path]::GetDirectoryName([IO.Path]::GetFullPath($taskPath)) -cne $taskRoot){throw 'Request control escaped its owned directory'}}
$taskReady=Get-Content -Raw -LiteralPath $taskRequest.ready_file|ConvertFrom-Json
$taskHelper=Get-Content -Raw -LiteralPath (Join-Path $taskRoot 'helper.json')|ConvertFrom-Json
if($taskReady.request_id -cne $taskRequest.request_id -or $taskHelper.request_id -cne $taskRequest.request_id -or $taskReady.runtime_occurrence_id -cne $taskRequest.runtime_occurrence_id -or $taskHelper.runtime_occurrence_id -cne $taskRequest.runtime_occurrence_id){throw 'Native marker identity mismatch'}
. 'D:/myhexin-local/opencorvus/.tmp-product-iteration/live-sol-long-source-reading-406-launch.ps1' -FunctionsOnly
$taskIdentities=@(
 @{role='owner';pid=$taskRequest.owner_pid;processInstanceID=$taskRequest.owner_process_instance_id},
 @{role='helper';pid=$taskHelper.helper_pid;processInstanceID=$taskHelper.helper_process_instance_id},
 @{role='target';pid=$taskReady.target_pid;processInstanceID=$taskReady.target_process_instance_id}
)
$taskStates=@($taskIdentities|ForEach-Object {@{identity=$_;state=(Get-OwnedNativeState $_)}})
if(@($taskStates|Where-Object state -NE 'exact_live').Count){throw 'Original owned fixture chain must still be live'}
$taskFact=@{requestID=$taskRequest.request_id;runtimeOccurrenceID=$taskRequest.runtime_occurrence_id;chain=$taskStates;observedAtUtc=[DateTime]::UtcNow.ToString('o');reason='Stop only the owned fixture whose unconsumed run-once wake prevented cleanup'}
$taskFact|ConvertTo-Json -Depth 8|Set-Content -LiteralPath 'D:/myhexin-local/opencorvus/.tmp-product-iteration/orchestrator-cancellation-428/standby/fixture-stop-request.json'
[IO.File]::WriteAllText($taskRequest.cancel_file,'owned fixture preparation failure')
Write-Output 'Requested exact owned fixture cancellation'
