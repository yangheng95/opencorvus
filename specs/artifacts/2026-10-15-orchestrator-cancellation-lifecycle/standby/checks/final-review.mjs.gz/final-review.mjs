import fs from 'node:fs'
import path from 'node:path'
import zlib from 'node:zlib'
import assert from 'node:assert/strict'
const root=import.meta.dirname,artifact=path.resolve('specs/artifacts/2026-10-15-orchestrator-cancellation-lifecycle/standby')
for(const name of ['docs-check.log','architecture-check.log','archive.log','final-review.mjs'])fs.writeFileSync(artifact+'/checks/'+name+'.gz',zlib.gzipSync(fs.readFileSync(root+'/'+name)))
const walk=dir=>fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(dir,e.name)):[path.join(dir,e.name)])
const files=walk(artifact),secrets=[]
const collect=obj=>{for(const [key,value] of Object.entries(obj)){if(value&&typeof value==='object')collect(value);else if(typeof value==='string'&&value.length>16&&/access|refresh|token|key|secret|password/i.test(key))secrets.push(value)}}
collect(JSON.parse(fs.readFileSync('C:/Users/hengu/AppData/Local/opencorvus/data/auth.json','utf8')))
assert(secrets.length>0,'Actual credential material required for the in-memory disclosure review')
for(const file of files){if(file.endsWith('.jpg'))continue;const raw=fs.readFileSync(file),text=(file.endsWith('.gz')?zlib.gunzipSync(raw):raw).toString('utf8');for(const value of secrets)assert.equal(text.includes(value),false,`Credential disclosure in ${file}`)}
console.log(JSON.stringify({artifactFiles:files.length,credentialDisclosureReview:'passed; values remain in memory',positiveContracts:23,assertions:59,typecheckPackages:8,docs:'345 operations / 26 groups',architecture:'20 documents'}))
