import fs from 'node:fs'
import path from 'node:path'
import zlib from 'node:zlib'
import assert from 'node:assert/strict'
const root=import.meta.dirname,dest=path.resolve('specs/artifacts/2026-10-15-orchestrator-cancellation-lifecycle/standby')
const save=(name,bytes)=>{const target=path.join(dest,name);fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,zlib.gzipSync(bytes))}
const facts=JSON.parse(fs.readFileSync(root+'/facts-post-stop.json','utf8')),streaming=JSON.parse(fs.readFileSync(root+'/facts-streaming.json','utf8'))
const assistant=facts.messages.find(m=>m.role==='assistant'),requested=facts.events.find(e=>e.type==='task.cancellation.requested'),terminal=facts.events.find(e=>e.type==='task.cancelled'),lifecycle=facts.events.filter(e=>e.type==='agent.execution.lifecycle').at(-1)
assert(assistant&&requested&&terminal&&lifecycle)
assert.equal(assistant.error.name,'MessageAbortedError')
assert.deepEqual(lifecycle.payload,{inputMessageID:assistant.parentID,status:{type:'terminal',reason:'aborted',error:requested.payload.reason}})
assert.equal(requested.payload.execution_epoch,1);assert.equal(terminal.payload.execution_epoch,1);assert.equal(requested.correlation_id,terminal.correlation_id)
assert.deepEqual(assistant.error.data.cancellation,{actor:'user',source:'task.cancel',surface:'overlay.composer_stop',requestID:requested.correlation_id,reason:requested.payload.reason,taskID:facts.selection.taskID,causationEventID:requested.id})
assert.equal(streaming.messages.find(m=>m.id===assistant.id).time.completed,undefined)
assert.deepEqual(facts.sessions.map(s=>s.kind),['root','orchestrator'])
const publicMessage=JSON.parse(fs.readFileSync(root+'/public-message-read.json','utf8'));assert.equal(publicMessage.status,200);assert.deepEqual(publicMessage.error,assistant.error)
const evidence='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-15/orchestrator-cancellation-428-standby/evidence'
const clean=JSON.parse(fs.readFileSync(evidence+'/physical-terminal-and-pair-cleanup.json','utf8')),native=JSON.parse(fs.readFileSync(evidence+'/native-host-settled.json','utf8'))
assert.equal(clean.physicalCompletion,true);assert.equal(clean.pairedCleanupComplete,true);assert.equal(native.terminal.exitCode,0)
const audits=fs.readdirSync(evidence).filter(name=>/^provider-.*\.json$/.test(name)&&name!=='provider-pair-staging.json').map(name=>({name,value:JSON.parse(fs.readFileSync(evidence+'/'+name,'utf8'))})).filter(entry=>Array.isArray(entry.value.requests)).sort((a,b)=>b.value.requests.length-a.value.requests.length||Date.parse(b.value.observedAt)-Date.parse(a.value.observedAt))
const last=audits[0];assert(last)
const requests=last.value.requests.map(({model,streaming,status,response_reader})=>({model,streaming,status,response_reader}))
for(const r of requests){assert.equal(r.model,'gpt-6.1-sol');assert.equal(r.streaming,true);assert.equal(r.status,200);assert.equal(r.response_reader.state,'settled')}
const business=requests.filter(r=>r.response_reader.requestContext?.sessionID===assistant.sessionID);assert.equal(business.length,1);assert.equal(business[0].response_reader.terminal.kind,'aborted')
for(const name of ['native-host-ready.json','native-host-settled.json','physical-terminal-and-pair-cleanup.json','preflight-ready.json','provider-pair-staging.json','public-shutdown.json','launcher-child-exit.json'])save('native/'+name+'.gz',fs.readFileSync(evidence+'/'+name))
save('native/provider-summary.json.gz',JSON.stringify({source:last.name,requests},null,2))
for(const name of ['launch.ps1','settle.ps1','shutdown.ps1','launch.log'])save('native/'+name+'.gz',fs.readFileSync(root+'/native/'+name))
const receipt={at:new Date().toISOString(),task:facts.selection,assistant:{id:assistant.id,parentID:assistant.parentID,error:assistant.error,time:assistant.time},requested,terminal,lifecycle,requests,native:native.terminal,physicalCompletion:true,pairedCleanupComplete:true,boundary:'Actual active Stop after original idle-receipt preservation fix; standby lifecycle is a separately qualified backend contract'}
fs.writeFileSync(root+'/review-result.json',JSON.stringify(receipt,null,2));save('facts/review-result.json.gz',JSON.stringify(receipt,null,2))
for(const name of fs.readdirSync(root)){const file=path.join(root,name);if(fs.statSync(file).isFile()&&/\.(ts|mjs|ps1|log|json|before)$/.test(name))save('checks/'+name+'.gz',fs.readFileSync(file))}
console.log(JSON.stringify({taskID:facts.selection.taskID,assistantError:assistant.error.name,lifecycle:lifecycle.payload,requestCount:requests.length,readerTerminals:requests.map(r=>r.response_reader.terminal.kind),physicalCompletion:true,pairedCleanupComplete:true,exitCode:native.terminal.exitCode},null,2))
