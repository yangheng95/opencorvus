import fs from 'node:fs'
const root='.tmp-product-iteration/orchestrator-cancellation-428',base='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-15'
for(const [phase,port] of [['before',18577],['after',18579]]){
 const tag='orchestrator-cancellation-428-'+phase,bundle=base+'/'+tag+'-bundle/bin'
 if(fs.existsSync(bundle))throw Error('Fresh bundle required')
 fs.mkdirSync(bundle,{recursive:true});fs.copyFileSync('.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64/bun.exe',bundle+'/bun.exe');fs.cpSync('packages/overlay/dist-vite',bundle+'/ui',{recursive:true})
 fs.mkdirSync(root+'/'+phase,{recursive:true})
 for(const name of ['launch.ps1','settle.ps1','shutdown.ps1']){
  let source=fs.readFileSync('.tmp-product-iteration/cancellation-activation-426/retry/'+name,'utf8')
  source=source.replaceAll('cancellation-activation-426-retry',tag).replaceAll('.tmp-product-iteration/cancellation-activation-426/retry',root+'/'+phase).replaceAll('18575',String(port))
  fs.writeFileSync(root+'/'+phase+'/'+name,source)
 }
}
let driver=fs.readFileSync('.tmp-product-iteration/cancellation-activation-426/create-task.ps1','utf8')
driver=driver.replaceAll('cancellation-activation-426-after','orchestrator-cancellation-428-after').replaceAll('.tmp-product-iteration/cancellation-activation-426',root).replaceAll('18573','18579').replaceAll('取消原因回归 426','主动停止体验 428').replaceAll('product-cancellation-426','product-cancellation-428')
fs.writeFileSync(root+'/create-task.ps1',driver)
fs.copyFileSync('.tmp-product-iteration/cancellation-activation-426/read-facts.ts',root+'/read-facts.ts')
for(const [name,source] of [['agent.ts.before','packages/opencorvus/src/orchestrator/agent.ts'],['delegate-agent.ts.before','packages/opencorvus/src/tool/delegate-agent.ts']])fs.copyFileSync(source,root+'/'+name)
const artifact='specs/artifacts/2026-10-15-orchestrator-cancellation-lifecycle'
fs.mkdirSync(artifact,{recursive:true});fs.writeFileSync(artifact+'/README.md','# 独立Prompt取消执行终态证据\n\n[方案与Recall](../../records/2026-10/2026-10-15-orchestrator-cancellation-lifecycle.md)。实际前后验收在执行后补齐，不含凭据、UI自动化或完整数据库文件。\n')
for(const [file,line] of [
 ['specs/README.md','- [独立Prompt取消执行终态](records/2026-10/2026-10-15-orchestrator-cancellation-lifecycle.md)：原typed取消与Orchestrator执行事实一致性。'],
 ['specs/records/2026-10/README.md','- [独立Prompt取消执行终态](2026-10-15-orchestrator-cancellation-lifecycle.md)：取消catch根因、共享审计及真实Stop。'],
 ['specs/artifacts/README.md','- [独立Prompt取消执行终态](2026-10-15-orchestrator-cancellation-lifecycle/README.md)：原事件、正向合同与人工页面复核。'],
]){const text=fs.readFileSync(file,'utf8');if(text.includes(line))throw Error('Already indexed');fs.writeFileSync(file,text.trimEnd()+'\n\n'+line+'\n')}
console.log(JSON.stringify({phases:['before:18577','after:18579'],budget:'600s / 180s inactivity / 12 cumulative actual streams per scope'}))
