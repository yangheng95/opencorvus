$ErrorActionPreference='Stop'
$taskDiag='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-15/orchestrator-cancellation-428-after'
$taskRun='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/member-live-rendering-412-fresh'
$taskScratch='D:/myhexin-local/opencorvus/.tmp-product-iteration/orchestrator-cancellation-428'
$taskReady=Get-Content -Raw -LiteralPath "$taskDiag/evidence/native-host-ready.json"|ConvertFrom-Json
$taskPreflight=Get-Content -Raw -LiteralPath "$taskDiag/evidence/preflight-ready.json"|ConvertFrom-Json
$taskAuthority=Get-Content -Raw -LiteralPath "$taskDiag/evidence/authority-ready.json"|ConvertFrom-Json
if($taskReady.occurrence -cne $taskPreflight.occurrence -or $taskReady.target.pid -ne $taskPreflight.pid -or $taskPreflight.preflight.actualModel -cne 'gpt-6.1-sol' -or !$taskPreflight.preflight.streaming -or $taskPreflight.preflight.credential -cne 'usable' -or $taskPreflight.preflight.catalog -cne 'projected'){throw 'Actual paired provider preflight required'}
if($taskAuthority.pid -ne $taskReady.target.pid -or $taskAuthority.admission.packageRevision.id -cne 'base' -or $taskAuthority.admission.packageRevision.scope -cne 'built_in'){throw 'Actual builtin Base target required'}
. 'D:/myhexin-local/opencorvus/.tmp-product-iteration/live-sol-long-source-reading-406-launch.ps1' -FunctionsOnly
if((Get-OwnedNativeState $taskReady.target) -cne 'exact_live'){throw 'Exact owned target required'}
$taskSelectionPath="$taskRun/orchestrator-cancellation-428-after-selection.json"
if(Test-Path -LiteralPath $taskSelectionPath){throw 'This occurrence already has an accepted Task'}
$taskRequest='只由当前执行者直接回答，不创建或调用任何其他成员，不委派，不搜索、不运行shell、不修改文件。请先连续写一篇约3000字的中文长文，解释在日常项目中如何把材料事实、尚待确认的信息和展示建议清楚分开。分成18个有编号的小节，每节用完整段落说明一个实际可用的方法。可以使用README中已有的“仅用于界面测试”价格和交付文字作为示例，但不要把它们写成真实报价或承诺。每个小节都有自己的具体例子，最后附一个核对表。直接持续输出正文，不人为等待、不请求澄清；正文完成后再说明结果。'
$taskRequestID=[Guid]::NewGuid().ToString()
$taskOriginal=@{};Get-ChildItem Env:|ForEach-Object {$taskOriginal[$_.Name]=$_.Value}
$taskEnv=@{};foreach($taskKey in @('PATH','SystemRoot','WINDIR','ComSpec','PATHEXT','LANG','LC_ALL','LC_CTYPE')){if($taskOriginal.ContainsKey($taskKey)){$taskEnv[$taskKey]=$taskOriginal[$taskKey]}}
$taskClient="$taskDiag/cli-home";New-Item -ItemType Directory -Path $taskClient,"$taskDiag/cli-temp","$taskDiag/cli-runtime" -Force|Out-Null
foreach($taskKey in @('USERPROFILE','APPDATA','LOCALAPPDATA','XDG_CONFIG_HOME','XDG_DATA_HOME','XDG_CACHE_HOME','XDG_STATE_HOME')){$taskEnv[$taskKey]=$taskClient}
$taskEnv.OPENCORVUS_HOME="$taskDiag/cli-runtime";$taskEnv.OPENCORVUS_DISABLE_EXTERNAL_SKILLS='1';$taskEnv.OPENCORVUS_DISABLE_AUTOUPDATE='1';$taskEnv.OPENCORVUS_TASK_PROCESS_MODE='native'
foreach($taskKey in @('TEMP','TMP','TMPDIR')){$taskEnv[$taskKey]="$taskDiag/cli-temp"}
$taskEnv.HOMEDRIVE='C:';$taskEnv.HOMEPATH=([IO.Path]::GetFullPath($taskClient)).Substring(2)
try{
 Get-ChildItem Env:|ForEach-Object {[Environment]::SetEnvironmentVariable($_.Name,$null,'Process')}
 foreach($taskKey in $taskEnv.Keys){[Environment]::SetEnvironmentVariable($taskKey,$taskEnv[$taskKey],'Process')}
 $taskSent=[DateTime]::UtcNow.ToString('o')
 @{requestID=$taskRequestID;request=$taskRequest;requestSentAt=$taskSent;directory="$taskRun/project"}|ConvertTo-Json|Set-Content -LiteralPath "$taskScratch/task-request.json"
 & 'D:/myhexin-local/opencorvus/.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64/bun.exe' 'D:/myhexin-local/opencorvus/packages/opencorvus/src/index.ts' task create --url http://127.0.0.1:18579 --dir "$taskRun/project" --pillar work --expert-squad base --request $taskRequest --title '主动停止体验 428' --model openai/gpt-6.1-sol --request-id $taskRequestID --source product-cancellation-428 --format json 1> "$taskScratch/task-accepted.json" 2> "$taskScratch/task-create.log"
 $taskExit=$LASTEXITCODE
 if($taskExit -ne 0){throw "Actual Task CLI exit $taskExit"}
 $taskAcceptedAt=[DateTime]::UtcNow.ToString('o');$taskAccepted=Get-Content -Raw -LiteralPath "$taskScratch/task-accepted.json"|ConvertFrom-Json
 if(!$taskAccepted.task_id -or $taskAccepted.project_id -cne $taskAuthority.admission.projectID -or [IO.Path]::GetFullPath($taskAccepted.directory) -cne [IO.Path]::GetFullPath("$taskRun/project")){throw 'Actual Task acceptance identity mismatch'}
 $taskSelection=@{occurrence=$taskReady.occurrence;taskID=$taskAccepted.task_id;projectID=$taskAccepted.project_id;directory=$taskAccepted.directory;productPillar='work';requestID=$taskRequestID;requestSentAt=$taskSent;acceptedObservedAt=$taskAcceptedAt}
 Write-OwnedLaunchFact "$taskScratch/task-selection.json" $taskSelection
 Write-OwnedLaunchFact $taskSelectionPath $taskSelection
 $taskSelection|ConvertTo-Json
}finally{
 Get-ChildItem Env:|ForEach-Object {[Environment]::SetEnvironmentVariable($_.Name,$null,'Process')}
 foreach($taskKey in $taskOriginal.Keys){[Environment]::SetEnvironmentVariable($taskKey,$taskOriginal[$taskKey],'Process')}
}
