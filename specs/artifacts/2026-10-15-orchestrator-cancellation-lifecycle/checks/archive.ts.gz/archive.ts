import fs from "node:fs"
import path from "node:path"
import zlib from "node:zlib"
import assert from "node:assert/strict"
import { Database } from "bun:sqlite"
const root=import.meta.dir,dest=path.resolve("specs/artifacts/2026-10-15-orchestrator-cancellation-lifecycle")
const save=(name:string,bytes:string|Buffer)=>{const target=path.join(dest,name);fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,zlib.gzipSync(bytes))}
const facts=JSON.parse(fs.readFileSync(root+"/facts-post-stop.json","utf8"))
const streaming=JSON.parse(fs.readFileSync(root+"/facts-streaming.json","utf8"))
const original=JSON.parse(fs.readFileSync(path.resolve(root,"../cancellation-activation-426/facts-stopped.json"),"utf8"))
const assistant=facts.messages.find((m:any)=>m.role==="assistant")
const requested=facts.events.find((e:any)=>e.type==="task.cancellation.requested")
const terminal=facts.events.find((e:any)=>e.type==="task.cancelled")
const lifecycle=facts.events.filter((e:any)=>e.type==="agent.execution.lifecycle").at(-1)
assert(assistant&&requested&&terminal&&lifecycle)
assert.equal(assistant.error.name,"MessageAbortedError")
assert.equal(lifecycle.payload.inputMessageID,assistant.parentID)
assert.deepEqual(lifecycle.payload.status,{type:"terminal",reason:"aborted",error:requested.payload.reason})
assert.equal(requested.payload.execution_epoch,1);assert.equal(terminal.payload.execution_epoch,1)
assert.equal(requested.correlation_id,terminal.correlation_id)
assert.deepEqual(assistant.error.data.cancellation,{actor:"user",source:"task.cancel",surface:"overlay.composer_stop",requestID:requested.correlation_id,reason:requested.payload.reason,taskID:facts.selection.taskID,causationEventID:requested.id})
assert.equal(streaming.messages.find((m:any)=>m.id===assistant.id).time.completed,undefined)
assert.deepEqual(facts.sessions.map((s:any)=>s.kind),["root","orchestrator"])
const publicMessage=JSON.parse(fs.readFileSync(root+"/public-message-read.json","utf8"))
assert.equal(publicMessage.status,200);assert.deepEqual(publicMessage.error,assistant.error)
const originalLifecycle=original.events.filter((e:any)=>e.type==="agent.execution.lifecycle").at(-1)
assert.equal(originalLifecycle.payload.status.reason,"error")
save("facts/original-426-error.json.gz",JSON.stringify({taskID:original.task.id,lifecycle:originalLifecycle,assistant:original.messages.filter((m:any)=>m.error).map((m:any)=>({id:m.id,error:m.error}))},null,2))
const scopes=[]
for(const phase of ["before","after"]){
 const evidence=`C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-15/orchestrator-cancellation-428-${phase}/evidence`
 const clean=JSON.parse(fs.readFileSync(evidence+"/physical-terminal-and-pair-cleanup.json","utf8"))
 const native=JSON.parse(fs.readFileSync(evidence+"/native-host-settled.json","utf8"))
 assert.equal(clean.physicalCompletion,true);assert.equal(clean.pairedCleanupComplete,true);assert.equal(native.terminal.exitCode,0)
 const audits=fs.readdirSync(evidence).filter(name=>/^provider-.*\.json$/.test(name)&&name!=="provider-pair-staging.json").map(name=>({name,value:JSON.parse(fs.readFileSync(evidence+"/"+name,"utf8"))})).filter(entry=>Array.isArray(entry.value.requests)).sort((a,b)=>b.value.requests.length-a.value.requests.length||Date.parse(b.value.observedAt)-Date.parse(a.value.observedAt))
 const last=audits[0];assert(last)
 const requests=last.value.requests.map(({model,streaming,status,response_reader}:any)=>({model,streaming,status,response_reader}))
 for(const r of requests){assert.equal(r.model,"gpt-6.1-sol");assert.equal(r.streaming,true);assert.equal(r.status,200);assert.equal(r.response_reader.state,"settled")}
 for(const name of ["native-host-ready.json","native-host-settled.json","physical-terminal-and-pair-cleanup.json","preflight-ready.json","provider-pair-staging.json","public-shutdown.json","launcher-child-exit.json"])save(phase+"/"+name+".gz",fs.readFileSync(evidence+"/"+name))
 save(phase+"/provider-summary.json.gz",JSON.stringify({source:last.name,requests},null,2))
 for(const name of ["launch.ps1","settle.ps1","shutdown.ps1","launch.log"])save(phase+"/"+name+".gz",fs.readFileSync(root+"/"+phase+"/"+name))
 scopes.push({phase,requests,terminal:native.terminal,physicalCompletion:true,pairedCleanupComplete:true})
}
const business=scopes[1].requests.filter((r:any)=>r.response_reader.requestContext?.sessionID===assistant.sessionID)
assert.equal(business.length,1);assert.equal(business[0].response_reader.terminal.kind,"aborted")
const userPath="C:/Users/hengu/AppData/Local/opencorvus/data/opencorvus.db"
const userDB=new Database(userPath,{readonly:true}),userVersion=userDB.query("PRAGMA user_version").get();userDB.close(true)
const stat=fs.statSync(userPath)
const receipt={at:new Date().toISOString(),task:facts.selection,assistant:{id:assistant.id,parentID:assistant.parentID,activationID:assistant.activationID,error:assistant.error,time:assistant.time},requested,terminal,lifecycle,scopes,defaultUserObservation:{version:userVersion,size:stat.size,mtime:stat.mtime},boundary:"Real CLI, active Sol stream, manual UI Stop/reload/Chinese/history, exact original events and public message read; no UI assertions"}
fs.writeFileSync(root+"/review-result.json",JSON.stringify(receipt,null,2));save("facts/review-result.json.gz",JSON.stringify(receipt,null,2))
for(const name of fs.readdirSync(root)){const file=path.join(root,name);if(fs.statSync(file).isFile()&&/\.(ts|mjs|ps1|log|json|before)$/.test(name))save("checks/"+name+".gz",fs.readFileSync(file))}
console.log(JSON.stringify({taskID:facts.selection.taskID,assistantError:assistant.error.name,lifecycle:lifecycle.payload,scopes:scopes.map(s=>({phase:s.phase,requestCount:s.requests.length,readerTerminals:s.requests.map((r:any)=>r.response_reader.terminal.kind),exitCode:s.terminal.exitCode,physicalCompletion:true,pairedCleanupComplete:true})),defaultUserObservation:receipt.defaultUserObservation},null,2))
