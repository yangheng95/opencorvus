/** PREPARED ONLY. Root must review and authorize execution; ordinary CLI, no UI driver. */
import assert from "node:assert/strict"
import fs from "node:fs/promises"
import path from "node:path"
import { pathToFileURL } from "node:url"
import { randomUUID } from "node:crypto"
import { once } from "node:events"

const packageRoot = path.resolve(import.meta.dir, "../packages/opencorvus")
const source = (relative: string) => pathToFileURL(path.join(packageRoot, relative)).href

// Host owns one foreground launch; Target below remains the sole Task pipeline.
if (process.argv[2] === "--owned-host") {
  const [hostEvidence, hostOccurrence, hostDeadline, executable, ...args] = process.argv.slice(3)
  assert(hostEvidence && hostOccurrence && executable && args.length)
  assert(path.isAbsolute(hostEvidence) && path.isAbsolute(executable))
  const { installProcessShims } = await import(source("src/runtime/shims.ts"))
  installProcessShims()
  const { Filesystem } = await import(source("src/util/filesystem.ts"))
  const physical = await import(source("src/runtime/process-occurrence.ts"))
  const { supervisedHostProcessFacade } = await import(source("src/util/process-facade.ts"))
  const host = physical.currentRuntimeProcessOccurrence()
  const parent = physical.observedProcessOccurrence(process.ppid)
  assert(parent, "Native Host requires its actual supervising parent")
  await fs.mkdir(hostEvidence, { recursive: true })
  const fact = async (name: string, value: unknown) => {
    const target = path.join(hostEvidence, name)
    const stage = `${target}.${process.pid}-${randomUUID()}.stage`
    try {
      await fs.writeFile(stage, JSON.stringify(value, null, 2), { flag: "wx" })
      await Filesystem.renameNoReplace(stage, target)
    } finally { await fs.rm(stage, { force: true }) }
  }
  let phase = "spawn-admission"
  try {
    const deadlineAt = Number(hostDeadline)
    assert(Number.isSafeInteger(deadlineAt) && deadlineAt > Date.now(), "Explicit future native Host deadline required")
    const handle = await supervisedHostProcessFacade(hostOccurrence, true).spawn({
      command: { executable, args }, cwd: path.dirname(hostEvidence), env: process.env,
      stdin: "ignore", stdout: "pipe", stderr: "pipe", ownership: "owned_tree",
      deadlineAt, occurrenceID: hostOccurrence,
    })
    const drain = async (stream: AsyncIterable<Uint8Array> | null, destination: NodeJS.WriteStream) => {
      assert(stream, "Foreground native command requires an output stream")
      for await (const chunk of stream) {
        if (!destination.write(chunk)) await once(destination, "drain")
      }
    }
    const outcomes = Promise.allSettled([
      handle.settled,
      drain(handle.stdout, process.stdout), drain(handle.stderr, process.stderr),
    ])
    phase = "target-identity"
    const target = physical.observedProcessOccurrence(handle.pid)
    assert(target, "Native Target must be observable at ready admission")
    assert.equal(physical.observeRuntimeProcessOccurrence(target), "exact_live")
    const targetBirthAtMs = Number((BigInt(target.processInstanceID.slice("win32:".length)) - 621355968000000000n) / 10000n)
    await fact("native-host-ready.json", { occurrence: hostOccurrence, outcome: "ready", host, parent, target,
      targetBirthAtMs, deadlineAt, observedAtUtc: new Date().toISOString(), executable, args,
      authority: "Production foreground ProcessFacade request controls and ProcessSupervisor Windows Job; no detached transfer" })
    phase = "whole-job-output-request-settlement"
    const results = await outcomes
    const errors = results.flatMap((result) => result.status === "rejected" ? [result.reason] : [])
    if (errors.length) throw new AggregateError(errors, "Native Host physical/output/request settlement failed")
    const terminal = await handle.terminal
    await fact("native-host-settled.json", { occurrence: hostOccurrence, outcome: "settled", host, target,
      observedAtUtc: new Date().toISOString(), deadlineAt, terminal,
      physicalCompletion: true, outputDrainComplete: true, requestCleanupComplete: true,
      authority: "Actual fulfilled production ProcessFacade/ProcessSupervisor settlement and both output drains; native marker validation precedes request cleanup" })
    process.exit(terminal.reason === "exited" ? (terminal.exitCode ?? 1) : 1)
  } catch (error) {
    await fact("native-host-error.json", { occurrence: hostOccurrence, outcome: "failed", host, phase,
      observedAtUtc: new Date().toISOString(), errorType: error instanceof Error ? error.name : "UnknownError",
      message: error instanceof Error ? error.message : String(error),
      causes: error instanceof AggregateError ? error.errors.map((cause) => ({
        type: cause instanceof Error ? cause.name : typeof cause,
        message: cause instanceof Error ? cause.message : String(cause),
      })) : undefined,
      authority: "Failed Host observation/admission/settlement; no physical completion claim" })
    process.exit(1)
  }
}

