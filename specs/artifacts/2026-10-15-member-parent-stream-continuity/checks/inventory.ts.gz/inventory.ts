import fs from 'node:fs'
import {Database} from 'bun:sqlite'
const filename='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/member-live-rendering-412-fresh/runtime/data/opencorvus.db'
const ids=['ses_-zUS0X33CzzWEKMgCk98','ses_-zUS0WzzQzzDOGrIbYwN']
const db=new Database(filename,{readonly:true})
try {
 db.exec('PRAGMA busy_timeout=5000; BEGIN')
 const sessions=ids.flatMap(id=>db.query('SELECT id,parent_id,project_id,directory,kind,title,metadata FROM session WHERE id=?').all(id))
 const messages=ids.flatMap(id=>db.query('SELECT id,session_id,data FROM message WHERE session_id=? ORDER BY time_created,id').all(id)).map((row:any)=>{const info=JSON.parse(row.data);return {id:row.id,sessionID:row.session_id,parentID:info.parentID,role:info.role,agent:info.agent,finish:info.finish,time:info.time,error:info.error}})
 const sources=ids.flatMap(id=>db.query("SELECT p.id,p.message_id,p.data FROM part p JOIN message m ON m.id=p.message_id WHERE m.session_id=? AND json_extract(p.data,'$.type')='source-file' ORDER BY p.time_created,p.id").all(id)).map((row:any)=>({id:row.id,messageID:row.message_id,...JSON.parse(row.data)}))
 const receipt={at:new Date().toISOString(),version:db.query('PRAGMA user_version').get(),sessions,messages,sources,boundary:'Raw read-only original owned history; no synthetic event or application runtime'}
 const target=import.meta.dir+'/'+(process.argv[2]||'inventory')+'.json';if(fs.existsSync(target))throw Error('Fresh receipt name required');fs.writeFileSync(target,JSON.stringify(receipt,null,2));console.log(JSON.stringify({version:receipt.version,sessions,messages:messages.length,sources:sources.length},null,2))
}finally{db.exec('ROLLBACK');db.close(true)}
