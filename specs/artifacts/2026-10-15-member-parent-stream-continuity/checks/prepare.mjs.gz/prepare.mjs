import fs from 'node:fs'
const root='.tmp-product-iteration/member-parent-stream-431',tag='member-parent-stream-431',base='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-15'
const bundle=base+'/'+tag+'-bundle/bin'
if(fs.existsSync(bundle))throw Error('Fresh diagnostic publication required')
fs.mkdirSync(bundle,{recursive:true});fs.copyFileSync('.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64/bun.exe',bundle+'/bun.exe')
for(const name of ['launch.ps1','settle.ps1','shutdown.ps1']){
 let source=fs.readFileSync('.tmp-product-iteration/workspace-refresh-location-430/before/'+name,'utf8')
 source=source.replaceAll('workspace-refresh-location-430-before',tag).replaceAll('.tmp-product-iteration/workspace-refresh-location-430/before',root).replaceAll('18587','18599')
 fs.writeFileSync(root+'/'+name,source)
}
for(const file of ['components/TextPart.tsx','components/text-part-model.ts','components/ChatBubble.tsx','components/SubagentConversationPanel.tsx','components/CardParts.tsx','services/markdown-render.ts']){
 const target=root+'/original/'+file;fs.mkdirSync(target.substring(0,target.lastIndexOf('/')),{recursive:true});fs.copyFileSync('packages/overlay/src/'+file,target)
}
const artifact='specs/artifacts/2026-10-15-member-parent-stream-continuity';fs.mkdirSync(artifact,{recursive:true});fs.writeFileSync(artifact+'/README.md','# 主会话流中成员侧栏连续性证据\n\n[方案与Recall](../../records/2026-10/2026-10-15-member-parent-stream-continuity.md)。被动诊断与实际页面，执行后记录准确资格。\n')
for(const [file,line] of [
 ['specs/README.md','- [主流中成员连续性](records/2026-10/2026-10-15-member-parent-stream-continuity.md)：已有成员在主会话流中的真实阅读与生命周期。'],
 ['specs/records/2026-10/README.md','- [主流中成员连续性](2026-10-15-member-parent-stream-continuity.md)：真实主输入、旧成员、Sources与被动诊断。'],
 ['specs/artifacts/README.md','- [主流中成员连续性](2026-10-15-member-parent-stream-continuity/README.md)：实际页面和精确运行回执。'],
]){const text=fs.readFileSync(file,'utf8');if(text.includes(line))throw Error('Already indexed');fs.writeFileSync(file,text.trimEnd()+'\n\n'+line+'\n')}
console.log(JSON.stringify({port:18599,bundle,scope:'600s / 180s inactivity / 12 cumulative actual streams',business:'One parent input; original completed member only'}))
