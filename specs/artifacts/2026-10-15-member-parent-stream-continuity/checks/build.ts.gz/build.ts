import { preparePackageBuildEnvironment } from "../../script/package-build-environment"
const env=await preparePackageBuildEnvironment(process.cwd(),process.env)
console.log(JSON.stringify({buildRuntime:env.OPENCORVUS_HOME,renderer:'Node Vite with passive lifetime observation'}))
const child=Bun.spawn({cmd:['node','.tmp-product-iteration/member-parent-stream-431/build-diagnostic.mjs'],env,cwd:process.cwd(),stdin:'ignore',stdout:'inherit',stderr:'inherit'})
const exitCode=await child.exited;console.log(JSON.stringify({exitCode}));process.exit(exitCode)
