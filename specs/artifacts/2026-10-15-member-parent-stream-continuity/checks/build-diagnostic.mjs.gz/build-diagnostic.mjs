import path from 'node:path'
import {build,loadConfigFromFile} from '../../packages/overlay/node_modules/vite/dist/node/index.js'
const workspace=process.cwd()
const replace=(source,anchor,value)=>{if(source.split(anchor).length!==2)throw Error('Inspect passive diagnostic anchor: '+anchor);return source.replace(anchor,value)}
process.chdir(path.join(workspace,'packages/overlay'))
const loaded=await loadConfigFromFile({command:'build',mode:'production'},path.join(workspace,'packages/overlay/vite.config.ts'))
await build({...loaded.config,configFile:false,plugins:[{
 name:'owned-parent-stream-lifetime-observation',enforce:'pre',
 transform(source,id){
  const file=id.replaceAll('\\','/')
  if(file.endsWith('/components/text-part-model.ts')){
   source=replace(source,'export function createStreamingTextPartModel','let renderOwner431 = 0\nexport function createStreamingTextPartModel')
   source=replace(source,'  const [error, setError] = createSignal("")',`  const [error, setError] = createSignal("")
  const traceOwner431 = ++renderOwner431
  console.debug("MD431",JSON.stringify({kind:"create",owner:traceOwner431,at:performance.now()}))
  let traceState431 = ""
  createEffect(() => {
    const state={empty:!frozenHtml().length,pending:pending(),streaming:props.streaming===true,error:error()}
    const key=JSON.stringify(state)
    if(key===traceState431)return
    traceState431=key
    console.debug("MD431",JSON.stringify({kind:"state",owner:traceOwner431,...state,length:props.text.length,at:performance.now()}))
  })
  onCleanup(() => console.debug("MD431",JSON.stringify({kind:"dispose",owner:traceOwner431,at:performance.now()})))`)
   return replace(source,'return { frozenHtml, pending, error }','return { frozenHtml, pending, error, traceOwner431 }')
  }
  if(file.endsWith('/components/TextPart.tsx')){
   source=replace(source,'const { frozenHtml, pending, error } =','const { frozenHtml, pending, error, traceOwner431 } =')
   return replace(source,'<div class={props.className || "msg-text"}','<div data-render-owner={traceOwner431} class={props.className || "msg-text"}')
  }
  if(file.endsWith('/components/SubagentConversationPanel.tsx')){
   source=replace(source,'function SubagentConversationScroll(props:','let scrollOwner431 = 0\nfunction SubagentConversationScroll(props:')
   return replace(source,'  let scrollElement: HTMLDivElement | undefined',`  let scrollElement: HTMLDivElement | undefined
  const traceScroll431 = ++scrollOwner431
  console.debug("SCROLL431",JSON.stringify({kind:"create",owner:traceScroll431,at:performance.now()}))
  onCleanup(() => console.debug("SCROLL431",JSON.stringify({kind:"dispose",owner:traceScroll431,at:performance.now()})))`)
  }
  if(file.endsWith('/components/ChatBubble.tsx')){
   source='import { onCleanup as traceCleanup431 } from "solid-js"\n'+source
   source=replace(source,'export function ChatBubble(props:','let bubbleOwner431 = 0\nexport function ChatBubble(props:')
   return replace(source,'  const align = () => bubbleAlign(props.node)',`  const traceBubble431 = ++bubbleOwner431
  console.debug("BUBBLE431",JSON.stringify({kind:"create",owner:traceBubble431,cardID:props.node.id,at:performance.now()}))
  traceCleanup431(() => console.debug("BUBBLE431",JSON.stringify({kind:"dispose",owner:traceBubble431,at:performance.now()})))
  const align = () => bubbleAlign(props.node)`)
  }
 },
},...(loaded.config.plugins??[])],build:{...loaded.config.build,minify:false,outDir:'C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-15/member-parent-stream-431-bundle/bin/ui'}})
