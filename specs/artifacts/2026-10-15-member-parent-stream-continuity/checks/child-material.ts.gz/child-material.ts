import fs from 'node:fs'
import assert from 'node:assert/strict'
import {Database} from 'bun:sqlite'
const phase=process.argv[2]
if(!['before','after'].includes(phase))throw Error('Explicit phase required')
const file=import.meta.dir+'/child-'+phase+'.json';if(fs.existsSync(file))throw Error('Fresh child receipt required')
const db=new Database('C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/member-live-rendering-412-fresh/runtime/data/opencorvus.db',{readonly:true})
const sessionID='ses_-zUS0WzzQzzDOGrIbYwN'
try {
 db.exec('PRAGMA busy_timeout=5000; BEGIN')
 const session=db.query('SELECT * FROM session WHERE id=?').get(sessionID)
 const messages=db.query('SELECT * FROM message WHERE session_id=? ORDER BY id').all(sessionID)
 const parts=db.query('SELECT p.* FROM part p JOIN message m ON m.id=p.message_id WHERE m.session_id=? ORDER BY p.id').all(sessionID)
 const material={session,messages,parts}
 if(phase==='after')assert.deepEqual(material,JSON.parse(fs.readFileSync(import.meta.dir+'/child-before.json','utf8')).material)
 fs.writeFileSync(file,JSON.stringify({at:new Date().toISOString(),material,boundary:'Read-only exact original child Session, Messages and Parts; no UI assertion or synthetic message'},null,2))
 console.log(JSON.stringify({phase,sessionID,messages:messages.length,parts:parts.length,qualification:phase==='after'?'Original exact persisted member material preserved':'Original persisted member material captured'}))
}finally{db.exec('ROLLBACK');db.close(true)}
