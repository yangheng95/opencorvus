import fs from 'node:fs'
import path from 'node:path'
import zlib from 'node:zlib'
import assert from 'node:assert/strict'
const root=import.meta.dirname,dest=path.resolve('specs/artifacts/2026-10-15-member-parent-stream-continuity')
const evidence='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-15/member-parent-stream-431/evidence'
const read=file=>JSON.parse(fs.readFileSync(file,'utf8'))
const save=(name,bytes)=>{const target=path.join(dest,name);fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,zlib.gzipSync(bytes))}
// Positive persisted-data and physical-settlement contracts; no DOM or screenshot assertions.
const before=read(root+'/before.json'),after=read(root+'/after.json')
const childBefore=read(root+'/child-before.json'),childAfter=read(root+'/child-after.json')
assert.deepEqual(childAfter.material,childBefore.material)
assert.equal(childAfter.material.messages.length,12);assert.equal(childAfter.material.parts.length,29)
assert.equal(before.version.user_version,2);assert.equal(after.version.user_version,2)
const oldIDs=new Set(before.messages.map(row=>row.id)),added=after.messages.filter(row=>!oldIDs.has(row.id))
assert.equal(added.length,3);assert.equal(added[0].role,'user');assert.equal(added[1].finish,'tool-calls');assert.equal(added[2].finish,'stop')
for(const message of added)assert.equal(message.sessionID,'ses_-zUS0X33CzzWEKMgCk98')
assert.equal(after.sources.length,before.sources.length+1)
const clean=read(evidence+'/physical-terminal-and-pair-cleanup.json'),native=read(evidence+'/native-host-settled.json')
assert.equal(clean.physicalCompletion,true);assert.equal(clean.pairedCleanupComplete,true)
assert.equal(native.physicalCompletion,true);assert.equal(native.outputDrainComplete,true);assert.equal(native.requestCleanupComplete,true)
assert.equal(native.terminal.exitCode,0);assert.equal(read(evidence+'/launcher-child-exit.json').childExitCode,0)
assert.equal(read(evidence+'/public-shutdown.json').statusCode,200)
const audits=fs.readdirSync(evidence).filter(name=>/^provider-.*\.json$/.test(name)&&name!=='provider-pair-staging.json').map(name=>({name,value:read(evidence+'/'+name)})).filter(entry=>Array.isArray(entry.value.requests)).sort((a,b)=>b.value.requests.length-a.value.requests.length||Date.parse(b.value.observedAt)-Date.parse(a.value.observedAt))
const last=audits[0];assert(last)
const requests=last.value.requests.map(({model,streaming,status,response_reader})=>({model,streaming,status,response_reader}))
assert.equal(requests.length,5)
for(const request of requests){assert.equal(request.model,'gpt-6.1-sol');assert.equal(request.streaming,true);assert.equal(request.status,200);assert.equal(request.response_reader.state,'settled');assert.equal(request.response_reader.terminal.kind,'eof')}
for(const name of ['native-host-ready.json','native-host-settled.json','physical-terminal-and-pair-cleanup.json','preflight-ready.json','provider-pair-staging.json','public-shutdown.json','launcher-child-exit.json','existing-history-admitted.json','profile-selection-admitted.json'])save('runtime/'+name+'.gz',fs.readFileSync(evidence+'/'+name))
save('runtime/provider-summary.json.gz',JSON.stringify({source:last.name,observedAt:last.value.observedAt,requests},null,2))
const walk=dir=>fs.readdirSync(dir,{withFileTypes:true}).flatMap(entry=>entry.isDirectory()?walk(path.join(dir,entry.name)):[path.join(dir,entry.name)])
for(const file of walk(root+'/original'))save('original/'+path.relative(root+'/original',file)+'.gz',fs.readFileSync(file))
for(const name of fs.readdirSync(root)){
 const file=path.join(root,name)
 if(fs.statSync(file).isFile()&&/\.(ts|mjs|ps1|json|log)$/.test(name)&&name!=='review-result.json')save('checks/'+name+'.gz',fs.readFileSync(file))
}
const result={archivedAt:new Date().toISOString(),observedAt:after.at,requestCount:requests.length,memberMessages:12,memberParts:29,addedParentMessages:added.map(({id,role,finish})=>({id,role,finish})),physicalCompletion:true,pairedCleanupComplete:true,screenshots:fs.readdirSync(dest).filter(name=>name.endsWith('.jpg')),boundary:'Manual real-page observations and positive persisted/settlement contracts; console clipped at 500 entries; diagnostic bundle only; no product code changes or UI automated tests'}
fs.writeFileSync(root+'/review-result.json',JSON.stringify(result,null,2));save('checks/review-result.json.gz',JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2))
