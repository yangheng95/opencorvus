import fs from 'node:fs'
const root=import.meta.dirname,tag='directory-admission-cost-437-before'
const bundle='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-20/'+tag+'-bundle/bin'
if(fs.existsSync(bundle))throw Error('Fresh immutable publication required')
fs.mkdirSync(bundle,{recursive:true});fs.copyFileSync('.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64/bun.exe',bundle+'/bun.exe');fs.cpSync('packages/overlay/dist-vite',bundle+'/ui',{recursive:true})
for(const name of ['launch.ps1','settle.ps1','shutdown.ps1']){
 const source=fs.readFileSync('.tmp-product-iteration/config-write-cost-436/'+name,'utf8')
 .replaceAll('config-write-cost-436-before',tag)
 .replaceAll('.tmp-product-iteration/config-write-cost-436','.tmp-product-iteration/directory-admission-cost-437')
 .replaceAll('18639','18647')
 .replaceAll('Existing 412 v1 database required','Existing owned 412 history database required')
 fs.writeFileSync(root+'/'+name,source)
}
fs.writeFileSync(root+'/prepare-authority.mjs',fs.readFileSync('.tmp-product-iteration/config-write-cost-436/prepare-authority.mjs','utf8').replaceAll('config-write-cost-436-before-authority',tag+'-authority'))
const writer=fs.readFileSync('.tmp-product-iteration/config-write-cost-436/config-write-check.ts','utf8')
 .replace('const port = 18639','const port = 18647')
 .replaceAll('config-write-cost-436-','directory-admission-cost-437-').replaceAll('qa-cost-436','qa-admission-437')
fs.writeFileSync(root+'/config-write-check.ts',writer)
fs.writeFileSync(root+'/capture-cost.mjs',fs.readFileSync('.tmp-product-iteration/config-write-cost-436/capture-cost.mjs','utf8').replaceAll('config-write-cost-436-','directory-admission-cost-437-'))
console.log(JSON.stringify({tag,port:18647,businessInputs:0}))
