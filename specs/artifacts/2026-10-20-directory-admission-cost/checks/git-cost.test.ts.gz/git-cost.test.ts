import { test, expect } from "bun:test"
import { Process } from "../../packages/opencorvus/src/util/process"
import { NodeProcess } from "../../packages/util/src/process-node"
import { gitProcessArgs } from "../../packages/opencorvus/src/util/git"

test("measures fully settled read-only Git command through both owned process adapters", async () => {
  const cwd = "D:/myhexin-local/opencorvus"
  const command = gitProcessArgs(["rev-parse", "--show-toplevel"])
  const samples: unknown[] = []
  for (let index = 0; index < 3; index++) {
    for (const adapter of ["supervised", "owned_process"] as const) {
      const started = performance.now()
      const result = adapter === "supervised"
        ? await Process.runHost(command, { cwd, stdin: "ignore", timeoutMs: 15_000 })
        : await NodeProcess.run({ command: { executable: command[0]!, args: command.slice(1) }, cwd, stdin: "ignore", ownership: "owned_process", timeoutMs: 15_000 })
      const milliseconds = performance.now() - started
      expect("code" in result ? result.code : result.receipt.exitCode).toBe(0)
      expect(Buffer.from(result.stdout).toString().trim().replaceAll("\\", "/").toLowerCase()).toBe(cwd.toLowerCase())
      samples.push({ index, adapter, milliseconds })
    }
  }
  console.log(JSON.stringify({ probe: "git-process-settled", samples }))
})
