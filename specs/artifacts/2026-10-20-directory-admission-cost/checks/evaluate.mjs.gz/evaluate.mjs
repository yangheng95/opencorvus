import fs from 'node:fs'
const root=import.meta.dirname
const before=JSON.parse(fs.readFileSync(root+'/canonical-write-check.json','utf8'))
const after=JSON.parse(fs.readFileSync(root+'/canonical-write-after.json','utf8'))
const checks=[
 {name:'cold canonical write <=10000ms',actualMs:after.writeMs,passed:after.writeMs<=10000},
 {name:'warm canonical write <=5000ms',actualMs:after.restoreMs,passed:after.restoreMs<=5000},
 {name:'canonical accepted and completely restored with Ask',passed:after.accepted&&after.restored&&after.permissionMode==='ask'},
]
const result={status:checks.every(c=>c.passed)?'passed':'failed',before,after,checks,unmeasured:['Concurrent cold-page read <=20000ms'],coldImprovementPercent:100*(1-after.writeMs/before.writeMs)}
fs.writeFileSync(root+'/benchmark-result.json',JSON.stringify(result,null,2),{flag:'wx'})
console.log(JSON.stringify({status:result.status,checks,coldImprovementPercent:result.coldImprovementPercent}))
process.exitCode=result.status==='passed'?0:1
