import fs from 'node:fs'
const root=import.meta.dirname
const base='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-20/'
const bundle=base+'directory-admission-cost-437-after-bundle/bin'
if(fs.existsSync(bundle))throw Error('Fresh immutable publication required')
fs.mkdirSync(bundle,{recursive:true})
fs.copyFileSync(base+'directory-admission-cost-437-before-bundle/bin/bun.exe',bundle+'/bun.exe')
fs.cpSync('packages/overlay/dist-vite',bundle+'/ui',{recursive:true})
for(const name of ['launch','settle','shutdown']){
 let source=fs.readFileSync(root+'/'+name+'.ps1','utf8')
  .replaceAll('directory-admission-cost-437-before','directory-admission-cost-437-after')
  .replaceAll('directory-admission-cost-437-after-authority','directory-admission-cost-437-before-authority')
  .replaceAll('18647','18649')
 if(name==='launch')source=source.replaceAll('/settle.ps1','/settle-after.ps1')
 fs.writeFileSync(root+'/'+name+'-after.ps1',source,{flag:'wx'})
}
fs.writeFileSync(root+'/config-write-after.ts',fs.readFileSync(root+'/config-write-check.ts','utf8')
 .replace('phase === "before"','phase === "after"').replace('const port = 18647','const port = 18649')
 .replace('canonical-write-check.json','canonical-write-after.json'),{flag:'wx'})
console.log(JSON.stringify({port:18649,bundle,phase:'after',uiSource:'435 formal unchanged UI build'}))
