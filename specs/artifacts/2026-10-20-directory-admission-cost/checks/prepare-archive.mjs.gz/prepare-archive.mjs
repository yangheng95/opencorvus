import fs from 'node:fs'
const root=import.meta.dirname
let source=fs.readFileSync('.tmp-product-iteration/config-write-cost-436/archive.mjs','utf8')
 .replaceAll('2026-10-20-config-write-cost','2026-10-20-directory-admission-cost')
 .replaceAll('config-write-cost-436','directory-admission-cost-437')
 .replace("['before','after','verified','final']","['before','after']")
 .replace('physicalScopes:4','physicalScopes:2')
fs.writeFileSync(root+'/archive.mjs',source,{flag:'wx'})
console.log('Prepared exact two-scope physical settlement archive and private pair retirement')
