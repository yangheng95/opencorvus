const fs=require('node:fs'),path=require('node:path');
const scratch=path.resolve('.tmp-product-iteration/member-live-rendering-412');
let facts=fs.readFileSync('.tmp-product-iteration/execution-actor-identity-390/read-facts.ts','utf8');
facts=facts.replace("'.tmp-product-iteration/execution-actor-identity-390'","'.tmp-product-iteration/member-live-rendering-412'");
fs.writeFileSync(path.join(scratch,'read-facts.ts'),facts,{flag:'wx'});
const bundle='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/member-live-rendering-412-bundle';
fs.mkdirSync(path.join(bundle,'bin'),{recursive:true});
fs.copyFileSync('.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64/bun.exe',path.join(bundle,'bin/bun.exe'),fs.constants.COPYFILE_EXCL);
console.log(JSON.stringify({bundle,scratch}));
