const fs=require('node:fs'),path=require('node:path'),zlib=require('node:zlib'),assert=require('node:assert/strict');
const scratch=path.resolve('.tmp-product-iteration/member-live-rendering-412');
const out=path.resolve('specs/artifacts/2026-10-14-member-live-rendering');
const read=p=>JSON.parse(fs.readFileSync(p,'utf8').replace(/^\uFEFF/,''));
const json=(p,value)=>fs.writeFileSync(p,JSON.stringify(value,null,2)+'\n',{flag:'wx'});
const copy=(source,target)=>{fs.mkdirSync(path.dirname(target),{recursive:true});fs.copyFileSync(source,target,fs.constants.COPYFILE_EXCL)};
const zip=(source,target)=>{fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,zlib.gzipSync(fs.readFileSync(source)),{flag:'wx'})};
const before=read(path.join(scratch,'fresh-final.json')),after=read(path.join(scratch,'fresh-recovered.json'));
assert.deepEqual(before.databaseVersion,[{user_version:1}]);assert.deepEqual(after.databaseVersion,before.databaseVersion);
for(const key of ['messages','parts','tools','outcomes']){
 const id=key==='outcomes'?'requestPartID':'id';
 for(const row of before[key])assert.deepEqual(after[key].find(candidate=>candidate[id]===row[id]),row,`Retained ${key} ${row[id]}`);
}
const request=read(path.join(scratch,'prompt-request.json')),response=read(path.join(scratch,'prompt-response.json'));
const member='ses_-zUS0WzzQzzDOGrIbYwN',parent='ses_-zUS0X33CzzWEKMgCk98';
assert.equal(after.sessions.find(s=>s.id===member).parent_id,parent);
const user=after.messages.find(m=>m.id===request.body.messageID);assert.equal(user.role,'user');assert.equal(user.sessionID,member);
assert.equal(after.parts.filter(p=>p.messageID===user.id&&p.type==='text').map(p=>p.text).join(''),request.body.parts[0].text);
assert.equal(response.status,200);assert.equal(response.result.info.finish,'stop');
const assistant=after.messages.find(m=>m.id===response.result.info.id);assert.equal(assistant.sessionID,member);assert.equal(assistant.parentID,user.id);assert.equal(assistant.finish,'stop');assert.ok(assistant.time.completed>0);
const body=after.parts.filter(p=>p.messageID===assistant.id&&p.type==='text').map(p=>p.text).join('');
assert.equal(body,response.result.parts.filter(p=>p.type==='text').map(p=>p.text).join(''));
const sources=after.parts.filter(p=>p.type==='source-file');
for(const source of sources){
 const tool=after.tools.find(t=>t.id===source.toolPartID);assert.equal(tool.tool,'read');assert.equal(tool.messageID,source.messageID);assert.equal(tool.input.offset,2);assert.equal(tool.input.limit,2);
 assert.deepEqual(source.range,{startLine:2,endLine:3});assert.equal(path.basename(source.path),'README.md');
 assert.equal(after.outcomes.find(o=>o.requestPartID===tool.id).outcome,'completed');
}
json(path.join(out,'persisted-check.json'),{databaseVersion:after.databaseVersion,member,parent,retained:{messages:before.messages.length,parts:before.parts.length,tools:before.tools.length,outcomes:before.outcomes.length},userMessageID:user.id,assistantMessageID:assistant.id,finish:assistant.finish,bodyLength:body.length,sources:sources.map(p=>({id:p.id,messageID:p.messageID,toolPartID:p.toolPartID,path:p.path,range:p.range})),authority:'Read-only production SQLite records; exact retained IDs and payloads, real public input/result and completed read bindings. This is not UI acceptance.'});
for(const file of ['fresh-initial.json','fresh-final.json','fresh-recovered.json','prompt-request.json','prompt-response.json'])zip(path.join(scratch,file),path.join(out,'facts',file+'.gz'));
for(const file of fs.readdirSync(scratch).filter(x=>/^\d\d-.*\.jpg$/.test(x)))copy(path.join(scratch,file),path.join(out,file));
const scopes=[];
for(const [label,namespace] of [['legacy-rejected','member-live-rendering-412-live'],['before','member-live-rendering-412-fresh-diagnostic'],['after','member-live-rendering-412-after']]){
 const dir=`C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/${namespace}/evidence`;
 const target=path.join(out,label);fs.mkdirSync(target,{recursive:true});
 for(const name of ['native-host-ready.json','native-host-settled.json','physical-terminal-and-pair-cleanup.json','launcher-child-exit.json'])copy(path.join(dir,name),path.join(target,name));
 for(const name of ['preflight-ready.json','failed.json','public-shutdown.json','project-baseline.json','existing-history-admitted.json'])if(fs.existsSync(path.join(dir,name)))copy(path.join(dir,name),path.join(target,name));
 const audits=fs.readdirSync(dir).filter(x=>x.startsWith('provider-')&&x.endsWith('.json')).map(name=>({name,data:read(path.join(dir,name))})).filter(x=>Array.isArray(x.data.requests)&&typeof x.data.observedAt==='string').sort((a,b)=>Date.parse(a.data.observedAt)-Date.parse(b.data.observedAt));
 const audit=audits.at(-1);if(audit)copy(path.join(dir,audit.name),path.join(target,'provider-audit.json'));
 const native=read(path.join(dir,'native-host-settled.json')),cleanup=read(path.join(dir,'physical-terminal-and-pair-cleanup.json'));
 assert.equal(native.physicalCompletion,true);assert.equal(native.outputDrainComplete,true);assert.equal(native.requestCleanupComplete,true);assert.equal(cleanup.pairedCleanupComplete,true);
 if(label==='legacy-rejected')assert.equal(read(path.join(dir,'failed.json')).error.name,'DatabaseUnavailableError');
 else {assert.equal(native.terminal.reason,'exited');assert.equal(native.terminal.exitCode,0);assert.ok(audit.data.requests.length>0)}
 for(const r of audit?.data.requests??[]){assert.equal(r.model,'gpt-6.1-sol');assert.equal(r.streaming,true);assert.equal(r.status,200);assert.equal(r.response_reader.state,'settled');assert.equal(r.response_reader.terminal.kind,'eof')}
 scopes.push({label,occurrence:native.occurrence,requests:audit?.data.requests.length??null,nativeTerminal:native.terminal,physicalCompletion:true,outputDrainComplete:true,requestCleanupComplete:true,pairedCleanupComplete:true});
}
json(path.join(out,'execution-summary.json'),{scopes,toolJoins:{legacy:{chunk:'f4fc87',exitCode:1},before:{handle:42056,chunk:'1114aa',exitCode:0},after:{handle:31830,chunk:'7db3eb',exitCode:0},publicPrompt:{handle:55177,chunk:'d986d1',exitCode:0}},builds:{first:{exitCode:1,reason:'Wrong Vite entry path; MODULE_NOT_FOUND'},before:{handle:47107,exitCode:0},after:{handle:48085,exitCode:0}},typecheck:{handle:28642,exitCode:0},screenshots:11,browserBoundary:'Own product pages 28 and 29 closed. Error tab 27 could not be rebound or manually closed because Browser Use rejected its internal data URL; no preservation mark, no bypass.'});
for(const name of ['ui-build-first.log','ui-build.log','ui-build-after.log','typecheck.log','launch.log','launch-fresh.log','launch-after.log','send-after.log','read-final.log','launch.ps1','settle.ps1','launch-fresh.ps1','settle-fresh.ps1','shutdown-fresh.ps1','launch-after.ps1','settle-after.ps1','shutdown-after.ps1','read-fresh.ts','send-after.ts','prepare.cjs','prepare-run.cjs','prepare-fresh.cjs','prepare-after.cjs','archive.cjs'])zip(path.join(scratch,name),path.join(out,'execution',name+'.gz'));
for(const suffix of ['', '-fresh','-after'])zip(`.tmp-product-iteration/live-sol-member-rendering-412${suffix}.ts`,path.join(out,`execution/live-sol-member-rendering-412${suffix}.ts.gz`));
for(const name of ['push.log','push-exit.json','fetch-after-race.log','merge-after-race.log','push-after-race.log','push-after-race-exit.json','remote-after-push.txt'])zip(path.join('.tmp-product-iteration/clipboard-first-observation-411',name),path.join(out,'previous-411',name+'.gz'));
console.log(JSON.stringify({scopes,bodyLength:body.length,sources:sources.length,retainedMessages:before.messages.length,screenshots:11},null,2));
