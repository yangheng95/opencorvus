import fs from 'node:fs'
import path from 'node:path'
import {Identifier} from '../../packages/opencorvus/src/id/id'
const directory='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/member-live-rendering-412-fresh/project'
const sessionID='ses_-zUS0WzzQzzDOGrIbYwN'
const messageID=Identifier.ascending('message')
const text='这是既有成员会话的单次界面验收输入。请独立读取“README.md”第2—3行，核实已有价格与交付信息。随后直接写一篇约1800字的中文说明，分成12个有编号的小节，介绍如何区分材料事实、待确认事项和合理推断；小节之间连续输出，不等待我的回复。开头给出准确的材料事实，末尾附一个简短Markdown核对表。材料未提供的价格、日期或条件明确标为待确认。只做本次读取与说明，不创建或调用其他成员，不修改任何文件。'
const body={messageID,agent:'work',model:{providerID:'openai',modelID:'gpt-6.1-sol'},parts:[{type:'text',text}]}
const url=new URL(`http://127.0.0.1:18527/session/${sessionID}/message`);url.searchParams.set('directory',directory)
fs.writeFileSync(path.join(import.meta.dir,'prompt-request.json'),JSON.stringify({url:String(url),body,observedAt:new Date().toISOString()},null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({sent:true,sessionID,messageID,at:new Date().toISOString()}))
const response=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body),signal:AbortSignal.timeout(180000)})
const result=await response.json()
fs.writeFileSync(path.join(import.meta.dir,'prompt-response.json'),JSON.stringify({status:response.status,result,observedAt:new Date().toISOString()},null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({status:response.status,sessionID,messageID,responseMessageID:result.info?.id,finish:result.info?.finish,error:result.info?.error,parts:result.parts?.map((p:any)=>({id:p.id,type:p.type,length:p.text?.length}))}))
if(!response.ok)process.exitCode=1
