const fs=require('node:fs'),path=require('node:path');
const root=__dirname;
for(const name of ['launch','settle','shutdown']) {
  let code=fs.readFileSync(path.join(root,name+'.ps1'),'utf8')
    .replaceAll('dual-member-sources-416-live','dual-member-sources-416-after')
    .replaceAll('18541','18543')
    .replace('"48" "Task"','"12" "NativeService"');
  if(name==='launch') code=code.replace("/settle.ps1'", "/settle-after.ps1'");
  fs.writeFileSync(path.join(root,name+'-after.ps1'),code,{flag:'wx'});
}
const bundle='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/dual-member-sources-416-after-bundle';
fs.mkdirSync(path.join(bundle,'bin'),{recursive:true});
fs.copyFileSync('.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64/bun.exe',path.join(bundle,'bin/bun.exe'),fs.constants.COPYFILE_EXCL);
console.log(JSON.stringify({bundle,port:18543,qualification:'NativeService',requestBudget:12,nativeMaximumMs:600000}));
