const fs=require('node:fs'),path=require('node:path');
const root=path.resolve('.tmp-product-iteration/dual-member-sources-416');
for(const name of ['launch','settle','shutdown','create-task']){
 let code=fs.readFileSync('.tmp-product-iteration/task-acceptance-receipt-415/'+name+'.ps1','utf8')
 .replaceAll('task-acceptance-receipt-415','dual-member-sources-416').replaceAll('18539','18541')
 .replaceAll('active-task-dock-414-after-bundle','dual-member-sources-416-live-bundle')
 .replace('"40" "Task"','"48" "Task"');
 if(name==='create-task')code=code.replaceAll('指导即时受理 415','双成员来源 416').replaceAll('product-experience-415','product-experience-416')
 .replace(/^\$taskRequest=.*$/m,"$taskRequest='请安排两位独立读取成员，可并行完成。一位只用read读取本项目README.md第2行（offset=2,limit=1），给出约900字中文价格字段说明；另一位只用read读取第3行（offset=3,limit=1），给出约900字中文交付字段说明。两位分别直接交付各自正文，包含清楚的小标题、来源行号和仅用于界面测试的限定；各自围绕实际读取到的字段解释含义、信息边界、展示建议和一个明确标为示例的表达，不编造原文没有的条款。每位必须保留自己实际读取的原始行号，不能用另一位的转述代替独立读取。不需要外部搜索，不运行shell，不修改文件。这个Task用于体验两个成员之间的切换、Sources归属和阅读位置。'");
 fs.writeFileSync(path.join(root,name+'.ps1'),code,{flag:'wx'});
}
fs.copyFileSync('.tmp-product-iteration/task-acceptance-receipt-415/read-facts.ts',path.join(root,'read-facts.ts'),fs.constants.COPYFILE_EXCL);
const bundle='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/dual-member-sources-416-live-bundle';
fs.mkdirSync(path.join(bundle,'bin'),{recursive:true});fs.copyFileSync('.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64/bun.exe',path.join(bundle,'bin/bun.exe'),fs.constants.COPYFILE_EXCL);
console.log(JSON.stringify({bundle,port:18541,maxRequests:48,nativeMaximumMs:600000}));
