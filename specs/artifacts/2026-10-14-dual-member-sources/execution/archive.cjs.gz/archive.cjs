const fs=require('node:fs'),path=require('node:path'),z=require('node:zlib'),assert=require('node:assert/strict');
const scratch=__dirname,out=path.resolve('specs/artifacts/2026-10-14-dual-member-sources');
const read=p=>JSON.parse(fs.readFileSync(p,'utf8'));
const write=(p,b)=>{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,b,{flag:'wx'})};
const json=(n,v)=>write(path.join(out,n),JSON.stringify(v,null,2)+'\n');
const copy=(a,b)=>write(b,fs.readFileSync(a)),zip=(a,b)=>write(b,z.gzipSync(fs.readFileSync(a)));
const before=read(path.join(scratch,'facts-before-final.json')),after=read(path.join(scratch,'facts-after-final.json'));
const prior=read(path.join(scratch,'facts-prior-after.json')),old=read('.tmp-product-iteration/task-acceptance-receipt-415/facts-final.json');
const retain=(earlier,later)=>{
 assert.equal(earlier.task.id,later.task.id);
 for(const kind of ['messages','parts','tools','outcomes'])for(const item of earlier[kind])assert.deepEqual(later[kind].find(x=>(x.id??x.requestPartID)===(item.id??item.requestPartID)),item);
 for(const a of earlier.artifacts)assert.deepEqual(later.artifacts.find(x=>x.id===a.id)?.payload,a.payload);
 return {taskID:earlier.task.id,messages:earlier.messages.length,parts:earlier.parts.length,tools:earlier.tools.length,artifacts:earlier.artifacts.length};
};
const retention=[retain(before,after),retain(old,prior)];
const sources=[
 {sessionID:'ses_hdvEOzMlLHl6S8MoqpRU',partID:'prt_g0VY045Vq00G05gcZV75',line:2},
 {sessionID:'ses_ha8862QlAlLJD7Ku0sM0',partID:'prt_g0VY04LWg00GMoipa9RF',line:3},
].map(expected=>{
 const p=after.parts.find(p=>p.id===expected.partID),m=after.messages.find(m=>m.id===p.messageID),tool=after.tools.find(t=>t.id===p.toolPartID);
 assert.equal(m.sessionID,expected.sessionID);assert.equal(p.type,'source-file');assert.deepEqual(p.range,{startLine:expected.line,endLine:expected.line});
 assert.equal(tool.tool,'read');assert.equal(after.outcomes.find(o=>o.requestPartID===tool.id)?.outcome,'completed');
 return {...expected,messageID:m.id,toolPartID:tool.id,path:p.path,range:p.range};
});
const runs=[];
for(const phase of ['live','after']){
 const dir=`C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/dual-member-sources-416-${phase}/evidence`;
 const native=read(path.join(dir,'native-host-settled.json')),cleanup=read(path.join(dir,'physical-terminal-and-pair-cleanup.json'));
 assert.equal(native.terminal.reason,'exited');assert.equal(native.terminal.exitCode,0);
 for(const k of ['physicalCompletion','outputDrainComplete','requestCleanupComplete'])assert.equal(native[k],true);
 assert.equal(cleanup.pairedCleanupComplete,true);
 const audit=fs.readdirSync(dir).filter(n=>n.startsWith('provider-')&&n.endsWith('.json')).map(n=>({n,v:read(path.join(dir,n))})).filter(x=>Array.isArray(x.v.requests)&&x.v.observedAt).sort((a,b)=>Date.parse(a.v.observedAt)-Date.parse(b.v.observedAt)).at(-1);
 for(const r of audit.v.requests){assert.equal(r.model,'gpt-6.1-sol');assert.equal(r.streaming,true);assert.equal(r.status,200);assert.equal(r.response_reader.state,'settled');assert.equal(r.response_reader.terminal.kind,'eof')}
 const files=['native-host-ready.json','native-host-settled.json','physical-terminal-and-pair-cleanup.json','launcher-child-exit.json','preflight-ready.json','public-shutdown.json'];
 if(phase==='live'){
  const complete=read(path.join(dir,'task-complete.json'));assert.equal(complete.lifecycle.status,'completed');assert.equal(complete.selected.taskID,after.task.id);
  files.push('task-boundary-admitted.json','task-occurrence-admitted.json','task-complete.json');
 }
 for(const n of files)copy(path.join(dir,n),path.join(out,phase,n));
 copy(path.join(dir,audit.n),path.join(out,phase,'provider-audit.json'));
 runs.push({phase,requests:audit.v.requests.length,occurrence:native.occurrence,terminal:native.terminal,physicalCompletion:true,pairedCleanupComplete:true});
}
json('persisted-check.json',{taskID:after.task.id,projectID:after.task.project_id,databaseVersion:after.databaseVersion,sources,retention,boundary:'Read-only actual SQLite facts and real provider/native evidence. UI conclusions rely on original screenshots and manual interaction; after run reads the same completed Task, not a new live multi-member qualification.'});
json('execution-summary.json',{runs,handles:read(path.join(scratch,'joined-handles.json'))});
for(const n of fs.readdirSync(scratch)){
 if(/^\d\d-.*\.jpg$/.test(n))copy(path.join(scratch,n),path.join(out,n));
 else if(/^(facts-.*|task-(request|accepted|selection))\.json$/.test(n))zip(path.join(scratch,n),path.join(out,'facts',n+'.gz'));
 else if(/\.(ps1|cjs|ts|log)$/.test(n)&&!n.startsWith('archive-check')&&!n.startsWith('commit')&&!n.startsWith('prepare-commit'))zip(path.join(scratch,n),path.join(out,'execution',n+'.gz'));
}
zip('.tmp-product-iteration/live-sol-task-guidance-413.ts',path.join(out,'execution/live-sol-task-guidance-413.ts.gz'));
console.log(JSON.stringify({status:'qualified',runs,sources,retention}));
