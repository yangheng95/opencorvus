$ErrorActionPreference='Stop'
$taskDiag='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/dual-member-sources-416-live'
$taskRun='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/member-live-rendering-412-fresh'
$taskScratch='D:/myhexin-local/opencorvus/.tmp-product-iteration/dual-member-sources-416'
$taskReady=Get-Content -Raw -LiteralPath "$taskDiag/evidence/native-host-ready.json"|ConvertFrom-Json
$taskPreflight=Get-Content -Raw -LiteralPath "$taskDiag/evidence/preflight-ready.json"|ConvertFrom-Json
$taskAuthority=Get-Content -Raw -LiteralPath "$taskDiag/evidence/authority-ready.json"|ConvertFrom-Json
if($taskReady.occurrence -cne $taskPreflight.occurrence -or $taskReady.target.pid -ne $taskPreflight.pid -or $taskPreflight.preflight.actualModel -cne 'gpt-6.1-sol' -or !$taskPreflight.preflight.streaming -or $taskPreflight.preflight.credential -cne 'usable' -or $taskPreflight.preflight.catalog -cne 'projected'){throw 'Actual paired provider preflight required'}
if($taskAuthority.pid -ne $taskReady.target.pid -or $taskAuthority.admission.packageRevision.id -cne 'base' -or $taskAuthority.admission.packageRevision.scope -cne 'built_in'){throw 'Actual builtin Base target required'}
. 'D:/myhexin-local/opencorvus/.tmp-product-iteration/live-sol-long-source-reading-406-launch.ps1' -FunctionsOnly
if((Get-OwnedNativeState $taskReady.target) -cne 'exact_live'){throw 'Exact owned target required'}
$taskSelectionPath="$taskRun/dual-member-sources-416-selection.json"
if(Test-Path -LiteralPath $taskSelectionPath){throw 'This occurrence already has an accepted Task'}
$taskRequest='请安排两位独立读取成员，可并行完成。一位只用read读取本项目README.md第2行（offset=2,limit=1），给出约900字中文价格字段说明；另一位只用read读取第3行（offset=3,limit=1），给出约900字中文交付字段说明。两位分别直接交付各自正文，包含清楚的小标题、来源行号和仅用于界面测试的限定；各自围绕实际读取到的字段解释含义、信息边界、展示建议和一个明确标为示例的表达，不编造原文没有的条款。每位必须保留自己实际读取的原始行号，不能用另一位的转述代替独立读取。不需要外部搜索，不运行shell，不修改文件。这个Task用于体验两个成员之间的切换、Sources归属和阅读位置。'
$taskRequestID=[Guid]::NewGuid().ToString()
$taskOriginal=@{};Get-ChildItem Env:|ForEach-Object {$taskOriginal[$_.Name]=$_.Value}
$taskEnv=@{};foreach($taskKey in @('PATH','SystemRoot','WINDIR','ComSpec','PATHEXT','LANG','LC_ALL','LC_CTYPE')){if($taskOriginal.ContainsKey($taskKey)){$taskEnv[$taskKey]=$taskOriginal[$taskKey]}}
$taskClient="$taskDiag/cli-home";New-Item -ItemType Directory -Path $taskClient,"$taskDiag/cli-temp","$taskDiag/cli-runtime" -Force|Out-Null
foreach($taskKey in @('USERPROFILE','APPDATA','LOCALAPPDATA','XDG_CONFIG_HOME','XDG_DATA_HOME','XDG_CACHE_HOME','XDG_STATE_HOME')){$taskEnv[$taskKey]=$taskClient}
$taskEnv.OPENCORVUS_HOME="$taskDiag/cli-runtime";$taskEnv.OPENCORVUS_DISABLE_EXTERNAL_SKILLS='1';$taskEnv.OPENCORVUS_DISABLE_AUTOUPDATE='1';$taskEnv.OPENCORVUS_TASK_PROCESS_MODE='native'
foreach($taskKey in @('TEMP','TMP','TMPDIR')){$taskEnv[$taskKey]="$taskDiag/cli-temp"}
$taskEnv.HOMEDRIVE='C:';$taskEnv.HOMEPATH=([IO.Path]::GetFullPath($taskClient)).Substring(2)
try{
 Get-ChildItem Env:|ForEach-Object {[Environment]::SetEnvironmentVariable($_.Name,$null,'Process')}
 foreach($taskKey in $taskEnv.Keys){[Environment]::SetEnvironmentVariable($taskKey,$taskEnv[$taskKey],'Process')}
 $taskSent=[DateTime]::UtcNow.ToString('o')
 @{requestID=$taskRequestID;request=$taskRequest;requestSentAt=$taskSent;directory="$taskRun/project"}|ConvertTo-Json|Set-Content -LiteralPath "$taskScratch/task-request.json"
 & 'D:/myhexin-local/opencorvus/.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64/bun.exe' 'D:/myhexin-local/opencorvus/packages/opencorvus/src/index.ts' task create --url http://127.0.0.1:18541 --dir "$taskRun/project" --pillar work --expert-squad base --request $taskRequest --title '双成员来源 416' --model openai/gpt-6.1-sol --request-id $taskRequestID --source product-experience-416 --format json 1> "$taskScratch/task-accepted.json" 2> "$taskScratch/task-create.log"
 $taskExit=$LASTEXITCODE
 if($taskExit -ne 0){throw "Actual Task CLI exit $taskExit"}
 $taskAcceptedAt=[DateTime]::UtcNow.ToString('o');$taskAccepted=Get-Content -Raw -LiteralPath "$taskScratch/task-accepted.json"|ConvertFrom-Json
 if(!$taskAccepted.task_id -or $taskAccepted.project_id -cne $taskAuthority.admission.projectID -or [IO.Path]::GetFullPath($taskAccepted.directory) -cne [IO.Path]::GetFullPath("$taskRun/project")){throw 'Actual Task acceptance identity mismatch'}
 $taskSelection=@{occurrence=$taskReady.occurrence;taskID=$taskAccepted.task_id;projectID=$taskAccepted.project_id;directory=$taskAccepted.directory;productPillar='work';requestID=$taskRequestID;requestSentAt=$taskSent;acceptedObservedAt=$taskAcceptedAt}
 Write-OwnedLaunchFact "$taskScratch/task-selection.json" $taskSelection
 Write-OwnedLaunchFact $taskSelectionPath $taskSelection
 $taskSelection|ConvertTo-Json
}finally{
 Get-ChildItem Env:|ForEach-Object {[Environment]::SetEnvironmentVariable($_.Name,$null,'Process')}
 foreach($taskKey in $taskOriginal.Keys){[Environment]::SetEnvironmentVariable($taskKey,$taskOriginal[$taskKey],'Process')}
}
