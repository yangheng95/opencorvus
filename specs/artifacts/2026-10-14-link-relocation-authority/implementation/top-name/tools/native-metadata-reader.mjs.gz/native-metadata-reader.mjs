/** Current shared scratch ABI reader; Koffi is loaded only when explicitly called. */
import assert from "node:assert/strict"
import fs from "node:fs/promises"
import path from "node:path"
import { createRequire } from "node:module"

export function originalError(error, seen = new Map()) {
  if (typeof error === "bigint") return { type: "bigint", value: String(error) }
  if (error === undefined) return { type: "undefined" }
  if (error === null || typeof error !== "object") return { type: typeof error, value: String(error) }
  if (seen.has(error)) return { reference: seen.get(error) }
  const identity = seen.size + 1
  seen.set(error, identity)
  const properties = {}
  for (const name of Object.getOwnPropertyNames(error)) properties[name] = originalError(error[name], seen)
  return { identity, type: error instanceof Error ? error.name : "Object", properties }
}

export async function createNativeMetadataReader(input, publish) {
  await publish({ type: "reader-stage", stage: "single-koffi-load" })
  const packageRequire = createRequire(input.packageAnchor)
  const entryPath = packageRequire.resolve("koffi")
  const packagePath = path.join(path.dirname(entryPath), "package.json")
  const packageInfo = JSON.parse(await fs.readFile(packagePath, "utf8"))
  assert.equal(packageInfo.version, input.koffiVersion)
  const koffi = packageRequire("koffi")
  assert.equal(koffi.version, input.koffiVersion)
  const nativeModules = Object.values(packageRequire.cache).filter((item) => item?.filename?.endsWith(".node"))
  const addons = []
  for (const item of nativeModules) addons.push({ cacheFilename: item.filename, physicalPath: await fs.realpath(item.filename), loaded: item.loaded, exportedVersion: item.exports?.version })
  const library = { packageAnchor: input.packageAnchor, entryPath, physicalEntry: await fs.realpath(entryPath), packagePath, packageVersion: packageInfo.version, nativeVersion: koffi.version, addons }
  await publish({ type: "actual-library", library })
  assert.equal(addons.length, 1, "Exactly one observed loaded native addon is required; do not infer an unobserved path")
  assert.equal(addons[0].exportedVersion, input.koffiVersion)
  assert.ok(addons[0].physicalPath.toLowerCase().includes(`${path.sep}@koromix${path.sep}koffi-win32-x64${path.sep}`), "Observed addon must be the declared installed Windows x64 package")

  await publish({ type: "reader-stage", stage: "fixed-win32-abi" })
  const kernel = koffi.load("kernel32.dll")
  const HANDLE = koffi.pointer("DIRECTORY_TARGET_METADATA_HANDLE", koffi.opaque())
  const TAG_INFO = koffi.struct("DIRECTORY_TARGET_FILE_ATTRIBUTE_TAG_INFO", { FileAttributes: "uint32_t", ReparseTag: "uint32_t" })
  const abi = { handleBytes: koffi.sizeof(HANDLE), bufferSize: koffi.sizeof(TAG_INFO), fields: { FileAttributes: koffi.offsetof(TAG_INFO, "FileAttributes"), ReparseTag: koffi.offsetof(TAG_INFO, "ReparseTag") } }
  assert.deepEqual(abi, { handleBytes: 8, bufferSize: 8, fields: { FileAttributes: 0, ReparseTag: 4 } })
  const create = kernel.func("DIRECTORY_TARGET_METADATA_HANDLE __stdcall CreateFileW(const char16_t *lpFileName, uint32_t dwDesiredAccess, uint32_t dwShareMode, void *lpSecurityAttributes, uint32_t dwCreationDisposition, uint32_t dwFlagsAndAttributes, void *hTemplateFile)")
  const query = kernel.func("int __stdcall GetFileInformationByHandleEx(DIRECTORY_TARGET_METADATA_HANDLE hFile, int FileInformationClass, _Out_ DIRECTORY_TARGET_FILE_ATTRIBUTE_TAG_INFO *lpFileInformation, uint32_t dwBufferSize)")
  const lastError = kernel.func("uint32_t __stdcall GetLastError()")
  const close = kernel.func("int __stdcall CloseHandle(DIRECTORY_TARGET_METADATA_HANDLE hObject)")
  const getFinalPath = kernel.func("uint32_t __stdcall GetFinalPathNameByHandleW(DIRECTORY_TARGET_METADATA_HANDLE hFile, _Out_ char16_t *lpszFilePath, uint32_t cchFilePath, uint32_t dwFlags)")
  const getShortPath = kernel.func("uint32_t __stdcall GetShortPathNameW(const char16_t *lpszLongPath, _Out_ char16_t *lpszShortPath, uint32_t cchBuffer)")
  assert.equal(koffi.sizeof("char16_t"), 2)
  const INVALID = (1n << 64n) - 1n
  const invalid = (handle) => handle === null || handle === undefined || (typeof handle === "bigint" && BigInt.asUintN(64, handle) === INVALID)
  await publish({ type: "abi-layout", abi, nativeInput: input.nativeInput })
  await publish({ type: "entry-name-abi", codeUnitBytes: 2, finalPathFlags: 0,
    finalPathFlagsMeaning: "FILE_NAME_NORMALIZED | VOLUME_NAME_DOS", sizeThenReadCalls: 2,
    maximumCodeUnits: 32768, outputBufferInitialByte: 165, nativeHandleSource: "Same original NOFOLLOW CreateFileW handle as FileAttributeTagInfo" })

  function readWidePath(operation, subject, invoke) {
    const result = { operation, subject, sizeCall: null, readCall: null, path: null, failures: [] }
    try {
      const required = invoke(null, 0)
      const sizeError = lastError()
      result.sizeCall = { suppliedCodeUnits: 0, returnValue: required, lastError: sizeError,
        lastErrorMeaning: required ? "observed-stale-on-size-result" : "failure-code" }
      if (!required) result.failures.push({ kind: "win32", operation, phase: "size", subject, win32Error: sizeError, rawReturn: required })
      else if (!Number.isInteger(required) || required < 1 || required > 32768) result.failures.push({
        kind: "native-buffer-contract", operation, phase: "size", subject, rawReturn: required, maximumCodeUnits: 32768 })
      else {
        const buffer = Buffer.alloc(required * 2, 0xa5)
        const written = invoke(buffer, required)
        const readError = lastError()
        result.readCall = { suppliedCodeUnits: required, returnValue: written, lastError: readError,
          lastErrorMeaning: written ? "observed-stale-on-nonzero-result" : "failure-code",
          completeAllocatedBufferBase64: buffer.toString("base64"), allocatedBytes: buffer.length }
        if (!written) result.failures.push({ kind: "win32", operation, phase: "read", subject, win32Error: readError, rawReturn: written })
        else if (!Number.isInteger(written) || written >= required) result.failures.push({
          kind: "native-buffer-contract", operation, phase: "read", subject, rawReturn: written,
          suppliedCodeUnits: required, reason: "Returned length does not fit original sized buffer; no resize/retry" })
        else {
          result.readCall.terminatorCodeUnit = buffer.readUInt16LE(written * 2)
          result.readCall.returnedUtf16CodeUnits = Array.from({ length: written }, (_, index) => buffer.readUInt16LE(index * 2))
          result.readCall.returnedUtf16LEBase64 = buffer.subarray(0, written * 2).toString("base64")
          result.path = buffer.toString("utf16le", 0, written * 2)
          if (result.readCall.terminatorCodeUnit !== 0 || result.path.includes("\0")) result.failures.push({
            kind: "native-buffer-contract", operation, phase: "termination", subject,
            terminatorCodeUnit: result.readCall.terminatorCodeUnit, embeddedNul: result.path.includes("\0") })
        }
      }
    } catch (error) { result.failures.push({ kind: "host-or-ffi", operation, subject, error: originalError(error) }) }
    result.firstCause = result.failures[0] ?? null
    return result
  }

  function read(operand, includeEntryName = false) {
    const native = { open: null, query: null, close: { status: "not-opened" }, failures: [] }
    let handle
    try {
      handle = create(operand, 0, 7, null, 3, 0x00200000 | 0x02000000, null)
      const openError = lastError()
      native.open = { returnValue: handle, lastError: openError, lastErrorMeaning: invalid(handle) ? "failure-code" : "observed-stale-on-success" }
      if (invalid(handle)) native.failures.push({ kind: "win32", operation: "CreateFileW", win32Error: openError, operand, rawReturn: handle })
      else {
        const info = {}
        const accepted = query(handle, 9, info, 8)
        const queryError = lastError()
        native.query = { returnValue: accepted, lastError: queryError, lastErrorMeaning: accepted ? "observed-stale-on-success" : "failure-code", output: { ...info } }
        if (!accepted) native.failures.push({ kind: "win32", operation: "GetFileInformationByHandleEx", win32Error: queryError, operand, rawReturn: accepted })
        else if (includeEntryName) {
          native.finalPath = readWidePath("GetFinalPathNameByHandleW", { operand, handle, flags: 0 }, (buffer, count) => getFinalPath(handle, buffer, count, 0))
          native.failures.push(...native.finalPath.failures)
        }
      }
    } catch (error) { native.failures.push({ kind: "host-or-ffi", error: originalError(error) }) }
    finally {
      if (!invalid(handle)) {
        try {
          const accepted = close(handle)
          const closeError = lastError()
          native.close = { status: accepted ? "closed" : "failed", returnValue: accepted, lastError: closeError, lastErrorMeaning: accepted ? "observed-stale-on-success" : "failure-code" }
          if (!accepted) native.failures.push({ kind: "win32", operation: "CloseHandle", win32Error: closeError, operand, rawReturn: accepted })
        } catch (error) { native.close = { status: "failed", error: originalError(error) }; native.failures.push({ kind: "close-host-or-ffi", error: originalError(error) }) }
      }
    }
    return native
  }
  return { library, abi, read,
    readEntryName: (operand) => read(operand, true),
    readShortPath: (operand) => readWidePath("GetShortPathNameW", { operand }, (buffer, count) => getShortPath(operand, buffer, count)),
  }
}
