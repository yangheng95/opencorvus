import assert from 'node:assert/strict'
import fs from 'node:fs/promises'
import path from 'node:path'
import {randomUUID} from 'node:crypto'
import {fileURLToPath} from 'node:url'
import {createNativeMetadataReader,originalError} from './native-metadata-reader.mjs'

const directory=path.dirname(fileURLToPath(import.meta.url))
const input=JSON.parse(await fs.readFile(path.join(directory,'future-short.inputs.json'),'utf8'))
const [mode,host,expectedFixtureID]=process.argv.slice(2)
assert.ok(['prepare','read'].includes(mode)&&['node','bun'].includes(host))
assert.equal(mode==='read',typeof expectedFixtureID==='string'&&expectedFixtureID.length>0)
assert.equal(process.platform,input.platform);assert.equal(process.arch,input.architecture)
assert.equal(host==='bun'?process.versions.bun:process.versions.node,host==='bun'?input.runtimes.bun.bunVersion:input.runtimes.node.nodeVersion)
assert.equal(input.cases.length,input.maximumCasesPerHost)
const manifestPath=path.join(input.runRoot,'original-fixture.json')
const stringify=value=>JSON.stringify(value,(_key,item)=>typeof item==='bigint'?{type:'bigint',value:String(item)}:item)
const emit=value=>new Promise((resolve,reject)=>process.stdout.write(stringify(value)+'\n',error=>error?reject(error):resolve()))
const statFact=value=>({fields:Object.fromEntries(Object.entries(value).map(([key,item])=>[key,typeof item==='bigint'?String(item):item instanceof Date?item.toISOString():item])),file:value.isFile(),directory:value.isDirectory(),link:value.isSymbolicLink()})
const identity=value=>({dev:value.fields.dev,ino:value.fields.ino,birthtimeNs:value.fields.birthtimeNs,file:value.file,directory:value.directory,link:value.link})
const byteFact=value=>({byteLength:value.length,base64:value.toString('base64'),utf8:value.toString('utf8')})
function declared(root,relative){
 assert.ok(typeof relative==='string'&&relative.length>0&&!path.isAbsolute(relative))
 assert.ok(relative.split(/[\\/]/).every(part=>part&&part!=='.'&&part!=='..'))
 const result=path.resolve(root,relative)
 assert.ok(path.relative(root,result).split(path.sep)[0]!=='..')
 return result
}
async function observe(operation,operand,read){try{return {operation,operand,status:'fulfilled',value:await read()}}catch(error){return {operation,operand,status:'rejected',code:error?.code,error:originalError(error)}}}
async function direct(directory){const stat=statFact(await fs.lstat(directory,{bigint:true})),resolved=await fs.realpath(directory);assert.equal(stat.directory,true);assert.equal(stat.link,false);assert.equal(resolved.toLowerCase(),path.resolve(directory).toLowerCase());return {path:directory,stat,identity:identity(stat),realpath:resolved}}
async function member(root,item){
 const operand=declared(root,item.path),stat=statFact(await fs.lstat(operand,{bigint:true}))
 const fact={path:item.path,operand,stat,identity:identity(stat)}
 if(item.kind==='link'){assert.equal(stat.link,true);fact.readlink=await fs.readlink(operand)}
 else if(item.kind==='file'){assert.equal(stat.file,true);const bytes=await fs.readFile(operand);assert.deepEqual(bytes,Buffer.from(item.literal));fact.bytes=byteFact(bytes)}
 else {assert.equal(stat.directory,true);fact.realpath=await fs.realpath(operand)}
 return fact
}
function members(spec){return [...[...spec.directories,...(spec.lateDirectories??[])].map(relative=>({path:relative,kind:'directory'})),...spec.files.map(file=>({...file,kind:'file'})),...spec.links.map(link=>({...link,kind:'link'}))]}
let stage='input',fixtureID
try{
 await emit({type:'original-input',mode,host,input,qualification:'OS/library copy-kind and future access observations; not FileRoutes/UI or production noReplace acceptance'})
 const reader=await createNativeMetadataReader(input,fact=>emit({fixtureID,host,...fact}))
 if(mode==='prepare'){
  assert.equal(host,'node')
  stage='exclusive-fixture-root';await fs.mkdir(input.runRoot)
  const manifest={schema:'future-short-fixture/v1',fixtureID:randomUUID(),createdAtUtc:new Date().toISOString(),runRoot:input.runRoot,totalDeclaredLiteralBytes:input.totalDeclaredLiteralBytes,hosts:{}}
  fixtureID=manifest.fixtureID
  let totalBytes=0
  for(const targetHost of ['node','bun']){
   await fs.mkdir(path.join(input.runRoot,targetHost))
   const prepared=[]
   for(const spec of input.cases){
    const root=path.join(input.runRoot,targetHost,spec.id)
    stage='prepare:'+targetHost+':'+spec.id;await fs.mkdir(root)
    for(const relative of spec.directories)await fs.mkdir(declared(root,relative),{recursive:true})
    for(const file of spec.files.filter(file=>!spec.lateDirectories.some(directory=>file.path.startsWith(directory+'/')))){const bytes=Buffer.from(file.literal);assert.ok(bytes.length<=input.maximumFileBytes);totalBytes+=bytes.length;await fs.writeFile(declared(root,file.path),bytes,{flag:'wx'});await emit({type:'created-original-literal',fixtureID,host:targetHost,caseID:spec.id,operand:declared(root,file.path),bytes:byteFact(bytes)})}
    for(const link of spec.links){const operand=declared(root,link.path),target=link.rawRelativeText??declared(root,link.absoluteTarget);await fs.symlink(target,operand,link.type);await emit({type:'created-original-link',fixtureID,host:targetHost,caseID:spec.id,operand,targetArgument:target,typeArgument:link.type,actualReadlink:await fs.readlink(operand)})}
    for(const relative of spec.lateDirectories)await fs.mkdir(declared(root,relative),{recursive:true})
    for(const file of spec.files.filter(file=>spec.lateDirectories.some(directory=>file.path.startsWith(directory+'/')))){const bytes=Buffer.from(file.literal);totalBytes+=bytes.length;await fs.writeFile(declared(root,file.path),bytes,{flag:'wx'});await emit({type:'created-original-literal',fixtureID,host:targetHost,caseID:spec.id,operand:declared(root,file.path),bytes:byteFact(bytes)})}
    const shortPath=reader.readShortPath(declared(root,spec.shortOf));await emit({type:'original-short-path',fixtureID,host:targetHost,caseID:spec.id,shortPath})
    assert.equal(shortPath.firstCause,null);assert.ok(shortPath.path)
    const shortBasename=path.basename(shortPath.path),rawRelativeText=shortBasename+'/r',generatedLink={path:spec.generatedLink,type:'dir',rawRelativeText}
    await fs.symlink(rawRelativeText,declared(root,spec.generatedLink),'dir');await emit({type:'created-original-link-from-actual-short-path',fixtureID,host:targetHost,caseID:spec.id,generatedLink,shortBasename,terminalSpellingChanged:shortBasename.toLowerCase()!==path.basename(spec.shortOf).toLowerCase()})
    const preparedSpec={...spec,links:[...spec.links,generatedLink]}
    const originals=[];for(const item of members(preparedSpec))originals.push(await member(root,item))
    prepared.push({id:spec.id,directory:await direct(root),members:originals,shortPath,generatedLink,preparedSpec})
    await emit({type:'prepared-case',fixtureID,host:targetHost,case:prepared.at(-1)})
   }
   manifest.hosts[targetHost]=prepared
  }
  assert.equal(totalBytes,input.totalDeclaredLiteralBytes);assert.ok(totalBytes<=input.maximumDeclaredBytes)
  manifest.root=await direct(input.runRoot)
  await fs.writeFile(manifestPath,stringify(manifest)+'\n',{flag:'wx'})
  await emit({type:'prepared-fixture',fixtureID,manifestPath,manifest})
 }else{
  const manifest=JSON.parse(await fs.readFile(manifestPath,'utf8'));fixtureID=manifest.fixtureID
  assert.equal(manifest.schema,'future-short-fixture/v1');assert.equal(manifest.runRoot,input.runRoot)
  assert.equal(manifest.fixtureID,expectedFixtureID)
  assert.deepEqual(identity((await direct(input.runRoot)).stat),manifest.root.identity)
  async function capture(root,relative){
   const operand=declared(root,relative),fact={relative,operand}
   fact.lstat=await observe('lstat-bigint',operand,()=>fs.lstat(operand,{bigint:true}).then(statFact))
   if(fact.lstat.status==='fulfilled'){
    fact.native=reader.readEntryName(operand)
    await emit({type:'native-entry-observation',fixtureID,host,operand,native:fact.native})
    assert.equal(fact.native.query?.returnValue,1);assert.equal(fact.native.close?.status,'closed');assert.ok(fact.native.finalPath?.path)
    if(fact.lstat.value.link)fact.readlink=await observe('readlink',operand,()=>fs.readlink(operand))
   }
   if(fact.lstat.status==='fulfilled'){
    fact.shortPath=reader.readShortPath(operand);await emit({type:'actual-short-path-observation',fixtureID,host,operand,shortPath:fact.shortPath});assert.equal(fact.shortPath.firstCause,null)
   }
   fact.realpath=await observe('realpath',operand,()=>fs.realpath(operand))
   fact.stat=await observe('stat-bigint',operand,()=>fs.stat(operand,{bigint:true}).then(statFact))
   if(fact.stat.status==='fulfilled'&&fact.stat.value.file){assert.ok(BigInt(fact.stat.value.fields.size)<=BigInt(input.maximumFileBytes));fact.bytes=await observe('read-complete-bytes',operand,()=>fs.readFile(operand).then(byteFact))}
   return fact
  }
  const completed=[]
  for(const declaredSpec of input.cases){
   const prepared=manifest.hosts[host].find(item=>item.id===declaredSpec.id);assert.ok(prepared)
   const spec=prepared.preparedSpec
   const root=prepared.directory.path
   stage='original-members:'+spec.id
   const beforeMembers=[]
   for(const item of members(spec)){const actual=await member(root,item),original=prepared.members.find(row=>row.path===item.path);assert.deepEqual(actual.identity,original.identity);if(item.kind==='link')assert.equal(actual.readlink,original.readlink);beforeMembers.push(actual)}
   const sourceAlias=path.join('A/deep/tree',path.basename(prepared.shortPath.path)),targetAlias=path.join('A/result',path.basename(prepared.shortPath.path))
   const positions=[...spec.observations,sourceAlias,targetAlias,sourceAlias+'/r/marker.txt',targetAlias+'/r/marker.txt']
   const before=[];for(const relative of positions)before.push(await capture(root,relative))
   await emit({type:'before-operation-observations',fixtureID,host,caseID:spec.id,members:beforeMembers,observations:before})
   const operations=[]
   for(const operation of spec.operations){
    stage='operation:'+spec.id+':'+operation.method
    const source=declared(root,operation.source),target=declared(root,operation.target)
    const sourceStat=await fs.lstat(source)
    const sourceFact=beforeMembers.find(item=>item.path===operation.source)
    const options=operation.method==='copy'?{...input.copyOptions,recursive:sourceStat.isDirectory()}:undefined
    await emit({type:'actual-operation-input',fixtureID,host,caseID:spec.id,method:operation.method,source,target,options,originalSource:sourceFact??null})
    const startedAtUtc=new Date().toISOString()
    if(operation.method==='copy'){
     const links=new Map()
     await fs.cp(source,target,{...options,async filter(from,to){
      const stat=await fs.lstat(from,{bigint:true});if(!stat.isSymbolicLink())return true
      const native=reader.readEntryName(from);await emit({type:'actual-copy-link-entry',fixtureID,host,caseID:spec.id,from,to,native})
      assert.equal(native.query?.returnValue,1);assert.equal(native.close?.status,'closed');assert.equal(native.failures.length,0)
      const tag=native.query.output.ReparseTag,attributes=native.query.output.FileAttributes
      const kind=tag===0xa0000003?'junction':tag===0xa000000c?(attributes&0x10?'dir':'file'):undefined
      assert.ok(kind);const text=await fs.readlink(from);links.set(to,{text,kind});return false
     }})
     for(const [destination,descriptor] of links){await fs.symlink(descriptor.text,destination,descriptor.kind);await emit({type:'actual-copy-link-created',fixtureID,host,caseID:spec.id,destination,...descriptor})}
    }
    else {assert.equal(operation.method,'rename');await fs.rename(source,target)}
    const result={...operation,source,target,options,startedAtUtc,completedAtUtc:new Date().toISOString(),status:'returned'}
    operations.push(result);await emit({type:'actual-operation-completed',fixtureID,host,caseID:spec.id,result})
   }
   stage='after-observations:'+spec.id
   const after=[];for(const relative of positions)after.push(await capture(root,relative))
   const markers=[];for(const file of spec.files){const operand=declared(root,file.path);markers.push(await observe('original-literal-after',operand,()=>fs.readFile(operand).then(byteFact)))}
   const caseResult={caseID:spec.id,root,beforeMembers,before,operations,after,originalMarkersAfter:markers}
   completed.push(caseResult);await emit({type:'completed-case-originals',fixtureID,host,result:caseResult})
  }
  await emit({type:'completed-host-observations',fixtureID,host,cases:completed,qualification:'Original OS/library results only; no predicted kind or final permission expectations manufactured'})
 }
}catch(error){await emit({type:'phase-original-failure',fixtureID,mode,host,stage,error:originalError(error)});process.exitCode=1}
