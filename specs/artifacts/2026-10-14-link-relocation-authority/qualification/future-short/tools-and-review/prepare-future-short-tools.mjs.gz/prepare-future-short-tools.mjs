import fs from 'node:fs'
import path from 'node:path'
const scratch=path.resolve('.tmp-codex-directory-target-01a133'),original=JSON.parse(fs.readFileSync(path.join(scratch,'canonical-entry-name.inputs.json'),'utf8'))
const cases=[]
for(const collision of [false,true])for(const method of ['copy','rename']){
 const id=(collision?'collision-order':'stable-alias')+'-'+method
 const junctionNames=collision?['junction-alpha-link','junction-alpine-link']:['junction-descriptive-link']
 const late=collision?['A/deep/tree/junction-altar-folder','A/deep/tree/junction-altar-folder/r']:[]
 cases.push({id,directories:['A/deep/tree','A/data/nested','A/B','B'],lateDirectories:late,files:[{path:'A/B/marker.txt',literal:'SHORT INNER A\r\n'},{path:'B/marker.txt',literal:'SHORT OUTER B\r\n'},...(collision?[{path:'A/deep/tree/junction-altar-folder/r/marker.txt',literal:'SHORT ORDINARY\r\n'}]:[])],links:[{path:'A/data/nested/r',type:'dir',rawRelativeText:'../../../B'},...junctionNames.map(name=>({path:'A/deep/tree/'+name,type:'junction',absoluteTarget:'A/data/nested'}))],shortOf:'A/deep/tree/'+junctionNames[0],generatedLink:'A/deep/tree/u',operations:[{method,source:'A/deep/tree',target:'A/result'}],observations:['A/deep/tree','A/deep/tree/u','A/deep/tree/u/marker.txt',...junctionNames.map(name=>'A/deep/tree/'+name),'A/result','A/result/u','A/result/u/marker.txt',...junctionNames.map(name=>'A/result/'+name),...late]})
}
const input={schema:'future-short-input/v1',qualification:'Fixed original input; no model or UI automation',runRoot:'C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/future-short-input-01a133',maximumCasesPerHost:4,maximumDeclaredBytes:1024,maximumFileBytes:128,platform:'win32',architecture:'x64',packageAnchor:original.packageAnchor,koffiVersion:original.koffiVersion,runtimes:original.runtimes,nativeInput:original.nativeInput,modelCallsRequested:'none',credentialCatalogStaging:'none',copyOptions:{errorOnExist:true,force:false,dereference:false,verbatimSymlinks:true},cases,totalDeclaredLiteralBytes:2*cases.reduce((sum,spec)=>sum+spec.files.reduce((n,file)=>n+Buffer.byteLength(file.literal),0),0)}
if(input.totalDeclaredLiteralBytes>input.maximumDeclaredBytes)throw Error('Original literal budget exceeded')
fs.writeFileSync(path.join(scratch,'future-short.inputs.json'),JSON.stringify(input,null,2)+'\n',{flag:'wx'})
const originals=[],changes=[]
function replacement(text,label,before,after){if(text.split(before).length!==2)throw Error('Exact single source seam required: '+label);changes.push({label,before,after});return text.replace(before,after)}
const source=fs.readFileSync(path.join(scratch,'relocation-kind-qualifier.mjs'),'utf8');originals.push({path:'relocation-kind-qualifier.mjs',text:source})
let qualifier=source
qualifier=replacement(qualifier,'input filename',"'relocation-qualifier.inputs.json'","'future-short.inputs.json'")
qualifier=qualifier.replaceAll('link-relocation-copy-kind-fixture/v1','future-short-fixture/v1')
changes.push({label:'fixture schema',before:'link-relocation-copy-kind-fixture/v1',after:'future-short-fixture/v1',occurrences:source.split('link-relocation-copy-kind-fixture/v1').length-1})
qualifier=replacement(qualifier,'one reader in both phases'," if(mode==='prepare'){"," const reader=await createNativeMetadataReader(input,fact=>emit({fixtureID,host,...fact}))\n if(mode==='prepare'){")
qualifier=replacement(qualifier,'remove second reader load',"  const reader=await createNativeMetadataReader(input,fact=>emit({fixtureID,host,...fact}))\n",'')
qualifier=replacement(qualifier,'case member facts',"function members(spec){return [...spec.directories.map(relative=>({path:relative,kind:'directory'})),...spec.files.map(file=>({...file,kind:'file'})),...spec.links.map(link=>({...link,kind:'link'}))]}","function members(spec){return [...[...spec.directories,...(spec.lateDirectories??[])].map(relative=>({path:relative,kind:'directory'})),...spec.files.map(file=>({...file,kind:'file'})),...spec.links.map(link=>({...link,kind:'link'}))]}")
qualifier=replacement(qualifier,'late file preparation',"    for(const file of spec.files){","    for(const file of spec.files.filter(file=>!spec.lateDirectories.some(directory=>file.path.startsWith(directory+'/')))){")
qualifier=replacement(qualifier,'actual generated alias declaration',"    const originals=[];for(const item of members(spec))originals.push(await member(root,item))",String.raw`    for(const relative of spec.lateDirectories)await fs.mkdir(declared(root,relative),{recursive:true})
    for(const file of spec.files.filter(file=>spec.lateDirectories.some(directory=>file.path.startsWith(directory+'/')))){const bytes=Buffer.from(file.literal);totalBytes+=bytes.length;await fs.writeFile(declared(root,file.path),bytes,{flag:'wx'});await emit({type:'created-original-literal',fixtureID,host:targetHost,caseID:spec.id,operand:declared(root,file.path),bytes:byteFact(bytes)})}
    const shortPath=reader.readShortPath(declared(root,spec.shortOf));await emit({type:'original-short-path',fixtureID,host:targetHost,caseID:spec.id,shortPath})
    assert.equal(shortPath.firstCause,null);assert.ok(shortPath.path)
    const shortBasename=path.basename(shortPath.path),rawRelativeText=shortBasename+'/r',generatedLink={path:spec.generatedLink,type:'dir',rawRelativeText}
    await fs.symlink(rawRelativeText,declared(root,spec.generatedLink),'dir');await emit({type:'created-original-link-from-actual-short-path',fixtureID,host:targetHost,caseID:spec.id,generatedLink,shortBasename,terminalSpellingChanged:shortBasename.toLowerCase()!==path.basename(spec.shortOf).toLowerCase()})
    const preparedSpec={...spec,links:[...spec.links,generatedLink]}
    const originals=[];for(const item of members(preparedSpec))originals.push(await member(root,item))`)
qualifier=replacement(qualifier,'alias original manifest',"prepared.push({id:spec.id,directory:await direct(root),members:originals})","prepared.push({id:spec.id,directory:await direct(root),members:originals,shortPath,generatedLink,preparedSpec})")
qualifier=replacement(qualifier,'read fixed prepared generated link',"  for(const spec of input.cases){\n   const prepared=manifest.hosts[host].find(item=>item.id===spec.id);assert.ok(prepared)","  for(const declaredSpec of input.cases){\n   const prepared=manifest.hosts[host].find(item=>item.id===declaredSpec.id);assert.ok(prepared)\n   const spec=prepared.preparedSpec")
qualifier=replacement(qualifier,'source and target alias observations',"   fact.realpath=await observe('realpath',operand,()=>fs.realpath(operand))",String.raw`   if(fact.lstat.status==='fulfilled'){
    fact.shortPath=reader.readShortPath(operand);await emit({type:'actual-short-path-observation',fixtureID,host,operand,shortPath:fact.shortPath});assert.equal(fact.shortPath.firstCause,null)
   }
   fact.realpath=await observe('realpath',operand,()=>fs.realpath(operand))`)
qualifier=replacement(qualifier,'actual alias traversal positions',"   const before=[];for(const relative of spec.observations)before.push(await capture(root,relative))",String.raw`   const sourceAlias=path.join('A/deep/tree',path.basename(prepared.shortPath.path)),targetAlias=path.join('A/result',path.basename(prepared.shortPath.path))
   const positions=[...spec.observations,sourceAlias,targetAlias,sourceAlias+'/r/marker.txt',targetAlias+'/r/marker.txt']
   const before=[];for(const relative of positions)before.push(await capture(root,relative))`)
qualifier=replacement(qualifier,'after same original alias positions',"   const after=[];for(const relative of spec.observations)after.push(await capture(root,relative))","   const after=[];for(const relative of positions)after.push(await capture(root,relative))")
qualifier=replacement(qualifier,'current typed-copy protocol',"    if(operation.method==='copy')await fs.cp(source,target,options)",String.raw`    if(operation.method==='copy'){
     const links=new Map()
     await fs.cp(source,target,{...options,async filter(from,to){
      const stat=await fs.lstat(from,{bigint:true});if(!stat.isSymbolicLink())return true
      const native=reader.readEntryName(from);await emit({type:'actual-copy-link-entry',fixtureID,host,caseID:spec.id,from,to,native})
      assert.equal(native.query?.returnValue,1);assert.equal(native.close?.status,'closed');assert.equal(native.failures.length,0)
      const tag=native.query.info.ReparseTag,attributes=native.query.info.FileAttributes
      const kind=tag===0xa0000003?'junction':tag===0xa000000c?(attributes&0x10?'dir':'file'):undefined
      assert.ok(kind);const text=await fs.readlink(from);links.set(to,{text,kind});return false
     }})
     for(const [destination,descriptor] of links){await fs.symlink(descriptor.text,destination,descriptor.kind);await emit({type:'actual-copy-link-created',fixtureID,host,caseID:spec.id,destination,...descriptor})}
    }`)
fs.writeFileSync(path.join(scratch,'future-short-qualifier.mjs'),qualifier,{flag:'wx'})
const wrapper=fs.readFileSync(path.join(scratch,'run-dot-native.mjs'),'utf8');originals.push({path:'run-dot-native.mjs',text:wrapper})
fs.writeFileSync(path.join(scratch,'run-dot-native.before-future-short.mjs'),wrapper,{flag:'wx'})
let next=wrapper
next=replacement(next,'future short mode category',"const relocationMode=", "const shortMode=['future-short-prepare','future-short-read'].includes(mode)\nconst relocationMode=")
next=replacement(next,'accepted new modes',"'copy-ui-after'].includes(mode)||", "'copy-ui-after','future-short-prepare','future-short-read'].includes(mode)||")
next=replacement(next,'node-only new prepare',"mode==='relocation-prepare'||copyUIMode)&&host!=='node'", "mode==='relocation-prepare'||mode==='future-short-prepare'||copyUIMode)&&host!=='node'")
next=replacement(next,'required original fixture read',"(mode==='read'||mode==='relocation-read')&&!fixtureID", "(mode==='read'||mode==='relocation-read'||mode==='future-short-read')&&!fixtureID")
next=replacement(next,'prepare without invented fixture ID',"mode==='relocation-prepare'||copyUIMode)&&fixtureID", "mode==='relocation-prepare'||mode==='future-short-prepare'||copyUIMode)&&fixtureID")
next=replacement(next,'new fixed input',"scratch,relocationMode?'relocation-qualifier.inputs.json'", "scratch,shortMode?'future-short.inputs.json':relocationMode?'relocation-qualifier.inputs.json'")
next=replacement(next,'distinct root',"scratch,copyUIMode?'copy-ui-native-'", "scratch,shortMode?'future-short-native-'+mode.slice(13)+'-'+host:copyUIMode?'copy-ui-native-'")
next=replacement(next,'same original cap',"executionCapMs=relocationMode?60000:", "executionCapMs=relocationMode||shortMode?60000:")
next=replacement(next,'same true inactivity cap',"inactivityTimeoutMs=relocationMode?15000:", "inactivityTimeoutMs=relocationMode||shortMode?15000:")
next=replacement(next,'actual new target arguments',"const targetArgs=copyUIMode?", "const targetArgs=shortMode?[path.join(scratch,'future-short-qualifier.mjs'),mode.slice(13),host,...(fixtureID?[fixtureID]:[])]:copyUIMode?")
fs.writeFileSync(path.join(scratch,'run-dot-native.mjs'),next)
fs.writeFileSync(path.join(scratch,'future-short-tool-exact-changes.json'),JSON.stringify({originals,changes,newQualifier:qualifier,newWrapper:next},null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({casesPerHost:cases.length,declaredLiteralBytes:input.totalDeclaredLiteralBytes,syntaxRun:false,fixtureCreated:false,exactChanges:changes.length}))
