import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import {gzipSync} from 'node:zlib'
const root='.tmp-codex-channel-feedback-01a133',artifact='specs/artifacts/2026-10-14-channel-feedback-locale',files=[],runs=[],http=[]
const gz=(from,to)=>{const bytes=fs.readFileSync(from);fs.mkdirSync(path.dirname(to),{recursive:true});fs.writeFileSync(to,gzipSync(bytes));files.push({source:from,saved:to.slice(artifact.length+1),originalBytes:bytes.length})}
for(const stage of ['before','after']){
 const run=root+'/'+stage,out=artifact+'/runs/'+stage,read=name=>JSON.parse(fs.readFileSync(run+'/'+name,'utf8')),ready=read('ready.json'),owner=read('owner.json'),exit=read('exit.json'),cleanup=read('physical-pair-cleanup.json'),terminal=read('terminal.json')
 assert.equal(ready.pid,owner.pid);assert.equal(exit.pid,owner.pid);assert.equal(cleanup.pid,owner.pid);assert.equal(exit.exitCode,0);assert.equal(cleanup.actualExit,0);assert.equal(cleanup.listeners,0);assert.equal(terminal.normalRuntimeSettlement,true);assert.equal(terminal.requests,0)
 assert.deepEqual(cleanup.pair.map(({name,removed})=>({name,removed})),[{name:'auth.json',removed:true},{name:'models.json',removed:true}])
 for(const name of fs.readdirSync(run))if(name.endsWith('.json')&&name!=='privacy-ready.json'){
  gz(run+'/'+name,out+'/'+name+'.gz')
  const value=read(name)
  if(value.method&&value.route&&typeof value.status==='number')http.push({stage,file:name,...value})
 }
 for(const name of fs.readdirSync(run+'/redacted-logs'))gz(run+'/redacted-logs/'+name,out+'/logs/'+name+'.gz')
 runs.push({stage,pid:ready.pid,occurrence:ready.occurrence,port:ready.port,participantPort:ready.participantPort,physicalExit:exit.exitCode,requests:terminal.requests,privacy:read('privacy-qualified.json').files})
}
assert.equal(http.length,18)
const exits=fs.readdirSync(root).filter(x=>x.endsWith('.exit')&&x!=='archive.exit')
for(const name of exits){assert.equal(fs.readFileSync(root+'/'+name,'utf8').trim(),'0',name);gz(root+'/'+name,artifact+'/checks/'+name+'.gz');gz(root+'/'+name.replace(/\.exit$/,'.log'),artifact+'/checks/'+name.replace(/\.exit$/,'.log')+'.gz')}
for(const name of ['setup.mjs','runtime.ts','launch.ps1','privacy.ts','run.mjs','read.mjs','read-irc.mjs','fault.mjs','check-recovered.mjs','baseline.json','prepare-docs.mjs','stage-final.mjs','commit-final.mjs','shared-final.json','archive.mjs','final-results.mjs',...fs.readdirSync(root).filter(x=>x.endsWith('.before'))])gz(root+'/'+name,artifact+'/inputs/'+name+'.gz')
const screenshots=fs.readdirSync(artifact+'/screenshots').filter(x=>x.endsWith('.png')).sort().map(name=>{const stat=fs.statSync(artifact+'/screenshots/'+name);return{name,bytes:stat.size,savedUtc:stat.mtime.toISOString()}})
assert.equal(screenshots.length,32)
const from=screenshots.find(x=>x.name.startsWith('10-')),to=screenshots.find(x=>x.name.startsWith('13-'))
assert.ok(Date.parse(to.savedUtc)-Date.parse(from.savedUtc)>4000)
fs.writeFileSync(artifact+'/manifest.json',JSON.stringify({at:new Date().toISOString(),purpose:'Original response/log/screenshot preservation; no mutable-source hash, UI automation or pixel comparison.',runs,http,screenshots,limits:['06 is the initial Chat view, not a channel error target. 19 shows a scrolled catalog after IRC save; the independent accepted HTTP and 22 reopened saved field qualify the result.','23 and 26 are initial pending-load views. 24/25 qualify actual catalog failure; 27 qualifies settled recovery.','The manual UI response bodies were not independently saved; formal checker error bodies and safe config selections are retained separately.','Tutorial host failure and committed reconciliation feedback have source/shared positive-contract coverage only, not independently induced UI end-to-end qualification.','No real Provider, Sol, channel credential, connection or message was used.','Only own tabs 42 and 44 were closed; another task used tab 43.','Two foreign project-runtime locale keys per language remain outside this task; exact five-key locale patches only.'],files},null,2)+'\n')
fs.writeFileSync(artifact+'/README.md','# 第30批：通道反馈的当前语言与可读详情\n\n对应[Recall、根因、实施与验收限制](../../records/2026-10/2026-10-14-channel-feedback-locale.md)。用户要求本批收尾，不再扩展。Root独立实施和验收，无子agent/其他聊天消息/UI自动化。\n\n- [screenshots](screenshots/README.md)：32张未编辑原PNG，Root逐张人工查看；修前语言冻结/错误消失/丢草稿，修后当前语言、真实错误详情、失败草稿、修正保存重开、项目切换和清空。初始加载及区域未入镜图的限制明确保留。\n- [runs](runs/README.md)：before PID84444、18694/95；after PID75944、18696/97。18份正式HTTP回执：4个真实409、2个自有项目dispose200、12个安全选择GET200；HTTP错误正文完整，配置只选明确无敏感字段。三次真实故障输入均只精确创建/删除自有空非canonical文件，保留原canonical。\n- [checks](checks/README.md)：类型0、Node build1m2s0、14个原共享详情正向合同/42断言0，i18n初2/2482及并行外部两键后的最终2/2484，文档/架构原回执。没有把这些检查当视觉验收。\n- [inputs](inputs/README.md)：当前完整工具与初始源/两locale、精确共享段落/五键补丁；PowerShell一次引用错误的首次输出未另落完整文件，不伪造其捕获。\n- [previous-delivery](previous-delivery/README.md)：B29正常提交推送与全部原hook/fresh远端确认。\n\n两个自有tab42/44关闭，正常父实际exit0/双口0后整对移除生成auth/models；完整backend172250/246203字节、stdoutstderr0、隐私检查0、inference/Sol0。教程宿主故障与已提交整理错误没有自然诱发的独立UI资格；只复用原真实合同与14项局部正向检查，未当端到端通过。范围提交和正常上游推送以随后独立交付回执为准。见[原清单](manifest.json)。\n')
for(const [name,title,body]of [['screenshots','真实页面原图','01–07修前，其中06是Chat首页；08当前中文成功、09成功正常退场；10–13真实公网错误/详情/语言/持续；14–18中英IRC错误/详情/原草稿；19保存后目录滚动区不含成功反馈，20–22公网保存/重开与IRC实际保存后重开；23是加载初态、24/25真实目录错误；26加载初态、27真正恢复；28/29项目切换；30校验、31/32清空保存/重开。全部人工查看，无自动视觉断言。'],['runs','正式HTTP和物理生命周期','18份正式HTTP回执保留真实请求/status/公开错误或明确安全选择；自有文件恢复与进程退出分开，完整配置/Auth不归档。'],['checks','实际检查与退出','所有命令保留完整日志和真实退出；原错误详情合同是纯服务测试，非DOM/组件或端到端。'],['inputs','原始输入与实际工具','保留初始产品/locale、当前工具完整源与精确共享补丁，不重建未单独捕获的首次命令流。']]){fs.mkdirSync(artifact+'/'+name,{recursive:true});fs.writeFileSync(artifact+'/'+name+'/README.md','# '+title+'\n\n'+body+' 见[主说明](../README.md)。\n')}
console.log(JSON.stringify({artifact,originals:files.length,screenshots:screenshots.length,httpRecords:http.length,runs:runs.map(({stage,pid,physicalExit})=>({stage,pid,physicalExit}))}))
