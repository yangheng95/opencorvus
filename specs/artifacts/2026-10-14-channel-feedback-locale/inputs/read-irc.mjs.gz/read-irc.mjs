import fs from 'node:fs/promises'
import assert from 'node:assert/strict'
const root='.tmp-codex-channel-feedback-01a133/after',ready=JSON.parse(await fs.readFile(root+'/ready.json','utf8')),authority=JSON.parse(await fs.readFile(root+'/project-authorities.json','utf8'))
const route='/config?'+new URLSearchParams({directory:authority.defaultDirectory}),response=await fetch('http://127.0.0.1:'+ready.port+route,{signal:AbortSignal.timeout(30_000)}),raw=await response.text(),config=JSON.parse(raw)
const value=config.channel?.irc,receipt={method:'GET',route,status:response.status,requestID:response.headers.get('x-opencorvus-request-id'),responseBytes:Buffer.byteLength(raw),selection:'Only IRC nonsecret saved values and exact field keys; full configuration omitted.',irc:value?{keys:Object.keys(value).sort(),enabled:value.enabled,host:value.host,nick:value.nick,tls:value.tls}:null,at:new Date().toISOString()}
await fs.writeFile(root+'/read-irc.json',JSON.stringify(receipt,null,2)+'\n')
assert.equal(response.status,200);assert.deepEqual(receipt.irc,{keys:['enabled','host','nick','tls'],enabled:true,host:'127.0.0.1',nick:'owned-feedback-draft',tls:true})
console.log(JSON.stringify(receipt))
