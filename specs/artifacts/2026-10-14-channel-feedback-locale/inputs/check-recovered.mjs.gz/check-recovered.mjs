import fs from 'node:fs/promises'
import assert from 'node:assert/strict'
const root='.tmp-codex-channel-feedback-01a133/after',ready=JSON.parse(await fs.readFile(root+'/ready.json','utf8')),authorities=JSON.parse(await fs.readFile(root+'/project-authorities.json','utf8'))
for(const [label,pathname,directory]of [['catalog','/channel',authorities.defaultDirectory],['scope-b','/config',ready.projects.find(x=>x.label==='B').directory]]){
 const route=pathname+'?'+new URLSearchParams({directory}),response=await fetch('http://127.0.0.1:'+ready.port+route,{signal:AbortSignal.timeout(30_000)}),raw=await response.text(),parsed=JSON.parse(raw)
 const selection=label==='catalog'?{count:parsed.length,irc:parsed.find(x=>x.id==='irc')?.status}:{publicUrl:parsed.server?.publicUrl??null}
 const receipt={method:'GET',route,status:response.status,requestID:response.headers.get('x-opencorvus-request-id'),responseBytes:Buffer.byteLength(raw),selection,at:new Date().toISOString()}
 await fs.writeFile(root+'/recovered-'+label+'.json',JSON.stringify(receipt,null,2)+'\n')
 assert.equal(response.status,200)
 if(label==='catalog')assert.deepEqual(selection,{count:27,irc:'configured'})
 else assert.deepEqual(selection,{publicUrl:null})
 console.log(JSON.stringify(receipt))
}
