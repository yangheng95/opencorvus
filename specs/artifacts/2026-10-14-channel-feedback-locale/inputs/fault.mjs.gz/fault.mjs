import fs from 'node:fs/promises'
import path from 'node:path'
import assert from 'node:assert/strict'
const [stage,action,label]=process.argv.slice(2)
if(label)assert.match(label,/^[a-z][a-z0-9-]*$/)
const suffix=label?'-'+label:''
assert.match(stage??'',/^(before|after)([0-9]{2})?$/)
assert.match(action??'',/^(create|probe-write|dispose|probe-catalog|recover)$/)
const root=path.resolve('.tmp-codex-channel-feedback-01a133',stage),ready=JSON.parse(await fs.readFile(root+'/ready.json','utf8')),authority=JSON.parse(await fs.readFile(root+'/project-authorities.json','utf8')),directory=path.resolve(authority.defaultDirectory),query=new URLSearchParams({directory}),canonical=path.join(directory,'.opencorvus','opencorvus.jsonc'),conflict=path.join(directory,'.opencorvus','opencorvus.json')
const normalized=value=>path.resolve(value).toLowerCase(),inside=(parent,value)=>normalized(value).startsWith(normalized(parent)+path.sep)
assert.equal(directory,path.join(root,'project'));assert.ok(inside(root,directory));assert.ok(inside(directory,conflict));assert.equal(normalized(await fs.realpath(directory)),normalized(directory))
if(action==='create'){
 await fs.stat(canonical)
 assert.ok(inside(root,await fs.realpath(path.dirname(conflict))))
 const handle=await fs.open(conflict,'wx')
 try{await handle.writeFile('{}\n')}finally{await handle.close()}
 await fs.writeFile(root+'/fault-created'+suffix+'.json',JSON.stringify({action,path:conflict,canonical,content:'{}\n',boundary:'Only a new empty non-canonical file in the exact self-created isolated Project. Canonical data is untouched.',at:new Date().toISOString()},null,2)+'\n')
 console.log(JSON.stringify({stage,action,path:conflict,canonicalTouched:false}))
}else if(action==='recover'){
 const created=JSON.parse(await fs.readFile(root+'/fault-created'+suffix+'.json','utf8'))
 assert.equal(created.path,conflict);assert.equal(await fs.readFile(conflict,'utf8'),created.content)
 await fs.unlink(conflict)
 const state=await fs.stat(conflict).then(()=>({state:'present'}),error=>({state:error.code}))
 assert.deepEqual(state,{state:'ENOENT'})
 await fs.writeFile(root+'/fault-recovered'+suffix+'.json',JSON.stringify({action,path:conflict,canonicalTouched:false,state,at:new Date().toISOString()},null,2)+'\n')
 console.log(JSON.stringify({stage,action,path:conflict,state}))
}else{
 const route=(action==='dispose'?'/instance/dispose':action==='probe-catalog'?'/channel':'/config')+'?'+query,method=action==='dispose'?'POST':action==='probe-catalog'?'GET':'PATCH',body=action==='probe-write'?{server:{publicUrl:`http://127.0.0.1:${ready.participantPort}/rejected`}}:undefined
 const response=await fetch(`http://127.0.0.1:${ready.port}`+route,{method,...(body?{headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}:{}),signal:AbortSignal.timeout(30_000)}),raw=await response.text(),parsed=JSON.parse(raw)
 await fs.writeFile(root+'/fault-'+action+suffix+'.body.json',raw)
 const receipt={action,method,route,...(body?{body}:{}),status:response.status,requestID:response.headers.get('x-opencorvus-request-id'),responseBytes:Buffer.byteLength(raw),responseSelection:'Complete actual public error/boolean response; only own paths and diagnostic metadata, no configuration/auth body.',at:new Date().toISOString()}
 await fs.writeFile(root+'/fault-'+action+suffix+'.json',JSON.stringify(receipt,null,2)+'\n')
 if(action==='dispose'){assert.equal(response.status,200);assert.equal(parsed,true)}
 else{assert.equal(response.status,409);assert.equal(parsed.name,'NonCanonicalConfigFileError');assert.equal(normalized(parsed.data.canonical),normalized(canonical));assert.deepEqual(parsed.data.conflicts.map(normalized),[normalized(conflict)])}
 console.log(JSON.stringify({...receipt,responseName:parsed.name??'boolean'}))
}
