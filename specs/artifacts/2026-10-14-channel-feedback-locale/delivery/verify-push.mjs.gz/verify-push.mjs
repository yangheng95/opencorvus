import fs from 'node:fs'
import {execFileSync} from 'node:child_process'
const scratch='.tmp-codex-channel-feedback-01a133',own='17ee22b8e8abf0ab10fe9381f79d07682631cb77',git=args=>execFileSync('git',args,{encoding:'utf8',maxBuffer:64*1024*1024}).trim()
git(['merge-base','--is-ancestor',own,'origin/main'])
const remote=git(['ls-remote','origin','refs/heads/main']),receipt={ownCommit:own,freshFetchedUpstream:git(['rev-parse','origin/main']),remoteMain:remote,ownAncestorOfFreshUpstream:true,at:new Date().toISOString()}
fs.writeFileSync(scratch+'/verified-remote.json',JSON.stringify(receipt,null,2)+'\n')
console.log(JSON.stringify(receipt))
