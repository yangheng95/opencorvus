import fs from 'node:fs'
import {execFileSync} from 'node:child_process'
import {gunzipSync} from 'node:zlib'
const commit='cb21f21c42a72d138f35d45830ac1966a01ccc67',git=args=>execFileSync('git',args,{encoding:'utf8',maxBuffer:64*1024*1024}),files=git(['show','--format=','--name-only',commit]).trim().split('\n'),manifests=files.filter(x=>/^(expert-squads\/builtin|packages\/opencorvus\/src\/expert-squad\/builtin)\/[^/]+\/expert-squad.jsonc$/.test(x)),source=files.filter(x=>!x.startsWith('specs/artifacts/')&&!manifests.includes(x)),diff=git(['show','--format=','--unified=0',commit,'--',...manifests]),changes=diff.split('\n').filter(x=>/^[+-]/.test(x)&&!/^---|^\+\+\+/.test(x)),groups={}
for(const line of changes)groups[line]=(groups[line]??0)+1
const artifacts='specs/artifacts/2026-10-14-scheduler-frontier-grants',logs={}
for(const name of ['grant-contracts.log','grant-contracts-retry.log','projection-contracts.log','tool-surface-contracts.log','docs-check.log','architecture-check.log']){
 const value=gunzipSync(fs.readFileSync(artifacts+'/first/execution/'+name+'.gz')).toString('utf8')
 logs[name]={bytes:Buffer.byteLength(value),tail:value.split('\n').slice(-13).join('\n')}
}
const facts=JSON.parse(fs.readFileSync(artifacts+'/execution-summary.json','utf8'))
const result={commit,totalPaths:files.length,manifestCount:manifests.length,manifestChanges:groups,allPaths:files,nonManifestNonEvidencePaths:source,logs,qualification:{status:facts.status,tests:facts.tests,assertions:facts.assertions,additionalChecks:facts.additionalChecks,boundary:facts.boundary},decision:'Existing independently human-authorized backend delivery: all current shipped grants and unique template/payload source updated together; exact raw focused backend contracts and tool-surface checks pass. Full live UI, multProject/Mission and pre-existing root cancellation defect remain explicitly unqualified, not claimed solved. No UI code changed. This task adds no agents or provider runs.'}
fs.writeFileSync('.tmp-codex-channel-feedback-01a133/pending-peer-review.json',JSON.stringify(result,null,2)+'\n')
console.log(JSON.stringify({...result,allPaths:'All exact paths retained in pending-peer-review.json'},null,2))
