import fs from 'node:fs'
import {execFileSync} from 'node:child_process'
const scratch='.tmp-codex-channel-feedback-01a133',review=JSON.parse(fs.readFileSync(scratch+'/closing-review.json','utf8')),git=(args,env=process.env)=>execFileSync('git',args,{encoding:'utf8',maxBuffer:64*1024*1024,env}).trim(),reconcileOnly=process.argv.includes('--reconcile')
if(!reconcileOnly){if(git(['rev-parse','HEAD'])!==review.head)throw Error('HEAD advanced; re-review closing index');execFileSync('git',['commit','-m','docs(iteration): record channel feedback delivery and acceptance limits'],{env:{...process.env,GIT_INDEX_FILE:review.index},stdio:'inherit'})}
const commit=reconcileOnly?JSON.parse(fs.readFileSync(scratch+'/closing-created.json','utf8')).commit:git(['rev-parse','HEAD']),parent=git(['rev-parse',commit+'^'])
if(parent!==review.head||JSON.stringify(git(['diff-tree','--no-commit-id','--name-only','-r',commit]).split('\n'))!==JSON.stringify(review.files))throw Error('Exact closing commit required')
fs.writeFileSync(scratch+'/closing-created.json',JSON.stringify({commit,parent,files:review.files,normalCommitExit:0},null,2)+'\n')
git(['add','-f','--',...review.files])
console.log(JSON.stringify({commit,parent,scopedPaths:review.files.length,normalCommitExit:0,indexReconciled:true}))
