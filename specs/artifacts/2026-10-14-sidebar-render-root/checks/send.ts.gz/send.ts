import fs from 'node:fs'
import path from 'node:path'
import {Identifier} from '../../packages/opencorvus/src/id/id'
const phase=process.argv[2]
if(!['before','after'].includes(phase))throw Error('Explicit phase')
const root=path.join(import.meta.dir,phase)
const authority=JSON.parse(fs.readFileSync(`C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/sidebar-render-root-420-${phase}/evidence/preflight-ready.json`,'utf8'))
if(authority.preflight.actualModel!=='gpt-6.1-sol'||authority.preflight.credential!=='usable')throw Error('Exact preflight required')
const sessionID='ses_-zUS0WzzQzzDOGrIbYwN',messageID=Identifier.ascending('message')
const text='仅为当前既有会话生成可阅读的验收内容，不创建或委派其他成员，不运行shell，不修改文件。请自己调用read读取README.md第2—3行，然后连续写约2400字中文解释，分成16个编号小节。每节都区分两行原文能证实的事实、尚未给出的条件与单纯展示建议，保留仅用于界面测试限定。保持小标题、引用、列表和最终核对表的Markdown结构。不要人为等待，不把技术测试信息写进解释，不使用其他成员回答作为证据。'
const body={messageID,agent:'work',model:{providerID:'openai',modelID:'gpt-6.1-sol'},parts:[{type:'text',text}]}
const url=new URL(`http://127.0.0.1:${phase==='before'?18555:18557}/session/${sessionID}/message`);url.searchParams.set('directory','C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/member-live-rendering-412-fresh/project')
fs.writeFileSync(path.join(root,'request.json'),JSON.stringify({url:String(url),body,at:new Date().toISOString()},null,2),{flag:'wx'})
console.log(JSON.stringify({sessionID,messageID,sentAt:new Date().toISOString()}))
const response=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)})
const result=await response.json()
fs.writeFileSync(path.join(root,'response.json'),JSON.stringify({status:response.status,result,at:new Date().toISOString()},null,2),{flag:'wx'})
console.log(JSON.stringify({status:response.status,messageID:result.info?.id,error:result.info?.error,finish:result.info?.finish}))
if(!response.ok||result.info?.error)process.exitCode=1
