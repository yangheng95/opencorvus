import fs from 'node:fs'
import path from 'node:path'
import zlib from 'node:zlib'
import {createRequire} from 'node:module'
import {execFileSync} from 'node:child_process'
import {Database} from 'bun:sqlite'
import {CredentialRedactor} from '../../packages/opencorvus/script/real-provider-audit'
import {completedToolOutcomeOutput} from '../../packages/opencorvus/src/session/tool-outcome-facts'

const root=import.meta.dir
const dest=path.resolve('specs/artifacts/2026-10-14-sidebar-render-root')
const base='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14'
const redactor=new CredentialRedactor()
redactor.collect(JSON.parse(fs.readFileSync('C:/Users/hengu/AppData/Local/opencorvus/data/auth.json','utf8')))
const original=JSON.parse(zlib.gunzipSync(fs.readFileSync('specs/artifacts/2026-10-14-member-live-rendering/facts/fresh-final.json.gz')).toString())
const save=(name:string,value:string)=>{
  const target=path.join(dest,name)
  fs.mkdirSync(path.dirname(target),{recursive:true})
  fs.writeFileSync(target,zlib.gzipSync(redactor.redact(value)))
}
const requireProduction=createRequire(path.resolve('packages/opencorvus/package.json'))
const {drizzle}=await import(requireProduction.resolve('drizzle-orm/bun-sqlite'))
const db=new Database(base+'/member-live-rendering-412-fresh/runtime/data/opencorvus.db',{readonly:true})
const outputDB=drizzle({client:db})
let facts:any
try {
  db.exec('BEGIN')
  const sessions=db.query('SELECT id,project_id,directory,kind,parent_id,title,metadata FROM session ORDER BY time_created,id').all()
  const messages=db.query('SELECT id,session_id,data FROM message ORDER BY time_created,id').all().map((r:any)=>({...JSON.parse(r.data),id:r.id,sessionID:r.session_id}))
  const parts=db.query('SELECT id,message_id,data FROM part ORDER BY time_created,id').all().map((r:any)=>({...JSON.parse(r.data),id:r.id,messageID:r.message_id}))
  const tools=db.query('SELECT id,message_id,data FROM tool_part_request ORDER BY time_created,id').all().map((r:any)=>({...JSON.parse(r.data),id:r.id,messageID:r.message_id}))
  const outcomes=db.query('SELECT request_part_id,data FROM tool_part_outcome ORDER BY time_created,id').all().map((r:any)=>{
    const data=JSON.parse(r.data)
    return {...data,requestPartID:r.request_part_id,output:completedToolOutcomeOutput(outputDB as any,data,()=>r.request_part_id)}
  })
  facts={observedAt:new Date().toISOString(),boundary:'Canonical read-only SQLite transaction; not visual acceptance',schema:db.query('PRAGMA user_version').get(),sessions,messages,parts,tools,outcomes}
} finally {db.exec('ROLLBACK');db.close()}
const selectedSessions=new Set(original.sessions.map((s:any)=>s.id))
facts.sessions=facts.sessions.filter((s:any)=>selectedSessions.has(s.id))
facts.messages=facts.messages.filter((m:any)=>selectedSessions.has(m.sessionID))
const selectedMessages=new Set(facts.messages.map((m:any)=>m.id))
facts.parts=facts.parts.filter((p:any)=>selectedMessages.has(p.messageID))
facts.tools=facts.tools.filter((p:any)=>selectedMessages.has(p.messageID))
const selectedTools=new Set(facts.tools.map((p:any)=>p.id))
facts.outcomes=facts.outcomes.filter((p:any)=>selectedTools.has(p.requestPartID))
facts.selection='Original 412 three persisted session identities (one preflight and the original parent/member pair); unrelated global histories excluded'
save('facts/final.json.gz',JSON.stringify(facts,null,2))
const stable=(value:any):string=>JSON.stringify(value,(_k,v)=>v&&typeof v==='object'&&!Array.isArray(v)?Object.fromEntries(Object.entries(v).sort(([a],[b])=>a.localeCompare(b))):v)
const preservation=Object.fromEntries(['sessions','messages','parts','tools','outcomes'].map(key=>{
 const id=key==='outcomes'?'requestPartID':'id'
 return [key,(original[key]??[]).map((old:any)=>{
  const current=facts[key].find((item:any)=>item[id]===old[id])
  return {id:old[id],retained:!!current,fields:Object.fromEntries(Object.keys(old).map(field=>[field,stable(old[field])===stable(current?.[field])]))}
 })]
}))
save('facts/preservation.json.gz',JSON.stringify({boundary:'Compare durable identities and actual prior field values, not mutable source hashes',preservation},null,2))
const providerSummary:any={}
for(const phase of ['before','after']){
 const local=path.join(root,phase),evidence=base+`/sidebar-render-root-420-${phase}/evidence`
 for(const name of fs.readdirSync(local)){
  const source=path.join(local,name)
  if(name.endsWith('.jpg')){fs.mkdirSync(path.join(dest,phase),{recursive:true});fs.copyFileSync(source,path.join(dest,phase,name));continue}
  if(/\.(json|jsonl|log|ps1)$/.test(name))save(`${phase}/${name}.gz`,fs.readFileSync(source,'utf8'))
 }
 const audits=fs.readdirSync(evidence).filter(n=>/^provider-.*\.json$/.test(n)&&!n.startsWith('provider-pair')).map(name=>({name,data:JSON.parse(fs.readFileSync(path.join(evidence,name),'utf8'))})).sort((a,b)=>String(a.data.observedAt).localeCompare(String(b.data.observedAt)))
 const latest=audits.at(-1)!
 providerSummary[phase]={file:latest.name,observedAt:latest.data.observedAt,maxRequests:latest.data.maxRequests,exhausted:latest.data.exhausted,requests:latest.data.requests.map((r:any)=>({model:r.model,streaming:r.streaming,status:r.status,reader:r.response_reader}))}
 for(const name of fs.readdirSync(evidence)){
  if(name.startsWith('provider-')&&name!==latest.name&&name!=='provider-pair-staging.json')continue
  if(name.endsWith('.json'))save(`${phase}/native/${name}.gz`,fs.readFileSync(path.join(evidence,name),'utf8'))
 }
}
save('facts/provider-summary.json.gz',JSON.stringify(providerSummary,null,2))
for(const name of ['build-diagnostic.mjs','send.ts','build-before.log','build-production.log','build-production-retry.log','sdk-build.log','vcs-contracts.log','routes-check.log','archive.ts'])save('checks/'+name+'.gz',fs.readFileSync(path.join(root,name),'utf8'))
const git=(args:string[])=>execFileSync('git',args,{encoding:'utf8',maxBuffer:8*1024*1024})
save('facts/historical-fixes.patch.gz',[
 git(['show','2e9d39ee5b7ca1e9d55b045d98fcf70d600ac526','--','packages/overlay/src']),
 git(['show','b93fe9a824e2dd0a9db109b406c8e15132d6370b','--','packages/overlay/src']),
 git(['show','72bacb0cbe','--','packages/overlay/src'])
].join('\n'))
const brief={schema:facts.schema,sessions:facts.sessions.map((s:any)=>({id:s.id,parentID:s.parent_id,kind:s.kind})),messages:facts.messages.length,sources:facts.parts.filter((p:any)=>p.type==='source-file').map((p:any)=>({id:p.id,messageID:p.messageID,toolPartID:p.toolPartID,path:p.path,range:p.range})),recentTools:facts.tools.slice(-5).map((t:any)=>({id:t.id,messageID:t.messageID,tool:t.tool,input:t.input})),preserved:Object.fromEntries(Object.entries(preservation).map(([key,rows]:any)=>[key,{count:rows.length,retained:rows.filter((r:any)=>r.retained).length,changed:rows.filter((r:any)=>Object.values(r.fields).some(v=>!v))}])),provider:Object.fromEntries(Object.entries(providerSummary).map(([k,v]:any)=>[k,{count:v.requests.length,requests:v.requests.map((r:any)=>({model:r.model,streaming:r.streaming,status:r.status,state:r.reader?.state,terminal:r.reader?.terminal?.kind,request:r.reader?.requestContext?.streamRequest?.requestID}))}]))}
save('facts/summary.json.gz',JSON.stringify(brief,null,2))
console.log(redactor.redact(JSON.stringify(brief,null,2)))
