import path from 'node:path'
import {build,loadConfigFromFile} from '../../packages/overlay/node_modules/vite/dist/node/index.js'
const workspace=process.cwd(),phase=process.argv[2]
if(!['before','after'].includes(phase))throw Error('Exact diagnostic phase required')
const replace=(source,anchor,value)=>{if(source.split(anchor).length!==2)throw Error('Inspect diagnostic anchor: '+anchor);return source.replace(anchor,value)}
process.chdir(path.join(workspace,'packages/overlay'))
const loaded=await loadConfigFromFile({command:'build',mode:'production'},path.join(workspace,'packages/overlay/vite.config.ts'))
await build({...loaded.config,configFile:false,plugins:[{
 name:'owned-render-lifetime-observation',enforce:'pre',
 transform(source,id){
  const file=id.replaceAll('\\','/')
  if(file.endsWith('/components/text-part-model.ts')){
   source=replace(source,'export function createStreamingTextPartModel','let renderOwner420 = 0\nexport function createStreamingTextPartModel')
   source=replace(source,'  const [error, setError] = createSignal("")',`  const [error, setError] = createSignal("")
  const traceOwner420 = ++renderOwner420
  console.debug("MD420", JSON.stringify({kind:"create",owner:traceOwner420,at:performance.now()}))
  let traceState420 = ""
  createEffect(() => {
    const state={empty:!frozenHtml().length,pending:pending(),streaming:props.streaming===true,error:error()}
    const key=JSON.stringify(state)
    if(key===traceState420)return
    traceState420=key
    console.debug("MD420",JSON.stringify({kind:"state",owner:traceOwner420,...state,length:props.text.length,at:performance.now()}))
  })
  onCleanup(() => console.debug("MD420",JSON.stringify({kind:"dispose",owner:traceOwner420,at:performance.now()})))`)
   return replace(source,'return { frozenHtml, pending, error }','return { frozenHtml, pending, error, traceOwner420 }')
  }
  if(file.endsWith('/components/TextPart.tsx')){
   source=replace(source,'const { frozenHtml, pending, error } =','const { frozenHtml, pending, error, traceOwner420 } =')
   return replace(source,'<div class={props.className || "msg-text"}','<div data-render-owner={traceOwner420} class={props.className || "msg-text"}')
  }
  if(file.endsWith('/components/SubagentConversationPanel.tsx')){
   source=replace(source,'function SubagentConversationScroll(props:','let scrollOwner420 = 0\nfunction SubagentConversationScroll(props:')
   source=replace(source,'  let scrollElement: HTMLDivElement | undefined',`  let scrollElement: HTMLDivElement | undefined
  const traceScroll420 = ++scrollOwner420
  console.debug("SCROLL420",JSON.stringify({kind:"create",owner:traceScroll420,at:performance.now()}))
  onCleanup(() => console.debug("SCROLL420",JSON.stringify({kind:"dispose",owner:traceScroll420,at:performance.now()})))`)
   return source
  }
  if(file.endsWith('/components/ChatBubble.tsx')){
   source='import { onCleanup as traceCleanup420 } from "solid-js"\n'+source
   source=replace(source,'export function ChatBubble(props:','let bubbleOwner420 = 0\nexport function ChatBubble(props:')
   return replace(source,'  const align = () => bubbleAlign(props.node)',`  const traceBubble420 = ++bubbleOwner420
  console.debug("BUBBLE420",JSON.stringify({kind:"create",owner:traceBubble420,at:performance.now()}))
  traceCleanup420(() => console.debug("BUBBLE420",JSON.stringify({kind:"dispose",owner:traceBubble420,at:performance.now()})))
  const align = () => bubbleAlign(props.node)`)
  }
 },
},...(loaded.config.plugins??[])],build:{...loaded.config.build,minify:false,outDir:`C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/sidebar-render-root-420-${phase}-bundle/bin/ui`}})
