const fs=require('node:fs'),path=require('node:path');
const root='.tmp-product-iteration/literal-reference-click-423';fs.mkdirSync(root,{recursive:true});
const record='specs/records/2026-10/2026-10-14-literal-reference-click.md',artifact='specs/artifacts/2026-10-14-literal-reference-click';fs.mkdirSync(artifact,{recursive:true});
fs.writeFileSync(record,`# 正文文件链接的原始路径点击

## Recall

用户要求持续自主迭代，单开发agent，优先Sources与侧栏Rendering，真实体验后提交推送。不得使用子agent。422已提交2d00e71a7；正常push仍在原60982执行，不能把待完成推送写为成功。当前仅原有.bun和packages/opencorvus/bun未跟踪，保留。当前schema版本2，已有历史及迁移保留，不清库、不发布。

## 修改前分析与全仓搜索

已读422 Recall及workspace/file-workbench/server-path、file-reference、markdown提取/链接渲染、main委托点击、SourceParts及07-panel路径合同；全仓搜索parseFileReference、elementFileReference、fileReferenceHtmlAttributes及两种路径attribute全部定义/调用与file-reference纯解析测试。Sources直接点击走openFileReference，正文代码引用走openPathInSelectedEditor，显式Markdown链接走openProjectFile，两种正文委托共同调用elementFileReference。文件workbench和host已保留原始目标；elementFileReference却对已解析并写入attribute的路径再次trim，可将以空白开头的相对文件名变成另一个文件。自然语言parseFileReference的文本边缘解析属于独立合同，不能据此改变已接受资源身份。

显式链接markdownProjectFileReference先分离行列再decodeURI，当前允许百分号编码的文件名前置空白且保留其身份；扩展名仍按现有列表判断。预期触发：项目根下NBSP（No-Break Space，不间断空格）开头的identity-423.md，与普通identity-423.md具有不同内容，真实模型输出[带空白文件](%C2%A0identity-423.md:1)，点击后旧attribute reader裁掉NBSP，可能打开普通文件。该触发尚待真实页面确认，不能先宣称已复现。422只修主机传递，没有覆盖正文attribute读取，420的Markdown生命周期与此路径身份错误独立。

影响为两种正文文件链接的最终路径，现有行号/行范围及错误检查保留。普通Sources和Explorer不变，文案/公共类型/接口/Provider/schema不变。尚无调度、队列、恢复或并发异常证据；若真实运行出现则按共享机制立即横审。现存file-reference测试是纯解析与range映射，不渲染组件、不操作DOM（Document Object Model，文档对象模型）；不新增或运行任何UI（User Interface，用户界面）自动化测试，也不为本UI点击改动引入fake Element断言。

## 实施及验收方案

1. 在412既有隔离项目创建两个不同的实际文件，保留内容与转义后的文件身份；复用422已构建正式bundle作为修改前版本。项目开发服务/ui、一个既有主Session内真实gpt-6.1-sol读取并自然输出两条显式链接，不生成子成员，不注入消息/DOM/Source数据。auth和models配对，credential/catalog/actualModel/streaming预检，12调用/180秒无活动/NativeService600秒。真实点击、原图人工查看与只读请求/数据库事实证明当前错误；随后公开shutdown、join原句柄、physical/output/request收尾和配对退休。
2. 实证成立后只删除elementFileReference对实际path的裁剪，空输入校验只检验而不改写目标。保持唯一reader及所有既有location校验；无需新配置/fallback/兼容层。先保存原文件及差异，按本方案实施。
3. 正式Node构建后新隔离服务/ui重开同一真实历史，点击同一带空白链接，截图确认文件内容与第1行准确，再点普通链接和普通Source复验；界面错误或运行器故障必须修根因重跑。未做到的厂商原生编辑器窗口及完整复制粘贴不冒称通过。
4. 更新唯一07-panel与三索引，当前文档/类型检查、人工差异复核；归档原件与精确资源终态。范围提交，fresh fetch/merge、完整pending集合审查后正常push。无新branch/worktree、无no-verify、无发布。
`);
fs.writeFileSync(artifact+'/README.md','# 正文文件链接原始路径证据\n\n[方案与Recall](../../records/2026-10/2026-10-14-literal-reference-click.md)。修改前真实点击与修后同历史复验将在执行后记录；不以DOM断言或截图差异替代人工视觉验收。\n');
for(const [file,line] of [
 ['specs/README.md','- [正文文件链接原始路径](records/2026-10/2026-10-14-literal-reference-click.md)：已解析资源身份的点击传递与真实页面验收。'],
 ['specs/records/2026-10/README.md','- [正文文件链接原始路径](2026-10-14-literal-reference-click.md)：正文点击的原始路径保真。'],
 ['specs/artifacts/README.md','- [正文文件链接原始路径](2026-10-14-literal-reference-click/README.md)：真实点击、文件身份和验收原件。'],
]){const text=fs.readFileSync(file,'utf8');fs.writeFileSync(file,text.trimEnd()+'\n\n'+line+'\n');}
fs.copyFileSync('packages/overlay/src/utils/file-reference.ts',root+'/file-reference.ts.before');
const project='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/member-live-rendering-412-fresh/project';
const files=[{path:'\u00a0identity-423.md',content:'# IDENTITY_LEADING_NBSP_423\n这是文件名开头保留不间断空格的真实文件。\n'},{path:'identity-423.md',content:'# IDENTITY_PLAIN_423\n这是没有开头空白的另一真实文件。\n'}];
for(const file of files){const target=path.join(project,file.path);if(fs.existsSync(target))throw Error('Owned material already exists');fs.writeFileSync(target,file.content);}
fs.writeFileSync(root+'/material.json',JSON.stringify({project,files},null,2));
for(const [phase,port] of [['before',18567],['after',18569]]){fs.mkdirSync(root+'/'+phase,{recursive:true});for(const name of ['launch.ps1','settle.ps1','shutdown.ps1']){let text=fs.readFileSync('.tmp-product-iteration/literal-file-targets-422/ui/'+name,'utf8').replaceAll('literal-file-targets-422-ui',`literal-reference-click-423-${phase}`).replaceAll('literal-file-targets-422-',`literal-reference-click-423-${phase}-`).replaceAll('.tmp-product-iteration/literal-file-targets-422/ui',root+'/'+phase).replaceAll('18565',String(port));if(phase==='before')text=text.replaceAll('literal-reference-click-423-before-bundle','literal-file-targets-422-ui-bundle');fs.writeFileSync(root+'/'+phase+'/'+name,text);}}
console.log({record,artifact,project,files:files.map(f=>JSON.stringify(f.path))});
