import fs from 'node:fs'
import path from 'node:path'
import zlib from 'node:zlib'
import {createRequire} from 'node:module'
import {Database} from 'bun:sqlite'
import {CredentialRedactor} from '../../packages/opencorvus/script/real-provider-audit'
import {completedToolOutcomeOutput} from '../../packages/opencorvus/src/session/tool-outcome-facts'
const root=import.meta.dir,dest=path.resolve('specs/artifacts/2026-10-14-literal-reference-click')
const base='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14'
const redactor=new CredentialRedactor()
redactor.collect(JSON.parse(fs.readFileSync('C:/Users/hengu/AppData/Local/opencorvus/data/auth.json','utf8')))
const save=(name:string,value:string)=>{const target=path.join(dest,name);fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,zlib.gzipSync(redactor.redact(value)))}
const requireProduction=createRequire(path.resolve('packages/opencorvus/package.json'))
const {drizzle}=await import(requireProduction.resolve('drizzle-orm/bun-sqlite'))
const db=new Database(base+'/member-live-rendering-412-fresh/runtime/data/opencorvus.db',{readonly:true})
const outputDB=drizzle({client:db})
let facts:any
try {
 db.exec('BEGIN')
 const sessionID='ses_-zURzTlJFzzacrP6FufN'
 const sessions=db.query('SELECT id,project_id,directory,kind,parent_id,title,metadata FROM session WHERE id=?').all(sessionID)
 const allMessages=db.query('SELECT id,session_id,data FROM message WHERE session_id=? ORDER BY time_created,id').all(sessionID).map((r:any)=>({...JSON.parse(r.data),id:r.id,sessionID:r.session_id}))
 const allIDs=new Set(allMessages.map((m:any)=>m.id))
 const allParts=db.query('SELECT id,message_id,data FROM part ORDER BY time_created,id').all().filter((r:any)=>allIDs.has(r.message_id)).map((r:any)=>({...JSON.parse(r.data),id:r.id,messageID:r.message_id}))
 const input=allParts.filter((p:any)=>p.type==='text'&&p.text?.includes('最终只输出这两个Markdown链接')).at(-1)
 if(!input)throw Error('Actual requested turn required')
 const inputIndex=allMessages.findIndex((m:any)=>m.id===input.messageID)
 const messages=allMessages.slice(inputIndex)
 const ids=new Set(messages.map((m:any)=>m.id)),parts=allParts.filter((p:any)=>ids.has(p.messageID))
 const tools=db.query('SELECT id,message_id,data FROM tool_part_request ORDER BY time_created,id').all().filter((r:any)=>ids.has(r.message_id)).map((r:any)=>({...JSON.parse(r.data),id:r.id,messageID:r.message_id}))
 const toolIDs=new Set(tools.map((t:any)=>t.id))
 const outcomes=db.query('SELECT request_part_id,data FROM tool_part_outcome ORDER BY time_created,id').all().filter((r:any)=>toolIDs.has(r.request_part_id)).map((r:any)=>{const data=JSON.parse(r.data);return {...data,requestPartID:r.request_part_id,output:completedToolOutcomeOutput(outputDB as any,data,()=>r.request_part_id)}})
 facts={boundary:'Actual existing-main-session turn, read-only persistent facts; no injected messages and no native IDE acceptance',schema:db.query('PRAGMA user_version').get(),sessions,messages,parts,tools,outcomes}
}finally{db.exec('ROLLBACK');db.close()}
const baseline=root+'/facts-before.json'
if(!fs.existsSync(baseline))fs.writeFileSync(baseline,JSON.stringify(facts,null,2))
const before=JSON.parse(fs.readFileSync(baseline,'utf8'))
fs.writeFileSync(root+'/facts-current.json',JSON.stringify(facts,null,2))
save('facts/before.json.gz',JSON.stringify(before,null,2));save('facts/current.json.gz',JSON.stringify(facts,null,2))
const comparison={comparedAt:new Date().toISOString(),boundary:'Field/content equality of the same persisted business turn, not mutable source hashes',retained:JSON.stringify(before)===JSON.stringify(facts),sessionIDs:facts.sessions.map((s:any)=>s.id),messageIDs:facts.messages.map((m:any)=>m.id),sourceIDs:facts.parts.filter((p:any)=>p.type==='source-file').map((p:any)=>p.id)}
save('facts/comparison.json.gz',JSON.stringify(comparison,null,2))
const material=JSON.parse(fs.readFileSync(root+'/material.json','utf8'))
save('facts/material.json.gz',JSON.stringify({...material,files:material.files.map((file:any)=>({...file,observedContent:fs.readFileSync(path.join(material.project,file.path),'utf8'),escapedPath:file.path.replaceAll('\u00a0','\\u00a0')}))},null,2))
const provider=[]
for(const phase of ['before','after']) {
 const local=root+'/'+phase,evidence=base+'/literal-reference-click-423-'+phase+'/evidence'
 for(const name of fs.readdirSync(local)){
  if(/\.(png|jpg)$/.test(name)){fs.mkdirSync(dest+'/'+phase,{recursive:true});fs.copyFileSync(local+'/'+name,dest+'/'+phase+'/'+name)}
  else if(/\.(log|json|jsonl|ps1)$/.test(name))save(phase+'/'+name+'.gz',fs.readFileSync(local+'/'+name,'utf8'))
 }
 if(!fs.existsSync(evidence))continue
 const audits=fs.readdirSync(evidence).filter(n=>/^provider-.*\.json$/.test(n)&&!n.startsWith('provider-pair')).map(name=>({name,data:JSON.parse(fs.readFileSync(evidence+'/'+name,'utf8'))})).sort((a,b)=>String(a.data.observedAt).localeCompare(String(b.data.observedAt)))
 const latest=audits.at(-1)!
 provider.push({phase,file:latest.name,observedAt:latest.data.observedAt,requests:latest.data.requests.map((r:any)=>({model:r.model,streaming:r.streaming,status:r.status,reader:r.response_reader}))})
 for(const name of fs.readdirSync(evidence)){
  if(name.startsWith('provider-')&&name!==latest.name&&name!=='provider-pair-staging.json')continue
  if(name.endsWith('.json'))save(phase+'/native/'+name+'.gz',fs.readFileSync(evidence+'/'+name,'utf8'))
 }
}
save('facts/provider-summary.json.gz',JSON.stringify(provider,null,2))
for(const name of ['build.log','docs-check.log','architecture-check.log','parser-check.log','archive.ts','prepare.cjs'])if(fs.existsSync(root+'/'+name))save('checks/'+name+'.gz',fs.readFileSync(root+'/'+name,'utf8'))
save('before/file-reference.ts.before.gz',fs.readFileSync(root+'/file-reference.ts.before','utf8'))
console.log(JSON.stringify({comparison,messages:facts.messages.map((m:any)=>({id:m.id,role:m.role,finish:m.finish,time:m.time})),tools:facts.tools,outcomes:facts.outcomes.map((o:any)=>({requestPartID:o.requestPartID,status:o.status,output:o.output})),sources:facts.parts.filter((p:any)=>p.type==='source-file'),provider:provider.map(p=>({phase:p.phase,requests:p.requests.map((r:any)=>({model:r.model,streaming:r.streaming,status:r.status,state:r.reader?.state,terminal:r.reader?.terminal?.kind}))}))},null,2))
