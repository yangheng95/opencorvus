// PREPARED, NOT EXECUTED. Finite owned producer; this is not Mission or server E2E.
import assert from "node:assert/strict"
import fs from "node:fs"
import path from "node:path"
import { pathToFileURL } from "node:url"
import { argumentsFor, exclusiveJson, makeRecorder, tailBytes } from "./evidence.mjs"

const args = argumentsFor(["--run-root"])
assert(process.platform === "win32" && args["--run-root"])
const runRoot = path.resolve(args["--run-root"])
const input = JSON.parse(fs.readFileSync(path.join(runRoot, "prepared-run.json"), "utf8"))
assert.equal(runRoot, input.runRoot)
assert.equal(process.env.OPENCORVUS_HOME, path.join(runRoot, "runtime"))
assert.equal(Bun.version, input.expectedBunVersion)
const record = makeRecorder(path.join(runRoot, "evidence", "producer-events.jsonl"), "finite-producer", input.experimentID)
const source = (name) => pathToFileURL(path.join(input.packageRoot, name)).href
const physical = await import(source("src/runtime/process-occurrence.ts"))
const producer = physical.currentRuntimeProcessOccurrence()
const parent = physical.observedProcessOccurrence(process.ppid)
assert(parent && physical.currentWindowsProcessIsInJob())
let shuttingDown = false
const server = Bun.serve({ hostname: "127.0.0.1", port: 0, async fetch(request) {
  const url = new URL(request.url)
  if (request.method === "GET" && url.pathname === `/health/${input.experimentID}`)
    return Response.json({ experimentID: input.experimentID, producer, shuttingDown })
  if (request.method !== "POST" || url.pathname !== `/shutdown/${input.experimentID}`)
    return Response.json({ outcome: "invalid-owned-route" }, { status: 400 })
  const body = await request.json()
  if (body.experimentID !== input.experimentID || body.producerOccurrenceID !== producer.occurrenceID || shuttingDown)
    return Response.json({ outcome: "invalid-owned-occurrence" }, { status: 409 })
  shuttingDown = true
  record.event("normal-shutdown-admitted", { producer, body })
  // Give the admitted HTTP response time to leave before the finite tail.
  setTimeout(() => { void finish() }, 200)
  return Response.json({ outcome: "normal-shutdown-admitted", experimentID: input.experimentID, producer })
} })
exclusiveJson(path.join(runRoot, "evidence", "producer-ready.json"), {
  experimentID: input.experimentID, producer, parent, inWindowsJob: true, url: server.url.href,
  actualBunVersion: Bun.version, tailBytes: tailBytes(input.experimentID).length, observedAtUtc: new Date().toISOString(),
})
record.event("listening", { producer, parent, url: server.url.href })

async function finish() {
  try {
    const stdout = tailBytes(input.experimentID)
    const stderr = Buffer.from(`NATIVE_SINK_STDERR_TAIL:${input.experimentID}\n`, "utf8")
    record.event("finite-tail-started", { stdoutBytes: stdout.length, stderrBytes: stderr.length })
    await Bun.write(Bun.stderr, stderr)
    record.event("stderr-tail-written", { bytes: stderr.length })
    const result = await Bun.write(Bun.stdout, stdout)
    record.event("stdout-tail-written", { expectedBytes: stdout.length, writeResult: result })
    await server.stop(false)
    exclusiveJson(path.join(runRoot, "evidence", "producer-exit-intent.json"), {
      experimentID: input.experimentID, producer, intent: "normal-exit", requestedExitCode: 0,
      observedAtUtc: new Date().toISOString(), boundary: "Intent only; native physical marker/exit supplies completion",
    })
    process.exit(0)
  } catch (error) {
    record.event("finite-producer-error", { error: record.errorFact(error) })
    process.exit(1)
  }
}
