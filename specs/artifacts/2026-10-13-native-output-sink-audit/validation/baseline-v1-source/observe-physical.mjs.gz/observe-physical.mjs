// PREPARED ONLY. Optional later-authorized read-only birth-identity observer, separate from both matrix runs.
import assert from "node:assert/strict"
import fs from "node:fs"
import path from "node:path"
import { pathToFileURL } from "node:url"
import { argumentsFor, applyIsolatedEnvironment, exclusiveJson, readObservation } from "./evidence.mjs"

const args = argumentsFor(["--run-root"])
assert(process.platform === "win32" && args["--run-root"])
const runRoot = path.resolve(args["--run-root"])
const ownedBase = path.resolve("C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13")
assert.equal(path.dirname(runRoot).toLowerCase(), ownedBase.toLowerCase())
assert(path.basename(runRoot).startsWith("native-sink-"))
assert.equal(fs.realpathSync.native(runRoot).toLowerCase(), runRoot.toLowerCase())
const input = JSON.parse(fs.readFileSync(path.join(runRoot, "prepared-run.json"), "utf8"))
assert.equal(input.runRoot, runRoot)
applyIsolatedEnvironment(runRoot, input.executable)
const physical = await import(pathToFileURL(path.join(input.packageRoot, "src/runtime/process-occurrence.ts")).href)
const ready = readObservation(path.join(runRoot, "evidence", "host-ready.json"))
assert.equal(ready.status, "present", "Exact ready birth identities required; never fabricate a recovered identity")
assert.equal(ready.value.experimentID, input.experimentID)
const result = { experimentID: input.experimentID, observer: physical.currentRuntimeProcessOccurrence(),
  host: { identity: ready.value.host, observation: physical.observeRuntimeProcessOccurrence(ready.value.host) },
  target: { identity: ready.value.target, observation: physical.observeRuntimeProcessOccurrence(ready.value.target) },
  originalRequestDirectory: readObservation(path.dirname(ready.value.request.ready_file)),
  observedAtUtc: new Date().toISOString(), boundary: "Physical birth observation only; never substitutes output/request settlement or rewrites prior failure" }
exclusiveJson(path.join(runRoot, "evidence", "physical-observer.json"), result)
