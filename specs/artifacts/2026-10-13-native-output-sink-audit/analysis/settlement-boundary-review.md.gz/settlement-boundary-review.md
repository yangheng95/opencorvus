# 公开结算与原始 Supervisor 收尾边界：只读核对

本报告为本轮证据分析，主agent负责落入正式spec；未授权且未修改任何产品代码、测试或执行其它进程实例。

新事实不是原before-failed精确归因。故障v2的公开facade.settled于13:13:23.624Z拒绝，原rawSupervisor.settled于.629Z拒绝并实际完成request目录删除；Host aggregate记录.626Z，registry退休.647Z。原物理exited/terminalFact都是0且在公开拒绝前已fulfilled。事件原完整时刻、同Error引用及markers在native-sink-reader-01a133-v2/evidence/host-events.jsonl，完整原因在observed-causes.json。

## 直接控制流

1. packages/opencorvus/src/util/process-facade.ts69/70的Host与Task只分派实际spawn authority；71–75完全共享：outputSettled取原Supervisor Promise，supervisorSettled取原handle.settled，然后`Promise.all([terminal, outputSettled, supervisorSettled])`生成适配器settled。任一拒绝提前结束该Promise；成功则等全部三成员。原Supervisor层1940–1951使用allSettled(physical,output)，physical成功后仍await唯一request cleanup，最后再合并错误。
2. packages/util/src/process.ts390–410的通用controlledHandle确实allSettled([raw.outputSettled,raw.settled])，但此raw.settled已是前述适配Promise，不是原Supervisor Promise。因此通用allSettled无法恢复被适配器fail-fast丢掉的收尾等待。原raw cleanup后续错误也可能不进入此前已经拒绝的公开settled；本次cleanup成功，未诱发该I/O分支，不声称其实机复现。
3. 原Supervisor owner和Task lease没有改成依赖公开settled：224–226 waitForOwnedPhysicalSettlement等待原exited，再allSettled原handle.settled；1167–1219 registry退出依赖它；422–455 Task read lease同样依赖tracked原handle。因此代码上Task owner/租约不会仅因公开提前reject自行退休。实际pending/unknown路径、取消重试和串并行仍需运行矩阵。
4. 显式公开terminate/dispose由适配器102/106调用Supervisor.disposeAndWaitForExit；Supervisor1271–1315收齐原dispose/exited/outputSettled/settled四路（各有预算）后才返回/抛错。通用controlledHandle417–468再收齐control operation与公开settled。它比只await公开settled更强。runProcess.finally650实际await handle.dispose，成功、失败、observer错误与正常nonzero路径都进入finally；入场abort/deadline的late-handle清理677–680也收齐dispose与settled。
5. 自动abort/deadline是通用controls→后台terminate（process.ts441/458）和公开settled两个不同Promise。terminal正常且output/cleanup均成功时公开settled等真实raw全部完成；若有原输出失败，公开settled仍可能早于后台strict control operation。显式await terminate/dispose才等它；控制失败或预算超时报告不确定性，不能强称真正收尾完成。本次没有运行取消/期限故障组合。

ProcessSpawnedHandle接口（packages/util/src/process.ts116–127）声明terminal/outputSettled/settled但没有另一份error-barrier语义。当前架构server-runtime-readiness.md25–31说监督的Host/Task adapter经Supervisor join disposal、physical、output、settlement，只有complete settlement授权删除隔离runtime，uncertainty保留。这至少排除把公开reject当作完整清理证明；是否将公开settled所有终态都定义为完整收齐、怎样保留全部最终cause，应由下一正式方案明确，不能仅依靠名称猜合同。

## 全生产入口的不同收尾来源

- Facade Host/Task run、command-inactivity、plugin提供的run：共用adapter，但runProcess finally严格dispose。plugin提供spawn仍暴露公开settled候选。直接spawn caller须逐一审查不能将run路径的finally借给spawn。
- util/process.ts100–112的Child把exited投影为handle.terminal，没有暴露settled/dispose。CLI pager session.ts208–221只await这个physical exited，inherit pipe目的端和request收尾没有调用方显式join。该接口是独立影响面；当前CLI实际退出时机尚未运行，不能以exited命名猜完整输出。
- Shell、bash、Session shell使用原Supervisor handle，strict结束路径分别shell/shell.ts176、tool/bash.ts595、session/shell-exec.ts654调用disposeAndWaitForExit，绕过此Facade fail-fast实现但仍共享Supervisor物理/output/request根和外sink风险。
- BrowserNode executor149使用Promise.all(exited,outputSettled)作过程结果，199实际dispose；需要其error cleanup与auxiliary role矩阵，不能把这另一处Promise.all直接认定同Facade request遗漏。BrowserMCP launcher110–112等待原exited再strictdispose。
- MCP transport1846–1858真实close调用strictdispose，1805–1816的exitObserved只负责退出/onclose通知。通知与完整close不是同Promise，Task与Host均须actual transport验证。
- codebase-tools220–221、file-broker114–116、ripgrep244/264有各自exited/output/dispose组合，不全部使用strict四路；package-tool-capsule614、plugin-tool-host205使用strictdispose。只读定位不能证明全部失败时finally均完备。
- restart-handoff168处理原Supervisor handle，其detached/transfer目录与diagnostic file descriptor是独立合同，不借用此次non-detached结果。NodeProcess owned_process/detached接口还有各自原settled组成，同属下一横审边界。

## inherit 与本次 caller drain 的区别

Facade项目输出在process-facade.ts76–90：inherit仅`stream.pipe(process.stdout/stderr)`且公开stream返回null；没有新destination settlement Promise纳入71–75，也没有显式destination error→原Supervisor错误的桥。原outputSettled是helper.close与原source/PassThrough错误记录（Supervisor1739–1862），不直接观察process.stdout/stderr目的对象。本次caller for-await的EPIPE→iterator destroy→原source ABORT_ERR链并不是inherit .pipe链；不能推定Bun1.4对目的端错误必然同样abort原source或一定global fatal。

BrowserMCP58–59显式pipe({end:false})，MCP1795–1800在data handler直接写stderr且不wait drain；后者custom stderr Stream路径也没有目的端结算桥。原stdout协议和source error hooks1788–1803并不等于目的端错误收齐。安装的生产全局错误日志util/process-error-logging.ts最终rethrow，不是恢复/吞错。需要真实Bun/Node断inherit目的端的新独立矩阵，在共享backend两个Project、Task/Mission/Session occurrence与重试/重启恢复上记录真实影响，不预设流程结果。

## 原成熟 UI Host 早退证据限度

.tmp-codex-explorer-01a133/native-host.ts49–64只收齐公开handle.settled与两个caller drains，catch71–80异步写原错误receipt后process.exit1；没有直接join原Supervisor或严格dispose。代码允许公开失败后、原raw cleanup仍pending时进入catch/退出，但异步fact写盘会给pending工作时间，原例没有raw states、markers或逐分支cause。本次新scratch还在finally显式等待bounded metrics，确实改变了失败后寿命，不能据此宣称旧实例的owner/request已净，也不能证明旧实例一定截断清理。

尚需证据：原式立即退出在全新自有fixture中的原marker/request与物理事实；生产inherit真实目的端失败；已知physical+output failure时后续cleanup error收齐；Task正常/错误/取消/期限、多Project串并行和重启/orphan。这里只给候选与最小影响面，不执行新实例、不加listener/fallback、不把旧Aggregate补写为已识别。
