# 首轮 Native 外输出运行证据

这是本任务 scratch 运行报告，来源为两发生实例原 journal/receipt 和本目录 `run-summary.json`、`observed-causes.json`；主 agent 负责归档到 specs。没有产品改动、模型调用、凭据或模型目录读取/复制、UI 自动化、用户窗口/进程操作。

Node 实际 v25.7.0，Host/producer 实际 Bun1.4.0；修前与环境修正后五项 `node --check` 各 exit0。原输出在 validation；未覆盖首次失败。v1 错设 OPENCORVUS_TEST_HOME 导致 Global 的测试运行时资格在 Supervisor import/spawn 前拒绝，Host85812 实际 exit/close1，父两个 drain fulfilled，stdout0B/stderr915B，Host birth/Target/raw/request unavailable、shutdownDispatched=false。v1 原五脚本保存在 validation/baseline-v1-source；仅去掉测试专用环境项，普通独立 HOME/USERPROFILE/OPENCORVUS_HOME 保留。Root 另行落盘并授权 v2 两精确目录，没有复用 v1。

| 事实 | baseline v2 | close-stdout-reader v2 |
| --- | --- | --- |
| 实验身份 | aae5a229-afb0-4f4c-87f1-04cdba922139 | 6b4e0ab5-9513-4091-a797-37c4ac72cf0f |
| Controller PID / 实际 exit | 76512 / 0 | 80168 / 1 |
| Host PID / birth / 实际 exit | 85880 / win32:639274939740638251 / 0 | 81060 / win32:639274940018663884 / 1 |
| Target PID / birth / 原始退出 | 80288 / win32:639274939756072430 / 0 | 13496 / win32:639274940031306768 / 0 |
| Native helper PID | 85344 | 61836 |
| 原 request_id | 05de591c-db67-4b1b-92dc-46c969468b37 | ca047e46-c804-404b-9f6c-907720ac13c6 |
| 唯一正常 shutdown | 一次，真实200 | reader close后一次，真实200 |
| Facade terminal | fulfilled, exited/exit0 | fulfilled, exited/exit0 |
| raw Supervisor exited/terminalFact | fulfilled/0 | fulfilled/0 |
| raw outputSettled / settled | fulfilled / fulfilled | rejected / rejected，同原 Error ref14，cause ref15 ABORT_ERR |
| Facade outputSettled / settled | fulfilled / fulfilled | rejected / rejected，同原 Error ref14 |
| output Promise 别名 | 两 outputSettled 均 Promise ID5，是同一个来源 | 同样 ID5，不当作独立证明 |
| Native stdout drain | fulfilled, 65,536B | rejected, 原 EPIPE ref13, errno -4047, syscall write |
| Native stderr drain | fulfilled, 61B | fulfilled, 61B |
| Controller stdout drain | fulfilled, 65,536B，与明确输入字节完全相等 | rejected, ERR_STREAM_PREMATURE_CLOSE，实际接收0B |
| Controller stderr drain | fulfilled, 61B，完整唯一尾 | fulfilled, 61B，完整唯一尾 |
| Controller Host exit/close Promise | 都 fulfilled，实际code0 | 都 fulfilled，实际code1 |
| Native active-zero marker | 原两时刻捕获，匹配request/helper/target/runtime, active_processes0 | 同样实际捕获，active_processes0 |
| 原请求目录 | 原 raw settled 后实际 ENOENT | 原 raw settled 后实际 ENOENT |
| Host registry owner | 实际退休，live/count0 | 实际退休，live/count0 |
| 另行授权只读 observer | 一次，exit0；原 Host/Target birth dead_or_reused | 一次，exit0；原 Host/Target birth dead_or_reused |

本次断管道的精确控制流：controller13:13:23.376Z仅destroy自己ChildProcess.stdout，无Error参数；.379Z该reader closed，stderrDestroyed=false；.380Z唯一shutdown dispatch，.387Z实际200。Target在.589Z向自身stdout提交全部65,536B并随后实际退出0。Host原destination.write在.593Z返回false，随后原once(destination,"drain")在.594Z以EPIPE拒绝；不是同步write throw。for-await退出时源Readable的async iterator destroy产生ABORT_ERR，Supervisor捕获并包装为原Error ref14。公开和原始错误链、堆栈和引用身份都保留在原host-events.jsonl及observed-causes.json。两层wholeAllSettled fulfilled只表示收齐每成员结果，不代表每成员成功；本次Native聚合包含[ref14 ABORT_ERR包装、ref13 EPIPE]，Controller同样保留原reader premature-close错误及实际退出1。

重要时序：故障Host journal seq31公开facade.settled拒绝13:13:23.624Z；seq32外三成员收齐同.624；seq33聚合事实.626；seq34原rawSupervisor.settled拒绝.629，其后的原请求目录观察已经ENOENT；seq36 registry退休.647。Scratch finally进行最多1秒的只读metrics观察，本次给原raw异步收尾额外约20ms。该差异是运行资格边界，不能把新发生实例的request清理等价到旧matureHost catch后即exit的路径。

baseline真实完成后才执行故障实例；两者都早于45秒绝对期限，无观察timeout、重启、kill或替代实例。两个observer不是原输出/请求收尾证明，独立物理观察只作为补证。原before-failed AggregateError子分支仍未知；新EPIPE/ABORT_ERR只证明新发生实例，不重写旧失败。

## 全矩阵当前资格

| 生产范围与当前入口 | 本次运行资格 | 尚缺的真实运行 |
| --- | --- | --- |
| util/process-facade.ts69–85 Host/Task，util/process.ts119/188/199 | Host owned_tree + caller drain +完整正常和断sink事实 | actual Task，Facade inherit双输出，root-exit true/false |
| cli/cmd/session.ts208 pager inherit | 只读；Child.exited只投影物理terminal | actual inherited目的端失败与Caller退出 |
| mcp/browser/node-launcher.ts44/58/59/193 | 只读actual stdio/http转写入口 | launcher两输出断端、stdin正常收尾、signal/timeout |
| mcp/index.ts1781/1785/1799 | 只读Host/Task stderr inherit/custom及协议stdout | actual transport，两个authority与真实close |
| shell/shell.ts188/198/377/387，tool/bash.ts384，session/shell-exec.ts583 | 只读Host/Task、gated及strict disposal | 正常/错误/取消/期限、mandatory/auxiliary、原Task轮次 |
| file/ripgrep.ts210，browser/runtime/node-executor.ts220/244，engine/codebase-tools.ts202 | 只读同Supervisor及其收集/清理方式 | 每生产consumer错误与完整收尾 |
| execution-capsule/file-broker.ts104，expert-squad/package-tool-capsule.ts500，tool/plugin-tool-host.ts152 | 只读Task入口 | capsule/native，受控失败及真实调用收敛 |
| plugin/index.ts181/543，shell/command-inactivity.ts34/40 | 只读Facade能力与run路径 | 初始化/hook、inactivity、重试 |
| process-supervisor.ts422/596/627/639/666，task-api/index.ts3203 | 只读Task租约/取消/terminal/checkpoint | Task mandatory与auxiliary、后续execution epoch、all owner退休 |
| process-supervisor.ts224/1167/1870/1940 | 本次Host正常和output失败都完成原physical/marker/request/registry事实 | physical unknown、request I/O failure、pending、重试后完整收尾 |
| process-supervisor.ts853，server/restart-handoff.ts126 | 只读孤儿/transfer角色 | exact-live/dead/unknown、retained/quarantined、实际重启 |
| engine/task-session-lineage.ts158，session/prompt/owner.ts287，mission/process-recovery.ts135/199，server/server.ts363 | 只读lineage/generation/epoch/恢复入口 | 真实Task/Mission/Session正常、终态、中断、恢复与持久事实 |
| 同backend两个Project/shared temporary基址 | 未运行 | 唯一request/owner，串行重试、并行一坏一对照；不能用两个独立runtime替代，也不预设全局Host fatal后另一Project仍存活 |
| Node adapter owned_process/detached、ACP stdout writer | 不同边界，仅已定位 | 不借本次Supervisor数据验收 |

如后续需要真实Sol才能进入实际Mission恢复链，必须先另行授权并绑定成对auth与models，分别验证凭据可用、目标目录projection和实际请求模型；所有模型交互流式。本次没有必要性，也没有读取或复制。
