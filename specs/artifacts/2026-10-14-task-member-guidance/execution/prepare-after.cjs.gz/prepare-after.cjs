const fs=require('node:fs'),path=require('node:path');
const scratch=path.resolve('.tmp-product-iteration/task-member-guidance-413');
for(const name of ['launch.ps1','settle.ps1','shutdown.ps1']){
 let code=fs.readFileSync(path.join(scratch,name),'utf8').replaceAll('task-member-guidance-413-live','task-member-guidance-413-after').replaceAll('18529','18531');
 if(name==='launch.ps1')code=code.replace('"40" "Task"','"12" "NativeService"').replaceAll('task-guidance-413-selection.json','task-guidance-413-after-selection.json').replaceAll('task-member-guidance-413/settle.ps1','task-member-guidance-413/settle-after.ps1');
 fs.writeFileSync(path.join(scratch,name.replace('.ps1','-after.ps1')),code,{flag:'wx'});
}
const bundle='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/task-member-guidance-413-after-bundle';
fs.mkdirSync(path.join(bundle,'bin'),{recursive:true});
fs.copyFileSync('.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64/bun.exe',path.join(bundle,'bin/bun.exe'),fs.constants.COPYFILE_EXCL);
console.log(JSON.stringify({bundle,port:18531,requests:12,nativeMaximumMs:600000}));
