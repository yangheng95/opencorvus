const fs=require('node:fs'),path=require('node:path'),zlib=require('node:zlib'),assert=require('node:assert/strict');
const scratch=path.resolve('.tmp-product-iteration/task-member-guidance-413'),out=path.resolve('specs/artifacts/2026-10-14-task-member-guidance');
const read=p=>JSON.parse(fs.readFileSync(p,'utf8').replace(/^\uFEFF/,''));
const save=(p,bytes)=>{fs.mkdirSync(path.dirname(p),{recursive:true});if(fs.existsSync(p)){assert.deepEqual(fs.readFileSync(p),Buffer.from(bytes),'Existing captured bytes must match their source');return}fs.writeFileSync(p,bytes,{flag:'wx'})};
const json=(p,v)=>save(p,JSON.stringify(v,null,2)+'\n'),copy=(s,t)=>save(t,fs.readFileSync(s)),zip=(s,t)=>save(t,zlib.gzipSync(fs.readFileSync(s)));
const before=read(path.join(scratch,'facts-before-final.json')),final=read(path.join(scratch,'facts-final.json'));
assert.deepEqual(final.databaseVersion,[{user_version:1}]);
for(const field of ['id','project_id','request_id','session_id','product_pillar'])assert.equal(final.task[field],before.task[field]);
for(const key of ['messages','parts','tools','outcomes']){const identity=key==='outcomes'?'requestPartID':'id';for(const row of before[key])assert.deepEqual(final[key].find(candidate=>candidate[identity]===row[identity]),row,`Retained ${key} ${row[identity]}`)}
for(const row of before.artifacts)assert.deepEqual(final.artifacts.find(a=>a.id===row.id).payload,row.payload,`Immutable Artifact ${row.id}`);
const complete=read('C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/task-member-guidance-413-live/evidence/task-complete.json');
assert.equal(complete.selected.taskID,final.task.id);assert.equal(complete.selected.requestID,final.selection.requestID);assert.equal(complete.lifecycle.status,'completed');assert.equal(complete.pinned.epoch,1);assert.deepEqual(complete.ownedPromptSessions,[]);
const source=final.parts.find(p=>p.type==='source-file'),tool=final.tools.find(t=>t.id===source.toolPartID);
assert.equal(tool.tool,'read');assert.equal(tool.input.offset,2);assert.equal(tool.input.limit,2);assert.equal(tool.messageID,source.messageID);assert.deepEqual(source.range,{startLine:2,endLine:3});assert.equal(final.outcomes.find(o=>o.requestPartID===tool.id).outcome,'completed');
const requestedIDs=['art_d8a7b88ce41c4c8fa127','art_fcba9ba90aca406cad3f'];
const chains=requestedIDs.map(id=>{
 const request=final.artifacts.find(a=>a.id===id);assert.equal(request.kind,'agent_coordination_request');assert.equal(request.payload.origin,'operator_steer');assert.equal(request.payload.task_id,final.task.id);assert.equal(request.payload.execution_epoch,1);assert.equal(request.payload.session_id,'ses_hE2vLKo2M333MIa0Vuq1');
 const response=final.artifacts.find(a=>a.kind==='agent_coordination_response'&&a.payload.request_id===id);
 const action=final.artifacts.find(a=>a.kind==='agent_coordination_action'&&a.payload.request_id===id);
 const outcome=final.artifacts.find(a=>a.kind==='agent_coordination_action_outcome'&&a.payload.request_id===id);
 assert.equal(response.payload.decision,'acknowledge_terminal');assert.equal(action.payload.action,'acknowledge_terminal');assert.equal(outcome.payload.status,'completed');assert.equal(outcome.payload.response_id,response.id);assert.equal(outcome.payload.action_id,action.id);assert.equal(outcome.payload.result.terminal_lifecycle_reference.terminalEventID,complete.lifecycle.terminalEventID);
 const responseTool=final.tools.find(t=>t.id===response.payload.orchestrator_tool_part_id);assert.equal(responseTool.tool,'respond_agent_coordination');assert.equal(responseTool.messageID,response.payload.orchestrator_message_id);assert.equal(final.outcomes.find(o=>o.requestPartID===responseTool.id).outcome,'completed');
 return {requestID:id,sessionID:request.payload.session_id,input:request.payload.operator_message,responseID:response.id,decision:response.payload.decision,message:response.payload.message,actionID:action.id,outcomeID:outcome.id,terminalEventID:complete.lifecycle.terminalEventID};
});
assert.equal(chains[1].input,'请仅确认收到这条说明，不需要追加任何工作。原任务和成员保持已完成状态。');
json(path.join(out,'persisted-check.json'),{taskID:final.task.id,projectID:final.task.project_id,rootSessionID:final.task.session_id,databaseVersion:final.databaseVersion,initialTaskCompletion:complete.lifecycle,retainedMessages:before.messages.length,source:{id:source.id,path:source.path,range:source.range,toolPartID:source.toolPartID},coordination:chains,boundary:'Actual production SQLite, completed Task monitor and real Tool/response/action/outcome bindings. First requested additional work was acknowledged only under the terminal contract; this does not prove worker redispatch or streaming dock reopen.'});
for(const name of ['facts-initial.json','facts-guidance.json','facts-before-final.json','facts-final.json','task-request.json','task-selection.json','task-accepted.json'])zip(path.join(scratch,name),path.join(out,'facts',name+'.gz'));
for(const name of fs.readdirSync(scratch).filter(x=>/^\d\d-.*\.jpg$/.test(x)))copy(path.join(scratch,name),path.join(out,name));
const scopes=[];
for(const suffix of ['live','after','after02']){
 const dir=`C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/task-member-guidance-413-${suffix}/evidence`,target=path.join(out,suffix);fs.mkdirSync(target,{recursive:true});
 for(const name of ['native-host-ready.json','native-host-settled.json','physical-terminal-and-pair-cleanup.json','launcher-child-exit.json','preflight-ready.json','public-shutdown.json'])copy(path.join(dir,name),path.join(target,name));
 for(const name of ['task-boundary-admitted.json','task-occurrence-admitted.json','task-complete.json'])if(fs.existsSync(path.join(dir,name)))copy(path.join(dir,name),path.join(target,name));
 const audits=fs.readdirSync(dir).filter(n=>n.startsWith('provider-')&&n.endsWith('.json')).map(name=>({name,data:read(path.join(dir,name))})).filter(x=>Array.isArray(x.data.requests)&&typeof x.data.observedAt==='string').sort((a,b)=>Date.parse(a.data.observedAt)-Date.parse(b.data.observedAt));
 assert.ok(audits.length);const audit=audits.at(-1);copy(path.join(dir,audit.name),path.join(target,'provider-audit.json'));
 const native=read(path.join(dir,'native-host-settled.json')),cleanup=read(path.join(dir,'physical-terminal-and-pair-cleanup.json'));
 assert.equal(native.terminal.reason,'exited');assert.equal(native.terminal.exitCode,0);assert.equal(native.physicalCompletion,true);assert.equal(native.outputDrainComplete,true);assert.equal(native.requestCleanupComplete,true);assert.equal(cleanup.pairedCleanupComplete,true);
 for(const r of audit.data.requests){assert.equal(r.model,'gpt-6.1-sol');assert.equal(r.streaming,true);assert.equal(r.status,200);assert.equal(r.response_reader.state,'settled');assert.equal(r.response_reader.terminal.kind,'eof')}
 scopes.push({scope:suffix,occurrence:native.occurrence,requests:audit.data.requests.length,nativeTerminal:native.terminal,physicalCompletion:true,outputDrainComplete:true,requestCleanupComplete:true,pairedCleanupComplete:true});
}
json(path.join(out,'execution-summary.json'),{scopes,toolJoins:{live:{handle:45947,chunk:'c31763',exitCode:0},after:{handle:75595,chunk:'a603fb',exitCode:0},after02:{handle:28989,chunk:'486b36',exitCode:0}},builds:[{handle:7909,exitCode:0},{handle:84230,exitCode:0},{handle:80496,exitCode:0}],typecheck:{handle:61009,exitCode:0},taskCreate:{chunk:'2f8378',exitCode:0},screenshots:12,browser:'Own pages 30,31,32 closed; prior error tab 27 was confirmed absent at the beginning of this batch.'});
for(const name of fs.readdirSync(scratch).filter(n=>/\.(ps1|cjs|ts|log)$/.test(n)&&!n.startsWith('archive-check')&&!n.endsWith('-before.tsx')&&!n.startsWith('commit')&&!n.startsWith('prepare-commit')))zip(path.join(scratch,name),path.join(out,'execution',name+'.gz'));
zip('.tmp-product-iteration/live-sol-task-guidance-413.ts',path.join(out,'execution/live-sol-task-guidance-413.ts.gz'));
const carry=[];for(const name of ['push.log','push-exit.json','fetch.log','merge.log','remote-after-push.txt']){
 const file=path.join('.tmp-product-iteration/member-live-rendering-412',name),exists=fs.existsSync(file);carry.push({name,capturedAsFile:exists});if(exists)zip(file,path.join(out,'previous-412',name+'.gz'));
}
json(path.join(out,'previous-412/capture-boundary.json'),{files:carry,push:{handle:24250,chunk:'ac0b17',exitCode:0},fetchMerge:{chunk:'c68d91',exitCode:0},commit:'50cf35a83baa9467e59aa91f541fc0d53dd8756b',boundary:'Empty fetch output can produce no Tee file; no original log is invented.'});
console.log(JSON.stringify({scopes,initialTaskStatus:complete.lifecycle.status,chains:chains.map(c=>({requestID:c.requestID,decision:c.decision,outcomeID:c.outcomeID})),retainedMessages:before.messages.length,screenshots:12},null,2));
