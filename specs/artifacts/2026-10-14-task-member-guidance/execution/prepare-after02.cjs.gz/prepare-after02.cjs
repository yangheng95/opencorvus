const fs=require('node:fs'),path=require('node:path');
const scratch=path.resolve('.tmp-product-iteration/task-member-guidance-413');
for(const base of ['launch','settle','shutdown']){
 const code=fs.readFileSync(path.join(scratch,base+'-after.ps1'),'utf8').replaceAll('task-member-guidance-413-after','task-member-guidance-413-after02').replaceAll('18531','18533').replaceAll('settle-after.ps1','settle-after02.ps1');
 fs.writeFileSync(path.join(scratch,base+'-after02.ps1'),code,{flag:'wx'});
}
const bundle='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/task-member-guidance-413-after02-bundle';
fs.mkdirSync(path.join(bundle,'bin'),{recursive:true});
fs.copyFileSync('.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64/bun.exe',path.join(bundle,'bin/bun.exe'),fs.constants.COPYFILE_EXCL);
console.log(JSON.stringify({bundle,port:18533,requests:12,nativeMaximumMs:600000}));
