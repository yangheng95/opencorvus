const fs=require('node:fs'),path=require('node:path');
const scratch=path.resolve('.tmp-product-iteration/task-member-guidance-413');
const wrapper=fs.readFileSync('.tmp-product-iteration/live-sol-member-rendering-412-after.ts','utf8');
fs.writeFileSync('.tmp-product-iteration/live-sol-task-guidance-413.ts',wrapper,{flag:'wx'});
let launch=fs.readFileSync('.tmp-product-iteration/member-live-rendering-412/launch-after.ps1','utf8').replaceAll('member-live-rendering-412-after','task-member-guidance-413-live').replaceAll('member-live-rendering-412-\'+','task-member-guidance-413-\'+').replaceAll('live-sol-member-rendering-412-after.ts','live-sol-task-guidance-413.ts').replaceAll('member-live-rendering-412/settle-after.ps1','task-member-guidance-413/settle.ps1').replaceAll('18527','18529').replace('"20" "NativeService"','"40" "Task"').replaceAll('reader-selection.json','task-guidance-413-selection.json').replace('Existing 390 database required','Existing 412 v1 database required');
// The namespace replacement also changed the bundle name, intentionally.
fs.writeFileSync(path.join(scratch,'launch.ps1'),launch,{flag:'wx'});
for(const [source,target] of [['settle-after.ps1','settle.ps1'],['shutdown-after.ps1','shutdown.ps1']]){
 const content=fs.readFileSync('.tmp-product-iteration/member-live-rendering-412/'+source,'utf8').replaceAll('member-live-rendering-412-after','task-member-guidance-413-live').replaceAll('18527','18529');
 fs.writeFileSync(path.join(scratch,target),content,{flag:'wx'});
}
const bundle='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/task-member-guidance-413-live-bundle';
fs.mkdirSync(path.join(bundle,'bin'),{recursive:true});
fs.copyFileSync('.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64/bun.exe',path.join(bundle,'bin/bun.exe'),fs.constants.COPYFILE_EXCL);
console.log(JSON.stringify({bundle,port:18529,requestLimit:40,nativeMaximumMs:600000}));
