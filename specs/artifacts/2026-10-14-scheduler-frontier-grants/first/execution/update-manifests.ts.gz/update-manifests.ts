import fs from 'node:fs'
import path from 'node:path'
import {execFileSync} from 'node:child_process'
import {isDeepStrictEqual} from 'node:util'
const repository=fs.realpathSync(process.cwd())
const files=fs.readFileSync('.tmp-product-iteration/live-member-switching-417/direct-entrypoints.txt','utf8').trim().split(/\r?\n/).map(s=>s.replaceAll('\\','/'))
if(files.length!==120)throw Error('Review scope requires the 120 observed production manifests')
const plans=files.map(file=>{
 const absolute=fs.realpathSync(path.resolve(repository,file))
 if(!absolute.startsWith(repository+path.sep)||!file.endsWith('/expert-squad.jsonc'))throw Error('Manifest outside reviewed repository')
 const original=fs.readFileSync(absolute,'utf8'),manifest=Bun.JSONC.parse(original)
 const oldRef='capability:tool:platform:tool-registry:dispatch_agent',newRef='capability:tool:platform:tool-registry:dispatch_agents'
 const refs=manifest.capability_projection.scheduler.capability_refs
 if(refs.filter((ref:string)=>ref===oldRef).length!==1)throw Error('Exact old scheduler grant required: '+file)
 if(manifest.version>='2026.10.14.1')throw Error('Review newer package version before changing '+file)
 const updated=original.replace('"'+oldRef+'"','"'+newRef+'"').replace('"version": "'+manifest.version+'"','"version": "2026.10.14.1"')
 const expected=structuredClone(manifest);expected.version='2026.10.14.1';expected.capability_projection.scheduler.capability_refs=refs.map((ref:string)=>ref===oldRef?newRef:ref)
 if(!isDeepStrictEqual(Bun.JSONC.parse(updated),expected))throw Error('Patch scope mismatch: '+file)
 return {file,absolute,original,updated,id:manifest.id,previousVersion:manifest.version}
})
const priorDiff=execFileSync('git',['diff','HEAD','--',...files],{encoding:'utf8',maxBuffer:32*1024*1024})
fs.writeFileSync(path.join(import.meta.dir,'manifest-prior.diff'),priorDiff,{flag:'wx'})
if(priorDiff)throw Error('Reviewed manifest scope has unrelated changes')
for(const p of plans){if(fs.readFileSync(p.absolute,'utf8')!==p.original)throw Error('Manifest changed during scope review: '+p.file)}
for(const p of plans)fs.writeFileSync(p.absolute,p.updated)
fs.writeFileSync(path.join(import.meta.dir,'updated-manifests.json'),JSON.stringify(plans.map(({file,id,previousVersion})=>({file,id,previousVersion,version:'2026.10.14.1'})),null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({updated:plans.length,version:'2026.10.14.1'}))
