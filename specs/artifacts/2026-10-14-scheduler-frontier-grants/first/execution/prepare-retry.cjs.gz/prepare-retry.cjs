const fs=require('node:fs'),path=require('node:path');const root=__dirname,retry=path.join(root,'retry');fs.mkdirSync(retry);
for(const name of ['launch','settle','shutdown','create-task']){
 let code=fs.readFileSync(path.join(root,name+'.ps1'),'utf8')
 .replaceAll('scheduler-frontier-grants-418-live','scheduler-frontier-grants-418-retry')
 .replaceAll('18547','18549')
 .replaceAll('scheduler-frontier-grants-418-selection.json','scheduler-frontier-grants-418-retry-selection.json');
 if(name==='launch')code=code.replace("$taskOccurrence='scheduler-frontier-grants-418-'","$taskOccurrence='scheduler-frontier-grants-418-retry-'").replace("/scheduler-frontier-grants-418/settle.ps1'","/scheduler-frontier-grants-418/retry/settle.ps1'");
 if(name==='create-task')code=code.replace("/scheduler-frontier-grants-418'","/scheduler-frontier-grants-418/retry'").replaceAll('集合并发 418','集合并发 418 复验');
 fs.writeFileSync(path.join(retry,name+'.ps1'),code,{flag:'wx'});
}
let reader=fs.readFileSync(path.join(root,'read-facts.ts'),'utf8').replace("'../../packages/opencorvus/script/real-provider-audit'","'../../../packages/opencorvus/script/real-provider-audit'");fs.writeFileSync(path.join(retry,'read-facts.ts'),reader,{flag:'wx'});
console.log(JSON.stringify({port:18549,requestBudget:48,qualification:'Task',nativeMaximumMs:600000}));
