import fs from 'node:fs'
import path from 'node:path'
import {Database} from 'bun:sqlite'
import {CredentialRedactor} from '../../packages/opencorvus/script/real-provider-audit'
const capture=process.argv[2]
if(!capture||!/^[a-z0-9-]+$/.test(capture))throw Error('Explicit capture name required')
const scratch=import.meta.dir
const selection=JSON.parse(fs.readFileSync(path.join(scratch,'task-selection.json'),'utf8'))
const db=new Database('C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/member-live-rendering-412-fresh/runtime/data/opencorvus.db',{readonly:true})
db.exec('PRAGMA busy_timeout = 5000')
const redactor=new CredentialRedactor();redactor.collect(JSON.parse(fs.readFileSync('C:/Users/hengu/AppData/Local/opencorvus/data/auth.json','utf8')))
const read=(sql:string,...parameters:any[])=>{const q=db.query(sql);try{return q.all(...parameters) as any[]}finally{q.finalize()}}
let facts:any
try{
 db.exec('BEGIN')
 const task=read('SELECT * FROM engine_task WHERE id=?',selection.taskID)[0]
 if(!task||task.project_id!==selection.projectID||task.request_id!==selection.requestID)throw Error('Exact accepted Task row required')
 const sessions=read(`WITH RECURSIVE tree(id) AS (SELECT ? UNION ALL SELECT s.id FROM session s JOIN tree p ON s.parent_id=p.id) SELECT s.* FROM session s JOIN tree t ON s.id=t.id ORDER BY s.time_created,s.id`,task.session_id)
 const messages=sessions.flatMap(s=>read('SELECT id,session_id,data FROM message WHERE session_id=? ORDER BY time_created,id',s.id).map(r=>({...JSON.parse(r.data),id:r.id,sessionID:r.session_id})))
 const parts=messages.flatMap(m=>read('SELECT id,message_id,data FROM part WHERE message_id=? ORDER BY time_created,id',m.id).map(r=>({...JSON.parse(r.data),id:r.id,messageID:r.message_id})))
 const tools=messages.flatMap(m=>read('SELECT id,message_id,data FROM tool_part_request WHERE message_id=? ORDER BY time_created,id',m.id).map(r=>({...JSON.parse(r.data),id:r.id,messageID:r.message_id})))
 const outcomes=tools.flatMap(t=>read('SELECT request_part_id,data FROM tool_part_outcome WHERE request_part_id=?',t.id).map(r=>({...JSON.parse(r.data),requestPartID:r.request_part_id})))
 const artifacts=read('SELECT * FROM engine_artifact WHERE task_id=? ORDER BY time_created,id',task.id).map(r=>({...r,payload:JSON.parse(r.payload)}))
 const events=read("SELECT * FROM protocol_event WHERE (aggregate_type='task' AND aggregate_id=?) OR task_id=? ORDER BY emitted_at,id",task.id,task.id).map(r=>({...r,payload:JSON.parse(r.payload)}))
 facts={capture,observedAt:new Date().toISOString(),databaseVersion:read('PRAGMA user_version'),selection,task,sessions,messages,parts,tools,outcomes,artifacts,events,boundary:'Read-only production SQLite transaction for the genuine CLI-accepted Task; no UI assertions or synthesized state.'}
}finally{db.exec('ROLLBACK');db.close()}
fs.writeFileSync(path.join(scratch,`facts-${capture}.json`),redactor.redact(JSON.stringify(facts,null,2))+'\n',{flag:'wx'})
console.log(JSON.stringify({capture,taskID:facts.task.id,sessions:facts.sessions.map((s:any)=>({id:s.id,kind:s.kind,parentID:s.parent_id})),messages:facts.messages.length,sources:facts.parts.filter((p:any)=>p.type.startsWith('source-')).map((p:any)=>({id:p.id,type:p.type,path:p.path,url:p.url})),tools:facts.tools.map((t:any)=>({id:t.id,tool:t.tool,outcome:facts.outcomes.find((o:any)=>o.requestPartID===t.id)?.outcome})),coordination:facts.artifacts.filter((a:any)=>a.kind.startsWith('agent_coordination')).map((a:any)=>({id:a.id,kind:a.kind,payload:a.payload})),latestEvents:facts.events.slice(-5).map((e:any)=>({id:e.id,type:e.type,payload:e.payload}))}))
