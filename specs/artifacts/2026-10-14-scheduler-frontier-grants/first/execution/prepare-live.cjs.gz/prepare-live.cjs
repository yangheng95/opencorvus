const fs=require('node:fs'),path=require('node:path');
const root=__dirname;
for(const name of ['launch','settle','shutdown','create-task']){
 let code=fs.readFileSync('.tmp-product-iteration/live-member-switching-417/'+name+'.ps1','utf8')
 .replaceAll('live-member-switching-417','scheduler-frontier-grants-418').replaceAll('18545','18547');
 if(name==='launch')code=code.replaceAll('scheduler-frontier-grants-418-live-bundle','live-member-switching-417-live-bundle');
 if(name==='create-task'){
  code=code.replaceAll('流中成员切换 417','集合并发 418').replaceAll('product-experience-417','product-experience-418');
  code=code.replace(". 'D:/myhexin-local/opencorvus/.tmp-product-iteration/live-sol-long-source-reading-406-launch.ps1' -FunctionsOnly", "if($taskAuthority.admission.packageRevision.version -cne '2026.10.14.1' -or $taskAuthority.admission.schedulerGrants.builtInToolIDs -cnotcontains 'dispatch_agents'){throw 'Current actual collection-dispatch projection required'}\n. 'D:/myhexin-local/opencorvus/.tmp-product-iteration/live-sol-long-source-reading-406-launch.ps1' -FunctionsOnly");
 }
 fs.writeFileSync(path.join(root,name+'.ps1'),code,{flag:'wx'});
}
fs.copyFileSync('.tmp-product-iteration/live-member-switching-417/read-facts.ts',path.join(root,'read-facts.ts'),fs.constants.COPYFILE_EXCL);
let prior=fs.readFileSync(path.join(root,'read-facts.ts'),'utf8').replace("path.join(scratch,'task-selection.json')","'D:/myhexin-local/opencorvus/.tmp-product-iteration/live-member-switching-417/task-selection.json'");
fs.writeFileSync(path.join(root,'read-prior-facts.ts'),prior,{flag:'wx'});
for(const [file,url] of [
 ['specs/README.md','records/2026-10/2026-10-14-scheduler-frontier-grants.md'],
 ['specs/records/2026-10/README.md','2026-10-14-scheduler-frontier-grants.md'],
 ['specs/artifacts/README.md','2026-10-14-scheduler-frontier-grants/README.md'],
]){
 const lines=fs.readFileSync(file,'utf8').split(/\r?\n/);lines.splice(2,0,`- [生产集合委派](${url})：统一平台/生产包/模板的并发能力及真实重叠验收。`,'');fs.writeFileSync(file,lines.join('\n'));
}
console.log(JSON.stringify({port:18547,model:'gpt-6.1-sol',requestBudget:48,nativeMaximumMs:600000,bundle:'live-member-switching-417-live-bundle'}));
