const fs=require('node:fs'),path=require('node:path');
const root=path.resolve('.tmp-product-iteration/task-acceptance-receipt-415');
for(const name of ['launch','settle','shutdown','create-task']){
 let code=fs.readFileSync('.tmp-product-iteration/active-task-dock-414/'+name+'-after.ps1','utf8')
 .replaceAll('active-task-dock-414-after','task-acceptance-receipt-415-live')
 .replaceAll('active-task-dock-414','task-acceptance-receipt-415')
 .replaceAll('18537','18539').replaceAll('/settle-after.ps1','/settle.ps1')
 .replaceAll('task-acceptance-receipt-415-live-selection.json','task-acceptance-receipt-415-selection.json')
 .replaceAll('task-acceptance-receipt-415-live-bundle/bin/bun.exe','active-task-dock-414-after-bundle/bin/bun.exe');
 if(name==='create-task')code=code.replaceAll('活动 Task 侧栏 414 修后','指导即时受理 415').replaceAll('product-experience-414','product-experience-415')
 .replaceAll('after-task-','task-');
 fs.writeFileSync(path.join(root,name+'.ps1'),code,{flag:'wx'});
}
fs.writeFileSync(path.join(root,'read-facts.ts'),fs.readFileSync('.tmp-product-iteration/active-task-dock-414/read-after-facts.ts','utf8')
 .replaceAll('after-task-selection.json','task-selection.json').replaceAll('`after-facts-${capture}.json`','`facts-${capture}.json`'),{flag:'wx'});
console.log(JSON.stringify({port:18539,requests:40,nativeMaximumMs:600000,bundle:'active-task-dock-414-after-bundle',wrapper:'live-sol-task-guidance-413.ts'}));
