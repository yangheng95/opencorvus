const fs=require('node:fs'),path=require('node:path'),z=require('node:zlib'),assert=require('node:assert/strict');
const scratch=path.resolve('.tmp-product-iteration/task-acceptance-receipt-415'),out=path.resolve('specs/artifacts/2026-10-14-task-acceptance-receipt');
const read=p=>JSON.parse(fs.readFileSync(p,'utf8'));
const write=(p,b)=>{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,b,{flag:'wx'})};
const json=(n,v)=>write(path.join(out,n),JSON.stringify(v,null,2)+'\n');
const copy=(a,b)=>write(b,fs.readFileSync(a)),zip=(a,b)=>write(b,z.gzipSync(fs.readFileSync(a)));
const f=read(path.join(scratch,'facts-final.json')),prior=read(path.join(scratch,'prior-final.json')),old=read('.tmp-product-iteration/active-task-dock-414/after-facts-final.json');
assert.equal(prior.task.id,old.task.id);
for(const kind of ['messages','parts','tools','outcomes'])for(const item of old[kind])assert.deepEqual(prior[kind].find(x=>(x.id??x.requestPartID)===(item.id??item.requestPartID)),item);
for(const a of old.artifacts)assert.deepEqual(prior.artifacts.find(x=>x.id===a.id)?.payload,a.payload);
const requests=f.artifacts.filter(a=>a.kind==='agent_coordination_request');assert.equal(requests.length,1);
const request=requests[0];assert.equal(request.id,'art_3e9833bfd33b4bf5a43d');
const response=f.artifacts.find(a=>a.kind==='agent_coordination_response'&&a.payload.request_id===request.id),action=f.artifacts.find(a=>a.id===response.payload.action_id),outcome=f.artifacts.find(a=>a.kind==='agent_coordination_action_outcome'&&a.payload.action_id===action.id);
assert.equal(response.payload.decision,'redispatch');assert.equal(action.payload.action,'redispatch_worker');assert.equal(outcome.payload.status,'completed');assert.equal(outcome.payload.result.dispatch_session_id,request.payload.session_id);
const dispatch=f.tools.find(t=>t.tool==='dispatch_agent'&&t.input?.dispatch?.turn?.authority?.coordination_action_id===action.id);
assert.equal(f.outcomes.find(o=>o.requestPartID===dispatch.id)?.outcome,'completed');
const worker=f.messages.filter(m=>m.sessionID===request.payload.session_id),inputs=worker.filter(m=>m.role==='user');assert.equal(inputs.length,2);
const original=worker.find(m=>m.id==='msg_g0VXzy7ou00qGwXDJwQm'),final=worker.find(m=>m.id==='msg_g0VXzyOpF00Z3ovIg1Un'),text=f.parts.find(p=>p.id==='prt_g0VXzyPkp006YIvtT8Hx');assert.equal(text.messageID,final.id);
const http=read(path.join(scratch,'http-first.json')).rows,receipts=http.filter(r=>r.data.status==='completed');assert.equal(receipts.length,1);const accepted=receipts[0];assert.equal(accepted.data.statusCode,202);assert.ok(accepted.data.path.includes('/'+request.payload.session_id+'/operator-steer'));
assert.ok(Date.parse(accepted.time)<original.time.completed);assert.ok(request.payload.created_at<=Date.parse(accepted.time));assert.ok(response.payload.created_at>Date.parse(accepted.time));assert.ok(final.time.completed>original.time.completed);
const source=f.parts.find(p=>p.type==='source-file');assert.deepEqual(source.range,{startLine:2,endLine:3});assert.equal(f.outcomes.find(o=>o.requestPartID===source.toolPartID)?.outcome,'completed');
const dir='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/task-acceptance-receipt-415-live/evidence';
const native=read(path.join(dir,'native-host-settled.json')),cleanup=read(path.join(dir,'physical-terminal-and-pair-cleanup.json')),complete=read(path.join(dir,'task-complete.json'));
assert.equal(complete.lifecycle.status,'completed');assert.equal(native.terminal.reason,'exited');assert.equal(native.terminal.exitCode,0);for(const k of ['physicalCompletion','outputDrainComplete','requestCleanupComplete'])assert.equal(native[k],true);assert.equal(cleanup.pairedCleanupComplete,true);
const audit=fs.readdirSync(dir).filter(n=>n.startsWith('provider-')&&n.endsWith('.json')).map(n=>({n,v:read(path.join(dir,n))})).filter(x=>Array.isArray(x.v.requests)&&x.v.observedAt).sort((a,b)=>Date.parse(a.v.observedAt)-Date.parse(b.v.observedAt)).at(-1);
for(const r of audit.v.requests){assert.equal(r.model,'gpt-6.1-sol');assert.equal(r.streaming,true);assert.equal(r.status,200);assert.equal(r.response_reader.state,'settled');assert.equal(r.response_reader.terminal.kind,'eof')}
for(const n of ['native-host-ready.json','native-host-settled.json','physical-terminal-and-pair-cleanup.json','launcher-child-exit.json','preflight-ready.json','public-shutdown.json','task-boundary-admitted.json','task-occurrence-admitted.json','task-complete.json'])copy(path.join(dir,n),path.join(out,'live',n));
copy(path.join(dir,audit.n),path.join(out,'live/provider-audit.json'));
json('persisted-check.json',{taskID:f.task.id,projectID:f.task.project_id,databaseVersion:f.databaseVersion,request:request.payload,responseID:response.id,actionID:action.id,outcome:outcome.payload,httpReceipt:accepted,originalReply:original.time,finalReply:final.time,workerInputs:inputs.map(m=>({id:m.id,author:m.author,time:m.time})),finalText:text,source:{id:source.id,path:source.path,range:source.range,toolPartID:source.toolPartID},priorTaskID:prior.task.id,priorMessagesRetained:old.messages.length,boundary:'Actual original server HTTP logs and production SQLite show a single first 202 receipt before original assistant completion and before its coordination decision, followed by same-session continuation. No UI assertions or timing threshold benchmark.'});
json('execution-summary.json',{requests:audit.v.requests.length,native:native.terminal,pairedCleanupComplete:true,launchJoin:{handle:22954,chunk:'25b22d',exitCode:0},taskCreate:{handle:91626,chunk:'2bf7aa',exitCode:0},business:[{handle:15038,chunk:'cc0608',exitCode:0,tests:8,assertions:75},{handle:39145,chunk:'b2c876',exitCode:0,tests:8,assertions:75}],types:[{handle:5158,chunk:'7895e9',exitCode:2,reason:'Temporary config missed package-local Bun types'},{handle:51567,chunk:'fb3943',exitCode:2,reason:'Existing test fixture Part union and never-transaction types'},{handle:79009,chunk:'b3b1a1',exitCode:0}],screenshots:6,closedTab:'35',firstHTTPMilliseconds:accepted.data.duration,previousFirstHTTPMilliseconds:118925,uiBundle:'Reused active-task-dock-414-after-bundle; this batch changes backend acceptance only.'});
for(const n of fs.readdirSync(scratch)){
 if(/^\d\d-.*\.jpg$/.test(n))copy(path.join(scratch,n),path.join(out,n));
 else if(/^(facts-.*|prior-final|http-first|task-(request|accepted|selection))\.json$/.test(n))zip(path.join(scratch,n),path.join(out,'facts',n+'.gz'));
 else if((/\.(ps1|cjs|ts|log)$/.test(n)||/^tsconfig.*\.json$/.test(n))&&!n.startsWith('archive-check')&&!n.startsWith('commit'))zip(path.join(scratch,n),path.join(out,'execution',n+'.gz'));
}
zip('.tmp-product-iteration/live-sol-task-guidance-413.ts',path.join(out,'execution/live-sol-task-guidance-413.ts.gz'));
for(const n of ['operator-steer-http-receipts.json','push.log','push-exit.json','remote-after-push.txt','merge.log','pending-reviewed.txt'])zip(path.join('.tmp-product-iteration/active-task-dock-414',n),path.join(out,'previous-414',n+'.gz'));
console.log(JSON.stringify({status:'qualified',requests:audit.v.requests.length,firstHTTPMilliseconds:accepted.data.duration,firstReceiptBeforeOriginalCompletion:true,continuationSession:request.payload.session_id,finalMessage:final.id,preservedPriorMessages:old.messages.length,screenshots:6}));
