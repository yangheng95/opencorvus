import fs from "node:fs/promises"
import path from "node:path"
import net from "node:net"
import os from "node:os"
import { NodeProcess } from "../packages/util/src/process-node"
import { bootstrapIsolatedTestRuntime, applyIsolatedTestUserEnvironment, removeIsolatedTestRuntime } from "../packages/util/src/test-runtime-environment"
import { prepareTestProcessSupervisor } from "../packages/opencorvus/script/prepare-test-process-supervisor"

const [output, executable] = process.argv.slice(2)
if (!output || !executable || !path.isAbsolute(output) || !path.isAbsolute(executable)) throw new Error("Explicit owned output and original native executable required")
await fs.mkdir(output, { recursive: false })
const startedAt = Date.now()
const deadlineAt = startedAt + 90000
const lifetime = new AbortController()
const overall = setTimeout(() => lifetime.abort(new Error("Original 90000ms probe maximum")), 90000)
const runtime = await bootstrapIsolatedTestRuntime("runner")
applyIsolatedTestUserEnvironment(runtime)
const supervisor = prepareTestProcessSupervisor()
if (supervisor) process.env.OPENCORVUS_PROCESS_SUPERVISOR = supervisor
const environment = Object.fromEntries(Object.entries(process.env).filter(([name]) => /^(PATH|SystemRoot|WINDIR|ComSpec|PATHEXT|HOME|USERPROFILE|APPDATA|LOCALAPPDATA|TEMP|TMP|TMPDIR|XDG_CONFIG_HOME|XDG_DATA_HOME|XDG_CACHE_HOME|XDG_STATE_HOME|OPENCORVUS_(TEST_|PROCESS_SUPERVISOR|HOME))/i.test(name)))
const facts: any = { startedAt, deadlineAt, controllerPID: process.pid, executable, supervisor, isolatedRoot: runtime.processRoot, cases: [] }
let active: Awaited<ReturnType<typeof NodeProcess.spawn>> | undefined
const record = () => fs.writeFile(path.join(output, "driver.json"), JSON.stringify(facts, null, 2))
const portReleased = (port: number) => new Promise<boolean>((resolve) => {
  const socket = net.connect({ host: "127.0.0.1", port })
  socket.setTimeout(1000)
  socket.once("connect", () => { socket.destroy(); resolve(false) })
  socket.once("error", (error: NodeJS.ErrnoException) => { socket.destroy(); resolve(error.code === "ECONNREFUSED") })
  socket.once("timeout", () => { socket.destroy(); resolve(false) })
})
try {
  const version = await NodeProcess.run({ command: { executable, args: ["--version"] }, ownership: "owned_tree", windowsHide: true, env: environment, timeoutMs: 20000, deadlineAt, signal: lifetime.signal })
  facts.version = { text: new TextDecoder().decode(version.stdout).trim(), stderr: new TextDecoder().decode(version.stderr), receipt: version.receipt }
  await record()
  for (const mode of ["idle", "pending", "disconnected"]) {
    const directory = path.join(output, mode)
    await fs.mkdir(directory)
    const caseDeadlineAt = Math.min(Date.now() + 20000, deadlineAt)
    const item: any = { mode, deadlineAt: caseDeadlineAt, requestFacts: [] }
    facts.cases.push(item)
    active = await NodeProcess.spawn({ command: { executable, args: [path.join(import.meta.dir, "listener-phase-a-child.mjs"), mode, directory, String(caseDeadlineAt)] }, ownership: "owned_tree", windowsHide: true, stdin: "ignore", env: environment, deadlineAt: caseDeadlineAt, signal: lifetime.signal })
    const handle = active
    item.pid = handle.pid
    item.occurrenceID = handle.occurrenceID
    const drain = async (stream: typeof handle.stdout, filename: string) => { if (stream) for await (const bytes of stream) await fs.appendFile(path.join(directory, filename), bytes) }
    const outputDrains = Promise.all([drain(handle.stdout, "stdout.log"), drain(handle.stderr, "stderr.log")])
    void outputDrains.catch(() => undefined)
    for (const entry of await fs.readdir(os.tmpdir(), { withFileTypes: true })) {
      if (!entry.isDirectory() || !entry.name.startsWith("opencorvus-node-process-")) continue
      const requestRoot = path.join(os.tmpdir(), entry.name)
      try {
        const request = JSON.parse(await fs.readFile(path.join(requestRoot, "request.json"), "utf8"))
        if (request.request_id !== handle.occurrenceID) continue
        const ready = JSON.parse(await fs.readFile(path.join(requestRoot, "ready.json"), "utf8"))
        item.requestFacts.push({ root: requestRoot, requestID: request.request_id, ready })
      } catch (error) { if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error }
    }
    item.terminal = await handle.settled
    await outputDrains
    await handle.outputSettled
    item.outputDrainComplete = true
    active = undefined
    item.requestCleanup = await Promise.all(item.requestFacts.map(async (fact: any) => ({ root: fact.root, removed: await fs.stat(fact.root).then(() => false, (error) => { if (error.code === "ENOENT") return true; throw error }) })))
    const ready = JSON.parse(await fs.readFile(path.join(directory, "ready.json"), "utf8"))
    item.portReleased = await portReleased(ready.port)
    item.phases = JSON.parse(await fs.readFile(path.join(directory, "result.json"), "utf8"))
    await record()
    console.log(JSON.stringify({ mode, terminal: item.terminal, outputDrainComplete: true, requestCleanup: item.requestCleanup, portReleased: item.portReleased, phases: item.phases.phases }))
    if (item.requestFacts.length !== 1 || item.terminal.reason !== "exited" || item.terminal.exitCode !== 0 || !item.portReleased || item.requestCleanup.some((entry: any) => !entry.removed)) throw new Error(`Case ${mode} did not settle with one exact native owner`)
  }
} catch (error) {
  facts.error = String(error)
  throw error
} finally {
  if (active) { facts.emergencySettlement = await active.dispose(); await active.outputSettled; active = undefined }
  clearTimeout(overall)
  facts.finishedAt = Date.now()
  await record()
  await removeIsolatedTestRuntime(runtime)
}
