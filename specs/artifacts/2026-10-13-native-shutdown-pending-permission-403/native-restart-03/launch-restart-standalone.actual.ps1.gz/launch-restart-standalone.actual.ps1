param([Parameter(Mandatory=$true)][string]$Scope,[Parameter(Mandatory=$true)][string]$Native,[Parameter(Mandatory=$true)][string]$Repository)
$ErrorActionPreference = 'Stop'
if (-not [IO.Path]::IsPathRooted($Scope) -or -not [IO.Path]::IsPathRooted($Native) -or -not [IO.Path]::IsPathRooted($Repository)) { throw 'Explicit absolute scope/native/repository required' }
if (Test-Path -LiteralPath $Scope) { throw 'Restart scope must be fresh' }
New-Item -ItemType Directory -Path $Scope | Out-Null
$taskTemporary403 = Join-Path $Scope 'owned-temporary'
New-Item -ItemType Directory -Path $taskTemporary403 | Out-Null
$taskStarted403 = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
$taskDeadline403 = $taskStarted403 + 600000
$taskCloseBy403 = $taskDeadline403 - 45000
$taskOccurrence403 = [Guid]::NewGuid().ToString()
$taskOwners403 = @{}
$taskUrls403 = @{}
$taskRequests403 = @{}
$taskFacts403 = [ordered]@{ occurrenceID=$taskOccurrence403; startedAt=$taskStarted403; deadlineAt=$taskDeadline403; closeBy=$taskCloseBy403; launcherPID=$PID; launcherBirth=('win32:' + (Get-Process -Id $PID).StartTime.ToUniversalTime().Ticks); native=$Native; scope=$Scope; normalShutdown=@(); forced=@(); scanErrors=@() }
function Write-TaskFact403([string]$Name,$Value) { $Value | ConvertTo-Json -Depth 24 | Set-Content -LiteralPath (Join-Path $Scope $Name) -Encoding UTF8 }
function Add-TaskOwner403($Value,[string]$Source,[string]$Role) {
  if ($null -eq $Value -or -not $Value.pid -or -not $Value.processInstanceID) { return }
  $taskOwners403[([string]$Value.pid + '|' + $Value.processInstanceID)] = @{ pid=[int]$Value.pid; processInstanceID=[string]$Value.processInstanceID; occurrenceID=[string]$Value.occurrenceID; source=$Source; role=$Role }
}
function Get-ExactTaskProcess403($Owner) {
  try { $taskObserved403=Get-Process -Id $Owner.pid -ErrorAction Stop; $null=$taskObserved403.Handle; if (('win32:' + $taskObserved403.StartTime.ToUniversalTime().Ticks) -ceq $Owner.processInstanceID) { return $taskObserved403 } } catch {}
  return $null
}
function Read-OwnedFacts403 {
  $taskNames403=@('launcher-started.json','owner.json','ready.json','helper.json','restart-ready.json','startup.json','admitted.json','child-phase.json')
  foreach ($taskFile403 in Get-ChildItem -LiteralPath $taskTemporary403 -File -Recurse -ErrorAction SilentlyContinue) {
    if ($taskFile403.Name -notin $taskNames403) { continue }
    try { $taskValue403=Get-Content -LiteralPath $taskFile403.FullName -Raw | ConvertFrom-Json } catch { continue }
    switch ($taskFile403.Name) {
      'launcher-started.json' { Add-TaskOwner403 $taskValue403 $taskFile403.FullName 'standalone' }
      'owner.json' { if ($taskFile403.Directory.Name -eq 'sdk-owned-tree') { Add-TaskOwner403 $taskValue403 $taskFile403.FullName 'sdk' } }
      'admitted.json' { Add-TaskOwner403 $taskValue403.owner $taskFile403.FullName 'crash-fixture-owner' }
      'child-phase.json' { Add-TaskOwner403 $taskValue403.owner $taskFile403.FullName 'crash-fixture-target' }
      'ready.json' { if ($taskValue403.protocol -eq 3 -and $taskValue403.target_pid -and $taskValue403.target_process_instance_id) { Add-TaskOwner403 @{pid=$taskValue403.target_pid;processInstanceID=$taskValue403.target_process_instance_id;occurrenceID=$taskValue403.runtime_occurrence_id} $taskFile403.FullName 'native-target' } }
      'helper.json' { if ($taskValue403.helper_pid -and $taskValue403.helper_process_instance_id) { Add-TaskOwner403 @{pid=$taskValue403.helper_pid;processInstanceID=$taskValue403.helper_process_instance_id;occurrenceID=$taskValue403.request_id} $taskFile403.FullName 'native-helper' } }
      'restart-ready.json' { Add-TaskOwner403 $taskValue403.successor $taskFile403.FullName 'successor'; if ($taskValue403.url -and $taskValue403.successor.pid) { $taskUrls403[[string]$taskValue403.successor.pid]=$taskValue403.url } }
      'startup.json' { if ($taskValue403.outcome -eq 'listening' -and $taskValue403.pid -and $taskValue403.url) { $taskUrls403[[string]$taskValue403.pid]=$taskValue403.url } }
    }
  }
}
function Stop-OwnedListeners403 {
  foreach ($taskOwner403 in @($taskOwners403.Values)) {
    if (-not $taskUrls403.ContainsKey([string]$taskOwner403.pid)) { continue }
    $taskExact403=Get-ExactTaskProcess403 $taskOwner403
    if (-not $taskExact403) { continue }
    $taskUrl403=[Uri]$taskUrls403[[string]$taskOwner403.pid]
    if ($taskUrl403.Host -ne '127.0.0.1' -or $taskUrl403.Scheme -ne 'http') { continue }
    $taskKey403=[string]$taskOwner403.pid+'|'+$taskOwner403.processInstanceID+'|'+$taskUrl403.Port
    if ($taskRequests403.ContainsKey($taskKey403)) { continue }
    $taskBinding403=Get-NetTCPConnection -State Listen -LocalPort $taskUrl403.Port -ErrorAction SilentlyContinue | Where-Object { $_.OwningProcess -eq $taskOwner403.pid }
    if (-not $taskBinding403) { continue }
    $taskRequests403[$taskKey403]=$true
    try { $taskReceipt403=Invoke-RestMethod -Uri ([Uri]::new($taskUrl403,'/shutdown')) -Method Post -ContentType 'application/json' -Body '{}' -TimeoutSec 3; $taskFacts403.normalShutdown+=@{owner=$taskOwner403;receipt=$taskReceipt403;at=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()} }
    catch { $taskFacts403.normalShutdown+=@{owner=$taskOwner403;error=$_.Exception.Message;at=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()} }
  }
}
function Kill-ExactTaskProcess403($Owner,[string]$Reason) {
  $taskExact403=Get-ExactTaskProcess403 $Owner
  if (-not $taskExact403) { return }
  $taskExact403.Kill()
  $taskRemaining403=[Math]::Max(0,[Math]::Min(5000,$taskDeadline403-[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()))
  $taskJoined403=$taskExact403.WaitForExit([int]$taskRemaining403)
  $taskFacts403.forced+=@{owner=$Owner;reason=$Reason;joined=$taskJoined403;at=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()}
}
try {
  Set-Location -LiteralPath $Repository
  foreach ($taskName403 in @([Environment]::GetEnvironmentVariables('Process').Keys)) {
    if ($taskName403 -notmatch '^(PATH|SystemRoot|WINDIR|ComSpec|PATHEXT|LANG|LC_ALL|CARGO_HOME|RUSTUP_HOME|RUSTUP_TOOLCHAIN)$') { Remove-Item -LiteralPath ('Env:'+$taskName403) -ErrorAction SilentlyContinue }
  }
  $env:TEMP=$taskTemporary403; $env:TMP=$taskTemporary403; $env:TMPDIR=$taskTemporary403
  $env:SERVER_RESTART_RESULT=Join-Path $Scope 'result.json'
  $taskEntry403=Join-Path $Repository 'packages/opencorvus/script/server-restart-e2e.ts'
  $taskChecker403=Start-Process -FilePath $Native -ArgumentList @('"'+$taskEntry403+'"') -WorkingDirectory $Repository -WindowStyle Hidden -RedirectStandardOutput (Join-Path $Scope 'stdout.log') -RedirectStandardError (Join-Path $Scope 'stderr.log') -PassThru
  $null=$taskChecker403.Handle
  $taskCheckerOwner403=@{pid=$taskChecker403.Id;processInstanceID=('win32:'+$taskChecker403.StartTime.ToUniversalTime().Ticks);occurrenceID=$taskOccurrence403;role='checker'}
  $taskFacts403.checker=$taskCheckerOwner403
  Write-TaskFact403 'owner.json' $taskFacts403
  while ($true) {
    Read-OwnedFacts403
    $taskChecker403.Refresh()
    $taskNow403=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
    $taskLive403=@($taskOwners403.Values | Where-Object { $null -ne (Get-ExactTaskProcess403 $_) })
    if ($taskChecker403.HasExited -and $taskLive403.Count -eq 0) { break }
    if ($taskNow403 -ge $taskCloseBy403) {
      $taskFacts403.deadlineCleanup=$true
      Stop-OwnedListeners403
      if ($taskNow403 -ge ($taskDeadline403-30000)) { Kill-ExactTaskProcess403 $taskCheckerOwner403 'original checker deadline; stop further admission' }
      if ($taskNow403 -ge ($taskDeadline403-20000)) {
        foreach ($taskOwner403 in @($taskLive403 | Sort-Object { $_.role -eq 'native-helper' })) { Kill-ExactTaskProcess403 $taskOwner403 'original scope deadline after normal owned shutdown' }
      }
      if ($taskNow403 -ge $taskDeadline403) { throw 'Original fixed 600000ms restart checker owner deadline reached' }
    }
    Write-TaskFact403 'observed-owners.json' @($taskOwners403.Values)
    Start-Sleep -Milliseconds 500
  }
  $taskChecker403.WaitForExit()
  $taskFacts403.checkerExitCode=$taskChecker403.ExitCode
  if (Test-Path -LiteralPath (Join-Path $Scope 'result.json')) { $taskResult403=Get-Content -LiteralPath (Join-Path $Scope 'result.json') -Raw | ConvertFrom-Json; $taskFacts403.canonicalCheckerOwner=$taskResult403.checkerOwner; $taskFacts403.checkerStatus=$taskResult403.status }
  $taskFacts403.ownerDispositions=@($taskOwners403.Values | ForEach-Object { @{owner=$_;disposition=if(Get-ExactTaskProcess403 $_){'exact_live'}else{'dead_or_reused'}} })
  $taskFacts403.outputFilesClosed=$true
  if ($taskChecker403.ExitCode -ne 0 -or $taskFacts403.checkerStatus -ne 'passed' -or $taskFacts403.deadlineCleanup) { throw 'Restart qualification failed; original checker evidence retained' }
} catch {
  $taskFacts403.error=$_.Exception.Message; $taskExit403=1
  try { Read-OwnedFacts403; Stop-OwnedListeners403 } catch { $taskFacts403.cleanupError=$_.Exception.Message }
  if ($taskChecker403 -and -not $taskChecker403.HasExited) {
    $taskRemaining403=[Math]::Max(0,[Math]::Min(10000,$taskDeadline403-[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()))
    if (-not $taskChecker403.WaitForExit([int]$taskRemaining403)) { Kill-ExactTaskProcess403 $taskCheckerOwner403 'failed checker original owner cleanup' }
  }
  try { Read-OwnedFacts403 } catch {}
  foreach ($taskOwner403 in @($taskOwners403.Values | Sort-Object { $_.role -eq 'native-helper' })) { Kill-ExactTaskProcess403 $taskOwner403 'failed checker exact owned native cleanup' }
  $taskFacts403.ownerDispositions=@($taskOwners403.Values | ForEach-Object { @{owner=$_;disposition=if(Get-ExactTaskProcess403 $_){'exact_live'}else{'dead_or_reused'}} })
}
finally {
  $taskFacts403.finishedAt=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
  Write-TaskFact403 'terminal.json' $taskFacts403
}
if ($taskExit403) { exit $taskExit403 }
exit 0
