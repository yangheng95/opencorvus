// No listener, Provider call, Session creation, auth read, or copied model directory.
import assert from "node:assert/strict"
import fs from "node:fs/promises"
import path from "node:path"
import { bootstrapIsolatedTestRuntime, applyIsolatedTestUserEnvironment, removeIsolatedTestRuntime } from "../packages/util/src/test-runtime-environment"
import { phaseBConfig, phaseBSessionCreate, phaseBMessage, phaseBModel } from "./phase-b-input"
const output = process.argv[2]
if (!output || !path.isAbsolute(output)) throw new Error("Absolute fresh preflight output required")
const runtime = await bootstrapIsolatedTestRuntime("runner")
applyIsolatedTestUserEnvironment(runtime)
const retained = /^(PATH|SystemRoot|WINDIR|ComSpec|PATHEXT|HOME|HOMEDRIVE|HOMEPATH|USERPROFILE|APPDATA|LOCALAPPDATA|TEMP|TMP|TMPDIR|XDG_CONFIG_HOME|XDG_DATA_HOME|XDG_CACHE_HOME|XDG_STATE_HOME|OPENCORVUS_(TEST_|HOME|PROCESS_SUPERVISOR))/i
for (const name of Object.keys(process.env)) if (!retained.test(name)) delete process.env[name]
const catalog = path.join(runtime.processRoot, "public-model-catalog.json")
await fs.writeFile(catalog, "{}\n", { flag: "wx" })
process.env.OPENCORVUS_MODELS_PATH = catalog
let cleanup: (() => Promise<void>) | undefined
try {
  const { Global } = await import("../packages/opencorvus/src/global")
  const { Config } = await import("../packages/opencorvus/src/config/config")
  const { ConfigPaths } = await import("../packages/opencorvus/src/config/paths")
  const { Session } = await import("../packages/opencorvus/src/session")
  const { PromptInput } = await import("../packages/opencorvus/src/session/prompt/schema")
  const { Identifier } = await import("../packages/opencorvus/src/id/id")
  const { Instance } = await import("../packages/opencorvus/src/project/instance")
  const { Database } = await import("../packages/opencorvus/src/storage/db")
  const { configuredDefaultModelRef } = await import("../packages/opencorvus/src/agent/model")
  const { SystemPrompt } = await import("../packages/opencorvus/src/session/system")
  const { controlledProviderRequestKind } = await import("../packages/opencorvus/test/fixture/controlled-streaming-provider")
  const { selectProjectDirectory } = await import("../packages/opencorvus/src/server/directory")
  cleanup = async () => { await Instance.disposeAll(); Database.close() }
  const project = path.join(runtime.processRoot, "public-project")
  await fs.mkdir(project)
  const config = phaseBConfig("http://127.0.0.1:1/v1")
  Config.Info.parse(config)
  await fs.mkdir(Global.Path.config, { recursive: true })
  await fs.writeFile(path.join(Global.Path.config, ConfigPaths.CANONICAL_FILE_NAME), JSON.stringify(config))
  const projectConfig = ConfigPaths.projectFile(project)
  await fs.mkdir(path.dirname(projectConfig), { recursive: true })
  await fs.writeFile(projectConfig, JSON.stringify({ username: "public-preflight" }))
  const snapshot = await Config.snapshotForProject(project)
  assert.equal(snapshot.permission_mode, "ask")
  assert.equal(snapshot.prompt_profile?.active, "base")
  assert.equal(snapshot.model, config.model)
  assert.equal(snapshot.small_model, config.small_model)
  assert.equal(snapshot.username, "public-preflight")
  assert.deepEqual(configuredDefaultModelRef(snapshot), phaseBModel)
  const create = Session.create.schema.parse(phaseBSessionCreate("pending"))
  // Exact public route composition at server/routes/session.ts:249–262.
  const publicInput = PromptInput.omit({ sessionID: true, author: true, noReply: true, tools: true, includeMcpTools: true, extra: true, byteMaterializationProjectID: true }).extend({ messageID: Identifier.schema("message") })
  const message = publicInput.parse(phaseBMessage(path.join(runtime.processRoot, "public-external.csv")))
  assert.equal(selectProjectDirectory({ headerDirectory: project }), project)
  const memoryPrompt = await fs.readFile(path.resolve("packages/opencorvus/src/agent/prompt/memory.txt"), "utf8")
  const kinds = { memory: controlledProviderRequestKind([{ role: "system", content: [memoryPrompt, SystemPrompt.requestLanguage()].join("\n\n") }]), business: controlledProviderRequestKind([{ role: "user", content: message.parts[0] }]) }
  assert.deepEqual(kinds, { memory: "memory", business: "prompt" })
  const result = { kind: "isolated-production-schemas-and-cumulative-project-config-no-services", infoParsed: true, snapshot: { permissionMode: snapshot.permission_mode, activeProfile: snapshot.prompt_profile?.active, model: snapshot.model, smallModel: snapshot.small_model, username: snapshot.username, provider: snapshot.provider?.[phaseBModel.providerID], mcp: snapshot.mcp }, projectDirectory: project, publicCreate: create, defaultTitle: Session.isDefaultTitle(create.title!), publicMessage: message, fixtureRequestKinds: kinds, memoryModelRef: configuredDefaultModelRef(snapshot), scope: "No Session or message was created; no Provider request or listener was started. These schema samples are not synthetic product messages." }
  await fs.writeFile(output, JSON.stringify(result, null, 2) + "\n", { flag: "wx" })
  console.log(JSON.stringify(result))
} finally { await cleanup?.(); await removeIsolatedTestRuntime(runtime) }
