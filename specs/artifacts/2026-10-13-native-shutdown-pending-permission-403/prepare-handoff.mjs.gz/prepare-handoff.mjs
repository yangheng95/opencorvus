import fs from "node:fs/promises"
import path from "node:path"
const root = path.resolve(import.meta.dirname, "..")
const scratch = ".tmp-native-shutdown-pending-permission-403"
const sourceFiles = [
  "packages/opencorvus/src/server/stop.ts",
  "packages/opencorvus/src/server/server.ts",
  "packages/opencorvus/src/cli/server-runtime.ts",
  "packages/opencorvus/src/cli/cmd/serve.ts",
  "packages/opencorvus/src/server/restart-handoff.ts",
  "packages/opencorvus/script/server-restart-e2e.ts",
  "packages/opencorvus/test/runtime-startup-recovery.test.ts",
  "packages/opencorvus/test/server-runtime-quiesce.test.ts",
]
const spec = "specs/records/2026-10/2026-10-13-native-shutdown-pending-permission-403.md"
const allow = []
const add = (p) => allow.push(`${scratch}/${p}`)
for (const p of ["listener-phase-a.ts", "listener-phase-a-child.mjs", "launch-phase-b.ts", "serve-phase-b.ts", "phase-b-input.ts", "preflight-phase-b.ts", "check-native-green.mjs", "launch-restart-standalone.ps1", "probe-checker-exit.ps1", "launch-native-timeout.ts", "native-timeout-probe.ts", "native-timeout-preload.ts", "prepare-handoff.mjs"]) add(p)
for (const name of ["red", "green-unit", "red-timeout-callback", "green-timeout-callback", "related", "ownership-matrix", "final-focused", "final-positive-review", "typecheck", "typecheck-final", "typecheck-positive-review", "native-green-check", "native-restart-01", "native-timeout-01", "native-timeout-02"]) for (const ext of ["log", "exit"]) add(`implementation/${name}.${ext}`)
for (const p of ["head-before.txt", "final-scope.patch", "server-runtime-quiesce.final.test.ts", "runtime-startup-recovery.before-positive-review.test.ts", "checker-exit-probe.json", "checker-exit-probe.json.False.stderr", "checker-exit-probe.json.False.stdout", "checker-exit-probe.json.True.stderr", "checker-exit-probe.json.True.stdout", "native-restart-01.json"]) add(`implementation/${p}`)
for (const p of sourceFiles.slice(0, 6)) add(`implementation/preimage/${p}`)
for (const ext of ["exit", "log"]) add(`phase-a-01.${ext}`)
add("phase-a-01/driver.json")
for (const mode of ["idle", "pending", "disconnected"]) for (const p of ["phases.jsonl", "ready.json", "result.json"]) add(`phase-a-01/${mode}/${p}`)
for (const n of ["01", "02", "03", "04", "05"]) {
  for (const ext of ["exit", "log", "launch.json"]) add(`phase-b-${n}.${ext}`)
  add(`phase-b-${n}/driver.json`)
  if (n !== "05") for (const p of ["launch-phase-b.actual.ts", "serve-phase-b.actual.ts"]) add(`phase-b-${n}/${p}`)
  if (["01", "02", "03"].includes(n)) add(`phase-b-${n}/post-close-observation.json`)
  if (n === "04") for (const p of ["summary.json", "phase-b-input.actual.ts"]) add(`phase-b-${n}/${p}`)
  if (n === "05") add("phase-b-05/green-check.json")
  for (const mode of (["04", "05"].includes(n) ? ["pending", "disconnected"] : ["pending"])) {
    for (const p of ["case.json", "public-config.json", "shutdown-admission.json", "startup.json", "stderr.log", "stdout.log"]) add(`phase-b-${n}/${mode}/${p}`)
    if (["04", "05"].includes(n)) for (const p of ["pending-observation.json", "prompt-input.json", "sender-terminal.json", "terminal-observation.json"]) add(`phase-b-${n}/${mode}/${p}`)
  }
}
for (const n of ["01", "02", "03"]) for (const ext of ["exit", "log"]) add(`phase-b-preflight-${n}.${ext}`)
add("phase-b-preflight-03.json")
for (const n of ["02", "03"]) {
  add(`native-restart-${n}-wmi.json`)
  for (const p of ["launch-restart-standalone.actual.ps1", "observed-owners.json", "owner.json", "result.json", "server-restart-e2e.actual.ts", "stderr.log", "stdout.log", "terminal.json"]) add(`native-restart-${n}/${p}`)
}
add("native-restart-03/final-observation.json")
for (const n of ["01", "02"]) {
  add(`native-timeout-${n}.launch.json`)
  for (const p of ["native-timeout-preload.actual.ts", "native-timeout-probe.actual.ts", "launch-native-timeout.actual.ts", "result.json", "phases.jsonl", "startup.json", "stderr.log", "stdout.log"]) add(`native-timeout-${n}/${p}`)
}
const evidenceFiles = []
const findings = []
for (const relative of [...new Set(allow)]) {
  if (/\/(?:owned-temporary|runtime-root|auth\.json|models\.json)\//.test(relative) || /\.(?:db|sqlite|exe|dll)$/i.test(relative)) throw new Error(`Forbidden evidence source: ${relative}`)
  const bytes = await fs.readFile(path.join(root, relative))
  const text = bytes.toString("utf8")
  for (const [kind, regex] of [
    ["private-key", /-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/g],
    ["credential-token", /\bsk-(?:proj-)?[A-Za-z0-9_-]{24,}\b/g],
    ["jwt-value", /\beyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}\b/g],
    ["bearer-value", /Bearer [A-Za-z0-9._-]{24,}/g],
  ]) if (regex.test(text)) findings.push({ path: relative, kind })
  evidenceFiles.push({ path: relative, bytes: bytes.length })
}
const read = async p => JSON.parse(await fs.readFile(path.join(root, scratch, p), "utf8"))
const a = await read("phase-a-01/driver.json"), b = await read("phase-b-05/driver.json"), restart = await read("native-restart-03/final-observation.json"), timeout = await read("native-timeout-02/result.json")
const tests = [
  ["test/server-runtime-quiesce.test.ts",9,20,"implementation/final-focused.log"],
  ["test/runtime-startup-recovery.test.ts",12,23,"implementation/final-positive-review.log"],
  ["test/runtime-execution-settlement.test.ts",17,32,"implementation/related.log"],
  ["test/server-lifecycle-occurrence.test.ts",8,13,"implementation/related.log"],
  ["test/process-shutdown-task-lifecycle.test.ts",3,8,"implementation/ownership-matrix.log"],
  ["test/instance-background-shutdown.test.ts",4,23,"implementation/ownership-matrix.log"],
  ["test/mission-process-recovery.test.ts",4,8,"implementation/ownership-matrix.log"],
  ["test/mission-streamed-recovery.test.ts",1,34,"implementation/ownership-matrix.log"],
].map(([file,pass,assertions,log]) => ({file:`packages/opencorvus/${file}`,pass,assertions,log:`${scratch}/${log}`,exitCode:0}))
const handoff = {
  sourceFiles, spec, formal:{files:tests,distinctTests:58,distinctAssertions:161,repeatedRunsAddCoverage:false},
  scopeFacts:{
    a:{startedAt:a.startedAt,deadlineAt:a.deadlineAt,finishedAt:a.finishedAt,cases:a.cases.map(c=>({mode:c.mode,deadlineAt:c.deadlineAt,terminal:c.terminal,outputDrainComplete:c.outputDrainComplete,requestCleanup:c.requestCleanup,portReleased:c.portReleased})),evidence:`${scratch}/phase-a-01/driver.json`},
    b05:{startedAt:b.startedAt,deadlineAt:b.deadlineAt,finishedAt:b.finishedAt,cases:b.cases.map(c=>({mode:c.mode,startedAt:c.startedAt,deadlineAt:c.deadlineAt,owner:c.owner,terminal:c.terminal,outputDrainComplete:c.outputDrainComplete,requestCleanup:c.requestCleanup,portReleased:c.portReleased,provider:c.provider})),evidence:`${scratch}/phase-b-05/green-check.json`},
    restart03:{...restart,evidence:`${scratch}/native-restart-03/terminal.json`},
    timeout02:{nativeStartedAt:timeout.nativeStartedAt,nativeDeadlineAt:timeout.nativeDeadlineAt,owner:timeout.owner,shutdown:timeout.shutdown,physicalAt:timeout.physicalAt,terminal:timeout.terminal,outputDrainComplete:timeout.outputDrainComplete,requestCleanup:timeout.requestCleanup,portReleased:timeout.portReleased,logicalDrain:timeout.logicalDrain,evidence:`${scratch}/native-timeout-02/result.json`},
  },
  preservedFailures:[
    {scope:"phase-b-01",reason:"helper parsed metrics as msg/pid instead of actual message/data.pid; no business, Native shutdown0; probe1"},
    {scope:"phase-b-02",reason:"helper encoded raw directory header; public400; no business, Native shutdown0; probe1"},
    {scope:"phase-b-03",reason:"helper configured forbidden agent.memory.model; public500; no business, Native shutdown0; probe1"},
    {scope:"phase-b-preflight-01/02",reason:"offline helper canonical config-path assumptions; no service; corrected preflight03 passes"},
    {scope:"phase-b-04",reason:"real product RED both pending/disconnected Native1 at5s; unfinished canonical assistant/tool; probe0 means observed not passed"},
    {scope:"native-restart-01",reason:"checker inside WindowsJob precondition, cases[]; exit1/no service"},
    {scope:"native-restart-02",reason:"canonical13passed but thinPS failed reading unpinned Handle ExitCode null; all owned dead; originalfailure kept"},
    {scope:"native-timeout-01",reason:"unreferenced neverPromise did not hold Bun handler drain; Native0; probe1; no timeoutproof"},
  ],
  limitations:["No real Provider credentials/models or GPT-6.1 Sol calls; local controlled streaming fixture only", "No browser/UI acceptance", "No complete pending-Permission CLI restart/model chain", "No non-Windows platform claim", "Original395 active metrics timing remains unknown", "Fault timeout02 proves natural failed exit1 and physical cleanup; logical listener drain intentionally unfinished", "Permission retained requested; no synthetic decision", "Task fixture and scripted Mission recovery tests prove their backend contracts, not real-model end-to-end"],
  evidenceFiles, evidenceCount:evidenceFiles.length, evidenceBytes:evidenceFiles.reduce((sum,f)=>sum+f.bytes,0),
  scan:{readScope:"Only explicit public allowlist; no runtime traversal, database/auth/models read, or known-credential scan",publicFixtureKey:"local-controlled-provider is public test data, not a credential",findings},
  excluded:["implementation/workspace-before.patch (peer changes)","owned-temporary/**","runtime directories","databases","auth.json","models.json","binary executables","raw real-Provider payloads"],
}
await fs.writeFile(path.join(root,scratch,"handoff-403.json"),JSON.stringify(handoff,null,2)+"\n")
console.log(JSON.stringify({sourceFileCount:sourceFiles.length,evidenceCount:handoff.evidenceCount,evidenceBytes:handoff.evidenceBytes,findings}))
