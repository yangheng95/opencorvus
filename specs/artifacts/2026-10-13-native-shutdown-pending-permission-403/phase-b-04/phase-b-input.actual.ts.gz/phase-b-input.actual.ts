// One public scratch input source shared by preflight and the actual CLI probe.
import { randomUUID } from "node:crypto"
export const phaseBModel = { providerID: "shutdown-fixture", modelID: "session-prompt-owner-model" }
export function phaseBConfig(apiURL: string) {
  return {
    model: "shutdown-fixture/session-prompt-owner-model", small_model: "shutdown-fixture/session-prompt-owner-model",
    permission_mode: "ask", prompt_profile: { active: "base" }, enabled_providers: ["shutdown-fixture"],
    mcp: { browser: { enabled: false }, computer: { enabled: false } },
    provider: { "shutdown-fixture": { name: "Public local shutdown fixture", npm: "@ai-sdk/openai-compatible", api: apiURL, options: { apiKey: "local-controlled-provider" }, models: { "session-prompt-owner-model": { name: "Public local shutdown model", tool_call: true, modalities: { input: ["text"], output: ["text"] }, limit: { context: 1_000_000, output: 4096 } } } } },
  }
}
export const phaseBSessionCreate = (mode: string) => ({ kind: "assistant", title: `Public shutdown ${mode}` })
export const phaseBMessage = (externalFile: string) => ({ messageID: `msg_${randomUUID()}`, agent: "chat", model: phaseBModel, parts: [{ type: "text", text: `Read the public CSV at ${externalFile} and report its rows.` }] })
