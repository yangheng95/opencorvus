import fs from "node:fs/promises"
import path from "node:path"
import { bootstrapIsolatedTestRuntime, isolatedTestChildEnvironment, removeIsolatedTestRuntime } from "../packages/util/src/test-runtime-environment"
import { prepareTestProcessSupervisor } from "../packages/opencorvus/script/prepare-test-process-supervisor"
const [output, native] = process.argv.slice(2)
if (!output || !native || !path.isAbsolute(output) || !path.isAbsolute(native)) throw new Error("Explicit absolute fresh output and Native paths required")
const startedAt = Date.now(), deadlineAt = startedAt + 60_000
const runtime = await bootstrapIsolatedTestRuntime("runner")
const supervisor = prepareTestProcessSupervisor()
if (supervisor) process.env.OPENCORVUS_PROCESS_SUPERVISOR = supervisor
let settlementConfirmed = false
try {
  const { runHostCommandWithInactivity } = await import("../packages/opencorvus/src/shell/command-inactivity")
  const result = await runHostCommandWithInactivity({ executable: process.execPath, args: [path.join(import.meta.dir, "native-timeout-probe.ts"), output, native, String(deadlineAt)], cwd: process.cwd(), env: isolatedTestChildEnvironment(runtime), deadlineAt, inactivityTimeoutMs: 30_000, onStdout: chunk => process.stdout.write(chunk), onStderr: chunk => process.stderr.write(chunk) })
  settlementConfirmed = result.settlementConfirmed
  await fs.writeFile(output + ".launch.json", JSON.stringify({ startedAt, deadlineAt, launcherPID: process.pid, result: { exitCode: result.exitCode, settlementConfirmed, failure: result.failure, stdout: result.stdout, stderr: result.stderr } }, null, 2) + "\n", { flag: "wx" })
  process.exitCode = result.failure || result.exitCode === undefined ? 1 : result.exitCode
} finally {
  if (settlementConfirmed) await removeIsolatedTestRuntime(runtime)
  else console.error(`Original timeout probe runtime retained: ${runtime.processRoot}`)
}
