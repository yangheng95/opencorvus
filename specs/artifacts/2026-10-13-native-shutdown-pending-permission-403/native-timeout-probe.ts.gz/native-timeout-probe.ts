import fs from "node:fs/promises"
import path from "node:path"
import os from "node:os"
import net from "node:net"
import assert from "node:assert/strict"
import { NodeProcess } from "../packages/util/src/process-node"
import { bootstrapIsolatedTestRuntime, applyIsolatedTestUserEnvironment, removeIsolatedTestRuntime } from "../packages/util/src/test-runtime-environment"
import { prepareTestProcessSupervisor } from "../packages/opencorvus/script/prepare-test-process-supervisor"

const [output, executable, deadline] = process.argv.slice(2)
if (!output || !executable || !path.isAbsolute(output) || !path.isAbsolute(executable)) throw new Error("Explicit absolute fresh output and Native paths required")
const deadlineAt = Number(deadline), startedAt = Date.now()
if (!Number.isSafeInteger(deadlineAt) || deadlineAt <= startedAt || deadlineAt > startedAt + 60_000) throw new Error("Original outer deadline required")
await fs.mkdir(output, { recursive: false })
const runtime = await bootstrapIsolatedTestRuntime("runner")
applyIsolatedTestUserEnvironment(runtime)
const environment = Object.fromEntries(Object.entries(process.env).filter(([name]) => /^(PATH|SystemRoot|WINDIR|ComSpec|PATHEXT|HOME|HOMEDRIVE|HOMEPATH|USERPROFILE|APPDATA|LOCALAPPDATA|TEMP|TMP|TMPDIR|XDG_CONFIG_HOME|XDG_DATA_HOME|XDG_CACHE_HOME|XDG_STATE_HOME|OPENCORVUS_(TEST_|HOME))/i.test(name)))
for (const name of Object.keys(process.env)) if (!(name in environment)) delete process.env[name]
const supervisor = prepareTestProcessSupervisor()
if (supervisor) process.env.OPENCORVUS_PROCESS_SUPERVISOR = environment.OPENCORVUS_PROCESS_SUPERVISOR = supervisor
const catalog = path.join(runtime.processRoot, "public-empty-catalog.json")
await fs.writeFile(catalog, "{}\n", { flag: "wx" })
const facts: any = { kind: "real-native-five-second-failed-exit-contract", startedAt, deadlineAt, driverPID: process.pid, executable, requestFacts: [] }
const save = () => fs.writeFile(path.join(output, "result.json"), JSON.stringify(facts, null, 2) + "\n")
const readJSON = async (file: string) => { try { return JSON.parse(await fs.readFile(file, "utf8")) } catch (error) { if ((error as NodeJS.ErrnoException).code === "ENOENT") return; throw error } }
const portReleased = (port: number) => new Promise<boolean>(resolve => {
  const socket = net.connect({ host: "127.0.0.1", port })
  socket.setTimeout(1000)
  socket.once("connect", () => { socket.destroy(); resolve(false) })
  socket.once("error", (error: NodeJS.ErrnoException) => { socket.destroy(); resolve(error.code === "ECONNREFUSED") })
  socket.once("timeout", () => { socket.destroy(); resolve(false) })
})
let handle: Awaited<ReturnType<typeof NodeProcess.spawn>> | undefined
let drains: Promise<unknown> | undefined, held: Promise<unknown> | undefined
let stdout = "", stderr = "", ready: any
const sender = new AbortController()
try {
  const version = await NodeProcess.run({ command: { executable, args: ["--version"] }, ownership: "owned_tree", windowsHide: true, env: environment, timeoutMs: 5000, deadlineAt })
  facts.version = { text: new TextDecoder().decode(version.stdout).trim(), receipt: version.receipt }
  assert.equal(facts.version.text, "1.3.14")
  const project = path.join(runtime.processRoot, "project")
  await fs.mkdir(project)
  const startup = path.join(output, "startup.json"), phases = path.join(output, "phases.jsonl")
  const childStartedAt = Date.now(), childDeadlineAt = Math.min(childStartedAt + 20_000, deadlineAt)
  assert.equal(childDeadlineAt - childStartedAt, 20_000)
  facts.nativeStartedAt = childStartedAt; facts.nativeDeadlineAt = childDeadlineAt
  const signal = AbortSignal.timeout(childDeadlineAt - Date.now())
  handle = await NodeProcess.spawn({ command: { executable, args: ["--preload", path.join(import.meta.dir, "native-timeout-preload.ts"), path.resolve("packages/opencorvus/src/index.ts"), "serve", "--hostname", "127.0.0.1", "--port", "0", "--project-dir", project, "--startup-receipt", startup, "--startup-occurrence", "403-native-timeout", "--print-logs"] }, ownership: "owned_tree", windowsHide: true, stdin: "ignore", env: { ...environment, OPENCORVUS_HOME: path.join(runtime.processRoot, "app-home"), OPENCORVUS_MODELS_PATH: catalog, OPENCORVUS_DISABLE_AUTOUPDATE: "1", OPENCORVUS_DISABLE_EXTERNAL_SKILLS: "1", OPENCORVUS_DISABLE_CLAUDE_CODE: "1", PROBE_403_PHASE_FILE: phases }, deadlineAt: childDeadlineAt, signal })
  const owner = handle
  facts.owner = { pid: owner.pid, occurrenceID: owner.occurrenceID }
  console.log(JSON.stringify({ phase: "native-owned", ...facts.owner, childStartedAt, childDeadlineAt }))
  const drain = async (stream: typeof owner.stdout, name: string) => { if (stream) for await (const bytes of stream) { const text = new TextDecoder().decode(bytes); if (name === "stdout.log") stdout += text; else stderr += text; await fs.appendFile(path.join(output, name), bytes) } }
  drains = Promise.all([drain(owner.stdout, "stdout.log"), drain(owner.stderr, "stderr.log")]); void drains.catch(() => undefined)
  for (const entry of await fs.readdir(os.tmpdir(), { withFileTypes: true })) {
    if (!entry.isDirectory() || !entry.name.startsWith("opencorvus-node-process-")) continue
    const root = path.join(os.tmpdir(), entry.name), request = await readJSON(path.join(root, "request.json"))
    if (request?.request_id === owner.occurrenceID) facts.requestFacts.push({ root, requestID: request.request_id, ready: await readJSON(path.join(root, "ready.json")) })
  }
  async function wait<T>(label: string, inspect: () => Promise<T | undefined>): Promise<T> {
    for (;;) { signal.throwIfAborted(); const value = await inspect(); if (value !== undefined) return value; await Bun.sleep(50) }
  }
  ready = await wait("startup", () => readJSON(startup))
  assert.equal(ready.outcome, "listening"); assert.equal(ready.pid, owner.pid)
  held = fetch(new URL("/__403_hold", ready.url), { signal: AbortSignal.any([signal, sender.signal]) }).then(async response => ({ at: Date.now(), status: response.status, body: await response.text() }), error => ({ at: Date.now(), error: String(error), cause: String(error?.cause ?? "") })).then(receipt => { facts.heldRequest = receipt; return receipt })
  await wait("actual owned handler entered", async () => { const text = await fs.readFile(phases, "utf8"); const entries = text.trim().split("\n").map(line => JSON.parse(line)); return entries.find(entry => entry.phase === "owned-request-entered") })
  const shutdownStartedAt = Date.now()
  const response = await fetch(new URL("/shutdown", ready.url), { method: "POST", headers: { "content-type": "application/json" }, body: "{}", signal })
  facts.shutdown = { startedAt: shutdownStartedAt, status: response.status, body: await response.json() }
  assert.equal(response.status, 200)
  facts.terminal = await owner.settled
  facts.physicalAt = Date.now()
  await owner.outputSettled; await drains; await held
  facts.outputDrainComplete = true
  facts.requestCleanup = await Promise.all(facts.requestFacts.map(async (entry: any) => ({ root: entry.root, removed: await fs.stat(entry.root).then(() => false, error => { if (error.code === "ENOENT") return true; throw error }) })))
  facts.portReleased = await portReleased(Number(new URL(ready.url).port))
  facts.timeoutDiagnostic = stderr.includes("[serve] listener quiesce timeout, escalating: 5000\n[serve] shutdown failed: Server stop timed out after 5000ms")
  facts.runtimeSettledLog = stdout.includes("[serve] settled process-owned prompts")
  assert.equal(facts.terminal.reason, "exited"); assert.equal(facts.terminal.exitCode, 1)
  assert.equal(facts.timeoutDiagnostic, true); assert.equal(facts.runtimeSettledLog, true)
  assert.ok(facts.physicalAt - shutdownStartedAt >= 5000)
  assert.ok(facts.physicalAt < childDeadlineAt)
  assert.equal(facts.requestFacts.length, 1); assert.equal(facts.requestCleanup[0].removed, true); assert.equal(facts.portReleased, true)
  facts.status = "expected-native-failure-contract-verified"
  facts.logicalDrain = "unfinished-by-injected-uncooperative-handler; process-owned-failed-exit"
} catch (error) { facts.error = String(error); throw error }
finally {
  sender.abort(new Error("Owned probe finishing"))
  if (handle) {
    facts.cleanupTerminal = await handle.dispose()
    await handle.outputSettled; await drains; await held
    facts.outputDrainComplete = true
    if (ready) facts.finalPortReleased = await portReleased(Number(new URL(ready.url).port))
  }
  facts.finishedAt = Date.now(); await save(); await removeIsolatedTestRuntime(runtime)
}
