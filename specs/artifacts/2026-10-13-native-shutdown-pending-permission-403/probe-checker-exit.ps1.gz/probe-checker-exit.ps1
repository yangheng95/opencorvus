param([string]$Native,[string]$Output)
$ErrorActionPreference='Stop'
$taskRows403=@()
foreach($taskPin403 in @($false,$true)) {
  $taskChild403=Start-Process -FilePath $Native -ArgumentList @('-e','"setTimeout(()=>process.exit(0),100)"') -WindowStyle Hidden -RedirectStandardOutput ($Output+'.'+$taskPin403+'.stdout') -RedirectStandardError ($Output+'.'+$taskPin403+'.stderr') -PassThru
  if($taskPin403){$null=$taskChild403.Handle}
  $taskBirth403='win32:'+$taskChild403.StartTime.ToUniversalTime().Ticks
  $taskDeadline403=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()+5000
  while(-not $taskChild403.HasExited -and [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds() -lt $taskDeadline403) { $taskChild403.Refresh(); Start-Sleep -Milliseconds 10 }
  if(-not $taskChild403.HasExited){$taskChild403.Kill();$taskChild403.WaitForExit();throw 'Owned exit-code probe deadline'}
  $taskChild403.WaitForExit()
  $taskRows403+=@{pinHandle=$taskPin403;pid=$taskChild403.Id;birth=$taskBirth403;exitCode=$taskChild403.ExitCode;physicalExited=$taskChild403.HasExited}
}
$taskRows403 | ConvertTo-Json | Set-Content -LiteralPath $Output -Encoding UTF8
$taskRows403 | ConvertTo-Json
