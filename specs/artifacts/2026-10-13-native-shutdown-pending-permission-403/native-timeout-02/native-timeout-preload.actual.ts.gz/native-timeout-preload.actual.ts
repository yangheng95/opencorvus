import { appendFileSync } from "node:fs"
import { Server } from "../packages/opencorvus/src/server/server"
const phaseFile = process.env.PROBE_403_PHASE_FILE
if (!phaseFile) throw new Error("Explicit owned timeout phase file required")
const phase = (name: string) => appendFileSync(phaseFile, JSON.stringify({ phase: name, at: Date.now(), pid: process.pid }) + "\n")
Server.TestHooks.installBeforeRequest(async (request) => {
  if (new URL(request.url).pathname !== "/__403_hold") return
  phase("owned-request-entered")
  request.signal.addEventListener("abort", () => phase("owned-request-signal-aborted"), { once: true })
  // Deliberately uncooperative handler: this probe proves the native owner's
  // existing five-second failed-exit contract, not successful logical drain.
  await new Promise<void>((resolve) => setTimeout(() => { phase("fixed-handler-release"); resolve() }, 15_000))
})
phase("test-hook-installed")
