import fs from "node:fs"
import path from "node:path"
const [mode, output, deadlineText] = process.argv.slice(2)
if (!["idle", "pending", "disconnected"].includes(mode) || !path.isAbsolute(output)) throw new Error("Explicit owned case required")
const startedAt = Date.now()
const deadlineAt = Number(deadlineText)
const phases = []
const phase = (name, data = {}) => {
  const value = { phase: name, at: Date.now(), elapsedMs: Date.now() - startedAt, pid: process.pid, ...data }
  phases.push(value)
  fs.appendFileSync(path.join(output, "phases.jsonl"), JSON.stringify(value) + "\n")
}
phase("child-start", { mode, version: Bun.version, startedAt, deadlineAt })
// Give the parent its bounded native owner-fact observation window before the
// idle case can naturally exit. This never changes the fixed case deadline.
await new Promise((resolve) => setTimeout(resolve, 300))
let release
let enter
const gate = new Promise((resolve) => { release = resolve })
const entered = new Promise((resolve) => { enter = resolve })
const clientAbort = new AbortController()
let client
let timer
let server
let stopPromise
try {
  server = Bun.serve({ hostname: "127.0.0.1", port: 0, idleTimeout: 0, async fetch(request) {
    phase("request-enter")
    request.signal.addEventListener("abort", () => phase("request-signal-aborted"), { once: true })
    enter()
    await gate
    phase("handler-released")
    return new Response("public listener probe\n")
  } })
  phase("listener-ready", { port: server.port })
  fs.writeFileSync(path.join(output, "ready.json"), JSON.stringify({ pid: process.pid, version: Bun.version, port: server.port, startedAt, deadlineAt }))
  if (mode !== "idle") {
    timer = setTimeout(() => { phase("fixed-gate-release"); release() }, Math.max(1, startedAt + 4000 - Date.now()))
    client = fetch(`http://127.0.0.1:${server.port}/hold`, { method: "POST", body: "public", signal: clientAbort.signal })
      .then(async (response) => { phase("client-response", { status: response.status, text: await response.text() }) })
      .catch((error) => { phase("client-terminal", { name: error.name, message: error.message }) })
    await entered
    await new Promise((resolve) => setTimeout(resolve, 50))
    if (mode === "disconnected") {
      phase("client-disconnect-requested")
      clientAbort.abort()
      await client
      phase("client-disconnected")
    }
  }
  phase("stop-requested", { closeActiveConnections: true })
  stopPromise = server.stop(true)
  await stopPromise
  phase("stop-resolved")
} finally {
  clearTimeout(timer)
  release()
  clientAbort.abort()
  if (server) await (stopPromise ?? server.stop(true))
  if (client) await client
  phase("finally-closed")
  fs.writeFileSync(path.join(output, "result.json"), JSON.stringify({ mode, version: Bun.version, pid: process.pid, startedAt, deadlineAt, phases }, null, 2))
}
