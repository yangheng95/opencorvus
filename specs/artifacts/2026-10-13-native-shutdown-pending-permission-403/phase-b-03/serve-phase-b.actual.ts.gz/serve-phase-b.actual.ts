// PREPARED ONLY. Root must approve this exact application probe before execution.
// This is a local streaming Provider fixture, never a real-model qualification.
import fs from "node:fs/promises"
import path from "node:path"
import os from "node:os"
import net from "node:net"
import { Database } from "bun:sqlite"
import { randomUUID } from "node:crypto"
import { NodeProcess } from "../packages/util/src/process-node"
import { bootstrapIsolatedTestRuntime, applyIsolatedTestUserEnvironment, removeIsolatedTestRuntime } from "../packages/util/src/test-runtime-environment"
import { prepareTestProcessSupervisor } from "../packages/opencorvus/script/prepare-test-process-supervisor"

const [output, executable, originalDeadline] = process.argv.slice(2)
if (!output || !executable || !path.isAbsolute(output) || !path.isAbsolute(executable)) throw new Error("Explicit absolute fresh output and Native Bun paths required")
if (!originalDeadline || !Number.isSafeInteger(Number(originalDeadline))) throw new Error("Original launcher's exact physical deadline is required")
await fs.mkdir(output, { recursive: false })
const startedAt = Date.now(), deadlineAt = Number(originalDeadline)
if (deadlineAt <= startedAt || deadlineAt > startedAt + 180_000) throw new Error("Invalid or extended phase B owner deadline")
const lifetime = new AbortController()
const overall = setTimeout(() => lifetime.abort(new Error("Original phase B 180000 ms deadline reached")), deadlineAt - startedAt)
const runtime = await bootstrapIsolatedTestRuntime("runner")
applyIsolatedTestUserEnvironment(runtime)
// Whitelist, never print/read/copy a user's credentials or model catalog.
const environment = Object.fromEntries(Object.entries(process.env).filter(([name]) => /^(PATH|SystemRoot|WINDIR|ComSpec|PATHEXT|HOME|HOMEDRIVE|HOMEPATH|USERPROFILE|APPDATA|LOCALAPPDATA|TEMP|TMP|TMPDIR|XDG_CONFIG_HOME|XDG_DATA_HOME|XDG_CACHE_HOME|XDG_STATE_HOME|OPENCORVUS_(TEST_|HOME))/i.test(name)))
for (const name of Object.keys(process.env)) if (!(name in environment)) delete process.env[name]
const supervisor = prepareTestProcessSupervisor()
if (supervisor) process.env.OPENCORVUS_PROCESS_SUPERVISOR = environment.OPENCORVUS_PROCESS_SUPERVISOR = supervisor
const publicCatalog = path.join(runtime.processRoot, "public-model-catalog.json")
await fs.writeFile(publicCatalog, "{}\n", { flag: "wx" })
process.env.OPENCORVUS_MODELS_PATH = publicCatalog
const facts: any = { kind: "real-cli-listener-local-controlled-streaming-provider", startedAt, deadlineAt, controllerPID: process.pid, executable, supervisor, cases: [] }
const save = () => fs.writeFile(path.join(output, "driver.json"), JSON.stringify(facts, null, 2) + "\n")
const write = (directory: string, name: string, value: unknown) => fs.writeFile(path.join(directory, name), JSON.stringify(value, null, 2) + "\n")
const readJSON = async (file: string) => { try { return JSON.parse(await fs.readFile(file, "utf8")) } catch (error) { if ((error as NodeJS.ErrnoException).code === "ENOENT") return; throw error } }
const portReleased = (port: number) => new Promise<boolean>((resolve) => {
  const socket = net.connect({ host: "127.0.0.1", port })
  socket.setTimeout(1000)
  socket.once("connect", () => { socket.destroy(); resolve(false) })
  socket.once("error", (error: NodeJS.ErrnoException) => { socket.destroy(); resolve(error.code === "ECONNREFUSED") })
  socket.once("timeout", () => { socket.destroy(); resolve(false) })
})
const freePort = () => new Promise<number>((resolve, reject) => {
  const probe = net.createServer()
  probe.once("error", reject)
  probe.listen(0, "127.0.0.1", () => { const port = (probe.address() as net.AddressInfo).port; probe.close(error => error ? reject(error) : resolve(port)) })
})
async function wait<T>(label: string, until: number, inspect: () => Promise<T | undefined>): Promise<T> {
  let announcedAt = Date.now()
  for (;;) {
    lifetime.signal.throwIfAborted()
    const result = await inspect()
    if (result !== undefined) return result
    if (Date.now() >= until) throw new Error(`Timed out observing ${label}`)
    if (Date.now() - announcedAt >= 5000) { console.log(JSON.stringify({ phase: "bounded-observation", label, remainingMs: until - Date.now() })); announcedAt = Date.now() }
    await Bun.sleep(100)
  }
}
function observeDatabase(file: string, sessionID: string) {
  const db = new Database(file, { readonly: true })
  try {
    db.exec("BEGIN")
    const result = {
      observedAt: Date.now(),
      session: db.query("SELECT * FROM session WHERE id=?").all(sessionID),
      messages: db.query("SELECT * FROM message WHERE session_id=? ORDER BY time_created,id").all(sessionID),
      toolRequests: db.query("SELECT t.* FROM tool_part_request t JOIN message m ON m.id=t.message_id WHERE m.session_id=? ORDER BY t.time_created,t.id").all(sessionID),
      toolOutcomes: db.query("SELECT o.* FROM tool_part_outcome o JOIN tool_part_request t ON t.id=o.request_part_id JOIN message m ON m.id=t.message_id WHERE m.session_id=? ORDER BY o.time_created,o.id").all(sessionID),
      permissionLedger: db.query("SELECT * FROM permission_ledger WHERE request_id IN (SELECT request_id FROM permission_ledger WHERE session_id=?) ORDER BY time_created,id").all(sessionID),
      promptOwner: db.query("SELECT * FROM session_prompt_owner WHERE session_id=?").all(sessionID),
    }
    db.exec("ROLLBACK")
    return result
  } finally { db.close() }
}

try {
  const version = await NodeProcess.run({ command: { executable, args: ["--version"] }, ownership: "owned_tree", windowsHide: true, env: environment, timeoutMs: 20_000, deadlineAt, signal: lifetime.signal })
  facts.version = { text: new TextDecoder().decode(version.stdout).trim(), receipt: version.receipt }
  if (facts.version.text !== "1.3.14") throw new Error("Phase B requires the same measured Native Bun 1.3.14")
  // Deferred import after the mature isolated HOME/runtime and public catalog bind.
  const { startControlledStreamingProvider } = await import("../packages/opencorvus/test/fixture/controlled-streaming-provider")
  for (const mode of ["pending", "disconnected"] as const) {
    lifetime.signal.throwIfAborted()
    const directory = path.join(output, mode)
    await fs.mkdir(directory)
    const caseRoot = path.join(runtime.processRoot, mode)
    const project = path.join(caseRoot, "project"), appRuntime = path.join(caseRoot, "runtime")
    await fs.mkdir(project, { recursive: true })
    const externalFile = path.join(caseRoot, "public-external.csv")
    await fs.writeFile(externalFile, "batch,item,quantity\nCEDAR403,Maple,3\nCEDAR403,Iris,4\n", { flag: "wx" })
    const caseStartedAt = Date.now(), caseDeadlineAt = Math.min(caseStartedAt + 120_000, deadlineAt)
    if (caseDeadlineAt - caseStartedAt < 30_000) throw new Error("Original phase B deadline has insufficient reserve for the second native owner")
    const item: any = { mode, startedAt: caseStartedAt, deadlineAt: caseDeadlineAt, project, appRuntime, metricsIntervalMs: 300_000, requestFacts: [], phases: [] }
    facts.cases.push(item)
    const phase = async (name: string, detail: Record<string, unknown> = {}) => { const row = { phase: name, at: Date.now(), ...detail }; item.phases.push(row); await write(directory, "case.json", item); console.log(JSON.stringify({ mode, ...row })) }
    const provider = startControlledStreamingProvider({ memoryModelID: "shutdown-helper-model", firstPromptToolCall: { name: "read", arguments: { filePath: externalFile } } })
    const providerPort = provider.server.port!
    const releaseProvider = setInterval(() => { for (const request of provider.requests) request.release() }, 10)
    let handle: Awaited<ReturnType<typeof NodeProcess.spawn>> | undefined
    let outputDrains: Promise<unknown> | undefined
    let prompt: Promise<unknown> | undefined
    let ready: any
    let sessionID: string | undefined
    let stopAdmitted = false
    const sender = new AbortController()
    const caseLife = new AbortController()
    const fixedCase = setTimeout(() => caseLife.abort(new Error("Original application child deadline reached")), caseDeadlineAt - Date.now())
    const signal = AbortSignal.any([lifetime.signal, caseLife.signal])
    let stderrText = "", stdoutText = ""
    const model = (id: string) => ({ name: id, tool_call: true, modalities: { input: ["text"], output: ["text"] }, limit: { context: 1_000_000, output: 4096 } })
    const config = {
      model: "shutdown-fixture/session-prompt-owner-model", small_model: "shutdown-fixture/shutdown-helper-model",
      permission_mode: "ask", prompt_profile: { active: "base" }, enabled_providers: ["shutdown-fixture"],
      agent: { title: { model: "shutdown-fixture/shutdown-helper-model" }, summary: { model: "shutdown-fixture/shutdown-helper-model" }, memory: { model: "shutdown-fixture/shutdown-helper-model" } },
      mcp: { browser: { enabled: false }, computer: { enabled: false } },
      provider: { "shutdown-fixture": { name: "Public local shutdown fixture", npm: "@ai-sdk/openai-compatible", api: provider.apiURL, options: { apiKey: "local-controlled-provider" }, models: { "session-prompt-owner-model": model("session-prompt-owner-model"), "shutdown-helper-model": model("shutdown-helper-model") } } },
    }
    const headers = { "content-type": "application/json", "x-opencorvus-directory": project }
    const request = async (route: string, method = "GET", body?: unknown) => {
      const response = await fetch(new URL(route, ready.url), { method, headers, ...(body === undefined ? {} : { body: JSON.stringify(body) }), signal: AbortSignal.any([signal, AbortSignal.timeout(20_000)]) })
      const text = await response.text()
      let data: unknown; try { data = JSON.parse(text) } catch { data = text }
      const receipt = { at: Date.now(), route, method, status: response.status, data }
      if (!response.ok) throw new Error(`HTTP ${response.status} ${route}: ${text}`)
      return receipt
    }
    const shutdown = async () => { if (ready && !stopAdmitted) { const receipt = await request("/shutdown", "POST", {}); stopAdmitted = true; await write(directory, "shutdown-admission.json", receipt); await phase("shutdown-admitted", { receipt }) } }
    try {
      await write(directory, "public-config.json", config)
      const startupReceipt = path.join(directory, "startup.json")
      const requestedPort = await freePort()
      const environmentCase = { ...environment, OPENCORVUS_HOME: appRuntime, OPENCORVUS_MODELS_PATH: publicCatalog, OPENCORVUS_CONFIG_CONTENT: JSON.stringify(config), OPENCORVUS_RUNTIME_MEMORY_METRICS_INTERVAL_MS: "300000", OPENCORVUS_DISABLE_AUTOUPDATE: "1", OPENCORVUS_DISABLE_EXTERNAL_SKILLS: "1", OPENCORVUS_DISABLE_CLAUDE_CODE: "1" }
      handle = await NodeProcess.spawn({ command: { executable, args: [path.resolve("packages/opencorvus/src/index.ts"), "serve", "--hostname", "127.0.0.1", "--port", String(requestedPort), "--project-dir", project, "--startup-receipt", startupReceipt, "--startup-occurrence", `phase-b-${mode}-${randomUUID()}`, "--print-logs"] }, ownership: "owned_tree", windowsHide: true, stdin: "ignore", env: environmentCase, deadlineAt: caseDeadlineAt, signal })
      const owner = handle
      item.owner = { pid: owner.pid, occurrenceID: owner.occurrenceID }
      const drain = async (stream: typeof owner.stdout, filename: string) => {
        if (stream) for await (const bytes of stream) { const text = new TextDecoder().decode(bytes); if (filename === "stderr.log") stderrText += text; else stdoutText += text; await fs.appendFile(path.join(directory, filename), bytes) }
      }
      outputDrains = Promise.all([drain(owner.stdout, "stdout.log"), drain(owner.stderr, "stderr.log")])
      void outputDrains.catch(() => undefined)
      for (const entry of await fs.readdir(os.tmpdir(), { withFileTypes: true })) {
        if (!entry.isDirectory() || !entry.name.startsWith("opencorvus-node-process-")) continue
        const root = path.join(os.tmpdir(), entry.name)
        const requestFact = await readJSON(path.join(root, "request.json"))
        if (requestFact?.request_id !== owner.occurrenceID) continue
        item.requestFacts.push({ root, requestID: requestFact.request_id, ready: await readJSON(path.join(root, "ready.json")) })
      }
      ready = await wait("framed startup receipt", Math.min(Date.now() + 20_000, caseDeadlineAt), () => readJSON(startupReceipt))
      if (ready.outcome !== "listening" || ready.pid !== owner.pid) throw new Error("Native startup receipt did not identify this exact listener")
      await phase("listener-ready", { ready })
      const metrics = await wait("initial actual memory metrics completed record", Math.min(Date.now() + 20_000, caseDeadlineAt), async () => {
        for (const line of stderrText.split(/\r?\n/)) { let record: any; try { record = JSON.parse(line) } catch { continue }; if (record.message === "runtime.memory.metrics" && record.data?.pid === ready.pid) return record }
        return undefined
      })
      item.initialMetrics = metrics
      await phase("initial-metrics-observed", { metrics })
      const created = await request("/session", "POST", { kind: "assistant", title: `Public shutdown ${mode}` })
      const session = created.data as { id: string; projectID: string; directory: string }
      if (path.resolve(session.directory) !== path.resolve(project)) throw new Error("Created Session owner differs from the explicit isolated Project")
      sessionID = session.id
      item.session = session
      const body = { messageID: `msg_${randomUUID()}`, agent: "chat", model: { providerID: "shutdown-fixture", modelID: "session-prompt-owner-model" }, parts: [{ type: "text", text: `Read the public CSV at ${externalFile} and report its rows.` }] }
      await write(directory, "prompt-input.json", body)
      prompt = fetch(new URL(`/session/${sessionID}/message`, ready.url), { method: "POST", headers, body: JSON.stringify(body), signal: AbortSignal.any([signal, sender.signal]) }).then(async response => ({ at: Date.now(), status: response.status, body: await response.text() }), error => ({ at: Date.now(), error: String(error), cause: String(error?.cause ?? "") })).then(async receipt => { item.senderTerminal = receipt; await write(directory, "sender-terminal.json", receipt); return receipt })
      const pending = await wait("canonical public pending read", Math.min(Date.now() + 20_000, caseDeadlineAt), async () => {
        const result = await request("/permission")
        const records = result.data as Array<{ sessionID: string; toolName: string; scope: unknown }>
        return records.find(record => record.sessionID === sessionID && record.toolName === "read")
      })
      item.pending = pending
      await write(directory, "pending-observation.json", observeDatabase(path.join(appRuntime, "data/opencorvus.db"), sessionID))
      await phase("permission-pending", { pending })
      if (mode === "disconnected") { sender.abort(new Error("Probe-owned client disconnect before shutdown")); await prompt; await phase("client-disconnected") }
      // 300s interval exceeds the entire 180s owner: the initial logged collect is the only scheduled collect.
      if (Date.now() - caseStartedAt >= 120_000) throw new Error("Original application child budget expired before shutdown")
      await shutdown()
      item.terminal = await owner.settled
      await outputDrains
      await owner.outputSettled
      item.outputDrainComplete = true
      handle = undefined
      await prompt
      item.requestCleanup = await Promise.all(item.requestFacts.map(async (fact: any) => ({ root: fact.root, removed: await fs.stat(fact.root).then(() => false, error => { if (error.code === "ENOENT") return true; throw error }) })))
      item.portReleased = await portReleased(new URL(ready.url).port ? Number(new URL(ready.url).port) : 80)
      await write(directory, "terminal-observation.json", observeDatabase(path.join(appRuntime, "data/opencorvus.db"), sessionID))
      item.applicationOutcome = { exitCode: item.terminal.exitCode, physicalReason: item.terminal.reason, runtimeSettlementLog: stdoutText.includes("[serve] settled process-owned prompts"), quiesceTimeoutLog: stderrText.includes("listener quiesce timeout") }
      await phase("native-joined", { terminal: item.terminal, applicationOutcome: item.applicationOutcome, portReleased: item.portReleased })
      if (item.requestFacts.length !== 1 || !item.portReleased || item.requestCleanup.some((value: any) => !value.removed)) throw new Error("Native physical ownership or request cleanup did not close")
    } catch (error) {
      item.error = String(error)
      throw error
    } finally {
      sender.abort(new Error("Probe owner finishing"))
      if (handle) {
        try { await shutdown() } catch (error) { item.cleanupShutdownError = String(error) }
        const joined = await Promise.race([handle.settled, Bun.sleep(Math.max(0, Math.min(10_000, caseDeadlineAt - Date.now()))).then(() => undefined)])
        if (joined) item.cleanupNormalTerminal = joined
        // Original handle owns fallback only. It is recorded as failure, never application success.
        else item.emergencySettlement = await handle.dispose()
        await handle.outputSettled
        await outputDrains
      }
      await prompt
      clearInterval(releaseProvider)
      for (const request of provider.requests) request.release()
      await Promise.all(provider.requests.map(request => request.responded))
      await provider.server.stop(true)
      item.provider = { pid: process.pid, port: providerPort, requests: provider.requests.map(request => { const body = request.body as { model?: unknown; stream?: unknown; tools?: Array<{ function?: { name?: unknown } }> }; return { index: request.index, kind: request.kind, model: body.model, stream: body.stream, toolNames: body.tools?.map(tool => tool.function?.name) } }), closedAt: Date.now(), portReleased: await portReleased(providerPort) }
      clearTimeout(fixedCase)
      await write(directory, "case.json", item)
      await save()
    }
  }
} catch (error) { facts.error = String(error); throw error }
finally { clearTimeout(overall); facts.finishedAt = Date.now(); await save(); await removeIsolatedTestRuntime(runtime) }
