import assert from 'node:assert/strict'
import fs from 'node:fs/promises'
import path from 'node:path'
const directory=process.argv[2]
assert(directory&&path.isAbsolute(directory),'Explicit completed scope required')
const json=async file=>JSON.parse(await fs.readFile(file,'utf8'))
const launch=await json(directory+'.launch.json')
const driver=await json(path.join(directory,'driver.json'))
assert.equal(launch.result.exitCode,0)
assert.equal(launch.result.settlementConfirmed,true)
assert.equal(driver.version.text,'1.3.14')
assert(driver.finishedAt<=launch.deadlineAt)
const cases=[]
for(const mode of ['pending','disconnected']){
 const current=await json(path.join(directory,mode,'case.json'))
 const snapshot=await json(path.join(directory,mode,'terminal-observation.json'))
 assert.deepEqual(current.applicationOutcome,{exitCode:0,physicalReason:'exited',runtimeSettlementLog:true,quiesceTimeoutLog:false})
 assert.equal(current.outputDrainComplete,true)
 assert.equal(current.portReleased,true)
 assert.equal(current.requestCleanup.length,1)
 assert.equal(current.requestCleanup[0].removed,true)
 assert.equal(current.provider.portReleased,true)
 const assistant=snapshot.messages.map(row=>({id:row.id,...JSON.parse(row.data)})).find(row=>row.role==='assistant')
 assert.equal(assistant.error.name,'MessageAbortedError')
 assert.equal(assistant.error.data.cancellation.source,'process.shutdown')
 assert.equal(assistant.error.data.cancellation.targetSessionID,current.session.id)
 assert.equal(assistant.finish,'error')
 assert(Number.isSafeInteger(assistant.time.completed))
 assert.equal(snapshot.toolOutcomes.length,1)
 const outcome=JSON.parse(snapshot.toolOutcomes[0].data)
 assert.equal(outcome.outcome,'failed')
 assert.equal(outcome.failure.kind,'process-execution-interrupted')
 assert.equal(outcome.failure.data.sessionID,current.session.id)
 assert.deepEqual(snapshot.permissionLedger.map(row=>({eventType:row.event_type,requestID:row.request_id})),[{eventType:'requested',requestID:current.pending.id}])
 assert.deepEqual({retainedPromptOwners:snapshot.promptOwner.length,process:current.terminal.reason},{retainedPromptOwners:0,process:'exited'})
 assert.deepEqual(current.provider.requests.map(row=>({kind:row.kind,stream:row.stream,model:row.model})),[{kind:'memory',stream:true,model:'session-prompt-owner-model'},{kind:'prompt',stream:true,model:'session-prompt-owner-model'}])
 cases.push({mode,sessionID:current.session.id,projectID:current.session.projectID,permissionID:current.pending.id,native:current.terminal,assistantID:assistant.id,completedAt:assistant.time.completed,assistantError:assistant.error.name,toolOutcome:outcome.outcome,toolFailure:outcome.failure.kind,retainedPromptOwners:0,permissionState:'requested (not a synthetic approval or denial)',physicalOutputRequestAndPorts:'settled'})
}
const result={kind:'actual-native-shutdown-green-check',passed:true,version:driver.version.text,startedAt:launch.startedAt,deadlineAt:launch.deadlineAt,finishedAt:driver.finishedAt,cases,limits:'Controlled local streaming Provider. No true model, pending restart, GUI, or unsupported platform assertion.'}
await fs.writeFile(path.join(directory,'green-check.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify(result))
