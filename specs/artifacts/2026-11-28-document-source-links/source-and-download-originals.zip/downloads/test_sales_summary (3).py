import csv
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from sales_summary import SalesDataError, markdown_report, summarize


ROOT = Path(__file__).resolve().parent


class SalesSummaryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.folder = Path(self.temp.name)
        self.source = self.folder / "输入.csv"

    def fixture(self, rows, headers=None, bom=False):
        with self.source.open(
            "w", encoding="utf-8-sig" if bom else "utf-8", newline=""
        ) as stream:
            writer = csv.writer(stream)
            writer.writerow(headers or ["订单编号", "区域", "金额", "备注"])
            writer.writerows(rows)
        return self.source

    def cli(self, *extra):
        return subprocess.run(
            [
                sys.executable,
                str(ROOT / "sales_summary.py"),
                str(self.source),
                "--output",
                str(self.folder / "summary.json"),
                "--report",
                str(self.folder / "报告.md"),
                *extra,
            ],
            capture_output=True,
            encoding="utf-8",
            env={**__import__("os").environ, "PYTHONIOENCODING": "utf-8"},
        )

    def test_actual_csv(self):
        self.assertEqual(
            summarize(ROOT / "sales.csv"),
            {
                "order_count": 5,
                "total_amount": "35.60",
                "by_region": {
                    "华东": {"order_count": 3, "total_amount": "28.25"},
                    "华南": {"order_count": 2, "total_amount": "7.35"},
                },
            },
        )

    def test_refund_and_zero(self):
        self.fixture([["1", "北", "-12.30", "退款"], ["2", "北", "0", "免费"]])
        self.assertEqual(
            summarize(self.source),
            {
                "order_count": 2,
                "total_amount": "-12.30",
                "by_region": {"北": {"order_count": 2, "total_amount": "-12.30"}},
            },
        )

    def test_invalid_amounts_api_and_cli(self):
        for value in ("abc", "", " ", "NaN", "sNaN", "Infinity", "-Infinity"):
            with self.subTest(value=value):
                self.fixture([["1", "北", value, ""]])
                with self.assertRaisesRegex(SalesDataError, "第 2 行：无效金额"):
                    summarize(self.source)
                result = self.cli()
                self.assertEqual(result.returncode, 2)
                self.assertIn("第 2 行：无效金额", result.stderr)
                self.assertFalse((self.folder / "summary.json").exists())
                self.assertFalse((self.folder / "报告.md").exists())

    def test_escaped_csv_original_regions_and_cli(self):
        region = ' 华,东"|区\n分部 '
        self.fixture(
            [
                ["1", region, "1.005", '备注含,逗号"及\n换行'],
                ["2", "华东", "2e0", ""],
                ["3", " 华东", "0", ""],
            ],
            bom=True,
        )
        before = self.source.read_bytes()
        self.assertIn(b'""', before)
        result = self.cli()
        self.assertEqual(result.returncode, 0, result.stderr)
        output = json.loads((self.folder / "summary.json").read_text(encoding="utf-8"))
        self.assertEqual(
            output,
            {
                "order_count": 3,
                "total_amount": "3.01",
                "by_region": {
                    region: {"order_count": 1, "total_amount": "1.01"},
                    "华东": {"order_count": 1, "total_amount": "2.00"},
                    " 华东": {"order_count": 1, "total_amount": "0.00"},
                },
            },
        )
        report = (self.folder / "报告.md").read_text(encoding="utf-8")
        self.assertIn("&#124;区<br>分部", report)
        self.assertEqual(self.source.read_bytes(), before)

    def test_sum_before_rounding_and_large_precision(self):
        self.fixture(
            [["1", "R", "0.004", ""], ["2", "R", "0.004", ""], ["3", "S", "-0.005", ""]]
        )
        result = summarize(self.source)
        self.assertEqual(result["total_amount"], "0.00")
        self.assertEqual(result["by_region"]["R"]["total_amount"], "0.01")
        self.assertEqual(result["by_region"]["S"]["total_amount"], "-0.01")
        self.fixture(
            [
                ["1", "R", "123456789012345678901234567890.12", ""],
                ["2", "R", "0.01", ""],
            ]
        )
        self.assertEqual(
            summarize(self.source)["total_amount"], "123456789012345678901234567890.13"
        )

    def test_empty_data(self):
        self.fixture([])
        self.assertEqual(
            summarize(self.source),
            {"order_count": 0, "total_amount": "0.00", "by_region": {}},
        )

    def test_reordered_headers_and_empty_region(self):
        self.fixture([["", "1.50", "备注", "1"]], ["区域", "金额", "备注", "订单编号"])
        self.assertEqual(
            summarize(self.source)["by_region"],
            {"": {"order_count": 1, "total_amount": "1.50"}},
        )

    def test_bad_shape_and_headers(self):
        for text in (
            "订单编号,区域,金额,备注\n1,北,1\n",
            "订单编号,区域,金额,备注\n1,北,1,,额外\n",
            "x,y\n",
            "订单编号,区域,金额,金额\n",
        ):
            with self.subTest(text=text):
                self.source.write_text(text, encoding="utf-8")
                with self.assertRaises(SalesDataError):
                    summarize(self.source)

    def test_regions_csv_sorting_rounding_and_json_compatibility(self):
        self.fixture(
            [
                ["1", "乙", "2.004", ""],
                ["2", "负十", "-10", ""],
                ["3", "大额", "1e1", ""],
                ["4", "甲", "2.00", ""],
                ["5", "零", "-0.004", ""],
                ["6", "负二", "-2", ""],
                ["7", "累加", "0.004", ""],
                ["8", "累加", "+.0040", ""],
                ["9", "舍入", "1.005", ""],
                ["10", "负舍入", "-0.005", ""],
            ]
        )
        before = self.source.read_bytes()
        old = self.cli()
        self.assertEqual(old.returncode, 0, old.stderr)
        original_json = (self.folder / "summary.json").read_bytes()
        destination = self.folder / "区域汇总.csv"
        result = self.cli("--regions-csv", str(destination))
        self.assertEqual(result.returncode, 0, result.stderr)
        with destination.open(encoding="utf-8", newline="") as stream:
            self.assertEqual(
                list(csv.reader(stream)),
                [
                    ["区域", "订单数", "净金额"],
                    ["大额", "1", "10.00"],
                    ["乙", "1", "2.00"],
                    ["甲", "1", "2.00"],
                    ["舍入", "1", "1.01"],
                    ["累加", "2", "0.01"],
                    ["零", "1", "0.00"],
                    ["负舍入", "1", "-0.01"],
                    ["负二", "1", "-2.00"],
                    ["负十", "1", "-10.00"],
                ],
            )
        self.assertEqual((self.folder / "summary.json").read_bytes(), original_json)
        self.assertEqual(self.source.read_bytes(), before)
        self.assertIn(
            "--regions-csv", (self.folder / "报告.md").read_text(encoding="utf-8")
        )

    def test_regions_csv_special_characters_and_precision(self):
        special = ' 华,东"\r\n分部 '
        self.fixture(
            [
                ["1", "B", "123456789012345678901234567890.12", ""],
                ["2", special, "2e0", ""],
                ["3", "A", "123456789012345678901234567890.13", ""],
                ["4", " 华东", "2.000", ""],
                ["5", "华东", "+2", ""],
                ["6", "", "0", ""],
            ]
        )
        destination = self.folder / "区域.csv"
        result = self.cli("--regions-csv", str(destination))
        self.assertEqual(result.returncode, 0, result.stderr)
        with destination.open(encoding="utf-8", newline="") as stream:
            self.assertEqual(
                list(csv.reader(stream)),
                [
                    ["区域", "订单数", "净金额"],
                    ["A", "1", "123456789012345678901234567890.13"],
                    ["B", "1", "123456789012345678901234567890.12"],
                    [special, "1", "2.00"],
                    [" 华东", "1", "2.00"],
                    ["华东", "1", "2.00"],
                    ["", "1", "0.00"],
                ],
            )

    def test_regions_csv_empty_and_input_protection(self):
        self.fixture([])
        destination = self.folder / "区域.csv"
        result = self.cli("--regions-csv", str(destination))
        self.assertEqual(result.returncode, 0, result.stderr)
        with destination.open(encoding="utf-8", newline="") as stream:
            self.assertEqual(list(csv.reader(stream)), [["区域", "订单数", "净金额"]])
        before = self.source.read_bytes()
        result = self.cli("--regions-csv", str(self.source))
        self.assertEqual(result.returncode, 2)
        self.assertEqual(self.source.read_bytes(), before)

    def test_input_cannot_be_output(self):
        self.fixture([["1", "北", "1", ""]])
        before = self.source.read_bytes()
        result = subprocess.run(
            [
                sys.executable,
                str(ROOT / "sales_summary.py"),
                str(self.source),
                "--output",
                str(self.source),
                "--report",
                str(self.folder / "r.md"),
            ],
            capture_output=True,
        )
        self.assertEqual(result.returncode, 2)
        self.assertEqual(self.source.read_bytes(), before)


if __name__ == "__main__":
    unittest.main()
