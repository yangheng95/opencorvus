const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),{Database}=require('bun:sqlite');
const root=path.resolve('specs/artifacts/2026-10-13-compaction-stress');
const names=['cross-model-user-retention-grant','cross-model-user-retention-read-repair-grant','cross-model-user-retention-eager-grant','cross-model-user-retention-eager-revoke'];
const reports=names.map(name=>{
 const r=JSON.parse(fs.readFileSync(path.join(root,name+'.json'),'utf8'));
 const audit=JSON.parse(fs.readFileSync(path.join(root,name+'.json.requests.json'),'utf8'));
 const summary=JSON.parse(fs.readFileSync(path.join(root,name+'-summary.json'),'utf8'));
 const db=new Database(path.join(r.runtime,'runtime/data/opencorvus.db'),{readonly:true});
 assert.equal(r.requests.length,audit.length);assert.equal(summary.requests,audit.length);
 const rounds=r.cases.map(c=>{
  const source=db.query('SELECT id,data FROM part WHERE message_id=? ORDER BY time_created,id').all(c.updateID)
   .map(row=>({id:row.id,...JSON.parse(row.data)})).find(p=>p.type==='text');assert(source);
  const selected=(c.retainedUserSources??[]).filter(m=>m.messageID===c.updateID);
  const actualText=selected.flatMap(m=>{assert.equal(m.role,'user');assert.equal(m.author,'user');return m.parts.map(p=>{
    assert.equal(p.partID,source.id);assert(source.text.includes(p.text));return p.text;
  });}).join('\n');
  const retainedFields=Object.fromEntries(Object.entries(c.expected).map(([key,value])=>[key,actualText.includes(value)]));
  const laneProofs=c.lanes.map(l=>{
   const probe=audit[l.requestStart]?.input_evidence?.probes?.find(p=>p.id===c.name);assert(probe);
   const userRole=probe.matches.some(m=>m.message_role==='user');
   if(l.lane==='full')assert(userRole);
   return {lane:l.lane,status:l.status,requestIndex:l.requestStart,userRole,matches:probe.matches};
  });
  const preserved=Object.values(retainedFields).every(Boolean)&&laneProofs.find(l=>l.lane==='compacted').userRole;
  const tools=db.query('SELECT r.id,r.data AS request,o.data AS outcome FROM tool_part_request r JOIN tool_part_outcome o ON o.request_part_id=r.id WHERE r.message_id=? ORDER BY r.time_created,r.id')
   .all(c.checkpoint.summaryID).map(row=>{
    const request=JSON.parse(row.request),outcome=JSON.parse(row.outcome);let output;
    try{output=JSON.parse(outcome.output)}catch{}
    return {partID:row.id,callID:request.callID,tool:request.tool,input:request.input,outcome:outcome.outcome,
     ...(output?{receipt:request.tool==='ReadCompactionEvidence'?{partID:output.partID,field:output.field,offset:output.offset,end:output.end,nextOffset:output.nextOffset,totalChars:output.totalChars,containsExpectedRegion:output.content?.includes(c.expected.region)}:output}:{failure:outcome.failure})};
   });
  return {round:c.round,status:c.status,summaryID:c.checkpoint.summaryID,source:{messageID:c.updateID,partID:source.id,totalChars:source.text.length,
   originalAuthorization:source.text.split('\n').find(line=>Object.values(c.expected).every(value=>line.includes(value)))},selected,retainedFields,preserved,laneProofs,tools};
 });db.close();
 const result={name,status:r.status,requests:audit.length,passedActions:summary.passedActions,passedFields:summary.passedFields,sourceRolePreserved:rounds.filter(r=>r.preserved).length,rounds};
 fs.writeFileSync(path.join(root,name+'-role-evidence.json'),JSON.stringify(result,null,2)+'\n');
 return result;
});
const final=reports.slice(-2);for(const r of final){assert.equal(r.status,'passed');assert.equal(r.sourceRolePreserved,5);assert.equal(r.passedActions,10);assert.equal(r.passedFields,50);}
const matrix={status:'passed',model:'openai/gpt-6-luna',compactedInputCeiling:19000,fullInputCeiling:256000,completedCheckpoints:10,actualActions:20,passedActions:20,passedFields:100,sourceRolePreserved:10,
 requests:final.reduce((n,r)=>n+r.requests,0),phaseRequests:reports.reduce((n,r)=>n+r.requests,0),priorRequests:618,total:618+reports.reduce((n,r)=>n+r.requests,0),runs:reports.map(({rounds,...r})=>r),
 limits:['Authored histories, one exact model per run; no universal retention or private Codex equivalence claim.','The first two interventions remain failures; passing controls do not erase them.','Role preservation is independently verified from original text and outgoing request roles, not summary self-report.']};
fs.writeFileSync(path.join(root,'user-retention-matrix-summary.json'),JSON.stringify(matrix,null,2)+'\n');console.log(JSON.stringify(matrix));
