const fs=require('node:fs'),path=require('node:path');
const scratch=path.resolve('.tmp-product-iteration/active-task-dock-414');
for(const name of ['launch','shutdown','settle','create-task']){
 let code=fs.readFileSync(path.join(scratch,name+'.ps1'),'utf8')
 .replaceAll('active-task-dock-414-live','active-task-dock-414-after')
 .replaceAll('18535','18537').replaceAll('active-task-dock-414-selection.json','active-task-dock-414-after-selection.json')
 .replaceAll('/settle.ps1','/settle-after.ps1');
 if(name==='create-task')code=code.replaceAll('活动 Task 侧栏 414','活动 Task 侧栏 414 修后')
 .replaceAll('task-request.json','after-task-request.json').replaceAll('task-selection.json','after-task-selection.json')
 .replaceAll('task-accepted.json','after-task-accepted.json').replaceAll('task-create.log','after-task-create.log');
 fs.writeFileSync(path.join(scratch,name+'-after.ps1'),code,{flag:'wx'});
}
fs.writeFileSync(path.join(scratch,'read-after-facts.ts'),fs.readFileSync(path.join(scratch,'read-facts.ts'),'utf8').replaceAll("'task-selection.json'","'after-task-selection.json'").replaceAll('`facts-${capture}.json`','`after-facts-${capture}.json`'),{flag:'wx'});
const bundle='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/active-task-dock-414-after-bundle';
fs.mkdirSync(path.join(bundle,'bin'),{recursive:true});
fs.copyFileSync('.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64/bun.exe',path.join(bundle,'bin/bun.exe'),fs.constants.COPYFILE_EXCL);
console.log(JSON.stringify({bundle,port:18537,requestLimit:40,nativeMaximumMs:600000}));
