const fs=require('node:fs'),path=require('node:path');
const scratch=path.resolve('.tmp-product-iteration/active-task-dock-414');
for(const name of ['launch.ps1','shutdown.ps1','settle.ps1','create-task.ps1']){
 let value=fs.readFileSync('.tmp-product-iteration/task-member-guidance-413/'+name,'utf8')
  .replaceAll('task-member-guidance-413','active-task-dock-414')
  .replaceAll('task-guidance-413-selection.json','active-task-dock-414-selection.json')
  .replaceAll('18529','18535');
 // Reuse the reviewed wrapper itself; only the diagnostic scope is new.
 if(name==='create-task.ps1')value=value.replace(/^\$taskRequest=.*$/m,"$taskRequest='请安排唯一一位读取成员核对本项目 README.md 第2—3行，并让该成员直接给出约2400字中文说明，分成12个有小标题的章节和一张简短表格。准确说明价格CNY 99、确认需求后5个工作日的交付约定，并始终保留“仅用于界面测试”的限定及原来源行号；区分原文事实与例子，不编造其他承诺。逐节解释这些字段应如何理解和呈现，避免重复填充。只读取本地材料，不联网、不修改文件。此Task用于体验长回复生成中的Sources阅读、成员侧栏及活动指导。'")
  .replaceAll('Task 成员指导 413','活动 Task 侧栏 414').replaceAll('product-experience-413','product-experience-414');
 fs.writeFileSync(path.join(scratch,name),value,{flag:'wx'});
}
fs.copyFileSync('.tmp-product-iteration/task-member-guidance-413/read-facts.ts',path.join(scratch,'read-facts.ts'),fs.constants.COPYFILE_EXCL);
const bundle='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/active-task-dock-414-live-bundle';
fs.mkdirSync(path.join(bundle,'bin'),{recursive:true});
fs.copyFileSync('.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64/bun.exe',path.join(bundle,'bin/bun.exe'),fs.constants.COPYFILE_EXCL);
console.log(JSON.stringify({bundle,port:18535,requestLimit:40,nativeMaximumMs:600000,wrapper:'live-sol-task-guidance-413.ts'}));
