const fs=require('node:fs'),path=require('node:path'),z=require('node:zlib'),assert=require('node:assert/strict');
const scratch=path.resolve('.tmp-product-iteration/active-task-dock-414'),out=path.resolve('specs/artifacts/2026-10-14-active-task-dock');
const read=p=>JSON.parse(fs.readFileSync(p,'utf8'));
const write=(p,b)=>{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,b,{flag:'wx'})};
const json=(name,value)=>write(path.join(out,name),JSON.stringify(value,null,2)+'\n');
const copy=(a,b)=>write(b,fs.readFileSync(a));const zip=(a,b)=>write(b,z.gzipSync(fs.readFileSync(a)));
const before=read(path.join(scratch,'facts-before-final.json')),preserved=read(path.join(scratch,'facts-preserved.json')),after=read(path.join(scratch,'after-facts-final.json'));
for(const kind of ['messages','parts','tools','outcomes'])for(const item of before[kind])assert.deepEqual(preserved[kind].find(x=>(x.id??x.requestPartID)===(item.id??item.requestPartID)),item);
for(const item of before.artifacts)assert.deepEqual(preserved.artifacts.find(x=>x.id===item.id)?.payload,item.payload);
const requests=after.artifacts.filter(a=>a.kind==='agent_coordination_request');assert.equal(requests.length,1);
const request=requests[0];assert.equal(request.id,'art_1c71e9b10c80478ebf95');
const response=after.artifacts.find(a=>a.kind==='agent_coordination_response'&&a.payload.request_id===request.id);
const action=after.artifacts.find(a=>a.id===response.payload.action_id);
const outcome=after.artifacts.find(a=>a.kind==='agent_coordination_action_outcome'&&a.payload.action_id===action.id);
assert.equal(response.payload.decision,'redispatch');assert.equal(action.payload.action,'redispatch_worker');assert.equal(outcome.payload.status,'completed');
assert.equal(outcome.payload.result.dispatch_session_id,request.payload.session_id);
const dispatch=after.tools.find(t=>t.tool==='dispatch_agent'&&t.input?.dispatch?.turn?.authority?.coordination_action_id===action.id);
assert.equal(after.outcomes.find(o=>o.requestPartID===dispatch.id)?.outcome,'completed');
const source=after.parts.find(p=>p.type==='source-file');assert.deepEqual(source.range,{startLine:2,endLine:3});
assert.equal(after.outcomes.find(o=>o.requestPartID===source.toolPartID)?.outcome,'completed');
const worker=after.messages.filter(m=>m.sessionID===request.payload.session_id),inputs=worker.filter(m=>m.role==='user');assert.equal(inputs.length,2);
const original=worker.find(m=>m.id==='msg_g0VXzrcIN00cCLHy56JF'),final=worker.find(m=>m.id==='msg_g0VXzrwjd003dt5niBzT');
assert.ok(request.payload.created_at<original.time.completed);assert.ok(final.time.completed>original.time.completed);
const finalText=after.parts.find(p=>p.id==='prt_g0VXzrxJd009xiH5glZq');assert.equal(finalText.messageID,final.id);
const scopes=[];
for(const scope of ['live','after']){
 const dir=`C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/active-task-dock-414-${scope}/evidence`;
 const native=read(path.join(dir,'native-host-settled.json')),cleanup=read(path.join(dir,'physical-terminal-and-pair-cleanup.json')),complete=read(path.join(dir,'task-complete.json'));
 assert.equal(native.terminal.exitCode,0);assert.equal(native.terminal.reason,'exited');
 for(const key of ['physicalCompletion','outputDrainComplete','requestCleanupComplete'])assert.equal(native[key],true);
 assert.equal(cleanup.pairedCleanupComplete,true);assert.equal(complete.lifecycle.status,'completed');
 const audit=fs.readdirSync(dir).filter(n=>n.startsWith('provider-')&&n.endsWith('.json')).map(n=>({n,v:read(path.join(dir,n))})).filter(x=>Array.isArray(x.v.requests)&&x.v.observedAt).sort((a,b)=>Date.parse(a.v.observedAt)-Date.parse(b.v.observedAt)).at(-1);
 for(const r of audit.v.requests){assert.equal(r.model,'gpt-6.1-sol');assert.equal(r.streaming,true);assert.equal(r.status,200);assert.equal(r.response_reader.state,'settled');assert.equal(r.response_reader.terminal.kind,'eof')}
 for(const name of ['native-host-ready.json','native-host-settled.json','physical-terminal-and-pair-cleanup.json','launcher-child-exit.json','preflight-ready.json','public-shutdown.json','task-boundary-admitted.json','task-occurrence-admitted.json','task-complete.json'])copy(path.join(dir,name),path.join(out,scope,name));
 copy(path.join(dir,audit.n),path.join(out,scope,'provider-audit.json'));
 scopes.push({scope,occurrence:native.occurrence,requests:audit.v.requests.length,task:complete.lifecycle,terminal:native.terminal,physicalCompletion:true,outputDrainComplete:true,requestCleanupComplete:true,pairedCleanupComplete:true});
}
json('persisted-check.json',{beforeTaskID:before.task.id,retainedMessages:before.messages.length,afterTaskID:after.task.id,projectID:after.task.project_id,requestID:request.id,responseID:response.id,actionID:action.id,outcome:outcome.payload,workerSessionID:request.payload.session_id,inputs:inputs.map(m=>({id:m.id,time:m.time})),originalReply:original.time,finalReply:final.time,requestAcceptedAt:request.payload.created_at,source:{id:source.id,path:source.path,range:source.range,toolPartID:source.toolPartID},finalText,boundary:'Read-only real SQLite + Task monitor facts. UI first response timed out; exact same ID retry returned acceptance after actual continuation. This does not qualify timely HTTP acknowledgement.'});
json('execution-summary.json',{scopes,totalRequests:scopes.reduce((n,s)=>n+s.requests,0),joins:{live:{handle:19442,chunk:'1606ba',exitCode:0},after:{handle:77295,chunk:'0d6d72',exitCode:0}},builds:[{handle:11839,chunk:'c6e184',exitCode:0},{handle:26138,chunk:'9e376e',exitCode:0}],typecheck:{handle:41683,chunk:'755f94',exitCode:0},screenshots:11,closedTabs:['33','34'],remaining:'Timely operator-steer HTTP receipt and shared acceptance/drain audit; two-member switching remains unqualified.'});
for(const name of fs.readdirSync(scratch)){
 if(/^\d\d-.*\.jpg$/.test(name))copy(path.join(scratch,name),path.join(out,name));
 else if(/^(after-)?(facts-.*|task-(request|selection|accepted))\.json$/.test(name))zip(path.join(scratch,name),path.join(out,'facts',name+'.gz'));
 else if(/\.(ps1|cjs|ts|log)$/.test(name)&&!name.startsWith('archive-check')&&!name.startsWith('commit'))zip(path.join(scratch,name),path.join(out,'execution',name+'.gz'));
}
zip('.tmp-product-iteration/live-sol-task-guidance-413.ts',path.join(out,'execution/live-sol-task-guidance-413.ts.gz'));
for(const name of ['push.log','push-exit.json','push-retry.log','push-retry-exit.json','push-delivery.log','push-delivery-exit.json','remote-after-delivery.txt','pending-reviewed.txt','pending-reviewed-retry.txt','merge-delivery.log'])zip(path.join('.tmp-product-iteration/task-member-guidance-413',name),path.join(out,'previous-413',name+'.gz'));
console.log(JSON.stringify({status:'qualified_partial',requests:scopes.map(s=>({scope:s.scope,count:s.requests})),retainedMessages:before.messages.length,requestID:request.id,continuationSession:request.payload.session_id,finalMessageID:final.id,screenshots:11}));
