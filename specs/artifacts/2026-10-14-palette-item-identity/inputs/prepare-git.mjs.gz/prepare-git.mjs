import fs from 'node:fs'
const prior='.tmp-codex-archive-experience-01a133',root='.tmp-codex-palette-item-identity-01a133'
let stage=fs.readFileSync(prior+'/stage-final.mjs','utf8').replaceAll(prior,root).replaceAll('2026-10-14-archive-experience-search','2026-10-14-palette-item-identity')
stage=stage.replace("const sources=['packages/opencorvus/src/work-ledger/projection.ts','packages/opencorvus/test/work-ledger-search.test.ts','packages/overlay/src/components/CommandPalette.tsx']","const sources=['packages/overlay/src/components/CommandPalette.tsx']")
if(stage.includes('src/work-ledger/projection.ts')||stage.includes('test/work-ledger-search.test.ts'))throw Error('Foreign source scope')
fs.writeFileSync(root+'/stage-final.mjs',stage)
fs.writeFileSync(root+'/commit-final.mjs',fs.readFileSync(prior+'/commit-final.mjs','utf8').replaceAll(prior,root).replace('fix(work-ledger): preserve conversation experience search through the palette','fix(overlay): distinguish command palette work item identities'))
const paragraph='Selectable ledger commands retain the original title and show the current UI\nlanguage\'s kind label beside the original Project directory basename. Chat and\nWork icons and labels use the same canonical conversation-experience helpers as\nthe Work Ledger and Archive, so equal titles within one Project remain\ndistinguishable through the existing visible and accessible option description.\n\n'
const shared=[{file:'specs/current/architecture/07-panel.md',anchor:'Each query owns its existing AbortController and captured API authority.',paragraph},{file:'CHANGELOG.md',zh:'- 命令面板使用 Chat/Work 的统一体验图标，并在工作项提示中显示类型与项目；同项目同名记录可清楚区分，原始标题和选择目标保持。',en:'- The command palette uses the shared Chat/Work experience icons and shows each work item\'s type beside its project, making equal titles within one project distinguishable while preserving original titles and selection targets.'}]
fs.writeFileSync(root+'/shared-final.json',JSON.stringify(shared,null,2)+'\n')
console.log('Prepared one-source exact private index and normal commit. Shared documents only use the reviewed B24 paragraph and entries.')
