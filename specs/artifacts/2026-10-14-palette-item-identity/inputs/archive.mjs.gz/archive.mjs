import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import {gzipSync} from 'node:zlib'
import {execFileSync} from 'node:child_process'
const scratch='.tmp-codex-palette-item-identity-01a133',artifact='specs/artifacts/2026-10-14-palette-item-identity',files=[],runs=[]
const gz=(from,to)=>{const bytes=fs.readFileSync(from);fs.mkdirSync(path.dirname(to),{recursive:true});fs.writeFileSync(to,gzipSync(bytes));files.push({source:from,saved:to.slice(artifact.length+1),originalBytes:bytes.length})}
for(const stage of ['before','after']){
 const root=`${scratch}/${stage}`,out=`${artifact}/runs/${stage}`,read=name=>JSON.parse(fs.readFileSync(root+'/'+name,'utf8')),ready=read('ready.json'),owner=read('owner.json'),cleanup=read('physical-pair-cleanup.json'),terminal=read('terminal.json')
 assert.equal(ready.pid,owner.pid);assert.equal(cleanup.pid,owner.pid);assert.equal(cleanup.actualExit,0);assert.equal(cleanup.listeners,0)
 assert.deepEqual(cleanup.pair.map(({name,removed})=>({name,removed})),[{name:'auth.json',removed:true},{name:'models.json',removed:true}])
 assert.equal(terminal.normalRuntimeSettlement,true);assert.equal(terminal.requests,0);assert.equal(terminal.realSolCalls,0)
 for(const name of fs.readdirSync(root))if(name.endsWith('.json')&&name!=='privacy-ready.json')gz(root+'/'+name,out+'/'+name+'.gz')
 for(const name of fs.readdirSync(root+'/redacted-logs'))gz(root+'/redacted-logs/'+name,out+'/logs/'+name+'.gz')
 runs.push({stage,pid:ready.pid,occurrence:ready.occurrence,port:ready.port,participantPort:ready.participantPort,uiDirectory:ready.uiDirectory,physicalExit:cleanup.actualExit,inferenceRequests:terminal.requests,privacy:read('privacy-qualified.json').files})
}
const passed=['before-parent','privacy-before','after-parent','privacy-after','data-before','data-after-ready','data-ui-final','overlay-typecheck','ui-build','docs-current','architecture-current','fetch-after-b23','merge-after-b23']
for(const name of ['docs-final','architecture-final'])if(fs.existsSync(`${scratch}/${name}.exit`))passed.push(name)
for(const name of passed)assert.equal(fs.readFileSync(`${scratch}/${name}.exit`,'utf8').trim(),'0',name+' actual original exit')
const failed=['data-after'],failureExits=Object.fromEntries(failed.map(name=>[name,fs.readFileSync(`${scratch}/${name}.exit`,'utf8').trim()]))
for(const name of [...passed,...failed])for(const ext of ['log','exit'])gz(`${scratch}/${name}.${ext}`,`${artifact}/checks/${name}.${ext}.gz`)
for(const name of ['setup.mjs','runtime.ts','launch.ps1','privacy.ts','run.mjs','data.mjs','data.initial.mjs','CommandPalette.before.tsx','baseline.json','prepare-git.mjs','stage-final.mjs','commit-final.mjs','shared-final.json','archive.mjs'])gz(`${scratch}/${name}`,`${artifact}/inputs/${name}.gz`)
const rawGroups=[['before','data-create-receipts.json'],['after','data-create-receipts.json'],['after','data-ui-final-receipts.json']].map(([stage,name])=>({stage,name,count:JSON.parse(fs.readFileSync(`${scratch}/${stage}/${name}`,'utf8')).receipts.length})),retained=rawGroups.reduce((n,r)=>n+r.count,0)
assert.equal(retained,41)
fs.writeFileSync(artifact+'/manifest.json',JSON.stringify({capturedAt:new Date().toISOString(),purpose:'Lossless evidence capture and exact resource identity, not a mutable-source checksum or functional hash gate.',runs,failureExits,retainedHTTPReceipts:retained,rawGroups,files},null,2)+'\n')
fs.writeFileSync(artifact+'/README.md',`# 第24批：命令面板工作项身份

对应[Recall、实施前分析、失败与最终资格](../../records/2026-10/2026-10-14-palette-item-identity.md)。Root独立实施并逐一查看10张原PNG；没有子agent、聊天消息、UI自动化、真实凭据或模型推理。

- [screenshots](screenshots/README.md)：01/02修前英文最近项/同名查询，Chat与Work同图标且hint仅项目；03/04最终英文最近项/查询显示canonical Chat/Work图标及类型/项目；05实际点击A-Chat，06当前Ctrl+6实际打开A-Work；07中文同名6项，08原B-Mission完整请求与未开始状态；09中文Work类型查询保留两Work与本地命令，10当前Ctrl+1实际打开B-Work。全部未编辑，不以可访问文本或构建替代视觉。
- [runs](runs/README.md)：before PID57596、18666/67；after PID78496、18668/69，新独立occurrence和原Node UI。公开创建/命名两Project的同名4会话+2Mission草稿，原17+17及人工交互后7读回共${retained}个正式HTTP原响应；UI请求另计。原ID/experience/project/draft保存，Mission未派发。首after checker在ready前ENOENT/exit1，没有HTTP；补30秒有界ready后原准备/读取重跑0，不覆盖失败。
- [checks](checks/README.md)：overlay类型0，Node构建0（1m7s，warnings原件），docs345/26和架构20当前检查0；两原父退出/物理同对清理/完整日志隐私均0。失败data-after原1保留；没有UI或源码文案断言。中文语言候选重建期间首数字点击工具无法解析目标，重取后真实Enter完成，没有伪称首次成功。
- [inputs](inputs/README.md)：原修前CommandPalette、唯一HTTP checker/旧checker、独立生命周期与精确提交工具。产品只有CommandPalette接入现有conversation helper及类型/原项目hint；没有新配置、查询或数据格式。
- [previous-delivery](previous-delivery/README.md)：B23 af6d6896f正常commit/push0、原全部hook及完整pending原审阅。Root后续fresh fetch/merge确认own祖先，远端观察58096d4d7。

tab28/29均关闭。两轮正常settlement/父exit0/双端口0后删除自有假auth/models整对；后台完整原日志103958/162743字节，stdout/stderr各0，隐私0。inferenceRequests与realSolCalls均0；Task执行/恢复、长列表/长目录、真实Provider和永久删除未独立验收。当前架构/未发布中英日志/三索引同步；提交与push按后续实际回执结算。见[原捕获清单](manifest.json)。
`)
for(const [name,title,description]of [['screenshots','真实桌面原图','10张Root逐一查看的原PNG；修前缺口与最终实际选择/原草稿均保留。'],['runs','正式输入与真实生命周期','41个正式响应、两独立原occurrence及实际退出，凭据/数据库内容不归档。'],['checks','原检查与退出状态','真实0与ready时序原1均保留，类型/构建不替代视觉。'],['inputs','实施前原件与工具','HTTP checker仅检查真实接口；没有UI自动化或源码文案测试。']]){fs.mkdirSync(`${artifact}/${name}`,{recursive:true});fs.writeFileSync(`${artifact}/${name}/README.md`,`# ${title}\n\n${description} 见[主说明](../README.md)。\n`)}
fs.writeFileSync(scratch+'/status-before-commit.txt',execFileSync('git',['status','--short']))
console.log(JSON.stringify({artifact,capturedFiles:files.length,retainedHTTPReceipts:retained,runs:runs.map(({stage,pid,physicalExit})=>({stage,pid,physicalExit})),failureExits}))
