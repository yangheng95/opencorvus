import fs from 'node:fs'
import path from 'node:path'
import {gzipSync} from 'node:zlib'
import {execFileSync} from 'node:child_process'
const root='.tmp-codex-palette-item-identity-01a133',prior='.tmp-codex-archive-experience-01a133',artifact='specs/artifacts/2026-10-14-palette-item-identity'
fs.mkdirSync(root,{recursive:true});fs.mkdirSync(artifact+'/screenshots',{recursive:true});fs.mkdirSync(artifact+'/previous-delivery',{recursive:true})
for(const name of ['runtime.ts','launch.ps1','privacy.ts','run.mjs'])fs.writeFileSync(root+'/'+name,fs.readFileSync(prior+'/'+name,'utf8').replaceAll(prior,root).replaceAll('archive experience search','palette item identity').replaceAll('18662','18666').replaceAll('18663','18667').replaceAll('18664','18668').replaceAll('18665','18669'))
for(const name of ['commit-final.log','commit-final.exit','commit-final-created.json','commit-final-receipt.json','pending-final-review.json','push-final.log','push-final.exit','push-final-receipt.json','push-final.mjs','fetch-current.log','fetch-current.exit','merge-current.log','merge-current.exit','exact-module.log','exact-module.exit','exact-release.log','exact-release.exit','reconcile-check.log','reconcile-check.exit'])fs.writeFileSync(artifact+'/previous-delivery/'+name+'.gz',gzipSync(fs.readFileSync(prior+'/'+name)))
const head=execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),source='packages/overlay/src/components/CommandPalette.tsx'
fs.writeFileSync(root+'/CommandPalette.before.tsx',execFileSync('git',['show',head+':'+source]))
fs.writeFileSync(root+'/baseline.json',JSON.stringify({head,source,capturedAt:new Date().toISOString()},null,2)+'\n')
fs.writeFileSync(artifact+'/previous-delivery/README.md','# 第23批真实交付回执\n\naf6d6896f正常提交和推送实际0，全部原hook通过。后续fresh fetch/merge和远端观察为58096d4d7，own提交为其祖先。原始日志/实际exit保留，不改写历史失败。\n')
console.log(JSON.stringify({root,head,beforePorts:[18666,18667],afterPorts:[18668,18669],noRealCredential:true}))
