import fs from 'node:fs/promises'
import path from 'node:path'
import assert from 'node:assert/strict'
async function main(){
 const [stage,mode='create']=process.argv.slice(2)
 assert.match(stage??'',/^(before|after)([0-9]{2})?$/)
 const root=path.resolve('.tmp-codex-palette-item-identity-01a133',stage),ready=JSON.parse(await fs.readFile(root+'/ready.json','utf8')),base=`http://127.0.0.1:${ready.port}`,receipts=[]
 async function call(url,method='GET',body,expected=200){
  const response=await fetch(base+url,{method,headers:body?{'Content-Type':'application/json'}:undefined,body:body?JSON.stringify(body):undefined}),raw=await response.text()
  receipts.push({url,method,body,status:response.status,raw})
  await fs.writeFile(root+`/data-${mode}-progress.json`,JSON.stringify({receipts},null,2)+'\n')
  assert.equal(response.status,expected,`${method} ${url}`)
  const value=JSON.parse(raw);receipts.at(-1).response=value;return value
 }
 let items=[]
 if(mode==='create'){
  for(const project of ready.projects){
   const q='?'+new URLSearchParams({directory:project.directory}),title='季度计划'
   for(const experience of ['work','chat']){
    const {session}=await call(`/coding/${experience}/session`+q,'POST',{},201)
    const {session:renamed}=await call(`/coding/${experience}/session/${session.id}`+q,'PATCH',{title})
    assert.equal(renamed.id,session.id);assert.equal(renamed.metadata.conversation.experience,experience);assert.equal(renamed.title,title)
    items.push({kind:'chat',experience,project:project.label,projectID:renamed.projectID,directory:project.directory,id:session.id,sessionID:session.id,title})
   }
   const request=`这是${project.label}项目的原季度计划草稿。仅确认同名工作项的选择和重新打开，不派发执行。`
   const mission=await call('/mission/draft'+q,'POST',{title,request,productPillar:'work',expertSquadIDs:['base']})
   assert.equal(mission.pendingPrompt.text,request);assert.equal(mission.title,title)
   items.push({kind:'mission',project:project.label,projectID:mission.projectID,directory:project.directory,id:mission.missionID,sessionID:mission.sessionID,title,request,boardLane:mission.boardLane,taskStats:mission.taskStats})
  }
  await fs.writeFile(root+'/inputs.json',JSON.stringify(items,null,2)+'\n')
 }else items=JSON.parse(await fs.readFile(root+'/inputs.json','utf8'))
 const all=await call('/work-ledger?'+new URLSearchParams({search:'季度计划',limit:'100'}))
 const identity=r=>({kind:r.kind,id:r.id,sessionID:r.sessionID,title:r.title,directory:r.directory,...(r.kind==='chat'?{experience:r.experience}:{})})
 const sorted=rows=>rows.map(identity).sort((a,b)=>a.id.localeCompare(b.id))
 assert.deepEqual(sorted(all.rows),sorted(items))
 for(const item of items){
  const q='?'+new URLSearchParams({directory:item.directory})
  if(item.kind==='chat'){
   const {session}=await call(`/coding/${item.experience}/session/${item.id}`+q)
   assert.equal(session.id,item.id);assert.equal(session.projectID,item.projectID);assert.equal(session.title,item.title);assert.equal(session.metadata.conversation.experience,item.experience)
  }else{
   const list=await call('/mission?'+new URLSearchParams({directory:item.directory,archived:'false'})),mission=list.find(m=>m.missionID===item.id)
   assert.equal(mission.missionID,item.id);assert.equal(mission.pendingPrompt.text,item.request);assert.equal(mission.boardLane,item.boardLane);assert.deepEqual(mission.taskStats,item.taskStats)
  }
 }
 await fs.writeFile(root+`/data-${mode}-receipts.json`,JSON.stringify({receipts,items,rows:all.rows.map(identity)},null,2)+'\n')
 console.log(JSON.stringify({stage,mode,actualHTTP:receipts.length,rows:all.rows.map(identity)}))
}
await main().catch(error=>{console.error(error);process.exitCode=1})
