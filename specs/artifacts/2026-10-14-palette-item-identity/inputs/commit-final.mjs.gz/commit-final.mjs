import fs from 'node:fs'
import {execFileSync} from 'node:child_process'
import {applyPatch,reversePatch} from '../node_modules/.bun/diff@8.0.3/node_modules/diff/libesm/index.js'
const scratch='.tmp-codex-palette-item-identity-01a133',review=JSON.parse(fs.readFileSync(scratch+'/reviewed-final-index.json','utf8'))
const git=(args,input,env=process.env)=>execFileSync('git',args,{encoding:'utf8',maxBuffer:64*1024*1024,env,...(input===undefined?{}:{input})})
const reconcileOnly=process.argv.includes('--reconcile')
if(!reconcileOnly){
 if(git(['rev-parse','HEAD']).trim()!==review.head)throw Error('Concurrent HEAD changed; regenerate reviewed index')
 const env={...process.env,GIT_INDEX_FILE:review.index}
 git(['diff','--cached','--check'],undefined,env)
 if(JSON.stringify(git(['diff','--cached','--name-only'],undefined,env).trim().split('\n'))!==JSON.stringify(review.files))throw Error('Reviewed scope changed')
 execFileSync('git',['commit','-m','fix(overlay): distinguish command palette work item identities'],{env,stdio:'inherit'})
}
const commit=reconcileOnly?JSON.parse(fs.readFileSync(scratch+'/commit-final-created.json','utf8')).commit:git(['rev-parse','HEAD']).trim(),parent=git(['rev-parse',commit+'^']).trim()
if(parent!==review.head)throw Error('Committed parent changed')
if(JSON.stringify(git(['diff-tree','--no-commit-id','--name-only','-r',commit]).trim().split('\n'))!==JSON.stringify(review.files))throw Error('Committed paths differ')
fs.writeFileSync(scratch+'/commit-final-created.json',JSON.stringify({commit,parent,files:review.files,normalGitCommitExit:0,privateReviewedIndex:review.index,at:new Date().toISOString()},null,2)+'\n')
const owned=review.files.filter(x=>review.sources.includes(x)||x===review.record||x.startsWith(review.artifact))
const batch=execFileSync('git',['cat-file','--batch'],{input:owned.map(x=>commit+':'+x).join('\n')+'\n',maxBuffer:64*1024*1024});let cursor=0
for(const file of owned){
 const end=batch.indexOf(10,cursor),header=batch.subarray(cursor,end).toString('utf8').split(' ')
 if(header[1]!=='blob')throw Error('Exact committed blob unavailable')
 const size=Number(header[2]),saved=batch.subarray(end+1,end+1+size);cursor=end+2+size
 const disk=fs.readFileSync(file)
 if(file.endsWith('.png')||file.endsWith('.gz')?!disk.equals(saved):disk.toString('utf8').replaceAll('\r\n','\n')!==saved.toString('utf8'))throw Error('Owned file changed '+file)
}
git(['add','-f','--',...review.sources,review.record,review.artifact])
const sharedUpdates=[]
for(const item of review.shared){
 const before=git(['show',':'+item.file]).replaceAll('\r\n','\n')
 if(applyPatch(before,reversePatch(item.patch))!==false)continue
 const after=applyPatch(before,item.patch)
 if(after===false)throw Error('Shared index changed; precise reconciliation required '+item.file)
 sharedUpdates.push(`100644 ${git(['hash-object','-w','--stdin'],after).trim()}\t${item.file}\n`)
}
if(sharedUpdates.length)git(['update-index','--index-info'],sharedUpdates.join(''))
fs.writeFileSync(scratch+'/commit-final-receipt.json',JSON.stringify({commit,parent,scopedPaths:review.files.length,normalGitCommitExit:0,indexReconciliation:'Exact committed blobs checked in one batch; only own source and reviewed shared patches applied; peer staging preserved',at:new Date().toISOString()},null,2)+'\n')
console.log(JSON.stringify({commit,parent,scopedPaths:review.files.length,normalCommitExit:0,indexReconciled:true}))
