# PREPARED ONLY. Each exact Prepare/Run invocation requires Root's separate authorization.
param(
  [Parameter(Mandatory=$true)][ValidateSet('active','idle')][string]$Case,
  [Parameter(Mandatory=$true)][ValidateSet('Prepare','Run')][string]$Mode
)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'owned-launch-functions.ps1')
$casePrefix='directory-target-native-'+$Case+'-resolution-02'
$caseRun=[IO.Path]::GetFullPath('C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/'+$casePrefix+'-01a133')
$caseEvidence=Join-Path $caseRun 'evidence'
$caseBinary='D:/myhexin-local/opencorvus/.tmp-codex-directory-target-01a133/ui-bundle/bin/bun.exe'
$caseNode='C:/Program Files/nodejs/node.exe'
$caseProgram=Join-Path $PSScriptRoot 'native-activity-target.mjs'
$caseManifest=Join-Path $caseRun 'prepared-native-case.json'
function Assert-CaseDirect([string]$directory) {
  $item=Get-Item -LiteralPath $directory -Force -ErrorAction Stop
  if(!$item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Exact direct physical case directory required'}
  return @{path=$item.FullName;creationTimeUtc=$item.CreationTimeUtc.ToString('o');attributes=[string]$item.Attributes}
}
# Root creates these two empty passive directories once. They own no service or Task.
$null=Assert-CaseDirect (Join-Path $PSScriptRoot 'native-observer')
$null=Assert-CaseDirect (Join-Path $PSScriptRoot 'native-observer/runtime')
$caseDirectories=@('runtime','evidence','home','appdata','localappdata','temp','xdg-config','xdg-data','xdg-cache','xdg-state')
if($Mode -ceq 'Prepare') {
  $null=Assert-CaseDirect (Split-Path $caseRun -Parent)
  if(Test-Path -LiteralPath $caseRun){throw 'Case namespace already exists; never replace/reuse it'}
  $null=New-Item -ItemType Directory -Path $caseRun
  foreach($name in $caseDirectories){$null=New-Item -ItemType Directory -Path (Join-Path $caseRun $name)}
  $physical=@(Assert-CaseDirect $caseRun; foreach($name in $caseDirectories){Assert-CaseDirect (Join-Path $caseRun $name)})
  foreach($file in @($caseBinary,$caseNode,$caseProgram,(Join-Path $PSScriptRoot 'native-host.ts'))){
    $item=Get-Item -LiteralPath $file -Force -ErrorAction Stop
    if($item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Direct original executable/program required'}
  }
  $occurrence=$casePrefix+'-'+[Guid]::NewGuid().ToString()
  $expectedReason=if($Case -ceq 'active'){'exited'}else{'inactivity_timeout'}
  $expectedHostExit=if($Case -ceq 'active'){0}else{1}
  Write-OwnedLaunchFact $caseManifest @{schema='directory-target-native-activity/v1';case=$Case;prefix=$casePrefix;occurrence=$occurrence;runRoot=$caseRun;evidence=$caseEvidence;hostExecutable=$caseBinary;nodeExecutable=$caseNode;program=$caseProgram;inactivityTimeoutMs=200;executionCapMs=30000;expectedReason=$expectedReason;expectedHostExit=$expectedHostExit;expectedOutputCount=if($Case -ceq 'active'){7}else{1};physical=$physical;modelCallsRequested='none';credentialCatalogStaging='none';qualification='Prepared production NativeFacade timer qualification only; no service/UI/function acceptance';preparedAtUtc=[DateTime]::UtcNow.ToString('o')}
  Write-Output $caseManifest
  return
}
$prepared=Get-Content -Raw -LiteralPath $caseManifest|ConvertFrom-Json
if($prepared.schema -cne 'directory-target-native-activity/v1' -or $prepared.case -cne $Case -or $prepared.prefix -cne $casePrefix -or [IO.Path]::GetFullPath($prepared.runRoot) -ne $caseRun -or $prepared.hostExecutable -cne $caseBinary -or $prepared.nodeExecutable -cne $caseNode -or $prepared.program -cne $caseProgram -or $prepared.inactivityTimeoutMs -ne 200 -or $prepared.executionCapMs -ne 30000 -or $prepared.modelCallsRequested -cne 'none' -or $prepared.credentialCatalogStaging -cne 'none'){throw 'Exact prepared Native case required'}
$null=Assert-CaseDirect $caseRun
foreach($name in $caseDirectories){$null=Assert-CaseDirect (Join-Path $caseRun $name)}
$deadline=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()+[long]$prepared.executionCapMs
$arguments=@((Join-Path $PSScriptRoot 'native-host.ts'),'--owned-host',$caseEvidence,$prepared.occurrence,[string]$deadline,[string]$prepared.inactivityTimeoutMs,$caseNode,$caseProgram,'--case',$Case,$prepared.occurrence)
$start=[Diagnostics.ProcessStartInfo]::new()
$start.FileName=$caseBinary;$start.WorkingDirectory=$caseRun;$start.UseShellExecute=$false;$start.CreateNoWindow=$true
$start.RedirectStandardOutput=$true;$start.RedirectStandardError=$true;$start.Environment.Clear()
foreach($name in @('PATH','SystemRoot','WINDIR','ComSpec','PATHEXT','LANG','LC_ALL','LC_CTYPE')){if(Test-Path -LiteralPath "Env:$name"){$start.Environment[$name]=[Environment]::GetEnvironmentVariable($name)}}
foreach($mapping in @(@('HOME','home'),@('USERPROFILE','home'),@('APPDATA','appdata'),@('LOCALAPPDATA','localappdata'),@('TEMP','temp'),@('TMP','temp'),@('TMPDIR','temp'),@('XDG_CONFIG_HOME','xdg-config'),@('XDG_DATA_HOME','xdg-data'),@('XDG_CACHE_HOME','xdg-cache'),@('XDG_STATE_HOME','xdg-state'),@('OPENCORVUS_HOME','runtime'))){$start.Environment[$mapping[0]]=Join-Path $caseRun $mapping[1]}
$start.Environment['HOMEDRIVE']='C:';$start.Environment['HOMEPATH']=$start.Environment['HOME'].Substring(2).Replace('/','\')
$start.Environment['OPENCORVUS_TASK_PROCESS_MODE']='native';$start.Environment['OPENCORVUS_DISABLE_EXTERNAL_SKILLS']='1';$start.Environment['OPENCORVUS_DISABLE_AUTOUPDATE']='1'
foreach($argument in $arguments){$start.ArgumentList.Add($argument)}
# Exclusive admission is published before Start. An ambiguous run is never retried.
Write-OwnedLaunchFact (Join-Path $caseEvidence ($casePrefix+'-inputs.json')) @{schema=$prepared.schema;occurrence=$prepared.occurrence;case=$Case;runRoot=$caseRun;manifest=$caseManifest;executable=$caseBinary;arguments=$arguments;deadlineAt=$deadline;executionCapMs=$prepared.executionCapMs;inactivityTimeoutMs=$prepared.inactivityTimeoutMs;printLogs=$false;environmentNames=@($start.Environment.Keys);admittedAtUtc=[DateTime]::UtcNow.ToString('o')}
$process=[Diagnostics.Process]::new();$process.StartInfo=$start
$outFile=[IO.File]::Open((Join-Path $caseRun 'stdout.log'),[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read)
$errFile=[IO.File]::Open((Join-Path $caseRun 'stderr.log'),[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read)
if(!$process.Start()){throw 'Original Native qualification Host failed to start'}
$outDrain=$process.StandardOutput.BaseStream.CopyToAsync($outFile)
$errDrain=$process.StandardError.BaseStream.CopyToAsync($errFile)
while(!$process.WaitForExit(500)){}
$process.WaitForExit()
$drainFacts=@();$drainErrors=@()
foreach($pair in @(@('stdout',$outDrain),@('stderr',$errDrain))){try{$null=$pair[1].GetAwaiter().GetResult();$drainFacts+=@{stream=$pair[0];status='fulfilled'}}catch{$drainErrors+=$_;$drainFacts+=@{stream=$pair[0];status='rejected';error=$_.Exception.ToString()}}}
$outFile.Dispose();$errFile.Dispose()
Write-OwnedLaunchFact (Join-Path $caseEvidence ($casePrefix+'-parent-joined.json')) @{occurrence=$prepared.occurrence;hostPID=$process.Id;parentPID=$PID;exitCode=$process.ExitCode;outputs=$drainFacts;observedAtUtc=[DateTime]::UtcNow.ToString('o')}
try {
  if($drainErrors.Count){throw 'Original parent output drain failed; all facts retained'}
  $ready=Get-Content -Raw -LiteralPath (Join-Path $caseEvidence 'native-host-ready.json')|ConvertFrom-Json
  if($ready.occurrence -cne $prepared.occurrence -or $ready.host.pid -ne $process.Id -or $ready.deadlineAt -ne $deadline -or $ready.inactivityTimeoutMs -ne 200 -or $ready.printLogs -ne $false -or [IO.Path]::GetFullPath($ready.executable) -ne [IO.Path]::GetFullPath($caseNode)){throw 'Original Native ready identity/input mismatch'}
  $settled=Get-OwnedNativeSettlement @{evidence=$caseEvidence;occurrence=$prepared.occurrence;host=$ready.host;nativeTarget=$ready.target}
  if(!$settled -or $settled.terminal.reason -cne $prepared.expectedReason -or $process.ExitCode -ne $prepared.expectedHostExit){throw 'Original terminal does not meet the predeclared positive timer contract'}
  $stdout=[IO.File]::ReadAllBytes((Join-Path $caseRun 'stdout.log'));$stderr=[IO.File]::ReadAllBytes((Join-Path $caseRun 'stderr.log'))
  if([Convert]::ToBase64String($stdout) -cne [Convert]::ToBase64String([IO.File]::ReadAllBytes((Join-Path $caseEvidence 'native-host-stdout.bin'))) -or [Convert]::ToBase64String($stderr) -cne [Convert]::ToBase64String([IO.File]::ReadAllBytes((Join-Path $caseEvidence 'native-host-stderr.bin')))){throw 'Original child bytes were not fully transported to parent files'}
  $lines=@([Text.UTF8Encoding]::new($false,$true).GetString($stdout).Split("`n")|Where-Object Length -gt 0|ForEach-Object {$_|ConvertFrom-Json})
  if($lines.Count -ne $prepared.expectedOutputCount){throw 'Original complete positive output sequence mismatch'}
  for($index=0;$index -lt $lines.Count;$index++){
    $line=$lines[$index]
    if($line.index -ne $index -or $line.case -cne $Case -or $line.occurrence -cne $prepared.occurrence -or $line.pid -ne $ready.target.pid -or [IO.Path]::GetFullPath($line.execPath) -ne [IO.Path]::GetFullPath($caseNode) -or $line.elapsedMs -lt 0){throw 'Original Node output identity/sequence mismatch'}
    if($index -gt 0 -and $line.elapsedMs -lt $lines[$index-1].elapsedMs){throw 'Original Node monotonic output time regressed'}
  }
  if($Case -ceq 'active' -and ($lines[-1].elapsedMs -lt 400 -or $settled.terminal.exitCode -ne 0 -or $settled.runOutcome -cne 'returned')){throw 'Output-active Node did not prove natural completion beyond the inactivity budget'}
  if($Case -ceq 'idle' -and ($settled.runOutcome -cne 'rejected' -or $settled.firstRunError.type -cne 'ProcessInactivityTimeoutError')){throw 'Idle Node did not yield the original typed inactivity result'}
  $chain=@(@($ready.host,$ready.target)|ForEach-Object {@{expected=$_;state=(Get-OwnedNativeState $_)}})
  if(@($chain|Where-Object state -ne 'dead_or_reused').Count){throw 'Original Native Host/Target occurrence still live'}
  Write-OwnedLaunchFact (Join-Path $caseEvidence ($casePrefix+'-qualification.json')) @{occurrence=$prepared.occurrence;case=$Case;qualification='positive-production-Native-output-inactivity-contract';outcome='passed';originalHostExit=$process.ExitCode;terminal=$settled.terminal;outputs=$lines;chain=$chain;physicalCompletion=$true;outputDrainComplete=$true;requestCleanupComplete=$true;uiAcceptance='not-applicable';modelCallsRequested='none';observedAtUtc=[DateTime]::UtcNow.ToString('o')}
} catch {
  Write-OwnedLaunchFact (Join-Path $caseEvidence ($casePrefix+'-qualification-error.json')) @{occurrence=$prepared.occurrence;case=$Case;outcome='failed';originalHostExit=$process.ExitCode;error=$_.Exception.ToString();observedAtUtc=[DateTime]::UtcNow.ToString('o');boundary='Original facts retained; no retry, kill, namespace reuse or success rewrite'}
  throw
}
# The idle qualification may pass its expected contract while the original Host/parent exit remains 1.
exit $process.ExitCode
