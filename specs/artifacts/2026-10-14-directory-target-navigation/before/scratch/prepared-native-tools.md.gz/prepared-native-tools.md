# Directory target Native tools — resolution-02 prepared, not executed

## Current resolution-02 status (supersedes the original preparation status below)

Root authorized only a scratch import-resolution repair and seven syntax checks after the first active case failed. The original active Prepare returned0 (PS61960); original Run returned1 (PS86556). Original Host38876 exited1 and the actual PS parent joined both original output streams as fulfilled at2026-10-13T17:59:19.9928675Z. The outer tool joined parent86556/output streams at17:59:20.2375134Z. Full original Host stderr explicitly reports `Cannot find module '@opencorvus-ai/util/process' from .../native-host.ts` on Bun1.4.0. That new bare dynamic import occurs before facade.run/onSpawned; the later missing-ready error is secondary. No Target handle or Native timer result was acquired. This conclusion uses the original exception and source order, not file absence alone.

Full production `packages/opencorvus/src/util/process-facade.ts` was reread: it imports `@opencorvus-ai/util/process`; its package-local dependency link points to `packages/util`, whose Bun/source export maps process to `src/process.ts`. The scratch Host now type-imports `../packages/util/src/process.ts` and dynamically imports that exact source via pathToFileURL. This is the same production definition, without copied code, a second resolver, fallback, or a product change. Runtime module identity remains to be confirmed by the newly authorized future actual case; syntax alone does not prove it.

All seven pre-repair tool files plus their input/report and the original eight wrapper input/stdout/stderr/exit files are preserved byte-for-byte in `native-resolution-first-history/`. The actual first run remains untouched at `C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/directory-target-native-active-01a133`, occurrence `directory-target-native-active-b5b99929-1097-4f40-83c7-fb3a32f1183b`. Its prepared/input/parent-joined/qualification-error files and complete stdout/stderr are retained. The first idle case was not created or executed.

The current two fresh case prefixes are `directory-target-native-active-resolution-02` and `directory-target-native-idle-resolution-02`; each runRoot adds `-01a133` under the same approved dated parent. The child occurrence validator and explicit current input JSON agree. No new Prepare/Run is executed under this repair authorization. The original case namespace cannot be reused. Native200ms activity/30s execution inputs, full output and expected active0/idle1 contracts remain unchanged. The service namespace/port/fixture stays directory-target-before/18455.

Complete original-to-resolution-02 diffs are saved in `native-resolution-02-diffs/`. New syntax outputs are stored in the new unique `tool-validation/syntax-*` directory and reported to Root separately. The original preparation description below is retained as its historical stage description; its claims that no case has executed apply only to that earlier stage, not to the failed original active occurrence above.

## Recall / exact scope

Root authorized preparation after formally recording `specs/records/2026-10/2026-10-14-directory-target-navigation.md`. Read its complete Recall, phase1, budget, input and delivery sections before editing. This owner may only prepare ignored scratch tools and perform pure syntax checks. No service, API, model, fixture, process qualification or UI entrypoint has run; no owned runtime or passive observer directory has been created by this owner. The other owner implements the fixture and API tools. Product/tests/formal specs/index/Git remain untouched here.

Original source is the single previous `.tmp-codex-next-feedback-01a133` mature set. Exact copies of five originals are saved in `native-original/`: native-host.ts, owned-launch-functions.ps1, launch-ui.ps1, shutdown.ps1, check-tool-syntax.ps1. `owned-launch-functions.ps1` remains unchanged. Complete original-to-current diffs are in `native-diffs/`; the two newly authored qualification scripts are reviewed as their complete source files. No source digest is a functional qualification.

## Prepared service inputs

- RunRoot: `C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/directory-target-before-01a133`.
- Port18455; prefix and scratch evidence `directory-target-before`.
- Private Bun/UI pair: `.tmp-codex-directory-target-01a133/ui-bundle/bin/bun.exe` and sibling ui. Root reported its actual private build completed before this preparation; this owner did not rerun it or claim new runtime qualification.
- Original source CLI remains `packages/opencorvus/src/index.ts serve`, with existing INFO and newly admitted `--print-logs`. There is no outer inactivity driver or fake ping.
- Original absolute execution input is created once as now+900000; one `inactivityTimeoutMs=120000` is passed separately to the same facade.run. Startup45s/shutdown45s/other settlement join75s remain observations. They never reset/restart the command.
- Producer contract coordinated directly with the fixture owner: `directory-target-navigation.fixture/v1`, qualification=`real-desktop-directory-target-navigation`, fixtureID/runRoot/port/prefix; scopes.root.directory=A/project and scopes.b.directory=B/project-b; modelCallsRequested and credentialCatalogStaging both none. Inputs reference the complete original manifest path and ID, without inventing old query/files/pickerInputs fields.
- Environment mapping remains the original small allowlist and exact run-local home/appdata/localappdata/temp/xdg-config/xdg-data/xdg-cache/xdg-state/runtime directories. No inherited user HOME/config, provider/catalog staging or credential reads.

The service launcher keeps exclusive original launch admission, hidden Windows process, redirected full parent streams, original Native ready+startup binding, actual Target/Host birth, original port owner, immutable UI asset binding, first setup failure, optional ordinary public shutdown once and same-parent join. The hidden `.git` `Get-Item -Force` repair is retained. The shutdown tool only changes this namespace/schema/qualification/port; its original ordinary shutdown/physical check/one owner/75s join behavior remains.

## Native Host reader and result contract

The old Host spawn/manual stream readers are replaced, rather than retained alongside run. `supervisedHostProcessFacade(occurrence,true).run` is the only child stdout/stderr consumer. The original onSpawned handle is captured first; its terminal, settled and outputSettled promises are observed immediately. onSpawned writes the actual original ready/birth plus deadlineAt/inactivityTimeoutMs/printLogs, actual Host execPath and Bun1.4.0 version. The timer begins after onSpawned as the existing run contract specifies; admission/preparation still relies on original execution controls.

On normal return or controlled error, the complete public result bytes are persisted as `evidence/native-host-stdout.bin` and `native-host-stderr.bin`, then forwarded once to Host stdout/stderr after run has finished consuming. Each parent write joins both its callback and required drain; even a final write returning true awaits its callback. Original PS CopyToAsync drains remain. No async void output callback or second stream consumer exists.

`native-host-run-error.json` records the first run rejection with complete error properties, nested cause/errors and byte-bearing results; object references/cycles, bigint, undefined and byte arrays have explicit diagnostic representations, not truncation. The original in-memory error identity is not replaced during joins. Original handle and parent-write failures are separately retained. Receipt publication retains both write and staging-cleanup failures.

Normal result, ProcessRunFailedError, and the public result on controlled errors have explicit byte sources. ProcessExecutionError retains its own observed bytes and original cause tree but does not claim complete output. Output-limit results also do not claim complete original output. Missing results are unknown rather than fabricated empty success. There is no maxOutputBytes override: the existing run default is Infinity for this bounded fixture.

Only fulfilled original terminal/settled/outputSettled, complete bytes, successful byte-file writes and complete parent forwards permit `native-host-settled.json`. A controlled inactivity result can have proven physical settlement while retaining original `runOutcome=rejected`, first typed error, terminal reason and Host exit1. The separate run-error file does not cause the old settlement reader to lose that proven fact. Incomplete observation/cleanup/output instead produces `native-host-error.json` with the full first and later causes and no completion claim. The Host uses natural exitCode, without force-exit/kill/restart after uncertainty. If an original producer remains live, the same namespace remains retained for Root's observation.

The original native Windows request protocol is unchanged: no extra native deadline/inactivity field is injected. Deadline and output inactivity control the one original facade handle. Actual INFO request logging may reset inactivity; normal15s Files polls are real output activity, so this is not a detector of semantic UI progress. Each API keeps its separate original finite request budget and the service keeps its900s cap.

## Two finite production Native timer inputs

`native-qualification-inputs.json` declares the exact executable/program, separate active/idle run roots,200ms inactivity,30s original execution cap and expectations. The real Node path was resolved read-only as `C:/Program Files/nodejs/node.exe`; pure syntax tooling reported Node v25.7.0 and Bun1.4.0. This is not execution of the new target.

One `qualify-native-activity.ps1` is used with two explicit case inputs, avoiding duplicate runners. `-Mode Prepare` exclusively creates only that case's new run/environment/evidence directories and an immutable prepared manifest; it starts no target. `-Mode Run` saves once-only admission before Start, uses the same new Native Host and original mature parent dual drains, preserves the actual parent join, verifies original ready/terminal/raw byte transport/Node execPath and sequence, observes exact Host/Target birth and saves its qualification result. Each case requires Root's separate execution decision; this report is preparation only.

- active: `-Case active -Mode Prepare`, then `-Case active -Mode Run`. Node emits the seven indexed original JSON lines at initial/75ms intervals through nominal450ms, then naturally exits. The checker requires full sequence, actual Node identity, monotonic time and final elapsed≥400ms, terminal exited/0 and Host/parent0.
- idle: corresponding `-Case idle` inputs. Node emits one original line then remains alive without further output. The checker requires ProcessInactivityTimeoutError, original inactivity_timeout receipt, complete raw one-line output and full Native physical/output/request joins. Positive expected-contract receipt may say passed, while original Host and parent script both remain exit1. It is never rewritten to0.

These are tool qualifications, not product/UI/Task or directory acceptance. Their tiny target writes are never copied into the service as synthetic activity. The idle target's keepalive interval emits nothing. Scheduler stalls/failure to acquire original ready or actual output gaps are retained failures; no tolerant retry, delay extension or replacement case is coded.

## Passive directory preparation order

Root chooses when to explicitly create the two passive empty paths `scratch/native-observer` and `scratch/native-observer/runtime` once. Both case preparation and the service fixture preparation only assert their direct physical identity. The original observer function still points TEST_HOME at its original home child, but no new requirement to precreate/read it was invented. The observer reads process occurrence through the original production module; it has no service/Task to take over.

Each case runtime remains exclusive, and the service runRoot/runtime remains separately exclusive. Existing passive directories are not a fallback to reusing a prior service. None of these directories was created during this tool preparation.

## Verification / changes / limits

Seven owner files passed pure syntax once, all exit0: Node --check on native-activity-target.mjs; Bun1.4 Transpiler parsing native-host.ts with no imports executed; PowerShell Parser.ParseFile on launch-ui, functions, shutdown, check-tool-syntax and qualify-native-activity. Original individual output/exit records and summary are in `tool-validation/syntax-20261013T175004113/`. This owner checks only its files; the fixture owner's tools require their own review/checks. No claimed ten-file result, TypeScript semantic check, timer run, Native calibration, service startup or UI qualification is inferred from syntax.

An initial apply_patch attempted delete/add of one path in a single patch and was rejected before mutation: `apply_patch verification failed: invalid patch: multiple operations target .../native-host.ts`. The saved original was preserved, then the exact scratch file was replaced using separate permitted patch operations. This is transcribed from the original tool output, not a fabricated validation log. No product or test was involved.

Root must read complete new Host, qualification source and all five diffs before executing either case. Then separately qualify actual timing and Native joins, prepare the source CLI fixture, bind original schema/IDs, launch one service and perform genuine desktop/API readback. Unknown producer settlement, process-API error branches, target filesystem I/O, before UI and every new directory feature remain untested. Capsule live-owner/recovery unknowns are unchanged and not excluded by these tools.
