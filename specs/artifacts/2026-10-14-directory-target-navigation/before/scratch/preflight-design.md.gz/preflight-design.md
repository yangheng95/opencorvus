# Directory target 前置资格与唯一 checker 设计（只读，未执行）

## Recall / 权限 / 当前结论

2026-10-14。用户持续批次迭代授权仍有效。Root 报告上一批 `5107ed64` 已完成正常 push0、fresh HEAD=origin/main；原 HEAD race128、首次远端并发拒绝1均保原记录，两个 UI 实例均收束。当前新批只授权本文件：读取 candidate、公共 schema、成熟 SDK（Software Development Kit，软件开发工具包）生成流程、旧链接报告，设计最小 Windows/Bun1.4 primitive 和 source CLI（Command-Line Interface，命令行接口）两 Project 前后复用 checker。Root 另补无活动预算审查。不得再委托、创建夹具、运行脚本/模块导入/服务/模型/API/UI、改产品/测试/spec/索引/Git。新 runRoot、port、prefix 未指定，本文不猜值、不占用实例。

开始 git status 已读：其它 owner 的 server/restart/permission/spec、design patch 与未跟踪文件保留；未以本报告授权它们。当前写入只有 ignored scratch 分析。检索遇到旧猜测路径不存在后已定位真实 `packages/overlay/src/services/file-workbench.ts`、`packages/opencorvus/src/shell/process-supervisor.ts`；一次扩大文件名定位遇到无关 ignored 路径访问错误，没有读取其内容或据此作全仓不存在结论。

核心结论：可把候选收敛为**现有条目事实之上的列表专用、必需 `directoryTarget` 字段**。不能把新 target stat 放进成功 mutation 回执；不能把 unknown I/O（Input/Output，输入输出）压成 false。旧证据不足以确认当前 Windows Bun Dirent 三谓词，应先做一个不启动产品的极小真实物理调查。预算方面：已有 output inactivity primitive 在 `ProcessFacade.run`，**不在 `spawn` 或 Native request schema**；现 `native-host.ts` 的 spawn 加同名字段不会取得该能力。可复用原 facade.run 单 owner，但需明确替换原手工 drain/ready/error 收尾；不是透传一行即可交付。

已读材料：

- `.tmp-codex-next-publication-01a133/next-batch-candidate.md` 全文，含已纠正“现 launcher 没有外部120s driver”的预算段。
- `.tmp-codex-file-link-01a133/audit-report.md`、调查脚本；旧14案例报告与现链接批 Recall/最终/92项测试/14图资格。历史反例是修前，不能当当前后端仍有这些错误。
- `specs/records/2026-10/2026-10-13-file-link-entry-contract.md`、`specs/current/architecture/07-panel.md:486–529`，现 File/index、routes/error、SDK schema、file-workbench、Explorer/TaskDirBar 消费者。
- `packages/sdk/js/script/build.ts`、`generation-transaction.ts`调用点、`packages/opencorvus/script/generate-openapi.ts`、根 `script/generate.ts`与 package scripts。
- 成熟本轮 `fixture-support.mjs`、`register-projects.mjs`、`ui-readback.mjs`、`launch-ui.ps1`、`native-host.ts`；只读原工具，没有运行旧 occurrence。
- Root 补预算后完整读 `C:/Users/hengu/.codex/skills/benchmark-debug-template/SKILL.md`，其明确要求“测试超时必须是无活动后的真实超时”；本文区分执行 cap 与 inactivity，不将技能示例中的 UI 自动化/像素指标用于本仓禁止的 UI 测试。

## 1. 当前公共事实与生产调用证据

`packages/opencorvus/src/file/index.ts:42–53` 的 File.Node 必需五字段：name/path/absolute/type/ignored。type 是 entry 的 `file | directory`；不是可浏览、可读、可写能力。`nodeForEntry:1185–1197` 是单一投影；`nodeForPath:1199–1205` 从 lstat 取得 entry 后加载原 ignore matcher。create:1373、move:1409、copy:1495 在成功发布后调用它。`File.list:1640–1664` 从 readdir Dirent 得 entry 并调用同投影，忽略 matcher 一批一次。内容 API 仍使用 realpath/真实内容读取，独立于 entry 成功。

全仓生产 `File.list(` 仅 `src/server/routes/file.ts:113` 和 `src/cli/cmd/debug/file.ts:64`；GET `/file` 的200当前是 `resolver(File.Node.array())`，query.path 必需，实际失败经过 serverErrorResponse；route尚未声明实际500。GET `/file/content` 则明确404 FileNotFoundError、500 UnknownError，不能把它的错误合同挪到 directory list。SDK 当前 `FileListResponses` 为 `Array<FileNode>`，create/move/copy也引用 FileNode。

`packages/overlay/src/services/file-workbench.ts:9–15` 手写 FileNode，`:391` loadFileDirectory 返回其数组；`:415` create、move/copy均保持 entry 类型。可以在本次正式实现只将涉及的 Node/ListingNode 变成原生成 SDK 类型 alias，不能复制第二份 target schema，也不需顺手重写所有 Upload/Move 接口。

Explorer 的 current directory Map 是唯一列表事实来源：childrenByPath:354；rows/展开、选择协调:736–775、目录目标:844、drop、move刷新:1097 后会受新字段影响。TaskDirBar只使用列表成员数量。search返回字符串列表，当前 search row 是file；本次不为每行补metadata、不改 ripgrep follow/搜索owner。mutation selection 仍从真实 entry receipt建立，不缓存/补猜 directoryTarget。随后 required list loaded/failed/retired 仍提供独立目标事实与刷新结果。

建议正式公开名：`File.ListingNode` / meta ref `FileListingNode`，从 File.Node.extend 必需 `directoryTarget: z.boolean()`并给新独立ref；仅 File.list/GET200使用。字段定义为“本次列表读取确定此逻辑条目/其目标在当前 File authority 内为目录”，**不称 readable、writable、resolved、isDirectory 或 type**。普通实体目录true，普通文件/其它非链接entry false，允许的健康目录link true，已知非目录/missing/越域link false。它不承诺以后能readdir、ACL（Access Control List，访问控制列表）许可、内容/写入成功或目标不变。

原 type/ignored/逻辑path不变。目录导航与 New/Upload/drop 目的地使用列表字段；递归 copy、自目录保护、source根保护与entry选择身份仍用entry type。选择/anchor/drop的后代可见性应随成功列表 target=false退休，但link本体不因target变化改type或换row identity。move展开路径映射保原entry结果，已展开link需按现expanded意图读新逻辑目录；不能从缺target的mutationreceipt填false或用type兜底。

## 2. 极小真实 primitive 前检（仅设计）

待 Root 指定全新直接物理 runRoot/prefix 后，使用其明确 Bun1.4 executable，保存 `process.execPath/process.versions.bun/platform/arch`、真实 cwd、输入预算/原stdout/stderr/exit。不能以 Node 文档、编译通过或旧 lstat 结果替代此次 Bun Dirent 实测。只用 `node:fs/promises`/path，完全不 import 产品初始化模块。

同一个新 owned namespace 内 A/B 两个直接目录可先准备物理图，之后正常 init 成各自独立 Git 项目；不能先把 B 放进 A worktree，否则不是外域反例。预声明3个完整短 UTF-8/CRLF marker（A file、A target/资料 Mix marker、B marker），期望 bytes 由输入字面量产生并保原Base64，不从读回结果重算“期望”。初始身份保存 bigint dev/ino 字符串、birthtimeNs、mode/size；readlink原文字与 realpath 为不同字段，不归一后覆盖原值。

最小10个分类输入（可同用少量真实target，不增加大树）：

| 输入条目 | entry事实 | target期望 / 资格目的 |
| --- | --- | --- |
| A ordinary-dir（含Unicode/空格子名） | 实体directory | directory / 基线 |
| A ordinary-file.txt | 实体file | file / 基线 |
| A junction-dir | symlink(junction) | A内directory / Windows关键谓词 |
| A absolute-dir-link | 真dir symlink | A内directory / 与junction区分记录 |
| A relative-dir-link | 真dir symlink，原相对文字 | A内directory / 不改写readlink |
| A file-link | file symlink | A内file / 导航false |
| A broken-dir-link | dir symlink | 已声明A内missing / 原错误code |
| A broken-junction | junction | 已声明A内missing / Windows broken资格 |
| A external-dir-link | symlink | 指向 owned B目录 / domain基线 |
| A root-link | symlink/junction | A root / 只一层，不递归跟随 |

检查严格有界：一次 A root readdir({withFileTypes:true})取得所有对应 Dirent；对每个预声明路径各做一次 lstat、stat、realpath；仅声明的link做一次 readlink；三marker各完整readFile。分别记录 Dirent.isSymbolicLink/isFile/isDirectory 和 lstat/stat三个谓词、每个调用的成功值或完整 name/code/errno/syscall/path/message。broken的stat与realpath分别独立保存失败，不能因为前一个throw跳过后一个。除三字节文件与一层readdir，不做递归扫描、权限提升、fs.access“可读”猜测、NTFS私有类型解析或创建循环链接。

候选classifier只有在 **本次 Dirent三谓词与显式创建entry图及lstat实际事实一致** 后才有实施资格，尤其junction/true dir symlink。调查先保存所有原结果再作资格比较，失败保存不丢弃，不把创建symlink EPERM改成“平台跳过通过”；没有真symlink权限就明确该case未取得。若Dirent不足以辨别，回到正式方案统一选择lstat策略、评估新增I/O；不同时留Dirent猜测与lstatfallback。当前这些谓词未执行，不能在本文填入假结果。

## 3. 已知 false、未知错误及新增列表500

唯一既有 known-missing predicate `isMissingPathError:501`只接受 `ENOENT | ENOTDIR`；`realpathIfExists:510`只消化这两类，其余原throw；`canonicalPath:526`沿最近真实父补词法后缀；`isPathAllowed:548`覆盖 Instance.directory 和 Instance.worktree 两真实根。新resolver应复用这些单一authority primitive，不配置第二roots。

- allowed=true不是target存在证明，broken canonical父可仍允许；要通过实际target stat确认。已知missing→false；真实regular target→false；真实权限域比较false→false。原entry继续存在并可有合法move/copy/delete结果。
- EACCES/EPERM/EIO/ELOOP、未知realpath/stat失败不能当false、missing或ignored=false。不匹配英文message，不catch-all吞错，不返回半张“成功列表”。目录整体原error→500 UnknownError及request ID是明确新的读影响。
- 普通实体dir按原entrytrue可免额外stat；普通非link false。link需目标authority/目录判断。这只是计划，必须先通过上述Dirent资格。现unknown I/O未有安全可重复Windows条件，不能凭mkdir .ignore故障证明target resolver失败；.ignore EISDIR是另外已有loader路径。
- 新读若失败，原mutation.completed/member error保持，由已有required目录collector记独立failed或retired，不覆盖真实完成数；scope/token/authority/selectionEpoch以及upload/mutation独立owner不改。
- target检查与随后的操作并非原子，realpath/stat之间也可能被外部替换。稳定夹具不能证明 race 消除；后续API仍重新按现authority检查。不给UI新授权、不引入target身份缓存/alias editor cache/队列。
- 普通直接list(link)当前missing/regular/outside可能500，不擅改typed404/400；将触及GET/file补实际500 schema是声明已有错误，并不意味着已覆盖所有新target错误。

## 4. source CLI 两 Project 的唯一 checker 输入/输出

Root 先定新run、port、prefix、私有Bun/UI binding；修前与修后必须不同 occurrence、新Project IDs与原Native input，不能重启旧run或转用已有UI实例。采用当前成熟 source CLI `/ui`，不用独立 Vite。正常 `/project/current?directory=<exact A/B>`取得真实Project；正常POST `/coding/chat/session`空body取得各自empty Chat，保HTTP全字节/header/requestID/真实ID。无SQL、模型、凭据/catalog复制或合成消息。

一个 checker 实现读取**预声明请求计划**和fixture manifest，前/后只更换显式输入合同，不根据实际响应猜profile。建议输入字段：

- fixtureID、occurrence、原Host/Target PID（Process Identifier，进程标识符）/birth、runRoot、port、deadlineAt、scope A/B真实directory与Project IDs；必须与原inputs/ready/registration对应。
- phase（before/after，输入显式选择）与有序steps：label、role、method、route、query/body、expectedStatus、expectedBody或明确字段合同、declared physical observations。
- bytesMap：预声明完整marker/新建/上传正文；entryGraph：各logical path、link类型及原link文字、declaredtarget；原identity来自prepare时真实lstat。不能由调用当前产品resolver生成expected directoryTarget。
- before期望是现已公开的五字段Node与实际直接list/content结果；after成功listing必须是六字段ListingNode，directoryTarget每项必有且为预声明bool。使用同一个比较算法与不同显式expected数据，**不**做缺字段兼容、不自动probe协议、不把旧field缺失当新合同成功。
- 非稳定字段如requestID/revision只做实际格式/存在资格并完整记录；revision不能用可变源码hash或自行重算当功能门槛。文件完整bytes与entry dev/ino/birth/readlink对应才证明对象内容/身份。

最小修前API步骤：A/B各root列表、A三种健康目录link各一层list+marker content、filelink content、broken child明确404、A外域直接list真实错误、B自身目录list/content。先用纯GET绑定“旧UI不能展开”与“当前后端能明确列目录”的事实；Root真实页面点击/菜单与截图另做，不读DOM或断言文案。

后态同一checker的明确计划可读取：完整A/Broot六字段；三健康alias目录list/content；newfile/picker upload/普通entry copy或move到alias之后预声明bytes及物理落点；已展开link rename/move前后原readlink/identity、child新logical内容与真实mutationreceipt；broken合法entry动作和独立内容404；root-link仅一层marker；跨A/B同名entries和各自ignore规则。每个API动作与expected均在Root审读计划内。

真实桌面动作后的checker只GET/物理读回，**不重放mutation**。需要在修前调查 `link -> link/moved-link` 及另一个alias指向同target的危险路径时，另以同请求执行器的显式有限mutation steps单独执行一次：保存一次性admission和原PATCH正文，异常响应也先物理读原entry/最终实体位置，再报告；不能自动retry、改为期望500通过或扩大UI尝试。当前仅有控制流风险，尚未证明这种操作的最终路径/回执结果，正式实现前应由Root有限调查。

所有响应即使非JSON也保原bytes+parseError；原错误保存name/code/status/data及requestID，不关键字匹配。请求预算复用 `min(20_000, 原deadline-Date.now())`，超时/失败原样记录，不能延后原执行deadline。A/B可并发只读，但每个结果绑定原scope、全steps输入顺序与原response；不借全局lastProject。

输出：one receipt含原输入与有序HTTP raw、physical facts、明确每项实际输出/错误、实际exit；不写UI/模型E2E通过。Root另关联真实截图/人工视觉复核、普通shutdown200、原Native terminal/physical/output/request、Host/Target birth与port及原parent join。未知platform/ACL/late replacement/search follow/Task-Capsule共享恢复原样待验。

## 5. 成熟 SDK 流程与后续聚焦验证（均未运行）

现生成唯一入口 `packages/sdk/js/package.json` build → `bun ./script/build.ts`。build.ts:236运行 `bun --conditions=source ./script/generate-openapi.ts`（cwd opencorvus）；后者独立test runtime内加载真实routes生成OpenAPI并finally回收。build.ts:240用已锁定 `@hey-api/openapi-ts 0.97.3`生成types/sdk/fetch；:296起在 `.tmp-sdk-build`复制现src、写schema、生成、执行既有SSE收尾修正与format、flat-body校验、tsc；成功后 `replaceGeneratedArtifactsAfterSuccessfulBuild`一次发布gen/dist/defaults/route-policy/platform-tool-ids/openapi。没有理由手改generated FileListingNode或保optional字段。

root `script/generate.ts`还会生成专家团payload/revisions/templates及全部API文档，超出此File schema范围。正式实施应先保存/审当前foreign generated差异，使用精确SDK入口而非顺手全树generate。候选的推荐命令（待授权执行）是repo cwd、Bun1.4 PATH下 `bun run --cwd packages/sdk/js build`；随后必要类型与现API docs renderer/check，不宣称本次已成功。

纯正向合同重点：完整ListingNode真/假值与原entry不变；真实GET child完整bytes；broken/retargetfile/retargetdir后真实success与404/200；twoProject规则与authority；root/noReplace公开400/409；新target未知I/O500只有取得真实条件后才纳入。继承旧 `file-link-entry-contract.test.ts`、`file-mutation-root-contract.test.ts`、`file-ignore-coordinate-contract.test.ts`、file-read identity的相应触及用例，不把旧partial assertion通过当新增字段已证。当前link testcase http.list用toMatchObject/arrayContaining，所以允许附加字段；mutation exact回执保持旧正确entry。新字段有专门完整正向输出验收，不写源码文案/DOM（Document Object Model，文档对象模型）测试。

精确后端运行入口是 `bun run --cwd packages/opencorvus test <精确测试文件...>`（package → script/run-tests.ts），非全量bun test；Overlay已有服务test使用 `bun run --cwd packages/overlay script/run-unit-tests.ts test/file-workbench-mutation.test.ts test/file-workbench-refresh.test.ts`。后一类host transport模拟/collector promise只证明局部service合同，不证明真实API/页面。当前没有执行这些命令，也没有新增测试。

## 6. Root 补充：同原 handle 的无活动预算审查

### 真实定义、入口与缺口

`packages/util/src/process.ts:91–105` ProcessSpawnRequest只有signal/deadlineAt等，**没有 inactivityTimeoutMs**；:133–144 ProcessRunRequest 扩展后才有该字段和onStdout/onStderr/onSpawned。`createProcessFacade:735–762` spawn只admission/controlled handle，run唯一进入runProcess:535。现scratch native-host:39使用 `supervisedHostProcessFacade(occurrence,true).spawn`、手工双stream drain；没有120sdriver、没有既有inactivitytimer。不能把unknown字段塞spawn称生效。

supervisedProcessFacade 位于 `src/util/process-facade.ts:30–127`，Host/Task均同createProcessFacade；owned_tree转ProcessSupervisor.spawnHostCommand/spawnTaskCommand，terminal/outputSettled/handle.settled join，terminate/dispose严格disposeAndWaitForExit。现Native `DurableWindowsRequest`（shell/process-supervisor.ts:742–787）严格字段集合，Rust LaunchRequest（native/process-supervisor/src/main.rs:82）仅command/owner/birth/request/ready/cancel/settled等，**没有inactivity或deadline字段**。不能追加Native私有field，当前请求解析也会拒绝意外字段。

共性入口已追：Supervisor Host Shell/Host Gated Shell/Host Command只物理spawn+track；Task Shell/Task Gated Shell/Task Command在readLease/resolveTaskExecution/三catch路径，未实现输出inactivity；Task facade.run或Shell command-inactivity上层才有run计时。`src/util/process.ts` runRequest透传inactivity，spawnHost不透传；`shell/command-inactivity.ts` Host/Task两个公开wrapper共用facade.run，Overlay与后端runner等已有caller。Task/Session cancellation-scope其它同名durable-activity等待是另一语义，不可借用。Capsule准备还在原Task三catch/lease未知边界，run的inactivity从spawn返回后才开始，**不解决卡住准备、原starts owner或crash恢复**。

### 唯一成熟计时语义

runProcess:535先facade.spawn（deadlineFrom保原absolute deadline，若另有timeout取min）；:589先await onSpawned；:594启inactivity；:595两collectOutput是唯一reader。每个原stdout/stderr chunk触发refreshInactivity(:548–554)，stdin真实write也可刷新。当前默认maxOutputBytes=Infinity，完整原bytes保留；计时与真实目标输出绑定，不监听dev.log文件大小、不把checker requests或observer轮询合成活动。

期限到时原handle.terminate("inactivity_timeout")，同Native树收尾；result/errors明确保reason，`ProcessInactivityTimeoutError.result`含原receipt/full bytes。run等待handle.settled+两output，finally取消timer并await原dispose；unknown cleanup包装ProcessExecutionError与原cause，不能因为caller已有限返回就宣称physical结算。onSpawned还未结束时inactivity未启，但原absolute900000已作用；该区别必须保。

可行最小工具改变是**将现Host的spawn+手动consume替换成同facade.run一次调用**，原occurrence、deadlineAt、foreground=true不变，加唯一inactivityTimeoutMs:120000，使用既有onSpawned生成原ready/birth事实。不新增outer driver/第二counter/后台echo。必须同步删除旧manual stream readers，不能两人消费同stream。

但这需要Root另审工具设计，不是当前可直接执行版本：run callbacks类型是同步void，collectOutput不会await返回Promise；不可把现 `async drain` 原样塞onStdout后声称backpressure已经join。完整bytes应由run唯一收齐，使用返回result或typed error.result/ProcessExecutionError原bytes落盘，并明确join本Host→parent写出；若要同步旁路显示原chunk只能作为原输出转发、不能再建timer，且最后parent flush/错误必须收齐。现高层runHostCommandWithInactivity固定owner='inactivity-command'、foreground=false，未暴露onSpawned；不能直接换该wrapper丢本批原occurrence/foreground/ready合同。建议使用原supervisedHostProcessFacade(occurrence,true).run而不是新增wrapper。

### print-logs 真实活动与资格限制

source `index.ts:51–70`现有 `--print-logs`，Log.init的print来自原argv；`util/log.ts:126–143`在同pino owner上以multistream写原dev.log和stderr。`server/server.ts:818–856`记录真实request开始/完成/失败，含原requestID/method/path/status，/log路径明确跳过。因此 `--log-level INFO --print-logs`可把真实Files/API活动变为原Native stderr字节，不需要host伪造heartbeat。

但输出活动不是功能进展：Explorer:564–580现每15s真实poll active scope root/expanded dirs，即使用户不操作也可能产生日志；同服务其它后台真实日志也会reset run的inactivity。global event heartbeat:1222每10s写的是SSE网络stream，代码没有每次log，因此不能把网络heartbeat当stderr活动。悬挂某请求时别的poll继续成功，inactivity不会证明该动作有进展；此候选依靠独立有限HTTP请求预算、功能checker与原absolute900s cap，不得宣称120s就能判任意UI/Task卡死。

未来资格需原ready输入明确inactivity120000+absolute deadline，实际source CLI argv含print-logs；原HTTP requestID在对应stdout/stderr真实pino记录中可关联，正常shutdown后原run结果/两输出/fullraw/Native request/birth/parent join完整。仅静态字段、日志文件存在或之前不含print-logs的运行不能宣称已满足。不能为了续命发额外请求/打印tick；自然真实服务活动即可。`command-inactivity-settlement.test.ts`已有真实output-active native deadline+并行peer与output-observer failure局部契约，并有factory模拟late-output条目；已读未运行，它们不等价于本次source CLI print-logs120s实机资格。

900000是原execution cap，120000是输出无活动时长，两者不同事实。startup45s/shutdown45s/otherjoin75s是成熟工具观察界限，不改写、reset或延长执行input。当前无新增进程，任何newrun实际输入与收尾均未取得。

### Root 最终收敛提案复核：run独占读，结算后完整转发

Root 后续明确的设计可行：新namespace中用**同一个** `supervisedHostProcessFacade(occurrence,true).run({deadlineAt:原900k绝对期限,inactivityTimeoutMs:120000,onSpawned,...})`。onSpawned首先保存原handle引用、立即观察其terminal/settled/outputSettled原promise，再执行当前ready/birth事实写入。返回后仅run读取两流，既不设置void onStdout异步写，也不保留手动drain。onSpawned的短暂I/O发生在run inactivity启用前，其错误仍会进入run cleanup；不能称这段也受120s无活动计时，原900k持续有效。

run完成或reject后才把其完整原stdout/stderr bytes写到Host对应输出，父PS仍用原双CopyToAsync完整落盘。转发是同一原输出的运输，不是新的进程活动事实。两个目的stream各自backpressure write/once drain，最后一次write也必须等待真实write callback/flush完成，不能只在write=false时等待而随即process.exit；保存bytes落盘失败和父pipe失败原cause，不截断、trim、重新编码原Uint8Array。可以一次传一份完整bytes再等待完成，避免新增chunk队列或第二reader。原成熟PS父输出join保持。

结果提取必须按现错误类型完整保留，不能只读error.message：

| run实际结局 | 权威bytes/receipt |
| --- | --- |
| 正常返回，包括nothrow=true时原非零exit | result.stdout/stderr/receipt |
| ProcessAbortedError / ProcessDeadlineExceededError（可能尚无result） | 有result才从其完整字段取；无result必须记录未取得，不能造空结果代表成功 |
| ProcessInactivityTimeoutError / ProcessOutputLimitError / ProcessOutputObserverError | error.result原receipt和bytes；Observer另保原cause |
| ProcessRunFailedError | 自身stdout/stderr/receipt（无result对象） |
| ProcessExecutionError | 自身stdout/stderr是run本轮已观察完整前缀，stage和cause树原样保；若cause含控制error.result仍保两者来源，不能挑一个“较好结果”替换第一异常 |
| spawn/admission前失败、unknown thrown value | 原类型/值与原完整cause；没有捕获handle不宣称有Target或cleanup资格 |

`runProcess:651–666`的finally若dispose失败会包ProcessExecutionError，cause保primary和cleanup；它没有证明两者都成功。Host应在catch立刻记最初run异常（即公开run返回的原对象/cause树），然后对已捕获的**原**handle terminal/settled/outputSettled与两输出转发各allSettled，逐个保原结果/error，再生成最终观察。不能让Host finally throw第二错误覆盖最初错误，不能以write成功或ProcessSettlementUncertainError有限返回把physical=true。原settled若rejected，后来OS dead/birth事实也作为后续观察独立保留，不重写原run错误；原Native request/marker全证据仍由原owner收尾取证。这里不增加retry、dispose旁路或pending poll替代join。

`controlledHandle:386–469`把原terminal转换为第一次requestedReason/原control reason，原dispose在terminal已结算后不重写其既有exited值；inactivity先调用terminate("inactivity_timeout")时该reason保留。因此正常后调用原settled与outputSettled是观察同一权柄，不再读流或重新发控制。900k原control lease仍在spawn阶段建立，输出inactivity仅后续调用同handle的terminate，两者不是两套原生Job。

可选先做Root提议的两个**纯工具**生产NativeFacade资格case（未创建/未运行；各用原独立occurrence和有限execution cap，Node executable由准备时真实路径绑定）：

1. 持续输出case：真实Node在0/80/160/240/320/400ms输出预声明的有序短行，450ms输出done后自然结束；run inactivity200ms。正向核完整有序bytes、原receipt exited/0、原Host/Target birth与完整physical/output/request/parentjoin。首尾实际观测跨度应大于200ms且真实输出活动间隔小于200ms；计时延迟/机器饥饿导致实际gap过大时保失败，不宽松接受。它证明有真实后续输出时没有从启动机械到200ms截止，不证明服务业务进展。
2. idle case：真实Node只输出预声明one-line后保持alive；run inactivity200ms，原independent absolute cap应足够区分这200ms路径。正向核原ProcessInactivityTimeoutError.result.receipt.reason=inactivity_timeout、完整one-line字节、原handle结算、Native request清理与父输出join；不能用工具wall-time“约200ms”替代typed原reason，OS调度只影响精确延迟。

这两个case是明确授权后工具资格用的真实子进程输出，不得把其tick移植成CLI假ping或继续运行的heartbeat。使用同生产Native facade、foreground=true、原onSpawned与run reader；不mock handle、Task、metadata，不跑UI自动化。已有foreground-process-facade正向合同证明run路径已在生产Native wrapper使用，但本次新namespace/200ms及print-logs交互仍需真实执行才能取得资格。

## 7. 未覆盖与交付边界

没有创建primitive fixture、没有运行Bun/脚本/模块导入/API/服务/UI/model、没有改产品或生成SDK。Dirent具体三谓词、source-through-self物理/回执、Windows可重复unknown target I/O、新列表target字段与UI交互、真实120s source CLI输出计时均未取得；本文只给可执行的后续输入和明确资格，不是假验收。

保持原已知边界：POSIX/macOS/UNC/网络盘、多卷、ACL、并发外部retarget/删除、search link target枚举、同scope晚读/上传逆序、Task/Mission/Session/Capsule live preparation与重启恢复未由此候选排除。没有用此前普通成功实例或scope静态分析降级共享机制问题。

下一步由Root完整分析并正式落spec，指定唯一newrun/port，审读准备工具及上面run所有者替换后再授权有限真实前检/页面。不是向用户再索要自动迭代授权；当前只是Root已经划定的实现/运行先后顺序。
