# 健康目录link：搬迁准入、目标坐标与可寻址回执审计

## Recall、资格与结论

2026-10-14，root确认上一批5107ed64正常同步/完整hooks/push0、fresh HEAD与origin/main相同，另启一层只读健康目录link调查。本agent只负责未取得实证的terminal source link经自身或另一alias到达同target目录的Move、relative relocation、权限/root/Node回执/required刷新影响。禁止再次委托、任何fixture/API/服务/模型/UI/产品测试运行，禁止产品/正式spec/共享索引/Git动作。本报告是唯一scratch写入；没有启动或访问任何实例，源码推导不能代替真实Windows结果。

已完整读当前File/index的canonicalPath/isPathAllowed/准入/relocation/Move/copy/Node producer，Filesystem.exists/renameNoReplace包装，完整native rename-no-replace.ts，HTTP Move与error-handler、File.read/list、workbench admission/commit/descendantSuffix、Explorer applyMoveResults/expanded/target guard；重读root保护、ignore坐标、link entry/outcome历史Recall/最终和07-panel。相关已运行测试的代码/正式原记录已查；本轮不执行它们，也不调用Git验证root给出的提交事实。

**两个必须分开的待实测点：**

1. destination父路径经被移动source entry到达实体目录，native Move若发布，旧source路径可能随移动消失，使同raw targetFull无法lstat，形成“物理已移动、回执404”的候选。独立alias到同实体目录可能仍可寻址，不能以realpath相同就拒绝。
2. relative readlink含`..`且destination parent是alias时，当前relocation先按词法parent做path.resolve，再权限检查；它可能检查A内坐标，而实际native link按实体新parent解释后指向B。此候选比单纯icon/type更深，但尚没有本轮运行证据，不能预先判已越权或加gate。

正确entry.type=file、link原文字/native Move、本体root区分继续保留。建议root正式计划先做下述两真实Project、最多7个Move的owned小调查；实际证据后再决定需要修数据准入还是仅目录浏览。不得先把terminal link当递归实体目录。

## 当前准入、发布与回执逐段事实

| 当前源码 | 精确合同及本题影响 |
| --- | --- |
| File/index:526–553 canonicalPath/isPathAllowed | 先path.resolve；完整realpath成功则用实体坐标，knownmissing才向上找存在parent并拼剩余suffix；仅ENOENT/ENOTDIR可missing，未知I/O传播。canonical仅权限比较用Windows lowercase。允许实体directory或worktree两根，不以ProjectID字符串代替directory scope |
| assertAllowedFilePath:1119–1132 | raw空/absolute/null的原准入，随后现physical permission；错误为FileInvalidPathError400 |
| assertExistingParent:1134–1149 | target父真实allowed与followedstat.isDirectory；knownmissing→原400，其它throw。它只证明rename前父目录可到达，没有证明rename后raw路径寿命 |
| assertFileMutationPaths:1151–1182 | raw空root错误与targetbasename/sourceallowed/targetallowed/parent顺序保持；两词法根先拒绝；精确lstat源，terminal symlink直接返回其entry；非link再比两实体根。终端root-link不是实体根，不可把followed realpath相同当root源 |
| Filesystem.exists:57–63 | access成功true、任意失败false的现advisory检查；Move真正no-overwrite由native一项原子rename提供。不要将exists=false单独当permission/entry missing证明或扩改这个通用helper |
| assertRelocatedSymlinkTargetsAllowed:1208–1249 | lstat/readlink逐entry；terminal link不follow递归。sourceTarget与relocatedTarget都先按**词法parent**path.resolve(linkText)，各走现isPathAllowed。实体目录只遍历其实际目录树里的link entries。不会要求declared target存在，允许in-scope missing |
| move:1376–1411 | targetexisting→409，relocation后唯一renameNoReplace(sourceFull,targetFull)，只有EEXIST映射409；其它native错误原样throw。rename成功后notifyEdited、再nodeForPath(targetFull)。没有rollback或physical target重映射 |
| nodeForPath:1199–1205 | 精确raw targetFull的lstat，knownmissing→该scope-relativepath FileNotFoundError404；未知lstat/ignore loader错误传播。metadata不会另用physical destination探测成功，不follow终端target |
| nodeForEntry:1185–1197 | 公开name/path/absolute为raw词法entry；type与ignored目录hint由entry.isDirectory，terminallink为file。没有“target目录”字段，也没有内容可读承诺 |

MoveResult.previousPath/path当前原样保输入source/newPath；其node.path是path.relative(Instance.directory,targetFull)。dot aliases先由path.join归约，不能用修改raw previousPath或canonical终端target来掩盖不完整回执。三个Node producer只有create/move/copy；list复用同entry projection、ignore批次一次。

## 原生rename与平台边界

完整 `util/rename-no-replace.ts` 已读：Windows Move用Bun FFI（Foreign Function Interface，外部函数接口）直接`MoveFileExW(source,target,flags=0)`，GetLastError映射Node errno；没有REPLACE_EXISTING、COPY_ALLOWED、WRITE_THROUGH或两次publication。它不同于另一replaceWindows的CreateFileW/handle实现。File Move不调用contention retry、普通fs.rename或replace fallback；也不在此固定父目录handle。

Darwin为renamex_np排他flag，Linux为renameat2(RENAME_NOREPLACE)，unsupported平台明确throw。此源码不证明Windows在“source link是target ancestor”时一定rename成功或一定拒绝；可能原生rejected而原source保留，也可能完成后raw路径不可再寻址，必须实测原errno与实体状态。

[Microsoft MoveFileExW官方](https://learn.microsoft.com/en-us/windows/win32/api/winbase/nf-winbase-movefileexw)支持按flags移动、失败取GetLastError；COPY_ALLOWED可改成跨卷copy/delete，但当前flags0没有这个行为。该文档没有为本题junction/source-dependent destination保证特定结果。[Node symlink官方](https://nodejs.org/api/fs.html#fspromisessymlinktarget-path-type)说明Windowsjunction绝对目录目标和relative目标按link parent解释；[lstat官方](https://nodejs.org/api/fs.html#fspromiseslstatpath-options)区分entry与target。已先核仓库Bun1.4实际旧记录，再读官方；文档不代替新NTFS（New Technology File System，Windows文件系统）真实结果。

## 三种destination身份不能混为一类

以下`A`为scope/worktree真实Project A根，`D=A/targets/data`是真目录；每case有独立source/target basename，不能Move重放。

### 直接依赖source的父路径

source=`A/self-link`，readlink绝对`D`；newPath=`self-link/moved-entry`。rename前：sourceFull的lstat是link，destinationparent self-link的stat是真D，现两root permission与relocation均可成立。若native完成，实际新entry可能位于`D/moved-entry`，但old `A/self-link`已退休；`A/self-link/moved-entry`因ancestor缺失可能404。**这个“若”尚未实际证明**，不能仅看native调用名字断定发布。

如果source target是A实体根，该独立root-link本体仍是合法可搬entry；同样路径寿命候选成立，实体根/marker应始终独立测身份。root guard并不是禁止link指向root，此正确合同已有实证，不能为修回执而倒改。

### 另一独立alias到相同D

source=`A/independent/source-link -> D`，另一`A/independent/other-link -> D`；newPath=`independent/other-link/moved-entry`。other-link不依赖source.entry而存在；搬source不应自动使other-link消失。该目标与source.followedtarget实体相同，但destinationpublicpath可能始终有效，应该作为合法正向对照。不能把`realpath(sourceFull)===realpath(targetParent)`当“移动进自身”一律挡住：它比较的是target目录，不是两个link entries或路径依赖。

### 另一alias仍间接依赖source

source=`A/dependent/source-link -> D`；other-link是relative真dir symlink，原readlink=`source-link`，newPath=`dependent/other-link/moved-entry`。词法destination不以sourceFull为前缀，但other-link的解析要经过source.entry；source退休后它可能也dangling。简单lexical descendant检查不能证明所有case覆盖；canonicalPath只返回最终实体坐标，也不提供link-hop依赖链。旧14案例/当前测试未覆盖此链。

因此不能现在承诺仅加`isPathOrDescendant`就已完整修复，也不宜写自造NTFS解析器。若实际出现published/unaddressable，正式方案必须定义“success的新logicalentry可寻址”完整数据合同，并分别证明直接/独立/间接边界。

## relative relocation的实体parent候选

严格bound的两Project例子，仅代码推导，尚未创建：

```text
R/                                新owned runRoot
  managed/project-a/              A，真实独立Git/Project
    b-target/marker.txt            A自己的原target、A字节
    from/deep/source-link          relative dir symlink text="../../b-target"
    to/deep/                       同实体深度normal对照目的地
    aliases/root-back              junction -> A
  b-target/                       B，另真实独立Git/Project
    marker.txt                    B独立字节
```

原source实际parent是`A/from/deep`，`../../b-target`解析到`A/b-target`，healthy/in-scope。请求将它移到`aliases/root-back/moved-relative`：

1. rename前newPath完整坐标不存在，canonicalPath沿实际存在root-back parent重建为`A/moved-relative`，target/parent权限可成立。
2. 当前relocation使用词法`A/aliases/root-back`，`path.resolve(parent,"../../b-target")`得`A/b-target`，可能通过A内权限。
3. native新entry如果实际位于`A/moved-relative`，其relative readlink parent是实体A，同原文字可能解析到`R/b-target`即B。raw `aliases/root-back/moved-relative`仍可lstat为entry，Node可能200；内容/子目录权限随后另校验。

这个例子不向用户项目或runRoot外写入：A、B、所有alias、理论新target全部在新R内，B只是本API scope的outside root。它不能证明目前已跨项目暴露内容：**当前File.read与File.list会重新isPathAllowed，对跨两权限根的实体deny。** 更精确地，它是“relocation准入的declared未来目标计算可能与实际relative目标不一致”的候选，原读权限不是因此被排除。

普通对照同readlink移到`to/deep/moved-relative`仍指`A/b-target`；两个物理根marker字节要同时保留。junction的绝对readlink不用这个relative例子替代，file/dir symlink的原文保留与copy sharedpreflight也受该坐标选择影响，不能只修Move一个调用形成双源。

若实际确认此差异，成熟候选是**仅为declared-target权限计算解析entry的实体parent**：源link用真实parent+原readlink；destination先由实际已存在top parent的realpath和未来entry/tree suffix得到将来实体parent，再解析原readlink。terminal full entry仍保原词法Node/Git身份，不canonical成target；missing in-scope仍可用现isPathAllowed判断，未知parent I/O仍error。实体目录整体copy/move中的未发布nested parents不能直接realpath不存在位置，需要以已验证top parent+现遍历tree suffix计算；不改成只处理terminal link、漏整树成员。

此为待证实现方向，不是已授权改动。parent snapshot不保证外部并发retarget的原子性，也不解决source-dependent destination路径寿命；后者必须独立处理。

## 公开status与实体终态必须分别保存

| 原路径阶段 | 当前源码公开合同 | 核实体的必要事实 |
| --- | --- | --- |
| typed source/target/root/parent/relocation准入 | FileInvalidPathError400，source/path/精确message | 原source entry/readlink/dev/inode与全部target bytes保持 |
| source缺失 | FileNotFoundError404 | 明确原entry missing；不能由content targetmissing猜source不存在 |
| noReplace原EEXIST | FileConflictError409 | 原source及已有destination各entry/bytes |
| 其它native errno | UnknownError500 +原log/requestID | 可能原生未发布，必须source/newphysicaltarget观察确认，不以500直接判失败回滚 |
| rename后nodeForPath knownmissing | FileNotFoundError404，scope-relativetarget路径 | 是否另一个可达physicaldestination保原sourceinode/readlink；原target markers完整 |
| metadata未知lstat/ignore读错 | UnknownError500 | 是否已发布分开记录，禁止失败吞成Node或ignored=false |
| File.read / File.list scope deny | 当前genericError→UnknownError500 | 新link实际target已越scope时，不能误写成mutation的typed400 |
| File.read真实target missing/非regularfile | FileNotFoundError404 | entry可能存在且mutation成功；target独立状态 |

最新精确核对`File.read:1018–1030`：isPathAllowed(full/physical)失败抛genericError，serverErrorResponse500；不是assertAllowedFilePath400。File.list同类genericpermission/readdir500。只有mutation准入有typed400。root已收到这一错误边界补充；后续checker不得按名字套错状态。

建议每case输出一个明确分类：`admission-rejected`、`native-rejected-source-retained`、`published-and-addressable`、`published-but-public-path-unaddressable`、`published-retarget-outside-scope`或`unknown`。分类必须同时由原HTTP/rawcause/完整实体identity构成，不能以最后status、sourceabsence或日志条数单独归因。第一failure/unknown原保，不重试造成第二发布。

## 回执消费者与历史影响

`services/file-workbench.ts:351–366/430–453`根据真实旧source或其词法descendant向原editor owner准入，只有API成功MoveResult后admission.commit/bump revision；ApiError释放reservation并保持旧resource。若本题真实published404，旧编辑path与新实体会再次分裂，而不是可以由前端扫描硬盘猜第二成功。不能新增physicalalias/editorcache绕行。

`FileExplorer.applyMoveResults:1097–1124`只对真实已成功结果作old/newexpandedprefix、选中Node、clearcache和required reads；之前/之后父目录加entity-directory时目标目录读取。现terminallink回执type=file，不自动把新link目标当目录。new directory-target能力应由唯一list owner收齐真实target/所需expandedlogicalpath读取，不能为了多读目录改Node.type或让refresh失败覆盖已完成成员。scope/token、项目/authority/selectEpoch、retirement与原错误Details沿66/83收敛合同。

根保护历史明确两root的逻辑/physical身份与terminal-entry例外；ignore坐标历史明确entry逻辑path/Git身份保真；link批修followedstat false404、相对link原生retarget、broken原entry操作与verbatimcopy，**没有证明通过被移动source作为target ancestor时raw address存活，也没有覆盖destination ancestor alias的relative `..`实际parent**。既有rootlink/retarget/外域declared400和92项通过不是这两候选的排除证据。

旧`file-link-entry-contract.test.ts:269–296`的relative retarget source/targetparent均普通实体目录，447–480外域relocation例也不是浅root-back alias；当前source-into-self没有生产backend特判。前端canPlaceSelectionsInDirectory仅对item.type=directory做self/descendant限制，terminal link仍file；改变到浏览目录target不能误把这个branch当已覆盖数据完整性。

这些不是Task/Mission/Session scheduling事故，但属于多个producer共享File准入/metadata链；copy/move共享relocation、create/copy/move共享Node回执已横向核，原正常/error、retry source、串并行/multiProject与alias/root边界分别记录。当前没有新真实运行，不能宣称它们全已通过。

## 最低两Project有限前态调查提案（未授权执行）

root先正式spec汇总，再授一次prepare/真实Windows调查。一个全新owned R、两个真实独立Git Project A/B、同backend正常公开Project/emptyChat身份，不覆写Instance.directory/worktree/ID，不credentials/models/SQL/LLM（Large Language Model，大语言模型）或User文件。A/B各原marker32–64bytes UTF-8/CRLF；最多约30个真实entry、7个Move，没有filler/并发采集负载。

| case | source/targetparent关系 | 精确目的 |
| --- | --- | --- |
| J-self | absolutejunction自身作为parent | 原native结果 +raw/path/node可达与独立physicaldest |
| J-independent | 另一个独立junction到同D | 正向合法对照，不能因physicaltarget相同误拒 |
| S-self | 真absolute dir symlink自身parent | 不拿junction实际结果外推真dir symlink |
| S-dependent | 另一relative dir alias经source到D | 分开间接依赖与独立alias，检验lexical检查不足候选 |
| R-shallow-alias | 上述A/from/deep相对source经root-back浅实体parent | relocated permission坐标与A/B实际target |
| R-normal-control | 同relativetext移到A/to/deep | 正常in-scope/addressable200/read bytes对照 |
| B-independent-control | B ownscope独立source/other alias到B/data | 第二真实Project ownauthority/正常entry/read结果；与A外域区分 |

绝对junction/symlink source、otheralias、dataDir都为每case新名字，别重复同source；准备后记录每个entry lstat、followedstat、readlink、realpath和markerfullbytes/dev/inode。Dirent三个谓词亦采一遍，作为主导航调查的原primitive补证。真正crossProject例无须创建outside R的目录；所有实际/理论target清楚bound到R后才创建，失败停止，不删除既有目录或用户link。

正常API顺序：两Project/current与两个普通emptyChat（若开发CLI页面集成需），root资格/dev/inode/原marker内容→每case唯一PATCH/file/item→立即原响应/status/header/requestID/时间/cause日志→只读source、raw newPath、提前记录的physicaldestination各lstat/readlink/realpath→GET/file父目录和GET/content对应marker。拒绝时原source与targetmarker保持；成功时当前MoveResult/node和可达新path一致，并验证旧sourcetyped404/currenttarget完整内容或独立明确error。对于relocation外域候选，A新link访问可能500，B直接ownscope content200/fullbytes必须独立保。

每case最多1PATCH+4GET（source/target relevantcontent、parentlist、ownactualtarget control），7case≤35HTTP，加两Project/Chat与固定资格≤8，即caller最多43；physical读取不额外API、不无限递归目录链。实际需要的GET label预先审读，不为异常自动追加mutation或blind retry；原firstunknown/failure持久保存。额外完整body/sourceinode证明不可用时标unknown，不能用相同数组/alias名称或absence降级。

launcher只复用现成熟PS sourceCLI工具：900000ms absoluteexecution、startup45s/shutdown45s/otherjoin75s，原Host/Target births/occurrence、两outputs/request和parent正常结算；**没有external120000ms inactivitydriver**。未指定新R/port或创建任何脚本。本agent本轮不执行；root真实desktop另作为原点击/菜单资格，不能以此TCP/physical矩阵冒称UI或model验收。

## 证据后的最小当前单一方案边界

首先保持mature native noReplace、本体type、target原文字和既有权限两根。理想公开终态为：准确400/409等准入错误对应原entry保留，或200对应新logicalNode真实可lstat的同entry；新target内容另由read/list给真实200/404/500，不强制保持旧targetidentity。

- 若直接/依赖case原生rejected并source保持，不将它包装published404；未发现路径寿命故障就不加source门。
- 若实际published/raw-address404，先定义source-dependent destination的**数据完整性准入**而非LLM流程gate。只许证明该parent依赖被退休entry才精确InvalidPath400，保独立alias同D的合法200；canonical ultimate target equality不是依赖事实。当前没有成熟“保link hop身份”primitive，如何覆盖间接alias需正式分析，不为简单keyword或只有直接prefix通过宣称完成。
- 若relative浅alias真的造成preflightA内/actualB，修唯一shareddeclared-target resolver的实体parent坐标，copy/move/树内links一起覆盖；不将目标realpath写回publicNode、rewrite relative readlink或放宽A→B读取。源/目的futureparent/unknownI/O的准确推导需新spec后实施。
- 不采用“先rename失败再试physicalpath”、失败后followedstat猜200、raw target不存在才fallback真实path、先复制后删、别名client补receipt或延迟metadata来掩盖。若正式选择改变MoveResult地址合同，必须API/SDK/Node/Git logicalidentity/editor/全部callers一起明确；当前没有该授权，不默认改变。
- 目录浏览List-only target事实仍可作为下一实现，但上述搬迁风险应先实际判定；不能把新capability加到mutationreceipt，诱发新的未知targetI/O发布后500。

当前最关键unknown为Windows原生source-dependent rename结果、relative浅alias最终target与准确API/cause、其他alias依赖链、未知I/O/retargetrace、POSIX/UNC/跨卷。所有源码推导已标条件；没有新增产品、测试、fixture或正式spec，没有执行用户进程/API/UI/Git/模型。
