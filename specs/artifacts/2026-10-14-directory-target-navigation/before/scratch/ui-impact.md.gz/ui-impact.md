# 健康目录 link 浏览：UI/公共消费者影响增量审计

## Recall 与本轮权限

用户持续批次要求保持：先完整根因/影响分析落正式spec，再实施、真实桌面/截图人工复核、聚焦正向功能检查和需要且已授权的模型验收，精确提交/同步上游/正常push后下一批。上一批5107ed64根目录显示已按root原回执正常push/fresh fetch，HEAD=origin/main、own ancestor0；两个自有UI实例已物理收束。首轮deadline1/父join1与独立最终普通0仍分开，typed根upload及Capsule未知不据此排除。

本轮是一层限定只读委托，禁止再次委托、产品/测试/正式spec/共享索引/Git修改、服务/模型/API（Application Programming Interface，应用程序接口）/进程运行或用户应用查看。只写本owned ignored scratch；已读git status，当前其它owner的serve/runtime/restart/stop/Univer与规格差异全部保留。没有新fixture、checker或UI自动化。

先完整重读 .tmp-codex-next-publication-01a133/next-batch-candidate.md、上批directory-label Recall及剩余资格、file-link-entry-contract Recall/最终entry合同、07-panel487–579当前路径/反馈/owner合同、07-panel-reactivity authority/selection原原则。此报告**补UI收敛与公共消费者精确影响**，不重做前报告已经完整的backend target resolver、Dirent/权限/primitive/真实TCP（Transmission Control Protocol，传输控制协议）计划。随后完整读取Root新落盘的2026-10-14-directory-target-navigation.md Recall/权限/有限真实调查和验收，当前仍无本agent实施或运行授权；真Windows谓词尚须新fixture实测。

## 全仓定义/调用与既有证据资格

精确检索 FileNode/loadFileDirectory/File.list()/resolver(File.Node)、所有Explorer entry.type/navigation/selection/cache/refresh/drop调用、SDK（Software Development Kit，软件开发工具包）生成和现相关测试/历史，实际生产影响集中如下：

| 定义/消费者 | 当前合同与预期影响 |
| --- | --- |
|opencorvus/src/file/index.ts:41–53 File.Node；:1185 nodeForEntry；:1641 list|Node是entry事实；list目前同Node，尚无directoryTarget定义。拟列表独立必需bool扩展保Node本体/ignored不变。|
|opencorvus/src/server/routes/file.ts:86–113|GET/file200仍Node.array；需准确引用新列表schema，未知读取500作为真实公开错误而非knownfalse。create/copy/move Node routes保持entryschema。|
|opencorvus/src/cli/cmd/debug/file.ts:64|直接File.list→输出，复用同一个列表projector，不新增CLI stat/resolver。|
|sdk/js/src/gen/types.gen.ts:2256/18321等；gen/sdk.gen.ts:4269|FileNode及FileListResponses200为Array<FileNode>；Move/Copy/Create分别也引用Node。必须成熟生成独立ListingNode/FileListResponse，不能让这些mutation返回target读或把field改可选兼容。|
|sdk/js/script/build.ts:236/340等|现源码OpenAPI生成与replaceGeneratedArtifactsAfterSuccessfulBuild单一事务更新openapi/gen；本轮只读，不能手改gen或执行另schema。|
|overlay/src/services/file-workbench.ts:9/391|手写FileNode是五字段，loadFileDirectory回FileNode[]；可改SdkFileNode/SdkListingNode两个类型alias并明确list结果，未发现其它手写target事实来源。Node完成回执保持原create/move/copy/editor流程。|
|overlay/src/components/FileExplorerPanel.tsx|仅此tree/selection/context/drop消费者，详细如下；childrenByPath存当前accepted ListingNode，不新增capability Map或selection缓存flag。|
|overlay/src/components/TaskDirBar.tsx:366|loadFileDirectory只消费items.length；schema扩展无须改计数语义，但一个unknown target I/O使整个list失败也会使其现file-information owner显示原失败，不能忽略这个非Explorer影响。|

其余全仓node.type/isDirectory匹配多属于DOM/AST（Abstract Syntax Tree，抽象语法树）、Git/Task/shell/skill的独立对象，未认领为FileNode。model tool/read.ts:111–122有Dirent symbolic-link→followed stat→目录尾斜线的独立同语义展示，但属于模型读工具/权限owner，并且现catch→undefined策略不满足新File.list的unknown-error合同，不能复制来做本UI事实或顺手改模型工具。model glob/ls与File.search的字符串结果不走File.Node，本批不加rg --follow或逐search row元数据请求。

现overlay/test的唯一loadFileDirectory引用是file-workbench-mutation.test.ts:428退役authority→明确ApiAuthorityChangedError的服务case；没有找到本函数的成功ListingNode body fixture需要移植。其Node mutation fixtures保持entryschema，无理由补fake directoryTarget。相关已有backend列表断言是否exact及需要迁移由backendowner逐处核，不能因为toMatchObject容许extra字段便称新bool已经验对。

只用view_image实际看既有链接批after/04-junction-move-selected.png与05-junction-selected.png：05能看到已选moved-junction仍是document glyph且无chevron，普通目录有folder/chevron。它证明旧entry展示，不证明最新健康link单击错误/新导航已复现。旧候选已有健康link显式GET/file200/marker内容证据；新修前实际点击/当前source/pid/路径绑定仍需root取得。当前source链预测File pane会对目录target走regular-file限制，statReadableFile:676映射FileNotFoundError；真实新UI/HTTP错误未运行，不能仅按此代码把404当已观察事实。

## entry.kind与directoryTarget必须各守其角色

保File.Node.type是entry kind：directory entry为directory，terminal symlink/junction为file。directoryTarget应仅由**当前scope/token成功发布的ListingNode**证明此path当时是现权限内目录导航/目的地。它不是link自身kind、writable/readable保证、physical identity或原子target快照；false是已确认不能作为该允许目录target，undefined是没有列表事实，不能用`?? node.type===directory`变成旧协议或另事实源。

最小frontend数据模型：ExplorerRow.node和childrenByPath泛型改ListingNode；ExplorerOutcome.completed、FileMove/CopyResult.node仍Node；selectionFromNode只需要共有entry path/name/type，可同时消费这两个明确schema，**不把directoryTarget保存进selectedItems/draggedItems**。父目录成功列表是该path当前target提示来源，mutation node不能合成true/false。当前list失败保持原cause和last successful list；不得把一次failed读取解释成成功knownfalse。

| 行/动作现位置 | 使用新target事实还是原entry事实 |
| --- | --- |
|rows:658 expanded+pushChildren；render:1773–1844|directoryTarget决定expanded、folder/chevron、aria-expanded、单击导航与Open→Expand/Collapse；key仍scopeKey+node.type+logical path，target bit变更不替换entry identity/row owner。|
|FileRowContent视觉primitive|已有expandable/icon/expanded props足够，不需要新glyph体系或CSS；原name/path/ignored数据保持，不把physical target basename覆盖alias。data-kind仍entry type。|
|range/Ctrl选择、selectionFromNode、selectedItemMap|保存entry身份；健康link仍file，只改变可见子rows。不要因目标是dir而把link变成recursive实体dir。|
|renderItemContextMenu:1592–1644|node row原目录role改为directoryTarget；Expand/Collapse、New file/New folder、Upload的目的地必须一致指原alias logical path。Rename/Copy/Move/Delete继续entry操作。|
|contextTargetDirectory:844、rowDropDirectory:1782|健康已确认dir target取原link path；普通file/filelink与search-file row保父目录。目标菜单/row drop均从当前row已知bit传入，不读另shadow selection bool。|
|canPlaceSelectionsInDirectory:859、copyItem:1396|真正实体directory的递归/self-directory保护仍按entry.type，不机械替换为target bit。危险link自身destination另须真实公共API调查。|
|topLevelActionSelections:835|继续词法ancestor吸收后代；选中link及其展开child后，当前算法只处理top-level link，这仍是entry-only复制/移动/删除而非跟随target递归。应在正式合同和真实例中明确这个新可达组合，不把同名physical alias算重复entry。|
|reconcileDirectorySelection:736–775|判断child path能支撑后代selection/anchor/drop时用accepted child.directoryTarget；exact leaf的type/name比较仍entry事实。成功false/missing时叶link本身仍可被选，后代/anchor/drop范围必须退休。|
|create/upload/copy/move目的地正文|原root-label helper只把空规范key本地化；非空alias/child/Unicode/POSIX反斜杠/空白保持事实。不能因target是实体root把alias名字改“根目录”。|

当前contextTargetDirectory依赖selection.type，故只改chevron/row click会把healthy link Upload/drop错误导向parent。具体最小方向是让该私有helper接收当前row的明确directory-target role，node menu/drop都传同一个node getter，search menu/drop显式保持其file-result合同。四个实际createEntry调用（node两项/background两项）都传显式targetDir；其可选参数的selectedItem fallback是当前无调用分支。若迁移helper签名，优先在本触及的目录角色合同内把这个私有target参数收为required并删除无调用隐式选择分支，避免仅为旧optional猜测引入target lookup/cache；这需root正式scope决定，当前未改。不会改用户手输Copy/Move目的地：其真实目录资格仍由backend处理，不把list bit当写权限gate。

搜索row.kind=search仅有path，继续原file结果/Open/父目录目的地，没有新target metadata。即使childrenByPath还保有同path旧列表，也不能不说明就让搜索row选择从其不存在的schema继承dir导航。当前context options已明确search isDirectory:false，保这种公开边界，别逐row请求来补不可证明的字段。

## 已展开link Move/缓存：不能从receipt补target或借poll/editor充数

现updateExpandedPathsAfterMove:1078–1095已经按logical prefix搬迁所有已有expanded intent，与entry kind无关；clearDirectoryCaches:997–1020按previous subtree清缓存。applyMoveResults:1111却只在result.node.type===directory时请求normalizedNext。健康目录link仍file，因此迁移后的expanded alias/new child map为空，action只刷新旧/新parent/root。15秒poll:573–579也只读已有children或error的expanded键，新键两者都无时继续略过。没有已开child editor时，新alias的展开箭头可指向没有立即采集的空tree；不能宣称已有普通目录逻辑覆盖了link。

已有selectedFileTarget effect:584–606会扩并读取被打开child的ancestors，但那是另一个现有非required owner，不能用它或15秒poll替代这次mutation的原required refresh qualification。File-workbench moveFileItem:430–450在真实PATCH成功即沿descendantSuffix+same editor admission.commit映射打开child；该唯一编辑owner保持，包括unsaved决定/原range/新path/content错误，Explorer不建物理别名target表。

最小计划：在现expanded-prefix primitive处收集**实际被映射的展开意图path**（包含link本身和已经展开的下层），纳入同一次refreshFileViews required reads；保原实体directory receipt已有必要读。意图是该existing owner的真实用户/编辑资源意图，不是假directoryTarget。父列表读与每个新logical目录读都通过原scope/token/collectFileRefreshReceipts完成，再给它们自己的loaded/failed/retired/observedFailure；新link变missing/regular/outside时可以有真实独立刷新失败/退休，completed entry成功仍保。不要把前link true复制到新的mutation Node，亦不填false隐藏未取得的当前列表事实。

不能在loadDirectory入口加“没有directoryTarget就不读”的总gate：move后的新parent listing尚未完成、editor ancestors初次尚未列举，都需要原explicit/required读取建立事实。navigation/目的地使用当前已知true，与原started read的owner/receipt合同是不同角色。

## 成功父列表确认false/missing后的收敛必须补明

目前reconcile只管理selection/anchor/drag；没有按父结果退expandedPaths/child cache或tokens。若仅改type判据，健康link→file/broken/outside后rows会隐藏descendants，但旧expanded意图与child Map仍留。现15秒poll和explicit Refresh会继续对其旧分支读，target恢复时toggleDirectory:1522非force又能复用旧cache。ordinary entity dir→file/missing也共享这套机制，不能把这个消费者遗漏说成仅某link/一次按钮问题。

正式方案需把**accepted successful parent list**的明确invalid branch作为同一existing owner的结构变化：对不存在或directoryTarget=false的immediate child，退休其展开/后代可见性/anchor/drop并清对应旧child subtree。root空键保留，failed parent read只保原错误而不推knownfalse；尚未列出的新路径是unknown，不与false混同。

还需精确定义在途read：只清Map而不处理原path tokens，旧非required/required请求可能在clear之后publish回来。应复用当前directoryLoadTokens/requiredDirectoryLoadTokens/原scope/token来完成这些旧投影退休，**不是新增target epoch/cache/gate**。已started required请求必须仍由原collector收齐，并保真实error/retired+observedFailure；不能取消等待、把退休判loaded，或吞其错误。尤其同一move action的parent/新alias required读并行，父先确认false时不应盖掉已完成entry和另一个started read的原事实；该结构退休用当前retired理由/发布时刻如何准确归类，需要root在正式spec明确，不能在实施时临时猜。

这是新导航加入后必须考虑的正常/失败/恢复/并发与终态收敛边界。全入口已核：初次root250ms加载、toggle普通读取、editor ancestor读取、15秒poll、Retry force、明确Refresh、create/rename/copy/move/delete/upload required reads均共用loadDirectory与两个原token Map。search独立source，最后仍由同refresh collector收齐。不同Project/authority/selectEpoch/Close/disposed仍使旧read退休；换tool/隐藏Dock保同owner。Task/Mission/Session选择在Files使用同activeDirectory与selection scope，并不修改其执行轮次/调度/LLM（Large Language Model，大语言模型）工具权限；没有新模型/engine异常资格可据此排除原Capsule/Native共享调查。

## Drop新可达风险与Entry/editor边界

新true目录目的地会让“将link拖到自身行”变成targetDir=该link，nextPath=link/<name>。现canPlace只拦真正directory source，terminal link file可通过；backend metadata回执是否因source alias移动失效而成为发布后404是旧候选明确的真实API调查缺口。另一alias到同physical target也不能由前端path/bit推安全。必须root owned公共API/physical证据先核link→link/moved-link及另alias两种情况；如证发布后回执异常，先根因/全public mutation合同落盘，不能只加row gate遮公共入口或把directoryTarget升格成permissions。

删除link及展开child的top-level组合按现逻辑只unlink link，真实target内容保留；单独选择child是其自己的logical path实体操作。这是entry/target语义需展示与验收的区别。copy保readlink而不递归target；relative link relocation可能使随后directoryTarget变false，仍是成功copy entry+独立target读事实。root-link有限一层浏览不授权移动被followed ancestor访问的实体root，现root双保护/两declared target/strict staging/no-overwrite与未知I/O（Input/Output，输入输出）传播必须保持。

## 两Project/当前语言/最小准入与未取证

两独立Git/Project同backend：A可列其own healthy target；A指B的outside目录entry可以存在，但不得借target字段开启越域导航/写入，B ownscope对相同physical目录有自己的成功列表。不能共享按Project ID归一的cap缓存、原A list response/expanded subtree或mutation node来推B。已选same directory再回来的selectionEpoch仍退休旧动作；纯navigation普通scope隔离不等于late response实际矩阵已验。

现Open/Expand/Collapse/loading/error/menu/actions/counts两locale已齐，FileRow name/path保用户原文；无需新字符串或locale冻结state来教使用方式。目标root label上一批已实现；healthy alias目标仍显示真实alias名。SDK/doc须说明entry type与listing capability不同、bool仅时刻目录资格、mutation不提供target，并同步07-panel原“不提供目录link导航”合同。默认保持原entry排序与rowkey，不因folder glyph无证据改backend排序或新增link subtype/badge。

建议root正式准入最小产品范围：File/index+GET/file route+成熟OpenAPI/SDK生成；file-workbench仅两schema type/list返回；FileExplorer仅导航/目的地/accepted-list selection与展开读收敛，保完整mutation/editor/feedback合同。后端新required列表字段要实际完整正向API验证，unknown错误只在读阶段保原500，禁止进入mutation Node造成已发布后新错误。本轮未实施任何部分。

仍需修前新实页与owned证据：healthy junction/dir symlink真实点击/右键Open；Windows Bun1.4 Dirent三谓词；同alias显式list/content完整bytes；self-drop对应public mutation真实结果；成功父list false/missing与原child读取的自然先后。修后root实际展开/collapse/Open marker、alias New/Upload/普通CopyMove目的地、expanded link rename/move（editor关闭和打开child/dirty两种）、nested expanded alias children、target变file/missing/outside再恢复、相同原path late list、跨两Project/语言/Close和tool隐藏，分别有人工原图/原API/实体/receipt。不可伪造DOM/DataTransfer/调用隐藏函数、mock target stat或Private SQL来补证明。

已有链接批数据/原图不包含本新导航的完整点击和target变化时序；本agent没访问用户应用、启动fixture/API、运行任何UI/功能测试。当前相关overlay/test检索未发现FileExplorer/render/DOM/Playwright UI自动test；纯file-workbench是服务fixture资格，不能冒页面，后续若触及发现自动UI路径仍应报告root删除。

typed根upload、publication B/逆序drop A、Capsule准备/恢复、原Aggregate nested cause、真实POSIX/UNC/ACL（Access Control List，访问控制列表）/多卷/循环link并发等保持各自未知；不能以本bool/source审计或上一批正常收尾降级。这里只给具体增量影响和实施前决策/证据缺口，root完成正式spec并另授实施/新运行后才推进。

## 补核：原目录读owner的全入口/结算矩阵

Root要求按共享机制横审，故重新逐行读取当前loadDirectory:482–540、两个token Map、全部调用和所有clearDirectoryCaches消费者。当前**七处实际loadDirectory调用语句**，并非七个不同owner；统一归属Explorer现scope/token，mutation的多入口最后都进入一处required刷新。以下都是源码可达合同，不是本轮真实时序复现。

| 入口/调用位置 | 原读取输入与结果消费 | target/分支退休影响 |
| --- | --- | --- |
|initial effect:542–564|scope/API authority/selectEpoch/tool-open变化重置原Map/selection/loading/errors/两token；enabled时250ms后ambient root。scope原timer cleanup取消尚未启动读。|首次父list建立当前target事实；成功为空与pending/失败继续区别。不因暂无target gate根读取。|
|15s poll:566–580|捕获当前scope；root+expanded；root必读，其余仅有children/error时force ambient；每个Promise原样运行但无action receipt。|新mapped expanded无cache/error时不会自动补齐；失效分支不退休则继续poll。force仍让位当前required token。|
|row toggle:1523–1531|修改原expanded set，ambient非force读取；缓存/loading/required已在时skip→undefined。collapse也会调用同读。|row当前true允许展开；knownfalse/missing枝清原cache/token/loading后，恢复true的下一次展开才真实读。不能把skip作loaded。|
|editor auto-expand:583–603|同directory的selectedFileTarget令ancestors展开，untrack启动root/ancestors ambient；scope/authority/epoch原捕获。|祖先首次未列举也需读；不能要求先有target bool才准读，不能借该ambient effect替代mutation required。|
|explicit Refresh:1062–1070→1023–1036|required root+全部expanded，与当前非空query独立并行collect；runMutation最终只有当前operation owner可发feedback。|退休枝从expanded删除，后续Refresh不重读它；本次已经started child的原Promise仍完整收齐。|
|root Retry:1073–1075；expanded error Retry:1907|force ambient（root先清mutationfeedback），仍受同path required admission及同scope/token；原error Map由真正新读更新。|新accepted parent才可判枝false/missing；父Retry失败不等于false，不清最后成功target/tree事实。|
|all mutation refresh:1029|required路径按uniquePaths去重并立即发新HTTP；create1192、rename1245/Move1288与批次/drop共applyMove1120、Copy1148、Delete1494、Upload1570；同时启动当前query读。|receipt保持entry-only；move必须纳入原映射expanded意图；所有已started目录与query各自收齐loaded/failed/retired。没有新的target predicate gate。|

newtarget=false成功父list并非新增外部load入口，而是同loadDirectory成功发布:514–518内的结构确认。当前reconcile仅触及selection/anchor/drag:736–772。父read failed:520–529只记原error，children Map保前次成功值；这正是不能以failed parent判false的已有事实边界。

原owner成功/错误/退休流程与要保的契约：

| 同path情况 | 原控制/可观察输出 | 最小结构修正必须保持 |
| --- | --- | --- |
|ambient缓存或loading在；ambient撞required|497–498 skip返回undefined；并无HTTP/loaded资格。|不造一份成功read receipt，不复制required结果到另cache。|
|required开始；旧ambient在途|501删除旧ambient token，新required token独占该path。旧HTTP继续原await。|旧成功→retired/superseded；旧失败→retired/superseded+observedFailure原error；旧finally不清后继loading。|
|第二required同path开始|同required Map覆盖token，两个原Promise继续。|较旧read完整结算retired；collector按各自target保存，不能把第二read success改称第一success或join第二owner。|
|当前scope/token read成功|516同步发布准确parent list并协调选择，519才返回loaded。|parent结构收敛应在这同一batch完成，loaded不是仅HTTP200。保原请求和原列表对象字段。|
|当前scope/token read失败|原error对象进directoryErrors且返回failed；finally清自己的token/loading。|保原cause/Details，目标读取未知I/O使wholelist失败也不可改成knownfalse。|
|scope退休后原read成功/失败|512/521分别retired/scope，失败另保observedFailure；不发当前Map/error。|跨Project/authority/epoch/disposed最终不投影旧action；不取消原Promise等待或复用给新scope。|
|同scope accepted parent退休在途child枝|现无此退休；只clearChildren/errors允许旧token随后回写。|同步删该枝两token+loading/cache/error/expanded，旧HTTP仍原await；它自己的success/catch按ownsLoad自然retired/superseded、失败保observedFailure；finally不清其它后继owner。|
|child已经published/返回loaded，之后parent才false|先前loaded是该真实read的已结算事实；当前tree随后有新的parent结构事实。|可退休当前树，不能回写已fulfilled receipt或将其改成伪error；action的每个read事实与当前tree后续事实分开。现架构也不让后来的ambient成功重写历史action。|

collectFileRefreshReceipts唯一实现:file-workbench:74–81，Promise.allSettled按原输入次序组合每个target/state，真实reject（包括undefined）保存原reason。纯服务test只证明该collector的保序/收齐/原引用和独立组；并未证明组件token fence或自然parent/child先后，且本agent未运行。新accepted-list结构处理不能在finally return、throw一个新error盖旧cause、提前return丢剩余reads、因一条superseded而清真正completed，亦不新增等待cache/history store。

## 补核：同一move required parent/child的自然先后

applyMove先映射已有expanded intent、清旧/新相关cache，再同时启动refreshTargets。当前get列节点路径与同一parent两个required重复会被uniquePaths归一；不同parent/child保持真实并行。最小修正应把映射后的每个expanded path加入这一个collector，不能为“等父true”新建串行准入gate。

| 自然顺序 | 正确当前投影及原receipt |
| --- | --- |
|new child读先成功，parent随后成功并含true child|child自己的cache/loaded事实保；父确认true不清new expanded或其cache。它能支撑后代，仅该后代自己的父list才证明具体后代存在。|
|parent先成功并含true child，new child稍后成功|parent保new expanded意图及child原token/loading；child随后同token发布loaded。|
|parent先成功并明确false/missing，new child还pending|只退休被确认无效的对应child枝；child原Promise最终retired/superseded，真实error保observedFailure，completed mutation仍成功事实。|
|parent先失败，new child成功|保父原cause与最后成功父list；child原scope/token成功可发布自己的loaded，不能因父失败假定该branch无target。|
|new child已成功，parent稍后确认false/missing|退当前tree/expanded/cache，但保已完成child read receipt为其真实loaded时刻；不能凭最终可见性重写它为retired，也不能声称这是一份原子whole-tree快照。|
|parent含true新child，同时其它sibling false/missing|只退那个sibling的枝；对new child intent/token/cache不做广域清空。|
|旧ambient parent请求开始于publication之前，mutation启动新required parent|原required开始删除旧ambient token；旧返回retired，不准旧prepublication list误判new child missing。|

这组顺序需要Root真实owner/原请求与截图或明确协议事实取证；本轮未造延迟/mock/DOM注入或运行race矩阵。代码支持风险与最小修正，但不能据此宣布某个race已复现，更不能以单个顺序正常排除共享owner缺口。

## 补核：最小唯一结构退休及根命名空间边界

clearDirectoryCaches:999–1020目前**仅删children/errors**。全调用只有applyMove1117、applyCopy1145、create1190、applyDelete1493；原定义可追到65d0bfc98:715–736，仍同两Map逻辑。5090c7e36的精确diff只把成功列表reconcile加入同batch，新增selection/anchor/drag处理，未增加expanded/cache/token枝退休。66 outcome记录完善required/retired/collector和finally，83保mounted owner与upload query同步，后继search publication记录修query时序；都没有提供结构枝退休，故这不是目录link的新独立缓存实现需求。

建议沿原唯一clearDirectoryCaches定义使指定exact/subtree失效同时删**两原token Map+loading Set**；mutation clear仍保expanded意图，之后立即发新的原required读。accepted-list另在同一成功batch导出明确invalid immediate-child subtree，调用这一原primitive并移除相应expanded意图，配合原selection/anchor/drag协调。分开“mutation invalidates metadata但保展开意图”和“accepted parent确证枝退休”，避免一改clear就把成功move刚mapped的new expanded删除。这个建议不引入第二owner、target cache/epoch、请求替换或物理别名图。

枝退休范围必须从**该parent列表所覆盖的直系child命名空间**判断，并仅作用于明确missing/false的枝，exclude parent自身与保留空root键。不能把整棵expanded/cache清空；也不能要求new required path必须在旧parent list中已有true。成功父listing当前完整成员可以证明其直系child missing；父未成功/hidden/search/filter/尚未读父均无该证明。

具体公有路径风险：isPathOrDescendant:404–408在root==""时把任意非空key视作后代，reconcile:738/740据firstsegment查root成员。合法directory-relative`../parent-created.md`/`../parent-move.md`是前批真实A子scope→worktree父路径合同（metadata-feedback:79–81，真实API list父目录200/完整bytes）；它不是当前root list的`..` entry。新结构退休若直接用该root predicate，会把expanded `..`/`../folder`及其在途required parent读取误判missing。故必须明确root的真正child namespace：leading `..`不是root列表child；对于真正parent=`..`的成功列表，可按其实际nodes.path辨其`../x`直系child。保非空路径大小写/空白/Unicode/POSIX反斜杠原样，不能靠physical canonical target或翻译路径来判此关系。

这同一命名空间还触及existing selection reconcile而非只有新cache retirement，最小实现需使用同一个精确immediate-child relation给selection/anchor/drop与新退休，避免保两个不同“covered”来源。原leading-dot路径helper已成熟词法归约，不能加新的fallback归一；上述源码风险尚未取得本轮leading-`..`自然page失效证据，Root决定正式scope/验收后才修改。

## 补核：Task/Mission/Session、重试恢复、串并行/两Project资格

| 横向域 | 实际当前来源/合同 | 本轮证据与未知 |
| --- | --- | --- |
|Task selection|activeProjectDirectory:6–9→taskOwningDirectory(selectedSource.id)，main:2785仅一处Explorer并传activeDirectory。|同目录换Task的selectEpoch也退休，Task执行occurrence/lease不参与目录读Promise；未新调度Task或模型。|
|Mission selection|main:1053–1062传Mission row.directory到openMissionWithUILifecycle；选中的session走project-directory:11–14明确selectedSource.directory。|Mission实际row scope不是Git common root；Mission dispatch/retry/recovery引擎未改、无本轮真实发生实例。|
|Session selection|selectedSource.kind=session从其必需owning directory返回；缺目录明确throw，不猜settings fallback。|同scope/authority/epoch约束覆盖；本轮未创建Session来证明新UI。|
|当前directory/API authority/selectionEpoch|Explorer:465–479；workspace.beginWorkspaceSelection:876–879原monotonic epoch；effects454与542原reset；reactivity:15–41唯一API revision。|A→B→A仍不得重入旧read/action；同URL新authority也退休。无第二Project ID/cache key。|
|tool hidden/Close/reopen|07-panel:560–567保留open工具owner，active是tool-open；Close disposed、新mount新Map。|隐藏不是退休或false；Close之后旧read原scope判disposed而不发反馈。restart新UI不能恢复旧局部token，服务原request按自己transport结算。|
|正常serial/同path并行|单sequence与两token Map决定真正当前publication；required抢ambient/后required抢先required。|不插新queue/gate；较旧请求仍原等待/retired。尚无本轮真实late窗口证据。|
|不同目录parallel/两Project同backend|每个component唯一Map的scopefence；API请求携原authority+directory，A指B外域由backend判false/权限，B有自己scope。|原A list/expanded/node receipt不能移植B；新list bool本身不能证明两Project恢复矩阵。|
|Retry与失败后恢复|root/branch Retry走force ambient；explicitRefresh走required；mutations没有自动重试；成功新list建立新fact。|knownfalse恢复true显示新导航；旧expanded已退休则由真实再展开建立childlist。unknown parent error仍保旧fact/Details，不能false回退。|
|终态/取消/retired|read只是原HTTP投影owner；scope退休返回三态，actionfinally只在原owner当前publish；已完成entry/原failure均保原事实。|不能把目录read退休等价生产Task取消/Host终态，也不以文件scope正常排除Capsule/旧Native Aggregate未知。|
|TaskDirBar第二公开list consumer|357–377捕获directory/authority/selectEpoch/revision，成功只count，scope/source exact验后返回；失败原summary，完全独立information resource。|不是第二directoryTarget store；newwholelist unknown I/O会影响其Files信息。无需给它加Explorer tokens或entry导航role。|

当前结论仅：最小导航能力需要list-only必需target事实、既有expanded意图required刷新和同accepted-list结构退休；原目录read owner/全started receipts保持唯一。新目录link与ordinary目录共享的late缓存publication风险未在本轮实机排除；本报告不把源码推断、旧截图、纯collector局部测试或某条正常运行冒充全序矩阵。新真实before/API/typed unknown/自然并行窗口与全部上文尚未覆盖项由Root后续明确准入，当前未实施或执行。
