/** PREPARE ONLY until Root separately authorizes an exact mode. No product modules imported. */
import fs from "node:fs/promises"
import path from "node:path"
import { execFile } from "node:child_process"
import { promisify } from "node:util"
import { scratch, runRoot, evidence, projects, prefix, port, schema, qualification, primitiveBun, stamp, factError, requireFact, samePath, missing, bound, directDirectory, directOwned, observe, sameEntry, save, json, label, loadFixture, loadOwner, loadRegistration, executor } from "./fixture-support.mjs"

const [mode] = process.argv.slice(2)
requireFact(process.argv.length === 3 && ["prepare", "primitive", "register", "before-probe", "readOnly"].includes(mode), "Usage: fixture-tool.mjs <prepare|primitive|register|before-probe|readOnly>; every mode needs separate Root authorization")
const tiny = (text) => Buffer.from(`${text} 01a133\r\n`, "utf8")
const join = (role, relative) => bound(path.join(projects[role], relative))
const relativeParent = (relative) => path.posix.dirname(relative) === "." ? "" : path.posix.dirname(relative)
const inputFiles = [
  { role: "root", path: "root-marker.txt", bytes: tiny("ROOT A") },
  { role: "root", path: "regular-file.txt", bytes: tiny("REGULAR A") },
  { role: "root", path: "target-dir/资料 Note.txt", bytes: tiny("DIRECTORY A 资料") },
  { role: "root", path: "target-dir/资料 Mix/marker.txt", bytes: tiny("NESTED A") },
  { role: "root", path: "project-b/marker.txt", bytes: tiny("RELATIVE SOURCE A") },
  { role: "root", path: "aliases/project-b/marker.txt", bytes: tiny("RELATIVE LOGICAL A") },
  ...["j-self", "s-self", "dependent", "independent"].map((name) => ({ role: "root", path: `mut-targets/${name}/marker.txt`, bytes: tiny(`MUT ${name} A`) })),
  { role: "root", path: ".gitignore", bytes: Buffer.from("/junction-dir/\n", "utf8") },
  { role: "b", path: "target-dir/marker.txt", bytes: tiny("PROJECT B TARGET") },
  { role: "b", path: ".gitignore", bytes: Buffer.from("", "utf8") },
]
const link = (role, relative, text, kind, basic = false) => ({ role, path: relative, text, kind, basic })
const links = [
  link("root", "junction-dir", projects.root + path.sep + "target-dir", "junction", true),
  link("root", "absolute-dir-link", projects.root + path.sep + "target-dir", "dir", true),
  link("root", "relative-dir-link", "target-dir", "dir", true),
  link("root", "file-link", "regular-file.txt", "file", true),
  link("root", "broken-dir-link", "missing-dir", "dir", true),
  link("root", "broken-junction", projects.root + path.sep + "missing-junction-dir", "junction", true),
  link("root", "external-dir-link", projects.b + path.sep + "target-dir", "dir", true),
  link("root", "root-link", projects.root, "junction", true),
  link("root", "mut/j-self", join("root", "mut-targets/j-self"), "junction"),
  link("root", "mut/s-self", join("root", "mut-targets/s-self"), "dir"),
  link("root", "mut/dependent-source", join("root", "mut-targets/dependent"), "dir"),
  link("root", "mut/dependent-other", "dependent-source", "dir"),
  link("root", "mut/independent-source", join("root", "mut-targets/independent"), "junction"),
  link("root", "mut/independent-other", join("root", "mut-targets/independent"), "junction"),
  link("root", "from/move-relative", "../project-b", "dir"),
  link("root", "from/copy-relative", "../project-b", "dir"),
  link("root", "from/control-relative", "../project-b", "dir"),
  link("root", "aliases/root-back", projects.root, "junction"),
  link("b", "mut/independent-source", join("b", "target-dir"), "junction"),
  link("b", "mut/independent-other", join("b", "target-dir"), "junction"),
]
const basic = [
  { role: "root", path: "target-dir", createdKind: "directory" },
  { role: "root", path: "regular-file.txt", createdKind: "file" },
  ...links.filter((item) => item.basic).map((item) => ({ role: item.role, path: item.path, createdKind: item.kind })),
]
const cases = [
  { id: "j-self", role: "root", action: "move", source: "mut/j-self", target: "mut/j-self/moved-entry", physicalDestination: "mut-targets/j-self/moved-entry", content: "mut-targets/j-self/marker.txt", relation: "direct-source-parent" },
  { id: "s-self", role: "root", action: "move", source: "mut/s-self", target: "mut/s-self/moved-entry", physicalDestination: "mut-targets/s-self/moved-entry", content: "mut-targets/s-self/marker.txt", relation: "direct-source-parent" },
  { id: "s-dependent", role: "root", action: "move", source: "mut/dependent-source", target: "mut/dependent-other/moved-entry", physicalDestination: "mut-targets/dependent/moved-entry", content: "mut-targets/dependent/marker.txt", relation: "other-alias-depends-on-source" },
  { id: "independent", role: "root", action: "move", source: "mut/independent-source", target: "mut/independent-other/moved-entry", physicalDestination: "mut-targets/independent/moved-entry", content: "mut/independent-other/moved-entry/marker.txt", relation: "independent-alias-same-target" },
  { id: "relative-move", role: "root", action: "move", source: "from/move-relative", target: "aliases/root-back/moved-relative", physicalDestination: "moved-relative", content: "aliases/root-back/moved-relative/marker.txt", relation: "relative-parent-shallower-alias" },
  { id: "relative-copy", role: "root", action: "copy", source: "from/copy-relative", target: "aliases/root-back/copied-relative", physicalDestination: "copied-relative", content: "aliases/root-back/copied-relative/marker.txt", relation: "relative-parent-shallower-alias" },
  { id: "b-independent", role: "b", action: "move", source: "mut/independent-source", target: "mut/independent-other/moved-entry", physicalDestination: "target-dir/moved-entry", content: "mut/independent-other/moved-entry/marker.txt", relation: "independent-project-control" },
  { id: "relative-normal", role: "root", action: "move", source: "from/control-relative", target: "normal/moved-relative", physicalDestination: "normal/moved-relative", content: "normal/moved-relative/marker.txt", relation: "ordinary-parent-relative-control" },
]
const get = (name, role, route, query) => ({ label: name, role, method: "GET", route, query })
const registrationSteps = ["root", "b"].flatMap((role) => [get(`register-${role}-project`, role, "/project/current", {}), { label: `register-${role}-chat`, role, method: "POST", route: "/coding/chat/session", query: {}, body: {} }])
const probeSteps = cases.flatMap((item) => [
  { label: `${item.id}-mutation`, role: item.role, method: item.action === "copy" ? "POST" : "PATCH", route: item.action === "copy" ? "/file/item/copy" : "/file/item", query: {}, body: { path: item.source, newPath: item.target } },
  get(`${item.id}-source-parent`, item.role, "/file", { path: relativeParent(item.source) }),
  get(`${item.id}-target-parent`, item.role, "/file", { path: relativeParent(item.target) }),
  get(`${item.id}-content`, item.role, "/file/content", { path: item.content }),
])
const readOnlySteps = [
  get("gui-root-list", "root", "/file", { path: "" }),
  get("gui-b-list", "b", "/file", { path: "" }),
  ...["junction-dir", "absolute-dir-link", "relative-dir-link"].flatMap((name, index) => [get(`gui-alias-${index + 1}-list`, "root", "/file", { path: name }), get(`gui-alias-${index + 1}-content`, "root", "/file/content", { path: `${name}/资料 Note.txt` })]),
  get("gui-file-link-content", "root", "/file/content", { path: "file-link" }),
  get("gui-broken-content", "root", "/file/content", { path: "broken-dir-link/marker.txt" }),
  get("gui-external-list", "root", "/file", { path: "external-dir-link" }),
  get("gui-b-own-content", "b", "/file/content", { path: "target-dir/marker.txt" }),
]
const stages = { register: { firstSequence: 1, steps: registrationSteps }, "before-probe": { firstSequence: 5, steps: probeSteps }, readOnly: { firstSequence: 37, steps: readOnlySteps } }
const inputLiteralManifest = () => ({ files: inputFiles.map(({ bytes, ...item }) => ({ ...item, bytesBase64: bytes.toString("base64"), size: bytes.byteLength })), links, basic, cases, requestPlan: stages, totalHTTP: 48 })
const result = { mode, startedAt: stamp(), executable: process.execPath, runtime: process.versions, platform: process.platform, preparedOnlyUntilAuthorized: true, requests: [] }

async function markerFacts(fixture) {
  const facts = []
  for (const item of fixture.files) {
    const actual = await observe(item.full, true)
    facts.push({ role: item.role, path: item.path, expectedBytesBase64: item.bytesBase64, actual })
    requireFact(actual.content?.bytesBase64 === item.bytesBase64 && sameEntry(actual.entry, item.original.entry), `Original literal bytes/entry changed: ${item.path}`)
  }
  return facts
}

async function prepare() {
  requireFact(process.platform === "win32", "This original fixture qualifies Windows only")
  const fixture = { schema, qualification, fixtureID: globalThis.crypto.randomUUID(), runRoot, prefix, port, project: projects.root, projectB: projects.b, modelCallsRequested: "none", credentialCatalogStaging: "none", preparedAt: stamp(), scopes: {}, files: [], links: [], basic, cases, git: [], pickerInputs: [], originalInputs: inputLiteralManifest() }
  result.fixture = fixture
  await save("prepare-admission.json", { ...fixture.originalInputs, schema, qualification, fixtureID: fixture.fixtureID, runRoot, prefix, port, admittedAt: stamp(), boundary: "Only this exact new run; no cleanup/reuse/retry" })
  // Root owns the new passive observer creation/calibration. It has no reused service owner.
  await directDirectory(path.join(scratch, "native-observer"))
  await directDirectory(path.join(scratch, "native-observer", "runtime"))
  const day = path.dirname(runRoot)
  await directDirectory(path.dirname(day))
  try { await fs.lstat(day) } catch (error) { if (!missing(error)) throw error; await fs.mkdir(day) }
  await directDirectory(day)
  await fs.mkdir(runRoot) // Exclusive, never recursive/delete/reuse.
  await directDirectory(runRoot)
  for (const name of ["runtime", "project", "project-b", "evidence", "home", "appdata", "localappdata", "temp", "xdg-config", "xdg-data", "xdg-cache", "xdg-state", "inputs"]) await fs.mkdir(path.join(runRoot, name))
  const directories = { root: ["target-dir/资料 Mix", "project-b", "aliases/project-b", "from", "normal", "mut", ...["j-self", "s-self", "dependent", "independent"].map((name) => `mut-targets/${name}`)], b: ["target-dir", "mut"] }
  for (const role of ["root", "b"]) for (const name of directories[role]) await fs.mkdir(join(role, name), { recursive: true })
  const execute = promisify(execFile)
  const gitEnvironment = Object.fromEntries(["PATH", "SystemRoot", "WINDIR", "ComSpec", "PATHEXT"].filter((name) => process.env[name] !== undefined).map((name) => [name, process.env[name]]))
  Object.assign(gitEnvironment, { HOME: path.join(runRoot, "home"), USERPROFILE: path.join(runRoot, "home"), APPDATA: path.join(runRoot, "appdata"), LOCALAPPDATA: path.join(runRoot, "localappdata"), TEMP: path.join(runRoot, "temp"), TMP: path.join(runRoot, "temp"), GIT_CONFIG_NOSYSTEM: "1", GIT_CONFIG_GLOBAL: "NUL" })
  for (const role of ["root", "b"]) {
    const original = { role, executable: "git", args: ["-C", projects[role], "init", "--initial-branch=main", "--template="], startedAt: stamp() }
    fixture.git.push(original)
    try { const output = await execute("git", original.args, { env: gitEnvironment, windowsHide: true, timeout: 15000 }); Object.assign(original, { stdout: output.stdout, stderr: output.stderr, exitCode: 0, completedAt: stamp() }) }
    catch (error) { Object.assign(original, { error: factError(error), stdout: error.stdout, stderr: error.stderr, exitCode: error.code }); throw error }
    fixture.scopes[role] = { directory: projects[role], identity: await observe(projects[role]), gitIdentity: await observe(path.join(projects[role], ".git")) }
  }
  for (const input of inputFiles) {
    const full = join(input.role, input.path)
    await directOwned(path.dirname(full))
    await fs.writeFile(full, input.bytes, { flag: "wx" })
    const original = await observe(full, true)
    requireFact(original.content?.bytesBase64 === input.bytes.toString("base64"), "Original literal bytes do not match prepared file")
    fixture.files.push({ role: input.role, path: input.path, full, bytesBase64: input.bytes.toString("base64"), size: input.bytes.byteLength, original })
  }
  for (const input of links) {
    const full = join(input.role, input.path)
    await directOwned(path.dirname(full))
    await fs.symlink(input.text, full, input.kind)
    const original = await observe(full)
    requireFact(original.entry?.symbolicLink === true && original.readlink?.state === "present", "Actual independently created link required")
    fixture.links.push({ ...input, full, original })
  }
  const pickerBytes = tiny("PICKER LINK")
  const pickerFull = path.join(runRoot, "inputs", "directory-target-picker.txt")
  await fs.writeFile(pickerFull, pickerBytes, { flag: "wx" })
  fixture.pickerInputs.push({ full: pickerFull, name: "directory-target-picker.txt", logicalTarget: "junction-dir/directory-target-picker.txt", bytesBase64: pickerBytes.toString("base64"), size: pickerBytes.byteLength, original: await observe(pickerFull, true) })
  fixture.completeInputBytes = inputFiles.reduce((count, file) => count + file.bytes.byteLength, 0) + pickerBytes.byteLength
  requireFact(fixture.completeInputBytes <= 4096 && basic.length === 10 && cases.length === 8, "Original tiny bytes/case budget exceeded")
  fixture.ownedMutationPlan = stages["before-probe"]
  fixture.readOnlyPlan = stages.readOnly
  fixture.preparationCompletedAt = stamp()
  await fs.writeFile(path.join(runRoot, "prepared-fixture.json"), JSON.stringify(fixture, null, 2), { flag: "wx" })
  await save("prepared-fixture.json", fixture)
  result.outcome = "new-exclusive-owned-fixture-prepared"; result.fixtureID = fixture.fixtureID
}

async function primitive(fixture) {
  requireFact(process.versions.bun === "1.4.0" && samePath(process.execPath, primitiveBun), "Primitive must run on the exact reviewed Bun1.4; Node observations are not Bun Dirent qualification")
  await save("primitive-admission.json", { fixtureID: fixture.fixtureID, executable: process.execPath, runtime: process.versions, at: stamp(), cases: basic })
  const entries = await fs.readdir(projects.root, { withFileTypes: true })
  result.rows = []
  for (const item of basic) {
    const entry = entries.find((entry) => entry.name === item.path)
    requireFact(entry, `Original basic entry not enumerated: ${item.path}`)
    const actual = await observe(join(item.role, item.path))
    const dirent = { directory: entry.isDirectory(), file: entry.isFile(), symbolicLink: entry.isSymbolicLink() }
    result.rows.push({ ...item, dirent, actual })
  }
  result.markers = await markerFacts(fixture)
  const mismatches = result.rows.filter((row) => !["directory", "file", "symbolicLink"].every((key) => row.dirent[key] === row.actual.entry[key]))
  result.predicateMismatches = mismatches.map((row) => row.path)
  result.outcome = mismatches.length === 0 ? "actual-ten-Dirent-entry-predicates-agree" : "actual-Dirent-predicate-qualification-unfulfilled"
  result.exitCode = mismatches.length === 0 ? 0 : 1
}

async function register(fixture, owner) {
  await save("register-admission.json", { fixtureID: fixture.fixtureID, occurrence: owner.occurrence, owner, at: stamp(), originalPlan: stages.register })
  const request = executor(owner, stages.register, result.requests)
  const registered = { fixtureID: fixture.fixtureID, occurrence: owner.occurrence, owner, startedAt: stamp(), scopes: {}, requests: result.requests }
  result.registered = registered
  for (const [index, role] of ["root", "b"].entries()) {
    const project = await request(registrationSteps[index * 2])
    requireFact(project.status === 200 && typeof project.body?.id === "string" && typeof project.requestID === "string", "Original normal Project200 required")
    const chat = await request(registrationSteps[index * 2 + 1])
    requireFact(chat.status === 201 && typeof chat.body?.session?.id === "string" && typeof chat.requestID === "string", "Original empty Chat201 required")
    requireFact(chat.body.session.projectID === project.body.id && samePath(chat.body.session.directory, projects[role]), "Actual Project/Chat directory binding failed")
    registered.scopes[role] = { directory: projects[role], projectID: project.body.id, chatID: chat.body.session.id }
  }
  requireFact(registered.scopes.root.projectID !== registered.scopes.b.projectID && registered.scopes.root.chatID !== registered.scopes.b.chatID, "Actual two independent Projects/Chats required")
  registered.completedAt = stamp(); registered.outcome = "two-original-independent-projects-registered"
  await save("registered-projects.json", registered)
  result.outcome = registered.outcome
}

async function originalLogs(owner, ids) {
  const root = path.join(owner.runtime, "log")
  await directOwned(root)
  const files = (await fs.readdir(root, { withFileTypes: true })).filter((entry) => entry.isFile() && entry.name.endsWith(".log"))
  requireFact(files.length <= 8, "Owned original log file cap exceeded")
  const captures = []
  for (const entry of files) {
    const full = await directOwned(path.join(root, entry.name)); const bytes = await fs.readFile(full)
    requireFact(bytes.byteLength <= 4 * 1024 * 1024, "Owned original log capture exceeds input cap")
    const rawBody = bytes.toString("utf8"); const parsed = []; const parseErrors = []
    for (const [index, line] of rawBody.split(/\r?\n/).entries()) { if (!line) continue; try { parsed.push(JSON.parse(line)) } catch (error) { parseErrors.push({ line: index + 1, rawLine: line, error: factError(error) }) } }
    captures.push({ full, at: stamp(), rawBodyBase64: bytes.toString("base64"), rawBody, parseErrors, matchingRecords: parsed.filter((record) => ids.includes(record.data?.requestID)) })
  }
  return captures
}

function classify(item, response, before, after) {
  const retained = sameEntry(after.source.entry, before.source.entry) && after.source.readlink?.text === before.source.readlink?.text
  const physicalPublished = after.physicalDestination.entry?.symbolicLink === true && after.physicalDestination.readlink?.text === before.source.readlink?.text && (item.action === "copy" ? retained : sameEntry(after.physicalDestination.entry, before.source.entry))
  const publicAddressable = sameEntry(after.target.entry, after.physicalDestination.entry)
  const targetValue = after.target.realpath?.value
  const relative = targetValue ? path.relative(projects[item.role], targetValue) : undefined
  const targetOutsideScope = relative !== undefined && (relative === ".." || relative.startsWith(`..${path.sep}`) || path.isAbsolute(relative))
  let outcome = "unknown-observation-retained"
  if (physicalPublished && !publicAddressable) outcome = "published-public-entry-path-unaddressable"
  else if (physicalPublished && targetOutsideScope) outcome = "published-entry-retargets-outside-own-project"
  else if (physicalPublished && publicAddressable && response?.status === 200) outcome = "published-and-public-entry-addressable"
  else if (retained && response?.body?.name === "FileInvalidPathError" && response.status === 400) outcome = "typed-admission-rejected-entry-retained"
  else if (retained && response?.status >= 400) outcome = "original-error-and-source-entry-retained"
  return { outcome, retained, physicalPublished, publicAddressable, targetOutsideScope, actualHTTPStatus: response?.status, boundary: "Observation classification only. No claim that any old bug is correct, no native-stage inference from HTTP alone." }
}

async function beforeProbe(fixture, owner) {
  await loadRegistration(fixture, owner)
  await save("before-probe-admission.json", { fixtureID: fixture.fixtureID, occurrence: owner.occurrence, owner, at: stamp(), originalPlan: stages["before-probe"], cases, maximumMutationRequests: 8, maximumHTTP: 32, qualification: "Original before-state classification, never an assertion that an old failure is correct" })
  const request = executor(owner, stages["before-probe"], result.requests)
  result.cases = []; result.originalMarkersBefore = await markerFacts(fixture)
  for (const [index, item] of cases.entries()) {
    const original = fixture.links.find((entry) => entry.role === item.role && entry.path === item.source)
    const current = { ...item, before: { source: await observe(join(item.role, item.source)), target: await observe(join(item.role, item.target)), physicalDestination: await observe(join(item.role, item.physicalDestination)) }, requests: [] }
    result.cases.push(current)
    requireFact(sameEntry(current.before.source.entry, original.original.entry) && current.before.source.readlink?.text === original.original.readlink?.text, "Original dedicated source changed before its one mutation")
    try { current.mutation = await request(probeSteps[index * 4]); current.requests.push(current.mutation) }
    finally { current.after = { source: await observe(join(item.role, item.source)), target: await observe(join(item.role, item.target)), physicalDestination: await observe(join(item.role, item.physicalDestination)) } }
    current.classification = classify(item, current.mutation, current.before, current.after)
    await save(`before-probe-case-${item.id}-mutation-and-physical.json`, current)
    for (let offset = 1; offset <= 3; offset++) current.requests.push(await request(probeSteps[index * 4 + offset]))
    current.originalMarkers = await markerFacts(fixture)
    current.originalLogs = await originalLogs(owner, current.requests.map((value) => value.requestID).filter(Boolean))
    await save(`before-probe-case-${item.id}-complete.json`, current)
    if (current.classification.outcome === "unknown-observation-retained") throw new Error(`First unclassified mutation retained: ${item.id}; remaining original plan is not executed`)
  }
  result.outcome = "eight-original-before-observations-collected-not-product-acceptance"
}

async function readOnly(fixture, owner) {
  await loadRegistration(fixture, owner)
  await save("readOnly-admission.json", { fixtureID: fixture.fixtureID, occurrence: owner.occurrence, owner, at: stamp(), originalPlan: stages.readOnly, readOnly: true, boundary: "Manual GUI readback; no mutation replay, UI assertions or model requests" })
  result.originalMarkers = await markerFacts(fixture)
  result.basicPhysical = []
  for (const item of basic) result.basicPhysical.push({ ...item, actual: await observe(join(item.role, item.path)) })
  const request = executor(owner, stages.readOnly, result.requests)
  for (const step of readOnlySteps) await request(step)
  const originalDirectory = inputFiles.find((file) => file.path === "target-dir/资料 Note.txt").bytes.toString("base64")
  const regular = inputFiles.find((file) => file.path === "regular-file.txt").bytes.toString("base64")
  const originalB = inputFiles.find((file) => file.role === "b" && file.path === "target-dir/marker.txt").bytes.toString("base64")
  for (const entry of result.requests) {
    const expectedStatus = entry.input.label === "gui-broken-content" ? 404 : entry.input.label === "gui-external-list" ? 500 : 200
    requireFact(entry.status === expectedStatus && typeof entry.requestID === "string", `Original public read status/ID: ${entry.input.label}`)
    if (entry.input.route === "/file/content" && entry.status === 200) {
      const expected = entry.input.role === "b" ? originalB : entry.input.label === "gui-file-link-content" ? regular : originalDirectory
      requireFact(entry.body?.type === "text" && Buffer.from(entry.body.content, "utf8").toString("base64") === expected && typeof entry.body.revision === "string", `Exact literal content/revision: ${entry.input.label}`)
    }
    if (entry.status === 404) requireFact(entry.body?.name === "FileNotFoundError" && entry.body.data.path === entry.input.query.path, "Original typed broken content404 required")
    if (entry.status === 500) requireFact(entry.body?.name === "UnknownError" && typeof entry.body.data.message === "string", "Original scope-denied list500 required")
    if (entry.input.route === "/file" && entry.status === 200) requireFact(Array.isArray(entry.body), "Actual directory nodes required")
  }
  result.outcome = "original-GUI-readback-content-and-list-contracts-collected-no-visual-claim"
}

try {
  if (mode === "prepare") await prepare()
  else {
    const fixture = await loadFixture(); result.fixtureID = fixture.fixtureID
    if (mode === "primitive") await primitive(fixture)
    else { const owner = await loadOwner(fixture); result.owner = owner; if (mode === "register") await register(fixture, owner); else if (mode === "before-probe") await beforeProbe(fixture, owner); else await readOnly(fixture, owner) }
  }
  result.completedAt = stamp(); result.exitCode ??= 0
} catch (error) { result.outcome = "original-first-error-or-unknown-retained"; result.error = factError(error); result.originalHTTP = error.originalHTTP; result.observation = error.observation; result.failedAt = stamp(); result.exitCode = 1 }
const full = await save(`${label(mode)}.json`, result)
console.log(JSON.stringify({ mode, outcome: result.outcome, exitCode: result.exitCode, fixtureID: result.fixtureID, evidence: full, actualHTTP: result.requests.length, classifications: result.cases?.map((entry) => ({ id: entry.id, classification: entry.classification })) }))
process.exitCode = result.exitCode
