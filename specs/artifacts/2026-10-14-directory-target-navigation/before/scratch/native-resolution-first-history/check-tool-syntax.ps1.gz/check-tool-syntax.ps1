# Only syntax parsing. Does not execute/import any prepared tool or touch its runtime namespace.
$ErrorActionPreference='Stop'
$taskBunDirectory='D:/myhexin-local/opencorvus/.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64'
$env:PATH=$taskBunDirectory+[IO.Path]::PathSeparator+$env:PATH
$taskValidation=Join-Path $PSScriptRoot ('tool-validation/syntax-'+[DateTime]::UtcNow.ToString('yyyyMMddTHHmmssfff'))
$null=New-Item -ItemType Directory -Path $taskValidation
$taskResults=@()
foreach($taskName in @('native-activity-target.mjs')) {
  $taskLog=Join-Path $taskValidation ($taskName+'.log')
  & node --check (Join-Path $PSScriptRoot $taskName) *> $taskLog
  $taskExit=$LASTEXITCODE
  $taskResults+=@{file=$taskName;checker='node --check';exitCode=$taskExit;stdoutStderr=$taskLog}
  [IO.File]::WriteAllText(($taskLog+'.exit.json'),(@{exitCode=$taskExit;checkedAtUtc=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json),[Text.UTF8Encoding]::new($false))
}
$taskHostLog=Join-Path $taskValidation 'native-host.ts.log'
& bun -e 'const fs=require("node:fs"); new Bun.Transpiler({loader:"ts"}).transformSync(fs.readFileSync(process.argv[1],"utf8")); console.log("native-host TypeScript syntax parsed; no imports executed")' (Join-Path $PSScriptRoot 'native-host.ts') *> $taskHostLog
$taskHostExit=$LASTEXITCODE
$taskResults+=@{file='native-host.ts';checker='Bun 1.4.0 Transpiler syntax only';exitCode=$taskHostExit;stdoutStderr=$taskHostLog}
[IO.File]::WriteAllText(($taskHostLog+'.exit.json'),(@{exitCode=$taskHostExit;checkedAtUtc=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json),[Text.UTF8Encoding]::new($false))
foreach($taskName in @('launch-ui.ps1','owned-launch-functions.ps1','shutdown.ps1','check-tool-syntax.ps1','qualify-native-activity.ps1')) {
  $taskTokens=$null
  $taskErrors=$null
  $null=[Management.Automation.Language.Parser]::ParseFile((Join-Path $PSScriptRoot $taskName),[ref]$taskTokens,[ref]$taskErrors)
  $taskExit=if($taskErrors.Count){1}else{0}
  $taskLog=Join-Path $taskValidation ($taskName+'.log')
  [IO.File]::WriteAllText($taskLog,($taskErrors|Out-String),[Text.UTF8Encoding]::new($false))
  $taskResults+=@{file=$taskName;checker='PowerShell Parser.ParseFile only';exitCode=$taskExit;stdoutStderr=$taskLog}
  [IO.File]::WriteAllText(($taskLog+'.exit.json'),(@{exitCode=$taskExit;checkedAtUtc=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json),[Text.UTF8Encoding]::new($false))
}
$taskBunVersion=& bun --version
$taskNodeVersion=& node --version
$taskSummary=@{qualification='syntax only; no prepared entrypoint was executed';bun=$taskBunVersion;node=$taskNodeVersion;results=$taskResults;finishedAtUtc=[DateTime]::UtcNow.ToString('o')}
[IO.File]::WriteAllText((Join-Path $taskValidation 'results.json'),($taskSummary|ConvertTo-Json -Depth 6),[Text.UTF8Encoding]::new($false))
$taskSummary|ConvertTo-Json -Depth 6
if(@($taskResults|Where-Object exitCode -ne 0).Count){exit 1}
