/** PREPARED ONLY. A finite qualification target, never a service heartbeat. */
import assert from "node:assert/strict"
import { performance } from "node:perf_hooks"
const [mode, caseName, occurrence] = process.argv.slice(2)
assert.equal(mode, "--case")
assert.equal(process.argv.length, 5)
assert.ok(caseName === "active" || caseName === "idle")
assert.match(occurrence, /^directory-target-native-(active|idle)-[a-f0-9-]+$/)
assert.equal(process.release.name, "node", "This qualification target must be the admitted real Node executable")
const started = performance.now()
const emit = (index) => process.stdout.write(JSON.stringify({ case: caseName, occurrence, index, elapsedMs: performance.now() - started, pid: process.pid, execPath: process.execPath, nodeVersion: process.versions.node }) + "\n")
emit(0)
if (caseName === "active") {
  let index = 0
  const timer = setInterval(() => {
    emit(++index)
    if (index === 6) clearInterval(timer)
  }, 75)
} else {
  setInterval(() => {}, 1000)
}
