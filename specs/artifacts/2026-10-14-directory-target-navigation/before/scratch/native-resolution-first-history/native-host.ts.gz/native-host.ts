/** PREPARED ONLY. One production foreground owner; Root authorizes every invocation. */
import assert from "node:assert/strict"
import fs from "node:fs/promises"
import path from "node:path"
import { pathToFileURL } from "node:url"
import { randomUUID } from "node:crypto"
import type { ProcessHandle, ProcessRunResult } from "@opencorvus-ai/util/process"

const packageRoot = path.resolve(import.meta.dir, "../packages/opencorvus")
const source = (relative: string) => pathToFileURL(path.join(packageRoot, relative)).href

function diagnostic(value: unknown, seen = new Map<object, number>()): unknown {
  if (typeof value === "bigint") return { type: "bigint", value: String(value) }
  if (typeof value === "symbol") return { type: "symbol", value: String(value) }
  if (typeof value === "number" && !Number.isFinite(value)) return { type: "number", value: String(value) }
  if (value === undefined) return { type: "undefined" }
  if (value === null || typeof value !== "object") return typeof value === "function" ? { type: "function", name: value.name } : value
  const previous = seen.get(value)
  if (previous !== undefined) return { reference: previous }
  const identity = seen.size + 1
  seen.set(value, identity)
  if (value instanceof Uint8Array) return { identity, type: "Uint8Array", bytesBase64: Buffer.from(value).toString("base64") }
  if (Array.isArray(value)) return { identity, type: "Array", values: value.map((item) => diagnostic(item, seen)) }
  const fields: Record<string, unknown> = {}
  for (const key of Object.getOwnPropertyNames(value)) fields[key] = diagnostic((value as Record<string, unknown>)[key], seen)
  return { identity, type: value instanceof Error ? value.name : "Object", fields }
}

// Only run reads child streams. Join every parent write callback, including a final write returning true.
async function forward(bytes: Uint8Array, destination: NodeJS.WriteStream): Promise<void> {
  await new Promise<void>((resolve, reject) => {
    let callbackDone = false, drainDone = false, writeReturned = false, completed = false
    const cleanup = () => { destination.off("error", failed); destination.off("drain", drained) }
    const failed = (error: unknown) => { if (completed) return; completed = true; cleanup(); reject(error) }
    const finish = () => { if (!completed && writeReturned && callbackDone && drainDone) { completed = true; cleanup(); resolve() } }
    const drained = () => { drainDone = true; finish() }
    destination.once("error", failed)
    destination.once("drain", drained)
    try {
      const writable = destination.write(bytes, (error?: Error | null) => {
        if (error) { failed(error); return }
        callbackDone = true
        finish()
      })
      if (writable) { drainDone = true; destination.off("drain", drained) }
      writeReturned = true
      finish()
    } catch (error) { failed(error) }
  })
}

assert.equal(process.argv[2], "--owned-host")
assert.equal(process.versions.bun, "1.4.0", "Reviewed Native Host requires the actual Bun 1.4.0 runtime")
const [hostEvidence, hostOccurrence, hostDeadline, hostInactivity, executable, ...args] = process.argv.slice(3)
assert(hostEvidence && hostOccurrence && executable && args.length)
assert(path.isAbsolute(hostEvidence) && path.isAbsolute(executable))
const deadlineAt = Number(hostDeadline), inactivityTimeoutMs = Number(hostInactivity)
assert(Number.isSafeInteger(deadlineAt) && deadlineAt > Date.now(), "Original future execution deadline required")
assert(Number.isSafeInteger(inactivityTimeoutMs) && inactivityTimeoutMs > 0, "Original positive inactivity input required")
const evidenceEntry = await fs.lstat(hostEvidence)
assert(evidenceEntry.isDirectory() && !evidenceEntry.isSymbolicLink(), "Prepared direct evidence directory required")
assert.equal((await fs.realpath(hostEvidence)).toLowerCase(), path.resolve(hostEvidence).toLowerCase())
const { installProcessShims } = await import(source("src/runtime/shims.ts"))
installProcessShims()
const { Filesystem } = await import(source("src/util/filesystem.ts"))
const physical = await import(source("src/runtime/process-occurrence.ts"))
const { supervisedHostProcessFacade } = await import(source("src/util/process-facade.ts"))
const errors = await import("@opencorvus-ai/util/process")
const host = physical.currentRuntimeProcessOccurrence()
const parent = physical.observedProcessOccurrence(process.ppid)
assert(parent, "Native Host requires its actual supervising parent")
const printLogs = args.includes("--print-logs")
const fact = async (name: string, value: unknown) => {
  const target = path.join(hostEvidence, name), stage = `${target}.${process.pid}-${randomUUID()}.stage`
  const failures: unknown[] = []
  try {
    await fs.writeFile(stage, JSON.stringify(value, null, 2), { flag: "wx" })
    await Filesystem.renameNoReplace(stage, target)
  } catch (error) { failures.push(error) }
  try { await fs.rm(stage, { force: true }) } catch (error) { failures.push(error) }
  if (failures.length === 1) throw failures[0]
  if (failures.length > 1) throw new AggregateError(failures, "Native evidence publication and staging cleanup failed")
}
let phase = "spawn-admission"
let handle: ProcessHandle | undefined
let target: ReturnType<typeof physical.observedProcessOccurrence>
let targetBirthAtMs: number | undefined
let originalJoins: Promise<PromiseSettledResult<unknown>[]> | undefined
let result: ProcessRunResult | undefined
let firstRunError: unknown, runRejected = false
const laterFailures: unknown[] = []
try {
  result = await supervisedHostProcessFacade(hostOccurrence, true).run({
    command: { executable, args }, cwd: path.dirname(hostEvidence), env: process.env,
    stdin: "ignore", stdout: "pipe", stderr: "pipe", ownership: "owned_tree",
    deadlineAt, inactivityTimeoutMs, occurrenceID: hostOccurrence, nothrow: true,
    async onSpawned(original) {
      handle = original
      originalJoins = Promise.allSettled([original.terminal, original.settled, original.outputSettled])
      phase = "target-identity"
      target = physical.observedProcessOccurrence(original.pid)
      assert(target, "Native Target must be observable at ready admission")
      assert.equal(physical.observeRuntimeProcessOccurrence(target), "exact_live")
      targetBirthAtMs = Number((BigInt(target.processInstanceID.slice("win32:".length)) - 621355968000000000n) / 10000n)
      await fact("native-host-ready.json", { occurrence: hostOccurrence, outcome: "ready", host, parent, target,
        targetBirthAtMs, deadlineAt, inactivityTimeoutMs, printLogs, hostExecutable: process.execPath, hostBunVersion: process.versions.bun, observedAtUtc: new Date().toISOString(), executable, args,
        authority: "Original production foreground run/onSpawned handle; run alone consumes child streams; no detached transfer" })
      phase = "whole-job-output-request-settlement"
    },
  })
} catch (error) { firstRunError = error; runRejected = true }

// An execution-error prefix is retained but never represented as a complete run result.
let bytes: { stdout: Uint8Array; stderr: Uint8Array; complete: boolean; origin: string } | undefined
if (result) bytes = { stdout: result.stdout, stderr: result.stderr, complete: true, origin: "ProcessRunResult" }
else if (firstRunError instanceof errors.ProcessExecutionError)
  bytes = { stdout: firstRunError.stdout, stderr: firstRunError.stderr, complete: false, origin: "ProcessExecutionError observed bytes" }
else if (firstRunError instanceof errors.ProcessRunFailedError)
  bytes = { stdout: firstRunError.stdout, stderr: firstRunError.stderr, complete: true, origin: "ProcessRunFailedError" }
else if (firstRunError instanceof errors.ProcessAbortedError || firstRunError instanceof errors.ProcessDeadlineExceededError ||
  firstRunError instanceof errors.ProcessInactivityTimeoutError || firstRunError instanceof errors.ProcessOutputLimitError ||
  firstRunError instanceof errors.ProcessOutputObserverError) {
  if (firstRunError.result) {
    result = firstRunError.result
    bytes = { stdout: result.stdout, stderr: result.stderr, complete: !(firstRunError instanceof errors.ProcessOutputLimitError), origin: firstRunError.name + ".result" }
  }
}
if (runRejected) {
  try { await fact("native-host-run-error.json", { occurrence: hostOccurrence, phase, observedAtUtc: new Date().toISOString(), firstRunError: diagnostic(firstRunError), bytesOrigin: bytes?.origin }) }
  catch (error) { laterFailures.push(error) }
}
const joins = originalJoins ? await originalJoins : undefined
if (joins) for (const join of joins) if (join.status === "rejected") laterFailures.push(join.reason)
const outputFacts = bytes ? await Promise.allSettled([
  fs.writeFile(path.join(hostEvidence, "native-host-stdout.bin"), bytes.stdout, { flag: "wx" }),
  fs.writeFile(path.join(hostEvidence, "native-host-stderr.bin"), bytes.stderr, { flag: "wx" }),
  forward(bytes.stdout, process.stdout), forward(bytes.stderr, process.stderr),
]) : undefined
if (outputFacts) for (const item of outputFacts) if (item.status === "rejected") laterFailures.push(item.reason)
const terminalJoin = joins?.[0]
const terminal = terminalJoin?.status === "fulfilled" ? terminalJoin.value as ProcessRunResult["receipt"] : undefined
const complete = Boolean(handle && target && joins?.every((item) => item.status === "fulfilled") && bytes?.complete && outputFacts?.every((item) => item.status === "fulfilled") && laterFailures.length === 0)
const receipt = { occurrence: hostOccurrence, host, parent, target, targetBirthAtMs, observedAtUtc: new Date().toISOString(),
  deadlineAt, inactivityTimeoutMs, printLogs, terminal, runOutcome: runRejected ? "rejected" : "returned",
  firstRunError: runRejected ? diagnostic(firstRunError) : undefined,
  originalJoins: joins?.map((item, index) => ({ kind: ["terminal", "settled", "outputSettled"][index], ...item, ...(item.status === "rejected" ? { reason: diagnostic(item.reason) } : {}) })),
  bytes: bytes ? { origin: bytes.origin, complete: bytes.complete, stdout: bytes.stdout.byteLength, stderr: bytes.stderr.byteLength } : null,
  outputFacts: outputFacts?.map((item, index) => ({ kind: ["stdout-file", "stderr-file", "stdout-parent-forward", "stderr-parent-forward"][index], status: item.status, ...(item.status === "rejected" ? { reason: diagnostic(item.reason) } : {}) })),
  laterFailures: diagnostic(laterFailures), phase,
}
try {
  if (complete) await fact("native-host-settled.json", { ...receipt, outcome: "settled", physicalCompletion: true, outputDrainComplete: true, requestCleanupComplete: true,
    authority: "Original fulfilled run handle terminal/settled/outputSettled and full original byte persistence/parent writes; controlled terminal reason retained" })
  else await fact("native-host-error.json", { ...receipt, outcome: "failed", physicalCompletion: false, outputDrainComplete: false, requestCleanupComplete: false,
    authority: "Original observation/run/settlement incomplete; first error and all causes retained; no physical completion claim" })
} catch (error) {
  await fs.writeFile(path.join(hostEvidence, "native-host-receipt-error.json"), JSON.stringify({ occurrence: hostOccurrence, receipt, error: diagnostic(error) }, null, 2), { flag: "wx" })
  process.exitCode = 1
}
if (process.exitCode !== 1) process.exitCode = complete && !runRejected && terminal?.reason === "exited" ? (terminal.exitCode ?? 1) : 1
// Natural Host exit retains any still-owned producer after uncertain settlement; never force-exit or kill it here.
