# current Move guard 产品 diff：独立只读复核

## Recall 与范围

Root 已冻结 `specs/records/2026-10/2026-10-14-directory-target-navigation.md` 的 current guard 合同，授权本 agent 只读 `src/util/file-entry.ts` 与 `src/file/index.ts` 产品 diff。禁止再次委托、产品/测试/spec/Git 修改及执行任何服务、测试、UI（User Interface，用户界面）、模型或新 qualification。本报告仅新增到本 owned scratch；没有执行功能验收。开始/结束只读检查 Git 状态，保留 Root/其它 owner 的变更。

已读冻结23–37行、File完整diff、新129行helper全文、guard最新1195–1266行、Move1450–1491行、现error-handler映射、唯一调用搜索与打包依赖位置。复核中Root另补 `sourceFile`/source missing404并格式化；本报告按**最后读到的**版本写，不将最初草稿视为最终问题。File最后完整diff为116+/31-，其中status/read-preview/strict-copy等hunks是格式变更，未发现语义扩张。

结论：**没有确认的 P0/P1/P2 guard 功能阻断。** namespace/entry/precedence方向符合当前正式scope；下面两项P3只是诊断资格界限，不冒称真实Windows故障或必须先完成future-tree才可验current guard。后态真实TCP（Transmission Control Protocol，传输控制协议）、production loader和桌面图由Root负责，本审阅不称通过。

## 准确 entry、native绑定与 cause

- `file-entry.ts:12–18/47–48` 用 address + dev/ino/birthtimeNs/type bits共同匹配，保BigInt精度；不是裸inode或同 ultimate D 合并。`index.ts:1181` 的源lstat也是BigInt，原 snapshot传到Move guard，copy/remove仍只消费entry predicates，公开Node五字段无BigInt泄漏。
- Windows `file-entry.ts:33–37/90–115` 对原input开0access/share7/OPEN_EXISTING/OPEN_REPARSE_POINT|BACKUP_SEMANTICS，同一原handle取TagInfo与normalized-DOS final name；tag0普通、`0xa000000c` symbolic、`0xa0000003` junction；未知tag或reparse属性异常明确ENOTSUP。没有名字关键词/最终target/另一FFI（Foreign Function Interface，外部函数接口）fallback。
- get-name size→实际allocation→同capacity read，written不足/越界或NUL异常拒绝；UTF-16（Unicode Transformation Format, 16-bit，十六位字符编码）按原长度解码，不用ASCII或lowercase改名。源/候选两个地址均取同API的stored name，原大小写/实际8.3资格支持这一方向；没有再调用会follow terminal的normalizeCanonicalPath。
- `file-entry.ts:42–43` 核对原path与returned address的两个真实BigInt lstat，防止返回另一个entry或简单观察变化当witness。种类与lstat不一致、identity变化明确ERR_FILE_ENTRY_CHANGED500，不当普通或独立成功。
- `file-entry.ts:54–74` 用现requireRuntimePackage加载Koffi3.3.2，opaque HANDLE大小据库sizeof，标准stdcall/两个DWORD struct/_Out_ UTF16。kernel/functions模块引用保持lifetime，不挂Computer DPI（Dots Per Inch，每英寸点数）或新进程，不复制安装目录。`package.json:129`与build-artifact:63/167已经单源提供Koffi及对应Windows native包；裸库16×2资格仍不能替代新production helper实际加载。
- open失败未获得validhandle，直接原native error；validhandle的主体try/finally一次Close。`file-entry.ts:116–127` 保原JS/FFI error对象；single failure原throw，主体+close双失败为同两个原references的AggregateError，cause是第一个。Close不覆写先前tag/name/buffer失败；success+close failure也不会返回伪success。
- `failure:79–86` 在每次false/zero native返回之后直接GetLastError；中间没有另native调用。成功stale lastError无须充当错误事实。原Win32 errno/syscall/path均在错误上保留。

### P3：并行 post lstat 的诊断收齐资格有限

`file-entry.ts:42` 当前 `Promise.all` 对 after/addressed 两I/O（Input/Output，输入输出）采用fail-fast：任何一项reject会保该原reason并拒绝准入，但若两项都reject，不会合并第二个reason，也不保证helper拒绝时另一个Promise已经settled。代码证据足够说明此限制；本任务没有自然触发双失败，不能写成已复现泄漏或两个原cause都已收齐。

这两项是Node内部lstat，原Win32 handle已在它们开始之前Close，failure路径不进入rename；当前没有已证资源泄漏、错误放行或错误400。冻结合同要求native主体/Close双因（已满足），没有声明这两项全部I/O聚合。若Root扩大“全部观察均完整结算”的合同，可选串行真实lstat或成熟allSettled聚合；本审阅不复制collector、不改产品，不将其包装P1发布缺陷。

### P3：native query/name 的 missing 分类是未验界限

同一个 `failure:82` 给CreateFileW、TagInfo、GetFinalPathName、Close的errno2/3都标ENOENT。后续source catch:1202–1204会把此code转404，parent catch:1257–1263转parent-invalid400；Aggregate双因不会被isMissingPathError吞掉。原有限资格的Win322事实来自CreateFileW missing entry，未证明name/query/Close返回这些errno时与“entry/parent已不存在”完全同义。

这不是已复现的400误分类；当前限定local普通/SYM/J案例没有这些native失败。需要将这条实际classifier资格与“unknown query/name/Close原error”的交付说明分清。若未来要覆盖UNC（Universal Naming Convention，通用命名约定）/卷名读取失败，成熟最小方向是missing只在能证明entry lookup missing的operation归类，其他操作保raw WIN32码/cause；不根据message关键字猜。当前没有在本审阅执行或要求新错误实验。

## 唯一 inspect 的 namespace、dot 与 finite/cycle

`index.ts:1207–1253` 当前一条私有inspect。active key为当前完整operand，是本次namespace+完整remaining的编码；namespace变量与未消费components保本次前进状态，没有globalentrycache/completedshadow或第二路径resolver。

- Windows1208/1240–1241按当时namespace每stage path.resolve；原四种v的`v/../goal`会在expanded stage折掉v，不错误记录为source依赖；不是遇missing再换坐标。
- 每个实际candidate先readFileEntry并source exact witness比较，再展开link；实际命中source直接400，原newPath/固定message1230–1231，不按同D拒绝独立alias。
- symbolic1245/1248用target递归**返回namespace**继续原suffix；S→B/J返回B/J，S→B/T→D/data返回D/data。junction也检查其实际declared target，但1248保外层candidate；没有用其最终physical D覆盖relative anchor。这与两mixed实际结果一致。
- POSIX1242–1244保raw readlink组件，只有实际dot组件1222–1223调用mature native realpath当前namespace+dot；不提前用path.resolve擦掉link/..，不把反斜杠split成separator。current普通dir各步namespace已由此前SYM展开；没有把Windows规则外推。
- `active.delete`在finally1251–1252，throw也退休该递归状态。finite `root-link/root-link/child`的target分支返回后可以再观测同目标；不同remaining不按重复inode误判循环。exact同active operand才抛明确validator ELOOP诊断，其Error/code/path不是伪造已执行syscall。初始existing parent的native preflight仍可更早给真实ELOOP；应由真实checker记录实际阶段。

静态手动对照现actual fixed dot/mixed与前两个ancestor差异未发现反例。本审阅没有运行新helper，因此不能把上述逐源码对照称FileRoutes已通过。POSIX/Mac、无限外部retarget、全部网络/其它tag仍未取得真实资格；外部retarget原子性不在当前guard承诺。

## Precedence、正常发布与影响面

- 原 `assertFileMutationPaths:1171–1191` source/target一般准入、root/parent、source missing与两physical root顺序保留。terminal link本体例外不改；ordinarysource移进自身或实际后代会在目的access chain碰到同source entry，用同guard400而非新增ultimate self-directory gate。
- Move1462–1467为唯一strict destination lstat：existing健康/danglingentry409先于新依赖400；仅knownmissing继续，unknown直接throw。旧Move的access/false调用已删，Copy/create/global Filesystem.exists仍保原scope。原native晚EEXIST仍1484–1486映射409。
- 最新source重新观察knownmissing1202–1204→FileNotFoundError404原source path；parent/hop knownmissing1257–1263→parent-invalid400原newPath；changedentry/ELOOP/ENOTSUP/未知I/O不是false或success。已存在目标409使新source metadata读取不抢占conflict。
- 新guard在旧sharedrelocation之前；后者original current.file错误400/两目标检查仍未修。最后唯一renameNoReplace1483、notify1490、原nodeForPath/publicreceipt不变，没有把新physical namespace当renameoperand或改变editor成功协调。
- search定义调用：readFileEntry/sameFileEntry产品只有File这一个consumer；guard只有Move调用。sourceBigInt仅共有准入返回kind的类型变化；新immutablelibrary缓存没有entry事实缓存，两个Project/currentInstance请求各有自己的source snapshot和active集合。无Task/Mission/Session occurrence状态、恢复/重试队列修改，不把HTTP局部验收称其端到端。

相邻完整diff的status/preview/validateCopiedTree formatting不改变argv/timeout/读/比较；未发现foreign语义被覆盖。不存在UI/SDK/Node字段改动或新fallback。

## 最小验收与最终资格

Root目前正在写真实positive TCP checker并准备独立service UI；该事实不是本agent跑过或已过。必须保原before/after以及healthy/dangling409 precedence、selfJ/S/indirect400/source bytes与identity、independent同D200/newraw address、mixedJ/S、Windows dotfold合法、ordinary selfdir、finite rootback、broken、root、两Project等实际结果。自然cycle/unknownI/O若没有实际可安全输入，明示unknown，不用注入emit/假nativeerror代替。

本次129行adapter加73行私有guard没有扩成future树框架、NTFS parser、sidecar或新配置；当前必需的native kind+ownname facts与访问状态都在单源。额外读源/每个prefix metadata及两个身份复核会有真实I/O成本，本任务没有测量量化影响，不能凭源码称性能无回归；真实TCP/服务原预算可先验证本有限场景。

已确认范围内代码方向可继续Root当前验收；**无已确认阻断项**。sharedrelocation/futuretree与完整目录link UI仍未交付，Mac/hardlink/case-sensitiveWindows/network/provider/外部原子性和两条P3诊断范围未被本审阅排除。没有新产品修改、执行、委托、暂存、提交或push。
