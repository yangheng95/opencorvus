# File relocation：最小真实 TCP 正向合同矩阵

## Recall / 当前资格

Root 要求只读复核 assertFileMutationPaths、assertRelocatedSymlinkTargetsAllowed、Move/Copy 和已交付 link/root 契约，利用本轮真实 dot/mixed 资料列出后端聚焦正向矩阵。此次未执行 fixture、API（Application Programming Interface，应用程序接口）、服务、模型、库探针或测试；未修改产品、测试、正式规格、Git；没有 UI（User Interface，用户界面）自动化搜索或执行，没有再次委托。唯一当前产物是此 scratch 建议；后续新工具仅 prepare-only，须另审/另授运行。

TCP（Transmission Control Protocol，传输控制协议）合同使用真正 loopback listener + fetch → FileRoutes → Instance.provide → 当前 File 生产函数。不是 Hono app.request、静态字符串断言或 mock。该级别证明生产 FileRoutes/权限/physical 状态，不冒充完整 server startup、桌面交互或 Provider 验收。

已读完整相关源码和函数顺序、server错误映射、link/root两现功能test、memoryProject、原8API前态 raw/分类、两native hop对照、Node25.7/Bun1.4各32原dot/mixed读取。正式资料为 `2026-10-13-file-link-entry-contract.md`、`2026-10-13-explorer-copy-convergence.md` 根保护实施合同、当前 `2026-10-14-directory-target-navigation.md`。全仓搜索未找到名为 file-mutation-root-contract 的独立spec；同名是现测试 `packages/opencorvus/test/file-mutation-root-contract.test.ts`，不可伪称另有规格树。

**当前源码没有 Move retirement dependency guard；因此下面 D 组的400是已落方向的正确新合同，尚未实现/实测。** 现8原API已证明3个源依赖目的地发布后404。新mixed/dot依据native读语义提出真实API资格，不把它们提前写成API通过。

## 当前顺序、身份与公开响应

源码 `packages/opencorvus/src/file/index.ts:1151–1190`：raw空source先动作root错误；target basename；一般source allowed；target allowed/existing parent；两词法权限根source保护；source lstat；terminal link返回原entry；非link source实体等于directory/worktree才root错误。各未知 I/O（Input/Output，输入输出）原throw；已知ENOENT/ENOTDIR映射公开missing。根保护只保护source，不阻止普通子文件newPath位于合法根。

Move 1376–1411：上述共同准入 → `Filesystem.exists(targetFull)` conflict → shared relocation → 原renameNoReplace → notifyEdited → lstat entry receipt。Copy 1413–1500：共同准入 → source实目录copy进自身400 → exists conflict → shared relocation → cp(verbatimSymlinks=true,dereference=false) → 原strict validateCopiedTree → 原noReplace staging发布 → strict再次验证 → notify/entryreceipt。不是统一“所有409最先”；一般准入/root/selfcopy先后须保。

重要细节：Filesystem.exists 目前是fs.access，follow终端dangling，可能false；普通已有dangling destination的409由后续native noReplace EEXIST得来。已交付test覆盖该409。但“dangling destination + dependent parent”这一双条件没有原API实证；新guard若放在native rename前可能先400，不能擅称它已有同样409优先。健康existing target的409先于relocation已经代码明确。建议正式规格先决定新dependencyguard与**entry conflict**的完整优先级，再补该组合old实际响应；不能只凭exists函数名改变合同。此项需root决定/有限资格，不在此次跑。

公共输出模板（request原path字符串保真，Node为path.join后的逻辑entry）：

- `PATCH /file/item {path:S,newPath:T}`200：`{previousPath:S,path:T,node:{name:basename(fullT),path:relative(scope,fullT),absolute:fullT,type:entryDirectory?"directory":"file",ignored:现matcher结果}}`。
- `POST /file/item/copy {path:S,newPath:T}`200：同结构，以sourcePath:S代previousPath。复制link/目录link回执仍type=file，成功不承诺target可读。
- 新源退休依赖错误：400，`{name:"FileInvalidPathError",data:{path:原T,message:主spec冻结的依赖错误文案}}`。错误path是newPath，别改成canonical地址或source。现实现尚无此文案，不凭本报告猜已有exactmessage。
- source/current或future declared-target权限错误：400，name=FileInvalidPathError，data.path是当前被审link的原source子路径（整树为source/path/to/link）；保现两种message语义或主spec统一后正式冻结，不能把target newPath套入该错误。
- conflict：409，`{name:"FileConflictError",data:{path:原T,message:"File destination already exists: "+T}}`。
- missing：404，`{name:"FileNotFoundError",data:{path:原被请求path,message:"File entry not found: "+path}}`，内容missing也按当前content合同。root错误按动作source原path保持现message。
- 未知读/metadata/native I/O 的真实500保持当前server错误边界，不转换成false/未ignored/400。此处没有安全可确定的真实IO输入，暂不制造mock/error注入覆盖。

正向状态：source/target原lstat bigint dev/ino/kind + 原readlink全文 + 实体parent/entry地址 + 所有literal完整Buffer字节。Move新entry等于原source identity，Copy保原source并新entry具有正确kind/readlink/bytes；**不要求copy新ino数值或以ino相等/不等判断copy成败**。不同hardlink同ino但不同entry地址独立，不能用targetultimate equality判依赖。

## 已有原事实怎样约束预期

原8case `fixture-before-probe-02-original.stdout.log`：j-self/s-self/s-dependent实际PATCH404，原entry已在实体data/moved发布；独立A/B alias及normal relative200可寻址。relative Move/Copy通过raw root-back alias的内容为A/aliases/project-b，**同terminalentry在实体A/{moved,copied}-relative的目标是独立Project B**。原classification targetOutsideScope=false仅描述raw读，不能作为实体future准入通过。

`hop-qualification-results.json` 两原native noReplace操作：dir SYMLINK祖先case原目标raw路径发布后entry可寻址，junction祖先case原raw目标ENOENT而同inode实体entry已发布。两case都返回native成功，marker完整。因此保持独立alias200以及拒退休dependency400是共同目标，不能粗拒same ultimate target。

dot/mixed 读取原fixture ID `df2ea0df-f134-4503-aea1-a2597ff25c9e`，Node/Bun共32条各自原记录：

| 真实输入 | 两host完整读结果 | 新合同意义 |
| --- | --- | --- |
| stored u.raw=`v/../goal`，v为ordinary、absolute directory SYMLINK、junction或broken absolute SYMLINK | u与未提前fold的raw-access均各自tree/goal全文；broken v自己stat=ENOENT、u仍tree/goal | Windows在该relative替换stage先fold掉v。dependency walk不能再对已取消的v判退休或先查询broken v而拒成功 |
| S absolute SYMLINK→B-context/J，J junction→D/data，D/data/r.raw=`../goal` | S/r= B-context/goal全文；direct D/data/r=D/goal全文 | 绝对SYM引入的返回namespace中junction保外层context；不能用ultimate D覆盖 |
| S absolute SYMLINK→B-context/T，T absolute SYMLINK→D/data，同r.raw | S/r与direct均D/goal全文 | 后一个absoluteSYM继续重置prefix，不能freeze第一次S.text |

这里B-context是同一个fixture内的目录名，不是独立Git Project B。报告后续跨Project权限测试使用独立A/B根，禁止把这两个B混同。

## 新增最小矩阵：D / retirement dependency

每mutation独立source/目标，一次原请求；不靠retry成功/失败证明主要行为。所有source绝对指A/data且data/marker为预声明CRLF literal，target目录当前都在A权限内；Move guard不是copy guard。以下组须在新的owned A/B projects中执行，绝不重放旧8已consumed inputs。

| ID / 明确输入布局 | 请求与正确输出 | 必须同时证明的正向状态 |
| --- | --- | --- |
| D1 direct junction self：A/source-j junction→A/data；newPath=`source-j/moved-j` | Move400/FileInvalidPathError.path=`source-j/moved-j` | A/source-j同原lstat dev/ino/kind、readlink全文；A/data/marker完整；GET/list仍给原source-j entry；不是发布后404 |
| D2 direct absolute directorySYM self：source-s→A/data；newPath=`source-s/moved-s` | Move400/path=原newPath | 原source-s entry/readlink和data marker完整；保type=file，不能把健康dir target改source kind |
| D3 indirect：A/context/indirect-relative.raw=`../source-j`；newPath=`context/indirect-relative/moved-j` | Move source-j → newPath400/path=newPath | source-j/context relative alias各原identity/readlink；marker完整。证明依赖经另link到source entry，非仅词法prefix |
| D4 independent junction alias→sameA/data | Move source-j→`alias-j/moved-j`200完整模板 | newphysical A/data/moved-j同原source-j inode/dev/readlink；raw请求entry可寻址，alias-j原identity保；list(alias-j)返回新link，GET alias-j/marker全文 |
| D5 independent absolute directorySYM alias→sameA/data | Move source-s→`alias-s/moved-s`200完整模板 | same-source identity发布、rawaddressable、alias-s保原identity、marker完整。与D2同target但不同entryaddress |
| D6 mixed pair：A/contextB/goal为退休source→A/output；A/D/goal是独立alias→同output；D/data/r.raw=`../goal`；S absoluteSYM→contextB/J或contextB/T，J junction/T absoluteSYM→D/data | source=`contextB/goal`,newPath=`S/r/moved`；J分支400/path=newPath，T分支200 | J：保source原identity+output marker；T：newraw entry和A/output/moved同原source身份，D/goal独立entry保真。此pair依据已读mixed32，但该mutation组合尚未实测，不能提前assert旧态通过 |
| D7 Windows cancelled-dot：tree/v为退休absoluteSYM→A/data；tree/goal独立alias→data；tree/u stored dirSYM.raw=`v/../goal` | Move `tree/v`→`tree/u/moved`200 | 原v身份发布到data/moved，u的rawtext保，tree/goal独立entry保，rawtarget可寻址/marker正确。若validator只逐字分量查v会误400 |
| D8 Windows cancelled broken v：tree/v broken absoluteSYM→A/missing；tree/goal健康alias→data；u同raw | Move v→u/moved200；新内容GET=FileNotFoundError404 | 新terminalentry同旧v身份/readlink，u/goal和data marker完整。原dot32证明fold允许避开brokenv；这是当前guard需保的FileRoute新组合，尚待真实API |
| D9 conflict优先：健康合法target已在dependent parent下存在，literal=`DEST EXISTING\r\n` | Move400条件同时存在，但existing healthytarget使409/path=原newPath | source原identity/readlink+existingtarget原identity/fullbytes，现exists409路径保真。普通dangling409沿现suite；dependentparent+dangling双条件先补实际old资格/主spec决定 |
| D10 ordinarydirectory source→source自身子目录（source-tree/sub/moved） | 若主spec用同retiring-ancestor规则，Move400/path=newPath | source-tree原directory identity、完整note与成员名；该新目录ancestor合同需主specfreeze，不能沿旧native错误猜500/400。Copy既有selfcopy400独立保持 |

最小本轮Current Move实现建议先 D1–D5（5mutation）+D6两参数（2）+D7/D8（2）+D9（1），总10原mutation。D10待主spec完整确定目录ancestor边界再加入。**这不是授权运行预算**；Root当前有限after tools只含D1–D5所需基础entries，D6–D8要独立批准扩 fixture，不能偷偷填入根指定512B提案。

如果未来原handle GetFinalPathNameByHandle资格提供实际entry长名/case/8.3同entryaddress，再加实际返回名称的同source依赖400对照与独立hardlink同ino200；不造8.3名字、不凭文件名推tag。该native身份资格尚未完成，列为未满足项，不扩平台全量研究。

## R / shared current 与 future实体 declared-target 权限

此组验证现move/copy共享relocation完整范围，两动作各用新独立source。Windows source访问namespace与**nativeMove未来实体entryparent**是两个不同被验证对象；未来准入不能只用原rawalias目标推断。通过shared源函数覆盖整树，不能只增加terminal两个修补点。

| ID / 原输入 | Move / Copy明确正向输出 | 全状态与资格边界 |
| --- | --- | --- |
| R1 原声明本身外域：A/from/link相对指向独立B的existingmarker（布局层级按真实两个根生成text） | 400 FileInvalidPathError.path=source/link | source sameentry/readlink；A/B marker完整；B ownscope GET200。一般isPathAllowed若已拒source仍是现400，不假称sharedfunction分支已覆盖 |
| R2 future实体parent外域，重现原relative alias：A/from/link.raw=`../project-b`，源指A/project-b，newPath=`aliases/root-back/moved`，root-back→A；rawfuture对照A/aliases/project-b，physicalfutureA/moved指run/project-b=独立B | 两动作400/path=原source link | source sameentry/readlink；A当前target、A词法control与B marker完整；B ownscope读200。这是本轮旧200暴露的shared修复新合同 |
| R3 source通过alias的实体parent差异：同一relativeentry经raw路径在A逻辑control内，而实际entryparent声明指B；target新位置保持A | 两动作400/path=原source访问字符串 | source.entryaddress/devino/readlink保真；rawcontrol A和真实B字节都保。该反向source组合未真实API，不把source原isPathAllowed(currentraw)通过当实体声明合格 |
| R4 已知missing future target在权限域内；link现健康，搬浅后relative指A/missing | 两动作200，entrytype=file，content404/FileNotFoundError | 原目标完整bytes；Move新sameentry，Copysource保+newreadlink相同。missing不是外域，也不是mutation404，现link-suite已覆盖该基本合同 |
| R5 healthy in-domain retarget：source/link.raw=`target.md`，源folder与目的parent有不同literal | 两动作200，content200=目的parent真实newmarker | 源/目的两个实体target原devino及完整不同bytes；readlink原文，source/future同时合法；revision由真实content唯一产生，不自行重算 |
| R6 整tree包含normal note、relative file/dir link、broken file/dir、absolute in-domainlink；目标经过独立目录alias | 两动作200，node.type=directory | 源tree和每子entry原snapshot；Move整tree/newchildren同原identity；Copysource整snapshot保、新tree exact成员名/kind/readlink/所有literal bytes，含broken content404；现strictchecker仍工作 |
| R7 整tree内一relative子link current实体声明外域，根本身普通directory合法 | 两动作400/path=`tree/nested/link`（按现sourcefile拼接） | tree根/全children identity/readlink/bytes原snapshot；A/B marker全文。证明current分支真的walk到nested，避免root allowed已拒source的假覆盖 |
| R8 整treecurrent允许、future实体nestedparent声明外域，未来普通tree与internal link同搬；含component-link/.. storedtext | 两动作400/path=该原nested source path；或200+预声明in-domain真实target，取正式input各自合同 | 须在新pre声明双literal目标和futureoverlay中精确资格。Windows32只证明当前stagefold/mixednamespace，不证明未发布virtualtree解析；不能将existingparent realpath+suffix视已完整根治。尚未完成futuretree设计/实测，Root分批则明确暂不关闭 |

R1/R2/R3/R7参数2动作共8，R4/R5/R6参数2动作共6。实施sharedrelocation本批至少R2两动作、一个R3反向、R6两动作、R7/R8独立tree权限对照；现成熟R1/R4/R5/R6基本例不另复制测试。R8若无法在有限qualification中收敛，报告精确未满足，不能把“current Move guard完成”改称全部relocation完成。

## E / 现成熟合同回归（复用，不新写重复矩阵）

- file-mutation-root-contract：raw空、`.`/`folder/..`/`missing/..`、directory/worktree两roots、ancestorjunction到根、scope itself junction及末尾separator按实际lstat；三动作exact400 source root message+root marker/devino保；普通child目标根`./copy.md`/`folder/../moved.md`200完整receipt与bytes；绝对/NULL/permission400和missing404。新guard不能改变准入先后。
- file-link-entry-contract：healthyfile/dirSYM/junction的copy/move200；已brokenfile/dir/junction move/copy/delete200和content404；retarget/fullbytes；terminalrootlinkcopy200；已externalhealthy/brokensource400；sourcefutureexternal声明400；ordinary/dangling existingtarget409；普通整树healthy/broken完整copy/move；childscope父worktree合法200；两个Project并行metadata/rules/通知。
- file-ignore-coordinate-contract：mutationreceipt仍是entryhint/type，原logicalworktree coordinate与outside-domain维持单一matcher；新dependencyvalidator不产第二ignore事实或targetcapability。

root/content/git的邻接测试在相关源最终修改后由Root安排聚焦；此次不运行。没有新增ListingNode/SDK（Software Development Kit，软件开发工具包）/target浏览测试，这些能力仍后批。rawlabel、文件名空白/Unicode/大小写必须字面保真；依赖新sourcephysicalkey不翻译文件身份。

## 单一成熟 helper 与记录方式

推荐在当前 `file-link-entry-contract.test.ts` 的同一project/api/identity/linkIdentity/exactBytes/node/published/invalid/missing helper下新增本批参数case；helpers是文件私有的，**不能假称可跨testfile import复用**。若Root另需独立testfile，先抽取已证重复的realTCP fixture单一实现而非复制第三份helper；本次没有抽取授权/改动。`memoryProject(seed)`会真git init/config/commit，且使用owned managed fixtures；两个不同seed冻结不同Git root identity，assert ProjectID set size=2，Bownscope真实读marker。

api helper现创建真实Bun.serve loopback port0+Hono FileRoutes，fetch经Instance.provide，现serverErrorResponse；dispose原server.stop/Bus unsubscribe。Bus成功观察使用现waitForEdits，验证真实file与`{kind:"host",cwd:scope.directory}`；不新增“不发事件/不调用rename”核心断言，不把事件序列当mutation唯一成功证据。roottesthelper缺content方法，不另开假listener。

每case原输入先记录JSON，capture source/declared targets publicscope/entryaddress/lstat/readlink/所有literalbytes；HTTP保method/route/body、status/headers/requestID、完整response bytes和parseerror（现helper仅response.json，若Root需要全bytes证据须升级这一唯一helper或独立standalonechecker，不能声称现已有完整rawpersist）。本轮真实工具保存raw比测试console更强，两个证据层分别说清。

400/409的主断言是准确typedresponse和retained完整source/targetstate；200主断言是准确receipt、entryidentity和完整bytes/实际可寻址读。oldsource retired用真实404错误合同，broken target用内容404合同；不以exists=false、mock未调用、字符串“不包含”或影子缓存状态作核心。

新fixture保tiny且独占、case之间不重试同mutation；成功/明确错误都保首次原结果。未知metadata、closefailed、cycle/permission无法安全稳定触发时保unknown，不更换error当期望。当前Node/Bunmetadata裸库已资格不等于productionloader、FileRoute或全树future通过。没有本任务新增任何实时运行事实。
