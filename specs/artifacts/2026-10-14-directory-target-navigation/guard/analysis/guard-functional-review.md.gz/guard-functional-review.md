# Current Move guard — 首轮功能证据只读复核

## Recall 与结论边界

Root 授权本 agent 只读首轮原完整日志、两份真实 FileRoutes 测试、新 helper/产品 diff，输出本 scratch JSON/Markdown。没有再次委托、执行测试/服务/API/模型/UI、修改产品/测试/spec 或 Git。已完整读原 log 全部328条结构化记录和65条其余非空行，原始错误响应逐条归入实际通过的 case；同时读新 helper 全文、File diff、link test 全文/178行新增和 root test 全文。

**首轮实际48pass/0fail、628次expect；188条真实HTTP全部可归类，未发现本轮原日志中的未解释运行异常。** 这是原 `guard-functional-first.log` 对原执行时版本的资格。Root 告知随后调整诊断错误聚合并安排最终重跑；当前审阅 helper 已包含 `Promise.allSettled`/`AggregateError`，不能拿这份首0覆盖后来的代码或18456正式页面。

完整派生清单在 `guard-functional-review.json`：188条HTTP ledger、78组实际scope对象、48个原pass行、94条原link identity、42条完整marker观测、4条terminal entry和全部非JSON日志行均带原行号。它是原日志的结构化分析，**不是新生成的运行回执**。

## 原命令、退出和计数

原日志：`guard-functional-first.log`，180077B；命令为 `bun script/run-tests.ts test/file-link-entry-contract.test.ts test/file-mutation-root-contract.test.ts`。Bun实际banner为1.4.0。独立 `guard-functional-first.exit.json` 为 exit0，UTC `2026-10-13T20:22:18.9919935Z`。

| 文件 | pass/fail | expect | Bun报告时长 | runner原时长/exit | 实际HTTP |
|---|---:|---:|---:|---:|---:|
| file-link-entry-contract.test.ts | 30/0 | 334 | 113.98s | 114.70s / 0 | 130 |
| file-mutation-root-contract.test.ts | 18/0 | 294 | 129.50s | 129.71s / 0 | 58 |
| 合计 | 48/0 | 628 | 两原子运行分别保留 | 两个原exit0 | 188 |

原 typecheck 命令是 `node --max-old-space-size=8192 node_modules/typescript/bin/tsc --noEmit`；日志75B，独立退出为0，UTC `2026-10-13T20:19:18.0236244Z`。它只证明该首轮类型检查，不是功能或视觉资格。

| 实际状态 | link | root | 合计 | 原错误类型 |
|---|---:|---:|---:|---|
| 200 | 91 | 7 | 98 | 实际成功回执/内容/list |
| 400 | 13 | 48 | 61 | FileInvalidPathError |
| 404 | 22 | 3 | 25 | FileNotFoundError |
| 409 | 4 | 0 | 4 | FileConflictError |

link 原logger明确记录 DELETE7、GET66、PATCH42、POST15；130条均有requestID字段，其中39个错误响应有真实ID、91个成功响应为null。root 原logger记录 action copy18/delete20/move20，**没有**原method/route/requestID字段；JSON不伪造这些字段。两个testhelper均实际 `Bun.serve(127.0.0.1,port0)`＋`fetch`→Hono FileRoutes→`Instance.provide`，没有 app.request/mock 或UI页面。

新10个guard相关pass项对应31条HTTP：200×22、400×6、404×1、409×2。其余是原link/root正向回归；同一原请求在D矩阵多个目的中引用，不重复计数。

## D1–D10 原结果与证据强度

以下行号均指首轮原 log，不是源码断言测试。

| 矩阵 | 原实际结果 | 原物理/内容证据 |
|---|---|---|
| D1＋D4 junction直接依赖/独立alias | L164精确400，L168独立alias200；两次内容GET200 | L162/165/169的source inode `3940649677967519`、dev和完整readlink相同；L163/170独立alias inode `3940649677967521`保持；L167完整31B |
| D2＋D5 true directorySYM | L175精确400，L179独立alias200；内容GET200 | L173/176/180同source inode `8725724282048659`和text；独立alias inode `4503599631388833`前后相同；L178完整31B |
| D3 indirect relative | L186对`context/indirect/moved`400，L190独立alias200 | L184/187/191同source inode `1688849864310314`、完整text；alias前后保；L189完整31B。indirect link本身未独立记录/断言前后identity，不多作保真声明 |
| case变体附加 | L197对原`SOURCE-LINK/moved`400，L201独立alias200 | 原`Source-Link`与新entry同inode `1407374887600696`/text；原请求大小写保在错误data.path；31B完整 |
| D6 mixed junction/trueSYM | L207 junction分支400；L212 trueSYM200、L214内容200 | junction源L206/208 inode `1407374887601518`保持；SYM原L211与发布L213 inode `1407374887601521`一致；两次31B完整。独立D/goal终态identity未额外journal |
| D7 folded ordinary/dir/junction | L217/220/223三Move200；健康link内容GET200 | 原producer顺序为directory/dir/junction；ordinary新note34B和各data31B全文均原log。原source/new identity与text有实际通过的断言，但该处identity()不打印数值 |
| D8 folded broken component | L226 Move200；L227真实内容404/FileNotFoundError | L228 data marker31B；新entry identity/readlink通过原断言，原数值未序列化；不把内容404改说mutation失败 |
| D9 healthy＋dangling冲突优先 | L236/L241均409/FileConflictError，data.path原`source/existing` | 两source的前后inode/readlink原log相同；healthy原34B在L238。destination identity和dangling readlink由实际断言验证但未逐值打印 |
| D10 ordinary自身后代/有限root alias | L230自身parent400；L232 `root-link/root-link/moved`200，L233完整内容200 | L231原note31B；directory原/新identity实际断言通过，但其inode未打印。重复root alias没有被静态inode cycle规则误拒 |

上述六个新依赖400全部原message为 `Destination parent depends on the source entry being moved: <原newPath>`，data.path为原目标，包括大小写/indirect路径；不是发布后404再改文案。独立alias成功仍用原逻辑path回执，真实raw路径可读且源entry inode/text保持。

## 物理事实、旧合同、两Project与通知

原log有94条 `link entry identity`，字段是lstat得到的directory/file/link、dev和inode十进制字符串、完整readlink。**没有birthtimeNs或完整stat/native handle/tag/address**；本报告不补造这些值。新D1–D6等28条identity原记录可直接复核，其余属于旧healthy/broken/tree/root/authority回归。

42条 `link target bytes` 保存完整Unicode/CRLF正文与长度：原marker31B×34次，retarget marker34B×8次，累计观察1326B（重复读取计入，非fixture写入总量）。逐条UTF-8长度与原长度相符；原 `exactBytes` 对整个实际Buffer和预声明literal作正向比较并通过。revision仅保原HTTP值，不重新算hash作验收。

旧回归包含健康file/dir/junction的copy/move/list/content；relative搬后missing和retarget；已broken三种entry的move/copy/delete200与真实内容/重试404；普通整tree的成员名称、四种健康/broken link text和文件全文；独立terminal root link copy200；外域source/current/future声明精确400；既有dangling destination409；child scope→父worktree入口及ignored坐标。root文件的18项覆盖空/点/dot别名、directory/worktree双根、祖先link、scope本身link、terminal尾分隔符、普通子文件根目标和absolute/NUL/权限/missing错误。

root日志L360/362/365/367四条原terminal observation在本Windows上均 `directory=false,symlink=true`，含两条尾分隔符；对应move/delete均200，root marker/physical identity由原实际断言检查。根保留函数没有把实际inode/marker数值写日志，故只能报告“正向断言通过”，不能把它包装成完整原physical journal。

两Project并行原L282–291有10条200，两个真实projectID分别为 `prj_haIpV7pEh98cQ1HS7ORN` 与 `prj_hVafWAUSzLTpGEvrPQiQ`，各5条。响应显示独立root/内容及ignored=true与false规则；通过的是两真实managed Git projects和各自Instance scope，不把mixed场景的目录名字D/context误称Project B。

通知使用真实Bus.subscribe＋waitForEdits；healthy三项、依赖/独立alias四项、parallel两scope均实际assert指定file及 `{kind:"host",cwd:<原scope>}`。原pass证明这些正向输出检查完成，但没有独立event payload日志、全事件顺序或exact数量；不能补写虚构Bus流水。未新增“不调用/不发生”核心断言。所读两文件都是非UI正向功能测试，没有UI/DOM/组件/源码文案测试，也未由本agent运行。

## 原警告/错误与最终版本资格

原非空非结构化65行全部是唯一命令、两个runner START/DONE、Bun banner/isolated entry、48个pass行和统计，没有独立WARN/ERROR、native exception stack、timeout或failed test。原90个4xx全部归入上述实际正向错误合同：61 invalid、25 missing、4 conflict；没有原5xx。这里仅对这份完整捕获日志作结论，不排除系统或其它owner日志中的问题。

静态读当前产品可确认：current Move guard只在Move入口消费source原BigInt事实/准确entry地址；destination lstat conflict在新dependency之前；sameFileEntry同时比较原地址和dev/ino/birth/type，不以ultimate target或单inode合并；guard保访问namespace、Win已资格fold和J/SYM差别，raw rename/notify/public Node保持原路径。新helper当前诊断版同handle tag/name/finally close，并收齐两个identity读的原错误。**这些源码复核不是该后续诊断版本的运行通过**，Root最终原run必须单列。

未验：production Move经实际8.3 source依赖与独立hardlink pair、unknown reparse/原native/query/Close失败、外部retarget原子性、POSIX/Darwin/Windows case-sensitive policy和remote provider、packaged loader、完整server启动/18456真实桌面截图、Provider/GPT流式任务。shared relocation/futuretree与目录link浏览仍是下一批能力；Native/Capsule/Task/Mission/Session的共享未验机制不由这188请求排除。当前两test实际进入source production loader/FileRoutes；不能把它扩称安装包或网页E2E。

结论是首轮已有真实正向功能证据，未发现其日志或测试核心合同的阻断；新版诊断修改、正式页面和原关闭/所有join仍由Root最终证据收敛。本报告未启动任何新进程或复跑原验收。
