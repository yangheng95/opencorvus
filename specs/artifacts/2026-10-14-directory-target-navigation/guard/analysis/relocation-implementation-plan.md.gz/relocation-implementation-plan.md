# Move 退休 entry guard 与后续 relocation：只读实施核验

## Recall、范围与结论资格

Root 授权本 agent 只读当前 File 全文、既有调查和本轮 dot/mixed 原输入/结果，写本 scratch 报告；禁止再次委托、产品/测试/正式规格/Git 修改或执行新的 API（Application Programming Interface，应用程序接口）、UI（User Interface，用户界面）、Native、fixture、模型、进程或 metadata probe。本报告没有执行这些操作。用户持续迭代、先分析/正式 spec 后实施、真实页面/人工截图和正向功能验收、正常交付仍由 Root 负责。

最新 Root 决定是**先修当前 Move 的 retiring-entry 依赖 guard**；shared move/copy relocation 与 future-tree 另批继续，保持明确未满足。本报告优先给这条可独立实施的最小设计。它不是已经实施/测试通过的产品结论，也不将 guard 的通过扩称为完整目录链接浏览或全部 relocation 已根治。

已完整读取 `packages/opencorvus/src/file/index.ts` 当前 1705 行，FileRoutes 相关定义/唯一 Move/Copy 调用、`file-link-entry-contract.test.ts` 全文、Filesystem 比较/命名空间/加载 primitive、当前 07-panel 的 entry/relocation 合同、当前批 Recall、`native-entry-effect-revision.md`、`state-and-futuretree-amendment.md`、dot inputs/review、两份 actual output 的全部 32 条观察。已查看 File 历史 `66f796d22` 完整该文件 diff；当前源码仍无新 retiring-entry guard。搜索 `File.(move|copy)(` 的全部生产 TypeScript/TSX 路径只有 `server/routes/file.ts:260/285`。所读链接合同测试为真实 TCP（Transmission Control Protocol，传输控制协议）服务测试，没有 UI 自动分支；本任务不运行它。

开始/结束只读 `git status --short`；有 Root/其它 owner 的多个改动，File 当前产品文件未被本 agent 修改。报告只写本 owned scratch。

## 一、本轮原证据实际说明什么

原 fixture ID 是 `df2ea0df-f134-4503-aea1-a2597ff25c9e`，数据根为 `C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/directory-target-dot-mixed-01a133`。原输入六例/338 个 literal 字节/32 operands 每 host；一次 Prepare、Node25.7.0/Bun1.4.0 同原 fixture 的各一次 Read。输入的 `proposal-only` 是原保存文本，不能据此否认已另授执行，也不能把命名当实际结果。

实际 raw 输出：

- `dot-native-read-node/evidence/native-host-stdout.bin`：269998 完整字节，32 条 `original-access-observation`，6 例完成；原 Node Target 21592、Host 88620，原 terminal/settled/outputSettled fulfilled、ordinary exited0、物理/输出/request cleanup true、父与两外 drain0/fulfilled。
- `dot-native-read-bun/evidence/native-host-stdout.bin`：272927 完整字节，同 32 条/6 例；原 Bun Target 82864、Host 90072，同原三 joins/ordinary0/三个完成事实与父0。各 birth/occurrence/原输出已存在该 run 的 settled/parent-joined JSON，不在本报告生成替代身份。

| 真实对照 | 两 host 原结果 | 可采用的限定规则 |
| --- | --- | --- |
| v 普通目录、true absolute SYM、junction、broken true SYM；u.raw=`v\\..\\goal` | 四例 u 与未提前 fold 的 raw-access 均读取本例 `tree/goal` 完整 literal；broken v 本身 stat/realpath ENOENT，u 仍成功 | 本次 Windows relative 展开阶段可在当时 access namespace 上先用成熟 `path.resolve` 折叠点段；被折掉的 v 不是实际经过的依赖 witness，不能因为文本出现 source 就拒绝 |
| S true SYM→B/J，J actual MOUNT_POINT→D/data，r.raw=`..\\goal` | S/r 得 `mixed-junction:B-goal\n`；direct D/data/r 得 D-goal | SYM 的递归返回必须保 B/J access namespace；junction 的 declared-target 分支不覆盖外层 namespace |
| S true SYM→B/T，T true SYM→D/data，同 r | S/r 与 direct r 都得 `mixed-absolute-symbolic:D-goal\n` | 内层 true SYM 的替换必须返回 D/data，不能 freeze 第一层 S 的 text=B/T |

所有 64 个成功 lstat 前/后 identityStable=true；actual tag 普通0、SYM `0xa000000c`、J `0xa0000003`，原 valid handles CloseHandle=1。普通 entry 的 readlink EINVAL 是实际观察，broken v 的 ENOENT 是实际错误，不被改写为失败的 instrumentation 或所有目标成功。

这只资格当前 Windows fixed operands、两 host 与该裸库读取/有限 namespace 转换，不证明 production loader、未来未发布树、FileRoutes、Mac/其它 POSIX（Portable Operating System Interface，可移植操作系统接口）、所有 Windows namespace/provider 或外部 retarget 的原子性。**不能用 basename+lowercase 或最终 target realpath 冒称准确 entry identity**。

冻结前新增资格已经实际完成，已独立读 `entry-results-node.json`/`entry-results-bun.json` 的全部32个 compact观察、原 library/ABI（Application Binary Interface，应用二进制接口）字段与 original joins：Node/Bun各16槽/16次同NOFOLLOW原handle name读取完成，239792/244721完整stdout、Target/父0、stderr0、三joins及四writes fulfilled。终端SYMLINK/junction/broken返回ownentry原名，uppercase归stored大小写；actual 8.3普通与Unicode文件访问（含实际祖先短名）归原full spelling。所有 exactDeclaredEntrySpelling/entryIdentityStable=true，原name size/read与Close事实由Root完整核验；本agent也读到原CloseHandle=1记录。它使当前Win32 normalized-DOS原名 primitive可以进入正式实现，**不等于**production adapter/loader、hardlink pair、Windows case-sensitive policy、所有短名组合、FileRoutes或Mac已通过。

## 二、现产品触发、根因、旧路径遗漏与影响

`assertFileMutationPaths:1151–1182` 保 source/target 一般准入、parent、两 logical/physical roots 和 terminal-link 本体。`move:1376–1411` 之后依次 destination `Filesystem.exists`、旧 shared relocation、native `renameNoReplace`、通知、原 targetFull 的 `nodeForPath`。没有证明原目的 parent 在 source 退休后仍可达的步骤。因此既有实际 dependent cases 可 native 发布成功，原 targetFull 随源 entry 退休而不可寻址，后续 receipt 读404；不能靠禁用 receipt、改用 physical receipt 或发布后再猜成功解决。

`66f796d22` 根治的是 entry 与 followed target 混淆：lstat entry receipt、broken links、原 readlink 声明、Copy verbatim/strict tree；它没有原目的 access chain 依赖状态。旧 `isPathAllowed/canonicalPath` 的 ultimate target membership 与 exact retiring directory-entry 是不同问题。相同最终 D 的独立 aliases 可以合法；同 dev/ino 的不同 hardlink 名也不等于将退休的名字。原最初统一 Windows logical-anchor 建议已经被实际 SYM/J 对照反证，不能重用。

后端唯一生产入口是 FileRoutes PATCH `/file/item`；已有 overlay `moveFileItem:430–446` 只在200后协调原 editor owner，Explorer batch/rename/move/drop 的 `applyMoveResults:1095…` 只消费真实成功 receipt。新发布前400让原 source 保持身份，旧错误/Details正常呈现；无需前端扫描、第二 receipt、state/cache/epoch 或改 SDK（Software Development Kit，软件开发工具包）DTO（Data Transfer Object，数据传输对象）。File.copy 的源存续，不调用 source-retirement guard。create/delete/upload/read/write、其它 `renameNoReplace` 使用者不在该 guard 范围。

## 三、第一批最小函数与唯一事实源

建议仅一个 File 私有 `assertMoveDestinationIndependent({ sourceFull, targetFull, targetFile, sourceEntry })`，从 `dirname(targetFull)` 的**原访问路径**开始。共享底层 entry observation 用已决定的 Filesystem 当前 primitive：原 lstat BigInt identity、actual traversal kind、原 readlink、同 NOFOLLOW entry 的真实 canonical name/address。不得给 File 复制 Win32 DLL loader/tag parser 或再用 ultimate path 推断 kind。

`assertFileMutationPaths` 的单一源 lstat可改 `{ bigint:true }`/返回 `fs.BigIntStats`；现 move/copy/remove 只用 kind，类型影响限定三调用者。Move 取这一原 snapshot，不通过 `BigInt(number ino)` 恢复已可能舍入的值。新的 entry metadata witness必须核对同一 source snapshot；前后身份改变是未确认观察/error，不能当独立或可靠依赖成功。

Windows entry-address 比较采用原 NOFOLLOW handle 返回的实际名字；POSIX 用 mature parent realpath + 真实 basename，保字节/名称含义。两者均需 exact BigInt identity，地址相等与身份相等共同构成 witness。只做语法 namespace 去前缀的成熟 `normalizeWindowsPath`；绝不能用 `normalizeCanonicalPath`/`Filesystem.normalizePath` 再 follow terminal。原Win32返回stored name后不需要再将filename全局lowercase；case-sensitive policy仍未资格，不能提前合并不同真实名字。没有失败后 basename猜测key后备路径。

guard 只返回完成或 throw，不将解析所得地址交给 rename，也不改 public path/name/readlink。已有 raw sourceFull/targetFull 仍是唯一 native rename operands。

### 内部状态与递归最小结构

内部当前状态至少包含 `accessNamespace` 和该递归请求尚未消费的 `remaining`；递归返回 `accessNamespace`。记录被实际访问的原 entry witnesses。递归调用的 active key包含该 host 的当前 namespace/root 与完整 remaining（当前完整 operand 是其等价编码）；不能用裸 inode、最终 D 或 source-relative suffix 替代。

不需要全局 cache。每次递归在 finally 退休自己的 active key；同 namespace 再次出现但前次已返回，可以重新实际观测。若使用请求内 completed 表，只能保存该 exact access state 的原完成结果，不能替代另 namespace/remaining 的读取；为最小当前 guard，active 集合已够，无需额外 completed cache。

```text
inspectAccess(rawAbsoluteOperand):
  进入该 host 的 stage grammar；登记 exact active state
  从 root 消费本次 stage 的 components
  每个实际 candidate entry：原 metadata + source witness 比较
  ordinary：继续当前 accessNamespace
  SYM：展开其原 text；递归 inspectAccess(target)
       将返回 accessNamespace 作为 prefix，继续原 remaining
  Windows JUNCTION：递归检查其原 declared target 的依赖
       该分支完成后保原 candidate accessNamespace，继续原 remaining
  返回最终 accessNamespace；finally 退休本次 active state
```

这是有限 parent access dependency 检查，不是新通用 filesystem resolver。只读实际 path 的 metadata，不 readdir link target 整树、不解析 NTFS（New Technology File System，Windows 文件系统）reparse payload、不配置新 authority。current admission 已对完整 parent 做 native realpath/stat 成功资格，guard补它不暴露的 entry dependencies。

### Windows stage grammar

最初 targetFull 已按原 API path.join 合同归约；每次 actual SYM relative expansion，使用**当时** `dirname(candidate accessNamespace)` +原 readlink 经 `path.resolve` 生成下一 stage；absolute SYM 重置 prefix并递归消费其 target。原 u 的 `v/../goal` 在该阶段折去 v，不能逐 raw token先把 v 记作依赖。

SYM target 的递归完成后必须返回其 accessNamespace；S→B/J 返回 B/J，S→B/T→D/data 返回 D/data。junction target 的依赖分支会记录实际 source witness，但它的返回 namespace不回写 outer。这两个规则用同一 inspect 函数，不能 junction 失败后改试 physical namespace、并行选成功或重建另一个 anchor helper。

### POSIX raw components

不能照搬 Windows 的整串 `path.resolve`。relative SYM从真实 containing parent展开，保 raw components；遇内层 SYM先实际展开，再处理后续 dot。处理 `.`/`..` 可复用 mature `fs.realpath` 对**当前已解析 namespace + 原 dot component**的实际 lookup，让 native 保 ENOTDIR/ENOENT/ELOOP；不能字符串 pop掉尚未实际经过的 link，也不能把反斜杠分成 separator。

原 targetParent preflight仍是 native 成功资格。POSIX路径的分量语义有已有官方 source依据，但当前任务没有 POSIX 实机。标准字节路径规则不等于已排除 Mac case-insensitive/Unicode normalization、其它非标准 filesystem aliases；这些保持未知，不全局lowercase POSIX filename。

### cycle 与 finite 重复

`root-link/root-link/child` 这类有限访问不能按重复 link inode拒绝；剩余 suffix缩短或 namespace不同就是不同状态，declared-target 分支返回后也已退出 active。actual同一 active access state递归重复才是循环；原 native ELOOP仍保原错误/500，不能改成“independent”或虚构 source-dependent400。新增 active-cycle诊断若需要 error code ELOOP，须明确它来自 validator 的状态证据而不是伪造一个已执行 syscall。

完整 parent 的现 native preflight通常更早报告真实不可达循环；不能删除它，再用自造 hop 上限取代。不要按“text含..”、同 D、inode重复或硬编码小 hop次数阻断正常访问。网络/其它 provider、unsupported path-changing tag、native unknown I/O（Input/Output，输入输出）与 retarget变化继续原 error，不默认为 ordinary。

## 四、错误 precedence 与 Move destination 单源修正

Root 新选择：**只替换 Move 的 destination precheck**为 `fs.promises.lstat(targetFull)`。entry成功明确409（包含 dangling）；仅 known ENOENT/ENOTDIR继续；unknown error原 throw。当前 `Filesystem.exists=fs.access.then(true,false)` 会follow terminal且吞所有错误；原 dangling409来自后面的真实 native EEXIST，并非这条 precheck已证明终端存在。此处替换后删除 Move 的旧 `exists`调用，不改全局 Filesystem.exists、Copy/create。

保持严格顺序：

1. 原 source空/root、target basename、source一般路径、target一般路径/parent、logical roots、source lstat/physical roots仍按 `assertFileMutationPaths` 原先顺序。
2. 新 Move destination lstat已存在entry→`FileConflictError`409，`data.path=newPath`；unknown原500。
3. 新 source/target access observations；精确命中将退休 source→`FileInvalidPathError`400，`data.path=newPath`，建议固定 message `Destination parent depends on the source entry being moved: ${newPath}`。ordinary directory source也是同一 entry witness，不另建 ultimate descendant判断。
4. 旧唯一 shared relocation 按原 source/current.file 错误400；本批未修其 future/tree缺口。
5. 原 native `renameNoReplace`，真实竞态 EEXIST仍409；其它原 error。原通知与 entry receipt照旧。

source观察已缺失→原 source404；parent/hop发生 known missing使目的访问资格失效→现 parent-invalid400(newPath)，不能missing→independent。EACCES/EIO/ELOOP/native Win32 query/close/unsupported kind等 unknown保原cause/500，不兜底假false。source witness400只用于已确认 exact entry依赖，不把所有访问故障当同一400。

这仍是发布前当前观察，不提供 external retarget与后续 rename/receipt 的原子绑定。禁止增加发布后回滚/physical receipt旁路来假称彻底消除所有 unknown。

## 五、第一批正向真实 FileRoutes 矩阵

使用现 `memoryProject` owned identity与真实 Hono/FileRoutes/Bun.serve TCP模式，原请求/完整 body/requestID/entry BigInt identity/readlink/完整 marker字节/通知分别保留。功能测试不用 mock factory/人工 emit/静态源码断言/UI自动化。新 checker先在旧产品源码记录真实前态，正式授权后再修/运行；本报告未运行。

| 输入/资格 | 明确正确输出及事实 |
| --- | --- |
| 原 J-self、S-self、间接 relative dependency（各独立 source） | PATCH400，精确 name/data.path=newPath/message；原 source exact address/identity/readlink与原 target marker完整 |
| 原独立 A/B alias到同 D | PATCH200，原 public newPath Node.type=file；原 raw新路径/实体新entry可读，Move inode/text保持，独立 alias/目标bytes保持 |
| 新原 ancestor对照：true absolute SYM vs junction，另独立 source-link | SYM case200且raw newPath可寻址；J case400/source保持；不能照case名造tag |
| mixed S→B/J与S→B/T；goal构造成真实合法directory/dir-link、同目标独立entry | J namespace确实到source的case400；T namespace到独立D/goal的case200/raw receipt/content；同实际metadata grammar，不mock返回namespace |
| 四种 v，目的parent由raw `v/../destination-folder` relative SYM指向普通目的folder | Windows实际400依赖只按经过的entry；v正好为所移source但被stage折掉时合法200/raw新路径。每例独立source，Bun/Native成熟当前host实际确认，不冒称已有32 File API已验 |
| ordinary directory direct/alias进入自身子树 | 400/newPath/source whole-tree与marker保持；独立同目标 link不被误当source entry |
| 普通/terminal root-link、relative retarget、in-scope broken source→独立parent | 200/原entry kind/text/真正目标bytes或typed404；两物理root source仍原400，root目标正常子文件200 |
| 有限root-link重复与真正循环 | finite合法200/raw路径；cycle原明确500/error cause，若前置native preflight先报则注明实际阶段，不伪造guard已触发 |
| 实际case/8.3 alias到source entry；独立hardlink | 原16×2名字读取已资格其fixed operands；guard仍需实际source案例：同实际entry400，独立硬链接名字不合并。宿主无法实际建立link-hardlink则保原errno/未覆盖，不用普通fixture伪造；case-sensitive policy/未取短名组合保unknown |
| 健康existing与danglingdestination；新missingdestination | 前两409原 destination/source identity保持（验证新precedence），missing进入实际guard/rename正常200；unknown I/O只有安全真实条件才能声称500资格 |
| child scope→worktree parent、A/B串行与并行 | 当前两个authority roots/原scope/通知/identity/ignore正确；per-request active state不泄漏项目。仅资格File HTTP，不冒称Task/Mission/Session端到端 |

聚焦相邻既有文件：`file-link-entry-contract.test.ts`（含broken、retarget、tree、root-link、external、dangling409、parallel、child scope）、`file-mutation-root-contract.test.ts`；必要原 types/build覆盖source primitive/Native loader。读图/真实 Move错误反馈由Root另做，现八张before图片和纯类型不是after UI。测试恢复/重试只对新明确请求：发布前400的source可再移到合法独立parent；先前实际已发布404不可重放当同发生实例。

## 六、后续 shared relocation 如何复用，何处不能一行简化

当前唯一 `assertRelocatedSymlinkTargetsAllowed:1208–1249` 两个调用：Move1391、Copy1440。它遍历普通 source树、不follow terminal link，取每个原readlink，源与future都用logical dirname+path.resolve再isPathAllowed。此缺口仍影响 terminal浅alias与nested普通树；本批guard不会修它。旧strict Copy staging/full tree、verbatim readlink/noReplace/cleanup仍应保。

后续必须继续只有一条namespace转换算法，不复制“terminal relocation resolver”与“tree resolver”。可沿当前 guard的 inspect state扩展一个**当前/未来 entry observation view**，只在真正操作tree的位置预测尚未发布entry：由真实destination parent realpath+新basename得到 futureRoot，每个普通tree entry以 source relative suffix映射；source snapshot/readlink/tag是唯一事实。当前只为guard实现 actual view，不提前引入未用泛型框架/第二cache。

后续状态还需要 physical/entry lookup位置，不能仅 accessNamespace：junction返回物理目标使实际child metadata能读取，但外层 accessNamespace仍保用于下一relative展开。SYM的递归返回则更新namespace与lookup位置。这个区别正是mixed两实际case，不可用ultimate physical cursor覆盖accessNamespace。

可安全简化的部分：一次 mature physical destination parent；source每个link真实parent；ordinary subtree位置suffix；外部真实entry metadata/native realpath；最后已解析或knownmissing目标的现 `canonicalPath/isPathAllowed`两root membership。**不能简化**成 `physicalparent+canonicalPath(futurePath)`就称future完整：future内部link尚不存在，当前canonicalPath走最近存在parent会把它们当普通missing suffix，无法读取即将发表的原text。

一个未运行的Windows推导例解释必要性（不是新增复现）：`A/deep/tree/p`是junction→`A/data/nested`，`q`relative SYM→`p`，`u`relative SYM→`q/r`；外部真实 `A/data/nested/r` relative text=`../../../outside`。源树访问u的namespace为`A/deep/tree/p/r`，relativestage到`A/outside`（allowed）；futureRoot=`A/result`时，future q/p还不存在，现canonicalPath各fold declaration看似A内，但真正发布后u由future namespace `A/result/p/r`展开到run/outside（out-of-scope）。p自己absolute declaration合法，q/u未来位置的现missing fallback也合法，原strict copy只验entry/text/bytes；因此只换physical parent仍可漏组合。此例须下一正式plan/真实checker核验，不能写成已证OS行为。

future view语义须明确：

- ordinary投影tree里metadata从对应source entry读取，按**future位置**解释原text；不平移当前 ultimate target。
- 跳出投影范围沿真实external metadata；现权限只看被移动link的declared源/future最终实体目标，不能顺手禁止中间external→backlink而改变现两个root权限合同。
- Copy保旧source namespace；Move使旧source entry退休，ordinary目录是整个旧subtree、terminal link是该entry而非其最终D。absolute text不自动改写；Move后原旧树地址可成为in-scope missing，Copy仍可指原树。
- knownmissing保持现合法broken declaration；unknown I/O不能catch→false。未来自循环、内部missing/ENOTDIR、source树变化、外部retarget、Windows未来自动短名、Mac别名必须先定准确错误/资格，不能假existing或选当前/未来成功一方。
- source与future共用同grammar/view/authority，不另权限root、不物理试发布shadow tree、不修改用户readlink；新positive API需要terminal与至少两层普通tree、internalSYMLINK/JUNCTION/relative dot、broken/external/两Project、Copy旧namespace与Move退休各有actual输入。

目前没有仓库成熟public future-tree resolver可直接调用。realpath/canonicalPath对存在路径成熟，不提供未发布internal links。以本次实际scope先交付current guard是明确能力分批，不以此排除future/shared根因；后续必须替换旧同语义计算，不保fallback。

## 未完成与 Root 可采用的最小决定

当前可落正式实施的是：同一metadata primitive提供准确entry key+BigInt facts，一个Move私有access-state guard、该Move唯一strict destination-lstat precheck；SYM递归返回namespace、junction依赖分支保outer、Win stage fold、POSIX rawcomponent/native dot lookup，原400/newPath与原error顺序。没有新的public Node/SDK/state/UI功能。

已完成限定资格：Win32固定16×2 NOFOLLOW canonical entry名字/当前大小写与两实际8.3操作数；当前dot/mixed固定32×2访问。仍未完成：production adapter/packaged loader；本新guard实际产品/真实TCP/桌面after；hardlink pair/Windows case-sensitive policy/POSIX/Mac实际case；unknown provider/网络/retarget原子性；完整sharedrelocation/future-tree与目录链接浏览；此前meta timeout/Capsule/Native未验分支仍保各自unknown。本报告不启动新meta资格、模型或其它实例。
