import fs from 'node:fs'
import path from 'node:path'
import { spawnSync } from 'node:child_process'

const repo = process.cwd(), scratch = path.join(repo, '.tmp-codex-directory-target-01a133')
const normal = { ...process.env }
const scopes = [
  '.gitattributes',
  'specs/records/2026-10/2026-10-14-directory-target-navigation.md',
  'specs/artifacts/2026-10-14-directory-target-navigation',
  'packages/opencorvus/src/file/index.ts',
  'packages/opencorvus/src/util/file-entry.ts',
  'packages/opencorvus/test/file-link-entry-contract.test.ts',
]
const shared = ['specs/README.md', 'specs/records/2026-10/README.md', 'specs/artifacts/README.md']
const architecture = 'specs/current/architecture/07-panel.md'
const guardContract = `Move verifies that the destination parent's actual access chain remains
independent of the source entry being retired before native publication. A
dependency returns HTTP 400/FileInvalidPathError with the original destination
path; an existing destination entry, including a dangling link, takes precedence
as HTTP 409/FileConflictError. Independently addressable aliases to the same
target remain valid. Entry identity combines its exact address with BigInt
filesystem identity; Windows observes the terminal reparse entry through one
non-following handle and preserves junction versus symbolic access namespaces.
This integrity check does not apply to Copy or claim atomic external-retarget
protection. It does not add directory-link navigation or a second receipt.

`
const previousRows = {
  'specs/README.md': '- [目录链接浏览与别名目的地](records/2026-10/2026-10-14-directory-target-navigation.md)：entry与目标事实、物理准入、有限真实调查和完整浏览方案。',
  'specs/records/2026-10/README.md': '- [目录链接浏览与别名目的地](2026-10-14-directory-target-navigation.md)：独立列表target合同、别名移动与相对链接范围前检。',
  'specs/artifacts/README.md': '- [目录链接浏览与别名目的地](2026-10-14-directory-target-navigation/README.md)：独立分析、真实predicate/文件准入、原活动与桌面资格。',
}
function git(args, env = normal, input) {
  const r = spawnSync('git', args, { cwd: repo, env, input, encoding: 'utf8', windowsHide: true, maxBuffer: 128 * 1024 * 1024 })
  if (args[0] === 'commit') fs.writeFileSync(path.join(scratch, 'checkpoint-commit-tool-result.json'), JSON.stringify({ args, stdout: r.stdout, stderr: r.stderr, exitCode: r.status, at: new Date().toISOString() }, null, 2))
  if (r.status !== 0) {
    const errorPath = path.join(scratch, 'checkpoint-git-failure-' + Date.now() + '.json')
    fs.writeFileSync(errorPath, JSON.stringify({args,stdout:r.stdout,stderr:r.stderr,exitCode:r.status,at:new Date().toISOString()},null,2))
    throw Error('git ' + args.join(' ') + ' failed; full result at ' + errorPath + ': ' + (r.stderr + r.stdout).slice(0,6000))
  }
  return r.stdout
}
function blob(file, text, env) {
  const oid = git(['hash-object', '-w', '--stdin'], env, text).trim()
  git(['update-index', '--add', '--cacheinfo', '100644,' + oid + ',' + file], env)
}
if (process.argv.includes('--prepare')) {
  const base = git(['rev-parse', 'HEAD']).trim(), index = path.join(scratch, 'checkpoint-index-' + Date.now()), env = { ...normal, GIT_INDEX_FILE: index }
  fs.writeFileSync(path.join(scratch, 'checkpoint-real-index-before.diff'), git(['diff', '--cached', '--binary']))
  fs.writeFileSync(path.join(scratch, 'checkpoint-status-before.txt'), git(['status', '--short']))
  git(['read-tree', base], env)
  git(['add', '-f', '--', ...scopes], env)
  for (const file of shared) {
    const text = fs.readFileSync(path.join(repo, file), 'utf8').replaceAll('\r\n', '\n')
    const rows = text.split('\n').filter(line => line.startsWith('- [') && line.includes('2026-10-14-directory-target-navigation'))
    if (rows.length !== 1) throw Error('Exactly one owned row required: ' + file)
    let baseText = git(['show', base + ':' + file])
    const baseRows = baseText.split('\n').filter(line => line.startsWith('- [') && line.includes('2026-10-14-directory-target-navigation'))
    if (baseRows.length > 1 || (baseRows.length === 1 && baseRows[0] !== rows[0] && baseRows[0] !== previousRows[file])) throw Error('Owned base row differs from the exact reviewed previous/new row: ' + file)
    if (baseRows.length === 1) baseText = baseText.replace(baseRows[0], rows[0])
    if (baseRows.length === 0) baseText = baseText.replace('\n', '\n\n' + rows[0] + '\n')
    blob(file, baseText, env)
  }
  const workingArchitecture = fs.readFileSync(path.join(repo, architecture), 'utf8').replaceAll('\r\n', '\n')
  if (workingArchitecture.split(guardContract).length !== 2) throw Error('Exact single Root architecture contract required')
  let architectureText = git(['show', base + ':' + architecture])
  if (!architectureText.includes(guardContract)) {
    const anchor = "Move/copy validate each link's declared source and relocated destination targets\n"
    if (architectureText.split(anchor).length !== 2) throw Error('Exact architecture anchor required')
    architectureText = architectureText.replace(anchor, guardContract + anchor)
  }
  blob(architecture, architectureText, env)
  git(['diff', '--cached', '--check'], env)
  const files = git(['diff', '--cached', '--name-only'], env).trim().split('\n')
  if (files.some(file => !scopes.some(scope => file === scope || file.startsWith(scope + '/')) && !shared.includes(file) && file !== architecture)) throw Error('Staging escaped task scope')
  fs.writeFileSync(path.join(scratch, 'checkpoint-prepared-index.json'), JSON.stringify({ base, index, files }, null, 2))
  fs.writeFileSync(path.join(scratch, 'checkpoint-staged-stat.txt'), git(['diff', '--cached', '--stat'], env))
  fs.writeFileSync(path.join(scratch, 'checkpoint-staged-review.diff'), git(['diff', '--cached', '--', ...shared, architecture, ...scopes.filter(scope => scope !== scopes[2]), ...files.filter(file => file.startsWith(scopes[2] + '/') && file.endsWith('/README.md'))], env))
  console.log(JSON.stringify({ base, index, files: files.length, preparedOnly: true }))
  process.exit(0)
}
if (process.argv.includes('--reconcile')) {
  const data = JSON.parse(fs.readFileSync(path.join(scratch, 'checkpoint-delivery-commit.json'), 'utf8'))
  if (git(['rev-parse', 'HEAD']).trim() !== data.commit) throw Error('HEAD changed; inspect before precise real-index reconciliation')
  const patch = git(['diff', data.base, data.commit, '--binary'])
  fs.writeFileSync(path.join(scratch, 'checkpoint-owned-index.patch'), patch)
  git(['apply', '--cached', '--check'], normal, patch)
  git(['apply', '--cached'], normal, patch)
  fs.writeFileSync(path.join(scratch, 'checkpoint-real-index-after.diff'), git(['diff', '--cached', '--binary']))
  console.log(JSON.stringify({ commit: data.commit, reconciledOnlyOwned: true, remainingStaged: git(['diff', '--cached', '--name-only']).trim() }))
  process.exit(0)
}
if (!process.argv.includes('--commit')) throw Error('Explicit prepare/commit/reconcile required')
const prepared = JSON.parse(fs.readFileSync(path.join(scratch, 'checkpoint-prepared-index.json'), 'utf8'))
if (git(['rev-parse', 'HEAD']).trim() !== prepared.base) throw Error('HEAD changed; prepare fresh before commit')
const title = process.argv.includes('--guard-title') ? 'fix(files): reject move destinations that depend on the source entry' : process.argv.includes('--metadata-title') ? 'docs(files): record verified native link metadata and remaining boundaries' : process.argv.includes('--restore-title') ? 'fix(evidence): preserve original directory investigation bytes' : 'docs(files): preserve directory alias failures and native evidence'
const result = git(['commit', '-m', title], { ...normal, GIT_INDEX_FILE: prepared.index })
const match = result.match(/^\[.+ ([a-f0-9]+)\] /m)
if (!match) throw Error('Cannot identify successful commit')
const commit = git(['rev-parse', match[1]]).trim()
fs.writeFileSync(path.join(scratch, 'checkpoint-delivery-commit.json'), JSON.stringify({ base: prepared.base, commit, files: prepared.files, result, at: new Date().toISOString() }, null, 2))
console.log(JSON.stringify({ commit, files: prepared.files.length, reconciliationPending: true }))
