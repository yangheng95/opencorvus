# Guard after：工具准备审阅

## Recall 与当前状态

Root 已全文核 proxy 横审，不授权执行 reg 或调整 timeout。之后授权只读 File 准入正向矩阵，并允许准备一个有限、全新 Windows guard 后态工具提案：runRoot=`C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/directory-target-guard-after-01a133`，port18456，prefix=`directory-target-guard-after`，A/B 两真实独立 Git 根、literal≤512B，五个健康link和一个普通source-tree；普通source/root/B markers，不建 root-loop、不复用旧8 consumed输入。900000ms absolute execution、120000ms真实输出无活动、startup45/shutdown45/other-owner-join75原预算保持。Prepare/Register/launch/界面/Mutation须另授，当前只准备源码。

这里 Git 只指**将来准备夹具时新根的普通git init**，不是当前仓库操作；没有执行任何Git、fixture、服务、API（Application Programming Interface，应用程序接口）、库探针或模型。UI（User Interface，用户界面）由Root负责，工具没有UI脚本、自动测试、上传/picker或mutation模式。Credential/catalog从未读取、复制或写入；新run/observer/真实fixture现在没有由本工具创建。只新建了本workspace scratch提案目录和六份成熟工具原文历史。

当前代码准备完成；**纯语法检查尚未运行**，遵守当前“不执行库/命令”与Root先全文审读的顺序。检查可在Root审阅后单独授权：Node `--check` 两mjs只parse不evaluate；PowerShell Parser API只parse两PS1+functions；NativeHost的原语法检查入口也只parse，不能用运行它替代syntax。不能把本报告称syntax0或runtime资格。

## 当前执行文件（Root逐份审读）

1. `fixture-support.mjs`：唯一当前共享helper。exact新run/port/prefix/qualification、bound/direct physical、tiny声明观察、原Host/Target/birth/ready/deadline、原完整HTTP bytes/headers/parseerror。删除旧loadRegistration及48request预算，当前仅四register requests。
2. `fixture-tool.mjs`：只有`prepare`和`register`两个显式mode。Prepare新独占run/Git/markers/link/manifest；Register仅GET /project/current + POST /coding/chat/session {}各两Project共4请求，原200/201和真实scopeID/emptyChatID绑定。没有primitive/before-probe/readOnly或mutation模式。
3. `launch.ps1`：当前namespace限定、同immutable Bun/UI pair、当前source CLI（Command Line Interface，命令行界面）、原NativeHost、原budget；Root单独授权后启动，保持长parent handle。ready后记录原owner、UI（只有GET资源绑定，不操作页面）；未提前注册，也不读取旧receipt。
4. `native-host.ts`：成熟原ProcessFacade.run唯一Target bytes collector、原onSpawned/terminal/settled/outputSettled/完整四writes/actualbirth/原firsterror。只是下移一层后的`../../packages`定位修正，未改run/控制/结算协议。
5. `owned-launch-functions.ps1`：成熟原文完整相同。source定义下`$PSScriptRoot/native-observer`自然变为新passive namespace；不复制旧观察receipt。
6. `shutdown.ps1`：原sameoccurrence settlement winner/75秒同行join、一次普通POST、原Host/Target/birth/两output/requests/port判断，仅exact新namespace/port/qualification替换。Rootpageclosed后另授，不触其它用户process、无kill/restart。

fixture schema保留当前 `directory-target-navigation.fixture/v1`；本次精确qualification改为`real-desktop-directory-target-guard`，所有producer/launcher/loadOwner/shutdown同源替换。前者描述现fixture结构，后者明确后端guard基础的桌面轮次；不能暗示目录link浏览已通过。

## 原文/完整变化

`history/`保存mature fixture-support、fixture-tool、launch-ui、native-host、owned-launch-functions、shutdown 六个完整原文件；原上层文件全未改。`full-changes.json`逐一包含originalPath/historyPath/preparedPath、完整originalText/完整preparedText与历史full-bytes等于原文件的结果。逐原byte保存用于明确变更对象，不以源码hash/换行摘要作功能门槛。

- helper：exactnamespace、port、qualification；删除private旧loadRegistration；registrationexecutor cap4，旧额外模式没有current入口。
- fixture-tool：替换成这次95B/5links/3ordinarydirs的新明示输入，仅Prepare/Register，不携带旧8mutation和10primitive/12readback/4096B输入。
- launcher/shutdown：exact新run/prefix/port/qualification/轮次说明；maturebudget、process封装与ordinaryshutdown保持。
- NativeHost：三个相对package定位多一层`../`，type import、packageRoot、errors import全部同步。
- owned functions：原bytes相同；新的passive目录由将来Prepare exclusive mkdir创建，原 observer实际Bun1.4与productionphysical API不改。

## 全部预声明夹具

A=`run/project`；B=`run/project-b`。两个新独立`git init --initial-branch=main --template=`，不借旧Project/common仓库或SQL（Structured Query Language，结构化查询语言）造ID。Git仅命令精确argc/15s、privateHOME/GIT_CONFIG_GLOBAL=NUL/NOSYSTEM，原stdout/stderr完整Buffer/base64记录，首失败保存不重试/清理。注册后实验证明两真实Project/Chat IDs，而不是从目录名推断。

| role/path | 原literal |
| --- | --- |
| A/root-marker.txt | `GUARD ROOT A 01a133\r\n` |
| A/data/marker.txt | `GUARD DATA A 01a133\r\n` |
| A/source-tree/note.txt | `GUARD TREE A 01a133\r\n` |
| A/.gitignore | `/source-j/\n` |
| B/root-marker.txt | `GUARD ROOT B 01a133\r\n` |
| B/.gitignore | 空0B |

四正文各21B，加原A ignore11B，总95B；上限512B。bootstrapped registered阶段两ignore各精确追加原canonical `.opencorvus/.r/\n`16B，总文件literal变为127B。这是已声明生产metadata阶段，不把现任意bytes重算作期望。markerFacts明确prepared/registered与expectedBytesSource，同entrydev/ino、完整bytes；不是checker修改规则。

五条entry：A/source-j junction→A/data，source-s absolute directorySYMLINK→A/data，alias-j junction→同data，alias-s absolute directorySYMLINK→同data，context/indirect-relative dirSYMLINK原text=`../source-j`。普通dir只A/data、A/context、A/source-tree。每条记录实际lstat bigint dev/ino/kind/birthtime、原readlink全文与stat/realpath。relativetext只允许nativeseparator spelling；不折dot、不把相对text转绝对。当前observe helper不充当新产品dependencywalker，它只用于这五个已声明无dot/loop的bounded owned图。

除了成熟 runtime/home/appdata/localappdata/temp/xdg-config/data/cache/state/evidence/inputs 两Project运行目录，不扩其它fixture。passive root为本scratch `guard-after-tools/native-observer`，将来Prepare一并exclusive mkdir及runtime/home；不是旧observer，不是Task/服务owner。新`prepared-fixture.json`冻结fixtureID、scopes的root/.git physical身份、原bytes、links、四请求plan、env/credential-none投入及qualificationBoundary。run存在即准备失败保全，绝无reuse/删除/替新namespace。

## 原请求和owner边界

Register的唯一计划：

1. A GET /project/current?directory=<A> →200真ProjectID；
2. A POST /coding/chat/session?directory=<A>，body={} →201真emptyChat；
3. B同GET →200；
4. B同POST {} →201。

每次原status/headers/requestID、UTF-8（Unicode Transformation Format, 8-bit，八位字符编码）完整rawbody/base64、parseerror、dispatch/headers/bodyfinish clock都独占wx保存。任一transport/parse/status/scope失败停后续，不重复请求；register-admission.wx阻止重放。注册完成后只进行预声明physicalmarkers/links读（没有额外HTTP），保preparedbytes+runtime规则、linksameentry/rawtext、truehealthydata目标。没有fakeProject/假UUID/角色字段/noTask/model调用；UUID（Universally Unique Identifier，通用唯一标识符）仅真实fixture/owner occurrence。

loadOwner读本run唯一launch-owner、Native ready与startup framed receipt；核fixture/prefix/port/project/projectB/qualification/runtime/evidence、原Host+Target PID（Process Identifier，进程标识）/Windowsbirth、同occurrence、startup targetPID、原deadline、120000/printLogs true。原已settled/error或deadline届满则失败，不relaunch/延长。新的NativeHost仍由成熟run捕获Target；Hostbootstrap的错误是另一层，原全parentstderr保留，不因Target0B称clean。

## 风险和未满足项

两mjs/PS/native源码仅准备，没有syntax0、fixture成功、注册成功、服务ready或视觉证据。Root读全文/语法/另授执行后才能产生资格。PrivateimmutableUI沿当前原ui-bundle，source CLI启动读当前产品源码；启动时HEAD/相关workingdiff由Root独立记录，工具不作Git/hash功能gate。

原mature owned observer显式installProcessShims，并可能触发共享OS（Operating System，操作系统）proxy查询；本次**没有执行observer/Host/reg**。此提案没有擅改它、不加disable或timeout。函数对exit0的observerstderr目前不单独持久，而主Host原stdout/stderr会完整留存；此前proxy报告指出的reg identity/输出/树边界继续未知，不能据observerstate green封闭它。若Root要改observercapture须另明确小规格/审阅，不能把新guard工具混成proxy修复。

原本NativeHost尚未进入run之前的bootstrap仍不受Target inactivitytimer；此报告不新增外围driver或新的预算权威。900秒输入和120秒真实Target output inactivity保持，startup/shutdown/join观察期限不是reset。普通shutdown仍等原receipt/physical/output/request与Hostport，controlledreason/exit1保原值。

后态mutations/真实页面/内容readback由Root另授权：D1–D5基础足够；新mixed/dot/futuretree/8.3矩阵需要另独占fixture/输入审阅，当前没有偷偷补其中任何布局。这组tools只交付有限工具提案，不能代替全部relocation修复或目录浏览。
