/** Prepare-only tools. Importing performs no I/O, product import, or process launch. */
import fs from "node:fs/promises"
import path from "node:path"
import { fileURLToPath } from "node:url"

export const scratch = path.dirname(fileURLToPath(import.meta.url))
export const runRoot = path.resolve("C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/directory-target-guard-after-01a133")
export const evidence = path.join(scratch, "directory-target-guard-after")
export const projects = { root: path.join(runRoot, "project"), b: path.join(runRoot, "project-b") }
export const port = 18456
export const prefix = "directory-target-guard-after"
export const schema = "directory-target-navigation.fixture/v1"
export const qualification = "real-desktop-directory-target-guard"
export const stamp = () => ({ utc: new Date().toISOString(), wallMs: Date.now(), monotonicNs: process.hrtime.bigint().toString() })
export const factError = (error) => ({ name: error?.name ?? typeof error, code: error?.code, errno: error?.errno, syscall: error?.syscall, path: error?.path, message: error?.message ?? String(error), stack: error?.stack })
export const requireFact = (condition, message) => { if (!condition) throw new Error(message) }
export const samePath = (a, b) => path.resolve(a).toLowerCase() === path.resolve(b).toLowerCase()
export const missing = (error) => error?.code === "ENOENT" || error?.code === "ENOTDIR"
export const label = (stem) => `${stem}-${Date.now()}-${globalThis.crypto.randomUUID()}`
export const json = async (full) => JSON.parse(await fs.readFile(full, "utf8"))

function unnamespace(value) {
  if (value.startsWith("\\\\?\\UNC\\")) return `\\\\${value.slice(8)}`
  if (value.startsWith("\\\\?\\")) return value.slice(4)
  if (value.startsWith("\\??\\")) return value.slice(4)
  return value
}
export function bound(full) {
  const resolved = path.resolve(unnamespace(full))
  const relative = path.relative(runRoot, resolved)
  requireFact(relative === "" || (!path.isAbsolute(relative) && relative !== ".." && !relative.startsWith(`..${path.sep}`)), `Outside new owned namespace: ${full}`)
  return resolved
}
export async function directDirectory(full) {
  const item = await fs.lstat(full)
  requireFact(item.isDirectory() && !item.isSymbolicLink(), `Direct directory required: ${full}`)
  requireFact(samePath(await fs.realpath(full), full), `Directory alias is not admitted: ${full}`)
}
export async function directOwned(full) {
  let cursor = bound(full)
  for (;;) {
    const item = await fs.lstat(cursor)
    requireFact(!item.isSymbolicLink(), `Direct owned entry required: ${cursor}`)
    if (samePath(cursor, runRoot)) break
    cursor = path.dirname(cursor)
  }
  await directDirectory(runRoot)
  return bound(full)
}

/** Bound every declared link hop before following stat/realpath/readFile. Missing is observed, never permission success. */
export async function safeLinkGraph(full, trail = new Set(), hops = 0) {
  requireFact(hops < 32, "Owned link observation exceeded 32 declared hops; unknown retained")
  const target = bound(full)
  await directDirectory(runRoot)
  const segments = path.relative(runRoot, target).split(path.sep).filter(Boolean)
  let current = runRoot
  for (const segment of segments) {
    current = path.join(current, segment)
    let entry
    try { entry = await fs.lstat(current) } catch (error) { if (missing(error)) return; throw error }
    if (!entry.isSymbolicLink()) continue
    const key = path.resolve(current).toLowerCase()
    requireFact(!trail.has(key), `Owned link loop is unknown: ${current}`)
    const text = await fs.readlink(current)
    const parent = await fs.realpath(path.dirname(current))
    bound(parent)
    const declared = bound(path.isAbsolute(unnamespace(text)) ? unnamespace(text) : path.resolve(parent, text))
    const nextTrail = new Set(trail).add(key)
    await safeLinkGraph(declared, nextTrail, hops + 1)
  }
}

function stats(item) {
  return { file: item.isFile(), directory: item.isDirectory(), symbolicLink: item.isSymbolicLink(), device: String(item.dev), inode: String(item.ino), birthtimeNs: String(item.birthtimeNs), mode: String(item.mode), size: Number(item.size) }
}
export async function observe(full, bytes = false) {
  full = bound(full)
  await safeLinkGraph(full)
  const result = { full, at: stamp() }
  let entry
  try { entry = await fs.lstat(full, { bigint: true }); result.entry = { state: "present", ...stats(entry) } }
  catch (error) { result.entry = { state: "error", error: factError(error) }; if (!missing(error)) throw Object.assign(error, { observation: result }) }
  if (entry?.isSymbolicLink()) {
    try { result.readlink = { state: "present", text: await fs.readlink(full) } }
    catch (error) { result.readlink = { state: "error", error: factError(error) }; throw Object.assign(error, { observation: result }) }
  }
  try { result.target = { state: "present", ...stats(await fs.stat(full, { bigint: true })) } }
  catch (error) { result.target = { state: "error", error: factError(error) }; if (!missing(error)) throw Object.assign(error, { observation: result }) }
  try { const value = await fs.realpath(full); bound(value); result.realpath = { state: "present", value } }
  catch (error) { result.realpath = { state: "error", error: factError(error) }; if (!missing(error)) throw Object.assign(error, { observation: result }) }
  if (bytes && result.target?.file) {
    const value = await fs.readFile(full)
    result.content = { bytes: value.byteLength, bytesBase64: value.toString("base64") }
  }
  return result
}
export const sameEntry = (a, b) => a?.state === "present" && b?.state === "present" && ["device", "inode", "file", "directory", "symbolicLink"].every((key) => a[key] === b[key])

export async function save(name, data) {
  requireFact(path.basename(name) === name, "Evidence basename required")
  await fs.mkdir(evidence, { recursive: true })
  await directDirectory(evidence)
  const full = path.join(evidence, name)
  await fs.writeFile(full, JSON.stringify(data, null, 2), { flag: "wx" })
  return full
}
export async function loadFixture() {
  const full = await directOwned(path.join(runRoot, "prepared-fixture.json"))
  const fixture = await json(full)
  requireFact(fixture.schema === schema && fixture.qualification === qualification, "Exact new fixture schema/qualification required")
  requireFact(fixture.prefix === prefix && fixture.port === port && samePath(fixture.runRoot, runRoot), "Exact new fixture namespace required")
  requireFact(fixture.modelCallsRequested === "none" && fixture.credentialCatalogStaging === "none", "No model or credential staging is admitted")
  for (const role of ["root", "b"]) {
    requireFact(samePath(fixture.scopes[role].directory, projects[role]), "Exact physical Project root required")
    requireFact(sameEntry((await observe(projects[role])).entry, fixture.scopes[role].identity.entry), "Original Project entry changed")
    requireFact(sameEntry((await observe(path.join(projects[role], ".git"))).entry, fixture.scopes[role].gitIdentity.entry), "Original independent Git entry changed")
  }
  return fixture
}
export async function loadOwner(fixture) {
  const owner = await json(await directOwned(path.join(runRoot, "launch-owner.json")))
  requireFact(owner.fixtureID === fixture.fixtureID && owner.qualification === qualification && owner.evidencePrefix === prefix, "Original launch owner does not bind this fixture")
  requireFact(owner.port === port && samePath(owner.runRoot, runRoot) && samePath(owner.project, projects.root) && samePath(owner.projectB, projects.b), "Original owner Project/port mismatch")
  requireFact(samePath(owner.runtime, path.join(runRoot, "runtime")) && samePath(owner.settlementEvidenceRoot, evidence), "Original owner runtime/evidence mismatch")
  requireFact(typeof owner.occurrence === "string" && owner.occurrence.startsWith(`${prefix}-`), "Original occurrence required")
  for (const item of [owner.host, owner.nativeTarget]) requireFact(Number.isSafeInteger(item?.pid) && item.pid > 0 && /^win32:[0-9]+$/.test(item.processInstanceID), "Actual Host/Target PID and native birth required")
  const ready = await json(await directOwned(path.join(runRoot, "evidence", "native-host-ready.json")))
  const startup = await json(await directOwned(path.join(runRoot, "startup.json")))
  requireFact(ready.occurrence === owner.occurrence && startup.occurrenceID === owner.occurrence && startup.outcome === "listening", "Original ready/startup occurrence mismatch")
  requireFact(ready.host.pid === owner.host.pid && ready.host.processInstanceID === owner.host.processInstanceID && ready.target.pid === owner.nativeTarget.pid && ready.target.processInstanceID === owner.nativeTarget.processInstanceID && startup.pid === owner.nativeTarget.pid, "Original Host/Target birth mismatch")
  requireFact(new URL(startup.url).port === String(port) && ready.deadlineAt === owner.nativeDeadline, "Original listener/deadline input mismatch")
  requireFact(owner.inactivityTimeoutMs === 120000 && ready.inactivityTimeoutMs === 120000 && owner.printLogs === true && ready.printLogs === true, "Reviewed service run input must be original inactivity120000/printLogs=true; this does not declare calibration passed")
  requireFact(owner.nativeDeadline > Date.now(), "Original deadline expired; no relaunch or extension")
  for (const name of ["native-host-settled.json", "native-host-error.json"]) {
    try { await fs.lstat(path.join(runRoot, "evidence", name)); throw new Error(`Original service already has ${name}`) }
    catch (error) { if (error.code !== "ENOENT") throw error }
  }
  return owner
}
/** Exact reviewed registration plan only: four public requests. No mutation, readback or retry mode. */
export function executor(owner, stage, records) {
  const plan = stage.steps
  let cursor = 0
  return async (input) => {
    requireFact(cursor < plan.length && JSON.stringify(input) === JSON.stringify(plan[cursor]), "Only the next original predeclared request is admitted")
    requireFact(owner.nativeDeadline > Date.now(), "Original execution deadline reached")
    const sequence = stage.firstSequence + cursor++
    requireFact(sequence <= 4, "Original registration HTTP budget4 exceeded")
    const url = new URL(input.route, `http://127.0.0.1:${port}`)
    url.searchParams.set("directory", projects[input.role])
    for (const [key, value] of Object.entries(input.query ?? {})) url.searchParams.set(key, String(value))
    const requestBody = input.body === undefined ? undefined : JSON.stringify(input.body)
    const record = { sequence, input, occurrence: owner.occurrence, host: owner.host, nativeTarget: owner.nativeTarget, url: url.toString(), method: input.method, requestBody, requestBodyBase64: requestBody === undefined ? undefined : Buffer.from(requestBody).toString("base64"), dispatchedAt: stamp(), chunks: [] }
    records.push(record)
    let error
    const received = []
    try {
      const response = await fetch(url, { method: input.method, headers: requestBody === undefined ? undefined : { "content-type": "application/json" }, body: requestBody, signal: AbortSignal.timeout(Math.min(20000, owner.nativeDeadline - Date.now())) })
      record.status = response.status; record.headers = Object.fromEntries(response.headers); record.requestID = response.headers.get("x-opencorvus-request-id"); record.headersAt = stamp()
      if (response.body) for await (const value of response.body) { const bytes = Buffer.from(value); received.push(bytes); record.chunks.push({ at: stamp(), bytes: bytes.length, bytesBase64: bytes.toString("base64") }) }
      const bytes = Buffer.concat(received)
      record.rawBodyBase64 = bytes.toString("base64"); record.rawBody = bytes.toString("utf8"); record.bodyCompleteAt = stamp()
      try { record.body = JSON.parse(record.rawBody) } catch (cause) { record.parseError = factError(cause); error = cause }
    } catch (cause) { record.error = factError(cause); record.failedAt = stamp(); record.rawBodyBase64 = Buffer.concat(received).toString("base64"); record.rawBody = Buffer.concat(received).toString("utf8"); record.bodyState = "incomplete"; error = cause }
    await save(`http-${String(sequence).padStart(2, "0")}-${input.label}.json`, record)
    console.log(JSON.stringify({type:"original-guard-http",record}))
    if (error) throw Object.assign(error, { originalHTTP: record })
    return record
  }
}
