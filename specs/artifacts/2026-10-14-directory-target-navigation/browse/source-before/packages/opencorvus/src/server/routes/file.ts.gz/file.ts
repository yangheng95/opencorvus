import { Hono } from "hono"
import { describeRoute, resolver } from "hono-openapi"
import { validator } from "@/server/validator"
import z from "zod"
import { File } from "../../file"
import { Ripgrep } from "../../file/ripgrep"
import { Instance } from "../../project/instance"
import { badRequestOrNamedErrorResponse, errors, namedErrorResponse } from "../error"
import { lazy } from "../../util/lazy"

export const FileRoutes = lazy(() =>
  new Hono()
    .get(
      "/find",
      describeRoute({
        summary: "Find text",
        description: "Search for text patterns across files in the project using ripgrep.",
        operationId: "find.text",
        responses: {
          200: {
            description: "Matches",
            content: {
              "application/json": {
                schema: resolver(Ripgrep.Match.shape.data.array()),
              },
            },
          },
          ...errors(500),
        },
      }),
      validator(
        "query",
        z.object({
          pattern: z.string(),
        }),
      ),
      async (c) => {
        const pattern = c.req.valid("query").pattern
        const result = await Ripgrep.searchHost({
          cwd: Instance.directory,
          pattern,
          limit: 10,
        })
        return c.json(result)
      },
    )
    .get(
      "/find/file",
      describeRoute({
        summary: "Find files",
        description: "Search for files or directories by name or pattern in the project directory.",
        operationId: "find.files",
        responses: {
          200: {
            description: "File paths",
            content: {
              "application/json": {
                schema: resolver(z.string().array()),
              },
            },
          },
          ...errors(500),
        },
      }),
      validator(
        "query",
        z.object({
          query: z.string(),
          dirs: z.enum(["true", "false"]).optional(),
          type: z.enum(["file", "directory"]).optional(),
          limit: z.coerce.number().int().min(1).max(200).optional(),
        }),
      ),
      async (c) => {
        const query = c.req.valid("query").query
        const dirs = c.req.valid("query").dirs
        const type = c.req.valid("query").type
        const limit = c.req.valid("query").limit
        const results = await File.search({
          query,
          limit: limit ?? 10,
          dirs: dirs !== "false",
          type,
        })
        return c.json(results)
      },
    )
    .get(
      "/file",
      describeRoute({
        summary: "List files",
        description: "List files and directories in a specified path.",
        operationId: "file.list",
        responses: {
          200: {
            description: "Files and directories",
            content: {
              "application/json": {
                schema: resolver(File.Node.array()),
              },
            },
          },
        },
      }),
      validator(
        "query",
        z.object({
          path: z.string(),
        }),
      ),
      async (c) => {
        const path = c.req.valid("query").path
        const content = await File.list(path)
        return c.json(content)
      },
    )
    .get(
      "/file/content",
      describeRoute({
        summary: "Read file",
        description: "Read the content of a specified file.",
        operationId: "file.read",
        responses: {
          200: {
            description: "File content",
            content: {
              "application/json": {
                schema: resolver(File.Content),
              },
            },
          },
          404: namedErrorResponse("File not found", "FileNotFoundError"),
          500: namedErrorResponse("File read failed", "UnknownError"),
        },
      }),
      validator(
        "query",
        z.object({
          path: z.string(),
        }),
      ),
      async (c) => {
        const path = c.req.valid("query").path
        const content = await File.read(path)
        return c.json(content)
      },
    )
    .get(
      "/file/source-content",
      describeRoute({
        summary: "Read an absolute source file",
        description: "Read the exact absolute file represented by a persisted source-file citation.",
        operationId: "file.readSource",
        responses: {
          200: {
            description: "Read-only source file content",
            content: {
              "application/json": {
                schema: resolver(File.Content),
              },
            },
          },
          400: badRequestOrNamedErrorResponse("Invalid source file request", "FileInvalidPathError"),
          404: namedErrorResponse("Source file not found", "FileNotFoundError"),
          ...errors(500),
        },
      }),
      validator(
        "query",
        z.object({
          path: z.string(),
        }),
      ),
      async (c) => {
        const path = c.req.valid("query").path
        const content = await File.readSource(path)
        return c.json(content)
      },
    )
    .patch(
      "/file/content",
      describeRoute({
        summary: "Write file",
        description:
          "Write text content to an existing editable file only when expectedRevision matches its loaded content and physical identity.",
        operationId: "file.write",
        responses: {
          200: {
            description: "Updated file content",
            content: {
              "application/json": {
                schema: resolver(File.Content),
              },
            },
          },
          ...errors(400, 404, 500),
          409: namedErrorResponse("File changed since it was loaded", "FileWriteConflictError"),
        },
      }),
      validator(
        "json",
        z.object({
          path: z.string(),
          content: z.string(),
          expectedRevision: File.ContentRevision,
        }),
      ),
      async (c) => {
        const input = c.req.valid("json")
        const content = await File.writeText(input.path, input.content, input.expectedRevision)
        return c.json(content)
      },
    )
    .post(
      "/file/item",
      describeRoute({
        summary: "Create file item",
        description: "Create one file or directory under an existing project directory without overwriting.",
        operationId: "file.create",
        responses: {
          200: {
            description: "Created file node",
            content: {
              "application/json": {
                schema: resolver(File.Node),
              },
            },
          },
          ...errors(400, 404, 409),
        },
      }),
      validator("json", File.CreateRequest),
      async (c) => {
        const input = c.req.valid("json")
        const node = await File.create(input)
        return c.json(node)
      },
    )
    .post(
      "/file/item/copy",
      describeRoute({
        summary: "Copy file item",
        description: "Copy one file or directory within the project directory without overwriting.",
        operationId: "file.copy",
        responses: {
          200: {
            description: "Copied file node",
            content: {
              "application/json": {
                schema: resolver(File.CopyResult),
              },
            },
          },
          ...errors(400, 404, 409),
        },
      }),
      validator("json", File.CopyRequest),
      async (c) => {
        const input = c.req.valid("json")
        const result = await File.copy(input)
        return c.json(result)
      },
    )
    .patch(
      "/file/item",
      describeRoute({
        summary: "Move file item",
        description: "Move or rename one file or directory within the project directory without overwriting.",
        operationId: "file.move",
        responses: {
          200: {
            description: "Moved file node",
            content: {
              "application/json": {
                schema: resolver(File.MoveResult),
              },
            },
          },
          ...errors(400, 404, 409),
        },
      }),
      validator("json", File.MoveRequest),
      async (c) => {
        const input = c.req.valid("json")
        const result = await File.move(input)
        return c.json(result)
      },
    )
    .delete(
      "/file/item",
      describeRoute({
        summary: "Delete file item",
        description: "Delete one project file or directory recursively. The project root cannot be deleted.",
        operationId: "file.delete",
        responses: {
          200: {
            description: "Deleted file path",
            content: {
              "application/json": {
                schema: resolver(File.DeleteResult),
              },
            },
          },
          ...errors(400, 404),
        },
      }),
      validator(
        "query",
        z.object({
          path: z.string(),
        }),
      ),
      async (c) => {
        const path = c.req.valid("query").path
        const result = await File.remove({ path })
        return c.json(result)
      },
    )
    .post(
      "/file/upload",
      describeRoute({
        summary: "Upload files",
        description: "Write dropped files into an existing project directory without overwriting existing files.",
        operationId: "file.upload",
        responses: {
          200: {
            description: "Uploaded files",
            content: {
              "application/json": {
                schema: resolver(File.UploadResult.array()),
              },
            },
          },
          ...errors(400, 409),
        },
      }),
      validator("json", File.UploadRequest),
      async (c) => {
        const input = c.req.valid("json")
        const result = await File.upload(input)
        return c.json(result)
      },
    )
    .get(
      "/file/status",
      describeRoute({
        summary: "Get file status",
        description: "Get the git status of all files in the project.",
        operationId: "file.status",
        responses: {
          200: {
            description: "File status",
            content: {
              "application/json": {
                schema: resolver(File.Info.array()),
              },
            },
          },
        },
      }),
      async (c) => {
        const content = await File.status()
        return c.json(content)
      },
    ),
)
