/** PREPARED ONLY. Root separately authorizes Prepare, launch, and Register. No mutation or readback mode. */
import fs from "node:fs/promises"
import path from "node:path"
import { execFile } from "node:child_process"
import { promisify } from "node:util"
import {
  scratch, runRoot, evidence, projects, prefix, port, schema, qualification,
  stamp, factError, requireFact, samePath, missing, bound, directDirectory,
  directOwned, observe, sameEntry, save, label, loadFixture, loadOwner, executor,
} from "./fixture-support.mjs"

const [mode] = process.argv.slice(2)
requireFact(process.argv.length === 3 && ["prepare", "register"].includes(mode), "Usage: fixture-tool.mjs <prepare|register>; every mode requires separate Root authorization")
const join = (role, relative) => bound(path.join(projects[role], relative))
const tiny = (literal) => Buffer.from(literal, "utf8")
const files = [
  { role: "root", path: "root-marker.txt", bytes: tiny("BROWSE ROOT A 01a133\r\n") },
  { role: "root", path: "data/marker.txt", bytes: tiny("BROWSE DATA A 01a133\r\n") },
  { role: "root", path: "source-tree/note.txt", bytes: tiny("BROWSE TREE A 01a133\r\n") },
  { role: "root", path: ".gitignore", bytes: tiny("/source-j/\n") },
  { role: "b", path: "root-marker.txt", bytes: tiny("BROWSE ROOT B 01a133\r\n") },
  { role: "b", path: ".gitignore", bytes: tiny("") },
]
files.push({ role: "root", path: "project-b/root-marker.txt", bytes: tiny("BROWSE INNER A 01a133\r\n") })
const links = [
  { role: "root", path: "source-j", text: join("root", "data"), kind: "junction" },
  { role: "root", path: "source-s", text: join("root", "data"), kind: "dir" },
  { role: "root", path: "alias-j", text: join("root", "data"), kind: "junction" },
  { role: "root", path: "alias-s", text: join("root", "data"), kind: "dir" },
  { role: "root", path: "context/indirect-relative", text: "../source-j", kind: "dir" },
]
for (const item of links) item.targetDirectory = join("root", "data")
links.push({ role: "root", path: "aliases/root-back", text: projects.root, kind: "junction", targetDirectory: projects.root },
  { role: "root", path: "context/relative", text: "../project-b", kind: "dir", targetDirectory: join("root", "project-b") })
links.push({ role: "root", path: "outside-alias", text: projects.b, kind: "junction", targetDirectory: projects.b })
const extraLinks = [
  { role: "root", path: "file-alias", text: "root-marker.txt", kind: "file" },
  { role: "root", path: "broken-alias", text: "missing-dir", kind: "dir" },
]
const pickerLiteral = tiny("BROWSE UPLOAD 01a133\r\n")
const directories = { root: ["data", "context", "source-tree", "project-b", "aliases"], b: [] }
const registeredRule = Buffer.from(".opencorvus/.r/\n", "utf8")
const steps = ["root", "b"].flatMap((role) => [
  { label: `register-${role}-project`, role, method: "GET", route: "/project/current", query: {} },
  { label: `register-${role}-chat`, role, method: "POST", route: "/coding/chat/session", query: {}, body: {} },
])
const registrationPlan = { firstSequence: 1, steps }
const inputBytes = files.reduce((count, item) => count + item.bytes.byteLength, pickerLiteral.length)
requireFact(inputBytes <= 512 && links.length === 8 && steps.length === 4, "Reviewed literal/link/registration budget changed")
const originalInputs = {
  files: files.map(({ bytes, ...item }) => ({ ...item, size: bytes.length, bytesBase64: bytes.toString("base64"), literal: bytes.toString("utf8") })),
  directories, links, extraLinks, picker: { name: "browser-upload.txt", bytesBase64: pickerLiteral.toString("base64") }, registrationPlan, maximumHTTP: 4, maximumLiteralBytes: 512, actualLiteralBytes: inputBytes,
  modelCallsRequested: "none", credentialCatalogStaging: "none",
  boundary: "Prepare only creates these inputs; Register only performs four ordinary public Project/empty-Chat requests. Root separately owns all UI and mutation/readback actions.",
}
const result = { mode, startedAt: stamp(), executable: process.execPath, runtime: process.versions, platform: process.platform, requests: [], originalInputs }
console.log(JSON.stringify({type:"original-guard-input",mode,originalInputs,startedAt:result.startedAt}))

async function markerFacts(fixture, stage) {
  requireFact(stage === "prepared" || stage === "registered", "Explicit original literal stage required")
  const facts = []
  for (const item of fixture.files) {
    const expected = stage === "registered" && item.path === ".gitignore"
      ? Buffer.concat([Buffer.from(item.bytesBase64, "base64"), registeredRule])
      : Buffer.from(item.bytesBase64, "base64")
    const actual = await observe(item.full, true)
    facts.push({ role: item.role, path: item.path, expectedStage: stage,
      expectedBytesSource: stage === "registered" && item.path === ".gitignore" ? "prepared-literal-plus-predeclared-canonical-runtime-rule" : "prepared-literal",
      expectedBytesBase64: expected.toString("base64"), actual })
    requireFact(sameEntry(actual.entry, item.original.entry) && actual.content?.bytesBase64 === expected.toString("base64"), `Original ${stage} entry/literal changed: ${item.path}`)
  }
  return facts
}

async function linkFacts(fixture) {
  const facts = []
  for (const item of fixture.links) {
    const actual = await observe(item.full)
    facts.push({ role: item.role, path: item.path, declaredText: item.text, original: item.original, actual })
    requireFact(sameEntry(actual.entry, item.original.entry) && actual.readlink?.text === item.original.readlink?.text, `Original dedicated link changed: ${item.path}`)
    requireFact(actual.target?.directory === true && samePath(actual.realpath?.value, item.targetDirectory), `Original link is not the declared healthy owned directory: ${item.path}`)
  }
  return facts
}

async function prepare() {
  requireFact(process.platform === "win32", "Reviewed guard fixture is Windows only")
  const fixture = { schema, qualification, fixtureID: globalThis.crypto.randomUUID(), runRoot, prefix, port,
    project: projects.root, projectB: projects.b, modelCallsRequested: "none", credentialCatalogStaging: "none",
    preparedAt: stamp(), scopes: {}, files: [], links: [], extraLinks: [], git: [], pickerInputs: [], originalInputs,
    completeInputBytes: inputBytes, registrationPlan,
    qualificationBoundary: "Real desktop directory-target browsing and alias destinations; no model or non-Windows acceptance is claimed" }
  result.fixture = fixture
  await save("prepare-admission.json", { schema, qualification, fixtureID: fixture.fixtureID, runRoot, prefix, port,
    originalInputs, at: stamp(), boundary: "Exclusive new namespace; first failure retained, no deletion/reuse/retry" })
  const day = path.dirname(runRoot)
  await directDirectory(path.dirname(day))
  try { await fs.lstat(day) } catch (error) { if (!missing(error)) throw error; await fs.mkdir(day) }
  await directDirectory(day)
  await fs.mkdir(runRoot)
  await directDirectory(runRoot)
  for (const name of ["runtime", "project", "project-b", "evidence", "home", "appdata", "localappdata", "temp", "xdg-config", "xdg-data", "xdg-cache", "xdg-state", "inputs"]) await fs.mkdir(path.join(runRoot, name))
  // The new passive observation namespace is direct and exclusive. No previous observer or receipt is reused.
  const passive = path.join(scratch, "native-observer")
  await fs.mkdir(passive)
  for (const name of ["runtime", "home"]) await fs.mkdir(path.join(passive, name))
  for (const full of [passive, path.join(passive, "runtime"), path.join(passive, "home")]) await directDirectory(full)
  fixture.passiveObserver = { root: passive, runtime: path.join(passive, "runtime"), home: path.join(passive, "home"), qualification: "Direct new passive namespace; no process or service exists merely from preparing directories" }
  for (const role of ["root", "b"]) for (const relative of directories[role]) await fs.mkdir(join(role, relative))
  const execute = promisify(execFile)
  const gitEnvironment = Object.fromEntries(["PATH", "SystemRoot", "WINDIR", "ComSpec", "PATHEXT"].filter((name) => process.env[name] !== undefined).map((name) => [name, process.env[name]]))
  Object.assign(gitEnvironment, { HOME: path.join(runRoot, "home"), USERPROFILE: path.join(runRoot, "home"), APPDATA: path.join(runRoot, "appdata"), LOCALAPPDATA: path.join(runRoot, "localappdata"), TEMP: path.join(runRoot, "temp"), TMP: path.join(runRoot, "temp"), GIT_CONFIG_NOSYSTEM: "1", GIT_CONFIG_GLOBAL: "NUL" })
  for (const role of ["root", "b"]) {
    const git = { role, executable: "git", args: ["-C", projects[role], "init", "--initial-branch=main", "--template="], startedAt: stamp() }
    fixture.git.push(git)
    try {
      const output = await execute("git", git.args, { env: gitEnvironment, windowsHide: true, timeout: 15000, encoding: "buffer" })
      Object.assign(git, { stdoutBase64: output.stdout.toString("base64"), stderrBase64: output.stderr.toString("base64"), stdout: output.stdout.toString("utf8"), stderr: output.stderr.toString("utf8"), exitCode: 0, completedAt: stamp() })
      console.log(JSON.stringify({type:"original-git-result",git}))
    } catch (error) {
      Object.assign(git, { error: factError(error), stdoutBase64: error.stdout?.toString("base64"), stderrBase64: error.stderr?.toString("base64"), exitCode: error.code })
      throw error
    }
    fixture.scopes[role] = { directory: projects[role], identity: await observe(projects[role]), gitIdentity: await observe(path.join(projects[role], ".git")) }
  }
  for (const item of files) {
    const full = join(item.role, item.path)
    await directOwned(path.dirname(full))
    await fs.writeFile(full, item.bytes, { flag: "wx" })
    const original = await observe(full, true)
    requireFact(original.content?.bytesBase64 === item.bytes.toString("base64"), "Original literal bytes mismatch")
    fixture.files.push({ role: item.role, path: item.path, full, size: item.bytes.length, bytesBase64: item.bytes.toString("base64"), original })
  }
  for (const item of links) {
    const full = join(item.role, item.path)
    await directOwned(path.dirname(full))
    await fs.symlink(item.text, full, item.kind)
    const original = await observe(full)
    requireFact(original.entry?.symbolicLink === true && original.readlink?.state === "present" && original.target?.directory === true, "Actual declared healthy link entry required")
    if (path.isAbsolute(item.text)) requireFact(samePath(bound(original.readlink.text), item.text), "Original absolute link declaration changed")
    else requireFact(original.readlink.text.replaceAll("\\", "/") === item.text, "Original relative link text changed")
    fixture.links.push({ ...item, full, original })
  }
  for (const item of extraLinks) {
    const full = join(item.role, item.path)
    await fs.symlink(item.text, full, item.kind)
    const original = await observe(full)
    requireFact(original.entry?.symbolicLink === true && original.readlink?.state === "present", "Actual extra symbolic entry required")
    fixture.extraLinks.push({ ...item, full, original })
  }
  const picker = path.join(runRoot, "inputs", "browser-upload.txt")
  await fs.writeFile(picker, pickerLiteral, { flag: "wx" })
  fixture.pickerInputs.push({ full: picker, bytesBase64: pickerLiteral.toString("base64"), original: await observe(picker, true) })
  result.preparedMarkers = await markerFacts(fixture, "prepared")
  result.preparedLinks = await linkFacts(fixture)
  fixture.preparationCompletedAt = stamp()
  await fs.writeFile(path.join(runRoot, "prepared-fixture.json"), JSON.stringify(fixture, null, 2), { flag: "wx" })
  await save("prepared-fixture.json", fixture)
  result.fixtureID = fixture.fixtureID
  result.outcome = "new-exclusive-guard-foundation-fixture-prepared"
}

async function register(fixture, owner) {
  await save("register-admission.json", { fixtureID: fixture.fixtureID, occurrence: owner.occurrence, owner, at: stamp(),
    originalPlan: registrationPlan, maximumHTTP: 4, mutationRequests: 0,
    declaredRuntimeRuleBase64: registeredRule.toString("base64"), boundary: "Normal four requests only; no retry, mutation, source readback, UI or model request" })
  const request = executor(owner, registrationPlan, result.requests)
  const registered = { fixtureID: fixture.fixtureID, occurrence: owner.occurrence, owner, startedAt: stamp(), scopes: {}, requests: result.requests }
  result.registered = registered
  for (const [index, role] of ["root", "b"].entries()) {
    const project = await request(steps[index * 2])
    requireFact(project.status === 200 && typeof project.body?.id === "string" && typeof project.requestID === "string", "Original Project200 required")
    const chat = await request(steps[index * 2 + 1])
    requireFact(chat.status === 201 && typeof chat.body?.session?.id === "string" && typeof chat.requestID === "string", "Original empty Chat201 required")
    requireFact(chat.body.session.projectID === project.body.id && samePath(chat.body.session.directory, projects[role]), "Original Project/Chat scope binding failed")
    registered.scopes[role] = { directory: projects[role], projectID: project.body.id, chatID: chat.body.session.id }
  }
  requireFact(new Set([registered.scopes.root.projectID, registered.scopes.b.projectID]).size === 2 && new Set([registered.scopes.root.chatID, registered.scopes.b.chatID]).size === 2, "Two distinct original Projects and empty Chats required")
  registered.markers = await markerFacts(fixture, "registered")
  registered.links = await linkFacts(fixture)
  registered.completedAt = stamp()
  registered.outcome = "two-original-guard-projects-and-empty-chats-registered"
  await save("registered-projects.json", registered)
  result.outcome = registered.outcome
}

try {
  if (mode === "prepare") await prepare()
  else {
    const fixture = await loadFixture()
    result.fixtureID = fixture.fixtureID
    const owner = await loadOwner(fixture)
    result.owner = owner
    await register(fixture, owner)
  }
  result.completedAt = stamp()
  result.exitCode = 0
} catch (error) {
  result.outcome = "original-first-error-retained-no-retry"
  result.error = factError(error)
  result.originalHTTP = error.originalHTTP
  result.observation = error.observation
  result.failedAt = stamp()
  result.exitCode = 1
}
const full = await save(`${label(mode)}.json`, result)
console.log(JSON.stringify({ mode, outcome: result.outcome, exitCode: result.exitCode, fixtureID: result.fixtureID, evidence: full, actualHTTP: result.requests.length }))
process.exitCode = result.exitCode
