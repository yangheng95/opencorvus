# Dot / mixed access qualifier — prepare-only proposal

## Recall 与当前资格

Root 授权只准备最多六个实际 owned 小场景及只读双 host 观察工具，先读 `state-and-futuretree-amendment.md` 和原固定 metadata 方案；不得执行新 fixture、Native、Node/Bun 模块、API、模型、UI、Git 或修改正式产品/spec。该 amendment 已完整读取，含 raw component、递归返回访问 namespace、futuretree 投影、可分批边界和所有 unknown。原 `native-metadata-qualifier.mjs`、inputs、review、outer recorder 和原固定 C 定义已完整读取。

Root 已报告原 metadata Node25.7.0/Bun1.4.0 各 20 项真实 exit0；本准备没有重跑。该事实证明当时固定 operands 的库/应用二进制接口（Application Binary Interface，ABI），不证明这里未运行的 dot/mixed 语义、替换后的 helper 运行资格、production loader 或 File API。

本子任务只产生本 scratch 新工具/输入/审阅材料及原工具历史副本。没有创建下面的新数据根、fixture ID、literal 文件、链接或 manifest，也没有调用任何新 qualifier、Node/Bun parser、Koffi、Native、API 或 UI。静态全文审查与 PowerShell 读取 JSON/计数不等于 JavaScript syntax 或运行验收。Root 全文审核后才决定 namespace、提取方案和实际执行。

## 精确文件与提取影响

- `dot-mixed-qualifier.inputs.json`：六例完整声明，新的建议物理根、两 exact runtime、literal bytes、创建顺序和 32 个读取 operand。
- `dot-mixed-qualifier.mjs`：单入口 `prepare` / `read`；Prepare 只用 Node 文件系统 primitive，Read 在显式入口才调用 shared native reader。
- `native-metadata-reader.mjs`：原已资格代码的最小 library load / fixed C ABI / 一次 metadata read 提取；另导出同一原错误序列化函数。没有 resolver、fixture、CLI、process owner、计时器、缓存或重试。
- `native-metadata-qualifier.shared-proposal.mjs`：旧 metadata consumer 的**替换提案**，不是第二个应执行的 qualifier；原 20 项不可重跑。Root 若批准提取，应以该提案替换当前原 consumer，历史副本仅保审计，不作为 fallback。
- `native-metadata-shared-reader.exact-changes.json`：每个完整旧/新文本块及用途，供逐项审查；除说明性文件头外，改动仅 import、错误序列化、load/ABI/read 提取和同一个返回 handle 的引用位置。
- `dot-mixed-metadata-history/`：原已执行 metadata qualifier、inputs、review、outer recorder 四份原字节副本。它们与当前原文件均保留；原运行 raw/exit 已由 Root 保全，本任务不重写。

这里没有复制整个 metadata qualifier 作为新的运行框架。两份拟用的 consumer 只消费一个 `createNativeMetadataReader`：固定 createRequire anchor、一次 Koffi load、同一 library/struct/prototypes、原 GetLastError 紧邻调用和 CloseHandle finally。旧原 body 此刻未改，因为 Root 要先审差异再决定替换；提案与历史不构成生产并行实现。

helper 保留确切 Koffi3.3.2 source loader 与实际 loaded `.node` cache/realpath/version 输出，未调用 production package loader，未安装或拷贝 native addon。与原工具相比只多两个 `reader-stage` 输出用于故障归因；它们发生在实际 native 调用之前，不插到 API/GetLastError 之间。旧 consumer 对 loaded library/ABI 的原输出引用仍由其 owner 保存。公开 C 声明及参数完全同源：

```text
CreateFileW(operand, 0, 7, null, 3, 0x02200000, null)
GetFileInformationByHandleEx(handle, 9, two-DWORD library struct, 8)
GetLastError() immediately after each API; CloseHandle(valid original handle) once
```

## 新 namespace 与六例

建议唯一新根：

`C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/directory-target-dot-mixed-01a133`

该路径与原 before、8 mutation、2 native hop、活动 calibration namespaces 均不同。这里不查询其存在性，也不创建它。实际 Prepare 要求日期父目录是原 direct physical directory；唯一根 `mkdir` 无 recursive/no EEXIST recovery。每次目录创建、链接创建和文件 `wx` 都只发生于该新根。第一次失败保留已创建原事实、停止，无删除/清空/重用/重试。fixture ID 只能由一次成功进入 Prepare 的 `randomUUID()` 生成；不存在预造 ID。

每例有独立 case root，完整 schema 输入有 19 个成员目录、12 个普通 marker 文件（总计 **338 个预声明 UTF-8 字节**）、13 个链接；加总根和六个 case root 为 26 个将创建的目录。最后 `dot-mixed-fixture.json` 用 `wx` 写入原 input、actual runtime、每个 direct entry 完整 BigInt lstat、dev/inode/birth/type、原 readlink 和固定文件的完整原 bytes。Prepare 原 stdout 逐步保存创建回执，不把写 manifest 之前的失败隐藏。

| Case | 原链接实参/成员 | 两个不同 goal marker | 读取重点 |
|---|---|---|---|
| dot-ordinary | `tree/v` 普通目录；`tree/u` raw `v/../goal` | `tree/goal`、`physical/goal` | 普通 component 基线 |
| dot-absolute-symbolic | `tree/v` true absolute dir symbolic → `physical/data`；u 同 raw text | 同上、各有本例 literal | 先跟 v 再 dot 与提前 fold 的区别 |
| dot-junction | `tree/v` junction → `physical/data`；u 同 raw text | 同上 | junction context 与 raw dot |
| dot-broken-symbolic | `tree/v` true dir symbolic → 预声明缺失 `physical/missing`；u 同 raw text | 同上 | 是否真实经过 v；不由 text 命名推断依赖 |
| mixed-junction | `S` true absolute dir symbolic → `B/J`；`J` junction → `D/data`；`D/data/r` raw `../goal` | `B/goal`、`D/goal` | 递归返回访问 namespace，直接 r 与 S/r 对照 |
| mixed-absolute-symbolic | `S` true absolute dir symbolic → `B/T`；`T` true absolute dir symbolic → `D/data`；r 同 raw text | 同上 | 内层 true symbolic 与 junction 的对照 |

goal 是不同普通文件，每个有唯一 case/位置的 literal；读取结果按实际完整 bytes 对应预声明 literal，**不预设其中哪一个是正确解析结果**。Prepare 的 symlink `type` 是原创建输入，不被当成 native tag 事实。实际 ReparseTag 只取 C struct 返回值。

四个 dot case 各有五个观察 operand：v、u、两个 goal 和 raw-access。raw-access 通过 `absolute-tree + separator + "v/../goal"` 拼接，刻意不调用 `join/resolve` 处理 raw suffix。这一直接路径对照与保存在 u 里的 raw readlink 是两个不同输入；runtime 自己是否规范化，由原实际结果显示。创建 u 时 raw target 原样传 `fs.symlink`；原 `readlink` 完整保留，只允许验证本机分隔符拼写差异，绝不提前折去 v/..。

两 mixed case 各六个观察 operand：S、J/T、direct r、S/r、B/goal、D/goal。因此每 host 最多 **32 个同固定 flags 的 metadata open 尝试**，每个成功 open 有一次 query 和一次 close。它们仍是六个 case，不扩成 mutation/API 矩阵。

## Read 的真实事实与错误合同

Read 必须显式传 `--host node|bun --fixture-id <Prepare 的原 UUID>`；校验实际 execPath/版本/平台/架构，核对原 manifest ID、完整输入、根/case root dev/inode/birth/type。每例在观察前重读所有实际成员，与原 owner identity、原 readlink 和预声明 literal 核对。直接 ordinary 目录的 realpath 必须仍为该 direct path。broken component 的缺失目标用真实 lstat `ENOENT` 明确合同；这不是针对结果的负向“没有调用/不存在”断言。

每个观察包含原未折叠 operand、完整 BigInt lstat before/after、readlink、stat、realpath，成功值或完整 own-property error/cause/code。后续 content 只在 stat 已是 ≤128B 文件且原 realpath 仍在本次 owned root 时读取，保存**完整** base64、UTF-8、长度与匹配的预声明 marker。目录或 stat/realpath 失败时 content 明确 `not-read` 并保原错误；不会把没有执行的 readFile 编造为 ENOENT，也不会为拿到内容尝试另一坐标。这个约束保留“能读取的实际原完整 tiny bytes”；失败的内容能力由原 stat/realpath errno 证明，不额外冒称实际 readFile error。

native 部分保留 raw handle、query 输出、每个同步 lastError（成功时标 stale）、valid handle 的原 CloseHandle 结果和所有 failure，首 cause 单独引用。actual tag 与 attributes 用 uint32/hex 原值输出；没有名字/关键词 tag 推断。original open error 是所请求访问 operand 的观测事实，不等于 instrumentation 成功；FFI/query/close 异常会在原 record emit 后停止。成功 lstat 的 before/after identity 必须一致；两次 rejected lstat 不虚称“身份稳定”。

Read exit0 的含义仅为该 fixed input 的六例观察完整收齐，**不是所有 open/stat/readlink 都成功，更不是所提 walker 语义通过**。没有 target 预期断言或 Windows/POSIX 相同断言。Root 必须读每例实际 raw、bytes 和 error，形成 host grammar 的明确结论后再决定生产设计。atomic retarget race、跨进程外部修改、网络/云/provider、大小写别名、POSIX/Darwin、futuretree/move-retirement/权限/API/Task/Mission/Session 等均不由这里证明。

## 拟交 Root 的原命令与 capture

下列仅为待审命令，没有在本子任务执行。Node/Bun 进程的唯一 stdout/stderr/exit capture 仍由 Root 成熟 outer recorder 负责；这里不新建 child-process runner、Native host、timer 或控制 namespace。Root 可沿原 metadata recorder 的 30s/8MiB 单次工具预算，分别用新的唯一 `dot-mixed-*` prefix 写原 input/raw/exit，不覆盖任一旧 metadata prefix。不能把 outer timeout 或只读裸库观察称为 NativeFacade settlement / 服务900s预算资格。

```powershell
# Optional parser-only stage; does not import/load these modules. Root records each original result.
& 'C:/Program Files/nodejs/node.exe' --check 'D:/myhexin-local/opencorvus/.tmp-codex-directory-target-01a133/native-metadata-reader.mjs'
& 'C:/Program Files/nodejs/node.exe' --check 'D:/myhexin-local/opencorvus/.tmp-codex-directory-target-01a133/dot-mixed-qualifier.mjs'
& 'C:/Program Files/nodejs/node.exe' --check 'D:/myhexin-local/opencorvus/.tmp-codex-directory-target-01a133/native-metadata-qualifier.shared-proposal.mjs'

# Exact one-time Prepare, only after Root approves the fixture namespace/input and capture.
& 'C:/Program Files/nodejs/node.exe' 'D:/myhexin-local/opencorvus/.tmp-codex-directory-target-01a133/dot-mixed-qualifier.mjs' prepare --host node

# Exact read-only stages; insert the actual UUID returned by that Prepare, not a placeholder/generated replacement.
& 'C:/Program Files/nodejs/node.exe' 'D:/myhexin-local/opencorvus/.tmp-codex-directory-target-01a133/dot-mixed-qualifier.mjs' read --host node --fixture-id '<actual-Prepare-fixtureID>'
& 'D:/myhexin-local/opencorvus/.tmp-codex-directory-target-01a133/ui-bundle/bin/bun.exe' 'D:/myhexin-local/opencorvus/.tmp-codex-directory-target-01a133/dot-mixed-qualifier.mjs' read --host bun --fixture-id '<same-actual-Prepare-fixtureID>'
```

两个 Read 共用一次真实 fixture，均无 FS 写入；host 读操作可能自然更新访问时间，identity 比较不拿可变访问时间当同一文件依据。原完整 stat 仍留字段。Root 如观测首次异常应保原 partial/raw/exit，先修工具或分析结果；不得复用已失败 Prepare 根假装新 occurrence。

## 未完成与正式范围

当前仅代码/输入准备与静态阅读：三个新 JS 文件的 parser 资格、helper 的执行资格、实际 fixture、两个 Read 及所有新 dot/mixed 结论均**未完成**。原 metadata 各20实际0仅引用 Root 已提供的历史，不转移为新工具绿灯。新 namespace 和提案替换仍待 Root 完整审阅，不是等待用户重复授权。

六例只补当前已有 entry 上访问 namespace/dot 的证据。它不构造 future projection，不修现 `path.resolve(parent, readlink)` 的共享 relocation 缺口，不为目录 UI 新增可浏览能力，不为 Task/Capsule 共享机制排除未知。后续生产修改仍须以 Root 完整根因和正式 spec 为准。
