/** Preparation proposal only. Prepare mutates a new owned fixture; Read is read-only. */
import assert from "node:assert/strict"
import fs from "node:fs/promises"
import path from "node:path"
import { randomUUID } from "node:crypto"
import { fileURLToPath } from "node:url"
import { createNativeMetadataReader, originalError } from "./native-metadata-reader.mjs"

const scriptDirectory = path.dirname(fileURLToPath(import.meta.url))
const inputPath = path.join(scriptDirectory, "dot-mixed-qualifier.inputs.json")
const samePath = (left, right) => path.resolve(left).toLowerCase() === path.resolve(right).toLowerCase()
const stringify = (value) => JSON.stringify(value, (_key, item) => typeof item === "bigint" ? { type: "bigint", value: String(item) } : item)
const emit = (value) => new Promise((resolve, reject) => process.stdout.write(stringify(value) + "\n", (error) => error ? reject(error) : resolve()))
const fullStat = (value) => ({
  fields: Object.fromEntries(Object.entries(value).map(([key, item]) => [key, typeof item === "bigint" ? String(item) : item instanceof Date ? item.toISOString() : item])),
  isFile: value.isFile(), isDirectory: value.isDirectory(), isSymbolicLink: value.isSymbolicLink(),
  isBlockDevice: value.isBlockDevice(), isCharacterDevice: value.isCharacterDevice(), isFIFO: value.isFIFO(), isSocket: value.isSocket(),
})
const identity = (stat) => ({ dev: stat.fields.dev, ino: stat.fields.ino, birthtimeNs: stat.fields.birthtimeNs,
  isFile: stat.isFile, isDirectory: stat.isDirectory, isSymbolicLink: stat.isSymbolicLink })
const byteFact = (bytes) => ({ byteLength: bytes.length, base64: bytes.toString("base64"), utf8: bytes.toString("utf8") })
async function observe(operation, operand, read) {
  try { return { operation, operand, status: "fulfilled", value: await read() } }
  catch (error) { return { operation, operand, status: "rejected", code: error?.code, error: originalError(error) } }
}
function declaredPath(root, relative) {
  assert.equal(typeof relative, "string")
  assert.ok(relative.length > 0 && !path.isAbsolute(relative))
  assert.ok(relative.split(/[\\/]/).every((item) => item && item !== "." && item !== ".."))
  return path.join(root, relative)
}
function observationPath(caseRoot, item) {
  if (item.path !== undefined) return declaredPath(caseRoot, item.path)
  assert.equal(item.rawSuffix, "v/../goal")
  // Concatenation is deliberate: path.join/resolve would remove the component being qualified.
  return declaredPath(caseRoot, item.base) + path.sep + item.rawSuffix
}
async function assertDirectDirectory(directory) {
  const stat = fullStat(await fs.lstat(directory, { bigint: true }))
  const realpath = await fs.realpath(directory)
  assert.ok(stat.isDirectory && !stat.isSymbolicLink)
  assert.ok(samePath(directory, realpath))
  return { path: directory, stat, realpath }
}
function declaredMembers(caseInput) {
  return [
    ...caseInput.directories.map((relative) => ({ relative, kind: "directory" })),
    ...caseInput.files.map((item) => ({ relative: item.path, kind: "file", literal: item.literal })),
    ...caseInput.links.map((item) => ({ relative: item.path, kind: "link", link: item })),
  ]
}
async function captureMember(caseRoot, member, maximumFileBytes) {
  const operand = declaredPath(caseRoot, member.relative)
  const stat = fullStat(await fs.lstat(operand, { bigint: true }))
  const result = { ...member, operand, stat, identity: identity(stat) }
  if (member.kind === "directory") {
    assert.ok(stat.isDirectory && !stat.isSymbolicLink)
    result.realpath = await fs.realpath(operand)
    assert.ok(samePath(operand, result.realpath))
  } else if (member.kind === "file") {
    assert.ok(stat.isFile && !stat.isSymbolicLink)
    assert.ok(BigInt(stat.fields.size) <= BigInt(maximumFileBytes))
    const bytes = await fs.readFile(operand)
    result.bytes = byteFact(bytes)
    assert.deepEqual(bytes, Buffer.from(member.literal, "utf8"))
  } else {
    assert.ok(stat.isSymbolicLink)
    result.readlink = await fs.readlink(operand)
    if (member.link.rawRelativeText !== undefined) {
      // Record the original value; this check permits only native separator spelling, never dot folding.
      assert.equal(result.readlink.replace(/\\/g, "/"), member.link.rawRelativeText)
    } else assert.ok(samePath(result.readlink, declaredPath(caseRoot, member.link.absoluteTarget)))
  }
  return result
}

let stage = "input"
let fixtureID
let input
let completedCases = 0
try {
  const mode = process.argv[2]
  assert.ok(mode === "prepare" || mode === "read")
  assert.equal(process.argv[3], "--host")
  const host = process.argv[4]
  assert.ok(host === "node" || host === "bun")
  assert.equal(process.argv.length, mode === "prepare" ? 5 : 7)
  if (mode === "prepare") assert.equal(host, "node")
  else { assert.equal(process.argv[5], "--fixture-id"); fixtureID = process.argv[6]; assert.match(fixtureID, /^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/) }
  input = JSON.parse(await fs.readFile(inputPath, "utf8"))
  assert.equal(input.schema, "directory-target-dot-mixed-input/v1")
  assert.equal(input.maximumCases, 6)
  assert.equal(input.cases.length, 6)
  assert.equal(input.maximumFileBytes, 128)
  assert.equal(input.manifestName, "dot-mixed-fixture.json")
  assert.equal(process.platform, input.platform)
  assert.equal(process.arch, input.architecture)
  assert.ok(samePath(process.execPath, input.runtimes[host].executable))
  if (host === "node") assert.equal(process.versions.node, input.runtimes.node.nodeVersion)
  else assert.equal(process.versions.bun, input.runtimes.bun.bunVersion)
  assert.ok(samePath(input.runRoot, "C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/directory-target-dot-mixed-01a133"))
  assert.equal(input.modelCallsRequested, "none")
  assert.deepEqual(input.cases.map((item) => item.id), ["dot-ordinary", "dot-absolute-symbolic", "dot-junction", "dot-broken-symbolic", "mixed-junction", "mixed-absolute-symbolic"])
  for (const caseInput of input.cases) {
    assert.equal(new Set(declaredMembers(caseInput).map((item) => item.relative)).size, declaredMembers(caseInput).length)
    for (const file of caseInput.files) assert.ok(Buffer.byteLength(file.literal, "utf8") <= input.maximumFileBytes)
    for (const link of caseInput.links) {
      assert.ok(["file", "dir", "junction"].includes(link.type))
      assert.equal(Number(link.rawRelativeText !== undefined) + Number(link.absoluteTarget !== undefined), 1)
      if (link.rawRelativeText !== undefined) assert.ok(["v/../goal", "../goal"].includes(link.rawRelativeText))
    }
  }
  await emit({ type: "original-input", mode, host, inputPath, input, fixtureID, executable: process.execPath,
    versions: { ...process.versions }, platform: process.platform, architecture: process.arch, startedAt: new Date().toISOString() })
  const manifestPath = path.join(input.runRoot, input.manifestName)

  if (mode === "prepare") {
    stage = "prepare:existing-direct-parent"
    const parent = await assertDirectDirectory(path.dirname(input.runRoot))
    fixtureID = randomUUID()
    stage = "prepare:exclusive-root"
    await fs.mkdir(input.runRoot) // Exclusive: no recursive mkdir, EEXIST recovery, reuse or cleanup.
    await emit({ type: "created-root", fixtureID, runRoot: input.runRoot, parent })
    const manifest = { schema: "directory-target-dot-mixed-fixture/v1", fixtureID, input, createdAt: new Date().toISOString(),
      executable: process.execPath, versions: { ...process.versions }, cases: [] }
    for (const caseInput of input.cases) {
      const caseRoot = declaredPath(input.runRoot, caseInput.id)
      stage = `prepare:${caseInput.id}:root`
      await fs.mkdir(caseRoot)
      for (const relative of caseInput.directories) {
        const operand = declaredPath(caseRoot, relative)
        stage = `prepare:mkdir:${operand}`
        await fs.mkdir(operand)
        await emit({ type: "created-directory", fixtureID, caseID: caseInput.id, operand })
      }
      for (const file of caseInput.files) {
        const operand = declaredPath(caseRoot, file.path)
        stage = `prepare:write-exclusive:${operand}`
        await fs.writeFile(operand, file.literal, { flag: "wx", encoding: "utf8" })
        await emit({ type: "created-literal-file", fixtureID, caseID: caseInput.id, operand, literal: file.literal, bytes: byteFact(Buffer.from(file.literal, "utf8")) })
      }
      for (const link of caseInput.links) {
        const operand = declaredPath(caseRoot, link.path)
        const target = link.rawRelativeText ?? declaredPath(caseRoot, link.absoluteTarget)
        stage = `prepare:symlink:${operand}`
        await fs.symlink(target, operand, link.type) // Raw relative text is passed unchanged.
        await emit({ type: "created-link", fixtureID, caseID: caseInput.id, operand, originalTargetArgument: target, originalTypeArgument: link.type, actualReadlink: await fs.readlink(operand) })
      }
      stage = `prepare:original-members:${caseInput.id}`
      const members = []
      for (const member of declaredMembers(caseInput)) members.push(await captureMember(caseRoot, member, input.maximumFileBytes))
      const missing = []
      for (const item of caseInput.declaredMissing ?? []) {
        const record = await observe("lstat-bigint", declaredPath(caseRoot, item.path), () => fs.lstat(declaredPath(caseRoot, item.path), { bigint: true }).then(fullStat))
        await emit({ type: "declared-missing-original", fixtureID, caseID: caseInput.id, record })
        assert.equal(record.status, "rejected"); assert.equal(record.code, item.expectedCode)
        missing.push(record)
      }
      const preparedCase = { id: caseInput.id, directory: await assertDirectDirectory(caseRoot), members, missing }
      manifest.cases.push(preparedCase)
      completedCases += 1
      await emit({ type: "prepared-case", fixtureID, preparedCase })
    }
    manifest.root = await assertDirectDirectory(input.runRoot)
    stage = "prepare:exclusive-manifest"
    await fs.writeFile(manifestPath, JSON.stringify(manifest, null, 2) + "\n", { flag: "wx" })
    await emit({ type: "prepare-complete", fixtureID, manifestPath, completedCases,
      qualification: "Six exclusive literal fixtures prepared; no grammar/read ABI outcome is asserted, and no service/model/API was started" })
  } else {
    stage = "read:original-manifest"
    const root = await assertDirectDirectory(input.runRoot)
    const manifest = JSON.parse(await fs.readFile(manifestPath, "utf8"))
    assert.equal(manifest.schema, "directory-target-dot-mixed-fixture/v1")
    assert.equal(manifest.fixtureID, fixtureID)
    assert.deepEqual(manifest.input, input)
    assert.equal(manifest.cases.length, 6)
    assert.deepEqual(identity(root.stat), identity(manifest.root.stat))
    await emit({ type: "original-fixture-binding", fixtureID, manifestPath, manifest, root })
    const reader = await createNativeMetadataReader(input, async (fact) => {
      if (fact.type === "reader-stage") stage = fact.stage
      await emit({ fixtureID, ...fact })
    })
    let observations = 0
    for (const caseInput of input.cases) {
      const caseRoot = declaredPath(input.runRoot, caseInput.id)
      const original = manifest.cases.find((item) => item.id === caseInput.id)
      assert.ok(original)
      stage = `read:bind-members:${caseInput.id}`
      const directory = await assertDirectDirectory(caseRoot)
      assert.deepEqual(identity(directory.stat), identity(original.directory.stat))
      const bindings = []
      for (const member of declaredMembers(caseInput)) {
        const actual = await captureMember(caseRoot, member, input.maximumFileBytes)
        const prepared = original.members.find((item) => item.relative === member.relative)
        assert.ok(prepared)
        assert.deepEqual(actual.identity, prepared.identity)
        if (member.kind === "link") assert.equal(actual.readlink, prepared.readlink)
        bindings.push(actual)
      }
      for (const item of caseInput.declaredMissing ?? []) {
        const operand = declaredPath(caseRoot, item.path)
        const record = await observe("lstat-bigint", operand, () => fs.lstat(operand, { bigint: true }).then(fullStat))
        await emit({ type: "declared-missing-read", fixtureID, caseID: caseInput.id, record })
        assert.equal(record.status, "rejected"); assert.equal(record.code, item.expectedCode)
      }
      await emit({ type: "same-original-member-bindings", fixtureID, caseID: caseInput.id, directory, bindings })
      for (const item of caseInput.observations) {
        stage = `read:observe:${caseInput.id}:${item.id}`
        const operand = observationPath(caseRoot, item)
        const record = { caseID: caseInput.id, id: item.id, originalOperandDeclaration: item, operand }
        record.lstatBefore = await observe("lstat-bigint", operand, () => fs.lstat(operand, { bigint: true }).then(fullStat))
        record.readlink = await observe("readlink", operand, () => fs.readlink(operand))
        record.stat = await observe("stat-bigint", operand, () => fs.stat(operand, { bigint: true }).then(fullStat))
        record.realpath = await observe("realpath", operand, () => fs.realpath(operand))
        if (record.stat.status === "fulfilled" && record.stat.value.isFile && record.realpath.status === "fulfilled") {
          const relative = path.relative(input.runRoot, record.realpath.value)
          assert.ok(relative && !path.isAbsolute(relative) && !relative.split(path.sep).includes(".."), "Read content only inside the original owned fixture")
          assert.ok(BigInt(record.stat.value.fields.size) <= BigInt(input.maximumFileBytes))
          record.content = await observe("readFile-full-bytes", operand, async () => {
            const bytes = await fs.readFile(operand)
            assert.ok(bytes.length <= input.maximumFileBytes)
            return { ...byteFact(bytes), matchesDeclaredLiterals: caseInput.files.filter((file) => bytes.equals(Buffer.from(file.literal, "utf8"))).map((file) => file.path) }
          })
        } else record.content = { operation: "readFile-full-bytes", operand, status: "not-read", reason: "Followed file plus owned resolved target not established; full stat/realpath result remains above" }
        record.native = reader.read(operand)
        record.firstNativeCause = record.native.failures[0] ?? null
        const values = record.native.query?.output
        const validFields = values && [values.FileAttributes, values.ReparseTag].every((value) => Number.isInteger(value) && value >= 0 && value <= 0xffffffff)
        if (validFields) record.metadata = { ...values, FileAttributesHex: `0x${values.FileAttributes.toString(16).padStart(8, "0")}`, ReparseTagHex: `0x${values.ReparseTag.toString(16).padStart(8, "0")}` }
        record.lstatAfter = await observe("lstat-bigint", operand, () => fs.lstat(operand, { bigint: true }).then(fullStat))
        record.entryIdentityStable = record.lstatBefore.status === "fulfilled" && record.lstatAfter.status === "fulfilled"
          ? stringify(identity(record.lstatBefore.value)) === stringify(identity(record.lstatAfter.value)) : null
        observations += 1
        await emit({ type: "original-access-observation", fixtureID, host, record })
        // An original open error is an access observation. FFI/query/close failures are instrumentation failures.
        const instrumentationFailure = record.native.failures.find((failure) => failure.operation !== "CreateFileW")
        if (instrumentationFailure) throw instrumentationFailure
        if (record.native.query?.returnValue) assert.ok(validFields)
        if (record.entryIdentityStable !== null) assert.equal(record.entryIdentityStable, true)
      }
      completedCases += 1
    }
    await emit({ type: "read-complete", fixtureID, host, completedCases, observations, completedAt: new Date().toISOString(),
      qualification: "Actual existing-fixture Win32/host access observations collected; open/stat/readlink/realpath errors remain facts, not functional success. No expected goal, Windows/POSIX equivalence, futuretree, File API or production loader result is asserted" })
  }
} catch (error) {
  process.exitCode = 1
  await emit({ type: "first-unexpected-error", stage, fixtureID, completedCases, error: originalError(error), input,
    failedAt: new Date().toISOString(), qualification: "Original error retained. No retry, cleanup, fixture reuse or alternate resolver was attempted" })
}
