/** Read-only proposal. Root owns separate syntax/run authorization and original stream capture. */
import assert from "node:assert/strict"
import fs from "node:fs/promises"
import path from "node:path"
import { fileURLToPath } from "node:url"
import { createNativeMetadataReader, originalError } from "./native-metadata-reader.mjs"

const inputPath = path.join(path.dirname(fileURLToPath(import.meta.url)), "canonical-entry-name.inputs.json")
const samePath = (left, right) => path.resolve(left).toLowerCase() === path.resolve(right).toLowerCase()
const stringify = (value) => JSON.stringify(value, (_key, item) => typeof item === "bigint" ? { type: "bigint", value: String(item) } : item)
const emit = (value) => new Promise((resolve, reject) => process.stdout.write(stringify(value) + "\n", (error) => error ? reject(error) : resolve()))
const fullStat = (value) => ({
  fields: Object.fromEntries(Object.entries(value).map(([key, item]) => [key, typeof item === "bigint" ? String(item) : item instanceof Date ? item.toISOString() : item])),
  isFile: value.isFile(), isDirectory: value.isDirectory(), isSymbolicLink: value.isSymbolicLink(),
  isBlockDevice: value.isBlockDevice(), isCharacterDevice: value.isCharacterDevice(), isFIFO: value.isFIFO(), isSocket: value.isSocket(),
})
const identity = (stat) => ({ dev: stat.fields.dev, ino: stat.fields.ino, birthtimeNs: stat.fields.birthtimeNs,
  isFile: stat.isFile, isDirectory: stat.isDirectory, isSymbolicLink: stat.isSymbolicLink })
const beforeIdentity = (entry) => ({ dev: entry.device, ino: entry.inode, birthtimeNs: entry.birthtimeNs,
  isFile: entry.file, isDirectory: entry.directory, isSymbolicLink: entry.symbolicLink })
const sameObservedIdentity = (left, right) => left?.status === "fulfilled" && right?.status === "fulfilled"
  ? stringify(identity(left.value)) === stringify(identity(right.value)) : null
async function observe(operation, operand, read) {
  try { return { operation, operand, status: "fulfilled", value: await read() } }
  catch (error) { return { operation, operand, status: "rejected", code: error?.code, error: originalError(error) } }
}
function declaredPath(root, relative) {
  assert.equal(typeof relative, "string")
  assert.ok(relative && !path.isAbsolute(relative) && relative.split(/[\\/]/).every((part) => part && part !== "." && part !== ".."))
  return path.join(root, relative)
}
function originalReference(slot, manifests, input) {
  const manifest = manifests[slot.fixture]
  const declaration = slot.reference
  const operand = declaredPath(input.fixtures[slot.fixture].root, declaration.path)
  if (slot.fixture === "before") {
    assert.ok(declaration.collection === "files" || declaration.collection === "links")
    assert.ok(declaration.field === "entry" || declaration.field === "target")
    const member = manifest[declaration.collection].find((item) => item.role === "root" && item.path === declaration.memberPath)
    assert.ok(member)
    const fact = member.original[declaration.field]
    assert.equal(fact.state, "present")
    const originalPath = declaration.field === "entry" ? member.full : member.original.realpath.value
    assert.ok(samePath(originalPath, operand))
    return { operand, sourceManifest: input.fixtures.before.manifest, fixtureID: manifest.fixtureID,
      selector: declaration, originalFact: fact, identity: beforeIdentity(fact),
      readlink: declaration.field === "entry" && member.original.readlink?.state === "present" ? member.original.readlink.text : undefined }
  }
  const originalCase = manifest.cases.find((item) => item.id === declaration.caseID)
  assert.ok(originalCase)
  const member = originalCase.members.find((item) => item.relative === declaration.memberPath)
  assert.ok(member && samePath(member.operand, operand))
  return { operand, sourceManifest: input.fixtures.mixed.manifest, fixtureID: manifest.fixtureID,
    selector: declaration, originalFact: member, identity: member.identity, readlink: member.readlink }
}

let stage = "input"
let input
let completedSlots = 0
let entryNameReads = 0
try {
  assert.equal(process.argv.length, 4)
  assert.equal(process.argv[2], "--host")
  const host = process.argv[3]
  assert.ok(host === "node" || host === "bun")
  input = JSON.parse(await fs.readFile(inputPath, "utf8"))
  assert.equal(input.schema, "directory-target-canonical-entry-name-input/v1")
  assert.equal(input.maximumSlots, 16)
  assert.equal(input.slots.length, 16)
  assert.equal(new Set(input.slots.map((slot) => slot.id)).size, 16)
  assert.equal(process.platform, input.platform)
  assert.equal(process.arch, input.architecture)
  assert.ok(samePath(process.execPath, input.runtimes[host].executable))
  if (host === "node") assert.equal(process.versions.node, input.runtimes.node.nodeVersion)
  else assert.equal(process.versions.bun, input.runtimes.bun.bunVersion)
  assert.equal(input.entryNameInput.flags, 0)
  assert.equal(input.modelCallsRequested, "none")
  await emit({ type: "original-input", inputPath, input, host, executable: process.execPath, versions: { ...process.versions }, startedAt: new Date().toISOString() })
  const manifests = {}
  for (const [name, fixture] of Object.entries(input.fixtures)) {
    stage = `bind-fixture:${name}`
    const stat = fullStat(await fs.lstat(fixture.root, { bigint: true }))
    const realpath = await fs.realpath(fixture.root)
    assert.ok(stat.isDirectory && !stat.isSymbolicLink && samePath(realpath, fixture.root))
    const manifest = JSON.parse(await fs.readFile(fixture.manifest, "utf8"))
    assert.equal(manifest.schema, fixture.schema)
    assert.equal(manifest.fixtureID, fixture.fixtureID)
    const originalRoot = name === "before" ? beforeIdentity(manifest.scopes.root.identity.entry) : identity(manifest.root.stat)
    assert.ok(samePath(name === "before" ? manifest.scopes.root.directory : manifest.root.path, fixture.root))
    assert.deepEqual(identity(stat), originalRoot)
    manifests[name] = manifest
    await emit({ type: "original-fixture-binding", name, fixture, originalRoot, currentRoot: { stat, realpath } })
  }
  const reader = await createNativeMetadataReader(input, async (fact) => {
    if (fact.type === "reader-stage") stage = fact.stage
    await emit(fact)
  })
  const observations = []
  for (const slot of input.slots) {
    stage = `entry-slot:${slot.id}`
    const record = { id: slot.id, declaration: slot, reference: originalReference(slot, manifests, input) }
    record.reference.lstat = await observe("lstat-bigint", record.reference.operand, () => fs.lstat(record.reference.operand, { bigint: true }).then(fullStat))
    record.reference.actualReadlink = await observe("readlink", record.reference.operand, () => fs.readlink(record.reference.operand))
    await emit({ type: "original-reference-binding", record: { id: slot.id, reference: record.reference } })
    assert.equal(record.reference.lstat.status, "fulfilled")
    assert.deepEqual(identity(record.reference.lstat.value), record.reference.identity)
    if (record.reference.readlink !== undefined) {
      assert.equal(record.reference.actualReadlink.status, "fulfilled")
      assert.equal(record.reference.actualReadlink.value, record.reference.readlink)
    }
    if (slot.shortOf !== undefined) {
      const original = observations.find((item) => item.id === slot.shortOf)
      assert.ok(original?.operand)
      record.shortPath = reader.readShortPath(original.operand)
      record.firstCause = record.shortPath.firstCause
      await emit({ type: "actual-short-path-query", id: slot.id, originalOperand: original.operand, shortPath: record.shortPath })
      if (record.shortPath.firstCause) throw record.shortPath.firstCause
      const unchangedIgnoringCase = record.shortPath.path.toLowerCase() === original.operand.toLowerCase()
      record.shortCoverage = { originalOperand: original.operand, returnedOperand: record.shortPath.path,
        changedNamespaceSpelling: !unchangedIgnoringCase,
        changedTerminalSpelling: path.basename(record.shortPath.path).toLowerCase() !== path.basename(original.operand).toLowerCase(),
        claim: unchangedIgnoringCase ? "No short-name access covered: API returned the original long spelling (ignoring case); no alias created" : "Only the actual API-returned operand is probed; terminal and ancestor coverage are reported separately" }
      if (unchangedIgnoringCase) {
        record.status = "short-name-access-uncovered"
        observations.push(record); completedSlots += 1
        await emit({ type: "original-entry-name-observation", host, record })
        continue
      }
      record.operand = record.shortPath.path
    } else record.operand = declaredPath(input.fixtures[slot.fixture].root, slot.path)
    const operand = record.operand
    record.inputBasename = path.basename(operand)
    record.lstatBefore = await observe("lstat-bigint", operand, () => fs.lstat(operand, { bigint: true }).then(fullStat))
    record.readlink = await observe("readlink", operand, () => fs.readlink(operand))
    record.stat = await observe("stat-bigint", operand, () => fs.stat(operand, { bigint: true }).then(fullStat))
    record.realpath = await observe("realpath", operand, () => fs.realpath(operand))
    record.parentRealpath = await observe("realpath-parent", path.dirname(operand), () => fs.realpath(path.dirname(operand)))
    record.parentPlusInputBasename = record.parentRealpath.status === "fulfilled" ? path.join(record.parentRealpath.value, path.basename(operand)) : null
    // Diagnostic projection above is never used for admission, reopening, canonicalization or fallback.
    record.native = reader.readEntryName(operand)
    entryNameReads += 1
    record.firstCause = record.native.failures[0] ?? null
    const tag = record.native.query?.output
    if (tag) record.metadata = { ...tag, FileAttributesHex: `0x${tag.FileAttributes.toString(16).padStart(8, "0")}`, ReparseTagHex: `0x${tag.ReparseTag.toString(16).padStart(8, "0")}` }
    if (!record.firstCause) {
      const finalPath = record.native.finalPath.path
      const withinDeclaredRoot = Object.values(input.fixtures).some((fixture) => {
        const relative = path.win32.relative(path.win32.toNamespacedPath(fixture.root), finalPath)
        return relative.length > 0 && !path.win32.isAbsolute(relative) && !relative.split(/[\\/]/).includes("..")
      })
      record.finalPath = { original: finalPath, withinDeclaredRoot, basename: path.win32.basename(finalPath),
        exactDeclaredEntrySpelling: finalPath === path.win32.toNamespacedPath(record.reference.operand),
        exactParentPlusInputBasename: record.parentPlusInputBasename === null ? null : finalPath === path.win32.toNamespacedPath(record.parentPlusInputBasename) }
      if (withinDeclaredRoot) {
        record.finalPath.lstat = await observe("lstat-bigint-returned-path", finalPath, () => fs.lstat(finalPath, { bigint: true }).then(fullStat))
        record.finalPath.readlink = await observe("readlink-returned-path", finalPath, () => fs.readlink(finalPath))
        record.finalPath.identityEqualsInputEntry = sameObservedIdentity(record.finalPath.lstat, record.lstatBefore)
        record.finalPath.identityEqualsDeclaredEntry = sameObservedIdentity(record.finalPath.lstat, record.reference.lstat)
        record.finalPath.identityEqualsFollowedTarget = sameObservedIdentity(record.finalPath.lstat, record.stat)
      } else record.finalPath.readback = "Not read outside the declared owned fixtures; raw API string retained and qualifier fails after emitting this record"
    }
    record.lstatAfter = await observe("lstat-bigint", operand, () => fs.lstat(operand, { bigint: true }).then(fullStat))
    record.entryIdentityStable = sameObservedIdentity(record.lstatBefore, record.lstatAfter)
    record.status = record.firstCause ? "native-failure-retained" : "entry-name-observed"
    observations.push(record); completedSlots += 1
    await emit({ type: "original-entry-name-observation", host, record })
    if (record.firstCause) throw record.firstCause
    assert.equal(record.finalPath.withinDeclaredRoot, true)
    assert.equal(record.entryIdentityStable, true)
  }
  await emit({ type: "complete", host, completedSlots, plannedSlots: input.slots.length, entryNameReads,
    shortNameAccessCovered: observations.filter((item) => item.shortCoverage?.changedNamespaceSpelling).map((item) => item.id),
    shortTerminalNameCovered: observations.filter((item) => item.shortCoverage?.changedTerminalSpelling).map((item) => item.id),
    completedAt: new Date().toISOString(), qualification: input.qualification,
    unverified: ["hardlink entry disambiguation", "production loader or adapter", "File API", "retirement dependency validator", "futuretree", "atomic retarget races", "POSIX/Darwin/remote/provider semantics"] })
} catch (error) {
  process.exitCode = 1
  await emit({ type: "first-unexpected-error", stage, completedSlots, entryNameReads, error: originalError(error), failedAt: new Date().toISOString(),
    qualification: "Original native/host failure retained; no resize, alternate flags, alternate API, mutation or retry. Prior metadata and dot/mixed results are unchanged." })
}
