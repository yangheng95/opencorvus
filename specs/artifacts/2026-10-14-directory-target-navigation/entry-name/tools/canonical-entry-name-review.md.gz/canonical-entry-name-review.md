# Canonical entry name — fixed read-only preparation

## Recall / scope

Root 已实际读两 host 的六例/各32项：dot u 的 `v/../goal` 在该 Windows stage 到 tree/goal；mixed S→B/J→D/data 的 S/r 到 B/goal，而 S→B/T→D/data 的 S/r 到 D/goal。本任务不重跑或改这些工具、inputs、raw、exit，不把其已验证范围延伸到 entry canonical name。

本次仅准备固定只读 qualifier：同一原 NOFOLLOW CreateFileW handle 同时查询原 tag 和 GetFinalPathNameByHandleW，观察真实 entry 地址、case variant 与可用的现存 short-name operand。当前共享 reader、产品、spec、Git、服务、模型和所有旧数据不修改。没有创建 fixture、目录 entry、short alias 或设置8.3/case policy。当前 Move entry 依赖 guard 的 sourceName+BigInt 方案仍待本次资格，shared relocation/futuretree 不在本次完成范围。

已完整读当前共享 reader、此前 metadata/dot 输入和已保存 Prepare fixtureID、before manifest 的原 entry fact、现 dot/mixed manifest 的原 root/member fact；Microsoft 官方 API 文档及安装的 Koffi3.3.2 output/transient-pointer 文档亦已读取。当前为**准备完成、尚未语法检查/加载库/执行**；没有任何新的真实 GetFinalPathNameByHandleW 或 GetShortPathNameW 结果。

## 固定文件

以下均在 `D:/myhexin-local/opencorvus/.tmp-codex-directory-target-01a133/`：

1. `canonical-entry-name.inputs.json`：16个明确 slot、两个原 fixtureID、实际 Node25.7/Bun1.4 executable、原 create flags 与 name API 输入。
2. `canonical-entry-name-qualifier.mjs`：只读入口；stdout 是唯一产物通道，Root 原 wrapper 独占保存原 raw/exit。
3. `canonical-entry-native-reader.before.mjs`：当前共享 reader 的完整原字节副本（5768B）。
4. `canonical-entry-native-reader.proposal.mjs`：在同一 reader 上扩展的完整 after 提案（9560B）；新 qualifier 仅 import 这份明确提案，不自动替换当前 reader。
5. `canonical-entry-native-reader.exact-changes.json`：五个完整 before/after 文本块；从 before 逐块替换可准确生成完整 after。
6. 本 `canonical-entry-name-review.md`。

原 `native-metadata-reader.mjs` 与 before 副本已用实际完整 bytes 逐字节确认相同；这是历史复制身份检查，不是源码 hash/功能验收。既有 reader 的所有消费者不改。若 Root 后续接受提案，须由 Root 决定唯一当前文件的替换；历史 before 不作可执行 fallback。

## API 与本次尚待实测的区别

[GetFinalPathNameByHandleW 官方合同](https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-getfinalpathnamebyhandlew)定义 flags0 为 normalized + DOS，成功长度不含末尾 NUL，buffer 不足时所需长度含 NUL，其他失败返回0并读取 GetLastError。本工具固定两次 size/read，保原返回值，不在不足、权限或 provider 错误后改用 OPENED、GUID、NT、另一 API 或更大 buffer 重试。normalized DOS 返回的原 `\\?\` 文本保留。

[CreateFileW 官方符号链接说明](https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-createfilew)说明 OPEN_REPARSE_POINT 获取 terminal symbolic link handle；这不是“GetFinalPathNameByHandleW 一定返回本体路径”的实际证据。本次必须观察 terminal fileSYM/dirSYM/junction/broken 的真实 name，再对该返回路径做 lstat/readlink，与原 input entry、预声明 direct entry 和 followed stat 并列比较。不会引用一般文档中的 fully-resolved 描述而提前断言 own entry 或 target。

[GetShortPathNameW 官方合同](https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-getshortpathnamew)允许 NULL/0 请求所需大小；无现存 short name 时可能成功返回 long name。本工具最多对两个原 long operands 作 size/read；仅实际返回的不同 spelling 可作为新的短名读取 operand。返回原 long（忽略 case）时记录 `short-name-access-uncovered`，跳过对应 entry probe，不创建/猜测 alias。ancestor 与 terminal spelling 是否改变分别记录；仅祖先缩短不能冒称 terminal 8.3 已覆盖。

安装的 `koffi/doc/output.md` 的 transient pointers 允许同步 API 接收 Buffer 输出内存；此处采用 `_Out_ char16_t *`，核 sizeof(char16_t)=2。没有保留 native 指针到调用之后或异步调用 Buffer，没有 Bun FFI、安装包、原型自重试或自写 reparse buffer 解析。

## 同原 handle 和完整原错

原 load/package anchor/version/addon path、FILE_ATTRIBUTE_TAG_INFO、CreateFileW(0access,share7,OPEN_EXISTING3,0x02200000)、tag query、GetLastError、CloseHandle 代码来自当前 reader。提案新增两个明确 W 函数声明、一份两阶段 UTF-16 output 函数、`readEntryName` 和 `readShortPath`；旧 `read(operand)` 行为保持不请求 name。提案中的新增函数 binding 是否可被两 host 正确加载仍未验，不能把原 reader0 自动转为本提案0。

`readEntryName` 只开一次原 handle，tag query 成功后在该 handle 上调用 final-name size/read，最后由**原 finally** CloseHandle 一次；不开第二个 native handle，不把原路径重新 open 当 name 事实。name query 的 subject 明确保原 BigInt handle/operand/flags。

每次 API 下一 native 调用就是同步 GetLastError，中间无 await/log/native call。size 返回零即保存原 Win32 failure，不作第二次读；正数按原返回 code-unit 数分配唯一 Buffer（每单位2B，初值0xA5），再调用一次。保存全部 allocated raw Buffer、返回的 UTF-16 code units/base64/string、原 terminator 和原 lastError。成功或 sizing 的 lastError 标为可能 stale，不据其数值制造失败。

第二次若返回0、长度仍不适配原 buffer、非预期 NUL/FFI 错，保存原 size/read/raw，不 resize/retry。32768 code-unit 上限只约束本固定 qualifier 的 Win32 name buffer，不新增产品配置。Close 失败追加进同一 failures，首 cause 不被覆盖。当前 `readEntryName` 全部退出路径仍经原 finally；GetShortPathNameW 不产生 handle。首次 native/FFI/buffer/close failure 保存原 record 后退出1，后续 slot 停止。

## 原 fixtures 与16个 slot

before 原 fixtureID：`c2a68b0b-9f1b-4fe3-af16-f289f0715e93`；A root 是原 `directory-target-before-01a133/project`。

mixed 原 fixtureID：`df2ea0df-f134-4503-aea1-a2597ff25c9e`；root 是原 `directory-target-dot-mixed-01a133`。两者只核对原 manifest/root identity，不创建或接管 runtime。

| Slot | 原 operand / 来源 | 目的 |
|---|---|---|
| 1–2 | before `regular-file.txt` / `REGULAR-FILE.TXT` | same entry case variant 是否实际返回 canonical casing |
| 3–4 | before `target-dir/资料 Note.txt` / `target-dir` | UTF-16 Unicode 文件与 ordinary dir |
| 5–7 | before `file-link` / `absolute-dir-link` / `junction-dir` | terminal NOFOLLOW own entry 对照 |
| 8–9 | before `broken-dir-link` / `broken-junction` | broken entry name 的原 native 结果 |
| 10–11 | before `aliases/root-back/regular-file.txt` / `absolute-dir-link/资料 Note.txt` | junction/true symbolic 祖先的 canonical entry |
| 12–13 | mixed `mixed-junction/S/r` / `mixed-absolute-symbolic/S/r` | 访问 namespace 不同但 entry/address 分别是什么 |
| 14 | before `ABSOLUTE-DIR-LINK` | terminal link case variant |
| 15–16 | GetShortPathNameW 实际返回 slot1 / slot3 的路径 | 若现存8.3可用，观察原 short operand；否则明确未覆盖 |

最多16次 CreateFileW/tag/final-name/Close，每次 final-name 最多2调用；两个 short 转换最多4调用。没有目录枚举扩样或未知 user 文件扫描。14个固定 input spelling 加2个实际 API 产物槽，不追加未声明 case。

before 的普通文件/link direct reference 来自原 `files/links[].original.entry`；ordinary `target-dir` 来自原 junction 的 `original.target` 与原 realpath，两者真实对应同目录，未生成新 inode 期望。mixed r 来自原 case.members 中 `D/data/r` 的实际 identity/readlink。当前 reference 先实际 lstat/readlink 并核同原 manifest；别名 operand 自身 lstat/stat/realpath 保观察，不提前宣称 alias 成功。

每个 record 完整保 BigInt lstat before/after、readlink/stat/realpath 原值或 raw errno/完整 own-property error，原 input basename 和 `realpath(parent)+input basename` 的诊断投影。这个投影仅用于显示旧算法差异，不参与 admission/reopen/成功选择。name 原结果保原完整路径；只对返回到两已声明 owned roots 的路径做 lstat/readlink。超域返回会保存原值、停止，不读未知 target。

输出分别给 `exactDeclaredEntrySpelling`、`exactParentPlusInputBasename`、returned-path identity 与 input/direct reference/followed target 的关系。它们是并列事实，不以一个 inode equality 决定所有 directory entry 相同，也不把 `exactDeclaredEntrySpelling=false` 自行降级为 success。Root 必须从原大小写文本、tag、lstat/readlink 事实判资格。Read exit0 仅表示所有计划槽收齐、native calls/close 原合同完成；short 未覆盖、canonical 语义或 case canonicalization 不理想仍须读结果判定。

## hardlink 与其它未验边界

已搜索本 before producer 与 dot input：没有 actual hardlink pair producer；本次无创建授权，不新增。在现两 fixtures 中即使 inode相等且 canonical 文本相等，也不能用它排除所有 hardlink entry 混淆。[Microsoft hardlink 定义](https://learn.microsoft.com/en-us/windows/win32/fileio/hard-links-and-junctions)明确多个路径可关联一个文件；因此没有一个此处可用的“仅 inode 就等于同 entry”的结论。该缺口在最终 `unverified` 中明确输出。

同handle tag/name 是一次 original open 的事实，周围 Node lstat 仍不是与它原子绑定的 snapshot；retarget race、远程/云/provider、POSIX/Darwin、case-sensitive Windows 目录 policy、所有8.3形态与 hardlink 尚未证明。不会因本次通过就宣称 File API、move-retirement guard、完整 source/future relocation、Task/Capsule 或 UI 已修复。

## 待 Root 审核执行的原命令

本任务没有运行下列命令。Root 用已有 Native 原 owner/capture，以**新的独立 occurrence/evidence namespace** 包裹 child args；不复用原20、dot、service 或 calibration namespace，不在本提案建立新 runner/timer/服务。原 stdout、stderr、exit、Native ready/settled/output/request/parent 收齐由 Root 原工具负责。

```powershell
# Root may run parser-only stages first and save each original output/exit.
& 'C:/Program Files/nodejs/node.exe' --check 'D:/myhexin-local/opencorvus/.tmp-codex-directory-target-01a133/canonical-entry-native-reader.proposal.mjs'
& 'C:/Program Files/nodejs/node.exe' --check 'D:/myhexin-local/opencorvus/.tmp-codex-directory-target-01a133/canonical-entry-name-qualifier.mjs'

# Exact future child argv; Root owns actual Native wrapping and complete original capture.
& 'C:/Program Files/nodejs/node.exe' 'D:/myhexin-local/opencorvus/.tmp-codex-directory-target-01a133/canonical-entry-name-qualifier.mjs' --host node
& 'D:/myhexin-local/opencorvus/.tmp-codex-directory-target-01a133/ui-bundle/bin/bun.exe' 'D:/myhexin-local/opencorvus/.tmp-codex-directory-target-01a133/canonical-entry-name-qualifier.mjs' --host bun
```

准备阶段仅已读取文件、创建上述 scratch 提案、解析输入 JSON、全文静态审阅并核对完整 before/after 文本；未进行 parser/native/runtime/API/UI/模型验证。新资格尚未达成，等待的是 Root 审阅后的实际执行，不是需要用户重复许可。

## Root 审阅后的唯一 reader 激活计划（尚非运行事实）

Root 已通知将自行保存四份当前 dot 工具的历史，再把本完整 reader proposal 采用到唯一 `native-metadata-reader.mjs`，并将新 qualifier 的 import 改为这个唯一 reader、调整当前文件头。此操作由 Root 执行；本子任务没有修改原 reader 或原 dot 结果。上文 proposal 路径保留的是审核前后关系，不授权同时运行两份 reader 或重跑旧20/dot64。

Root 计划扩展现 `run-dot-native` 的有限 entry-name 分支，使用新 `entry-native-{host}` namespace 和原30000ms execution cap / 3000ms真实输出 inactivity，仍由原 Native Host 单一消费两个流。这是 Root 给出的将来输入，不是本准备已执行或已证明的预算事实。新 child CLI **没有 read positional 参数**：传 `canonical-entry-name-qualifier.mjs --host node|bun`；wrapper 自身的 mode 可以是 entry-name/read，但不可把 read 插入 child argv。
