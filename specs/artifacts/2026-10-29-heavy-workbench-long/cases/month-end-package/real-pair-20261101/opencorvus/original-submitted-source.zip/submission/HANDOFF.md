# April 2025 CFO-review package

## Open this file

`Aurisic_Financials_4-25-1.xlsx` is the financial handoff, not `engine_recalculated.xlsx` (a technical engine export). Start with Table of Contents, then CFO Review and Period Bridges. The workbook contains 31 sheets, preserves the retained template order, excludes CFO-reserved sections 1/2/2a/3, and appends new schedules and source support. All 105 April division/account identities are retained. The Audit Index locates 166 claims in actual financial/source cells; it is not an answer sheet.

This is a CFO-review draft. No ledger entries were posted, no request was sent externally, and no company policy or financial approval is implied. Original source observations, current calculations and missing company evidence are separately identified.

## Priority CFO requests

- Obtain the independent bank statement and reconciliation items. Book cash is 6,610,926.80; checks and proposed reclassification are 16,166.78. These do not establish a bank-statement balance.
- Supply missing `AP_TB-1.xlsx`; the known April AP GL credit is 314,563.78, not a supplier reconciliation.
- Resolve insurance: source close 5,493.27 versus GL 54,630.68, a GL-minus-source gap of 49,137.41. Confirm amortization posting and coverage.
- Resolve payroll accrual: supported rollforward 318,500 versus GL 141,033, a GL-minus-source gap of -177,467. Obtain posting/cutoff and reallocation support; partial salary/expense bridges are not claims of GL error.
- Confirm prepaid coverage, source-version differences and rounding. Expense source close is 692,501.313131..., versus GL 692,501.33. The residual is retained, not plugged. Original PPD1250 P50/S50 `#REF!` errors remain on the source sheet.
- Confirm GA-0015 entity mapping, funding allocations, bonus policy, loan terms/borrower mapping and historical posting/cutoff explanations. Amount matches alone do not establish these facts. Loan accrued-interest difference of about 0.005671 remains disclosed rather than written off.

The workbook's 32-item CFO Review contains exact source locations, observed differences, requested evidence and outstanding status. Period Bridges includes all joint identities and identifies source-backed candidate components without asserting that a matching amount proves a journal posting. Legal transaction totals are counted once; the source's duplicated subtotal is documented, not copied into the current financial result.

## Rebuild and evidence

Run from the project root in native Windows Git Bash, with the public inputs left unchanged:

```text
"C:/Users/hengu/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe" submission/run_all.py
"C:/Users/hengu/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe" submission/make_visual_index.py
```

The script resolves its own directory and uses the Python/Node/module paths declared in `public/RUNTIME.md`. It writes only under submission, runs child processes synchronously, and requires no server, Excel UI, Docker or WSL. A rebuild replaces generated workbook/evidence files and archives previous visuals; retain a copy first if you need a particular review version. Review the resulting images before using a rebuilt workbook.

Source flow: `build.py` constructs the package and invokes `presentation.py`; `consumer.mjs` imports/recalculates/exports using the declared shared Artifact Tool, exercises temporary input changes, and renders schedules; `validate.py` separately derives source-based arithmetic/provenance expectations; `finalize.py` transfers actual engine formula caches to the styled workbook, saves/reopens, and compares values. The final workbook is then reimported into the shared engine. `inspect_inputs.py` and `inspect_focus.py` preserve source inspection utilities. No additional dependencies were installed.

Evidence retained:

- `validation.json`: 148 numerical comparisons, per-account signed amounts, eight source-table comparisons and structural checks.
- `interventions.json`: six in-memory edits, with 21 dependent-result comparisons in validation.json; edits are restored and do not replace the submitted original.
- `saved_reopened.json`: 154 scalar/input observations compared to actual saved formula caches.
- `final_engine_reopen.json`: final workbook reimport/recalculation, 154 scalar observations, no differences.
- `recalculated_claims.json`, `final_baseline.json`, `scenario_expectations.json`: actual observations and separately derived intervention expectations.
- `visual/index.html`, individual PNGs and contact sheets: 63 rendered ranges across all 31 sheets. `render_results.json` maps image names to exact sheets/ranges.
- `logs/` and `validation_history.json`: actual executions and genuine failures/corrections, including the corrected provenance-write defect affecting loan interest.

## Limits

Recalculation and rendering were tested using the declared shared file consumer, not Microsoft Excel's native application. Source checks are separately implemented arithmetic, not a second-person review; no agent delegation was used. Wide source appendices and audit tables are best read at native zoom or in the workbook, not as compressed contact sheets. Static narrative observations describe this April review and are not live scenario commentary. The code is an April-specific reconstruction, not a certified generalized close system. No benchmark grade, financial sign-off, professional certification or external-reporting compliance is claimed.
