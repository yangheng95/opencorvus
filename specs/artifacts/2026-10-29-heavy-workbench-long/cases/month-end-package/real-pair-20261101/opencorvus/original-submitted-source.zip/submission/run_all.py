"""Native Windows build/evidence entry point. No server, UI automation or subprocess left running."""

import os, sys, subprocess, json, shutil
from pathlib import Path

O = Path(__file__).resolve().parent
R = O.parent
PY = "C:/Users/hengu/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe"
NODE = "C:/Users/hengu/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe"
(O / "logs").mkdir(exist_ok=True)
env = os.environ.copy()
env.update(
    {
        "PYTHONUTF8": "1",
        "PYTHONDONTWRITEBYTECODE": "1",
        "TEMP": str(O / "temp"),
        "TMP": str(O / "temp"),
        "XDG_CACHE_HOME": str(O / "cache"),
    }
)
(O / "temp").mkdir(exist_ok=True)
(O / "cache").mkdir(exist_ok=True)


def execute(label, args):
    print(label, flush=True)
    result = subprocess.run(
        args,
        cwd=R,
        env=env,
        encoding="utf-8",
        errors="replace",
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )
    (O / "logs" / f"{label}.log").write_text(result.stdout, encoding="utf-8")
    print(result.stdout[-1600:], flush=True)
    if result.returncode:
        raise RuntimeError(
            f"{label}: exit{result.returncode}; actual output retained in logs"
        )


execute("01_build", [PY, str(O / "build.py")])
execute("02_recalculation", [NODE, str(O / "consumer.mjs")])
execute("03_source_validation", [PY, str(O / "validate.py")])
execute("04_interventions", [NODE, str(O / "consumer.mjs"), "--interventions"])
execute("05_validation", [PY, str(O / "validate.py")])
execute("06_saved_reopened", [PY, str(O / "finalize.py")])
shutil.copyfile(O / "recalculated_claims.json", O / "final_baseline.json")
execute("07_final_engine_reopen", [NODE, str(O / "consumer.mjs"), "--verify-final"])
if (O / "visual").exists():
    archive = O / "visual_initial"
    if archive.exists():
        # Retain earlier evidence; a fresh run uses a distinct local archive rather than destroying it.
        n = 2
        while (O / f"visual_previous_{n}").exists():
            n += 1
        archive = O / f"visual_previous_{n}"
    (O / "visual").rename(archive)
execute("08_render", [NODE, str(O / "consumer.mjs"), "--visual"])
print(
    "All child processes have exited naturally. Inspect visual/index.html after make_visual_index.py."
)
