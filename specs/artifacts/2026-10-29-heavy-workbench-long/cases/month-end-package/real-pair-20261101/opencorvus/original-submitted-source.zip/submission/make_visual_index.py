from pathlib import Path
import json, html
from PIL import Image, ImageOps, ImageDraw

O = Path(__file__).resolve().parent
items = json.loads((O / "render_results.json").read_text())
text = [
    '<!doctype html><html><head><meta charset="utf-8"><title>April workbook visual evidence</title><style>body{font:16px Arial;background:#edf2f7;color:#17365d;margin:28px}section{background:white;padding:20px;margin:24px 0}img{max-width:100%;height:auto}a{color:#17365d}</style></head><body><h1>April CFO draft — actual workbook renders</h1><p>Rendered by the shared artifact-tool engine, not Excel UI automation. Images show actual saved/reopened calculations. Source matrices retain original errors and contradictory labels; financial front tabs distinguish current results. Open an image for original resolution.</p>'
]
for x in items:
    text.append(
        f"<section><h2>{html.escape(x['sheet'])} — {x['range']}</h2><p>{html.escape(x['result'])}</p>"
    )
    if x["result"] == "rendered":
        text.append(
            f'<a href="{x["file"]}"><img src="{x["file"]}" alt="{html.escape(x["sheet"])} {x["range"]}"></a>'
        )
    text.append("</section>")
text.append("</body></html>")
(O / "visual" / "index.html").write_text("\n".join(text), encoding="utf-8")
# Contact sheets are navigation only; full-resolution PNGs are the inspection evidence.
for start in range(0, len(items), 6):
    chunk = items[start : start + 6]
    canvas = Image.new("RGB", (1600, 3 * 650), "#e8edf3")
    draw = ImageDraw.Draw(canvas)
    for j, x in enumerate(chunk):
        if x["result"] != "rendered":
            continue
        im = Image.open(O / "visual" / x["file"]).convert("RGB")
        im.thumbnail((780, 600))
        xx = (j % 2) * 800 + 10
        yy = (j // 2) * 650 + 35
        canvas.paste(im, (xx, yy))
        draw.text((xx, yy - 25), x["sheet"] + " " + x["range"], fill="black")
    canvas.save(O / "visual" / f"contact_{start // 6 + 1:02d}.png")
print(
    "Visual index written;",
    len(items),
    "actual image pages,",
    len(set(x["sheet"] for x in items)),
    "sheets.",
)
