import fs from 'node:fs/promises';
import path from 'node:path';
import {createRequire} from 'node:module';
import {fileURLToPath,pathToFileURL} from 'node:url';
const dir=path.dirname(fileURLToPath(import.meta.url));
const require=createRequire('C:/Users/hengu/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/package.json');
const {FileBlob,SpreadsheetFile}=await import(pathToFileURL(require.resolve('@oai/artifact-tool')).href);
const wb=await SpreadsheetFile.importXlsx(await FileBlob.load(path.join(dir,'Aurisic_Financials_4-25-1.xlsx')));
console.log((await wb.inspect({kind:'sheet',include:'id,name',maxChars:10000})).ndjson);
if(process.argv.includes('--help-render')){
 console.log(wb.help('workbook.render',{include:'index,examples,notes',maxChars:6500}).ndjson);
}else if(process.argv.includes('--interventions')){
 const claims=JSON.parse(await fs.readFile(path.join(dir,'claims.json'),'utf8'));
 const cases=JSON.parse(await fs.readFile(path.join(dir,'scenario_expectations.json'),'utf8'));
 const byClaim=Object.fromEntries(claims.map(x=>[x.Claim,x]));
 const scalar=(c)=>wb.worksheets.getItem(c.Sheet).getRange(c.Address).values[0][0];
 wb.recalculate();const results={};
 for(const [name,test] of Object.entries(cases)){
  const c=byClaim[test.input],input=wb.worksheets.getItem(c.Sheet).getRange(c.Address);
  const original=scalar(c);const before={};
  for(const key of Object.keys(test.deltas))before[key]=scalar(byClaim[key]);
  input.values=[[original+test.change]];wb.recalculate();const after={};
  for(const key of Object.keys(test.deltas))after[key]=scalar(byClaim[key]);
  results[name]={input:test.input,original,change:test.change,before,after};
  input.values=[[original]];wb.recalculate();
  results[name].restored=Object.fromEntries(Object.keys(test.deltas).map(k=>[k,scalar(byClaim[k])]));
 }
 await fs.writeFile(path.join(dir,'interventions.json'),JSON.stringify(results,null,2));
 console.log('Six in-memory input changes executed and restored; no modified workbook exported.');
}else if(process.argv.includes('--visual')){
 await fs.mkdir(path.join(dir,'visual'),{recursive:true});wb.recalculate();
 const plan=JSON.parse(await fs.readFile(path.join(dir,'render_plan.json'),'utf8'));const results=[];
 for(const item of plan){
  try{
   const image=await wb.render({sheetName:item.sheet,range:item.range,scale:1,format:'png'});
   const file=path.join(dir,'visual',item.file);
   await fs.writeFile(file,new Uint8Array(await image.arrayBuffer()));
   results.push({...item,result:'rendered'});console.log('Rendered',item.sheet,item.range);
  }catch(e){results.push({...item,result:'error',error:String(e)});console.log('Render failure',item.sheet,item.range,String(e));}
 }
 await fs.writeFile(path.join(dir,'render_results.json'),JSON.stringify(results,null,2));
}else{
 const claims=JSON.parse(await fs.readFile(path.join(dir,'claims.json'),'utf8'));
 wb.recalculate();
 let results=[];
 for(const c of claims.filter(x=>!['table','source_table'].includes(x.Role))){
  const range=wb.worksheets.getItem(c.Sheet).getRange(c.Address);
  results.push({...c,value:range.values,formula:range.formulas});
 }
 await fs.writeFile(path.join(dir,'recalculated_claims.json'),JSON.stringify(results,null,2));
 if(process.argv.includes('--verify-final')){
  const previous=JSON.parse(await fs.readFile(path.join(dir,'final_baseline.json'),'utf8'));
  const differences=[];
  for(let i=0;i<results.length;i++){
   const a=results[i].value[0][0],b=previous[i].value[0][0];
   if(typeof a==='number'&&typeof b==='number'?Math.abs(a-b)>1e-7:a!==b)differences.push({claim:results[i].Claim,actual:a,previous:b});
  }
  await fs.writeFile(path.join(dir,'final_engine_reopen.json'),JSON.stringify({target:'Aurisic_Financials_4-25-1.xlsx',scalar_count:results.length,differences},null,2));
  if(differences.length)throw Error('Final engine reopen changed financial values');
  console.log('Exact final workbook reimported and recalculated; all scalar results unchanged.');
 }else{
 const out=await SpreadsheetFile.exportXlsx(wb);
 await out.save(path.join(dir,'engine_recalculated.xlsx'));
 console.log('Recalculated and exported',results.length,'scalar/input observations');
 }
}
