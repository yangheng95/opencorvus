"""Build the April CFO draft from immutable public inputs. No ledger entries are posted."""

from pathlib import Path
from copy import copy
from datetime import datetime
import re, json
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter as L
from openpyxl.comments import Comment
from openpyxl.workbook.properties import CalcProperties

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "submission"
PUB = ROOT / "public"
W = openpyxl.load_workbook(PUB / "Aurisic_Financials_3-25-1.xlsx")
PRIOR = openpyxl.load_workbook(PUB / "Aurisic_Financials_3-25-1.xlsx", data_only=True)
W.calculation = CalcProperties(calcId=191029, fullCalcOnLoad=True)
names = list(W.sheetnames)
names[1] = "#3a) TB convert 4-30-25"
names[3] = "#5) Bank recon 4-30-25"
for s, n in zip(W.worksheets, names):
    s.title = n
TOC, TB, CASH, BANK, FUND, PPD, INS, FEES, LEGAL, L1, L2, AP, AR, PAY, REB = names
claims = []
meta = {}
issues = []


def ref(s, a):
    return "'" + s.replace("'", "''") + "'!" + a


def claim(c, s, a, role="calculated", basis="", columns=None):
    claims.append([c, s, a, role, json.dumps(columns or {}), basis])


def put(s, a, v):
    W[s][a] = v


def formula(s, a, f):
    put(s, a, "=" + f)


def clear(s):
    sh = W[s]
    for r in list(sh.merged_cells.ranges):
        sh.unmerge_cells(str(r))
    for row in sh:
        for c in row:
            c.value = None
    sh.print_area = None
    for k in list(sh.column_dimensions):
        del sh.column_dimensions[k]
    for k in list(sh.row_dimensions):
        del sh.row_dimensions[k]


def banner(s, title, note, cols=6):
    sh = W[s]
    sh.merge_cells(start_row=1, start_column=1, end_row=1, end_column=cols)
    sh.cell(1, 1, title)
    sh.merge_cells(start_row=2, start_column=1, end_row=2, end_column=cols)
    sh.cell(2, 1, note)
    sh.row_dimensions[1].height = 29
    sh.row_dimensions[2].height = 42


def row(s, r, vals):
    for i, v in enumerate(vals, 1):
        W[s].cell(r, i, v)


def issue(
    area,
    source,
    observation,
    result,
    action,
    status="Open — CFO evidence/approval required",
):
    issues.append([area, source, observation, result, action, status])


def copy_source(file, name, index=0):
    src = openpyxl.load_workbook(PUB / file).worksheets[index]
    sh = W.create_sheet(name)
    for rr in src:
        for c in rr:
            if c.value is not None:
                t = sh.cell(c.row, c.column, c.value)
                if c.has_style:
                    t._style = copy(c._style)
                t.number_format = c.number_format
    for k, d in src.column_dimensions.items():
        sh.column_dimensions[k] = copy(d)
    for k, d in src.row_dimensions.items():
        sh.row_dimensions[k] = copy(d)
    for m in src.merged_cells.ranges:
        sh.merge_cells(str(m))
    sh.freeze_panes = src.freeze_panes
    sh.sheet_view.showGridLines = False
    sh.sheet_properties.pageSetUpPr.fitToPage = True
    sh.print_options.horizontalCentered = True
    sh.page_setup.orientation = "landscape"
    sh.page_setup.paperSize = sh.PAPERSIZE_A3
    sh.page_setup.fitToWidth = 1
    sh.page_setup.fitToHeight = 0
    sh.print_area = f"A1:{L(src.max_column)}{src.max_row}"
    return sh


def source_index(c, s, start, end, last):
    sh = W[s]
    extra = openpyxl.utils.column_index_from_string(last) + 1
    sh.cell(2, extra, "source_row")
    for r in range(start, end + 1):
        sh.cell(r, extra, r)
    claim(
        c,
        s,
        f"A{start}:{L(extra)}{end}",
        "source_table",
        "Original first-sheet coordinates retained; formulas recalculate, observations retain source identity.",
        dict(source_row=L(extra), **{L(i): L(i) for i in range(1, extra)}),
    )


# Source observations: raw signed inputs are retained in separate, visibly identified tabs.
sources = [
    ("PPD1250-1.xlsx", "Source PPD1250"),
    ("PPD1251-1.xlsx", "Source PPD1251"),
    ("Prof_Fee_Dump-1.xlsx", "Source Fees"),
    ("Legal_Dump-1.xlsx", "Source Legal"),
    ("Payroll-1.xlsx", "Source Payroll"),
    ("Aurisic_Corp_Payrolls_April_2025-1.xlsx", "Source Corporate Payroll"),
    ("Outstanding_CKs_4-30-25-1.xlsx", "Source Checks"),
    ("Aurisic_Prepaid_Expenses_4-25-1.xlsx", "Version PPD Expenses"),
    ("Aurisic_Prepaid_Expenses_4-25-1.xlsx", "Version Insurance", 1),
]
for item in sources:
    copy_source(*item)
S1250 = "Source PPD1250"
S1251 = "Source PPD1251"
SF = "Source Fees"
SL = "Source Legal"
SP = "Source Payroll"
SC = "Source Checks"
for args in [
    ("source.prepaid_expense", S1250, 8, 45, "CD"),
    ("source.prepaid_insurance", S1251, 6, 31, "AV"),
    ("source.fees", SF, 3, 8, "W"),
    ("source.legal", SL, 3, 59, "M"),
    ("source.payroll", SP, 5, 20, "D"),
    ("source.checks", SC, 7, 8, "E"),
]:
    source_index(*args)

# Original April TB: preserve division + account, signed period/YTD and classification.
accounts = []
for lineno, line in enumerate(
    (PUB / "Aurisic_Final_TB_4-25-1.txt").read_text().splitlines(), 1
):
    m = re.match(
        r"^\s*(\d{4})-(\d{4})\s+(.+?)\s+([\d,.]+-?)\s+([\d,.]+-?)\s+([a-zA-Z])\s*$",
        line,
    )
    if m:
        div, acc, name, p, y, cls = m.groups()

        def signed(x):
            return float(x.rstrip("-").replace(",", "")) * (
                -1 if x.endswith("-") else 1
            )

        accounts.append(
            [int(div), int(acc), name, signed(p), signed(y), cls.lower(), lineno]
        )
clear(TB)
row(
    TB,
    1,
    [
        "Div #",
        "Acct #",
        "Account Name",
        "April movement",
        "April YTD",
        "Class",
        "Source line",
    ],
)
mapping = {}
for r, a in enumerate(accounts, 2):
    row(TB, r, a)
    mapping[(a[0], a[1])] = r
end = len(accounts) + 1
claim(
    "ledger",
    TB,
    f"A2:G{end}",
    "table",
    "Aurisic_Final_TB_4-25-1.txt; signed April 0425, all account records.",
    {
        "division": "A",
        "account": "B",
        "name": "C",
        "period": "D",
        "ytd": "E",
        "class": "F",
    },
)


def gl(a, div=10, col="E"):
    return ref(TB, f"{col}{mapping[(div, a)]}")


def glnum(a, div=10, col="E"):
    return W[TB][f"{col}{mapping[(div, a)]}"].value


stats = end + 4
for j, (label, classes) in enumerate(
    [
        ("Assets", ["a"]),
        ("Liabilities", ["l"]),
        ("Net income / expenses (debit signed)", ["i", "e"]),
        ("Clearing", ["c"]),
        ("Full-ledger proof", ["a", "l", "i", "e", "c"]),
    ]
):
    r = stats + j
    put(TB, f"C{r}", label)
    for col in ["D", "E"]:
        terms = [
            f"{col}{i}" for i in range(2, end + 1) if W[TB][f"F{i}"].value in classes
        ]
        formula(TB, f"{col}{r}", "+".join(terms))
for c, r in [("net", stats + 2), ("clearing", stats + 3), ("proof", stats + 4)]:
    for suffix, col in [("period", "D"), ("ytd", "E")]:
        claim(
            f"tb.{c}.{suffix}",
            TB,
            f"{col}{r}",
            basis="April TB classification sum; full proof includes clearing without inventing entries.",
        )
put(
    TB,
    f"C{stats + 7}",
    "Period 0425; debit positive / credit negative. Full-ledger proof includes clearing.",
)
W[TB].freeze_panes = "D2"
claim(
    "input.cash1024",
    TB,
    "E" + str(mapping[(10, 1024)]),
    "input",
    "Original April TB division10/account1024 YTD; editable scenario observation, not approval to post.",
)

# Cash availability: retain template definitions and original row structure.
clear(CASH)
banner(
    CASH,
    "Aurisic | Cash availability",
    "30 April 2025 • GL2600 scope retained; not a bank-statement confirmation.",
    3,
)
row(CASH, 4, ["Description", "Amount", "Basis"])
row(CASH, 5, ["Good Insurance Co loan balance", "=-" + gl(2600), "GL 0010-2600 only"])
row(CASH, 7, ["Intercompany loans"])
for r, a in enumerate([1651, 1652, 1653, 1654, 1656, 1663, 1664], 8):
    row(
        CASH,
        r,
        [
            W[TB].cell(mapping[(10, a)], 3).value,
            "=" + gl(a),
            "April ledger asset balance",
        ],
    )
for r, lab, f in [
    (15, "Total intercompany loans", "SUM(B8:B14)"),
    (17, "Unused borrowed funds", "B5-B15"),
    (19, "Cash balance at 30 April", gl(1023) + "+" + gl(1024)),
    (21, "Cash in excess of borrowed funds", "B19-B17"),
]:
    row(CASH, r, [lab, "=" + f])
for c, a in [
    ("borrowing", "B5"),
    ("intercompany", "B15"),
    ("unused", "B17"),
    ("balance", "B19"),
    ("excess", "B21"),
]:
    claim(
        "cash." + c,
        CASH,
        a,
        basis="April TB; original cash-availability definitions and seven intercompany balances.",
    )

# Bank: do not manufacture a bank balance from ledger cash.
clear(BANK)
banner(
    BANK,
    "Aurisic | Outstanding checks and bank review",
    "30 April 2025 • reconciliation incomplete: independent bank statement not supplied.",
    5,
)
row(BANK, 4, ["Independent bank-statement balance", None, "Unavailable"])
row(BANK, 6, ["Check #", "Amount", "Status", "Issued", "Payee"])
for r in [7, 8]:
    for col in ["A", "B", "D", "E"]:
        formula(BANK, f"{col}{r}", ref(SC, f"{col}{r}"))
    put(BANK, f"C{r}", "Source outstanding")
row(BANK, 10, ["Total outstanding checks", "=SUM(B7:B8)"])
row(BANK, 12, ["Allowance GL2001 credit", "=-" + gl(2001)])
row(
    BANK,
    14,
    ["Proposed reclassification to AP", "=B10", "Not posted; CFO approval pending"],
)
row(BANK, 16, ["Ledger book cash", None, "=" + gl(1023) + "+" + gl(1024)])
row(BANK, 18, ["Bank-to-book reconciliation", None, "Unavailable"])
row(BANK, 20, ["Checks less GL allowance", "=B10-B12"])
W[BANK].merge_cells("A22:E24")
put(
    BANK,
    "A22",
    "CFO request: provide the April bank statement and clearing evidence for checks 19943096 and 199410923; confirm deposits/transfers in transit and approve any reclassification. The check list agrees with the allowance, but this does not verify the bank balance or authorize a journal.",
)
for c, a, role in [
    ("checks", "B10", "calculated"),
    ("reclass", "B14", "calculated"),
    ("book", "C16", "calculated"),
    ("statement", "C4", "unavailable"),
    ("reconciliation", "C18", "unavailable"),
]:
    claim(
        "bank." + c,
        BANK,
        a,
        role,
        "Outstanding_CKs_4-30-25-1.xlsx rows7:8; separate April ledger control; bank statement absent.",
    )
claim(
    "input.check", SC, "B7", "input", "Outstanding_CKs_4-30-25-1.xlsx B7; first check."
)
issue(
    "Bank",
    "Outstanding_CKs_4-30-25-1.xlsx C4; April TB cash1023/1024 and allowance2001",
    "No independent bank statement. Checks total equals allowance.",
    "Book cash "
    + str(glnum(1023) + glnum(1024))
    + "; proposed reclass 16,166.78 only.",
    "Provide statement, check clearing and transit items; approve reclass before posting.",
)

# Funding: historical subsidiary observations are not assumed to be April allocations.
old = PRIOR[PRIOR.sheetnames[4]]
clear(FUND)
banner(
    FUND,
    "Aurisic | Funding sources 2025",
    "April control totals are current. Subsidiary split is unavailable; March observations and budgets stay separately labeled.",
    8,
)
row(
    FUND,
    4,
    [
        "Subsidiary / control",
        "Budget monthly",
        "Budget annual",
        "March YTD source",
        "April allocation",
        "April YTD",
        "YTD / 4 months",
        "Comment",
    ],
)
for r in range(5, 12):
    row(
        FUND,
        r,
        [
            old.cell(r, 1).value,
            old.cell(r, 2).value,
            f"=B{r}*12",
            old.cell(r, 4).value,
            "Unavailable",
            "Unavailable",
            "Unavailable",
            old.cell(r, 6).value or "April split not supplied",
        ],
    )
row(
    FUND,
    12,
    [
        "Shared funding total",
        "=SUM(B5:B11)",
        "=SUM(C5:C11)",
        "=SUM(D5:D11)",
        "=-" + gl(7206, col="D"),
        "=-" + gl(7206),
        "=F12/4",
        "GL7206 control; not evidence of subsidiary allocation",
    ],
)
row(
    FUND,
    14,
    [
        "Intercompany interest",
        50000,
        "=B14*12",
        -float(PRIOR[PRIOR.sheetnames[1]]["E95"].value),
        "=-" + gl(7075, col="D"),
        "=-" + gl(7075),
        "=F14/4",
        "GL7075; no subsidiary interest split supplied",
    ],
)
row(
    FUND,
    15,
    [
        "Bank interest and other income",
        None,
        None,
        -float(PRIOR[PRIOR.sheetnames[1]]["E96"].value),
        "=-" + gl(7076, col="D") + "-" + gl(7092, col="D"),
        "=-" + gl(7076) + "-" + gl(7092),
        "=F15/4",
        "GL7076 + added GL7092, signs reversed for income presentation",
    ],
)
row(
    FUND,
    17,
    [
        "Total funded",
        "=B12+B14",
        "=C12+C14",
        "=D12+D14+D15",
        "=E12+E14+E15",
        "=F12+F14+F15",
        "=F17/4",
        "Elapsed months corrected to four for all April averages",
    ],
)
row(
    FUND,
    20,
    [
        "Mapping issue: duplicate UK labels in original rows5/7; do not rename or allocate without CFO crosswalk."
    ],
)
for c, a in [
    ("funding", "F12"),
    ("funding_average", "G12"),
    ("intercompany", "F14"),
    ("intercompany_average", "G14"),
    ("bank_other", "F15"),
    ("bank_other_average", "G15"),
    ("total", "F17"),
    ("total_average", "G17"),
]:
    claim(
        "funding." + c,
        FUND,
        a,
        basis="April TB GL7206/7075/7076/7092; positive income presentation and elapsed4 months; split unresolved.",
    )
issue(
    "Funding / identity",
    "March template funding rows5/7; April TB7206,7075,7076,7092",
    "Duplicate UK labels; no April subsidiary allocation or crosswalk. GL1656 name changes FR to DE.",
    "Use April GL control totals; March splits retained as historical only.",
    "Confirm subsidiary crosswalk and allocation; no extrapolation from monthly budgets.",
)

# Prepaids: supported source equations remain live; no balancing plugs or term guesses.
for (
    name,
    sr,
    first,
    last,
    priorcol,
    addcol,
    amcol,
    closecol,
    vcol,
    percol,
    desccol,
    acct,
    prefix,
) in [
    (
        PPD,
        S1250,
        8,
        45,
        "BU",
        "BV",
        "BW",
        "BX",
        "A",
        "BY",
        "BZ",
        1250,
        "prepaid.expense.",
    ),
    (
        INS,
        S1251,
        6,
        31,
        "AQ",
        "AR",
        "AS",
        "AT",
        "B",
        "C",
        "AU",
        1251,
        "prepaid.insurance.",
    ),
]:
    clear(name)
    banner(
        name,
        "Aurisic | "
        + ("Prepaid expenses #1250" if acct == 1250 else "Prepaid insurance #1251"),
        "April 2025 • source-calculated observations, not approved GL adjustments. Coverage conflicts and residuals require CFO review.",
        8,
    )
    row(
        name,
        4,
        [
            "Original row",
            "Vendor / description",
            "Source period",
            "March source close",
            "April additions",
            "April amortization",
            "April close",
            "Description / exception",
        ],
    )
    rr = 5
    for r in range(first, last + 1):
        if W[sr][f"{closecol}{r}"].value is None:
            continue
        for c, orig in [
            ("B", vcol),
            ("C", percol),
            ("D", priorcol),
            ("E", addcol),
            ("F", amcol),
            ("G", closecol),
            ("H", desccol),
        ]:
            if W[sr][f"{orig}{r}"].value is not None:
                formula(name, f"{c}{rr}", ref(sr, f"{orig}{r}"))
        put(name, f"A{rr}", r)
        claim(
            prefix + "vendor." + str(r),
            name,
            f"G{rr}",
            basis=f"{sr} original {closecol}{r}; source equation retained pending terms confirmation.",
        )
        rr += 1
    total = rr + 1
    row(
        name,
        total,
        [
            "Total source-calculated closing",
            None,
            None,
            f"=SUM(D5:D{rr - 1})",
            f"=SUM(E5:E{rr - 1})",
            f"=SUM(F5:F{rr - 1})",
            f"=SUM(G5:G{rr - 1})",
        ],
    )
    row(
        name,
        total + 1,
        ["April GL control", None, None, None, None, None, "=" + gl(acct)],
    )
    row(
        name,
        total + 2,
        [
            "GL less source — not an adjustment",
            None,
            None,
            None,
            None,
            None,
            f"=G{total + 1}-G{total}",
        ],
    )
    for suffix, r in [("total", total), ("gl", total + 1), ("gap", total + 2)]:
        claim(
            prefix + suffix,
            name,
            f"G{r}",
            basis=f"Dedicated April PPD{acct}-1.xlsx; actual April GL control; no source variance plug adopted.",
        )
    W[name].merge_cells(
        start_row=total + 4, start_column=1, end_row=total + 6, end_column=8
    )
    put(
        name,
        f"A{total + 4}",
        (
            "Dedicated source closing uses original monthly denominators and historical 0.01 adjustment; original source variance 0.02 is NOT added to the calculated total. Dedicated P50/S50 contain #REF! legacy checks; retained as errors on source tab, not zeroed. Combined version differs by 0.01 and has inconsistent opening bridge. See CFO Review."
            if acct == 1250
            else "Dedicated source April amortization 43,644.14 plus TMMR turnover differs from April GL movement. Source TMMR text still says March coverage; April allocation and insurance invoices/amortization policy need confirmation. Combined insurance version ends in March, despite file name; not adopted as April."
        ),
    )
    meta[str(acct)] = {"totalrow": total}
claim(
    "prepaid.expense.amortization25",
    S1250,
    "BW25",
    basis="PPD1250-1.xlsx BW25 = April BV25 / 6 months,4/25–9/25.",
)
claim(
    "input.prepaid_addition",
    S1250,
    "BV25",
    "input",
    "PPD1250-1.xlsx BV25; six-month SIMPLE addition.",
)
issue(
    "Prepaid expenses",
    "PPD1250-1.xlsx BX46/BX48/BX49; April TB1250",
    "Source calculated close 692,501.313131; source adds a fixed0.02 variance to its labeled GL balance.",
    "Actual GL692,501.33 less source0.016869; retain residual, not a plug.",
    "Confirm rounding policy and legacy checks P50/S50 (#REF!); do not treat these checks as zero.",
)
issue(
    "Prepaid coverage",
    "PPD1250-1.xlsx BY/BZ and monthly formulas, rows8:42",
    "r8 expired3/25 but amortizes April; r10/11 period starts10/24 vs description11/24; r13 9-month denominator vs May2024 description; r17 expired1/25; r18 /10 vs11/24–11/25; r22/23 expired periods; r24 /3 vs3/25–6/25; r31 began March amortization despite4/25 start; r32 /10 vs 11/24–10/25 and11/25; r40 /8 vs4/25–12/25 and12.25–12.26.",
    "Source equations shown, not silently re-termed. Other inclusive/exclusive endpoint ambiguities: r9,r14,r21,r30,r33,r42.",
    "Provide vendor agreements/invoices, effective dates, endpoint convention, amortization approvals and cutoffs before changing equations.",
)
issue(
    "Prepaid source versions",
    "Aurisic_Prepaid_Expenses_4-25-1.xlsx, both sheets; PPD1250-1.xlsx and PPD1251-1.xlsx",
    "Combined expense close differs by0.01 (ZIPLINE historical adjustment); STARTUP/CONNXTION and PINK identities differ; some period text differs. Combined insurance ends March2025 under a2024 sheet label.",
    "Dedicated April versions used explicitly, not because closest to GL. Combined expense BU53 omits165,000 opening insertions.",
    "Resolve identity/period differences and confirm source authority; original versions preserved on Version tabs.",
)
issue(
    "Prepaid insurance",
    "PPD1251-1.xlsx AT32; April TB1251",
    "Source closing5,493.27 vs GL54,630.68; source April amortization43,644.14, GL movement+5,493.27.",
    "GL less source49,137.41; source March close49,137.41.",
    "Confirm April amortization journal, insurance policy and TMMR April coverage; obtain posting history. No adjustment posted.",
)

# Professional fees preserve signed opening and every posted movement.
clear(FEES)
banner(
    FEES,
    "Aurisic | Professional-fee accrual #2404",
    "April 2025 • signed source opening plus transactions; credits remain negative.",
    6,
)
row(
    FEES,
    4,
    ["Original row", "Period", "Posting date", "Reference", "Debit", "Signed credit"],
)
for out, r in enumerate(range(3, 9), 5):
    row(FEES, out, [r])
    for col, orig in [("B", "D"), ("C", "C"), ("D", "S"), ("E", "V"), ("F", "W")]:
        if W[SF][f"{orig}{r}"].value is not None:
            formula(FEES, f"{col}{out}", ref(SF, f"{orig}{r}"))
row(FEES, 12, ["Signed balance", None, None, None, "=SUM(E5:F10)"])
row(FEES, 13, ["Signed April GL", None, None, None, "=" + gl(2404)])
row(FEES, 14, ["GL less source", None, None, None, "=E13-E12"])
claim(
    "fees.balance",
    FEES,
    "E12",
    basis="Prof_Fee_Dump-1.xlsx signed opening W3 plus V/W rows4:8 once.",
)
claim("input.fees", SF, "V8", "input", "Prof_Fee_Dump-1.xlsx V8; April reversal debit.")

# Legal signed detail once; ignore the duplicated source total in row62.
clear(LEGAL)
banner(
    LEGAL,
    "Aurisic | Legal / audit expense #6200",
    "January–April 2025 • each signed transaction counted once. Period425 shown separately; duplicate source subtotal excluded.",
    9,
)
row(
    LEGAL,
    4,
    [
        "Source row",
        "Period",
        "Posting date",
        "Vendor",
        "Reference",
        "Debit",
        "Signed credit",
        "Net",
        "Journal",
    ],
)
for out, r in enumerate(range(3, 60), 5):
    row(LEGAL, out, [r])
    for col, orig in [
        ("B", "D"),
        ("C", "C"),
        ("D", "G"),
        ("E", "K"),
        ("F", "L"),
        ("G", "M"),
        ("I", "H"),
    ]:
        if W[SL][f"{orig}{r}"].value is not None:
            formula(LEGAL, f"{col}{out}", ref(SL, f"{orig}{r}"))
    formula(LEGAL, f"H{out}", f"SUM(F{out}:G{out})")
row(
    LEGAL,
    64,
    ["YTD signed activity", None, None, None, None, None, None, "=SUM(H5:H61)"],
)
row(
    LEGAL,
    65,
    [
        "April period425",
        None,
        None,
        None,
        None,
        None,
        None,
        "=SUMIF(B5:B61,425,H5:H61)",
    ],
)
row(LEGAL, 66, ["April GL YTD", None, None, None, None, None, None, "=" + gl(6200)])
row(LEGAL, 67, ["GL less source", None, None, None, None, None, None, "=H66-H64"])
row(
    LEGAL,
    68,
    ["April GL movement", None, None, None, None, None, None, "=" + gl(6200, col="D")],
)
row(
    LEGAL,
    69,
    ["April movement less source", None, None, None, None, None, None, "=H68-H65"],
)
for c, a in [("total", "H64"), ("april", "H65"), ("gl", "H66"), ("gap", "H67")]:
    claim(
        "legal." + c,
        LEGAL,
        a,
        basis="Legal_Dump-1.xlsx rows3:59 only, signed L+M. Row60 subtotal and row62 duplicate total excluded.",
    )
issue(
    "Legal source total",
    "Legal_Dump-1.xlsx L60:M63; rows3:59; April TB6200",
    "Row62 sums transaction rows plus row60 subtotal; displayed row63 doubles the total and is mislabeled March.",
    "435,284.69 signed YTD and62,772.93 April agree to April GL.",
    "Adopt corrected one-count formula, documented here; no GL adjustment.",
    "Calculation corrected; CFO review pending",
)

# Loan schedules retain dated principal, interest transactions and complete running balances.
for file, name, last, c in [
    ("Good Insurance Co - Loan.xlsx", L1, 74, "loan1."),
    ("Good Insurance Co - Loan II.xlsx", L2, 24, "loan2."),
]:
    clear(name)
    src = openpyxl.load_workbook(PUB / file).active
    sh = W[name]
    for rr in src:
        for cell in rr:
            if cell.value is not None:
                sh.cell(cell.row, cell.column, cell.value)
                if cell.has_style:
                    sh.cell(cell.row, cell.column)._style = copy(cell._style)
    for k, d in src.column_dimensions.items():
        sh.column_dimensions[k] = copy(d)
    for k, d in src.row_dimensions.items():
        sh.row_dimensions[k] = copy(d)
    sh["J2"] = "April source schedule — review draft"
    sh["J3"] = "Actual/365, quarterly payments; source dates retained."
    sh["J4"] = "Interest payment is not a principal repayment."
    sh["J5"] = "Original borrower TEXAS; entity mapping needs confirmation."
    sh["J6"] = (
        "Source historical formula convention retained, not policy certification."
    )
    if c == "loan1.":
        sh["D74"] = "=MIN(3,$D$8+A74)"
        sh["J7"] = (
            "April rate capped at3% per stated terms; history retains source calculations."
        )
        claim(
            "input.loan1_rate",
            name,
            "A74",
            "input",
            "Good Insurance Co - Loan.xlsx A74, percent-point units (3 means3%); April effective rate capped at3%.",
        )
    # Provenance belongs in J; never overwrite the running-interest opening in F.
    for r in range(11, last + 1):
        sh.cell(r, 6).value = src.cell(r, 6).value
        sh.cell(r, 10, r)
    sh["F2"] = src["F2"].value
    sh["J10"] = "source_row"
    claim(
        "source." + c.rstrip("."),
        name,
        f"A11:J{last}",
        "source_table",
        file
        + " first worksheet original A:E; source rate observations and signed transactions retained.",
        dict(source_row="J", **{L(i): L(i) for i in range(1, 6)}),
    )
    for suf, a in [
        ("principal", f"G{last}"),
        ("charge", f"E{last}"),
        ("interest", f"F{last}"),
    ]:
        claim(
            c + suf,
            name,
            a,
            basis=file
            + f" original row{last}; date-based actual/365; accrued balance includes signed payments and historical rounding residuals.",
        )

# Missing AP cannot be replaced by a March list.
clear(AP)
banner(
    AP,
    "Aurisic | Accounts payable trade #2000",
    "30 April 2025 • detailed AP trial balance unavailable. March supplier list is not carried forward.",
    5,
)
row(AP, 5, ["April GL trade AP credit", "=-" + gl(2000)])
row(AP, 7, ["Detailed AP support", "Unavailable"])
W[AP].merge_cells("A9:E12")
put(
    AP,
    "A9",
    "CFO request: supply AP_TB-1.xlsx as of30 April, including supplier/account detail and aging, reconciling to GL0010-2000. Confirm scope, cutoffs, debit balances and proposed outstanding-check reclassification. Detail has not been received and no approval or adjustment has been recorded.",
)
claim(
    "ap.control",
    AP,
    "B5",
    basis="April TB0010-2000 credit magnitude; known control, not detailed support.",
)
claim(
    "ap.detail",
    AP,
    "B7",
    "unavailable",
    "AP_TB-1.xlsx is named in original request but absent from supplied17 inputs.",
)
claim(
    "ap.action",
    AP,
    "A9",
    "explanation",
    "Draft CFO evidence request; not sent; approval pending.",
)
issue(
    "AP",
    "AP_TB-1.xlsx absent; April TB0010-2000",
    "No April supplier detail or aging. March supplier list cannot establish April.",
    "Known GL credit314,563.78; detailed reconciliation unavailable.",
    "Provide missing AP trial balance, reconcile supplier balances to control, review cutoff and approve any correction.",
)

# AR source identity is not a proven entity crosswalk.
clear(AR)
banner(
    AR,
    "Aurisic | AR accrual #1101",
    "30 April 2025 • preserve source GA-0015 identity and both ledger divisions.",
    5,
)
src = openpyxl.load_workbook(PUB / "AR_Accrual-1.xlsx").active
row(AR, 4, [src["A4"].value, src["B4"].value, "Source observation"])
row(AR, 6, ["Source total", "=SUM(B4:B5)"])
row(AR, 8, ["Division10 ledger", "= " + gl(1101)])
row(AR, 9, ["Division12 ledger", "=" + gl(1101, 12)])
row(AR, 11, ["Division10 GL less source", "=B8-B6"])
W[AR].merge_cells("A13:E16")
put(
    AR,
    "A13",
    "GA-0015 is the original source label. The amount matches division10, but no legal entity-to-division crosswalk is supplied. Division12 has an additional60,500.00. CFO must confirm ownership, scope and completeness before reconciling the company total or assigning the source to a division.",
)
for c, a, role in [
    ("source", "B6", "calculated"),
    ("division10", "B8", "calculated"),
    ("division12", "B9", "calculated"),
    ("gap", "B11", "calculated"),
    ("mapping", "A13", "explanation"),
]:
    claim(
        "ar." + c,
        AR,
        a,
        role,
        "AR_Accrual-1.xlsx GA-0015 B4; April TB division10/12 account1101; crosswalk absent.",
    )
issue(
    "AR identity",
    "AR_Accrual-1.xlsx A4:B6; April TB0010-1101 and0012-1101",
    "GA-0015 source10,997 matches division10 but has no proven crosswalk.",
    "Division10 10,997; division12 60,500; matched amount alone is insufficient.",
    "Confirm GA-0015 entity/division and obtain support for all divisions.",
)

# Payroll: one copy counted, unique corporate reallocation instruction preserved.
clear(PAY)
ps = openpyxl.load_workbook(PUB / "Payroll-1.xlsx").active
for rr in ps:
    for cell in rr:
        if cell.value is not None:
            formula(
                PAY, cell.coordinate, ref(SP, cell.coordinate)
            ) if cell.data_type == "f" or isinstance(cell.value, (int, float)) else put(
                PAY, cell.coordinate, cell.value
            )
put(PAY, "E18", "Corporate copy: need to reallocate")
row(
    PAY,
    36,
    [
        "April payroll / GL reconciliation",
        "Credit-positive controls",
        "Source or calculation",
    ],
)
for r, lab, f in [
    (
        37,
        "Opening accrual (March GL)",
        str(-float(PRIOR[PRIOR.sheetnames[1]]["E29"].value)),
    ),
    (38, "Signed April source accrual postings", "C25+C28+C32"),
    (39, "Credit rollforward", "B37-B38"),
    (40, "April GL credit", "-" + gl(2200)),
    (41, "GL credit less source rollforward", "B40-B39"),
    (43, "Partial source salary movement", "C6+D6+C26+C29+C33"),
    (44, "GL6000 April movement", gl(6000, col="D")),
    (45, "GL less salary-source movement", "B44-B43"),
    (47, "Source employee-expense movement", "C18+D18"),
    (48, "GL6305 April movement", gl(6305, col="D")),
    (49, "GL less expense-source movement", "B48-B47"),
    (51, "Fixed payroll accrual vs130% estimate", "-C28-E29"),
]:
    row(PAY, r, [lab, "=" + f])
W[PAY].merge_cells("A53:F56")
put(
    PAY,
    "A53",
    "Payroll-1.xlsx and corporate April copy contain the same numeric postings: count once. Corporate E18 says need to reallocate; Payroll row16 says Paycom Fees while corporate says Payroll Fees. Source fixed new accrual236,500 differs from130% estimate236,448.888 by51.112. Partial salary/employee-expense bridges are not proof the GL is wrong; obtain all posting and allocation history before adjustment. Source special IT20,500 may overlap opening scope; CFO confirmation needed.",
)
for c, a in [
    ("first", "C21"),
    ("second", "D21"),
    ("estimate", "E29"),
    ("opening", "B37"),
    ("postings", "B38"),
    ("rollforward", "B39"),
    ("gl", "B40"),
    ("gap", "B41"),
    ("salary", "B43"),
    ("salary_gl", "B44"),
    ("salary_gap", "B45"),
    ("expenses", "B47"),
    ("expenses_gl", "B48"),
    ("expenses_gap", "B49"),
]:
    claim(
        "payroll." + c,
        PAY,
        a,
        basis="Payroll-1.xlsx April counted once; corporate copy unique annotation preserved; March GL2200 opening and April movements are separate controls.",
    )
claim(
    "payroll.annotation",
    PAY,
    "E18",
    "explanation",
    "Aurisic_Corp_Payrolls_April_2025-1.xlsx April2025 E18 business instruction retained.",
)
issue(
    "Payroll",
    "Payroll-1.xlsx; corporate April2025 copy E18; March/April TB2200,6000,6305",
    "Copies overlap numerically; corporate instruction says need to reallocate. Fixed accrual differs from estimate.",
    "Credit rollforward318,500 vs GL141,033, gap−177,467. Partial salary GL less source7,649.98; employee-expense GL less source−26,750.90.",
    "Provide posting history, cutoff and reallocation support; confirm special IT/opening scope and accrual rounding/policy. No journal inferred.",
)

# Rebates, new April uninvoiced, bonus and miscellaneous schedules.
clear(REB)
for file, name, prefix, acct, total in [
    ("Rebates-1.xlsx", REB, "rebates.", 2005, "B11"),
    ("Accr2011-1.xlsx", "#16) Uninvoiced #2011", "uninvoiced.", 2011, "B7"),
    ("AccrBonus-1.xlsx", "#17) Bonus #2401", "bonus.", 2401, "B13"),
    ("AccrMisc-1.xlsx", "#18) Misc accrual #2410", "misc.", 2410, "C10"),
]:
    if name not in W.sheetnames:
        W.create_sheet(name)
    src = openpyxl.load_workbook(PUB / file).active
    for rr in src:
        for c in rr:
            if c.value is not None:
                W[name].cell(c.row, c.column, c.value)
                if c.has_style:
                    W[name].cell(c.row, c.column)._style = copy(c._style)
    r = max(src.max_row + 4, 23)
    row(name, r, ["Source-calculated closing", "=" + total])
    row(name, r + 1, ["April GL credit", "=-" + gl(acct)])
    row(
        name,
        r + 2,
        [
            "Source less GL" if acct == 2005 else "GL less source",
            f"=B{r}-B{r + 1}" if acct == 2005 else f"=B{r + 1}-B{r}",
        ],
    )
    for c, a in [("total", total), ("gl", f"B{r + 1}"), ("gap", f"B{r + 2}")]:
        claim(
            prefix + c,
            name,
            a,
            basis=file
            + " original source transactions; April TB credit control; no balancing entries.",
        )
    if acct == 2401:
        # Preserve original B15/B18 observations; refreshed headlines elsewhere.
        row(name, 28, ["Current live bonus headline", "=B13"])
        row(name, 29, ["Current salary YTD GL6000", "=" + gl(6000)])
        row(name, 30, ["10% salary reference — unapproved", "=B29*0.1"])
        W[name].merge_cells("A32:F35")
        put(
            name,
            "A32",
            "Original B15 fixed reported total and B18 salary are historical observations, not live formulas. B13 and current headline refresh from source accrual inputs. 10% is a reference from the source, not an approved compensation policy. Source includes188,639.10 Aurisic CA accrual; obtain approval and entity allocation before final sign-off.",
        )
        for c, a, role in [
            ("headline", "B28", "calculated"),
            ("salary_ytd", "B29", "calculated"),
            ("ten_percent_reference", "B30", "calculated"),
            ("source_salary", "B18", "source"),
            ("source_reported", "B15", "source"),
        ]:
            claim(
                "bonus." + c,
                name,
                a,
                role,
                "AccrBonus-1.xlsx historical B15/B18 versus current source rollforward and April GL6000;10% policy unapproved.",
            )
        claim(
            "input.bonus",
            name,
            "B12",
            "input",
            "AccrBonus-1.xlsx B12 April accrual; original input precision retained.",
        )
        issue(
            "Bonus policy",
            "AccrBonus-1.xlsx B11:B19; April TB2401/6000",
            "Source rollforward agrees with GL, including CA188,639.10. Fixed reported total and salary are not refreshable controls.",
            "Current rollforward334,593.73;10% salary146,302.636 is only a reference.",
            "Approve compensation/accrual policy, CA allocation and supporting calculation; no policy approval supplied.",
        )
    if acct == 2011:
        W[name].merge_cells("A29:F32")
        put(
            name,
            "A29",
            "Source contains April costs paid in May144,474.11 and transfer-pricing adjustment at3/31/25 of159,695.00. Source closing agrees to April GL. Cross-period mismatch requires posting history; matching source values do not establish journal approval.",
        )

CTRL = "Loan Controls"
W.create_sheet(CTRL)
banner(
    CTRL,
    "Aurisic | Combined loan controls",
    "30 April 2025 • compare both source schedules with ledger, retaining payment and rounding evidence.",
    5,
)
for r, lab, f in [
    (5, "Loan I principal", ref(L1, "G74")),
    (6, "Loan II principal", ref(L2, "G24")),
    (7, "Combined principal", "SUM(B5:B6)"),
    (8, "GL2600 + GL2601 credit", "-" + gl(2600) + "-" + gl(2601)),
    (9, "GL less schedule principal", "B8-B7"),
    (11, "April Loan I charge", ref(L1, "E74")),
    (12, "April Loan II charge", ref(L2, "E24")),
    (13, "Combined April charge", "SUM(B11:B12)"),
    (15, "Loan I accrued interest", ref(L1, "F74")),
    (16, "Loan II accrued interest", ref(L2, "F24")),
    (17, "Combined accrued interest", "SUM(B15:B16)"),
    (18, "GL2402 credit", "-" + gl(2402)),
    (19, "GL less schedule interest", "B18-B17"),
    (21, "April7 Loan I payment", ref(L1, "E73")),
    (22, "April7 Loan II payment", ref(L2, "E23")),
    (24, "GL6810 April expense", gl(6810, col="D")),
    (25, "GL expense less April schedule charge", "B24-B13"),
]:
    row(CTRL, r, [lab, "=" + f])
for c, a in [
    ("principal", "B7"),
    ("principal_gl", "B8"),
    ("principal_gap", "B9"),
    ("interest", "B17"),
    ("interest_gl", "B18"),
    ("interest_gap", "B19"),
]:
    claim(
        "loans." + c,
        CTRL,
        a,
        basis="Both dated Good Insurance Co loan schedules; original GL2600+2601 and2402; no rounding or policy balancing plug.",
    )
W[CTRL].merge_cells("A27:E30")
put(
    CTRL,
    "A27",
    "Source Loan I/II borrower is TEXAS, not a confirmed Aurisic entity crosswalk. Combined principal agrees with GL. April charges use30 days (3/31–4/30), not23 days since the4/7 payments. Source payments clear prior quarterly interest; retained historical rounding leaves a sub-cent combined difference. Confirm executed agreements, rate reset evidence, entity mapping and rounding policy. Historical Loan I source has corrected-rate/payment anomalies; source computations are retained, not certified.",
)
issue(
    "Loan terms and accrual",
    "Good Insurance Co - Loan.xlsx rows72:74; Loan II rows22:24; April TB2402,2600,2601,6810",
    "Principal31,800,000 agrees with GL; April interest spans30 days notwithstanding April7 payments.",
    "Combined running interest67,315.064329 vs GL67,315.07; gap0.005671 retained.",
    "Confirm TEXAS borrower crosswalk, executed terms/rates, historical corrections and rounding policy. No write-off or certification of historical policy.",
)

# Cross-period bridge for every joint account identity, not just selected exceptions.
BR = "Period Bridges"
W.create_sheet(BR)
banner(
    BR,
    "Aurisic | March-to-April bridges",
    "Gap = April YTD − (March YTD + April movement). Differences are review questions, not automatic accounting errors.",
    9,
)
row(
    BR,
    4,
    [
        "Division",
        "Account",
        "March YTD",
        "April movement",
        "April YTD",
        "Gap",
        "Source-backed candidate",
        "CFO action",
        "Account name",
    ],
)
prev = {}
for rr in PRIOR[PRIOR.sheetnames[1]].iter_rows(min_row=2, max_row=98, values_only=True):
    if isinstance(rr[0], (int, float)) and isinstance(rr[1], (int, float)):
        prev[(int(rr[0]), int(rr[1]))] = rr[4]
candidates = {
    1250: (
        "165,000 =81,000 Global +28,000 +56,000 TTK inserted into source March close.",
        "PPD1250 BU20,BU36:37 vs March template; obtain journal/cutoff history.",
    ),
    2011: (
        "159,695 transfer-pricing adjustment dated3/31/25 in Accr2011 B5.",
        "Confirm posting timing and cutoff; match does not establish booked entry.",
    ),
    6200: (
        "−84,000 = March source credits−28,000−56,000 (Legal rows55:56); April amortization28,000 rows57:58.",
        "Trace actual posting history and linkage to PPD1250 BU36:37; no second adjustment.",
    ),
    7107: (
        "78,695 =159,695 transfer-price source less81,000 Global prepaid insertion; hypothesis only.",
        "Obtain source journal links, scope and approval; amount match is not proof.",
    ),
    1656: (
        "March name FR vs April DE; same joint account, identity unresolved.",
        "CFO crosswalk needed; no silent entity rename.",
    ),
}
for r, a in enumerate(accounts, 5):
    div, acc, name, p, y, cls, _ = a
    pr = prev.get((div, acc))
    # March clearing accounts not in converted template; preserve absent status rather than inventing prior.
    row(
        BR,
        r,
        [
            div,
            acc,
            pr if pr is not None else "Not in March converted table",
            "=" + gl(acc, div, "D"),
            "=" + gl(acc, div),
            f"=E{r}-C{r}-D{r}" if pr is not None else "Unavailable",
            candidates.get(
                acc,
                (
                    "No specific causal posting evidence supplied.",
                    "Obtain posting/cutoff history for nonzero gap; do not plug.",
                ),
            )[0],
            candidates.get(
                acc,
                (
                    "",
                    "Obtain posting/cutoff history for nonzero gap; no adjustment inferred.",
                ),
            )[1],
            name,
        ],
    )
    if pr is not None and abs(y - pr - p) > 0.005:
        issue(
            "Period bridge " + str(div) + "-" + str(acc),
            "March template TB vs April original TB; see Period Bridges",
            f"Prior {pr:,.2f} + movement {p:,.2f} vs current {y:,.2f}.",
            f"Current less expected {y - pr - p:,.2f}. "
            + candidates.get(acc, ("Causal history unavailable.",))[0],
            candidates.get(
                acc,
                (
                    "",
                    "Provide posting history, opening/cutoff and entity-scope reconciliation; do not assume error.",
                ),
            )[1],
        )
    if pr is None:
        issue(
            "Prior scope " + str(div) + "-" + str(acc),
            "March converted TB; original April TB",
            "Joint account identity not present in March converted ledger.",
            f"April movement{p:,.2f}; April YTD{y:,.2f}; prior unknown, not zero.",
            "Confirm account creation/opening or clearing prior scope; no invented March balance.",
        )
claim(
    "bridges",
    BR,
    f"A5:I{len(accounts) + 4}",
    "table",
    "March template converted TB versus original April TB; no implicit zero for absent prior.",
    {
        "division": "A",
        "account": "B",
        "prior": "C",
        "movement": "D",
        "current": "E",
        "gap": "F",
        "candidate": "G",
        "action": "H",
    },
)

# CFO draft request and audit index appended after financial schedules.
REV = "CFO Review"
W.create_sheet(REV)
banner(
    REV,
    "Aurisic | CFO review requests — draft, not sent",
    "April 2025 • prepared from supplied records. No financial sign-off, approvals or ledger changes implied.",
    6,
)
row(
    REV,
    4,
    [
        "Area",
        "Source",
        "Observation",
        "Result / difference",
        "Requested action",
        "Status",
    ],
)
for r, data in enumerate(issues, 5):
    row(REV, r, data)
claim(
    "issues",
    REV,
    f"A5:F{len(issues) + 4}",
    "table",
    "Concrete source differences and missing company evidence; draft CFO requests, not sent.",
    {
        "area": "A",
        "source": "B",
        "observation": "C",
        "result": "D",
        "action": "E",
        "status": "F",
    },
)
INDEX = "Audit Index"
W.create_sheet(INDEX)
row(INDEX, 1, ["Claim", "Sheet", "Address", "Role", "Columns", "Basis"])

# Original tab order preserved; genuinely new schedules and source appendices follow #15.
primary = names + [
    "#16) Uninvoiced #2011",
    "#17) Bonus #2401",
    "#18) Misc accrual #2410",
    CTRL,
    BR,
    REV,
]
appendix = [s for s in W.sheetnames if s not in primary and s != INDEX]
W._sheets = [W[s] for s in primary + appendix + [INDEX]]
clear(TOC)
banner(
    TOC,
    "Aurisic | April 2025 financial package",
    "CFO REVIEW DRAFT • Tab0. CFO-reserved sections1/2/2a/3 excluded. No missing evidence has been replaced by a balancing entry.",
    4,
)
row(TOC, 4, ["Section", "Sheet", "Status / review comment", "Purpose"])
statuses = {
    TB: "All original April accounts and proofs; prior bridges open",
    CASH: "Calculated from April ledger; not bank verification",
    BANK: "Checks calculated; independent bank statement unavailable",
    FUND: "GL totals calculated; subsidiary allocations unresolved",
    PPD: "Source calculations complete; terms/version/rounding questions open",
    INS: "Source calculations complete; GL gap49,137.41 open",
    FEES: "Signed source and GL reconciled",
    LEGAL: "Duplicate subtotal corrected; YTD/April reconcile",
    L1: "Dated accrual calculated; terms/entity confirmation pending",
    L2: "Dated accrual calculated; terms/entity confirmation pending",
    AP: "GL control only; AP_TB-1.xlsx missing",
    AR: "Both GL scopes shown; GA-0015 crosswalk unresolved",
    PAY: "Copies counted once; accrual and partial movement bridges open",
    REB: "Signed April source reconciled",
    REV: "Draft CFO requests — not sent; approvals outstanding",
    BR: "All joint identities; nonzero bridges escalated",
}
for r, s in enumerate(W.sheetnames[1:], 5):
    section = re.match(r"^#([^)]*)", s)
    row(
        TOC,
        r,
        [
            section.group(1) if section else "Appendix",
            s,
            statuses.get(
                s,
                "Source observations / supporting calculations; see CFO Review"
                if s.startswith(("Source", "Version"))
                else "Calculated support; review pending",
            ),
            "Retained financial schedule"
            if s in names
            else "New April schedule / audit support",
        ],
    )
    W[TOC].cell(r, 2).hyperlink = "#'" + s.replace("'", "''") + "'!A1"
claim(
    "contents",
    TOC,
    f"A5:D{W[TOC].max_row}",
    "table",
    "Actual workbook sheet names and individual completion/uncertainty statuses; Tab0 retained.",
    {"section": "A", "sheet": "B", "status": "C"},
)
for r, c in enumerate(claims, 2):
    row(INDEX, r, c)

# Consistent review presentation: preserve template order/meaning, improve readable view.
navy = "17365D"
teal = "DDEBF7"
amber = "FFF2CC"
green = "E2F0D9"
grey = "F2F2F2"
money = '#,##0.00;[Red](#,##0.00);"–"'
for sh in W:
    sh.sheet_view.showGridLines = False
    sh.sheet_properties.pageSetUpPr.fitToPage = True
    sh.page_setup.orientation = "landscape"
    sh.page_setup.paperSize = sh.PAPERSIZE_A3
    sh.page_setup.fitToWidth = 1
    sh.page_setup.fitToHeight = 0
    sh.oddFooter.center.text = "Aurisic | April2025 | CFO review draft"
    sh.oddFooter.right.text = "Page &P of &N"
    sh.print_options.horizontalCentered = True
    if sh.title.startswith(("Source", "Version")):
        sh.sheet_properties.tabColor = "A6A6A6"
        # Hide distant empty formatted rows; full source historical matrix remains available.
        if sh.title in [S1250, "Version PPD Expenses"]:
            for i in range(2, 71):
                sh.column_dimensions[L(i)].hidden = True
        if sh.title in [S1251, "Version Insurance"]:
            for i in range(4, 41):
                sh.column_dimensions[L(i)].hidden = True
        continue
    sh.sheet_properties.tabColor = "C65911" if sh.title in [REV, BR, AP, BANK] else navy
    for rr in sh:
        for c in rr:
            if c.value is None:
                continue
            c.font = Font(
                name="Aptos",
                size=10,
                color="008000"
                if c.data_type == "f"
                else "17365D"
                if isinstance(c.value, (int, float))
                else "202020",
            )
            c.alignment = Alignment(vertical="top", wrap_text=True)
            if c.data_type == "f" or isinstance(c.value, (int, float)):
                c.number_format = money
            if c.row % 2 == 0:
                c.fill = PatternFill("solid", fgColor="F3F6FA")
    # Apply headers and deliberate layouts per family.
    if sh.title not in [
        TB,
        L1,
        L2,
        PAY,
        REB,
        "#16) Uninvoiced #2011",
        "#17) Bonus #2401",
        "#18) Misc accrual #2410",
        INDEX,
    ]:
        for c in sh[1]:
            c.fill = PatternFill("solid", fgColor=navy)
            c.font = Font(name="Aptos", size=16, bold=True, color="FFFFFF")
        for c in sh[2]:
            c.fill = PatternFill("solid", fgColor=amber)
        sh.row_dimensions[1].height = 30
        sh.row_dimensions[2].height = 43
        for c in sh[4]:
            c.fill = PatternFill("solid", fgColor=navy)
            c.font = Font(name="Aptos", size=10, bold=True, color="FFFFFF")
    else:
        for c in sh[1]:
            c.fill = PatternFill("solid", fgColor=navy)
            c.font = Font(name="Aptos", size=11, bold=True, color="FFFFFF")
    widths = [38, 22, 22, 25, 24, 24, 24, 42, 22]
    if sh.title == TOC:
        widths = [14, 43, 70, 35]
    elif sh.title == TB:
        widths = [10, 12, 48, 22, 22, 10, 14]
    elif sh.title in [PPD, INS]:
        widths = [12, 27, 22, 22, 22, 22, 22, 55]
    elif sh.title == REV:
        widths = [26, 44, 76, 68, 75, 36]
    elif sh.title == BR:
        widths = [10, 12, 23, 23, 23, 23, 68, 68, 43]
    elif sh.title == FUND:
        widths = [32, 21, 22, 22, 23, 23, 23, 63]
    elif sh.title == LEGAL:
        widths = [12, 12, 18, 38, 44, 22, 22, 22, 12]
    elif sh.title == FEES:
        widths = [14, 14, 20, 42, 23, 23]
    elif sh.title == INDEX:
        widths = [39, 40, 22, 17, 52, 95]
    elif sh.title in [L1, L2]:
        widths = [14, 18, 23, 17, 23, 23, 24, 25, 14, 18, 22, 22, 22]
    elif sh.title == PAY:
        widths = [42, 22, 24, 24, 42, 22]
    for i, v in enumerate(widths, 1):
        sh.column_dimensions[L(i)].width = v
    for rr in sh:
        if any(c.value is not None for c in rr):
            r = rr[0].row
            if r > 4:
                sh.row_dimensions[r].height = (
                    72
                    if sh.title == REV
                    else 59
                    if sh.title == BR
                    else 45
                    if sh.title in [TOC, INDEX, PPD, INS, LEGAL]
                    else 33
                )
    sh.freeze_panes = (
        "C5"
        if sh.title in [PPD, INS, BR]
        else "A5"
        if sh.title not in [TB, L1, L2, PAY]
        else "D2"
        if sh.title == TB
        else "C11"
        if sh.title in [L1, L2]
        else "C5"
    )
    if sh.title == TB:
        for rr in sh.iter_rows(min_row=2, max_row=end):
            for col in [0, 1, 6]:
                rr[col].number_format = "0"
    if sh.title in [L1, L2]:
        for r in range(11, 75 if sh.title == L1 else 25):
            sh.cell(r, 2).number_format = "yyyy-mm-dd"
            sh.cell(r, 10).number_format = "0"
            sh.cell(r, 1).number_format = "0.00000"
        for a in ["B5"]:
            sh[a].number_format = "yyyy-mm-dd"
    if sh.title in [PPD, INS]:
        for r in range(5, meta["1250" if sh.title == PPD else "1251"]["totalrow"]):
            sh.cell(r, 1).number_format = "0"
    if sh.title in [LEGAL, FEES]:
        for r in range(5, 62 if sh.title == LEGAL else 11):
            sh.cell(r, 1).number_format = "0"
            sh.cell(r, 2).number_format = "0"
            sh.cell(r, 3).number_format = "yyyy-mm-dd"
    if sh.title == BANK:
        for r in [7, 8]:
            sh.cell(r, 1).number_format = "0"
            sh.cell(r, 4).number_format = "yyyy-mm-dd"
    if sh.title == BR:
        for r in range(5, sh.max_row + 1):
            sh.cell(r, 1).number_format = "0"
            sh.cell(r, 2).number_format = "0"
    sh.print_title_rows = "1:4" if sh.title not in [TB, L1, L2, INDEX] else "1:1"
    sh.print_area = f"A1:{L(min(sh.max_column, len(widths)))}{sh.max_row}"
    if sh.title in [REV, BR, INDEX, TB]:
        sh.auto_filter.ref = f"A{4 if sh.title in [REV, BR] else 1}:{L(min(sh.max_column, len(widths)))}{sh.max_row}"

# Blue editable observations; source formula results remain green. No protection implies no approval.
for c in claims:
    if c[3] == "input":
        W[c[1]][c[2]].fill = PatternFill("solid", fgColor="DDEBF7")
        W[c[1]][c[2]].comment = Comment(
            c[5] + " Scenario edits are not approved journals.", "Preparation notes"
        )
from presentation import polish

polish(W)
W.active = 0
target = OUT / "Aurisic_Financials_4-25-1.xlsx"
W.save(target)
(OUT / "claims.json").write_text(
    json.dumps(
        [
            dict(zip(["Claim", "Sheet", "Address", "Role", "Columns", "Basis"], c))
            for c in claims
        ],
        indent=2,
    ),
    encoding="utf-8",
)
(OUT / "build_manifest.json").write_text(
    json.dumps(
        {
            "workbook": target.name,
            "account_count": len(accounts),
            "sheet_order": W.sheetnames,
            "issues": len(issues),
            "claim_count": len(claims),
            "sources": [p.name for p in sorted(PUB.glob("*.xlsx"))]
            + ["Aurisic_Final_TB_4-25-1.txt"],
            "public_contracts": [
                "TASK.original.txt",
                "QUALITY-CONTRACT.md",
                "SOURCE-POLICY.md",
                "OUTPUTS.md",
                "RUNTIME.md",
            ],
            "notes": "Original template order retained. Compact current-period presentations replace wide historical front views; complete April source matrices and alternative versions are appended. Original source errors preserved; no GL adjustments.",
        },
        indent=2,
    ),
    encoding="utf-8",
)
print(
    "Built",
    target,
    "accounts",
    len(accounts),
    "sheets",
    len(W.sheetnames),
    "claims",
    len(claims),
    "issues",
    len(issues),
)
