"""Independent source arithmetic and saved/reopened workbook checks.

Reads original source records; does not import build.py or its calculations.
"""

from pathlib import Path
from datetime import datetime, date
from decimal import Decimal
import re, json, math
import openpyxl
from openpyxl.utils.datetime import to_excel
from openpyxl.utils.cell import range_boundaries

ROOT = Path(__file__).resolve().parent.parent
P = ROOT / "public"
O = ROOT / "submission"


class Source:
    def __init__(self, file, sheet=0):
        self.s = openpyxl.load_workbook(P / file, data_only=False).worksheets[sheet]
        self.cache = {}

    def val(self, a):
        a = a.replace("$", "")
        if a in self.cache:
            return self.cache[a]
        v = self.s[a].value
        if v is None:
            v = 0
        elif isinstance(v, (date, datetime)):
            v = to_excel(v)
        elif isinstance(v, str) and v.startswith("="):
            t = v[1:]

            def sumfn(m):
                result = 0
                for part in m.group(1).split(","):
                    if ":" in part:
                        x1, y1, x2, y2 = range_boundaries(part.replace("$", ""))
                        result += sum(
                            self.val(self.s.cell(r, c).coordinate)
                            for r in range(y1, y2 + 1)
                            for c in range(x1, x2 + 1)
                        )
                    else:
                        result += self.val(part.strip())
                return str(result)

            t = re.sub(r"SUM\(([^()]*)\)", sumfn, t)
            t = re.sub(r"\$?[A-Z]{1,3}\$?\d+", lambda m: str(self.val(m.group())), t)
            t = t.replace("%", "/100")
            if not re.fullmatch(r"[0-9+\-*/(). eE]+", t):
                raise ValueError((a, t))
            v = eval(t, {"__builtins__": {}}, {})
        self.cache[a] = v
        return v


def parse_tb():
    a = {}
    for line in (P / "Aurisic_Final_TB_4-25-1.txt").read_text().splitlines():
        parts = line.split()
        if not parts or not re.fullmatch(r"\d{4}-\d{4}", parts[0]):
            continue
        d, n = map(int, parts[0].split("-"))

        def num(t):
            return Decimal(t.rstrip("-").replace(",", "")) * (
                -1 if t.endswith("-") else 1
            )

        a[(d, n)] = dict(
            name=" ".join(parts[1:-3]),
            period=num(parts[-3]),
            ytd=num(parts[-2]),
            cls=parts[-1].lower(),
        )
    return a


tb = parse_tb()


def gl(a, d=10, k="ytd"):
    return float(tb[(d, a)][k])


exp = {}
for c, cls in [
    ("net", ["i", "e"]),
    ("clearing", ["c"]),
    ("proof", ["a", "l", "i", "e", "c"]),
]:
    for k in ["period", "ytd"]:
        exp[f"tb.{c}.{k}"] = float(sum(v[k] for v in tb.values() if v["cls"] in cls))
inter = sum(gl(a) for a in [1651, 1652, 1653, 1654, 1656, 1663, 1664])
cash = gl(1023) + gl(1024)
exp.update(
    {
        "cash.borrowing": -gl(2600),
        "cash.intercompany": inter,
        "cash.unused": -gl(2600) - inter,
        "cash.balance": cash,
        "cash.excess": cash - (-gl(2600) - inter),
    }
)
checks = Source("Outstanding_CKs_4-30-25-1.xlsx")
checktotal = sum(checks.val("B" + str(r)) for r in [7, 8])
exp.update({"bank.checks": checktotal, "bank.reclass": checktotal, "bank.book": cash})
for c, v in [
    ("funding", -gl(7206)),
    ("intercompany", -gl(7075)),
    ("bank_other", -gl(7076) - gl(7092)),
    ("total", -gl(7206) - gl(7075) - gl(7076) - gl(7092)),
]:
    exp["funding." + c] = v
    exp["funding." + c + "_average"] = v / 4
for prefix, file, col, start, end, acct in [
    ("prepaid.expense.", "PPD1250-1.xlsx", "BX", 8, 45, 1250),
    ("prepaid.insurance.", "PPD1251-1.xlsx", "AT", 6, 31, 1251),
]:
    src = Source(file)
    values = []
    for r in range(start, end + 1):
        if src.s[f"{col}{r}"].value is not None:
            v = src.val(f"{col}{r}")
            exp[prefix + "vendor." + str(r)] = v
            values.append(v)
    total = sum(values)
    exp[prefix + "total"] = total
    exp[prefix + "gl"] = gl(acct)
    exp[prefix + "gap"] = gl(acct) - total
exp["prepaid.expense.amortization25"] = Source("PPD1250-1.xlsx").val("BV25") / 6
fees = Source("Prof_Fee_Dump-1.xlsx")
exp["fees.balance"] = sum(
    fees.val(f"{col}{r}") for r in range(3, 9) for col in ["V", "W"]
)
legal = Source("Legal_Dump-1.xlsx")
nets = {r: legal.val("L" + str(r)) + legal.val("M" + str(r)) for r in range(3, 60)}
exp["legal.total"] = sum(nets.values())
exp["legal.april"] = sum(v for r, v in nets.items() if legal.val("D" + str(r)) == 425)
exp["legal.gl"] = gl(6200)
exp["legal.gap"] = gl(6200) - exp["legal.total"]
for k, file, last in [
    ("loan1.", "Good Insurance Co - Loan.xlsx", 74),
    ("loan2.", "Good Insurance Co - Loan II.xlsx", 24),
]:
    src = Source(file)
    # Principal sum and dated April charge separately derived; accrued interest from source transaction equations.
    exp[k + "principal"] = sum(src.val("C" + str(r)) for r in range(11, last + 1))
    rate = src.val("A" + str(last))
    start = 72 if last == 74 else 22
    exp[k + "charge"] = (
        exp[k + "principal"]
        * rate
        / 100
        / 365
        * (src.s["B" + str(last)].value - src.s["B" + str(start)].value).days
    )
    exp[k + "interest"] = sum(src.val("E" + str(r)) for r in range(11, last + 1))
exp["loans.principal"] = exp["loan1.principal"] + exp["loan2.principal"]
exp["loans.principal_gl"] = -gl(2600) - gl(2601)
exp["loans.principal_gap"] = exp["loans.principal_gl"] - exp["loans.principal"]
exp["loans.interest"] = exp["loan1.interest"] + exp["loan2.interest"]
exp["loans.interest_gl"] = -gl(2402)
exp["loans.interest_gap"] = exp["loans.interest_gl"] - exp["loans.interest"]
exp.update(
    {
        "ap.control": -gl(2000),
        "ar.source": Source("AR_Accrual-1.xlsx").val("B4"),
        "ar.division10": gl(1101),
        "ar.division12": gl(1101, 12),
    }
)
exp["ar.gap"] = exp["ar.division10"] - exp["ar.source"]
pay = Source("Payroll-1.xlsx")
corp = Source("Aurisic_Corp_Payrolls_April_2025-1.xlsx")
prior = Source("Aurisic_Financials_3-25-1.xlsx", 1)
exp["payroll.first"] = sum(pay.val("C" + str(r)) for r in range(5, 21))
exp["payroll.second"] = sum(pay.val("D" + str(r)) for r in range(5, 21))
exp["payroll.estimate"] = (
    sum(pay.val(a) for a in ["C6", "C7", "C10", "C16", "C17"]) * 1.3
)
exp["payroll.opening"] = -prior.val("E29")
exp["payroll.postings"] = sum(pay.val(a) for a in ["C25", "C28", "C32"])
exp["payroll.rollforward"] = exp["payroll.opening"] - exp["payroll.postings"]
exp["payroll.gl"] = -gl(2200)
exp["payroll.gap"] = exp["payroll.gl"] - exp["payroll.rollforward"]
exp["payroll.salary"] = sum(pay.val(a) for a in ["C6", "D6", "C26", "C29", "C33"])
exp["payroll.salary_gl"] = gl(6000, k="period")
exp["payroll.salary_gap"] = exp["payroll.salary_gl"] - exp["payroll.salary"]
exp["payroll.expenses"] = pay.val("C18") + pay.val("D18")
exp["payroll.expenses_gl"] = gl(6305, k="period")
exp["payroll.expenses_gap"] = exp["payroll.expenses_gl"] - exp["payroll.expenses"]
for prefix, file, total, acct in [
    ("rebates.", "Rebates-1.xlsx", "B11", 2005),
    ("uninvoiced.", "Accr2011-1.xlsx", "B7", 2011),
    ("bonus.", "AccrBonus-1.xlsx", "B13", 2401),
    ("misc.", "AccrMisc-1.xlsx", "C10", 2410),
]:
    exp[prefix + "total"] = Source(file).val(total)
    exp[prefix + "gl"] = -gl(acct)
    exp[prefix + "gap"] = (
        exp[prefix + "total"] - exp[prefix + "gl"]
        if acct == 2005
        else exp[prefix + "gl"] - exp[prefix + "total"]
    )
exp.update(
    {
        "bonus.headline": exp["bonus.total"],
        "bonus.salary_ytd": gl(6000),
        "bonus.ten_percent_reference": gl(6000) * 0.1,
        "bonus.source_salary": Source("AccrBonus-1.xlsx").val("B18"),
        "bonus.source_reported": Source("AccrBonus-1.xlsx").val("B15"),
    }
)
exp.update(
    {
        "input.cash1024": gl(1024),
        "input.bonus": Source("AccrBonus-1.xlsx").val("B12"),
        "input.prepaid_addition": Source("PPD1250-1.xlsx").val("BV25"),
        "input.fees": fees.val("V8"),
        "input.check": checks.val("B7"),
        "input.loan1_rate": 3,
    }
)

resultfile = O / "recalculated_claims.json"
actual = {x["Claim"]: x for x in json.loads(resultfile.read_text())}
details = []
for k, v in exp.items():
    a = actual[k]["value"][0][0]
    error = a - v if isinstance(a, (int, float)) else None
    details.append(
        {
            "claim": k,
            "expected": v,
            "actual": a,
            "signed_error": error,
            "absolute_error": abs(error) if error is not None else None,
            "pass": error is not None and abs(error) < 0.005,
            "basis": "Independently read original source, Python arithmetic/Decimal TB; not generated workbook formulas.",
        }
    )
w = openpyxl.load_workbook(O / "Aurisic_Financials_4-25-1.xlsx", data_only=False)
ledger = w[actual["input.cash1024"]["Sheet"]]
seen = {}
for rr in ledger.iter_rows(min_row=2, max_row=106, values_only=True):
    seen[(rr[0], rr[1])] = rr
ledgerchecks = []
for key, v in tb.items():
    a = seen[key]
    ledgerchecks.append(
        {
            "division": key[0],
            "account": key[1],
            "period_error": float(Decimal(str(a[3])) - v["period"]),
            "ytd_error": float(Decimal(str(a[4])) - v["ytd"]),
            "name_ok": a[2] == v["name"],
            "class_ok": a[5] == v["cls"],
        }
    )
sourcechecks = []
for file, sheet, start, end, last in [
    ("Legal_Dump-1.xlsx", "Source Legal", 3, 59, 13),
    ("Prof_Fee_Dump-1.xlsx", "Source Fees", 3, 8, 23),
    ("Good Insurance Co - Loan.xlsx", "#11a) Interest Accrual I", 11, 74, 5),
    ("Good Insurance Co - Loan II.xlsx", "#11b) Interest Accrual II", 11, 24, 5),
    ("Payroll-1.xlsx", "Source Payroll", 5, 20, 4),
    ("Outstanding_CKs_4-30-25-1.xlsx", "Source Checks", 7, 8, 5),
    ("PPD1250-1.xlsx", "Source PPD1250", 8, 45, 82),
    ("PPD1251-1.xlsx", "Source PPD1251", 6, 31, 48),
]:
    src = Source(file).s
    count = 0
    bad = []
    for rr in src.iter_rows(min_row=start, max_row=end, max_col=last):
        for c in rr:
            if c.value is not None and c.data_type not in ["f", "e"]:
                count += 1
                if w[sheet][c.coordinate].value != c.value:
                    bad.append(c.coordinate)
    sourcechecks.append(
        {
            "file": file,
            "sheet": sheet,
            "observations_compared": count,
            "differences": bad,
            "pass": not bad,
        }
    )
overlap = []
for r in range(5, 34):
    for c in ["B", "C", "D"]:
        a = pay.val(f"{c}{r}")
        b = corp.val(f"{c}{r}")
        if a != b:
            overlap.append([f"{c}{r}", a, b])
unavailable = {
    k: actual[k]["value"][0][0]
    for k in ["bank.statement", "bank.reconciliation", "ap.detail"]
}
scenarios = {
    "cash": {
        "input": "input.cash1024",
        "change": 1,
        "deltas": {"cash.balance": 1, "cash.excess": 1, "bank.book": 1},
    },
    "bonus": {
        "input": "input.bonus",
        "change": 100,
        "deltas": {
            "bonus.total": 100,
            "bonus.headline": 100,
            "bonus.gap": -100,
            "bonus.source_reported": 0,
            "bonus.source_salary": 0,
        },
    },
    "prepaid": {
        "input": "input.prepaid_addition",
        "change": 6,
        "deltas": {
            "prepaid.expense.amortization25": 1,
            "prepaid.expense.vendor.25": 5,
            "prepaid.expense.total": 5,
            "prepaid.expense.gap": -5,
        },
    },
    "fees": {"input": "input.fees", "change": 1, "deltas": {"fees.balance": 1}},
    "check": {
        "input": "input.check",
        "change": 1,
        "deltas": {"bank.checks": 1, "bank.reclass": 1, "bank.book": 0},
    },
    "rate": {
        "input": "input.loan1_rate",
        "change": -1,
        "deltas": {
            "loan1.charge": -18300000 * 0.01 * 30 / 365,
            "loan1.interest": -18300000 * 0.01 * 30 / 365,
            "loans.interest": -18300000 * 0.01 * 30 / 365,
            "loans.interest_gap": 18300000 * 0.01 * 30 / 365,
            "loan1.principal": 0,
        },
    },
}
(O / "scenario_expectations.json").write_text(json.dumps(scenarios, indent=2))
scenario_results = []
if (O / "interventions.json").exists():
    raw = json.loads((O / "interventions.json").read_text())
    for name, s in scenarios.items():
        for k, delta in s["deltas"].items():
            got = raw[name]["after"][k] - raw[name]["before"][k]
            scenario_results.append(
                {
                    "scenario": name,
                    "claim": k,
                    "expected_delta": delta,
                    "actual_delta": got,
                    "error": got - delta,
                    "pass": abs(got - delta) < 0.005,
                }
            )
struct = {
    "105_joint_accounts": len(tb) == 105 and len(seen) == 105,
    "no_CFO_reserved_sheets": not any(
        re.match(r"^#(?:1|2|2a|3)\)", s) for s in w.sheetnames
    ),
    "Tab0": w.sheetnames[0] == "Table of Contents",
    "original_template_order": all(
        a == b or (i in [1, 3])
        for i, (a, b) in enumerate(
            zip(
                w.sheetnames,
                openpyxl.load_workbook(P / "Aurisic_Financials_3-25-1.xlsx").sheetnames,
            )
        )
    ),
    "external_links_absent": not bool(w._external_links),
    "payroll_numeric_overlap": not overlap,
    "corporate_instruction_preserved": "need to reallocate"
    in w["#14) Payroll Accrual #2200"]["E18"].value,
    "unavailable_not_zero": all(v == "Unavailable" for v in unavailable.values()),
}
report = {
    "target": "Aurisic_Financials_4-25-1.xlsx",
    "consumer": "Shared artifact-tool native Windows; Excel application not certified",
    "scalar_checks": details,
    "ledger_checks": ledgerchecks,
    "source_observation_checks": sourcechecks,
    "structure_checks": struct,
    "intervention_checks": scenario_results,
    "source_errors_retained": ["Source PPD1250!P50 #REF!", "Source PPD1250!S50 #REF!"],
    "limitations": [
        "No independent bank statement or detailed AP support.",
        "No CFO approval or external financial sign-off.",
        "Source coverage, allocation and posting-history questions remain open in CFO Review.",
        "This is a separately implemented calculation check, not a second-person review; no delegation used.",
    ],
}
ok = (
    all(x["pass"] for x in details + sourcechecks + scenario_results)
    and all(struct.values())
    and all(
        x["period_error"] == 0
        and x["ytd_error"] == 0
        and x["name_ok"]
        and x["class_ok"]
        for x in ledgerchecks
    )
)
report["pass_with_disclosed_company_evidence_gaps"] = ok
(O / "validation.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
print("Scalar checks", len(details), "failed", [x for x in details if not x["pass"]])
print("Structure", struct)
print("Source comparisons", sourcechecks)
print(
    "Scenarios",
    len(scenario_results),
    "failed",
    [x for x in scenario_results if not x["pass"]],
)
print("RESULT", ok)
if not ok:
    raise SystemExit(1)
