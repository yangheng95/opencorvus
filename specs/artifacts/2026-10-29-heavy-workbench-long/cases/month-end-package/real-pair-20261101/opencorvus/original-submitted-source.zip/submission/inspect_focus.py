from pathlib import Path
import openpyxl

P = Path(__file__).resolve().parent.parent / "public"
for f in [
    "PPD1250-1.xlsx",
    "PPD1251-1.xlsx",
    "Aurisic_Prepaid_Expenses_4-25-1.xlsx",
    "Prof_Fee_Dump-1.xlsx",
    "Rebates-1.xlsx",
]:
    w = openpyxl.load_workbook(P / f)
    d = openpyxl.load_workbook(P / f, data_only=True)
    print("\nFILE", f)
    for s in w:
        print("SHEET", s.title)
        for row in s:
            vs = []
            for c in row:
                if c.value is not None and (
                    c.column <= 3
                    or c.column
                    >= (70 if "1250" in s.title else 40 if "1251" in s.title else 1)
                ):
                    vs.append(
                        f"{c.coordinate}: {c.value}"
                        + (
                            f" [cache {d[s.title][c.coordinate].value}]"
                            if c.data_type == "f"
                            else ""
                        )
                    )
            if vs:
                print(" | ".join(vs))
