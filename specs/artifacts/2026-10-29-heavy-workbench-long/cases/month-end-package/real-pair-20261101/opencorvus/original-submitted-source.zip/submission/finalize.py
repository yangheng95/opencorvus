"""Preserve openpyxl layout/formulas while installing actual shared-engine caches.

Only the cached result node and result type of formula cells are transferred.
This is not a Python financial recalculation or replacement with expected values.
"""

from pathlib import Path
from copy import deepcopy
import zipfile, json
import xml.etree.ElementTree as ET
import openpyxl

O = Path(__file__).resolve().parent
N = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
tag = lambda x: "{" + N["m"] + "}" + x
original = O / "Aurisic_Financials_4-25-1.xlsx"
engine = O / "engine_recalculated.xlsx"
target = O / "final_with_caches.xlsx"
updates = []
with (
    zipfile.ZipFile(original) as src,
    zipfile.ZipFile(engine) as calc,
    zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as dest,
):
    for entry in src.infolist():
        data = src.read(entry.filename)
        if entry.filename.startswith("xl/worksheets/sheet") and entry.filename.endswith(
            ".xml"
        ):
            tree = ET.fromstring(data)
            ct = ET.fromstring(calc.read(entry.filename))
            cells = {
                c.attrib["r"]: c for c in ct.findall(".//m:sheetData/m:row/m:c", N)
            }
            count = 0
            for c in tree.findall(".//m:sheetData/m:row/m:c", N):
                if c.find(tag("f")) is None:
                    continue
                other = cells.get(c.attrib["r"])
                if other is None:
                    raise ValueError(
                        ("Engine omitted formula", entry.filename, c.attrib["r"])
                    )
                for old in list(c):
                    if old.tag in [tag("v"), tag("is")]:
                        c.remove(old)
                for element in list(other):
                    if element.tag in [tag("v"), tag("is")]:
                        c.append(deepcopy(element))
                if "t" in other.attrib:
                    c.attrib["t"] = other.attrib["t"]
                else:
                    c.attrib.pop("t", None)
                count += 1
            updates.append(
                {"worksheet_xml": entry.filename, "formula_caches_from_engine": count}
            )
            data = ET.tostring(tree, encoding="utf-8", xml_declaration=True)
        dest.writestr(entry, data)
# Consume the exact candidate before replacing the final entry point.
base = openpyxl.load_workbook(original, data_only=False)
candidate = openpyxl.load_workbook(target, data_only=False)
assert base.sheetnames == candidate.sheetnames
for s in base:
    for rr in s:
        for c in rr:
            assert c.value == candidate[s.title][c.coordinate].value, (
                s.title,
                c.coordinate,
            )
            assert c.number_format == candidate[s.title][c.coordinate].number_format
            assert c.style_id == candidate[s.title][c.coordinate].style_id
target.replace(original)
cached = openpyxl.load_workbook(original, data_only=True)
claims = json.loads((O / "claims.json").read_text())
scalars = json.loads((O / "recalculated_claims.json").read_text())
bad = []
for c in scalars:
    expected = c["value"][0][0]
    got = cached[c["Sheet"]][c["Address"]].value
    if isinstance(expected, (int, float)):
        if not isinstance(got, (int, float)) or abs(got - expected) > 1e-7:
            bad.append([c["Claim"], got, expected])
    elif got != expected:
        bad.append([c["Claim"], got, expected])
report = {
    "method": "Transfer actual formula cache nodes only from shared-engine export; source equations, styles, names and order unchanged.",
    "transfers": updates,
    "saved_reopened_scalar_count": len(scalars),
    "cache_mismatches": bad,
    "engine_errors": [
        {"sheet": s.title, "cell": c.coordinate, "error": c.value}
        for s in cached
        for rr in s
        for c in rr
        if c.data_type == "e"
    ],
}
(O / "saved_reopened.json").write_text(json.dumps(report, indent=2))
assert not bad, bad
print(
    "Final saved/reopened caches verified:",
    len(scalars),
    "scalars; only original PPD legacy errors retained.",
)

# Every included sheet has a real rendering. Financial detail and long registers paginate.
plan = []
for i, s in enumerate(base):
    if s.title.startswith(("Source", "Version")):
        if "PPD1250" in s.title or s.title == "Version PPD Expenses":
            ranges = ["A1:BZ28", "A29:BZ55"]
        elif "PPD1251" in s.title or s.title == "Version Insurance":
            ranges = ["A1:AV20", "A21:AV35"]
        elif s.title == "Source Fees":
            ranges = ["A1:M10", "N1:X10"]
        elif s.title == "Source Legal":
            ranges = ["A1:N25", "A26:N47", "A48:N63"]
        else:
            ranges = [f"A1:F{s.max_row}"]
    elif s.title.startswith("#11a"):
        ranges = ["A1:M20", "A21:J47", "A48:J74"]
    elif s.title.startswith("#11b"):
        ranges = ["A1:M24"]
    else:
        n = {
            "Table of Contents": 4,
            "#3a) TB convert 4-30-25": 7,
            "#10) Legal Audit Expense #6200": 9,
            "#6) Aurisic Funding Sources": 8,
            "#7) PPD Exps #1250 (2025)": 8,
            "#8) PPD Ins #1251 (2025)": 8,
            "Period Bridges": 9,
            "CFO Review": 6,
            "Audit Index": 6,
            "#14) Payroll Accrual #2200": 6,
        }.get(s.title, 6)
        last = max(c.row for rr in s for c in rr if c.value is not None)
        last = max([last] + [r.max_row for r in s.merged_cells.ranges])
        chunks = (
            14
            if s.title == "CFO Review"
            else 24
            if s.title in ["Period Bridges", "Audit Index"]
            else 30
        )
        ranges = [
            f"A{start}:{openpyxl.utils.get_column_letter(n)}{min(last, start + chunks - 1)}"
            for start in range(1, last + 1, chunks)
        ]
    for j, r in enumerate(ranges, 1):
        plan.append({"sheet": s.title, "range": r, "file": f"{i:02d}_{j:02d}.png"})
(O / "render_plan.json").write_text(json.dumps(plan, indent=2))
