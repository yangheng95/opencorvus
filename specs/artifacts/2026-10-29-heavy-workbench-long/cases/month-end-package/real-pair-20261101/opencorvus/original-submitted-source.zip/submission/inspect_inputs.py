from pathlib import Path
import openpyxl, json

ROOT = Path(__file__).resolve().parent.parent
out = []
for p in sorted((ROOT / "public").glob("*.xlsx")):
    w = openpyxl.load_workbook(p, data_only=False)
    d = openpyxl.load_workbook(p, data_only=True)
    out.append("\nFILE " + p.name)
    for s in w:
        out.append(f"SHEET {s.title} {s.max_row}x{s.max_column}")
        for row in s:
            vals = []
            for c in row:
                if c.value is not None:
                    v = str(c.value)
                    if c.data_type == "f":
                        v += " [cached " + str(d[s.title][c.coordinate].value) + "]"
                    vals.append(c.coordinate + "=" + v)
            if vals:
                out.append(" | ".join(vals))
(ROOT / "submission" / "input_inspection.txt").write_text(
    "\n".join(out), encoding="utf-8"
)
print("\n".join(x for x in out if x.startswith(("FILE", "SHEET"))))
