"""Repeatable presentation corrections observed from actual engine PNG renders."""

from math import ceil
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter as L


def polish(w):
    for sh in w:
        if sh.title.startswith("#11"):
            notes = [
                str(sh.cell(r, 10).value)
                for r in range(2, 8)
                if sh.cell(r, 10).value is not None
            ]
            for r in range(2, 8):
                sh.cell(r, 10).value = None
            sh.merge_cells("J2:M7")
            sh["J2"] = "\n".join(notes)
            sh["J2"].alignment = Alignment(wrap_text=True, vertical="top")
            sh["J2"].font = Font(name="Aptos", size=10, color="17365D")
            sh["J2"].fill = PatternFill("solid", fgColor="FFF2CC")
            for r in range(2, 8):
                sh.row_dimensions[r].height = max(sh.row_dimensions[r].height or 15, 30)
        if sh.title == "CFO Review":
            widths = [24, 34, 62, 55, 64, 30]
            for c, width in enumerate(widths, 1):
                sh.column_dimensions[L(c)].width = width
            for r in range(5, sh.max_row + 1):
                lines = max(
                    ceil(len(str(sh.cell(r, c).value or "")) / (widths[c - 1] * 0.95))
                    for c in range(1, 7)
                )
                sh.row_dimensions[r].height = max(66, lines * 13 + 12)
        if not sh.title.startswith(("Source", "Version")):
            last = max(c.row for rr in sh for c in rr if c.value is not None)
            last = max([last] + [r.max_row for r in sh.merged_cells.ranges])
            for key in list(sh._cells):
                if key[0] > last:
                    del sh._cells[key]
            for key in list(sh.row_dimensions):
                if key > last:
                    del sh.row_dimensions[key]
            for rr in sh:
                for c in rr:
                    if c.data_type == "f" or isinstance(c.value, (int, float)):
                        c.alignment = Alignment(
                            horizontal="right", vertical="top", wrap_text=True, indent=1
                        )
            sh.print_area = f"A1:{L(min(sh.max_column, 13 if sh.title.startswith('#11') else 9))}{last}"
    return w
