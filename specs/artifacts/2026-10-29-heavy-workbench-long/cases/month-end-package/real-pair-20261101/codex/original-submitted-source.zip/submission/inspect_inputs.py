from pathlib import Path
import openpyxl,json,datetime
ROOT=Path(__file__).resolve().parent.parent
out={}
for p in sorted((ROOT/'public').glob('*.xlsx')):
 wbf=openpyxl.load_workbook(p,data_only=False); wbv=openpyxl.load_workbook(p,data_only=True)
 out[p.name]={}
 for ws in wbf:
  vals=wbv[ws.title]
  rows=[]
  for row in ws:
   cells=[]
   for c in row:
    if c.value is not None:
     cells.append({'cell':c.coordinate,'value':c.value,'cached':vals[c.coordinate].value,'format':c.number_format})
   if cells: rows.append(cells)
  out[p.name][ws.title]={'dimensions':ws.calculate_dimension(),'merged':list(map(str,ws.merged_cells.ranges)),'print_area':str(ws.print_area),'rows':rows}
 (ROOT/'submission'/'inputs_inspected.json').write_text(json.dumps(out,default=str,indent=2),encoding='utf-8')
for fn,sheets in out.items():
 print(fn)
 for name,d in sheets.items():print(' ',name,d['dimensions'],len(d['rows']),'rows')
