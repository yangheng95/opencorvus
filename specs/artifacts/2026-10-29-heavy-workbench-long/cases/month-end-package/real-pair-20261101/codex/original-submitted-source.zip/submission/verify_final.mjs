import fs from 'node:fs/promises';
import path from 'node:path';
import {createRequire} from 'node:module';
import {pathToFileURL,fileURLToPath} from 'node:url';
const require=createRequire(import.meta.url);
const {FileBlob,SpreadsheetFile}=await import(pathToFileURL(require.resolve('@oai/artifact-tool',{paths:['C:/Users/hengu/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules']})).href);
const root=path.dirname(fileURLToPath(import.meta.url));
const baseline=JSON.parse(await fs.readFile(path.join(root,'evidence','recalculated_claims.json'),'utf8'));
const wb=await SpreadsheetFile.importXlsx(await FileBlob.load(path.join(root,'Aurisic_Financials_4-25-1.xlsx')));
await wb.recalculate();
const checks=[];
for(const [claim,p] of Object.entries(baseline)){
 const value=wb.worksheets.getItem(p.sheet).getRange(p.address).values[0][0];
 const verified=typeof value==='number'&&typeof p.value==='number'?Math.abs(value-p.value)<1e-7:value===p.value;
 checks.push({claim,final_reopened_recalculated:value,prior_live:p.value,verified});
}
await fs.writeFile(path.join(root,'evidence','final_runtime_reopen.json'),JSON.stringify(checks,null,2));
if(checks.filter(x=>x.verified).length!==checks.length)throw Error('Final saved/reopened live calculation discrepancy');
console.log(`Final saved file reimported and recalculated: ${checks.length} scalar claims verified.`);
