import fs from 'node:fs/promises';
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';
const require=createRequire(import.meta.url);
const {FileBlob,SpreadsheetFile}=await import(pathToFileURL(require.resolve('@oai/artifact-tool',{paths:['C:/Users/hengu/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules']})).href);
const wb=await SpreadsheetFile.importXlsx(await FileBlob.load('public/Aurisic_Financials_3-25-1.xlsx'));
await fs.writeFile('submission/evidence/runtime_help.txt',wb.help('workbook.render',{include:'index,examples,notes',maxChars:7000}).ndjson);
console.log((await wb.inspect({kind:'sheet',include:'id,name',maxChars:3000})).ndjson);
