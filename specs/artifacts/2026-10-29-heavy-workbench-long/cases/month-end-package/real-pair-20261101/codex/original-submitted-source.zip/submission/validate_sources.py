from pathlib import Path
import openpyxl,json,re,math,datetime
from simple_source_calc import SimpleCalc
ROOT=Path(__file__).resolve().parent.parent;P=ROOT/'public';O=ROOT/'submission'
wb=openpyxl.load_workbook(O/'Aurisic_Financials_4-25-1.xlsx',data_only=False)
claims=json.loads((O/'claims.json').read_text());actual=json.loads((O/'evidence'/'recalculated_claims.json').read_text())
source={};calc={}
for fn in [p.name for p in P.glob('*.xlsx')]:
 source[fn]=openpyxl.load_workbook(P/fn,data_only=False);calc[fn]=SimpleCalc(source[fn])
def v(fn,cell,index=0):return calc[fn].value(source[fn].worksheets[index].title,cell)
ledger=[]
pat=re.compile(r'^(\d{4})-(\d{4})\s+(.+?)\s+([\d,]+\.\d{2}-?)\s+([\d,]+\.\d{2}-?)\s+([a-z])\s*$',re.M)
def signed(x):return -float(x[:-1]) if x.endswith('-') else float(x)
for m in pat.finditer((P/'Aurisic_Final_TB_4-25-1.txt').read_text()):ledger.append([int(m[1]),int(m[2]),m[3].strip(),signed(m[4]),signed(m[5]),m[6]])
gl={(r[0],r[1]):r for r in ledger}
def y(acct,div=10):return gl[div,acct][4]
def p(acct,div=10):return gl[div,acct][3]
expected={}
for period,idx in [('period',3),('ytd',4)]:
 expected['tb.net.'+period]=sum(r[idx] for r in ledger if r[5] in 'ie')
 expected['tb.clearing.'+period]=sum(r[idx] for r in ledger if r[5]=='c')
 expected['tb.proof.'+period]=sum(r[idx] for r in ledger)
expected.update({'cash.borrowing':-y(2600),'cash.intercompany':sum(y(a) for a in [1651,1652,1653,1654,1656,1663,1664]),'cash.balance':y(1023)+y(1024)})
expected['cash.unused']=expected['cash.borrowing']-expected['cash.intercompany'];expected['cash.excess']=expected['cash.balance']-expected['cash.unused']
expected.update({'bank.checks':v('Outstanding_CKs_4-30-25-1.xlsx','B7')+v('Outstanding_CKs_4-30-25-1.xlsx','B8'),'bank.book':y(1023)+y(1024)})
expected['bank.reclass']=expected['bank.checks']
expected.update({'funding.funding':-y(7206),'funding.intercompany':-y(7075),'funding.bank_other':-y(7076)-y(7092)})
expected['funding.total']=sum(expected['funding.'+k] for k in ['funding','intercompany','bank_other'])
for k in ['funding','intercompany','bank_other','total']:expected['funding.'+k+'_average']=expected['funding.'+k]/4
for name,fn,col,start,end,acct in [('expense','PPD1250-1.xlsx','BX',8,45,1250),('insurance','PPD1251-1.xlsx','AT',6,31,1251)]:
 total=0;ws=source[fn].active
 for r in range(start,end+1):
  if ws[f'{col}{r}'].value is not None:
   value=v(fn,f'{col}{r}');expected[f'prepaid.{name}.vendor.{r}']=value;total+=value
 expected[f'prepaid.{name}.total']=total;expected[f'prepaid.{name}.gl']=y(acct);expected[f'prepaid.{name}.gap']=y(acct)-total
expected['prepaid.expense.amortization25']=v('PPD1250-1.xlsx','BV25')/6
expected['fees.balance']=v('Prof_Fee_Dump-1.xlsx','W3')+sum(v('Prof_Fee_Dump-1.xlsx',f'{c}{r}') for r in range(4,9) for c in ['V','W'])
expected['legal.total']=sum(v('Legal_Dump-1.xlsx',f'{c}{r}') for r in range(3,60) for c in ['L','M'])
expected['legal.gl']=y(6200);expected['legal.gap']=y(6200)-expected['legal.total']
expected['legal.april']=sum(v('Legal_Dump-1.xlsx',f'{c}{r}') for r in range(3,60) for c in ['L','M'] if source['Legal_Dump-1.xlsx'].active[f'D{r}'].value==425)
for n,fn,end in [(1,'Good Insurance Co - Loan.xlsx',74),(2,'Good Insurance Co - Loan II.xlsx',24)]:
 for suffix,col in [('principal','G'),('charge','E'),('interest','F')]:expected[f'loan{n}.{suffix}']=v(fn,f'{col}{end}')
expected.update({'loans.principal':expected['loan1.principal']+expected['loan2.principal'],'loans.principal_gl':-y(2600)-y(2601),'loans.interest':expected['loan1.interest']+expected['loan2.interest'],'loans.interest_gl':-y(2402)})
expected['loans.principal_gap']=expected['loans.principal_gl']-expected['loans.principal'];expected['loans.interest_gap']=expected['loans.interest_gl']-expected['loans.interest']
expected.update({'ap.control':-y(2000),'ar.source':v('AR_Accrual-1.xlsx','B6'),'ar.division10':y(1101),'ar.division12':y(1101,12),'ar.gap':y(1101)-v('AR_Accrual-1.xlsx','B6')})
fn='Payroll-1.xlsx'
expected.update({'payroll.first':sum(v(fn,f'C{r}') for r in range(5,21)),'payroll.second':sum(v(fn,f'D{r}') for r in range(5,21)),'payroll.estimate':sum(v(fn,f'C{r}') for r in [6,7,10,16,17])*1.3})
march=source['Aurisic_Financials_3-25-1.xlsx'].worksheets[1]
opening=-next(row[4].value for row in march if row[0].value==10 and row[1].value==2200)
postings=sum(v(fn,f'C{r}') for r in [25,28,32])
expected.update({'payroll.opening':opening,'payroll.postings':postings,'payroll.rollforward':opening-postings,'payroll.gl':-y(2200),'payroll.gap':-y(2200)-(opening-postings)})
expected['payroll.salary']=sum(v(fn,cell) for cell in ['C6','D6','C26','C29','C33']);expected['payroll.salary_gl']=p(6000);expected['payroll.salary_gap']=p(6000)-expected['payroll.salary']
expected['payroll.expenses']=v(fn,'C18')+v(fn,'D18');expected['payroll.expenses_gl']=p(6305);expected['payroll.expenses_gap']=p(6305)-expected['payroll.expenses']
for prefix,fn,cell,acct in [('rebates','Rebates-1.xlsx','B11',2005),('uninvoiced','Accr2011-1.xlsx','B7',2011),('bonus','AccrBonus-1.xlsx','B13',2401),('misc','AccrMisc-1.xlsx','C10',2410)]:
 expected[prefix+'.total']=v(fn,cell);expected[prefix+'.gl']=-y(acct);expected[prefix+'.gap']=(v(fn,cell)+y(acct)) if prefix=='rebates' else (-y(acct)-v(fn,cell))
expected.update({'bonus.headline':v('AccrBonus-1.xlsx','B13'),'bonus.salary_ytd':y(6000),'bonus.ten_percent_reference':y(6000)*.1,'bonus.source_salary':v('AccrBonus-1.xlsx','B18'),'bonus.source_reported':v('AccrBonus-1.xlsx','B15')})
expected.update({'input.cash1024':y(1024),'input.bonus':v('AccrBonus-1.xlsx','B12'),'input.prepaid_addition':v('PPD1250-1.xlsx','BV25'),'input.fees':v('Prof_Fee_Dump-1.xlsx','V8'),'input.check':v('Outstanding_CKs_4-30-25-1.xlsx','B7'),'input.loan1_rate':v('Good Insurance Co - Loan.xlsx','A74')})
results=[]
for claim,value in expected.items():
 a=actual[claim]['value'];err=a-value if isinstance(a,(int,float)) else None
 results.append({'claim':claim,'expected_from_original_sources':value,'actual_recalculated':a,'signed_error':err,'absolute_error':abs(err) if err is not None else None,'status':'verified' if err is not None and abs(err)<1e-6 else 'review'})
# Every ledger account retains its own exact original cents and identity.
ledger_errors=[];s=wb['#3a) TB convert 4-30-25']
for i,row in enumerate(ledger,2):
 a=[s.cell(i,c).value for c in range(1,7)]
 ledger_errors.append({'division':row[0],'account':row[1],'source_name':row[2],'actual_name':a[2],'period_error':a[3]-row[3],'ytd_error':a[4]-row[4],'identity_verified':a[:3]==row[:3] and a[5]==row[5]})
# Source input tables are audited against originals, excluding only formulas/errors/blanks as declared.
tables={'source.legal':('Legal_Dump-1.xlsx',3,59,13),'source.fees':('Prof_Fee_Dump-1.xlsx',3,8,23),'source.loan1':('Good Insurance Co - Loan.xlsx',11,74,5),'source.loan2':('Good Insurance Co - Loan II.xlsx',11,24,5),'source.payroll':('Payroll-1.xlsx',5,20,4),'source.checks':('Outstanding_CKs_4-30-25-1.xlsx',7,8,5),'source.prepaid_expense':('PPD1250-1.xlsx',8,45,82),'source.prepaid_insurance':('PPD1251-1.xlsx',6,31,48)}
source_results=[]
for claim,(fn,start,end,n) in tables.items():
 locator=next(c for c in claims if c[0]==claim);mapping=json.loads(locator[4]);dest=wb[locator[1]];checks=[]
 for rr in range(start,end+1):
  for cc in range(1,n+1):
   original=source[fn].active.cell(rr,cc)
   if original.value is not None and original.data_type not in ['f','e']:
    actual_input=dest[f'{mapping[openpyxl.utils.get_column_letter(cc)]}{rr}'].value
    checks.append({'source_cell':original.coordinate,'actual_cell':f'{mapping[openpyxl.utils.get_column_letter(cc)]}{rr}','verified':actual_input==original.value})
 source_results.append({'claim':claim,'source':fn,'checked_original_inputs':len(checks),'checks':checks})
changes=json.loads((O/'evidence'/'input_change_results.json').read_text())
delta_rules={'input.cash1024':{'cash.balance':1,'cash.excess':1,'bank.book':1},'input.bonus':{'bonus.total':100,'bonus.headline':100,'bonus.gap':-100},'input.prepaid_addition':{'prepaid.expense.amortization25':1,'prepaid.expense.vendor.25':5,'prepaid.expense.total':5,'prepaid.expense.gap':-5},'input.fees':{'fees.balance':1},'input.check':{'bank.checks':1,'bank.reclass':1},'input.loan1_rate':{'loan1.charge':-18300000*.01/365*30,'loan1.interest':-18300000*.01/365*30,'loans.interest':-18300000*.01/365*30,'loans.interest_gap':18300000*.01/365*30}}
interventions=[]
for t in changes:
 for claim,expected_delta in delta_rules[t['input']].items():
  got=t['results'][claim]['value']-actual[claim]['value'];interventions.append({'input':t['input'],'dependent_claim':claim,'expected_delta_from_source_equation':expected_delta,'actual_delta':got,'signed_error':got-expected_delta,'status':'verified' if abs(got-expected_delta)<1e-6 else 'review'})
report={'scalar_results':results,'ledger_account_results':ledger_errors,'source_input_tables':source_results,'legal_input_change_results':interventions,'limits':['Source company evidence gaps remain CFO review items. Original prepaid legacy P50/S50 #REF! errors preserved.','Independent source arithmetic uses a deliberately limited SUM/numeric evaluator; declared Artifact Tool recalculates actual submitted formulas.','No native Microsoft Excel application certification or financial approval claimed.']}
(O/'evidence'/'source_validation.json').write_text(json.dumps(report,indent=2,default=str),encoding='utf-8')
bad=[r for r in results+interventions if r['status']=='review']
print('Source-backed scalar comparisons:',len(results),'review items:',len(bad));print('Ledger accounts:',len(ledger_errors));print('Preserved original table inputs:',sum(t['checked_original_inputs'] for t in source_results));print('Input change dependency checks:',len(interventions))
assert len([r for r in results if r['status']=='verified'])==len(results)
assert all(r['identity_verified'] and r['period_error']==0 and r['ytd_error']==0 for r in ledger_errors)
assert all(c['verified'] for t in source_results for c in t['checks'])
assert len([r for r in interventions if r['status']=='verified'])==len(interventions)
print('All positive source/recalculation contracts verified.')
