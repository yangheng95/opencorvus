import json
from pathlib import Path
D=json.loads(Path('submission/inputs_inspected.json').read_text(encoding='utf-8'))
for fn,ss in D.items():
 if fn in ['PPD1250-1.xlsx','PPD1251-1.xlsx','Aurisic_Prepaid_Expenses_4-25-1.xlsx']:continue
 print('\n###',fn)
 for sn,d in ss.items():
  print('SHEET',sn)
  for row in d['rows']:
   if fn.startswith('Aurisic_Financials') and sn.startswith(('#7)', '#8)', '#10)')):
    cs=[c for c in row if c['cell'].rstrip('0123456789') in ['A','B','C','D','E','F','G','H']]
   else:cs=row
   print(' | '.join(c['cell']+'='+str(c['value'])+((' [cache '+str(c['cached'])+']') if str(c['value']).startswith('=') else '') for c in cs))
