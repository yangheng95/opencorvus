from PIL import Image,ImageOps,ImageDraw
from pathlib import Path
import json,math
O=Path('submission');plan=json.loads((O/'render_plan.json').read_text())
for start in range(0,len(plan),6):
 subset=plan[start:start+6];canvas=Image.new('RGB',(1900,1500),'#DCE3EA');draw=ImageDraw.Draw(canvas)
 for i,p in enumerate(subset):
  img=Image.open(O/'evidence'/'renders'/(p['tag']+'.png')).convert('RGB');img.thumbnail((930,455))
  x=(i%2)*950;y=(i//2)*500;draw.text((x+10,y+8),p['tag']+' | '+p['sheet'],fill='black')
  canvas.paste(img,(x+10,y+35))
 canvas.save(O/'evidence'/f'contact_{start//6+1:02d}.png')
print(f'Created{math.ceil(len(plan)/6)} review contact sheets for{len(plan)} actual rendered panels')
