import json
from pathlib import Path
D=json.loads(Path('submission/inputs_inspected.json').read_text(encoding='utf-8'))
for fn in ['PPD1250-1.xlsx','PPD1251-1.xlsx','Aurisic_Prepaid_Expenses_4-25-1.xlsx']:
 print('\n###',fn)
 for sn,d in D[fn].items():
  print(sn)
  for row in d['rows']:
   cs=[c for c in row if int(''.join(filter(str.isdigit,c['cell'])))<8 or ''.join(filter(str.isalpha,c['cell'])) in ['A','B','C','D','BR','BS','BT','BU','BV','BW','BX','BY','BZ','CA','CB','CC','CD','AN','AO','AP','AQ','AR','AS','AT','AU','AV','AW']]
   print(' | '.join(c['cell']+'='+str(c['value'])+(' [cache '+str(c['cached'])+']' if str(c['value']).startswith('=') else '') for c in cs))
