import json
from pathlib import Path
D=json.loads(Path('submission/inputs_inspected.json').read_text(encoding='utf-8'))
for fn in ['Legal_Dump-1.xlsx','Outstanding_CKs_4-30-25-1.xlsx','Payroll-1.xlsx','Prof_Fee_Dump-1.xlsx','Rebates-1.xlsx']:
 print('\n',fn)
 for sn,s in D[fn].items():
  for row in s['rows']:
   cols=['A','B','C','D','E','F','G','H','I','J','K','L','M'] if fn.startswith('Legal') else None
   print(' | '.join(c['cell']+'='+str(c['value']) for c in row if cols is None or ''.join(filter(str.isalpha,c['cell'])) in cols))
for fn in ['PPD1251-1.xlsx','Aurisic_Prepaid_Expenses_4-25-1.xlsx']:
 print('\n',fn)
 for sn,s in D[fn].items():
  print(sn)
  for row in s['rows']:
   if any(int(''.join(filter(str.isdigit,c['cell'])))>=29 for c in row):
    print(' | '.join(c['cell']+'='+str(c['value'])+' [cached '+str(c['cached'])+']' for c in row if ''.join(filter(str.isalpha,c['cell'])) in ['A','B','C','AQ','AR','AS','AT','AU','AV','AW','BT','BU','BV','BW','BX','BY','BZ','CA','CB','CC','CD']))
