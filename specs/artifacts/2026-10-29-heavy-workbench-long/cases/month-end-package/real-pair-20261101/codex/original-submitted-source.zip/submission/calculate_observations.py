import json,openpyxl,re
from pathlib import Path
P=Path('public')
for fn in ['PPD1250-1.xlsx','PPD1251-1.xlsx']:
 w=openpyxl.load_workbook(P/fn,data_only=True).active
 col='BX' if fn.startswith('PPD1250') else 'AT'; start,end=(8,45) if col=='BX' else (6,31)
 print(fn,'cached vendor sum',sum(w[f'{col}{i}'].value or 0 for i in range(start,end+1)))
 if col=='AT':print('premiums',sum(w[f'AT{i}'].value or 0 for i in range(7,29)))
print('all account count',len(re.findall(r'^\d{4}-\d{4}',(P/'Aurisic_Final_TB_4-25-1.txt').read_text(),re.M)))
