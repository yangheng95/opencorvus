import fs from 'node:fs/promises';
import path from 'node:path';
import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
const require=createRequire(import.meta.url);
const {FileBlob,SpreadsheetFile}=await import(pathToFileURL(require.resolve('@oai/artifact-tool',{paths:['C:/Users/hengu/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules']})).href);
const root=path.dirname(new URL(import.meta.url).pathname).replace(/^\/([A-Za-z]:)/,'$1');
const file=path.join(root,'Aurisic_Financials_4-25-1.xlsx');
const claims=JSON.parse(await fs.readFile(path.join(root,'claims.json'),'utf8'));
const wb=await SpreadsheetFile.importXlsx(await FileBlob.load(file));
await wb.recalculate();
function snapshot(){const out={};for(const [claim,sheet,address,role] of claims){if(!address.includes(':')&&!address.includes(','))out[claim]={sheet,address,role,value:wb.worksheets.getItem(sheet).getRange(address).values[0][0]};}return out;}
const baseline=snapshot();
await fs.writeFile(path.join(root,'evidence','recalculated_claims.json'),JSON.stringify(baseline,null,2));
await (await SpreadsheetFile.exportXlsx(wb)).save(path.join(root,'evidence','artifact_recalculated.xlsx'));
const tests=[['input.cash1024',1],['input.bonus',100],['input.prepaid_addition',6],['input.fees',1],['input.check',1],['input.loan1_rate',-1]];
const changes=[];
for(const [claim,delta] of tests){
 const {sheet,address,value}=baseline[claim];const cell=wb.worksheets.getItem(sheet).getRange(address);
 cell.values=[[value+delta]];await wb.recalculate();changes.push({input:claim,delta,original:value,changed:value+delta,results:snapshot()});
 cell.values=[[value]];await wb.recalculate();
}
await fs.writeFile(path.join(root,'evidence','input_change_results.json'),JSON.stringify(changes,null,2));
await fs.writeFile(path.join(root,'evidence','post_restore_claims.json'),JSON.stringify(snapshot(),null,2));
const plan=JSON.parse(await fs.readFile(path.join(root,'render_plan.json'),'utf8'));
const wanted=process.argv.includes('--all')?plan:plan.filter(p=>['cash','prepaid_expense_top','legal_april_review','loans_controls','contents_top','issues_1'].includes(p.tag));
await fs.mkdir(path.join(root,'evidence','renders'),{recursive:true});
for(const p of wanted){try{const png=await wb.render({sheetName:p.sheet,range:p.range,scale:1.4,format:'png'});await fs.writeFile(path.join(root,'evidence','renders',p.tag+'.png'),new Uint8Array(await png.arrayBuffer()));console.log('Rendered '+p.tag);}catch(e){console.log('Render failure '+p.tag+': '+e);await fs.appendFile(path.join(root,'evidence','render_failures.log'),p.tag+': '+e+'\n');}}
await fs.writeFile(path.join(root,'evidence','runtime_inspect.ndjson'),(await wb.inspect({kind:'sheet',include:'id,name',maxChars:18000})).ndjson);
console.log('Recalculated saved workbook; completed all six legal input changes and restored originals.');
