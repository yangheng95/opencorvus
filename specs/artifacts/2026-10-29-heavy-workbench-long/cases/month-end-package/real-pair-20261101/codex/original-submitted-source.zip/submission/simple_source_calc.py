from pathlib import Path
import openpyxl,re,datetime,json,ast,operator
from openpyxl.utils.datetime import to_excel
class SimpleCalc:
 def __init__(self,wb):self.wb=wb;self.cache={};self.active=set()
 def value(self,sheet,addr):
  addr=addr.replace('$',''); key=(sheet,addr)
  if key in self.cache:return self.cache[key]
  if key in self.active:raise ValueError('Circular '+str(key))
  v=self.wb[sheet][addr].value
  if v is None:v=0
  elif isinstance(v,(datetime.datetime,datetime.date)):v=to_excel(v)
  elif isinstance(v,str) and v.startswith('='):
   self.active.add(key)
   # Source formula family is SUM plus numeric arithmetic and local references.
   f=v[1:].replace('$','').replace('^','**')
   def rr(m):
    a,b=m.group(1).split(':');return str(sum(self.value(sheet,c.coordinate) for row in self.wb[sheet][a:b] for c in row))
   f=re.sub(r'([A-Z]+\d+:[A-Z]+\d+)',rr,f)
   def sr(m):return repr(self.value(sheet,m.group(0)))
   f=re.sub(r'(?<![A-Za-z0-9_])([A-Z]+\d+)(?![A-Za-z0-9_])',sr,f)
   f=re.sub(r'(\d+(?:\.\d+)?)%',r'(\1/100)',f)
   def SUM(*a):return sum(a)
   try:v=eval(f,{'__builtins__':{}},{'SUM':SUM,'MIN':min,'MAX':max,'ROUND':round})
   finally:self.active.remove(key)
  elif isinstance(v,str):
   raise ValueError('Nonnumeric '+str(key)+' '+v)
  self.cache[key]=v;return v
if __name__=='__main__':
 report={}
 for fn,cell in [('PPD1250-1.xlsx','BX46'),('PPD1251-1.xlsx','AT32'),('Legal_Dump-1.xlsx','L63'),('Good Insurance Co - Loan.xlsx','F74'),('Good Insurance Co - Loan II.xlsx','F24')]:
  w=openpyxl.load_workbook(Path('public')/fn);c=SimpleCalc(w);s=w.active.title
  print(fn,cell,c.value(s,cell))
  if fn.startswith('Legal'):print('single count',sum(c.value(s,f'L{i}')+c.value(s,f'M{i}') for i in range(3,60)))
  diffs=[];cached=openpyxl.load_workbook(Path('public')/fn,data_only=True)
  for row in w.active:
   for x in row:
    if x.data_type=='f':
     try:
      val=c.value(s,x.coordinate);old=cached[s][x.coordinate].value
      if old is not None and isinstance(old,(float,int)) and abs(val-old)>.00001:diffs.append({'cell':x.coordinate,'original_cache':old,'recalculated':val,'difference':val-old})
     except Exception as e:diffs.append({'cell':x.coordinate,'error':str(e)})
  report[fn]=diffs
 Path('submission/evidence/source_formula_differences.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
