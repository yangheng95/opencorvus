from pathlib import Path
from copy import copy
import re,json,datetime,openpyxl
from openpyxl.styles import Font,PatternFill,Alignment
from openpyxl.utils import get_column_letter as L
from openpyxl.comments import Comment
from openpyxl.workbook.properties import CalcProperties
ROOT=Path(__file__).resolve().parent.parent; OUT=ROOT/'submission'; PUB=ROOT/'public'
NAVY='17365D'; TEAL='DDEEF0'; BLUE='1F4E78'; ORANGE='FFF0D3'; NUM='#,##0.00;[Red](#,##0.00);–'
wb=openpyxl.load_workbook(PUB/'Aurisic_Financials_3-25-1.xlsx')
original_names=wb.sheetnames[:]
wb[original_names[1]].title='#3a) TB convert 4-30-25';wb[original_names[3]].title='#5) Bank recon 4-30-25'
N=wb.sheetnames[:]; tb=N[1]; cash=N[2]; bank=N[3];fund=N[4];pe=N[5];pi=N[6];fees=N[7];legal=N[8];ln1=N[9];ln2=N[10];ap=N[11];ar=N[12];pay=N[13];reb=N[14]
claims=[];renders=[];sources={}
def add(claim,sheet,address,role='calculated',basis='',columns=None):
 claims.append([claim,sheet,address,role,json.dumps(columns or {},separators=(',',':')),basis])
def ref(sheet,cell):return "'"+sheet.replace("'","''")+"'!"+cell
def clear(ws):
 for m in list(ws.merged_cells.ranges):ws.unmerge_cells(str(m))
 ws.delete_rows(1,ws.max_row+1);ws.column_dimensions.clear();ws.row_dimensions.clear();ws.print_area=None;ws.auto_filter.ref=None
def fmt(ws,cols=None,headrows=(1,),last=None):
 ws.sheet_view.showGridLines=False;ws.sheet_properties.pageSetUpPr.fitToPage=True
 ws.page_setup.orientation='landscape';ws.page_setup.paperSize=ws.PAPERSIZE_A3
 ws.page_setup.fitToWidth=1;ws.page_setup.fitToHeight=0
 ws.page_margins.left=.25;ws.page_margins.right=.25;ws.page_margins.top=.35;ws.page_margins.bottom=.35
 ws.oddFooter.center.text='Aurisic | April 2025 | CFO review draft | Page &P of &N';ws.oddFooter.center.size=8
 for row in ws:
  for c in row:
   c.font=Font(name='Calibri',size=11,color='1F2937');c.alignment=Alignment(vertical='center')
   if isinstance(c.value,(int,float)) or c.data_type=='f':c.number_format=NUM
   if isinstance(c.value,(datetime.datetime,datetime.date)):c.number_format='m/d/yyyy'
  ws.row_dimensions[row[0].row].height=21
 for rr in headrows:
  for c in ws[rr]:
   c.fill=PatternFill('solid',fgColor=NAVY);c.font=Font(name='Calibri',bold=True,color='FFFFFF',size=11);c.alignment=Alignment(vertical='center',wrap_text=True)
  ws.row_dimensions[rr].height=30
 for col,width in (cols or {}).items():ws.column_dimensions[col].width=width
 ws.print_area=f'A1:{L(last or ws.max_column)}{ws.max_row}';ws.freeze_panes='A5';ws.sheet_properties.tabColor=BLUE
def line(ws,row,label,value,lc='A',vc='B',note=None,nc='C'):
 ws[f'{lc}{row}']=label;ws[f'{vc}{row}']=value
 for col in [lc,vc]:ws[f'{col}{row}'].fill=PatternFill('solid',fgColor=TEAL);ws[f'{col}{row}'].font=Font(name='Calibri',size=11,bold=True,color=NAVY)
 ws[f'{vc}{row}'].number_format=NUM
 if note:ws[f'{nc}{row}']=note;ws[f'{nc}{row}'].alignment=Alignment(wrap_text=True,vertical='center');ws.row_dimensions[row].height=42
def note(ws,row,text,start='A',end='F',height=48):
 ws.merge_cells(f'{start}{row}:{end}{row}');c=ws[f'{start}{row}'];c.value=text;c.alignment=Alignment(wrap_text=True,vertical='center');c.fill=PatternFill('solid',fgColor=ORANGE);c.font=Font(name='Calibri',size=11,color='7A4100');ws.row_dimensions[row].height=height
def donor(filename,target,index=0):
 srcwb=openpyxl.load_workbook(PUB/filename);src=srcwb.worksheets[index]
 ws=wb[target] if target in wb.sheetnames else wb.create_sheet(target);clear(ws)
 for row in src:
  for c in row:
   if c.value is not None or c.has_style:
    d=ws.cell(c.row,c.column,c.value)
    if c.has_style:d._style=copy(c._style)
    d.alignment=copy(c.alignment)
    if c.comment:d.comment=copy(c.comment)
 for k,d in src.column_dimensions.items():ws.column_dimensions[k]=copy(d)
 for k,d in src.row_dimensions.items():ws.row_dimensions[k]=copy(d)
 for m in src.merged_cells.ranges:ws.merge_cells(str(m))
 sources[target]=(filename,src.title);return ws
def source_table(claim,sheet,start,end,colend):
 ws=wb[sheet];n=openpyxl.utils.column_index_from_string(colend);extra=max(n,ws.max_column)+1;el=L(extra)
 ws.cell(start-1,extra,'source_row')
 for r in range(start,end+1):ws.cell(r,extra,r)
 ws.column_dimensions[el].hidden=True
 columns={'source_row':el};columns.update({L(i):L(i) for i in range(1,n+1)})
 add(claim,sheet,f'A{start}:{el}{end}','source_table',f'{sources[sheet][0]} / {sources[sheet][1]} / original rows{start}:{end}; original inputs/signs retained; formulas live.',columns)
def panel(sheet,range_,tag):renders.append({'sheet':sheet,'range':range_,'tag':tag})
# All original signed April observations, in text order.
rows=[]
pat=re.compile(r'^(\d{4})-(\d{4})\s+(.+?)\s+([\d,]+\.\d{2}-?)\s+([\d,]+\.\d{2}-?)\s+([a-z])\s*$',re.M)
def signed(x):return -float(x[:-1].replace(',','')) if x.endswith('-') else float(x.replace(',',''))
for m0 in pat.finditer((PUB/'Aurisic_Final_TB_4-25-1.txt').read_text()):rows.append([int(m0[1]),int(m0[2]),m0[3].strip(),signed(m0[4]),signed(m0[5]),m0[6]])
assert len(rows)==105
ws=wb[tb];clear(ws);ws.append(['Div #','Acct #','Account Name','April movement','April YTD','Class'])
for row in rows:ws.append(row)
ledger={(r[0],r[1]):i+2 for i,r in enumerate(rows)}
def gl(account,division=10,col='E',credit=False):return ('-' if credit else '')+ref(tb,f'{col}{ledger[division,account]}')
for rr,label,classes in [(109,'Total Balance Sheet Accounts','al'),(110,'Total Income & Expenses','ie'),(111,'Total Clearing Accounts','c'),(114,'Assets','a'),(115,'Liabilities','l'),(118,'Income','i'),(119,'Expenses','e')]:
 ws[f'C{rr}']=label
 for col in ['D','E']:ws[f'{col}{rr}']='=SUM('+','.join(f'{col}{i+2}' for i,r in enumerate(rows) if r[5] in classes)+')'
for rr,label,form in [(116,'Balance sheet proof','=D114+D115'),(120,'Income/expense proof','=D118+D119'),(122,'Full-ledger proof','=SUM(D2:D106)')]:
 ws[f'C{rr}']=label;ws[f'D{rr}']=form;ws[f'E{rr}']=form.replace('D','E')
fmt(ws,{'A':9,'B':10,'C':43,'D':20,'E':22,'F':10},(1,109,110,111,116,120,122),6)
ws.freeze_panes='D2';ws.auto_filter.ref='A1:F106';ws.print_title_rows='1:1'
for rr in range(2,107):
 for c in ['A','B']:ws[f'{c}{rr}'].number_format='0'
note(ws,124,'Source: Aurisic_Final_TB_4-25-1.txt, period0425. Debit positive / credit negative. Division/account are a joint identity. Full-ledger proof includes clearing; income/expense proof is net activity, not a zero-balance test.',end='F',height=48)
add('ledger',tb,'A2:F106','table','Original April TB;105 account observations and signed cents.',dict(division='A',account='B',name='C',period='D',ytd='E',**{'class':'F'}))
for claim,cell in [('net.period','D110'),('net.ytd','E110'),('clearing.period','D111'),('clearing.ytd','E111'),('proof.period','D122'),('proof.ytd','E122')]:add('tb.'+claim,tb,cell,basis='Original ledger class semantics; sum of all relevant accounts.')
add('input.cash1024',tb,f'E{ledger[10,1024]}','input','April TB division0010/account1024 YTD original signed input.')
panel(tb,'A1:F28','ledger_assets');panel(tb,'A91:F124','ledger_proofs')
# Cash retains original schedule definitions and row order.
ws=wb[cash];clear(ws)
for rr,text in [(1,'Aurisic Companies'),(2,'Cash availability from sources'),(3,'As of April30,2025'),(4,'Description')]:ws.cell(rr,1,text)
ws['B4']='Amount';ws['C4']='Basis'
line(ws,5,'Good Insurance Co loan balance','='+gl(2600,credit=True),note='Template borrowing scope: GL2600 only; loanII outside this definition.')
ws['A7']='Intercompany loans:'
for rr,acct in zip(range(8,15),[1651,1652,1653,1654,1656,1663,1664]):
 ws[f'A{rr}']=next(r[2] for r in rows if r[0]==10 and r[1]==acct);ws[f'B{rr}']='='+gl(acct);ws[f'C{rr}']=f'April division0010 / account{acct}'
for rr,label,f in [(15,'Total intercompany loans','=SUM(B8:B14)'),(17,'Unused Good Insurance Co funds','=B5-B15'),(19,'April ledger cash balance','='+gl(1023)+'+'+gl(1024)),(21,'Cash in excess of loan funds','=B19-B17')]:line(ws,rr,label,f)
fmt(ws,{'A':46,'B':22,'C':72},(1,4),3)
note(ws,23,'GL1656 is named Aurisic DE in April; March called it FR. April identity retained. No entity crosswalk is inferred. Cash is ledger cash; independent bank verification outstanding.',end='C',height=55)
for suf,cell in [('borrowing','B5'),('intercompany','B15'),('unused','B17'),('balance','B19'),('excess','B21')]:add('cash.'+suf,cash,cell,basis='April GL, template definitions; all seven specified intercompany notes.')
panel(cash,'A1:C23','cash')
ws=donor('Outstanding_CKs_4-30-25-1.xlsx',bank)
ws['C4']='Unavailable';ws['A4']='Independent bank statement balance';ws['C12']='Unavailable';ws['A12']='Statement less outstanding checks'
ws['C14']='=B10';ws['A14']='Proposed check reclass to AP';ws['A16']='Actual April ledger book cash';ws['C16']='='+gl(1023)+'+'+gl(1024)
ws['A18']='GL2001 credit allowance control';ws['C18']='='+gl(2001,credit=True);ws['A20']='Checks less GL2001 control';ws['C20']='=B10-C18'
ws['A22']='Independent bank-to-book reconciliation';ws['C22']='Unavailable';ws['A24']='Ledger less checks (illustration only)';ws['C24']='=C16-B10'
fmt(ws,{'A':52,'B':19,'C':23,'D':17,'E':35},(1,3),5)
ws['D7'].number_format=ws['D8'].number_format='m/d/yyyy';ws['A7'].number_format=ws['A8'].number_format='0'
note(ws,26,'C4 is not supplied. Book cash comes only from the April ledger. Check reclassification is proposed, not posted/approved. Obtain statement, cleared-check evidence and CFO approval before completing the bank reconciliation.',end='E',height=58)
source_table('source.checks',bank,7,8,'E')
for suf,cell,role in [('checks','B10','calculated'),('reclass','C14','calculated'),('book','C16','calculated'),('statement','C4','unavailable'),('reconciliation','C22','unavailable')]:add('bank.'+suf,bank,cell,role,'Outstanding_CKs_4-30-25-1.xlsx rows7:8; GL1023+1024 book control; independent statement absent.')
add('input.check',bank,'B7','input','First source check B7, positive original amount.');panel(bank,'A1:E26','bank')
# Funding aggregate actuals; subsidiary detail remains unavailable.
ws=wb[fund]
for rr in range(5,12):ws[f'G{rr}']=ws[f'D{rr}'].value;ws[f'D{rr}']='Unavailable';ws[f'E{rr}']='Unavailable'
ws['A1']='Aurisic funding sources — April2025 CFO draft';ws['D4']='April30 YTD';ws['E4']='Average /4 months';ws['G4']='March source YTD'
ws['D12']='='+gl(7206,credit=True);ws['E12']='=D12/$D$20';ws['D14']='='+gl(7075,credit=True);ws['E14']='=D14/$D$20'
ws['D15']='='+gl(7076,credit=True)+'+'+gl(7092,credit=True);ws['E15']='=D15/$D$20';ws['D17']='=SUM(D12,D14,D15)';ws['E17']='=D17/$D$20';ws['D20']=4;ws['A20']='Elapsed months in2025'
for rr,label,acct in [(22,'April shared funding',7206),(23,'April intercompany interest',7075)]:ws[f'A{rr}']=label;ws[f'D{rr}']='='+gl(acct,col='D',credit=True)
ws['A24']='April bank and other income';ws['D24']='='+gl(7076,col='D',credit=True)+'+'+gl(7092,col='D',credit=True)
fmt(ws,{'A':35,'B':18,'C':20,'D':21,'E':23,'F':62,'G':22},(1,4,12,17),7)
for rr in [5,6]:ws[f'F{rr}'].alignment=Alignment(wrap_text=True);ws.row_dimensions[rr].height=48
note(ws,26,'April subsidiary split unavailable. March labels contain Aurisic UK twice (rows5/7); March amounts/budgets do not establish April mapping. Budgets/March observations retained as historical. Aggregate April uses GL7206/7075/7076/7092. Ask CFO for mapped subsidiary detail.',end='G',height=64)
for suf,cell in [('funding','D12'),('funding_average','E12'),('intercompany','D14'),('intercompany_average','E14'),('bank_other','D15'),('bank_other_average','E15'),('total','D17'),('total_average','E17')]:add('funding.'+suf,fund,cell,basis='April GL credit income as positive funding; elapsed months D20=4; no subsidiary allocation inferred.')
panel(fund,'A1:G26','funding')
# Dedicated prepaid histories; hide historical columns for a compact April view.
ws=donor('PPD1250-1.xlsx',pe)
ws['BX49']='='+gl(1250);ws['A49']='Actual April GL1250';ws['BX50']='=BX49-BX46';ws['A50']='GL less source calculation'
fmt(ws,{'A':30,'BU':19,'BV':19,'BW':19,'BX':20,'BY':20,'BZ':58},(1,5,46,49,50),78)
for c in range(2,73):ws.column_dimensions[L(c)].hidden=True
for c in range(79,83):ws.column_dimensions[L(c)].hidden=True
for rr in range(8,46):
 ws[f'BY{rr}'].alignment=Alignment(wrap_text=True);ws[f'BZ{rr}'].alignment=Alignment(wrap_text=True);ws.row_dimensions[rr].height=34
for rr,text in [(53,'Dedicated PPD1250-1.xlsx is the calculation basis. Historical columns retained, hidden for April focus. Source calculations are not adjusted to fit the GL.'),(55,'Residual = GL less live vendor sum. Source BX48 has a0.02 variance observation; no balancing amount applied. Original historical P50/S50 #REF! errors remain as source facts.'),(57,'Terms needing approval: ZIPLINE r8 past3/25 expiry; XRP r10/r11 period vs description; r13 /9 vs description; r14/r21/r30 inclusive endpoints ambiguous.'),(59,'Resolve MORPH r17 expired1/25; PPL r22/r23 past terms and r24 /3 vs3/25–6/25; READY r31 starts4/25 but charged March; KNIGHT r32 /10 vs year; PINK r40 /8 vs4/25–12/25 and later description; TIMMY r42 /12 vs period.'),(61,'Source formulas are unapproved calculations pending vendor contracts. SIMPLE r25 April addition /6 covers4/25–9/25. No dates, denominators or policies silently changed.')]:note(ws,rr,text,start='BU',end='BZ',height=62)
ws.freeze_panes='BU8';ws.print_title_rows='1:5';ws.sheet_view.topLeftCell='BU1';ws.print_area='A1:BZ61'
source_table('source.prepaid_expense',pe,8,45,'CD')
for r in range(8,46):
 if ws[f'BX{r}'].value is not None:add(f'prepaid.expense.vendor.{r}',pe,f'BX{r}',basis=f'PPD1250-1.xlsx BX{r} live source formula; term approval not inferred.')
for suf,cell in [('total','BX46'),('gl','BX49'),('gap','BX50'),('amortization25','BW25')]:add('prepaid.expense.'+suf,pe,cell,basis='Dedicated source vs actual April GL1250; gap=GL less source, full precision retained.')
add('input.prepaid_addition',pe,'BV25','input','PPD1250-1.xlsx BV25 SIMPLE original April addition.')
panel(pe,'A1:BZ26','prepaid_expense_top');panel(pe,'A27:BZ61','prepaid_expense_bottom')
ws=donor('PPD1251-1.xlsx',pi)
ws['AT35']='='+gl(1251);ws['B35']='Actual April GL1251';ws['B36']='GL less source calculation';ws['AT36']='=AT35-AT32'
fmt(ws,{'A':13,'B':31,'C':18,'AQ':18,'AR':18,'AS':19,'AT':20,'AU':48,'AV':12},(1,5,32,35,36),48)
for c in range(4,43):ws.column_dimensions[L(c)].hidden=True
for rr in range(6,32):ws[f'AU{rr}'].alignment=Alignment(wrap_text=True);ws.row_dimensions[rr].height=27
note(ws,39,'Dedicated source closes at$5,493.27 versus GL$54,630.68; $49,137.41 remains unresolved. Source premiums less cumulative amortization leave zero premium balance. Obtain policy and amortization posting support.',start='AQ',end='AV',height=60)
note(ws,41,'Combined insurance source ends March31,2025 at$49,137.41 despite the file name. It is an earlier-period observation. TMMR r30 says March coverage in April columns; CFO must confirm cutoff.',start='AQ',end='AV',height=60)
ws.freeze_panes='AQ6';ws.sheet_view.topLeftCell='AQ1';ws.print_title_rows='1:5';ws.print_area='A1:AV41'
source_table('source.prepaid_insurance',pi,6,31,'AV')
for r in range(6,32):
 if ws[f'AT{r}'].value is not None:add(f'prepaid.insurance.vendor.{r}',pi,f'AT{r}',basis=f'PPD1251-1.xlsx AT{r} live source formula.')
for suf,cell in [('total','AT32'),('gl','AT35'),('gap','AT36')]:add('prepaid.insurance.'+suf,pi,cell,basis='Dedicated PPD1251-1.xlsx versus actual April GL1251; gap=GL less source.')
panel(pi,'A1:AV22','prepaid_insurance_top');panel(pi,'A23:AV41','prepaid_insurance_bottom')
ws=donor('Prof_Fee_Dump-1.xlsx',fees)
fmt(ws,{'C':17,'D':13,'S':52,'V':22,'W':23},(1,2,10),23)
for i in [1,2]+list(range(5,19))+[20,21]:ws.column_dimensions[L(i)].hidden=True
ws['S13']='April GL2404 signed balance';ws['W13']='='+gl(2404);ws['S14']='GL less signed source rollforward';ws['W14']='=W13-W10'
note(ws,17,'Opening credit plus signed debit/credit transactions. April V8 is reversal journal1740 for March1739, not a new estimate. Source closing agrees to April GL2404. No journal posted by this workbook.',start='S',end='W',height=60)
source_table('source.fees',fees,3,8,'W');add('fees.balance',fees,'W10',basis='Prof_Fee_Dump-1.xlsx openingW3 and signed transactionsV4:W8 counted once.')
add('input.fees',fees,'V8','input','Prof_Fee_Dump-1.xlsx V8 April reversal debit for journal1740.');panel(fees,'A1:W17','fees')
ws=donor('Legal_Dump-1.xlsx',legal)
ws['L62']='=SUM(L3:L59)';ws['M62']='=SUM(M3:M59)';ws['L63']='=L62+M62';ws['K63']='Current signed source YTD total'
for rr in range(3,60):ws[f'N{rr}']=f'=L{rr}+M{rr}'
ws['N2']='Signed amount'
fmt(ws,{'C':17,'D':11,'G':38,'K':42,'L':20,'M':20,'N':22},(1,2,60,63),14)
for i in [1,2,5,6,8,9,10]:ws.column_dimensions[L(i)].hidden=True
for rr in range(3,60):ws[f'G{rr}'].alignment=Alignment(wrap_text=True);ws[f'K{rr}'].alignment=Alignment(wrap_text=True);ws.row_dimensions[rr].height=29
for rr,label,f in [(66,'April GL6200 YTD','='+gl(6200)),(67,'GL less single-count source','=L66-L63'),(68,'April period425 signed source','=SUM('+','.join(f'N{r}' for r in range(3,60) if ws[f'D{r}'].value==425)+')'),(69,'April GL6200 movement','='+gl(6200,col='D')),(70,'April GL less source','=L69-L68'),(71,'Original displayed total — observation',870569.38)]:ws[f'G{rr}']=label;ws[f'L{rr}']=f
note(ws,73,'Formula correction: original L62/M62 included subtotal row60 again, doubling signed activity to$870,569.38. Current L63 counts transaction rows3:59 once; reversal credits stay negative. Period425 is distinct from YTD.',start='G',end='N',height=60)
note(ws,75,'March source credits: rows55/56, journals1761/1762, “amort Apr-Jun,” $(28,000)/$(56,000). These support the$84,000 bridge to March GL. Posting history and cutoff approval remain requested, not established by matching amounts.',start='G',end='N',height=60)
source_table('source.legal',legal,3,59,'M')
for suf,cell in [('total','L63'),('gl','L66'),('gap','L67'),('april','L68')]:add('legal.'+suf,legal,cell,basis='Legal_Dump-1.xlsx signed rows3:59 once; period425 isolated; actual April GL6200.')
panel(legal,'A1:N22','legal_top');panel(legal,'A43:N75','legal_april_review')
# Original dated loan histories and running principal/interest.
for filename,target,end in [('Good Insurance Co - Loan.xlsx',ln1,74),('Good Insurance Co - Loan II.xlsx',ln2,24)]:
 ws=donor(filename,target)
 if target==ln1:ws['B3']='Lesser of3% or SOFR3-Mo';ws['D74']='=MIN(A74,3)+$D$8'
 fmt(ws,{'A':13,'B':18,'C':22,'D':16,'E':23,'F':23,'G':24,'H':24,'I':52},(1,10,end),9)
 for rr in range(11,end+1):ws[f'B{rr}'].number_format='m/d/yyyy';ws[f'A{rr}'].number_format='0.00000';ws[f'D{rr}'].number_format='0.00000'
 ws.freeze_panes='C11';ws.print_title_rows='9:10'
 for rr,label,f in [(end+3,'April ending principal',f'=G{end}'),(end+4,'April interest charge',f'=E{end}'),(end+5,'Running accrued interest',f'=F{end}')]:line(ws,rr,label,f,lc='B',vc='E')
 note(ws,end+7,'Source method: actual dated principal × percent rate /365 × days. April charge accrues March31–April30 despite April7 cash payment. Negative interest transactions are payments or dated source adjustments. No further payment inferred.',start='B',end='I',height=55)
 if target==ln1:note(ws,end+9,'April rate=MIN(A74,3), consistent with stated cap. Earlier source rates and revisions remain historical. Obtain executed terms, rate reset evidence and historical revision approval. Source-based draft, not lender confirmation.',start='B',end='I',height=55)
 source_table('source.loan1' if target==ln1 else 'source.loan2',target,11,end,'E')
 prefix='loan1.' if target==ln1 else 'loan2.'
 for suf,cell in [('principal',f'G{end}'),('charge',f'E{end}'),('interest',f'F{end}')]:add(prefix+suf,target,cell,basis=f'{filename}, final source row{end}; dated April calculations and running balance.')
 panel(target,'A1:I16','loan1_terms' if target==ln1 else 'loan2_terms');panel(target,f'A{end-6}:I{end+9}','loan1_april' if target==ln1 else 'loan2_april')
add('input.loan1_rate',ln1,'A74','input','Good Insurance Co - Loan.xlsx A74 numeric percentage points; April current rate capped at3%.')
ws=wb[ln2]
for rr,label,f in [(37,'Combined principal','='+ref(ln1,'G74')+'+G24'),(38,'GL2600+2601 principal','='+gl(2600,credit=True)+'+'+gl(2601,credit=True)),(39,'GL less combined principal','=E38-E37'),(41,'Combined accrued interest','='+ref(ln1,'F74')+'+F24'),(42,'GL2402 accrued interest','='+gl(2402,credit=True)),(43,'GL less accrued interest','=E42-E41'),(45,'Combined April charge','='+ref(ln1,'E74')+'+E24'),(46,'GL6810 April charge','='+gl(6810,col='D'))]:line(ws,rr,label,f,lc='B',vc='E')
ws['E43'].number_format='0.000000000'
note(ws,48,'Accrued interest has a$0.005671233 GL-less-source residual ($0.01 at cents); no write-off. April charges round to GL6810. Source payment rounding carries sub-cent residuals. Obtain lender confirmations and current terms.',start='B',end='I',height=55)
for suf,cell in [('principal','E37'),('principal_gl','E38'),('principal_gap','E39'),('interest','E41'),('interest_gl','E42'),('interest_gap','E43')]:add('loans.'+suf,ln2,cell,basis='Combined source loans vs April GL2600+2601 /2402 positive credits; full precision.')
panel(ln2,'A27:I48','loans_controls')
ws=wb[ap];clear(ws)
ws['A1']='Aurisic A/P trade #2000 — April30,2025';ws['A3']='April GL credit balance';ws['B3']='='+gl(2000,credit=True);ws['A5']='Detailed AP support';ws['B5']='Unavailable'
ws['A7']='CFO request / draft notification'
ws['A8']='Please provide AP_TB-1.xlsx as of April30, aging and vendor detail tied to GL2000; identify posted versus proposed check reclassification. Review the$314,563.78 ledger control and$16,166.78 proposed check reclass separately. Confirm completeness and approve any journal before finalization.'
fmt(ws,{'A':80,'B':25},(1,7),2);ws['A8'].alignment=Alignment(wrap_text=True,vertical='top');ws.row_dimensions[8].height=110;ws['A10']='Approval status';ws['B10']='Pending CFO'
add('ap.control',ap,'B3',basis='April TB0010-2000 credit, independent of missing detail.');add('ap.detail',ap,'B5','unavailable','AP_TB-1.xlsx named in task but absent.');add('ap.action',ap,'A8','explanation','Draft CFO request, not sent; review/approval pending.');panel(ap,'A1:B10','ap_missing')
ws=donor('AR_Accrual-1.xlsx',ar)
ws['A9']='April division10 GL1101';ws['B9']='='+gl(1101);ws['A10']='April division12 GL1101';ws['B10']='='+gl(1101,division=12);ws['A11']='Division10 GL less source';ws['B11']='=B9-B6'
fmt(ws,{'A':53,'B':22,'C':38},(1,6),3)
note(ws,14,'Source identity: Aurisic GA-0015. Its$10,997 matches division10 GL, but no GA-0015/entity crosswalk is supplied. Division12 separately has$60,500. Obtain mapping and detail; the zero division10 gap does not establish completeness/mapping.',end='C',height=72)
for suf,cell,role in [('source','B6','calculated'),('division10','B9','calculated'),('division12','B10','calculated'),('gap','B11','calculated'),('mapping','A14','explanation')]:add('ar.'+suf,ar,cell,role,'AR_Accrual-1.xlsx GA-0015 observation; both April GL division scopes preserved; mapping unconfirmed.')
panel(ar,'A1:C14','ar')
ws=donor('Payroll-1.xlsx',pay);ws['E18']='Corporate copy E18: need to reallocate';ws['E16']='Payroll-1: Paycom Fees; corporate: Payroll Fees'
fmt(ws,{'A':40,'B':12,'C':21,'D':21,'E':52,'F':12},(1,4,21),6)
for rr in [16,18]:ws[f'E{rr}'].alignment=Alignment(wrap_text=True);ws.row_dimensions[rr].height=40
for rr in range(5,34):ws[f'B{rr}'].number_format='0'
for rr,label,f in [(37,'Opening March GL2200 credit','=-'+ref('Prior March TB','E29')),(38,'Signed April accrual postings','=SUM(C25,C28,C32)'),(39,'Source credit rollforward','=C37-C38'),(40,'April GL2200 credit','='+gl(2200,credit=True)),(41,'GL less credit rollforward','=C40-C39'),(43,'Partial salary movement','=SUM(C6,D6,C26,C29,C33)'),(44,'April GL6000 movement','='+gl(6000,col='D')),(45,'GL less partial salary movement','=C44-C43'),(47,'Source employee expenses','=C18+D18'),(48,'April GL6305 movement','='+gl(6305,col='D')),(49,'GL less partial expenses','=C48-C47'),(51,'Posting less130% estimate','=236500-E29')]:line(ws,rr,label,f,vc='C')
note(ws,53,'April payroll copies have the same amounts, counted once using Payroll-1.xlsx. Corporate E18 says “need to reallocate”; no destination/approval supplied. Paycom/Payroll Fees labels differ. Both observations retained.',end='F',height=58)
note(ws,55,'130% estimate=$236,448.888; source posts$236,500 plus special IT$20,500. Accrual, salary and expense bridges have partial coverage; they do not prove GL wrong. Obtain all payroll journals, allocation/per-diem detail, opening support and estimate-policy approval.',end='F',height=64)
source_table('source.payroll',pay,5,20,'D')
for suf,cell in [('first','C21'),('second','D21'),('estimate','E29'),('opening','C37'),('postings','C38'),('rollforward','C39'),('gl','C40'),('gap','C41'),('salary','C43'),('salary_gl','C44'),('salary_gap','C45'),('expenses','C47'),('expenses_gl','C48'),('expenses_gap','C49')]:add('payroll.'+suf,pay,cell,basis='Payroll-1.xlsx once; March GL2200 opening; April GL controls; signed postings/partial movement scopes.')
add('payroll.annotation',pay,'E18','explanation','Aurisic_Corp_Payrolls_April_2025-1.xlsx April2025 E18: need to reallocate; destination/approval missing.')
panel(pay,'A1:F33','payroll_source');panel(pay,'A36:F55','payroll_review')
ws=donor('Rebates-1.xlsx',reb);ws['A13']='April GL2005 credit';ws['B13']='='+gl(2005,credit=True);ws['A14']='Source less GL';ws['B14']='=B11-B13'
fmt(ws,{'A':47,'B':23,'C':23},(1,3,11,13,14),3)
for rr in range(4,10):ws[f'C{rr}'].number_format='m/d/yyyy'
note(ws,16,'LIGHT source=$7,892.45 in April versus$7,892.00 in March, a$0.45 source-version difference. April source opening components=$29,803.93, matching March GL2005. No unsupported journal created.',end='C',height=60)
for suf,cell in [('total','B11'),('gl','B13'),('gap','B14')]:add('rebates.'+suf,reb,cell,basis='Rebates-1.xlsx signed sources; gap=source less positive GL credit.')
panel(reb,'A1:C16','rebates')
# New April accrual schedules appended after original15.
u='#16) Uninvoiced #2011';b='#17) Bonus #2401';m='#18) Misc #2410'
for fn,target,total,acct,end in [('Accr2011-1.xlsx',u,'B7',2011,16),('AccrBonus-1.xlsx',b,'B13',2401,29),('AccrMisc-1.xlsx',m,'C10',2410,18)]:
 ws=donor(fn,target);fmt(ws,{'A':55,'B':23,'C':48,'D':30},(1,),4)
 rr=10 if target==u else 22 if target==b else 13;vc='C' if target==m else 'B'
 line(ws,rr,'April GL credit balance','='+gl(acct,credit=True),vc=vc);line(ws,rr+1,'GL credit less live source',f'={vc}{rr}-{total}',vc=vc)
 prefix='uninvoiced' if target==u else 'bonus' if target==b else 'misc'
 for suf,cell in [('total',total),('gl',f'{vc}{rr}'),('gap',f'{vc}{rr+1}')]:add(prefix+'.'+suf,target,cell,basis=fn+' signed source vs April GL positive credit; no entry proposed.')
 if target==u:note(ws,14,'Source line5 is year-end March31 transfer-pricing adjustment$159,695, matching GL2011 cross-period bridge. April costs paid May=$144,474.11. Obtain journal/posting date/cutoff approval; matching amount is not posting proof.',end='D',height=68)
 if target==m:note(ws,17,'Signed rollforward includes rebate transfer and LIFE ARMOUR items. Current source agrees to GL2410; completeness/approval remains CFO responsibility.',end='D',height=54)
 if target==b:
  ws['A15']='Live April accrued-bonus headline';ws['B15']='=B13';ws['A18']='Original source salary observation';ws['A19']='Current10% reference — unapproved';ws['B19']='=B25*10%'
  ws['A25']='April GL6000 YTD salary';ws['B25']='='+gl(6000);ws['A26']='Original fixed reported accrual';ws['B26']=334593.73
  note(ws,28,'Original B15 fixed$334,593.73 preserved at B26; B18 fixed salary$1,463,026.36 retained. B15 now follows signed rollforward.10% is an unapproved reference, not compensation policy/approved liability. Obtain compensation plan and approval.',end='D',height=70)
  for suf,cell,role,basis in [('headline','B15','calculated','Live signed rollforward, replacing fixed headline.'),('salary_ytd','B25','calculated','Current April GL6000 YTD.'),('ten_percent_reference','B19','calculated','10% current salary; unapproved source reference.'),('source_salary','B18','source','AccrBonus-1.xlsx original B18 fixed observation; C18 retained.'),('source_reported','B26','source','AccrBonus-1.xlsx original B15 fixed reported total.'),('input','B12','input','AccrBonus-1.xlsx original B12 April accrual input.')]:
   add('input.bonus' if suf=='input' else 'bonus.'+suf,b,cell,role,basis)
 panel(target,f'A1:D{end}',prefix)
# Alternate source versions and corporate annotations with original periods.
ce='Source Combined PPD1250';ci='Source Combined PPD1251';ca='Source Corporate April';cm='Source Corporate March'
for target,index in [(ce,0),(ci,1)]:
 ws=donor('Aurisic_Prepaid_Expenses_4-25-1.xlsx',target,index)
 if index==0:
  fmt(ws,{'A':30,'BU':20,'BV':20,'BW':20,'BX':21,'BY':20,'BZ':55},(1,5,52),78)
  for col in range(2,73):ws.column_dimensions[L(col)].hidden=True
  note(ws,58,'Alternate combined source: April$692,501.323131 versus dedicated$692,501.313131 ($0.01 difference). Extra fully-amortized ECOMMERCE rows/shifted identities retained. March BU52 includes$165,000 additions, BU53 excludes them; no source silently preferred to fit GL.',start='BU',end='BZ',height=85)
  ws.freeze_panes='BU8';panel(target,'A1:BZ27','combined_expense_top');panel(target,'A28:BZ58','combined_expense_bottom')
 else:
  fmt(ws,{'A':13,'B':31,'C':18,'AQ':20,'AR':20,'AS':20,'AT':21,'AU':48,'AV':12},(1,5,32),48)
  for col in range(4,43):ws.column_dimensions[L(col)].hidden=True
  note(ws,38,'Earlier-period source: actual AT5=March31,2025 and AT32=$49,137.41. This is not April insurance. Original coverage/March data retained; no relabeling as April support.',start='AQ',end='AV',height=65)
  ws.freeze_panes='AQ6';panel(target,'A1:AV22','combined_insurance_top');panel(target,'A23:AV38','combined_insurance_bottom')
for target,index in [(ca,0),(cm,1)]:
 ws=donor('Aurisic_Corp_Payrolls_April_2025-1.xlsx',target,index);fmt(ws,{'A':38,'B':12,'C':19,'D':19,'E':25,'F':20,'G':45,'H':12},(1,4,21),8)
 for rr in range(5,34):ws[f'B{rr}'].number_format='0'
 for col in ['E','G']:
  for rr in [18,28,29]:ws[f'{col}{rr}'].alignment=Alignment(wrap_text=True)
 note(ws,36,'Source copy for unique annotations and historical context. April amounts overlap Payroll-1.xlsx and are counted once on main payroll. March stays March, not an April substitute.',end='H',height=56)
 panel(target,'A1:H36','corporate_april' if index==0 else 'corporate_march')
# March observations for cross-period comparisons only.
prior=wb.create_sheet('Prior March TB');prior.append(['Division','Account','Name','March movement','March YTD','Class','Source row'])
orig=openpyxl.load_workbook(PUB/'Aurisic_Financials_3-25-1.xlsx',data_only=True).worksheets[1];prior_map={}
for row in orig:
 if isinstance(row[0].value,int) and isinstance(row[1].value,int):
  values=[c.value for c in row[:6]]+[row[0].row];prior.append(values);prior_map[values[0],values[1]]=prior.max_row
fmt(prior,{'A':12,'B':12,'C':45,'D':21,'E':22,'F':10,'G':14},(1,),7)
for row in prior.iter_rows(min_row=2):
 for c in [row[0],row[1],row[6]]:c.number_format='0'
wb[pay]['C37']='=-'+ref(prior.title,f'E{prior_map[10,2200]}')
prior.freeze_panes='D2';prior.auto_filter.ref=f'A1:G{prior.max_row}';prior.print_title_rows='1:1'
panel(prior.title,'A1:G29','prior_assets');panel(prior.title,'A73:G98','prior_income')
bridge=wb.create_sheet('Cross-period bridges');bridge.append(['Division','Account','March YTD source','April movement','April YTD source','Current less prior/movement','Source-backed candidate / limit','CFO request']);bridge_records=[]
for div,acct,name,movement,current,cls in rows:
 rr=bridge.max_row+1;pr=prior_map.get((div,acct));cprior=('='+ref(prior.title,f'E{pr}')) if pr else 'Unavailable'
 candidate='No difference at cents precision in supplied snapshots.';action='Review with close package.'
 if pr:
  gap=current-prior.cell(pr,5).value-movement
  if abs(gap)>.005:
   candidate='Source snapshots differ; causal posting history not supplied.';action='Provide adjustment journals/posting dates/cutoff approval; no entry inferred.'
   if acct==1250:candidate='Dedicated prepaid BU20/36/37:81,000+28,000+56,000=165,000 pre-April additions. Bridge matches numerically; posting/cutoff not proved.'
   elif acct==6200:candidate='Legal rows55/56 period325: credits28,000+56,000=84,000, journals1761/1762. April source movement agrees GL.'
   elif acct==2011:candidate='Accr2011 line5 year-end3/31 transfer-pricing adjustment159,695 equals credit bridge. Posting history unknown.'
 else:gap=None;candidate='April-only account/division; March template has no comparable row. Missing prior not assumed zero.';action='Confirm opening and entity scope; March clearing is aggregate only.'
 bridge.append([div,acct,cprior,'='+gl(acct,div,'D'),'='+gl(acct,div,'E'),f'=E{rr}-C{rr}-D{rr}' if pr else 'Unavailable',candidate,action]);bridge_records.append({'division':div,'account':acct,'gap':gap,'candidate':candidate})
fmt(bridge,{'A':10,'B':12,'C':23,'D':23,'E':23,'F':24,'G':85,'H':80},(1,),8)
for rr in range(2,bridge.max_row+1):
 for col in ['G','H']:bridge[f'{col}{rr}'].alignment=Alignment(wrap_text=True,vertical='center')
 bridge.row_dimensions[rr].height=58
 for col in ['A','B']:bridge[f'{col}{rr}'].number_format='0'
 if bridge_records[rr-2]['gap'] is None or abs(bridge_records[rr-2]['gap'])>.005:
  for c in bridge[rr]:c.fill=PatternFill('solid',fgColor=ORANGE)
bridge.freeze_panes='C2';bridge.auto_filter.ref=f'A1:H{bridge.max_row}';bridge.print_title_rows='1:1'
add('bridges',bridge.title,f'A2:H{bridge.max_row}','table','March YTD+April movement vs current YTD; changed close snapshots are questions, not asserted accounting errors.',dict(division='A',account='B',prior='C',movement='D',current='E',gap='F',candidate='G',action='H'))
for st in range(1,bridge.max_row+1,15):panel(bridge.title,f'A{st}:H{min(st+14,bridge.max_row)}',f'bridges_{st}')
issues=wb.create_sheet('CFO review requests');issues.append(['Area','Source / exact location','Observation','Calculated result / impact','Action requested from CFO','Status'])
issue_rows=[
['Draft status','April package;17 originals; public contracts','Source calculations/reconciliations prepared. Financial approval and external reporting conclusions not supplied.','Review draft; no journals posted or messages sent.','Review open items, obtain missing support, authorize entries and sign off separately.','Pending CFO review'],
['AP detail','AP_TB-1.xlsx absent; April TB0010-2000','Vendor/aging support not supplied.','GL credit314,563.78; detail completeness unknown.','Provide April30 AP detail/aging/cutoff tie-out. Review proposed check reclass separately.','Missing company evidence'],
['Bank','Outstanding_CKs_4-30-25-1.xlsx rows7:8; TB1023/1024/2001','No independent statement. Two checks16,166.78 equal GL2001 credit.','Book cash6,610,926.80; proposed reclass16,166.78; independent reconciliation unavailable.','Provide statement/cleared-check evidence; confirm completeness and approve reclass.','Missing statement / approval'],
['Funding / identity','March funding rows5/7; April7206/7075/7076/7092;1656','March UK label duplicated; April subsidiary split unavailable.1656 label FR changed to DE.','Aggregate funding5,003,243.01; monthly average1,250,810.7525. No allocation invented.','Provide mapped April subsidiary detail; confirm duplicate UK and1656 identity.','Mapping unresolved'],
['Prepaid expense','PPD1250-1.xlsx BX46/BX48; GL1250','Vendor sum692,501.313131313;0.02 source variance is not a plug.','GL692,501.33 less source0.016868687 (0.02 display); no balancing entry.','Provide rounding/GL posting reconciliation and treatment approval.','Residual unresolved'],
['Prepaid versions','Combined expense BX52/BU52/BU53; dedicated BX46','Combined0.01 higher; extra amortized ECOMMERCE rows and differing term labels. March BU52 includes165,000;BU53 excludes it.','Combined692,501.323131313; dedicated692,501.313131313. Source selection not based on GL proximity.','Confirm approved source version,0.01 difference and March additions.','Version confirmation pending'],
['Prepaid terms','Dedicated expense BY/BZ/BW; rows8,10,11,13,14,17,21:24,30:33,40,42','Expiry/inclusive endpoints/descriptions/denominators conflict; formulas retained as source, not approved contract interpretation.','r25 /6 matches4/25–9/25. PINK r40 /8 vs9-month label/later description; KNIGHT r32 /10 vs year. See main notes.','Provide contracts/invoices/service dates and row-specific amortization approval.','Company evidence / policy pending'],
['Legacy check errors','PPD1250-1.xlsx P50/S50','Original historical check cells have #REF! errors.','Preserved source errors, not current dependencies or zero substitutes.','Confirm/repair legacy check provenance if historical checks needed.','Source limitation preserved'],
['Prepaid insurance','PPD1251-1.xlsx AT32/35; combined insurance AT5/32','Dedicated April5,493.27 vs GL54,630.68; combined actual March31=49,137.41.','April gap49,137.41; TMMR says March coverage in April columns.','Provide policies/cumulative amortization postings; explain residual and TMMR cutoff; confirm current source.','Unresolved support'],
['Legal calculation','Legal_Dump-1.xlsx L60/L62/M60/M62; rows3:59','Original formula counts subtotal row60 twice. Signed transactions now counted once.','Corrected YTD435,284.69 matches GL; original displayed870,569.38 retained. April425=62,772.93 matches GL.','Review adopted formula correction and completeness/cutoff.','Calculation corrected; review pending'],
['Close snapshots','Cross-period bridges; Legal55/56; prepaid BU20/36/37; Accr2011 B5','Components: prepaid+165,000; legal−84,000; uninvoiced credit+159,695. Other differences need posting history.','Matching amounts do not prove posting/approval; no bridging journal invented.','Provide final March/current extracts, adjustment journals/dates and cutoff approval; resolve highlighted rows.','History / cutoff pending'],
['Payroll accrual','Payroll-1 C25/C28/C32; corporate April E18','Overlapping copies counted once. Corporate need to reallocate; Paycom/Payroll Fees labels differ.','Credit rollforward318,500 vs GL141,033:gap−177,467.130% estimate236,448.888 vs posted236,500.','Provide2200 journals/opening support; allocation destination; confirm special IT and estimate policy.','Partial coverage unresolved'],
['Payroll movements','Payroll-1 C6/D6/C26/C29/C33; C18/D18; GL6000/6305','Source sums are partial movement bridges, not proof GL wrong.','Salary380,356.01 vs388,005.99:gap7,649.98. Expenses18,097.83 vs−8,653.07:gap−26,750.90.','Provide other salary/per-diem entries, allocation and reimbursement detail.','Journals / allocation pending'],
['AR mapping','AR_Accrual-1 A4/B4; TB0010/0012-1101','GA-0015 source10,997 matches division10 arithmetically; no entity crosswalk.','Division10=10,997; division12=60,500. Match is not mapping/completeness.','Confirm GA-0015 entity/division and both division supports.','Mapping unresolved'],
['Bonus policy','AccrBonus-1 B12/B13/B15/B18/B19','Live headline refreshes rollforward; fixed original observations separate.10% is unapproved reference.','Accrual334,593.73 tied; salary1,463,026.36;10% reference146,302.636.','Provide compensation plan/CA support and approved accrual methodology.','Policy / approval pending'],
['Loans / precision','Good Insurance Co loans rows74/24; GL2402/2600/2601','Principal31,800,000 tied. Actual/365 and payment rounding retained; April loanI cap explicit.','Accrued67,315.064328767 vs GL67,315.07; residual0.005671233. April charge67,315.068493151 rounds to GL6810.','Obtain executed terms, rate evidence, lender confirmations and revision approvals; resolve residual without automatic write-off.','Support / review pending'],
['Rebate version','Rebates-1 B5 vs March B5','April LIGHT7,892.45 vs March7,892.00. April source opening agrees March GL.','0.45 version difference; April source159,707.51 matches GL.','Confirm source correction/supporting rebate documents.','Source confirmation pending'],
['Other accruals','Accr2011-1; AccrMisc-1; April2011/2410','Signed calculations agree current controls; historical transfer pricing needs cutoff.','Uninvoiced304,169.11; miscellaneous146,796.76.','Review completeness/invoices and approve separately from arithmetic tie-out.','Arithmetic tied; review pending']]
for row in issue_rows:issues.append(row)
fmt(issues,{'A':25,'B':66,'C':92,'D':83,'E':94,'F':30},(1,),6)
for rr in range(2,issues.max_row+1):
 for c in issues[rr]:c.alignment=Alignment(wrap_text=True,vertical='center')
 issues.row_dimensions[rr].height=100
issues.freeze_panes='C2';issues.auto_filter.ref=f'A1:F{issues.max_row}';issues.print_title_rows='1:1';issues.sheet_properties.tabColor='C77719'
add('issues',issues.title,f'A2:F{issues.max_row}','table','Draft CFO notification; sources/calculations/missing evidence/approval status separate.',dict(area='A',source='B',observation='C',result='D',action='E',status='F'))
for st in range(1,issues.max_row+1,6):panel(issues.title,f'A{st}:F{min(st+5,issues.max_row)}',f'issues_{st}')
statuses={tb:'105 April accounts converted; proofs and bridge questions linked',cash:'Calculated from April ledger; bank verification pending',bank:'Checks/book control complete; statement and approval missing',fund:'Aggregate actuals/4-month averages complete; subsidiary mapping pending',pe:'Dedicated April live calculation;0.016869 residual/term conflicts flagged',pi:'Dedicated April calculation;49,137.41 GL gap unresolved',fees:'Signed rollforward tied to GL2404',legal:'Double-count corrected; YTD/April tied; cutoff review pending',ln1:'April principal/charge/accrual calculated; lender/terms pending',ln2:'April/combined controls calculated; sub-cent residual disclosed',ap:'AP_TB-1.xlsx missing; GL control/request provided',ar:'Source and both GL divisions shown; GA-0015 mapping pending',pay:'Runs balanced; partial bridges require journals',reb:'Source tied;0.45 opening version difference disclosed',u:'Source tied; historical transfer-pricing cutoff pending',b:'Live rollforward tied; compensation policy unapproved',m:'Signed source tied; completeness review pending',ce:'Alternate April version;0.01 source difference retained',ci:'Actual March31 source period retained; not April',ca:'Overlapping April copy; unique instruction retained; counted once',cm:'March historical payroll observations',prior.title:'97 March accounts; comparison only',bridge.title:'105 April identities; supported components and unknown prior scopes',issues.title:'Draft CFO notification; evidence/approval requests pending'}
ws=wb[N[0]];clear(ws);ws['A1']='Aurisic';ws['A2']='April2025 financial package';ws['A3']='CFO review draft — source calculations and unresolved evidence';ws['A5']='Tab / section';ws['B5']='Actual worksheet';ws['C5']='Status / review comment'
for sn in wb.sheetnames[1:]:
 section=re.match(r'#([^)]*)\)',sn);ws.append([section[1] if section else 'Appendix',sn,statuses[sn]]);ws.cell(ws.max_row,2).hyperlink=f"#'{sn}'!A1"
ws.append(['Appendix','Audit index','Technical locators to actual financial cells/tables; no expected answers'])
contents_end=ws.max_row;fmt(ws,{'A':18,'B':42,'C':115},(1,5),3)
for rr in range(6,contents_end+1):ws[f'C{rr}'].alignment=Alignment(wrap_text=True);ws.row_dimensions[rr].height=37
note(ws,contents_end+2,'CFO sections1/2/2a/3 excluded. Original3a–15 schedule order retained; new April accruals/review/source appendices follow. Teal=current controls; amber=limits. Ledger/source credits signed; liability controls positive where labeled.',end='C',height=60)
add('contents',ws.title,f'A6:C{contents_end}','table','Actual included worksheets, original order then new schedules/appendices.',dict(section='A',sheet='B',status='C'))
ix=wb.create_sheet('Audit index');ix.append(['Claim','Sheet','Address','Role','Columns','Basis'])
for row in claims:ix.append(row)
fmt(ix,{'A':40,'B':42,'C':22,'D':19,'E':85,'F':120},(1,),6)
for rr in range(2,ix.max_row+1):ix[f'F{rr}'].alignment=Alignment(wrap_text=True);ix[f'E{rr}'].alignment=Alignment(wrap_text=True);ix.row_dimensions[rr].height=44
ix.freeze_panes='D2';ix.auto_filter.ref=f'A1:F{ix.max_row}'
panel(ws.title,'A1:C21','contents_top');panel(ws.title,f'A22:C{ws.max_row}','contents_bottom');panel(ix.title,'A1:F18','audit_index')
for sn in wb.sheetnames:
 w=wb[sn];w.sheet_view.zoomScale=85
 if not w.print_area:w.print_area=f'A1:{L(w.max_column)}{w.max_row}'
wb.active=0;wb.calculation=CalcProperties(calcId=191029,fullCalcOnLoad=True,forceFullCalc=True,calcMode='auto')
wb.properties.creator='Aurisic Financial Reporting';wb.properties.title='April2025 Financial Package — CFO Review Draft'
# Visual QA corrections: compact review tables, readable controls, explicit subtotal bounds.
# Original loanII E33 summed a blank future area; new review cells must not enter it.
wb[ln2]['E33']='=SUM(E11:E24)';wb[ln2]['B33']='Interest transactions through April'
for target,end in [(ln1,74),(ln2,24)]:
 w=wb[target]
 rrlist=[end+3,end+4,end+5]+([33,37,38,39,41,42,43,45,46] if target==ln2 else [])
 for rr in rrlist:
  w.merge_cells(f'B{rr}:D{rr}');w[f'B{rr}'].alignment=Alignment(wrap_text=True,vertical='center');w.row_dimensions[rr].height=28
  for col in ['B','C','D','E']:w[f'{col}{rr}'].fill=PatternFill('solid',fgColor=TEAL)
for rr in range(66,72):
 wb[legal].merge_cells(f'G{rr}:K{rr}');wb[legal][f'G{rr}'].alignment=Alignment(wrap_text=True,vertical='center');wb[legal].row_dimensions[rr].height=28
for col,width in {'A':18,'B':32,'C':38,'D':36,'E':42,'F':20}.items():issues.column_dimensions[col].width=width
for col,width in {'G':55,'H':50}.items():bridge.column_dimensions[col].width=width
for col,width in {'A':35,'B':37,'C':20,'D':15,'E':55,'F':70}.items():ix.column_dimensions[col].width=width
for row in ix.iter_rows(min_row=2):
 if row[3].value=='source_table':ix.row_dimensions[row[0].row].height=180
for sn in wb.sheetnames:
 w=wb[sn]
 hidden={i for i in range(1,w.max_column+1) if w.column_dimensions[L(i)].hidden}
 for row in w:
  for c in row:
   if c.data_type=='f' or isinstance(c.value,(int,float)):
    if c.number_format=='General':c.number_format=NUM
   if c.column in hidden:c.alignment=Alignment(wrap_text=True,vertical='center')
 for col in ['D'] if sn in [legal,fees] else []:
  for row in w.iter_rows(min_row=3,max_row=59 if sn==legal else 8):row[3].number_format='0'
for rr in range(6,contents_end+1):wb[N[0]][f'A{rr}'].alignment=Alignment(horizontal='left',vertical='center')
wb[N[0]]['A2']='April 2025 financial package';wb[cash]['A3']='As of April 30, 2025';wb[fund]['D20'].number_format='0'
note(wb[N[0]],contents_end+4,'Reading guide: GL = general ledger; YTD = year to date; AP = accounts payable; AR = accounts receivable; CFO = Chief Financial Officer. Blue input cells are editable original observations; formulas and fixed source observations have separate roles in Audit index.',end='C',height=55)
for claim,sheet,address,role,columns,basis in claims:
 if role=='input':
  c=wb[sheet][address];c.fill=PatternFill('solid',fgColor='E7EFFB');c.font=Font(name='Calibri',size=11,color='0000FF');c.comment=Comment(basis,'Source input')
wb[N[0]].print_area=f'A1:C{wb[N[0]].max_row}'
wb[fund]['B2']='Budget 2025 (March plan)'
for cell,value in [('B3','Monthly plan'),('C3','Annual plan'),('D3','Current YTD actual'),('E3','Monthly average'),('G3','Prior source')]:wb[fund][cell]=value
wb[ln1]['I10']='Source notes'
for address in ['C4','C22']:wb[bank][address].fill=PatternFill('solid',fgColor=ORANGE)
for sn in wb.sheetnames:
 for row in wb[sn]:
  for c in row:
   if c.fill.fgColor.type=='rgb' and c.fill.fgColor.rgb[-6:]==NAVY and c.number_format==NUM:c.number_format='#,##0.00;(#,##0.00);–'
# Complete visible detail coverage beyond the control panels.
for sn,range_,tag in [(tb,'A29:F60','ledger_liabilities'),(tb,'A61:F90','ledger_expenses'),(legal,'A23:N42','legal_middle'),(ln1,'A17:I42','loan1_history_1'),(ln1,'A43:I67','loan1_history_2'),(prior.title,'A30:G51','prior_liabilities'),(prior.title,'A52:G72','prior_expenses')]:panel(sn,range_,tag)
# Ensure the visual plan includes the reading guide added during review.
for p in renders:
 if p['tag']=='contents_bottom':p['range']=f'A22:C{wb[N[0]].max_row}'
wb.save(OUT/'Aurisic_Financials_4-25-1.xlsx')
(OUT/'claims.json').write_text(json.dumps(claims,indent=2),encoding='utf-8');(OUT/'render_plan.json').write_text(json.dumps(renders,indent=2),encoding='utf-8')
(OUT/'evidence'/'bridge_analysis.json').write_text(json.dumps(bridge_records,indent=2),encoding='utf-8')
print('Saved',len(wb.sheetnames),'sheets',len(claims),'claims',len(renders),'visual panels')
for x in bridge_records:
 if x['gap'] is not None and abs(x['gap'])>.005:print(x)
