from pathlib import Path
import zipfile,xml.etree.ElementTree as ET,json,openpyxl
O=Path(__file__).resolve().parent;target=O/'Aurisic_Financials_4-25-1.xlsx';calculated=O/'evidence'/'artifact_recalculated.xlsx'
NS={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
cv=openpyxl.load_workbook(calculated,data_only=True);formulas=openpyxl.load_workbook(target,data_only=False)
ET.register_namespace('',NS['m'])
report=[];tmp=O/'temp'/'cached_presentation.xlsx'
with zipfile.ZipFile(target) as src,zipfile.ZipFile(tmp,'w',zipfile.ZIP_DEFLATED) as dst:
 for entry in src.infolist():
  data=src.read(entry.filename)
  if entry.filename.startswith('xl/worksheets/sheet') and entry.filename.endswith('.xml'):
   index=int(entry.filename.split('sheet')[-1].split('.')[0])-1;ws=cv[formulas.sheetnames[index]];root=ET.fromstring(data)
   for cell in root.findall('.//m:c',NS):
    f=cell.find('m:f',NS)
    if f is None:continue
    address=cell.attrib['r'];value=ws[address].value;v=cell.find('m:v',NS)
    if v is None:v=ET.SubElement(cell,'{'+NS['m']+'}v')
    if value is None:
     report.append({'sheet':ws.title,'cell':address,'cache':'unavailable'});continue
    if isinstance(value,bool):cell.set('t','b');v.text='1' if value else '0'
    elif isinstance(value,(int,float)):cell.attrib.pop('t',None);v.text=repr(value)
    elif isinstance(value,str) and value.startswith('#'):cell.set('t','e');v.text=value
    else:cell.set('t','str');v.text=str(value)
    report.append({'sheet':ws.title,'cell':address,'cache':value})
   data=ET.tostring(root,encoding='utf-8',xml_declaration=True)
  dst.writestr(entry,data)
tmp.replace(target)
saved=openpyxl.load_workbook(target,data_only=True);savedf=openpyxl.load_workbook(target,data_only=False)
claims=json.loads((O/'claims.json').read_text());live=json.loads((O/'evidence'/'recalculated_claims.json').read_text());checks=[]
for claim,sheet,address,role,columns,basis in claims:
 if ':' in address or ',' in address:continue
 actual=saved[sheet][address].value;expected=live[claim]['value']
 ok=abs(actual-expected)<1e-7 if isinstance(actual,(int,float)) and isinstance(expected,(int,float)) else actual==expected
 checks.append({'claim':claim,'saved_cache_or_input':actual,'runtime_live':expected,'verified':ok,'actual_formula':savedf[sheet][address].value if savedf[sheet][address].data_type=='f' else None})
errors=[{'sheet':ws.title,'cell':c.coordinate,'value':c.value,'formula':savedf[ws.title][c.coordinate].value} for ws in saved for row in ws for c in row if c.data_type=='e']
summary={'formula_cache_count':len(report),'reopened_claims':checks,'preserved_errors':errors,'cache_method':'Only XML cached <v> values for actual formulas copied from declared Artifact Tool export; original formulas, styles, identities and layout retained. No financial values hand-entered as formula caches.'}
(O/'evidence'/'saved_reopened_validation.json').write_text(json.dumps(summary,indent=2,default=str),encoding='utf-8')
assert all(c['verified'] for c in checks)
print('Saved/reopened',len(checks),'scalar claims;',len(report),'formula caches;',len(errors),'preserved source errors.')
print('Preserved errors:',errors)
