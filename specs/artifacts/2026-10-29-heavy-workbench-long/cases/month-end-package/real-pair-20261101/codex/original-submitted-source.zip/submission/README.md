# April 2025 CFO review package

Deliverable: **Aurisic_Financials_4-25-1.xlsx**. Start with the first worksheet, Table of Contents, then CFO review requests. The first 15 worksheets retain the March schedule order and financial meaning. New April uninvoiced, bonus and miscellaneous schedules follow, then source-version and review appendices. CFO-reserved sections 1/2/2a/3 are excluded.

This is a completed source-supported **review draft**, with unresolved company evidence explicitly open. It is not financial sign-off, a lender/bank confirmation, certification or a benchmark grade. No journals were posted and no message was sent to the CFO. The workbook contains the draft notification and specific requests.

Material review points:

- AP_TB-1.xlsx is missing. GL2000 has a $314,563.78 credit, separate from unavailable vendor support. Bank cash of $6,610,926.80 is a ledger control, not an independent statement. Checks total $16,166.78; their reclassification is proposed only.
- Dedicated prepaid insurance calculates to $5,493.27 versus GL $54,630.68, leaving $49,137.41 unresolved. The combined insurance file actually ends March 31. Dedicated prepaid expenses calculate to $692,501.313131 versus GL $692,501.33, a $0.016869 residual. The combined expense source is $0.01 higher. Coverage and denominator contradictions need contracts and approval.
- The legal dump's original formula double counted its subtotal. Counting each signed transaction once gives $435,284.69 YTD and $62,772.93 April, both agreeing to the current ledger. Source-backed cross-period components are shown, with posting history and cutoff approval still unknown.
- Payroll copies overlap and are counted once. Credit accrual rollforward is $318,500 versus GL $141,033; salary/expense bridges have partial coverage. Reallocation instructions, remaining journals and policy approval are requested. GA-0015 AR mapping and funding subsidiary detail are also unresolved.
- Loan principal totals $31,800,000 and ties to GL2600+2601. Running interest is $67,315.064328767 versus GL $67,315.07. No automatic rounding write-off is made. Bonus live totals refresh; original fixed observations and the unapproved 10% reference remain distinct.

Build from the project directory in native PowerShell:

```powershell
& .\submission\build.ps1
```

The script uses only the Python, Node and shared Artifact Tool declared in public/RUNTIME.md. It reads immutable public inputs and writes only submission. No downloads or additional installed dependencies are required. The explicit runtime paths are in build.ps1; openpyxl authors the original presentation file, and Artifact Tool imports, recalculates, renders and exports real workbook evidence. Public API documentation used: the RUNTIME.md-listed artifact_tool_docs/API_QUICK_START.md and its bounded workbook.render help.

The build script performs these steps, which can also be run individually:

1. `build_workbook.py`: create the consolidated workbook from original files; write claims.json/render_plan.json.
2. `recalculate.mjs --all`: import the actual file, recalculate, export evidence/artifact_recalculated.xlsx, apply each of the six public input changes in memory, restore inputs, and render all 55 financial/review panels.
3. `validate_sources.py`: independently compare 148 numeric claims to original-source arithmetic, all 105 ledger accounts to the text, 1,362 nonempty source-table inputs, and 17 dependent input-change results.
4. `cache_and_reopen.py`: copy only actual recalculated formula caches into the original presentation XML; reopen and verify 154 scalar claims. Formulas and layout are retained. No expected amounts are hand-written as caches.
5. `verify_final.mjs`: cold import the final saved workbook and recalculate all 154 scalar claims again.
6. `make_contacts.py`: create visual review contact sheets from actual rendered workbook panels. Inspect these and full-size files in evidence/renders; contact sheets do not replace source or financial review.

Evidence includes source_validation.json (per-claim/account/input errors, not just a pass count), input_change_results.json, saved_reopened_validation.json, final_runtime_reopen.json, bridge_analysis.json, rendered PNGs and visual_review.md. inputs_inspected.json preserves source formulas, displayed caches and layout observations. Inspection scripts are retained for reproducibility.

Engine and evidence limits: only the declared Artifact Tool file consumer was exercised; native Microsoft Excel application behavior was not certified. The simple independent source calculator covers the supplied SUM/numeric source formula family, not arbitrary Excel functions. Two original prepaid historical check errors, P50/S50 #REF!, remain preserved and are outside current calculation dependencies. Company support, approved policies, identities and cutoff history cannot be created by a workbook recalculation. Initial technical failures and corrective actions are retained in evidence/initial_runtime_failure.txt and evidence/implementation_failures.txt.
