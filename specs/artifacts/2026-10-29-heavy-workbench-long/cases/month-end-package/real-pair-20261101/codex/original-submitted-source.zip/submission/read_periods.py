import openpyxl
from pathlib import Path
w=openpyxl.load_workbook(Path('public')/'Aurisic_Prepaid_Expenses_4-25-1.xlsx',data_only=True)
for s in w:
 print(s.title,[(x,s[x].value) for x in ['A2','B2','AQ5','AR4','AT5','BU5','BX5','BX52','BU53','AT32']])
p=openpyxl.load_workbook(Path('public')/'Aurisic_Financials_3-25-1.xlsx',data_only=True)
for s in p:
 if s.title.startswith('#3a'):
  print('template accounts',sum(1 for r in s if isinstance(r[0].value,int) and isinstance(r[1].value,int)))
  for row in s:
   if row[0].row>95:print([(c.coordinate,c.value) for c in row[:6] if c.value is not None])
