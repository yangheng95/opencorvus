import openpyxl,re
from pathlib import Path
for p in Path('public').glob('*.xlsx'):
 wb=openpyxl.load_workbook(p,data_only=False)
 fun=set(); errors=[]
 for ws in wb:
  for row in ws:
   for c in row:
    if c.data_type=='f':fun.update(re.findall(r'([A-Z][A-Z0-9_.]*)\(',c.value))
    elif c.data_type=='e':errors.append((ws.title,c.coordinate,c.value))
 print(p.name,fun,'error',errors[:10])
