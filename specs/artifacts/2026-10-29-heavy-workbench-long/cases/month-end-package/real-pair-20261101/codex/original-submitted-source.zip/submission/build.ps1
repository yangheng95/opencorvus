$ErrorActionPreference='Stop'
$project=Split-Path -Parent $PSScriptRoot
Set-Location -LiteralPath $project
$python='C:/Users/hengu/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
$node='C:/Users/hengu/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe'
New-Item -ItemType Directory -Path submission/temp,submission/cache,submission/evidence -Force | Out-Null
$env:TEMP=(Resolve-Path submission/temp).Path
$env:TMP=$env:TEMP
$env:XDG_CACHE_HOME=(Resolve-Path submission/cache).Path
$env:PYTHONDONTWRITEBYTECODE='1'
& $python submission/build_workbook.py 2>&1 | Tee-Object submission/evidence/build.log
if($LASTEXITCODE -ne 0){throw 'Workbook build failed'}
& $node submission/recalculate.mjs --all 2>&1 | Tee-Object submission/evidence/recalculate.log
if($LASTEXITCODE -ne 0){throw 'Declared runtime recalculation failed'}
& $python submission/validate_sources.py 2>&1 | Tee-Object submission/evidence/source_validation.log
if($LASTEXITCODE -ne 0){throw 'Original-source validation failed'}
& $python submission/cache_and_reopen.py 2>&1 | Tee-Object submission/evidence/saved_reopened_validation.log
if($LASTEXITCODE -ne 0){throw 'Saved-cache validation failed'}
& $node submission/verify_final.mjs 2>&1 | Tee-Object submission/evidence/final_runtime_reopen.log
if($LASTEXITCODE -ne 0){throw 'Final runtime reimport failed'}
& $python submission/make_contacts.py
if($LASTEXITCODE -ne 0){throw 'Contact sheet creation failed'}
