import json
from pathlib import Path
import subprocess
ROOT=Path(__file__).resolve().parent
math=json.loads((ROOT/'calendar-math.json').read_text(encoding='utf-8'))
source=[]
base=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L02/evaluator/current-source')
for name in ['build_materials.py','decode_materials.py']:
    p=ROOT/'source-current-grid'/name
    source.append({'file':name,'snapshot':str(p),'same_current_bytes':p.read_bytes()==(base/name).read_bytes(),'review_scope':'target +2 definition/diff only; not full implementation qualification'})
result={'stage':'corrected_UTC_material_design_can_proceed_to_actual_qualification','blocking':[],
 'initial_semantic_blockers':[{'id':'P1-grid','finding':'09:00 origin with next-midnight end includes9 elapsed hours, inconsistent with14 wholly future days','status':'closed_in_plan_and_static_plus2_grid_definitions','original_sources':'initial-grid-source'},
 {'id':'P1-development-label-privacy','finding':'Jan1 publication-truncated dev archive necessarily contains terminal labels of declared2024Jun-Nov development targets','status':'closed_by_explicit_public_dev_backtest_vs_private2025outer_vs_per_origin_feature_split'}],
 'calendar_pairs_checked':math['inner_pairs_checked'],'selected_grid':'14_wholly_future_UTC_days','minimum_fixed_rule_inner_label_margin_hours':math['minimum_margin_hours_by_policy']['14_wholly_future_UTC_days'],
 'actual_material_generation_decoder_or_worker_run_by_reviewer':False,'new_Provider_solver_GPU_Docker_UI_processes':0,'delegations':0,'source_grid_bindings':source,
 'next_required_evidence':['actual source-only material generation/decoder CLI','independent raw UTC/Decimal/identity and latest-missing records','actual inner required-label release rows bound to outer rather than declared lag alone','full public-artifact as-of embargo incl operational metadata','issue/publication/revision semantics','complete truth/missing eligibility/hierarchy'],
 'not_approved':['correctness of newly formed full decoder/builder','full research/reference/interval scoring pipeline','complete atomic rubric/freeze','quality threshold/professional-statistical maturity','hours or ten-task completion'],
 'candidate_score':None,'only_material_design_stage':True,'no_Codex_project_read_or_message':True}
(ROOT/'stage-assessment.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
refs=[{'url':'https://otext.robjhyndman.com/hyndsight/tscv/','read':'rolling-origin and multi-step training/test separation'}, {'url':'https://otexts.com/fpp3/toolbox.html#time-series-cross-validation','read':'current redirect of original /tscv.html, section5.10'}, {'url':'https://journals.plos.org/ploscompbiol/article?id=10.1371/journal.pcbi.1008618','read':'WIS/interval forecast evaluation, future scope only'}, {'url':'https://journals.plos.org/ploscompbiol/article?id=10.1371/journal.pcbi.1010592','read':'2022 example/figure correction, not new scorer validation'}]
(ROOT/'primary-sources-read.json').write_text(json.dumps(refs,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
status=subprocess.run(['git','status','--short'],cwd='D:/myhexin-local/opencorvus',capture_output=True,text=True,encoding='utf-8');(ROOT/'git-status-end.txt').write_text(status.stdout,encoding='utf-8')
print(json.dumps({'stage':result['stage'],'blocking':[],'two_original_semantic_errors_closed':True,'inner_margin_hours':result['minimum_fixed_rule_inner_label_margin_hours'],'no_new_material_execution':True},ensure_ascii=False))
