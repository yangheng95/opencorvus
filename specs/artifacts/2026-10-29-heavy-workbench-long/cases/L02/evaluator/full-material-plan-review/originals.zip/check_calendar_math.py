"""Plan arithmetic only: no generator/decoder/worker/solver/model is executed."""
from datetime import datetime,timedelta,timezone
import json
from pathlib import Path
import shutil
import subprocess
ROOT=Path(__file__).resolve().parent
REPO=Path('D:/myhexin-local/opencorvus')
record=REPO/'specs/records/2026-10/2026-10-30-heavy-workbench-l02-qualification.md'
def iso(x):return x.isoformat().replace('+00:00','Z')
def grid(origin,first_end_offset):
    floor=origin.replace(hour=0,minute=0,second=0,microsecond=0)
    return [{'start':floor+timedelta(days=i-1),'end':floor+timedelta(days=i)} for i in range(first_end_offset,first_end_offset+14)]
def main():
    shutil.copy2(record,ROOT/'record-reviewed.md')
    shutil.copy2(REPO/'specs/artifacts/2026-10-29-heavy-workbench-long/cases/L02/public/ASOF-CONTRACT.draft.md',ROOT/'primitive-contract-reviewed.md')
    before=Path('D:/opencorvus-benchmark-runs/l02-full-material-plan-status-pre.txt')
    if before.exists():shutil.move(str(before),str(ROOT/'git-status-start.txt'))
    cutoff=datetime(2025,1,1,9,tzinfo=timezone.utc);cases=[];dev=[]
    for first,name in [(1,'current_day_total_plus13future_days'),(2,'14_wholly_future_UTC_days')]:
        for month in range(1,13):
            outer=datetime(2025,month,15,9,tzinfo=timezone.utc)
            for offset in [112,84,56]:
                inner=outer-timedelta(days=offset);g=grid(inner,first);last=g[-1]['end'];release=last+timedelta(days=21,hours=6)
                cases.append({'policy':name,'outer':iso(outer),'inner':iso(inner),'offset_days':offset,'first_target_start':iso(g[0]['start']),'first_target_end':iso(g[0]['end']),'last_target_end':iso(last),'last_terminal_label_release':iso(release),'strictly_before_outer':release<outer,'margin_hours':int((outer-release).total_seconds()/3600)})
        for month in range(6,12):
            origin=datetime(2024,month,15,9,tzinfo=timezone.utc);g=grid(origin,first);release=g[-1]['end']+timedelta(days=21,hours=6)
            dev.append({'policy':name,'origin':iso(origin),'last_dev_target_end':iso(g[-1]['end']),'last_dev_terminal_release':iso(release),'all_dev_horizon_labels_published_by_public_cutoff':release<=cutoff})
    outer=datetime(2025,1,15,9,tzinfo=timezone.utc);example={}
    for first,name in [(1,'current_day_total_plus13future_days'),(2,'14_wholly_future_UTC_days')]:
        g=grid(outer,first);dec=grid(datetime(2025,12,15,9,tzinfo=timezone.utc),first)
        example[name]={'origin':iso(outer),'first_start':iso(g[0]['start']),'first_end':iso(g[0]['end']),'past_hours_in_first_target':max(0,int((outer-g[0]['start']).total_seconds()/3600)),
          'last_December_target_end':iso(dec[-1]['end']),'last_December_terminal_release':iso(dec[-1]['end']+timedelta(days=21,hours=6))}
    result={'scope':'calendar algebra under proposed fixed21day6h terminal-release rule only; no material or reference execution','origin_target_grid_examples':example,'inner_pairs_checked':len(cases),'all_inner_latest_terminal_releases_strictly_before_outer':all(r['strictly_before_outer'] for r in cases),
      'minimum_margin_hours_by_policy':{name:min(r['margin_hours'] for r in cases if r['policy']==name) for name in example},'inner_rows':cases,'development_rows':dev,
      'all_declared_dev_target_terminal_labels_fall_in_publication_cutoff':all(r['all_dev_horizon_labels_published_by_public_cutoff'] for r in dev),
      'maximum_full_2025_event_terminal_release':iso(datetime(2026,1,1,tzinfo=timezone.utc)+timedelta(days=21,hours=6)),'not_actual_generated_csv_or_decoder_validation':True}
    (ROOT/'calendar-math.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    status=subprocess.run(['git','status','--short'],cwd=REPO,capture_output=True,text=True,encoding='utf-8');(ROOT/'git-status-end.txt').write_text(status.stdout,encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k not in ('inner_rows','development_rows')},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
