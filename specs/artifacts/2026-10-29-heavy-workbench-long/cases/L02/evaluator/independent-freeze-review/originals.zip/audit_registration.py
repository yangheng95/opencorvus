"""Independent object-level audit only; no model, matrix reader or grader run."""
from pathlib import Path
from fractions import Fraction
import json,zipfile,subprocess,re,datetime

R=Path(__file__).resolve().parent
case=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L02')
oldpath=Path('D:/opencorvus-benchmark-runs/l02-quality-study-qualification-20261030/registered-reference-originals.zip')
newpath=R/'registration-initial/registered-reference.zip'
def zread(path):
    with zipfile.ZipFile(path)as z:
        assert len(z.namelist())==len(set(z.namelist()))
        return {n:z.read(n)for n in z.namelist()}
def j(raw):return json.loads(raw)
def same(a,b):
    if type(a)is not type(b):return False
    if isinstance(a,dict):return set(a)==set(b)and all(same(a[k],b[k])for k in a)
    if isinstance(a,list):return len(a)==len(b)and all(same(x,y)for x,y in zip(a,b))
    return a==b
checks=[]
def check(name,value,detail=None):
    checks.append({'name':name,'passed':bool(value),'detail':detail})
    if not value:raise AssertionError(name)
old,new=zread(oldpath),zread(newpath)
check('registry same complete member identities',set(old)==set(new),len(old))
changed={name for name in old if old[name]!=new[name]}
allowed={'study-contract.draft.json':{'status','scope','quality_floor'},'policy-before-results.json':{'status','scope'}}
check('only the two explicit registration metadata members changed',changed==set(allowed),sorted(changed))
diffs={}
for name,keys in allowed.items():
    a,b=j(old[name]),j(new[name]);check(name+' same field set',set(a)==set(b))
    diff={k:{'old':a[k],'new':b[k]}for k in a if not same(a[k],b[k])};diffs[name]=diff
    check(name+' exact allowed typed field differences',set(diff)<=keys,sorted(diff))
    public='study-contract.json'if name.startswith('study-')else'quality-policy.json'
    check(name+' current public exact bytes',new[name]==(R/'public-initial'/public).read_bytes())
record=j((R/'registration-initial/derivation.json').read_bytes())
check('derivation reports all exact changes',same(record['changes'],diffs))
check('unchanged member count matches real bytes',record['unchanged_member_count']==sum(old[n]==new[n]for n in old)==95)
check('unchanged members list enumerates exactly original evidence',set(record['unchanged_archive_members'])==set(old)-changed)
source=zread(R/'registration-initial/registration-source-objects.zip')
for key,member in [('study-contract.json','study-contract.draft.json'),('quality-policy.json','policy-before-results.json')]:
    check('preserved old metadata '+key,source['old/'+key]==old[member])
    check('captured current metadata '+key,source['current/'+key]==new[member])
check('material registration remains identical',old['material-contract.json']==(R/'public-initial/material-contract.json').read_bytes())
profile=j((R/'public-initial/profile.json').read_bytes());study=j((R/'public-initial/study-contract.json').read_bytes());policy=j((R/'public-initial/quality-policy.json').read_bytes())
check('quality floor one exact reference',study['quality_floor']=={'policy':'quality-policy.json','reference_id':policy['reference_id']})
check('profile lists exact public16 once',len(profile['public_files'])==len(set(profile['public_files']))==16 and set(profile['public_files'])=={p.name for p in(R/'public-initial').iterdir()})
check('profile resource policies remain null',all(profile['resources'][k]is None for k in ['minimum_runtime','user_total_wall_limit','user_total_token_limit']))
# Direct immutable original assignment evidence, not mutable source digests.
actual=zread(Path('D:/opencorvus-benchmark-runs/l02-scientific-reference-full-review-20261030/assignment.zip'))
check('unchanged parent registry is actual original assigned object',actual['reference.zip']==oldpath.read_bytes())
oldrub=j(actual['rubric.json']);rub=j((R/'rubric-initial.json').read_bytes())
oldcriteria=[x for g in oldrub['groups']for x in g['criteria']];criteria=[x for g in rub['groups']for x in g['criteria']]
sem=lambda row:{k:v for k,v in row.items()if k!='readiness'}
check('all66 original rule method anchor weight flags exact',same([sem(x)for x in oldcriteria],[sem(x)for x in criteria]))
check('publication comparison unchanged',same(oldrub['publication'],rub['publication']))
check('fixed100 denominator',sum(Fraction(x['weight'])for x in criteria)==100)
check('Q26 all critical same 15 weight',len([x for x in criteria if x['quality']])==26 and all(x['critical']for x in criteria if x['quality'])and sum(Fraction(x['weight'])for x in criteria if x['quality'])==15)
check('38 review + 2 original execution source rules',len([x for x in criteria if x['method']=='independent_evaluator_review'])==38 and len([x for x in criteria if x['method']=='registered_execution_checker'])==2)
check('current draft has seven readiness false',rub['status']=='draft'and len(rub['readiness'])==7 and all(v is False for v in rub['readiness'].values()))
forecasts=[n for n in new if n.startswith('reference/')and n.endswith('/forecast.json')]
check('12 original reference1008 cells all preserved',len(forecasts)==12 and sum(len(j(new[n])['forecasts'])for n in forecasts)==1008 and all(new[n]==old[n]for n in forecasts))
gitpath='specs/artifacts/2026-10-29-heavy-workbench-long/cases/L02/public/development-materials.zip'
p=subprocess.run(['git','show','5b445d92b:'+gitpath],cwd='D:/myhexin-local/opencorvus',capture_output=True)
check('development archive unchanged from actual formal source commit',p.returncode==0 and p.stdout==(R/'public-initial/development-materials.zip').read_bytes())
links=[]
for p in(R/'public-initial').glob('*.md'):
    for raw in re.findall(r'\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
        if '://'in raw:continue
        target=raw.split('#')[0]
        if target:links.append({'from':p.name,'target':target,'exists':(p.parent/target).is_file()})
check('local public markdown targets resolve',all(v['exists']for v in links),links)
result={'checks':checks,'all_passed':all(x['passed']for x in checks),'registry_evidence_members':95,'fixed_reference_cells':1008,'new_prediction_solver_reader_calls':0,
 'scope':'object/metadata/criterion/public links only, no repeat of original full scientific/numerical audit'}
(R/'registration-audit.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'checks':len(checks),'all_passed':result['all_passed'],'original_evidence_preserved':95,'fixed_reference_cells':1008}))
