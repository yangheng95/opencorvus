"""A closed-form wire-only selector probe, no forecast execution or reader."""
import json,sys
from pathlib import Path
R=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'source-initial'))
from l02_selection import choose,assess_selection
study=json.loads((R/'public-initial/study-contract.json').read_text(encoding='utf-8'))
ids=['a','b'];frames=[]
quantiles=study['quantiles']
for i in range(3):
    origin=i+1;targets=list(range(100+14*i,114+14*i))
    context={'format':'l02-score-context/1','origin_tick':origin,'target_ticks':targets,
        'series_catalogue':[{'series_id':'A','kind':'leaf'},{'series_id':'Z','kind':'aggregate'}],
        'hierarchy':[{'parent':'Z','child':'A','weight':1}],'scales_litres':{'A':'1','Z':'1'}}
    labels=[{'series_id':s,'target_tick':t,'value':0}for s in ['A','Z']for t in targets]
    forecasts={m:{'format':'l02-distribution-forecasts/1','method_id':m,'origin_tick':origin,
        'forecasts':[{'series_id':s,'target_tick':t,'mean':0,'quantiles':{q:0 for q in quantiles}}for s in ['A','Z']for t in targets]}for m in ids}
    frames.append({'origin_id':'closed-inner-'+str(i),'context':context,'labels':labels,'labels_released_at':999,'forecasts':forecasts})
payload={'format':'l02-inner-selection-packet/1','outer_origin_tick':1000,'inner_ids':[f['origin_id']for f in frames],'selection_ids':ids,'frames':frames}
correct=choose(payload,study);actual={**correct,'method_mean_inner_scaled_mse':{'a':False,'b':False}}
(R/'selection-bool-payload.json').write_text(json.dumps(payload,indent=2)+'\n',encoding='utf-8')
(R/'selection-bool-output.json').write_text(json.dumps(actual,indent=2)+'\n',encoding='utf-8')
result={'control_expected':correct,'well_typed_result':assess_selection(correct,payload,study),'bool_wire_result':assess_selection(actual,payload,study),
    'scope':'closed wire-only protocol control, not a real forecast, quality, or candidate score'}
(R/'selection-bool-receipt.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result))
