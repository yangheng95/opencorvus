"""Repeat original two boolean wire cases and equivalent rational strings only."""
from pathlib import Path
import sys,json,shutil,difflib
R=Path(__file__).resolve().parent
SRC=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L02/evaluator/current-source')
out=R/'type-repaired';out.mkdir();source=out/'source';source.mkdir()
for path in SRC.glob('*.py'):shutil.copy2(path,source/path.name)
(out/'l02_selection.diff').write_text(''.join(difflib.unified_diff((R/'source-initial/l02_selection.py').read_text().splitlines(True),(source/'l02_selection.py').read_text().splitlines(True),fromfile='initial',tofile='repaired')),encoding='utf-8')
sys.path.insert(0,str(source))
from l02_selection import assess_selection
from l02_pipeline import candidate_assessment
from l02_execution import ExecutionError
study=json.loads((R/'public-initial/study-contract.json').read_text(encoding='utf-8'))
checks=[]
for name in ['selection-bool','selection-bool-one']:
    payload=json.loads((R/(name+'-payload.json')).read_text(encoding='utf-8'))
    actual=json.loads((R/(name+'-output.json')).read_text(encoding='utf-8'))
    try:candidate_assessment(lambda:assess_selection(actual,payload,study))
    except ExecutionError as error:
        check={'name':name+' maps explicit candidate error','passed':error.code=='selection_invalid'and error.candidate is True,'code':error.code,'candidate':error.candidate}
    else:check={'name':name+' typed error','passed':False}
    checks.append(check);assert check['passed']
    value='2/2'if name.endswith('one')else'0/7'
    actual['method_mean_inner_scaled_mse']={key:value for key in actual['method_mean_inner_scaled_mse']}
    verified=candidate_assessment(lambda:assess_selection(actual,payload,study))
    checks.append({'name':name+' exact equivalent nonminimal rational','passed':verified['status']=='selection_verified','status':verified['status']})
    assert checks[-1]['passed']
(out/'assessment.json').write_text(json.dumps({'checks':checks,'all_passed':all(x['passed']for x in checks),'new_forecast_reader_Docker_calls':0,'scope':'two original closed wire controls only; not a new study/grade'},indent=2)+'\n',encoding='utf-8')
print(json.dumps({'checks':len(checks),'all_passed':all(x['passed']for x in checks)}))
