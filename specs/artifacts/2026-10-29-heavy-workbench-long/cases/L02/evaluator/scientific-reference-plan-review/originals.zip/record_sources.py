"""Read-only evidence scope for the scientific reference delivery plan."""
import json
import shutil
import subprocess
from pathlib import Path

ROOT=Path(__file__).resolve().parent
REPO=Path('D:/myhexin-local/opencorvus')
CASE=REPO/'specs/artifacts/2026-10-29-heavy-workbench-long/cases/L02'
paths=[CASE/'evaluator/current-source'/n for n in ['report_l02_reference.py','package_l02_reference.py','l02_daily_reference.py']]
paths += [CASE/'evaluator/reference-pool.json',CASE/'evaluator/REFERENCE-LITERATURE.draft.md',CASE/'rubric.draft.json']
paths += [CASE/'public'/n for n in ['RESEARCH-DELIVERY.draft.md','REVIEW-ANCHORS.draft.md','STUDY-CONTRACT.draft.md','MATERIALS.draft.md']]
paths += [CASE/'evaluator/qualification/quality-study/research-analysis/RESEARCH.md',REPO/'specs/records/2026-10/2026-10-30-heavy-workbench-l02-qualification.md']
out=ROOT/'source-reviewed';out.mkdir(exist_ok=False)
items=[]
for source in paths:
    relative=source.relative_to(REPO);target=out/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
    items.append({'path':str(source),'snapshot':str(target.relative_to(ROOT)),'bytes':source.stat().st_size})
(ROOT/'source-inventory.json').write_text(json.dumps(items,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
status=subprocess.run(['git','status','--short'],cwd=REPO,capture_output=True,text=True,encoding='utf-8')
(ROOT/'git-status-observed.txt').write_text(status.stdout,encoding='utf-8')
print(json.dumps({'sources':len(items),'kind':'design source inventory only','new_experiments':0,'repo_modified':False},ensure_ascii=False))
