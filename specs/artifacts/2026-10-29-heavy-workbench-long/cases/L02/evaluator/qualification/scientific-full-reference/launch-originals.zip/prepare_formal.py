"""Export one committed author reference, without previous numerical outputs."""
from datetime import datetime,timezone
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile

ROOT=Path(__file__).resolve().parent
REPO=Path('D:/myhexin-local/opencorvus')
BASE='specs/artifacts/2026-10-29-heavy-workbench-long/cases/L02/evaluator/'
commit=subprocess.check_output(['git','rev-parse','5b445d92b'],cwd=REPO,text=True).strip()
data=subprocess.check_output(['git','archive',commit,BASE+'current-source',BASE+'material-contract.json',BASE+'study-contract.draft.json',BASE+'reference-pool.json'],cwd=REPO)
(ROOT/'frozen-origin.tar').write_bytes(data)
source=ROOT/'frozen-source';source.mkdir(exist_ok=False)
with tarfile.open(fileobj=io.BytesIO(data)) as archive:
    for member in archive.getmembers():
        if not member.isfile():continue
        if member.name.startswith(BASE+'current-source/'):
            target=source/member.name[len(BASE+'current-source/'):]
        else:
            name=member.name[len(BASE):]
            target=ROOT/('study-contract.json' if name=='study-contract.draft.json' else name)
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(archive.extractfile(member).read())
command=[sys.executable,'-X','utf8','-B',str(source/'package_l02_reference.py'),'--pool',str(ROOT/'reference-pool.json'),'--out',str(ROOT/'submission')]
p=subprocess.run(command,cwd=ROOT,capture_output=True,text=True,encoding='utf-8')
(ROOT/'formal-package-command.json').write_text(json.dumps({'argv':command,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr},indent=2),encoding='utf-8')
if p.returncode:raise SystemExit(p.returncode)
sys.path.insert(0,str(source))
from run_l02_study import validate_submission
manifest,objects=validate_submission(ROOT/'submission')
declared=sorted({n for program in manifest['programs'].values() for n in program['files']})
checks=[{'file':name,'same_committed_programme_object':objects[name]==(source/name).read_bytes()} for name in declared]
if not all(c['same_committed_programme_object'] for c in checks):raise ValueError('formal_package_committed_binding_invalid')
launch={'source_commit':commit,'prepared_at':datetime.now(timezone.utc).isoformat(),'checks':checks,
    'assignment':'formal_full_assignment','subject_role':'reference_qualification','run_root':str(ROOT/'formal-run'),
    'expected_forecasts':108,'expected_selectors':12,'expected_reports':1,
    'image':'sha256:23ff8bfbf8055caa0b9fa5745ddb27cceea2f31d7d15b7a900c81112cdfe8ddf',
    'scope':'new source-only raw-to-report author qualification; no old forecasts, fitted models or private quality reference in any programme',
    'total_time_cap':None,'candidate_hour_evidence':False}
(ROOT/'launch.json').write_text(json.dumps(launch,indent=2),encoding='utf-8')
print(json.dumps({'prepared':True,'source_commit':commit,'declared_programme_files':len(declared),'native_started':0}))
