from pathlib import Path

original=Path(__file__).with_name('render_reference.py').read_text(encoding='utf-8')
assert "job=root/'render-job'" in original
updated=original.replace("job=root/'render-job'","job=root/'render-color-repair'")
exec(compile(updated,__file__,'exec'))
