import json
from pathlib import Path
import shutil
import sys

root=Path(__file__).parent/'main/full-reference-summary';job=root/'render-job';job.mkdir()
source=job/'source';source.mkdir();input_root=job/'input';input_root.mkdir()
current=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L02/evaluator/current-source')
shutil.copyfile(current/'plot_l02_study.py',source/'plot_l02_study.py');shutil.copyfile(root/'plot-input.json',input_root/'plot-input.json')
sys.path.insert(0,str(current));from run_l02_study import run_numeric
def event(kind,detail):
 with (job/'events.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(dict(kind=kind,**detail))+'\n')
run_numeric(source,input_root,job/'output','plot_l02_study.py',['--input','/input/plot-input.json','--out','/output/figures'],'sha256:23ff8bfbf8055caa0b9fa5745ddb27cceea2f31d7d15b7a900c81112cdfe8ddf',event)
print((job/'output/figures/render.json').read_text())
