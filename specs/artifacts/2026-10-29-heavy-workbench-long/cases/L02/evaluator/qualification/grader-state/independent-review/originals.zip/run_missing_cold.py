"""One authorized real missing-output control: one native process, no forecast fitting."""
import json
import shutil
import sqlite3
import subprocess
import sys
import time
import zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parent
REPO=Path('D:/myhexin-local/opencorvus')
SRC=REPO/'specs/artifacts/2026-10-29-heavy-workbench-long/cases/L02/evaluator/current-source'
Q=Path('D:/opencorvus-benchmark-runs/l02-grader-state-qualification-20261030')
ROOT.mkdir(exist_ok=True)
snapshot=ROOT/'source-executed';snapshot.mkdir(exist_ok=False)
for p in SRC.glob('*.py'):shutil.copy2(p,snapshot/p.name)
sys.path.insert(0,str(snapshot))
from l02_execution import read_archive,json_bytes
from l02_study_data import extract_data
from l02_sealed import inspect_run

def save(path,value):path.write_bytes(json_bytes(value))

case=ROOT/'missing-forecast';case.mkdir()
submission=case/'submission';shutil.copytree(Q/'bad-json/submission',submission)
manifest=json.loads((submission/'submission.json').read_text(encoding='utf-8'))
manifest['programs']['predict']={'files':['missing.py'],'argv':['/opt/cpsat/bin/python','missing.py']}
(submission/'missing.py').write_text("print('deliberate missing-forecast control; no scientific prediction',flush=True)\n",encoding='utf-8')
save(submission/'submission.json',manifest)
old=Path('D:/opencorvus-benchmark-runs/l02-generic-execution-qualification-20261030/python-loop')
extract_data(read_archive(old/'registration.zip'),case/'authority')
argv=[sys.executable,'-X','utf8','-B',str(snapshot/'run_l02_study.py'),'--submission',str(submission),
      '--raw',str(case/'authority/raw'),'--material-contract',str(case/'authority/material-contract.json'),
      '--study',str(case/'authority/study.json'),'--out',str(case/'run'),'--image',
      'sha256:23ff8bfbf8055caa0b9fa5745ddb27cceea2f31d7d15b7a900c81112cdfe8ddf']
start=time.perf_counter();p=subprocess.run(argv,capture_output=True,text=True,encoding='utf-8')
save(case/'driver-command.json',{'argv':argv,'exitcode':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'seconds':time.perf_counter()-start})
start=time.perf_counter();inspection=inspect_run(case/'run');save(case/'inspection.json',inspection['summary'])
save(case/'inspection-receipt.json',{'kind':'actual inspect_run on own newly captured original objects','seconds':time.perf_counter()-start})
with sqlite3.connect((case/'run/runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
    db.row_factory=sqlite3.Row;rows=[dict(r)for r in db.execute('select * from cell')]
job=case/'run/cells/1';terminal=read_archive(job/'terminal.zip');native=json.loads(terminal['terminal-inspect.json'])
commands=[json.loads(p.read_text(encoding='utf-8'))for p in job.glob('*.json')]
operations={name:[r for r in commands if r['argv'][1:2]==[name]]for name in ('create','start','rm')}
facts={'scope':'one deliberate missing artifact control, full formal registration but zero scientific forecasts',
    'driver_exit':p.returncode,'native':native,'ledger_cells':rows,'summary':inspection['summary'],
    'operations':operations,'actual_output_members':[n for n in terminal if n.startswith('output/')],
    'candidate_score':None,'new_native_processes':1,'scientific_forecasts_executed':0}
save(case/'actual-facts.json',facts)
print(json.dumps({'driver_exit':p.returncode,'CID':native['Id'],'native_exit':native['State']['ExitCode'],
 'state':native['State']['Status'],'expected':inspection['summary']['expected_cells'],
 'counts':inspection['summary']['counts'],'first':inspection['summary']['cells'][0],
 'operations':{k:len(v)for k,v in operations.items()},'candidate_score':None},ensure_ascii=False))
