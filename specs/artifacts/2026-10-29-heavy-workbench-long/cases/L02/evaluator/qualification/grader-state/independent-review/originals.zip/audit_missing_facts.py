"""Independent scalar/raw/native checks of the sole new original; no executor."""
import csv
import io
import json
import zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parent
CASE=ROOT/'missing-forecast'
def load(path):return json.loads(path.read_text(encoding='utf-8'))
facts=load(CASE/'actual-facts.json');summary=facts['summary'];native=facts['native']
with zipfile.ZipFile(CASE/'run/registration.zip') as z:
    reg=json.loads(z.read('registration.json'));manifest=json.loads(z.read('submission/submission.json'))
    raw=list(csv.DictReader(io.StringIO(z.read('raw/origins.csv').decode('utf-8'))))
    frozen_source=z.read('submission/missing.py')
with zipfile.ZipFile(CASE/'run/cells/1/prepared.zip') as z:
    captured_source=z.read('project/missing.py')
expected=[]
for outer in reg['outer_ids']:
    for row in raw:
        if row['role']=='inner'and row['outer_id']==outer:
            expected += [dict(kind='predict',outer_id=outer,origin_id=row['origin_id'],method_id=m,level='inner')for m in manifest['pool']['selection_ids']]
    expected.append(dict(kind='select',outer_id=outer))
    expected += [dict(kind='predict',outer_id=outer,origin_id=outer,method_id=m,level='outer')for m in manifest['pool']['outer_ids']]
expected.append(dict(kind='report'))
key=lambda d:json.dumps(d,sort_keys=True)
checks=[]
def ck(name,ok):checks.append({'name':name,'passed':bool(ok)})
ck('formal_12_registered_raw_origins',reg['assignment_kind']=='formal_full_assignment'and len(reg['outer_ids'])==12 and set(reg['outer_ids'])=={r['origin_id']for r in raw if r['role']=='outer'})
ck('complete_121_identity_set_from_original_raw_and_pool',len(expected)==121 and {key(i)for i in expected}=={key(v['identity'])for v in summary['cells']})
first=summary['cells'][0];ck('missing_artifact_named_candidate_incomplete',first['outcome']=='candidate_failed'and first['reason']=='candidate_output_missing'and first['candidate_state']=='candidate_incomplete'and first['native_exit']==0)
failed=key(first['identity']);blocked=[c for c in summary['cells']if c['outcome']=='blocked_candidate'];unassessed=[c for c in summary['cells']if c['outcome']=='unassessed']
ck('two_genuine_dependency_nodes',len(blocked)==2 and {c['identity']['kind']for c in blocked}=={'select','report'}and all(any(key(d)==failed for d in c['dependencies'])for c in blocked))
ck('all_other_independent_forecasts_unassessed',all(c['outcome']=='unassessed'for c in summary['cells']if c['identity']['kind']=='predict'and key(c['identity'])!=failed))
ck('118_unassessed_full_denominator_retained',len(unassessed)==118 and summary['expected_cells']==121 and summary['candidate_score']is None and summary['aggregate_exact']is None)
ck('actual_source_frozen_and_executed',frozen_source==captured_source==(CASE/'submission/missing.py').read_bytes()and native['Path']=='/opt/cpsat/bin/python'and native['Args']==['missing.py'])
ck('actual_native_exited_zero',native['State']['Status']=='exited'and native['State']['ExitCode']==0 and native['State']['OOMKilled']is False)
ck('actual_readonly_networknone_1CPU',native['HostConfig']['ReadonlyRootfs']is True and native['HostConfig']['NetworkMode']=='none'and native['HostConfig']['NanoCpus']==1000000000 and {m['Destination']:m['RW']for m in native['Mounts']}=={'/project':False,'/input':False,'/output':True})
ops=facts['operations'];cid=native['Id']
ck('one_owned_create_start_rm_same_CID',all(len(ops[k])==1 and ops[k][0]['exitcode']==0 for k in ['create','start','rm'])and ops['create'][0]['stdout'].strip()==cid and ops['start'][0]['argv']==['docker','start',cid]and ops['rm'][0]['argv']==['docker','rm',cid])
result={'checks':checks,'all_passed':all(x['passed']for x in checks),'scope':'independent raw and scalar/native checks; zero new execution','new_Docker_processes':0,'candidate_score':None}
(ROOT/'missing-facts-assessment.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'checks':len(checks),'all_passed':result['all_passed']},ensure_ascii=False))
