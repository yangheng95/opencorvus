print('deliberate missing-forecast control; no scientific prediction',flush=True)
