import json,sys
print(json.dumps({'status':'run_invalid','error':'candidate_self_label'}),flush=True)
sys.exit(2)
