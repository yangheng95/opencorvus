"""A real formal registration that stops at its first deliberately bad predictor."""
import argparse
from pathlib import Path
import json
import shutil
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--mode',choices=['bad-json','native-two'],required=True);a=parser.parse_args()
source=ROOT/'source-partial-current';sys.path.insert(0,str(source))
from l02_execution import read_archive,atomic_bytes,json_bytes
from l02_study_data import extract_data
from package_l02_reference import package
from l02_sealed import inspect_run

case=ROOT/a.mode;case.mkdir();submission=case/'submission'
pool=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L02/evaluator/reference-pool.json')
package(pool,submission)
manifest=json.loads((submission/'submission.json').read_text())
manifest['programs']['predict']={'files':['bad.py'],'argv':['/opt/cpsat/bin/python','bad.py']}
if a.mode=='bad-json':
    programme="from pathlib import Path\np=Path('/output/result');p.mkdir()\n(p/'forecast.json').write_text('{bad JSON')\n"
else:
    programme="import json,sys\nprint(json.dumps({'status':'run_invalid','error':'candidate_self_label'}),flush=True)\nsys.exit(2)\n"
(submission/'bad.py').write_text(programme,encoding='utf-8')
(submission/'submission.json').write_text(json.dumps(manifest),encoding='utf-8')
old=Path('D:/opencorvus-benchmark-runs/l02-generic-execution-qualification-20261030/python-loop')
extract_data(read_archive(old/'registration.zip'),case/'authority')
argv=[sys.executable,'-X','utf8','-B',str(source/'run_l02_study.py'),
    '--submission',str(submission),'--raw',str(case/'authority/raw'),
    '--material-contract',str(case/'authority/material-contract.json'),'--study',str(case/'authority/study.json'),
    '--out',str(case/'run'),'--image','sha256:23ff8bfbf8055caa0b9fa5745ddb27cceea2f31d7d15b7a900c81112cdfe8ddf']
start=time.perf_counter();p=subprocess.run(argv,capture_output=True,text=True,encoding='utf-8')
atomic_bytes(case/'command.json',json_bytes({'argv':argv,'exitcode':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'wall_seconds':time.perf_counter()-start}))
inspection=inspect_run(case/'run');atomic_bytes(case/'inspection.json',json_bytes(inspection['summary']))
atomic_bytes(case/'assessment.json',json_bytes({'candidate_driver_exitcode':p.returncode,'summary':inspection['summary'],
    'scope':'one real deliberately bad forecast process under full formal registration; no good scientific reference or hours evidence'}))
print(json.dumps({'mode':a.mode,'driver_exit':p.returncode,'driver_output':p.stdout,'inspection_status':inspection['summary']['status'],
    'counts':inspection['summary']['counts'],'formal':inspection['summary']['formal_full_assignment'],
    'expected_cells':inspection['summary']['expected_cells'],'scope':'one native forecast, remaining independent units unassessed'}))
