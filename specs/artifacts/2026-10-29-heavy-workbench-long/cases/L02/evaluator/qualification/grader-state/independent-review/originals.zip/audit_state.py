"""One read-only old complete reconstruction plus existing-object protocol mutations."""
import json
import shutil
import sqlite3
import subprocess
import sys
import time
import zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parent
SRC=ROOT/'source-executed'
Q=Path('D:/opencorvus-benchmark-runs/l02-grader-state-qualification-20261030')
OLD=Path('D:/opencorvus-benchmark-runs/l02-generic-execution-qualification-20261030/python-loop')
sys.path.insert(0,str(SRC))
from l02_execution import read_archive,json_bytes,bound_execution
from l02_sealed import read_completed

OUT=ROOT/'audit';OUT.mkdir(exist_ok=False)
def save(path,value):path.write_bytes(json_bytes(value))
def load(path):return json.loads(path.read_text(encoding='utf-8'))
checks=[]
def ck(name,value,details=None):checks.append({'name':name,'passed':bool(value),'details':details})
def canonical_files(run):
    paths=[run/'registration.zip',run/'runs.sqlite3',*run.glob('cells/*/prepared.zip'),*run.glob('cells/*/terminal.zip'),*run.glob('cells/*/accepted.zip')]
    return {str(p.relative_to(run)):p.read_bytes()for p in paths}
def copy_canonical(run,dest):
    dest.mkdir()
    for name,value in canonical_files(run).items():
        p=dest/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(value)
def cli(run,name):
    argv=[sys.executable,'-X','utf8','-B',str(SRC/'summarize_l02_study.py'),'--run',str(run),'--out',str(OUT/(name+'-result'))]
    start=time.perf_counter();p=subprocess.run(argv,capture_output=True,text=True,encoding='utf-8')
    result={'argv':argv,'exitcode':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'seconds':time.perf_counter()-start}
    save(OUT/(name+'-command.json'),result)
    assessment=OUT/(name+'-result/assessment.json')
    return result,load(assessment)if assessment.exists()else None

# No native process is started by this script. Observe the parent's two originals.
parent=[]
for mode,expected_exit,expected_reason in [('bad-json',0,'candidate_output_invalid'),('native-two',2,'candidate_program_failed')]:
    run=Q/mode/'run';db=sqlite3.connect((run/'runs.sqlite3').as_uri()+'?mode=ro',uri=True);db.row_factory=sqlite3.Row
    row=dict(db.execute('select * from cell').fetchone());run_id=db.execute('select id from run').fetchone()[0];db.close()
    reg=read_archive(run/'registration.zip');registration=json.loads(reg['registration.json']);manifest=json.loads(reg['submission/submission.json'])
    identity=json.loads(row['identity']);declaration=manifest['programs'][identity['kind']]
    row['objects']={k:read_archive(run/'cells/1'/ (k+'.zip'))for k in ['prepared','terminal']}
    record=bound_execution(row,identity,declaration,{n:reg['submission/'+n]for n in declaration['files']},registration['image_id'],run_id)
    original=load(Q/mode/'inspection.json');commands=[load(p)for p in(run/'cells/1').glob('*.json')]
    counts={op:sum(c['argv'][1:2]==[op]for c in commands)for op in ['create','start','rm']}
    fact={'mode':mode,'native':record['native'],'row':{k:v for k,v in row.items()if k!='objects'},'inspection':original,'counts':counts}
    save(OUT/(mode+'-original-facts.json'),fact);parent.append(fact)
    ck(mode+'_native_and_typed_original',record['native']['State']['ExitCode']==expected_exit and json.loads(row['failure'])['code']==expected_reason and original['cells'][0]['reason']==expected_reason)
    ck(mode+'_expected_and_independence',original['formal_full_assignment']is True and original['expected_cells']==121 and original['counts']=={'verified':0,'candidate_failed':1,'blocked_candidate':2,'unassessed':118,'facility_error':0})
    ck(mode+'_one_original_native_lifecycle',counts=={'create':1,'start':1,'rm':1})

# Exactly one authorized pure read of the old fully verified request with the new reader.
before=canonical_files(OLD);start=time.perf_counter();summary,numerical=read_completed(OLD);seconds=time.perf_counter()-start
save(OUT/'old-complete-summary.json',summary);save(OUT/'old-complete-numerical.json',numerical)
save(OUT/'old-reader-receipt.json',{'call':'read_completed(original python-loop)','seconds':seconds,'new_native_processes':0})
ck('old_requested_complete_11_verified',summary['status']=='sealed_requested_matrix_recomputed'and summary['expected_cells']==11 and summary['verified_cells']==11 and summary['forecast_cells']==9)
ck('old_private_diagnostic_keeps_formal_false',summary['formal_full_assignment']is False)
ck('old_actual_report_not_delivered',summary['report_provenance']['status']=='not_delivered')
ck('old_canonical_artifacts_and_DB_unchanged',before==canonical_files(OLD))

# Protocol mutations of actual originals; no mutated object is a real candidate outcome.
valid_failed=OUT/'mutation-valid-output-failed';copy_canonical(OLD,valid_failed)
with sqlite3.connect(valid_failed/'runs.sqlite3')as db:
    db.execute('update cell set phase=?, failure=? where id=1',('failed',json.dumps({'code':'candidate_output_invalid','detail':'reviewer mutation of evaluator ledger only'})))
(valid_failed/'cells/1/accepted.zip').unlink()
command,assessment=cli(valid_failed,'valid-output-failed')
ck('valid_output_failed_mutation_facility',command['exitcode']==3 and assessment['status']=='run_invalid'and any(f.get('reason')=='facility_failed_outcome_contradiction'for f in assessment['facility_findings']))

wrong_reason=OUT/'mutation-nonzero-code-with-zero-exit';copy_canonical(Q/'bad-json/run',wrong_reason)
with sqlite3.connect(wrong_reason/'runs.sqlite3')as db:
    db.execute('update cell set failure=? where id=1',(json.dumps({'code':'candidate_program_failed','detail':'reviewer mutation: claims nonzero native failure although captured native exit0'}),))
command,assessment=cli(wrong_reason,'contradictory-native-reason')
ck('contradictory_native_failure_code_maps_facility',command['exitcode']==3 and assessment['status']=='run_invalid'and any(f.get('reason')=='facility_failed_outcome_contradiction'for f in assessment.get('facility_findings',[])),{'actual_exit':command['exitcode'],'actual_status':None if assessment is None else assessment['status'],'actual_first':None if assessment is None else assessment['cells'][0]})

save(OUT/'checks.json',checks)
result={'checks':len(checks),'all_passed':all(c['passed']for c in checks),'failed':[c['name']for c in checks if not c['passed']],
 'old_reader_seconds':seconds,'new_native_processes':0,'mutations_are_synthetic_evaluator_protocol_controls':True,'candidate_score':None,'scope':'state/original-object classification only'}
save(OUT/'assessment.json',result);print(json.dumps(result,ensure_ascii=False))
