from pathlib import Path
p=Path('/output/result');p.mkdir()
(p/'forecast.json').write_text('{bad JSON')
