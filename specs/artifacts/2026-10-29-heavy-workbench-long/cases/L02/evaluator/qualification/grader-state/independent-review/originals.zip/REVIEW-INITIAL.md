# L02 归因与 partial reader：独立实审初结论

当前有 **1 项状态完整性阻断 B01**，未批准本状态组件收敛。合法缺输出、主方两种真实失败、旧完整请求及“合法输出却标 failed”路径的必要观察均符合预期；另一个仅评估端 ledger mutation 暴露原失败归因与 native 矛盾未被拒绝。没有科学预测、完整矩阵或模型运行。

本次为熟悉既有参考的非盲 AI-agent 组件审查，未再次委托；主仓只读。唯一新增 native 是明确故意缺交的微程序，且只有首次 forecast 位置执行。所有评估端 mutation 仅在自有新目录复制原 capsule 后改 ledger，原件保持不动。

## B01：原 failure 声称非零退出，实际 native0 仍被当作候选输出失败

最小真实协议控制位于 `audit/mutation-nonzero-code-with-zero-exit/`：从主方 `bad-json/run` 的真实正式 registration/prepared/terminal/SQLite 复制，不变原 source/input/坏 JSON/native exit0。只把副本 `cell.failure` 改为：

```json
{"code":"candidate_program_failed","detail":"reviewer mutation: claims nonzero native failure although captured native exit0"}
```

实际进入当前唯一 `summarize_l02_study.py` CLI；命令和 stdout/stderr 在 `audit/contradictory-native-reason-command.json`，真实结果在 `audit/contradictory-native-reason-result/assessment.json`。CLI **exit4/assessment_incomplete**，首格是 `candidate_failed/candidate_output_invalid`，facility_findings 为空。应当将原 host “程序非零”记录与 captured native0 的矛盾判为 `facility_failed_outcome_contradiction/run_invalid`，不能在互相矛盾的评估事实之间静默选择另一种候选归因。

源码根因在 `source-executed/l02_sealed.py`：非零 native 分支核 failure.code，但 native0 的 `check(terminal)` 抛 typed candidate error 后直接输出 candidate_failed，未将该真实原因和原持久 failure.code 对照；`invalid-output.json` 分支也须同语义审查。`bound_execution` 已核 failure 的生命周期关系，但不足以核具体原归因。

建议在唯一 failed 路径闭合：真实非零只允许已登记 candidate_program_failed；native0 的实际 typed 输出错误与原已持久错误不符则设施矛盾。错误 detail 中临时路径或包装文本无需逐字相等，避免将无关诊断文本当功能门；typed 原因必须一致。保留旧原件，不改真实 candidate code/output、不新增 alias/fallback。修后只需重放这个副本 CLI 加必要原合法失败控制，不能再启动 native 或重跑旧完整请求。

这是 evaluator 证据完整性反例，不是真实候选自己改了 ledger，也不说明坏 JSON 是正确答案；所证明的是当前 reader 没按其源完整性合同拒绝冲突的原判定。

## 唯一新增真实冷控制：缺 forecast 文件

实际 source-only 命令在 `missing-forecast/driver-command.json`，源码快照 `source-executed/`；候选 predict 微程序仅打印明确控制标识，返回0，故意不交 forecast。原 frozen authority 从既有 registration 提取；正式入口没有 author-diagnostic 参数，原注册包含全部12outer。select/report 的冻结原声明保留但未执行，不把它们当已完成或科学成果。

实际 CID：`b03ff24e4d1a0a1c108d0d08d3a9bc019bf17fb90e639d324fc18c3863a9cf06`。native 自然 exited/0，driver exit2，错误 `candidate_output_missing`；inspection 首格 `candidate_failed`、叶级 `candidate_state=candidate_incomplete`。共121 expected：0verified、1candidate_failed、2blocked_candidate、118unassessed；aggregate/score 为 null，科学 forecast 数为0。

driver host 耗时14.510841秒；整个控制含后续 inspection 的包装耗时22.452519秒。原 native 精确 StartedAt/FinishedAt 保存在 `missing-forecast/actual-facts.json`。真实 inspect 核 netnone、1CPU、rootfs/project/input 只读、新 output；create/start/rm 各一次且绑定同 CID，先原 terminal 封存后 cleanup。没有第二个新 Docker 程序。

我独立从 registration 原 CSV origins 与 pool 构造 identities 核121集合，核实际源码封存/argv/native、两真依赖、其它独立 forecast 未调度、118未评和同 CID cleanup，10项纯事实检查通过（`missing-facts-assessment.json`）。它不是完整题执行。

## 主方原件和唯一旧请求只读重建

- 主方 bad-json：原 native0/typed candidate_output_invalid；native-two：原 native2，stdout 自称 run_invalid 仍按 candidate_program_failed。只读原 SQLite、terminal、实际 create/start/rm 并以当前 shared bound_execution 核身份；两者121 expected和1/2/118边界一致，没有重跑这两控制。
- 只调用一次新 `read_completed` 重建原 `python-loop` 的完整请求，耗时54.455878秒，expected=11/verified=11、9forecast，原 diagnostic 保 formal=false，原 report 来源 not_delivered；canonical DB/registration/prepared/terminal/accepted 的实际字节前后相同。未重新预测或补造旧报告来源。结果在 `audit/old-complete-summary.json`、`old-complete-numerical.json` 和 `old-reader-receipt.json`。
- 另一协议 mutation：只复制该旧 L02 registration 与 canonical 原件，将第一格评估端 row 改 failed/candidate_output_invalid 并去掉副本 accepted，使其拥有原合法 source/input/terminal/output。实际 CLI 正确给 `facility_failed_outcome_contradiction/run_invalid`（`audit/valid-output-failed-command.json`）。没有给旧 generic record 场景事后伪造 L02 registration。

`audit/assessment.json` 为12项观察，11过、B01一项失败；脚本 exit0 只说明观察脚本完成，不是 all_pass。原 stdout/JSON/失败断言内容完整保留。10项新缺交事实与12项观察不相加为独立样本或端到端次数。

## 已读实现与未认证边界

短 OS owner lock 捕获原 DB/capsule 后释放；同一 reader 供完整/partial，read_completed 只是要求完整；source/input/native/sandbox 身份在成功/失败前共用；prepared/terminal/accepted 的闭合、phase/cid/failure关系已读。selector 包构造与完整 assembler 共用；独立预测无 selector/其它预测依赖，只有 selector 的完整 inner 与 report 的全部 numeric 是实际依赖。未知 host异常的 typed 设施修复、candidate_text/json 的明确边界已读，未重做主方 host fault 原 native。

OOM、signal-style退出、外部终止目前是保守待调查规则，没有这类真实新场景资格；本审查不称全部资源/终止归因已覆盖。B01修复前组件仍阻断。完整 grader、reference/review版本绑定、40叶锚点/校准、新formal完整参考、case冻结、职业专家/统计成熟、候选小时和十题完成均未批准。
