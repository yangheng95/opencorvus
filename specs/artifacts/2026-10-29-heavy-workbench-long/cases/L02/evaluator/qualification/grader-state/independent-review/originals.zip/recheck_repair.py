"""Recheck only the original contradiction and the existing normal missing original."""
import difflib
import json
import shutil
import subprocess
import sys
import time
from pathlib import Path

ROOT=Path(__file__).resolve().parent
SRC=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L02/evaluator/current-source')
OUT=ROOT/'repair';OUT.mkdir(exist_ok=False)
snapshot=ROOT/'source-repaired';snapshot.mkdir(exist_ok=False)
identity=[];diff=[]
for p in SRC.glob('*.py'):
    shutil.copy2(p,snapshot/p.name)
    before=ROOT/'source-executed'/p.name
    same=before.exists()and before.read_bytes()==p.read_bytes()
    identity.append({'file':p.name,'bytes':p.stat().st_size,'same_as_initial_own_execution_snapshot':same})
    if before.exists()and not same:
        diff.extend(difflib.unified_diff(before.read_text(encoding='utf-8').splitlines(True),p.read_text(encoding='utf-8').splitlines(True),fromfile='initial/'+p.name,tofile='repaired/'+p.name))
(OUT/'source-identity.json').write_text(json.dumps(identity,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(OUT/'source-repaired-versus-initial.diff').write_text(''.join(diff),encoding='utf-8')
cases=[('original-contradiction',ROOT/'audit/mutation-nonzero-code-with-zero-exit',3,'run_invalid'),
       ('original-missing',ROOT/'missing-forecast/run',4,'assessment_incomplete')]
checks=[]
for name,run,expected_exit,expected_status in cases:
    argv=[sys.executable,'-X','utf8','-B',str(snapshot/'summarize_l02_study.py'),'--run',str(run),'--out',str(OUT/(name+'-result'))]
    start=time.perf_counter();p=subprocess.run(argv,capture_output=True,text=True,encoding='utf-8')
    command={'argv':argv,'exitcode':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'seconds':time.perf_counter()-start}
    (OUT/(name+'-command.json')).write_text(json.dumps(command,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    a=json.loads((OUT/(name+'-result/assessment.json')).read_text(encoding='utf-8'))
    checks.append({'name':name+'_native_cli_status','passed':p.returncode==expected_exit and a['status']==expected_status,'exitcode':p.returncode,'status':a['status']})
    if name=='original-contradiction':
        good=a['counts']=={'verified':0,'candidate_failed':0,'blocked_candidate':0,'unassessed':120,'facility_error':1}and any(f.get('reason')=='facility_failed_outcome_contradiction'for f in a['facility_findings'])
    else:
        good=a['counts']=={'verified':0,'candidate_failed':1,'blocked_candidate':2,'unassessed':118,'facility_error':0}and a['cells'][0]['reason']=='candidate_output_missing'and a['cells'][0]['candidate_state']=='candidate_incomplete'
    checks.append({'name':name+'_original_cause_and_counts','passed':good and a['candidate_score']is None})
result={'checks':checks,'all_passed':all(c['passed']for c in checks),'new_native_or_forecast_processes':0,'old_complete_repeated':False,
        'source_changes':[r['file']for r in identity if not r['same_as_initial_own_execution_snapshot']],
        'scope':'two actual Python-subprocess summary CLI replays on original copied contradiction and own original missing object; not new Docker/forecast'}
(OUT/'assessment.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
