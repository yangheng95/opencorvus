"""CLI/object-binding controls on real fail-fast runs, not candidate scores."""
import copy
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

BASE=Path(__file__).resolve().parent
ROOT=Path('D:/opencorvus-benchmark-runs/l02-source-bound-grade-qualification-20261030')
SOURCE=ROOT/'source-initial';sys.path.insert(0,str(SOURCE))
from l02_execution import atomic_bytes,json_bytes,read_archive,zip_bytes

def main():
    started=time.perf_counter();results=[]
    case=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L02')
    run=BASE/'bad-json/run';candidate=BASE/'bad-json/submission'
    reference=case/'evaluator/qualification/quality-study/registered-reference-originals.zip'
    originals=read_archive(reference)
    (ROOT/'reference-method.json').write_bytes(originals['fixed-reference-method.json'])
    def invoke(label,args,expected_exit,expected_field,expected_value):
        argv=[sys.executable,'-X','utf8','-B',str(SOURCE/'l02_grade.py'),*map(str,args)]
        p=subprocess.run(argv,capture_output=True,text=True,encoding='utf-8')
        atomic_bytes(ROOT/(label+'-command.json'),json_bytes({'argv':argv,'exitcode':p.returncode,'stdout':p.stdout,'stderr':p.stderr}))
        value=json.loads(p.stdout)
        if p.returncode!=expected_exit or value[expected_field]!=expected_value:
            raise AssertionError((label,p.returncode,value))
        results.append({'name':label,'status':'passed','exitcode':p.returncode,'response':value})
        return value
    common=['prepare','--run',run,'--candidate-root',candidate,'--rubric',case/'rubric.draft.json',
        '--quality-policy',case/'evaluator/quality-policy.draft.json','--reference',reference,
        '--reference-method',ROOT/'reference-method.json','--submission-id','state-control-real-bad-json',
        '--reviewer-id','/root/benchmark_review','--subject-role','protocol_control']
    invoke('prepare-original',common+['--out',ROOT/'evaluation'],0,'status','evaluation_assigned')
    assignment=ROOT/'evaluation/assignment.zip';files=read_archive(assignment);header=json.loads(files['assignment.json'])
    grade_args=['grade','--assignment',assignment,'--run',run]
    value=invoke('no-review',grade_args+['--out',ROOT/'without-review'],4,'status','assessment_incomplete')
    if value['counts']!={'blocked_candidate':27,'candidate_incomplete':0,'unassessed':38,'verified_fail':1,'verified_pass':0} or value['total_score'] is not None:
        raise AssertionError(value)
    review=ROOT/'review-protocol';review.mkdir();shutil.copy2(assignment,review/'assignment.zip')
    rubric=json.loads(files['rubric.json'])
    ids=[r['id'] for g in rubric['groups'] for r in g['criteria'] if r['method']=='independent_evaluator_review']
    pending={'format':'l02-independent-review/1','assignment_id':header['assignment_id'],
        'submission_id':header['submission_id'],'reviewer_id':header['reviewer_id'],'anchor_version':header['anchor_version'],
        'disclosure':{'kind':'ai-agent','blinded':False,'familiarity':'protocol fixture only','limitations':'no scientific judgement made'},
        'findings':[{'id':i,'status':'unassessed','basis':'protocol control, independent content not reviewed','sources':[],'dependency_roots':[]} for i in ids]}
    (review/'review.json').write_bytes(json_bytes(pending))
    invoke('bound-pending-review',grade_args+['--review',review,'--out',ROOT/'bound-pending'],4,'status','assessment_incomplete')
    bad=copy.deepcopy(pending);bad['submission_id']='different-submission'
    (review/'review.json').write_bytes(json_bytes(bad))
    invoke('wrong-submission',grade_args+['--review',review,'--out',ROOT/'wrong-submission'],3,'error','facility_review_binding_invalid')
    bad=copy.deepcopy(pending);bad['anchor_version']='different-anchor'
    (review/'review.json').write_bytes(json_bytes(bad))
    invoke('wrong-anchor',grade_args+['--review',review,'--out',ROOT/'wrong-anchor'],3,'error','facility_review_binding_invalid')
    bad=copy.deepcopy(pending);bad['findings'][0]['sources']=[{'object':'execution/registration.zip','member':'submission/missing.py','locator':'protocol member mutation'}]
    (review/'review.json').write_bytes(json_bytes(bad))
    invoke('wrong-member',grade_args+['--review',review,'--out',ROOT/'wrong-member'],3,'error','facility_review_source_invalid')
    (review/'review.json').write_bytes(json_bytes(pending))
    changed={**files,'assignment.json':json_bytes({**header,'assignment_id':'different-object'})}
    (review/'assignment.zip').write_bytes(zip_bytes(changed))
    invoke('different-received-object',grade_args+['--review',review,'--out',ROOT/'different-received'],3,'error','facility_review_binding_invalid')
    invoke('candidate-review-location',grade_args+['--review',candidate/'private-review','--out',ROOT/'candidate-path'],3,'error','facility_evaluation_location_invalid')
    weak=json.loads((ROOT/'reference-method.json').read_text());weak['configuration']['weekday_repeats']=1
    (ROOT/'weak-method.json').write_bytes(json_bytes(weak))
    weak_args=list(common);weak_args[weak_args.index('--reference-method')+1]=ROOT/'weak-method.json'
    invoke('bad-reference-and-candidate',weak_args+['--out',ROOT/'weak-reference'],3,'error','facility_quality_binding_invalid')
    copied=ROOT/'run-object-copy';shutil.copytree(run,copied)
    terminal_path=copied/'cells/1/terminal.zip';terminal=read_archive(terminal_path)
    terminal['output/result/forecast.json']=b'{other invalid JSON'
    terminal_path.write_bytes(zip_bytes(terminal))
    invoke('different-run-object',['grade','--assignment',assignment,'--run',copied,'--out',ROOT/'different-run'],3,'error','facility_evaluation_binding_invalid')
    result={'status':'source_bound_grade_protocol_qualified','wall_seconds':time.perf_counter()-started,
        'controls':results,'new_candidate_processes':0,'scientific_review_performed':False,
        'formal_successful_reference_run':False,'candidate_score':None,
        'scope':'real failed execution inventory and private object/review/reference binding; not full success-path or case freeze qualification'}
    atomic_bytes(ROOT/'assessment.json',json_bytes(result));print(json.dumps({'status':result['status'],'controls':len(results),'seconds':result['wall_seconds']}))

if __name__=='__main__':main()
