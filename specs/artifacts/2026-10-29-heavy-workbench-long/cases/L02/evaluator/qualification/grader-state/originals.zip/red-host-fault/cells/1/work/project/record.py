from pathlib import Path
Path('/output/result.json').write_text('{"value":7}')
