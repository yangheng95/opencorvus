"""Independent original-row/SQL/metric/process audit. Never fits a model."""
import argparse,ast,csv,json,math,re,sqlite3,time,zipfile
from collections import Counter,defaultdict
from datetime import datetime,timedelta,timezone
from decimal import Decimal
from fractions import Fraction as F
from pathlib import Path

ROOT=Path(__file__).resolve().parent
PREV=Path('D:/opencorvus-benchmark-runs/l02-full-materials-independent-review-20261030/audit_materials.py')
EPOCH=datetime(2022,1,1,tzinfo=timezone.utc)
Fraction=F
def load(p):return json.loads(p.read_text(encoding='utf-8'),parse_float=Decimal)
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2,default=str)+'\n',encoding='utf-8')
Fraction=F
source=PREV.read_text(encoding='utf-8');nodes=[n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef)and n.name in {'load','table','utc','tick','read_independently'}and n.name!='load']
exec(compile(ast.Module(body=nodes,type_ignores=[]),'reviewer_prior_csv_oracle','exec'),globals())

def score_independent(value,truth,origin,targets,catalogue,hierarchy,scales):
    ids={r['series_id']for r in catalogue};by={}
    assert value['origin_tick']==origin
    for row in value['forecasts']:
        k=row['series_id'],row['target_tick'];assert k not in by and k[0]in ids and k[1]in targets
        mean=F(row['mean']);q={F(p):F(v)for p,v in row['quantiles'].items()};assert mean>=0 and all(v>=0 for v in q.values())
        qs=sorted(q);assert qs==list(map(F,['.025','.1','.25','.5','.75','.9','.975']))and all(q[a]<=q[b]for a,b in zip(qs,qs[1:]))
        by[k]=mean,q
    assert set(by)=={(s,t)for s in ids for t in targets}
    metrics={}
    for s in ids:
        sums={'scaled_mse':F(),'scaled_mae':F(),'scaled_wis':F()}
        for t in targets:
            mean,q=by[s,t];y=F(truth[s,t]);scale=scales[s]
            total=abs(y-q[F(1,2)])/2
            for alpha in [F(1,2),F(1,5),F(1,20)]:
                low,high=q[alpha/2],q[1-alpha/2]
                total+=alpha/2*(high-low+2/alpha*max(low-y,F())+2/alpha*max(y-high,F()))
            sums['scaled_mse']+=((mean-y)/scale)**2;sums['scaled_mae']+=abs(mean-y)/scale;sums['scaled_wis']+=total/F(7,2)/scale
        metrics[s]={k:v/len(targets)for k,v in sums.items()}
    for t in targets:
        for node in catalogue:
            if node['kind']=='aggregate':
                children=[int(e['weight'])*by[e['child'],t][0]for e in hierarchy if e['parent']==node['series_id']]
                parent=by[node['series_id'],t][0];assert abs(parent-sum(children))<=F(1,1000000)*max(F(1),abs(parent),sum(map(abs,children)))
    final={k:sum(F(1,2)*sum(metrics[n['series_id']][k]for n in catalogue if n['kind']==kind)/sum(n['kind']==kind for n in catalogue)for kind in ['leaf','aggregate'])for k in ['scaled_mse','scaled_mae','scaled_wis']}
    return final,metrics,by

def main(a):
    started=time.perf_counter();a.out.mkdir(parents=True,exist_ok=False);checks=[]
    def ck(n,ok,detail=None):checks.append({'name':n,'passed':bool(ok),'detail':detail})
    run=a.run;registration=load(run/'registration.json');pool=registration['pool'];methods={m['method_id']:m for m in pool['methods']}
    raw,rawrows,catalogue=read_independently(a.raw)
    with(a.raw/'hierarchy.csv').open(encoding='utf-8',newline='')as f:hierarchy=list(csv.DictReader(f))
    originrows=table(a.raw/'origins.csv');origins={r['origin_id']:r for r in originrows};outer=origins[a.outer];O=tick(outer['cutoff_utc'])
    inners={r['origin_id']for r in originrows if r['role']=='inner'and r['outer_id']==a.outer}
    ck('assigned_one_outer_and_three_inner',a.outer in registration['outer_ids']and len(registration['outer_ids'])==10 and len(inners)==3)
    expected_origins=inners|{a.outer};fullids={r['series_id']for r in catalogue};leaves={r['series_id']for r in catalogue if r['kind']=='leaf'}
    terminal={(r['series_id'],r['event_tick']):r for r in raw['observations']if r['revision_id']==2}
    hist=[r for r in raw['observations']if r['revision_id']==2 and tick('2023-01-02T00:00:00Z')<=r['event_tick']<=tick('2024-01-01T00:00:00Z')]
    assert len(hist)==1460 and all(r['release_tick']<=tick('2024-02-01T09:00:00Z')for r in hist)
    scales={s:max(F(1),sum(F(r['value'])for r in hist if r['series_id']==s)/365)for s in leaves}
    for node in catalogue:
        if node['kind']=='aggregate':scales[node['series_id']]=max(F(1),sum(int(e['weight'])*scales[e['child']]for e in hierarchy if e['parent']==node['series_id']))
    ck('registration_scales_exact_actual_2023',all(F(registration['scale_litres'][s])==v for s,v in scales.items()))
    original={}
    for kind,idkey,endkey in [('observations','series_id','event_end_utc'),('covariates','variable_id','valid_end_utc')]:original[kind]={(r[idkey],tick(r[endkey]),int(r['revision_id'])):r for r in rawrows[kind]}
    sql=sqlite3.connect(':memory:');sql.execute('CREATE TABLE f(kind,idx,id,t,rev,released,future)')
    for kind,idkey,tkey in [('observations','series_id','event_tick'),('covariates','variable_id','valid_tick')]:sql.executemany('INSERT INTO f VALUES(?,?,?,?,?,?,?)',[(kind,i,r[idkey],r[tkey],r['revision_id'],r['release_tick'],int(kind=='covariates'and raw['variables'][r[idkey]]['availability']=='known_future'))for i,r in enumerate(raw[kind])])
    facts={};metric_rows={};job_receipts=[];closures=[];fit_checks=[]
    for terminal_path in sorted((run/'outer'/a.outer).rglob('terminal-inspect.json')):
        job=terminal_path.parent;term=load(terminal_path);cid=term['Id'];mounts={r['Destination']:r for r in term['Mounts']};selector='l02_selection.py'in term['Args']
        st=term['State'];create=load(job/'create-command.json');execution=load(job/'execution-command.json');cleanup=load(job/'cleanup-command.json')
        ck('natural_terminal_'+str(job.relative_to(run)),st['Status']=='exited'and st['ExitCode']==0 and not st['OOMKilled']and not st['Error']and execution['exitcode']==0 and create['stdout'].strip()==cid)
        ck('physical_mounts_resources_'+str(job.relative_to(run)),set(mounts)=={'/project','/input','/output'}and not mounts['/project']['RW']and not mounts['/input']['RW']and mounts['/output']['RW']and term['HostConfig']['NetworkMode']=='none'and term['HostConfig']['NanoCpus']==1000000000 and term['Image']==registration['image'])
        src=Path(mounts['/project']['Source']);expected_files={'l02_selection.py','l02_scoring.py','material_contract.py','asof_input.py'}if selector else{'l02_daily_reference.py','daily_data.py','decode_materials.py','material_contract.py','asof_input.py'}
        ck('minimal_actual_source_'+str(job.relative_to(run)),{p.relative_to(src).as_posix()for p in src.rglob('*')if p.is_file()}==expected_files and all((src/n).read_bytes()==(run/'source'/n).read_bytes()for n in expected_files))
        with zipfile.ZipFile(job/'completed-originals.zip')as z:
            members=set(z.namelist());actual=[p for p in job.rglob('*')if p.is_file()and p.name not in {'completed-originals.zip','cleanup-command.json','metric-assessment.json','assessment.json'}]
            # Later assessment files are not pre-cleanup execution artifacts.
            same=all(p.relative_to(job).as_posix()in members and z.read(p.relative_to(job).as_posix())==p.read_bytes()for p in actual if p.relative_to(job).parts[0]in {'input','output'}or p.name=='terminal-inspect.json')
            ck('sealed_terminal_input_output_'+str(job.relative_to(run)),same and all(z.read('executed-source/'+n)==(src/n).read_bytes()for n in expected_files))
        ck('exact_own_CID_cleanup_'+str(job.relative_to(run)),cleanup['exitcode']==0 and cleanup['argv']==['docker','rm',cid])
        job_receipts.append({'job':job.relative_to(run).as_posix(),'cid':cid,'selector':selector,'start':st['StartedAt'],'finish':st['FinishedAt']})
        input_names={p.relative_to(job/'input').as_posix()for p in(job/'input').rglob('*')if p.is_file()}
        input_expected={'inner.json','study.json'}if selector else{'method.json','packet/packet.json','packet/observations.csv','packet/covariate-vintages.csv'}
        ck('recursive_input_namespace_'+str(job.relative_to(run)),input_names==input_expected)
        ck('actual_singlethread_blas_'+str(job.relative_to(run)),all(v in create['argv']for v in ['OPENBLAS_NUM_THREADS=1','OMP_NUM_THREADS=1']))

        if selector:continue
        inp=job/'input';packet=inp/'packet';meta=load(packet/'packet.json');o=meta['origin_tick'];g=next(r for r in originrows if tick(r['cutoff_utc'])==o and r['origin_id']in expected_origins);origin_id=g['origin_id']
        targets=[(o//24+2)*24+24*i for i in range(14)]
        ck('packet_meta_'+job.relative_to(run).as_posix(),set(meta)=={'format','clock','origin_tick','target_ticks','series_catalogue','hierarchy','units','variables','quantiles'}and meta['target_ticks']==targets and meta['clock']=={'epoch_utc':'2022-01-01T00:00:00Z','tick_unit':'hour','event_interval':'[UTC date 00:00, next UTC date 00:00)'}and meta['series_catalogue']==catalogue and meta['variables']==raw['variables'])
        packet_raw={**raw,'observations':[],'covariates':[]}
        for kind,idkey,tkey,file,endkey in [('observations','series_id','event_tick','observations.csv','event_end_utc'),('covariates','variable_id','valid_tick','covariate-vintages.csv','valid_end_utc')]:
            rs=table(packet/file);keys=[(r[idkey],tick(r[endkey]),int(r['revision_id']))for r in rs]
            wanted=[raw[kind][row[0]]for row in sql.execute('SELECT idx FROM f WHERE kind=? AND released<=? AND(future=1 OR t<?) ORDER BY id,t,rev',(kind,o,o))]
            wkeys=[(r[idkey],r[tkey],r['revision_id'])for r in wanted]
            ck('raw_CSV_SQL_authority_'+job.relative_to(run).as_posix()+'_'+kind,len(keys)==len(set(keys))and set(keys)==set(wkeys)and all(r==original[kind][k]for r,k in zip(rs,keys)))
            packet_raw[kind]=wanted
        method=load(inp/'method.json');mid=method['method_id'];ck('immutable_method_'+job.relative_to(run).as_posix(),method=={k:methods[mid][k]for k in ['method_id','configuration']})
        truth={(s,t):terminal[s,t]['value']for s in leaves for t in targets};released=max(terminal[s,t]['release_tick']for s in leaves for t in targets)
        for node in catalogue:
            if node['kind']=='aggregate':
                for t in targets:truth[node['series_id'],t]=sum(int(e['weight'])*truth[e['child'],t]for e in hierarchy if e['parent']==node['series_id'])
        value=load(job/'output/result/forecast.json');metrics,nodes,by=score_independent(value,truth,o,targets,catalogue,hierarchy,scales)
        assessed=load(job/'metric-assessment.json');ck('all84_metrics_'+job.relative_to(run).as_posix(),len(value['forecasts'])==84 and all(F(assessed['metrics_exact'][k])==v for k,v in metrics.items())and all(F(assessed['node_metrics_exact'][s][k])==v for s,row in nodes.items()for k,v in row.items()))
        facts[origin_id,mid]={'metrics':metrics,'forecast':value,'truth':truth,'released':released,'targets':targets,'meta':meta,'job':str(job)}
        fit=load(job/'output/result/fit.json');cfg=method['configuration'];known={}
        for r in packet_raw['observations']:
            key=r['series_id'],r['event_tick']
            if key not in known or r['revision_id']>known[key]['revision_id']:known[key]=r
        ck('fit42paired_current_label_permission_'+job.relative_to(run).as_posix(),fit['paired_residual_rows']==42 and fit['method']==method and len(fit['calibration'])==3)
        for block in [{'origin_tick':o,'target_ticks':targets,'fit':fit['fit']}]+fit['calibration']:
            P=block['origin_tick'];pt=block['target_ticks'];latest={}
            for r in packet_raw['observations']:
                key=r['series_id'],r['event_tick']
                if r['release_tick']<=P and r['event_tick']<P and(key not in latest or r['revision_id']>latest[key]['revision_id']):latest[key]=r
            for s in leaves:
                eligible=[r for(sid,t),r in latest.items()if sid==s and r['quality_flag']=='valid'and P-24*cfg['train_window_days']<=t<P]
                f=block['fit'][s];expected_features=['up_to_8_same_weekday_values']if cfg['algorithm']=='seasonal_weekday'else['intercept']+['weekday_'+str(i)for i in range(1,7)]+['year_sin','year_cos']+(['temperature_C']if cfg['use_weather']else[])+(['open','transfer_in']if cfg['use_operations']else[])
                fit_checks.append({'job':job.relative_to(run).as_posix(),'origin':P,'series':s,'passed':len(eligible)==f['training_rows']and max(r['event_tick']for r in eligible)==f['maximum_training_event_tick']and f['features']==expected_features})
            if P!=o:
                valid=[t for t in pt if all((s,t)in known and known[s,t]['quality_flag']=='valid'for s in leaves)]
                ck('calibration_highest_known_labels_'+job.relative_to(run).as_posix()+'_'+str(P),block['accepted_complete_leaf_ticks']==valid and len(valid)==14 and P in{o-24*x for x in [56,84,112]})
        if cfg['algorithm']=='ridge'and cfg['use_operations']:
            covs={}
            for r in packet_raw['covariates']:
                k=r['variable_id'],r['valid_tick']
                if k not in covs or r['revision_id']>covs[k]['revision_id']:covs[k]=r
            for t in targets:
                for s in leaves:
                    row=covs.get((s+'.open',t))
                    if row and row['value']==0:
                        mean,q=by[s,t];closures.append({'method':mid,'origin':origin_id,'series':s,'target':t,'all_output_zero':mean==0 and all(v==0 for v in q.values())})
    ck('exact10sequential_actual_processes',len(job_receipts)==10 and sum(j['selector']for j in job_receipts)==1 and all(b['start']>=a['finish']for a,b in zip(sorted(job_receipts,key=lambda v:v['start']),sorted(job_receipts,key=lambda v:v['start'])[1:])))
    ck('all144actual_fit_source_permissions_features',len(fit_checks)==144 and all(v['passed']for v in fit_checks))
    ck('all_observed_closed_leaf_sample_outputs_zero',all(v['all_output_zero']for v in closures),closures)
    selector_job=run/'outer'/a.outer/'selector';payload=load(selector_job/'input/inner.json');actual=load(selector_job/'output/result/selection.json')
    ck('selector_only_complete_registered_inner_labels',set(payload['inner_ids'])==inners and len(payload['frames'])==3 and set(payload['selection_ids'])==set(pool['selection_ids']))
    losses={m:[]for m in pool['selection_ids']}
    for frame in payload['frames']:
        gid=frame['origin_id'];g=origins[gid];i=tick(g['cutoff_utc'])
        wanted_truth=facts[gid,pool['selection_ids'][0]]['truth'];labels={(r['series_id'],r['target_tick']):r['value']for r in frame['labels']}
        ck('selector_frame_truth_actual_release_'+gid,labels==wanted_truth and frame['labels_released_at']==facts[gid,pool['selection_ids'][0]]['released']<=O and frame['context']['origin_tick']==i and frame['context']['target_ticks']==facts[gid,pool['selection_ids'][0]]['targets']and all(F(frame['context']['scales_litres'][s])==v for s,v in scales.items()))
        for m in pool['selection_ids']:
            ck('selector_forecast_actual_binding_'+gid+'_'+m,frame['forecasts'][m]==facts[gid,m]['forecast']);losses[m].append(facts[gid,m]['metrics']['scaled_mse'])
    mean={m:sum(v)/3 for m,v in losses.items()};best=min(mean,key=lambda m:(mean[m],m))
    ck('independent_fixed_grid_minimum_ID_selection',actual['selected_method_id']==best and actual['outer_origin_tick']==O and all(F(actual['method_mean_inner_scaled_mse'][m])==v for m,v in mean.items()))
    ck('all9forecast_cells_complete_same_configs',set(facts)=={(g,m)for g in inners for m in pool['selection_ids']}|{(a.outer,m)for m in pool['outer_ids']})
    save(a.out/'checks.json',checks);save(a.out/'processes.json',job_receipts);save(a.out/'fit-permission-checks.json',fit_checks)
    result={'outer_id':a.outer,'checks':len(checks),'all_passed':all(c['passed']for c in checks),'failed':[c['name']for c in checks if not c['passed']],'actual_processes':len(job_receipts),'forecasts':len(facts),'forecast_rows_each':84,'fit_groups_independently_checked':len(fit_checks),'closed_leaf_outputs':len(closures),'selector_expected':best,'inner_losses_exact':{m:str(v)for m,v in mean.items()},'outer_metrics':{m:{k:str(v)for k,v in facts[a.outer,m]['metrics'].items()}for m in pool['outer_ids']},'seconds':time.perf_counter()-started,'candidate_score':None,'scope':'Actual isolated author reference and permissions/metrics/fit metadata only; not a full research benchmark grade.','new_forecast_fit_solver_or_Docker_calls_from_this_audit':0}
    save(a.out/'assessment.json',result);sql.close();print(json.dumps({k:v for k,v in result.items()if k not in['outer_metrics','inner_losses_exact']},ensure_ascii=False))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--run',type=Path,required=True);p.add_argument('--raw',type=Path,required=True);p.add_argument('--outer',required=True);p.add_argument('--out',type=Path,required=True);main(p.parse_args())
