"""Read-only remaining-ten increment. Reuses reviewer arithmetic, never forecasts."""
import csv,json
from pathlib import Path
from types import SimpleNamespace
import time
ROOT=Path(__file__).resolve().parent
RUN=Path('D:/opencorvus-benchmark-runs/l02-daily-loop-qualification-20261030/main/remaining-ten')
RAW=RUN.parent/'raw'
OUT=ROOT/'full-matrix-increment';OUT.mkdir(exist_ok=False)
base=(ROOT/'audit_completed_loop.py').read_text(encoding='utf-8')
old="registration['outer_ids']==[a.outer]and len(inners)==3"
new="a.outer in registration['outer_ids']and len(registration['outer_ids'])==10 and len(inners)==3"
assert base.count(old)==1;base=base.replace(old,new)
old="sorted(run.rglob('terminal-inspect.json'))"
new="sorted((run/'outer'/a.outer).rglob('terminal-inspect.json'))"
assert base.count(old)==1;base=base.replace(old,new)
old="{p.name for p in src.iterdir()if p.is_file()}==expected_files"
new="{p.relative_to(src).as_posix()for p in src.rglob('*')if p.is_file()}==expected_files"
assert base.count(old)==1;base=base.replace(old,new)
marker="        job_receipts.append({'job':job.relative_to(run).as_posix(),'cid':cid,'selector':selector,'start':st['StartedAt'],'finish':st['FinishedAt']})"
extra="""
        input_names={p.relative_to(job/'input').as_posix()for p in(job/'input').rglob('*')if p.is_file()}
        input_expected={'inner.json','study.json'}if selector else{'method.json','packet/packet.json','packet/observations.csv','packet/covariate-vintages.csv'}
        ck('recursive_input_namespace_'+str(job.relative_to(run)),input_names==input_expected)
        ck('actual_singlethread_blas_'+str(job.relative_to(run)),all(v in create['argv']for v in ['OPENBLAS_NUM_THREADS=1','OMP_NUM_THREADS=1']))
"""
assert base.count(marker)==1;base=base.replace(marker,marker+extra)
(OUT/'auditor-ten-outer.py').write_text(base,encoding='utf-8')
namespace={'__file__':str(OUT/'auditor-ten-outer.py'),'__name__':'reviewer_remaining_increment'}
exec(compile(base,str(OUT/'auditor-ten-outer.py'),'exec'),namespace)
registration=json.loads((RUN/'registration.json').read_text(encoding='utf-8'))
with(RAW/'origins.csv').open(encoding='utf-8',newline='')as f:origins=list(csv.DictReader(f))
expected={r['origin_id']for r in origins if r['role']=='outer'}-{'outer-20250115','outer-20250620'}
assert set(registration['outer_ids'])==expected and len(expected)==10
started=time.perf_counter();assessments=[]
for outer in registration['outer_ids']:
    namespace['main'](SimpleNamespace(run=RUN,raw=RAW,outer=outer,out=OUT/outer))
    result=json.loads((OUT/outer/'assessment.json').read_text(encoding='utf-8'));assessments.append(result)
    (OUT/'progress.json').write_text(json.dumps({'completed_outer':len(assessments),'of':10,'last':outer,'all_current_passed':all(v['all_passed']for v in assessments),'new_forecast_Docker_Provider_calls':0},indent=2)+'\n',encoding='utf-8')
result={'outer_count':10,'all_passed':all(v['all_passed']for v in assessments),'per_outer':[{'outer_id':v['outer_id'],'checks':v['checks'],'all_passed':v['all_passed'],'failed':v['failed'],'selector':v['selector_expected']}for v in assessments],'actual_terminal_processes_independently_read':sum(v['actual_processes']for v in assessments),'forecasts_complete84rows':sum(v['forecasts']for v in assessments),'fit_group_metadata_checked':sum(v['fit_groups_independently_checked']for v in assessments),'seconds':time.perf_counter()-started,'new_forecast_Docker_fit_solver_Provider_calls':0,'Jan_June_rerun':False,'candidate_score':None}
(OUT/'assessment.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
