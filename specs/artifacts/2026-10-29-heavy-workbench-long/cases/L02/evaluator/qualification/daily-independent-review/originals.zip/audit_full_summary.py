"""Independent exact aggregation and report binding; never forecasts or starts a container."""
import csv,json,runpy,shutil,time,zipfile
from pathlib import Path
from fractions import Fraction as F
from datetime import timedelta

ROOT=Path(__file__).resolve().parent
MAIN=Path('D:/opencorvus-benchmark-runs/l02-daily-loop-qualification-20261030/main')
REPO=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L02/evaluator')
OUT=ROOT/'full-summary-audit';OUT.mkdir(exist_ok=False)
ns=runpy.run_path(str(ROOT/'audit_completed_loop.py'),run_name='reviewer_arithmetic')
load=ns['load'];save=ns['save'];score=ns['score_independent'];tick=ns['tick'];table=ns['table']
started=time.perf_counter();checks=[]
def ck(name,value,detail=None):checks.append({'name':name,'passed':bool(value),'detail':detail})

raw,rawrows,catalogue=ns['read_independently'](MAIN/'raw')
hierarchy=table(MAIN/'raw/hierarchy.csv');origins={r['origin_id']:r for r in table(MAIN/'raw/origins.csv')}
leaves={n['series_id'] for n in catalogue if n['kind']=='leaf'}
terminal={(r['series_id'],r['event_tick']):r for r in raw['observations'] if r['revision_id']==2}
hist=[r for r in raw['observations'] if r['revision_id']==2 and tick('2023-01-02T00:00:00Z')<=r['event_tick']<=tick('2024-01-01T00:00:00Z')]
scales={s:max(F(1),sum(F(r['value'])for r in hist if r['series_id']==s)/365)for s in leaves}
for n in catalogue:
    if n['kind']=='aggregate':scales[n['series_id']]=max(F(1),sum(int(e['weight'])*scales[e['child']]for e in hierarchy if e['parent']==n['series_id']))
runs=[MAIN/'representative',ROOT/'cold-june20/run',MAIN/'remaining-ten']
outermap={}
for run in runs:
    reg=load(run/'registration.json')
    for gid in reg['outer_ids']:assert gid not in outermap;outermap[gid]=run
ck('registered_exact12outer_no_replacement',set(outermap)=={gid for gid,r in origins.items()if r['role']=='outer'}and len(outermap)==12)
summary=load(MAIN/'full-reference-summary/assessment.json');plot=load(MAIN/'full-reference-summary/plot-input.json')
rows={r['outer_id']:r for r in summary['rows']};prows={r['outer_id']:r for r in plot['origins']}
ck('summary12outer36inner36outer84cells_scope',summary['registered_outer_count']==12 and summary['registered_inner_count']==36 and summary['outer_forecasts']==36 and summary['rows_per_forecast']==84 and summary['quality_floor'] is None and summary['candidate_score']is None and set(rows)==set(outermap)and set(prows)==set(outermap))
methods=load(runs[0]/'registration.json')['pool']['outer_ids'];keys=['scaled_mse','scaled_mae','scaled_wis']
macro={m:{k:[]for k in keys}for m in methods+['selected']};node={m:{n['series_id']:{k:[]for k in keys}for n in catalogue}for m in methods+['selected']}
actual={};selectedids=[]
for gid,run in sorted(outermap.items()):
    o=tick(origins[gid]['cutoff_utc']);targets=[(o//24+2)*24+24*i for i in range(14)]
    truth={(s,t):terminal[s,t]['value']for s in leaves for t in targets}
    for n in catalogue:
        if n['kind']=='aggregate':
            for t in targets:truth[n['series_id'],t]=sum(int(e['weight'])*truth[e['child'],t]for e in hierarchy if e['parent']==n['series_id'])
    selected=load(run/'outer'/gid/'selector/output/result/selection.json')['selected_method_id'];selectedids.append(selected)
    ck('summary_original_selector_'+gid,rows[gid]['selected_method_id']==selected)
    pp=prows[gid]
    ck('plot_origin_actual_truth_'+gid,pp['cutoff_utc']==origins[gid]['cutoff_utc']and pp['target_ticks']==targets and pp['selected_method_id']==selected and {(r['series_id'],r['target_tick']):r['value']for r in pp['labels']}==truth)
    actual[gid]={}
    for mid in methods:
        job=run/'outer'/gid/'outer'/mid
        forecast=load(job/'output/result/forecast.json');m,n,by=score(forecast,truth,o,targets,catalogue,hierarchy,scales)
        sm=rows[gid]['metrics'][mid]
        ck('summary_macro_and_nodes_exact_'+gid+'_'+mid,all(F(sm['metrics_exact'][k])==m[k]for k in keys)and all(F(sm['node_metrics_exact'][s][k])==n[s][k]for s in n for k in keys))
        expectedcurve=[{'series_id':r['series_id'],'target_tick':r['target_tick'],'mean':float(F(r['mean'])),'lower80':float(F(next(v for q,v in r['quantiles'].items()if F(q)==F(1,10)))),'upper80':float(F(next(v for q,v in r['quantiles'].items()if F(q)==F(9,10))))}for r in forecast['forecasts']]
        # Plot is a floating display, exact scientific metrics stay rational.
        ck('plot_curve_actual_mean_and_interval_'+gid+'_'+mid,pp['curves'][mid]==expectedcurve)
        for k in keys:macro[mid][k].append(m[k])
        for s in n:
            for k in keys:node[mid][s][k].append(n[s][k])
        actual[gid][mid]={'macro':m,'node':n,'forecast':forecast,'truth':truth,'by':by,'job':str(job)}
        if mid==selected:
            ck('selected_metrics_same_exact_forecast_'+gid,rows[gid]['selected_metrics']==sm)
            for k in keys:macro['selected'][k].append(m[k])
            for s in n:
                for k in keys:node['selected'][s][k].append(n[s][k])
aggregate={m:{k:sum(v)/12 for k,v in row.items()}for m,row in macro.items()}
nodeaggregate={m:{s:{k:sum(v)/12 for k,v in row.items()}for s,row in nod.items()}for m,nod in node.items()}
ck('aggregate_all12_fixed_exact_fraction',all(F(summary['aggregate_exact'][m][k])==v for m,row in aggregate.items()for k,v in row.items()))
ck('selected_weather_all12_actual_not_reoptimized',selectedids==['ridge-weather-operations']*12 and aggregate['selected']==aggregate['ridge-weather-operations'])
csvrows=table(MAIN/'full-reference-summary/outer-metrics.csv')
ck('csv36_unique_complete',len(csvrows)==36 and {(r['outer_id'],r['method_id'])for r in csvrows}=={(g,m)for g in outermap for m in methods})
for r in csvrows:
    ck('csv_display_'+r['outer_id']+'_'+r['method_id'],all(r[k]==format(float(actual[r['outer_id']][r['method_id']]['macro'][k]),'.12g')for k in keys)and r['selected']==str(r['method_id']==rows[r['outer_id']]['selected_method_id']))

june=actual['outer-20250620']['ridge-weather-operations'];jtargets=prows['outer-20250620']['target_ticks'];jul=[t for t in jtargets if tick('2025-07-02T00:00:00Z')<=t<=tick('2025-07-05T00:00:00Z')]
failure={}
for s in ['A1','A2','ZA']:
    y=sum(F(june['truth'][s,t])for t in jul)/4;mu=sum(june['by'][s,t][0]for t in jul)/4
    hits=sum(june['by'][s,t][1][F(1,10)]<=june['truth'][s,t]<=june['by'][s,t][1][F(9,10)]for t in jul)
    failure[s]={'truth_mean_exact':str(y),'forecast_mean_exact':str(mu),'truth_mean_display':format(float(y),'.2f'),'forecast_mean_display':format(float(mu),'.2f'),'central80_hits':hits,'days':len(jul)}
ck('June_actual4day_failure_A1_ZA_and_closedA2',len(jul)==4 and failure['A1']['central80_hits']==0 and failure['ZA']['central80_hits']==0 and failure['A2']['central80_hits']==4 and F(failure['A2']['forecast_mean_exact'])==0)
ck('actual_ablation_better_no_weather_general_benefit_claim',aggregate['ridge-no-weather']['scaled_mse']<aggregate['ridge-weather-operations']['scaled_mse']and aggregate['ridge-no-weather']['scaled_wis']<aggregate['ridge-weather-operations']['scaled_wis'])

controls=[];janpayload=load(runs[0]/'outer/outer-20250115/selector/input/inner.json')
for name in ['one-perfect','all-tied-perfect']:
    folder=MAIN.parent/'selection-numeric-controls'/name;p=load(folder/'inner.json');result=load(folder/'result/selection.json');cmd=load(folder/'command.json');losses={m:[]for m in p['selection_ids']}
    ck('control_same_legal_identity_context_labels_'+name,{k:v for k,v in p.items()if k!='frames'}=={k:v for k,v in janpayload.items()if k!='frames'}and all({k:v for k,v in f.items()if k!='forecasts'}=={k:v for k,v in original.items()if k!='forecasts'}for f,original in zip(p['frames'],janpayload['frames']))and len(p['frames'])==3)
    for f in p['frames']:
        c=f['context'];truth={(r['series_id'],r['target_tick']):r['value']for r in f['labels']}
        for m in p['selection_ids']:losses[m].append(score(f['forecasts'][m],truth,c['origin_tick'],c['target_ticks'],c['series_catalogue'],c['hierarchy'],{s:F(v)for s,v in c['scales_litres'].items()})[0]['scaled_mse'])
    means={m:sum(v)/3 for m,v in losses.items()};best=min(means,key=lambda m:(means[m],m))
    expected='seasonal-weekday'if name=='one-perfect'else'ridge-weather-operations'
    ck('control_actual_CLI_and_own_exact_min_ID_'+name,cmd['exitcode']==0 and best==expected==result['selected_method_id']and all(F(result['method_mean_inner_scaled_mse'][m])==v for m,v in means.items())and (means['seasonal-weekday']==0 if name=='one-perfect'else all(v==0 for v in means.values())))
    controls.append({'name':name,'own_min_ID':best,'exact_inner_losses':{m:str(v)for m,v in means.items()},'scope':'constructed numeric interface control, not a forecast performance sample','command':str(folder/'command.json')})

current=REPO/'current-source';sourcechecks={}
for n in ['l02_daily_reference.py','daily_data.py','decode_materials.py','material_contract.py','asof_input.py','l02_selection.py','l02_scoring.py']:
    sourcechecks[n]={'remaining_equals_June':(MAIN/'remaining-ten/source'/n).read_bytes()==(ROOT/'cold-june20/source'/n).read_bytes(),'current_equals_remaining':(current/n).read_bytes()==(MAIN/'remaining-ten/source'/n).read_bytes()}
ck('worker5_selector4_current_June_remaining_exact',all(all(v.values())for v in sourcechecks.values()))
for n in ['material-contract.json','reference-pool.json','study-contract.draft.json']:
    f=MAIN/'remaining-ten/source'/n
    ck('contract_June_remaining_'+n,f.read_bytes()==(ROOT/'cold-june20/source'/n).read_bytes())
for p in(MAIN/'raw').iterdir():
    if p.is_file():ck('raw_June_remaining_identity_'+p.name,p.read_bytes()==(ROOT/'cold-june20/raw'/p.name).read_bytes())

reported=REPO/'qualification/daily-full-reference';report=(reported/'REPORT.md').read_text(encoding='utf-8')
ck('repo_summary_and_CSV_exact_external',all((reported/n).read_bytes()==(MAIN/'full-reference-summary'/n).read_bytes()for n in ['assessment.json','outer-metrics.csv']))
ck('report_table_precision_exact',all(format(float(aggregate[m][k]),'.9f') in report for m in methods+['selected']for k in keys))
ck('report_fourday_table_exact',all(f['truth_mean_display']in report and f['forecast_mean_display']in report and str(f['central80_hits'])+'/4'in report for f in failure.values()))
render=MAIN/'full-reference-summary/render-job';ti=load(render/'terminal-inspect.json');png=render/'output/figures/june20-forecasts.png'
ck('repo_PNG_actual_render_exact',png.read_bytes()==(reported/'june20-forecasts.png').read_bytes())
ck('render_actual_natural_process_and_raw_plot_binding',ti['State']['ExitCode']==0 and ti['State']['Status']=='exited'and ti['HostConfig']['NetworkMode']=='none'and ti['HostConfig']['NanoCpus']==1000000000 and set(m['Destination']for m in ti['Mounts'])=={'/project','/input','/output'}and all(m['RW']==(m['Destination']=='/output')for m in ti['Mounts'])and (render/'input/plot-input.json').read_bytes()==(MAIN/'full-reference-summary/plot-input.json').read_bytes())
for n in ['REPORT.md','assessment.json','outer-metrics.csv','june20-forecasts.png']:shutil.copy2(reported/n,OUT/('reported-'+n))
for n in ['terminal-inspect.json','execution-command.json','create-command.json','cleanup-command.json']:shutil.copy2(render/n,OUT/('render-'+n))
save(OUT/'checks.json',checks);save(OUT/'aggregate-exact.json',aggregate);save(OUT/'node-aggregate-exact.json',nodeaggregate);save(OUT/'June-failure-exact.json',failure);save(OUT/'numeric-controls.json',controls);save(OUT/'source-identity.json',sourcechecks)
save(OUT/'assessment.json',{'checks':len(checks),'all_passed':all(c['passed']for c in checks),'failed':[c['name']for c in checks if not c['passed']],'seconds':time.perf_counter()-started,'scope':'independent Fraction aggregation and raw-to-report binding; not a candidate grade','candidate_score':None,'new_forecast_fit_solver_Docker_Provider_calls':0})
print(json.dumps(load(OUT/'assessment.json'),ensure_ascii=False))
