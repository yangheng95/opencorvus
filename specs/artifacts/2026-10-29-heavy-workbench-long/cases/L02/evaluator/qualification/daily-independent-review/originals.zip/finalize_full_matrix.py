"""Read-only final evidence joins. No model, solver, container or Provider calls."""
import json,zipfile,shutil,time,difflib
from pathlib import Path
from fractions import Fraction as F
ROOT=Path(__file__).resolve().parent
MAIN=Path('D:/opencorvus-benchmark-runs/l02-daily-loop-qualification-20261030/main')
REPO=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L02/evaluator')
OUT=ROOT/'full-matrix-final';OUT.mkdir(exist_ok=False)
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
started=time.perf_counter();checks=[]
def ck(n,v):checks.append({'name':n,'passed':bool(v)})
ten=load(ROOT/'full-matrix-increment/assessment.json');first=load(ROOT/'main-january-audit/assessment.json');june=load(ROOT/'cold-june20/independent-audit/assessment.json');s=load(ROOT/'full-summary-audit/assessment.json');repair=load(ROOT/'full-summary-display-repair/assessment.json')
ck('10_remaining168checks_each',ten['all_passed']and len(ten['per_outer'])==10 and all(r['checks']==168 and r['all_passed']for r in ten['per_outer']))
ck('priorJan_and_June148_each',first['all_passed']and june['all_passed']and first['checks']==148 and june['checks']==148)
ck('summary100_exact_original_and72_display_semantic_repaired',s['checks']==172 and len(s['failed'])==72 and repair['all_passed']and repair['checks']==72 and set(s['failed'])=={r['name']for r in load(ROOT/'full-summary-display-repair/checks.json')})
processes=[]
for a in [ROOT/'main-january-audit',ROOT/'cold-june20/independent-audit']+[ROOT/'full-matrix-increment'/r['outer_id']for r in ten['per_outer']]:processes+=load(a/'processes.json')
ordered=sorted(processes,key=lambda r:r['start'])
ck('all120_unique_actual_CIDs108forecast12selector',len(ordered)==120 and len({r['cid']for r in ordered})==120 and sum(r['selector']for r in ordered)==12)
ck('all120_globally_sequential',all(b['start']>=a['finish']for a,b in zip(ordered,ordered[1:])))
save(OUT/'all120-actual-processes.json',ordered)
events=[json.loads(line)for line in(MAIN/'remaining-ten/events.jsonl').read_text().splitlines()]
terms={r['container_id']:r for r in events if r['kind']=='numeric_terminal'};starts={r['container_id']:r for r in events if r['kind']=='numeric_started'}
remaining=[p for a in ten['per_outer']for p in load(ROOT/'full-matrix-increment'/a['outer_id']/'processes.json')]
ck('100_terminal_events_match_actualCIDs_and_archives',len(terms)==len(starts)==100 and all(p['cid']in terms and terms[p['cid']]['exitcode']==0 and Path(terms[p['cid']]['archive']).is_file()and starts[p['cid']]['at']<=terms[p['cid']]['at']for p in remaining))
for name in ['registration.json','events.jsonl','assessment.json','status.json']:shutil.copy2(MAIN/'remaining-ten'/name,OUT/('remaining-'+name))
shutil.copytree(MAIN/'remaining-ten/source',OUT/'executed-remaining-source')
for e in terms.values():
    job=Path(e['job']);destination=OUT/'remaining-process-receipts'/Path(job).relative_to(MAIN/'remaining-ten')
    destination.mkdir(parents=True)
    for n in ['create-command.json','execution-command.json','terminal-inspect.json','cleanup-command.json']:shutil.copy2(job/n,destination/n)
old=(MAIN/'remaining-ten/source/run_l02_study.py').read_text();cur=(REPO/'current-source/run_l02_study.py').read_text();jdriver=(ROOT/'cold-june20/source/run_l02_study.py').read_text()
ck('remaining_driver_same_as_June_actual',old==jdriver)
diff=''.join(difflib.unified_diff(old.splitlines(True),cur.splitlines(True),fromfile='executed_remaining',tofile='current_ownership_repair'))
(OUT/'driver-current-ownership.diff').write_text(diff,encoding='utf-8')
shutil.copy2(REPO/'current-source/run_l02_study.py',OUT/'current-driver-verbatim.py')
ck('current_driver_only_ownership_diff_already_audited',cur==(ROOT/'output-ownership-addendum/current-driver-verbatim.py').read_text())
ck('ownership_two_actual_contracts_passed',load(ROOT/'output-ownership-addendum/assessment.json')['all_passed'])

archive=REPO/'qualification/daily-full-reference/numerical-originals.zip'
with zipfile.ZipFile(archive)as z:
    bindings=json.loads(z.read('duplicate-input-bindings.json'));bindingchecks=[]
    def original(member):
        for prefix,base in [('main/representative/',MAIN/'representative'),('main/remaining-ten/',MAIN/'remaining-ten'),('independent/cold-june20/',ROOT/'cold-june20/run')]:
            if member.startswith(prefix):return base/member[len(prefix):]
        raise AssertionError(member)
    for b in bindings:
        actual=original(b['original_member']);stored=z.read(b['same_original_bytes_at'])
        bindingchecks.append({'original_member':b['original_member'],'stored_member':b['same_original_bytes_at'],'passed':actual.read_bytes()==stored})
    ck('324_deduplicated_packet_original_bytes_reconstruct',len(bindings)==324 and all(v['passed']for v in bindingchecks))
    ck('published_archive120_actual_terminal_inspects',sum(n.endswith('/terminal-inspect.json')and n.startswith(('main/representative/','main/remaining-ten/','independent/cold-june20/'))for n in z.namelist())==120)
save(OUT/'archive-deduplication-bindings.json',bindingchecks)
for name in ['REPORT.md','archive-receipt.json']:shutil.copy2(REPO/'qualification/daily-full-reference'/name,OUT/('current-'+name))
aggregate=load(ROOT/'full-summary-audit/aggregate-exact.json');display={m:{k:float(F(v))for k,v in row.items()}for m,row in aggregate.items()}
improvement={k:100*(1-F(aggregate['selected'][k])/F(aggregate['seasonal-weekday'][k]))for k in ['scaled_mse','scaled_wis']}
report=(REPO/'qualification/daily-full-reference/REPORT.md').read_text()
ck('report_improvement_display_matches_exact_values',all(format(float(v),'.3f')in report for v in improvement.values()))
save(OUT/'readable-metrics.json',{'metrics':display,'selected_relative_improvement_percent':{k:float(v)for k,v in improvement.items()}})
visual={'actually_viewed':True,'tool':'view_image','path':str(REPO/'qualification/daily-full-reference/june20-forecasts.png'),'image_native_pixels':[2240,1190],'tool_display_pixels':[2048,1088],'panels':['A1','A2','B1','B2','ZA','ZB'],'observations':['Daily UTC dates and litres axes, method/truth legend and selected central80-band title are readable.','A2 ridge means and bands become zero on July1 while seasonal stays positive.','A1 truth jumps above selected; ZA also underestimated. Four-day exact interval miss and means are independently recomputed, not inferred only from pixels.','Blue translucent selected band uses a different color from orange selected mean; title identifies it, but matching colors would improve readability. This is a nonblocking presentation note.'],'figure_is_UI_automation':False,'semantic_curve_binding':'all36 plotted curves (84cells each) bound to original exact forecast outputs with float display conversion','candidate_visual_grade':None}
save(OUT/'visual-review.json',visual)
save(OUT/'checks.json',checks)
result={'status':'author_daily_numerical_reference_qualified_with_documented_failure_boundaries','all_passed':all(c['passed']for c in checks),'checks':len(checks),'failed':[c['name']for c in checks if not c['passed']],'seconds':time.perf_counter()-started,'complete_matrix':{'outer':12,'inner':36,'forecasts':108,'selectors':12,'actual_numeric_processes':120,'rows_per_forecast':84,'fit_groups_metadata_independently_checked':1728,'paired_residual_rows_per_forecast':42},'new_forecasts_or_containers_this_increment':0,'blocking_findings':[],'quality_floor':None,'candidate_score':None,'full_L02_frozen':False,'hours_qualified':False,'expert_or_statistical_validation_claimed':False}
save(OUT/'assessment.json',result);print(json.dumps(result))
