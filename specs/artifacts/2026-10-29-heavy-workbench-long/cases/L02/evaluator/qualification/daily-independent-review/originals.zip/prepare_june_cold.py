"""Prepare only the authorized one-outer cold; does not start a container."""
from datetime import datetime,timezone
import difflib,json
from pathlib import Path
import shutil

ROOT=Path(__file__).resolve().parent
MAIN=Path('D:/opencorvus-benchmark-runs/l02-daily-loop-qualification-20261030/main')
CURRENT=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L02/evaluator/current-source')
COLD=ROOT/'cold-june20';COLD.mkdir(exist_ok=False)
shutil.copytree(MAIN/'source',COLD/'source-original')
shutil.copytree(MAIN/'source',COLD/'source')
shutil.copytree(MAIN/'raw',COLD/'raw')
differences=[]
for n in ['l02_selection.py','run_l02_study.py']:
    shutil.copy2(CURRENT/n,COLD/'source'/n)
    before=(COLD/'source-original'/n).read_text(encoding='utf-8');after=(COLD/'source'/n).read_text(encoding='utf-8')
    (COLD/(n+'.diff')).write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='main/source/'+n,tofile='cold/source/'+n)),encoding='utf-8')
for p in (COLD/'source').iterdir():
    if p.is_file():differences.append({'file':p.name,'same_main_bytes':p.read_bytes()==(MAIN/'source'/p.name).read_bytes(),'allowed_boundary_repair':p.name in ['l02_selection.py','run_l02_study.py']})
assert all(v['same_main_bytes']or v['allowed_boundary_repair']for v in differences)
assert all((COLD/'source'/n).read_bytes()==(MAIN/'source'/n).read_bytes()for n in ['l02_daily_reference.py','daily_data.py','decode_materials.py','material_contract.py','asof_input.py','reference-pool.json','material-contract.json','study-contract.draft.json'])
raw=[{'file':p.name,'same_main_bytes':p.read_bytes()==(MAIN/'raw'/p.name).read_bytes()}for p in (COLD/'raw').iterdir()if p.is_file()]
assert all(v['same_main_bytes']for v in raw)
for folder in ['source','raw']:
    for p in (COLD/folder).rglob('*'):
        if p.is_file():p.chmod(0o444)
image='sha256:23ff8bfbf8055caa0b9fa5745ddb27cceea2f31d7d15b7a900c81112cdfe8ddf'
argv=['C:/Python314/python.exe','-X','utf8','-B',str(COLD/'source/run_l02_study.py'),'--raw',str(COLD/'raw'),'--material-contract',str(COLD/'source/material-contract.json'),'--study',str(COLD/'source/study-contract.draft.json'),'--pool',str(COLD/'source/reference-pool.json'),'--image',image,'--outer-id','outer-20250620','--out',str(COLD/'run')]
registration={'at':datetime.now(timezone.utc).isoformat(),'authorization':'Parent explicitly authorized exactly one June20 outer plus3inner source-only cold, sequential10processes1CPU/networknone. No other worker/model/solver/Provider/GPU/UI/user action. Own exact CIDs collected before cleanup.','argv':argv,'source_identity':differences,'raw_identity':raw,'prediction_code_and_parameters_same_main':True,'allowed_source_repairs':['l02_selection.py context type/facility boundary','run_l02_study.py typed sealed-author facility propagation only'],'outputs_new':not(COLD/'run').exists(),'task_total_budget':None,'candidate_score':None}
(COLD/'registration-before-start.json').write_text(json.dumps(registration,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'root':str(COLD),'argv':argv,'source_changes':[r['file']for r in differences if not r['same_main_bytes']],'prediction_and_pool_same':True},ensure_ascii=False))
