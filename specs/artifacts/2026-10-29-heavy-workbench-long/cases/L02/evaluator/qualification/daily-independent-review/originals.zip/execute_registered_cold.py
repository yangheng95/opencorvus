"""Execute exactly the one pre-registered June20 numerical reference loop."""
from datetime import datetime,timezone
import json,os
from pathlib import Path
import subprocess,time
ROOT=Path(__file__).resolve().parent/'cold-june20'
registration=json.loads((ROOT/'registration-before-start.json').read_text(encoding='utf-8'))
started=datetime.now(timezone.utc).isoformat();clock=time.perf_counter()
with subprocess.Popen(registration['argv'],cwd=ROOT/'source',stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8')as child:
    (ROOT/'owned-runner-process.json').write_text(json.dumps({'observer_pid':os.getpid(),'runner_pid':child.pid,'started_utc':started,'argv':registration['argv'],'scope':'Only this exact authorized runner and its UUID container CIDs; no other process operation.'},indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'started':started,'own_runner_pid':child.pid,'out':str(ROOT/'run')}),flush=True)
    stdout,stderr=child.communicate()
    (ROOT/'runner.stdout.txt').write_text(stdout,encoding='utf-8');(ROOT/'runner.stderr.txt').write_text(stderr,encoding='utf-8')
    receipt={'argv':registration['argv'],'cwd':str(ROOT/'source'),'started_utc':started,'finished_utc':datetime.now(timezone.utc).isoformat(),'exit_code':child.returncode,'seconds':time.perf_counter()-clock,'stdout_file':'runner.stdout.txt','stderr_file':'runner.stderr.txt'}
    (ROOT/'runner-command.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(receipt,ensure_ascii=False),flush=True)
    print(stdout,flush=True)
