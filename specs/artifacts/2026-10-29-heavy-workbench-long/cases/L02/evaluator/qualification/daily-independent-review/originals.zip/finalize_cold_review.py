"""Archive actual cold-loop conclusions. No fitting, scoring total or Docker."""
from datetime import datetime,timezone
from fractions import Fraction
import json
from pathlib import Path
import subprocess

ROOT=Path(__file__).resolve().parent
COLD=ROOT/'cold-june20'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
jan=read(ROOT/'main-january-audit/assessment.json');june=read(COLD/'independent-audit/assessment.json');scope=read(ROOT/'isolation-and-decoder/assessment.json')
procs=read(COLD/'independent-audit/processes.json')
assert len(procs)==10 and len({p['cid']for p in procs})==10
save(COLD/'owned-final-CIDs.json',{'exact_own_containers':procs,'handling':'Each completed naturally; its actual terminal/input/output/source ZIP was closed before docker rm of this exact CID. Original per-job cleanup commands are retained. No global enumeration/cancel/restart or other user container operation.','terminal_and_cleanup_proof':'run/outer/outer-20250620/**/{terminal-inspect.json,completed-originals.zip,cleanup-command.json}'})
imputation=[]
for job in (COLD/'run').rglob('fit.json'):
    fit=read(job);cfg=fit['method']['configuration']
    outerforecast=read(job.parent/'forecast.json');targets=sorted({v['target_tick']for v in outerforecast['forecasts']})
    for block in [{'origin_tick':fit['origin_tick'],'target_ticks':targets,'fit':fit['fit']}]+fit['calibration']:
        expected=[block['target_ticks'][-1]]if cfg['algorithm']=='ridge'and cfg['use_weather']else[]
        for s,v in block['fit'].items():imputation.append({'method':fit['method']['method_id'],'current_origin':fit['origin_tick'],'fit_origin':block['origin_tick'],'series':s,'actual_imputed':v['future_temperature_imputed_ticks'],'expected':expected,'passed':v['future_temperature_imputed_ticks']==expected})
save(COLD/'imputation-observations.json',{'groups':len(imputation),'all_passed':all(v['passed']for v in imputation),'observations':imputation,'scope':'Actual declared missing14th-day weather-imputation trace and no-weather/seasonal trace; source+physical legal packets establish publication. No new model run.'})
(ROOT/'REVIEW-COLD-JUNE20.md').write_text('''# L02 actual representative pipeline and independent June20 cold

The isolated daily-reference/selection pipeline is locally qualified on the actual January representative and this one independent June20 reconstruction. January148 checks pass; June20148 checks pass;51 additional physical-namespace/decoder/original-object checks pass. There is no remaining identified functional blocker in this scope. The June20 group may count as that registered outer and its three inners in the full12outer reference matrix, with no repeat needed. This is an author reference qualification, not a full L02 research delivery, quality floor/rubric/freeze, candidate result, professional/statistical certification or effective-hours proof.

## Exact run and ownership

Only one new independent numerical loop ran. Registration before start fixes outer-20250620, existing pool/contract/image and all actual argv. Main/source original is preserved in cold-june20/source-original; only l02_selection.py and run_l02_study.py were replaced by the explicitly authorized context-type/facility-error repairs, with exact diffs. All five model worker files, raw eight-file packet, method pool, material/study contracts and prediction parameters remain byte-identical to the completed January reference. No outcome-driven tuning took place.

Own host runner PID99784 started2026-10-30T03:44:51.389762Z and naturally exited0 at03:45:41.364847Z. Wrapper49.973713s, actual program49.774539s. It created exactly ten UUID containers sequentially:6inner forecasts,1selector,3outer method forecasts, each1CPU/networknone and single-thread BLAS/OpenMP. All naturally exited0. Every actual per-job create/start/initial/terminal/argv/source/input/output receipt is retained; terminal/input/output/source were sealed in that job's ZIP before exact same-CID removal. owned-final-CIDs.json lists all ten. No global container listing, unrelated container action, restart/cancel, GPU, Provider, LLM candidate or UI operation occurred. Parent's later remaining-ten-outer run is separate and was not inspected/operated here.

Actual mounts have only readonly minimal /project, readonly this-job /input, new writable /output. Recursive source file sets are exactly the five predictor or four selector files; predictor input is method.json plus packet.json/two原CSV, selector input exactly inner.json/study.json. This includes subdirectories, not just top-level filenames. The shared dependency image is the same immutable prepared dependency resource; no answer/DGP is mounted in a model worker. All copies/byte checks identify actual objects, not source-correctness gates.

## Independent input, time, arithmetic and selection checks

audit_completed_loop.py imports no author model/scorer and starts no fit/process/container. It reconstructs raw CSV/UTC/units independently, SQL-selects the full authorized vintage sets and compares every packet original row and registered business identity. No canonical answers, scale/label/role or sibling result sidecar is in the model input. Full current vintage history is retained so earlier calibration pseudo-origins can lawfully reproject. All four origin packets and every method copy are exactly authorized, rather than accepting selfreported max_time/PASS.

For all nine forecast cells, complete84series-target rows, nonnegative ordered quantiles, additive mean tolerance and all per-node/aggregate fixed-scale MSE/MAE/WIS values are independently recomputed with exact Fraction arithmetic. Actual2023scale source rows/parent sums and genuine terminal label release times are checked. Each three-inner label frame is actually published before this outer and contains only its assigned target labels; every prediction equals the actual worker artifact. Exact complete-inner losses determine the lexical-tie minimum, matching the real separate selector's existing ID. Frozen method parameters are inherited by outer invocations; no selector-generated parameters or fit state enter an outer model.

Both January and June20 legitimately select ridge-weather-operations. June inner scaled MSE≈.00344840 versus seasonal≈.00849374; all exact ratios are retained. This choice does not use June outer errors. All mandatory cells remain present; fixed denominators are not reduced. No quality threshold or total has been invented.

144fit groups per outer were independently checked against authorized latest-revision observations: training window counts/max event times, actual feature identities and complete currently-known calibration target sets. Maximum revision is selected including missing before validity; an older valid value is not revived. All three historical pseudo-folds use point-only base_predict, not recursive calibration, with labels known at the current origin. Each run has42paired fourleaf residual vectors. Source inspection plus observed packet/process boundaries supports causal data flow; these checks do not claim an independent retraining of every QR coefficient or a proof of fitted-model optimality.

The true no-weather ablation has the declared effective feature list without temperature in both current/pseudo fits, and its actual runs use the same no-weather config throughout. Weather imputation trace is separately recorded for144groups: missing final target day is explicitly imputed using permitted historical month data; seasonal/no-weather traces remain their proper empty-imputation behavior. Closed-station gating is after residual addition before aggregate sample summation. In June, two ridge methods each output A2zero mean/all seven quantiles on the four closed days:8actual active closure cases. January had0closed target cases and cannot itself establish that active mechanism.

The refactored archive/development decoder's actual results also equal independent complete CSV/UTC/Fraction reconstruction; new public counts stay6823/21934. This closes the reader refactor's known-data positive behavior without generating materials again or reprojecting old54origins. Source helper and forecast source are identified in archived actual worker mounts, not merely by a new function name.

## Scientific result and remaining boundary

Actual outer metrics are retained, including negative weather contribution. January selected-weather scaled MSE≈.00082366/WIS≈.01242996 versus no-weather≈.00047474/.00916919. June selected-weather MSE≈.01963499/WIS≈.05829455 versus no-weather≈.01908818/.05588492. Seasonal June MSE≈.06540623. Do not retrofit no-weather into the two-ID selection pool, select using these outer errors, assert weather always helps or erase the ablation. The actual improvement/decline is a research result; two correlated outers are not a significance test. Selected ID remains correct under predeclared inner selection.

The two late error-boundary repairs affect only invalid selector context/typed author facility failures, not predictions/config/valid selection math. Parent's earlier null-context exception is separate original evidence; this reviewer did not rerun it or claim the old source executed the repair. The current author-reference runner's trusted status handling is not permission for arbitrary future candidate code to selfdeclare infrastructure immunity. A future candidate evaluator must keep that trust boundary explicit.

No new plots/report were requested/generated by this kernel; there is no visual-product or full-study visualization acceptance here. Pure later postprocessing must report all registered method/fold results without model/selection changes. Remaining ten outers require their own natural completion and complete independent output checks; their current in-progress state is not inferred as pass. Full comparison/low-quality controls, case quality floors/atomic rubric/grader, research/decision report and independent case freeze remain future work. Old hourly toy entry should retire from current runtime publication when this daily entry is accepted, while original historical ZIP/evidence stay intact; no fallback is part of the actual observed model source bundle.

Evidence: cold-june20/registration-before-start.json, runner-command/stdout/stderr, run/events and per-job receipts/ZIPs, independent-audit/{assessment,checks,processes,fit-permission-checks}.json; main-january-audit and isolation-and-decoder/main-originals preserve observed January originals; readable-method-metrics.json retains a readable approximation alongside the exact ratios. The main independent audits themselves took3.118974s and3.594153s, additional read-only namespace/reader audit1.300619s. Those durations and the50s numerical reference are not candidate thinking hours. Only this external directory was written; no delegation or repository/Git edit.
''',encoding='utf-8')
save(ROOT/'stage-assessment-cold.json',{'stage':'L02 daily isolated author reference + independent June20 cold locally qualified','blocking_current_scope':[],'January_existing_loop_independent_audit':{'checks':jan['checks'],'passed':jan['all_passed'],'actual_root_processes_observed':10,'new_January_forecast_runs':0},'June20_one_actual_independent_cold':{'program_seconds':read(COLD/'runner-command.json')['seconds'],'actual_processes':10,'natural_exit':0,'all_exact_own_CIDs_sealed_then_cleaned':True,'checks':june['checks'],'passed':june['all_passed'],'forecasts':9,'rows_each':84,'fit_groups':144,'paired_residual_samples':42,'closed_leaf_output_cases':8,'selector':'ridge-weather-operations'},'namespace_decoder_additive_audit':{'checks':scope['checks'],'passed':scope['all_passed']},'same_forecast_worker5_pool_parameters':True,'only_two_author_error_boundary_repairs':True,'June20_may_count_once_in_registered12outer_reference':True,'remaining10outer_results':'unassessed here; parent owned separate run','weather_ablation_outer_lower_errors_retained':True,'actual_total_or_candidate_score':None,'full_L02_quality_rubric_freeze_or_hours_approved':False,'new_LLM_Provider_GPU_UI_user_process_or_redelegation':0,'new_independent_forecast_groups':1,'new_independent_numerical_containers':10,'repository_edits':0,'completed_utc':datetime.now(timezone.utc).isoformat()})
(ROOT/'CURRENT-STAGE.md').write_text('''# Latest L02 independent stage

PLAN-REVIEW.md: original static implementation-plan opinion. No executed loop was approved at that time.

REVIEW-COLD-JUNE20.md and stage-assessment-cold.json: later actual January artifact audit and exactly one authorized independent June20 ten-process cold, all local permission/metric/selection/fit-source/isolation checks pass; own processes naturally terminal and exact own CIDs sealed then cleaned. June20 may be counted once in the registered12outer reference. Parent's remaining10results are not assessed here.

No full L02 research delivery/quality floor/rubric/freeze/candidate score/professional or hours approval. Original stages/receipts/failed-history boundaries are retained.
''',encoding='utf-8')
status=subprocess.run(['git','status','--short'],cwd='D:/myhexin-local/opencorvus',capture_output=True,text=True,encoding='utf-8');(ROOT/'git-status-cold-end.txt').write_text(status.stdout+status.stderr,encoding='utf-8')
print(json.dumps({'report':str(ROOT/'REVIEW-COLD-JUNE20.md'),'all_local_scope_checks_passed':True,'June20_may_count_once':True,'imputation_groups':len(imputation),'imputation_all_passed':all(v['passed']for v in imputation),'full_case_approved':False,'candidate_score':None},ensure_ascii=False))
