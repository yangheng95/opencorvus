"""Supplement exact namespace and two-role reader facts; no process/model run."""
import ast,csv,json,math,re,shutil,time
from collections import Counter,defaultdict
from datetime import datetime,timedelta,timezone
from decimal import Decimal
from fractions import Fraction
from pathlib import Path
ROOT=Path(__file__).resolve().parent
MAIN=Path('D:/opencorvus-benchmark-runs/l02-daily-loop-qualification-20261030/main')
COLD=ROOT/'cold-june20'
OUT=ROOT/'isolation-and-decoder';OUT.mkdir(exist_ok=False)
EPOCH=datetime(2022,1,1,tzinfo=timezone.utc)
def load(p):return json.loads(p.read_text(encoding='utf-8'))
code=Path('D:/opencorvus-benchmark-runs/l02-full-materials-independent-review-20261030/audit_materials.py').read_text(encoding='utf-8')
nodes=[n for n in ast.parse(code).body if isinstance(n,ast.FunctionDef)and n.name in {'table','utc','tick','read_independently'}]
exec(compile(ast.Module(body=nodes,type_ignores=[]),'reviewer_csv_oracle','exec'),globals())
checks=[]
def ck(n,v,d=None):checks.append({'name':n,'passed':bool(v),'detail':d})
start=time.perf_counter();namespace=[]
for label,run in [('main-January',MAIN/'representative'),('reviewer-June',COLD/'run')]:
    for terminal in run.rglob('terminal-inspect.json'):
        term=load(terminal);job=terminal.parent;selector='l02_selection.py'in term['Args'];mounts={v['Destination']:v for v in term['Mounts']}
        src=Path(mounts['/project']['Source']);inp=job/'input'
        wanted={'l02_selection.py','l02_scoring.py','material_contract.py','asof_input.py'}if selector else{'l02_daily_reference.py','daily_data.py','decode_materials.py','material_contract.py','asof_input.py'}
        files={p.relative_to(src).as_posix()for p in src.rglob('*')if p.is_file()};inputfiles={p.relative_to(inp).as_posix()for p in inp.rglob('*')if p.is_file()}
        expected_input={'inner.json','study.json'}if selector else{'method.json','packet/packet.json','packet/observations.csv','packet/covariate-vintages.csv'}
        ck('full_recursive_namespace_'+label+'_'+job.relative_to(run).as_posix(),files==wanted and inputfiles==expected_input)
        namespace.append({'set':label,'job':job.relative_to(run).as_posix(),'CID':term['Id'],'source_files':sorted(files),'input_files':sorted(inputfiles)})
        if not selector:
            meta=load(inp/'packet/packet.json');hierarchy=table(MAIN/'raw/hierarchy.csv');study=load(run/'source/study-contract.draft.json')
            ck('complete_packet_static_metadata_'+label+'_'+job.relative_to(run).as_posix(),meta['hierarchy']==hierarchy and meta['units']==load(MAIN/'raw/units.json')and meta['quantiles']==study['quantiles'])
    for name,envval in [('OPENBLAS_NUM_THREADS=1',None),('OMP_NUM_THREADS=1',None)]:
        ck('actual_singlethread_setting_'+label+'_'+name,all(name in load(p)['argv']for p in run.rglob('create-command.json')))
raw,_,_=read_independently(MAIN/'raw');dev,_,_=read_independently(MAIN/'development')
ck('refactored_archive_decoder_actual_complete_values',raw==load(MAIN/'decoder-archive/canonical.json')and load(MAIN/'decoder-archive-command.json')['exitcode']==0)
ck('refactored_development_decoder_actual_complete_values',dev==load(MAIN/'decoder-development/canonical.json')and load(MAIN/'decoder-development-command.json')['exitcode']==0)
ck('new_boundary_actual_public_counts',len(dev['observations'])==6823 and len(dev['covariates'])==21934)
same=[]
for p in (COLD/'source').iterdir():
    if p.is_file():same.append({'file':p.name,'same_main':p.read_bytes()==(MAIN/'source'/p.name).read_bytes(),'allowed_error_boundary_only':p.name in['l02_selection.py','run_l02_study.py']})
ck('only_two_error_boundary_changes_no_forecast_tune',all(v['same_main']or v['allowed_error_boundary_only']for v in same))
ck('all_actual_forecast_worker5_same_Jan_June',all((MAIN/'representative/worker-source'/n).read_bytes()==(COLD/'run/worker-source'/n).read_bytes()for n in ['l02_daily_reference.py','daily_data.py','decode_materials.py','material_contract.py','asof_input.py']))
ck('all_raw_eight_objects_identical_main_reviewer',all(p.read_bytes()==(MAIN/'raw'/p.name).read_bytes()for p in(COLD/'raw').iterdir()if p.is_file()))
for n in ['material-contract.json','study-contract.draft.json','reference-pool.json']:
    ck('exact_same_predeclared_contract_'+n,(MAIN/'source'/n).read_bytes()==(COLD/'source'/n).read_bytes())
snapshot=OUT/'main-originals'
shutil.copytree(MAIN/'representative',snapshot/'representative')
for n in ['source','raw','development','decoder-archive','decoder-development']:shutil.copytree(MAIN/n,snapshot/n)
for p in MAIN.glob('*.json'):shutil.copy2(p,snapshot/p.name)
result={'checks':len(checks),'all_passed':all(v['passed']for v in checks),'failed':[v['name']for v in checks if not v['passed']],'namespaces':namespace,'unchanged_source_facts':same,'seconds':time.perf_counter()-start,'main_actual_originals_copied':str(snapshot),'new_Docker_fit_forecast_solver_Provider_calls':0,'scope':'Physical recursive namespace, original-data reader output and object identity; not a new model run.'}
(OUT/'checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');(OUT/'assessment.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in result.items()if k not in['namespaces','unchanged_source_facts']},ensure_ascii=False))
