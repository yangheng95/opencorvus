"""Only bind the two-line plot presentation change and actual viewed PNG."""
import difflib,json,shutil,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'visual-color-addendum';OUT.mkdir(exist_ok=False)
CASE=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L02/evaluator')
SUM=Path('D:/opencorvus-benchmark-runs/l02-daily-loop-qualification-20261030/main/full-reference-summary')
old=SUM/'render-job/source/plot_l02_study.py';new=CASE/'current-source/plot_l02_study.py';run=SUM/'render-color-repair'
def load(p):return json.loads(p.read_text(encoding='utf-8'))
before=old.read_text();after=new.read_text()
expected=before.replace("            axis.plot(dates,[rows[t]['mean'] for t in selected['target_ticks']],'.-',label=method)","            line=axis.plot(dates,[rows[t]['mean'] for t in selected['target_ticks']],'.-',label=method)[0]").replace("alpha=.15)\n","alpha=.15,color=line.get_color())\n")
checks={'only_two_line_color_binding':after==expected,'rendered_source_equals_current':new.read_bytes()==(run/'source/plot_l02_study.py').read_bytes(),'same_original_plot_input':(SUM/'plot-input.json').read_bytes()==(run/'input/plot-input.json').read_bytes(),'published_PNG_equals_new_render':(CASE/'qualification/daily-full-reference/june20-forecasts.png').read_bytes()==(run/'output/figures/june20-forecasts.png').read_bytes(),'new_render_natural_exit0':load(run/'terminal-inspect.json')['State']['ExitCode']==0 and load(run/'terminal-inspect.json')['State']['Status']=='exited'}
for source,name in [(old,'source-before.py'),(new,'source-color-fixed.py'),(CASE/'qualification/daily-full-reference/june20-forecasts.png','viewed-june20-color-fixed.png'),(run/'terminal-inspect.json','render-terminal-inspect.json'),(run/'execution-command.json','render-execution-command.json')]:shutil.copy2(source,OUT/name)
(OUT/'source.diff').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='original_render',tofile='color_fixed')),encoding='utf-8')
result={'all_passed':all(checks.values()),'checks':checks,'actually_viewed':True,'view_image_original_size':[2240,1190],'observations':'Orange central80 band now matches orange selected weather mean in all six panels. Dates/units/legend and A1/ZA underprediction remain visible.','nonblocking_color_suggestion':'resolved','previous_report_and_blue_PNG_preserved':True,'new_forecast_numeric_Docker_Provider_solver_calls_by_reviewer':0,'candidate_score':None,'full_L02_frozen':False,'hours_qualified':False}
(OUT/'assessment.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
status=subprocess.run(['git','status','--short'],cwd='D:/myhexin-local/opencorvus',capture_output=True,text=True,encoding='utf-8');(OUT/'git-status-readonly.txt').write_text(status.stdout,encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
