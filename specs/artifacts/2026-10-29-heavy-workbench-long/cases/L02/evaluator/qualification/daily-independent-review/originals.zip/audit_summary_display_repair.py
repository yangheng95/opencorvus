"""Repair only reviewer display comparisons. Original arithmetic/false receipts stay intact."""
import csv,json,shutil,time
from pathlib import Path
from fractions import Fraction as F
ROOT=Path(__file__).resolve().parent
MAIN=Path('D:/opencorvus-benchmark-runs/l02-daily-loop-qualification-20261030/main')
OUT=ROOT/'full-summary-display-repair';OUT.mkdir(exist_ok=False)
shutil.copy2(ROOT/'audit_full_summary.py',ROOT/'full-summary-audit/auditor-executed.py')
started=time.perf_counter();checks=[]
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def ck(n,ok):checks.append({'name':n,'passed':bool(ok)})
runs=[MAIN/'representative',ROOT/'cold-june20/run',MAIN/'remaining-ten']
where={g:r for r in runs for g in load(r/'registration.json')['outer_ids']}
summary=load(MAIN/'full-reference-summary/assessment.json');srows={r['outer_id']:r for r in summary['rows']};plot=load(MAIN/'full-reference-summary/plot-input.json');prows={r['outer_id']:r for r in plot['origins']}
methods=load(runs[0]/'registration.json')['pool']['outer_ids']
for gid,run in sorted(where.items()):
    for mid in methods:
        fc=load(run/'outer'/gid/'outer'/mid/'output/result/forecast.json')
        expected=[{'series_id':r['series_id'],'target_tick':r['target_tick'],'mean':float(F(str(r['mean']))),'lower80':float(F(str(next(v for q,v in r['quantiles'].items()if F(q)==F(1,10))))),'upper80':float(F(str(next(v for q,v in r['quantiles'].items()if F(q)==F(9,10)))))}for r in fc['forecasts']]
        ck('plot_curve_actual_mean_and_interval_'+gid+'_'+mid,prows[gid]['curves'][mid]==expected)
for r in csv.DictReader((MAIN/'full-reference-summary/outer-metrics.csv').open(encoding='utf-8',newline='')):
    exact=srows[r['outer_id']]['metrics'][r['method_id']]['metrics_exact']
    ck('csv_display_'+r['outer_id']+'_'+r['method_id'],all(r[k]==format(float(F(exact[k])),'.12g')for k in ['scaled_mse','scaled_mae','scaled_wis'])and r['selected']==('1'if r['method_id']==srows[r['outer_id']]['selected_method_id']else'0'))
old=load(ROOT/'full-summary-audit/assessment.json');failnames=set(old['failed']);fixednames={c['name']for c in checks}
assert failnames==fixednames and len(checks)==72
result={'checks':len(checks),'all_passed':all(c['passed']for c in checks),'failed':[c['name']for c in checks if not c['passed']],'original_passed_unchanged':old['checks']-len(old['failed']),'final_semantic_checks':old['checks'],'original_failure_causes':{'36_plot_checks':'Reviewer parsed plot JSON decimals exactly then compared with binary float display values. Repaired display-only reader uses actual JSON float semantics; exact metric computation remains Fraction.','36_CSV_checks':'Reviewer assumed string True/False, while actual documented display is 1/0. Both selected flags are now bound semantically to selector ID.','original_exit1':'After all 172 checks/outputs were saved, reviewer tried to JSON serialize Decimal seconds in final print; unrelated to author program. Original stdout/stderr and exit1 remain.'},'seconds':time.perf_counter()-started,'new_forecast_fit_solver_Docker_Provider_calls':0}
for name,value in [('checks.json',checks),('assessment.json',result)]: (OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
