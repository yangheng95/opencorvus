"""Only two local runner input/error CLIs; creates no numerical process."""
from datetime import datetime,timezone
import difflib,json
from pathlib import Path
import shutil,subprocess,time
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'output-ownership-addendum';OUT.mkdir(exist_ok=False)
SRC=OUT/'source';SRC.mkdir()
OLD=ROOT/'cold-june20/source'
CURRENT=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L02/evaluator/current-source/run_l02_study.py')
for p in OLD.iterdir():
    if p.is_file():(SRC/p.name).write_bytes(p.read_bytes())
before=(SRC/'run_l02_study.py').read_text(encoding='utf-8');after=CURRENT.read_text(encoding='utf-8')
(OUT/'driver-before.py').write_text(before,encoding='utf-8');(SRC/'run_l02_study.py').write_text(after,encoding='utf-8')
(OUT/'current-driver.diff').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='actual June driver',tofile='output-owner repaired driver')),encoding='utf-8')
MAIN=Path('D:/opencorvus-benchmark-runs/l02-daily-loop-qualification-20261030')
for n in ['output-reentry-initial-receipt.json','output-reentry-repaired-receipt.json']:shutil.copy2(MAIN/n,OUT/n)
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
common=['C:/Python314/python.exe','-X','utf8','-B',str(SRC/'run_l02_study.py'),'--raw',str(ROOT/'cold-june20/raw'),'--material-contract',str(SRC/'material-contract.json'),'--study',str(SRC/'study-contract.draft.json'),'--pool',str(SRC/'reference-pool.json'),'--image','sha256:23ff8bfbf8055caa0b9fa5745ddb27cceea2f31d7d15b7a900c81112cdfe8ddf']
sentinel=OUT/'owned-existing-sentinel';sentinel.mkdir();original=b'{"status":"previous_synthetic_sentinel","value":23}\n';(sentinel/'assessment.json').write_bytes(original)
cases=[]
for name,argv in [('existing-output',common+['--out',str(sentinel)]),('new-output-invalid-outer',common+['--out',str(OUT/'owned-new-invalid'),'--outer-id','unregistered-reviewer-control'])]:
    started=time.perf_counter();p=subprocess.run(argv,cwd=SRC,capture_output=True,text=True,encoding='utf-8',timeout=20)
    (OUT/(name+'.stdout.txt')).write_text(p.stdout,encoding='utf-8');(OUT/(name+'.stderr.txt')).write_text(p.stderr,encoding='utf-8')
    result=json.loads(p.stdout);record={'argv':argv,'exit_code':p.returncode,'seconds':time.perf_counter()-started,'actual':result};save(OUT/(name+'-command.json'),record);cases.append(record)
same=(sentinel/'assessment.json').read_bytes()==original
new=OUT/'owned-new-invalid';assessment=json.loads((new/'assessment.json').read_text(encoding='utf-8'))
checks=[{'name':'existing_directory_maps_explicit_output_ownership_error_and_retains_original','passed':cases[0]['exit_code']==3 and cases[0]['actual']['status']=='run_invalid'and cases[0]['actual']['error']=='output_directory_unavailable'and same},{'name':'new_directory_owns_its_invalid_outer_receipt','passed':cases[1]['exit_code']==3 and cases[1]['actual']['status']=='run_invalid'and assessment==cases[1]['actual']and assessment['detail']=='registered_outer_identity'}]
result={'checks':checks,'all_passed':all(v['passed']for v in checks),'actual_local_CLI':2,'new_forecast_Docker_solver_Provider_calls':0,'new_sentinel_is_synthetic_owned_directory':True,'source_same_current':CURRENT.read_bytes()==(SRC/'run_l02_study.py').read_bytes(),'executed_June_driver_preserved_unchanged':(ROOT/'cold-june20/source/run_l02_study.py').read_text(encoding='utf-8')==before,'candidate_score':None,'completed_utc':datetime.now(timezone.utc).isoformat()}
save(OUT/'assessment.json',result);print(json.dumps(result,ensure_ascii=False))
