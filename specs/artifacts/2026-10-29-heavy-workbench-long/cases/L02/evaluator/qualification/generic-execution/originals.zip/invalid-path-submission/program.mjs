import fs from 'node:fs';
const read = p => JSON.parse(fs.readFileSync(p, 'utf8'));
const mode = process.argv[2];
fs.mkdirSync('/output/result');
const write = (p, value) => fs.writeFileSync('/output/result/' + p, JSON.stringify(value));
function csv(text) {
  const rows=[];let row=[],field='',quoted=false;
  for(let i=0;i<text.length;i++) {const c=text[i];
    if(c==='"') {if(quoted&&text[i+1]==='"'){field+='"';i++;}else quoted=!quoted;}
    else if(!quoted&&(c===','||c==='\n')) {row.push(field.replace(/\r$/,''));field='';if(c==='\n'){rows.push(row);row=[];}}
    else field+=c;
  }
  if(field||row.length){row.push(field.replace(/\r$/,''));rows.push(row);}
  const headers=rows.shift();return rows.map(r=>Object.fromEntries(headers.map((h,i)=>[h,r[i]])));
}
function litres(value, multiplier) {
  const [integer, decimals='']=value.split('.');const denominator=10n**BigInt(decimals.length);
  const numerator=BigInt(integer+decimals)*BigInt(multiplier);
  if(numerator%denominator)throw Error('nonintegral unit conversion');
  return Number(numerator/denominator);
}
if(mode==='predict') {
  const meta=read('/input/packet/packet.json'),method=read('/input/method.json'),config=method.configuration;
  const epoch=Date.parse(meta.clock.epoch_utc);const tick=value=>(Date.parse(value)-epoch)/3600000;
  const latest=new Map();
  for(const r of csv(fs.readFileSync('/input/packet/observations.csv','utf8'))) {
    const event=tick(r.event_end_utc),release=tick(r.release_time_utc),revision=Number(r.revision_id);
    if(event>=meta.origin_tick||release>meta.origin_tick)throw Error('unauthorized original row');
    const key=r.series_id+'\0'+event;
    if(!latest.has(key)||revision>latest.get(key).revision)latest.set(key,{...r,event,revision});
  }
  const leaves=meta.series_catalogue.filter(n=>n.kind==='leaf');let all=[];
  for(const node of leaves) {
    const history=[...latest.values()].filter(r=>r.series_id===node.series_id&&r.quality_flag==='valid'&&r.event>=meta.origin_tick-365*24).sort((a,b)=>b.event-a.event);
    if(history.length<56)throw Error('insufficient_history');
    for(const target of meta.target_ticks) {
      const chosen=config.algorithm==='constant'?history:history.filter(r=>((r.event-target)%168+168)%168===0).slice(0,config.repeats);
      if(!chosen.length)throw Error('insufficient_weekday');
      const mean=Math.round(chosen.reduce((s,r)=>s+litres(r.value,meta.units[r.unit].multiplier),0)/chosen.length);
      all.push({series_id:node.series_id,target_tick:target,mean,quantiles:Object.fromEntries(meta.quantiles.map(q=>[q,Math.round(mean*(.7+.6*Number(q)))]))});
    }
  }
  for(const node of meta.series_catalogue.filter(n=>n.kind==='aggregate'))for(const target of meta.target_ticks) {
    const edges=meta.hierarchy.filter(e=>e.parent===node.series_id);
    const total=field=>edges.reduce((s,e)=>s+Number(e.weight)*field(all.find(r=>r.series_id===e.child&&r.target_tick===target)),0);
    all.push({series_id:node.series_id,target_tick:target,mean:total(r=>r.mean),quantiles:Object.fromEntries(meta.quantiles.map(q=>[q,total(r=>r.quantiles[q])]))});
  }
  write('forecast.json',{format:'l02-distribution-forecasts/1',method_id:method.method_id,origin_tick:meta.origin_tick,forecasts:all});
} else if(mode==='select') {
  const packet=read('/input/inner.json');
  const gcd=(a,b)=>b?gcd(b,a%b):a;
  const rational=(a,b=1n)=>{if(b<0n){a=-a;b=-b;}const g=gcd(a<0n?-a:a,b);return [a/g,b/g];};
  const parse=s=>{const [a,b='1']=String(s).split('/');return rational(BigInt(a),BigInt(b));};
  const add=(x,y)=>rational(x[0]*y[1]+y[0]*x[1],x[1]*y[1]);
  const divide=(x,d)=>rational(x[0],x[1]*BigInt(d));
  const values={};
  for(const id of packet.selection_ids) {
    let overall=[0n,1n];
    for(const frame of packet.frames) {
      const truth=new Map(frame.labels.map(r=>[r.series_id+'\0'+r.target_tick,r.value]));
      let score=[0n,1n];
      for(const kind of ['leaf','aggregate']) {
        const nodes=frame.context.series_catalogue.filter(n=>n.kind===kind);let layer=[0n,1n];
        for(const node of nodes) {
          let total=[0n,1n];const scale=parse(frame.context.scales_litres[node.series_id]);
          for(const r of frame.forecasts[id].forecasts.filter(r=>r.series_id===node.series_id)) {
            const delta=BigInt(r.mean-truth.get(r.series_id+'\0'+r.target_tick))*scale[1];
            total=add(total,rational(delta*delta,scale[0]*scale[0]));
          }
          layer=add(layer,divide(total,frame.context.target_ticks.length));
        }
        score=add(score,divide(layer,2*nodes.length));
      }
      overall=add(overall,score);
    }
    values[id]=divide(overall,packet.frames.length);
  }
  const unicodeCompare=(a,b)=>{const x=Array.from(a,c=>c.codePointAt(0)),y=Array.from(b,c=>c.codePointAt(0));for(let i=0;i<Math.min(x.length,y.length);i++)if(x[i]!==y[i])return x[i]-y[i];return x.length-y.length;};
  const ids=[...packet.selection_ids].sort((a,b)=>{const d=values[a][0]*values[b][1]-values[b][0]*values[a][1];return d<0n?-1:d>0n?1:unicodeCompare(a,b);});
  write('selection.json',{format:'l02-selection/1',outer_origin_tick:packet.outer_origin_tick,selected_method_id:ids[0],method_mean_inner_scaled_mse:Object.fromEntries(Object.entries(values).map(([k,v])=>[k,v[0]+'/'+v[1]]))});
} else if(mode==='report') {
  const data=read('/input/results.json');
  write('report.json',{format:'l02-report-receipt/1',outer_ids:data.outer_ids});
  fs.writeFileSync('/output/result/report.md','# Node numerical protocol diagnostic\n\nAll predictions are from original authorized CSV packets.\n\n'+JSON.stringify({complete_assignment:data.complete_assignment,choices:data.outer_results.map(r=>[r.outer_id,r.selected_method_id]),metrics:data.aggregate_exact},null,2)+'\n\nNo scientific quality, candidate score, or hour qualification is claimed.\n');
} else throw Error('assigned mode required');
console.log(JSON.stringify({status:'program_completed',mode,runtime:process.version}));
