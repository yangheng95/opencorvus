"""Read-only original lifecycle evidence audit; no Docker or submitted program execution."""
import ast,io,json,shutil,sqlite3,time,zipfile
from pathlib import Path,PurePosixPath
ROOT=Path(__file__).resolve().parent
Q=Path('D:/opencorvus-benchmark-runs/l02-generic-execution-qualification-20261030')
OUT=ROOT/'implementation-stage1';OUT.mkdir(exist_ok=False)
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
started=time.perf_counter();checks=[]
def ck(n,v):checks.append({'name':n,'passed':bool(v)})
shutil.copytree(Q/'source-current',OUT/'source-current-executed')
shutil.copytree(Q/'record-run',OUT/'record-run-originals')
for p in Q.glob('record-*.json'):shutil.copy2(p,OUT/p.name)
for p in Q.glob('checkpoint-*.json'):shutil.copy2(p,OUT/p.name)
for n in ['record_probe.py','run_recovery_qualification.py','failure-command.json']:shutil.copy2(Q/n,OUT/n)
shutil.copytree(Q/'failure-run',OUT/'failure-run-originals')
for n in ['l02_execution.py','run_l02_study.py']:shutil.copy2(Q/'source-initial'/n,OUT/('failure-initial-'+n))
job=Q/'record-run/cells/1';db=sqlite3.connect((Q/'record-run/runs.sqlite3').as_uri()+'?mode=ro',uri=True);db.row_factory=sqlite3.Row
cell=dict(db.execute('SELECT * FROM cell').fetchone());events=[dict(r)for r in db.execute('SELECT * FROM event ORDER BY id')]
ck('single_SQLite_v1_verified_originalCID',db.execute('pragma user_version').fetchone()[0]==1 and db.execute('select count(*)from cell').fetchone()[0]==1 and cell['phase']=='verified'and cell['exitcode']==0)
db.close();cid=cell['cid'];commands={p.name:load(p)for p in job.glob('*.json')}
creates=[r for r in commands.values()if r['argv'][1:2]==['create']];starts=[r for r in commands.values()if r['argv'][1:2]==['start']];removes=[r for r in commands.values()if r['argv'][1:2]==['rm']]
ck('one_real_create_one_start_one_exact_remove',len(creates)==len(starts)==len(removes)==1 and creates[0]['stdout'].strip()==cid and starts[0]['argv']==['docker','start',cid]and removes[0]['argv']==['docker','rm',cid]and all(r['exitcode']==0 for r in creates+starts+removes))
inspects=[json.loads(r['stdout'])[0]for r in commands.values()if r['argv'][1:2]==['inspect']and r['exitcode']==0]
ck('all_native_inspects_sameCID_name',len(inspects)>=5 and all(r['Id']==cid and r['Name']=='/'+cell['name']for r in inspects))
actualstart={r['State']['StartedAt']for r in inspects if not r['State']['StartedAt'].startswith('0001-')};actualfinish={r['State']['FinishedAt']for r in inspects if not r['State']['FinishedAt'].startswith('0001-')}
ck('same_physical_StartedAt_FinishedAt_no_restart',len(actualstart)==len(actualfinish)==1 and all(r['RestartCount']==0 and r['HostConfig']['RestartPolicy']['Name']=='no'for r in inspects))
ck('actual_isolation_current_contract',all(r['HostConfig']['NetworkMode']=='none'and r['HostConfig']['NanoCpus']==1000000000 and r['HostConfig']['ReadonlyRootfs']and not r['HostConfig']['Privileged']and set(r['HostConfig']['CapDrop'])=={'ALL'}and len(r['Mounts'])==3 and {m['Destination']:m['RW']for m in r['Mounts']}=={'/project':False,'/input':False,'/output':True}and set(r['HostConfig']['Tmpfs'])=={'/tmp'}for r in inspects))
def archive(p):
 with zipfile.ZipFile(p)as z:return {n:z.read(n)for n in z.namelist()}
prepared=archive(job/'prepared.zip');terminal=archive(job/'terminal.zip');accepted=archive(job/'accepted.zip')
ck('prepared_exact_source_input_program_sealed',all(terminal[n]==v for n,v in prepared.items())and all((job/'work'/n).read_bytes()==v for n,v in prepared.items()if n.startswith(('project/','input/'))))
ck('accepted_only_adds_assessment_to_original_terminal',set(accepted)==set(terminal)|{'assessment.json'}and all(accepted[n]==v for n,v in terminal.items()))
native=json.loads(terminal['terminal-inspect.json']);ck('actual_effect_count1_stdout1_native_exit0',terminal['output/count.txt']==b'1'and terminal['stdout.txt']==b'1\n'and native['Id']==cid and native['State']['Status']=='exited'and native['State']['ExitCode']==0 and native['State']['StartedAt']in actualstart and native['State']['FinishedAt']in actualfinish)
ck('assessment_count1_agrees_actual_effect',json.loads(accepted['assessment.json'])=={'status':'record_once_verified','count':1})
stagephases={'create_returned':('prepared',None),'start_returned':('created',cid),'terminal_sealed':('terminal',cid),'accepted_sealed':('terminal',cid),'verified':('verified',cid)}
for stage,(phase,boundcid)in stagephases.items():
 cp=load(Q/('checkpoint-'+stage+'.json'));cmd=load(Q/('record-'+stage+'-command.json'))
 ck('actual_crash_checkpoint_'+stage,cp['stage']==stage and cp['cell']['phase']==phase and cp['cell']['cid']==boundcid and cmd['exitcode']==81 and not cmd['stderr']and cmd['argv'][-1]==stage)
owner=load(Q/'checkpoint-create_returned.json')['concurrent_owner'];response=json.loads(owner['stdout'])
ck('actual_competing_owner_run_busy',owner['exitcode']==3 and response['status']=='run_invalid'and response['error']=='run_busy'and owner['argv'][-2:]==['--resume',str(Q/'record-run')])
lifecycle=[json.loads(e['facts'])for e in events if e['kind']=='lifecycle'];ck('SQL_events_created_to_terminal_to_verified_then_cleanup',lifecycle[0]=={'phase':'prepared'}and lifecycle[1]=={'cid':cid,'phase':'created'}and all(e.get('cid',cid)==cid for e in lifecycle)and lifecycle[-1]=={'phase':'verified'}and events[-1]['kind']=='cleanup_confirmed'and events[-1]['cell_id']==cell['id'])
complete=load(Q/'record-complete-command.json');ck('final_resume_exit0_original_native_times',complete['exitcode']==0 and json.loads(complete['stdout'])['native']==native['State'])
fdb=sqlite3.connect((Q/'failure-run/runs.sqlite3').as_uri()+'?mode=ro',uri=True);fdb.row_factory=sqlite3.Row;fc=dict(fdb.execute('select *from cell').fetchone());fdb.close();fj=Q/'failure-run/cells'/str(fc['id']);ft=archive(fj/'terminal.zip');fcommand=load(Q/'failure-command.json')
ck('initial_actual_exit2_self_facility_classified_candidate',fc['phase']=='failed'and fc['exitcode']==2 and json.loads(fc['failure'])['code']=='candidate_program_failed'and json.loads(ft['terminal-inspect.json'])['State']['ExitCode']==2 and json.loads(ft['stdout.txt'])['status']=='run_invalid'and fcommand['exitcode']==2 and json.loads(fcommand['stdout'])['status']=='candidate_execution_failed')
fremoves=[load(p)for p in fj.glob('*.json')if load(p).get('argv',[None,None])[1:2]==['rm']];ck('initial_failed_terminal_preserved_exact_own_cleanup',len(fremoves)==1 and fremoves[0]['argv']==['docker','rm',fc['cid']]and fremoves[0]['exitcode']==0 and not(fj/'accepted.zip').exists())

# Pure archive-reader probe from exact source; deliberately excludes all Executor/Docker code.
source=(Q/'source-current/l02_execution.py').read_text();tree=ast.parse(source);pieces=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))and n.name in {'ExecutionError','safe_relative','unzip_bytes'}]
namespace={'io':io,'zipfile':zipfile,'PurePosixPath':PurePosixPath};exec(compile(ast.Module(body=pieces,type_ignores=[]),'source-current_archive_reader','exec'),namespace)
try:namespace['unzip_bytes'](b'not a zip file')
except Exception as e:
 archive_error={'probe':'unzip_bytes(b"not a zip file")','kind':'pure exact-source helper probe, not full CLI or candidate execution','type':type(e).__name__,'mro':[t.__name__for t in type(e).__mro__],'detail':str(e),'caught_by_current_main_tuple':isinstance(e,(OSError,ValueError,KeyError,TypeError,namespace['ExecutionError']))}
save(OUT/'archive-reader-error-probe.json',archive_error)
save(OUT/'ledger-facts.json',{'cell':cell,'events':events,'physical_started_at':sorted(actualstart),'physical_finished_at':sorted(actualfinish),'command_count':len(commands),'create':creates,'start':starts,'cleanup':removes})
save(OUT/'checks.json',checks)
result={'stage':'source-current record lifecycle and initial candidate failure originals','checks':len(checks),'all_passed':all(c['passed']for c in checks),'failed':[c['name']for c in checks if not c['passed']],'seconds':time.perf_counter()-started,'one_actual_record_execution':{'cid':cid,'effect_count':1,'native_started_at':sorted(actualstart),'native_finished_at':sorted(actualfinish)},'qualification_scope':'Windows kernel lock and five process-crash recovery windows on one micro cell; initial-source failure classified separately','new_Docker_program_model_solver_Provider_calls':0,'archive_error_unhandled_helper':archive_error,'full_submission_ABI_qualified':False,'candidate_score':None,'L02_frozen':False}
save(OUT/'assessment.json',result);print(json.dumps(result,ensure_ascii=False))
