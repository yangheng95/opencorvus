import os
os.symlink('/input/instruction.txt','/output/link.txt')
