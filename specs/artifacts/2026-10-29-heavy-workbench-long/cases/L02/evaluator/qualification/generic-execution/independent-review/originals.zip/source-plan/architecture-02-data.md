# 02 — 数据面

> 对应代码：`src/engine/engine.sql.ts` · `src/session/session.sql.ts` · `src/trace/` ·
> `src/bus/` · `src/decision-log/` · `src/storage/` · `src/workspace/workspace.sql.ts` ·
> `src/control/control.sql.ts`

## 时间字符串的持久合同

安装生成元数据、交互时间线与演进证据的日期时间由util包的`isoDateTimeSchema`
统一声明。ISO（International Organization for Standardization，国际标准化组织）8601
分钟、秒和分数秒精度均保留输入字符串；安装元数据和时间线允许带冒号时区偏移，
演进证据保持UTC（Coordinated Universal Time，协调世界时）边界。
这些精度由Zod公开schema显式组成，避免依赖默认精度变化收紧已持久化值的读取。
读取不会补秒、改写元数据或升级数据库；OpenAPI与SDK由同一声明生成。

## Tool 完整结果与 Source 提交

`persistMessageSources` 在同一 SQLite immediate transaction 内验证真实 Session/Message
归属、读取该消息的规范 Source Parts，并按 `(type, sourceId)` 去重写入整批来源。
`MessageStore.sourcePartsInTransaction` 复用规范 Part 校验，仅读取 Source 行；
来源身份算法只有 Session canonical writer 一份；`source-persistence` 公开 helper 委托它。
`Session.persistCompletedToolResult` 在同一事务提交 Tool outcome、行内产物 display、
去重 Source 与事件 outbox，完整提交后处理器才退休本地调用。事件消费者可读取完整结果。

工具伴随的 Source/interactive-artifact Part 记录 `toolPartID`，应用与 SQLite 同时验证
它引用同 Message 的真实 Tool request 和 completed outcome。只有该复合 writer 可晚到结算
已接受调用的伴随结果，包括已完成助手或 Task activation 已释放的恢复；普通新 Part、
独立 Provider Source 和历史内容仍遵循原不可变/activation 合同。fork 将绑定重映射到新 Tool。

成功 Permission receipt 通过精确 Project/Session/Message/call/Tool 身份与唯一 attempt 的
`execution_succeeded` 配对读取；缺失配对或多成功结果给明确完整性错误。处理器错误收敛与
共享 Session 中断恢复先用原 receipt 物化输出、附件、display 和 Source，经同一复合 writer
提交；恢复不再次执行工具，也不伪造助手成功。Full access continuation 已退休仍可恢复。
当前触发器纳入版本1基线；后续变更经下述版本化迁移更新，完成校验后才进入业务恢复。

权限恢复的 Message 收尾使用 `Session.completeRecoveredToolMessage`，在单一写事务中
验证现有 Prompt generation，并重读全部 Tool/Provider 请求结果；未结束的 Tool 保持
Message 开放，终态重放保留原 completed 时间。各 Tool 的 park/handoff 共同决定后续
行为，已死亡 Provider 的 aborted 事实与助手错误保持真实。`retireMessageContinuations`
以完成 Message 和规范 Tool outcome 为退休依据；成功 Tool 与 Message 完成之间的
进程退出不会移除启动恢复入口。权限请求首写与身份检查同事务，读取按 request identity
而非 requested 事件条数计数。Mission 的中断归属仍由正式 process-recovery 协议结算。

正常完成、silent 写入、bundle、atomic/import 与不可变完成 payload 的相同重放，均在
唯一 `upsertMessageRow` 内复用该退休 writer。原 Message 和真实 Session 的 Project
共同确定候选，不依赖当前环境 Project。Message、退休事实与原发布 outbox 同事务；
退休写入错误、复合 Part 或 completion callback 错误均回滚本次外层写入，此前已提交
的真实 Tool/result 保持。恢复入口继续处理历史完成消息，不注册后提交扫描或新队列。
原 stale/superseded 错误与退休写错误同时出现时，AggregateError 保留两项原始原因；
逐请求恢复隔离保持，日志的 retired 读取真实账本，诊断读取失败明确为 unknown。

## 事件投递的数据库提交

Bus的投递请求注册、control lease取得、成功/失败receipt加lease释放及phase receipt，
通过唯一`bus/delivery-transaction`提交原语在每个事件循环轮次合并最多256份同步数据库写入。
每份写入用当前Database savepoint隔离输入/租约错误；数据库不可用则整批回滚。
调用者只有在真实commit/rollback后才收到Promise结果，普通subscriber回调在事务外。
已存在的publication reservation与Project activity拥有排队和提交的完整生命周期，
outbox及规范receipt/lease仍是唯一持久事实，重试和重启读取原occurrence，不另建投递状态。
该有界队列只减少物理提交并让出事件循环，不改变事件内容、phase顺序或SQLite持久化配置。

同步数据库effect使用`Bus.subscribeInTransaction`，由原delivery的Instance上下文直接
进入`Database.immediateTransaction`，将effect、原success receipt和精确lease释放一起
提交；不进入上述跨Project批量队列。通知通过`Database.effect`在commit后发出。异步返回
映射明确同步合同错误；临时`Bus.publish`映射`BUS_DURABLE_PUBLICATION_REQUIRED`，不能
执行无持久收据的SQL effect。同一durable ID和callback更改普通/事务模式返回原订阅身份
冲突。外部、异步副作用仍使用普通Bus接口及其原occurrence幂等合同。

Bus source的Project ID、原目录、事件正文与Project generation共同确定不可重绑的来源；
普通exact与事务exact共用同一个source writer。取得delivery lease时在同一writer重验
terminal receipt，避免原成功后被排队的另一owner再次进入callback。同步effect、异步
effect前和success提交均验证原generation；共享receipt batch只读数据库authority，
不能借batch调度者的Instance代替原delivery上下文。冷恢复在原Project当前注册目录进入
其生命周期，当前Instance不符不等同于原Project已退休。

未完成旧来源由真实host owner verifier写自己的ignored处置：`owner_unresolved`或
`owner_retired`，即使原source在delivery注册前中断也有实际校验回执；原callback成功、
ignored与phase历史均不改写。`GET /global/publication`及`/global/publication/source`
在Project删除或phase完成后仍可读原owner、原始JSON字节、delivery/attempt/phase及
lease/grant事实。正文按4096原字节base64分页，来源与事实每页最多64条，不重序列化正文。

## SQLite 回写与连接生命周期

SQLite的周期回写由成功初始化的物理连接统一拥有：同一个不保活进程的定时器在每个
PASSIVE checkpoint工作线程真实退出后间隔1秒再次执行，代替提交内1000页阈值，连续业务写入不重置计时。
WAL/NORMAL同步级别与业务事务原子性保持；它不承诺每次提交抗掉电，也不保证WAL硬性尺寸上限。
每轮工作线程只打开已有数据库、回写、退休statement并严格关闭连接；内嵌入口同时用于源码和编译产物。
工作线程保持进程存活至真实exit。同步关闭/重置、TRUNCATE/VACUUM先取得在途线程的SQLite资源释放回执，
再执行原操作；60秒仍无法确认释放时报明确错误并保留owner，不能删除或重开文件。资源释放不代替线程exit。
周期从排程开始登记到现有RuntimeExecutionSettlement的`database_checkpoint`类别。Server统一关闭新入场，
取消尚未启动的定时器并等待已运行线程实际退出；不以显式process.exit代替结算。rollback恢复周期，
已提交handoff后的新授权Database访问可恢复同一物理连接的周期；当前关闭阶段拒绝该入场。
关闭成功后清理定时器，不可用连接退休周期任务。定时器脱离已关闭的数据库调用上下文，旧回调按实际
SQLite句柄和回写job确认归属；不产生业务消息、额外进程、业务写入或第二套持久化状态。
PASSIVE的busy/部分进度在下次周期继续；非暂态回写错误进入现有DatabaseUnavailableError，
真实SQLite错误码保留，非SQLite错误为`SQLITE_CHECKPOINT_FAILED`，操作为`Database.checkpoint`。

## 数据库版本化迁移

当前版本为9，从新建的不可改写版本1基线开始支持自动迁移。唯一 registry 位于
`src/storage/migrations/index.ts`，每版保存完整、不可改写的目标 SQL；后续结构或持久
payload 语义变更必须追加连续版本。`PRAGMA user_version` 是唯一已完成版本，当前
`SCHEMA_DDL` 与 typed schema 继续定义唯一业务 reader/writer。`check:database-migrations`
在 typecheck 和正式构建中实例化两份内存 SQLite，比较当前对象与最后迁移目标的实际结构。
它不依赖可变源码摘要。

构建入口必须在求值运行模块前绑定唯一仓库专用
`.scratch/package-runtime`，不能继承应用的 `OPENCORVUS_HOME` 作为构建数据目录。
运行时相关生成器在该绑定完成后才加载。构建迁移检查仅使用内存 SQLite；编译产物的
首次运行验收另外拥有自建临时运行目录，不以用户数据库验证初始化或升级。
正常应用启动的版本化迁移合同保持独立。

`Database.Client` 成功完成开库后只输出一条 `database schema ready` 完成记录，
包含实际数据库 `path`、迁移事务回执的 `from`/`to` 与存在时的 `backupPath`。
`action` 根据同一回执区分 `initialized`（从0创建）、`validated`（版本相同的校验）
和 `migrated`（非零旧版本升级），不能把当前版本开库校验记为结构升级。

版本9沿用版本8的表结构，只修复既有复制历史中同Project的跨Session产物引用。
按目标Message与原artifactID去重复制完整payload及原时间，展示Part绑定新身份；
原Message、Tool输出、复制证据与源记录保持。压缩覆盖先验证原Part的精确摘要，
只重绑定确实覆盖修复内容的条目，并按依赖顺序更新后续覆盖；历史已变化的绑定保留。
原payload已丢失或跨Project的引用不能据猜测补造，保持明确读取错误。

所有 CLI、服务及子执行进程经 `Database.Client` 在业务访问/恢复前进入同一个迁移器。
旧版文件升级要求实际 Write-Ahead Logging（WAL，预写日志）模式，在原连接上取得
EXCLUSIVE 物理锁后进入 `BEGIN IMMEDIATE`，排除持旧语义的空闲只读连接；仅 writer 锁
不能证明这项排除。未关闭旧连接时保留原库并返回实际 SQLite busy 错误。非 WAL 旧文件
明确返回 `SCHEMA_MIGRATION_REQUIRED` 的维护说明，不自动切换 journal mode。
事务内重读版本；同库并发开库加入已提交的升级，独立数据库各自迁移。若未持物理保护的
fresh/current 初判在事务内变为旧版，明确要求维护并回滚，不能无保护升级。
新库直接事务创建当前 schema 和版本。支持范围内的旧版本先在锁定快照序列化完整
SQLite 到同目录 `migration-backups`，包含 WAL 中的已提交行；完整快照副本的读写格式
使用 rollback header，可独立只读开库或反序列化，无需伴随 WAL/SHM；原连接的 WAL 模式
和物理锁不变。独占临时文件 fsync 后原子
重命名，成功后才开始迁移。这个备份只覆盖数据库，不替代项目文件/附件和配置备份。

每版可用同步函数转换明确的数据语义，再按目标 schema 更新表、索引、视图和触发器。
表重建显式复制共同列和 rowid，新增列使用声明的默认值；字段移除、改名、类型或虚拟表
变化需要显式语义转换，不能猜测丢弃。整条待升级链、最终 schema、外键与当前业务完整性
校验处于同一事务，完成后提交版本。失败回滚并保留备份路径；进程中断由 SQLite 恢复
最后已提交状态，再次开库重试。所有保护路径恢复原 foreign_keys 和 NORMAL locking mode，
并通过真实 finalized main 访问确认物理解锁后才暴露业务连接；提交后的解锁失败保留已提交
版本与原备份，不伪称回滚。升级不会自动 reset、执行 Task 或合成历史消息。

版本2用同一权限图校验器验证原请求、决定、源 grant、执行与结果完整性，再追加
`grant_decision_indexed` 审计行，为历史无 slot 的 grant_used 建立唯一决定定位。
索引行保存实际迁移时间，源指向原 grant_used；原授权时间、执行 source、rowid 与结果保留。
任何不唯一或不完整的图返回明确完整性错误，不猜赢家、不改历史批准或产生 Bus/模型消息。

版本3复用版本2的完整不可改写目标DDL，只转换独立调度结果的可见会话身份。
Event由原fire.created_session_id与exact definition Project确定；项目Automation由原
run/revision/Project和不可变deterministicAutomationID确定。只有原assistant根缺少
conversation身份时补canonical Work metadata，其他metadata、Session/Message/Part身份、
权限、标题、目录、时间及调度回执保留；有效既有Chat/Work保持。冲突身份返回维护错误并
回滚，不覆盖；被删除的Session不复活。正常完整性校验沿同一来源合同识别当前缺失/冲突，
不在reader或打开路由增加兼容路径。查询不依赖语义迁移期间被暂时移除的索引。
执行历史仍按各次持久化输入中的真实agent投影，当前Work surface不重写旧coding等参与者；
后续新输入继续由当前Work overlay产生，与历史使用同一执行身份解析器。

版本4追加原Message移交及Part删除的精确来源查询索引，不改写原事件、消息或业务数据。
版本5复用版本4的完整目标DDL，在同步权限记忆投递启用前检查旧human Task Replied的
精确subscriber成功回执、attempt lease和exact phase。尚未attempt的原publication正常恢复；
真实旧success保留既有结算，不据此追溯重建历史记忆效果。已有attempt而缺success，或
exact phase已绕过该subscriber却无success时，无法判断原inbox是否曾被消费，返回
`SCHEMA_MIGRATION_REQUIRED`并保留原库、版本与备份。最近500条覆盖、时钟和rowid不能
替代永久效果证明；不猜补输入、不造成功回执，也不要求清空数据库。

版本6为上述保留的旧歧义提供自动恢复。后续版本可显式声明同步prepare及其较早的
beforeVersion，须满足2≤beforeVersion<本版本；在该旧版本的前驱完成后、原版本执行前，
仍在同一独占锁、原始备份和整条链事务内执行。版本6在原版本5前完成本次真实恢复，
原版本5校验照常执行；从版本5开库则在版本6执行同一个修复函数。任何切点失败整笔回滚，
不改已交付版本1–5、不catch跳过旧校验、不提前写完成版本。

恢复只处理原human Task Replied且缺精确成功回执的publication：校验原ledger决定、
Project/Session/Task/source和原human输入。仍pending的完整canonical Entry逐字保留；
原MEMORY.MD明确覆盖原interaction时保留已消费效果。证据未知则把原输入实际重新登记
到同一个inbox，添加仅说明来源的recovery字段（migration6、原publication、实际恢复时刻、
previousCapture=unknown），不虚构旧上下文，不把该字段作为去重依据。现时真实成功receipt
证明此次验证/登记完成，不表示旧attempt当时成功；原source、attempt、failure、lease和
文档全部保留。幂等仍由原delivery成功receipt和现有inbox身份保证。
合法task.deleted/session.deleted原事实继续退休语义，不复活owner。整Project物理删除
使用同数据库authority绑定的原active/completed清理manifest，按登记根包含原投递目录
核退休；备份迁移时需一并保留这些现有文件。当前Project存在而原owner缺失时，原输入
保存在同一protected inbox，原interaction审计行存在则验证并复用，否则引用原publication。
原pending字节保持，新增Entry明确ownerResolution=unresolved；单一inbox投影也从当前
owner与原source Session的缺失/退休识别旧Entry。此类输入可分页完整审阅，不进入当前
Organizer或容量丢弃，新输入正常消费。归属冲突、缺Project且缺合法退休证据或不合法
ignored终态返回明确完整性合同。恢复不执行原批准工具或模型。
新恢复pending由正常Project打开时的持久OrganizationRequested进入同一个Organizer。

版本7保留所有历史source/receipt/rowid，并为每个原Bus outbox追加唯一不可变owner绑定；
旧generation一律NULL，不以当前同ID的Project、Session或Message猜补历史归属。
新Bus source与绑定同事务提交；缺绑定行属于完整性错误，NULL是合法的历史未知。
Event Fire与Automation Run在原reservation冻结Project generation；旧执行未知归属记录
`owner_unresolved`，原Project消失或代次改变记录`target_deleted`，不重造新代次的执行数据。
Channel accepted新增原generation及实际选择的effect引用，并移除Project cascade，保留
原accepted/outcome历史；旧两列NULL保持可审阅未知。已交付版本1–6原文保持。

非空版本0返回 `SCHEMA_BASELINE_REQUIRED`，不属于本基线的升级范围；高于当前版本返回
`SCHEMA_VERSION_AHEAD`。当前版本出现未声明结构漂移或有损转换返回
`SCHEMA_MIGRATION_REQUIRED`；执行/备份/校验失败返回 `SCHEMA_MIGRATION_FAILED`。
当前已登记版本中出现旧语义返回 `DATA_MIGRATION_REQUIRED`，真实当前数据完整性损坏返回
`DATA_INTEGRITY_ERROR`。错误保留原数据供修复，不以抹库作为基线之后的升级方式。显式
管理员 reset 仍是独立破坏性维护能力。未登记历史库的首次基线处置必须有用户明确授权。

版本8将安装 mutation 的成功事实从 Task 报告生命周期分离。唯一不可变
`expert_squad_mutation_receipt` 保留原完整 Manager envelope、source Task identity 与创建时刻，
无 Task/Artifact 外键；原 Task 报告和消息继续按原删除合同处理。唯一 Artifact writer 在同一
SAVEPOINT 内写原报告字节、长期事实、catalog revision 与真实 Protocol 事件；payload 更新
保持原 receipt 字节身份，label 等元数据可正常更新。跨 Task 导入是报告，不生成本地安装权威。
迁移仅从实际正 receipt 复制原 envelope 字节和时刻；Manager/Evolution 仅读长期事实裁成功。
历史缺 receipt 的 cold journal 保全原 current、before backup、staging 与 journal 全部证据，
公开 `commit_receipt_unavailable`；保全 terminal 仅说明当前保全完成。原包可用时继续可用；
target 原本 absent 时保留该实际状态，可从归档通过新的显式操作恢复版本，不猜历史成功。
原 journal 在保全 terminal 前始终保留恢复入口，terminal 后才退休 current slot；后续显式
mutation 不删除旧 archive。只读 `/expert-squad/mutation-recovery` 有序分页读取保全记录。

保全文件协议@2通过原DurablePublicationStore的追加upgrade/resource-plan事实自动续接旧
pending @1，原intent/已写阶段/complete不改。唯一resource plan在copy/rename前冻结原expected
observation及实际source/destination；重入沿原plan认领已经完成的精确destination。
可得的冻结原观察与当前变化分别保留，原expected树不可得时明确标记，不能用当前树替代。
summary的targetEvidence为observed_at_preservation，originalMutationAfter为unverified，
完整filesystem观察不能由journal包digest或旧commit猜补。历史正receipt且当前revision不同
返回committed_revision_changed并保全当前观察，唯一成功权威仍为原长期表。
所有新安装/导入/update先在同一安装owner内恢复原journal，再执行当前CAS和真实效果；
普通导入也适用，不得通过省略durableReceipt越过原恢复。
已开始的保全先于恢复后重新出现的canonical成功清理，防止删掉未保全的before。
current journal已丢失时，显式及background恢复均从该installation/package原Store的open
occurrence原intent继续；旧orphan不退休另一operation的当前slot。该恢复会枚举相关
installation的包分区及各包历史，成本O(history)，不使用平行current index。

Worktree readiness 的唯一 journal 按 Database authority 与稳定 Project ID 分区；intent 冻结
Project generation、请求的 logical directory、canonical physical occurrence 和实际 startup。
同一次目录解析分别冻结保留真实大小写及未创建 suffix 的 `physicalPath` 与规范化的
`directoryKey`；前者用于 Git、startup、owner marker 和公开目录，后者只作比较/锁身份。
Windows 比较 key 不可用来创建带 Task/Session ID 的目录，业务 ID 与实际目录名必须逐字一致。
`reset` 必须显式提供 `operationID`，同 logical path 与 operationID 只能恢复原请求，即使
路径别名改指或 Project 已重建也不能对替代资源再次执行。新操作使用新 ID；物理 subject 的
同一跨进程 owner 覆盖读取、Git mutation、startup 和 terminal。别名共享同一资源的当前结果。
已持久 `populated` 只补回执并保留现有字节；成功未知返回 `startup_outcome_unknown` 保全结果，
不重跑任意脚本。Build、Workspace、Automation 和 Orchestrator 在使用前核真实 READY。
重启遇到 dead/reused reset admission，按原 immutable facts 收尾后结算 exact fence；live/未知
owner 及其他 admission kind 仍由其原 authority 处理，不能让残留 reset 阻断整个 Project 打开。
Store 先读取并校验 intent，再为匹配资源读取完整 phases/terminal；查找成本随当前 Project
历史 intent 数线性增长，不读取其他 Project 分区。它不是全局历史扫描或第二份 current index。

## 运行时目录根

Continuous goal（持续目标）与既有 Delivery Slice Goal（交付切片）是不同合同。
持续意图、自动输入与精确用量归属复用 Protocol/Message/Provider ledger，见
[Continuous goal execution intent](continuous-goal.md)，不为交付切片增加执行状态。

OpenCorvus 拥有的用户级运行时文件统一位于一个 canonical root。显式配置只接受绝对路径
`OPENCORVUS_HOME`；未配置时，Windows 使用 `%LOCALAPPDATA%/opencorvus`，macOS 使用
`~/Library/Application Support/opencorvus`，其他平台使用
`$XDG_DATA_HOME/opencorvus`（未设置时为 `~/.local/share/opencorvus`）。

`@opencorvus-ai/util/runtime-paths` 是 TypeScript 运行时的唯一路径契约；
`@opencorvus-ai/util/runtime-directories` 是目录初始化、临时子目录创建与递归清理的唯一
生命周期管理面。`Global.Path`、channel runtime 和安装脚本均投影固定子目录：
`bin`、`cache`、`config`、`data`、`log`、
`state`、`tmp`、`overlay/embedded` 与 `overlay/webview`。Tauri（Toolkit for building
desktop applications，桌面应用构建工具包）host 实现同一跨语言布局，并把主 WebView
（Web View，嵌入式网页视图）的 user data directory 显式绑定到 `overlay/webview`。
生产临时目录只能由 canonical root 下的 `tmp` 派生。测试 preload 在 canonical
`<root>/tmp/tests` 下为每个进程创建一个 owner，并在加载产品模块前把
`OPENCORVUS_HOME`、`TEMP`、`TMP` 与 `TMPDIR` 投影到该 owner 的固定子树；所有 fixture、
Git template、子进程和第三方临时写入均在该树内嵌套，结束时由同一生命周期管理面整体清理。
测试 owner 不得位于被测 Git 工作树内部，否则无仓库 fixture 的 Git discovery 会越界命中
真实项目仓库。

运行时不得扫描、读取或复制历史 XDG（Cross-Desktop Group，跨桌面规范组织）、AppData
或旧 `~/.opencorvus` 分散目录，也不得把历史位置保留为 fallback。旧数据库及其 WAL
（Write-Ahead Log，预写日志）/SHM（Shared Memory，共享内存）文件只能在进程完全退出后
由用户明确授权的 maintenance 操作整体处置；普通启动不会搜索旧目录或重建数据库。
规范路径内的版本化数据库按下述合同自动升级。

SQLite 数据库与 data root 不拥有单后端启动锁；不同监听端口的多个后端可以同时打开同一
数据库。物理执行由各领域的 durable lease 协调。破坏性 Project 删除、identity convergence
和匿名 Project promotion 仅通过 `project_maintenance_fence` 隔离其涉及的 Project occurrence：
fence 与 Project generation、维护 operation 和拥有它的 PID/进程启动指纹绑定，Task/Session
新建及 Task-root lease 的取得/续租在各自写事务内读取该 fence。删除和 identity convergence
的启动恢复只在物理观察证明 owner occurrence 已死亡或 PID 已复用后删除对应 fence；promotion
fence 只能由同一 operation/generation 的 durable publication occurrence 收敛并释放，通用死亡
owner sweep 不得释放它。任何 fence 都不得升级为 database path 或 data root 的排他 owner。

匿名 Project promotion 的唯一 Ready 决策是 durable publication terminal receipt。完整的
Project/Session before-snapshot 和 source digest 先写入 immutable occurrence；随后一个 SQLite
write transaction 重读并核对完整 snapshot、取得 promotion fence，首个 filesystem rename 只能
发生在两者之后。外部 Project/Session writer 由 SQLite trigger 在 persistent `promotion` fence
期间拒绝；精确 relocation/rollback transaction 临时使用 `promotion_commit`，并在 commit 前恢复
`promotion`。Project projection 隐藏 fenced row，只有 terminal 已落盘且 exact fence 已释放后才
发布 Project event 和 caller success。启动必须在 listener bind 前收敛所有 open occurrence 和
仍持有 exact fence 的 settled occurrence；未知路径、pre-relocation digest、generation 或双 source/quarantine
不允许猜测所有权或删除数据。

## Durable publication subject 准入

`DurablePublicationStore.withSubjectLock` 以实际解析的物理 lock root 与 kind/subject 身份
协调 publication。持有有效祖先 lease 的调用先按原 lease 重入；其他同进程调用按该身份的
实际接受顺序，依次尝试原跨进程文件锁。队列只管理本地准入，不提供 owner、不落盘，也
不承诺不同后端之间的全局先进先出。原文件 lease 仍是唯一跨进程 authority。

一次准入必须等原 callback、已接受的子 callback、lease 退休和文件锁 release 全部结算后
才推进下一项。准备或 callback 失败也按原顺序结算，向调用者保留原错误；不同物理 root、
kind 或 subject 独立推进。队列不改变 immutable phase、terminal receipt、恢复决策或数据库格式。

## engine 域

### 业务身份与完整性摘要

`src/id/id.ts` 的默认新签发路径为每个 canonical identity family 生成总长度不超过 24 个字符的
标识；读取或重放历史 caller-supplied 标识仍保持原值。需要稳定重放的业务身份只能在它的存储
迁移或明确 epoch 边界内切换到紧凑派生键。完整 SHA-256 继续保存在其所属 payload、目录或完整性
列中，作为字节相等和防冲突事实；紧凑业务 ID 不是截断后冒充的密码学摘要。Project ID 由完整
normalized repository identity material 经 `Identifier.deterministic("project", material)` 生成不超过
24 字符的 `prj_*` 身份；包含旧 expanded Project primary key 的 pre-release Database 在 bootstrap
返回 `DATA_MIGRATION_REQUIRED`，不创建第二个 Project。Task wait 由 exact Tool Part 确定性派生一个 native
Task-control registration identity；due ingress 与该 wait 的 `due_ingress_accepted` settlement 在同一事务提交，
因此 restart 只重放一个 durable ingress。Automation `cal_*` fire identity 只属于 Session delay、recurring 与
manual Automation occurrence，不再承担 Task wait 业务身份。其他手工或
caller-supplied 新落盘身份尚未迁入该默认签发面，属于后续迁移契约。Project Memory 的 pending
user-input file/chunk 与 Project `MEMORY.MD` envelope file/chunk 分别使用 domain-separated 的 compact
`memory` / `memchunk` identity；完整 Project、occurrence、content 和 provenance 仍在关系与 payload 中。
包含 expanded Project Memory file 或 chunk primary key 的 pre-release Database 返回 `DATA_MIGRATION_REQUIRED`，不
双读或原位改写其外键图。Permission request、execution attempt 和 ledger event 分别使用 domain-separated
deterministic `per_*` identity 与 ordered `per_*` occurrence identity，均不超过 24 字符；policy revision、
provider digest、scope fingerprint 和 execution-result SHA-256 继续保持完整。Permission ledger/result 中
任一 prior-epoch expanded identity 或关系镜像会在 bootstrap 返回 `DATA_MIGRATION_REQUIRED`，不会进入恢复重放。
Scheduler delivery 的 protocol event/inbox 与目标 Message/Part/Session-control 五个 occurrence identity 由同一
invocation 分别 domain-separate 后确定性派生，全部不超过 24 字符。event/inbox 在 enqueue transaction 原子
发行；目标 Message/Part/Session-control 在后续 materialization transaction 与 inbox settlement 原子提交。
prior-epoch expanded scheduler occurrence graph 会在 bootstrap 返回 `DATA_MIGRATION_REQUIRED`，不允许跨 epoch
拼接 replay。
Orchestrator 的 terminal lifecycle/infrastructure wake 使用同一 wake identity 分别 domain-separate 派生 compact
Message/Part identity；完整 wake/fact provenance 保留在 Message extra 与 Part metadata。旧 expanded control
Message/Part graph 在 bootstrap 返回 `DATA_MIGRATION_REQUIRED`，compact identity 被不同语义占用时返回 typed conflict。
Mission terminal caller receipt 使用 Mission Session identity 分别 domain-separate 派生 compact Message/Part；caller、
Mission、terminal reason 与正式 receipt pointer 继续在同一事务持久化。旧 expanded receipt graph 在 bootstrap 返回
`DATA_MIGRATION_REQUIRED`，不同语义占用 compact Message/Part 时在通用 Session upsert 前返回 typed conflict。

Build terminal observation 与 Evolution mutation receipt 使用同一 `Identifier.deterministic` Artifact
生成器，业务 ID 最长 24 字符。Build 使用 Task/dispatch occurrence，Evolution 使用完整授权、目标修订与证据
摘要作为 domain-separated 输入；完整 SHA-256 继续保存在事实和精确 locator 中。旧 expanded Build publication、
尚未 publication 的 cleanup owner 或 Evolution receipt 在 bootstrap 返回 `DATA_MIGRATION_REQUIRED`。
Evolution 重放按完整 receipt identity 验证后才执行 Manager reconcile；不同语义占用同一短 ID 返回
`EvolutionMutationReceiptIdentityConflictError`，不增加 alias store 或双读。

反馈修订 candidate 使用 Task 与完整 envelope 派生 compact Artifact ID，完整 package/payload digest
保留；同 ID 的 Task、kind 或 envelope 冲突返回 `FeedbackRevisionIdentityConflictError`。
旧 expanded candidate 由既有 compact Artifact bootstrap admission 拒绝。Goal Workload publication
使用 Task/dispatch 派生 compact Artifact ID，publisher、store 与启动关系完整性校验复用同一生成器；
旧 expanded Workload 由既有 `goalWorkloadCoverage` 启动校验返回 `DATA_INTEGRITY_ERROR`，不增设第二套检查。

所有表定义在 `src/engine/engine.sql.ts`，命名前缀 `engine_`（历史文档里的
`orchestrator_*` 已全部重命名为 `engine_*`）。旧的多张过程表已合并为单一
`engine_artifact`，按 `kind` 区分语义。

### 顶层与持久事实

| 表            | 关键字段 / 状态                                                                                                                        |
| ------------- | -------------------------------------------------------------------------------------------------------------------------------------- |
| `engine_task` | priority ∈ {critical, high, normal, low}；生命周期从时间、错误与取消事实派生；`session_id` 指向 root session；无 runtime selector 字段 |

### 计划与 Delivery Slice

| 表                      | 关键字段 / 状态                                                                                                                                                                                                                                                                 |
| ----------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Delivery Slice contract | 用户界面仍称 Goal。稳定 `delivery_slice_id` 连接不可变 `delivery_slice_revision_id`；revision 保存 objective、acceptance specifications、owned paths、priority、kind 与精确 RequirementSet/ContractGraph 引用。无 status、depends_on、retry、workspace 或 execution ownership。 |

### 执行与交付（artifact-centric）

| 表                         | 关键字段 / 状态                                                                                                                                                   |
| -------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `engine_artifact`          | **统一过程表**，`kind` 决定语义；替代旧的多表过程模型。`EngineArtifactKind` 的唯一真源是 `packages/opencorvus/src/engine/engine.sql.ts`，本文档禁止复制完整枚举。 |
| `engine_progress_snapshot` | 进度快照（旧名 `orchestrator_progress_snapshot` 已重命名）                                                                                                        |

### 交互与绑定

| 表                           | 关键字段 / 状态                                                                 |
| ---------------------------- | ------------------------------------------------------------------------------- |
| `engine_interaction_request` | type ∈ {permission, question}; status ∈ {pending, …}                            |
| `engine_channel_binding`     | 外部 channel（platform/channel/thread） ↔ task 绑定；`ChannelIngress` 查询入口 |

> 实际 `sqliteTable` 注册以 `packages/opencorvus/src/engine/engine.sql.ts` 的 `export const Engine*Table = sqliteTable(...)` 为唯一真源；本文档只描述表职责，不复制完整注册清单或数量。

**唯一写入者**：`engine_artifact` 的唯一直接表写入文件是
`engine/artifact.ts`。所有 workflow selection、dispatch lineage、execution、证据、
preview、review 与 Task completion artifact row 必须通过这个 writer 进入；生产源码中其他文件禁止直接
`insert` / `update` / `delete` `EngineArtifactTable`。`engine_progress_snapshot`
的唯一直接表写入文件是 `engine/progress.ts`；任务创建、任务状态更新、队列
claim 和 git note 都只能通过这个 writer 记录 progress row。
`engine_interaction_request` 的唯一直接表写入文件是
`engine/interaction-request.ts`；permission/question bridge 与 operator protocol
interaction request 和 operator protocol interaction resolution 都只能通过这个
writer 创建或解析 interaction row。`engine_channel_binding` 的唯一直接表写入文件
是 `engine/channel-binding.ts`；task creation 和 task cancellation / removal 只能通过
这个 writer 创建或删除 channel binding row。RequirementSet 与 ContractGraph 作为
`engine_artifact` 的不可变领域产物写入；ContractGraph 只包含
producer/consumer interface `contracts`，没有 `dependency_contracts`，也不产生 Slice
readiness。Delivery Slice revision 只保存这些产物的精确引用，不存在
Task-current Spec/Plan 指针或 latest-wins 选择器。Slice contract 的唯一 writer 追加
初始 revision；operator 修改 Goal 时追加同一 logical identity 的新 revision，禁止覆盖
旧 revision 或写入 execution bookkeeping。`engine_task`
的唯一直接表写入文件是 `engine/task.ts`；task creation、metadata/touch、
budget/title edits、physical delete、queue reorder/claim、lifecycle state updates
和 rewind cursor mutation 都只能通过这个 task writer 变更 task row。
Task completion 不写入可覆盖的 Task JSON 槽位。每次完成都追加一个
`engine_artifact[kind="task_completion_decision"]`，保存真实 Orchestrator
Session/message/tool-call/tool-part 身份和经过类型、存在性、Task 归属校验的证据引用。
这些关系由唯一的 `recordTaskCompletionDecision` writer 在追加前从持久化
Session/message/tool part/Slice revision/artifact 事实中验证，调用方不能以预检结果绕过。
重新打开 Task 不删除历史决策；只有 artifact `time_created` 与当前
`engine_task.time_completed` 精确相等的决策才投影为当前 `completionDecision`。
叙事 summary 留在真实 assistant message 和 progress 事实中，不复制进完成决策 artifact。
对绑定 virtual workflow 的 Task，完成前还要从当前 Artifact catalog 枚举没有下游消费者的
terminal node agent 所发布的全部 current `expert_output`。这些精确 locator 必须全部出现在
Completion Decision 的 evidence 或 deliverable 集合；缺少任一项时返回
`TASK_COMPLETION_EVIDENCE_INCOMPLETE`，Task 保持非终态。direct Task 与仍被下游消费的中间 node
不适用这一 terminal-output 完整性规则，避免把过程证据误投影为用户交付。
在完成 checkpoint 之前，`complete_task` 还会在同一个 `engine_task.metadata` 权威面取得
`task-completion-closure-v1` 执行收敛租约；取得事务同时要求既有 dispatch 全部结算，
`dispatch_lineage` 唯一 writer 则在其写入事务中拒绝 closure 后的新 lineage。失败或被其他终态
竞争者击败的完成调用释放租约；retry/replan 打开新 execution epoch 时原子删除旧租约；独占项目
进程启动时只清理非终态 Task 的遗留租约；成功完成后的租约保留为该 epoch 的收敛 receipt，但不
替代不可变 `TaskCompletionDecision`。

成功完成与后续业务 Message 的接纳使用同一事务边界：当前 Task、Project 和 execution epoch
内尚未激活且没有不可变 disposition 的 Message ingress 必须先沿原 FIFO 处理。
完成事务在该情况下整体回滚终态和 Completion Decision，释放自己的 closure，并返回真实的
`Completion Deferred` Tool 结果来结束旧 Turn。原 Tool 决策结算旧 ingress；Task 保持 active，
原队列继续处理相同 Message 和 ingress，不换 epoch 或复制输入。显式取消及失败仍按各自
终止授权收敛，生命周期、等待及恢复通知继续使用原终态合同。

Expert output publication 在同一个 Artifact 写事务中读取 Task terminal 状态；终态之后只允许内容和
identity 完全相同的 idempotent replay，拒绝新的不同产物。
idempotent expert output 的业务 ID 由 canonical publication material 经统一 deterministic Identifier
生成且总长不超过 24；完整 payload SHA-256 继续独立存储并进入 exact locator。若短 ID 已被不同
canonical material 占用，writer 返回 typed identity-collision error，不得 alias。包含旧
`art_idempotent_<64hex>` 身份的 pre-release Database 属于不兼容持久化 epoch，bootstrap 在业务读取前
返回 `DATA_MIGRATION_REQUIRED`；不得同时发行旧、新两套确定性身份或猜测重写 immutable provenance。
Mission 创建下游 Task 时只提交一个
discriminated `artifact_sources` 权威集合：completed source 只携带 source Task ID，由 Host 读取当前
`TaskCompletionDecision` 并原子展开其完整 `deliverable_artifact_locators`；模型不再复制任何 completed
source locator。failed/cancelled source 没有 CompletionDecision，继续由当前 typed terminal lifecycle
event 加调用者提供的精确 immutable locator 构成恢复权威。两种分支共用同一个 exact import writer，
不存在旧 `artifact_imports` 输入、latest-wins selector 或 fuzzy recovery。prepare 阶段冻结 source epoch/decision，target Task 与
imported Artifact 的同一事务再次进行 compare-and-swap（CAS，比较并交换）复核；source 已 reopen
或换 epoch 时整个 target commit 失败，准备期 TaskArtifact 由既有创建失败清理路径删除。
显式交付按用户/后继Task用途定义，业务结构化Artifact即使resources为空也可作为deliverable；仅验收用途的记录仍属evidence，
同一产物可同时具备两种明确用途。请求实际文件时仍须真实资源；不把全部evidence自动展开为交付，也不以resource数量分类交付意图。
Reviewer artifact 的 producer Session、completed assistant message、Slice revision、
RequirementSet、ContractGraph 和 evidence artifact 引用同样由
`recordIntegrityReview` writer 验证为同一 Task；这是数据完整性约束，不是调度
或 acceptance gate。
其他 `engine_*` 表的写入仍必须停留在已声明的 engine-owned writer/service 内，
禁止跨域模块直接写。

`engine_artifact.payload` 的严格领域 schema 也是持久化契约。让既有行无法被当前
reader 解释的变更必须同时更新对应完整性 trigger，并追加保留原始身份和权威的版本化
数据迁移。迁移成功后只使用当前格式，不增加兼容 reader 或双读写。无法从真实事实重建的
权威必须明确报错并保留原数据；禁止用 optional 字段、默认值或猜测 row patch 伪造。
`dispatch_lineage` 的整个 payload 由
`engine_dispatch_lineage_payload_insert` 约束为精确 JSON（JavaScript Object Notation，
JavaScript 对象表示法）shape：顶层 key、Tool occurrence、projected worker identity、Task work
scope、Delivery Slice revision、delivery owner、adapter input 与创建时间必须完整且无重复 key；
projected target、runtime template、Session kind 与 dispatch adapter 必须属于同一执行身份。整个
lineage row 不可更新；它的 breaking 变更必须同步改变该 trigger，并登记对应版本迁移，保证基线之后的已存 lineage 可由当前 reader 正确解释。

Dispatch recovery 每次最多接收 64 个去重的 exact
`(task_id, child_session_id, dispatch_id)` descriptor。lineage 查询按完整 triple 命中；后续
delivery disposition、settlement ingress 与 terminal lifecycle ingress 只消费实际命中的
descriptor，并通过 bounded `VALUES` request 与 correlated `EXISTS` 返回每个 request 至多一行。
不能把独立 Task ID 集合和 dispatch ID 集合做笛卡尔候选，也不能让重复 ingress fact 放大立即事务内
的读取量。lifecycle membership 还必须匹配 descriptor 的 exact child Session。
`dispatch_agents` member 的恢复还会按同一 Task/epoch/orchestrator Message/Tool part/call
读取 declared member set。没有 lineage 的 index 只能由 exact outer Tool request append-only progress
中的 typed failed checkpoint，或明确带 `occurrence_not_committed` authority 的 completed infrastructure
outcome 终结；一旦 lineage 已存在，该 member 必须有 immutable settlement，且只有带
`occurrence_committed` authority 的 infrastructure settlement 可以在 descriptor 前终结。其余 index
必须由 exact lineage/descriptor/settlement 终结。只有完整 set 才能导出一个
确定性 representative ingress；该 ingress 或其 budget-suppressed disposition 一旦存在，整个 set 都从
recovery frontier 消失，而不是继续按 member 重放 scheduler Turn。

TaskArtifact 的 Engine envelope 与 exact resource identity 进入 SQLite，当前不可变
manifest 和资源字节则由 TaskArtifactStore 发布。发布的唯一文件系统提交点是最终目录中的
canonical `manifest.json`：两个 writer 都先验证 stage、独占创建目标目录、逐个移动并同步
regular resource files，最后原子 no-replace 发布清单；不移动含被开发服务器监听的子目录的
整棵目录。没有清单的准备中目录不进入 snapshot 列表，exact ref 读取仍严格验证清单与资源。
失败只清理本次独占创建的目标；同一 Task 的 catalog writer lock 下，确定性幂等重试可以清理
其精确 producer/content identity 的未提交目录后重建，已有有效清单则校验并复用。
资源完整性错误必须由 exact
Artifact/resource consumer 明确报告；project bootstrap 的 retention scan 只能记录
结构化 corruption evidence，不能把一个缺失或损坏的 snapshot 提升为整个 Project、
VCS、Task events 或 Session events 不可用。严格读取继续验证 manifest、路径、媒体
类型、字节数与 SHA-256，禁止 fallback、伪造字节或自动修复。无法证明安全的回收不
得创建第二条删除路径。

完整 Artifact 读取审计由 Plugin 的同一 `auditArtifactReadLocatorsFromFacts` 供 Session
持久 Tool 回执、Panel 和 Package ToolHost 使用，按实际 `delivery` 解释运输。`inline`
验证文本字节窗口或完整二进制附件；`materialized_file` 验证完整资源范围、媒体类型、
不可变 digest、资源字节数及非空只读缓存路径回执，不要求内联文本或受内联窗口大小限制。
后者证明已验证资源的字节可用性，内容检查仍由真实消费者完成。语义来源必须引用同一
physical Turn（物理轮次）内、当前动作之前持久化的完整读取；随后 inline 读取与合法物化
读取可共同覆盖同一 locator，非法窗口仍使对应 locator 的审计失败。发布不得重建模型引用、
隐藏失败回执或改走另一来源授权路径。

Artifact Catalog 对 TaskArtifact 的可发现性同样由持久权威决定。`catalog` snapshot
投影一个 immutable parent 和它的全部 resource entries；`engine_resource` snapshot
只是 Engine receipt 的物理资源依赖，不单独投影 parent。只有被当前搜索
Engine catalog revision/version scope 内至少一个 exact Engine Artifact envelope 引用的
`engine_resource` identity，才把它的 resource entries 投影为当前 Task 的
`task_artifact_resource`。准备期、失败清理前或其他未引用物理 snapshot 不进入 Catalog。
语义 Catalog 在现有 Task snapshot 读锁内核对引用集合与已提交 snapshot 的完整 identity；
已被 Engine 引用的清单缺失、identity 被替换或整个 snapshot 丢失，必须返回
`task_artifact` provider error、`catalog_complete: false` 与 `incomplete_catalog`，
不能作为尚未提交的目录静默跳过。物理列表的准备期过滤不代表持久引用已完整解析。
该引用集合与 Engine catalog revision upper bound、TaskArtifact publication sequence
共同冻结在 cursor membership 中；后续 Engine receipt 只能由 fresh search 观察，不能改变
既有分页结果。Agent 不得从 wrapper payload 手抄 resource locator，也不存在另一个资源发现路径。

`artifact_search`的计数、`catalog_complete`与`resolution`均只描述请求来源和版本范围内的
同一冻结目录。模型运输保留`resolution.scope.sources/version_scope`，即使省略较大的facets与
applied_filters，也不能丢掉完整性事实的作用范围。`unmatched_filters`和`no_match`不证明排除
来源中没有该事实；诊断不额外查询排除来源。读取失败继续给明确provider error及不完整状态，
不能当空目录。`ArtifactInspectionError`的模型可见消息保留具体expected/received诊断，
不能只给错误数量而省略可修正的差异。

正式 Artifact 类型的发布权威来自绑定包的可选 `artifact_publishers`：精确类型映射到该包
已投影的 Tool CapabilityRef，null 保留 Host-only 类型。通用 Tool 与 Package Host 共用的
canonical publisher 读取 Task 绑定的 immutable package snapshot，并比对真实 runtime
binding 导出的当前 packageToolRef；模型参数不能声明或覆盖调用者身份。错配返回明确
expected/actual publisher 错误，不能换另一个 Tool 绕过 typed codec。未声明类型继续原通用
JSON/身份/来源合同；历史包没有的声明不会从当前安装版本回填，历史产物也不会因此变成 typed。
此关系只约束来源和类型权威，不代替包的 payload/前驱算法或 Agent 的语义审查。

Evolution Lab 的 typed Artifact publisher 在写入前验证直接语义前驱，而不是把先前的
`artifact_select` 当成隐式 publication provenance。`failure-attribution` 必须直接绑定且完整读取
唯一的 `opportunity` Engine Artifact，验证其 Evolution observer producer，并让 payload
`owner_evidence` 引用同一 exact locator；缺失、额外、错误类型、错误 producer 或 payload 不一致
都返回 typed integrity error，不能持久化为可供 Campaign 消费的成功 Artifact。
当 completed source Task 同时把已关联的 opportunity 与 failure-attribution 导入下游 Task 时，
import writer 保留两者的 immutable source locator 与 source provenance，但不伪造新的 direct source。
Campaign publisher 只在两份 import lineage 属于同一 source Task、opportunity 的 source locator 同时匹配
attribution 的唯一 source provenance 与 payload owner evidence 时，把两份当前 Task locator 认定为同一
canonical predecessor pair；Campaign 自身仍只持久化当前 Task locator。错配 pair 返回同一 typed
integrity error，不允许模型引用 source-Task locator、改写 imported payload 或重发 attribution。

重复导入时，当前`import_lineage`仍描述即时来源Task/locator/producer；其`prior_imports`
以近到远顺序保留源envelope已经携带的逐跳事实，使用同一非递归source schema。共享import
writer只复制实际已有事实，不把Mission importer改称原作者，也不通过未授权Task补查历史。
唯一`engineArtifactSourceChain`读取当前Task envelope中的完整已运输链，Lab作者检查与
attribution/opportunity相关性使用最早已知事实。缺失`prior_imports`不证明历史完整；若已知
链末仍是Mission，就不能满足原worker作者合同。旧丢失记录保持原样、不回填；payload与资源
原bytes保持，目标资源snapshot的Mission producer仍只说明本次复制动作。该运输能力本身
不把原payload内的locator改写成当前Task locator。`createEvolutionArtifactReferences`在调用者
当前Task/冻结目录已读集合中，以exact current locator及已运输Engine source chain建立原件
身份索引；`evolutionArtifactProvenance`投影已知最早作者和直接来源。索引没有I/O、没有新账本，
不以值/名称/时间或普通source引用合并身份；同一exact原件若出现矛盾type/schema/payload会
报conflicting_identity，当前集合缺少所需前驱报missing_source。所有物理Artifact及原payload保留。

Comparison发现/比较、Review显式取代、新鲜性检查、history和Lab晋升前驱验证共用该规则。
相同原件的运输副本可通过任意已保存一跳关联；两个独立native Review即使内容相同仍是两份
审查事实。明确supersedes多个同源副本会取代同一原件的全部已读副本，不伪造新的Review；
重复列同一exact locator仍是duplicate_parent。当前新Review仍需自己的直接来源，导入Review
的finding与父声明按原source provenance校验，不让复制动作变成原审查作者。
history纳入可验证Lab导入事实，按所属Task分别建索引，保持当前Task locator/原payload和
冻结历史上界；不同Task不得混成授权域。安装检查仍在原receipt immediate事务，Lab原作者可由
已运输链证明，Core反馈/恢复权限不扩大；缺源不等于没有后发Review，已提交receipt仍先重放。

`run-evidence-bundle` 的模型面输入只有 Evaluator 选择的 Campaign 槽位（`case_id`、`arm`、`repetition`），
publication 以唯一一份 campaign-spec 为 source、以 collector 的唯一 JSON 资源为 resource set。publisher
要求该资源等于对同一 Trial 的新鲜采集，再盖章 Task、终态时间、outcome、活动时长、workspace 与五项
package revision；从该 Trial 的 `provider_usage_event` 盖章已记录 token、cost（null 表示未知）与唯一
服务模型；从所引 Campaign 盖章 environment。账本记录的模型不是恰好一个、或 revision 事实不一致时，
返回写出实际值的 typed integrity error，该槽位没有可发布的运行证据。比较与度量工具的冻结模型检查
因此比较的是实际服务模型；Evaluator 不复述任何宿主事实。

collector JSON当前为schema_version 2，其usage把原ledger event IDs、token/cost/model与
Task lifecycle、Session树放在同一SQLite采集事务及同一canonical资源中。publisher只从已验真
bundle盖章，独立taskRuns.usage入口已删除。后入账会使旧采集与fresh collection不一致，必须
生成新资源，旧资源不改。完成工具可先于本次请求的用量回调，因此终态时间不等于费用封口。
旧v1采集资源保留历史字节；当前发布/metric执行只接受v2，不补字段、重算历史或fallback。

Evolution Opportunity建议预算与Campaign预算的`max_cost`使用同一显式合同：非负数字或null。null表示用户/Mission未声明费用上限，0保留零上限原义；缺字段仍是输入错误，不默认或回填。Campaign输入、持久化与history context共用预算schema，页面明确显示未声明状态。该字段不是实际费用、未知计价或新增花费授权；原usage事实、全矩阵max_runs校验和金额执行策略不变。

Metric请求显式以Run所携带的collector资源作为subject；评分owner仍是Evaluator Task。
Host精确读取canonical bundle，shell按其terminal Git commit/tree在本次调用的受管目录物化
根仓库regular文件，保留Git执行位，执行后随TaskArtifact execution关闭回收。相对cwd限定在
该副本内；绝对/越界配置是configuration_invalid。live_observation、嵌套仓库、symlink/gitlink、
不可移植路径和本仓库缺失对象是input_unavailable，不借用Trial现场或Evaluator目录。
独立Git对象库导入仅传collector字节不保证对象可达；忽略的构建输出不属于冻结commit主体。
每次attempt的schema_version 2记录subject资源、原Trial及commit/tree或live observation身份，
旧attempt字节保留。judge消费同一bundle及采集时选择的Message正文；原消息和provenance不
隐藏，这不保证盲审或证据业务充分性。query/aggregator继续归属Evaluator评分流水。
冻结spec读取经唯一MetricSpec schema解析，数据库更新时间不是评分定义；同定义可复用，
真实定义变化仍按原冻结契约拒绝。

Evaluation receipt JSON是测量结果的运输形式，其不可变身份不单独证明测量来源。
Lab评分Tool完成全部scorer后以原catalog TaskArtifact发布该receipt，使同Task可在Evaluation
发布前公开发现并读取，恢复时可继续发布原测量。历史receipt种类保持原样；不放开通用
engine_resource目录，也不据可见性宣称所有原生评分已进入Comparison。
`metrics.recorded`按当前评分owner Task和确切attempt资源，在原`engine_metric_result`读取
已记录结果，核对原MetricSpec与attempt的Task、iteration、status/value，返回原Trial subject及
measured/unavailable事实及原metric_result_id。未落账的独立JSON或另一Task的结果不能作为当前Task的新测量。
该投影的tool_request通过原manifest producer的Session/Message/call，在同一Task内读取不可变
tool_part_request，含原Part ID、Tool名称与完整input；running或failed outcome不改变原请求或
已落账评分。Core producer无Tool发生时为null；有Tool身份却缺少精确同Task请求则是完整性错误，
不得从当前调用者、后来receipt、同名Tool或时间重建。请求本身不定义同一Tool内部多次SDK评分的批次。
Evolution执行与发布共用原Campaign/Run上下文和同一recorded结果投影；publisher要求receipt的
slot、Trial、subject、完整冻结scorer集合/revision及声明结果与原生事实一致，再发布Evaluation。
unavailable先按其真实状态运输，不把raw_value=null解释为measured或0。已有跨Task Evaluation
导入保持原件，新Task重新评分仍归其自身账本。此约束不证明全部Trial已公开，也不解决从多次
真实metric执行选择观察的完整性；没有重写旧回执或新增测量ledger。

recorded observation同时投影评分attempt原snapshot manifest的完整producer；不从后来发布的
receipt推断评分调用。单份Evaluation的全部scorer必须有相同Task、原Tool producer和iteration。
当前Lab公开评分Tool内只有一次evaluate，故该规则阻止不同Tool调用的真实结果拼接；它不
定义任意SDK在同一Tool内多次evaluate的更细批次。不同snapshot可以属于同一调用，iteration
自身也不能唯一识别调用；不要求外层Tool成功来丢弃已经完整落账的测量。完整回执重新发布
保留原来源。TaskArtifact幂等复核沿原manifest实际snapshot_kind计算身份，catalog与
engine_resource分别可复用和恢复其相同字节，二者的身份保持区分。

`comparison-recommendation` 的模型面 payload 是空对象；Recommendation Owner 选择并完整读取
确切Campaign与Candidate（可附带Run/Evaluation，但它们必须属于该对）；测量与Review都不由它选择子集。
publisher在一次冻结Task catalog分页内，经`evolutionComparisonMembers`发现所有以自身盖章事实
绑定该对的已发布Evaluation（baseline臂candidate为null，candidate臂为该Candidate）及其确切Run，
补齐发布别名并完整读取全部相关Review，再经唯一比较器生成并持久化全部统计、可用性、置信度与
推荐字段，不要求模型重抄派生结果。Owner 完整读回所发布的比较后
再渲染文档与图表；测量槽位和统计公式保持原定义，计算输入与当前晋升身份按下述契约核对。目录不完整或provider错误不能
等同没有Review。这保证该目录快照中绑定该对的已发布测量及其Review集合，不保证未来证据新鲜性或业务判断正确。

Comparison的`calculation_inputs`由唯一比较器盖章exact Campaign/Candidate及实际消费的全部
Run/Evaluation/Review身份（含等值别名与已取代Review）；它与保留的同Turn宽来源图不同。
共享reader校验原直接来源和原件类型，重放、history与晋升使用同一当前Task引用索引。
History新鲜性解析保留同一Task在原Project及Catalog上界内的完整冻结Artifact上下文，包含全部合法导入别名与历史revision，
不能从显示的Campaign/Candidate重建精简引用图；差异仍只对照该冻结边界内最新的Run/Evaluation/Review目录。
实时晋升准入与提交新鲜性校验共用同一当前Task上下文reader，包含当前目录、调用者确切历史版本及原生Comparison直接来源；
不从其他Task补读源库，也不以三个显示定位符代替完整已授权别名闭包。
历史缺字段表示没有记录计算输入，保留原结果并公开COMPARISON_INPUTS_UNAVAILABLE、
promotion_intent=null，不能从宽来源猜值或改写历史。新比较的授权Campaign/Candidate必须匹配
实际计算身份；额外背景来源不扩大权限。Review新鲜性对照实际已消费Review，而非宽来源成员。
已发布且绑定该对的不同测量全部被消费；本契约不能证明执行了却未发布的测量或未公开Trial完整性，
未被任何成员Evaluation引用的Run也不从宽来源猜归属。

`integrity-review.revision`是可选的显式改判声明，包含`supersedes`确切父Review及`reason`；
未声明时是初始/独立审查，不取代任何记录。publisher校验同一Evaluation/slot、生产者和直接来源，
唯一`resolveEvolutionIntegrityReviews`校验完整父集合及无环并投影current/superseded原记录。
普通引用和时间先后不表示取代，不要求新增证据或自由文本finding同名。并列current分支的typed
findings全部进入比较，后续完整Review可显式取代多个分支；原件永久保留。history的review_history
逐项暴露真实状态，单项review投影只在唯一current时存在，不合成合并Review或写第二ledger。

晋升授权与尚未提交的执行（`requireCurrentEvolutionEvidence`）先核对该对的当前成员测量：
绑定该Campaign/Candidate的已发布测量不在Comparison实际输入（同一测量的发布别名除外）时，返回
`EvolutionComparisonMeasurementChangedError`及确切缺失locators；再核对确切Evaluation所关联的
当前完整Review身份，后发独立或显式改判Review未进入时返回`EvolutionComparisonReviewChangedError`。
不按结论好坏决定是否忽略。history在自身冻结目录上用同一差异公开`MEASUREMENT_SNAPSHOT_CHANGED`
与`REVIEW_SNAPSHOT_CHANGED`，保留原推荐，不提供该快照已知过期的promotion_intent。安装前检查仅为预检，最终检查与durable receipt写入
在同一个SQLite immediate事务中串行化：相关新测量或Review先提交则原manager按journal回滚未提交安装；
receipt先提交则后发证据不倒改历史。重试先识别已有receipt，按原journal清理并返回；
同进程确定失败按原journal回滚；cold中断缺长期receipt先按上文保全unknown，新的显式执行
再复核当前版本与新证据。恢复/feedback授权保持原契约。

Run/Evaluation的发布身份与测量身份分开：Evaluation publisher从已核验原生结果盖章
measurement_identity（owner_task_id及每个scorer的metric_result_id），不从回执包装猜评分发生。
唯一`createEvolutionMeasurementKey`供分组与别名闭包使用：Run仍以完整typed payload为事实；
有原生身份的Evaluation保留Trial/slot/scorer revision、值、状态、attempt及原结果ID，只将回执
运输身份排除，并按已证明的Campaign/Candidate原件及完整等值Run事实归一引用。scorer集合顺序
不创造新观察；不同原结果ID即使同分、同Tool或同iteration仍保持不同观察。历史缺少原生身份
表示未记录，只有完整原payload相等才是已证发布别名，不猜发生、不回填、不以值或时间择优。
`groupEvolutionMeasurements`按slot与同一key分组，统计只计一次，原locators全部保留。
不同Trial、结果、usage或terminal事实保持不同观察；仅运输receipt不同不证明另一次评分。
Review可引用同一测量组内任一确切Evaluation别名；原Review的显式取代scope不改变。
同槽多个不同观察由唯一`deriveEvolutionSlotObservations`派生，比较器与history共用：全部观察
都被消费，不按时间或数值择一。多于一个Trial Task、或同一Trial多于一个终态发生，为required
`trial_conflict:<slot>`；槽位有终态观察时，只由终态观察及测量它的Evaluation提供结果、资源与
scorer值，同一Trial的inactive/awaiting观察及其Review仍被消费但不供值。参与观察一致的事实被
采用：measured值多于一个为required `scorer_conflict:<scorer>:<slot>`，typed unavailable不提供值
也不与已测值冲突；终态outcome不一致为required `run_outcome_conflict:<slot>`；token/cost/activity
不一致只使对应资源差值不可用（`run_resource_conflict:<slot>`）。槽内全部成员Evaluation的当前
Review均生效。history只在上述Trial/outcome/scorer不一致时公开MEASUREMENT_OBSERVATION_CONFLICT，
多个一致观察的单项run/evaluation为null而scorer投影为一致值。
Comparison直接引用的Run/Evaluation通过该图可达，不要求baseline Run另抄Candidate来源。
此引用可达性规则本身不证明测量全集；成员发现的范围由上文目录合同界定，不能证明未公开Trial的完整执行历史。

在一次Comparison的实际计算集合内，Run.task_id与Evaluation.trial_task_id必须各自只归属一个
case/arm/repetition槽位；同一Trial的发布别名、晚到费用或继续/恢复不能变成第二个独立槽位。
`evolutionTrialSlotConflicts`是唯一纯身份计算：比较器把它写成required
`trial_slot_collision:<trial_task_id>`并发布inconclusive（已发布测量全部被消费，拒绝发布只会让
Owner无法披露），当前安装证据复核对已消费输入仍抛出携带确切Task/slots/原locators的错误。
history保留原推荐与原测量，公开TRIAL_SLOT_COLLISION并不给当前安装intent；
已提交receipt仍先重放。规则不跨Campaign禁止复用baseline，不选择同slot的不同观察，不按相同
资源字节合并不同Task，也不能证明统计独立或全部Trial已经公开。

同一测量的发布身份闭包由`expandEvolutionMeasurementAliases`唯一计算：在当前Task目录中，
以已选及成员Run/Evaluation的同一测量key补齐全部已证发布别名，再关联每个Evaluation别名上的Review。
publisher一次分页同时读取三类Artifact，固定同一upper/membership，完整read/select后发布比较；
不以Owner只传一个别名为由遗漏另一别名的审查。mutation在原receipt immediate事务中读同一当前
DB快照并使用相同闭包；history用自己的冻结上界。新的别名与Review在安装期间出现时也进入复核，
同证据显式Review更正仍按各自exact Evaluation scope执行，旧回执幂等重放保持。

多观察归约仍按真正测量组要求独立审查：任一组没有current Review或有unavailable审查，
该slot的integrity_review保持required unavailable；同一原测量的运输别名可以共用审查。
`evolutionMeasurementReviewCoverage`供比较与history完整性计数共同消费，不以一个slot内第一份
Review替代其余独立测量的审查，不要求固定finding类别。原审查仍逐件保留。
Run的terminal_event_id由原collector.lifecycle.terminalEventID盖章，非终态为null，旧记录缺失即
未记录。多份终态Run仅凭相同时间不能证明同一次发生；已知不同ID或同ID矛盾时间为发生冲突，
多份观察缺少原生发生身份为required trial_occurrence，不从时间/摘要回填。单份历史原件仍可读。

Metrics 域沿用 `engine_*` 表名承载评分流水，但写入边界归属 metrics store：
Package Tool经native/Capsule共同的异步Host RPC调用能力；`metrics.assertRecordedSnapshot`返回Promise<void>且发布器必须await，让完整性错误作为正常Tool失败返回。原生集合的底层同步读取与receipt immediate事务不因此变异步。

Evolution Comparison的`calculation_inputs.native_measurements`记录当前评分Task已验证的原生结果ID全集，以及相关但尚未被本次Evaluation覆盖的原结果/attempt/Run身份。`metrics.recordedSnapshot`共用原recorded权威验证每个结果，并核对异步资源读取前后原生ID集合不变。相关性来自实际Trial、collector完整字节身份和冻结scorer revision；原持久请求只补入exact Campaign/Run，不将Campaign当排他归属或同Tool/iteration当批次。未发布结果给required unpublished_measurement，原complete receipt可继续发布，部分发生不伪造Evaluation或拼批次。

安装与history共用原生ID集合差异。原receipt immediate事务同步查既有metric表，不异步读manifest、不建第二ledger；rename后新增行使提交回滚，已commit receipt仍先重放。Engine catalog上界与native写入不是同一序列：历史原推荐/输入保持，native差异明确为current_task_live，当前promotion intent不可用；不声称旧catalog cursor冻结了native账本。导入Comparison仅核对目标Task，源Task未运输事实保持未知；历史未记录native快照且当前有原生行也需重新比较，当前空集由原表直接证明。

`engine_metric_spec`、`engine_metric_result` 和 `engine_iteration` 的唯一直接表写入文件
是 `metrics/store.ts`。任务、agent、engine 或 UI 层不得直接写这些 metrics 表。

## session 域（9 表）

Session 标题通过同一个事务 primitive 写入并发布真实 Updated 事件；已有事务的业务创建可直接使用它，异步调用继续使用 Session.setTitle。自动命名携带读取时的 expectedTitle，并在写事务内与当前值比较：匹配才提交生成名称，不匹配返回当前真实 Session，保留用户期间选择的名称。显式重命名不携带该条件。首次人类命名由持久化 Message 的 role=user 且 author=user 身份确定，允许其后已有其他输入；控制器/调度器的传输 user 角色不构成人类作者。流式标题生成沿用同一身份与条件写回，消息与模型请求仍保留真实参与者。
共享自动标题投影通过公共引用词法范围识别连续开场引用；存在业务正文时由正文首个非空行命名并沿用80字符上限。正文内引用、仅含引用的请求及非法前缀保持原有文本语义；消息、Goal目标和Task请求不改写，历史或用户自定义标题不批量更新。

`src/session/session.sql.ts`：

| 表                       | 作用                                                                                                                                   |
| ------------------------ | -------------------------------------------------------------------------------------------------------------------------------------- |
| `session`                | 会话树节点；关键列：`kind`、`parent_id`、`directory`、`permission`、`metadata`；不拥有 Goal lifecycle                                  |
| `message`                | 持久化 user / assistant 消息                                                                                                           |
| `part`                   | 消息分片（tool call / text / reasoning / …）                                                                                           |
| `interactive_artifact`   | Session 内可交互 artifact                                                                                                              |
| `session_control_record` | durable compaction / summarize 等控制请求；记录请求事实，不证明当前 Runtime 存活                                                       |
| `session_prompt_owner`   | Session 唯一物理 prompt loop 的 generation 与精确 OS process occurrence；仅在该 occurrence 已死或 PID 已复用后允许原子接管             |
| `worker_turn_descriptor` | Projected worker 的不可变 Turn identity、模型、tool projection、Task、dispatch lineage、精确 package revision 与哈希；restart 恢复真源 |
| `todo`                   | session 内 todo                                                                                                                        |
| `permission`             | 权限请求（project 级全量规则集）                                                                                                       |

**SessionKind** 固定在 creation time。唯一枚举来源是
`session.sql.ts` 的 `SESSION_KINDS`; 文档不复制成员列表。Projected worker 的
运行身份来自持久化 worker descriptor，不来自 SessionKind。

Session/Trace 是持久化历史与身份容器；Turn/Attempt 是一次模型执行；Runtime
中的 stream、取消句柄、MCP（Model Context Protocol，模型上下文协议）连接、
tool instance、callback 与 Promise 仍只属于当前进程。`session_prompt_owner` 不复制
这些资源，只用 generation 加 PID、process-instance identity 与 occurrence identity
证明哪个物理进程可以产生 Provider/Tool effect。它在 standby 期间继续存在，并持续
观察 durable user Message、runtime wake 与 `session_control_record`。普通待机还必须查询同一 Session
尚有 `pendingDelivery` 的输入；执行中入队的消息可能早于该 Turn 的最终 assistant，不能仅凭最终
assistant 的 timeline cursor 跳过它。该检查只唤醒现有循环，由原有原子 acceptance 消费输入；
等待精确 compaction lease 的分支仍遵循该控制的唤醒/到期边界。进程内事件只用于
降低唤醒延迟。reply peer 通过 accepted input Message identity 加入，summary peer 先按
本次 exact Session control ID 加入其 consumed/failed 终态；consumed terminal 必须与
该 control durable payload 中的 exact summary Message ID 绑定在同一个 immediate transaction。
新 compaction 直接使用 checkpoint publisher 返回的 Message ID，禁止按 source、时间或排序
重新查找；首次没有可压缩材料且没有已有 summary 时写入 typed failed terminal。已有 summary 且
没有 post-summary material 的幂等 no-op 显式绑定已有 summary；local callback 与 peer 只从
该 receipt 投影，不按 source 或 wall-clock 猜测。只有 OS 证明原 occurrence `dead_or_reused` 后才原子替换并
终态化废弃 assistant。服务重启只销毁 Runtime，不能使 Session、message、descriptor
或 durable coordination request 失效。

本地 Prompt 的同一 `terminating` 状态区分关闭接纳与释放资源两个阶段。终态结果回调
可见前，循环先依据精确结果匹配、其他已接入回调、待处理控制和 runtime wake，决定
继续当前 owner 还是同步关闭接纳；新调用随后等待原有 reusable receipt，再取得下一代
owner。资源释放只加入已经释放中的同一 owner，不能把“已关闭接纳”误作释放已启动。
手动压缩按其实际 summary/control receipt 完成并交付结果，不按最早调用方的 result mode
或最新一条 Message 推断。普通成功、失败、重复结果与取消继续使用相同的拥有者合同；
自动压缩和待机通知本身不是终态。此过程没有增加持久化队列或调度状态副本。

`SessionStatus.executionOccurrence`绑定当前接管的真实输入与精确Prompt拥有者，
并从唯一进程内executionStates派生已发布status。真实idle保留在该现状态中；
尚未有首次发布的输入为undefined，不能把getExecution的展示默认idle当作已结束事实。
物理取消receipt保存该边界的精确未结束输入，不按最后Message或pending callback猜测。

Compaction history reconstruction preserves the original dispatch authority input across incremental
continuations. During newest-first traversal, a completed assistant-step tail already encountered before
the checkpoint's source input satisfies that boundary immediately; reconstruction continues toward the
checkpoint's original anchor. Repeated compaction for the same source keeps that checkpoint anchor,
not the incremental source Message. Worker descriptor/Task authority checks remain strict. Invalid
historical markers are not rewritten or repaired by a different dispatch or a new Session.
The relocated summary's position in model history is not a durable chronology boundary.
Post-checkpoint material is identified by canonical Message timeline order, so an old
retained tail cannot trigger repeated compaction merely because it follows that summary
in the Provider projection. A repeated control with the same source binds the existing
summary receipt until actual newer material is persisted.
Windows 进程对象即使在退出后仍可能因外部 query handle 而保持可查询；只有持有 `SYNCHRONIZE` 权限的
process handle 经零时长 `WaitForSingleObject` 返回 `WAIT_TIMEOUT`，才可结合匹配的 creation FILETIME 证明
`exact_live`。已 signaled 的 process object 必须投影为 `dead_or_reused`；`GetProcessTimes` 在未退出时的 exit
FILETIME 内容未定义，不能作为存活或死亡判据。否则 peer Prompt 会永久等待已经退出但 kernel object 尚未释放的 owner。

跨进程调度准入不能读取进程内 `SessionStatus` 作为共享 busy 权威。一个 Session 的当前
共享执行事实是同一数据库快照中 `session_prompt_owner` 的精确进程 occurrence 仍为
`exact_live` 或 `unknown_live`，且该 Session 存在 `time.completed` 为空的 assistant Message；
standby owner 没有 unfinished assistant，已证实 `dead_or_reused` 的 owner 也不阻止接管。
Recurring Session Automation 在 claim 已发布的 scheduled Fire 前，必须在同一个 immediate writer transaction
内重验该组合事实与 exact Fire/definition/delivery frontier。busy 时只获取绑定原 due occurrence 的
短 `automation` admission-delay lease，不创建 Fire、attempt、run 或 receipt；lease 到期后
下一 poll 重新读取全部事实。manual API/Tool run 在同一事务看到该事实时返回 typed running
conflict，同样不得先创建 Fire。

空闲 Session 的一个 Turn 可以按顺序接受该 Turn 开始时完整的待投递 user Message
批次。新 assistant Message 持久化完整的 accepted input Message identity 集合，且
`parentID` 等于集合尾项；删除这些输入的 `pendingDelivery` 标记与插入 assistant
Message 必须属于同一个 SQLite transaction，并发生在 streaming status 发布与
Provider 请求之前。进程内 callback 与跨进程公开请求 replay 都按该持久化集合的成员关系
收敛到同一 assistant Message；peer 不得创建第二个本地 prompt loop。Session 尚未接受更新 user Turn 时，失败重试选择与
当前调用方 identity 相交的最新失败批次；一旦 Session 已接受更新 user Turn，旧失败
identity 的公开 replay 返回 typed conflict 并要求新 identity，不能用更新 transcript
重驱旧批次。该最终判定必须发生在真实 Session owner 准入之后：旧 replay 附着到更新
owner 时只拒绝旧 callback；旧 replay 因竞态先成为 owner 时也只拒绝自身 callback，并由
该 owner 继续处理已接受的更新 Turn。后续成功回复保持唯一权威；没有显式集合的历史
assistant Message 只接受其 `parentID`。该事务只消费投递标记，不得重写其余 authored
payload；已冻结的 Task-root causal fact 仍由数据库不可变约束拒绝修改。

**去掉的字段 / 索引**（旧文档还在提，代码已清理）：

- ~~`session.channel_key`~~ — Gateway 单例概念删除
- ~~`session_gateway_singleton_idx`~~ — partial unique index 已删

`gateway` 不再是 SessionKind；当前 gateway 是 control-plane HTTP surface / route（见 [03-control.md](03-control.md)），不通过独立 session kind 或旧 gateway 包承载。

Session 通过 immutable dispatch lineage 关联真实 Task 派发及其可选参考来源和 logical
`workflow_occurrence_id`；lineage 可以列出
一个或多个 `delivery_slice_revision_id` 作为证据主题，但这些引用不表示 Session 归
Goal 所有。Overlay 从真实 live/terminal Session、node evidence、Artifact Catalog、
reviewer artifact 与 Task Completion Decision 分别投影 current revision、独立
activity/evidence/review association 和显式 acceptance。各 facet 互不合成为 Goal
进度或 lifecycle；该 projection 只读，不回写 Slice，不参与调度或 Task 完成判断。

Session message 表按 Session writer 分层写入：`part` 的唯一直接表写入文件是
`session/index.ts`。Build、tool、server route、compaction 和 shell execution 只能通过
`Session.updatePart` / `Session.updatePartData` / `Session.persistMessage` 等 Session writer API
创建或修正 part row，不能直接写 `PartTable`。

公开 Session shell 以调用方创建的 user Message ID 作为执行 occurrence（执行轮次）身份，
同一身份永不重新执行命令。input user Message、assistant、running `bash` Tool request、当前 backend
process occurrence 与该 Tool 的 `session_shell` execution lease 必须在一个 SQLite writer transaction
内原子持久化。跨 backend 竞争的失败方只能读取这一完整执行图，不得观察到只有 input 的中间状态。
spawn 创建的是等待 start admission 的 gated child；只有 child 的精确 process occurrence 已写入可变
Tool progress fact 后才打开闸门并启动真实命令。该初始 progress writer 必须在同一 transaction 内
assert exact shell lease 且确认确实新增 running progress；outcome 已存在时返回的 no-op 不构成 start
admission。child occurrence 不得回写不可变 request metadata。owner 在命令存活期间续租该 Tool 的
精确 lease；正常、abort 和 caught failure 均等待物理进程收敛，再在一个 writer transaction 内 assert
exact lease、按 Tool terminal → assistant terminal 的顺序写入，并以同一 transaction 释放该 lease。
fence loss 的旧 owner 不得写 success/failure terminal，而是从 durable graph 收敛同一 interruption outcome。

replay 只读取该 occurrence：精确 child 仍存活，或同一 Tool 的精确未过期 lease 仍有效时，返回同一
in-flight assistant；backend PID（Process Identifier，进程标识符）存活本身不证明该 shell 仍被拥有。
child 已死亡/被复用且精确 lease 已释放、过期或丢失时，把同一 open Tool 写成 deterministic typed
`process-execution-interrupted` error 并收敛同一 assistant，绝不生成替代 Message 或重跑命令。
旧版本遗留的 completed assistant 加 open Tool 仍须 terminalize 该 Tool；completed assistant 已是不可变
事实，不得为修饰历史状态而重写。

## 控制 / 工作区

| 表                | 文件                         | 作用                                                                              |
| ----------------- | ---------------------------- | --------------------------------------------------------------------------------- |
| `workspace`       | `workspace/workspace.sql.ts` | 多工作区代理元数据（路径、状态）                                                  |
| `control_account` | `control/control.sql.ts`     | 外部控制账号（email + url）                                                       |
| `project`         | `project/project.sql.ts`     | 项目根；`time_pinned` 是 Work Ledger 项目置顶状态的唯一来源，且不改变项目活动时间 |

Work Ledger 的置顶状态由各耐久领域拥有：Project 使用
`project.time_pinned`，Mission/Chat/Work 使用 `session.time_pinned`，Task
使用 `engine_task.time_pinned`。各领域 writer 只改写本领域的
`time_pinned` 并发布既有更新事件，不改写 `time_updated`；统一 Work Ledger
投影按 `pinned DESC, updated DESC, rowKey DESC` 排序和游标分页，Overlay 不保存
第二份置顶状态。

活动 Work Ledger 在服务端按精确 Mission 根划分 Task 层级：只有能解析到同一
Project 中精确 Mission Session 的 Task 才进入该 Mission 的子列表；未归档且没有
这条根关系的 Task 是 Mission、Chat/Work 的普通顶层同级项，复用同一 Task 选择和
耐久操作契约。该划分发生在搜索、排序和游标分页之前，Overlay 不过滤或重建层级，
同一 Task 也不跨层重复投影。

Control Agent 的文本、tool call 与 tool result 只写普通 Session message/part；
不存在独立 `control_message` timeline。轻量辅助域仍按领域 writer 分层写入：
`decision_log` 的唯一直接表写入文件是 `decision-log/index.ts`，`quick_note` 的唯一
直接表写入文件是 `quicknote/service.ts`。Project delete 可以编排项目级清理事务，
但必须调用这些领域 writer API，不能直接删除其它领域表。

`project` 表的唯一直接表写入文件是 `project/project.ts`。Project delete 和
Project GC（Garbage Collection，垃圾回收）可以编排项目生命周期，但必须调用
`Project.deleteRows` 等项目领域 API，不能直接写 `ProjectTable`。

生产代码的直接表写入 registry 由
`packages/opencorvus/test/script/db-write-boundary.test.ts` 强制维护：每个出现
`.insert(Table)` / `.update(Table)` / `.delete(Table)` 的表都必须登记唯一 writer 文件。
新增直接写表或第二个写文件会让该测试失败，不能用未登记表绕过分层边界。

## Project Storage Namespace

`project.id` / `project_id` 是后端 storage namespace，不是用户可见项目数。
同一 canonical project worktree / common Git identity 必须收敛到一个后端
namespace；一个目录下的多个用户可见 Mission / task 通过现有 Mission/task 记录
表达，不能通过制造多个 `project_id` 行表达。

Session、Mission 和全局 Task 的可选目录查询复用
`session/directory-filter.ts`。查询在同一数据库读事务中收集当前范围内实际存储的
Session 目录，用 `Filesystem.resolve` 与 `Project.samePath` 的既有词法语义匹配，
再以这些真实值构造 SQL（Structured Query Language，结构化查询语言）条件。
匹配发生在游标分页之前；省略或空目录保留原有全范围语义，合法未匹配目录返回空结果。
Project 内与全局范围仍由各领域查询决定，不以目录归一化改变所有权。该词法契约不合并
符号链接或物理别名，也不提供另一套前端路径规则、规范化列或目录缓存。

`Project.fromDirectory()` 与 exact-worktree convergence 是当前 namespace 入口。
重复 worktree 行只能收敛或显式报错；当历史 JSON/text 中存在
`/attachment/<projectID>/...` 这类嵌入式 namespace identity 时，不能盲改或复制
foreign attachment 来“修复”。Attachment bytes 的物理池在
`.opencorvus/.r/b/a`，但语义 owner 来自记录里的 `project_id` / durable contract。

## 辅助域

| 表                                                            | 文件                         | 作用                                            |
| ------------------------------------------------------------- | ---------------------------- | ----------------------------------------------- |
| `decision_log`                                                | `decision-log/schema.ts`     | **全局共享上下文**，append-only，所有 agent R/W |
| `workbench_brief_snapshot`                                    | `workbench/workbench.sql.ts` | 面板简报快照                                    |
| `memory_file` · `memory_chunk` · `memory_embedding`           | `memory/memory.sql.ts`       | Project 级长期语义记忆                          |
| `task_plan`                                                   | `memory/task-plan.sql.ts`    | 任务计划记忆                                    |
| `quick_note`                                                  | `quicknote/quicknote.sql.ts` | quicknote                                       |
| `session_share`                                               | `share/share.sql.ts`         | 分享                                            |
| `protocol_event` · `protocol_inbox` · `protocol_stream_chunk` | `protocol/protocol.sql.ts`   | 可观测协议事件与流分片                          |
| `automation` · `automation_definition_tombstone` · `automation_fire` · `automation_fire_frontier` · `automation_fire_attempt` · `automation_fire_attempt_receipt` · `automation_run` · `automation_run_receipt` · `automation_delay_settlement` · `event_job` · `event_job_definition_tombstone` · `event_occurrence` · `event_job_fire` · `event_job_fire_receipt` | `scheduler/*.sql.ts` | 定时、逻辑 Fire、唯一物理交付 frontier、物理尝试、目标执行、Session admission 与事件触发 |

Scheduler 表按事实 owner 分层写入：Automation service 拥有 definition revision、tombstone、Fire、attempt、run 与 receipt；Session assistant-admission transaction 可以追加唯一的 `automation_delay_settlement`，并在同一事务追加该 one-shot delay 的 superseded run receipt 与 definition tombstone。两者共用同一个 transaction-local fact reducer，后者不是第二个 Automation service。 `due_accepted` 绑定一个精确 Fire 与 accepted input batch 的首次 assistant admission；同一 batch 的后续 Tool step 或重启续行复用该不可变接收事实，保留首次 assistant Message ID。后续步不重新竞争 Automation 接收 lease，也不创建第二个 settlement；不同 Fire、batch 或 disposition 仍属于接收冲突。Assistant admission 通过 `(session_id, kind, status, definition_id, revision)` frontier index 只查询调用方给出的 Session 集合中的 latest active delay，并按同一有界 definition page 批量读取 lease、Fire、run/receipt 与 attempt summary；它不扫描其他 Project 或全局 Automation。Active definition revision 在接收时发布一个 revision/due-bound scheduled Fire，并把它写入唯一的 `automation_fire_frontier` 物理交付权威。Claim 与 lease renewal 在同一 writer transaction 把 `available_at` 推进到 lease expiry；retry 推进到 receipt deadline；scheduled terminal settlement 原子发布 successor 并替换 frontier，manual terminal 恢复已发布的 scheduled Fire，pause/tombstone 与 one-shot terminal 删除 frontier。Global poll 只从 `(available_at, definition_id, fire_id)` index 读取一个 64-row due page；retained terminal Fire、future retry、旧 definition 与 live lease history都不参与物理扫描。Exact claim 在 immediate writer 中重验 current revision、frontier、Fire 与 lease；完整 immutable history 只在显式 history API 中归约。Event service 在一个 immediate writer snapshot 内以 active Project 的 `definition_id` cursor 分页读取 current definition，为匹配 Fire 分配 definition-local immutable queue position，因此 definition/tombstone、one-shot terminal 与 Fire acceptance 只有一个串行顺序。terminal receipt 复制该受 DDL 约束的 queue relation并且只能连续推进 FIFO frontier；head 查询先从 partial terminal index seek 最新位置，再从 Fire index seek精确 successor。accept、startup recovery、claim、handoff 与 lease recovery 共用该 reducer，retained terminal history 不进入物理调度集合；lease timer 醒来时重读 definition frontier，所以 terminal commit 后的 owner crash 不会丢失 successor handoff。Event 与 Automation 的完整 immutable history 都只在显式 history API 中归约。Tool、server route 和 engine 层只能通过这些领域入口创建、更新或删除 scheduler definition。Task wait 不使用 Automation 表，而是 `engine_task_wait_registration` 加可选 `engine_task_wait_settlement` 的 epoch-bound Task-control 事实。

Automation target membership 属于 exact physical definition revision。当前投影的 `id` 是稳定 `definition_id`，`revision_id` 才是目标关系与 Fire 冻结的物理修订。展示、后续定义更新、manual/due claim 与 retry/restart execution 通过同一显式 revision target reader 读取关系；projected caller 必须传 `revision_id`，Tool immutable receipt 传其原始物理 `id`。两者不能互相 fallback，也不得由稳定 definition ID 读取首版本项目成员。目标顺序保留对应物理修订的 position；不同修订与历史 Fire 仍各自保留真实目标事实。

Automation physical attempt 在同一 writer transaction 冻结 exact lease ID、lease-grant ordinal 与 admission-time expiry；三者必须精确匹配 acquisition/renewal 时追加的 immutable `engine_control_activation_lease_grant`，attempt 对 lease/grant 的 retained foreign key 防止历史权限成为 orphan。后续 lease release 或 renewal 不改写既有 grant。Live admission 以 `(time_activated DESC, id DESC)` 选择 current lease，并冻结当时 latest grant ordinal；后续 grant renewal 保留原 attempt 的 immutable admission，不按 mutable live expiry 重新解释历史授权。

## Trace — 统一运行追踪（横切）

**代码**：`src/trace/index.ts`

替代旧的：

- `AgentTrace` — per-agent markdown dump
- env-gated `LLMTrace` — session 级 JSONL

**新设计**：

```
每个运行事件（task/agent 边界、llm.step deltas、tool.call/result、lifecycle 事实）
  ↓ AgentTrace.recordLLMRequest / recordHelperLLMCall / trace event writers
  ├─ 追加 JSON 一行到 <Instance.directory>/.opencorvus/trace/<sessionID>.jsonl
  │  以及 _task-<taskID>.jsonl（taskID rollup）和 _index.jsonl（manifest）
  └─ Bus.publish — overlay SSE 消费者实时拿到
```

**自动埋点**：`session/llm.ts`（`LLM.stream` 入口）+ `agent/runner.ts`（`runAgentSession`）+
`orchestrator/agent.ts`（`Orchestrator.processTask` wake）+ `task-api/index.ts`（helper 调用记录）。
Agent 代码不手工调 trace；命名空间是 `AgentTrace`，不是历史文档里的 `Trace.event()`。

## Bus — 全局事件总线（横切）

**代码**：`src/bus/bus-event.ts` · `src/bus/global.ts` · `src/bus/index.ts`

- 类型安全的 event 定义（`BusEvent.define(name, zodSchema)`）
- `Bus.publish()` 全局发布
- SSE 消费者订阅 → overlay 实时刷新
- Trace 双写的第二条路径

Task Conversation 的 Agent progress activity 是 `part` 持久事实的有界读时投影，
不是第二份 transcript。`MessageStore.latestConversationAgentActivityBySession` 通过 canonical
raw Part type/time 表达式索引，在每个 Session 的一个 compound read 中分别读取 Text、Tool、
Patch、File、part-error 的首个有界页，只在该类型含非投影值时继续 indexed keyset，最终保留
最新 24 个实际活动事实。reasoning、boundary、interaction 与 control 等 transcript-only Part
不得先搬入 JavaScript 再被丢弃；其损坏诊断仍由精确 Session transcript route 单独拥有。

事件清单定义在 `engine/model.ts` 的 `Event.*` namespace。Goal 面板更新来自 Slice
revision、Session/dispatch、Artifact、review 与 Task decision 的真实事件；不存在
可写的 Goal 状态事件。

## Decision Log（重申）

- 全局共享 append-only 表。
- 精确动态 worker 通过各自 typed adapter 写入事实与契约；Orchestrator 根据 active package guidance 和当前证据选择后续 projected consumer。
- Adapter ID 与 SessionKind 只描述 ABI 或会话形态，不构成固定 Agent 身份、成员顺序或调度拓扑。
- **传 WHY 不只 WHAT**。

## Task Input 与 Design Resource 语义

## Workspace 与受管 Git 子项

Workspace 数据库行不是 Git worktree 的创建或删除 receipt（收据）。当前事实源是
`workspace-lifecycle` durable publication occurrence：Database 实例、Project、Workspace 与
`creating` / `deleting` 共同确定 occurrence，immutable intent（不可变意图）在任何 Git mutation
之前冻结 Project generation、primary repository、managed directory、branch 与 branch target。
创建依次记录 Git registration、worktree readiness、Project sandbox ownership 和 Workspace-row
publication；只有四者完整时才提交 occurrence。删除依次记录 physical directory removal、Git
registration prune、exact branch retirement、sandbox settlement 和 Workspace-row retirement；只有
外部子项完整结算后才删除 aggregate row。重启与 API retry 都重放同一个 occurrence，不从目录是否
存在、最新 registry entry 或随机 worktree name 推导结果。

创建或删除在 journal 和任何 Git effect 之前，先在 `workspace_lifecycle_admission` 发布当前 frontier：
exact Project generation、Workspace identity、`creating` / `deleting`、`public` / `project_delete` authority
与 physical process occurrence。每个 frontier 通过 Database、Project 与 Workspace scope 直接定位自己的
durable journal，不枚举全局永久历史。Project deletion fence 和 Project identity convergence 都在自己的
SQLite immediate writer transaction 中检查这张表；Project 关闭阻止 `public` frontier，只接管同一
Project deletion fence 已发布的 delete frontier，Workspace row publication 也在同一事实源中重验 exact
owner。这样 create、public delete 与 Project delete/convergence 只能按数据库 writer 顺序线性化，而不是
依赖进程内锁或 Bus。启动恢复仅在物理 owner 被证明 `dead_or_reused` 后接管无 journal frontier；open
journal 继续同一 reducer。public terminal frontier 结算即删除，Project-delete terminal frontier 保留到
Project row cascade，使 Workspace row 已退休后的 Project retry 仍可直接找到其 frozen child receipt。

Project 删除在第一个 child effect 前冻结全部 Workspace rows 和其余 registered managed worktrees。
Workspace child 复用其 canonical deleting occurrence；没有 Workspace row 的 managed worktree 使用按
Database、Project generation 与 directory occurrence 确定的 Project-child journal。两类 journal 都
复用同一个 directory admission 和 Git writer lease，并在 Project deletion fence 下保留原 sandbox
snapshot，直到 final Project transaction 证明 Workspace set 为空、所有 child receipts terminal，才允许
删除 Project row。已经在 intent capture 前被证明不存在的 registered directory 仍保留在 registry
snapshot 中，但不会制造一个虚假的 physical cleanup target。

Project managed-child journal 把 device、inode 与 birth time 纳入 occurrence ID，并以显式 predecessor
连接同一 Project generation、registration/sandbox path 上的后继物理 occurrence。retry 只选择唯一 chain
head；每个 Project generation 与 frozen child path 使用自己的 publication scope，建立后继后退休已结算
的历史 predecessor，所以 lookup 与 retained history 都不随其他 Project 或永久历史增长。present namespace
必须匹配该 exact occurrence，只有 namespace 已消失时才能重放 head 的 frozen plan。因此 retry 不从已被
删除的 alias/registry 重新计算 child identity，同路径后继也不会被历史 terminal journal 吞掉。普通
garbage-collection（GC，垃圾回收）候选本来没有
Project sandbox owner；其 public removal plan 冻结“无匹配 sandbox 且不释放 sandbox authority”的事实，
仍须证明 exact Git registration、branch target、directory occurrence 和 ownerless marker，不能制造
sandbox ownership。Workspace/public delete 与 Project delete 仍必须持有并结算其 frozen exact sandbox。

`task.attachments` 只保存用户上传的中性输入。每条记录固定为
`intent="task_input"`、`source="user-upload"`；MIME（Multipurpose Internet Mail
Extensions，多用途互联网邮件扩展类型）、文件名和扩展名都不能推导领域语义。
`AttachmentStore` 只负责 canonical bytes 与 metadata sidecar，也不拥有领域语义。
物理 attachment 目录不保存第二份 Database authority，也不创建 `.authority.json`。
Project identity、附件引用和可回收集合只来自当前 Database；`Project.worktree` 是物理位置的唯一
来源。attachment bytes 位于 `attachments/<database-path-digest>/` 命名空间；同一路径的普通 reopen、
显式 reset 后建立的新库继续使用同一 bytes 命名空间，不同 SQLite 路径即使指向同一 Project 目录也不
共享 sweep 集合。该目录段只用于物理隔离，不是可变 marker、锁或平行 authority 文件。write 继续使用
每个 content-addressed blob/metadata pair 的跨进程锁、临时 staging、哈希、长度与 canonical
reference 校验；sweep 清理当前命名空间中未引用且超过 grace period 的 blob 及其 sidecar（若存在）。
显式 `db reset` 必须同时删除 SQLite DB/WAL/SHM 与传入 Project 的 `.opencorvus/.r`；它不靠
项目文件中的数据库身份阻止或修复不完整的 operator reset。Project identity convergence 只使用
canonical Database rows、嵌入引用和现有 durable owner 检查，不读取文件系统 marker 作为平行事实源。

Overlay 手动文件、文件夹、拖放、粘贴和 host attach 的唯一入口先把 raw bytes 写入
project-scoped `POST /attachment`，composer 只保留返回的
`/attachment/<projectID>/<name>` canonical reference。后续 Chat、Mission、Task create
和 Task follow-up 都只传该 reference，不能在 browser store 或 JSON（JavaScript Object
Notation，JavaScript 对象表示法）请求体中保留 data URL / base64 bytes。
公开 Session message 在已验证当前 Project 与 Session lineage 后，以该 Session.projectID 绑定内部字节物化 owner；该字段不进入用户请求 schema 或原始输入身份。普通续聊的 canonical attachment、显式 binary 输入及 MCP blob 共用原 AttachmentStore 校验、存储和公开读取，不根据 URL、文件名或全局当前项目猜测归属。
全局 New Chat / Work 的空 Composer 和取消 picker 不创建 Project / Session 数据（显式模型偏好由既有 Overlay settings 保存）；一旦 picker 返回真实文件或
目录、发生拖放或粘贴，实际附件就是首个 durable input，由统一 Composer Project resolver
创建并激活一个匿名 Project，再进入上述严格 project-scoped ingress。后续首次 Session 或
Mission 提交复用该 Project，不能为附件建立 browser-memory 暂存源或第二个 Project identity。

Composer 的文件与文件夹是两个独立的有界输入集合：文件最多 10 个，文件夹最多 3 个。
文件选择、拖放、粘贴与 host attach 共用文件容量；移除后释放对应容量。文件夹选择必须走
host 的原生单目录 picker，得到一个真实路径后由
`POST /attachment/directory-reference` 校验并写入一份
`application/vnd.opencorvus.directory-reference+json` canonical manifest。一个根目录固定只
产生一个引用和一个 UI（User Interface，用户界面）卡片；该入口禁止使用
`webkitdirectory`、`webkitRelativePath` 或任何递归枚举、逐文件上传、自动压缩逻辑。

手动上传生成的 persisted `Message.FilePart` 必须带
`presentation="attachment-index"`。Provider replay 对所有 MIME 只投影稳定的
filename、MIME 和 URL（Uniform Resource Locator，统一资源定位符）索引，不读取 bytes。
该 presentation 是手动上传来源的显式逐文件契约，不得通过 canonical URL、MIME 或文件名
猜测。没有该标记的 programmatic typed evidence 保留既有 multimodal 行为，避免把 Build、
tool result 或其他显式证据输入误降级为索引。

`frontend_design` 通过 typed adapter 显式声明本次调用的资源及 intent：

- 已上传文件使用 `attachment_bindings[{ attachment_url, intent }]`，URL 必须属于当前
  task / project，且 DB（Database，数据库）记录必须与 canonical metadata 一致。
- 本地材料使用 `materials[{ path, intent }]`。

供应商资源的获取、解析和文件命名属于专家团 package tool / skill / scoped MCP（Model
Context Protocol，模型上下文协议）；core 不识别供应商 URL 或工具序列。Package 将产物
落成 task/project-scoped 本地文件，再通过通用 `materials` 输入。物化的本地材料写入
`system_artifacts`，不能伪装成用户附件。调用方显式声明的 intent 被原样写入
`design_resource_manifest`；manifest 创建过程不能根据 mode、MIME、来源或文件名覆盖 intent。FrontendDesign Agent、continuation evidence 与
reference-parity Build 都只能读取该 manifest 投影出的设计资源。Reference-parity Build
缺少 manifest 或 manifest 中没有 `visual_reference` 时必须显式失败，不能回退扫描原始
attachments / system artifacts。

可渲染 HTML 不是 text-only 备注。`reference_parity` 调用中，显式声明为
`design_source` / `interaction_reference` 的 HTML 是结构、样式、内容和交互的 source
authority。Frontend Design adapter 在 worker 启动前使用现有 Node/Playwright 静态文件
renderer，把每个 HTML 投影成 task-scoped PNG，并在同一个 manifest 中追加
`origin=rendered_design_source`、`intent=visual_reference` 的 raster row；HTML row 与
raster row 通过 `related_entries` 双向绑定，raster 的 task artifact path 记录在
`artifact_paths`。这不是第二份资源目录：manifest 仍是唯一语义索引，AttachmentStore
仍是 byte store，PNG 只是 HTML authority 的可查看/可比较投影。投影失败必须暴露为
materialization/toolchain error，禁止改走 `greenfield_original`。

Browser Node sidecar 的唯一脚本输入协议是 `argv[2]` 中的 base64 JSON payload 与
`argv[3]` 中的精确 Playwright module path；Frontend Design 静态渲染、runtime visual
render、acceptance walkthrough、Browser webpage extract/render/runtime-state 与 Browser
Preview evidence/region/layout/scroll render 均消费这两个参数，不读取平行环境变量、空值
fallback 或从用户项目解析运行依赖。
截图输出与 source/reference 的语义来自显式字段和 DesignResourceManifest，不通过文件名中的
preview、render、source 等词推断。截图路径必须位于当前 Task 的 visual-html-skeleton
目录且为支持的 raster 扩展名；真实路径、解码结果、renderer provenance 和 fresh-render
SHA256 校验提供字节证据。capture 输出不得与显式 source_reference_artifact 指向同一文件。
`capture_frontend_visual_evidence` 仅对 sidecar transport/toolchain 失败返回稳定 error code、
signature 与 `retry_once_after_concrete_correction` disposition。Frontend Design Agent 仅能在
一次具体修正后重试；相同 signature 再现时保留当前 facts、记录 blocker 并自然结束 Turn，
由既有 partial Artifact / `domain_incomplete` settlement 收敛，不能在用户项目安装 renderer
依赖或继续探查 Host 私有二进制。页面 request/page/runtime validation 失败使用独立
`frontend_visual_evidence_page_validation_failed` 契约，要求修复页面后重试，不得误分类为
基础设施阻塞。

## Build Input Evidence

Build 输入由 Orchestrator 从 Task、Delivery Slice revision、Artifact、Finding、Attachment 和可见
Session message 临时渲染成一条自然消息与一组稳定 attachment refs。这个临时 read
model 没有公共类型、durable identity、active/current 状态或启动 gate，也不会复制成
`build_session_contract`、Pack 或 Manifest。

AttachmentStore 继续拥有 content-addressed bytes；Session message/file part 只保存
真实 provider byte binding。Build prompt 携带稳定引用和自然文本，真实
byte/project 校验发生在 AttachmentStore read/stage、SessionPrompt byte
materialization 和明确的 storage API 边界。服务重启后从原始 durable facts
重建消息，不读取 runtime/live aggregate。

`filename` 是 display/provenance metadata，不是 byte identity。硬身份校验只能使用
project URL、`sha`、`mime`、`size` 和实际可读 bytes。

后续修复必须作为新的显式 Task dispatch，从持久化消息、Task attachments、Artifact
references 与 Slice/Requirement facts 构造自然输入。Session 不持有 Goal retry
counter 或 retry workspace。已经存在的 provider file part 是真实 Session message
fact，可以复用；不得额外复制成 input manifest。

后续长期文件 owner 是通用 `artifact_file_ref`，不是 attachment-only
`attachment_ref`。在该表实施前，GC 仍可对 `/attachment/...` 嵌入引用做
harvest。

## Text file page boundaries

The ordinary Read tool and both Skill supporting-file readers use one text-page
collector for line limits, contiguous byte-bounded pages and complete file totals.
Its long-line prefix stays within the existing 2000 UTF-16 code-unit budget and
ends between complete code points: a boundary inside a valid surrogate pair moves
back one code unit. The existing truncation notice and 50 KB page budget apply to
that same prefix. Tool output and preview share it; file bytes, source identity and
line ranges remain the original read facts. This does not promise grapheme-cluster
boundaries or repair malformed source text.

## 相关文档

完成的助手消息在原子整批写入及正式会话导入时，共用同一初始行构造器：先在事务内保留可写入 Parts 的开放行，临时移除 completed、finish、error 以及依附 error 的 failureOccurrence、convergenceFailure、observationFailures；Parts 写入后再统一持久化完整原终态。临时行不作为对外消息发布，最终错误及诊断归属必须满足原 Message schema，已完成消息仍不可变。

- [17-code-work-agent-platform.md](17-code-work-agent-platform.md) — 动态 Agent 投影、runtime template 与 typed adapter 的职责边界
- [03-control.md](03-control.md) — Trace/Bus 如何流向 overlay
