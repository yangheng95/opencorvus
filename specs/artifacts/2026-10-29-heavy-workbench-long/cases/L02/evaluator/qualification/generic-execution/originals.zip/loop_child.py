import json,os,sys
from pathlib import Path
root=Path(__file__).parent
sys.path.insert(0,str(root/'source-loop'))
from run_l02_study import main
from l02_execution import atomic_bytes,json_bytes
mode=sys.argv[1]
def observer(stage,cell):
 if mode=='checkpoint' and stage=='verified':
  atomic_bytes(root/'python-checkpoint.json',json_bytes(cell))
  os._exit(82)
raise SystemExit(main(sys.argv[2:],observer))
