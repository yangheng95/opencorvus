"""Read-only plan/source capture. Does not import or execute benchmark programs."""
import json,shutil,subprocess
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parent
SNAP=ROOT/'source-plan';SNAP.mkdir(exist_ok=False)
REPO=Path('D:/myhexin-local/opencorvus')
SPEC=REPO/'specs/records/2026-10/2026-10-30-heavy-workbench-l02-qualification.md'
CASE=REPO/'specs/artifacts/2026-10-29-heavy-workbench-long/cases/L02'
paths={
 'qualification-record.md':SPEC,
 'run_l02_study.py':CASE/'evaluator/current-source/run_l02_study.py',
 'l02_study_data.py':CASE/'evaluator/current-source/l02_study_data.py',
 'STUDY-CONTRACT.draft.md':CASE/'public/STUDY-CONTRACT.draft.md',
 'evaluator-README.md':CASE/'evaluator/README.md',
 'process-lock.ts':REPO/'packages/opencorvus/src/util/process-lock.ts',
 'architecture-02-data.md':REPO/'specs/current/architecture/02-data.md'}
for name,src in paths.items():shutil.copy2(src,SNAP/name)
full=SPEC.read_text(encoding='utf-8');marker='## 2026-10-30 04:35 UTC 实施前Recall：通用提交与持久执行';assert full.count(marker)==1
(SNAP/'PLAN-04-35.md').write_text(marker+full.split(marker)[1],encoding='utf-8')
commands=[['git','status','--short'],['rg','-n','--glob','*.py','--glob','*.ts','--glob','!**/*.test.*','msvcrt|portalocker|FileLock|flock\\(|run_busy','script/benchmark','specs/artifacts/2026-10-29-heavy-workbench-long/cases/L02/evaluator/current-source','packages/opencorvus/src/util']]
receipts=[]
for i,argv in enumerate(commands):
 p=subprocess.run(argv,cwd=REPO,capture_output=True,text=True,encoding='utf-8');receipts.append({'argv':argv,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
(ROOT/'read-only-command-receipts.json').write_text(json.dumps(receipts,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
metadata={'captured_at_utc':datetime.now(timezone.utc).isoformat(),'paths_read':{n:str(p)for n,p in paths.items()},'copies_direct_byte_equal':all((SNAP/n).read_bytes()==p.read_bytes()for n,p in paths.items()),'new_benchmark_model_Docker_solver_Provider_executions':0,'new_implementation_executed':False,'scope':'preimplementation contract review only; code snapshots are old current reference primitives'}
(ROOT/'capture-receipt.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(metadata,ensure_ascii=False))
