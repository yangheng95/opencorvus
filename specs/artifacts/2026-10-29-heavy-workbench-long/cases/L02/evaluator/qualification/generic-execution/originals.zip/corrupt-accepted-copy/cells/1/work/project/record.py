from pathlib import Path
p=Path('/output/count.txt')
v=int(p.read_text())+1 if p.exists() else 1
p.write_text(str(v))
print(v,flush=True)
