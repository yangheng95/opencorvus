"""Only final reader/aggregate primitives and existing evidence, no external execution."""
import ast,difflib,io,json,shutil,sqlite3,zipfile,zlib
from pathlib import Path,PurePosixPath
from fractions import Fraction
ROOT=Path(__file__).resolve().parent
Q=Path('D:/opencorvus-benchmark-runs/l02-generic-execution-qualification-20261030')
OUT=ROOT/'implementation-final-boundaries';OUT.mkdir(exist_ok=False)
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
shutil.copytree(Q/'source-final',OUT/'source-final')
for n in ['final-error-addendum.json','boundary-assessment.json','binary-original-command.json','binary-observation-correction.json','binary_probe.py']:shutil.copy2(Q/n,OUT/n)
shutil.copytree(Q/'binary-log-run',OUT/'binary-log-run-originals')
checks=[]
def ck(n,v):checks.append({'name':n,'passed':bool(v)})
old=ROOT/'implementation-loops/source-boundaries-initial';new=OUT/'source-final'
files={p.name for p in old.iterdir()if p.is_file()};ck('final_only_execution_file_changed',files=={p.name for p in new.iterdir()if p.is_file()}and all((old/n).read_bytes()==(new/n).read_bytes()for n in files if n!='l02_execution.py'))
a=(old/'l02_execution.py').read_text();b=(new/'l02_execution.py').read_text();expected=a.replace('import zipfile\n','import zipfile\nimport zlib\n').replace('except (zipfile.BadZipFile, RuntimeError, OSError, ValueError) as e:','except (zipfile.BadZipFile, zlib.error, RuntimeError, OSError, ValueError) as e:')
ck('final_delta_only_import_zlib_and_catch',b==expected)
(OUT/'final-source.diff').write_text(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='source-boundaries',tofile='source-final')),encoding='utf-8')
pieces=[n for n in ast.parse(b).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))and n.name in {'ExecutionError','safe_relative','unzip_bytes'}];ns={'io':io,'zipfile':zipfile,'zlib':zlib,'PurePosixPath':PurePosixPath};exec(compile(ast.Module(body=pieces,type_ignores=[]),'final_archive_reader','exec'),ns)
probe=ROOT/'implementation-loops/corrupt-deflate.zip';shutil.copy2(probe,OUT/'original-corrupt-deflate.zip');reader=[]
for name,blob in [('original_corrupt_deflate',probe.read_bytes()),('original_bad_zip',b'not a zip file')]:
 try:ns['unzip_bytes'](blob)
 except Exception as e:
  reader.append({'name':name,'type':type(e).__name__,'code':getattr(e,'code',None),'detail':str(e),'scope':'exact-source pure helper; no full CLI rerun'})
  ck('reader_named_facility_'+name,isinstance(e,ns['ExecutionError'])and e.code=='facility_archive_invalid')
with zipfile.ZipFile(Q/'record-run/cells/1/accepted.zip')as z:expectedgood={n:z.read(n)for n in z.namelist()}
ck('valid_original_accepted_archive_exact_read',ns['unzip_bytes']((Q/'record-run/cells/1/accepted.zip').read_bytes())==expectedgood)
scoring=ast.parse((new/'l02_scoring.py').read_text());parts=[n for n in scoring.body if isinstance(n,(ast.ClassDef,ast.FunctionDef))and n.name in {'ProtocolError','aggregate_study_metrics'}];sn={'Fraction':Fraction};exec(compile(ast.Module(body=parts,type_ignores=[]),'final_aggregate','exec'),sn)
fields=['scaled_mse','scaled_mae','scaled_wis'];metrics={(o,m):{k:str(v)for k in fields}for o,m,v in [('o1','selected',8),('o1','other',2),('o2','selected',6),('o2','other',4)]};actual=sn['aggregate_study_metrics'](metrics,{'o1':'other','o2':'selected'},['selected','other'])
expected={'per_method':{'selected':{k:'7'for k in fields},'other':{k:'3'for k in fields}},'selected':{k:'4'for k in fields}}
ck('unselected_real_method_selected_no_alias_collision_two_origins',actual==expected)
bad=dict(metrics);del bad['o2','other']
try:sn['aggregate_study_metrics'](bad,{'o1':'other','o2':'selected'},['selected','other'])
except Exception as e:ck('missing_cell_named_fixed_denominator',getattr(e,'code',None)=='facility_aggregate_invalid')
finalreceipt=load(Q/'final-error-addendum.json');sr=finalreceipt['malformed_sqlite'];r=json.loads(sr['stdout']);ck('existing_malformed_SQLite_CLI_facility_exit3',sr['exitcode']==3 and r['status']=='run_invalid'and r['error']=='facility_storage_invalid'and r['candidate_score']is None)
binary=Q/'binary-log-run';db=sqlite3.connect((binary/'runs.sqlite3').as_uri()+'?mode=ro',uri=True);db.row_factory=sqlite3.Row;cell=dict(db.execute('select*from cell').fetchone());db.close();job=binary/'cells'/str(cell['id'])
with zipfile.ZipFile(job/'accepted.zip')as z:
 binarynative=json.loads(z.read('terminal-inspect.json'));bstdout=z.read('stdout.txt');binaryassessment=json.loads(z.read('assessment.json'))
commands=[load(p)for p in job.glob('*.json')];rm=[r for r in commands if r['argv'][1:2]==['rm']]
ck('binary_probe_actual_program_exit0_verified_cleaned',cell['phase']=='verified'and cell['exitcode']==0 and binarynative['State']['ExitCode']==0 and len(rm)==1 and rm[0]['argv']==['docker','rm',cell['cid']]and rm[0]['exitcode']==0)
bc=load(Q/'binary-original-command.json');correction=load(Q/'binary-observation-correction.json');ck('binary_original_checker_assertion_failure_preserved',bc['exitcode']==1 and json.loads(bc['stdout'])['type']=='AssertionError'and bstdout==bytes(correction['actual_docker_stdout_bytes'])and correction['actual_program_exit']==0)
with zipfile.ZipFile(Q/'python-loop/cells/11/accepted.zip')as z:
 png=z.read('output/result/forecast.png');report=z.read('output/result/report.md')
ck('actually_viewed_png_bound_original_report_process',png==(Q/'python-report-view/forecast.png').read_bytes())
(OUT/'actually-viewed-python-forecast.png').write_bytes(png);(OUT/'python-report.md').write_bytes(report)
save(OUT/'archive-reader-replay.json',reader);save(OUT/'aggregate-hand-control.json',{'input':{o+'|'+m:v for(o,m),v in metrics.items()},'choices':{'o1':'other','o2':'selected'},'expected':expected,'actual':actual});save(OUT/'binary-facts.json',{'cell':cell,'actual_native':binarynative['State'],'accepted_stdout_bytes':list(bstdout),'accepted_assessment':binaryassessment,'classification':'author probe assertion failed; actual program succeeded; binary-lossless stdout not qualified; daemon/CLI conversion origin unknown'})
save(OUT/'checks.json',checks);result={'checks':len(checks),'all_passed':all(r['passed']for r in checks),'failed':[r['name']for r in checks if not r['passed']],'new_Docker_predictor_solver_Provider_calls':0,'full_generic12_executed':False,'L02_frozen':False,'candidate_score':None};save(OUT/'assessment.json',result);print(json.dumps(result))
