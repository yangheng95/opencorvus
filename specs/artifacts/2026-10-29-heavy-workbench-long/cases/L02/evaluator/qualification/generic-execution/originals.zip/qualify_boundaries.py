from pathlib import Path
from decimal import Decimal
import json,shutil,sqlite3,subprocess,sys,io,zipfile,time
root=Path(__file__).parent
sys.path.insert(0,str(root/'source-boundaries'))
from l02_execution import ExecutionError,Executor,Ledger,run_lock,unzip_bytes,json_bytes,atomic_bytes,archived_json
from l02_scoring import aggregate_study_metrics,ProtocolError
from material_contract import parse_json
from run_l02_study import validate_submission
checks=[]
def expect(name,fn,code):
 try:fn()
 except (ExecutionError,ProtocolError) as e:
  assert e.code==code,(name,e.code,e)
  checks.append({'name':name,'error':e.code,'detail':str(e)})
 else:raise AssertionError(name)
high=Decimal('1.2345678901234567890123456789')
assert parse_json(json_bytes({'number':high}).decode(),decimal_numbers=True)['number']==high
checks.append({'name':'exact_decimal_packet_roundtrip','value':str(high)})
fields=('scaled_mse','scaled_mae','scaled_wis')
metric=lambda n:{f:str(n) for f in fields}
values={('one','selected'):metric(9),('one','other'):metric(1),('two','selected'):metric(7),('two','other'):metric(3)}
aggregate=aggregate_study_metrics(values,{'one':'other','two':'other'},['selected','other'])
assert aggregate['per_method']['selected']==metric(8) and aggregate['selected']==metric(2),aggregate
checks.append({'name':'unselected_method_named_selected_keeps_own_metric','result':aggregate})
expect('fixed_denominator_missing_cell',lambda:aggregate_study_metrics({('one','selected'):metric(1)},{'one':'other'},['selected','other']),'facility_aggregate_invalid')
expect('broken_zip',lambda:unzip_bytes(b'not a zip'),'facility_archive_invalid')
b=io.BytesIO()
with zipfile.ZipFile(b,'w') as z:z.writestr('../escape',b'1')
expect('zip_member_escape',lambda:unzip_bytes(b.getvalue()),'facility_archive_invalid')
bad=root/'invalid-path-submission';shutil.copytree(root/'node-submission',bad)
m=json.loads((bad/'submission.json').read_text());m['programs']['predict']['files']=['../node_program.mjs'];(bad/'submission.json').write_text(json.dumps(m))
expect('submitted_file_escape',lambda:validate_submission(bad),'submission_path_invalid')
corrupt=root/'corrupt-accepted-copy';shutil.copytree(root/'record-run',corrupt)
shutil.copyfile(corrupt/'cells/1/accepted.zip',root/'accepted-copy-before.zip');(corrupt/'cells/1/accepted.zip').write_bytes(b'bad archive')
with run_lock(corrupt):
 ledger=Ledger(corrupt)
 expect('accepted_corruption_keeps_facility_classification',lambda:Executor(ledger,'sha256:23ff8bfbf8055caa0b9fa5745ddb27cceea2f31d7d15b7a900c81112cdfe8ddf').invoke({'kind':'record'},{'files':[],'argv':['unused']},{},{},lambda _:{}),'facility_archive_invalid')
 ledger.close()
linked=root/'output-link-run';linked.mkdir()
start=time.perf_counter()
with run_lock(linked):
 ledger=Ledger(linked,create=True)
 executor=Executor(ledger,'sha256:23ff8bfbf8055caa0b9fa5745ddb27cceea2f31d7d15b7a900c81112cdfe8ddf')
 code=b"import os\nos.symlink('/input/instruction.txt','/output/link.txt')\n"
 expect('real_output_symlink',lambda:executor.invoke({'kind':'output-link'},{'files':['link.py'],'argv':['/opt/cpsat/bin/python','link.py']},{'link.py':code},{'instruction.txt':b'authorized packet'},lambda _:{}),'candidate_output_invalid')
 assert ledger.db.execute('select phase,exitcode from cell').fetchone()[:]==('failed',0)
 ledger.close()
checks.append({'name':'output_link_terminal_sealed_and_failed','wall_seconds':time.perf_counter()-start})
commands=[]
def cli(name,args,code,error):
 argv=[sys.executable,'-X','utf8','-B',str(root/'source-boundaries/run_l02_study.py'),*args]
 p=subprocess.run(argv,capture_output=True,text=True,encoding='utf-8');value=json.loads(p.stdout)
 receipt={'name':name,'argv':argv,'exitcode':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
 assert p.returncode==code and value['error']==error,receipt
 commands.append(receipt)
cli('resume_rebinding',['--resume',str(root/'python-loop'),'--image','arbitrary'],3,'resume_arguments_invalid')
old=root/'old-format';old.mkdir()
cli('old_directory_format',['--resume',str(old)],3,'run_format_invalid')
unknown=root/'unknown-version';unknown.mkdir()
with sqlite3.connect(unknown/'runs.sqlite3') as db:db.execute('pragma user_version=2')
cli('unknown_schema',['--resume',str(unknown)],3,'run_format_invalid')
# Recompute accepted historical execution objects with the final error boundary/helper.
for name in ['python','node']:
 argv=[sys.executable,'-X','utf8','-B',str(root/'source-boundaries/summarize_l02_study.py'),'--run',str(root/(name+'-loop')),'--out',str(root/(name+'-summary-final'))]
 p=subprocess.run(argv,capture_output=True,text=True,encoding='utf-8');receipt={'name':name+'-final-summary','argv':argv,'exitcode':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
 assert p.returncode==0,receipt
 expected=json.loads((root/(name+'-assessment.json')).read_text())['result']['aggregate_exact']
 assert json.loads(p.stdout)['aggregate_exact']==expected
 commands.append(receipt)
value={'status':'focused_boundaries_verified','checks':checks,'commands':commands,'scope':'actual sealed replay, one real symlink-output process and typed protocol inputs; no full forecast replay'}
(root/'boundary-assessment.json').write_text(json.dumps(value,indent=2,ensure_ascii=False))
print(json.dumps({'status':value['status'],'checks':len(checks),'commands':len(commands)}),flush=True)
