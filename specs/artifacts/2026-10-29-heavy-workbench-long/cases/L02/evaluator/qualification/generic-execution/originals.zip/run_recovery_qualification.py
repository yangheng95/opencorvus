import json,subprocess,sys,time,sqlite3
from pathlib import Path
root=Path(__file__).parent
receipts=[]
for stage in ['create_returned','start_returned','terminal_sealed','accepted_sealed','verified','complete']:
 argv=[sys.executable,'-X','utf8','-B',str(root/'record_probe.py'),stage]
 start=time.perf_counter();p=subprocess.run(argv,capture_output=True,text=True,encoding='utf-8')
 receipt={'stage':stage,'argv':argv,'exitcode':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'wall_seconds':time.perf_counter()-start}
 (root/('record-'+stage+'-command.json')).write_text(json.dumps(receipt,indent=2))
 receipts.append(receipt)
 if p.returncode!=(0 if stage=='complete' else 81):
  print(json.dumps(receipt),flush=True);raise SystemExit(1)
 print(stage,p.returncode,flush=True)
with sqlite3.connect(root/'record-run/runs.sqlite3') as db:
 cells=db.execute('select id,phase,cid from cell').fetchall()
 assert len(cells)==1 and cells[0][1]=='verified',cells
facts={'status':'same_container_recovery_verified','cells':cells,'stages':receipts,'scope':'Windows process-crash/OS lock and Docker lifecycle; no hardware power-loss or candidate hours qualification'}
(root/'record-assessment.json').write_text(json.dumps(facts,indent=2))
print(json.dumps({'status':facts['status'],'cells':cells}),flush=True)
