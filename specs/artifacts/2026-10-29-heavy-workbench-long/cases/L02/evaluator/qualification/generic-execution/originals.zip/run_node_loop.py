import json,subprocess,sys,time,shutil
from pathlib import Path
root=Path(__file__).parent;bundle=root/'node-submission';bundle.mkdir()
shutil.copyfile(root/'node_program.mjs',bundle/'program.mjs')
pool={'format':'l02-method-pool/1','methods':[
 {'method_id':'../../baseline / 零','role':'baseline','configuration':{'algorithm':'weekday','repeats':8}},
 {'method_id':'selected','role':'extension','configuration':{'algorithm':'weekday','repeats':4}},
 {'method_id':'ablation:mean','role':'ablation','configuration':{'algorithm':'constant'}}],
 'selection_ids':['../../baseline / 零','selected'],'outer_ids':['../../baseline / 零','selected','ablation:mean']}
manifest={'format':'l02-numerical-submission/1','pool':pool,'programs':{mode:{'files':['program.mjs'],'argv':['node','program.mjs',mode]} for mode in ['predict','select','report']}}
(bundle/'submission.json').write_text(json.dumps(manifest,ensure_ascii=False))
case=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L02')
argv=[sys.executable,'-X','utf8','-B',str(root/'source-loop/run_l02_study.py'),'--out',str(root/'node-loop'),'--submission',str(bundle),'--raw','D:/opencorvus-benchmark-runs/l02-daily-loop-qualification-20261030/main/raw','--material-contract',str(case/'evaluator/material-contract.json'),'--study',str(case/'evaluator/study-contract.draft.json'),'--image','sha256:43fb719000213f116c9e185f1022f3218e0e1155448ad74042a86fe84f6b51bb','--author-diagnostic-outer-id','outer-20250115']
t=time.perf_counter();p=subprocess.run(argv,capture_output=True,text=True,encoding='utf-8');receipt={'argv':argv,'exitcode':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'wall_seconds':time.perf_counter()-t}
(root/'node-loop-command.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=False));print(json.dumps(receipt,ensure_ascii=False),flush=True)
assert p.returncode==0,receipt
result=json.loads(p.stdout);assert len(result['aggregate_exact']['per_method'])==3 and 'selected' in result['aggregate_exact']['per_method'],result
argv=[sys.executable,'-X','utf8','-B',str(root/'source-loop/summarize_l02_study.py'),'--run',str(root/'node-loop'),'--out',str(root/'node-summary')]
t=time.perf_counter();p=subprocess.run(argv,capture_output=True,text=True,encoding='utf-8');receipt={'argv':argv,'exitcode':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'wall_seconds':time.perf_counter()-t}
(root/'node-summary-command.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=False));assert p.returncode==0,receipt
assert json.loads(p.stdout)['aggregate_exact']==result['aggregate_exact']
(root/'node-assessment.json').write_text(json.dumps({'status':'node_original_csv_programs_verified','result':result,'summary':json.loads(p.stdout),'scope':'generic ABI/private author diagnostic; not forecast quality or candidate hours'},indent=2,ensure_ascii=False))
print('Node original CSV/selector/report complete and summary recomputed',flush=True)
