import json,shutil,subprocess,sys,time,sqlite3,zipfile
from pathlib import Path
root=Path(__file__).parent
sys.path.insert(0,str(root/'source-loop'))
from package_l02_reference import package
case=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L02')
package(case/'evaluator/reference-pool.json',root/'loop-submission')
def execute(name,args):
 argv=[sys.executable,'-X','utf8','-B',str(root/'loop_child.py'),*args]
 start=time.perf_counter();p=subprocess.run(argv,capture_output=True,text=True,encoding='utf-8')
 receipt={'argv':argv,'exitcode':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'wall_seconds':time.perf_counter()-start}
 (root/(name+'-command.json')).write_text(json.dumps(receipt,indent=2));print(name,p.returncode,p.stdout[-300:],flush=True)
 return receipt
fresh=['checkpoint','--out',str(root/'python-loop'),'--submission',str(root/'loop-submission'),'--raw','D:/opencorvus-benchmark-runs/l02-daily-loop-qualification-20261030/main/raw','--material-contract',str(case/'evaluator/material-contract.json'),'--study',str(case/'evaluator/study-contract.draft.json'),'--image','sha256:23ff8bfbf8055caa0b9fa5745ddb27cceea2f31d7d15b7a900c81112cdfe8ddf','--author-diagnostic-outer-id','outer-20250115']
first=execute('python-first',fresh)
assert first['exitcode']==82,first
checkpoint=json.loads((root/'python-checkpoint.json').read_text())
working=root/'python-loop/cells'/str(checkpoint['id'])/'work/output/result/forecast.json'
shutil.copyfile(working,root/'working-forecast-before.json')
working.write_text('{}')
manifest=root/'loop-submission/submission.json'
shutil.copyfile(manifest,root/'submission-before-external-edit.json')
changed=json.loads(manifest.read_text());changed['pool']['methods'][0]['configuration']['weekday_repeats']=1
manifest.write_text(json.dumps(changed))
last=execute('python-resume',['complete','--resume',str(root/'python-loop')])
assert last['exitcode']==0,last
result=json.loads(last['stdout']);assert result['verified_cells']==11 and result['complete_assignment'] is False,result
argv=[sys.executable,'-X','utf8','-B',str(root/'source-loop/summarize_l02_study.py'),'--run',str(root/'python-loop'),'--out',str(root/'python-summary')]
start=time.perf_counter();p=subprocess.run(argv,capture_output=True,text=True,encoding='utf-8');receipt={'argv':argv,'exitcode':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'wall_seconds':time.perf_counter()-start}
(root/'python-summary-command.json').write_text(json.dumps(receipt,indent=2));assert p.returncode==0,receipt
summary=json.loads(p.stdout);assert summary['aggregate_exact']==result['aggregate_exact'],summary
(root/'python-assessment.json').write_text(json.dumps({'status':'one_outer_generic_execution_verified','checkpoint':checkpoint,'result':result,'summary':summary,'scope':'private author diagnostic; no candidate quality/freeze/hours'},indent=2))
print('python generic complete and sealed summary recomputed',flush=True)
