# Sealed numerical study

This is an author protocol reference. Scientific review and quality thresholds remain unassessed.

Complete registered assignment: False

| Method | Scaled MSE | Scaled WIS |
|---|---:|---:|
| seasonal-weekday | 0.006425043932 | 0.05450524711 |
| ridge-weather-operations | 0.0008236596246 | 0.01242996233 |
| ridge-no-weather | 0.0004747445529 | 0.009169193241 |
| Chosen by inner selection | 0.0008236596246 | 0.01242996233 |

Choices use earlier inner folds only. No-weather is a mandatory ablation, not a retrospective addition to the selection pool.
Intervals are marginal; this execution does not establish nominal coverage or calibrated joint paths.

![Actual forecasts and terminal observations](forecast.png)
