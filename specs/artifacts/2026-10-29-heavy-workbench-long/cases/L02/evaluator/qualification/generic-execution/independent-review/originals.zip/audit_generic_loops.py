"""Independent original CSV/SQL/Fraction/SQLite joins for two completed diagnostic submissions."""
import ast,csv,io,json,runpy,shutil,sqlite3,time,zipfile
from pathlib import Path,PurePosixPath
from fractions import Fraction as F
ROOT=Path(__file__).resolve().parent
Q=Path('D:/opencorvus-benchmark-runs/l02-generic-execution-qualification-20261030')
MAIN=Path('D:/opencorvus-benchmark-runs/l02-daily-loop-qualification-20261030/main')
OUT=ROOT/'implementation-loops';OUT.mkdir(exist_ok=False)
shutil.copytree(Q/'source-boundaries',OUT/'source-boundaries-initial')
shutil.copytree(Q/'source-loop',OUT/'source-loop-executed')
for n in ['boundary-assessment.json','qualify_boundaries.py','python-assessment.json','node-assessment.json','python-first-command.json','python-resume-command.json','node-loop-command.json','python-checkpoint.json','submission-before-external-edit.json','working-forecast-before.json']:
 shutil.copy2(Q/n,OUT/n)
ns=runpy.run_path('D:/opencorvus-benchmark-runs/l02-daily-loop-independent-review-20261030/audit_completed_loop.py',run_name='reviewer_arithmetic')
load=ns['load'];save=ns['save'];score=ns['score_independent'];tick=ns['tick'];table=ns['table']
def archive(p):
 with zipfile.ZipFile(p)as z:
  assert len(z.namelist())==len(set(z.namelist()));return {n:z.read(n)for n in z.namelist()}
def js(files,name):return json.loads(files[name],parse_float=ns['Decimal'])
started=time.perf_counter();checks=[]
def ck(n,ok,detail=None):checks.append({'name':n,'passed':bool(ok),'detail':detail})
raw,rawrows,catalogue=ns['read_independently'](MAIN/'raw');hierarchy=table(MAIN/'raw/hierarchy.csv');grid={r['origin_id']:r for r in table(MAIN/'raw/origins.csv')};leaves={n['series_id']for n in catalogue if n['kind']=='leaf'}
terminal={(r['series_id'],r['event_tick']):r for r in raw['observations']if r['revision_id']==2}
hist=[r for r in raw['observations']if r['revision_id']==2 and tick('2023-01-02T00:00:00Z')<=r['event_tick']<=tick('2024-01-01T00:00:00Z')]
scales={s:max(F(1),sum(F(r['value'])for r in hist if r['series_id']==s)/365)for s in leaves}
for n in catalogue:
 if n['kind']=='aggregate':scales[n['series_id']]=max(F(1),sum(int(e['weight'])*scales[e['child']]for e in hierarchy if e['parent']==n['series_id']))
sql=sqlite3.connect(':memory:');sql.execute('create table facts(kind,idx,id,t,rev,released,future)')
for kind,idkey,tkey in [('observations','series_id','event_tick'),('covariates','variable_id','valid_tick')]:sql.executemany('insert into facts values(?,?,?,?,?,?,?)',[(kind,i,r[idkey],r[tkey],r['revision_id'],r['release_tick'],int(kind=='covariates'and raw['variables'][r[idkey]]['availability']=='known_future'))for i,r in enumerate(raw[kind])])
original={kind:{(r[idkey],tick(r[end]),int(r['revision_id'])):r for r in rawrows[kind]}for kind,idkey,end in [('observations','series_id','event_end_utc'),('covariates','variable_id','valid_end_utc')]}
results={};processes=[]
for language in ['python','node']:
 run=Q/(language+'-loop');regzip=archive(run/'registration.zip');reg=js(regzip,'registration.json');manifest=js(regzip,'submission/submission.json');pool=manifest['pool'];methods={m['method_id']:m for m in pool['methods']}
 dest=OUT/(language+'-originals');shutil.copytree(run,dest)
 ck(language+'_raw_registration_exact_source',all(regzip['raw/'+p.name]==p.read_bytes()for p in(MAIN/'raw').iterdir()if p.is_file()))
 ck(language+'_explicit_private_author_diagnostic',reg['assignment_kind']=='private_author_diagnostic'and reg['outer_ids']==['outer-20250115']and len(reg['all_outer_ids'])==12)
 db=sqlite3.connect((run/'runs.sqlite3').as_uri()+'?mode=ro',uri=True);db.row_factory=sqlite3.Row
 rows=[dict(r)for r in db.execute('select*from cell order by id')];events=[dict(r)for r in db.execute('select*from event order by id')];runid=db.execute('select id from run').fetchone()[0];db.close()
 ck(language+'_11verified_unique_cells',len(rows)==11 and all(r['phase']=='verified'and r['exitcode']==0 for r in rows)and len({r['cid']for r in rows})==11)
 objects={};facts={}
 for cell in rows:
  ident=json.loads(cell['identity']);job=run/'cells'/str(cell['id']);accepted=archive(job/'accepted.zip');terminalzip=archive(job/'terminal.zip');prepared=archive(job/'prepared.zip');native=js(accepted,'terminal-inspect.json');cid=cell['cid'];kind=ident['kind'];program=manifest['programs'][kind]
  prefix=language+'_'+str(cell['id'])+'_'+kind
  ck(prefix+'_opaque_host_path',job.name==str(cell['id'])and native['Name']=='/'+cell['name']and native['Config']['Labels']['oc.l02.run']==runid and native['Config']['Labels']['oc.l02.cell']==str(cell['id']))
  ck(prefix+'_source_program_sealed_registration',js(accepted,'program.json')==program and {n[8:]:v for n,v in accepted.items()if n.startswith('project/')}=={n:regzip['submission/'+n]for n in program['files']})
  ck(prefix+'_prepared_terminal_accepted_exact_join',all(terminalzip[n]==v for n,v in prepared.items())and set(accepted)==set(terminalzip)|{'assessment.json'}and all(accepted[n]==v for n,v in terminalzip.items()))
  ck(prefix+'_actual_native_bound_argv_resources',native['Id']==cid and native['State']['Status']=='exited'and native['State']['ExitCode']==0 and native['Path']==program['argv'][0]and native['Args']==program['argv'][1:]and native['Image']==reg['image_id']and native['HostConfig']['ReadonlyRootfs']and not native['HostConfig']['Privileged']and native['HostConfig']['NanoCpus']==10**9 and native['HostConfig']['NetworkMode']=='none'and set(native['HostConfig']['Tmpfs'])=={'/tmp'}and native['RestartCount']==0 and native['HostConfig']['RestartPolicy']['Name']=='no')
  mounts={m['Destination']:m for m in native['Mounts']};ck(prefix+'_only_scoped_mounts',set(mounts)=={'/project','/input','/output'}and all(m['RW']==(key=='/output')and Path(m['Source']).resolve()==(job/'work'/key[1:]).resolve()for key,m in mounts.items()))
  commands=[load(p)for p in job.glob('*.json')];creates=[r for r in commands if r['argv'][1:2]==['create']];starts=[r for r in commands if r['argv'][1:2]==['start']];removes=[r for r in commands if r['argv'][1:2]==['rm']]
  ck(prefix+'_one_real_create_start_remove',len(creates)==len(starts)==len(removes)==1 and creates[0]['stdout'].strip()==cid and starts[0]['argv']==['docker','start',cid]and removes[0]['argv']==['docker','rm',cid]and all(r['exitcode']==0 for r in creates+starts+removes))
  ve=[e for e in events if e['cell_id']==cell['id']and e['kind']=='lifecycle'and json.loads(e['facts']).get('phase')=='verified'];ce=[e for e in events if e['cell_id']==cell['id']and e['kind']=='cleanup_confirmed'];ck(prefix+'_committed_verified_then_cleanup',len(ve)==1 and ce and all(e['id']>ve[0]['id']for e in ce))
  processes.append({'language':language,'cell':cell['id'],'kind':kind,'cid':cid,'started':native['State']['StartedAt'],'finished':native['State']['FinishedAt'],'argv':program['argv']})
  inputnames={n[6:]for n in accepted if n.startswith('input/')}
  expected={'predict':{'method.json','packet/packet.json','packet/observations.csv','packet/covariate-vintages.csv'},'select':{'inner.json','study.json'},'report':{'results.json'}}[kind]
  ck(prefix+'_exact_role_input_namespace',inputnames==expected)
  objects[cell['id']]=(ident,accepted)
  if kind!='predict':continue
  origin=ident['origin_id'];o=tick(grid[origin]['cutoff_utc']);targets=[(o//24+2)*24+24*i for i in range(14)];method=ident['method_id'];meta=js(accepted,'input/packet/packet.json')
  ck(prefix+'_assigned_registered_grid_config',meta['origin_tick']==o and meta['target_ticks']==targets and js(accepted,'input/method.json')=={k:methods[method][k]for k in ['method_id','configuration']})
  for k,idkey,tkey,end,file in [('observations','series_id','event_tick','event_end_utc','observations.csv'),('covariates','variable_id','valid_tick','valid_end_utc','covariate-vintages.csv')]:
   got=list(csv.DictReader(io.StringIO(accepted['input/packet/'+file].decode('utf-8'))));gkeys=[(r[idkey],tick(r[end]),int(r['revision_id']))for r in got]
   wanted=[raw[k][r[0]]for r in sql.execute('select idx from facts where kind=?and released<=?and(future=1 or t<?)',(k,o,o))];wkeys={(r[idkey],r[tkey],r['revision_id'])for r in wanted}
   ck(prefix+'_independent_SQL_raw_'+k,len(gkeys)==len(set(gkeys))and set(gkeys)==wkeys and all(r==original[k][key]for r,key in zip(got,gkeys)))
  truth={(s,t):terminal[s,t]['value']for s in leaves for t in targets}
  for n in catalogue:
   if n['kind']=='aggregate':
    for t in targets:truth[n['series_id'],t]=sum(int(e['weight'])*truth[e['child'],t]for e in hierarchy if e['parent']==n['series_id'])
  fc=js(accepted,'output/result/forecast.json');macro,node,by=score(fc,truth,o,targets,catalogue,hierarchy,scales);claimed=js(accepted,'assessment.json')['metric']
  ck(prefix+'_84node_and_macro_metrics_exact',len(fc['forecasts'])==84 and all(F(claimed['metrics_exact'][m])==v for m,v in macro.items())and all(F(claimed['node_metrics_exact'][s][m])==v for s,row in node.items()for m,v in row.items()))
  facts[origin,method]={'forecast':fc,'macro':macro,'node':node,'truth':truth,'targets':targets,'released':max(terminal[s,t]['release_tick']for s in leaves for t in targets)}
 selector=next(files for ident,files in objects.values()if ident['kind']=='select');payload=js(selector,'input/inner.json');selected=js(selector,'output/result/selection.json');outer=reg['outer_ids'][0];o=tick(grid[outer]['cutoff_utc']);inner={r['origin_id']for r in grid.values()if r['role']=='inner'and r['outer_id']==outer};losses={m:[]for m in pool['selection_ids']}
 ck(language+'_complete3_inner_selector_assignment',set(payload['inner_ids'])==inner and len(payload['frames'])==3 and payload['outer_origin_tick']==o and payload['selection_ids']==pool['selection_ids'])
 for frame in payload['frames']:
  g=frame['origin_id'];reference=facts[g,pool['selection_ids'][0]];c=frame['context'];labels={(r['series_id'],r['target_tick']):r['value']for r in frame['labels']}
  ck(language+'_selector_truth_permission_'+g,labels==reference['truth']and frame['labels_released_at']==reference['released']<=o and c['origin_tick']==tick(grid[g]['cutoff_utc'])and c['target_ticks']==reference['targets']and all(F(c['scales_litres'][s])==v for s,v in scales.items()))
  for method in pool['selection_ids']:
   ck(language+'_actual_inner_forecast_binding_'+g+'_'+method,frame['forecasts'][method]==facts[g,method]['forecast']);losses[method].append(facts[g,method]['macro']['scaled_mse'])
 means={m:sum(v)/3 for m,v in losses.items()};best=min(means,key=lambda m:(means[m],m));ck(language+'_independent_selector_min_ID',selected['selected_method_id']==best and all(F(selected['method_mean_inner_scaled_mse'][m])==v for m,v in means.items()))
 expectedcells={(g,m)for g in inner for m in pool['selection_ids']}|{(outer,m)for m in pool['outer_ids']};ck(language+'_all9_forecasts_required',set(facts)==expectedcells)
 aggregate={'per_method':{m:{k:str(v)for k,v in facts[outer,m]['macro'].items()}for m in pool['outer_ids']},'selected':{k:str(v)for k,v in facts[outer,best]['macro'].items()}}
 summary=load(Q/(language+'-summary-final')/'assessment.json');ck(language+'_summary_independent_all_metrics_and_alias',summary['aggregate_exact']==aggregate and summary['forecast_cells']==9 and summary['verified_cells']==11 and not summary['complete_assignment']and summary['candidate_score']is None)
 report=next(files for ident,files in objects.values()if ident['kind']=='report');ri=js(report,'input/results.json');rr=js(report,'output/result/report.json');ck(language+'_report_after_complete_numerical_input',ri['aggregate_exact']==aggregate and ri['outer_ids']==[outer]and ri['complete_assignment']is False and rr['format']=='l02-report-receipt/1'and rr['outer_ids']==[outer]and bool(report['output/result/report.md'].decode('utf-8').strip()))
 for row in ri['outer_results']:
  ck(language+'_report_outer_truth_forecasts_exact',row['selected_method_id']==best and {(r['series_id'],r['target_tick']):r['value']for r in row['labels']}==facts[outer,best]['truth']and all(row['forecasts'][m]==facts[outer,m]['forecast']for m in pool['outer_ids']))
 results[language]={'selected_method':best,'inner_losses_exact':{m:str(v)for m,v in means.items()},'aggregate_exact':aggregate,'cells':len(rows),'forecast_cells':len(facts),'accepted_source_used':'source-loop','last_current_summary_used':'source-boundaries'}
 if language=='python':
  ck('python_original_submission_external_edit_ignored',regzip['submission/submission.json']==(Q/'submission-before-external-edit.json').read_bytes()and regzip['submission/submission.json']!=(Q/'loop-submission/submission.json').read_bytes())
  ck('python_working_forecast_edit_not_accepted',archive(run/'cells/1/accepted.zip')['output/result/forecast.json']==(Q/'working-forecast-before.json').read_bytes()and (run/'cells/1/work/output/result/forecast.json').read_bytes()!=(Q/'working-forecast-before.json').read_bytes())
  ck('python_actual_first_verified_crash82_and_resume0',load(Q/'python-first-command.json')['exitcode']==82 and load(Q/'python-resume-command.json')['exitcode']==0)
 else:ck('node_arbitrary_ID_preserved_as_opaque_identity','../../baseline / 零'in methods and 'selected'in methods and 'ablation:mean'in methods)
for language in ['python','node']:
 ordered=sorted([r for r in processes if r['language']==language],key=lambda r:r['started']);ck(language+'_11sequential_actual_processes',len(ordered)==11 and all(b['started']>=a['finished']for a,b in zip(ordered,ordered[1:])))

# Current exact-source typed archive reader probes: ordinary bad ZIP and DEFLATE corruption.
source=(OUT/'source-boundaries-initial/l02_execution.py').read_text();pieces=[n for n in ast.parse(source).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))and n.name in {'ExecutionError','safe_relative','unzip_bytes'}];helpers={'io':io,'zipfile':zipfile,'PurePosixPath':PurePosixPath};exec(compile(ast.Module(body=pieces,type_ignores=[]),'source-boundaries_archive_reader','exec'),helpers)
buf=io.BytesIO()
with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED)as z:z.writestr('x.txt',b'a'*100)
damaged=bytearray(buf.getvalue());damaged[35]=255
(OUT/'corrupt-deflate.zip').write_bytes(damaged);archiveprobes=[]
for name,value in [('bad_zip',b'not a zip file'),('corrupt_deflate',damaged)]:
 try:helpers['unzip_bytes'](value)
 except Exception as e:archiveprobes.append({'name':name,'type':type(e).__module__+'.'+type(e).__name__,'code':getattr(e,'code',None),'detail':str(e),'kind':'pure exact-source helper, not an executed full CLI'})
save(OUT/'archive-helper-probes.json',archiveprobes)
save(OUT/'checks.json',checks);save(OUT/'results-exact.json',results);save(OUT/'all22-processes.json',processes)
result={'checks':len(checks),'all_passed':all(r['passed']for r in checks),'failed':[r['name']for r in checks if not r['passed']],'seconds':time.perf_counter()-started,'actual_new_author_processes_read':22,'independent_Fraction_forecasts':18,'rows_each':84,'new_Docker_forecast_Provider_solver_calls_by_reviewer':0,'new_archive_issue':archiveprobes[-1],'scientific_or_full_L02_grade':None,'full12generic_matrix_executed':False}
save(OUT/'assessment.json',result);print(json.dumps(result,ensure_ascii=False))
