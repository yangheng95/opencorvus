import os
from pathlib import Path
Path('/output/result.txt').write_text('valid result')
os.write(1,b'\xff\xfe\n')
