import sys,json,traceback
from pathlib import Path
root=Path(__file__).parent
sys.path.insert(0,str(root/sys.argv[1]))
from l02_execution import Ledger,Executor,run_lock
run=root/'binary-log-run';run.mkdir(exist_ok=True)
with run_lock(run):
 ledger=Ledger(run,create=not (run/'runs.sqlite3').is_file())
 program={'files':['binary.py'],'argv':['/opt/cpsat/bin/python','binary.py']}
 source={'binary.py':b"import os\nfrom pathlib import Path\nPath('/output/result.txt').write_text('valid result')\nos.write(1,b'\\xff\\xfe\\n')\n"}
 def validate(files):
  assert files['output/result.txt']==b'valid result'
  return {'status':'binary_diagnostic_valid_result'}
 try:
  accepted=Executor(ledger,'sha256:23ff8bfbf8055caa0b9fa5745ddb27cceea2f31d7d15b7a900c81112cdfe8ddf').invoke({'kind':'binary-diagnostic'},program,source,{'instruction.txt':b'valid computation'},validate)
  assert accepted['stdout.txt']==b'\xff\xfe\n'
  print(json.dumps({'status':'same_container_binary_logs_accepted','stdout_bytes':list(accepted['stdout.txt'])}),flush=True)
 except Exception as e:
  print(json.dumps({'status':'observed_failure','type':type(e).__name__,'detail':str(e),'traceback':traceback.format_exc()}),flush=True)
  raise SystemExit(1)
 finally:ledger.close()
