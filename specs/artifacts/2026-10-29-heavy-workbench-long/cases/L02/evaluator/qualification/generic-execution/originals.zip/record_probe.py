import json,os,sys,subprocess
from pathlib import Path
root=Path(__file__).parent
sys.path.insert(0,str(root/'source-current'))
from l02_execution import Ledger,Executor,run_lock,atomic_bytes,json_bytes,archived_json
run=root/'record-run'
run.mkdir(exist_ok=True)
stage=sys.argv[1]
with run_lock(run):
 ledger=Ledger(run,create=not (run/'runs.sqlite3').is_file())
 def observer(kind,cell):
  if kind!=stage:return
  record={'stage':kind,'cell':cell}
  if kind=='create_returned':
   argv=[sys.executable,'-X','utf8','-B',str(root/'source-current/run_l02_study.py'),'--resume',str(run)]
   p=subprocess.run(argv,capture_output=True,text=True,encoding='utf-8')
   record['concurrent_owner']={'argv':argv,'exitcode':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
   assert p.returncode==3 and json.loads(p.stdout)['error']=='run_busy',record
  atomic_bytes(root/('checkpoint-'+stage+'.json'),json_bytes(record))
  os._exit(81)
 code=b"from pathlib import Path\np=Path('/output/count.txt')\nv=int(p.read_text())+1 if p.exists() else 1\np.write_text(str(v))\nprint(v,flush=True)\n"
 executor=Executor(ledger,'sha256:23ff8bfbf8055caa0b9fa5745ddb27cceea2f31d7d15b7a900c81112cdfe8ddf',observer)
 def validate(files):
  assert files['output/count.txt']==b'1',files['output/count.txt']
  return {'status':'record_once_verified','count':1}
 result=executor.invoke({'kind':'record'}, {'files':['record.py'],'argv':['/opt/cpsat/bin/python','record.py']}, {'record.py':code},{'instruction.txt':b'one actual execution'},validate)
 print(json.dumps({'status':'record_verified','count':result['output/count.txt'].decode(),'native':archived_json(result,'terminal-inspect.json')['State']}),flush=True)
 ledger.close()
