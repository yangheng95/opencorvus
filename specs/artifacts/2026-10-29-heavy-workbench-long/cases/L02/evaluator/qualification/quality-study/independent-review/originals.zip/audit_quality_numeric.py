"""Independent CSV/Fraction quality reconstruction; never forecasts or runs Docker."""
import copy,csv,io,json,runpy,shutil,sys,time,zipfile
from pathlib import Path
from fractions import Fraction as F
ROOT=Path(__file__).resolve().parent
Q=Path('D:/opencorvus-benchmark-runs/l02-quality-study-qualification-20261030')
OLD=Path('D:/opencorvus-benchmark-runs/l02-daily-loop-qualification-20261030/main')
OUT=ROOT/'numeric-audit';OUT.mkdir(exist_ok=False)
shutil.copytree(Q/'source-quality',OUT/'source-quality')
for n in ['policy-before-results.json','registered-reference-originals.zip','qualify_real_quality.py','real-quality-command.json','real-quality-assessment.json','selected-reference.json','baseline-self-control.json','zero-control.json','wide-interval-control.json','coherent-one-leaf-mean-degradation.json','study-contract.draft.json','material-contract.json','reference-pool.json']:shutil.copy2(Q/n,OUT/n)
ns=runpy.run_path('D:/opencorvus-benchmark-runs/l02-daily-loop-independent-review-20261030/audit_completed_loop.py',run_name='reviewer_independent_math')
load=ns['load'];save=ns['save'];score=ns['score_independent'];table=ns['table'];tick=ns['tick'];started=time.perf_counter();checks=[]
def ck(n,v,detail=None):checks.append({'name':n,'passed':bool(v),'detail':detail})
def archive(p):
 with zipfile.ZipFile(p)as z:
  assert len(z.namelist())==len(set(z.namelist()));return {n:z.read(n)for n in z.namelist()}
refzip=archive(Q/'registered-reference-originals.zip')
def js(blob):return json.loads(blob,parse_float=ns['Decimal'])
policy=js(refzip['policy-before-results.json']);ck('policy_exact_before_and_after_known_review',refzip['policy-before-results.json']==(ROOT/'policy-before-results.json').read_bytes()==(Q/'policy-before-results.json').read_bytes())
raw,rawrows,catalogue=ns['read_independently'](OLD/'raw');rawcanonical=js(refzip['facts/canonical.json']);grid=js(refzip['facts/grid.json']);scales={k:F(v)for k,v in js(refzip['facts/scales.json']).items()};hierarchy=[{**r,'weight':int(r['weight'])}for r in table(OLD/'raw/hierarchy.csv')];originrows=table(OLD/'raw/origins.csv');originmap={r['origin_id']:r for r in originrows};outerids=[r['origin_id']for r in grid['origins']if r['role']=='outer'];leaves={n['series_id']for n in catalogue if n['kind']=='leaf'}
ck('canonical_all_original_observation_covariate_facts',rawcanonical['observations']==raw['observations']and rawcanonical['covariates']==raw['covariates']and rawcanonical['variables']==raw['variables'])
ck('exact12_registered_outer_IDs',len(outerids)==12 and len(set(outerids))==12 and set(outerids)=={r['origin_id']for r in originrows if r['role']=='outer'})
terminal={(r['series_id'],r['event_tick']):r for r in raw['observations']if r['revision_id']==2};hist=[r for r in raw['observations']if r['revision_id']==2 and tick('2023-01-02T00:00:00Z')<=r['event_tick']<=tick('2024-01-01T00:00:00Z')]
ourscales={s:max(F(1),sum(F(r['value'])for r in hist if r['series_id']==s)/365)for s in leaves}
for n in catalogue:
 if n['kind']=='aggregate':ourscales[n['series_id']]=max(F(1),sum(e['weight']*ourscales[e['child']]for e in hierarchy if e['parent']==n['series_id']))
ck('scale_from1460_published_original_values',len(hist)==1460 and all(r['release_tick']<=tick('2024-02-01T09:00:00Z')for r in hist)and scales==ourscales)
pool=load(Q/'reference-pool.json');methods={m['method_id']:m for m in pool['methods']};fixedmethod=js(refzip['fixed-reference-method.json']);ck('original_pre_results_fixed_baseline_config',fixedmethod==methods['seasonal-weekday']and pool==load(OLD/'remaining-ten/registration.json')['pool'])
cases={};reference={};contexts={};labels={};truths={};source_seen=[];bindings=js(refzip['original-bindings.json'])
ck('binding24_complete_role_origins',len(bindings)==24 and {(r['origin'],r['role'])for r in bindings}=={(o,r)for o in outerids for r in ['candidate','reference']})
allselectors=[]
for origin in outerids:
 if origin=='outer-20250115':run=OLD/'representative'
 elif origin=='outer-20250620':run=Path('D:/opencorvus-benchmark-runs/l02-daily-loop-independent-review-20261030/cold-june20/run')
 else:run=OLD/'remaining-ten'
 root=run/'outer'/origin;selectionzip=archive(root/'selector/completed-originals.zip');payload=js(selectionzip['input/inner.json']);chosen=js(selectionzip['output/result/selection.json']);o=tick(originmap[origin]['cutoff_utc']);targets=[(o//24+2)*24+24*i for i in range(14)]
 ck(origin+'_selected_original_archive_identity',refzip['selections/'+origin+'.json']==selectionzip['output/result/selection.json']and chosen['selected_method_id']in pool['selection_ids'])
 innerloss={m:[]for m in pool['selection_ids']};innerids={r['origin_id']for r in originrows if r['role']=='inner'and r['outer_id']==origin}
 ck(origin+'_selector3registered_inner_grid',len(payload['frames'])==3 and set(payload['inner_ids'])==innerids and payload['outer_origin_tick']==o)
 for frame in payload['frames']:
  gid=frame['origin_id'];p=tick(originmap[gid]['cutoff_utc']);tt=[(p//24+2)*24+24*i for i in range(14)];tr={(s,t):terminal[s,t]['value']for s in leaves for t in tt}
  for n in catalogue:
   if n['kind']=='aggregate':
    for t in tt:tr[n['series_id'],t]=sum(e['weight']*tr[e['child'],t]for e in hierarchy if e['parent']==n['series_id'])
  ck(origin+'_'+gid+'_inner_truth_release_bound',{(r['series_id'],r['target_tick']):r['value']for r in frame['labels']}==tr and frame['labels_released_at']==max(terminal[s,t]['release_tick']for s in leaves for t in tt)<=o)
  for m in pool['selection_ids']:
   iz=archive(root/'inner'/gid/m/'completed-originals.zip');fc=js(iz['output/result/forecast.json']);ck(origin+'_'+gid+'_'+m+'_actual_forecast_not_selfreport',frame['forecasts'][m]==fc);innerloss[m].append(score(fc,tr,p,tt,catalogue,hierarchy,scales)[0]['scaled_mse'])
 mean={m:sum(v)/3 for m,v in innerloss.items()};best=min(mean,key=lambda m:(mean[m],m));ck(origin+'_independent_Fraction_inner_min_ID',chosen['selected_method_id']==best and all(F(chosen['method_mean_inner_scaled_mse'][m])==v for m,v in mean.items()));allselectors.append({'origin':origin,'selected':best,'inner_loss_exact':{m:str(v)for m,v in mean.items()}})
 tr={(s,t):terminal[s,t]['value']for s in leaves for t in targets}
 for n in catalogue:
  if n['kind']=='aggregate':
   for t in targets:tr[n['series_id'],t]=sum(e['weight']*tr[e['child'],t]for e in hierarchy if e['parent']==n['series_id'])
 truths[origin]=tr;contexts[origin]={'format':'l02-score-context/1','origin_tick':o,'target_ticks':targets,'series_catalogue':catalogue,'hierarchy':hierarchy,'scales_litres':{k:str(v)for k,v in scales.items()}};labels[origin]=[{'series_id':s,'target_tick':t,'value':v}for(s,t),v in tr.items()]
 for role,m in [('reference','seasonal-weekday'),('candidate',best)]:
  original=root/'outer'/m/'completed-originals.zip';z=archive(original);native=js(z['terminal-inspect.json']);method=js(z['input/method.json']);forecast=js(z['output/result/forecast.json']);record=next(r for r in bindings if r['role']==role and r['origin']==origin)
  ck(origin+'_'+role+'_actual_original_binding',Path(record['original'])==original and record['method']==m and all(refzip[role+'/'+origin+'/'+name]==z[member]for name,member in [('forecast.json','output/result/forecast.json'),('method.json','input/method.json'),('terminal-inspect.json','terminal-inspect.json')])and method=={k:methods[m][k]for k in ['method_id','configuration']})
  ck(origin+'_'+role+'_native_terminal_84true_grid',native['State']['ExitCode']==0 and native['State']['Status']=='exited'and forecast['origin_tick']==o and len(forecast['forecasts'])==84 and forecast['method_id']==m)
  if role=='reference':source_seen.append({n[16:]:v for n,v in z.items()if n.startswith('executed-source/')})
  (reference if role=='reference'else cases)[origin]={'method_id':m,'forecast':forecast}
fixedsource={n[len('executed-fixed-reference-source/'):]:v for n,v in refzip.items()if n.startswith('executed-fixed-reference-source/')};ck('all12_original_reference_sources_exact',all(s==fixedsource for s in source_seen)and len(fixedsource)==5)

matrices={'selected-reference':cases,'baseline-self-control':reference,'zero-control':copy.deepcopy(cases),'wide-interval-control':copy.deepcopy(cases),'coherent-one-leaf-mean-degradation':copy.deepcopy(cases)}
for item in matrices['zero-control'].values():
 for row in item['forecast']['forecasts']:row['mean']=0;row['quantiles']={q:0 for q in row['quantiles']}
for item in matrices['wide-interval-control'].values():
 for row in item['forecast']['forecasts']:row['quantiles']={q:0 if F(q)<F(1,2)else 1000000 if F(q)>F(1,2)else v for q,v in row['quantiles'].items()}
for item in matrices['coherent-one-leaf-mean-degradation'].values():
 for row in item['forecast']['forecasts']:
  if row['series_id']in ['A1','ZA']:row['mean']=F(row['mean'])+100000
def own_decisions(fc,context,tr):
 rows={(r['series_id'],r['target_tick']):r for r in fc['forecasts']};nodes={};actions=[]
 for s in sorted(leaves):
  nodes[s]={}
  for under,q in [(1,'0.5'),(3,'0.75'),(9,'0.9')]:
   fields={k:F()for k in ['shortage_litres','surplus_litres','shortage_loss','surplus_loss','loss','mean_action_loss']}
   for t in context['target_ticks']:
    row=rows[s,t];a=F(row['quantiles'][q]);y=F(tr[s,t]);short=max(y-a,F());over=max(a-y,F());v={'shortage_litres':short,'surplus_litres':over,'shortage_loss':under*short,'surplus_loss':over,'loss':under*short+over};mu=F(row['mean']);vmean=under*max(y-mu,F())+max(mu-y,F())
    for k,x in v.items():fields[k]+=x
    fields['mean_action_loss']+=vmean
    actions.append({'series_id':s,'target_tick':t,'underage_cost':under,'overage_cost':1,'quantile':q,'action_litres':str(a),**{k:str(x)for k,x in v.items()}})
   nodes[s][str(under)]={k:str(x/14)for k,x in fields.items()}
 return {'node_mean':nodes,'actions':actions}
ownresults={};refcache={}
for origin in outerids:
 c=contexts[origin];refcache[origin]={'score':score(reference[origin]['forecast'],truths[origin],c['origin_tick'],c['target_ticks'],catalogue,hierarchy,scales),'decision':own_decisions(reference[origin]['forecast'],c,truths[origin])}
for name,matrix in matrices.items():
 published=load(Q/(name+'.json'));scored={};decisions={}
 for origin in outerids:
  c=contexts[origin];scored[origin,'candidate']=score(matrix[origin]['forecast'],truths[origin],c['origin_tick'],c['target_ticks'],catalogue,hierarchy,scales);scored[origin,'reference']=refcache[origin]['score'];decisions[origin,'candidate']=own_decisions(matrix[origin]['forecast'],c,truths[origin]);decisions[origin,'reference']=refcache[origin]['decision']
  for role in ['candidate','reference']:
   recorded=published['per_origin_decisions'][origin][role];ours=decisions[origin,role]
   sortkey=lambda r:(r['series_id'],r['target_tick'],r['underage_cost'])
   ck(name+'_'+origin+'_'+role+'_all168actions_and_loss_decomposition',recorded['node_mean']==ours['node_mean']and sorted(recorded['actions'],key=sortkey)==sorted(ours['actions'],key=sortkey))
 macro={role:{metric:sum(scored[o,role][0][metric]for o in outerids)/12 for metric in ['scaled_mse','scaled_mae','scaled_wis']}for role in ['candidate','reference']}
 ours={};nodevals={};costvals={}
 def add(key,c,b,strict=False):ours[key]={'id':key,'critical':True,'candidate_loss':str(c),'reference_loss':str(b),'comparison':'<'if strict else'<=','passed':c<b if strict else c<=b}
 for metric in ['scaled_mse','scaled_wis']:add('macro.'+metric,macro['candidate'][metric],macro['reference'][metric],True)
 for node in catalogue:
  s=node['series_id'];nodevals[s]={}
  for metric in ['scaled_mse','scaled_wis']:
   v={r:sum(scored[o,r][1][s][metric]for o in outerids)/12 for r in ['candidate','reference']};nodevals[s][metric]={r:str(x)for r,x in v.items()};add('node.'+s+'.'+metric,v['candidate'],v['reference'])
  if node['kind']=='leaf':
   costvals[s]={}
   for cost in ['1','3','9']:
    v={r:sum(F(decisions[o,r]['node_mean'][s][cost]['loss'])for o in outerids)/12 for r in ['candidate','reference']};costvals[s][cost]={r:str(x)for r,x in v.items()};add('decision.'+s+'.underage_'+cost,v['candidate'],v['reference'])
 ck(name+'_macro_node_cost_all_exact',published['macro_losses']=={r:{k:str(v)for k,v in row.items()}for r,row in macro.items()}and published['node_losses']==nodevals and published['decision_losses']==costvals)
 ck(name+'_26leaves_comparisons_success_exact',{r['id']:r for r in published['leaves']}==ours and len(ours)==26 and published['quality_success']==all(r['passed']for r in ours.values())and published['origin_ids']==outerids and published['study_complete']is None and published['candidate_score']is None)
 ownresults[name]={'quality_success':all(r['passed']for r in ours.values()),'pass_count':sum(r['passed']for r in ours.values()),'condition_count':26,'failed':[k for k,r in ours.items()if not r['passed']],'macro':{r:{k:str(v)for k,v in row.items()}for r,row in macro.items()},'nodes':nodevals,'costs':costvals}

# Exact-source typed primitive checks only. The independent oracle above never imports it.
sys.path.insert(0,str(OUT/'source-quality'))
from l02_quality import assess_quality,load_quality_policy,single_period_loss
from l02_scoring import load_study
study=load_study(OUT/'study-contract.draft.json');typed=[]
def error_probe(name,fn,expected):
 try:fn()
 except Exception as e:
  typed.append({'name':name,'type':type(e).__name__,'code':getattr(e,'code',None),'detail':str(e),'scope':'direct typed primitive, not arbitrary candidate JSON CLI'});ck('typed_'+name,getattr(e,'code',None)==expected)
 else:ck('typed_'+name,False)
missing=dict(cases);missing.pop(outerids[0]);error_probe('missing_registered_case',lambda:assess_quality(missing,reference,contexts,labels,outerids,study,policy),'quality_incomplete')
badref=copy.deepcopy(reference);badref[outerids[0]]['forecast']['forecasts'].pop();error_probe('broken_reference_is_facility',lambda:assess_quality(cases,badref,contexts,labels,outerids,study,policy),'facility_quality_reference_invalid')
badcase=copy.deepcopy(cases);badcase[outerids[0]]['forecast']['forecasts'].pop();error_probe('missing_candidate_forecast_row',lambda:assess_quality(badcase,reference,contexts,labels,outerids,study,policy),'prediction_incomplete')
extra=copy.deepcopy(cases);extra[outerids[0]]['labels']={'claimed_truth':0};error_probe('candidate_cannot_supply_truth_record',lambda:assess_quality(extra,reference,contexts,labels,outerids,study,policy),'quality_incomplete')
error_probe('boolean_action_is_typed_error',lambda:single_period_loss(True,10,3,1),'facility_decision_values_invalid')
ck('hand_loss_6_and_overage2',single_period_loss(F(8),10,3,1)['loss']=='6'and single_period_loss(F(12),10,3,1)['loss']=='2')
save(OUT/'typed-probes.json',typed);save(OUT/'independent-quality-results.json',ownresults);save(OUT/'selected-original-inner-bindings.json',allselectors);save(OUT/'checks.json',checks)
summary={'checks':len(checks),'all_passed':all(r['passed']for r in checks),'failed':[r['name']for r in checks if not r['passed']],'seconds':time.perf_counter()-started,'results':{n:{k:v for k,v in r.items()if k in ['quality_success','pass_count','condition_count','failed']}for n,r in ownresults.items()},'source':'original historical author forecasts; no new prediction or trained candidate','policy_unchanged_from_pre_results':checks[0]['passed'],'new_Docker_forecast_solver_Provider_calls':0,'L02_frozen':False,'candidate_score':None};save(OUT/'assessment.json',summary);print(json.dumps(summary,ensure_ascii=False))
