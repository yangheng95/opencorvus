from pathlib import Path
import json
from fractions import Fraction
root=Path(__file__).parent
case=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L02')
groups=[]
def group(identifier,title,rows):
 values=[]
 for index,(weight,critical,criterion,evidence) in enumerate(rows,1):
  values.append({'id':identifier+str(index).zfill(2),'weight':weight,'critical':critical,'quality':False,'criterion':criterion,
   'evidence':evidence,'method':'independent_evaluator_review','anchors':{'pass':'实际证据完整支持本原子结论','fail':'实际证据反驳本结论；缺交/依赖缺交另用candidate_incomplete/blocked_candidate','unassessed':'尚未由评估方完成审查，不出总分'},
   'truth_limit':'文件存在或候选自述不能证明该结论；须独立核数字/源码/实际执行或图形'})
 groups.append({'id':identifier,'title':title,'criteria':values})
group('A','原材料与可知信息',[
 (3,True,'逐行单位精确换算为规范L','原CSV值/单位、权威单位表与来源映射'),
 (3,True,'每个拟合/预测使用的事实满足当时发布时间许可','原行release_time、assigned origin和完整SQL许可集合'),
 (3,True,'最高已发布revision含missing为权威','同业务键各revision与实际取值/缺测路径'),
 (2,True,'预测目标恰为注册的14个完整未来UTC日','cutoff/target_ticks/原日区间和84格输出'),
 (2,True,'leaf与aggregate身份及均值相加关系正确','series/hierarchy、实际forecast均值'),
 (2,False,'报告数字能定位到原行和来源身份','完整来源映射、报告中实际数据引用')])
group('B','科学方法与事前选择池',[
 (4,True,'基线与扩展具有真实科学机制区别','冻结源/配置和实际特征/拟合行为'),
 (3,True,'消融实际移除所声明机制','消融源/配置及实际拟合/预测/校准路径'),
 (3,True,'方法池和参数在首私有预测前冻结','原注册、源/配置与实际启动记录'),
 (2,True,'拟合样本实际来自合法历史','每origin拟合来源、样本时点和实际执行'),
 (3,True,'校准伪origin特征按各自当时可知信息复建','伪origin原行/许可与实际校准输入'),
 (2,True,'校准标签来自真实origin已发布的明确版本','校准目标版本、release和来源映射'),
 (1,False,'最后一天天气缺测处理有可执行说明','源/实际缺测目标/报告说明'),
 (1,False,'所报mean的估计目标与MSE解释一致','方法定义/实际输出及结果解释'),
 (1,False,'边际区间的解释与实际估计对象一致','分位点构造/报告方法说明')])
group('C','真实完整数值实验',[
 (4,True,'全部声明inner/outer单元按固定网格完成','正式assignment ledger/真实终态/全部完整预测'),
 (3,True,'selector实际选完整已发布inner损失最小的原ID','原inner输入、独立精确重算和实际选择输出'),
 (3,True,'outer执行保持原冻结配置与信息边界','原注册、真实outer挂载/源/配置/时间线'),
 (2,True,'全部预测满足数值与均值一致性合同','完整forecast经权威score的真实检查结果'),
 (2,True,'声明程序与实际源/运行环境相符','原执行源码、argv、镜像和真实终态'),
 (1,True,'故障和已完成单元状态如实持久记录','原错误/原CID/accepted对象/恢复与未评状态')])
group('D','研究结果与解释',[
 (2,False,'点预测比较完整保留配对基线/扩展/消融结果','全部origin/node实际MSE与配对表'),
 (2,False,'区间比较完整保留配对基线/扩展/消融结果','全部origin/node实际WIS与配对表'),
 (2,False,'报告揭示逐节点和逐切点的失败分布','原误差表、实际图与失败定位'),
 (1,False,'覆盖率报告由实际目标/分位点计算','实际覆盖/宽度表及分母'),
 (1,False,'拟合和校准诊断与实际执行一致','真实参数/样本/残差诊断与报告'),
 (2,False,'机制解释有与结论对应的实验证据','源/配对实验/报告主张的逐项关联'),
 (2,True,'负结果未被隐藏或反向叙述','原消融/误差与报告结论一致性'),
 (2,True,'区分已知运营公告与未识别量效','当时原公告、合法历史与报告不确定性结论'),
 (1,True,'统计结论遵守实际依赖结构','采样单元/统计方法/局限，不把相邻单元伪当独立')])
group('E','合成运营损失与交接',[
 (3,True,'成本场景对应策略在见结果前固定','原成本合同、q.5/.75/.9映射及冻结预测'),
 (3,False,'完整行动和损失账与原预测/终审闭合','四leaf/日期/成本的action、缺余量与损失分量'),
 (1,False,'mean行动的诊断成本按同一口径计算','冻结mean、相同truth/成本和完整分母'),
 (2,False,'成本敏感性结论忠实于完整实际结果','三成本对照表、失败边界和运营建议'),
 (1,True,'运营适用性不超出实际单期边际模型','报告的容量/库存/联合尾风险/真实机构适用性说明')])
group('F','清洁复建与职业交付',[
 (4,True,'新目录从源码/原材料完整复建到研究报告','正式完整source-only新执行与独立结果核算'),
 (2,False,'实验来源可定位实际命令和产物','完整来源索引、真实命令/终态/文件定位'),
 (2,False,'实际图形清楚且与原数据一致','真实呈现的图、数据绑定和独立视觉观察'),
 (1,True,'关键方法/数据许可引用真实权威原文','报告引用与评估者实际核对的原文/许可'),
 (1,False,'交接说明明确复建条件及适用限制','依赖/命令/数据域/当前失败与交接文档')])
quality=[]
def q(identifier,weight,criterion):
 quality.append({'id':'Q.'+identifier,'weight':weight,'critical':True,'quality':True,'criterion':criterion,'method':'registered_quality_checker',
  'evidence':'权威完整网格/终审/尺度＋原真实选中预测＋私有固定参照注册','anchors':{'pass':'同一固定分母下原始loss满足预先比较关系','fail':'实际loss不满足关系','unassessed':'设施/参照或输入未资格则不伪造通过'},'readiness':'rule proposed; full-case reader/independent freeze pending'})
for metric in ['scaled_mse','scaled_wis']:q('macro.'+metric,'3/2','原既定层级宏平均'+metric+'严格低于固定外部参照')
for node in ['A1','A2','B1','B2','ZA','ZB']:
 for metric in ['scaled_mse','scaled_wis']:q('node.'+node+'.'+metric,'1/2',node+'完整平均'+metric+'不劣于固定外部参照')
for node in ['A1','A2','B1','B2']:
 for cost in ['1','3','9']:q('decision.'+node+'.underage_'+cost,'1/2',node+'缺量成本'+cost+'/余量成本1的固定分位策略完整平均loss不劣于参照')
groups.append({'id':'Q','title':'非补偿预测/运营质量','criteria':quality})
readiness={key:False for key in ['registered_quality_reference','quality_controls_independent','formal_full_assignment_cold','complete_scientific_reference','complete_grader_evidence_binding','independent_rubric_review','review_anchor_calibration']}
rubric={'format':'l02-rubric/1','case':'L02','status':'draft','total_weight':100,'criterion_count':sum(len(g['criteria']) for g in groups),
 'scope':'complete proposed research/quality criteria; executable arithmetic is not a qualified whole candidate grader or freeze',
 'groups':groups,'readiness':readiness,'publication':{'requires_readiness':list(readiness),'good_score_at_least':90,
 'threshold_origin':'author pre-candidate comparison rule, not a general mature-benchmark threshold','two_good_action':'new version; preserve this frozen line'},
 'scoring':'binary atomic leaves, fixed 100 denominator; quality/critical cannot be compensated; facility errors have no score; pending leaves block publication'}
assert sum(Fraction(c['weight']) for g in groups for c in g['criteria'])==100
(case/'rubric.draft.json').write_text(json.dumps(rubric,indent=2,ensure_ascii=False),encoding='utf-8')
print(json.dumps({'criteria':rubric['criterion_count'],'weights':{g['id']:str(sum(Fraction(c['weight']) for c in g['criteria'])) for g in groups}},ensure_ascii=False))
