"""Capture only the already observed policy/plan; deliberately never opens result files."""
import json,shutil,subprocess
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parent
source=Path('D:/opencorvus-benchmark-runs/l02-quality-study-qualification-20261030/policy-before-results.json')
target=ROOT/'policy-before-results.json';shutil.copy2(source,target)
record=Path('D:/myhexin-local/opencorvus/specs/records/2026-10/2026-10-30-heavy-workbench-l02-qualification.md')
start='## 2026-10-30 05:33 UTC 实施前Recall：质量政策与科学/运营交付'
end='正常文档索引/docs/范围提交/fetch-merge-审查-push，心跳ACTIVE。'
excerpt=[];taking=False
with record.open(encoding='utf-8')as f:
 for line in f:
  if line.startswith(start):taking=True
  if taking:excerpt.append(line)
  if taking and end in line:break
assert excerpt and end in excerpt[-1]
(ROOT/'PLAN-05-33-observed.md').write_text(''.join(excerpt),encoding='utf-8')
r=subprocess.run(['git','status','--short'],cwd='D:/myhexin-local/opencorvus',capture_output=True,text=True,encoding='utf-8')
(ROOT/'git-status-start.txt').write_text(r.stdout,encoding='utf-8')
receipt={'captured_at':datetime.now(timezone.utc).isoformat(),'policy_source':str(source),'policy_direct_byte_identity':source.read_bytes()==target.read_bytes(),'plan_source':str(record),'plan_capture_stops_at_known_pre_results_sentence':end,'new_per_node_quality_or_operational_results_read':False,'new_Docker_forecast_solver_Provider_GPU_UI_calls':0}
(ROOT/'capture-receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(receipt,ensure_ascii=False))
