from pathlib import Path
import copy,json,sys,time
root=Path(__file__).parent
sys.path.insert(0,str(root/'source-priority-repaired'))
from l02_quality import load_registered_reference,load_quality_policy,assess_quality
from l02_scoring import load_study,ProtocolError
from l02_study_data import StudySource,load_pool
from l02_execution import read_archive,archived_json,json_bytes,atomic_bytes
study=load_study(root/'study-contract.draft.json');policy=load_quality_policy(root/'policy-before-results.json');_,methods=load_pool(root/'reference-pool.json')
data=StudySource(Path('D:/opencorvus-benchmark-runs/l02-daily-loop-qualification-20261030/main/raw'),root/'material-contract.json',study)
reference,contexts,labels,origins=load_registered_reference(root/'registered-reference-originals.zip',data,study,policy,methods['seasonal-weekday'])
files=read_archive(root/'registered-reference-originals.zip')
cases={origin:{'method_id':archived_json(files,'selections/'+origin+'.json')['selected_method_id'],
 'forecast':archived_json(files,'candidate/'+origin+'/forecast.json',True)} for origin in origins}
checks=[];start=time.perf_counter()
def expect(name,candidate,base,code):
 try:assess_quality(candidate,base,contexts,labels,origins,study,policy)
 except ProtocolError as e:
  assert e.code==code,(name,e.code);checks.append({'name':name,'error':e.code})
 else:raise AssertionError(name)
candidate=copy.deepcopy(cases);candidate[origins[0]]['forecast']['forecasts'].pop()
base=copy.deepcopy(reference);base[origins[0]]['forecast']['forecasts'].pop()
expect('same_origin_both_incomplete',candidate,base,'facility_quality_reference_invalid')
base=copy.deepcopy(reference);base[origins[-1]]['forecast']['forecasts'].pop()
expect('early_candidate_late_reference_incomplete',candidate,base,'facility_quality_reference_invalid')
expect('candidate_missing_reference_incomplete',{},base,'facility_quality_reference_invalid')
expect('only_candidate_incomplete',candidate,reference,'prediction_incomplete')
expect('only_candidate_origin_missing',{k:v for k,v in cases.items() if k!=origins[0]},reference,'quality_incomplete')
value=assess_quality(cases,reference,contexts,labels,origins,study,policy)
assert value==json.loads((root/'selected-reference.json').read_text()),'legal result changed'
checks.append({'name':'actual_selected_reference_same_original_26_outcomes','quality_success':value['quality_success']})
result={'status':'facility_preflight_priority_repaired','checks':checks,'wall_seconds':time.perf_counter()-start,'scope':'original matrix/library replay, no prediction or candidate execution'}
atomic_bytes(root/'priority-repair-assessment.json',json_bytes(result));print(json.dumps(result),flush=True)
