"""Only incremental binding/priority/rubric arithmetic and existing report facts."""
import copy,csv,io,json,runpy,shutil,sys,zipfile
from pathlib import Path
from types import SimpleNamespace
from fractions import Fraction as F
ROOT=Path(__file__).resolve().parent
Q=Path('D:/opencorvus-benchmark-runs/l02-quality-study-qualification-20261030')
CASE=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L02')
OUT=ROOT/'binding-rubric-review';OUT.mkdir(exist_ok=False)
shutil.copytree(Q/'source-priority-repaired',OUT/'source-priority-repaired')
shutil.copytree(Q/'research-analysis',OUT/'research-analysis-originals')
for n in ['priority-repair-assessment.json','priority-repair-command.json','binding-rubric-assessment.json','binding-reorder-initial.json','rubric-before-anchor-repair.json','rubric.repaired.json']:shutil.copy2(Q/n,OUT/n)
shutil.copy2(CASE/'rubric.draft.json',OUT/'current-rubric.draft.json')
sys.path.insert(0,str(OUT/'source-priority-repaired'))
from l02_quality import load_registered_reference,assess_quality,load_quality_policy
from l02_rubric import load_rubric,aggregate
from l02_scoring import load_study
from material_contract import parse_json
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def save(n,v):(OUT/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
checks=[];errors=[]
def ck(n,v):checks.append({'name':n,'passed':bool(v)})
with zipfile.ZipFile(ROOT/'numeric-audit/registered-reference-originals.zip')as z:files={n:z.read(n)for n in z.namelist()}
def js(n):return parse_json(files[n].decode('utf-8'),decimal_numbers=True)
grid=js('facts/grid.json');raw=js('facts/canonical.json');scales=js('facts/scales.json');edges=[{**e,'weight':int(e['weight'])}for e in grid['hierarchy']];nodes=[{k:n[k]for k in ['series_id','kind']}for n in grid['series_catalogue']];contexts={};labels={};terminal={(r['series_id'],r['event_tick']):r for r in raw['observations']if r['revision_id']==2};cases={}
for o in grid['origins']:
 if o['role']!='outer':continue
 g=o['origin_id'];contexts[g]={'format':'l02-score-context/1','origin_tick':o['origin_tick'],'target_ticks':o['target_ticks'],'series_catalogue':nodes,'hierarchy':edges,'scales_litres':scales};tr={(n['series_id'],t):terminal[n['series_id'],t]['value']for n in nodes if n['kind']=='leaf'for t in o['target_ticks']}
 for n in nodes:
  if n['kind']=='aggregate':
   for t in o['target_ticks']:tr[n['series_id'],t]=sum(e['weight']*tr[e['child'],t]for e in edges if e['parent']==n['series_id'])
 labels[g]=[{'series_id':s,'target_tick':t,'value':v}for(s,t),v in tr.items()];forecast=js('candidate/'+g+'/forecast.json');cases[g]={'method_id':forecast['method_id'],'forecast':forecast}
data=SimpleNamespace(raw=raw,grid=grid,scales=scales,contract=js('material-contract.json'),context_and_labels=lambda g:(contexts[g],labels[g],0))
study=load_study(ROOT/'numeric-audit/study-contract.draft.json');policy=load_quality_policy(ROOT/'policy-before-results.json');method=js('fixed-reference-method.json');reference,c,l,ids=load_registered_reference(ROOT/'numeric-audit/registered-reference-originals.zip',data,study,policy,method)
ck('current_registered_loader_valid12_and1008',len(ids)==12 and sum(len(r['forecast']['forecasts'])for r in reference.values())==1008 and c==contexts and l==labels)
reordered=copy.deepcopy(data);reordered.raw['observations'].reverse();reordered.raw['covariates'].reverse()
for field in ['series_catalogue','hierarchy','origins']:reordered.grid[field].reverse()
r2,c2,l2,i2=load_registered_reference(ROOT/'numeric-audit/registered-reference-originals.zip',reordered,study,policy,method)
ck('current_loader_semantic_row_reorder_accepted',r2==reference and c2==contexts and l2==labels and set(i2)==set(ids))
def probe(n,fn,expected):
 try:fn()
 except Exception as e:errors.append({'name':n,'actual':getattr(e,'code',None),'detail':str(e)});ck(n,getattr(e,'code',None)==expected)
 else:ck(n,False)
drift=copy.deepcopy(data);drift.raw['observations'][0]['value']+=1;probe('raw_business_drift_facility',lambda:load_registered_reference(ROOT/'numeric-audit/registered-reference-originals.zip',drift,study,policy,method),'facility_quality_binding_invalid')
bothcase=copy.deepcopy(cases);bothref=copy.deepcopy(reference);bothcase[ids[0]]['forecast']['forecasts'].pop();bothref[ids[0]]['forecast']['forecasts'].pop();probe('original_same_origin_both_bad_now_facility',lambda:assess_quality(bothcase,bothref,contexts,labels,ids,study,policy),'facility_quality_reference_invalid')
rubric,criteria=load_rubric(OUT/'current-rubric.draft.json');ck('current_rubric_exact_repaired_copy',(OUT/'current-rubric.draft.json').read_bytes()==(OUT/'rubric.repaired.json').read_bytes())
by={r['id']:r for r in criteria};weights={r['id']:F(r['weight'])for r in criteria};quality=[r for r in criteria if r['quality']]
ck('66_atomic40review26quality_100split85_15',len(criteria)==66 and len(quality)==26 and sum(weights.values())==100 and sum(F(r['weight'])for r in quality)==15 and all(r['critical']for r in quality))
ck('B05_B06_actual_method_freedom_and_E02_critical',by['E02']['critical']and by['E02']['weight']==3 and '解析'in by['B05']['anchors']['pass']and '参数来源'in by['B06']['anchors']['pass'])
actualfindings=[{'id':r['id'],'status':'verified_pass'if r['quality']else'unassessed'}for r in criteria];draft=aggregate(rubric,criteria,actualfindings)
ck('actual_quality26_unassessed40_keeps_all_formal_fields_null',draft['counts']['unassessed']==40 and all(draft[k]is None for k in ['total_score','study_complete','quality_success','good']))
synthetic=copy.deepcopy(rubric);synthetic['status']='frozen';synthetic['readiness']={k:True for k in synthetic['readiness']};ratings=[{'id':r['id'],'status':'candidate_incomplete'if r['id']=='E02'else'verified_pass'}for r in criteria];new=aggregate(synthetic,criteria,ratings)
ck('synthetic_missing_required_E02_97_goodfalse',new['total_score']==97 and new['study_complete']is False and new['quality_success']is True and new['good']is False and new['known_critical_failures']==['E02'])
oldrubric,oldcriteria=load_rubric(OUT/'rubric-before-anchor-repair.json');old=copy.deepcopy(oldrubric);old['status']='frozen';old['readiness']={k:True for k in old['readiness']};oldresult=aggregate(old,oldcriteria,ratings)
ck('original_E02_counterexample_preserved_and_weights_unchanged',oldresult['total_score']==97 and oldresult['good']is True and {r['id']:F(r['weight'])for r in oldcriteria}==weights)

# Only new report joins; numerical primitive results were already independently computed.
research=Q/'research-analysis';own=load(ROOT/'numeric-audit/independent-quality-results.json')['selected-reference'];original=load(ROOT/'numeric-audit/selected-reference.json')
def rows(name):return list(csv.DictReader((research/name).open(encoding='utf-8-sig',newline='')))
nodecsv=rows('node-losses.csv');ck('report6node_exact_losses',len(nodecsv)==6 and all(F(r[role+'_'+metric])==F(own['nodes'][r['node']][metric][role])for r in nodecsv for role in ['candidate','reference']for metric in ['scaled_mse','scaled_wis']))
opcsv=rows('operating-losses.csv');opfields=['shortage_litres','surplus_litres','shortage_loss','surplus_loss','mean_action_loss']
ck('report12costs_exact_losses_and_prechecked_decompositions',len(opcsv)==12 and all(F(r['selected_mean_loss'])==F(own['costs'][r['node']][r['underage_cost']]['candidate'])and F(r['reference_mean_loss'])==F(own['costs'][r['node']][r['underage_cost']]['reference'])and all(F(r[prefix+'_'+field])==sum(F(original['per_origin_decisions'][g][role]['node_mean'][r['node']][r['underage_cost']][field])for g in ids)/12 for prefix,role in [('selected','candidate'),('reference','reference')]for field in opfields)for r in opcsv))
bindings=rows('source-bindings.csv');ck('report24original_member_provenance',bindings==js('original-bindings.json'))
fitrows=rows('actual-fit-summary.csv');fitchecks=[]
for r in fitrows:
 with zipfile.ZipFile(r['source_zip'])as z:f=parse_json(z.read(r['source_member']).decode('utf-8'),decimal_numbers=True)
 node=f['fit'][r['node']];fitchecks.append(int(r['training_rows'])==node['training_rows']and r['features']==';'.join(node['features'])and parse_json(r['coefficient'],decimal_numbers=True)==node['coefficient']and int(r['paired_residual_rows'])==f['paired_residual_rows']and json.loads(r['future_weather_imputed_ticks'])==node['future_temperature_imputed_ticks']and int(r['maximum_training_event_tick'])==node['maximum_training_event_tick']and r['numpy_version']==f['numpy_version'])
ck('report48actual_fit_metadata_and_coefficients',len(fitrows)==48 and len({(r['origin'],r['node'])for r in fitrows})==48 and all(fitchecks))
june=rows('june-A1-q90.csv');jcase=cases['outer-20250620']['forecast'];jref=reference['outer-20250620']['forecast'];jby={(r['series_id'],r['target_tick']):r for r in jcase['forecasts']};rb={(r['series_id'],r['target_tick']):r for r in jref['forecasts']};tr={(r['series_id'],r['target_tick']):r['value']for r in labels['outer-20250620']}
ck('report14June_q90_actions_truth_and_losses',len(june)==14 and all(F(r['truth_litres'])==tr['A1',int(r['target_tick'])]and F(r['selected_q90'])==F(jby['A1',int(r['target_tick'])]['quantiles']['0.9'])and F(r['reference_q90'])==F(rb['A1',int(r['target_tick'])]['quantiles']['0.9'])and F(r['shortage_litres'])==max(F(r['truth_litres'])-F(r['selected_q90']),F())and F(r['selected_loss'])==9*max(F(r['truth_litres'])-F(r['selected_q90']),F())+max(F(r['selected_q90'])-F(r['truth_litres']),F())for r in june))
plot=load(research/'plot-input.json');ck('plot_input_same_cost_and_boundary_tables',len(plot['operations'])==12 and len(plot['june_A1'])==14 and all(F(p['selected_mean_loss'])==F(r['selected_mean_loss'])and F(p['reference_mean_loss'])==F(r['reference_mean_loss'])for p,r in zip(plot['operations'],opcsv))and all(int(p['target_tick'])==int(r['target_tick'])and F(p['selected_q90'])==F(r['selected_q90'])and F(p['truth_litres'])==F(r['truth_litres'])for p,r in zip(plot['june_A1'],june)))
save('checks.json',checks);save('errors.json',errors);save('rubric-arithmetic-controls.json',{'warning':'synthetic protocol only, not candidate grading','old_missing_E02':oldresult,'new_missing_E02':new,'actual_40_unassessed':draft});save('fit-metadata-checks.json',fitchecks)
result={'checks':len(checks),'all_passed':all(r['passed']for r in checks),'failed':[r['name']for r in checks if not r['passed']],'numeric_335_not_repeated':True,'new_Docker_forecast_solver_Provider_calls':0,'actual_new_image_viewed':True,'rubric_scope':'draft structure and trusted arithmetic only; remaining human anchors/full grader not qualified','candidate_grade':None,'L02_frozen':False};save('assessment.json',result);print(json.dumps(result,ensure_ascii=False))
