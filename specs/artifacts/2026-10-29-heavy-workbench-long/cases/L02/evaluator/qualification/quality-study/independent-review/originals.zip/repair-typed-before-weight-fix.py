"""Only repair reviewer's two context fixtures, preserving original335 checks."""
import copy,json,sys,zipfile
from pathlib import Path
from fractions import Fraction
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'typed-probe-repair';OUT.mkdir(exist_ok=False)
sys.path.insert(0,str(ROOT/'numeric-audit/source-quality'))
from l02_quality import assess_quality,load_quality_policy
from l02_scoring import load_study,score
from material_contract import parse_json
with zipfile.ZipFile(ROOT/'numeric-audit/registered-reference-originals.zip')as z:
 files={n:z.read(n)for n in z.namelist()}
def js(n):return parse_json(files[n].decode('utf-8'),decimal_numbers=True)
grid=js('facts/grid.json');raw=js('facts/canonical.json');scales=js('facts/scales.json');origins=[r for r in grid['origins']if r['role']=='outer'];ids=[r['origin_id']for r in origins];terminal={(r['series_id'],r['event_tick']):r for r in raw['observations']if r['revision_id']==2};cases={};reference={};contexts={};labels={}
for o in origins:
 origin=o['origin_id'];nodes=[{k:n[k]for k in ['series_id','kind']}for n in grid['series_catalogue']];context={'format':'l02-score-context/1','origin_tick':o['origin_tick'],'target_ticks':o['target_ticks'],'series_catalogue':nodes,'hierarchy':grid['hierarchy'],'scales_litres':scales};contexts[origin]=context;tr={(n['series_id'],t):terminal[n['series_id'],t]['value']for n in nodes if n['kind']=='leaf'for t in o['target_ticks']}
 for n in nodes:
  if n['kind']=='aggregate':
   for t in o['target_ticks']:tr[n['series_id'],t]=sum(e['weight']*tr[e['child'],t]for e in grid['hierarchy']if e['parent']==n['series_id'])
 labels[origin]=[{'series_id':s,'target_tick':t,'value':v}for(s,t),v in tr.items()]
 for role,matrix in [('candidate',cases),('reference',reference)]:
  forecast=js(role+'/'+origin+'/forecast.json');matrix[origin]={'method_id':forecast['method_id'],'forecast':forecast}
study=load_study(ROOT/'numeric-audit/study-contract.draft.json');policy=load_quality_policy(ROOT/'policy-before-results.json');checks=[]
def probe(name,fn,expected):
 try:fn()
 except Exception as e:checks.append({'name':name,'code':getattr(e,'code',None),'detail':str(e),'expected':expected,'passed':getattr(e,'code',None)==expected})
 else:checks.append({'name':name,'passed':False})
first=ids[0];valid=score(cases[first]['forecast'],contexts[first],labels[first],cases[first]['method_id'],study)
checks.append({'name':'valid_two_field_context_actual84row_score','status':valid['status'],'rows':valid['rows'],'passed':valid['status']=='forecast_assessed'and valid['rows']==84})
badref=copy.deepcopy(reference);badref[first]['forecast']['forecasts'].pop();probe('broken_reference_is_facility',lambda:assess_quality(cases,badref,contexts,labels,ids,study,policy),'facility_quality_reference_invalid')
badcase=copy.deepcopy(cases);badcase[first]['forecast']['forecasts'].pop();probe('missing_candidate_forecast_row',lambda:assess_quality(badcase,reference,contexts,labels,ids,study,policy),'prediction_incomplete')
initial=json.loads((ROOT/'numeric-audit/assessment.json').read_text());result={'all_passed':all(r['passed']for r in checks),'checks':checks,'original_335_checks_preserved':True,'original_333_passed_unchanged':initial['checks']-len(initial['failed']),'original_two_false_cause':'Reviewer used raw series catalogue with extra columns as strict score context; target API correctly rejected facility_context_invalid before forecast checks. New fixture uses only declared series_id/kind; no main-source change.','new_forecasts_Docker_solver_Provider_calls':0}
(OUT/'assessment.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(result,ensure_ascii=False))
