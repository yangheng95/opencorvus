"""One direct primitive probe for authoritative-reference failure precedence."""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
source=(ROOT/'repair_typed_probes.py').read_text();prefix=source.split('study=load_study',1)[0].replace("ROOT/'typed-probe-repair-final'","ROOT/'facility-priority-probe'")
space={'__file__':str(ROOT/'repair_typed_probes.py')};exec(compile(prefix,'reviewer_valid_context_preamble','exec'),space)
from copy import deepcopy
study=space['load_study'](ROOT/'numeric-audit/study-contract.draft.json');policy=space['load_quality_policy'](ROOT/'policy-before-results.json');cases=deepcopy(space['cases']);ref=deepcopy(space['reference']);first=space['ids'][0]
cases[first]['forecast']['forecasts'].pop();ref[first]['forecast']['forecasts'].pop()
try:space['assess_quality'](cases,ref,space['contexts'],space['labels'],space['ids'],study,policy)
except Exception as e:
 result={'probe':'both candidate and fixed reference missing one actual assigned row','actual_error':getattr(e,'code',None),'detail':str(e),'kind':'typed primitive, not full candidate grader','reference_contract_is_also_broken':True,'new_Docker_forecast_solver_Provider_calls':0}
 (ROOT/'facility-priority-probe/result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(result,ensure_ascii=False))
