import json
from pathlib import Path
from fractions import Fraction
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

data=json.loads(Path('/input/plot-input.json').read_text())
out=Path('/output');figure,axes=plt.subplots(1,2,figsize=(14,5.8),layout='constrained')
nodes=['A1','A2','B1','B2'];colors=['#0072B2','#D55E00','#009E73']
for offset,cost in enumerate(['1','3','9']):
 ratios=[]
 for node in nodes:
  row=next(r for r in data['operations'] if r['node']==node and r['underage_cost']==cost)
  reference=Fraction(row['reference_mean_loss']);ratios.append(float(Fraction(row['selected_mean_loss'])/reference) if reference else float('nan'))
 axes[0].bar([i+(offset-1)*.23 for i in range(4)],ratios,width=.22,color=colors[offset],label='underage '+cost+' / overage 1')
axes[0].axhline(1,color='black',linestyle='--',label='fixed reference')
axes[0].set_xticks(range(4),nodes);axes[0].set_ylabel('Mean decision loss / fixed-reference mean loss')
axes[0].set_title('All 12 origins: declared quantile policy');axes[0].legend(fontsize=9,loc='upper right');axes[0].grid(axis='y',alpha=.2)
rows=data['june_A1'];x=range(len(rows));truth=[float(Fraction(r['truth_litres'])) for r in rows];action=[float(Fraction(r['selected_q90'])) for r in rows]
axes[1].plot(x,truth,'k.-',label='terminal truth')
axes[1].plot(x,action,'.-',color='#0072B2',label='frozen selected q0.9')
axes[1].fill_between(x,action,truth,where=[a<t for a,t in zip(action,truth)],alpha=.23,color='#D55E00',label='positive shortage')
axes[1].set_xticks(range(0,len(rows),2),[r['event_date'][5:] for r in rows[::2]],rotation=35)
axes[1].set_ylabel('A1 daily litres');axes[1].set_xlabel('UTC event date')
axes[1].set_title('June20 origin: local exposure remains');axes[1].legend(fontsize=9);axes[1].grid(alpha=.2)
figure.suptitle('Author reference analysis: relative acceptance is not a service guarantee')
figure.savefig(out/'quality-and-boundary.png',dpi=140);plt.close(figure)
(out/'render.json').write_text(json.dumps({'status':'actual_quality_analysis_rendered','matplotlib':matplotlib.__version__,'input_rows':{'operations':len(data['operations']),'june':len(rows)},'visual_review':'pending'}))
