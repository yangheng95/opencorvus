"""One-time historical-reference qualification adapter; not a live old-run grader."""
from pathlib import Path
from fractions import Fraction
import copy,csv,json,sys,time,zipfile
root=Path(__file__).parent
sys.path.insert(0,str(root/'source-quality'))
from material_contract import read_json,parse_json
from l02_scoring import load_study
from l02_study_data import StudySource,load_pool
from l02_selection import assess_selection
from l02_quality import load_quality_policy,assess_quality
from l02_execution import json_bytes,zip_bytes,atomic_bytes
start=time.perf_counter()
study=load_study(root/'study-contract.draft.json');policy=load_quality_policy(root/'policy-before-results.json')
old=Path('D:/opencorvus-benchmark-runs/l02-daily-loop-qualification-20261030')
data=StudySource(old/'main/raw',root/'material-contract.json',study)
pool,methods=load_pool(root/'reference-pool.json')
assert read_json(old/'main/decoder-archive/canonical.json')==data.raw
expected=[g['origin_id'] for g in data.grid['origins'] if g['role']=='outer']
reference,cases,contexts,labels={}, {}, {}, {}
sources={};binding=[]
archive_files={'facts/canonical.json':json_bytes(data.raw),'facts/grid.json':json_bytes(data.grid),
 'facts/scales.json':json_bytes(data.scales),'material-contract.json':(root/'material-contract.json').read_bytes(),
 'study-contract.draft.json':(root/'study-contract.draft.json').read_bytes(),'policy-before-results.json':(root/'policy-before-results.json').read_bytes(),
 'fixed-reference-method.json':json_bytes(methods['seasonal-weekday'])}
for origin in expected:
 if origin=='outer-20250115':run=old/'main/representative'
 elif origin=='outer-20250620':run=Path('D:/opencorvus-benchmark-runs/l02-daily-loop-independent-review-20261030/cold-june20/run')
 else:run=old/'main/remaining-ten'
 directory=run/'outer'/origin
 with zipfile.ZipFile(directory/'selector/completed-originals.zip') as z:
  payload=parse_json(z.read('input/inner.json').decode(),decimal_numbers=True)
  selection=parse_json(z.read('output/result/selection.json').decode())
  assess_selection(selection,payload,study)
  archive_files['selections/'+origin+'.json']=z.read('output/result/selection.json')
 chosen=selection['selected_method_id'];assert chosen in pool['selection_ids']
 contexts[origin],labels[origin],_=data.context_and_labels(origin)
 for role,method in [('reference','seasonal-weekday'),('candidate',chosen)]:
  original=directory/'outer'/method/'completed-originals.zip'
  with zipfile.ZipFile(original) as z:
   config=parse_json(z.read('input/method.json').decode(),decimal_numbers=True)
   assert config=={k:methods[method][k] for k in ['method_id','configuration']}
   forecast=parse_json(z.read('output/result/forecast.json').decode(),decimal_numbers=True)
   executed={n[16:]:z.read(n) for n in z.namelist() if n.startswith('executed-source/')}
   assert executed
   if role=='reference':
    if sources:assert sources==executed
    else:sources=executed
   archive_files[role+'/'+origin+'/forecast.json']=z.read('output/result/forecast.json')
   archive_files[role+'/'+origin+'/method.json']=z.read('input/method.json')
   archive_files[role+'/'+origin+'/terminal-inspect.json']=z.read('terminal-inspect.json')
   binding.append({'role':role,'origin':origin,'method':method,'original':str(original),'source_scope':'original executed-source bytes, not mutable working output'})
  (reference if role=='reference' else cases)[origin]={'method_id':method,'forecast':forecast}
for name,value in sources.items():archive_files['executed-fixed-reference-source/'+name]=value
archive_files['original-bindings.json']=json_bytes(binding)
atomic_bytes(root/'registered-reference-originals.zip',zip_bytes(archive_files))
def evaluate(name,matrix):
 result=assess_quality(matrix,reference,contexts,labels,expected,study,policy)
 atomic_bytes(root/(name+'.json'),json_bytes(result))
 return {'name':name,'quality_success':result['quality_success'],'failed':[row['id'] for row in result['leaves'] if not row['passed']],
         'pass_count':sum(row['passed'] for row in result['leaves']),'condition_count':len(result['leaves']),
         'source_scope':'real originally inner-selected forecasts' if name=='selected-reference' else 'deliberate qualification control, not candidate or reachability'}
results=[evaluate('selected-reference',cases),evaluate('baseline-self-control',reference)]
zero=copy.deepcopy(cases)
for item in zero.values():
 for row in item['forecast']['forecasts']:row['mean']=0;row['quantiles']={q:0 for q in study['quantiles']}
results.append(evaluate('zero-control',zero))
wide=copy.deepcopy(cases)
for item in wide.values():
 for row in item['forecast']['forecasts']:
  row['quantiles']={q:0 if Fraction(q)<Fraction(1,2) else 1000000 if Fraction(q)>Fraction(1,2) else row['quantiles'][q] for q in study['quantiles']}
results.append(evaluate('wide-interval-control',wide))
bad_node=copy.deepcopy(cases)
for origin,item in bad_node.items():
 for row in item['forecast']['forecasts']:
  if row['series_id'] in ['A1','ZA']:row['mean']+=100000
results.append(evaluate('coherent-one-leaf-mean-degradation',bad_node))
assert all(not row['quality_success'] for row in results[1:]),results
assessment={'status':'quality_policy_real_reference_and_controls_assessed','cases':results,'policy_unchanged':read_json(root/'policy-before-results.json')==policy,
 'wall_seconds':time.perf_counter()-start,'full_quality_reachability':results[0]['quality_success'],'candidate_score':None,'L02_frozen':False,
 'scope':'one-time old actual-prediction author qualification; no new forecast/solver/candidate, no live legacy input fallback'}
(root/'real-quality-assessment.json').write_text(json.dumps(assessment,indent=2));print(json.dumps(assessment),flush=True)
