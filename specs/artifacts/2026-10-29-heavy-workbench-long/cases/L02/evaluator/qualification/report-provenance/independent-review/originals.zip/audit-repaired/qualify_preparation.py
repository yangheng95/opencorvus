import json
from pathlib import Path
import shutil
import sqlite3
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'source-reporter-clarified'))
from l02_execution import (read_archive, archived_json, atomic_bytes, json_bytes, Executor, Ledger,
                           run_lock, ExecutionError)
from l02_report import provenance_coverage
from material_contract import same_json_value

def main():
    began=time.perf_counter();checks=[]
    def check(name,actual,expected):
        if not same_json_value(actual,expected):raise AssertionError((name,actual,expected))
        checks.append({'name':name,'status':'passed'})
    for stage,expected,preparations in [('before_prepared_publish','second',2),('prepared_published','first',1)]:
        run=ROOT/stage
        common=[sys.executable,'-X','utf8','-B',str(ROOT/'prepare_owner.py'),'--run',str(run)]
        initial=subprocess.run(common+['--value','first','--stop-stage',stage],capture_output=True,text=True,encoding='utf-8')
        atomic_bytes(ROOT/(stage+'-owner.json'),json_bytes({'argv':common,'exitcode':initial.returncode,'stdout':initial.stdout,'stderr':initial.stderr}))
        check(stage+'_real_owner_exit',initial.returncode,73)
        with sqlite3.connect((run/'runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
            check(stage+'_original_planned_row',db.execute('SELECT phase FROM cell').fetchone()[0],'planned')
        resume=subprocess.run(common+['--value','second'],capture_output=True,text=True,encoding='utf-8')
        atomic_bytes(ROOT/(stage+'-resume.json'),json_bytes({'argv':common,'exitcode':resume.returncode,'stdout':resume.stdout,'stderr':resume.stderr}))
        check(stage+'_resume_exit',resume.returncode,0)
        check(stage+'_actual_program_consumed',json.loads(resume.stdout)['actual'],{'consumed':expected})
        check(stage+'_recorded_input_preparations',len(json.loads((run/'input-preparation-history.json').read_text())),preparations)
        with sqlite3.connect((run/'runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
            cid,phase=db.execute('SELECT cid,phase FROM cell').fetchone()
            check(stage+'_native_verified_phase',phase,'verified')
        job=run/'cells/1';receipts=[]
        for name in ['create','start','cleanup']:
            files=list(job.glob(name+'-*.json'))
            if name=='cleanup':files=[f for f in files if read_archive(run/'cells/1/accepted.zip') and json.loads(f.read_text())['argv'][1]=='rm']
            check(stage+'_'+name+'_one_real_operation',len(files),1)
            check(stage+'_'+name+'_native_exit',json.loads(files[0].read_text())['exitcode'],0)
        accepted=read_archive(job/'accepted.zip');native=archived_json(accepted,'terminal-inspect.json')
        check(stage+'_same_cid',[native['Id'],native['State']['Status'],native['State']['ExitCode']],[cid,'exited',0])
        check(stage+'_sealed_original_input',archived_json(accepted,'input/value.json'),{'value':expected})
    # Resume only the old report on a complete copy. The original old run is read-only.
    old=Path('D:/opencorvus-benchmark-runs/l02-generic-execution-qualification-20261030/python-loop')
    copied=ROOT/'historical-report-copy';copied.mkdir()
    with sqlite3.connect((old/'runs.sqlite3').as_uri()+'?mode=ro',uri=True) as src:
        with sqlite3.connect(copied/'runs.sqlite3') as target:src.backup(target)
    shutil.copytree(old/'cells/11',copied/'cells/11')
    prior=read_archive(old/'cells/11/accepted.zip');program=archived_json(prior,'program.json')
    source={n[8:]:v for n,v in prior.items() if n.startswith('project/')}
    expected_inputs=read_archive(ROOT/'original-numeric-projection.zip')
    ledger=Ledger(copied)
    try:
        image=archived_json(prior,'terminal-inspect.json')['Image']
        with run_lock(copied):
            actual=Executor(ledger,image).invoke({'kind':'report'},program,source,lambda:expected_inputs,
                lambda files:{'status':'report_protocol_verified','scientific_review':'unassessed','candidate_score':None})
        check('historical_report_original_capsule',actual==prior,True)
        check('historical_report_original_input_fact',provenance_coverage(actual,expected_inputs)['status'],'not_delivered')
        check('historical_preserved_sql_version',ledger.db.execute('PRAGMA user_version').fetchone()[0],1)
        changed={**source,next(iter(source)):b'new programme'}
        try:Executor(ledger,image).invoke({'kind':'report'},program,changed,lambda:expected_inputs,lambda _: {})
        except ExecutionError as e:check('historical_source_rebind_named_facility',e.code,'facility_program_identity_changed')
        else:raise AssertionError('source identity response expected')
    finally:ledger.close()
    result={'status':'qualified','wall_seconds':time.perf_counter()-began,'checks':checks,
        'new_native_record_processes':2,'new_forecast_processes':0,
        'scope':'two prepared publication crash boundaries and original verified report; not power-loss, full study or hours qualification'}
    atomic_bytes(ROOT/'preparation-assessment.json',json_bytes(result));print(json.dumps(result))

if __name__=='__main__':main()
