"""New report only, from the prior real baseline-one numeric objects."""
import copy
import json
from pathlib import Path
import sqlite3
import sys
import time

ROOT = Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'source-current'))
from l02_execution import (Ledger, Executor, json_bytes, archived_json, read_archive,
                           atomic_bytes, zip_bytes, run_lock, ExecutionError)
from l02_pipeline import assess_report
from l02_report import numeric_records, report_inputs, provenance_coverage, project_argv
from material_contract import same_json_value


def main():
    began=time.perf_counter()
    old=Path('D:/opencorvus-benchmark-runs/l02-generic-execution-qualification-20261030/python-loop')
    with sqlite3.connect((old/'runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
        db.row_factory=sqlite3.Row;rows=[dict(r) for r in db.execute('SELECT * FROM cell ORDER BY id')]
        run_id=db.execute('SELECT id FROM run').fetchone()[0]
        schema=list(db.execute("SELECT sql FROM sqlite_master WHERE sql IS NOT NULL ORDER BY name"))
    sealed=read_archive(old/'registration.zip');reg=archived_json(sealed,'registration.json')
    manifest=archived_json(sealed,'submission/submission.json',True)
    expected=[json.loads(r['identity']) for r in rows if json.loads(r['identity'])!={'kind':'report'}]
    source={n[11:]:v for n,v in sealed.items() if n.startswith('submission/')}
    records=numeric_records(old,rows,run_id,reg['image_id'],manifest,source,expected)
    old_report=read_archive(old/'cells/11/accepted.zip')
    numerical=archived_json(old_report,'input/results.json',True)
    inputs=report_inputs(numerical,records)
    atomic_bytes(ROOT/'original-numeric-projection.zip',zip_bytes(inputs))
    checks=[]
    def check(name,actual,expected):
        if not same_json_value(actual,expected):raise AssertionError((name,actual,expected))
        checks.append({'name':name,'status':'passed'})
    check('historical_original_input_coverage',provenance_coverage(old_report,inputs)['status'],'not_delivered')
    check('narrow_argv_positive_projection',project_argv(['/usr/local/bin/python','report.py','/input/results.json','--private','C:/private/token'],['report.py']),
        [{'position':0,'kind':'executable_basename','value':'python'},
         {'position':1,'kind':'declared_source','value':'report.py'},
         {'position':2,'kind':'sandbox_path','value':'/input/results.json'},
         {'position':3,'kind':'opaque','value':None},{'position':4,'kind':'opaque','value':None}])
    projection=archived_json(inputs,'provenance/manifest.json')
    check('logical_identities_exact',[c['identity'] for c in projection['cells']],expected)
    for record,cell in zip(records,projection['cells']):
        check('native_execution_projection_'+str(cell['cell_id']),cell['execution'],
            {'argv_projection':project_argv([record['native']['Path'],*record['native']['Args']],record['program']['files']),
             'declared_source_files':record['program']['files'],
             'started_at':record['native']['State']['StartedAt'],'finished_at':record['native']['State']['FinishedAt'],
             'status':'exited','exit_code':0})
        check('output_member_projection_'+str(cell['cell_id']),
              {a['output_member']:inputs[a['input_path']].hex() for a in cell['artifacts']},
              {n[7:]:v.hex() for n,v in record['accepted'].items() if n.startswith('output/')})
    run=ROOT/'new-report-only';run.mkdir()
    ledger=Ledger(run,create=True)
    programme={'files':['report.py'],'argv':['python','report.py']}
    reporter={'report.py':(ROOT/'source-current/report_l02_reference.py').read_bytes()}
    try:
        with run_lock(run):
            executor=Executor(ledger,reg['image_id'])
            accepted=executor.invoke({'kind':'report'},programme,reporter,lambda:inputs,
                lambda files:assess_report(files,reg['outer_ids']))
            coverage=provenance_coverage(accepted,inputs)
    finally:ledger.close()
    check('new_actual_report_input_coverage',coverage,
        {'status':'delivered','numeric_cells':10,'candidate_artifacts':19,'scientific_review':'unassessed',
         'scope':'provided data only; use/truth require actual independent review'})
    delivered=ROOT/'new-report-output';delivered.mkdir()
    for name,value in accepted.items():
        if name.startswith('output/'):
            target=delivered/name[7:];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(value)
    # Actual native report programme consumed fit details into its output table.
    import csv
    with (delivered/'result/fit-index.csv').open(encoding='utf-8',newline='') as f:fits=list(csv.DictReader(f))
    check('actual_original_fit_rows',len(fits),36)
    selected=[r for r in fits if r['origin_id']=='outer-20250115' and r['method_id']=='ridge-weather-operations' and r['series_id']=='A1'][0]
    check('actual_fitted_origin_and_rows',[selected['training_rows'],selected['training_end_tick'],selected['paired_residual_rows']],['365','26640','42'])
    with (delivered/'result/operating-ledger.csv').open(encoding='utf-8',newline='') as f:actions=list(csv.DictReader(f))
    check('fixed_operating_grid',len(actions),168)
    with sqlite3.connect((run/'runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
        current_schema=list(db.execute("SELECT sql FROM sqlite_master WHERE sql IS NOT NULL ORDER BY name"))
        check('same_baseline_one_sql',[list(r) for r in current_schema],[list(r) for r in schema])
        check('schema_version',db.execute('PRAGMA user_version').fetchone()[0],1)
    result={'status':'report_component_qualified','wall_seconds':time.perf_counter()-began,'checks':checks,
        'new_numeric_processes':0,'new_report_processes':1,'numeric_origin':'previous real baseline-one accepted objects',
        'coverage':coverage,'scope':'report component only; not a new complete twelve-outer study, candidate score or hours proof'}
    atomic_bytes(ROOT/'report-component-assessment.json',json_bytes(result));print(json.dumps(result))


if __name__=='__main__':main()
