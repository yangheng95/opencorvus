"""Current captured-input and native identity boundaries, without new forecasts."""
import json
from pathlib import Path
import sqlite3
import sys
import tempfile
import time

ROOT=Path(__file__).resolve().parent
SOURCE=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L02/evaluator/current-source')
sys.path.insert(0,str(SOURCE))
from l02_execution import (archived_json,read_archive,json_bytes,atomic_bytes,ExecutionError,validate_terminal)
from l02_pipeline import assess_forecast,assess_selector
from l02_report import provenance_coverage
from l02_scoring import load_study
from l02_study_data import StudySource,extract_data,validate_pool,validate_assignment
from material_contract import same_json_value

def main():
    start=time.perf_counter();checks=[]
    def check(name,actual,expected):
        if not same_json_value(actual,expected):raise AssertionError((name,actual,expected))
        checks.append({'name':name,'status':'passed'})
    def response(name,call,code):
        try:call()
        except ExecutionError as e:check(name,e.code,code)
        else:raise AssertionError(name+' expected a named response')
    old=Path('D:/opencorvus-benchmark-runs/l02-generic-execution-qualification-20261030/python-loop')
    sealed=read_archive(old/'registration.zip');reg=archived_json(sealed,'registration.json')
    manifest=archived_json(sealed,'submission/submission.json',True);pool,methods=validate_pool(manifest['pool'])
    with sqlite3.connect((old/'runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
        db.row_factory=sqlite3.Row;rows=[dict(r) for r in db.execute('SELECT * FROM cell ORDER BY id')]
        run_id=db.execute('SELECT id FROM run').fetchone()[0]
    for row in rows:
        accepted=read_archive(old/'cells'/str(row['id'])/'accepted.zip')
        native=archived_json(accepted,'terminal-inspect.json')
        validate_terminal(native,row,manifest['programs'][json.loads(row['identity'])['kind']],reg['image_id'],run_id)
        check('current_native_name_exit_binding_'+str(row['id']),[native['Name'],row['exitcode']],['/'+row['name'],0])
    with tempfile.TemporaryDirectory() as tmp:
        extract_data(sealed,Path(tmp));study=load_study(Path(tmp)/'study.json');data=StudySource(Path(tmp)/'raw',Path(tmp)/'material-contract.json',study)
        forecast=read_archive(old/'cells/1/accepted.zip');identity=json.loads(rows[0]['identity']);method=methods[identity['method_id']]
        check('actual_captured_packet_and_forecast',assess_forecast(forecast,data,identity['origin_id'],method,study),archived_json(forecast,'assessment.json'))
        changed=dict(forecast);meta=archived_json(changed,'input/packet/packet.json');meta['origin_tick']=True
        changed['input/packet/packet.json']=json_bytes(meta)
        response('wrong_captured_origin_named_facility',lambda:assess_forecast(changed,data,identity['origin_id'],method,study),'facility_forecast_packet_invalid')
        changed=dict(forecast);methodvalue=archived_json(changed,'input/method.json');methodvalue['configuration']['weekday_repeats']=True
        changed['input/method.json']=json_bytes(methodvalue)
        response('wrong_captured_method_named_facility',lambda:assess_forecast(changed,data,identity['origin_id'],method,study),'facility_method_binding_invalid')
        selected=read_archive(old/'cells/7/accepted.zip');expected=archived_json(selected,'input/inner.json',True)
        check('actual_captured_selector',assess_selector(selected,expected,study),archived_json(selected,'assessment.json'))
        changed=dict(selected);payload=archived_json(changed,'input/inner.json',True);payload['frames'][0]['labels_released_at']=True
        changed['input/inner.json']=json_bytes(payload)
        response('wrong_captured_selector_named_facility',lambda:assess_selector(changed,expected,study),'facility_selection_binding_invalid')
        check('diagnostic_assignment_classification',validate_assignment(data,reg),False)
        full={**reg,'outer_ids':reg['all_outer_ids'],'assignment_kind':'formal_full_assignment'}
        check('actual_contract_full_assignment',validate_assignment(data,full),True)
    inputs=read_archive(ROOT/'original-numeric-projection.zip');report=read_archive(ROOT/'new-report-only/cells/1/accepted.zip')
    changed=dict(report);value=archived_json(changed,'input/results.json',True);value['candidate_score']=100
    changed['input/results.json']=json_bytes(value)
    response('report_result_drift_named_facility',lambda:provenance_coverage(changed,inputs),'facility_report_results_binding_invalid')
    changed=dict(report);value=archived_json(changed,'input/provenance/manifest.json');value['cells'][0]['execution']['exit_code']=True
    changed['input/provenance/manifest.json']=json_bytes(value)
    response('typed_provenance_drift_named_facility',lambda:provenance_coverage(changed,inputs),'facility_report_provenance_binding_invalid')
    result={'status':'qualified','wall_seconds':time.perf_counter()-start,'checks':checks,
            'scope':'captured input/native/report identity boundaries on original real objects; no new numeric execution'}
    atomic_bytes(ROOT/'bindings-assessment.json',json_bytes(result));print(json.dumps(result))

if __name__=='__main__':main()
