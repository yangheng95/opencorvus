# Sealed daily forecasting study

Author reference report. This report consumes captured numerical outputs and narrow native execution facts. It does not certify the self-reported fitting diagnostics or replace independent scientific review.

Requested outer origins: outer-20250115. Complete registered coverage: False.

## Methods and information timing

The execution contract freezes programmes and configurations before prediction. These report-side numeric records alone do not establish when this report programme was frozen relative to historical numeric cells; that requires the independent registration audit. Each worker is assigned an original CSV release-prefix; highest revision including missing is chosen before valid-value filtering. The reference uses historical seasonal weather imputation. Inner selection uses earlier published inner labels and mean scaled MSE; ties use the method ID. Outer labels reach the report only after numerical acceptance.

| Method | Role | Frozen configuration |
|---|---|---|
| seasonal-weekday | baseline | `{"algorithm": "seasonal_weekday", "weekday_repeats": 8, "train_window_days": 365, "minimum_training_rows": 56, "calibration_days_before": [56, 84, 112], "minimum_calibration_rows": 14}` |
| ridge-weather-operations | extension | `{"algorithm": "ridge", "use_weather": true, "use_operations": true, "ridge_alpha": "1", "train_window_days": 365, "minimum_training_rows": 56, "calibration_days_before": [56, 84, 112], "minimum_calibration_rows": 14}` |
| ridge-no-weather | ablation | `{"algorithm": "ridge", "use_weather": false, "use_operations": true, "ridge_alpha": "1", "train_window_days": 365, "minimum_training_rows": 56, "calibration_days_before": [56, 84, 112], "minimum_calibration_rows": 14}` |

The seasonal method averages up to eight matching weekdays. Ridge uses standardized features, an unpenalized intercept and the frozen alpha; the no-weather ablation removes weather features. Configuration and fitted coefficients are separately located in [fit-index.csv](fit-index.csv) and [fit-records.json](fit-records.json). These are empirical model parameters, not identified causal effects.

Uncertainty uses the recorded earlier pseudo-origins and complete paired leaf residual rows; current operating closures act on whole future sample vectors before hierarchical sums. Means are coherent; marginal quantiles need not sum. This empirical construction gives no finite-sample or joint-path coverage guarantee.

## Out-of-sample results

| Method | Scaled MSE | Scaled WIS |
|---|---:|---:|
| seasonal-weekday | 0.006425043932 | 0.05450524711 |
| ridge-weather-operations | 0.0008236596246 | 0.01242996233 |
| ridge-no-weather | 0.0004747445529 | 0.009169193241 |
| Inner-selected policy | 0.0008236596246 | 0.01242996233 |

[Per-origin metrics](origin-losses.csv) and [all node losses and 80% coverage counts](node-losses.csv) preserve every declared origin and method. The no-weather outer ablation remains a diagnostic; seeing its outer results cannot change the frozen selection pool. A good aggregate loss does not establish local calibration or correct response to a new operating regime.

![Actual selected forecasts and terminal observations](forecast.png)

## Single-period operating decisions

The [operating ledger](operating-ledger.csv) fixes overage cost 1 and shortage costs 1, 3, 9 cost-unit/L before truth, using q=.5, .75, .9 respectively. Actions are continuous litres. Each row records action, later truth, shortage, overage and realized cost. These are separate single-period decisions, not a capacity, inventory, joint-risk or field supply simulation.

## Reproduction and evidence limitations

[Source index](source-index.csv) links actual numeric cell IDs, origin/method, narrowed argv, native start/finish/exit and delivered copies of each original output. [Execution index](execution-index.json) preserves the allowed native facts. Candidate fit statements require source and independent execution audit; a file or timestamp alone does not prove how training occurred. Exact rational tables retain evaluation precision; figure coordinates are plotting floats.

This report is a reproducible research component. Study completion, quality success and benchmark score remain unassessed until the full frozen case and independent rubric review.
