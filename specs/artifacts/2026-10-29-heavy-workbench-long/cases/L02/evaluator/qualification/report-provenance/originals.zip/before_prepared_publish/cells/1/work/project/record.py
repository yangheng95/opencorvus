from pathlib import Path
import json
v=json.loads(Path('/input/value.json').read_text())
Path('/output/result.json').write_text(json.dumps({'consumed':v['value']}))
