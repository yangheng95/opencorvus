"""One authorized report-only cold process. Never starts a numeric predictor."""
import json,shutil,sqlite3,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
Q=Path('D:/opencorvus-benchmark-runs/l02-report-provenance-qualification-20261030')
CASE=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L02/evaluator/current-source')
SNAP=ROOT/'source-executed';shutil.copytree(CASE,SNAP)
assert (SNAP/'report_l02_reference.py').read_bytes()==(Q/'source-reporter-clarified/report_l02_reference.py').read_bytes()
sys.path.insert(0,str(SNAP))
from l02_execution import Ledger,Executor,run_lock,read_archive,archived_json,json_bytes,atomic_bytes
from l02_pipeline import assess_report
from l02_report import provenance_coverage
shutil.copy2(Q/'original-numeric-projection.zip',ROOT/'original-numeric-projection.zip')
inputs=read_archive(ROOT/'original-numeric-projection.zip');numerical=archived_json(inputs,'results.json',True)
old=read_archive(Q/'new-report-only/cells/1/accepted.zip');image=archived_json(old,'terminal-inspect.json')['Image']
run=ROOT/'cold-report';run.mkdir();started=time.perf_counter();events=[]
with run_lock(run):
 ledger=Ledger(run,create=True)
 try:
  def observe(stage,cell):
   events.append({'stage':stage,'cell':cell});atomic_bytes(ROOT/'own-events.json',json_bytes(events))
  program={'files':['report.py'],'argv':['python','report.py']};source={'report.py':(SNAP/'report_l02_reference.py').read_bytes()}
  accepted=Executor(ledger,image,observe).invoke({'kind':'report'},program,source,lambda:inputs,lambda files:assess_report(files,numerical['outer_ids']))
  coverage=provenance_coverage(accepted,inputs)
  cell=dict(ledger.db.execute('select*from cell').fetchone())
 finally:ledger.close()
output=ROOT/'cold-output';output.mkdir()
for name,value in accepted.items():
 if name.startswith('output/'):
  target=output/name[7:];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(value)
native=archived_json(accepted,'terminal-inspect.json')
result={'status':'own_clarified_report_cold_completed','source_report_matches_clarified_snapshot':True,'numeric_processes_started':0,'report_processes_started':1,'candidate_score':None,'full12_executed':False,'cell':cell,'image':image,'actual_state':native['State'],'report_coverage':coverage,'host_seconds':time.perf_counter()-started,'scope':'one report-only component from original numeric projection; not a new forecasting study'}
atomic_bytes(ROOT/'cold-execution.json',json_bytes(result));print(json.dumps(result,ensure_ascii=False))
