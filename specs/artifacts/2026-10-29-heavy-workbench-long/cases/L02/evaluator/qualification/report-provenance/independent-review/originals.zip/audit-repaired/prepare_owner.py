import argparse
import json
import os
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'source-reporter-clarified'))
from l02_execution import Ledger, Executor, atomic_bytes, json_bytes, archived_json, run_lock

parser=argparse.ArgumentParser();parser.add_argument('--run',type=Path,required=True)
parser.add_argument('--value',required=True);parser.add_argument('--stop-stage');a=parser.parse_args()
a.run.mkdir(parents=True,exist_ok=True)
ledger=Ledger(a.run,create=not (a.run/'runs.sqlite3').exists())
image='sha256:23ff8bfbf8055caa0b9fa5745ddb27cceea2f31d7d15b7a900c81112cdfe8ddf'
program={'files':['record.py'],'argv':['python','record.py']}
source={'record.py':b"from pathlib import Path\nimport json\nv=json.loads(Path('/input/value.json').read_text())\nPath('/output/result.json').write_text(json.dumps({'consumed':v['value']}))\n"}
def inputs():
    path=a.run/'input-preparation-history.json'
    history=json.loads(path.read_text()) if path.exists() else []
    history.append({'value':a.value})
    atomic_bytes(path,json_bytes(history))
    return {'value.json':json_bytes({'value':a.value})}
def observe(stage,cell):
    if stage==a.stop_stage:
        atomic_bytes(a.run/'owner-exit.json',json_bytes({'stage':stage,'cell':cell,'requested_value':a.value}))
        os._exit(73)
try:
    with run_lock(a.run):
        accepted=Executor(ledger,image,observe).invoke({'kind':'report'},program,source,inputs,
            lambda files:{'consumed':archived_json(files,'output/result.json')['consumed']})
    print(json.dumps({'status':'verified','actual':archived_json(accepted,'output/result.json')}))
finally:ledger.close()
