"""Read-only component/source/receipt audit. Does not invoke any executor."""
import csv,io,json,runpy,shutil,sqlite3,sys,time,zipfile
from pathlib import Path,PurePosixPath
from fractions import Fraction as F
ROOT=Path(__file__).resolve().parent
Q=Path('D:/opencorvus-benchmark-runs/l02-report-provenance-qualification-20261030')
OLD=Path('D:/opencorvus-benchmark-runs/l02-generic-execution-qualification-20261030/python-loop')
OUT=ROOT/'audit-repaired';OUT.mkdir(exist_ok=False)
sys.path.insert(0,str(ROOT/'source-executed'))
from l02_sealed import read_completed
from l02_execution import read_archive,archived_json
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def save(n,v):(OUT/n).write_text(json.dumps(v,ensure_ascii=False,indent=2,default=str)+'\n',encoding='utf-8')
def csvrows(p):return list(csv.DictReader(p.open(encoding='utf-8',newline='')))
checks=[]
def ck(n,v,detail=None):checks.append({'name':n,'passed':bool(v),'detail':detail})
for n in ['reader-first.json','preparation-assessment.json','bindings-assessment.json','prepare_owner.py','qualify_preparation.py','qualify_bindings.py','report-clarification.json']:
 shutil.copy2(Q/n,OUT/n)
before=(OLD/'cells/11/accepted.zip').read_bytes();summary=load(ROOT/'audit/old-reader-summary.json');numerical=archived_json(read_archive(OLD/'cells/11/accepted.zip'),'input/results.json',True);reader_seconds=None
ck('readonly_single_reader_old_report_not_delivered',summary['report_provenance']['status']=='not_delivered'and summary['forecast_cells']==9 and summary['verified_cells']==11 and summary['formal_full_assignment']is False and summary['candidate_score']is None)
ck('old_accepted_original_bytes_retained_after_reader',before==(OLD/'cells/11/accepted.zip').read_bytes())
save('old-reader-summary.json',summary)
inputs=read_archive(ROOT/'original-numeric-projection.zip');manifest=archived_json(inputs,'provenance/manifest.json');num=archived_json(inputs,'results.json',True)
ck('projection_results_exact_numerical_semantics',num==numerical)
db=sqlite3.connect((OLD/'runs.sqlite3').as_uri()+'?mode=ro',uri=True);db.row_factory=sqlite3.Row;rows={r['id']:dict(r)for r in db.execute('select*from cell')};schema=[tuple(r)for r in db.execute("select sql from sqlite_master where sql is not null order by name")];db.close()
def argv_projection(argv,declared):
 out=[]
 for i,v in enumerate(argv):
  if i==0:
   b=PurePosixPath(v).name;safe=('\\'not in v and ':'not in v and b not in ('','.','..'));out.append({'position':i,'kind':'executable_basename'if safe else'opaque','value':b if safe else None})
  elif v in declared:out.append({'position':i,'kind':'declared_source','value':v})
  else:
   p=PurePosixPath(v);safe=p.is_absolute()and len(p.parts)>1 and p.parts[1]in ['project','input','output','tmp']and str(p)==v and all(':'not in s and '\\'not in s and s!='..'for s in p.parts);out.append({'position':i,'kind':'sandbox_path'if safe else'opaque','value':v if safe else None})
 return out
allowed={'results.json','provenance/manifest.json'};source_map={};natives={};fit_count=0
for entry in manifest['cells']:
 cid=entry['cell_id'];row=rows[cid];actual=read_archive(OLD/'cells'/str(cid)/'accepted.zip');prepared=read_archive(OLD/'cells'/str(cid)/'prepared.zip');native=archived_json(actual,'terminal-inspect.json');prog=archived_json(actual,'program.json');natives[cid]=native
 ck('numeric_identity_'+str(cid),entry['identity']==json.loads(row['identity'])and row['phase']=='verified'and entry['identity']['kind']in ['predict','select'])
 ex={'argv_projection':argv_projection([native['Path'],*native['Args']],prog['files']),'declared_source_files':prog['files'],'started_at':native['State']['StartedAt'],'finished_at':native['State']['FinishedAt'],'status':native['State']['Status'],'exit_code':native['State']['ExitCode']}
 ck('native_positive_projection_'+str(cid),entry['execution']==ex and set(entry)=={'cell_id','identity','execution','artifacts'})
 actualoutputs={n[7:]:v for n,v in actual.items()if n.startswith('output/')};got={}
 for artifact in entry['artifacts']:
  key=artifact['output_member'];path='provenance/files/'+str(cid)+'/'+key;allowed.add(path);got[key]=inputs[artifact['input_path']];source_map['sources/'+str(cid)+'/'+key]=inputs[path]
  ck('artifact_'+str(cid)+'_'+key,artifact=={'output_member':key,'input_path':path,'bytes':len(actualoutputs[key]),'origin':'candidate_program_output_not_independently_verified_claim'}and inputs[path]==actualoutputs[key])
 ck('only_candidate_outputs_'+str(cid),got==actualoutputs)
ck('exact_narrow_export_inventory_10cells19outputs',len(manifest['cells'])==10 and set(inputs)==allowed and len(source_map)==19 and set(manifest)=={'format','cells','scope'}and manifest['format']=='l02-report-provenance/1')
reg=read_archive(OLD/'registration.zip');registration=archived_json(reg,'registration.json');decl=archived_json(reg,'submission/submission.json',True);origins=list(csv.DictReader(io.StringIO(reg['raw/origins.csv'].decode())))
expected=set()
for outer in registration['outer_ids']:
 for r in origins:
  if r['role']=='inner'and r['outer_id']==outer:
   for m in decl['pool']['selection_ids']:expected.add(('predict',outer,r['origin_id'],m,'inner'))
 expected.add(('select',outer,'','',''))
 for m in decl['pool']['outer_ids']:expected.add(('predict',outer,outer,m,'outer'))
observed={tuple(c['identity'].get(k,'')for k in ['kind','outer_id','origin_id','method_id','level'])for c in manifest['cells']};ck('numeric_export_exact_assigned_roles',observed==expected)

cold=ROOT/'cold-report';accepted=read_archive(cold/'cells/1/accepted.zip');terminal=read_archive(cold/'cells/1/terminal.zip');prepared=read_archive(cold/'cells/1/prepared.zip');native=archived_json(accepted,'terminal-inspect.json');commands=[load(p)for p in(cold/'cells/1').glob('*.json')];created=[r for r in commands if r['argv'][1:2]==['create']];started=[r for r in commands if r['argv'][1:2]==['start']];removed=[r for r in commands if r['argv'][1:2]==['rm']]
ck('one_own_report_create_start_remove_natural_exit',len(created)==len(started)==len(removed)==1 and created[0]['stdout'].strip()==native['Id']and started[0]['argv']==['docker','start',native['Id']]and removed[0]['argv']==['docker','rm',native['Id']]and all(r['exitcode']==0 for r in created+started+removed)and native['State']['Status']=='exited'and native['State']['ExitCode']==0)
ck('own_report_actual_readonly_mounts_resources',native['HostConfig']['NetworkMode']=='none'and native['HostConfig']['NanoCpus']==10**9 and native['HostConfig']['ReadonlyRootfs']and {m['Destination']:m['RW']for m in native['Mounts']}=={'/project':False,'/input':False,'/output':True})
ck('own_report_original_prepared_input_and_clarified_source',{n[6:]:v for n,v in prepared.items()if n.startswith('input/')}==inputs and prepared['project/report.py']==(Q/'source-reporter-clarified/report_l02_reference.py').read_bytes()and all(terminal[k]==v for k,v in prepared.items())and all(accepted[k]==v for k,v in terminal.items()))
db=sqlite3.connect((cold/'runs.sqlite3').as_uri()+'?mode=ro',uri=True);current_schema=[tuple(r)for r in db.execute("select sql from sqlite_master where sql is not null order by name")];events=[(r[0],r[1])for r in db.execute('select kind,facts from event order by id')];ck('same_SQLite_baseline1_no_new_persistent_fields',current_schema==schema and db.execute('pragma user_version').fetchone()[0]==1);db.close();ck('own_terminal_accepted_before_verified_cleanup',events[-2][0]=='lifecycle'and json.loads(events[-2][1])['phase']=='verified'and events[-1][0]=='cleanup_confirmed')
out=ROOT/'cold-output/result';ck('all19_original_candidate_outputs_copied_into_report',all((out/p).read_bytes()==v for p,v in source_map.items()))
fitrows=csvrows(out/'fit-index.csv');fitchecks=[]
for r in fitrows:
 f=json.loads(source_map[r['source']],parse_float=F);n=f['fit'][r['series_id']];given=json.loads(r['coefficient']);coefficient_equal=(given is None and n['coefficient']is None)if n['coefficient']is None else given is not None and [F(x)for x in given]==[F(x)for x in n['coefficient']];fitchecks.append(int(r['training_rows'])==n['training_rows']and int(r['training_end_tick'])==n['maximum_training_event_tick']and int(r['paired_residual_rows'])==f['paired_residual_rows']and json.loads(r['features'])==n['features']and coefficient_equal and json.loads(r['calibration_origins'])==[x['origin_tick']for x in f['calibration']])
ck('36_fit_records_exact_original_diagnostics',len(fitrows)==36 and all(fitchecks))

# Independent report arithmetic, no call to reporter's wis or evaluator's score.
nodechecks=[];macrochecks=[];actionchecks=[];nodecsv=csvrows(out/'node-losses.csv');actcsv=csvrows(out/'operating-ledger.csv')
for outer in num['outer_results']:
 tr={(r['series_id'],r['target_tick']):F(r['value'])for r in outer['labels']};context=outer['context']
 for m,fc in outer['forecasts'].items():
  for node in context['series_catalogue']:
   s=node['series_id'];rr=[r for r in fc['forecasts']if r['series_id']==s];scale=F(context['scales_litres'][s]);mse=F();wis=F();hits=0
   for r in rr:
    y=tr[s,r['target_tick']];q={F(k):F(v)for k,v in r['quantiles'].items()};mse+=((F(r['mean'])-y)/scale)**2;v=abs(y-q[F(1,2)])/2
    for a in [F(1,2),F(1,5),F(1,20)]:
     lo,hi=q[a/2],q[1-a/2];v+=a/2*(hi-lo+2/a*max(lo-y,F())+2/a*max(y-hi,F()))
    wis+=v/F(7,2)/scale;hits+=q[F(1,10)]<=y<=q[F(9,10)]
   r=next(r for r in nodecsv if(r['outer_id'],r['method_id'],r['series_id'])==(outer['outer_id'],m,s));nodechecks.append(F(r['scaled_mse'])==mse/14 and F(r['scaled_wis'])==wis/14 and int(r['central80_hits'])==hits and int(r['assigned_days'])==14)
 selected=outer['forecasts'][outer['selected_method_id']];by={(r['series_id'],r['target_tick']):r for r in selected['forecasts']}
 for r in actcsv:
  if r['outer_id']!=outer['outer_id']:continue
  s,t=r['series_id'],int(r['target_tick']);a=F(by[s,t]['quantiles'][r['frozen_quantile']]);y=tr[s,t];under=max(y-a,F());over=max(a-y,F());cost=int(r['shortage_cost_unit_per_L'])*under+int(r['overage_cost_unit_per_L'])*over;actionchecks.append(F(r['action_L'])==a and F(r['truth_L'])==y and F(r['shortage_L'])==under and F(r['overage_L'])==over and F(r['loss_cost_units'])==cost)
ck('all18_new_node_WIS_MSE_coverage_rows_independent',len(nodechecks)==18 and all(nodechecks));ck('all168_new_operating_rows_independent',len(actionchecks)==168 and all(actionchecks))
report=(out/'report.md').read_text();ck('actual_report_explicit_reporter_freeze_limit','do not establish when this report programme was frozen'in report and 'self-reported fitting diagnostics'in report)

# Existing genuine publication-crash controls, read only; no new process started.
recovery=[]
for stage,expected_value,historyn in [('before_prepared_publish','second',2),('prepared_published','first',1)]:
 run=Q/stage;job=run/'cells/1';a=read_archive(job/'accepted.zip');p=read_archive(job/'prepared.zip');o=load(run/'owner-exit.json');hist=load(run/'input-preparation-history.json');owner=load(Q/(stage+'-owner.json'));resume=load(Q/(stage+'-resume.json'));nat=archived_json(a,'terminal-inspect.json');r=[load(p)for p in job.glob('*.json')]
 ck(stage+'_actual_exit73_planned_no_CID',owner['exitcode']==73 and o['stage']==stage and o['cell']['phase']=='planned'and o['cell']['cid']is None)
 ck(stage+'_original_input_consumed_and_factory_count',resume['exitcode']==0 and len(hist)==historyn and archived_json(p,'input/value.json')=={'value':expected_value}and archived_json(a,'output/result.json')=={'consumed':expected_value})
 for operation in ['create','start','rm']:
  selected=[x for x in r if x['argv'][1:2]==[operation]];ck(stage+'_one_'+operation,len(selected)==1 and selected[0]['exitcode']==0)
 recovery.append({'stage':stage,'cid':nat['Id'],'owner_cell_at_crash':o['cell'],'consumed':expected_value,'preparations':len(hist),'argv_receipt_limit':'owner/resume argv contains common prefix only; value/stop arguments established by executed harness plus owner-exit/history, not recorded complete argv'})
copy=Q/'historical-report-copy';copied=read_archive(copy/'cells/11/accepted.zip');ck('old_verified_copy_exact_original_accepted',copied==read_archive(OLD/'cells/11/accepted.zip'))
save('checks.json',checks);save('fit-checks.json',fitchecks);save('table-checks.json',{'node_rows':len(nodechecks),'node_all_passed':all(nodechecks),'action_rows':len(actionchecks),'action_all_passed':all(actionchecks)});save('publication-recovery-facts.json',recovery)
result={'checks':len(checks),'all_passed':all(r['passed']for r in checks),'failed':[r['name']for r in checks if not r['passed']],'readonly_old_reader_seconds':reader_seconds,'reader_result_reused_after_reviewer_null_coefficient_fix':True,'reader_source_result':'audit/old-reader-summary.json from completed original read_completed call; wrapper later TypeError; exact standalone reader timing not saved','numeric10_reexecuted':False,'new_report_processes_total':1,'new_forecasts_Docker_other_than_own_report':0,'actual_new_PNG_viewed':True,'full12':False,'candidate_score':None,'L02_frozen':False};save('assessment.json',result);print(json.dumps(result,ensure_ascii=False))
