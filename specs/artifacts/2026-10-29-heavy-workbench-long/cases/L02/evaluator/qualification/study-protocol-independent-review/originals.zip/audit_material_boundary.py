"""New boundary delta only: no builder, decoder, forecast or Docker run."""
import ast
from collections import Counter,defaultdict
import csv
from datetime import datetime,timedelta,timezone
from decimal import Decimal
from fractions import Fraction
import importlib.util
import json
from pathlib import Path
import re
import shutil
import sqlite3
import time
import zipfile

ROOT=Path(__file__).resolve().parent
MAIN=Path('D:/opencorvus-benchmark-runs/l02-study-material-boundary-20261030')
OLD=Path('D:/opencorvus-benchmark-runs/l02-full-materials-20261030/main')
PREV=Path('D:/opencorvus-benchmark-runs/l02-full-materials-independent-review-20261030')
CASE=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L02')
OUT=ROOT/'material-boundary-addendum';OUT.mkdir(exist_ok=True)
SNAP=OUT/'snapshot'
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
start=time.perf_counter()
for name in ['source','materials','decoded-archive','decoded-development','six-development-projections']:
    shutil.copytree(MAIN/name,SNAP/name)
for p in MAIN.glob('*.json'):shutil.copy2(p,SNAP/p.name)
for p in MAIN.glob('*.py'):shutil.copy2(p,SNAP/p.name)
pub=OUT/'public-current';pub.mkdir()
for p in (CASE/'public').iterdir():
    if p.is_file():shutil.copy2(p,pub/p.name)
code=(PREV/'audit_materials.py').read_text(encoding='utf-8')
names={'load','table','utc','tick','read_independently'}
nodes=[v for v in ast.parse(code).body if isinstance(v,ast.FunctionDef)and v.name in names]
EPOCH=datetime(2022,1,1,tzinfo=timezone.utc)
(OUT/'reviewer_csv_oracle.py').write_text('\n\n'.join(ast.get_source_segment(code,v)for v in nodes)+'\n',encoding='utf-8')
exec(compile(ast.Module(body=nodes,type_ignores=[]),'reviewer_csv_oracle','exec'),globals())
checks=[]
def ck(n,v,d=None):checks.append({'name':n,'passed':bool(v),'detail':d})
for name in ['build','decode-archive','decode-development']:
    receipt=load(SNAP/(name+'-command.json'));observed=json.loads(receipt['stdout'])
    ck('actual_root_'+name+'_terminal',receipt['exitcode']==0 and not receipt['stderr']and observed['status']=='materials_decoded'if name!='build'else receipt['exitcode']==0 and observed['format']=='l02-material-construction/1',receipt)
full=SNAP/'materials/full-private';dev=SNAP/'materials/development-public'
for name in ['observations.csv','covariate-vintages.csv','series.csv','hierarchy.csv','availability.json','units.json']:
    ck('full_unchanged_inherited_'+name,(full/name).read_bytes()==(OLD/'materials-final/full-private'/name).read_bytes())
raw=load(SNAP/'decoded-archive/canonical.json');oldraw=load(OLD/'decoded-final-archive/canonical.json')
ck('entire_old_independently_checked_full_canonical_inherited',raw==oldraw)
development,drows,catalogue=read_independently(dev)
ck('new_public_rows_independent_Fraction_UTC_unit_decode',development==load(SNAP/'decoded-development/canonical.json'),{'observations':len(development['observations']),'covariates':len(development['covariates'])})
cut=tick('2024-08-01T09:00:00Z')
expected={**raw,'observations':[r for r in raw['observations']if r['release_tick']<=cut],'covariates':[r for r in raw['covariates']if r['release_tick']<=cut]}
ck('public_is_exact_complete_new_release_subset',development==expected and len(development['observations'])==6823 and len(development['covariates'])==21934)
grid=load(SNAP/'decoded-archive/origin-grid.json');oldgrid=load(OLD/'decoded-final-archive/origin-grid.json');before={r['origin_id']:r for r in oldgrid['origins']};after={r['origin_id']:r for r in grid['origins']}
inherited=[r for r in grid['origins']if r['role']!='development'];new=[r for r in grid['origins']if r['role']=='development']
ck('same48inner_outer_objects_no_repeat_projection',len(inherited)==48 and all(before[r['origin_id']]==r for r in inherited))
ck('six2023exploration_ids_exact',len(new)==6 and {r['origin_id']for r in new}=={'dev-2023'+str(m).zfill(2)+'15'for m in range(6,12)})
contract=load(SNAP/'source/material-contract.json')
ck('sole_contract_and_input_clocks_new_cutoff',contract==load(CASE/'evaluator/material-contract.json')and contract['clock']['development_cutoff_utc']=='2024-08-01T09:00:00Z'and load(full/'time-axis.json')==load(dev/'time-axis.json')==contract['clock']and contract['schedule']['development_dates']==['2023-'+str(m).zfill(2)+'-15'for m in range(6,12)])
ck('all36inner_strictly_after_public_boundary',min(r['origin_tick']for r in inherited if r['role']=='inner')>cut)
zipfacts=[]
with zipfile.ZipFile(pub/'development-materials.zip')as z:
    members=[n for n in z.namelist()if not n.endswith('/')]
    for p in dev.iterdir():
        found=[n for n in members if n==p.name or n.endswith('/'+p.name)]
        zipfacts.append({'file':p.name,'members':found,'same_bytes':len(found)==1 and z.read(found[0])==p.read_bytes()})
ck('actual_public_zip_is_same_eight_material_files',len(members)==len(zipfacts)==8 and all(r['same_bytes']for r in zipfacts),zipfacts)
spec=importlib.util.spec_from_file_location('new_boundary_unique_core',SNAP/'source/asof_input.py');core=importlib.util.module_from_spec(spec);spec.loader.exec_module(core)
ck('core_unchanged_from_qualified_material_projection',(SNAP/'source/asof_input.py').read_bytes()==(PREV/'source-final/asof_input.py').read_bytes())
sql=sqlite3.connect(':memory:');sql.execute('CREATE TABLE facts(kind TEXT,idx INTEGER,id TEXT,t INTEGER,rev INTEGER,release INTEGER,future INTEGER)')
for kind,idkey,tkey in [('observations','series_id','event_tick'),('covariates','variable_id','valid_tick')]:
    sql.executemany('INSERT INTO facts VALUES(?,?,?,?,?,?,?)',[(kind,i,r[idkey],r[tkey],r['revision_id'],r['release_tick'],int(kind=='covariates'and raw['variables'][r[idkey]]['availability']=='known_future'))for i,r in enumerate(raw[kind])])
leaves={r['series_id']for r in grid['series_catalogue']if r['kind']=='leaf'}
ck('only_four_leaf_raw_sources_for_terminal_labels',leaves=={'A1','A2','B1','B2'}and {r['series_id']for r in raw['observations']}==leaves)
terminal={(r['series_id'],r['event_tick']):r for r in raw['observations']if r['revision_id']==2}
six=[]
for r in new:
    origin=utc(r['cutoff_utc']);ends=[origin.replace(hour=0)+timedelta(days=2+i)for i in range(14)]
    labels=[terminal[s,int((end-EPOCH).total_seconds())//3600]for s in leaves for end in ends]
    ck('actual_new_grid_and_public_terminal_labels_'+r['origin_id'],r['target_end_utc']==[v.strftime('%Y-%m-%dT%H:%M:%SZ')for v in ends]and r['target_ticks']==[int((v-EPOCH).total_seconds())//3600 for v in ends]and r['actual_last_label_release_tick']==max(v['release_tick']for v in labels)and all(v['quality_flag']=='valid'and v['release_tick']<=cut for v in labels))
    o=r['origin_tick'];permitted={'format':'l02-asof-snapshot/1','origin':o,'horizon':14,'series':raw['series'],'variables':raw['variables']}
    for kind in ['observations','covariates']:
        permitted[kind]=[raw[kind][i[0]]for i in sql.execute('SELECT idx FROM facts WHERE kind=? AND release<=? AND (future=1 OR t<?) ORDER BY id,t,rev',(kind,o,o))]
    actual=core.project(raw,o,14);ck('new_actual_core_vs_independent_SQL_'+r['origin_id'],actual==permitted)
    save(OUT/'six-core-snapshots'/(r['origin_id']+'.json'),actual)
    six.append({'origin_id':r['origin_id'],'observations':len(actual['observations']),'covariates':len(actual['covariates']),'first_start_hours_after_origin':(ends[0]-timedelta(days=1)-origin).total_seconds()/3600})
sql.close()
scale_rows=[r for r in raw['observations']if r['revision_id']==2 and tick('2023-01-02T00:00:00Z')<=r['event_tick']<=tick('2024-01-01T00:00:00Z')]
ck('1460_actual_scale_terminal_rows_prior_published_cutoff',len(scale_rows)==1460 and all(r['quality_flag']=='valid'and r['release_tick']<=tick('2024-02-01T09:00:00Z')for r in scale_rows))
scales={s:max(Fraction(1),sum(Fraction(r['value'])for r in scale_rows if r['series_id']==s)/365)for s in leaves}
for parent in {r['series_id']for r in grid['series_catalogue']if r['kind']=='aggregate'}:
    scales[parent]=max(Fraction(1),sum(Fraction(e['weight'])*sum(Fraction(r['value'])for r in scale_rows if r['series_id']==e['child'])/365 for e in grid['hierarchy']if e['parent']==parent))
ck('all6scales_equal_prior_independent_raw_Fraction_values',{k:str(v)for k,v in scales.items()}==load(ROOT/'hand-calculations.json')['actual_fixed2023_scales'])
ck('scale_visibility_public_contract_explicit','不能作为2023预测worker' in(pub/'STUDY-CONTRACT.draft.md').read_text(encoding='utf-8')and load(SNAP/'source/study-contract.draft.json')['scale_visibility']=='evaluator and selectors at or after published_by_utc; never earlier forecast workers')
identity=[]
for p in (SNAP/'source').glob('*.py'):identity.append({'name':p.name,'same_current_bytes':p.read_bytes()==(CASE/'evaluator/current-source'/p.name).read_bytes()})
ck('all9_current_source_objects_match_archived_execution',len(identity)==9 and all(r['same_current_bytes']for r in identity),identity)
save(OUT/'checks.json',checks);save(OUT/'six-origin-receipts.json',six)
assessment={'scope':'New public cutoff and six exploration grids/material delta only; no builder/decoder/old48 rerun or forecast worker/selector/full study.','checks':len(checks),'all_passed':all(c['passed']for c in checks),'failed':[c['name']for c in checks if not c['passed']],'actual_new_core_calls':6,'inherited_inner_outer_projections_not_rerun':48,'development_observations':len(development['observations']),'development_covariates':len(development['covariates']),'scales_litres':{k:str(v)for k,v in scales.items()},'public_zip_files':len(zipfacts),'source_identity':identity,'seconds':time.perf_counter()-start,'first_author_script_failure_preserved_in_snapshot':True,'candidate_score':None,'full_L02_or_freeze_approved':False,'new_solver_Docker_Provider_forecast_calls':0}
save(OUT/'stage-assessment.json',assessment);print(json.dumps({k:v for k,v in assessment.items()if k!='source_identity'},ensure_ascii=False))
