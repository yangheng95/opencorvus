"""Six cheap independent scorer CLIs; never forecast/model/worker/solver."""
import copy
from fractions import Fraction
import json
from pathlib import Path
import shutil
import subprocess
import time

ROOT=Path(__file__).resolve().parent
CASE=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L02')
FIX=Path('D:/opencorvus-benchmark-runs/l02-study-metric-qualification-20261030/hierarchy-nonunit-scale')
SRC=ROOT/'scorer-source-initial';SRC.mkdir(exist_ok=True)
for n in ['l02_scoring.py','material_contract.py','asof_input.py']:shutil.copy2(CASE/'evaluator/current-source'/n,SRC/n)
shutil.copy2(CASE/'evaluator/study-contract.draft.json',SRC/'study-contract.json')
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
context=read(FIX/'context.json');forecast=read(FIX/'forecast.json');labels=read(FIX/'labels.json');study=read(SRC/'study-contract.json')
results=[];started=time.perf_counter()
def cli(name,c=context,f=forecast,l=labels,s=study,raw_forecast=None,expected=None):
    folder=ROOT/'scorer-probes'/name;folder.mkdir(parents=True,exist_ok=False)
    for n,v in [('context',c),('forecast',f),('labels',l),('study',s)]:save(folder/(n+'.json'),v)
    if raw_forecast is not None:(folder/'forecast.json').write_text(raw_forecast,encoding='utf-8')
    argv=['C:/Python314/python.exe','-X','utf8','-B',str(SRC/'l02_scoring.py'),'--study',str(folder/'study.json'),'--context',str(folder/'context.json'),'--labels',str(folder/'labels.json'),'--forecast',str(folder/'forecast.json'),'--method-id','declared','--out',str(folder/'actual.json')]
    at=time.perf_counter();p=subprocess.run(argv,cwd=SRC,capture_output=True,text=True,encoding='utf-8',timeout=15)
    (folder/'stdout.txt').write_text(p.stdout,encoding='utf-8');(folder/'stderr.txt').write_text(p.stderr,encoding='utf-8')
    receipt={'argv':argv,'exit_code':p.returncode,'seconds':time.perf_counter()-at};save(folder/'command.json',receipt)
    actual=read(folder/'actual.json')if(folder/'actual.json').exists()else None
    record={'probe':name,**receipt,'expected':expected,'actual':actual,'output_exists':actual is not None}
    results.append(record);return actual

a=cli('normal_nonunit_2_5_10',expected={'status':'forecast_assessed','mse':'27/100','mae':'7/20','wis':'5/28'})
assert a['metrics_exact']=={'scaled_mse':'27/100','scaled_mae':'7/20','scaled_wis':'5/28'}
c=copy.deepcopy(context);c['scales_litres']={'A':2,'B':4,'Z':6}
a=cli('independent_nonunit_2_4_6',c=c,expected={'status':'forecast_assessed','mse':'11/36','mae':'5/12','wis':'19/84'})
assert a['metrics_exact']=={'scaled_mse':'11/36','scaled_mae':'5/12','scaled_wis':'19/84'}
raw=json.dumps(forecast).replace('"mean": 12','"mean": 1e9999999999999999999',1)
assert '1e9999999999999999999'in raw
cli('unrepresentable_decimal_exponent',raw_forecast=raw,expected={'status':'prediction_invalid','exit_code':2,'machine_receipt':True})
s=copy.deepcopy(study);s['interval_metric']='raw_wis'
cli('inconsistent_declared_interval_metric',s=s,expected={'status':'run_invalid','error':'facility_study_invalid','exit_code':3})
c=copy.deepcopy(context);c['target_ticks']=[48,72]
f=copy.deepcopy(forecast);l=copy.deepcopy(labels)
for original in forecast['forecasts']:
    row=copy.deepcopy(original);row['target_tick']=72;f['forecasts'].append(row)
for original in labels:
    row=copy.deepcopy(original);row['target_tick']=72;l.append(row)
a=cli('complete_two_target_grid',c=c,f=f,l=l,expected={'status':'forecast_assessed','rows':6,'mse':'27/100'})
assert a['rows']==6 and a['metrics_exact']['scaled_mse']=='27/100'
f=copy.deepcopy(f);f['forecasts'].pop()
a=cli('one_missing_target_of_six',c=c,f=f,l=l,expected={'status':'prediction_incomplete','error':'prediction_incomplete','exit_code':2})
assert a['status']=='prediction_incomplete'and a['error']=='prediction_incomplete'
save(ROOT/'scorer-probe-assessment-initial.json',{'actual_CLI_count':len(results),'seconds':time.perf_counter()-started,'results':results,'new_worker_solver_Docker_Provider_calls':0,'scope':'Local scorer arithmetic/protocol only; no selector or forecast research execution.'})
print(json.dumps({'actual_CLI_count':len(results),'seconds':time.perf_counter()-started,'statuses':[{'probe':r['probe'],'exit_code':r['exit_code'],'status':r['actual']['status']if r['actual']else None,'error':r['actual'].get('error')if r['actual']else None}for r in results]},ensure_ascii=False))
