"""Recheck only the original wrong metric declaration and nonunit success."""
import json
from pathlib import Path
import shutil
import subprocess
import time
ROOT=Path(__file__).resolve().parent
CURRENT=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L02/evaluator')
SRC=ROOT/'scorer-source-repaired';SRC.mkdir(exist_ok=False)
for name in ['l02_scoring.py','material_contract.py','asof_input.py']:shutil.copy2(CURRENT/'current-source'/name,SRC/name)
shutil.copy2(CURRENT/'study-contract.draft.json',SRC/'study-contract.json')
records=[];started=time.perf_counter()
for oldname,newname,expected,code in [('inconsistent_declared_interval_metric','raw_wis_original','run_invalid',3),('independent_nonunit_2_4_6','nonunit_correct','forecast_assessed',0)]:
    old=ROOT/'scorer-probes'/oldname;out=ROOT/'scorer-probes-repaired'/newname;out.mkdir(parents=True,exist_ok=False)
    for name in ['context.json','forecast.json','labels.json','study.json']:shutil.copy2(old/name,out/name)
    argv=['C:/Python314/python.exe','-X','utf8','-B',str(SRC/'l02_scoring.py'),'--study',str(out/'study.json'),'--context',str(out/'context.json'),'--labels',str(out/'labels.json'),'--forecast',str(out/'forecast.json'),'--method-id','declared','--out',str(out/'actual.json')]
    before=time.perf_counter();p=subprocess.run(argv,cwd=SRC,capture_output=True,text=True,encoding='utf-8',timeout=15)
    (out/'stdout.txt').write_text(p.stdout,encoding='utf-8');(out/'stderr.txt').write_text(p.stderr,encoding='utf-8')
    receipt={'argv':argv,'exit_code':p.returncode,'seconds':time.perf_counter()-before};(out/'command.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    result=json.loads((out/'actual.json').read_text(encoding='utf-8'))
    ok=p.returncode==code and result['status']==expected and (result.get('error')=='facility_study_invalid'if code else result['metrics_exact']=={'scaled_mse':'11/36','scaled_mae':'5/12','scaled_wis':'19/84'})
    records.append({'name':newname,**receipt,'actual':result,'passed':ok,'same_original_probe_input_bytes':all((old/name).read_bytes()==(out/name).read_bytes()for name in ['context.json','forecast.json','labels.json','study.json'])})
identity=[{'name':n,'same_current_bytes':(SRC/n).read_bytes()==(CURRENT/('study-contract.draft.json'if n=='study-contract.json'else'current-source/'+n)).read_bytes()}for n in ['l02_scoring.py','material_contract.py','asof_input.py','study-contract.json']]
assessment={'actual_CLI':2,'all_passed':all(r['passed']and r['same_original_probe_input_bytes']for r in records),'records':records,'source_identity':identity,'seconds':time.perf_counter()-started,'scope':'Original P2 wrong declaration plus necessary correct nonunit metric; not repeat of6CLI/material/worker.'}
(ROOT/'scorer-repair-assessment.json').write_text(json.dumps(assessment,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'actual_CLI':2,'all_passed':assessment['all_passed'],'source_same_current':all(r['same_current_bytes']for r in identity),'seconds':assessment['seconds']},ensure_ascii=False))
