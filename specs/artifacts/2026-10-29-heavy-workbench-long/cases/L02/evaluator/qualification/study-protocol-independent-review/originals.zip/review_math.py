"""Plan review arithmetic only: no worker, forecast, solver or container."""
import csv
from datetime import date, datetime, time, timedelta, timezone
from fractions import Fraction as F
import json
from pathlib import Path
import shutil
import subprocess
import time as timer

ROOT=Path(__file__).resolve().parent
REPO=Path('D:/myhexin-local/opencorvus')
CASE=REPO/'specs/artifacts/2026-10-29-heavy-workbench-long/cases/L02'
MATERIAL=Path('D:/opencorvus-benchmark-runs/l02-full-materials-20261030/main/materials-final/full-private')
ROOT.mkdir(parents=True,exist_ok=True)
def save(name,v):(ROOT/name).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def utc(s):return datetime.fromisoformat(s.replace('Z','+00:00'))
def txt(d):return d.isoformat().replace('+00:00','Z')
snapshot=ROOT/'snapshot';snapshot.mkdir(exist_ok=True)
for source,name in [(REPO/'specs/records/2026-10/2026-10-30-heavy-workbench-l02-qualification.md','record-reviewed.md'),(CASE/'public/MATERIALS.draft.md','MATERIALS-before-proposed-revision.md'),(CASE/'evaluator/material-contract.json','material-contract-before-proposed-revision.json'),(MATERIAL/'observations.csv','actual-observations.csv'),(MATERIAL/'origins.csv','actual-origins-before-proposed-revision.csv'),(MATERIAL/'units.json','actual-units.json')]:
    shutil.copy2(source,snapshot/name)
status=subprocess.run(['git','status','--short'],cwd=REPO,capture_output=True,text=True,encoding='utf-8');(ROOT/'git-status-start.txt').write_text(status.stdout+status.stderr,encoding='utf-8')
start=timer.perf_counter()
checks=[]
def ck(n,v,d=None):checks.append({'name':n,'passed':bool(v),'detail':d})
def interval(y,lo,hi,a):return hi-lo+2/a*(lo-y if y<lo else y-hi if y>hi else 0)
def wis(y,m,intervals):
    terms=[F(1,2)*abs(m-y)]+[a/2*interval(y,lo,hi,a)for a,lo,hi in intervals]
    return sum(terms)/(F(len(intervals))+F(1,2)),terms
A=[(F(1,2),F(8),F(12)),(F(1,5),F(5),F(15)),(F(1,20),F(0),F(20))]
Z=[(F(1,2),F(27),F(33)),(F(1,5),F(20),F(40)),(F(1,20),F(0),F(60))]
B=[(a,F(20),F(20))for a,_,_ in A]
WA,termsA=wis(F(10),F(11),A);WB,_=wis(F(20),F(20),B);WZ,termsZ=wis(F(30),F(30),Z)
ck('single_mean_MSE4',(F(12)-10)**2==4)
ck('single_WIS6over7',WA==F(6,7),{'weighted_terms':list(map(str,termsA))})
ck('hierarchy_MSE3',(F(1,2)*((F(12)-10)**2+(F(20)-20)**2)/2+F(1,2)*(F(32)-30)**2)==3)
ck('hierarchy_WIS13over14',F(1,2)*(WA+WB)/2+F(1,2)*WZ==F(13,14),{'leafA':str(WA),'leafB':str(WB),'zone':str(WZ),'zone_terms':list(map(str,termsZ))})
zero,_=wis(F(10),F(0),[(a,F(0),F(0))for a,_,_ in A])
ck('zero_degenerate_WIS10',zero==10)
low,_=wis(F(1),F(11),A);high,_=wis(F(25),F(11),A)
ck('both_under_over_penalties_are_exercised',low==F(37,7) and high==F(75,7),{'below_interval_truth1':str(low),'above_interval_truth25':str(high)})
# The metric choices below are proposed disambiguating anchors, not a
# claim that an unimplemented production scorer already uses them.
scaled_mse=F(1,2)*(((F(12)-10)/2)**2+((F(20)-20)/4)**2)/2+F(1,2)*((F(32)-30)/6)**2
scaled_wis=F(1,2)*(WA/2+WB/4)/2+F(1,2)*WZ/6
ck('nonunit_proposed_MSE_formula11over36',scaled_mse==F(11,36))
ck('nonunit_proposed_WIS_over_scale19over84',scaled_wis==F(19,84))
ck('sameunit_anchor_does_not_detect_wrong_scale_power',F(4,2)!=F(4,4)and(F(12)-10)**2==4)
ck('MSE_point_requires_mean_not_median',F(9,10)*(F(1)-0)**2+F(1,10)*(F(1)-10)**2==9 and F(9,10)*(F(0)-0)**2+F(1,10)*(F(0)-10)**2==10)
contract=read(snapshot/'material-contract-before-proposed-revision.json')
public=utc('2024-08-01T09:00:00Z');scale_cut=utc('2024-02-01T09:00:00Z')
outer=[];inner=[];explore=[]
def grid(o):return[o.replace(hour=0)+timedelta(days=2+i)for i in range(14)]
for s in contract['schedule']['outer_dates']:
    o=datetime.combine(date.fromisoformat(s),time(9),timezone.utc);outer.append(o)
    for offset in contract['schedule']['inner_days_before']:
        i=o-timedelta(days=offset);inner.append({'outer':o,'origin':i,'ends':grid(i)})
for month in range(6,12):
    o=datetime(2023,month,15,9,tzinfo=timezone.utc);explore.append({'origin':o,'ends':grid(o)})
ck('all36_inner_after_new_public_cutoff',len(inner)==36 and min(v['origin']for v in inner)>public,{'earliest_inner':txt(min(v['origin']for v in inner)),'new_cutoff':txt(public),'margin_hours':(min(v['origin']for v in inner)-public).total_seconds()/3600})
ck('all12_outer_dates_inherited_includingJune20',len(outer)==12 and outer[5]==datetime(2025,6,20,9,tzinfo=timezone.utc))
observations=list(csv.DictReader((snapshot/'actual-observations.csv').open(encoding='utf-8',newline='')))
ck('copied_actual_vintage_shape13152',len(observations)==13152)
terminal={(r['series_id'],r['event_end_utc']):r for r in observations if r['revision_id']=='2'}
scale_rows=[r for r in observations if r['revision_id']=='2'and '2023-01-01'<=r['event_date']<='2023-12-31']
units=read(snapshot/'actual-units.json')
def litres(r):return F(r['value'])*units[r['unit']]['multiplier']
ck('all1460_2023_terminal_rows_available_by_scale_cutoff',len(scale_rows)==1460 and all(r['quality_flag']=='valid'and utc(r['release_time_utc'])<=scale_cut and litres(r).denominator==1 for r in scale_rows),{'last_actual_release':max(r['release_time_utc']for r in scale_rows),'scale_cutoff':txt(scale_cut)})
scales={s:max(F(1),sum(litres(r)for r in scale_rows if r['series_id']==s)/365)for s in ['A1','A2','B1','B2']}
scales.update(ZA=max(F(1),sum(litres(r)for r in scale_rows if r['series_id']in ['A1','A2'])/365),ZB=max(F(1),sum(litres(r)for r in scale_rows if r['series_id']in ['B1','B2'])/365))
ck('actual2023_scales_positive_and_not_outer_derived',all(v>=1 for v in scales.values()),{k:str(v)for k,v in scales.items()})
label_checks=[]
for item in inner:
    rels=[]
    for end in item['ends']:
        for s in ['A1','A2','B1','B2']:
            r=terminal[(s,txt(end))];rels.append(utc(r['release_time_utc']))
    label_checks.append({'origin':txt(item['origin']),'outer':txt(item['outer']),'last_actual_terminal_release':txt(max(rels)),'hours_before_outer':(item['outer']-max(rels)).total_seconds()/3600})
ck('all36_actual_inner_terminal_releases_before_outer',all(v['hours_before_outer']>0 for v in label_checks),{'min_hours':min(v['hours_before_outer']for v in label_checks)})
ck('six_new_exploration_targets_all_actual_labels_public',len(explore)==6 and all(utc(terminal[(s,txt(end))]['release_time_utc'])<=public for item in explore for end in item['ends']for s in ['A1','A2','B1','B2']))
ck('scale_published_later_than_all_six_exploration_origins',all(v['origin']<scale_cut for v in explore),{'warning':'Safe as evaluator metric denominator, not origin-available predictor feature/pretraining state.'})
ck('all_new_daily_target_grids_wholly_future',all(len(v['ends'])==14 and v['ends'][0]-timedelta(days=1)>v['origin']and all(b-a==timedelta(hours=24)for a,b in zip(v['ends'],v['ends'][1:]))for v in inner+explore))
# A mathematical selection counterexample, not an executed selector.
ck('fixed_full_validation_grid_matters',min({'A':F(0+100,2),'B':F(36+36,2)},key=lambda k:({'A':F(50),'B':F(36)}[k],k))=='B'and 0<36,{'complete_mean_losses':{'A':'50','B':'36'},'incorrect_drop_failed_A_cell_mean':'0'})
ck('exact_ID_tie_can_be_deterministic',min([('b',F(1,3)),('a',F(1,3))],key=lambda v:(v[1],v[0]))[0]=='a')
save('hand-calculations.json',{'checks':checks,'all_passed':all(v['passed']for v in checks),'failed':[v['name']for v in checks if not v['passed']],'actual_inner_label_receipts':label_checks,'proposed_six_exploration_origins':[{'origin':txt(v['origin']),'targets':list(map(txt,v['ends']))}for v in explore],'actual_fixed2023_scales':{k:str(v)for k,v in scales.items()},'scope':'Arithmetic and read-only prior material facts; no worker/model/selector/scorer implemented or executed. Hypothetical probes are expressly mathematical only.','seconds':timer.perf_counter()-start})
print(json.dumps({'checks':len(checks),'all_passed':all(v['passed']for v in checks),'failed':[v['name']for v in checks if not v['passed']],'single_WIS':str(WA),'hierarchy_MSE':'3','hierarchy_WIS':str(F(1,2)*(WA+WB)/2+F(1,2)*WZ),'min_inner_to_outer_hours':min(v['hours_before_outer']for v in label_checks),'new_worker_solver_Docker_Provider_calls':0},ensure_ascii=False))
