def load(p):return json.loads(p.read_text(encoding='utf-8'))

def table(p):
    with p.open(encoding='utf-8',newline='') as f:return list(csv.DictReader(f))

def utc(s):
    assert re.fullmatch(r'\d{4}-\d{2}-\d{2}T\d{2}:00:00Z',s)
    return datetime(int(s[:4]),int(s[5:7]),int(s[8:10]),int(s[11:13]),tzinfo=timezone.utc)

def tick(s):
    d=utc(s)-EPOCH;assert d.seconds%3600==0;return d.days*24+d.seconds//3600

def read_independently(folder):
    catalogue=table(folder/'series.csv');units=load(folder/'units.json');availability=load(folder/'availability.json');rows={};canonical={'format':'l02-vintages/1','series':{r['series_id']:{'unit':r['canonical_unit']} for r in catalogue},'variables':availability,'observations':[],'covariates':[]}
    for name,kind,identity,daykey,endkey,tickkey in [('observations.csv','observations','series_id','event_date','event_end_utc','event_tick'),('covariate-vintages.csv','covariates','variable_id','valid_date','valid_end_utc','valid_tick')]:
        rows[kind]=table(folder/name);keys=[]
        for r in rows[kind]:
            end=utc(r[endkey]);day=datetime.fromisoformat(r[daykey]).replace(tzinfo=timezone.utc);assert end==day+timedelta(days=1)
            if r['quality_flag']=='missing':assert r['value']=='';value=None
            elif kind=='observations':
                exact=Fraction(Decimal(r['value']))*units[r['unit']]['multiplier'];assert exact.denominator==1 and 0<=exact<=10**9;value=exact.numerator
            else:value=int(r['value']);assert str(value)==r['value'] and r['unit']==availability[r[identity]]['unit']
            release=tick(r['release_time_utc']);t=tick(r[endkey]);revision=int(r['revision_id']);key=r[identity],t,revision;keys.append(key)
            if kind=='observations' or availability[r[identity]]['availability']=='observed':assert release>t
            canonical[kind].append({identity:r[identity],tickkey:t,'release_tick':release,'revision_id':revision,'value':value,'quality_flag':r['quality_flag']})
        assert len(set(keys))==len(keys)
    return canonical,rows,catalogue
