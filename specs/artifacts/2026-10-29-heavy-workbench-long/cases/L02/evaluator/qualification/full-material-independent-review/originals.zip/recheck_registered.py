"""New assigned-contract/precise-number reader replays; never regenerates material."""
from datetime import datetime,timedelta,timezone
import csv
import importlib.util
import json
from pathlib import Path
import shutil
import time
ROOT=Path(__file__).resolve().parent
CASE=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L02')
PYTHON='C:/Python314/python.exe'
spec=importlib.util.spec_from_file_location('own_command_helper',ROOT/'cold_and_probes.py');helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def csvrows(p):
    with p.open(encoding='utf-8',newline='') as f:r=csv.DictReader(f);return r.fieldnames,list(r)
def writecsv(p,fields,rows):
    with p.open('w',encoding='utf-8',newline='') as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
def main():
    source=ROOT/'source-repaired';source.mkdir(exist_ok=False)
    for p in (CASE/'evaluator/current-source').glob('*.py'):shutil.copy2(p,source/p.name)
    shutil.copy2(CASE/'evaluator/material-contract.json',source/'material-contract.json')
    shutil.copy2(CASE/'public/MATERIALS.draft.md',ROOT/'MATERIALS-repaired.md')
    contract=source/'material-contract.json';events=[];start=time.perf_counter()
    def run(label,data,role,expected,error=None,same=None):
        out=ROOT/'repaired-outputs'/label
        r=helper.command([PYTHON,'-X','utf8','-B',source/'decode_materials.py','--input',data,'--role',role,'--contract',contract,'--out',out],'registered-'+label,expected)
        actual=json.loads(r['stdout']);ok=actual.get('error')==error if error else actual['status']=='materials_decoded'
        if same is not None:ok &= load(out/'canonical.json')==load(ROOT/'cold'/same/'canonical.json') and load(out/'origin-grid.json')==load(ROOT/'cold'/same/'origin-grid.json')
        event={'label':label,'passed':ok,'expected_error':error,'actual':actual,'command':r};events.append(event);return event
    run('original_later_cutoff',ROOT/'probes-initial/self_declared_later_development_cutoff/input','development',2,'registered_clock_mismatch')
    run('original_fractional_L',ROOT/'probes-initial/inexact_decimal_litre/input','development',2,'quantity_integer_range')
    run('normal_archive',ROOT/'cold/materials/full-private','archive',0,same='decoded-full')
    for label in ['wrong_epoch','wrong_interval','legal_tail_zero','legal_equivalent_m3','actual_terminal_late','understated_lag']:
        data=ROOT/'repair-probes'/label/'input';shutil.copytree(ROOT/'cold/materials'/('full-private' if label in ['actual_terminal_late','understated_lag'] else 'development-public'),data)
        if label in ['wrong_epoch','wrong_interval']:
            clock=load(data/'time-axis.json')
            if label=='wrong_epoch':clock['epoch_utc']='2021-01-01T00:00:00Z'
            else:clock['event_interval']='[local day, variable length)'
            save(data/'time-axis.json',clock);run(label,data,'development',2,'registered_clock_mismatch')
        elif label in ['legal_tail_zero','legal_equivalent_m3']:
            fields,rows=csvrows(data/'observations.csv');row=next(r for r in rows if r['unit']=='L' and r['quality_flag']=='valid');n=int(row['value'])
            if label=='legal_tail_zero':row['value']=str(n)+'.'+'0'*31
            else:row['unit']='m3';row['value']=str(n//1000)+'.'+str(n%1000).zfill(3)+'0'*23
            writecsv(data/'observations.csv',fields,rows);run(label,data,'development',0,same='decoded-development')
        elif label=='actual_terminal_late':
            fields,rows=csvrows(data/'observations.csv');row=next(r for r in rows if r['series_id']=='A1' and r['event_date']=='2024-06-16' and r['revision_id']=='2');row['release_time_utc']='2025-01-15T10:00:00Z'
            writecsv(data/'observations.csv',fields,rows);run(label,data,'archive',2,'truth_release_bound')
        else:
            fields,rows=csvrows(data/'origins.csv');inner=next(r for r in rows if r['role']=='inner');outer=next(r for r in rows if r['origin_id']==inner['outer_id']);o=datetime.fromisoformat(outer['cutoff_utc'].replace('Z','+00:00'))-timedelta(days=20)
            inner['cutoff_utc']=o.strftime('%Y-%m-%dT%H:%M:%SZ');inner['first_target_end_utc']=(o.replace(hour=0)+timedelta(days=2)).strftime('%Y-%m-%dT%H:%M:%SZ');inner['truth_lag_hours']='0'
            writecsv(data/'origins.csv',fields,rows);run(label,data,'archive',2,'registered_truth_lag_mismatch')
    identity=[{'file':p.name,'same_current_bytes':p.read_bytes()==(CASE/'evaluator/current-source'/p.name).read_bytes()} for p in source.glob('*.py')]
    save(ROOT/'repair-checks.json',events);save(ROOT/'source-repaired-identity.json',{'sources':identity,'contract_same_bytes':contract.read_bytes()==(CASE/'evaluator/material-contract.json').read_bytes(),'all_same_current':all(r['same_current_bytes'] for r in identity)})
    assessment={'scope':'assigned contract/exact unit reader only; no second generation or54-core rerun','actual_CLI_rechecks':len(events),'all_passed':all(r['passed'] for r in events),'failed':[r['label'] for r in events if not r['passed']],'seconds':time.perf_counter()-start,'old_actual_failures_preserved':True,'no_worker_solver_Docker_Provider':True}
    save(ROOT/'repair-assessment.json',assessment);print(json.dumps(assessment,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
