"""Only final-role decodes, original failures, registered schedule guards and four new projections."""
from collections import defaultdict
import csv
from datetime import datetime,timedelta,timezone
import importlib.util
import json
from pathlib import Path
import shutil
import sqlite3
import sys
import time
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
MAIN=Path('D:/opencorvus-benchmark-runs/l02-full-materials-20261030/main')
CASE=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L02')
PYTHON='C:/Python314/python.exe';EPOCH=datetime(2022,1,1,tzinfo=timezone.utc)
spec=importlib.util.spec_from_file_location('commands_only',ROOT/'cold_and_probes.py');helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def rows(p):
    with p.open(encoding='utf-8',newline='') as f:r=csv.DictReader(f);return r.fieldnames,list(r)
def write_rows(p,fields,rs):
    with p.open('w',encoding='utf-8',newline='') as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rs)
def utc(s):return datetime.fromisoformat(s.replace('Z','+00:00'))
def tick(s):d=utc(s)-EPOCH;return d.days*24+d.seconds//3600
def main():
    start=time.perf_counter();out=ROOT/'final-increment';out.mkdir(exist_ok=False);source=ROOT/'source-final';shutil.copytree(MAIN/'source-final',source)
    shutil.copytree(MAIN/'materials-final',out/'materials');shutil.copy2(CASE/'public/MATERIALS.draft.md',ROOT/'MATERIALS-final.md')
    for name in ['final-build.json','final-decode-archive.json','final-decode-development.json','final-delta-identity-and-coverage.json']:
        if (MAIN/name).is_file():shutil.copy2(MAIN/name,out/name)
    shutil.copy2(MAIN/'projection-final-delta/assessment.json',out/'parent-delta-assessment.json')
    contract=source/'material-contract.json';checks=[];cli=[]
    def check(name,ok,detail=None):checks.append({'name':name,'passed':bool(ok),'detail':detail})
    def decode(label,data,role,code,error=None):
        target=out/'decoded'/label;r=helper.command([PYTHON,'-X','utf8','-B',source/'decode_materials.py','--input',data,'--role',role,'--contract',contract,'--out',target],'final-'+label,code)
        result=json.loads(r['stdout']);ok=result.get('error')==error if error else result.get('status')=='materials_decoded'
        check('actual_decoder_'+label,ok,result);cli.append(r);return target
    archive=decode('archive',out/'materials/full-private','archive',0);development=decode('development',out/'materials/development-public','development',0)
    decode('original_cutoff_bypass',ROOT/'probes-initial/self_declared_later_development_cutoff/input','development',2,'registered_clock_mismatch')
    decode('original_fractional_L',ROOT/'probes-initial/inexact_decimal_litre/input','development',2,'quantity_integer_range')
    raw=load(archive/'canonical.json');oldraw=load(ROOT/'cold/decoded-full/canonical.json');newgrid=load(archive/'origin-grid.json')['origins'];oldgrid=load(ROOT/'cold/decoded-full/origin-grid.json')['origins']
    check('all_canonical_facts_inherited_exactly',raw==oldraw and load(development/'canonical.json')==load(ROOT/'cold/decoded-development/canonical.json'))
    data_identity=[]
    for role in ['full-private','development-public']:
        for p in (out/'materials'/role).iterdir():
            if p.is_file() and p.name!='origins.csv':data_identity.append({'file':role+'/'+p.name,'exact_same_old_material_bytes':p.read_bytes()==(ROOT/'cold/materials'/role/p.name).read_bytes()})
    check('all_non_schedule_material_objects_unchanged',all(v['exact_same_old_material_bytes'] for v in data_identity),data_identity)
    before={r['origin_id']:r for r in oldgrid};after={r['origin_id']:r for r in newgrid};common=before.keys()&after.keys();added=sorted(after.keys()-before.keys());removed=sorted(before.keys()-after.keys())
    check('exactly50_inherited_plus4_replaced_origins',len(common)==50 and all(before[k]==after[k] for k in common) and len(added)==len(removed)==4,{'added':added,'removed':removed,'inherited':len(common)})
    drift=out/'schedule-drift';shutil.copytree(out/'materials/development-public',drift)
    fields,rs=rows(drift/'origins.csv');r=next(r for r in rs if r['role']=='outer');r['role']='development';write_rows(drift/'origins.csv',fields,rs)
    decode('role_or_schedule_drift',drift,'development',2,'registered_origins_mismatch')
    reordered=out/'reordered-origin-rows';shutil.copytree(out/'materials/development-public',reordered);fields,rs=rows(reordered/'origins.csv');write_rows(reordered/'origins.csv',fields,rs[::-1])
    reordered_out=decode('origin_row_order',reordered,'development',0)
    check('registered_schedule_accepts_semantic_row_reordering',load(reordered_out/'canonical.json')==load(development/'canonical.json') and {r['origin_id']:r for r in load(reordered_out/'origin-grid.json')['origins']}=={r['origin_id']:r for r in load(development/'origin-grid.json')['origins']})
    spec2=importlib.util.spec_from_file_location('final_unique_core',source/'asof_input.py');core=importlib.util.module_from_spec(spec2);spec2.loader.exec_module(core)
    check('asof_core_unchanged_from_original54_object',(source/'asof_input.py').read_bytes()==(ROOT/'source-initial/asof_input.py').read_bytes())
    sql=sqlite3.connect(':memory:');sql.execute('CREATE TABLE facts(kind TEXT,idx INTEGER,id TEXT,t INTEGER,rev INTEGER,release INTEGER,future INTEGER)')
    for kind,identity,tkey in [('observations','series_id','event_tick'),('covariates','variable_id','valid_tick')]:sql.executemany('INSERT INTO facts VALUES(?,?,?,?,?,?,?)',[(kind,i,r[identity],r[tkey],r['revision_id'],r['release_tick'],int(kind=='covariates' and raw['variables'][r[identity]]['availability']=='known_future')) for i,r in enumerate(raw[kind])])
    terminal={(r['series_id'],r['event_tick']):r for r in raw['observations'] if r['revision_id']==2};leaves={'A1','A2','B1','B2'};delta=[];margins=[]
    for id_ in added:
        r=after[id_];origin=utc(r['cutoff_utc']);ends=[origin.replace(hour=0)+timedelta(days=i) for i in range(2,16)];required=[terminal[s,tick(t.strftime('%Y-%m-%dT%H:%M:%SZ'))] for s in leaves for t in ends]
        check('new_grid_and_real_labels_'+id_,r['target_end_utc']==[t.strftime('%Y-%m-%dT%H:%M:%SZ') for t in ends] and r['actual_last_label_release_tick']==max(v['release_tick'] for v in required) and all(v['quality_flag']=='valid' for v in required))
        o=r['origin_tick'];expected={'format':'l02-asof-snapshot/1','origin':o,'horizon':14,'series':raw['series'],'variables':raw['variables']}
        for kind in ['observations','covariates']:expected[kind]=[raw[kind][i[0]] for i in sql.execute('SELECT idx FROM facts WHERE kind=? AND release<=? AND (future=1 OR t<?) ORDER BY id,t,rev',(kind,o,o))]
        actual=core.project(raw,o,14);check('new_actual_core_vs_independent_SQL_'+id_,actual==expected)
        snap=out/'delta4'/id_/'snapshot.json';snap.parent.mkdir(parents=True,exist_ok=True);snap.write_text(json.dumps(actual,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
        delta.append({'origin_id':id_,'observations':len(actual['observations']),'covariates':len(actual['covariates']),'snapshot':str(snap.relative_to(ROOT))})
        if r['role']=='outer':
            states={}
            for variable in ['A2.open','A1.transfer_in']:
                states[variable]=[]
                for target in r['target_ticks']:
                    values=[v for v in actual['covariates'] if v['variable_id']==variable and v['valid_tick']==target];states[variable].append(max(values,key=lambda v:v['revision_id'])['value'])
            check('new_June_outer_genuinely_crosses_announced_July1',states=={'A2.open':[1]*10+[0]*4,'A1.transfer_in':[0]*10+[1]*4},states)
            weather={z:[any(v['variable_id']==z+'.temperature_forecast' and v['valid_tick']==target for v in actual['covariates']) for target in r['target_ticks']] for z in ['ZA','ZB']}
            check('last_day_weather_still_explicitly_missing',weather=={'ZA':[True]*13+[False],'ZB':[True]*13+[False]},weather)
    for r in newgrid:
        if r['role']=='inner':
            actual=max(terminal[s,t]['release_tick'] for s in leaves for t in r['target_ticks']);margin=after[r['outer_id']]['origin_tick']-actual;margins.append(margin)
    check('actual_all36_inner_label_margin_remains483h',min(margins)==483 and min(margins)>0)
    sql.close()
    identity=[{'name':p.name,'same_current_bytes':p.read_bytes()==(CASE/'evaluator/current-source'/p.name).read_bytes()} for p in source.glob('*.py')]
    check('final8source_and_contract_identity',len(identity)==8 and all(v['same_current_bytes'] for v in identity) and contract.read_bytes()==(CASE/'evaluator/material-contract.json').read_bytes(),identity)
    save(out/'checks.json',checks);save(out/'delta4-evidence.json',delta)
    result={'scope':'final registered schedule delta only; no material generation or old54 rerun','actual_CLI_decodes':len(cli),'new_core_projection_calls':4,'old_projections_inherited_by_exact_same50_inputs_and_core':50,'all_passed':all(v['passed'] for v in checks),'failed':[v['name'] for v in checks if not v['passed']],'checks':len(checks),'seconds':time.perf_counter()-start,'source_final_identity':identity,'source_intermediate9CLI_remain_their_own_version':True,'no_forecast_worker_solver_Docker_Provider':True}
    save(out/'stage-assessment.json',result);print(json.dumps({k:v for k,v in result.items() if k!='source_final_identity'},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
