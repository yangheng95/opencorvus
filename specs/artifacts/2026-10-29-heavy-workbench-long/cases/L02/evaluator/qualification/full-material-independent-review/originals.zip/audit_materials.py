"""Independent CSV/Fraction/UTC/SQL reconstruction; imports no author builder/decoder."""
from collections import Counter,defaultdict
import csv
from datetime import datetime,timedelta,timezone
from decimal import Decimal
from fractions import Fraction
import importlib.util
import json
from pathlib import Path
import re
import sqlite3
import sys
import time
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
EPOCH=datetime(2022,1,1,tzinfo=timezone.utc)
CUTOFF=datetime(2025,1,1,9,tzinfo=timezone.utc)
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def table(p):
    with p.open(encoding='utf-8',newline='') as f:return list(csv.DictReader(f))
def utc(s):
    assert re.fullmatch(r'\d{4}-\d{2}-\d{2}T\d{2}:00:00Z',s)
    return datetime(int(s[:4]),int(s[5:7]),int(s[8:10]),int(s[11:13]),tzinfo=timezone.utc)
def tick(s):
    d=utc(s)-EPOCH;assert d.seconds%3600==0;return d.days*24+d.seconds//3600
def iso(d):return d.strftime('%Y-%m-%dT%H:%M:%SZ')
def read_independently(folder):
    catalogue=table(folder/'series.csv');units=load(folder/'units.json');availability=load(folder/'availability.json');rows={};canonical={'format':'l02-vintages/1','series':{r['series_id']:{'unit':r['canonical_unit']} for r in catalogue},'variables':availability,'observations':[],'covariates':[]}
    for name,kind,identity,daykey,endkey,tickkey in [('observations.csv','observations','series_id','event_date','event_end_utc','event_tick'),('covariate-vintages.csv','covariates','variable_id','valid_date','valid_end_utc','valid_tick')]:
        rows[kind]=table(folder/name);keys=[]
        for r in rows[kind]:
            end=utc(r[endkey]);day=datetime.fromisoformat(r[daykey]).replace(tzinfo=timezone.utc);assert end==day+timedelta(days=1)
            if r['quality_flag']=='missing':assert r['value']=='';value=None
            elif kind=='observations':
                exact=Fraction(Decimal(r['value']))*units[r['unit']]['multiplier'];assert exact.denominator==1 and 0<=exact<=10**9;value=exact.numerator
            else:value=int(r['value']);assert str(value)==r['value'] and r['unit']==availability[r[identity]]['unit']
            release=tick(r['release_time_utc']);t=tick(r[endkey]);revision=int(r['revision_id']);key=r[identity],t,revision;keys.append(key)
            if kind=='observations' or availability[r[identity]]['availability']=='observed':assert release>t
            canonical[kind].append({identity:r[identity],tickkey:t,'release_tick':release,'revision_id':revision,'value':value,'quality_flag':r['quality_flag']})
        assert len(set(keys))==len(keys)
    return canonical,rows,catalogue
def main():
    start=time.perf_counter();folder=ROOT/'cold/materials';raw,rows,catalogue=read_independently(folder/'full-private');dev,drows,dcatalogue=read_independently(folder/'development-public');checks=[]
    def check(name,ok,detail=None):checks.append({'name':name,'passed':bool(ok),'detail':detail})
    check('all_independent_full_fact_values_identity_types',raw==load(ROOT/'cold/decoded-full/canonical.json'),{'observations':len(raw['observations']),'covariates':len(raw['covariates'])})
    check('all_independent_development_fact_values_identity_types',dev==load(ROOT/'cold/decoded-development/canonical.json'),{'observations':len(dev['observations']),'covariates':len(dev['covariates'])})
    for name in ['series.csv','hierarchy.csv','availability.json','units.json','time-axis.json','origins.csv']:
        check('public_metadata_'+name,(folder/'full-private'/name).read_bytes()==(folder/'development-public'/name).read_bytes())
    for kind in ['observations','covariates']:
        permitted=[r for r in raw[kind] if r['release_tick']<=int((CUTOFF-EPOCH).total_seconds()/3600)]
        check('development_exact_published_set_'+kind,dev[kind]==permitted)
    check('development_has_no_announced_ops_revision1',all(not (r['variable_id'] in ['A2.open','A1.transfer_in'] and r['revision_id']>0) for r in dev['covariates']))
    leaf={r['series_id'] for r in catalogue if r['kind']=='leaf'};hierarchy=table(folder/'full-private/hierarchy.csv');terminal={(r['series_id'],r['event_tick']):r for r in raw['observations'] if r['revision_id']==2}
    check('all_leaf_days_have_valid_terminal_and_exact_hierarchy',len(terminal)==4*1096 and all(r['quality_flag']=='valid' for r in terminal.values()) and Counter(r['parent'] for r in hierarchy)=={'ZA':2,'ZB':2} and {r['child'] for r in hierarchy}==leaf and all(r['weight']=='1' for r in hierarchy))
    aggregate=[{'zone':zone,'event_tick':t,'value':sum(terminal[s,t]['value'] for s in children),'release_tick':max(terminal[s,t]['release_tick'] for s in children)} for zone,children in [('ZA',['A1','A2']),('ZB',['B1','B2'])] for t in sorted({t for s,t in terminal})]
    save(ROOT/'independent-zone-terminal.json',aggregate)
    grid=table(folder/'full-private/origins.csv');actualgrid=load(ROOT/'cold/decoded-full/origin-grid.json')['origins'];indexed={r['origin_id']:r for r in grid};gout=[]
    for r in grid:
        origin=utc(r['cutoff_utc']);first=utc(r['first_target_end_utc']);assert first==origin.replace(hour=0)+timedelta(days=2) and origin.hour==9
        ends=[first+timedelta(days=i) for i in range(int(r['horizon_days']))];assert len(ends)==14 and int(r['target_step_hours'])==24
        target_ticks=[tick(iso(v)) for v in ends];required=[terminal[s,t] for s in leaf for t in target_ticks];latest=max(v['release_tick'] for v in required)
        upper=ends[-1]+timedelta(hours=int(r['truth_lag_hours']));assert all(v['release_tick']<=tick(iso(upper)) for v in required)
        if r['role']=='inner':assert latest<tick(indexed[r['outer_id']]['cutoff_utc']) and (utc(indexed[r['outer_id']]['cutoff_utc'])-origin).days in [112,84,56]
        if r['role']=='development':assert latest<=tick(iso(CUTOFF))
        gout.append({'origin_id':r['origin_id'],'role':r['role'],'outer_id':r['outer_id'],'cutoff_utc':r['cutoff_utc'],'origin_tick':tick(r['cutoff_utc']),'target_ticks':target_ticks,'target_end_utc':[iso(v) for v in ends],'latest_label_release_utc':iso(upper),'actual_last_label_release_tick':latest})
    check('all54_grids_and_actual_terminal_release_bindings',gout==actualgrid and Counter(r['role'] for r in grid)=={'development':6,'outer':12,'inner':36})
    corepath=ROOT/'source-initial/asof_input.py';spec=importlib.util.spec_from_file_location('actual_unique_asof',corepath);core=importlib.util.module_from_spec(spec);spec.loader.exec_module(core)
    c=sqlite3.connect(':memory:');c.execute('CREATE TABLE facts(kind TEXT,idx INTEGER,id TEXT,t INTEGER,revision INTEGER,release INTEGER,future INTEGER)')
    for kind,identity,tkey in [('observations','series_id','event_tick'),('covariates','variable_id','valid_tick')]:c.executemany('INSERT INTO facts VALUES(?,?,?,?,?,?,?)',[(kind,i,r[identity],r[tkey],r['revision_id'],r['release_tick'],int(kind=='covariates' and raw['variables'][r[identity]]['availability']=='known_future')) for i,r in enumerate(raw[kind])])
    projections=[];weather_coverage=[];missing=[]
    for r in gout:
        o=r['origin_tick'];expected={'format':'l02-asof-snapshot/1','origin':o,'horizon':14,'series':raw['series'],'variables':raw['variables']}
        for kind in ['observations','covariates']:expected[kind]=[raw[kind][i[0]] for i in c.execute('SELECT idx FROM facts WHERE kind=? AND release<=? AND (future=1 OR t<?) ORDER BY id,t,revision',(kind,o,o))]
        actual=core.project(raw,o,14);projections.append({'origin_id':r['origin_id'],'actual_core_matches_independent_SQL':actual==expected,'observations':len(actual['observations']),'covariates':len(actual['covariates'])})
        latest={}
        for v in actual['observations']:
            key=v['series_id'],v['event_tick']
            if key not in latest or v['revision_id']>latest[key]['revision_id']:latest[key]=v
        missing.extend({'origin_id':r['origin_id'],'key':key,'revision':v['revision_id']} for key,v in latest.items() if v['quality_flag']=='missing')
        available={(v['variable_id'],v['valid_tick']) for v in actual['covariates']}
        for z in ['ZA','ZB']:weather_coverage.append({'origin_id':r['origin_id'],'zone':z,'per_target_any_published_forecast':[(z+'.temperature_forecast',t) in available for t in r['target_ticks']]})
    check('actual_single_core_all54_matches_separate_SQL',all(r['actual_core_matches_independent_SQL'] for r in projections));save(ROOT/'all54-permission-audit.json',projections)
    check('real_latest_missing_exists',len(missing)>0,{'selected_latest_missing_instances':len(missing),'example':missing[:3]})
    forecast_groups=defaultdict(list)
    for r in rows['covariates']:
        if r['variable_id'].endswith('temperature_forecast'):forecast_groups[r['variable_id'],r['valid_end_utc']].append(r)
    check('all_weather_issue_revision_versions',len(forecast_groups)==2*1096 and all(len(g)==14 and sorted(int(r['revision_id']) for r in g)==list(range(14)) and all((utc(r['valid_end_utc'])-timedelta(days=1)-utc(r['release_time_utc'])).days==13-int(r['revision_id']) and utc(r['release_time_utc']).hour==6 for r in g) for g in forecast_groups.values()))
    announce=tick('2025-06-15T12:00:00Z');valid=tick('2025-07-02T00:00:00Z');changes={}
    for o in [announce-1,announce]:
        snap=core.project(raw,o,14);changes[str(o)]={v:[(r['revision_id'],r['value']) for r in snap['covariates'] if r['variable_id']==v and r['valid_tick']==valid] for v in ['A2.open','A1.transfer_in']}
    check('real_announcement_changes_future_plan_only_on_release',changes[str(announce-1)]=={'A2.open':[(0,1)],'A1.transfer_in':[(0,0)]} and changes[str(announce)]=={'A2.open':[(0,1),(1,0)],'A1.transfer_in':[(0,0),(1,1)]},changes)
    mixed=defaultdict(list)
    for r in rows['observations']:mixed[r['series_id'],r['event_date']].append(r)
    examples=[{'key':key,'versions':[{'revision':r['revision_id'],'unit':r['unit'],'value':r['value']} for r in group]} for key,group in mixed.items() if len({r['unit'] for r in group})>1]
    check('actual_cross_release_units_and_measurement_revisions',len(examples)>0 and any(g[0]['value']!=g[2]['value'] for g in mixed.values()),{'mixed_unit_events':len(examples),'examples':examples[:2]})
    late=[r for r in rows['observations'] if r['revision_id']=='0' and (utc(r['release_time_utc'])-utc(r['event_end_utc']))==timedelta(hours=50)]
    check('actual_late_reports_and_missing_rows',len(late)>0 and any(r['quality_flag']=='missing' for r in rows['observations']),{'late_initial_reports':len(late),'all_missing_rows':sum(r['quality_flag']=='missing' for r in rows['observations'])})
    save(ROOT/'weather-target-coverage.json',weather_coverage)
    cross=[{'origin_id':r['origin_id'],'role':r['role']} for r in gout if r['origin_tick']>=announce and r['target_ticks'][0]<=valid<=r['target_ticks'][-1]]
    save(ROOT/'mechanism-coverage-observations.json',{'known_weather_published_target_counts':dict(Counter(sum(r['per_target_any_published_forecast']) for r in weather_coverage)),'announcement_and_effect_inside_target_window':cross,'outer_windows_crossing_announced_effect':sum(r['role']=='outer' for r in cross),'scope':'descriptive materials coverage, no quality/difficulty claim'})
    c.close();save(ROOT/'independent-material-checks.json',checks)
    result={'scope':'independent normal-material values/grids/actual label releases/permission/mechanisms, not a decoder security certification','checks':len(checks),'all_passed':all(r['passed'] for r in checks),'failed':[r['name'] for r in checks if not r['passed']],'seconds':time.perf_counter()-start,'observations':len(raw['observations']),'covariates':len(raw['covariates']),'grid_origins':len(gout),'development_observations':len(dev['observations']),'development_covariates':len(dev['covariates']),'qualified_forecast_outputs':False}
    save(ROOT/'normal-material-assessment.json',result);print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
