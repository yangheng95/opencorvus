"""Correct only the independent issue-time arithmetic, not the material or decoder."""
from collections import defaultdict
import csv
from datetime import datetime,timedelta,timezone
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def utc(s):return datetime.fromisoformat(s.replace('Z','+00:00'))
with (ROOT/'cold/materials/full-private/covariate-vintages.csv').open(encoding='utf-8',newline='') as f:rows=list(csv.DictReader(f))
g=defaultdict(list)
for r in rows:
    if r['variable_id'].endswith('temperature_forecast'):g[r['variable_id'],r['valid_end_utc']].append(r)
checks=[]
for key,values in g.items():
    checks.append({'key':key,'passed':len(values)==14 and sorted(int(v['revision_id']) for v in values)==list(range(14)) and all(utc(v['release_time_utc'])==utc(v['valid_end_utc'])-timedelta(days=1)-timedelta(days=13-int(v['revision_id']))+timedelta(hours=6) for v in values)})
result={'scope':'corrected full UTC issue/revision timestamp comparison only','groups':len(checks),'all_passed':len(checks)==2192 and all(v['passed'] for v in checks),'initial_auditor_error':'Using timedelta.days discarded the -6hour component and was one day too small; initial false predicate retained. Actual data issue/revision times are correct.','sample':g[next(iter(g))][:2],'checks':checks}
(ROOT/'weather-issue-correction.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
normal=json.loads((ROOT/'normal-material-assessment.json').read_text(encoding='utf-8'));others=[v for v in json.loads((ROOT/'independent-material-checks.json').read_text(encoding='utf-8')) if v['name']!='all_weather_issue_revision_versions']
current=normal|{'all_passed':all(v['passed'] for v in others) and result['all_passed'],'failed':[],'initial_auditor_formula_error_retained':True,'corrected_weather_groups':2192}
(ROOT/'normal-material-assessment-current.json').write_text(json.dumps(current,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'other18_predicates_passed':all(v['passed'] for v in others),'all2192_weather_issue_groups_passed':result['all_passed']},ensure_ascii=False))
