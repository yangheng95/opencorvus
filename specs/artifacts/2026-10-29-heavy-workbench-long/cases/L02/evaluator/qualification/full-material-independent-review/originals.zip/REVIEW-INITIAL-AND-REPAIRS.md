# L02 UTC材料/decoder独立实际审查：初材料与两P1修复

本记录先封存当前已真实执行的证据；后续六月origin/schedule演进另附，不覆写这些对象。角色为用户已授权的单层独立AI reviewer，未再委托，未读取/联系fresh Codex项目，未改主仓或Git。仅标准库材料/解码/算术/SQL；没有预测worker、Docker、Provider、优化求解器、GPU、UI或用户进程动作。

## 一次冷构建与独立正常事实

只有一次自有新目录source-only build，随后archive/development两解码，见cold-receipt.json与commands/cold-*。原材料1096日、13152 observation vintages、37632 covariates、54origins；公开开发8660/26524行。这个体量不是难度或小时证据，也没有产生预测成绩。

我未用builder/decoder函数当oracle：独立csv读取、canonical UTC逐字段日期验证、Fraction(Decimal(value))精确转L、signed integer协变量和真实业务ID/版本键重建出全部canonical，与两角色解码结果逐值一致。54个目标grid按origin翌日开始的完整14日逐项生成；逐leaf/目标读取真实rev2量及release，检查声明上界、inner父outer许可和development截止。继承数据6开发/12outer/36inner都满足；终审全valid，ZA/ZB按leaf真值和各自release最大值独立重算。全部metadata相等及完整公开release集合已核。

唯一现有asof核心实际处理原54cutoffs，与另建SQLite许可查询全等：release<=origin，observed period-end<origin，known_future可含未来period但须已发布，保留合法全版本。这个检查不是新forecast执行，也不承诺后来修改的cutoff已复跑。跨L/m3发布格式的同一事件真实存在；每行按自己的unit规范化，修订数量可以不同。迟报50h、真实missing、最高可用版本missing以及后续revision覆盖都有事实。天气2192个(variable,valid_end)组有14个issue/revision，完整UTC时刻映射一致。

最初天气检查用timedelta.days把-6h向下取整，导致审查器少一天；原19项记录中该false保留。随后只校正该UTC算术，2192组完整timestamp比较全过，其余18项原本全过。没有因审查公式错误改数据或重新跑54。weather-issue-correction.json与normal-material-assessment-current.json说明当前结论。

公布运营计划的可知性也被核：2025-06-15T11Z对未来2025-07-01业务日仅见旧计划A2.open=1/A1.transfer_in=0；12Z后保留rev0并新增rev1的0/1，最高版本取新值。开发包只含2022旧计划，不含以后具体变化日期/载荷；结构化两个运营通道本身是此前公开事实，不将此说成对任意metadata泄漏的形式证明。

## 两项真实P1，已在中间注册合同版本复验修复

P1-a：外部指定role=development仍信输入自报time-axis cutoff。把完整archive的development_cutoff_utc由2025-01-01T09Z改2026-02-01T09Z，实际CLI exit0/materials_decoded，13152/37632全数误判开发合法。原件probes-initial/self_declared_later_development_cutoff。非模型/候选错误，是评估工具边界未绑定分配合同。

P1-b：quantity先做默认28位Decimal乘法再检查是否整数，6236.0000000000000000000000000000001L被舍入成6236而实际CLI exit0。原件probes-initial/inexact_decimal_litre。真实精确数有非零分数部分，不能当合法整数L；这不是浮点容差选择。

根因修复是唯一外部分配material-contract.json，由material_contract.py及必传--contract共同绑定clock/units/grid，不用数据自己定义权限；quantity用plain-decimal解析后的Fraction精确换算。source-repaired是实际执行的8源码/当时合同，不等同后来的schedule版本。

修后只做9个必要CLI（15.781314s），没有第二次生成/54投影重跑：原假cutoff得到registered_clock_mismatch；原分数L得到quantity_integer_range；错误epoch/interval得到registered_clock_mismatch；合法多尾零和等价m3都得到与原development完全相同canonical/grid；真实rev2发布日期超界得到truth_release_bound；lag0元数据得到registered_truth_lag_mismatch；正常archive与原完整canonical/grid相同。全部原失败和修后输入/输出/argv保留，见repair-checks.json及commands/registered-*。

主方原understated-inner-label假通过与第一轮误/raw路径ENOENT是主方自己的原始证据；本review不把ENOENT当修复通过。真实原标签release与声明lag分开核验，不能仅凭新增role或title声称安全。

## 真实覆盖观察，不冒充全题错误或成绩

原+2 full-future grid每个zone/origin有13/14个target已发布weather forecast，末日尚无issue。不能用以后的issue补齐；目前不以此判材料格式失败，但必须公开末日缺测或正式改数据发布窗口。原monthlyouter没有在announce后预测窗口跨July1生效，只有3inner跨，不能说已用outer受测提前响应。这两事实被反馈给主方，后续若改变Juneouter/schedule必须另绑定/增量实核。

尚未资格：完整预测/内外选模执行器、每日target-grid worker接口、点/区间质量线、概率层级一致性、职业报告/复跑交付、多质量rubric/盲评、冻结/有效小时。旧小时toy forecast不能用于这些24h间隔target；材料体量、54切点或原语通过不构成十题成熟证据。
