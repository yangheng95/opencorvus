import json
from pathlib import Path
import shutil
import subprocess
ROOT=Path(__file__).resolve().parent
CASE=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L02')
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
identity=[]
for p in (ROOT/'source-final').glob('*.py'):
    identity.append({'file':p.name,'executed_final_snapshot':str(p),'bytes':p.stat().st_size,'same_current_bytes':p.read_bytes()==(CASE/'evaluator/current-source'/p.name).read_bytes()})
contract=ROOT/'source-final/material-contract.json';samecontract=contract.read_bytes()==(CASE/'evaluator/material-contract.json').read_bytes()
save(ROOT/'final-source-identity.json',{'eight_sources':identity,'contract_same_current_bytes':samecontract,'all_same_current':len(identity)==8 and all(v['same_current_bytes'] for v in identity) and samecontract,'source_initial_and_intermediate_are_distinct_executed_versions':True})
normal=load(ROOT/'normal-material-assessment-current.json');repair=load(ROOT/'repair-assessment.json');delta=load(ROOT/'final-increment/stage-assessment.json')
stage={'stage':'materials_and_decoder_locally_qualified_after_two_actual_P1_repairs_and_registered_schedule_delta','blocking':[],
 'actual_blockers_found_and_repaired':[{'id':'P1-cutoff-authority','original':'input self-declared later cutoff admitted full-private as development','repair':'sole assigned material contract; original CLI now registered_clock_mismatch'}, {'id':'P1-inexact-integer-unit','original':'Decimal context rounded noninteger L into an integer','repair':'plain decimal Fraction exact scaling; original CLI now quantity_integer_range'}],
 'one_actual_source_only_cold_generation':load(ROOT/'cold-receipt.json'),'normal_independent_all_fact_checks_passed_after_auditor_UTC_formula_correction':normal['all_passed'],'original54_core_SQL_projections':54,
 'intermediate_actual_9CLI_passed':repair['all_passed'],'final_increment':delta,'final50_projection_evidence_inherited_not_rerun':True,'final_only4_new_core_calls':True,'actual_low_level_workers_or_forecast_runs':0,'current_source_identity':'final-source-identity.json',
 'weather_last_target_declared_missing':True,'June20_outer_actual_operating_effect_crossed':True,'minimum_actual_inner_terminal_margin_hours':483,'original_failures_and_auditor_weather_formula_false_preserved':True,
 'no_Provider_solver_GPU_Docker_UI_user_process_or_redelegation':True,'no_Codex_project_access_or_messages':True,'full_L02_frozen':False,'full_forecast_selection_quality_rubric_approved':False,'candidate_score':None,'hours_or_statistical_maturity_claim':False}
save(ROOT/'stage-assessment.json',stage)
shutil.copy2(Path('D:/myhexin-local/opencorvus/specs/records/2026-10/2026-10-30-heavy-workbench-l02-qualification.md'),ROOT/'record-final.md')
status=subprocess.run(['git','status','--short'],cwd='D:/myhexin-local/opencorvus',capture_output=True,text=True,encoding='utf-8');(ROOT/'git-status-end.txt').write_text(status.stdout,encoding='utf-8')
print(json.dumps({'stage':stage['stage'],'blocking':[],'normal_facts_passed':normal['all_passed'],'intermediate9CLI':repair['all_passed'],'final23checks':delta['all_passed'],'same_final_sources':len(identity)==8 and all(v['same_current_bytes'] for v in identity) and samecontract},ensure_ascii=False))
