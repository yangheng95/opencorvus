"""Exactly one source-only stdlib material construction, plus focused decoder boundaries."""
from datetime import datetime,timezone
import csv
import json
from pathlib import Path
import shutil
import subprocess
import time
ROOT=Path(__file__).resolve().parent
REPO=Path('D:/myhexin-local/opencorvus')
CASE=REPO/'specs/artifacts/2026-10-29-heavy-workbench-long/cases/L02'
MAIN=Path('D:/opencorvus-benchmark-runs/l02-full-materials-20261030')
PYTHON='C:/Python314/python.exe'
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def command(argv,label,expected=None):
    folder=ROOT/'commands'/label;folder.mkdir(parents=True,exist_ok=False);start=time.perf_counter()
    p=subprocess.run([str(v) for v in argv],cwd=ROOT,capture_output=True,text=True,encoding='utf-8',timeout=30)
    (folder/'stdout.txt').write_text(p.stdout,encoding='utf-8');(folder/'stderr.txt').write_text(p.stderr,encoding='utf-8')
    result={'argv':[str(v) for v in argv],'exit_code':p.returncode,'seconds':time.perf_counter()-start,'stdout':p.stdout,'stderr':p.stderr}
    save(folder/'command.json',result)
    if expected is not None and p.returncode!=expected:raise RuntimeError(label+':actual_execution_failure')
    return result
def main():
    inventory=[]
    def cp(p,q):q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q);inventory.append({'source':str(p),'copy':str(q.relative_to(ROOT)),'bytes':q.stat().st_size,'byte_equal':p.read_bytes()==q.read_bytes()})
    for p in (CASE/'evaluator/current-source').glob('*.py'):cp(p,ROOT/'source-initial'/p.name)
    cp(CASE/'public/MATERIALS.draft.md',ROOT/'MATERIALS-initial.md')
    cp(REPO/'specs/records/2026-10/2026-10-30-heavy-workbench-l02-qualification.md',ROOT/'record-initial.md')
    for p in MAIN.glob('*.json'):cp(p,ROOT/'main-receipts'/p.name)
    save(ROOT/'source-inventory.json',inventory)
    status=subprocess.run(['git','status','--short'],cwd=REPO,capture_output=True,text=True,encoding='utf-8');(ROOT/'git-status-start.txt').write_text(status.stdout,encoding='utf-8')
    source=ROOT/'source-initial';start=time.perf_counter()
    command([PYTHON,'-X','utf8','-B',source/'build_materials.py','--out',ROOT/'cold/materials'],'cold-build',0)
    command([PYTHON,'-X','utf8','-B',source/'decode_materials.py','--input',ROOT/'cold/materials/full-private','--role','archive','--out',ROOT/'cold/decoded-full'],'cold-decode-archive',0)
    command([PYTHON,'-X','utf8','-B',source/'decode_materials.py','--input',ROOT/'cold/materials/development-public','--role','development','--out',ROOT/'cold/decoded-development'],'cold-decode-development',0)
    save(ROOT/'cold-receipt.json',{'one_source_only_generation':True,'two_role_decodes':True,'seconds':time.perf_counter()-start,'source_count':len(list(source.glob('*.py'))),'no_worker_solver_Docker_Provider':True})
    probes=[]
    for label in ('self_declared_later_development_cutoff','inexact_decimal_litre'):
        folder=ROOT/'probes-initial'/label;data=folder/'input'
        shutil.copytree(ROOT/'cold/materials'/('full-private' if label.startswith('self_') else 'development-public'),data)
        if label.startswith('self_'):
            v=load(data/'time-axis.json');v['development_cutoff_utc']='2026-02-01T09:00:00Z';save(data/'time-axis.json',v)
            mutation={'field':'development_cutoff_utc','from':'2025-01-01T09:00:00Z','to':v['development_cutoff_utc']}
        else:
            path=data/'observations.csv'
            with path.open(encoding='utf-8',newline='') as f:r=csv.DictReader(f);fields=r.fieldnames;rows=list(r)
            row=next(v for v in rows if v['unit']=='L' and v['quality_flag']=='valid');original=row['value'];row['value']=original+'.'+'0'*30+'1'
            mutation={'series_id':row['series_id'],'event_date':row['event_date'],'revision_id':row['revision_id'],'from':original,'to':row['value'],'exact_integer_litres':False}
            with path.open('w',encoding='utf-8',newline='') as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
        actual=command([PYTHON,'-X','utf8','-B',source/'decode_materials.py','--input',data,'--role','development','--out',folder/'decoded'],label)
        probes.append({'name':label,'mutation':mutation,'command':actual})
        save(folder/'probe.json',probes[-1])
    save(ROOT/'initial-probes.json',probes)
    print(json.dumps({'cold':load(ROOT/'cold-receipt.json'),'probes':[{'name':r['name'],'exit':r['command']['exit_code'],'stdout':r['command']['stdout']} for r in probes]},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
