import copy
from datetime import datetime,timezone
from fractions import Fraction
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT=Path(__file__).parent
SOURCE=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L02/evaluator/current-source')
STUDY=SOURCE.parent/'study-contract.draft.json'
ROOT.mkdir(parents=True,exist_ok=True)
snapshot=ROOT/'source-initial';snapshot.mkdir()
for name in ['l02_scoring.py','material_contract.py','asof_input.py']:shutil.copyfile(SOURCE/name,snapshot/name)
shutil.copyfile(STUDY,ROOT/'study-contract.json')
sys.path.insert(0,str(snapshot))
from l02_scoring import load_study,wis
study=load_study(ROOT/'study-contract.json')
qkeys=study['quantiles']
context={'format':'l02-score-context/1','origin_tick':0,'target_ticks':[48],
 'series_catalogue':[{'series_id':'A','kind':'leaf'},{'series_id':'B','kind':'leaf'},{'series_id':'Z','kind':'aggregate'}],
 'hierarchy':[{'parent':'Z','child':'A','weight':1},{'parent':'Z','child':'B','weight':1}],
 'scales_litres':{'A':1,'B':1,'Z':1}}
labels=[{'series_id':name,'target_tick':48,'value':v} for name,v in [('A',10),('B',20),('Z',30)]]
forecast={'format':'l02-distribution-forecasts/1','method_id':'declared','origin_tick':0,'forecasts':[]}
for name,mean,values in [('A',12,[0,5,8,11,12,15,20]),('B',20,[20]*7),('Z',32,[0,20,27,30,33,40,60])]:
 forecast['forecasts'].append({'series_id':name,'target_tick':48,'mean':mean,'quantiles':dict(zip(qkeys,values))})
receipts=[];began=time.perf_counter()
def check(name,value):
 receipts.append({'name':name,'passed':bool(value)})
 if not value:raise AssertionError(name)
def run(name,f=None,c=None,l=None,text=None,expected_exit=0,status='forecast_assessed',error=None,metrics=None):
 root=ROOT/name;root.mkdir()
 for file,value in [('context',c if c is not None else context),('labels',l if l is not None else labels)]:
  (root/(file+'.json')).write_text(json.dumps(value),encoding='utf-8')
 (root/'forecast.json').write_text(text if text is not None else json.dumps(f if f is not None else forecast),encoding='utf-8')
 argv=[sys.executable,'-X','utf8','-B',str(snapshot/'l02_scoring.py'),'--study',str(ROOT/'study-contract.json'),'--forecast',str(root/'forecast.json'),'--context',str(root/'context.json'),'--labels',str(root/'labels.json'),'--method-id','declared','--out',str(root/'result.json')]
 started=time.perf_counter();p=subprocess.run(argv,capture_output=True,text=True,encoding='utf-8')
 (root/'command.json').write_text(json.dumps({'argv':argv,'exitcode':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'wall_seconds':time.perf_counter()-started},indent=2),encoding='utf-8')
 result=json.loads((root/'result.json').read_text(encoding='utf-8'))
 check(name+':contract',p.returncode==expected_exit and result['status']==status and (error is None or result.get('error')==error))
 if metrics is not None:check(name+':hand_calculated_metrics',result['metrics_exact']==metrics)
 return result

qa={Fraction(k):Fraction(v) for k,v in forecast['forecasts'][0]['quantiles'].items()}
check('single-node-WIS-6/7',wis(Fraction(10),qa,[Fraction(a) for a in study['interval_alphas']])==Fraction(6,7))
check('zero-point-mass-WIS-absolute-error-10',wis(Fraction(10),{Fraction(k):Fraction(0) for k in qkeys},[Fraction(a) for a in study['interval_alphas']])==10)
run('hierarchy-unit-scale',metrics={'scaled_mse':'3','scaled_mae':'3/2','scaled_wis':'13/14'})
nonunit=copy.deepcopy(context);nonunit['scales_litres']={'A':2,'B':5,'Z':10}
run('hierarchy-nonunit-scale',c=nonunit,metrics={'scaled_mse':'27/100','scaled_mae':'7/20','scaled_wis':'5/28'})
reordered=copy.deepcopy(forecast);reordered['forecasts'].reverse()
run('reordered',f=reordered,metrics={'scaled_mse':'3','scaled_mae':'3/2','scaled_wis':'13/14'})
run('exact-decimal-JSON',text=json.dumps(forecast).replace('"mean": 12,','"mean": 12.0000,'),metrics={'scaled_mse':'3','scaled_mae':'3/2','scaled_wis':'13/14'})
bad=copy.deepcopy(forecast);bad['forecasts'][0]['mean']=True
run('boolean-prediction',f=bad,expected_exit=2,status='prediction_invalid',error='prediction_numeric_invalid')
bad=copy.deepcopy(forecast);bad['forecasts'][0]['quantiles']['0.1']=99
run('reversed-quantiles',f=bad,expected_exit=2,status='prediction_invalid',error='prediction_quantile_order')
bad=copy.deepcopy(forecast);bad['forecasts'][0]['mean']=14
run('incoherent-mean',f=bad,expected_exit=2,status='prediction_invalid',error='prediction_mean_incoherent')
bad=copy.deepcopy(forecast);bad['forecasts'].pop()
run('missing-node',f=bad,expected_exit=2,status='prediction_incomplete',error='prediction_incomplete')
run('duplicate-JSON',text='{"method_id":"a","method_id":"b"}',expected_exit=2,status='prediction_invalid',error='prediction_schema_invalid')
run('malformed-JSON',text='{',expected_exit=2,status='prediction_invalid',error='prediction_schema_invalid')
run('extreme-exponent',text=json.dumps(forecast).replace('"mean": 12,','"mean": 1e1001,'),expected_exit=2,status='prediction_invalid',error='prediction_numeric_invalid')
bad=copy.deepcopy(context);bad['target_ticks']=[True]
run('facility-bool-tick',c=bad,expected_exit=3,status='run_invalid',error='facility_context_invalid')
bad=copy.deepcopy(labels);bad[0]['value']=True
run('facility-bool-truth',l=bad,expected_exit=3,status='run_invalid',error='facility_labels_invalid')
bad=copy.deepcopy(labels);bad[-1]['value']=31
run('facility-incoherent-truth',l=bad,expected_exit=3,status='run_invalid',error='facility_labels_invalid')
(ROOT/'assessment.json').write_text(json.dumps({'status':'local_metric_qualified','checks':receipts,'wall_seconds':time.perf_counter()-began,'at':datetime.now(timezone.utc).isoformat(),'scope':'closed-form metrics and real metric CLI; no daily worker, selector, full study, candidate score or hours'},indent=2),encoding='utf-8')
print(json.dumps({'checks':len(receipts),'all_passed':all(c['passed'] for c in receipts),'wall_seconds':time.perf_counter()-began}))
