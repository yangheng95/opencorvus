import json
from pathlib import Path
import shutil
import subprocess
ROOT=Path(__file__).resolve().parent
CASE=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L02')
facts=[]
for p in (ROOT/'source-repaired').glob('*.py'):
    actual=CASE/'evaluator/current-source'/p.name
    facts.append({'name':p.name,'executed_snapshot':str(p),'bytes':p.stat().st_size,'same_current_bytes':p.read_bytes()==actual.read_bytes()})
shutil.copy2(CASE/'public/ASOF-CONTRACT.draft.md',ROOT/'ASOF-CONTRACT-reviewed.md')
shutil.copy2(Path('D:/myhexin-local/opencorvus/specs/records/2026-10/2026-10-30-heavy-workbench-l02-qualification.md'),ROOT/'record-repaired.md')
identity={'four_sources':facts,'all_same_current':len(facts)==4 and all(v['same_current_bytes'] for v in facts),'old_main_originals_execute_initial_byte_objects':'retained; only checker schema validation changed; no claim original main executed repaired checker','review_worker_forecast_source_unchanged':(ROOT/'source-initial/forecast_reference.py').read_bytes()==(ROOT/'source-repaired/forecast_reference.py').read_bytes()}
(ROOT/'final-source-identity.json').write_text(json.dumps(identity,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
stage=json.loads((ROOT/'stage-assessment.json').read_text(encoding='utf-8'));stage|={'blocking':[],'repaired_blocker':'snapshot bool/int false-pass preserved in initial-probes; fixed by sole validate reuse','current_source_binding':identity['all_same_current'],'note':'local primitive only; all broader limitations in REVIEW.md; no original source/result overwritten'}
(ROOT/'stage-assessment.json').write_text(json.dumps(stage,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
status=subprocess.run(['git','status','--short'],cwd='D:/myhexin-local/opencorvus',capture_output=True,text=True,encoding='utf-8');(ROOT/'git-status-end.txt').write_text(status.stdout,encoding='utf-8')
print(json.dumps({'stage':stage['stage'],'blocking':[],'all15_passed':stage['all_passed'],'same_current_sources':identity['all_same_current']},ensure_ascii=False))
