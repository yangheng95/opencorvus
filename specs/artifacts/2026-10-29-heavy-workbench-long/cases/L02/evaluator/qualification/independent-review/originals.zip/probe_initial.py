"""Snapshot original L02 primitive and issue exact positive error-contract probes."""
from datetime import datetime,timezone
import json
from pathlib import Path
import shutil
import subprocess
import time
ROOT=Path(__file__).resolve().parent
CASE=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L02')
MAIN=Path('D:/opencorvus-benchmark-runs/l02-asof-qualification-20261030/main')
PYTHON='C:/Python314/python.exe'
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def main():
    inventory=[]
    def cp(p,q):q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q);inventory.append({'source':str(p),'copy':str(q.relative_to(ROOT)),'bytes':q.stat().st_size,'byte_equal':p.read_bytes()==q.read_bytes()})
    for p in (CASE/'evaluator/current-source').glob('*.py'):cp(p,ROOT/'source-initial'/p.name)
    cp(CASE/'public/ASOF-CONTRACT.draft.md',ROOT/'ASOF-CONTRACT-initial.md')
    for p in MAIN.rglob('*'):
        if p.is_file() and p.suffix in ('.json','.py'):cp(p,ROOT/'main-originals'/p.relative_to(MAIN))
    cp(Path('D:/myhexin-local/opencorvus/specs/records/2026-10/2026-10-30-heavy-workbench-l02-qualification.md'),ROOT/'record-initial.md')
    save(ROOT/'snapshot-inventory.json',inventory)
    cases=[]
    for label,table,field,value in [('bool_revision','observations','revision_id',False),('bool_release','observations','release_tick',True),('bool_covariate_value','covariates','value',True)]:
        snap=load(MAIN/'base/input/snapshot.json')
        row=snap[table][0];original=row[field];row[field]=value
        folder=ROOT/'initial-probes'/label;folder.mkdir(parents=True,exist_ok=False);save(folder/'snapshot.json',snap)
        argv=[PYTHON,'-X','utf8','-B',str(ROOT/'source-initial/check_projection.py'),'--raw',str(ROOT/'main-originals/base/raw.json'),'--origin','7','--horizon','2','--snapshot',str(folder/'snapshot.json'),'--out',str(folder/'assessment.json')]
        start=time.perf_counter();p=subprocess.run(argv,cwd=ROOT,capture_output=True,text=True,encoding='utf-8',timeout=10)
        (folder/'stdout.txt').write_text(p.stdout,encoding='utf-8');(folder/'stderr.txt').write_text(p.stderr,encoding='utf-8')
        result={'argv':argv,'exit_code':p.returncode,'seconds':time.perf_counter()-start,'table':table,'field':field,'original_type':type(original).__name__,'original_value':original,'actual_type':type(value).__name__,'actual_value':value,'assessment':load(folder/'assessment.json')}
        save(folder/'command.json',result);cases.append(result)
    save(ROOT/'initial-probes.json',cases)
    print(json.dumps([{'table':r['table'],'field':r['field'],'exit':r['exit_code'],'status':r['assessment']['status']} for r in cases],ensure_ascii=False))
if __name__=='__main__':main()
