"""One tiny owned isolated worker, original type probes and distinct missing-version boundaries."""
from collections import Counter
from datetime import datetime,timezone
from fractions import Fraction
import json
from pathlib import Path
import shutil
import sqlite3
import subprocess
import time
import uuid
ROOT=Path(__file__).resolve().parent
PYTHON='C:/Python314/python.exe'
SOURCE=ROOT/'source-repaired'
IMAGE='sha256:23ff8bfbf8055caa0b9fa5745ddb27cceea2f31d7d15b7a900c81112cdfe8ddf'
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def command(argv,label,expected=0):
    folder=ROOT/'commands'/label;folder.mkdir(parents=True,exist_ok=False)
    tick=time.perf_counter();p=subprocess.run([str(x) for x in argv],cwd=ROOT,capture_output=True,text=True,encoding='utf-8',timeout=30)
    (folder/'stdout.txt').write_text(p.stdout,encoding='utf-8');(folder/'stderr.txt').write_text(p.stderr,encoding='utf-8')
    receipt={'argv':[str(x) for x in argv],'exit_code':p.returncode,'expected_exit_code':expected,'seconds':time.perf_counter()-tick}
    save(folder/'command.json',receipt)
    if p.returncode!=expected:raise RuntimeError('actual_contract_exit:'+label)
    return p
def checker(snapshot,out,label,origin=7,horizon=2,raw=None,expected=0):
    return command([PYTHON,'-X','utf8','-B',SOURCE/'check_projection.py','--raw',raw or ROOT/'main-originals/base/raw.json','--origin',origin,'--horizon',horizon,'--snapshot',snapshot,'--out',out],label,expected)
def project(raw,origin,path,label):
    command([PYTHON,'-X','utf8','-B',SOURCE/'asof_input.py','--raw',raw,'--origin',origin,'--horizon',2,'--out',path],label)
def legal_sql(raw,origin,horizon):
    result={'format':'l02-asof-snapshot/1','origin':origin,'horizon':horizon,'series':raw['series'],'variables':raw['variables']}
    for table,identity,tick in [('observations','series_id','event_tick'),('covariates','variable_id','valid_tick')]:
        with sqlite3.connect(':memory:') as c:
            c.execute('CREATE TABLE facts(id TEXT,t INTEGER,release INTEGER,revision INTEGER,future INTEGER,payload TEXT)')
            c.executemany('INSERT INTO facts VALUES(?,?,?,?,?,?)',[(r[identity],r[tick],r['release_tick'],r['revision_id'],int(table=='covariates' and raw['variables'][r[identity]]['availability']=='known_future'),json.dumps(r,sort_keys=True)) for r in raw[table]])
            result[table]=[json.loads(row[0]) for row in c.execute('SELECT payload FROM facts WHERE release<=? AND (future=1 OR t<?) ORDER BY id,t,revision',(origin,origin))]
    return result
def main():
    start=time.perf_counter();checks=[]
    def check(name,ok,detail=None):checks.append({'name':name,'passed':bool(ok),'detail':detail})
    for label,error in [('bool_revision','row_tick:observations'),('bool_release','row_tick:observations'),('bool_covariate_value','valid_value:covariates')]:
        out=ROOT/'repair-probes'/(label+'.json');out.parent.mkdir(exist_ok=True)
        checker(ROOT/'initial-probes'/label/'snapshot.json',out,'repair-'+label,expected=2)
        actual=load(out);check('original_'+label+'_explicit_type_error',actual=={'status':'input_invalid','error':error},actual)
    # Audit previously saved actual processes without reexecuting main's two workers.
    for label in ('base','future-mutated'):
        raw=load(ROOT/'main-originals'/label/'raw.json');snap=load(ROOT/'main-originals'/label/'input/snapshot.json')
        check('main_'+label+'_independent_SQL_published_set',snap==legal_sql(raw,7,2))
        i=load(ROOT/'main-originals'/label/'inspect-full.json');mount={m['Destination']:m for m in i['Mounts']}
        check('main_'+label+'_real_isolation',i['State']['Status']=='exited' and i['State']['ExitCode']==0 and i['HostConfig']['NetworkMode']=='none' and i['HostConfig']['NanoCpus']==10**9 and i['HostConfig']['ReadonlyRootfs'] is True and {k:v['RW'] for k,v in mount.items()}=={'/program':False,'/input':False,'/output':True} and len(mount)==3)
        check('main_'+label+'_worker_has_only_one_program_and_snapshot',set(p.name for p in Path(mount['/program']['Source']).iterdir())=={'forecast_reference.py'} and set(p.name for p in Path(mount['/input']['Source']).iterdir())=={'snapshot.json'})
    check('future_perturbation_same_permitted_input_and_prediction',load(ROOT/'main-originals/base/input/snapshot.json')==load(ROOT/'main-originals/future-mutated/input/snapshot.json') and load(ROOT/'main-originals/base/output/predictions.json')==load(ROOT/'main-originals/future-mutated/output/predictions.json'))
    raw=load(ROOT/'main-originals/base/raw.json');origin9=load(ROOT/'main-originals/origin9.json')
    check('origin9_exact_SQL_and_new_revision',origin9==legal_sql(raw,9,2) and any(r['event_tick']==3 and r['revision_id']==1 and r['value']==999 for r in origin9['observations']))
    cold=ROOT/'single-cold';(cold/'program').mkdir(parents=True);(cold/'input').mkdir();(cold/'output').mkdir()
    shutil.copy2(SOURCE/'forecast_reference.py',cold/'program/forecast_reference.py')
    project(ROOT/'main-originals/base/raw.json',7,cold/'input/snapshot.json','cold-projection')
    checker(cold/'input/snapshot.json',cold/'check.json','cold-projection-check')
    name='oc-l02-independent-asof-'+uuid.uuid4().hex[:12]
    create=command(['docker','create','--name',name,'--network','none','--cpus','1','--read-only','-e','PYTHONDONTWRITEBYTECODE=1',
      '--mount','type=bind,src='+str(cold/'program')+',dst=/program,readonly','--mount','type=bind,src='+str(cold/'input')+',dst=/input,readonly','--mount','type=bind,src='+str(cold/'output')+',dst=/output',IMAGE,
      '/opt/cpsat/bin/python','/program/forecast_reference.py','--input','/input/snapshot.json','--out','/output/predictions.json'],'cold-create')
    cid=create.stdout.strip();save(cold/'owned-container.json',{'id':cid,'name':name,'reviewer_owned':True})
    command(['docker','start','-a',cid],'cold-execution')
    inspected=command(['docker','inspect',cid],'cold-terminal-inspect');i=json.loads(inspected.stdout)[0];save(cold/'terminal-inspect.json',i)
    check('new_cold_terminal_readonly_snapshot_only',i['Id']==cid and i['State']['ExitCode']==0 and i['State']['Status']=='exited' and i['HostConfig']['NetworkMode']=='none' and i['HostConfig']['NanoCpus']==10**9 and i['HostConfig']['ReadonlyRootfs'] is True and {(m['Destination'],m['RW']) for m in i['Mounts']}=={('/program',False),('/input',False),('/output',True)})
    pred=load(cold/'output/predictions.json');actual=[Fraction(r['value']['numerator'],r['value']['denominator']) for r in pred['forecasts']]
    check('new_cold_exact_OLS_and_heldout_MAE',actual==[24,26] and [r['target_tick'] for r in pred['forecasts']]==[7,8] and pred['origin']==7 and sum(abs(x-y) for x,y in zip(actual,[24,26]))/2==0 and sum(abs(22-y) for y in [24,26])/2==3)
    command(['docker','rm',cid],'cold-exact-terminal-cleanup')
    missing={'format':'l02-vintages/1','series':{'S':{'unit':'count'}},'variables':{},'covariates':[],'observations':[
      {'series_id':'S','event_tick':t,'release_tick':t+1,'revision_id':0,'value':v,'quality_flag':'valid'} for t,v in [(0,10),(1,999),(2,14)]]}
    missing['observations'].append({'series_id':'S','event_tick':1,'release_tick':4,'revision_id':1,'value':None,'quality_flag':'missing'})
    path=ROOT/'missing-highest';path.mkdir();save(path/'raw.json',missing)
    project(path/'raw.json',3,path/'before.json','missing-before-published')
    project(path/'raw.json',4,path/'at-release.json','missing-at-release')
    checker(path/'at-release.json',path/'checked.json','missing-legal-check',origin=4,raw=path/'raw.json')
    command([PYTHON,'-X','utf8','-B',SOURCE/'forecast_reference.py','--input',path/'at-release.json','--out',path/'forecast.json'],'missing-highest-forecast')
    mr=load(path/'forecast.json');v=[Fraction(r['value']['numerator'],r['value']['denominator']) for r in mr['forecasts']]
    check('highest_missing_not_old_nonmissing_backfill',len(load(path/'before.json')['observations'])==3 and len(load(path/'at-release.json')['observations'])==4 and v==[18,20],{'forecast_exact':[str(x) for x in v],'older_tick1_value':999,'latest_tick1_missing':True})
    short=json.loads(json.dumps(missing));short['observations']=[r for r in short['observations'] if r['event_tick']!=2];save(path/'short-raw.json',short)
    project(path/'short-raw.json',4,path/'short-snapshot.json','missing-insufficient-projection')
    result=command([PYTHON,'-X','utf8','-B',SOURCE/'forecast_reference.py','--input',path/'short-snapshot.json','--out',path/'unused.json'],'missing-insufficient-execution',2)
    check('highest_missing_insufficient_explicit_execution_error',json.loads(result.stdout)=={'status':'execution_failed','error':'insufficient_history:S'})
    save(ROOT/'repair-and-cold-checks.json',checks)
    assessment={'stage':'local_asof_primitive_repaired_and_independently_qualified','checks':len(checks),'all_passed':all(r['passed'] for r in checks),'failed':[r['name'] for r in checks if not r['passed']],
       'new_independent_micro_worker_executions':1,'new_Provider_solver_GPU_or_UI':0,'exact_OLS':[24,26],'MAE':0,'last_value_MAE':3,'highest_missing_forecasts':[18,20],'all_own_containers_naturally_terminal_then_exact_removed':True,'seconds':time.perf_counter()-start,'full_L02_frozen':False,'candidate_score':None,'hours_or_statistical_maturity':False,'original_bool_bypass_preserved':True}
    save(ROOT/'stage-assessment.json',assessment);print(json.dumps(assessment,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
