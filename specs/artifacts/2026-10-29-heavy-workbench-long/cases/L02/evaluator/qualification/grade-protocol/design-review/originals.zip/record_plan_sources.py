"""Read and preserve the exact sources used for a design review; no grading or execution."""
import json
import shutil
import subprocess
import time
from pathlib import Path
from fractions import Fraction

ROOT = Path(__file__).resolve().parent
REPO = Path('D:/myhexin-local/opencorvus')
CASE = REPO / 'specs/artifacts/2026-10-29-heavy-workbench-long/cases/L02'
SOURCES = [
    REPO / 'specs/records/2026-10/2026-10-30-heavy-workbench-l02-qualification.md',
    CASE / 'rubric.draft.json',
    *[CASE / 'public' / p for p in ['TASK.draft.md', 'EXECUTION-CONTRACT.draft.md', 'RESEARCH-DELIVERY.draft.md', 'QUALITY-CONTRACT.draft.md']],
    *[CASE / 'evaluator/current-source' / p for p in ['l02_sealed.py', 'l02_pipeline.py', 'l02_report.py', 'l02_rubric.py', 'l02_quality.py', 'l02_execution.py', 'l02_study_data.py', 'run_l02_study.py', 'summarize_l02_study.py']],
    REPO / 'specs/artifacts/2026-10-29-heavy-workbench-long/cases/L06/evaluator/GRADING.md',
    REPO / 'specs/artifacts/2026-10-29-heavy-workbench-long/cases/L06/evaluator/qualification/current-source/l06_grade.py',
]
def save(name, value):
    (ROOT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

snapshot = ROOT / 'source-reviewed'
snapshot.mkdir(exist_ok=False)
inventory = []
for source in SOURCES:
    relative = source.relative_to(REPO)
    target = snapshot / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
    inventory.append({'path': str(source), 'snapshot': str(target.relative_to(ROOT)), 'bytes': source.stat().st_size,
                      'identity': 'actual bytes copied for review; no source hash or snapshot existence used as a functional pass'})
save('source-inventory.json', inventory)
rubric = json.loads((CASE/'rubric.draft.json').read_text(encoding='utf-8'))
leaves = [c for g in rubric['groups'] for c in g['criteria']]
save('rubric-observed.json', {'case': rubric['case'], 'status': rubric['status'], 'leaves': len(leaves),
    'research_leaves': len([c for c in leaves if not c['quality']]), 'quality_leaves': len([c for c in leaves if c['quality']]),
    'total_weight': str(sum(Fraction(c['weight']) for c in leaves)),
    'research_weight': str(sum(Fraction(c['weight']) for c in leaves if not c['quality'])),
    'quality_weight': str(sum(Fraction(c['weight']) for c in leaves if c['quality'])),
    'critical_count': sum(c['critical'] for c in leaves), 'publication': rubric['publication'], 'readiness': rubric['readiness'],
    'current_scoring': rubric['scoring'], 'scope': 'static description, not a test or a qualified grade'})
save('research-leaves-observed.json', [c for c in leaves if not c['quality']])
status = subprocess.run(['git','status','--short'],cwd=REPO,capture_output=True,text=True,encoding='utf-8')
(ROOT/'git-status-observed.txt').write_text(status.stdout,encoding='utf-8')
save('git-status-command.json', {'argv':['git','status','--short'],'cwd':str(REPO),'exit_code':status.returncode,
    'scope':'read only; all shared changes retained; reviewer writes solely this external review root'})
print(json.dumps({'sources':len(inventory),'rubric':{'research':40,'quality':26,'weight':'100'},'new_experiments':0,'repository_modified':False},ensure_ascii=False))
