"""One new grade-only protocol mutation; no native programme execution."""
import json
import shutil
import sqlite3
import subprocess
import sys
import time
from pathlib import Path

ROOT=Path(__file__).resolve().parent
REPO=Path('D:/myhexin-local/opencorvus')
CASE=REPO/'specs/artifacts/2026-10-29-heavy-workbench-long/cases/L02'
Q=Path('D:/opencorvus-benchmark-runs/l02-source-bound-grade-qualification-20261030')
ORIGINAL=Path('D:/opencorvus-benchmark-runs/l02-grader-state-qualification-20261030/bad-json/run')
snapshot=ROOT/'source-initial';snapshot.mkdir(parents=True,exist_ok=False)
for p in (CASE/'evaluator/current-source').glob('*.py'):shutil.copy2(p,snapshot/p.name)
shutil.copy2(CASE/'rubric.draft.json',ROOT/'rubric-initial.json')
shutil.copy2(CASE/'public/REVIEW-ANCHORS.draft.md',ROOT/'REVIEW-ANCHORS-initial.md')
sys.path.insert(0,str(snapshot))
from l02_execution import read_archive,json_bytes

run=ROOT/'mutation-state-only';run.mkdir()
paths=[ORIGINAL/'registration.zip',ORIGINAL/'runs.sqlite3',*ORIGINAL.glob('cells/*/prepared.zip'),*ORIGINAL.glob('cells/*/terminal.zip'),*ORIGINAL.glob('cells/*/accepted.zip')]
original_bytes={str(p.relative_to(ORIGINAL)):p.read_bytes()for p in paths}
for name,value in original_bytes.items():
    p=run/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(value)
with sqlite3.connect(run/'runs.sqlite3')as db:
    db.row_factory=sqlite3.Row;before=dict(db.execute('select * from cell where id=1').fetchone())
    db.execute('update cell set phase=?,failure=? where id=1',('terminal',None))
    after=dict(db.execute('select * from cell where id=1').fetchone())

assignment=ROOT/'original-assignment.zip';shutil.copy2(Q/'evaluation/assignment.zip',assignment)
bundle=read_archive(assignment)
captured={name[10:]:value for name,value in bundle.items()if name.startswith('execution/')}
argv=[sys.executable,'-X','utf8','-B',str(snapshot/'l02_grade.py'),'grade','--assignment',str(assignment),'--run',str(run),'--out',str(ROOT/'state-mutation-grade')]
start=time.perf_counter();p=subprocess.run(argv,capture_output=True,text=True,encoding='utf-8')
(ROOT/'state-mutation-command.json').write_bytes(json_bytes({'argv':argv,'exitcode':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'seconds':time.perf_counter()-start}))
resultpath=ROOT/'state-mutation-grade/assessment.json';assessment=json.loads(resultpath.read_text(encoding='utf-8'))if resultpath.exists()else None
newbytes={name:(run/name).read_bytes()for name in captured}
result={'kind':'synthetic evaluator-ledger-only mutation on copied actual formal run; not candidate judgement',
    'before':before,'after':after,'execution_bundle_members':list(captured),
    'captured_ZIP_bytes_still_match':newbytes==captured,
    'original_canonical_files_retained':all((ORIGINAL/name).read_bytes()==value for name,value in original_bytes.items()),
    'actual_exit':p.returncode,'response':json.loads(p.stdout),
    'C01':None if assessment is None else next(f for f in assessment['findings']if f['id']=='C01'),
    'expected':'facility_evaluation_binding_invalid or an equally explicit original-state binding error; not silent assessment of a changed stage',
    'new_native_processes':0,'candidate_score':None}
(ROOT/'state-mutation-observation.json').write_bytes(json_bytes(result))
print(json.dumps(result,ensure_ascii=False))
