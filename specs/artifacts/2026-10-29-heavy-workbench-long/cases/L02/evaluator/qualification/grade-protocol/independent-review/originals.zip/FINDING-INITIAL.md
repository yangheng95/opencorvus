# B01：初版 assignment 漏绑定原逻辑执行阶段

本项是评估侧协议 mutation，不是候选成绩或新 native。保留初始源码 `source-initial/`、原包 `original-assignment.zip`、变异副本 `mutation-state-only/` 与实际命令/输出，不用修后结果覆盖。

从真实正式 bad-json run 复制 canonical registration/prepared/terminal 和 SQLite。只在副本第一格把 `phase=failed` 改为 `terminal`、`failure` 改为 null；run_id、CID、source/input/output/native 及所有捕获 ZIP 字节均保持原值。原真实 run 的 canonical 文件经实际比较保持不变。

以原 assignment 调真实 `l02_grade.py grade`，实际 Python subprocess **exit4/assessment_incomplete**，C01 从原 verified_fail 变成 unassessed，所有66叶未评、known_critical_failures=[]。原 assignment 中 `execution/` 只有 registration.zip、prepared.zip、terminal.zip，未包含当时的 cell/event 逻辑状态。证明包身份绑定只覆盖部分原事实；没有拒绝同原包被套到另一执行阶段。

根因在初版 `l02_sealed.capture`/`l02_evaluation.load_assignment`：capture 读取原 DB 行供 inspection 使用，但 `inspection.originals` 仅返回 ZIP 字节；评估包与后续比较因此漏了 DB 逻辑状态。

最小建议：同一已有 owner 锁/DB 快照中将原 run/cell/event 的实际逻辑行编码为确定的来源对象，包内保存并与当前同一捕获比较。不加入本次捕获时间/临时路径，不写原 run、不加第二状态表、不改 schema1。缺该事实的未交付 prototype 包明确 stage_unbound，不从当前 DB 补造旧事实。合法阶段进展也需新 assignment/新 review，不能静默套旧评审。

实际原始证据：`state-mutation-command.json`、`state-mutation-observation.json`、`state-mutation-grade/assessment.json`。外层观察脚本 exit0仅说明记录完成，原 CLI returncode4另存；没有将此失败观察写成 all-pass。
