"""Only the repaired stage-binding controls; no numerical/native programme execution."""
import difflib
import json
import shutil
import subprocess
import sys
import time
import zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parent
CASE=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L02')
SRC=CASE/'evaluator/current-source'
Q=Path('D:/opencorvus-benchmark-runs/l02-source-bound-grade-qualification-20261030')
RUN=Path('D:/opencorvus-benchmark-runs/l02-grader-state-qualification-20261030/bad-json/run')
OUT=ROOT/'repair';OUT.mkdir(exist_ok=False)
snapshot=ROOT/'source-repaired';snapshot.mkdir(exist_ok=False)
changes=[];diff=[]
for p in SRC.glob('*.py'):
    shutil.copy2(p,snapshot/p.name);initial=ROOT/'source-initial'/p.name
    if not initial.exists()or p.read_bytes()!=initial.read_bytes():
        changes.append(p.name)
        if initial.exists():diff.extend(difflib.unified_diff(initial.read_text(encoding='utf-8').splitlines(True),p.read_text(encoding='utf-8').splitlines(True),fromfile='initial/'+p.name,tofile='repaired/'+p.name))
(OUT/'source.diff').write_text(''.join(diff),encoding='utf-8')
def save(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def call(name,args,expected_code,field,expected_value):
    argv=[sys.executable,'-X','utf8','-B',str(snapshot/'l02_grade.py'),*map(str,args)]
    start=time.perf_counter();p=subprocess.run(argv,capture_output=True,text=True,encoding='utf-8')
    receipt={'argv':argv,'exitcode':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'seconds':time.perf_counter()-start}
    save(OUT/(name+'-command.json'),receipt)
    value=json.loads(p.stdout)
    return {'name':name,'passed':p.returncode==expected_code and value[field]==expected_value,'exitcode':p.returncode,'response':value}

checks=[]
checks.append(call('old-unbound-protocol',['grade','--assignment',ROOT/'original-assignment.zip','--run',RUN,'--out',OUT/'old-unbound-result'],3,'error','facility_evaluation_stage_unbound'))
checks.append(call('new-stage-assignment',['prepare','--run',RUN,'--candidate-root',RUN.parent/'submission',
    '--rubric',CASE/'rubric.draft.json','--quality-policy',CASE/'evaluator/quality-policy.draft.json',
    '--reference',CASE/'evaluator/qualification/quality-study/registered-reference-originals.zip',
    '--reference-method',Q/'reference-method.json','--submission-id','reviewer-state-binding-protocol-control',
    '--reviewer-id','/root/benchmark_review','--subject-role','protocol_control','--out',OUT/'new-assignment'],0,'status','evaluation_assigned'))
assignment=OUT/'new-assignment/assignment.zip'
with zipfile.ZipFile(assignment)as z:
    header=json.loads(z.read('assignment.json'));rubric=json.loads(z.read('rubric.json'));ledger=json.loads(z.read('execution/ledger-snapshot.json'))
save(OUT/'captured-ledger-snapshot.json',ledger)
checks.append(call('new-bound-mutation',['grade','--assignment',assignment,'--run',ROOT/'mutation-state-only','--out',OUT/'mutated-result'],3,'error','facility_evaluation_binding_invalid'))

# This is a private all-unassessed schema fixture; it makes zero scientific judgements.
review=OUT/'private-pending-review';review.mkdir();shutil.copy2(assignment,review/'assignment.zip')
manual=[r for g in rubric['groups']for r in g['criteria']if r['method']=='independent_evaluator_review']
pending={'format':'l02-independent-review/1','assignment_id':header['assignment_id'],'submission_id':header['submission_id'],
    'reviewer_id':header['reviewer_id'],'anchor_version':header['anchor_version'],
    'disclosure':{'kind':'ai-agent','blinded':False,'familiarity':'protocol fixture, familiar with earlier reference; no content rating performed','limitations':'all 38 research leaves are unassessed; no scientific or professional judgement'},
    'findings':[{'id':r['id'],'status':'unassessed','basis':'private pending protocol fixture; no scientific assessment','sources':[],'dependency_roots':[]}for r in manual]}
save(review/'review.json',pending)
checks.append(call('new-bound-original-pending',['grade','--assignment',assignment,'--run',RUN,'--review',review,'--out',OUT/'normal-pending-result'],4,'status','assessment_incomplete'))
normal=json.loads((OUT/'normal-pending-result/assessment.json').read_text(encoding='utf-8'))
checks.append({'name':'normal_partial_counts_and_null_publication','passed':normal['counts']=={'blocked_candidate':27,'candidate_incomplete':0,'unassessed':38,'verified_fail':1,'verified_pass':0}and normal['total_score']is None and normal['study_complete']is None and normal['good']is None})
result={'checks':checks,'all_passed':all(c['passed']for c in checks),'source_changes':changes,'new_native_processes':0,
    'scope':'repaired stage binding and all-pending private review protocol only; no scientific ratings/full-success grade/freeze'}
save(OUT/'assessment.json',result)
print(json.dumps({'all_passed':result['all_passed'],'checks':len(checks),'source_changes':changes,'responses':[{'name':c['name'],'passed':c['passed'],'exitcode':c.get('exitcode')}for c in checks]},ensure_ascii=False))
