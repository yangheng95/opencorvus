"""Read-only addendum on a parent's already executed output metadata delta."""
import difflib
import json
import shutil
import zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'explicit-root-addendum';OUT.mkdir(exist_ok=False)
Q=Path('D:/opencorvus-benchmark-runs/l02-source-bound-grade-qualification-20261030')
SRC=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L02/evaluator/current-source/l02_evaluation.py')
shutil.copy2(SRC,OUT/SRC.name)
before=ROOT/'source-repaired/l02_evaluation.py'
diff=''.join(difflib.unified_diff(before.read_text(encoding='utf-8').splitlines(True),SRC.read_text(encoding='utf-8').splitlines(True),fromfile='prior-reviewed/l02_evaluation.py',tofile='current-root-evidence/l02_evaluation.py'))
(OUT/'source.diff').write_text(diff,encoding='utf-8')
for name in ['explicit-root-evidence-command.json','explicit-root-evidence-assessment.json']:
    shutil.copy2(Q/name,OUT/name)
shutil.copy2(Q/'explicit-root-evidence/assessment.json',OUT/'actual-grade-assessment.json')
value=json.loads((OUT/'actual-grade-assessment.json').read_text(encoding='utf-8'))
command=json.loads((OUT/'explicit-root-evidence-command.json').read_text(encoding='utf-8'))
with zipfile.ZipFile(ROOT/'repair/new-assignment/assignment.zip')as z:
    bundle={n:z.read(n)for n in z.namelist()}
cells={json.dumps(c['identity'],sort_keys=True):c for c in value['execution_inspection']['cells']}
checks=[]
def ck(name,passed):checks.append({'name':name,'passed':bool(passed)})
for leaf in ['C02','Q.macro.scaled_mse']:
    finding=next(f for f in value['findings']if f['id']==leaf)
    roots=finding['dependency_roots']
    ck(leaf+'_roots_are_actual_failed_inner',len(roots)==1 and all(cells[json.dumps(i,sort_keys=True)]['outcome']=='candidate_failed'and i['kind']=='predict'and i['level']=='inner'for i in roots))
    ck(leaf+'_original_terminal_and_stage_objects',all(s['object']in bundle for s in finding['sources'])and {'execution/cells/1/terminal.zip','execution/ledger-snapshot.json'}<={s['object']for s in finding['sources']})
ck('same_original_partial_counts_and_nulls',command['exitcode']==4 and value['counts']=={'blocked_candidate':27,'candidate_incomplete':0,'unassessed':38,'verified_fail':1,'verified_pass':0}and value['total_score']is None)
ck('C01_observations_include_actual_dependencies',all('dependencies'in o for o in next(f for f in value['findings']if f['id']=='C01')['observed_outcomes']))
result={'kind':'readonly observation of already executed parent delta','checks':checks,'all_passed':all(c['passed']for c in checks),
    'reviewer_new_CLI_or_native_runs':0,'old_reports_and_identity_observations_retained':True,
    'source_boundary':'new output evidence metadata version; earlier exact-source reports remain facts at their earlier snapshot, not reattributed to this delta',
    'scope':'two automatic dependency examples and unchanged partial state; no manual science, full-success path or new freeze'}
(OUT/'observation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'checks':len(checks),'all_passed':result['all_passed'],'new_runs':0},ensure_ascii=False))
