import argparse
import json
from pathlib import Path
import sqlite3
import sys
import time

parser=argparse.ArgumentParser();parser.add_argument('--source',type=Path,required=True)
parser.add_argument('--run',type=Path,required=True);parser.add_argument('--mode',choices=['host_fault','accept'],required=True);a=parser.parse_args()
sys.path.insert(0,str(a.source.resolve()))
from l02_execution import Ledger,Executor,ExecutionError,archived_json,json_bytes,atomic_bytes,run_lock

started=time.perf_counter();a.run.mkdir(parents=True,exist_ok=True)
ledger=Ledger(a.run,create=not (a.run/'runs.sqlite3').exists())
program={'files':['record.py'],'argv':['python','record.py']}
source={'record.py':b"from pathlib import Path\nPath('/output/result.json').write_text('{\"value\":7}')\n"}
def validate(files):
    if a.mode=='host_fault':raise RuntimeError('injected_author_validator_error')
    return {'actual':archived_json(files,'output/result.json')['value']}
try:
    with run_lock(a.run):
        try:
            value=Executor(ledger,'sha256:23ff8bfbf8055caa0b9fa5745ddb27cceea2f31d7d15b7a900c81112cdfe8ddf').invoke(
                {'kind':'report'},program,source,lambda:{},validate)
            result={'status':'accepted','assessment':archived_json(value,'assessment.json')}
        except ExecutionError as e:
            result={'status':'caught_execution_error','code':e.code,'candidate':e.candidate,'detail':e.detail}
        result['cell']=dict(ledger.db.execute('SELECT * FROM cell').fetchone())
        result['wall_seconds']=time.perf_counter()-started
        atomic_bytes(a.run/(a.mode+'-probe.json'),json_bytes(result));print(json.dumps(result))
finally:ledger.close()
