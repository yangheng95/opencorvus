"""Static comparison of declared rules and already captured protocol records."""
import json
import re
import shutil
from fractions import Fraction
from pathlib import Path

ROOT=Path(__file__).resolve().parent
CASE=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L02')
BEFORE=Path('D:/opencorvus-benchmark-runs/l02-full-grader-plan-review-20261030/source-reviewed/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L02/rubric.draft.json')
Q=Path('D:/opencorvus-benchmark-runs/l02-source-bound-grade-qualification-20261030')
current=json.loads((ROOT/'rubric-initial.json').read_text(encoding='utf-8'))
before=json.loads(BEFORE.read_text(encoding='utf-8'))
rows=[c for g in current['groups']for c in g['criteria']]
old=[c for g in before['groups']for c in g['criteria']]
identity=lambda c:(c['id'],str(c['weight']),c['critical'],c['quality'])
public=(ROOT/'REVIEW-ANCHORS-initial.md').read_text(encoding='utf-8')
anchors={i:body.strip() for i,body in re.findall(r'^\| ([A-F][0-9]{2}) \| (.*?) \|$',public,re.M)}
checks=[]
def ck(name,value):checks.append({'name':name,'passed':bool(value)})
ck('66_same_weight_critical_quality_id_tuples',len(rows)==66 and set(map(identity,rows))==set(map(identity,old)))
ck('85_research_15_quality_fixed100',sum(Fraction(c['weight'])for c in rows if not c['quality'])==85 and sum(Fraction(c['weight'])for c in rows if c['quality'])==15)
ck('40_exact_public_pass_boundaries',len(anchors)==40 and all(anchors[c['id']]==c['anchors']['pass']for c in rows if not c['quality']))
ck('38_manual_two_execution_26_quality_sources',sum(c['method']=='independent_evaluator_review'for c in rows)==38 and {(c['id'],c['source_rule'])for c in rows if c['method']=='registered_execution_checker'}=={('C01','full_numeric'),('C02','full_selection')}and sum(c['method']=='registered_quality_checker'for c in rows)==26)
ck('binary_anchors_and_pending_closure',all(set(c['anchors'])=={'pass','fail','candidate_incomplete','blocked_candidate','unassessed'}for c in rows if not c['quality']))
ck('original90_and_policy_weights_preserved',current['publication']==before['publication'])
ck('readiness_currently_false',all(v is False for v in current['readiness'].values()))
orig=json.loads((Q/'assessment.json').read_text(encoding='utf-8'))
shutil.copy2(Q/'assessment.json',ROOT/'parent-protocol-assessment-original.json')
for name in ['no-review-command.json','bound-pending-review-command.json','bad-reference-and-candidate-command.json','wrong-anchor-command.json','wrong-member-command.json','different-run-object-command.json']:
    shutil.copy2(Q/name,ROOT/name)
no=json.loads((Q/'without-review/assessment.json').read_text(encoding='utf-8'))
ck('observed_parent_no_review_38_pending_C01fail_C02Qblocked',no['counts']=={'blocked_candidate':27,'candidate_incomplete':0,'unassessed':38,'verified_fail':1,'verified_pass':0}and no['total_score']is None)
result={'checks':checks,'all_passed':all(c['passed']for c in checks),'scope':'static rule/object and parent original receipt comparison, not independent rerun or scientific rating','new_experiments':0}
(ROOT/'rules-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'checks':len(checks),'all_passed':result['all_passed'],'failed':[c['name']for c in checks if not c['passed']]},ensure_ascii=False))
