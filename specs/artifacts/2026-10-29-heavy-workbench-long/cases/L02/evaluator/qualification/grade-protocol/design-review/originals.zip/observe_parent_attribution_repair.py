"""Read existing parent-owned facts only; no process/container/executor invocation."""
import json
import shutil
import sqlite3
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
Q = Path('D:/opencorvus-benchmark-runs/l02-grader-state-qualification-20261030')
OUT = ROOT / 'parent-attribution-observation'
OUT.mkdir(exist_ok=False)

def load(path):
    return json.loads(path.read_text(encoding='utf-8'))

facts = []
for run_name in ['red-host-fault','repaired-host-fault']:
    run = Q / run_name
    dest = OUT / run_name
    dest.mkdir()
    for probe in run.glob('*-probe.json'):
        shutil.copy2(probe,dest/probe.name)
    probes = {p.name:load(p) for p in run.glob('*-probe.json')}
    with sqlite3.connect((run/'runs.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
        db.row_factory=sqlite3.Row
        cell=dict(db.execute('select * from cell').fetchone())
        events=[dict(row) for row in db.execute('select * from event order by id')]
    with zipfile.ZipFile(run/'cells/1/terminal.zip') as archive:
        native=json.loads(archive.read('terminal-inspect.json'))
        output=json.loads(archive.read('output/result.json'))
    commands=[load(p) for p in (run/'cells/1').glob('*.json')]
    ops={name:[{'argv':c['argv'],'exitcode':c['exitcode'],'stdout':c['stdout']} for c in commands if c['argv'][1:2]==[name]] for name in ['create','start','rm']}
    fact={'run':run_name,'source':str(run),'probes':probes,'final_cell':cell,'native':{'Id':native['Id'],'Name':native['Name'],'Image':native['Image'],'State':native['State']},'actual_output':output,'operations':ops,'ledger_events':events}
    facts.append(fact)
    (dest/'facts.json').write_text(json.dumps(fact,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

for version in ['source-before','source-attribution-repaired']:
    for name in ['l02_execution.py','l02_pipeline.py']:
        dest=OUT/version/name
        dest.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(Q/version/name,dest)
shutil.copy2(Q/'probe_attribution.py',OUT/'probe_attribution.py')
result={'kind':'read_only_observation_of_parent_originals','new_experiments':0,
        'red':{'native_exit':facts[0]['native']['State']['ExitCode'],'phase':facts[0]['final_cell']['phase'],'failure':facts[0]['final_cell']['failure']},
        'repaired_first':facts[1]['probes']['host_fault-probe.json'],
        'repaired_final':{'native_exit':facts[1]['native']['State']['ExitCode'],'phase':facts[1]['final_cell']['phase'],'failure':facts[1]['final_cell']['failure'],'same_cid_as_initial_host_error':facts[1]['native']['Id']==facts[1]['probes']['host_fault-probe.json']['cell']['cid'],'operation_counts':{k:len(v)for k,v in facts[1]['operations'].items()}},
        'scope':'observed source, terminal, SQL and native command facts; reviewer did not rerun author fault injection or current implementation'}
(OUT/'observation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
