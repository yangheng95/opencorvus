from datetime import datetime,timezone
from fractions import Fraction
import json
from pathlib import Path
import subprocess
import sys
import time

root=Path(__file__).parent;source=root/'source';old=Path('D:/opencorvus-benchmark-runs/l02-full-materials-20261030/main')
started=time.perf_counter();checks=[]
for name in ['build','decode-archive','decode-development']:
 receipt=json.loads((root/(name+'-command.json')).read_text());assert receipt['exitcode']==0
 checks.append({'name':'actual-completed:'+name,'passed':True})
for name in ['observations.csv','covariate-vintages.csv','series.csv','hierarchy.csv','availability.json','units.json']:
 assert (root/'materials/full-private'/name).read_bytes()==(old/'materials-final/full-private'/name).read_bytes()
 checks.append({'name':'unchanged-full-source-data:'+name,'passed':True})
raw=json.loads((root/'decoded-archive/canonical.json').read_text());oldraw=json.loads((old/'decoded-final-archive/canonical.json').read_text())
assert raw==oldraw;checks.append({'name':'same-complete-numerical-facts','passed':True})
grid=json.loads((root/'decoded-archive/origin-grid.json').read_text());oldgrid=json.loads((old/'decoded-final-archive/origin-grid.json').read_text())
new_by={g['origin_id']:g for g in grid['origins']};old_by={g['origin_id']:g for g in oldgrid['origins']}
inherited=[name for name,g in new_by.items() if g['role']!='development']
assert len(inherited)==48 and all(new_by[name]==old_by[name] for name in inherited)
checks.append({'name':'48-inner-outer-grids-retained','passed':True})
epoch=datetime(2022,1,1,tzinfo=timezone.utc)
def tick(value):return int((datetime.fromisoformat(value.replace('Z','+00:00'))-epoch).total_seconds())//3600
cutoff=tick('2024-08-01T09:00:00Z');published=tick('2024-02-01T09:00:00Z')
assert min(g['origin_tick'] for g in new_by.values() if g['role']=='inner')>cutoff
development=json.loads((root/'decoded-development/canonical.json').read_text())
assert all(r['release_tick']<=cutoff for key in ['observations','covariates'] for r in development[key])
checks.append({'name':'all-inner-after-public-cutoff-and-every-public-release-authorized','passed':True})
scales={};leaves=[r['series_id'] for r in grid['series_catalogue'] if r['kind']=='leaf']
assert len(leaves)==4
for name in leaves:
 rows=[r for r in raw['observations'] if r['series_id']==name and r['revision_id']==2 and tick('2023-01-02T00:00:00Z')<=r['event_tick']<=tick('2024-01-01T00:00:00Z')]
 assert len(rows)==365 and all(r['quality_flag']=='valid' and r['release_tick']<=published for r in rows)
 scales[name]=sum(Fraction(r['value']) for r in rows)/365
for parent in [r['series_id'] for r in grid['series_catalogue'] if r['kind']=='aggregate']:
 scales[parent]=sum(int(edge['weight'])*scales[edge['child']] for edge in grid['hierarchy'] if edge['parent']==parent)
checks.append({'name':'1460-leaf-scale-terminals-with-aggregate-from-registered-sum','passed':True})
argv=[sys.executable,'-X','utf8','-B',str(source/'audit_material_projection.py'),'--decoded',str(root/'decoded-archive'),'--out',str(root/'six-development-projections')]
for name,g in new_by.items():
 if g['role']=='development':argv+=['--origin-id',name]
t=time.perf_counter();p=subprocess.run(argv,capture_output=True,text=True,encoding='utf-8')
(root/'six-new-development-projections-command.json').write_text(json.dumps(dict(argv=argv,exitcode=p.returncode,stdout=p.stdout,stderr=p.stderr,wall_seconds=time.perf_counter()-t),indent=2),encoding='utf-8')
assert p.returncode==0,(p.stdout,p.stderr)
summary={'status':'new_public_information_boundary_qualified','checks':checks,'new_development_origins':6,'inherited_inner_outer_grids':48,
 'development_observations':len(development['observations']),'development_covariates':len(development['covariates']),
 'scales_litres':{k:str(v) for k,v in scales.items()},'scale_visibility':'evaluator/2024+selector only; not earlier 2023 forecast workers',
 'delta_wall_seconds':time.perf_counter()-started,'first_qualification_script_error':'initial validator iterated raw six-node registry as though aggregate observations existed; four leaf sources plus registered sum are authoritative',
 'scope':'new public cutoff/grid/material projection only; not predictor, selector, full L02, candidate grade or hours'}
(root/'assessment.json').write_text(json.dumps(summary,indent=2),encoding='utf-8');print(json.dumps(summary))
