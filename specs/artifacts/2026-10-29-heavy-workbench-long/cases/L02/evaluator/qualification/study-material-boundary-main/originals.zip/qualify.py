from datetime import datetime,timezone
from fractions import Fraction
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

root=Path(__file__).parent;root.mkdir(exist_ok=True,parents=True)
case=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L02')
source=root/'source';source.mkdir()
for file in (case/'evaluator/current-source').glob('*.py'):shutil.copyfile(file,source/file.name)
shutil.copyfile(case/'evaluator/material-contract.json',source/'material-contract.json')
shutil.copyfile(case/'evaluator/study-contract.draft.json',source/'study-contract.draft.json')
checks=[];started=time.perf_counter()
def run(name,script,*args):
 argv=[sys.executable,'-X','utf8','-B',str(source/script),*map(str,args)];t=time.perf_counter();p=subprocess.run(argv,capture_output=True,text=True,encoding='utf-8')
 (root/(name+'-command.json')).write_text(json.dumps(dict(argv=argv,exitcode=p.returncode,stdout=p.stdout,stderr=p.stderr,wall_seconds=time.perf_counter()-t),indent=2),encoding='utf-8')
 assert p.returncode==0,(name,p.stdout,p.stderr)
run('build','build_materials.py','--contract',source/'material-contract.json','--out',root/'materials')
for role,folder in [('archive','full-private'),('development','development-public')]:
 run('decode-'+role,'decode_materials.py','--contract',source/'material-contract.json','--role',role,'--input',root/'materials'/folder,'--out',root/('decoded-'+role))
old=Path('D:/opencorvus-benchmark-runs/l02-full-materials-20261030/main')
full=root/'materials/full-private';dev=root/'materials/development-public'
for name in ['observations.csv','covariate-vintages.csv','series.csv','hierarchy.csv','availability.json','units.json']:
 assert (full/name).read_bytes()==(old/'materials-final/full-private'/name).read_bytes(),name
 checks.append({'name':'unchanged-full-source-data:'+name,'passed':True})
raw=json.loads((root/'decoded-archive/canonical.json').read_text());oldraw=json.loads((old/'decoded-final-archive/canonical.json').read_text())
assert raw==oldraw;checks.append({'name':'same-complete-numerical-facts','passed':True})
grid=json.loads((root/'decoded-archive/origin-grid.json').read_text());oldgrid=json.loads((old/'decoded-final-archive/origin-grid.json').read_text())
new_by={g['origin_id']:g for g in grid['origins']};old_by={g['origin_id']:g for g in oldgrid['origins']}
inherited=[name for name,g in new_by.items() if g['role']!='development']
assert len(inherited)==48 and all(new_by[name]==old_by[name] for name in inherited)
checks.append({'name':'48-inner-outer-grids-retained','passed':True})
epoch=datetime(2022,1,1,tzinfo=timezone.utc)
def tick(value):return int((datetime.fromisoformat(value.replace('Z','+00:00'))-epoch).total_seconds())//3600
cutoff=tick('2024-08-01T09:00:00Z');published=tick('2024-02-01T09:00:00Z')
assert min(g['origin_tick'] for g in new_by.values() if g['role']=='inner')>cutoff
development=json.loads((root/'decoded-development/canonical.json').read_text())
assert all(r['release_tick']<=cutoff for key in ['observations','covariates'] for r in development[key])
checks.append({'name':'all-36-inner-after-public-cutoff-and-every-public-release-authorized','passed':True})
scales={}
for name in raw['series']:
 rows=[r for r in raw['observations'] if r['series_id']==name and r['revision_id']==2 and tick('2023-01-02T00:00:00Z')<=r['event_tick']<=tick('2024-01-01T00:00:00Z')]
 assert len(rows)==365 and all(r['quality_flag']=='valid' and r['release_tick']<=published for r in rows)
 scales[name]=str(sum(Fraction(r['value']) for r in rows)/365)
checks.append({'name':'1460-scale-terminal-values-actually-published-by-Feb1','passed':True})
args=[]
for name,g in new_by.items():
 if g['role']=='development':args+=['--origin-id',name]
assert len(args)==12
run('six-new-development-projections','audit_material_projection.py','--decoded',root/'decoded-archive','--out',root/'six-development-projections',*args)
summary={'status':'new_public_information_boundary_qualified','checks':checks,'six_new_development_origins':6,'inherited_inner_outer_grids':48,
 'development_observations':len(development['observations']),'development_covariates':len(development['covariates']),
 'scale_leaf_litres':scales,'scale_visibility':'evaluator/2024+selector only; not earlier 2023 forecast workers',
 'wall_seconds':time.perf_counter()-started,'scope':'new public cutoff/grid/material projection only, not a daily predictor, selection, full L02, candidate grade or hours'}
(root/'assessment.json').write_text(json.dumps(summary,indent=2),encoding='utf-8');print(json.dumps(summary))
