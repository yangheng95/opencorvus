from pathlib import Path
import difflib
import json
import shutil
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
REPO = Path('D:/myhexin-local/opencorvus')
CASE = REPO/'specs/artifacts/2026-10-29-heavy-workbench-long/cases/L02'
OUT = CASE/'evaluator/qualification/scientific-reference-preflight'
OUT.mkdir(parents=True,exist_ok=False)
shutil.copyfile(ROOT/'precheck-assessment.json',OUT/'assessment.json')
shutil.copyfile('D:/opencorvus-benchmark-runs/l02-report-provenance-qualification-20261030/original-numeric-projection.zip',ROOT/'precheck-input-original.zip')
(ROOT/'tooling-errors.json').write_text(json.dumps({'scope':'tool API rejected before source writes; not candidate or native failures',
    'messages':['apply_patch verification failed: invalid patch: multiple operations target report_l02_reference.py',
                'apply_patch verification failed: Failed to find expected lines: standalone Inner selection substring was part of a longer line'],
    'correction':'scoped reporter/helper updates; second rejected same-text change was unnecessary'},indent=2),encoding='utf-8')
with zipfile.ZipFile(OUT/'originals.zip','w',zipfile.ZIP_DEFLATED) as z:
    for path in sorted(ROOT.rglob('*')):
        if path.is_file():z.write(path,path.relative_to(ROOT).as_posix())
review = Path('D:/opencorvus-benchmark-runs/l02-scientific-reference-preflight-review-20261030')
stage = json.loads((review/'stage-assessment.json').read_text(encoding='utf-8'))
dest = OUT/'independent-review';dest.mkdir()
for name in ['REVIEW.md','stage-assessment.json']:shutil.copyfile(review/name,dest/name)
with zipfile.ZipFile(dest/'originals.zip','w',zipfile.ZIP_DEFLATED) as z:
    for path in sorted(review.rglob('*')):
        if path.is_file():z.write(path,path.relative_to(review).as_posix())
for path,needle in [('specs/README.md','[L02发布时间输入资格]'),
                    ('specs/artifacts/README.md','[长程任务资格与便宜实验]'),
                    ('specs/records/2026-10/README.md','[2026-10-30-heavy-workbench-l02-qualification.md]')]:
    old=subprocess.check_output(['git','show',':'+path],cwd=REPO).decode('utf-8')
    current=(REPO/path).read_text(encoding='utf-8')
    replacement=next(line for line in current.splitlines() if needle in line)
    changed=''.join(replacement+'\n' if needle in line else line for line in old.splitlines(keepends=True))
    patch=''.join(difflib.unified_diff(old.splitlines(keepends=True),changed.splitlines(keepends=True),fromfile='a/'+path,tofile='b/'+path)).encode('utf-8')
    subprocess.run(['git','apply','--cached','--whitespace=nowarn','-'],cwd=REPO,input=patch,check=True)
print(json.dumps({'archived':str(OUT),'review_stage':stage,'shared_indexes':'own line only; worktree reordering preserved'},ensure_ascii=False))
