"""One formal reference owner. No time cap, retry loop or extra model calls."""
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
def now():return datetime.now(timezone.utc).isoformat()
def save(name,value):(ROOT/name).write_text(json.dumps(value,indent=2,ensure_ascii=False),encoding='utf-8')

launch = json.loads((ROOT/'launch.json').read_text(encoding='utf-8'))
source = ROOT/'frozen-source'
command = [sys.executable,'-X','utf8','-B',str(source/'run_l02_study.py'),
    '--submission',str(ROOT/'submission'),
    '--raw','D:/opencorvus-benchmark-runs/l02-daily-loop-qualification-20261030/main/raw',
    '--material-contract',str(ROOT/'material-contract.json'),
    '--study',str(ROOT/'study-contract.json'),
    '--image','sha256:23ff8bfbf8055caa0b9fa5745ddb27cceea2f31d7d15b7a900c81112cdfe8ddf',
    '--out',str(ROOT/'formal-run')]
began = time.perf_counter();started = now()
with (ROOT/'owner.stdout.txt').open('wb') as out,(ROOT/'owner.stderr.txt').open('wb') as err:
    p = subprocess.Popen(command,cwd=str(ROOT),stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
    save('owner-started.json',{'started_at':started,'pid':p.pid,'argv':command,'source_commit':launch['source_commit'],
        'subject_role':'reference_qualification','formal_assignment':True,'total_time_cap':None,
        'scope':'new full raw-to-report author reference; not LLM candidate or hour evidence'})
    code = p.wait()
save('owner-terminal.json',{'started_at':started,'finished_at':now(),'pid':p.pid,'argv':command,
    'exit_code':code,'wall_seconds':time.perf_counter()-began,'source_commit':launch['source_commit'],
    'scope':'natural owner result; execution/quality/scientific review are separate'})
raise SystemExit(code)
