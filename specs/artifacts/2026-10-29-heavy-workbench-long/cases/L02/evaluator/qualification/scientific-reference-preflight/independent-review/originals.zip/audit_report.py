"""Pure standard-library preflight; no reader, report main, fitting or container."""
import csv
from decimal import Decimal
from fractions import Fraction as F
import json
import shutil
import sys
import zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parent
SRC=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L02/evaluator/current-source')
Q=Path('D:/opencorvus-benchmark-runs/l02-scientific-reference-20261030')
SNAP=ROOT/'source-reviewed';SNAP.mkdir(parents=True,exist_ok=False)
for name in ['report_l02_reference.py','report_diagnostics.py','package_l02_reference.py','reference-data.md','reference-sources.md','reference-reproduce.md']:
    shutil.copy2(SRC/name,SNAP/name)
shutil.copy2(Q/'precheck.py',ROOT/'parent-precheck.py')
shutil.copy2(Q/'precheck-assessment.json',ROOT/'parent-precheck-assessment.json')
sys.path.insert(0,str(SNAP))
from report_diagnostics import derive,interval_diagnostics,decision,discussion
from report_l02_reference import wis

checks=[]
def ck(name,value,details=None):checks.append({'name':name,'passed':bool(value),'details':details})
q={'0.025':0,'0.1':0,'0.25':0,'0.5':1,'0.75':2,'0.9':4,'0.975':6}
ck('nonunit_hand_MSE_WIS',((F(2)-3)/2)**2==F(1,4)and wis(F(3),q)==F(61,70)and wis(F(3),q)/2==F(61,140))
ck('three_interval_levels_hits_widths',[(d['coverage_level_percent'],d['hits'],d['width_L'],d['assigned_days'])for d in interval_diagnostics(F(3),q)]==[(50,0,F(2),1),(80,1,F(4),1),(95,1,F(6),1)])
ck('q_mean_differ_realized_negative_example',[decision(F(q[k]),F(3),c)['loss_cost_units']for c,k in [(1,'0.5'),(3,'0.75'),(9,'0.9')]]==[2,3,1]and [decision(F(2),F(3),c)['loss_cost_units']for c in [1,3,9]]==[1,3,9])

original=Path('D:/opencorvus-benchmark-runs/l02-report-provenance-qualification-20261030/original-numeric-projection.zip')
with zipfile.ZipFile(original)as z:
    data=json.loads(z.read('results.json'),parse_float=Decimal)
    manifest=json.loads(z.read('provenance/manifest.json'))
    sources=[]
    for cell in manifest['cells']:
        for a in cell['artifacts']:
            if a['output_member']=='result/fit.json':
                sources.append({'identity':cell['identity'],'source':a['input_path'],'fit':json.loads(z.read(a['input_path']),parse_float=Decimal)})
tables=derive(data)
row=data['outer_results'][0];truth={(r['series_id'],r['target_tick']):F(r['value'])for r in row['labels']}
interval_checks=[];action_checks=[];summary_checks=[]
for r in tables['intervals']:
    lo,hi={50:('0.25','0.75'),80:('0.1','0.9'),95:('0.025','0.975')}[r['coverage_level_percent']]
    actual=[v for v in row['forecasts'][r['method_id']]['forecasts']if v['series_id']==r['series_id']]
    hits=sum(F(v['quantiles'][lo])<=truth[r['series_id'],v['target_tick']]<=F(v['quantiles'][hi])for v in actual)
    width=sum(F(v['quantiles'][hi])-F(v['quantiles'][lo])for v in actual)/14
    interval_checks.append(len(actual)==14 and r['hits']==hits and r['assigned_days']==14 and r['width_L']==width)
ck('all54_interval_rows_independent_raw_Fraction',len(interval_checks)==54 and all(interval_checks))
ck('fixed_method_and_selected_summary_grid',len(tables['method-interval-summary'])==54 and len(tables['policy-interval-summary'])==18 and all(r['assigned_days']==14 for r in tables['method-interval-summary']+tables['policy-interval-summary']))
for r in tables['operating-ledger']:
    f=next(v for v in row['forecasts'][row['selected_method_id']]['forecasts']if(v['series_id'],v['target_tick'])==(r['series_id'],r['target_tick']))
    y=truth[r['series_id'],r['target_tick']];under=int(r['shortage_cost_unit_per_L'])
    okay=r['method_id']==row['selected_method_id']and r['truth_L']==y and r['frozen_quantile']=={1:'0.5',3:'0.75',9:'0.9'}[under]
    for prefix,action in [('',F(f['quantiles'][r['frozen_quantile']])),('mean_',F(f['mean']))]:
        short=max(y-action,F());over=max(action-y,F())
        expected={'action_L':action,'shortage_L':short,'overage_L':over,'shortage_cost_units':under*short,'overage_cost_units':over,'loss_cost_units':under*short+over}
        okay=okay and all(r[prefix+k]==v for k,v in expected.items())
    action_checks.append(okay)
ck('all168_action_rows_independent_both_actions_and_costs',len(action_checks)==168 and all(action_checks))
for summary in tables['operating-summary']:
    group=[r for r in tables['operating-ledger']if(r['series_id'],r['shortage_cost_unit_per_L'])==(summary['series_id'],summary['shortage_cost_unit_per_L'])]
    summary_checks.append(summary['assigned_days']==14 and len(group)==14 and all(summary['average_'+prefix+k]==sum(r[prefix+k]for r in group)/14 for prefix in ['','mean_']for k in ['shortage_L','overage_L','shortage_cost_units','overage_cost_units','loss_cost_units']))
ck('all12_cost_summaries_complete_Fraction',len(summary_checks)==12 and all(summary_checks))

text='\n'.join(discussion(data,tables,sources,row))
(ROOT/'derived-discussion-one-outer.txt').write_text(text,encoding='utf-8')
ck('pure_discussion_uses_actual_origin_and_diagnostic_sources',row['outer_id']in text and any(s['source']in text for s in sources if s['identity'].get('level')=='outer'))
package_dir=Q/'submission-final-preflight'
manifest=json.loads((package_dir/'submission.json').read_text(encoding='utf-8'))
report_files=manifest['programs']['report']['files']
assets=['reference-data.md','reference-sources.md','reference-reproduce.md','report_diagnostics.py']
ck('actual_final_packaged_declared_asset_bytes',all(n in report_files and (package_dir/n).read_bytes()==(SNAP/n).read_bytes()for n in assets))
ck('final_packaged_report_and_predictor_sources_are_current',all((package_dir/n).read_bytes()==(SRC/n).read_bytes()for p in manifest['programs'].values()for n in p['files']))
weighted=[]
for cost in [1,3,9]:
    group=[r for r in tables['operating-ledger']if r['shortage_cost_unit_per_L']==cost]
    weighted.append({'under_cost':cost,'station_days':len(group),**{k:str(sum(r[k]for r in group)/len(group))for k in ['shortage_L','overage_L','shortage_cost_units','overage_cost_units','loss_cost_units','mean_loss_cost_units']}})
(ROOT/'independent-cost-paragraph-expectations.json').write_text(json.dumps(weighted,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

result={'checks':checks,'all_passed':all(c['passed']for c in checks),'new_reader_report_container_forecast_native_calls':0,
    'scope':'hand calculation, old one-outer pure derived arithmetic and actual precheck package inspection; no full report or scientific judgement',
    'formal121_eligible_on_preflight':all(c['passed']for c in checks),'full_scientific_reference_approved':False,'candidate_score':None,
    'packaging_scope':str(package_dir),
    'prior_precheck_helper_equals_latest':(Q/'submission-precheck/report_diagnostics.py').read_bytes()==(SNAP/'report_diagnostics.py').read_bytes(),
    'prior_precheck_is_unchanged_historical_object':True}
(ROOT/'assessment.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'checks':len(checks),'all_passed':result['all_passed'],'failed':[c['name']for c in checks if not c['passed']],'new_native':0},ensure_ascii=False))
