import csv
from decimal import Decimal
from fractions import Fraction as F
import importlib
import json
from pathlib import Path
import shutil
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
SOURCE = Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L02/evaluator/current-source')
sys.path.insert(0,str(SOURCE))
from report_diagnostics import interval_diagnostics,decision,derive,COSTS
from report_l02_reference import wis
from package_l02_reference import package
from run_l02_study import validate_submission

checks = []
def check(name,condition):
    checks.append({'name':name,'passed':bool(condition)})
    if not condition:raise AssertionError(name)

q = {'0.025':0,'0.1':0,'0.25':0,'0.5':1,'0.75':2,'0.9':4,'0.975':6}
ds = interval_diagnostics(F(3),q)
check('analytic_interval_widths_hits',[(d['coverage_level_percent'],d['width_L'],d['hits'],d['assigned_days']) for d in ds]==[(50,F(2),0,1),(80,F(4),1,1),(95,F(6),1,1)])
check('analytic_scaled_mse',(F(2)-3)**2/F(2)**2==F(1,4))
check('analytic_wis',wis(F(3),q)==F(61,70))
check('analytic_scaled_wis',wis(F(3),q)/2==F(61,140))
check('quantile_action_expected',[decision(F(q[p]),F(3),c)['loss_cost_units'] for c,p in COSTS]==[F(2),F(3),F(1)])
check('exported_mean_expected',[decision(F(2),F(3),c)['loss_cost_units'] for c,p in COSTS]==[F(1),F(3),F(9)])

original = Path('D:/opencorvus-benchmark-runs/l02-report-provenance-qualification-20261030/original-numeric-projection.zip')
with zipfile.ZipFile(original) as z:
    data = json.loads(z.read('results.json'),parse_float=Decimal)
tables = derive(data)
check('original_one_outer_context',len(data['outer_results'])==1)
check('all_methods_nodes_levels_retained',len(tables['intervals'])==54 and len(tables['method-interval-summary'])==54 and len(tables['policy-interval-summary'])==18)
check('fixed_14_day_denominators',all(r['assigned_days']==14 for r in tables['intervals']+tables['policy-interval-summary']))
check('all_station_cost_actions',len(tables['operating-ledger'])==168 and len(tables['operating-summary'])==12)
for r in tables['operating-ledger']:
    check('ledger_components:'+r['series_id']+':'+str(r['target_tick'])+':'+str(r['shortage_cost_unit_per_L']),
          r['loss_cost_units']==r['shortage_cost_units']+r['overage_cost_units'] and
          r['mean_loss_cost_units']==r['mean_shortage_cost_units']+r['mean_overage_cost_units'])
check('actual_selector_binding',all(r['method_id']==data['outer_results'][0]['selected_method_id'] for r in tables['operating-ledger']))
check('complete_cost_summary',all(r['assigned_days']==14 and r['average_loss_cost_units']==r['average_shortage_cost_units']+r['average_overage_cost_units'] for r in tables['operating-summary']))

package(SOURCE.parent/'reference-pool.json',ROOT/'submission-precheck')
manifest,objects = validate_submission(ROOT/'submission-precheck')
check('actual_report_static_assets',all(name in manifest['programs']['report']['files'] and objects[name]==(SOURCE/name).read_bytes() for name in ['report_diagnostics.py','reference-data.md','reference-sources.md','reference-reproduce.md']))
snapshot = ROOT/'source-precheck';snapshot.mkdir()
for path in SOURCE.iterdir():
    if path.is_file():shutil.copyfile(path,snapshot/path.name)
(ROOT/'precheck-assessment.json').write_text(json.dumps({'status':'pure_derived_precheck_passed','checks':checks,'new_forecast_processes':0,'new_report_processes':0,'scope':'hand-calculation plus existing one-outer output derivation and package validation; no formal execution or scientific grade','tooling_initial_failure':'apply_patch rejected a combined delete/add on one path before writes; retried as scoped updates'},indent=2),encoding='utf-8')
print(json.dumps({'checks':len(checks),'passed':all(c['passed'] for c in checks),'new_native':0}))
