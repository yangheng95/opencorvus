from pathlib import Path
import json,sys,sqlite3,time,shutil,zipfile
ROOT=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L02')
SRC=ROOT/'evaluator/current-source';sys.path.insert(0,str(SRC))
from l02_pipeline import assess_selector
from l02_execution import json_bytes,ExecutionError
from l02_selection import choose
from material_contract import read_json,same_json_value

OUT=Path('D:/opencorvus-benchmark-runs/l02-selection-type-repair-20261030/final');OUT.mkdir(exist_ok=False)
shutil.copy2(SRC/'l02_selection.py',OUT/'l02_selection.py')
PEER=Path('D:/opencorvus-benchmark-runs/l02-final-contract-independent-review-20261030')
started=time.perf_counter();checks=[]
def run(name,payload,actual,study,expected_code=None):
    files={'input/inner.json':json_bytes(payload),'input/study.json':json_bytes(study),'output/result/selection.json':json_bytes(actual)}
    try:
        result=assess_selector(files,payload,study)
        ok=expected_code is None and result['status']=='selection_verified'
        row={'name':name,'status':result['status'],'passed':ok}
    except ExecutionError as e:
        row={'name':name,'code':e.code,'candidate':e.candidate,'passed':e.code==expected_code and e.candidate is True}
    checks.append(row)
    if not row['passed']:raise AssertionError(row)
for suffix in ['', '-one']:
    payload=read_json(PEER/('selection-bool'+suffix+'-payload.json'),decimal_numbers=True)
    bad=read_json(PEER/('selection-bool'+suffix+'-output.json'),decimal_numbers=True)
    study=read_json(ROOT/'public/study-contract.json',decimal_numbers=True)
    run('original-bool'+suffix,payload,bad,study,'selection_invalid')
    valid=choose(payload,study);run('rational-string'+suffix,payload,valid,study)
    equivalent={**valid,'method_mean_inner_scaled_mse':{k:('2/2' if v=='1' else '0/2') for k,v in valid['method_mean_inner_scaled_mse'].items()}}
    run('unreduced-equivalent'+suffix,payload,equivalent,study)
    minimal={k:v for k,v in valid.items() if k!='method_mean_inner_scaled_mse'};run('optional-omitted'+suffix,payload,minimal,study)
runroot=Path('D:/opencorvus-benchmark-runs/l02-scientific-reference-20261030/formal-run')
conn=sqlite3.connect('file:'+runroot.as_posix()+'/runs.sqlite3?mode=ro',uri=True);conn.row_factory=sqlite3.Row
rows=conn.execute('select * from cell').fetchall();conn.close()
for row in rows:
    identity=json.loads(row['identity'])
    if identity['kind']!='select':continue
    with zipfile.ZipFile(runroot/'cells'/str(row['id'])/'accepted.zip') as z:files={n:z.read(n) for n in z.namelist()}
    payload=json.loads(files['input/inner.json'],parse_float=__import__('decimal').Decimal)
    study=json.loads(files['input/study.json'],parse_float=__import__('decimal').Decimal)
    result=assess_selector(files,payload,study)
    original=json.loads(files['assessment.json'],parse_float=__import__('decimal').Decimal)
    ok=same_json_value(result,original)
    checks.append({'name':'original-accepted-'+str(row['id']),'outer_id':identity['outer_id'],'status':result['status'],'passed':ok})
    if not ok:raise AssertionError(identity)
result={'format':'l02-selection-type-repair/1','checks':checks,'all_passed':all(r['passed'] for r in checks),
 'elapsed_seconds':time.perf_counter()-started,'native_executions':0,
 'scope':'Real selector output checker, original bool controls and all 12 original accepted selector cells. No new forecasts, full reader or source-bound assignment grade.'}
(OUT/'assessment.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'all_passed':result['all_passed'],'checks':len(checks),'elapsed_seconds':result['elapsed_seconds'],'native_executions':0}))
