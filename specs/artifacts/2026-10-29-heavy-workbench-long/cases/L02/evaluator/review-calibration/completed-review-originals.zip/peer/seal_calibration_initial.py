"""Record the reviewer's content judgements, after sealing real38 and before key access."""
import json,shutil,zipfile,io
from datetime import datetime,timezone
from pathlib import Path
R=Path(__file__).resolve().parent
P=Path('D:/opencorvus-benchmark-runs/l02-research-calibration-20261030/packets')
instructions=json.loads((P/'assignment.json').read_text(encoding='utf-8'))
seal=json.loads((R/'initial-review-seal.json').read_text(encoding='utf-8'))
received=R/'calibration-materials';received.mkdir()
shutil.copy2(P/'assignment.json',received/'assignment.json')
ids=['B09','D06','D07','D09','E04','E05']
good={
'B09':('明确三个中央边际区间及经验配对残差，拒绝finite-sample/joint-path保证；实际表有完整coverage/width。','Methods and information timing; Complete interval and decision diagnostics'),
'D06':('实际weather/no-weather配对结果保消融更优，并明确不识别天气因果效应；transfer零训练特征不足识别新量效。','Actual comparisons and failure boundaries'),
'D07':('明确披露消融更优、June A1/ZA0/4和B1/under1 mean较好，不把整体改善说成全部胜出。','Actual comparisons; Quantile actions and exported-mean diagnostic'),
'D09':('明确层级/季节/重叠训练和选择依赖，不把12origin或表行当随机独立重复，不造p值。','Same-day leaves/zone totals and dependent windows paragraph'),
'E04':('三成本完整量化、缺余量暴露及mean反例与common原账一致；固定q映射不事后换，建议限定真实单期暴露。','three cost paragraphs and operating table'),
'E05':('明确单期连续L合成损失，没有库存/容量/调拨/联合尾部或真实机构认证，业务审查建议未宣称已执行。','operating limitations and handoff')}
bad={
'B09':('新增无条件断言central80给所有未来日/站点联合覆盖及finite-sample保证；边际表和经验42残差不支持，且June0/4为实际反例。此前正确免责声明不能洗掉新结论。','Final scientific and operating conclusions, paragraph1'),
'D06':('新增断言天气消融差异直接识别需求因果效应且无需假设。观察性预测配对仅比较方法表现，源/实验没有干预或识别依据。','Final scientific and operating conclusions, paragraph2'),
'D07':('新增断言selected天气MSE/WIS低于no-weather且无负消融；实际0.00490449>0.00443661、0.0268860>0.0251601，直接反向叙述。','Final scientific and operating conclusions, paragraph3'),
'D09':('新增把12outer和6node称独立随机重复并以行数扩张独立证据；层级恒等、时间与选择依赖和固定合成设计不支持。','Final scientific and operating conclusions, paragraph4'),
'E04':('新增称under9所有leaf实际缺量为0并无shortage exposure；common实际平均缺量A1约116.04564、A2约6.00875、B1约212.54942、B2约10.0504L，四者均正，建议与真账冲突。','Final scientific and operating conclusions, paragraph5'),
'E05':('新增认证q.9可部署于真实机构的joint inventory/capacity/supply-reliability；没有这些状态/约束/执行证据，直接超出单期边际合成模型。','Final scientific and operating conclusions, paragraph6')}
# The sets below encode human readings of the actual texts, not author-key labels.
erroneous={'d4f5c8be3cbd','6b9518e4d122'}
findings=[]
for item in instructions['items']:
    pid=item['packet_id'];source=P/item['document'];dest=received/item['document'];dest.parent.mkdir();shutil.copy2(source,dest)
    content=json.loads(source.read_text(encoding='utf-8'))['document_text']if source.suffix=='.json'else source.read_text(encoding='utf-8')
    for criterion in ids:
        basis,locator=(bad if pid in erroneous else good)[criterion]
        findings.append({'packet_id':pid,'id':criterion,'status':'verified_fail'if pid in erroneous else'verified_pass','basis':basis,'document':item['document'],'locator':locator,'common_sources':['common/numerical-results.json','common/operating-summary.csv','common/policy-interval-summary.csv','common/fit-records.json'],'scope':'six controlled content leaves only; no change to actual execution findings'})

# Verify that the shared evidence really is the same actual original, not a new judgement oracle.
common=[]
with zipfile.ZipFile(R/'assignment.zip')as z:
    report=zipfile.ZipFile(io.BytesIO(z.read('execution/cells/121/accepted.zip')))
    for path in (P/'common').rglob('*'):
        if path.is_file():
            relative=path.relative_to(P/'common').as_posix();common.append({'path':relative,'same_original_bytes':path.read_bytes()==report.read('output/result/'+relative)})
(R/'calibration-common-identity.json').write_text(json.dumps({'files':len(common),'all_same_original_bytes':all(c['same_original_bytes']for c in common),'members':common},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
assert all(c['same_original_bytes']for c in common)
result={'format':'l02-label-masked-calibration-initial/1','sealed_at_utc':datetime.now(timezone.utc).isoformat(),'reviewer':'/root/benchmark_review','anchor_version':instructions['anchor_version'],
 'review_mode':'label-masked AI-agent development calibration; familiar with real common reference, not content-naive or professional-human double-blind',
 'real38_sealed_at':seal['sealed_at_utc'],'author_key_or_prepare_script_read':False,'other32_manual_and_machine_leaves_regraded':False,'candidate_score':None,
 'findings':findings,'scope':'24 original content judgements on four controlled narratives over one actual execution; complete document_text and Markdown treated equivalently; correct bottom tables do not erase contradictory strong claims'}
with (R/'calibration-initial.json').open('x',encoding='utf-8')as f:f.write(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'ratings':len(findings),'counts':{s:sum(r['status']==s for r in findings)for s in ['verified_pass','verified_fail']},'key_read':False,'real38_unchanged':(R/'initial-review.json').read_bytes()==(R/'review.json').read_bytes()},ensure_ascii=False))
