"""Supplementary stdlib binding/timing checks; no original programme invocation."""
import csv,io,json,zipfile
from collections import defaultdict
from datetime import datetime,timedelta
from decimal import Decimal
from fractions import Fraction as F
from pathlib import Path
R=Path(__file__).resolve().parent
J=lambda b:json.loads(b,parse_float=Decimal)
C=lambda b:list(csv.DictReader(io.StringIO(b.decode('utf-8-sig'))))
def Z(b):return zipfile.ZipFile(io.BytesIO(b))
checks=[]
def ck(n,v):checks.append({'name':n,'passed':bool(v)})
with zipfile.ZipFile(R/'assignment.zip')as bundle:
    reg=Z(bundle.read('execution/registration.zip'));meta=J(reg.read('registration.json'));manifest=J(reg.read('submission/submission.json'));ledger=J(bundle.read('execution/ledger-snapshot.json'))
    epoch=datetime.fromisoformat(J(reg.read('raw/time-axis.json'))['epoch_utc'].replace('Z','+00:00'));tick=lambda s:int((datetime.fromisoformat(s.replace('Z','+00:00'))-epoch).total_seconds())//3600
    unit=J(reg.read('raw/units.json'));obs=C(reg.read('raw/observations.csv'));cov=C(reg.read('raw/covariate-vintages.csv'));origins={r['origin_id']:r for r in C(reg.read('raw/origins.csv'))}
    terminal={(r['series_id'],tick(r['event_end_utc'])):r for r in obs if int(r['revision_id'])==2}
    norm=lambda r:F(r['value'])*unit[r['unit']]['multiplier']
    ck('all_original_valid_unit_conversions_are_integral',all((F(r['value'])*unit[r['unit']]['multiplier']).denominator==1 for r in obs if r['quality_flag']=='valid'))
    caches={};ids=[];nativeok=[];metachecks=[];innerchecks=[];imputed=[];june=[]
    report=Z(bundle.read('execution/cells/121/accepted.zip'));data=J(report.read('input/results.json'));outprefix='output/result/'
    csvout=lambda n:C(report.read(outprefix+n))
    for cell in ledger['cells']:
        ident=J(cell['identity']);cid=cell['id'];a=Z(bundle.read(f'execution/cells/{cid}/accepted.zip'));nat=J(a.read('terminal-inspect.json'));ids.append(nat['Id']);nativeok.append(nat['Config']['Labels']['oc.l02.cell']==str(cid)and nat['RestartCount']==0 and nat['HostConfig']['RestartPolicy']['Name']=='no')
        if ident['kind']=='predict':
            m=J(a.read('input/packet/packet.json'));fit=J(a.read('output/result/fit.json'));caches[cid]=fit
            metachecks.append(set(m)=={'format','clock','origin_tick','target_ticks','series_catalogue','hierarchy','units','variables','quantiles'}and m['units']==unit and m['variables']==J(reg.read('raw/availability.json'))and m['series_catalogue']==C(reg.read('raw/series.csv'))and m['hierarchy']==C(reg.read('raw/hierarchy.csv')))
            if ident['method_id']=='ridge-weather-operations':
                available={}
                for r in cov:
                    if tick(r['release_time_utc'])>m['origin_tick']:continue
                    k=(r['variable_id'],tick(r['valid_end_utc']))
                    if k not in available or int(r['revision_id'])>int(available[k]['revision_id']):available[k]=r
                for s,zone in [('A1','ZA'),('A2','ZA'),('B1','ZB'),('B2','ZB')]:
                    expected=[t for t in m['target_ticks']if available.get((zone+'.temperature_forecast',t),{}).get('quality_flag')!='valid']
                    imputed.append(expected==fit['fit'][s]['future_temperature_imputed_ticks']and m['target_ticks'][-1]in expected)
                if ident['origin_id']=='outer-20250620':
                    audit=fit['fit']['A1'];i=audit['features'].index('transfer_in');june.append(F(audit['feature_centre'][i-1])==0 and F(audit['coefficient'][i])==0 and all(int(r['value'])==0 for(v,t),r in available.items()if v=='A1.transfer_in'and m['origin_tick']-365*24<=t<m['origin_tick']and r['quality_flag']=='valid'))
        elif ident['kind']=='select':
            packet=J(a.read('input/inner.json'))
            for frame in packet['frames']:
                ctx=frame['context'];truth={};releases=[]
                for s in ['A1','A2','B1','B2']:
                    for t in ctx['target_ticks']:
                        raw=terminal[s,t];truth[s,t]=norm(raw);releases.append(tick(raw['release_time_utc']))
                truth.update({('ZA',t):truth['A1',t]+truth['A2',t]for t in ctx['target_ticks']});truth.update({('ZB',t):truth['B1',t]+truth['B2',t]for t in ctx['target_ticks']})
                innerchecks.append({(r['series_id'],r['target_tick']):F(r['value'])for r in frame['labels']}==truth and max(releases)==frame['labels_released_at']<=packet['outer_origin_tick'])
    ck('121_distinct_native_ID_and_cell_labels_restart',len(ids)==len(set(ids))==121 and all(nativeok));ck('108_exact_nonsidechannel_packet_metadata',len(metachecks)==108 and all(metachecks));ck('36_actual_inner_terminal_labels_release_from_raw',len(innerchecks)==36 and all(innerchecks));ck('all_weather_fits_actual_lastday_imputation',len(imputed)==144 and all(imputed));ck('June_actual_zero_transfer_training_feature',len(june)==1 and all(june))
    intervals=csvout('intervals.csv');methods=csvout('method-interval-summary.csv');policy=csvout('policy-interval-summary.csv');selection={r['outer_id']:r['selected_method_id']for r in data['outer_results']}
    sums=[]
    for rows,selected in [(methods,False),(policy,True)]:
        for r in rows:
            part=[x for x in intervals if x['series_id']==r['series_id']and x['coverage_level_percent']==r['coverage_level_percent']and (x['method_id']==selection[x['outer_id']]if selected else x['method_id']==r['method_id'])]
            n=sum(int(x['assigned_days'])for x in part);hits=sum(int(x['hits'])for x in part);width=sum(F(x['width_L'])*int(x['assigned_days'])for x in part)/n
            sums.append(n==168 and int(r['hits'])==hits and int(r['assigned_days'])==n and F(r['coverage'])==F(hits,n)and F(r['mean_width_L'])==width)
    ck('54method18selected_interval_totals',len(sums)==72 and all(sums))
    fitrows=csvout('fit-index.csv');fitgood=[]
    for r in fitrows:
        fit=caches[int(r['cell_id'])];raw=fit['fit'][r['series_id']];given=J(r['coefficient']);samecoef=(given is None)if raw['coefficient']is None else given is not None and [F(x)for x in given]==[F(x)for x in raw['coefficient']];fitgood.append(int(r['training_rows'])==raw['training_rows']and int(r['training_end_tick'])==raw['maximum_training_event_tick']and J(r['features'])==raw['features']and samecoef and int(r['paired_residual_rows'])==fit['paired_residual_rows'])
    ck('432_fit_index_rows_bound_to_actual_fits',len(fitrows)==432 and all(fitgood))
    srcrows=csvout('source-index.csv');cachebytes={};sourcegood=[]
    for r in srcrows:
        cid=int(r['cell_id'])
        if cid not in cachebytes:cachebytes[cid]=Z(bundle.read(f'execution/cells/{cid}/accepted.zip'))
        actual=cachebytes[cid].read('output/'+r['artifact']);delivered=report.read(outprefix+r['delivered_copy']);sourcegood.append(actual==delivered)
    ck('228_original_output_source_copies',len(sourcegood)==228 and all(sourcegood))
    project=R/'received-project';project.mkdir()
    for n in reg.namelist():
        if n.startswith('submission/'):(project/n[11:]).write_bytes(reg.read(n))
    ck('actual_method_pool_projection',J(report.read(outprefix+'method-pool.json'))==manifest['pool'])
(R/'supplementary-assessment.json').write_text(json.dumps({'checks':checks,'all_passed':all(c['passed']for c in checks),'new_native_or_reader_calls':0,'scope':'original artifacts/raw timing and complete report summary/source connections; no coefficient refitting'},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'checks':len(checks),'all_passed':all(c['passed']for c in checks),'failed':[c['name']for c in checks if not c['passed']]},ensure_ascii=False))
