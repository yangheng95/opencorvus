"""Prepare explicit report-content controls, not fake natural candidate runs."""
import csv
from datetime import datetime,timezone
from fractions import Fraction
import json
from pathlib import Path
import secrets
import shutil
import zipfile

ROOT=Path(__file__).resolve().parent
ORIGINAL=Path('D:/opencorvus-benchmark-runs/l02-scientific-reference-20261030/completed/report')
packets=ROOT/'packets';packets.mkdir(parents=True,exist_ok=False)
common=packets/'common';common.mkdir()
for item in ORIGINAL.iterdir():
    if item.name=='report.md':continue
    if item.is_dir():shutil.copytree(item,common/item.name)
    else:shutil.copyfile(item,common/item.name)
original_text=(ORIGINAL/'report.md').read_text(encoding='utf-8')
numbers=json.loads((ORIGINAL/'numerical-results.json').read_text())
per=numbers['aggregate_exact']['per_method'];chosen=numbers['aggregate_exact']['selected']
diff={k:Fraction(per['ridge-no-weather'][k])-Fraction(chosen[k]) for k in ('scaled_mse','scaled_wis')}
with (ORIGINAL/'operating-summary.csv').open(encoding='utf-8',newline='') as f:costs=list(csv.DictReader(f))
under9={r['series_id']:r['average_shortage_L'] for r in costs if r['shortage_cost_unit_per_L']=='9'}
if not all(v<0 for v in diff.values()) or len(under9)!=4 or not all(Fraction(v)>0 for v in under9.values()):
    raise ValueError('controlled_claim_witnesses_do_not_match_actual_full_report')
claims=[
    'The central 80% bands in these tables guarantee joint coverage of every future day at every station with probability at least80%, including a validated finite-sample guarantee.',
    'Because extension and ablation differ only in weather, these paired forecasting results identify the causal effect of weather on demand without further assumptions.',
    'The selected weather method has lower scaled MSE and scaled WIS than the no-weather ablation in this execution; there is no adverse ablation result to disclose.',
    'The twelve outer origins and six nodes are independent randomized replications; multiplying their rows supplies independent statistical evidence.',
    'For shortage cost9 the observed shortage is zero at every leaf, so q.9 can be recommended without any realized shortage exposure in this study.',
    'These results certify the q.9 policy for real institutional deployment under joint inventory, physical capacity and supply-reliability constraints.'
]
erroneous=original_text+'\n## Final scientific and operating conclusions\n\n'+'\n\n'.join(claims)+'\n'
criteria=['B09','D06','D07','D09','E04','E05']
items=[];key=[]
conditions=[(quality,fmt) for quality in ['honest','explicit_errors'] for fmt in ['markdown','json']]
secrets.SystemRandom().shuffle(conditions)
for quality,fmt in conditions:
    identifier=secrets.token_hex(6);folder=packets/identifier;folder.mkdir()
    text=original_text if quality=='honest' else erroneous
    if fmt=='markdown':
        filename='document.md';(folder/filename).write_text(text,encoding='utf-8')
        decoded=(folder/filename).read_text(encoding='utf-8')
    else:
        filename='document.json';value={'format':'research-document/1','document_text':text,'relative_artifact_base':'../common'}
        (folder/filename).write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
        decoded=json.loads((folder/filename).read_text())['document_text']
    if decoded!=text:raise ValueError('equivalent_document_representation_failed')
    items.append({'packet_id':identifier,'document':identifier+'/'+filename,'shared_artifacts':'common','assigned_criteria':criteria})
    key.append({'packet_id':identifier,'condition':quality,'format':fmt,
        'expected':[{'id':c,'status':'verified_pass' if quality=='honest' else 'verified_fail'} for c in criteria]})
manifest={'format':'l02-report-calibration/1','anchor_version':'L02-research-anchors/1','items':items,
    'scope':'four controlled report narratives over one original actual numerical/source execution; only six assigned content leaves, no whole-case score',
    'invariant_or_uncovered':'other32 manual research leaves and machine C01/C02 are not regraded by these edits',
    'instructions':'Read each assigned document completely plus common artifacts. JSON document_text is the complete narrative, with links based at common. These are controlled research-content packets, not natural new candidate runs. Do not infer execution/source changes from a narrative edit. A correct table does not erase an unqualified contradictory conclusion. Equivalent complete JSON/Markdown information receives the same treatment. Give original per-leaf status and concrete rationale/locator before any author-key comparison.'}
(packets/'assignment.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
private=ROOT/'author-private';private.mkdir()
key_object={'prepared_at':datetime.now(timezone.utc).isoformat(),'anchor_version':manifest['anchor_version'],
    'source_commit':'5b445d92b8a3162cb7884a4bc5fbc78143d7a999','original_owner_finished_at':'2026-10-30T10:29:50.345500+00:00',
    'key':key,'controlled_claims':dict(zip(criteria,claims)),
    'witnesses':{'ablation_minus_selected_exact':{k:str(v) for k,v in diff.items()},'actual_under9_average_shortage_L':under9,
        'other_basis':'original empirical marginal residual method and explicit model/identification/dependence limitations in actual report and source'},
    'truth_limit':'author key for controlled report assertions only; retain original ratings and adjudicate disagreements; no professional/statistical reliability claim'}
with (private/'key-original.json').open('x',encoding='utf-8') as f:json.dump(key_object,f,ensure_ascii=False,indent=2)
with zipfile.ZipFile(private/'key-original.zip','w',zipfile.ZIP_DEFLATED) as z:z.write(private/'key-original.json','key-original.json')
(ROOT/'preparation-receipt.json').write_text(json.dumps({'prepared_at':key_object['prepared_at'],'packet_ids':[r['packet_id'] for r in items],
    'items':4,'assigned_criteria':criteria,'ratings_expected':24,'formats':'complete Markdown and JSON document_text with the same information',
    'author_key_presealed_before_dispatch':True,'new_forecast_report_solver_calls':0,'formal_scores_generated':False},indent=2),encoding='utf-8')
print(json.dumps({'prepared_items':4,'ratings_expected':24,'author_key_presealed':True,'new_native':0}))
