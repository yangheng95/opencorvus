from datetime import datetime,timezone
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
PEER=Path('D:/opencorvus-benchmark-runs/l02-scientific-reference-full-review-20261030')
key=json.loads((ROOT/'author-private/key-original.json').read_text())
initial=json.loads((PEER/'calibration-initial.json').read_text())
expected={(p['packet_id'],r['id']):r['status'] for p in key['key'] for r in p['expected']}
actual={(r['packet_id'],r['id']):r for r in initial['findings']}
if len(initial['findings'])!=len(actual) or set(actual)!=set(expected):raise ValueError('calibration_actual_assignment_incomplete')
rows=[{'packet_id':p,'id':i,'author_key_status':status,'initial_status':actual[p,i]['status'],
       'status_matches':status==actual[p,i]['status'],'initial_basis':actual[p,i]['basis']} for (p,i),status in expected.items()]
receipt={'compared_at':datetime.now(timezone.utc).isoformat(),'key_prepared_at':key['prepared_at'],
    'initial_sealed_at':initial['sealed_at_utc'],'key_precedes_initial':key['prepared_at']<initial['sealed_at_utc'],
    'rows':rows,'matches':sum(r['status_matches'] for r in rows),'total':len(rows),
    'open_substantive_rationale_clarification':{
        'criteria':'B09 in both explicit-error packets',
        'issue':'initial rationale also calls June0/4 an actual counterexample; one realized noncoverage event alone cannot logically refute an80% probabilistic guarantee under properly specified assumptions',
        'correct_basis':'these controls conflate marginal bands with joint coverage and assert finite-sample guarantee without the joint model/proof/assumptions; observed0/4 is local empirical exposure, not by itself a mathematical disproof of an80% probability assertion',
        'required_action':'independent appended clarification, preserve initial ratings and author key; expected fail status need not change'},
    'scope':'six content leaves over4 controlled packets and2 formats only; no statistical reliability/whole-case grade or source/execute counterexample coverage',
    'original_ratings_and_key_rewritten':False}
with (ROOT/'comparison-initial.json').open('x',encoding='utf-8') as f:json.dump(receipt,f,ensure_ascii=False,indent=2)
print(json.dumps({'status_matches':receipt['matches'],'total':receipt['total'],'key_precedes_initial':receipt['key_precedes_initial'],
    'rationale_clarification_pending':True,'rating_change_requested':False}))
