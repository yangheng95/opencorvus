"""Independent stdlib audit of received originals; no candidate/reader invocation."""
import csv,io,json,sqlite3,zipfile
from collections import defaultdict
from datetime import datetime,timedelta
from decimal import Decimal
from fractions import Fraction as F
from pathlib import Path

ROOT=Path(__file__).resolve().parent
def js(b):return json.loads(b,parse_float=Decimal)
def zipped(b):
    with zipfile.ZipFile(io.BytesIO(b))as z:return {n:z.read(n)for n in z.namelist()}
def csvs(b):return list(csv.DictReader(io.StringIO(b.decode('utf-8-sig'))))
def save(n,v):(ROOT/n).write_text(json.dumps(v,ensure_ascii=False,indent=2,default=str)+'\n',encoding='utf-8')
checks=[]
def ck(n,b,detail=None):checks.append({'name':n,'passed':bool(b),'detail':detail})
with zipfile.ZipFile(ROOT/'assignment.zip')as z:
    header=js(z.read('assignment.json'));ledger=js(z.read('execution/ledger-snapshot.json'))
    regfiles=zipped(z.read('execution/registration.zip'));reg=js(regfiles['registration.json']);manifest=js(regfiles['submission/submission.json']);study=js(regfiles['study.json'])
    rawobs=csvs(regfiles['raw/observations.csv']);rawcov=csvs(regfiles['raw/covariate-vintages.csv']);origins=csvs(regfiles['raw/origins.csv'])
    avail=js(regfiles['raw/availability.json']);units=js(regfiles['raw/units.json']);clock=js(regfiles['raw/time-axis.json']);epoch=datetime.fromisoformat(clock['epoch_utc'].replace('Z','+00:00'))
    tick=lambda s:int((datetime.fromisoformat(s.replace('Z','+00:00'))-epoch).total_seconds())//3600
    def key(r,typ):return '|'.join([r['series_id']if typ=='o'else r['variable_id'],r['event_end_utc']if typ=='o'else r['valid_end_utc'],r['revision_id']])
    obs=[{'id':r['series_id'],'t':tick(r['event_end_utc']),'rel':tick(r['release_time_utc']),'rev':int(r['revision_id']),'value':None if r['quality_flag']=='missing'else F(r['value'])*units[r['unit']]['multiplier'],'flag':r['quality_flag'],'key':key(r,'o'),'raw':r}for r in rawobs]
    cov=[{'id':r['variable_id'],'t':tick(r['valid_end_utc']),'rel':tick(r['release_time_utc']),'rev':int(r['revision_id']),'value':None if r['quality_flag']=='missing'else int(r['value']),'flag':r['quality_flag'],'key':key(r,'c'),'raw':r}for r in rawcov]
    obsmap={r['key']:r['raw']for r in obs};covmap={r['key']:r['raw']for r in cov}
    db=sqlite3.connect(':memory:');db.execute('create table o(k text,rel integer,t integer)');db.execute('create table c(k text,rel integer,t integer,f integer)')
    db.executemany('insert into o values(?,?,?)',[(r['key'],r['rel'],r['t'])for r in obs]);db.executemany('insert into c values(?,?,?,?)',[(r['key'],r['rel'],r['t'],int(avail[r['id']]['availability']=='known_future'))for r in cov])
    def latest(rows,origin,observed=True):
        out={}
        for r in rows:
            if r['rel']>origin or(observed and r['t']>=origin):continue
            k=(r['id'],r['t'])
            if k not in out or r['rev']>out[k]['rev']:out[k]=r
        return out
    terminal={(r['id'],r['t']):r for r in obs if r['rev']==2}
    ids={r['origin_id']:r for r in origins};cells=ledger['cells'];native_rows=[];forecasts={};fits={};report=None;source_checks=[];packet_checks=[];fit_checks=[];missing_exercised=0
    start=reg['created_at'];ck('formal_authority_12',reg['assignment_kind']=='formal_full_assignment'and len(reg['outer_ids'])==12 and set(reg['outer_ids'])=={r['origin_id']for r in origins if r['role']=='outer'})
    for cell in cells:
        cid=cell['id'];identity=js(cell['identity']);kind=identity['kind'];decl=manifest['programs'][kind]
        a=zipped(z.read(f'execution/cells/{cid}/accepted.zip'));p=zipped(z.read(f'execution/cells/{cid}/prepared.zip'));t=zipped(z.read(f'execution/cells/{cid}/terminal.zip'));native=js(t['terminal-inspect.json'])
        source_checks.append(all(a[n]==b and t[n]==b for n,b in p.items())and {n:b for n,b in a.items()if n!='assessment.json'}==t and all(p['project/'+n]==regfiles['submission/'+n]for n in decl['files']))
        nv=native['State'];host=native['HostConfig'];cfg=native['Config'];native_rows.append({'id':cid,'identity':identity,'CID':native['Id'],'started':nv['StartedAt'],'finished':nv['FinishedAt'],'phase':cell['phase'],'exit':nv['ExitCode']})
        ck('native_'+str(cid),cell['phase']=='verified'and cell['failure']is None and nv['Status']=='exited'and nv['ExitCode']==cell['exitcode']==0 and native['Id']==cell['cid']and native['Name']=='/'+cell['name']and native['Image']==reg['image_id']and native['Path']==decl['argv'][0]and native['Args']==decl['argv'][1:]and cfg['Labels']['oc.l02.run']==header['run_id']and host['NanoCpus']==10**9 and host['NetworkMode']=='none'and host['ReadonlyRootfs']and {m['Destination']:m['RW']for m in native['Mounts']}=={'/project':False,'/input':False,'/output':True}and datetime.fromisoformat(nv['StartedAt'].replace('Z','+00:00'))>=datetime.fromisoformat(start))
        if kind=='report':report=a;continue
        if kind=='select':forecasts[('select',identity['outer_id'])]=a;continue
        origin=identity['origin_id'];method=identity['method_id'];meta=js(a['input/packet/packet.json']);o=meta['origin_tick'];cfgm=js(a['input/method.json']);fit=js(a['output/result/fit.json']);fc=js(a['output/result/forecast.json'])
        forecasts[origin,method]=fc;fits[origin,method]=fit
        po=csvs(a['input/packet/observations.csv']);pc=csvs(a['input/packet/covariate-vintages.csv'])
        ko={key(r,'o')for r in po};kc={key(r,'c')for r in pc};eo={r[0]for r in db.execute('select k from o where rel<=? and t<?',(o,o))};ec={r[0]for r in db.execute('select k from c where rel<=? and (f=1 or t<?)',(o,o))}
        packet_checks.append(ko==eo and kc==ec and len(po)==len(ko)and len(pc)==len(kc)and all(r==obsmap[key(r,'o')]for r in po)and all(r==covmap[key(r,'c')]for r in pc)and o==tick(ids[origin]['cutoff_utc'])and meta['target_ticks']==[(o//24+2)*24+24*i for i in range(14)]and set(n for n in a if n.startswith('input/'))=={'input/method.json','input/packet/packet.json','input/packet/observations.csv','input/packet/covariate-vintages.csv'})
        config=cfgm['configuration'];known=latest(obs,o);currentfit=fit['fit'];cals=fit['calibration'];good=cfgm==fit['method']and fit['origin_tick']==o and len(cals)==3
        for originfit,audit in [(o,currentfit),*[(c['origin_tick'],c['fit'])for c in cals]]:
            sample=latest(obs,originfit)
            for series in ['A1','A2','B1','B2']:
                points=[r for (s,tickv),r in sample.items()if s==series and r['flag']=='valid'and originfit-24*config['train_window_days']<=tickv<originfit]
                good=good and audit[series]['training_rows']==len(points)and audit[series]['maximum_training_event_tick']==max(r['t']for r in points)
                missing_exercised+=sum(r['flag']=='missing'for(s,tickv),r in sample.items()if s==series and originfit-24*config['train_window_days']<=tickv<originfit)
                if method=='ridge-no-weather':good=good and 'temperature_C'not in audit[series]['features']and not audit[series]['future_temperature_imputed_ticks']
        accepted_n=0
        for cal,offset in zip(cals,config['calibration_days_before']):
            pseudo=o-offset*24;targets=[(pseudo//24+2)*24+24*i for i in range(14)]
            accepted=[tv for tv in targets if all(known.get((s,tv),{}).get('flag')=='valid'for s in ['A1','A2','B1','B2'])]
            good=good and cal['origin_tick']==pseudo and cal['target_ticks']==targets and cal['accepted_complete_leaf_ticks']==accepted;accepted_n+=len(accepted)
        good=good and fit['paired_residual_rows']==accepted_n==42
        fit_checks.append(good)
    ck('all121_original_source_and_capsule_closure',len(source_checks)==121 and all(source_checks))
    ck('all108_SQL_authorized_original_packets_and_exact_grids',len(packet_checks)==108 and all(packet_checks))
    ck('all108_fit_current_and_pseudo_training_row_timing',len(fit_checks)==108 and all(fit_checks),{'latest_missing_exercises':missing_exercised,'scope':'source/row/diagnostic audit, not independent coefficient refitting'})
    ck('report_after_all120_numerics',len(cells)==121 and all(r['finished']<=native_rows[-1]['started']for r in native_rows[:-1]))
    assert report is not None
    out={n[7:]:v for n,v in report.items()if n.startswith('output/result/')}
    # Strip the result/ component from report output paths.
    out={n[7:]:v for n,v in out.items()}
    (ROOT/'report').mkdir()
    for n,b in out.items():
        if not n.startswith('sources/')and not n.startswith('reproduction/'):
            path=ROOT/'report'/n;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(b)
    data=js(report['input/results.json']);ck('report_original_numerical_bytes',out['numerical-results.json']==report['input/results.json'])
    context0=data['outer_results'][0]['context'];scales={}
    for s in ['A1','A2','B1','B2']:
        rr=[r for(k,tv),r in terminal.items()if k==s and '2023-01-02T00:00:00'<= (epoch+timedelta(hours=tv)).isoformat()[:19] <= '2024-01-01T00:00:00']
        scales[s]=max(F(1),sum(r['value']for r in rr)/365)
        ck('scale_publication_'+s,len(rr)==365 and all(r['rel']<=tick('2024-02-01T09:00:00Z')for r in rr))
    scales.update(ZA=scales['A1']+scales['A2'],ZB=scales['B1']+scales['B2'])
    ck('fixed_scales_raw_2023',all(F(context0['scales_litres'][s])==v for s,v in scales.items()))
    nrows={(r['outer_id'],r['method_id'],r['series_id']):r for r in csvs(out['node-losses.csv'])};irows={(r['outer_id'],r['method_id'],r['series_id'],int(r['coverage_level_percent'])):r for r in csvs(out['intervals.csv'])};arows={(r['outer_id'],r['series_id'],int(r['target_tick']),int(r['shortage_cost_unit_per_L'])):r for r in csvs(out['operating-ledger.csv'])}
    metric_checks=[];int_checks=[];action_checks=[];mean_hierarchy=[];allmethod=defaultdict(list)
    def W(y,q):
        v=abs(y-F(q['0.5']))/2
        for alpha,lo,hi in [(F(1,2),'0.25','0.75'),(F(1,5),'0.1','0.9'),(F(1,20),'0.025','0.975')]:v+=alpha/2*(F(q[hi])-F(q[lo]))+max(F(q[lo])-y,F())+max(y-F(q[hi]),F())
        return v/F(7,2)
    labels_by_origin={}
    for outer in data['outer_results']:
        oid=outer['outer_id'];ticks=outer['context']['target_ticks'];truth={(s,tv):terminal[s,tv]['value']for s in ['A1','A2','B1','B2']for tv in ticks};truth.update({('ZA',tv):truth['A1',tv]+truth['A2',tv]for tv in ticks});truth.update({('ZB',tv):truth['B1',tv]+truth['B2',tv]for tv in ticks});labels_by_origin[oid]=truth
        ck('authoritative_labels_'+oid,{(r['series_id'],r['target_tick']):F(r['value'])for r in outer['labels']}==truth)
        for method,fc in outer['forecasts'].items():
            ck('sealed_forecast_'+oid+'_'+method,fc==forecasts[oid,method])
            by={(r['series_id'],r['target_tick']):r for r in fc['forecasts']}
            for tv in ticks:
                for parent,children in [('ZA',['A1','A2']),('ZB',['B1','B2'])]:
                    pa=F(by[parent,tv]['mean']);su=sum(F(by[c,tv]['mean'])for c in children);mean_hierarchy.append(abs(pa-su)<=F(1,10**6)*max(F(1),abs(pa),sum(abs(F(by[c,tv]['mean']))for c in children)))
            for s in scales:
                rows=[by[s,tv]for tv in ticks];mse=sum(((F(r['mean'])-truth[s,r['target_tick']])/scales[s])**2 for r in rows)/14;wisv=sum(W(truth[s,r['target_tick']],r['quantiles'])/scales[s]for r in rows)/14
                n=nrows[oid,method,s];metric_checks.append(F(n['scaled_mse'])==mse and F(n['scaled_wis'])==wisv and int(n['assigned_days'])==14);allmethod[method,s].append((mse,wisv))
                for level,lo,hi in [(50,'0.25','0.75'),(80,'0.1','0.9'),(95,'0.025','0.975')]:
                    n=irows[oid,method,s,level];hits=sum(F(r['quantiles'][lo])<=truth[s,r['target_tick']]<=F(r['quantiles'][hi])for r in rows);width=sum(F(r['quantiles'][hi])-F(r['quantiles'][lo])for r in rows)/14
                    int_checks.append(int(n['hits'])==hits and int(n['assigned_days'])==14 and F(n['width_L'])==width)
            if method==outer['selected_method_id']:
                for s in ['A1','A2','B1','B2']:
                    for tv in ticks:
                        f=by[s,tv];y=truth[s,tv]
                        for cost,q in [(1,'0.5'),(3,'0.75'),(9,'0.9')]:
                            r=arows[oid,s,tv,cost];good=F(r['truth_L'])==y and r['method_id']==method and r['frozen_quantile']==q
                            for prefix,a in [('',F(f['quantiles'][q])),('mean_',F(f['mean']))]:
                                short=max(y-a,F());over=max(a-y,F());e={'action_L':a,'shortage_L':short,'overage_L':over,'shortage_cost_units':cost*short,'overage_cost_units':over,'loss_cost_units':cost*short+over};good=good and all(F(r[prefix+k])==v for k,v in e.items())
                            action_checks.append(good)
    ck('all216_node_MSE_WIS_from_raw_truth',len(metric_checks)==216 and all(metric_checks));ck('all648_interval_hits_widths',len(int_checks)==648 and all(int_checks));ck('all2016_q_and_mean_actions_costs',len(action_checks)==2016 and all(action_checks));ck('all_mean_hierarchy',all(mean_hierarchy))
    summaries=csvs(out['operating-summary.csv']);ck('all12_operating_summaries',len(summaries)==12 and all(int(r['assigned_days'])==168 and all(F(r['average_'+p+k])==sum(F(a[p+k])for a in arows.values()if(a['series_id'],int(a['shortage_cost_unit_per_L']))==(r['series_id'],int(r['shortage_cost_unit_per_L'])))/168 for p in ['','mean_']for k in ['shortage_L','overage_L','shortage_cost_units','overage_cost_units','loss_cost_units'])for r in summaries))
    ck('all_macro_losses',all(F(data['aggregate_exact']['per_method'][m][metric])==sum(sum(v[j]for v in allmethod[m,s])/12*(F(1,8)if s in ['A1','A2','B1','B2']else F(1,4))for s in scales)for m in data['pool']['outer_ids']for j,metric in enumerate(['scaled_mse','scaled_wis'])))
    selector_checks=[]
    for oid in reg['outer_ids']:
        a=forecasts['select',oid];packet=js(a['input/inner.json']);selection=js(a['output/result/selection.json']);losses={}
        for m in packet['selection_ids']:
            vals=[]
            for frame in packet['frames']:
                fc=frame['forecasts'][m];co=frame['context'];truth={(r['series_id'],r['target_tick']):F(r['value'])for r in frame['labels']}
                selector_checks.append(frame['forecasts'][m]==forecasts[frame['origin_id'],m]and frame['labels_released_at']<=packet['outer_origin_tick'])
                vals.append(sum(((F(r['mean'])-truth[r['series_id'],r['target_tick']])/scales[r['series_id']])**2*(F(1,8)if r['series_id']in ['A1','A2','B1','B2']else F(1,4))/14 for r in fc['forecasts']))
            losses[m]=sum(vals)/3
        winner=min(losses,key=lambda m:(losses[m],m));selector_checks.append(selection['selected_method_id']==winner==next(r['selected_method_id']for r in data['outer_results']if r['outer_id']==oid))
    ck('all12_actual_inner_selection_from_exact_originals',all(selector_checks))
    ck('full_report_extraction_matches_original_accepted',all((Path('D:/opencorvus-benchmark-runs/l02-scientific-reference-20261030/completed/report')/n).read_bytes()==b for n,b in out.items()))
    save('native-audit.json',native_rows);save('independent-macro.json',{m:{'scaled_mse':str(sum(sum(v[0]for v in allmethod[m,s])/12*(F(1,8)if s in ['A1','A2','B1','B2']else F(1,4))for s in scales)),'scaled_wis':str(sum(sum(v[1]for v in allmethod[m,s])/12*(F(1,8)if s in ['A1','A2','B1','B2']else F(1,4))for s in scales))}for m in data['pool']['outer_ids']})
    save('checks.json',checks);save('audit-assessment.json',{'all_passed':all(c['passed']for c in checks),'checks':len(checks),'failed':[c['name']for c in checks if not c['passed']],'source_training_scope':'verified raw release-prefix, latest-missing training counts, all current/pseudo sample timing and original source/native identity; did not independently refit coefficients','new_native_or_reader_calls':0})
print(json.dumps({'checks':len(checks),'all_passed':all(c['passed']for c in checks),'failed':[c['name']for c in checks if not c['passed']]},ensure_ascii=False))
