"""Read archived actual argv; filename prefixes are not operation identity."""
import json,zipfile
from pathlib import Path
R=Path(__file__).resolve().parent
native=json.loads((R/'native-audit.json').read_text())
checks=[]
with zipfile.ZipFile('D:/opencorvus-benchmark-runs/l02-scientific-reference-20261030/completed/execution-originals.zip')as z:
    for c in native:
        prefix='formal-run/cells/'+str(c['id'])+'/'
        commands=[json.loads(z.read(n))for n in z.namelist()if n.startswith(prefix)and n.endswith('.json')]
        for op in ['create','start','rm']:
            found=[r for r in commands if r.get('argv',[None,None])[1:2]==[op]]
            okay=len(found)==1 and found[0]['exitcode']==0 and (found[0]['stdout'].strip()==c['CID']if op=='create'else found[0]['argv']==['docker',op,c['CID']])
            checks.append({'cell':c['id'],'operation':op,'passed':okay})
result={'checks':checks,'all_passed':all(c['passed']for c in checks),'correction':'reviewer initial filename prefix cleanup- also selected cleanup-discover and cleanup-inspect. Operation now comes from actual argv; original false JSON retained. No candidate/executor failure was found.','new_native_or_reader_calls':0}
(R/'native-command-corrected.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'checks':len(checks),'all_passed':result['all_passed']}))
