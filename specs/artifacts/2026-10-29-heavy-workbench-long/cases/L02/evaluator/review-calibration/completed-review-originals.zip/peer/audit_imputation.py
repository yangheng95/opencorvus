"""Correct a reviewer population-count assumption; original false receipt retained."""
import csv,io,json,zipfile
from datetime import datetime
from pathlib import Path
R=Path(__file__).resolve().parent
J=json.loads
with zipfile.ZipFile(R/'assignment.zip')as b:
    reg=zipfile.ZipFile(io.BytesIO(b.read('execution/registration.zip')))
    epoch=datetime.fromisoformat(J(reg.read('raw/time-axis.json'))['epoch_utc'].replace('Z','+00:00'))
    tick=lambda s:int((datetime.fromisoformat(s.replace('Z','+00:00'))-epoch).total_seconds())//3600
    cov=list(csv.DictReader(io.StringIO(reg.read('raw/covariate-vintages.csv').decode())))
    cells=J(b.read('execution/ledger-snapshot.json'))['cells'];rows=[]
    for c in cells:
        i=J(c['identity'])
        if i['kind']!='predict'or i['method_id']!='ridge-weather-operations':continue
        z=zipfile.ZipFile(io.BytesIO(b.read(f'execution/cells/{c["id"]}/accepted.zip')))
        meta=J(z.read('input/packet/packet.json'));fit=J(z.read('output/result/fit.json'));o=meta['origin_tick'];available={}
        for r in cov:
            if tick(r['release_time_utc'])>o:continue
            k=(r['variable_id'],tick(r['valid_end_utc']))
            if k not in available or int(r['revision_id'])>int(available[k]['revision_id']):available[k]=r
        for s,zone in [('A1','ZA'),('A2','ZA'),('B1','ZB'),('B2','ZB')]:
            expected=[t for t in meta['target_ticks']if available.get((zone+'.temperature_forecast',t),{}).get('quality_flag')!='valid']
            actual=fit['fit'][s]['future_temperature_imputed_ticks'];rows.append({'cell':c['id'],'series':s,'expected':expected,'actual':actual,'passed':expected==actual and meta['target_ticks'][-1]in expected})
    count=sum(J(c['identity'])['kind']=='predict'and J(c['identity']).get('method_id')=='ridge-weather-operations'for c in cells)
result={'weather_cells_from_actual_ledger':count,'node_checks':len(rows),'expected_node_checks_from_ledger':count*4,'all_passed':len(rows)==count*4 and all(r['passed']for r in rows),'rows':rows,'correction':'reviewer initially assumed36 weather predictions; actual36 inner plus12 outer=48, hence192 node checks, not144. No reported imputation discrepancy was discovered.','new_reader_or_forecast_calls':0}
(R/'imputation-correction.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in result.items()if k!='rows'},ensure_ascii=False))
