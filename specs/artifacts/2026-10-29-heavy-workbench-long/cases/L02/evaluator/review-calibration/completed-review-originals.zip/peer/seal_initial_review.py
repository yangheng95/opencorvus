"""Seal actual manual observations before opening calibration materials."""
import json,zipfile
from datetime import datetime,timezone
from pathlib import Path
R=Path(__file__).resolve().parent
with zipfile.ZipFile(R/'assignment.zip')as z:
    h=json.loads(z.read('assignment.json'));rubric=json.loads(z.read('rubric.json'))
manual=[c for g in rubric['groups']for c in g['criteria']if c['method']=='independent_evaluator_review']
def src(obj,member,where):return {'object':obj,'member':member,'locator':where}
reg=lambda member,where:src('execution/registration.zip','submission/'+member,where)
report=lambda member,where:src('execution/cells/121/accepted.zip','output/result/'+member,where)
packet=lambda cell,member,where:src(f'execution/cells/{cell}/accepted.zip',member,where)
ledger=src('execution/ledger-snapshot.json',None,'run and all121 original cell/event rows')
specs={
'A01':('原CSV逐revision保单位；实际decoder.quantity用Fraction乘1000/1后验整L。独立原值换算全部整数，108原packet逐行等于权威CSV；没有float先转整型。',[reg('decode_materials.py','quantity and read_fact_tables'),packet(1,'input/packet/observations.csv','original row units and revisions'),report('reference-data.md','exact units and provenance keys')]),
'A02':('108实际packet均与独立SQLite的release<=origin且observed tick<origin全集相等，metadata无额外角色/未来标签；实际源在每current/pseudo origin重新project。没有把外层终审输入预测。',[reg('asof_input.py','project'),packet(59,'input/packet/packet.json','June assigned origin and targets'),ledger]),
'A03':('实际latest先选最大已发布revision含missing，再仅valid入训练。独立current+pseudo训练行核含472次latest-missing排除，训练行/截止全部匹配，非旧valid回填。',[reg('l02_daily_reference.py','latest and base_predict points'),packet(1,'output/result/fit.json','B1 missing-aware training_rows and calibration')]),
'A04':('108原target grid逐一等于(cutoff//24+2)*24起的14个日末；108预测各84格完整，注册12outer/36inner与报告目标相符。',[packet(1,'input/packet/packet.json','first full future UTC day'),report('numerical-results.json','all outer contexts/forecasts'),ledger]),
'A05':('全外层原forecast中ZA=A1+A2、ZB=B1+B2的exported mean满足公开容差，原labels也由同日原leaf终审相加；没有强迫边际quantiles相加。',[report('numerical-results.json','all hierarchy/mean rows'),reg('l02_daily_reference.py','sample aggregation before means')]),
'A06':('216节点表/648区间表/2016双动作账可按outer/method/series/tick回指完整numerical-results；228source-index副本逐一等于原numeric output，原packet的业务键及单位由data note说明。',[report('source-index.csv','all228 artifact connections'),report('reference-data.md','event/release/revision/unit keys'),report('numerical-results.json','original report-side numeric bytes')]),
'B01':('seasonal为至多8个同weekday历史量；ridge实际标准化weekday/年周期及天气/运营特征、正则最小二乘，再生成经验概率样本。源/配置/原fits和不同实际损失支持机制差异，不以ID改名代替。',[reg('l02_daily_reference.py','base_predict seasonal and ridge branches'),report('method-pool.json','frozen configurations')]),
'B02':('no-weather配置在同一base_predict中关闭天气列，current和三pseudo拟合均无temperature_C及天气插补；实际outer消融损失更低也保留，不要求它变差。',[reg('l02_daily_reference.py','use_weather branch and pseudo calls'),packet(60,'output/result/fit.json','no-weather current/pseudo feature sets'),report('report.md','actual ablation minus selected losses')]),
'B03':('本次正式registration于10:05:24冻结全部predict/select/report和静态资产，121实际prepared源码均与原registration相同，所有native start在其后；report在120numeric结束后。作者已见旧探索结果已披露，不将此称全新盲研究。',[src('execution/registration.zip','registration.json','created_at/full assignment and original submission files'),ledger,packet(121,'terminal-inspect.json','report actual start after numerics')]),
'B04':('108 current及每次三pseudo拟合的训练窗口/最高missing处理、training_rows/max event逐一由原CSV独立重建相符。没有独立重拟合所有系数；源与真实执行和样本时点共同支持来源。',[reg('l02_daily_reference.py','base_predict legal points'),packet(59,'output/result/fit.json','current and calibration audits'),report('fit-index.csv','all432 current leaf fit rows')]),
'B05':('base_predict每pseudo重新project当时可知特征，weather train actual/未来forecast分开，no-weather全路径真移除。实际packet release许可、pseudo训练信息时点与源均核，不声称42残差独立或conformal保证。',[reg('l02_daily_reference.py','base_predict project, features, temperature'),report('report.md','uncertainty timing and limitations')]),
'B06':('残差标签使用真实current origin最高已发布revision，含missing后仅完整valid四leaf入组。108个fit的各pseudo target/accepted ticks与current原事实重建一致，均42成对行；原先验/参数无额外未来源。',[reg('l02_daily_reference.py','forecast known and residual_vectors'),packet(59,'output/result/fit.json','calibration accepted ticks'),report('report.md','highest released including missing then valid')]),
'B07':('48 weather预测×4leaf=192项末日forecast缺测及实际插补tick与原covariate发布数据相符；源用当origin已知历史月均值，未读次日issue/未来actual。最初我误设144项的审查计数false已保留并纠正。',[reg('l02_daily_reference.py','temperature/climate'),report('report.md','missing final weather day'),packet(59,'output/result/fit.json','imputed future ticks')]),
'B08':('exported mean是非负/闭站变换后完整预测样本的均值，不是median或ridge base point；报告明确用MSE评均值，运营mean另列，实际误差独立核同。',[reg('l02_daily_reference.py','np.mean(values)'),report('report.md','mean target and base point distinction')]),
'B09':('报告明确50/80/95中央边际区间、经验配对残差及无finite-sample/joint-path保证；实际分位点单调，区间按各node边际评，不要求其加总。',[report('report.md','methods and interval diagnostics/limitations'),report('reference-sources.md','WIS scope')]),
'C03':('所有outer的原source/argv/image与registration闭合，readonly project/input、1CPU/netnone；各cutoff原packet均只含当时合法事实，新origin可读已公布的旧终审，未回流outer调参。',[ledger,packet(59,'terminal-inspect.json','June outer environment/argv'),reg('l02_daily_reference.py','read only assigned packet/config')]),
'C04':('原实际输出全grid，独立216节点MSE/WIS、648区间和层级mean检查闭合；不是从报告重写结果或仅selected方法抽查。数值协议边界由原已验收记录及原源支持。',[report('numerical-results.json','all declared outer forecasts'),report('node-losses.csv','complete point/interval scores'),report('intervals.csv','all methods/node/levels')]),
'C05':('121原source/prepared/terminal/accepted关系、nativeID/name/run+cell labels、image/argv/资源/exit0均核；原execution-originals中363个create/start/rm回执与各CID一致。',[ledger,packet(1,'terminal-inspect.json','actual image/Path/Args/labels/resources'),packet(121,'terminal-inspect.json','actual reporter declaration')]),
'C06':('实际121格均verified、failure=null，原source、终态、接受和cleanup事件相符；原真实create/start/rm各一次。此次无新故障，不强迫注入；report README如实限定Windows旧恢复资格及设施/未评边界。',[ledger,report('reference-reproduce.md','persistent state and recovery scope')]),
'D01':('36 method/outer点指标、216节点及原macro全部保留，独立raw truth/2023尺度Fraction核数；selected仍为实际inner所选，未因no-weather更好改池。',[report('origin-losses.csv','all36 paired methods/origins'),report('node-losses.csv','all216 node rows'),report('report.md','macro method table')]),
'D02':('同一全部方法/outer/node保留WIS及50/80/95诊断，独立WIS公式/216行及648区间闭合；不只给漂亮带或好节点。',[report('node-losses.csv','WIS paired rows'),report('intervals.csv','full interval evidence'),report('report.md','ablation WIS negative result')]),
'D03':('完整node/outer表与实际June六panel可定位A1/ZA最后4日低估/0覆盖、A2关闭及B1较差覆盖；报告有数值观察并明示预知旧探索失败，不把概览提升等同局部可靠。',[report('report.md','actual comparisons and failure boundaries'),report('forecast.png','actually viewed six panels'),report('policy-interval-summary.csv','B1/other node coverage')]),
'D04':('648原区间rows及54method/18selected totals的hits、14/168分母、weighted width由原预测独立重算一致；区间nominal水平没有当保证。',[report('intervals.csv','all648 rows'),report('method-interval-summary.csv','54 complete aggregates'),report('policy-interval-summary.csv','18 actual-policy aggregates')]),
'D05':('432 fit-index current行的样本/截止/features/系数值逐项等于实际fit输出，完整fit-records保pseudo来源；训练行/时点由raw重建且源真实执行。未独立重拟合全部系数，不把文件存在单独当训练证明。',[report('fit-index.csv','432 actual output connections'),report('fit-records.json','current/pseudo diagnostics'),reg('l02_daily_reference.py','actual fit implementation')]),
'D06':('实际weather/no-weather成对损失如实显示消融更优，明确不是因果天气价值；June transfer训练中心/系数为0的诊断有原fit及原训练cov支持，并明确量效未识别，没有虚构因果证据。',[report('report.md','ablation/transfer/no causal identification'),packet(59,'output/result/fit.json','A1 centre/coefficient')]),
'D07':('报告直列no-weather比selected MSE和WIS更低、June0/4、mean在B1/under1更低；完整表没有删难origin/node，也没反向讲所有方法/行动都赢。',[report('report.md','negative differences and finite-sample mean counterexample'),report('operating-summary.csv','B1 under1')]),
'D08':('实际June A1 transfer训练特征全0，原fit centre0/coef0，公告已知但新量效不可识别；报告不把observed13751.75L当事前可知，建议明确未执行业务审查。',[packet(59,'input/packet/covariate-vintages.csv','published plan and historical transfer'),packet(59,'output/result/fit.json','A1 feature diagnostics'),report('report.md','known notice versus unlearned effect')]),
'D09':('报告明确同日leaf/zone、季节和重叠窗口/selection依赖，不用12origin或表行数做IID/p值，不声称覆盖保证；仅描述性比较，符合实际有限合成任务。',[report('report.md','time dependence and uncertainty limitations')]),
'E01':('原reporter/diagnostics在预测前冻结，COSTS固定under1/3/9->q.5/.75/.9，实际2016行从原selected forecast取该q，未在truth后选mean或较好动作。',[reg('report_diagnostics.py','COSTS/derive decisions'),report('operating-ledger.csv','fixed action lineage')]),
'E02':('4leaf×12outer×14日×3成本=2016原动作，q/action/truth/缺余L/两项cost/total全部独立Fraction闭合。完整账存在而非只给一个expected cost。',[report('operating-ledger.csv','all2016 rows'),report('numerical-results.json','original forecasts and terminal labels')]),
'E03':('同一2016格exported mean诊断行动与原forecast.mean完全相同，原truth/成本/分母及12个168日summary独立重算一致，没有换成base_predict点值或正式q动作。',[report('operating-ledger.csv','mean_* fields'),report('operating-summary.csv','average_mean_*')]),
'E04':('三成本/leaf量化表及672station-day加权段忠实保缺余量和成本，明示B1/under1的mean较好但不事后换策略；逐成本建议针对其罚价暴露，不承诺每格胜或风险消失。',[report('report.md','quantile and mean table plus three cost paragraphs'),report('operating-summary.csv','per-leaf sensitivity')]),
'E05':('报告与data/reproduce说明均限定连续L、合成可分离单期损失；无库存/容量/调拨/联合尾部/真实供水部署资格，业务审查建议称未执行而非已验证。',[report('report.md','operating model limitations'),report('reference-data.md','synthetic context')]),
'F01':('本次原registration源/原raw至108predict+12select+report真实全121新native；数据/源码only readonly，新outputs，非旧120或report adapter。原CLI/终态与报告原accepted字节已核。',[ledger,src('execution/registration.zip','registration.json','fresh formal run all roles frozen'),packet(121,'terminal-inspect.json','actual reporter natural exit0')]),
'F02':('228source-index副本逐字节等于原numeric output；实际argv/native起止/方法/origin定位与原capsule相符，原README不捏造被opaque的host命令，完整receipt在原execution archive。',[report('source-index.csv','228 actual output sources'),report('execution-index.json','narrow original native facts'),report('reference-reproduce.md','host facts scope')]),
'F03':('已实际view原accepted抽出的forecast.png：六panel标题/单位/日期索引/selected/truth/80带与legend可读；A1/ZA失效、A2归零及B1偏低真实可见。图代码使用同一新预测/标签，未用像素或文件存在替代视觉。',[report('forecast.png','actual rendered June20 six-panel image'),reg('report_l02_reference.py','plot data and legend construction')]),
'F04':('已独立打开Gneiting v2原文、Bracher WIS2.2及2022更正、FPP5.10官方原文。对应mean/quantile评分、width/尾惩罚、rolling训练顺序的主张相符；原数据明确原创合成无外部机构许可，未声称这些文献证明校准或因果。',[report('reference-sources.md','actual linked primary sources; see primary-sources-verification.md'),report('reference-data.md','material origin/permissions')]),
'F05':('原submission/12声明files与实际source可定位；交接含真实三角色字面argv、NumPy2.4.6/Matplotlib、new-root/fresh/resume/授权packet/信息边界及限制；完整report和program copies实际交付，没有把窄argv编成完整host历史。',[report('reference-reproduce.md','complete handoff and limitations'),report('method-pool.json','frozen pool projection'),src('execution/registration.zip','submission/submission.json','actual programmes/files/argv')])
}
assert set(specs)=={r['id']for r in manual}
findings=[{'id':r['id'],'status':'verified_pass','basis':specs[r['id']][0],'sources':specs[r['id']][1],'dependency_roots':[]}for r in manual]
with zipfile.ZipFile(R/'assignment.zip')as z:
    for row in findings:
        for s in row['sources']:
            assert s['object']in z.namelist()
            if s['member']is not None:
                import io
                with zipfile.ZipFile(io.BytesIO(z.read(s['object'])))as nested:assert s['member']in nested.namelist()
review={'format':'l02-independent-review/1','assignment_id':h['assignment_id'],'submission_id':h['submission_id'],'reviewer_id':h['reviewer_id'],'anchor_version':h['anchor_version'],
 'disclosure':{'kind':'ai-agent','blinded':False,'familiarity':'same assigned independent reviewer familiar with the author reference, prior known results and component work; this full initial review precedes opening calibration packets','limitations':'not a professional-human or statistical-maturity certification; no coefficient refit or programme reexecution; raw/source/native/derived arithmetic independently checked; audit mistakes and corrections retained'},'findings':findings}
text=json.dumps(review,ensure_ascii=False,indent=2)+'\n'
for name in ['initial-review.json','review.json']:
    with (R/name).open('x',encoding='utf-8')as f:f.write(text)
seal={'sealed_at_utc':datetime.now(timezone.utc).isoformat(),'actual_manual_leaves':38,'states':{'verified_pass':38},'calibration_packets_or_key_read_before_this_seal':False,'C01_C02_Q26_handgraded':False,'candidate_score':None,'truth_scope':'38 genuine observations under received anchors; not preset pass fixture or mature-case certification'}
(R/'initial-review-seal.json').write_text(json.dumps(seal,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(seal,ensure_ascii=False))
