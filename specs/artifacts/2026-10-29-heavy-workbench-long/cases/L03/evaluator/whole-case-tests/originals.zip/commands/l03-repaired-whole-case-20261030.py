from pathlib import Path
from datetime import datetime,timezone
import shutil,json,subprocess,sys
R=Path('D:/myhexin-local/opencorvus');L=R/'specs/artifacts/2026-10-29-heavy-workbench-long/cases/L03';O=Path('D:/opencorvus-benchmark-runs/l03-full-case-20261030')
submission=O/'repaired-submission';submission.mkdir(exist_ok=False)
for n in ['closing_rules.py','reference.py']:shutil.copy2(L/'evaluator'/n,submission/n)
shutil.copy2(O/'final-submission/submission.json',submission/'submission.json')
source=O/'repaired-evaluator-source';source.mkdir()
for p in (L/'evaluator').glob('*.py'):shutil.copy2(p,source/p.name)
shutil.copy2(L/'rubric.json',O/'repaired-rubric.json')
for name,program in [('repaired-reference-run',submission),('repaired-stale-run',O/'stale-submission')]:
    argv=[sys.executable,'-X','utf8','-B',str(L/'evaluator/evaluate.py'),'--submission',str(program),'--input',str(L/'public/inputs'),'--run',str(O/name),'--image','sha256:23ff8bfbf8055caa0b9fa5745ddb27cceea2f31d7d15b7a900c81112cdfe8ddf']
    start=datetime.now(timezone.utc).isoformat();p=subprocess.run(argv,cwd=R,capture_output=True,text=True,encoding='utf-8')
    (O/(name+'.stdout')).write_text(p.stdout,encoding='utf-8');(O/(name+'.stderr')).write_text(p.stderr,encoding='utf-8')
    (O/(name+'-command.json')).write_text(json.dumps({'argv':argv,'started_at':start,'finished_at':datetime.now(timezone.utc).isoformat(),'exit_code':p.returncode},indent=2)+'\n')
    if p.returncode!=4:raise RuntimeError('expected real unassessed-content exit4; preserve error')
    assessment=json.loads((O/name/'assessment.json').read_text());m15=next(r for r in assessment['findings'] if r['id']=='M15')
    assert all(r['status']=='pass' for r in assessment['findings'][:14])
    assert m15['status']==('pass' if name=='repaired-reference-run' else 'fail')
    print(json.dumps({'run':name,'native_runs':4,'base_numeric':'14pass','M15':m15['status'],'actual_exit':p.returncode}),flush=True)
old=O/'final-reference-run';new=O/'repaired-reference-run'
same={name:json.loads((old/name/'output/result/result.json').read_text(encoding='utf-8'))==json.loads((new/name/'output/result/result.json').read_text(encoding='utf-8')) for name in ['base','amount-change','new-period','late-correction']}
(O/'calendar-business-equivalence.json').write_text(json.dumps({'old_invalid_calendar_originals_preserved':True,'results_equal_by_actual_complete_objects':same,'scope':'calendar chronology corrected; no money, cutoff, allocation or decision rules altered'},indent=2)+'\n')
assert all(same.values())
