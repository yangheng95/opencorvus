import argparse,shutil
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--input');p.add_argument('--output');a=p.parse_args();shutil.copytree(Path(__file__).parent/'frozen-output',a.output)
