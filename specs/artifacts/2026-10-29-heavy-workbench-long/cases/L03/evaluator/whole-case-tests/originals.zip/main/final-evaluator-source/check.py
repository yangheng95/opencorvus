"""Actual L03 output checker; source execution is an evaluator-owned receipt."""
import argparse,json
from collections import defaultdict
from fractions import Fraction
from pathlib import Path
from closing_rules import close,parse

RUBRIC=parse((Path(__file__).resolve().parents[1]/'rubric.json').read_text(encoding='utf-8'))
LEAVES={r['id']:r for r in RUBRIC['leaves']}
if len(LEAVES)!=20 or set(LEAVES)!={*[f'M{i:02}' for i in range(1,16)],*[f'H{i:02}' for i in range(1,6)]} or sum(r['weight'] for r in LEAVES.values())!=100:raise ValueError('complete fixed rubric required')
if any(type(r['weight']) is not int or r['weight']<=0 or type(r['critical']) is not bool for r in LEAVES.values()):raise ValueError('typed positive weights and critical flags required')
NUMERIC_KEYS=[('M01','documents'),('M02','document_values'),('M03','allocations'),('M04','bank'),('M05','settlements'),('M06','unallocated'),
 ('M07','journal'),('M08','monthly'),('M09','vendors'),('M10','departments'),('M11','decision'),('M12','break_even'),('M13','cash'),('M14','exceptions')]
MACHINE=[(i,k,LEAVES[i]['criterion'],LEAVES[i]['weight']) for i,k in NUMERIC_KEYS]
HUMAN=[(i,LEAVES[i]['criterion'],LEAVES[i]['weight']) for i in [f'H{n:02}' for n in range(1,6)]]

def canonical(value,key=''):
    if key.endswith('_exact') and value is not None:
        if type(value) is not str:raise ValueError('exact values require rational strings')
        return ['rational',str(Fraction(value))]
    if type(value) is dict:return {k:canonical(v,k) for k,v in sorted(value.items())}
    if type(value) is list:
        rows=[canonical(v) for v in value];return sorted(rows,key=lambda r:json.dumps(r,sort_keys=True,ensure_ascii=False))
    if type(value) not in (str,int,bool,type(None)):raise ValueError('typed JSON required')
    return [type(value).__name__,value]
def journal_sum(rows):
    totals=defaultdict(int)
    for r in rows:
        if type(r) is not dict or any(type(r.get(k)) is not str for k in ['source_type','source_id','month','account']) or type(r.get('amount_minor')) is not int:raise ValueError('typed journal row')
        totals[r['source_type'],r['source_id'],r['month'],r['account']]+=r['amount_minor']
    return [dict(zip(['source_type','source_id','month','account'],k),amount_minor=v) for k,v in totals.items() if v]
def projected(result):
    docs=result['documents'];journal=journal_sum(result['journal']);monthly=result['monthly'];decision=result['decision']
    return {'documents':[{k:r.get(k) for k in ['doc_id','revision','status','vendor','department','book_month','service_months']} for r in docs],
      'document_values':[{k:r.get(k) for k in ['doc_id','gross_minor','currency','native_minor','fx_revision','lines']} for r in docs],
      'allocations':{'source':[r for r in journal if r['source_type']=='doc'],'months':[{k:r[k] for k in ['month','service_expense_minor','prepaid_close_minor']} for r in monthly]},
      'bank':result['bank'],'settlements':result['settlements'],
      'unallocated':[{k:r[k] for k in ['bank_tx_id','unallocated_minor','status']} for r in result['bank']],
      'journal':journal,'monthly':monthly,'vendors':result['vendors'],'departments':{'rows':result['departments'],'legacy_bridge':result['legacy_bridge']},
      'decision':{k:v for k,v in decision.items() if k!='break_even'},'break_even':decision['break_even'],
      'cash':[{k:r[k] for k in ['month','cash_open_minor','cash_out_minor','cash_close_minor']} for r in monthly],'exceptions':result['exceptions']}

def assess(input_root,output_root,execution=None,review=None):
    expected=projected(close(input_root));output_root=Path(output_root);findings=[]
    try:
        actual=parse((output_root/'result.json').read_text(encoding='utf-8'))
        if actual.get('format')!='l03-close-result/1':raise ValueError('format')
        actual=projected(actual)
        for id,key,title,weight in MACHINE:
            try:good=canonical(actual[key])==canonical(expected[key])
            except (ValueError,TypeError,KeyError,ZeroDivisionError):good=False
            findings.append({'id':id,'weight':weight,'critical':LEAVES[id]['critical'],'status':'pass' if good else 'fail','criterion':title})
    except (OSError,ValueError,TypeError,KeyError):
        findings=[{'id':i,'weight':w,'critical':LEAVES[i]['critical'],'status':'missing','criterion':t} for i,k,t,w in MACHINE]
    execution_status='unassessed'
    if execution is not None:
        runs=execution.get('runs',[])
        valid=execution.get('all_declared_runs_verified') is True and len(runs)==4 and {r.get('variant') for r in runs}=={'base','amount-change','new-period','late-correction'}
        valid=valid and all(r.get('verified') is True and type(r.get('native_exit')) is int and r['native_exit']==0 for r in runs)
        valid=valid and next((Path(r['output']).resolve()==output_root.resolve() for r in runs if r['variant']=='base'),False)
        execution_status='pass' if valid else 'fail'
    findings.append({'id':'M15','weight':LEAVES['M15']['weight'],'critical':LEAVES['M15']['critical'],'status':execution_status,'criterion':LEAVES['M15']['criterion']})
    for id,title,weight in HUMAN:
        rating=None if review is None else review.get('findings',{}).get(id)
        if rating is not None and (rating.get('status') not in ['pass','fail','missing'] or not rating.get('basis') or not rating.get('sources')):raise ValueError('invalid trusted review evidence')
        findings.append({'id':id,'weight':weight,'critical':LEAVES[id]['critical'],'status':'unassessed' if rating is None else rating['status'],'criterion':title})
    pending=[r['id'] for r in findings if r['status']=='unassessed'];failed=[r['id'] for r in findings if r['critical'] and r['status'] in ['fail','missing']]
    total=None if pending else sum(r['weight'] for r in findings if r['status']=='pass')
    return {'case':RUBRIC['version'],'status':'incomplete_assessment' if pending else 'graded','findings':findings,'total':total,'critical_failures':failed,
        'good':None if pending else total>=RUBRIC['good_score_at_least'] and not failed,'scope':'synthetic management close; not professional financial certification or candidate-hour evidence'}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--input',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--assessment',type=Path,required=True)
    p.add_argument('--execution',type=Path);p.add_argument('--review',type=Path);a=p.parse_args()
    try:
        execution=None if a.execution is None else json.loads(a.execution.read_text());review=None if a.review is None else json.loads(a.review.read_text())
        value=assess(a.input,a.output,execution,review);a.assessment.parent.mkdir(parents=True,exist_ok=True);a.assessment.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        print(json.dumps({'status':value['status'],'numeric_pass':sum(r['status']=='pass' for r in value['findings'][:14]),'total':value['total'],'good':value['good']}));raise SystemExit(4 if value['total'] is None else 0 if value['good'] else 2)
    except (OSError,ValueError,KeyError,TypeError) as e:
        print(json.dumps({'status':'facility_error','detail':str(e)}));raise SystemExit(3)
