from pathlib import Path
from datetime import datetime,timezone
import json,shutil,subprocess
R=Path(__file__).resolve().parent
base=Path('D:/opencorvus-benchmark-runs/l03-full-case-20261030/review-final-run/base/output/result')
raw=Path('D:/opencorvus-benchmark-runs/l03-full-case-20261030/review-final-run/base/input')
def source(p,where):return{'path':str(p).replace('\\','/'),'locator':where}
def finding(basis,*refs):return{'status':'pass','basis':basis,'sources':list(refs)}
findings={
 'H01':finding('已独立从原资料核最高可用版本/撤销/冲突/逐行FX及逐来源账到月度和legacy桥，完整账相同；修后UTC有效，不以账平证明来源真实。',
    source(base/'REPORT.md','结账与现金；原管理账到重述结果'),source(raw/'documents.jsonl','I-cancelled/I-conflict/I-resolved/I-rounding'),source(raw/'fx.jsonl','FX-Jan-correction及未发布版本'),source(R/'independent-book-reviewed/receipt.json','全部field_comparisons'),source(R/'whole-case-evidence.json','calendar_invalid_rows_after_repair')),
 'H02':finding('current无方案；available−4345032分，bridge/hybrid201000与expanded/bulk212000分为有条件融资选择。900/7超switch容量120及含融资费950/7交点有实际域解释，不声称因果/真实认证或全部未来偿付。',
    source(base/'REPORT.md','有条件的管理方案；资金缺口与附条件选择'),source(raw/'choices.json','工作量/四方案/资金报价'),source(base/'result.json','decision及monthly'),source(R/'independent-book-reviewed/receipt.json','独立decision重算')),
 'H03':finding('10条未决均有身份、金额或冲突及证据状态，逐项取证动作可定位；不猜配confirmed余2分/ambiguous/无通知，不把I-conflict责任当零。',
    source(base/'exceptions.csv','全部10行'),source(base/'REPORT.md','每项未决的后续动作；未决责任限制'),source(raw/'advice.jsonl','对应bank_tx_id最高版本')),
 'H04':finding('已实际view最终dashboard.png：CNY/月份/系列可读，费用预算/负现金/应付预付和未解释款与本次账相同；报告解释透支459860及余量140140分。',
    source(base/'dashboard.png','实际视觉查看三个panel'),source(base/'monthly.csv','2025-01..03'),source(base/'REPORT.md','金额单位及透支说明')),
 'H05':finding('仅两声明源码/九原输入在独立新目录只读1CPU/netnone真实冷跑native0；同源主方三变体原执行另读，不重矩阵。命令/环境/机器账/未决与更新交接可用，无旧答案缓存。',
    source(R/'submission-reviewed/submission.json','files及argv'),source(R/'cold-base/run-receipt.json','唯一独立基例冷跑'),source(R/'cold-base/terminal-inspect.json','实际权限/挂载/终态'),source(R/'whole-case-evidence.json','四实际同源运行'),source(base/'REPORT.md','清洁复建和更新'))}
for row in findings.values():
    for item in row['sources']:assert Path(item['path']).is_file(),item['path']
review={'format':'l03-independent-content-review/1','case':'L03/0.2.0-dev','output_root':str(base).replace('\\','/'),
    'reviewer':'/root/benchmark_review','subject_role':'author_reference_qualification',
    'disclosure':'Non-blind AI agent familiar with author material and repairs; not professional human, statistical maturity or candidate-hour certification.','findings':findings}
(R/'review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
case=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L03')
shutil.copytree(case/'public',R/'public-reviewed');shutil.copy2(case/'rubric.json',R/'rubric-reviewed.json')
stage={'format':'l03-whole-case-independent-final/1','observed_at_utc':datetime.now(timezone.utc).isoformat(),'case':'L03/0.2.0-dev','output_root':review['output_root'],
 'complete_development_case':True,'allow_development_pilot_freeze_metadata_and_README_only':True,'identity_material_weights_threshold_final_execution_objects_preserved':True,
 'remaining_substantive_blockers':[],'resolved_findings':['invalid UTC dates','ordered service months','unordered economic pair fairness','actual management domain explanation','source ancestor escape'],
 'independent_content_status':{k:v['status']for k,v in findings.items()},'independent_whole_raw_book_equal':True,'independent_base_cold_native_exit':0,
 'independent_base_cold_one_only':True,'independent_base_wall_including_seal_cleanup_seconds':2.7086021997965872,'main_four_actual_runs_read_not_repeated':True,
 'reference_PNG_actually_viewed':True,'stale_program_M15_failure_read':True,'total_handwritten':False,'original_failures_and_reviewer_errors_preserved':True,
 'new_LLM_Provider_GPU_solver_UI_calls':0,'hour_difficulty_validated':False,'professional_or_statistical_maturity_certified':False,'ten_case_complete':False}
(R/'stage-final.json').write_text(json.dumps(stage,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
p=subprocess.run(['git','status','--short'],cwd='D:/myhexin-local/opencorvus',capture_output=True);(R/'workspace-status-end.txt').write_bytes(p.stdout)
print(json.dumps({'review_saved':True,'five_statuses':[v['status']for v in findings.values()],'pilot_freeze_allowed':True,'total_handwritten':False}))
