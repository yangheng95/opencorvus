from pathlib import Path
from datetime import datetime,timezone
import copy,json,subprocess,sys,shutil,time
R=Path('D:/myhexin-local/opencorvus');L=R/'specs/artifacts/2026-10-29-heavy-workbench-long/cases/L03';O=Path('D:/opencorvus-benchmark-runs/l03-full-case-20261030');base=O/'final-reference-run/base/output/result'
out=O/'complete-controls';out.mkdir(exist_ok=False);records=[]
def run(name,inputs,outputs,expected_failures=(),execution=None):
    target=out/name;target.mkdir(exist_ok=False)
    argv=[sys.executable,'-X','utf8','-B',str(L/'evaluator/check.py'),'--input',str(inputs),'--output',str(outputs),'--assessment',str(target/'assessment.json')]
    if execution:argv+=['--execution',str(execution)]
    start=datetime.now(timezone.utc).isoformat();p=subprocess.run(argv,cwd=R,capture_output=True,text=True,encoding='utf-8')
    (target/'stdout.txt').write_text(p.stdout,encoding='utf-8');(target/'stderr.txt').write_text(p.stderr,encoding='utf-8')
    assessment=json.loads((target/'assessment.json').read_text(encoding='utf-8'));failed={r['id'] for r in assessment['findings'] if r['status'] in ['fail','missing']}
    good=set(expected_failures)<=failed if expected_failures else all(r['status']=='pass' for r in assessment['findings'][:14])
    rec={'name':name,'argv':argv,'started_at':start,'finished_at':datetime.now(timezone.utc).isoformat(),'exit_code':p.returncode,'failed':sorted(failed),'expected_failures':list(expected_failures),'qualified':good,'scope':'real checker CLI; content review still pending'}
    (target/'command.json').write_text(json.dumps(rec,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');records.append(rec)
    if not good:raise AssertionError(rec)
for name in ['base','amount-change','new-period','late-correction']:
    run('correct-'+name,O/'final-reference-run'/name/'input',O/'final-reference-run'/name/'output/result',execution=O/'final-reference-run/execution.json' if name=='base' else None)
original=json.loads((base/'result.json').read_text(encoding='utf-8'))
def material(name,value):
    p=out/('artifact-'+name);p.mkdir();(p/'result.json').write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');return p
wrong=copy.deepcopy(original);d=next(d for d in wrong['documents'] if d['doc_id']=='I-rounding');d['gross_minor']=71;d['lines'][0]['base_minor']=35
run('wrong-rounding',L/'public/inputs',material('wrong-rounding',wrong),['M02'])
wrong=copy.deepcopy(original);wrong['bank'].append(copy.deepcopy(wrong['bank'][0]))
run('duplicate-bank',L/'public/inputs',material('duplicate-bank',wrong),['M04','M06'])
wrong=copy.deepcopy(original);wrong['journal'] +=[{'source_type':'doc','source_id':'I013','month':'2025-01','account':'Expense:Engineering','amount_minor':100},{'source_type':'doc','source_id':'I013','month':'2025-01','account':'AP:V1','amount_minor':-100}]
run('balanced-fictional-posting',L/'public/inputs',material('balanced-fictional-posting',wrong),['M03','M07'])
wrong=copy.deepcopy(original);r=next(b for b in wrong['bank'] if b['bank_tx_id']=='P-unknown');r.update(allocated_minor=700,unallocated_minor=0,status='confirmed');wrong['exceptions']=[r for r in wrong['exceptions'] if r['identity']!='P-unknown']
run('unsupported-bank-match',L/'public/inputs',material('unsupported-bank-match',wrong),['M04','M06','M14'])
equivalent=copy.deepcopy(original)
for name,value in equivalent.items():
    if isinstance(value,list):value.reverse()
for row in equivalent['bank']:row['source_note']='extra honest metadata'
for row in equivalent['documents']:
    for line in row.get('lines',[]):line['source_note']='extra honest line metadata'
equivalent['decision']['options'][0]['expected_cost_exact']='384000/2'
run('equivalent-order-metadata-rational',L/'public/inputs',material('equivalent',equivalent))
partial=copy.deepcopy(original);del partial['decision'];run('missing-decision-local',L/'public/inputs',material('partial',partial),['M11','M12'])
a=json.loads((out/'missing-decision-local/assessment.json').read_text(encoding='utf-8'));assert all(r['status']=='pass' for r in a['findings'][:10]),'independent delivered leaves retain actual passes'
(out/'summary.json').write_text(json.dumps({'commands':len(records),'all_qualified':all(r['qualified'] for r in records),'records':records,'scope':'four real corrected outputs, four business errors, one equivalent complete output, one partial delivery; no invented whole-case scores'},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'commands':len(records),'all_qualified':True,'new_native_runs':0,'candidate_scores':None}))
