"""Independent whole-book calculation from original raw facts; no author imports.

Fractions perform conversions. A source/period/account event map is the working
ledger. This audit does not execute a candidate or call its checker/core.
"""
import argparse,csv,json
from fractions import Fraction as F
from collections import defaultdict
from pathlib import Path

def load(path):return json.loads(path.read_text(encoding='utf-8'))
def jl(path):return [json.loads(s)for s in path.read_text(encoding='utf-8').splitlines()if s.strip()]
def money(s):
    n=F(s)*100
    assert n.denominator==1
    return n.numerator
def round_half(x):
    if x<0:return -round_half(-x)
    return (2*x.numerator+x.denominator)//(2*x.denominator)
def versioned(rows,keys,cutoff):
    groups=defaultdict(list)
    for row in rows:
        if row['released_at']<=cutoff:groups[tuple(row[k]for k in keys)].append(row)
    out={}
    for key,versions in groups.items():
        top=max(x['revision']for x in versions)
        payloads={json.dumps({k:v for k,v in x.items()if k!='source_id'},sort_keys=True)for x in versions if x['revision']==top}
        out[key]=json.loads(next(iter(payloads)))if len(payloads)==1 else{'conflict':True,'revision':top}
    return out

def reconstruct(root):
    company=load(root/'company.json');months=company['months'];cutoff=company['as_of']
    rates=versioned(jl(root/'fx.jsonl'),['currency','rate_date'],cutoff)
    sources=versioned(jl(root/'documents.jsonl'),['doc_id'],cutoff)
    event=defaultdict(int);documents=[];recognized={};exceptions=[]
    def entry(kind,identity,period,account,value):event[kind,identity,period,account]+=value
    entry('opening','opening',months[0],'Cash',company['opening_cash_minor'])
    entry('opening','opening',months[0],'OpeningEquity',-company['opening_cash_minor'])
    for (key,),doc in sorted(sources.items()):
        if doc.get('conflict'):
            documents.append({'doc_id':key,'revision':doc['revision'],'status':'quarantined','gross_minor':None})
            exceptions.append({'kind':'document_conflict','identity':key,'revision':doc['revision'],'status':'unresolved'});continue
        if doc['status']=='cancelled':
            documents.append({'doc_id':key,'revision':doc['revision'],'status':'cancelled','gross_minor':0});continue
        factor=rates[doc['currency'],doc['rate_date']];sign=1 if doc['kind']=='invoice'else-1
        lines=[{'line_id':row['line_id'],'native_minor':money(row['amount']),'base_minor':sign*round_half(F(row['amount'])*F(factor['rate'])*100)}for row in doc['lines']]
        gross=sum(x['base_minor']for x in lines)
        rec={'doc_id':key,'revision':doc['revision'],'status':'posted','vendor':doc['vendor'],'department':doc['department'],
            'book_month':doc['book_month'],'service_months':doc['service_months'],'currency':doc['currency'],
            'native_minor':sign*sum(x['native_minor']for x in lines),'fx_revision':factor['revision'],'gross_minor':gross,'lines':lines}
        recognized[key]=rec;documents.append(rec)
        entry('doc',key,doc['book_month'],'Prepaid:'+doc['department'],gross)
        entry('doc',key,doc['book_month'],'AP:'+doc['vendor'],-gross)
        share=abs(gross)//len(doc['service_months'])
        amounts=[sign*share]*(len(doc['service_months'])-1)
        amounts.append(gross-sum(amounts))
        for month,value in zip(doc['service_months'],amounts):
            entry('doc',key,month,'Expense:'+doc['department'],value);entry('doc',key,month,'Prepaid:'+doc['department'],-value)
    banks={}
    for row in jl(root/'bank.jsonl'):
        if row['released_at']>cutoff:continue
        key=row['bank_tx_id'];value={k:v for k,v in row.items()if k!='source_id'}
        assert key not in banks or banks[key]==value
        banks[key]=value
    advice=versioned(jl(root/'advice.jsonl'),['bank_tx_id'],cutoff)
    paid_native=defaultdict(int);released_book=defaultdict(int);settlements=[];bank=[]
    for key in sorted(banks,key=lambda k:(banks[k]['posted_at'],k)):
        row=banks[key];month=row['posted_at'][:7];a=advice.get((key,));confirmed=a is not None and not a.get('conflict')and a['status']=='confirmed'
        allocated=0
        entry('bank',key,month,'Cash',-row['amount_minor']);entry('bank',key,month,'Expense:Finance',row['fee_minor'])
        if confirmed:
            for alloc in a['allocations']:
                doc=recognized[alloc['doc_id']];n=money(alloc['amount_native']);paid_native[doc['doc_id']]+=n
                assert 0<doc['native_minor']and paid_native[doc['doc_id']]<=doc['native_minor']
                target=round_half(F(doc['gross_minor']*paid_native[doc['doc_id']],doc['native_minor']))
                amount=target-released_book[doc['doc_id']];released_book[doc['doc_id']]=target
                cash=alloc['cash_minor'];allocated+=cash;fx=cash-amount
                settlements.append({'bank_tx_id':key,'doc_id':doc['doc_id'],'month':month,'native_minor':n,'book_minor':amount,'cash_minor':cash,'fx_minor':fx})
                entry('bank',key,month,'AP:'+doc['vendor'],amount);entry('bank',key,month,'FX:'+doc['department'],fx)
        rest=row['amount_minor']-allocated-row['fee_minor'];assert rest>=0
        entry('bank',key,month,'Suspense',rest)
        if rest:exceptions.append({'kind':'bank_unallocated','identity':key,'amount_minor':rest,'status':'unresolved','evidence_status':None if a is None else'conflict'if a.get('conflict')else a['status']})
        bank.append({'bank_tx_id':key,'month':month,'amount_minor':row['amount_minor'],'fee_minor':row['fee_minor'],'allocated_minor':allocated,'unallocated_minor':rest,'status':'confirmed'if confirmed else'unresolved'})
    budgets=versioned(jl(root/'budgets.jsonl'),['department','month'],cutoff)
    commits=versioned(jl(root/'commitments.jsonl'),['commit_id'],cutoff)
    vendors=sorted({r['vendor']for r in recognized.values()});depts=sorted({r['department']for r in recognized.values()}|{d for d,m in budgets}|{'Finance'})
    balance=defaultdict(int);monthly=[];vendor_rows=[];department_rows=[];opening=company['opening_cash_minor']
    for month in months:
        change=defaultdict(int)
        for (kind,key,period,acct),value in event.items():
            if period==month:change[acct]+=value;balance[acct]+=value
        pay=sum(max(-balance['AP:'+v],0)for v in vendors);advance=sum(max(balance['AP:'+v],0)for v in vendors)
        service=sum(change['Expense:'+d]for d in depts if d!='Finance');fees=change['Expense:Finance'];fx=sum(change['FX:'+d]for d in depts)
        budget=sum(row['amount_minor']for(d,m),row in budgets.items()if m==month)
        monthly.append({'month':month,'cash_open_minor':opening,'cash_out_minor':sum(b['amount_minor']for b in bank if b['month']==month),'cash_close_minor':balance['Cash'],
            'service_expense_minor':service,'fees_minor':fees,'fx_minor':fx,'expense_minor':service+fees+fx,
            'prepaid_close_minor':sum(balance['Prepaid:'+d]for d in depts),'ap_net_close_minor':pay-advance,'ap_payable_close_minor':pay,'vendor_advance_close_minor':advance,
            'suspense_close_minor':balance['Suspense'],'budget_minor':budget,'variance_minor':budget-service-fees-fx,
            'open_commitments_minor':sum(c['amount_minor']for c in commits.values()if not c.get('conflict')and c['status']=='open'and c['expected_month']==month),
            'overdraft_used_minor':max(-balance['Cash'],0),'overdraft_headroom_minor':company['bank_overdraft_limit_minor']-max(-balance['Cash'],0)})
        opening=balance['Cash']
        for vendor in vendors:
            net=-balance['AP:'+vendor];vendor_rows.append({'vendor':vendor,'month':month,'net_ap_minor':net,'payable_minor':max(net,0),'advance_minor':max(-net,0)})
        for department in depts:
            expense=change['Expense:'+department]+change['FX:'+department];budget=budgets.get((department,month),{}).get('amount_minor',0)
            department_rows.append({'department':department,'month':month,'expense_minor':expense,'budget_minor':budget,'variance_minor':budget-expense})
    journal=[{'source_type':k[0],'source_id':k[1],'month':k[2],'account':k[3],'amount_minor':v}for k,v in event.items()if v]
    source_balance=defaultdict(int)
    for(kind,key,period,acct),amount in event.items():source_balance[kind,key,period]+=amount
    assert all(v==0 for v in source_balance.values())
    choices=load(root/'choices.json');available=monthly[-1]['cash_close_minor']-monthly[-1]['ap_payable_close_minor']-choices['reserve_minor']
    options=[]
    for option in choices['options']:
        expectation=sum(F(s['probability'])*(option['fixed_minor']+option['unit_minor']*s['units'])for s in choices['scenarios'])
        options.append({'id':option['id'],'capacity_ok':all(s['units']<=option['capacity']for s in choices['scenarios']),'cash_ok':option['upfront_minor']<=available,'minimum_new_funding_minor':max(option['upfront_minor']-available,0),'expected_cost_exact':str(expectation)})
    eligible=[o for o in options if o['capacity_ok']and o['cash_ok']]
    selected=None if not eligible else min(eligible,key=lambda x:(F(x['expected_cost_exact']),x['id']))['id']
    funding=[]
    for offer in choices['funding_offers']:
        valid=[o for o,raw in zip(options,choices['options'])if o['capacity_ok']and raw['upfront_minor']<=available+offer['additional_cash_minor']]
        best=None if not valid else min(valid,key=lambda x:(F(x['expected_cost_exact']),x['id']))
        funding.append({'funding_id':offer['id'],'status':offer['status'],'additional_cash_minor':offer['additional_cash_minor'],'funding_fee_minor':offer['fee_minor'],'available_cash_minor':available+offer['additional_cash_minor'],
            'selected_plan':None if best is None else best['id'],'expected_total_cost_exact':None if best is None else str(F(best['expected_cost_exact'])+offer['fee_minor'])})
    best=min((r for r in funding if r['selected_plan']is not None),key=lambda x:(F(x['expected_total_cost_exact']),x['funding_id'],x['selected_plan']),default=None)
    cross=[{'left':a['id'],'right':b['id'],'volume_exact':None if a['unit_minor']==b['unit_minor']else str(F(b['fixed_minor']-a['fixed_minor'],a['unit_minor']-b['unit_minor']))}for i,a in enumerate(choices['options'])for b in choices['options'][i+1:]]
    decision={'available_cash_minor':available,'options':options,'selected':selected,'break_even':cross,'funding_scenarios':funding,'conditional_recommendation':None if best is None else{k:best[source]for k,source in [('funding_id','funding_id'),('plan_id','selected_plan'),('expected_total_cost_exact','expected_total_cost_exact')]}}
    with(root/'legacy-close.csv').open(encoding='utf-8',newline='')as f:legacy={r['month']:r for r in csv.DictReader(f)}
    bridge=[{'month':r['month'],'legacy_expense_minor':int(legacy[r['month']]['reported_expense_minor']),'corrected_expense_minor':r['expense_minor'],'expense_adjustment_minor':r['expense_minor']-int(legacy[r['month']]['reported_expense_minor']),
        'legacy_cash_close_minor':int(legacy[r['month']]['reported_cash_close_minor']),'corrected_cash_close_minor':r['cash_close_minor'],'cash_adjustment_minor':r['cash_close_minor']-int(legacy[r['month']]['reported_cash_close_minor'])}for r in monthly if r['month']in legacy]
    return {'format':'l03-close-result/1','documents':documents,'bank':bank,'settlements':settlements,'journal':journal,'monthly':monthly,'vendors':vendor_rows,'departments':department_rows,'exceptions':exceptions,'decision':decision,'legacy_bridge':bridge}

def normal(value,key=''):
    if isinstance(value,dict):return{k:normal(v,k)for k,v in value.items()}
    if isinstance(value,list):
        content=[normal(x)for x in value]
        return content if key=='service_months'else sorted(content,key=lambda v:json.dumps(v,sort_keys=True))
    return value
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--input',type=Path,required=True);p.add_argument('--result',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
    a.out.mkdir();independent=reconstruct(a.input);submitted=load(a.result)
    comparisons={key:normal(value,key)==normal(submitted.get(key),key)for key,value in independent.items()}
    (a.out/'independent-result.json').write_text(json.dumps(independent,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    receipt={'whole_book_equal':all(comparisons.values()),'field_comparisons':comparisons,'monthly':independent['monthly'],'decision':independent['decision'],
        'scope':'whole raw book independently reconstructed with exact Fraction arithmetic; no author module/checker imported; original impossible timestamps remain separate material blocker'}
    (a.out/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps({'whole_book_equal':all(comparisons.values()),'fields':comparisons}))
