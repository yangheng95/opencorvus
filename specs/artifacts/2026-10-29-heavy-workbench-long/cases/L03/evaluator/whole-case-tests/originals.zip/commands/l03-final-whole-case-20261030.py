from pathlib import Path
from datetime import datetime,timezone
import shutil,json,subprocess,sys,time
R=Path('D:/myhexin-local/opencorvus');L=R/'specs/artifacts/2026-10-29-heavy-workbench-long/cases/L03';O=Path('D:/opencorvus-benchmark-runs/l03-full-case-20261030')
submission=O/'review-final-submission';submission.mkdir(exist_ok=False)
for n in ['closing_rules.py','reference.py']:shutil.copy2(L/'evaluator'/n,submission/n)
shutil.copy2(O/'final-submission/submission.json',submission/'submission.json')
source=O/'review-final-evaluator-source';source.mkdir()
for p in (L/'evaluator').glob('*.py'):shutil.copy2(p,source/p.name)
shutil.copy2(L/'rubric.json',O/'review-final-rubric.json')
argv=[sys.executable,'-X','utf8','-B',str(L/'evaluator/evaluate.py'),'--submission',str(submission),'--input',str(L/'public/inputs'),'--run',str(O/'review-final-run'),'--image','sha256:23ff8bfbf8055caa0b9fa5745ddb27cceea2f31d7d15b7a900c81112cdfe8ddf']
start=datetime.now(timezone.utc).isoformat();clock=time.monotonic();p=subprocess.run(argv,cwd=R,capture_output=True,text=True,encoding='utf-8')
(O/'review-final.stdout').write_text(p.stdout,encoding='utf-8');(O/'review-final.stderr').write_text(p.stderr,encoding='utf-8')
(O/'review-final-command.json').write_text(json.dumps({'argv':argv,'started_at':start,'finished_at':datetime.now(timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-clock,'exit_code':p.returncode},indent=2)+'\n')
if p.returncode!=4:raise RuntimeError('expected incomplete content assessment exit4; inspect original error')
a=json.loads((O/'review-final-run/assessment.json').read_text());assert all(r['status']=='pass' for r in a['findings'][:15])
print(json.dumps({'native_runs':4,'machine':'15pass','whole_score':None,'reason':'actual five content ratings pending'}))
