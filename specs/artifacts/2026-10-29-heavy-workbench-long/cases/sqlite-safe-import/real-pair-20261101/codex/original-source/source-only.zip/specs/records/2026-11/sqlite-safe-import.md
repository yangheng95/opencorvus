# SQLite safe imports

## Recall

The public task requires checkpoint lifecycle APIs with named errors, persistent table invariants, atomic safe insert/upsert/CSV/JSON APIs and CLI insert/upsert/bulk including UPDATE, documentation, actual SQLite validation, HANDOFF.md and a source commit on main. Public material and the declared runtime are immutable. No delegation, network, branch, remote change or push is authorized.

Read: public/TASK.md, TASK.original.md, QUALITY.md, INPUTS.json, RUNTIME.md; pyproject.toml; Database construction/execution, table creation, insert/upsert, transform, script and transaction paths; CLI import options/parser and bulk execution; focused existing tests and documentation generation rules.

Search: checkpoint/invariant/import API definitions across sqlite_utils are absent. All commit-capable connection contexts and executescript calls in db.py were identified; CLI insert/upsert/bulk share insert_upsert_implementation. No specs tree or package.json documentation checker exists in this upstream Python repository. No UI is in scope. No scheduling/queue mechanism is involved. No delegation was used.

## Analysis before implementation

Observable issue: normal imports commit batches independently; later insertion, conversion or invariant errors can leave earlier writes and schema changes committed. Direct trigger effects and type conversion must be atomic with the operation. Root cause: sqlite3 connection contexts commit on success and roll back on failure, regardless of an external savepoint. executescript also commits pending transactions. A wrapper savepoint without addressing these paths cannot protect an import.

Impact: Database/Table transaction contexts, Database.executescript, persistent metadata, the common CLI importer and docs. Existing public ordinary write behavior remains the contract when no checkpoint is active. Checkpoints are connection-local savepoints, persistent configuration/invariants use two reserved SQLite tables. No existing data format is migrated; metadata is created lazily without rewriting user tables. Direct caller connection commit/rollback and transaction-control SQL remain caller-owned and cannot safely coexist with active checkpoints; this boundary will be documented.

## Implementation plan

1. Introduce named checkpoint and validation errors, persistent enable/invariant APIs and nested savepoint lifecycle. Finalizing an ancestor finalizes descendants; cleaning an active checkpoint rolls it back before removing its identity.
2. Replace package-owned connection contexts with a shared checkpoint-aware transaction context. Preserve script statements without implicit commit while checkpoints are active. Do not introduce database snapshots or shadow user data.
3. Execute SELECT invariants using the first value; execute expressions as SELECT(expression) FROM table and require every returned row to be truthy. SQLite naturally emits one row for aggregates. Preserve SQL errors as identified failures.
4. Integrate one safe-operation runner into insert/upsert/CSV/JSON and CLI import/bulk. Validate all registered tables so triggers/cross-table changes are covered. Keep strict rollback-and-raise and non-strict structured failures. Explicit safe operations enable safe support when needed; manual checkpoint creation requires enablement.
5. Add focused real-SQLite tests for lifecycle, persistence, complete schema/data rollback, batching/parser failures, strict/non-strict, trigger effects, nested operation, and native CLI process contracts. Run appropriate upstream import/transform tests. Save reproducible evidence, update docs and HANDOFF, review diff and commit on main.

## Verification

Pending implementation. Use only the Python interpreter declared in public/RUNTIME.md, local sources, and actual SQLite files. Set TEMP/TMP and pytest base directory inside this project. No benchmark grade is inferred from checks.

## Implementation and verification outcome

Implemented the plan in the existing package. A shared Database.transaction() preserves active savepoints across all package-owned Database/Table connection contexts. Script execution uses SQLite complete_statement parsing while checkpoints are active, retaining full trigger statements without sqlite3.executescript's implicit commit. The counts-trigger script retains its original tracer visibility through the same internal script primitive. No-checkpoint behavior remains ordinary batch commits.

Explicit safe operations start their checkpoint before automatic enablement, so a failed first operation restores metadata as well as user schema and rows. This also preserves caller-owned transactions. Persistent invariants use SQLite's own scalar/aggregate evaluation, including custom aggregate functions. The CLI parser and CSV type transform are inside the safe boundary; safe CSV parsing uses the csv module's strict parser. All registered invariants are validated to cover trigger-side writes.

Validation commands and full native reproduction are in HANDOFF.md. The final relevant check set returned 471 passed, one optional pandas/numpy skip. The original regression run returned seven failures (six missing command-doc entries and one counts-tracer expectation); those actual issues were fixed and the same set rerun. No UI tests were involved. The saved final transcript is specs/artifacts/safe-import/regression.txt.

The source rebuild/evidence checker compiled current source, built its standard-library zipapp, compared the existing CLI reference generator with generated documentation and executed actual source/zipapp CLI subprocesses against real databases. specs/artifacts/safe-import/evidence.json records complete before/after schema and data, actual invariant IDs, commands, inputs, outputs and process exit codes. Source SQLite schema/data restoration includes altered columns, dropped indexes/triggers, newly created tables/indexes/triggers, multiple import batches and first-use metadata. No source hashes are acceptance criteria.

Tooling boundary: the declared runtime has no setuptools/wheel/build/Black/Cog/Sphinx; dependency fetches are forbidden. The source runnable archive and native execution succeeded. An official wheel and rendered Sphinx build were not claimed.

Known semantic boundary: SQLite RAISE(ROLLBACK)/OR ROLLBACK aborts the entire enclosing transaction. Top-level rollback-trigger failures preserve pre-operation state and original error (tested). Inside a caller-owned transaction or outer checkpoint this SQLite action also undoes earlier outer writes, so the unconditional exact-inner-pre-operation requirement is not fulfilled for that edge. Direct caller transaction-control operations likewise invalidate savepoints. These limitations are explicit in HANDOFF.md and Python API documentation; no backup fallback or keyword rewriting was added. No crash/power-loss experiment was performed. External Python/SQL-function side effects are outside SQLite rollback.

All owned child processes settled naturally. Source changes will be committed on main as authorized; no remote, branch, worktree, push or publication operation is part of this task.
