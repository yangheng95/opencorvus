# Safe import evidence

- `verify.py`: source-only bytecode/zipapp rebuild, generated CLI reference verification and actual API/native CLI checker.
- `evidence.json`: saved command inputs, outputs, exit codes and SQLite before/after facts from that checker.
- `regression.txt`: final relevant upstream/feature regression output, including its optional dependency skip.

Run from the project root with the interpreter in `public/RUNTIME.md`:

```powershell
& D:/opencorvus-benchmark-runs/sqlite-safe-import-pair-20261101/runtime/Scripts/python.exe -B specs/artifacts/safe-import/verify.py
```

The script writes owned databases, bytecode and a runnable source zipapp under `.local-tmp/source-evidence/`. Each invocation uses a fresh output directory and records actual state and native process behavior for both local source and the rebuilt zipapp. No wheel backend, downloads, model calls, database dumps as replacement implementations or mocked CLI processes are used. It preserves failures in its JSON evidence if an assertion fails. See HANDOFF.md for the explicit nested SQLite transaction-wide ROLLBACK boundary and unavailable wheel/Sphinx build tooling.
