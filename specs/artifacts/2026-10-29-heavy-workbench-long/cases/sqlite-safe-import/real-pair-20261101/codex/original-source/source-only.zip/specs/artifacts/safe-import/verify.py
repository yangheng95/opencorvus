"""Rebuild the pure-Python application and save real SQLite/CLI evidence."""

import json
import os
from pathlib import Path
import py_compile
import shutil
import sqlite3
import subprocess
import sys
import textwrap
import traceback
import zipapp


ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from sqlite_utils import Database  # noqa: E402


def state(db):
    return {
        "schema": list(db.query(
            "SELECT type, name, tbl_name, sql FROM sqlite_master ORDER BY type, name"
        )),
        "data": {name: list(db[name].rows) for name in db.table_names()},
    }


def verify():
    output = ROOT / ".local-tmp" / "source-evidence"
    output.mkdir(parents=True, exist_ok=True)
    # Every output path is project-owned. Unique database names preserve earlier
    # runs without deleting or recreating any user database.
    import uuid
    run = output / uuid.uuid4().hex
    run.mkdir()
    report = {
        "python": sys.version,
        "executable": sys.executable,
        "sqlite": sqlite3.sqlite_version,
        "run_directory": str(run.relative_to(ROOT)),
        "completed": False,
        "commands": [],
    }
    try:
        reference = (ROOT / "docs" / "cli-reference.rst").read_text(encoding="utf-8")
        start = reference.index(".. [[[cog\n") + len(".. [[[cog\n")
        stop = reference.index(".. ]]]", start)
        end = reference.index(".. [[[end]]]", stop)
        class Output:
            def __init__(self):
                self.parts = []

            def out(self, value):
                self.parts.append(value)

        cog = Output()
        exec(textwrap.dedent(reference[start:stop]), {"cog": cog})
        actual = reference[stop + len(".. ]]]") + 1:end]
        assert actual == "".join(cog.parts)
        report["cli_reference"] = "matches current native CLI help using its upstream generator"

        staging = run / "source"
        shutil.copytree(ROOT / "sqlite_utils", staging / "sqlite_utils",
                        ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
        compiled = []
        for path in sorted((staging / "sqlite_utils").rglob("*.py")):
            target = run / "bytecode" / path.relative_to(staging).with_suffix(".pyc")
            target.parent.mkdir(parents=True, exist_ok=True)
            py_compile.compile(str(path), cfile=str(target), doraise=True)
            compiled.append(str(path.relative_to(staging)))
        archive = run / "sqlite-utils.pyz"
        zipapp.create_archive(staging, target=archive, main="sqlite_utils.cli:cli")
        report["source_rebuild"] = {
            "compiled_modules": compiled,
            "archive": str(archive.relative_to(ROOT)),
            "format": "standard-library zipapp of sqlite_utils source; not a wheel",
        }

        with Database(run / "first-failure.db") as db:
            db.add_import_invariant("inventory", "quantity >= 0")
            before = state(db)
            result = db.safe_bulk_insert("inventory", [{"quantity": -1}])
            after = state(db)
            report["first_failure_metadata_rollback"] = {
                "result": result, "before": before, "after": after,
            }
            assert result["success"] is False
            assert before == after

        with Database(run / "api.db") as db:
            db.enable_safe_import()
            db.executescript("""
                CREATE TABLE inventory (id INTEGER PRIMARY KEY, quantity INTEGER);
                CREATE UNIQUE INDEX inventory_quantity ON inventory(quantity);
                CREATE TABLE audit (quantity INTEGER);
                CREATE TRIGGER inventory_log AFTER INSERT ON inventory
                BEGIN INSERT INTO audit VALUES(new.quantity); END;
                INSERT INTO inventory VALUES (1, 10);
            """)
            identity = db.add_import_invariant("inventory", "quantity >= 0")
            before = state(db)
            def records():
                db.executescript("""
                    ALTER TABLE inventory ADD COLUMN note TEXT;
                    DROP INDEX inventory_quantity;
                    DROP TRIGGER inventory_log;
                    CREATE TABLE transient (value TEXT);
                    CREATE INDEX transient_value ON transient(value);
                    CREATE TRIGGER inventory_changed AFTER UPDATE ON inventory
                    BEGIN INSERT INTO audit VALUES(new.quantity); END;
                """)
                yield {"id": 2, "quantity": 5, "note": "batch one"}
                yield {"id": 3, "quantity": -1, "note": "batch two"}
            result = db.safe_bulk_insert("inventory", records(), batch_size=1)
            after = state(db)
            report["schema_rollback"] = {
                "result": result, "invariant_id": identity,
                "before": before, "after": after,
                "schema_differences": [] if before["schema"] == after["schema"] else ["schema changed"],
                "data_differences": [] if before["data"] == after["data"] else ["data changed"],
            }
            assert result["success"] is False
            assert result["failures"][0]["id"] == identity
            assert after == before
            assert db.safe_bulk_upsert("inventory", [{"id": 1, "quantity": 12}], pk="id") == {"success": True}
            report["api_committed_rows"] = list(db["inventory"].rows)

        for mode, prefix in (
            ("source", [sys.executable, "-B", "-m", "sqlite_utils"]),
            ("rebuilt_zipapp", [sys.executable, "-B", str(archive)]),
        ):
            path = run / (mode + ".db")
            def command(arguments, input=None, code=0):
                completed = subprocess.run(
                    prefix + [str(arg) for arg in arguments],
                    cwd=ROOT, input=input, text=True, encoding="utf-8",
                    capture_output=True, env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"),
                )
                report["commands"].append({
                    "mode": mode, "arguments": [str(a) for a in arguments],
                    "stdin": input, "exit_code": completed.returncode,
                    "stdout": completed.stdout, "stderr": completed.stderr,
                })
                assert completed.returncode == code, completed.stderr
                return completed.stdout

            command(["enable-safe-import", path])
            invariant = command(["add-import-invariant", path, "inventory", "quantity >= 0"]).strip()
            listed = command(["list-import-invariants", path, "inventory"])
            assert json.loads(listed) == [{"id": invariant, "expression": "quantity >= 0"}]
            command(["insert", path, "inventory", "-", "--pk", "id", "--safe-mode"],
                    '[{"id": 1, "quantity": 10}]')
            command(["upsert", path, "inventory", "-", "--pk", "id", "--safe-mode"],
                    '[{"id": 1, "quantity": 12}]')
            with Database(path) as db:
                before = state(db)
            command(["bulk", path, "UPDATE inventory SET quantity = :quantity WHERE id = :id",
                     "-", "--batch-size", "1", "--safe-mode"],
                    '[{"id": 1, "quantity": 20}, {"id": 1, "quantity": -5}]', code=1)
            with Database(path) as db:
                after = state(db)
                report[mode + "_bulk_rollback"] = {"before": before, "after": after}
                assert before == after
            assert "Validation passed" in command(["validate-import-invariants", path, "inventory"])
            command(["bulk", path, "UPDATE inventory SET quantity = :quantity WHERE id = :id", "-", "--safe-mode"],
                    '[{"id": 1, "quantity": 15}]')
            # An ordinary write can violate a stored invariant: the validation
            # command communicates failure while still returning exit code 0.
            command(["bulk", path, "UPDATE inventory SET quantity = :quantity WHERE id = :id", "-"],
                    '[{"id": 1, "quantity": -2}]')
            validation = command(["validate-import-invariants", path, "inventory"])
            assert "Validation failed" in validation and invariant in validation
            command(["remove-import-invariant", path, "inventory", invariant])
            assert json.loads(command(["list-import-invariants", path, "inventory"])) == []
            command(["disable-safe-import", path])
            with Database(path) as db:
                report[mode + "_final_rows"] = list(db["inventory"].rows)
                assert list(db["inventory"].rows) == [{"id": 1, "quantity": -2}]
        report["completed"] = True
    except BaseException:
        report["failure"] = traceback.format_exc()
        raise
    finally:
        target = Path(__file__).with_name("evidence.json")
        target.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print("Saved actual source rebuild and SQLite/CLI evidence to", target.relative_to(ROOT))


if __name__ == "__main__":
    verify()
