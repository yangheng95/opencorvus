"""Safe imports exercised against SQLite, including native CLI subprocesses."""

import io
import json
import os
import subprocess
import sys

import pytest

from sqlite_utils import (
    Database,
    CheckpointNotActiveError,
    CheckpointNotFoundError,
    ImportInvariantError,
    SafeImportNotEnabledError,
)
from sqlite_utils.utils import sqlite3


def snapshot(db):
    return {
        "schema": list(db.query("SELECT type, name, tbl_name, sql FROM sqlite_master ORDER BY type, name")),
        "rows": {name: list(db[name].rows) for name in db.table_names()},
    }


def test_checkpoint_lifecycle_and_persistence(tmp_path):
    path = tmp_path / "lifecycle.db"
    db = Database(path)
    with pytest.raises(SafeImportNotEnabledError):
        db.create_import_checkpoint()
    db.enable_safe_import()
    db.close()
    db = Database(path)
    outer = db.create_import_checkpoint()
    assert isinstance(outer, str) and len(outer) > 0
    db["items"].insert({"id": 1}, pk="id")
    inner = db.create_import_checkpoint()
    db["items"].insert({"id": 2})
    db.rollback_to_checkpoint(inner)
    assert list(db["items"].rows) == [{"id": 1}]
    for action in (db.commit_checkpoint, db.rollback_to_checkpoint):
        with pytest.raises(CheckpointNotActiveError):
            action(inner)
    db.cleanup_checkpoint(inner)
    with pytest.raises(CheckpointNotFoundError):
        db.commit_checkpoint(inner)
    db.commit_checkpoint(outer)
    with pytest.raises(CheckpointNotActiveError):
        db.rollback_to_checkpoint(outer)
    db.close()
    db = Database(path)
    assert list(db["items"].rows) == [{"id": 1}]
    db.disable_safe_import()
    db.close()
    db = Database(path)
    with pytest.raises(SafeImportNotEnabledError):
        db.create_import_checkpoint()
    with pytest.raises(CheckpointNotFoundError):
        db.cleanup_checkpoint("unknown")


@pytest.mark.parametrize("finalize", ["commit_checkpoint", "rollback_to_checkpoint", "cleanup_checkpoint", "disable_safe_import"])
def test_ancestor_finalizes_children(finalize):
    db = Database(memory=True)
    db.enable_safe_import()
    db["t"].insert({"n": 0})
    outer = db.create_import_checkpoint()
    db["t"].insert({"n": 1})
    inner = db.create_import_checkpoint()
    db["t"].insert({"n": 2})
    if finalize == "disable_safe_import":
        db.disable_safe_import()
    else:
        getattr(db, finalize)(outer)
    assert list(db["t"].rows) == ([{"n": 0}, {"n": 1}, {"n": 2}] if finalize == "commit_checkpoint" else [{"n": 0}])
    with pytest.raises(CheckpointNotActiveError):
        db.commit_checkpoint(inner)


def test_invariants_persist_and_use_sqlite_expression_semantics(tmp_path):
    path = tmp_path / "invariants.db"
    db = Database(path)
    db["odd table"].insert_all([{"value": 2}, {"value": 4}])
    expressions = [
        "value > 0",
        "COUNT(*) = 2 AND SUM(value) = 6 AND AVG(value) = 3 AND MIN(value) = 2 AND MAX(value) = 4",
        "  select sum(value) = 6 from [odd table]",
        "length('SUM(value)') > 0",  # Scalar text containing an aggregate name.
    ]
    ids = [db.add_import_invariant("odd table", sql) for sql in expressions]
    db.close()
    db = Database(path)
    assert db.list_import_invariants("odd table") == [dict(id=id_, expression=sql) for id_, sql in zip(ids, expressions)]
    assert db.validate_import_invariants("odd table") == {"valid": True, "failures": []}
    for id_ in ids:
        db.remove_import_invariant("odd table", str(id_))
    assert db.list_import_invariants("odd table") == []


def test_invariant_failure_details_and_empty_table():
    db = Database(memory=True)
    db["t"].insert_all([{"n": 2}, {"n": -1}])
    row_id = db.add_import_invariant("t", "n > 0")
    select_id = db.add_import_invariant("t", "SELECT 0 UNION ALL SELECT 1")
    error_id = db.add_import_invariant("t", "missing_column > 0")
    result = db.validate_import_invariants("t")
    assert result["valid"] is False
    assert [f["id"] for f in result["failures"]] == [row_id, select_id, error_id]
    assert result["failures"][0] == {"id": row_id, "expression": "n > 0", "error": "Invariant evaluated to false"}
    assert result["failures"][2]["error"] == "no such column: missing_column"
    db["empty"].create({"n": int})
    db.add_import_invariant("empty", "n > 0")
    assert db.validate_import_invariants("empty") == {"valid": True, "failures": []}
    count_id = db.add_import_invariant("empty", "COUNT(*) > 0")
    assert db.validate_import_invariants("empty")["failures"] == [{"id": count_id, "expression": "COUNT(*) > 0", "error": "Invariant evaluated to false"}]


def test_user_defined_aggregate_uses_sqlite_semantics():
    class Sum:
        def __init__(self):
            self.value = 0

        def step(self, value):
            self.value += value

        def finalize(self):
            return self.value

    db = Database(memory=True)
    db.conn.create_aggregate("custom_sum", 1, Sum)
    db["t"].insert_all([{"n": 2}, {"n": 3}])
    db.add_import_invariant("t", "custom_sum(n) = 5")
    db.add_import_invariant("t", "TOTAL(n) = 5 AND GROUP_CONCAT(n) = '2,3'")
    assert db.validate_import_invariants("t") == {"valid": True, "failures": []}


def test_ordinary_csv_and_json_imports():
    db = Database(memory=True)
    assert db.import_csv("t", io.StringIO("n\n2\n3\n")) == {"success": True}
    assert db.import_json("t", {"n": "4"}) == {"success": True}
    assert list(db["t"].rows) == [{"n": "2"}, {"n": "3"}, {"n": "4"}]


def test_first_safe_failure_restores_complete_database_and_disabled_setting():
    db = Database(memory=True)
    invariant = db.add_import_invariant("t", "n > 0")
    before = snapshot(db)
    result = db.safe_bulk_insert("t", [{"n": -1}])
    assert result["failures"][0]["id"] == invariant
    assert snapshot(db) == before
    with pytest.raises(SafeImportNotEnabledError):
        db.create_import_checkpoint()
    assert db.safe_bulk_insert("t", [{"n": 2}]) == {"success": True}
    checkpoint = db.create_import_checkpoint()
    db.commit_checkpoint(checkpoint)


def test_safe_operation_preserves_caller_transaction():
    db = Database(memory=True)
    db["t"].create({"n": int})
    db.execute('INSERT INTO t VALUES (1)')
    assert db.safe_bulk_insert("t", [{"n": 2}]) == {"success": True}
    assert db.conn.in_transaction is True
    assert list(db["t"].rows) == [{"n": 1}, {"n": 2}]
    db.conn.rollback()
    assert list(db["t"].rows) == []


def test_deferred_constraint_failure_at_commit_restores_state():
    db = Database(memory=True)
    db.execute("PRAGMA foreign_keys = ON")
    db.executescript("""
        CREATE TABLE parent (id INTEGER PRIMARY KEY);
        CREATE TABLE child (parent_id INTEGER REFERENCES parent(id)
            DEFERRABLE INITIALLY DEFERRED);
    """)
    before = snapshot(db)
    result = db.safe_bulk_insert("child", [{"parent_id": 7}])
    assert result["success"] is False
    assert result["error_report"] == "FOREIGN KEY constraint failed"
    assert snapshot(db) == before


@pytest.mark.parametrize("strict", [False, True])
def test_full_schema_and_data_rollback(strict):
    db = Database(memory=True)
    db.enable_safe_import()
    db.executescript("""
        CREATE TABLE t (id INTEGER PRIMARY KEY, n INTEGER, payload BLOB);
        CREATE UNIQUE INDEX t_n ON t(n);
        CREATE TABLE audit (n INTEGER);
        CREATE TRIGGER t_log AFTER INSERT ON t BEGIN INSERT INTO audit VALUES(new.n); END;
        INSERT INTO t VALUES(1, 2, x'001122');
    """)
    invariant = db.add_import_invariant("t", "n > 0")
    before = snapshot(db)

    def records():
        db.executescript("""
            ALTER TABLE t ADD COLUMN extra TEXT;
            CREATE TABLE transient (text TEXT);
            CREATE INDEX transient_index ON transient(text);
            DROP INDEX t_n;
            DROP TRIGGER t_log;
            CREATE TRIGGER altered AFTER UPDATE ON t BEGIN INSERT INTO audit VALUES (new.n); END;
        """)
        yield {"id": 2, "n": 5, "extra": "first batch"}
        yield {"id": 3, "n": -1, "extra": "second batch"}

    if strict:
        with pytest.raises(ImportInvariantError, match="validation") as ex:
            db.safe_bulk_insert("t", records(), batch_size=1, strict=True)
        assert ex.value.failures[0]["id"] == invariant
    else:
        result = db.safe_bulk_insert("t", records(), batch_size=1)
        assert result["success"] is False
        assert isinstance(result["checkpoint_id"], str) and len(result["checkpoint_id"]) > 0
        assert result["failures"][0]["id"] == invariant
        with pytest.raises(CheckpointNotActiveError):
            db.rollback_to_checkpoint(result["checkpoint_id"])
        db.cleanup_checkpoint(result["checkpoint_id"])
    assert snapshot(db) == before


@pytest.mark.parametrize("strict", [False, True])
def test_sql_error_rollback_after_batches_and_added_column(strict):
    db = Database(memory=True)
    db.enable_safe_import()
    db["t"].insert({"id": 1, "n": 2}, pk="id")
    before = snapshot(db)
    rows = [{"id": 2, "n": 3, "extra": "column"}, {"id": 1, "n": 4}]
    if strict:
        with pytest.raises(sqlite3.IntegrityError, match="UNIQUE constraint failed"):
            db.safe_bulk_insert("t", rows, alter=True, batch_size=1, strict=True)
    else:
        result = db.safe_bulk_insert("t", rows, alter=True, batch_size=1)
        assert result["success"] is False
        assert result["failures"] == []
        assert "UNIQUE constraint failed" in result["error_report"]
    assert snapshot(db) == before


def test_trigger_invariants_upsert_and_nested_safe_operation():
    db = Database(memory=True)
    db.enable_safe_import()
    db.executescript("""
        CREATE TABLE t (id INTEGER PRIMARY KEY, n INTEGER);
        CREATE TABLE audit (n INTEGER);
        CREATE TRIGGER t_log AFTER INSERT ON t BEGIN INSERT INTO audit VALUES(new.n); END;
    """)
    invariant = db.add_import_invariant("audit", "n > 0")
    before = snapshot(db)
    result = db.safe_bulk_insert("t", [{"id": 1, "n": -2}])
    assert result["failures"][0]["id"] == invariant
    assert snapshot(db) == before
    assert db.safe_bulk_insert("t", [{"id": 1, "n": 2}], pk="id") == {"success": True}
    outer = db.create_import_checkpoint()
    assert db.safe_bulk_upsert("t", [{"id": 1, "n": 3}, {"id": 2, "n": 4}], pk="id", batch_size=1) == {"success": True}
    assert list(db["t"].rows) == [{"id": 1, "n": 3}, {"id": 2, "n": 4}]
    db.rollback_to_checkpoint(outer)
    assert list(db["t"].rows) == [{"id": 1, "n": 2}]
    assert list(db["audit"].rows) == [{"n": 2}]


@pytest.mark.parametrize("kind", ["csv_path", "csv_stream", "json_text", "json_records", "json_stream"])
def test_import_sources_success_and_validation_rollback(tmp_path, kind):
    db = Database(tmp_path / "sources.db")
    invariant = db.add_import_invariant("t", "CAST(n AS INTEGER) > 0")
    def source(n):
        if kind == "csv_path":
            path = tmp_path / "data.csv"
            path.write_text("n\n{}\n".format(n), encoding="utf-8")
            return str(path)
        if kind == "csv_stream":
            return io.StringIO("n\n{}\n".format(n))
        records = [{"n": n}]
        return records if kind == "json_records" else io.StringIO(json.dumps(records)) if kind == "json_stream" else json.dumps(records)
    method = db.import_csv if kind.startswith("csv") else db.import_json
    assert method("t", source(2), safe_mode=True) == {"success": True}
    before = snapshot(db)
    result = method("t", source(-1), safe_mode=True)
    assert result["success"] is False
    assert result["failures"][0]["id"] == invariant
    assert snapshot(db) == before
    with pytest.raises(ImportInvariantError, match="invariant"):
        method("t", source(-1), safe_mode=True, strict=True)
    assert snapshot(db) == before


def test_parser_and_stream_failures_restore_new_table():
    db = Database(memory=True)
    db.enable_safe_import()
    before = snapshot(db)
    broken_csv = io.StringIO("n\n" + "2\n" * 101 + '"unterminated\n')
    result = db.import_csv("new_table", broken_csv, safe_mode=True)
    assert result["success"] is False
    assert result["error_report"] == "unexpected end of data"
    assert snapshot(db) == before
    result = db.import_json("new_table", "[{", safe_mode=True)
    assert result["success"] is False
    assert "Expecting property name" in result["error_report"]
    assert snapshot(db) == before
    def broken_records():
        yield {"n": 2}
        raise ValueError("source read failed")
    result = db.safe_bulk_insert("new_table", broken_records(), batch_size=1)
    assert result["error_report"] == "source read failed"
    assert snapshot(db) == before


def test_trigger_rollback_reports_original_error_and_restores_state():
    db = Database(memory=True)
    db.enable_safe_import()
    db.executescript("""
        CREATE TABLE t (n INTEGER);
        INSERT INTO t VALUES (1);
        CREATE TRIGGER reject_negative BEFORE INSERT ON t WHEN new.n < 0
        BEGIN SELECT RAISE(ROLLBACK, 'negative value'); END;
    """)
    before = snapshot(db)
    result = db.safe_bulk_insert("t", [{"n": 2}, {"n": -1}], batch_size=1)
    assert result["success"] is False
    assert result["error_report"] == "negative value"
    assert result["failures"] == []
    assert snapshot(db) == before
    assert db.safe_bulk_insert("t", [{"n": 3}]) == {"success": True}
    assert list(db["t"].rows) == [{"n": 1}, {"n": 3}]


def native_cli(*arguments, input=None):
    result = subprocess.run(
        [sys.executable, "-B", "-m", "sqlite_utils", *map(str, arguments)],
        input=input, text=True, encoding="utf-8", capture_output=True,
        env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"),
    )
    return result


def test_native_cli_management_and_insert_upsert_bulk_update(tmp_path):
    path = tmp_path / "cli.db"
    assert native_cli("enable-safe-import", path).returncode == 0
    added = native_cli("add-import-invariant", path, "t", "n > 0")
    assert added.returncode == 0, added.stderr
    invariant = added.stdout.strip()
    listed = native_cli("list-import-invariants", path, "t")
    assert json.loads(listed.stdout) == [{"id": invariant, "expression": "n > 0"}]
    inserted = native_cli("insert", path, "t", "-", "--pk", "id", "--safe-mode", input='[{"id": 1, "n": 2}]')
    assert inserted.returncode == 0, inserted.stderr
    passed = native_cli("validate-import-invariants", path, "t")
    assert passed.returncode == 0
    assert "Validation passed" in passed.stdout
    upserted = native_cli("upsert", path, "t", "-", "--pk", "id", "--safe-mode", input='[{"id": 1, "n": 3}]')
    assert upserted.returncode == 0, upserted.stderr
    for command, arguments, data in [
        ("insert", ["t", "-", "--alter", "--pk", "id"], '[{"id": 2, "n": 4, "extra": 1}, {"id": 3, "n": -1, "extra": 2}]'),
        ("upsert", ["t", "-", "--pk", "id"], '[{"id": 1, "n": 4}, {"id": 2, "n": -1}]'),
        ("bulk", ["UPDATE t SET n = :n WHERE id = :id", "-"], '[{"id": 1, "n": 4}, {"id": 1, "n": -1}]'),
    ]:
        with Database(path) as db:
            before = snapshot(db)
        result = native_cli(command, path, *arguments, "--safe-mode", "--batch-size", "1", input=data)
        assert result.returncode == 1, result.stderr
        assert invariant in result.stderr
        with Database(path) as db:
            assert snapshot(db) == before
    updated = native_cli("bulk", path, "UPDATE t SET n = :n WHERE id = :id", "-", "--safe-mode", input='[{"id": 1, "n": 7}]')
    assert updated.returncode == 0, updated.stderr
    with Database(path) as db:
        assert list(db["t"].rows) == [{"id": 1, "n": 7}]
        db["t"].update(1, {"n": -1})
    failed = native_cli("validate-import-invariants", path, "t")
    assert failed.returncode == 0
    assert "Validation failed" in failed.stdout and invariant in failed.stdout
    assert native_cli("remove-import-invariant", path, "t", invariant).returncode == 0
    assert json.loads(native_cli("list-import-invariants", path, "t").stdout) == []
    assert native_cli("disable-safe-import", path).returncode == 0
    with Database(path) as db:
        with pytest.raises(SafeImportNotEnabledError):
            db.create_import_checkpoint()


def test_native_cli_csv_transform_and_late_json_error(tmp_path):
    path = tmp_path / "csv.db"
    result = native_cli("insert", path, "t", "-", "--csv", "--safe-mode", input="id,n\n1,2\n2,3\n")
    assert result.returncode == 0, result.stderr
    with Database(path) as db:
        assert list(db["t"].rows) == [{"id": 1, "n": 2}, {"id": 2, "n": 3}]
        db.add_import_invariant("t", "n > 0")
        before = snapshot(db)
    result = native_cli("insert", path, "t", "-", "--csv", "--safe-mode", "--alter", input="id,n,extra\n3,-1,new\n")
    assert result.returncode == 1
    with Database(path) as db:
        assert snapshot(db) == before
    result = native_cli("insert", path, "t", "-", "--nl", "--safe-mode", "--batch-size", "1", input='{"id": 3, "n": 4}\n{\n')
    assert result.returncode == 1
    with Database(path) as db:
        assert snapshot(db) == before
    result = native_cli("insert", path, "t", "-", "--csv", "--safe-mode", "--batch-size", "1", input='id,n\n3,4\n4,"unterminated\n')
    assert result.returncode == 1
    assert "unexpected end of data" in result.stderr
    with Database(path) as db:
        assert snapshot(db) == before
