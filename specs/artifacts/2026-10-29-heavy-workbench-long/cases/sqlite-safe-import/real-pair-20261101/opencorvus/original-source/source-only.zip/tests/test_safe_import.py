import io
import json
import os
import subprocess
import sys

import pytest

from sqlite_utils import (
    Database,
    SafeImportNotEnabledError,
    CheckpointNotActiveError,
    CheckpointNotFoundError,
    ImportInvariantError,
)


def state(db):
    """Independent state oracle: complete schema SQL and all user table rows."""
    schema = list(
        db.execute(
            "SELECT type, name, tbl_name, sql FROM sqlite_master ORDER BY type, name"
        )
    )
    rows = {}
    for name in db.table_names():
        quoted = '"' + name.replace('"', '""') + '"'
        rows[name] = list(db.execute("SELECT * FROM " + quoted))
    return schema, rows


def test_checkpoint_lifecycle_and_nested(tmp_path):
    db = Database(tmp_path / "checkpoints.db")
    with pytest.raises(SafeImportNotEnabledError):
        db.create_import_checkpoint()
    db.enable_safe_import()
    outer = db.create_import_checkpoint()
    assert isinstance(outer, str) and outer
    db["items"].insert({"id": 1})
    inner = db.create_import_checkpoint()
    db["items"].insert({"id": 2})
    db.rollback_to_checkpoint(inner)
    assert list(db["items"].rows) == [{"id": 1}]
    with pytest.raises(CheckpointNotActiveError):
        db.commit_checkpoint(inner)
    db.cleanup_checkpoint(inner)
    with pytest.raises(CheckpointNotFoundError):
        db.rollback_to_checkpoint(inner)
    child = db.create_import_checkpoint()
    db["items"].insert({"id": 3})
    db.commit_checkpoint(child)
    db.rollback_to_checkpoint(outer)
    assert not db["items"].exists()
    for checkpoint in (outer, child):
        with pytest.raises(CheckpointNotActiveError):
            db.rollback_to_checkpoint(checkpoint)
    cp = db.create_import_checkpoint()
    db["committed"].insert({"x": 1})
    db.commit_checkpoint(cp)
    with Database(tmp_path / "checkpoints.db") as reopened:
        assert list(reopened["committed"].rows) == [{"x": 1}]
    db.disable_safe_import()
    with pytest.raises(SafeImportNotEnabledError):
        db.create_import_checkpoint()


def test_cleanup_active_and_outer_finalizes_children():
    db = Database(memory=True)
    db.enable_safe_import()
    outer = db.create_import_checkpoint()
    inner = db.create_import_checkpoint()
    db["new"].insert({"x": 1})
    db.cleanup_checkpoint(outer)
    assert not db["new"].exists()
    with pytest.raises(CheckpointNotFoundError):
        db.commit_checkpoint(outer)
    with pytest.raises(CheckpointNotActiveError):
        db.commit_checkpoint(inner)
    with pytest.raises(CheckpointNotFoundError):
        db.cleanup_checkpoint("unknown")


@pytest.mark.parametrize(
    "expression,valid",
    [
        ("value >= 0", False),
        ("value >= -1", True),
        ("COUNT(*) = 3", True),
        ("SUM(value) = 4", True),
        ("AVG(value) > 0", True),
        ("MIN(value) = -1", True),
        ("MAX(value, 0) >= 0", True),
        ("'COUNT(value)' != '' AND value >= 0", False),
        ("SELECT COUNT(*) = 3 FROM items", True),
        ("select value FROM items ORDER BY value LIMIT 1", True),
        ("SELECT 0 WHERE 0", False),
        ("NULL", False),
        ("missing_column > 0", False),
        ("COUNT(*) < 3", False),
    ],
)
def test_invariant_semantics(expression, valid):
    db = Database(memory=True)
    db["items"].insert_all([{"value": -1}, {"value": 2}, {"value": 3}])
    invariant = db.add_import_invariant("items", expression)
    result = db.validate_import_invariants("items")
    assert result["valid"] is valid
    assert (
        result["failures"] == [] if valid else result["failures"][0]["id"] == invariant
    )


def test_invariant_persistence_quoting_and_empty(tmp_path):
    path = tmp_path / "persistent.db"
    table = 'odd " table'
    db = Database(path)
    db.enable_safe_import()
    db.execute('CREATE TABLE "odd "" table" (n INTEGER)')
    row_id = db.add_import_invariant(table, "n > 0")
    assert db.validate_import_invariants(table)["valid"]  # vacuous all rows
    aggregate = db.add_import_invariant(table, "COUNT(*) > 0")
    assert db.validate_import_invariants(table)["failures"][0]["id"] == aggregate
    db.close()
    db = Database(path)
    assert db.list_import_invariants(table) == [
        {"id": row_id, "expression": "n > 0"},
        {"id": aggregate, "expression": "COUNT(*) > 0"},
    ]
    db.remove_import_invariant("wrong table", aggregate)
    assert len(db.list_import_invariants(table)) == 2
    db.remove_import_invariant(table, aggregate)
    assert db.safe_bulk_insert(table, [{"n": 2}]) == {"success": True}
    db.disable_safe_import()
    assert len(db.list_import_invariants(table)) == 1


@pytest.mark.parametrize("strict", [False, True])
@pytest.mark.parametrize("operation", ["insert", "upsert", "json", "csv"])
def test_safe_operations_rollback_and_success(tmp_path, operation, strict):
    db = Database(tmp_path / "atomic.db")
    db.enable_safe_import()
    db["items"].insert({"id": 1, "n": 5}, pk="id")
    invariant = db.add_import_invariant("items", "CAST(n AS INTEGER) >= 0")
    before = state(db)

    def run(n):
        records = [{"id": 1 if operation == "upsert" else 2, "n": n, "added": "new"}]
        kwargs = dict(strict=strict, alter=True, batch_size=1)
        if operation == "insert":
            return db.safe_bulk_insert("items", records, **kwargs)
        if operation == "upsert":
            return db.safe_bulk_upsert("items", records, pk="id", **kwargs)
        if operation == "json":
            return db.import_json(
                "items", json.dumps(records), safe_mode=True, **kwargs
            )
        return db.import_csv(
            "items",
            io.StringIO("id,n,added\n2,{},new\n".format(n)),
            safe_mode=True,
            **kwargs,
        )

    if strict:
        with pytest.raises(ImportInvariantError, match="validation"):
            run(-1)
    else:
        result = run(-1)
        assert result["success"] is False
        assert isinstance(result["checkpoint_id"], str) and result["checkpoint_id"]
        assert result["failures"][0]["id"] == invariant
        assert "validation" in result["error_report"]
    assert state(db) == before
    assert run(8) == {"success": True}
    assert "added" in db["items"].columns_dict


def test_multibatch_sql_error_and_generator_error():
    db = Database(memory=True)
    db.enable_safe_import()
    db["items"].insert({"id": 1}, pk="id")
    before = state(db)
    result = db.safe_bulk_insert(
        "items", [{"id": 2, "extra": 3}, {"id": 1}], batch_size=1, alter=True
    )
    assert not result["success"] and not result["failures"]
    assert "UNIQUE" in result["error_report"]
    assert state(db) == before

    def records():
        yield {"id": 3, "extra": 4}
        raise ValueError("broken stream")

    with pytest.raises(ValueError, match="broken stream"):
        db.safe_bulk_insert("items", records(), batch_size=1, alter=True, strict=True)
    assert state(db) == before


def test_checkpoint_restores_full_schema_and_trigger_effects():
    db = Database(memory=True)
    db.enable_safe_import()
    db.executescript("""
        CREATE TABLE items (id INTEGER PRIMARY KEY, n INTEGER);
        INSERT INTO items VALUES (1, 5);
        CREATE TABLE audit (n INTEGER);
        CREATE INDEX old_index ON items(n);
        CREATE TRIGGER old_trigger AFTER UPDATE ON items BEGIN
          INSERT INTO audit VALUES (new.n);
        END;
    """)
    before = state(db)
    cp = db.create_import_checkpoint()
    db.executescript("""
        UPDATE items SET n = 7;
        DROP TRIGGER old_trigger;
        DROP INDEX old_index;
        ALTER TABLE items ADD COLUMN extra TEXT;
        CREATE TABLE new_table (x);
        CREATE INDEX new_index ON items(extra);
        CREATE TRIGGER new_trigger AFTER INSERT ON items BEGIN
          INSERT INTO audit VALUES (99); INSERT INTO new_table VALUES ('semi;colon');
        END;
    """)
    db.rollback_to_checkpoint(cp)
    assert state(db) == before


def test_nested_safe_operation_does_not_commit_outer():
    db = Database(memory=True)
    db.enable_safe_import()
    cp = db.create_import_checkpoint()
    assert db.safe_bulk_insert("items", [{"x": 1}])["success"]
    db.rollback_to_checkpoint(cp)
    assert not db["items"].exists()


def test_commit_time_foreign_key_failure_rolls_back():
    db = Database(memory=True)
    db.enable_safe_import()
    db.execute("PRAGMA foreign_keys=ON")
    db.executescript("""
        CREATE TABLE parent (id INTEGER PRIMARY KEY);
        CREATE TABLE child (id INTEGER PRIMARY KEY, parent_id INTEGER,
            FOREIGN KEY(parent_id) REFERENCES parent(id) DEFERRABLE INITIALLY DEFERRED);
    """)
    before = state(db)
    result = db.safe_bulk_insert("child", [{"id": 1, "parent_id": 99}])
    assert not result["success"] and not result["failures"]
    assert "FOREIGN KEY" in result["error_report"]
    assert state(db) == before
    db["parent"].insert({"id": 99})
    assert db.safe_bulk_insert("child", [{"id": 1, "parent_id": 99}])["success"]


def test_trigger_side_effect_invariants_and_new_table_failure():
    db = Database(memory=True)
    db.enable_safe_import()
    db.executescript("""
        CREATE TABLE items (id INTEGER PRIMARY KEY, n INTEGER);
        CREATE TABLE audit (n INTEGER);
        CREATE TRIGGER audit_insert AFTER INSERT ON items BEGIN
          INSERT INTO audit VALUES (new.n);
        END;
        CREATE INDEX items_n ON items(n);
    """)
    invariant = db.add_import_invariant("audit", "n >= 0")
    before = state(db)
    failed = db.safe_bulk_insert(
        "items", [{"id": 1, "n": 4}, {"id": 2, "n": -1}], batch_size=1
    )
    assert not failed["success"] and failed["failures"][0]["id"] == invariant
    assert state(db) == before
    db.remove_import_invariant("audit", invariant)
    before = state(db)
    failed = db.safe_bulk_insert(
        "brand new", [{"id": 1}, {"id": 1}], pk="id", batch_size=1
    )
    assert not failed["success"]
    assert state(db) == before


def test_preexisting_transaction_remains_owned_by_caller():
    db = Database(memory=True)
    db.enable_safe_import()
    db["items"].insert({"id": 1, "n": 2}, pk="id")
    db.add_import_invariant("items", "n >= 0")
    db.execute("UPDATE items SET n = 3")
    before = state(db)
    assert not db.safe_bulk_upsert("items", [{"id": 1, "n": -1}], pk="id")["success"]
    assert state(db) == before
    assert db.conn.in_transaction
    assert db.safe_bulk_insert("items", [{"id": 2, "n": 4}])["success"]
    assert db.conn.in_transaction
    db.conn.rollback()
    assert list(db["items"].rows) == [{"id": 1, "n": 2}]


def test_sqlite_trigger_rollback_reports_original_failure():
    db = Database(memory=True)
    db.enable_safe_import()
    db.executescript("""
        CREATE TABLE items (id INTEGER);
        CREATE TRIGGER reject BEFORE INSERT ON items WHEN new.id = 2 BEGIN
          SELECT RAISE(ROLLBACK, 'rejected by trigger');
        END;
    """)
    before = state(db)
    result = db.safe_bulk_insert("items", [{"id": 1}, {"id": 2}], batch_size=1)
    assert not result["success"] and "rejected by trigger" in result["error_report"]
    assert state(db) == before
    assert db.safe_bulk_insert("items", [{"id": 3}])["success"]


@pytest.mark.parametrize("old_upsert", [False, True])
def test_composite_key_and_empty_import(old_upsert):
    db = Database(memory=True, use_old_upsert=old_upsert)
    db.enable_safe_import()
    db["pairs"].insert_all([{"a": "A", "b": 1, "n": 2}], pk=("a", "b"))
    db.add_import_invariant("pairs", "SUM(n) <= 10")
    before = state(db)
    result = db.safe_bulk_upsert(
        "pairs",
        [{"a": "A", "b": 1, "n": 5}, {"a": "B", "b": 2, "n": 7}],
        pk=("a", "b"),
        batch_size=1,
    )
    assert not result["success"] and state(db) == before
    assert db.safe_bulk_upsert("pairs", [{"a": "A", "b": 1, "n": 5}], pk=("a", "b"))[
        "success"
    ]
    assert db.safe_bulk_insert("pairs", [])["success"]
    assert list(db["pairs"].rows) == [{"a": "A", "b": 1, "n": 5}]


def test_csv_path_json_object_ordinary_and_malformed(tmp_path):
    db = Database(memory=True)
    db.enable_safe_import()
    source = tmp_path / "input.csv"
    source.write_text('name,value\n"comma, name",7\n', encoding="utf-8")
    assert db.import_csv("csv", str(source), safe_mode=True)["success"]
    assert list(db["csv"].rows) == [{"name": "comma, name", "value": "7"}]
    assert db.import_json("json", {"id": 1}, safe_mode=True)["success"]
    before = state(db)
    assert not db.import_json("json", "[broken", safe_mode=True)["success"]
    assert state(db) == before
    assert db.import_json("ordinary", [{"x": 1}])["success"]
    assert list(db["ordinary"].rows) == [{"x": 1}]


def test_disabled_results_and_failure_checkpoint_cleanup():
    db = Database(memory=True)
    result = db.safe_bulk_insert("items", [{"id": 1}])
    assert not result["success"] and isinstance(result["checkpoint_id"], str)
    assert result["error_report"] and not db["items"].exists()
    with pytest.raises(SafeImportNotEnabledError):
        db.safe_bulk_insert("items", [{"id": 1}], strict=True)
    db.enable_safe_import()
    cp = db.create_import_checkpoint()
    db.disable_safe_import()
    with pytest.raises(SafeImportNotEnabledError):
        db.create_import_checkpoint()
    db.commit_checkpoint(cp)
    db.cleanup_checkpoint(cp)
    with pytest.raises(CheckpointNotFoundError):
        db.commit_checkpoint(cp)
    db.enable_safe_import()
    db.add_import_invariant("items", "id > 0")
    failed = db.safe_bulk_insert("items", [{"id": -1}])
    assert not failed["success"]
    with pytest.raises(CheckpointNotActiveError):
        db.commit_checkpoint(failed["checkpoint_id"])
    db.cleanup_checkpoint(failed["checkpoint_id"])
    assert db.safe_bulk_insert("items", [{"id": 1}])["success"]
    assert db._import_checkpoints == {}


def cli(*args, input=None):
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
    return subprocess.run(
        [sys.executable, "-B", "-m", "sqlite_utils", *map(str, args)],
        input=input,
        text=True,
        capture_output=True,
        env=env,
    )


def test_real_cli_commands_and_update(tmp_path):
    path = tmp_path / "cli.db"
    assert cli("enable-safe-import", path).returncode == 0
    added = cli("add-import-invariant", path, "items", "n >= 0")
    assert added.returncode == 0
    invariant = added.stdout.strip()
    assert (
        invariant and invariant in cli("list-import-invariants", path, "items").stdout
    )
    assert (
        cli(
            "insert",
            path,
            "items",
            "-",
            "--pk",
            "id",
            "--safe-mode",
            input='[{"id":1,"n":5}]',
        ).returncode
        == 0
    )
    assert (
        cli(
            "upsert",
            path,
            "items",
            "-",
            "--pk",
            "id",
            "--safe-mode",
            input='[{"id":1,"n":6}]',
        ).returncode
        == 0
    )
    rejected_upsert = cli(
        "upsert",
        path,
        "items",
        "-",
        "--pk",
        "id",
        "--safe-mode",
        "--alter",
        input='[{"id":1,"n":-9,"new_column":"must roll back"}]',
    )
    assert rejected_upsert.returncode != 0 and invariant in rejected_upsert.stderr
    with Database(path) as db:
        assert list(db["items"].rows) == [{"id": 1, "n": 6}]
        assert "new_column" not in db["items"].columns_dict
        before = state(db)
    bad = cli(
        "bulk",
        path,
        "UPDATE items SET n = :n WHERE id = :id",
        "-",
        "--safe-mode",
        "--batch-size",
        "1",
        input='[{"id":1,"n":8},{"id":1,"n":-2}]',
    )
    assert bad.returncode != 0 and invariant in bad.stderr
    with Database(path) as db:
        assert state(db) == before
    assert (
        cli(
            "bulk",
            path,
            "UPDATE items SET n = :n WHERE id = :id",
            "-",
            "--safe-mode",
            input='[{"id":1,"n":9}]',
        ).returncode
        == 0
    )
    assert "PASS" in cli("validate-import-invariants", path, "items").stdout
    # Ordinary writes are intentionally unaffected by safe-import configuration.
    assert (
        cli("bulk", path, "UPDATE items SET n = :n", "-", input='[{"n":-1}]').returncode
        == 0
    )
    invalid = cli("validate-import-invariants", path, "items")
    assert (
        invalid.returncode == 0
        and "FAIL" in invalid.stdout
        and invariant in invalid.stdout
    )
    assert cli("remove-import-invariant", path, "items", invariant).returncode == 0
    assert cli("list-import-invariants", path, "items").stdout == ""
    assert cli("disable-safe-import", path).returncode == 0
    assert (
        cli(
            "insert", path, "items", "-", "--safe-mode", input='[{"id":2,"n":7}]'
        ).returncode
        != 0
    )


def test_cli_csv_transform_and_late_parse_failure(tmp_path):
    path = tmp_path / "cli.db"
    cli("enable-safe-import", path)
    cli("add-import-invariant", path, "items", "n >= 0")
    good = cli(
        "insert", path, "items", "-", "--csv", "--safe-mode", input="id,n\n1,5\n"
    )
    assert good.returncode == 0, good.stderr
    with Database(path) as db:
        before = state(db)
    for flags, data in [
        (["--csv", "--alter"], "id,n,extra\n2,-1,new\n"),
        (["--nl", "--alter"], '{"id":2,"n":3,"extra":"new"}\n{"bad"\n'),
    ]:
        bad = cli(
            "insert",
            path,
            "items",
            "-",
            "--safe-mode",
            "--batch-size",
            "1",
            *flags,
            input=data,
        )
        assert bad.returncode != 0
        with Database(path) as db:
            assert state(db) == before


@pytest.mark.parametrize(
    "extension,content",
    [
        ("csv", "id,n\n1,5\n"),
        ("tsv", "id\tn\n1\t5\n"),
        ("jsonl", '{"id":1,"n":5}\n'),
        ("ndjson", '{"id":1,"n":5}\n'),
    ],
)
def test_cli_safe_file_format_inference(tmp_path, extension, content):
    path = tmp_path / "infer.db"
    source = tmp_path / ("records." + extension)
    source.write_text(content, encoding="utf-8")
    assert cli("enable-safe-import", path).returncode == 0
    result = cli("insert", path, "items", source, "--pk", "id", "--safe-mode")
    assert result.returncode == 0, result.stderr
    result = cli("upsert", path, "items", source, "--pk", "id", "--safe-mode")
    assert result.returncode == 0, result.stderr
    with Database(path) as db:
        assert list(db["items"].rows) == [{"id": 1, "n": 5}]
    update = tmp_path / "update.csv"
    update.write_text("id,n\n1,6\n", encoding="utf-8")
    result = cli(
        "bulk", path, "UPDATE items SET n = :n WHERE id = :id", update, "--safe-mode"
    )
    assert result.returncode == 0, result.stderr
    with Database(path) as db:
        assert list(db["items"].rows) == [{"id": 1, "n": 6}]


def test_cli_explicit_format_overrides_suffix(tmp_path):
    path = tmp_path / "override.db"
    source = tmp_path / "really-json.csv"
    source.write_text('{"id":1,"n":5}\n', encoding="utf-8")
    cli("enable-safe-import", path)
    result = cli("insert", path, "items", source, "--nl", "--safe-mode")
    assert result.returncode == 0, result.stderr
    with Database(path) as db:
        assert list(db["items"].rows) == [{"id": 1, "n": 5}]
