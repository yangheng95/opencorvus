"""Reproduce real database and CLI evidence, entirely within this project.

Run from the project root: python -B -m validation.run_safe_import
"""

import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys

from sqlite_utils import Database


ROOT = Path(__file__).resolve().parent.parent
OUTPUT = ROOT / "validation" / "evidence"


def snapshot(db):
    return {
        "schema": list(
            db.query(
                "SELECT type, name, tbl_name, sql FROM sqlite_master ORDER BY type, name"
            )
        ),
        "items": list(db["items"].rows),
        "audit": list(db["audit"].rows),
    }


def main():
    OUTPUT.mkdir(exist_ok=True)
    path = OUTPUT / "safe-import.db"
    # Delete only this harness's previous database, after previous connections closed.
    if path.exists():
        path.unlink()
    report = {
        "python": sys.version,
        "sqlite": sqlite3.sqlite_version,
        "working_directory": str(ROOT),
        "history": [
            "Initial focused suite: 31 passed.",
            "Expanded focused suite after correcting its stale baseline: 36 passed; subsequent additions cover disabled-mode results, checkpoint cleanup, rejected CLI upsert and format inference.",
            "Scoped upstream regression suite: 114 passed, 2 timing/sleep tests deselected.",
            "Expanded focused suite first run: 35 passed, 1 failed. The failing test compared against a stale baseline after intentionally removing an invariant. The baseline was corrected after that removal; product state was not altered to satisfy the assertion.",
        ],
        "commands": [],
    }
    with Database(path) as db:
        db.enable_safe_import()
        db.executescript("""
            CREATE TABLE items (id INTEGER PRIMARY KEY, quantity INTEGER);
            CREATE TABLE audit (item_id INTEGER, quantity INTEGER);
            CREATE INDEX quantity_index ON items(quantity);
            CREATE TRIGGER log_item AFTER INSERT ON items BEGIN
                INSERT INTO audit VALUES (new.id, new.quantity);
            END;
            INSERT INTO items VALUES (1, 5);
        """)
        invariant = db.add_import_invariant("items", "quantity >= 0")
        db.add_import_invariant("audit", "quantity >= 0")
        report["invariant_id"] = invariant
        report["before"] = snapshot(db)
        report["failed_api_insert"] = db.safe_bulk_insert(
            "items",
            [
                {"id": 2, "quantity": 8, "extra": "new"},
                {"id": 3, "quantity": -1, "extra": "invalid"},
            ],
            alter=True,
            batch_size=1,
        )
        report["after_failed_api_insert"] = snapshot(db)
        assert not report["failed_api_insert"]["success"]
        assert report["before"] == report["after_failed_api_insert"]
        # Explicit DDL rollback exercises objects that insert --alter cannot create.
        cp = db.create_import_checkpoint()
        db.executescript("""
            DROP INDEX quantity_index;
            DROP TRIGGER log_item;
            ALTER TABLE items ADD COLUMN transient TEXT;
            CREATE TABLE transient_table (x);
            CREATE INDEX transient_index ON items(transient);
            CREATE TRIGGER transient_trigger AFTER UPDATE ON items BEGIN
              INSERT INTO transient_table VALUES ('changed; value');
            END;
            UPDATE items SET quantity = 99;
        """)
        db.rollback_to_checkpoint(cp)
        report["after_schema_rollback"] = snapshot(db)
        assert report["after_schema_rollback"] == report["before"]

    def run_cli(arguments, data=None, expected=0):
        command = [sys.executable, "-B", "-m", "sqlite_utils", *map(str, arguments)]
        result = subprocess.run(
            command,
            cwd=ROOT,
            input=data,
            text=True,
            capture_output=True,
            env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"),
        )
        report["commands"].append(
            {
                "argv": command,
                "input": data,
                "exit_code": result.returncode,
                "stdout": result.stdout,
                "stderr": result.stderr,
            }
        )
        assert (result.returncode == 0) is (expected == 0), result.stderr
        return result

    run_cli(["list-import-invariants", path, "items"])
    run_cli(
        [
            "bulk",
            path,
            "UPDATE items SET quantity = :q WHERE id = :id",
            "-",
            "--safe-mode",
            "--batch-size",
            "1",
        ],
        '[{"id":1,"q":8},{"id":1,"q":-2}]',
        expected=1,
    )
    with Database(path) as db:
        report["after_failed_cli_update"] = snapshot(db)
        assert report["after_failed_cli_update"] == report["before"]
    run_cli(
        ["upsert", path, "items", "-", "--pk", "id", "--safe-mode"],
        '[{"id":1,"quantity":9}]',
    )
    run_cli(["validate-import-invariants", path, "items"])
    run_cli(["query", path, "SELECT * FROM items"])
    # Validation must communicate failure but retain exit zero.
    run_cli(["add-import-invariant", path, "items", "COUNT(*) = 999"])
    invalid = run_cli(["validate-import-invariants", path, "items"])
    assert "FAIL" in invalid.stdout
    with Database(path) as db:
        report["final_database"] = snapshot(db)
        assert report["final_database"]["items"] == [{"id": 1, "quantity": 9}]
        assert db.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
        report["integrity_check"] = "ok"

    # The native source entry point needs no build frontend. Compile every
    # package source to check syntax without writing outside the project.
    sources = sorted((ROOT / "sqlite_utils").glob("*.py"))
    for source in sources:
        compile(source.read_bytes(), str(source), "exec")
    report["compiled_sources"] = [str(source.relative_to(ROOT)) for source in sources]

    for name, args in [
        ("focused", ["tests/test_safe_import.py"]),
        (
            "regression",
            [
                "tests/test_cli_insert.py",
                "tests/test_cli_bulk.py",
                "tests/test_upsert.py",
                "tests/test_transform.py",
                "-k",
                "not test_cli_bulk_batch_size and not test_insert_streaming_batch_size_1",
            ],
        ),
    ]:
        command = [
            sys.executable,
            "-B",
            "-m",
            "pytest",
            *args,
            "-q",
            "--basetemp=.validation-" + name,
        ]
        result = subprocess.run(
            command,
            cwd=ROOT,
            text=True,
            capture_output=True,
            env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"),
        )
        (OUTPUT / (name + ".txt")).write_text(
            result.stdout + result.stderr, encoding="utf-8"
        )
        report[name] = {
            "argv": command,
            "exit_code": result.returncode,
            "stdout": result.stdout,
            "stderr": result.stderr,
        }
        # Save failures too, before enforcing success.
        (OUTPUT / "results.json").write_text(
            json.dumps(report, indent=2), encoding="utf-8"
        )
        assert result.returncode == 0, result.stdout + result.stderr
    print("Database, CLI transcripts and pytest evidence saved to validation/evidence")


if __name__ == "__main__":
    main()
