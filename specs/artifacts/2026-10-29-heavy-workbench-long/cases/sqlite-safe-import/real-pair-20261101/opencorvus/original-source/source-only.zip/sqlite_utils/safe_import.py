"""Transactional import checkpoints and persistent, SQL-backed invariants."""

import contextlib
import csv
import json
import re
import uuid


class SafeImportNotEnabledError(Exception):
    pass


class CheckpointNotFoundError(Exception):
    pass


class CheckpointNotActiveError(Exception):
    pass


class ImportInvariantError(Exception):
    def __init__(self, failures):
        self.failures = failures
        super().__init__("Import invariant validation failed: {}".format(failures))


def _quote(name):
    return '"{}"'.format(name.replace('"', '""'))


class SafeImportMixin:
    # Checkpoints are connection-local; configuration and invariants are durable.
    _safe_config = "_sqlite_utils_safe_import"
    _safe_invariants = "_sqlite_utils_import_invariants"

    def _init_safe_import(self):
        self._import_checkpoints = {}
        self._active_import_checkpoints = []

    @contextlib.contextmanager
    def _transaction(self):
        if self._active_import_checkpoints:
            yield self.conn
        else:
            with self.conn:
                yield self.conn

    def _safe_metadata(self):
        with self._transaction():
            self.execute(
                'CREATE TABLE IF NOT EXISTS "{}" '
                "(id INTEGER PRIMARY KEY CHECK (id = 1), enabled INTEGER NOT NULL)".format(
                    self._safe_config
                )
            )
            self.execute(
                'CREATE TABLE IF NOT EXISTS "{}" '
                "(id TEXT PRIMARY KEY, table_name TEXT NOT NULL, expression TEXT NOT NULL)".format(
                    self._safe_invariants
                )
            )

    def enable_safe_import(self):
        self._safe_metadata()
        with self._transaction():
            self.execute(
                'INSERT OR REPLACE INTO "{}" VALUES (1, 1)'.format(self._safe_config)
            )

    def disable_safe_import(self):
        self._safe_metadata()
        with self._transaction():
            self.execute(
                'INSERT OR REPLACE INTO "{}" VALUES (1, 0)'.format(self._safe_config)
            )

    def _safe_import_enabled(self):
        if not self[self._safe_config].exists():
            return False
        row = self.execute(
            'SELECT enabled FROM "{}" WHERE id = 1'.format(self._safe_config)
        ).fetchone()
        return bool(row and row[0])

    def create_import_checkpoint(self):
        if not self._safe_import_enabled():
            raise SafeImportNotEnabledError("Safe import is not enabled")
        checkpoint_id = uuid.uuid4().hex
        self.execute('SAVEPOINT "{}"'.format(checkpoint_id))
        self._import_checkpoints[checkpoint_id] = True
        self._active_import_checkpoints.append(checkpoint_id)
        return checkpoint_id

    def _check_import_checkpoint(self, checkpoint_id):
        if checkpoint_id not in self._import_checkpoints:
            raise CheckpointNotFoundError(checkpoint_id)
        if not self._import_checkpoints[checkpoint_id]:
            raise CheckpointNotActiveError(checkpoint_id)

    def _finalize_import_checkpoint(self, checkpoint_id, rollback):
        self._check_import_checkpoint(checkpoint_id)
        if rollback:
            self.execute('ROLLBACK TO SAVEPOINT "{}"'.format(checkpoint_id))
        self.execute('RELEASE SAVEPOINT "{}"'.format(checkpoint_id))
        index = self._active_import_checkpoints.index(checkpoint_id)
        # SQLite releasing an outer savepoint also finalizes its descendants.
        for child in self._active_import_checkpoints[index:]:
            self._import_checkpoints[child] = False
        del self._active_import_checkpoints[index:]

    def rollback_to_checkpoint(self, checkpoint_id):
        self._finalize_import_checkpoint(checkpoint_id, True)

    def commit_checkpoint(self, checkpoint_id):
        self._finalize_import_checkpoint(checkpoint_id, False)

    def cleanup_checkpoint(self, checkpoint_id):
        if checkpoint_id not in self._import_checkpoints:
            raise CheckpointNotFoundError(checkpoint_id)
        # Removing an active checkpoint must not silently commit unvalidated work.
        if self._import_checkpoints[checkpoint_id]:
            self.rollback_to_checkpoint(checkpoint_id)
        del self._import_checkpoints[checkpoint_id]

    def add_import_invariant(self, table, sql):
        if not isinstance(sql, str) or not sql.strip():
            raise ValueError("An invariant must be nonempty SQL")
        self._safe_metadata()
        invariant_id = uuid.uuid4().hex
        with self._transaction():
            self.execute(
                'INSERT INTO "{}" VALUES (?, ?, ?)'.format(self._safe_invariants),
                (invariant_id, table, sql),
            )
        return invariant_id

    def remove_import_invariant(self, table, invariant_id):
        if not self[self._safe_invariants].exists():
            return
        with self._transaction():
            self.execute(
                'DELETE FROM "{}" WHERE table_name = ? AND id = ?'.format(
                    self._safe_invariants
                ),
                (table, str(invariant_id)),
            )

    def list_import_invariants(self, table):
        if not self[self._safe_invariants].exists():
            return []
        return [
            dict(id=row[0], expression=row[1])
            for row in self.execute(
                'SELECT id, expression FROM "{}" WHERE table_name = ? ORDER BY rowid'.format(
                    self._safe_invariants
                ),
                (table,),
            )
        ]

    def validate_import_invariants(self, table):
        failures = []
        for invariant in self.list_import_invariants(table):
            expression = invariant["expression"].strip()
            try:
                if re.match(r"SELECT\b", expression, re.I):
                    row = self.execute(expression).fetchone()
                    valid = bool(row and row[0])
                else:
                    query = "SELECT ({}) FROM {}".format(expression, _quote(table))
                    # Let SQLite identify aggregates, rather than guessing from
                    # names in strings, comments, scalar MIN/MAX or extensions.
                    aggregate = any(
                        row[1] in ("AggStep", "AggFinal", "AggValue")
                        for row in self.execute("EXPLAIN " + query)
                    )
                    rows = self.execute(query)
                    if aggregate:
                        row = rows.fetchone()
                        valid = bool(row and row[0])
                    else:
                        valid = all(bool(row[0]) for row in rows)
                if not valid:
                    failures.append(
                        dict(invariant, error="Invariant evaluated to false or NULL")
                    )
            except Exception as ex:
                failures.append(dict(invariant, error=str(ex)))
        return {"valid": not failures, "failures": failures}

    def _run_safe_import(self, operation, tables=None, strict=False):
        checkpoint_id = uuid.uuid4().hex
        failures = []
        active = False
        try:
            checkpoint_id = self.create_import_checkpoint()
            active = True
            operation()
            if tables is None:
                tables = [
                    row[0]
                    for row in self.execute(
                        'SELECT DISTINCT table_name FROM "{}"'.format(
                            self._safe_invariants
                        )
                    )
                ]
            for table in tables:
                failures.extend(self.validate_import_invariants(table)["failures"])
            if failures:
                raise ImportInvariantError(failures)
            self.commit_checkpoint(checkpoint_id)
            active = False
            # Successful helpers do not expose the internal ID to the caller.
            self.cleanup_checkpoint(checkpoint_id)
            return {"success": True}
        except BaseException as ex:
            if active:
                if self.conn.in_transaction:
                    self.rollback_to_checkpoint(checkpoint_id)
                else:
                    # SQLite may itself abort the transaction, e.g. a trigger
                    # using RAISE(ROLLBACK). Do not mask its original error.
                    for child in self._active_import_checkpoints:
                        self._import_checkpoints[child] = False
                    self._active_import_checkpoints.clear()
            if strict or not isinstance(ex, Exception):
                raise
            return {
                "success": False,
                "checkpoint_id": checkpoint_id,
                "failures": failures,
                "error_report": str(ex),
            }

    def safe_bulk_insert(self, table, records, strict=False, **kwargs):
        return self._run_safe_import(
            lambda: self[table].insert_all(records, **kwargs), strict=strict
        )

    def safe_bulk_upsert(self, table, records, pk, strict=False, **kwargs):
        return self._run_safe_import(
            lambda: self[table].upsert_all(records, pk=pk, **kwargs), strict=strict
        )

    def import_csv(self, table, source, safe_mode=False, strict=False, **kwargs):
        def operation():
            if isinstance(source, str):
                with open(source, encoding="utf-8-sig", newline="") as fp:
                    self[table].insert_all(csv.DictReader(fp), **kwargs)
            else:
                self[table].insert_all(csv.DictReader(source), **kwargs)

        if safe_mode:
            return self._run_safe_import(operation, strict=strict)
        operation()
        return {"success": True}

    def import_json(self, table, data, safe_mode=False, strict=False, **kwargs):
        def operation():
            records = (
                json.loads(data) if isinstance(data, (str, bytes, bytearray)) else data
            )
            if isinstance(records, dict):
                records = [records]
            self[table].insert_all(records, **kwargs)

        if safe_mode:
            return self._run_safe_import(operation, strict=strict)
        operation()
        return {"success": True}
