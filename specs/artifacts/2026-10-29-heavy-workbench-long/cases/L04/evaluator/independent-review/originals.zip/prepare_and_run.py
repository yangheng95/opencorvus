"""Owned stdlib-only L04 cold replay from three frozen sources and closed original DB."""
from datetime import datetime,timezone
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
REPO=Path('D:/myhexin-local/opencorvus')
BASE=Path('D:/opencorvus-benchmark-runs/l04-migration-qualification-20261029')
PUBLIC=REPO/'specs/artifacts/2026-10-29-heavy-workbench-long/cases/L04/public'

def save(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')

def load(path):return json.loads(path.read_text(encoding='utf-8'))

def command(argv,label,cwd=ROOT):
    stamp=datetime.now(timezone.utc).isoformat();t=time.perf_counter()
    p=subprocess.run(argv,cwd=cwd,capture_output=True,text=True,encoding='utf-8',
        env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONIOENCODING':'utf-8'})
    base=ROOT/'commands'/label;base.parent.mkdir(parents=True,exist_ok=True)
    base.with_suffix('.stdout.txt').write_text(p.stdout,encoding='utf-8')
    base.with_suffix('.stderr.txt').write_text(p.stderr,encoding='utf-8')
    row={'argv':argv,'cwd':str(cwd),'started_utc':stamp,'seconds':time.perf_counter()-t,
        'exit_code':p.returncode,'stdout':str(base.with_suffix('.stdout.txt').relative_to(ROOT)),
        'stderr':str(base.with_suffix('.stderr.txt').relative_to(ROOT))}
    save(base.with_suffix('.json'),row);return row

def main():
    if (ROOT/'source-snapshot').exists():raise RuntimeError('use a new occurrence')
    inventory=[]
    def copy(source,target):
        target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
        inventory.append({'source':str(source),'copy':str(target.relative_to(ROOT)),'bytes':target.stat().st_size,
            'byte_equal_at_copy':source.read_bytes()==target.read_bytes()})
    for name in ('legacy_writer.py','reference_api.py','qualify_migration.py'):
        copy(BASE/'run-b-explicit-input/executed-source'/name,ROOT/'source-snapshot'/name)
    for name in ('v1.sqlite','authority.json','provenance.json'):
        copy(BASE/'inputs/v1'/name,ROOT/'frozen-input'/name)
    for name in ('PROTOCOL.draft.md','v1-schema.sql','legacy_writer.py'):
        copy(PUBLIC/name,ROOT/'protocol-snapshot'/name)
    copy(REPO/'specs/records/2026-10/2026-10-29-heavy-workbench-l04-qualification.md',ROOT/'protocol-snapshot/Recall.md')
    save(ROOT/'source-inventory.json',inventory)
    save(ROOT/'public-input-identity.json',{'identity_scope_only_not_behavior':True,
        'frozen_input_equals_public':{name:(ROOT/'frozen-input'/name).read_bytes()==(PUBLIC/name).read_bytes()
            for name in ('v1.sqlite','authority.json','provenance.json')},
        'writer_source_equals_public':(ROOT/'source-snapshot/legacy_writer.py').read_bytes()==(PUBLIC/'legacy_writer.py').read_bytes()})
    command(['git','-C',str(REPO),'status','--short'],'git-status-start')
    result=command(['C:/Python314/python.exe','-B',str(ROOT/'source-snapshot/qualify_migration.py'),
        '--input',str(ROOT/'frozen-input'),'--output',str(ROOT/'cold-run')],'full-cold-replay')
    save(ROOT/'execution-summary.json',{'scope':'actual own subprocess fixture migration qualification only; no seed generation, candidate/LLM run, or user process control',
        'command':result,'receipt':load(ROOT/'cold-run/receipt.json') if (ROOT/'cold-run/receipt.json').exists() else None,
        'no_initial_old_output_or_database_other_than_frozen_original':True})
    print(json.dumps({'command':result,'receipt':load(ROOT/'cold-run/receipt.json') if (ROOT/'cold-run/receipt.json').exists() else None},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
