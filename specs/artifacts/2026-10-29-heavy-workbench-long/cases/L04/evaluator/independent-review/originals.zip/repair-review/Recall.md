# Recall

独立单层只读审查最终run-d四源。旧run-b失败、217项通过和NULL真实反例均保留。仅复制冻结v1输入及四份实际执行源码到自有新目录；真实故障仅由harness控制自己Popen子进程。禁止Provider/GPU/solver/用户进程/UI/凭据/再次委托。

验收：六场景实际冷跑；从原始authority/库独立逐身份金额、退款、raw、历史、ACK和audit核对；before/after真实提交状态与owned PID；两模糊身份中止全表保存；原NULL请求及变entry请求明确invalid_request/op_key；实际SQLite身份约束。微型局部资格，不认可L04重型冻结/数小时。
