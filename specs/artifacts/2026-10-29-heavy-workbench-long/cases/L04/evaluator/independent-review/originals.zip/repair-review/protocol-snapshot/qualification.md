# L04已有数据库迁移与切换：便宜资格

## Recall

用户要求十个真正重型全链路任务、rubric、独立agent审查、OpenCorvus与Codex实跑比较，数小时应来自有效业务依赖；旧H05两方旧标准100已触发升级。用户最新要求“从便宜的实验开始做”，没有设置总token/总墙钟限额。六个昂贵资格容器保持Paused，S06只证明微型管线，不计入十题。[长程Recall](2026-10-29-heavy-workbench-long.md)与[九题独立审查](../../artifacts/2026-10-29-heavy-workbench-long/evaluator/nine-case-review/H04.md)是前置依据。

当前旧H04只有600订单CSV/已指定目标三表，事务转换即可完成主要核，没有已有数据库、真实版本、写入ACK或切换边界。新任务要测试持久数据版本演进，与H05跨系统副作用区别；不能只加行数/报告/故障名称。独立建议先真实小构造O1=USD12.34、R1=-2.34及快照后ACK O2=CNY5.00，再做数据库/版本/epoch共同提交和受控进程恢复。

已查主仓tracked定义/调用及现行case目录：尚无l04-migration/L04资格实现，相关材料是旧H04与九题建议，不能冒充新执行器已存在。Windows字面glob搜索不能证明全仓结果，已改用git grep/rg文件过滤。当前宿主Python3.14/SQLite3.50.4可用；查[SQLite事务官方文档](https://www.sqlite.org/lang_transaction.html)与[WAL文档](https://www.sqlite.org/wal.html)。本资格明确使用本地rollback journal（DELETE）及synchronous FULL、显式事务和合作旧写者；不要求WAL/零停写/网络文件系统或物理断电。

## 问题深度与影响面

直接触发是旧题缺持久状态与并发切换能力，根因是CSV输入将身份、迁移史和ACK事实都消除了；一个新建库事务无法检验已确认数据保存。旧路径不涉及旧写者或提交后响应丢失，故此前局部通过不能证明安全升级。新资格只构造合成数据库/公开协议、隔离参考与独立SQL检查，不修改生产Task/Mission/Session调度、数据库迁移、Provider/工具、UI、发布或用户服务；不会以benchmark注入故障推断生产共享队列有问题。故障仅作用于本资格自行启动并记录PID的子进程。

公共事实必须先单一化：schema_migrations历史最大版本是唯一schema版本，control中的epoch是写者generation、不是版本影子；旧/新写者都在同一写事务内检查epoch。事务迁移同时提交数据、当前版本历史与epoch变化。历史raw数据只用于不可变归档/隔离，不保留第二套活跃协议/双写；目标只使用v2接口，旧写者以明确stale_epoch退场。

风险包括把金额汇总一致当逐身份保留、按邮箱猜合并、executescript隐式提交破坏事务、备份恢复丢升级后写、无日志却要求不停写无损，以及伪造故障位置。用权威身份映射、Decimal精确两位金额、真实数据库/稳定写者、明确短暂停写能力与真实进程控制边界解决；参考允许SQLite事务的正确简单实现，不以算法简单扣分。

## 实施前协议与便宜验收

1. 外部根`D:/opencorvus-benchmark-runs/l04-migration-qualification-20261029`，生成关闭连接的真实v1.sqlite、schema/migration史、权威customer映射与可执行legacy_writer.py。数据为明示合成，含相同邮箱不同权威身份、两legacy ID的合法同一客户别名、USD/CNY订单与退款、孤儿/未映射/金额非法记录。可安全映射和应隔离的原因公开，不能自行猜身份或静默丢原数据。
2. v1写者以BEGIN IMMEDIATE检查epoch3，再提交订单和稳定write_receipts，只有commit后才输出ACK。v2迁移目标有真实客户/别名、整数金额、退款外键、非负fee_minor及隔离原件；所有源数据必须可按稳定身份追踪。schema_migrations升级记录一次、epoch从3变4在同一事务。原迁移史保留，重复upgrade返回already_current，不再递增epoch。
3. 私有建设性参考先实现upgrade/read/write新接口。公开故障能力是在真实before_commit或after_commit处发出JSON checkpoint并等待stdin释放；评估侧只在确认自有PID/该事件后终止这个子进程，不使用sleep或操作用户进程。另一连接实际查看当时schema/epoch，防止把日志位置当提交事实。
4. 三组新副本：正常升级与升级前ACK O2保留；before_commit进程中断后真实v1状态/再次升级/继续v2写；after_commit响应前中断后真实v2状态/幂等重试/继续写。另在迁移持锁时启动独立旧写者，释放提交后应收到stale_epoch，不生成虚假成功。每组都核对逐entry ID、customer、币种、金额、退款关系、隔离raw、实际版本/epoch/ACK收据，并执行合法v2 fee写及明确冲突响应。
5. 完整源码新目录再冷跑，独立agent单层审查/复核原件，禁止再委托。先证实这几秒级能力真实可达，再补完整重型现场/版本与应用回归/操作手册/恢复决策、原子rubric和错误对照；微型资格不能宣布L04冻结、数小时或十题完成。没有新LLM候选、GPU、整数长求解或用户进程操作。

所有新spec/产物归根目录specs并同步索引；本任务修改范围提交，正常fetch/merge/完整待推集合审查/push，保留其他任务工作区。

首轮真实构造5.86秒完成正常/before_commit中断/after_commit响应丢失/旧写者跨切换4场景，43个真实子进程、217个正向事实/具名错误核对；source/PID/数据库与控制事件均落盘。它从已知seed生成了原库再运行，只作初轮构造。主方审读发现运行器仍把输入生成与执行耦合，不利于冻结原库的source-only复跑；因此删除运行器对seed生成的依赖，新增必需--input目录，仅复制v1.sqlite/authority/provenance，seed脚本只负责独立准备fixture，旧已执行源/数据库不覆盖。修后必须用同一冻结原库重跑真实场景，独立agent再另目录完整冷跑；不能仅靠源文件存在代替。

修后同一冻结原库主方6.15秒通过，独立冷跑核心10.47秒也通过4场景；另独立SQL按原库/authority重建112项通过。但独立真实反例发现两个写入口共同接受op_key:null：SQLite普通TEXT PRIMARY KEY未显式NOT NULL，且WHERE op_key=NULL不匹配，重发变entry_conflict/constraint_error，换entry_id又accepted形成第二条NULL收据。旧自检只取合法字符串身份，没有暴露共享缺口；不能拿原217项通过掩盖这个真实失败。反例在独立目录两个副本/6次真实CLI，原冷跑DB不覆盖。

修复前横向审计覆盖本资格全部v1/v2入口、正常/重复/冲突/提交后恢复/旧写者串并行切换，均只有这两个写函数和同一稳定收据表；四场景每次独立路径/库，无公共全局状态。脚本全部为本资格私有Python/SQLite，仅导入标准库，没有生产Task/Mission/Session或共享队列primitive调用，代码/路径据此排除产品调度根因，不把共享于两个写者的问题降为单个case。根因为入口没有稳定身份类型合同和表层允许NULL，需同时修API与v2持久约束。

实施前修复方案：新增唯一l04_request.py共同验证两写者的非空字符串op_key/entry_id、整数epoch及各版本字段，返回invalid_request/field；不复制两份身份规则。旧原库和已发布version1历史不改，v2在同一迁移事务内将write_receipts升级为显式NOT NULL/非空身份并保留原收据，entries.entry_id同样具备约束。已有无法判定的空/NULL收据身份或entry身份返回unresolved_receipt_identity/unresolved_entry_identity，迁移中止、原数据/版本/epoch保留待对账，禁止猜造op_key。补真实两写入口8个非法身份/类型错误、实际SQL身份约束和两个旧模糊身份中止对照；修后完整小资格再实跑，独立只复核新增修复与必要冷跑。新协议同步这些边界。

queued控制只独立观察到进程在紧邻BEGIN之前发出write_attempt、跨切换后stale；不能把它夸大为已读取SQLite内部等待队列。事务内检查epoch的真实代码、提交边界的独立SQL及结果共同支持当前合同，但不认证全部并发调度。当前仍非重型题冻结。

修复横向覆盖所有v2稳定TEXT主键：customers、entries、write_receipts均显式NOT NULL/非空；quarantine组合键原已NOT NULL。原v1库/迁移史不重写，v2收据约束在事务内自动升级并保留合法收据。修后run-c加入共享输入guard、8个真实CLI错误及两个模糊身份按合同中止；run-d再覆盖客户主键，核心7.18秒、53子进程/245事实通过。是4个成功升级场景和2个保留原库的明确中止场景，不能说6次全部升级成功。当前四源和实际版本快照、原失败都保留，公开writer与shared helper成对同步。SQLite TEXT主键允许NULL的事实另由[官方CREATE TABLE合同](https://www.sqlite.org/lang_createtable.html)及独立真实反例共同证明，不凭DDL字面值推定运行安全。
