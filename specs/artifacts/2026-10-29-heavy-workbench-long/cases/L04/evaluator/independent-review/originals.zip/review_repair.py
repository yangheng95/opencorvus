"""Owned independent cold replay of final D snapshot, standard library only."""
from datetime import datetime, timezone
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

BASE = Path('D:/opencorvus-benchmark-runs/l04-migration-qualification-20261029')
HOME = Path('D:/opencorvus-benchmark-runs/l04-migration-independent-review-20261029')
ROOT = HOME / 'repair-review'
REPO = Path('D:/myhexin-local/opencorvus')
PYTHON = 'C:/Python314/python.exe'

def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+'\n', encoding='utf-8')

def command(argv, label):
    started = datetime.now(timezone.utc).isoformat()
    clock = time.perf_counter()
    p = subprocess.run(argv, cwd=ROOT, capture_output=True, text=True, encoding='utf-8')
    duration = time.perf_counter()-clock
    folder=ROOT/'commands';folder.mkdir(exist_ok=True)
    (folder/(label+'.stdout.txt')).write_text(p.stdout, encoding='utf-8')
    (folder/(label+'.stderr.txt')).write_text(p.stderr, encoding='utf-8')
    receipt={'argv':argv,'cwd':str(ROOT),'started_utc':started,'seconds':duration,'returncode':p.returncode,
             'stdout':str(folder/(label+'.stdout.txt')),'stderr':str(folder/(label+'.stderr.txt'))}
    save(folder/(label+'.json'),receipt)
    if p.returncode:raise RuntimeError(receipt)
    return receipt

def main():
    ROOT.mkdir(exist_ok=False)
    (ROOT/'Recall.md').write_text('''# Recall\n\n独立单层只读审查最终run-d四源。旧run-b失败、217项通过和NULL真实反例均保留。仅复制冻结v1输入及四份实际执行源码到自有新目录；真实故障仅由harness控制自己Popen子进程。禁止Provider/GPU/solver/用户进程/UI/凭据/再次委托。\n\n验收：六场景实际冷跑；从原始authority/库独立逐身份金额、退款、raw、历史、ACK和audit核对；before/after真实提交状态与owned PID；两模糊身份中止全表保存；原NULL请求及变entry请求明确invalid_request/op_key；实际SQLite身份约束。微型局部资格，不认可L04重型冻结/数小时。\n''',encoding='utf-8')
    source=ROOT/'source-snapshot';source.mkdir()
    names=('legacy_writer.py','reference_api.py','l04_request.py','qualify_migration.py')
    for name in names:shutil.copy2(BASE/'run-d-storage-identity-final/executed-source'/name,source/name)
    inputs=ROOT/'frozen-input';inputs.mkdir()
    for name in ('v1.sqlite','authority.json','provenance.json'):shutil.copy2(BASE/'inputs/v1'/name,inputs/name)
    protocol=ROOT/'protocol-snapshot';protocol.mkdir()
    shutil.copy2(REPO/'specs/records/2026-10/2026-10-29-heavy-workbench-l04-qualification.md',protocol/'qualification.md')
    public=REPO/'specs/artifacts/2026-10-29-heavy-workbench-long/cases/L04/public'
    shutil.copy2(public/'PROTOCOL.draft.md',protocol/'PROTOCOL.draft.md')
    status=subprocess.run(['git','status','--short'],cwd=REPO,capture_output=True,text=True,encoding='utf-8')
    (ROOT/'git-status-before.txt').write_text(status.stdout,encoding='utf-8')
    save(ROOT/'snapshot-provenance.json',{
      'author_executed_directory':str(BASE/'run-d-storage-identity-final/executed-source'),
      'source_exact_byte_copy':{n:(source/n).read_bytes()==(BASE/'run-d-storage-identity-final/executed-source'/n).read_bytes() for n in names},
      'frozen_input_public_byte_identity':{n:(inputs/n).read_bytes()==(public/n).read_bytes() for n in ('v1.sqlite','authority.json','provenance.json')},
      'public_writer_current_identity':{n:(source/n).read_bytes()==(public/n).read_bytes() for n in ('legacy_writer.py','l04_request.py')},
      'identity_role':'provenance only; SQL and real process behavior are functional acceptance',
      'copied_author_generated_outputs':False})
    receipt=command([PYTHON,'-B',str(source/'qualify_migration.py'),'--input',str(inputs),'--output',str(ROOT/'cold-run')],'full-cold-replay')
    actual=json.loads((ROOT/'cold-run/receipt.json').read_text(encoding='utf-8'))
    print(json.dumps({'returncode':receipt['returncode'],'outer_seconds':receipt['seconds'],
       'harness_seconds':actual['seconds'],'cases':len(actual['cases']),
       'check_count':actual['check_count'],'subprocess_count':actual['subprocess_count']},ensure_ascii=False))

if __name__=='__main__':main()
