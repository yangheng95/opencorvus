"""Explicit synthetic migration fixture, not a heavy benchmark instance."""
import argparse
import json
from pathlib import Path
import sqlite3


CUSTOMERS=[(7,'张三','same@example.test'),(9,'张三旧别名','alias@example.test'),
           (11,'未核实','unknown@example.test'),(12,'另一个同名客户','same@example.test')]
ENTRIES=[('O1',7,'USD','12.34',None),('R1',9,'USD','-2.34','O1'),
         ('O_ALIAS',9,'CNY','2.50',None),('O_BETA',12,'USD','7.00',None),('O_ZERO',7,'CNY','0.00',None),
         ('O_SCALE',7,'USD','1.005',None),('O_TEXT',7,'USD','12O.00',None),
         ('O_UNKNOWN',11,'USD','3.00',None),('O_ORPHAN',999,'CNY','8.00',None),('R_BAD',7,'USD','-1.00','MISSING')]
AUTHORITY={'source':'explicit synthetic authoritative identity map; email equality is not identity',
           'legacy_to_customer':{'7':'C-ALPHA','9':'C-ALPHA','12':'C-BETA'},
           'customers':{'C-ALPHA':{'display_name':'甲客户','email':'same@example.test'},
                        'C-BETA':{'display_name':'乙客户','email':'same@example.test'}}}


def create(folder):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=False)
    db=folder/'v1.sqlite'
    connection=sqlite3.connect(db,isolation_level=None)
    connection.execute('PRAGMA journal_mode=DELETE');connection.execute('PRAGMA synchronous=FULL')
    statements=[
        'CREATE TABLE control(singleton INTEGER PRIMARY KEY CHECK(singleton=1), epoch INTEGER NOT NULL)',
        'CREATE TABLE schema_migrations(version INTEGER PRIMARY KEY,name TEXT NOT NULL,applied_at TEXT NOT NULL)',
        'CREATE TABLE legacy_customers(customer_id INTEGER PRIMARY KEY,display_name TEXT,email TEXT)',
        'CREATE TABLE legacy_entries(entry_id TEXT PRIMARY KEY,customer_id INTEGER NOT NULL,currency TEXT NOT NULL,amount TEXT NOT NULL,reversal_of TEXT)',
        'CREATE INDEX legacy_entries_customer ON legacy_entries(customer_id)',
        'CREATE TABLE write_receipts(op_key TEXT PRIMARY KEY,command_json TEXT NOT NULL,result_json TEXT NOT NULL)',
        'CREATE TABLE audit_events(event_id INTEGER PRIMARY KEY AUTOINCREMENT,entry_id TEXT NOT NULL,source_schema INTEGER NOT NULL,payload TEXT NOT NULL)',
        "CREATE TRIGGER legacy_entry_audit AFTER INSERT ON legacy_entries BEGIN INSERT INTO audit_events(entry_id,source_schema,payload) VALUES(NEW.entry_id,1,json_object('customer_id',NEW.customer_id,'currency',NEW.currency,'amount',NEW.amount,'reversal_of',NEW.reversal_of)); END",
    ]
    connection.execute('BEGIN IMMEDIATE')
    for statement in statements:connection.execute(statement)
    connection.execute('INSERT INTO control VALUES(1,3)')
    connection.execute("INSERT INTO schema_migrations VALUES(1,'synthetic_legacy_v1','2026-10-01T00:00:00Z')")
    connection.executemany('INSERT INTO legacy_customers VALUES(?,?,?)',CUSTOMERS)
    connection.executemany('INSERT INTO legacy_entries VALUES(?,?,?,?,?)',ENTRIES)
    connection.commit();connection.close()
    (folder/'authority.json').write_text(json.dumps(AUTHORITY,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (folder/'provenance.json').write_text(json.dumps({'synthetic':True,'sqlite_version':sqlite3.sqlite_version,
        'schema_version':1,'epoch':3,'customers':4,'entries':10,'journal_mode':'delete','synchronous':'FULL',
        'history_timestamp':'synthetic fixture date, not a real deployment claim'},indent=2)+'\n')
    return folder


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True)
    print(create(parser.parse_args().output))
