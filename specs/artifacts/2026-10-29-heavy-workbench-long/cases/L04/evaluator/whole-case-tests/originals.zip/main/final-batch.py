from native import run,ROOT,dump,now
done=[]
for subject in ('final','final-weak'):
    for variant in ('base','money','identity'):
        code=run(subject,variant);done.append({'subject':subject,'variant':variant,'exit_code':code,'finished_at':now()});dump(ROOT/'final-progress.json',done)
dump(ROOT/'final-terminal.json',{'finished_at':now(),'jobs':done})
