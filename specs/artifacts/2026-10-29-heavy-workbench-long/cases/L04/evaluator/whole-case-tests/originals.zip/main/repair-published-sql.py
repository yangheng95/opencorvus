import json,sqlite3,shutil,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent;PUB=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L04/public')
old=ROOT/'published-v1-construction-original.sql';shutil.copy2(PUB/'published-v1.sql',old)
try:sqlite3.connect(':memory:').executescript(old.read_text(encoding='utf-8'))
except sqlite3.Error as e:(ROOT/'published-sql-original-failure.json').write_text(json.dumps({'status':'author_material_construction_error','error':str(e),'original':str(old),'not_candidate_failure':True},indent=2)+'\n')
c=sqlite3.connect(PUB/'app-v1.sqlite');sql='\n\n'.join(x[0]+';' for x in c.execute("SELECT sql FROM sqlite_master WHERE sql IS NOT NULL AND name NOT LIKE 'sqlite_%' ORDER BY CASE type WHEN 'table' THEN 0 WHEN 'index' THEN 1 ELSE 2 END,name"));c.close();(PUB/'published-v1.sql').write_text('BEGIN IMMEDIATE;\n'+sql+'\nCOMMIT;\n',encoding='utf-8')
d=sqlite3.connect(ROOT/'published-rebuild.sqlite');d.executescript((PUB/'published-v1.sql').read_text(encoding='utf-8'));d.execute("INSERT INTO legacy_customers VALUES(7,'positive','mail@example.test')");d.execute("INSERT INTO legacy_entries VALUES('REAL-POSITIVE',7,'USD','12.34',NULL)");d.commit();entry=d.execute('SELECT * FROM legacy_entries').fetchone();audit=d.execute('SELECT entry_id,source_schema,payload FROM audit_events').fetchone();d.close()
assert entry==('REAL-POSITIVE',7,'USD','12.34',None) and audit[0:2]==('REAL-POSITIVE',1) and json.loads(audit[2])['amount']=='12.34'
(ROOT/'published-sql-repair-positive.json').write_text(json.dumps({'source':'current public/published-v1.sql','status':'executed','entry':entry,'actual_trigger_audit':audit,'input_app_v1':'unchanged, original rows/history preserved','scope':'one standalone published SQL construction/actual v1 insert; zero application matrix reruns'},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
