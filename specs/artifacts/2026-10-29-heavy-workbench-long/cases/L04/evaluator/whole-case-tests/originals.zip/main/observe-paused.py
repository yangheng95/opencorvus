import json,subprocess
from pathlib import Path
from datetime import datetime,timezone
root=Path(__file__).resolve().parent;receipt=json.loads(Path('D:/opencorvus-benchmark-runs/cheap-first-20261029/pause-receipt.json').read_text(encoding='utf-8'));ids=[x['id'] for x in receipt['containers']]
r=subprocess.run(['docker','inspect',*ids],capture_output=True,text=True)
if r.returncode:raise RuntimeError(r.stderr)
objects=json.loads(r.stdout);observations=[{'id':x['Id'],'name':x['Name'],'paused':x['State']['Paused'],'status':x['State']['Status'],'running':x['State']['Running']} for x in objects]
(root/'paused-observation-end.json').write_text(json.dumps({'observed_at':datetime.now(timezone.utc).isoformat(),'action':'read-only inspect of exact six owned IDs; no resume/restart','containers':observations},indent=2)+'\n',encoding='utf-8')
print(json.dumps({'observed':len(observations),'paused':sum(x['paused'] for x in observations)}))
