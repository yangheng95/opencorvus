import json,shutil,subprocess,time,zipfile,sys
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parent;CASE=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L04')
IMAGE='sha256:23ff8bfbf8055caa0b9fa5745ddb27cceea2f31d7d15b7a900c81112cdfe8ddf'
def now():return datetime.now(timezone.utc).isoformat()
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def prepare():
    for role in ('base','money','identity'):
        dst=ROOT/('raw-handover-'+role);shutil.copytree(CASE/'public',dst)
        for file in ('app-v1.sqlite','identity-authority.json'):shutil.copy2(ROOT/('raw-'+role)/file,dst/file)
    for subject in ('handover','handover-weak'):
        src=ROOT/(subject+'-submission');src.mkdir();files=['app.py','report.py','reproduce.py','legacy_app.py']
        for file in files:shutil.copy2(CASE/('public' if file=='legacy_app.py' else 'evaluator')/file,src/file)
        if subject=='handover-weak':(src/'defect.txt').write_text('weak_report\n',encoding='utf-8');files.append('defect.txt')
        dump(src/'submission.json',{'files':files,'app_argv':['python','-B','app.py'],'report_argv':['python','-B','report.py']})
def run(subject,role):
    out=ROOT/(subject+'-'+role);out.mkdir();results=out/'results';results.mkdir();source=ROOT/(subject+'-submission');raw=ROOT/('raw-handover-'+role);name='oc-l04-'+subject+'-'+role+'-20261031'
    argv=['docker','create','--name',name,'--network','none','--cpus','1','--mount',f'type=bind,source={source},target=/source,readonly','--mount',f'type=bind,source={raw},target=/raw,readonly','--mount',f'type=bind,source={results},target=/results',IMAGE,'/opt/cpsat/bin/python','-B','/source/reproduce.py','--input','/raw','--output','/results/run']
    start=now();r=subprocess.run(argv,capture_output=True,text=True);dump(out/'create-native.json',{'argv':argv,'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'started_at':start})
    if r.returncode:raise RuntimeError('container_create_failed')
    cid=r.stdout.strip();dump(out/'launch.json',{'cid':cid,'name':name,'started_at':now(),'source':str(source),'raw':str(raw),'entry':'only public input + submission reproduce.py, zero private evaluator mount'})
    t=time.monotonic();r=subprocess.run(['docker','start','--attach',cid],capture_output=True,text=True,encoding='utf-8');(out/'stdout.txt').write_text(r.stdout,encoding='utf-8');(out/'stderr.txt').write_text(r.stderr,encoding='utf-8')
    inspect=subprocess.run(['docker','inspect',cid],capture_output=True,text=True,check=True);(out/'inspect-terminal.json').write_text(inspect.stdout,encoding='utf-8');dump(out/'native-terminal.json',{'exit_code':r.returncode,'finished_at':now(),'wall_seconds':time.monotonic()-t})
    with zipfile.ZipFile(out/'completed-originals.zip','w',zipfile.ZIP_DEFLATED) as z:
        for file in out.rglob('*'):
            if file.is_file() and file.name!='completed-originals.zip':z.write(file,file.relative_to(out))
        for prefix,path in [('source',source),('raw',raw)]:
            for file in path.rglob('*'):
                if file.is_file():z.write(file,Path(prefix)/file.relative_to(path))
    c=subprocess.run(['docker','rm',cid],capture_output=True,text=True);dump(out/'cleanup.json',{'cid':cid,'exit_code':c.returncode,'stdout':c.stdout,'stderr':c.stderr});print(json.dumps({'subject':subject,'role':role,'exit_code':r.returncode,'seconds':time.monotonic()-t,'stdout':r.stdout}),flush=True)
    return r.returncode
if __name__=='__main__':
    if sys.argv[1]=='prepare':prepare()
    else:
        done=[]
        for subject in ('handover','handover-weak'):
            for role in ('base','money','identity'):
                code=run(subject,role);done.append({'subject':subject,'role':role,'exit_code':code,'finished_at':now()});dump(ROOT/'handover-progress.json',done)
                if code:raise SystemExit(code)
        dump(ROOT/'handover-terminal.json',{'finished_at':now(),'jobs':done})
