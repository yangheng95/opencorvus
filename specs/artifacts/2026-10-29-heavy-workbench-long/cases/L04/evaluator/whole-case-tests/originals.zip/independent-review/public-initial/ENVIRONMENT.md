# 环境

Python 3/SQLite标准库可运行公开旧应用；候选可用其它语言但须提供可复建依赖。参考验收环境Python/SQLite、Matplotlib已离线安装；1CPU、无网络、源码和原料只读、新输出。SQLite单机本地文件/DELETE journal/synchronous FULL；不承诺网络盘或物理掉电。无凭据需求。候选提交/源码不得引用宿主其它项目或旧答案。

应用不是LLM调用端：数据库语句锁超时10秒，故障握手由运行器在真实checkpoint后释放或终止自己子进程。没有整个agent任务token/墙钟额度和最低工作时长。准备/评估耗时与模拟业务不计有效候选小时。
