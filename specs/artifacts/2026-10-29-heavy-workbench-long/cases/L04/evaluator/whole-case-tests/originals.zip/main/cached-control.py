from native import ROOT,run,dump,now
import shutil,json
source=ROOT/'cached-authority-submission';shutil.copytree(ROOT/'final-submission',source)
p=source/'app.py';text=p.read_text(encoding='utf-8');old="json.loads(a.authority.read_text(encoding='utf-8'))";new="json.loads(Path(__file__).with_name('cached-authority.json').read_text(encoding='utf-8'))"
assert text.count(old)==1;p.write_text(text.replace(old,new),encoding='utf-8');shutil.copy2(ROOT/'raw-base'/'identity-authority.json',source/'cached-authority.json')
m=json.loads((source/'submission.json').read_text(encoding='utf-8'));m['files'].append('cached-authority.json');dump(source/'submission.json',m)
done=[]
for variant in ('base','money','identity'):
    code=run('cached-authority',variant);done.append({'variant':variant,'exit_code':code,'finished_at':now()});dump(ROOT/'cached-control-progress.json',done)
dump(ROOT/'cached-control-terminal.json',{'finished_at':now(),'jobs':done})
