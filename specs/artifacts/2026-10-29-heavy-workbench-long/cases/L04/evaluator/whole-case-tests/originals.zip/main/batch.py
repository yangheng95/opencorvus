from native import run,ROOT,dump,now
jobs=[('closed','money'),('closed','identity'),('email_merge','base'),('truncate_money','base'),('wrong_refund','base'),('early_version','base'),('restore_backup','base'),('weak_report','base'),('weak_report','money'),('weak_report','identity')]
done=[]
for subject,variant in jobs:
    code=run(subject,variant);done.append({'subject':subject,'variant':variant,'exit_code':code,'completed_at':now()});dump(ROOT/'batch-progress.json',done)
dump(ROOT/'batch-terminal.json',{'completed_at':now(),'jobs':done})
