# 干净复建
Python 3标准库用于app/旧app/执行器，Matplotlib用于图。程序仅app.py、legacy_app.py、report.py及submission声明的其它普通文件。离线依赖预装，不在运行时联网。
从公开app-v1.sqlite/identity-authority.json及legacy_app.py建只读raw，从submission文件建只读source，给新out；使用EXECUTION所述协议逐scenario运行。评估侧命令：python run_l04.py --source SOURCE --raw RAW --out OUT。它控制自己的进程故障并保存所有原native/SQL；最后执行冻结report命令。独立验收从原raw重新计算，不用候选自评。
先观察原owner真实终态，不重复已完成的同一目录。任何失败保留request、stdout/stderr、exit与现场库后处理。与SQLite commit后ACK丢失相区别，无法承诺物理掉电下OS/磁盘可靠性。
