import json,sqlite3,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
E=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L04/evaluator');CASE=E.parent
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def register():
    inputs={}
    for role in ('base','money','identity'):
        c=sqlite3.connect(ROOT/('raw-'+role)/'app-v1.sqlite');c.row_factory=sqlite3.Row
        tables=[r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")]
        inputs[role]={'tables':{t:[dict(x) for x in c.execute('SELECT * FROM '+t)] for t in tables},'authority':json.loads((ROOT/('raw-'+role)/'identity-authority.json').read_text(encoding='utf-8'))};c.close()
    path=CASE/'evaluator'/'registered-inputs.json'
    if path.exists():raise RuntimeError('registration_already_exists')
    dump(path,{'kind':'immutable raw business identities for three registered test controls','inputs':inputs})
def grade(subject,roles,review=None):
    out=ROOT/(subject+('-reviewed' if review else '-machine')+'-assessment')
    argv=[sys.executable,'-X','utf8','-B',str(E/'check_l04.py'),'--rubric',str(CASE/'rubric.json'),'--registered-inputs',str(E/'registered-inputs.json'),'--out',str(out)]
    for role in roles:
        launch=json.loads((ROOT/(subject+'-'+role)/'launch.json').read_text(encoding='utf-8'))
        argv+=['--run',str(ROOT/(subject+'-'+role)/'results/run'),'--raw',launch['raw']]
    if review:argv+=['--review',str(review)]
    p=subprocess.run(argv,capture_output=True,text=True,encoding='utf-8');dump(ROOT/(subject+('-reviewed' if review else '-machine')+'-command.json'),{'argv':argv,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr});print(subject,p.returncode,p.stdout,flush=True)
if __name__=='__main__':
    if sys.argv[1]=='register':register()
    elif sys.argv[1]=='grade':grade(sys.argv[2],sys.argv[3].split(','),Path(sys.argv[4]) if len(sys.argv)>4 else None)
