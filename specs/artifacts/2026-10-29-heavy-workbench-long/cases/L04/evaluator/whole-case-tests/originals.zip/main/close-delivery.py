import json,shutil,zipfile
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parent;REVIEW=ROOT.parent/'l04-whole-case-independent-review-20261031';REPO=Path('D:/myhexin-local/opencorvus');CASE=REPO/'specs/artifacts/2026-10-29-heavy-workbench-long/cases/L04';OUT=CASE/'evaluator/whole-case-tests'
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
rubric=json.loads((CASE/'rubric.json').read_text(encoding='utf-8'));before=json.loads(json.dumps(rubric));rubric['status']='frozen_development_pilot';dump(CASE/'rubric.json',rubric)
assert rubric['leaves']==before['leaves'] and rubric['good_rule']==before['good_rule']
profile=json.loads((CASE/'public/profile.json').read_text(encoding='utf-8'));profile['status']='frozen_development_pilot';profile['inputs']=sorted(p.name for p in (CASE/'public').iterdir() if p.is_file());dump(CASE/'public/profile.json',profile)
stage=json.loads((REVIEW/'stage-assessment.json').read_text(encoding='utf-8'));assert stage['development_pilot_freeze_allowed'] and not stage['remaining_substantive_blockers']
dump(CASE/'FREEZE.json',{'case_id':'L04','version':'0.2.0-dev','frozen_at':datetime.now(timezone.utc).isoformat(),'status':'development_pilot_frozen','public_inputs':profile['inputs'],'rubric':'rubric.json','weights_fixed':100,'good_rule':rubric['good_rule'],'review':'evaluator/whole-case-tests/independent-review/REVIEW-FINAL.md','review_scope':'one nonblind familiar AI whole-case review, one actual extra source-only base replay','reference_assessment':'evaluator/whole-case-tests/main-assessment.json','weak_assessment':'evaluator/whole-case-tests/weak-assessment.json','late_public_clarifications':['runnable standalone published-v1.sql repaired before freeze, original SQL/actual error retained; DB/history unchanged','DATA applied_at wording explicitly matches already reviewed actual UTC native window; no behavior/weight/threshold change'],'limitations':['author reference/error programmes, not model candidate scores','reference seconds not meaningful multi-hour candidate qualification','no physical power loss/arbitrary concurrency/lossless downgrade/security or professional statistical certification','suite 8/10 development contracts, genuine candidate-hour qualification 0/10; L05/L01 and triggered L02/L06 upgrades still required']})
OUT.mkdir(exist_ok=False)
shutil.copytree(ROOT/'handover-base/results/run/delivery',OUT/'reference-delivery');shutil.copytree(ROOT/'handover-submission',OUT/'reference-source')
for name,destination in [('handover-reviewed-assessment','main-assessment'),('handover-weak-reviewed-assessment','weak-assessment')]:shutil.copy2(ROOT/name/'assessment.json',OUT/(destination+'.json'))
for name in ('handover-reviewed-command.json','handover-weak-reviewed-command.json','handover-machine-command.json','handover-weak-machine-command.json','cached-authority-machine-command.json','published-sql-original-failure.json','published-sql-repair-positive.json','paused-observation-end.json','handover-terminal.json','batch-terminal.json','cached-control-terminal.json'):
    shutil.copy2(ROOT/name,OUT/name)
for name in ('email_merge','truncate_money','wrong_refund','early_version','restore_backup','cached-authority'):
    shutil.copy2(ROOT/(name+'-machine-assessment')/'assessment.json',OUT/(name+'-assessment.json'));shutil.copy2(ROOT/(name+'-machine-command.json'),OUT/(name+'-command.json'))
review_out=OUT/'independent-review';review_out.mkdir()
for file in REVIEW.iterdir():
    if file.is_file() and file.suffix in ('.md','.json','.py'):shutil.copy2(file,review_out/file.name)
dump(ROOT/'delivery.json',{'case':'L04/0.2.0-dev','status':'development_pilot_frozen','main_native':'handover-* three registered inputs, all native0/actual report0/six completed scenarios each','weak_native':'handover-weak-* three registered inputs, all native0','actual_checker':{'main':100,'weak':96,'weak_good':False,'weak_critical_failure':'H02'},'other_error_results':'actual same CLI, known critical failures; missing remaining control/review leaves stay null','review':stage,'whole_suite_development_contracts':8,'candidate_effective_hours_qualified':0,'next':'complete L05/L01, then triggered new L02/L06 intrinsic upgrades; no finished-case repeats'})
with zipfile.ZipFile(OUT/'originals.zip','w',zipfile.ZIP_DEFLATED) as z:
    for prefix,folder in [('main',ROOT),('independent-review',REVIEW)]:
        for file in folder.rglob('*'):
            if file.is_file():z.write(file,Path(prefix)/file.relative_to(folder))
    for file in [CASE/'rubric.json',CASE/'FREEZE.json',*list((CASE/'public').iterdir()),*list((CASE/'evaluator').glob('*.py')),CASE/'evaluator/BUILD-PLAN.md']:
        if file.is_file():z.write(file,Path('final-current-case')/file.relative_to(CASE))
dump(OUT/'archive-receipt.json',{'archive':'originals.zip','size_bytes':(OUT/'originals.zip').stat().st_size,'contains':'complete pre-push main/reviewer folders, source-initial captured by reviewer, native DB/requests/PIDs/logs/inspect/inputs, original failures and final case source','original_source':'reviewer source-initial/check_l04.py was captured before original real counterexamples; no reconstructed-source claim','late_publish_receipt':'external publish-delivery.json generated after push, not retroactively inside this archive','checks_not_used_as_functional_gate':'no source hash or mutable checksum acceptance'})
print(json.dumps({'archive_bytes':(OUT/'originals.zip').stat().st_size,'main_actual':100,'weak_actual':96,'weak_good':False}))
