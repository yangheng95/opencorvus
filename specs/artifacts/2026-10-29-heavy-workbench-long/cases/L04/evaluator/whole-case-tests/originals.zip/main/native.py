import json,subprocess,time,sys,shutil
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parent
IMAGE='sha256:23ff8bfbf8055caa0b9fa5745ddb27cceea2f31d7d15b7a900c81112cdfe8ddf'
def now():return datetime.now(timezone.utc).isoformat()
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def run(subject,variant):
    label=f'{subject}-{variant}';out=ROOT/label;out.mkdir(exist_ok=False);results=out/'results';results.mkdir();name='oc-l04-'+label+'-20261031'
    argv=['docker','create','--name',name,'--network','none','--cpus','1','--mount',f'type=bind,source={ROOT/(subject+"-submission")},target=/source,readonly','--mount',f'type=bind,source={ROOT/("raw-"+variant)},target=/raw,readonly','--mount',f'type=bind,source={ROOT/"run_l04.py"},target=/eval/run_l04.py,readonly','--mount',f'type=bind,source={results},target=/results',IMAGE,'/opt/cpsat/bin/python','-B','/eval/run_l04.py','--source','/source','--raw','/raw','--out','/results/run']
    start=now();p=subprocess.run(argv,capture_output=True,text=True);dump(out/'create-native.json',{'argv':argv,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'started_at':start})
    if p.returncode:raise RuntimeError('container_create_failed')
    cid=p.stdout.strip();dump(out/'launch.json',{'cid':cid,'name':name,'started_at':now(),'source':str(ROOT/(subject+'-submission')),'raw':str(ROOT/('raw-'+variant))})
    t=time.monotonic();p=subprocess.run(['docker','start','--attach',cid],capture_output=True,text=True,encoding='utf-8');(out/'stdout.txt').write_text(p.stdout,encoding='utf-8');(out/'stderr.txt').write_text(p.stderr,encoding='utf-8')
    inspect=subprocess.run(['docker','inspect',cid],capture_output=True,text=True,check=True);(out/'inspect-terminal.json').write_text(inspect.stdout,encoding='utf-8');dump(out/'native-terminal.json',{'exit_code':p.returncode,'finished_at':now(),'wall_seconds':time.monotonic()-t})
    import zipfile
    with zipfile.ZipFile(out/'completed-originals.zip','w',zipfile.ZIP_DEFLATED) as z:
        for file in out.rglob('*'):
            if file.is_file() and file.name!='completed-originals.zip':z.write(file,file.relative_to(out))
        for prefix,path in [('source',ROOT/(subject+'-submission')),('raw',ROOT/('raw-'+variant))]:
            for file in path.rglob('*'):
                if file.is_file():z.write(file,Path(prefix)/file.relative_to(path))
        z.write(ROOT/'run_l04.py','evaluator/run_l04.py')
    q=subprocess.run(['docker','rm',cid],capture_output=True,text=True);dump(out/'cleanup.json',{'argv':['docker','rm',cid],'exit_code':q.returncode,'stdout':q.stdout,'stderr':q.stderr})
    print(json.dumps({'subject':subject,'variant':variant,'exit_code':p.returncode,'stdout':p.stdout,'seconds':time.monotonic()-t}),flush=True)
    return p.returncode
if __name__=='__main__':raise SystemExit(run(*sys.argv[1:3]))
