import json
from pathlib import Path
root=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L04')
machine=[
('M01','真实完整应用执行','四营业链与两明确中止均完成，报告native0；不是自报通过','run/scenario/native'),
('M02','逐来源存量与可用数据库','从原SQLite/authority分类的正确原entry集合、integrity和FK均成立；不靠总额抵消','raw→final SQL'),
('M03','权威客户与别名','每原customer按authority精确映射/展示字段，完整alias raw；同邮箱不同法人不合并','authority/customer_aliases/customers'),
('M04','精确币种金额','逐业务customer/currency/minor/fee严格整数与原十进制相同，零额合法','raw/entries'),
('M05','退款链接与本金','每原退款链接准确，超额组按合同隔离；不能同总额换父单','raw/entries'),
('M06','原文隔离与追踪','每类异常原因/原表主键/完整raw及成功原entry/alias原文一致，不能静默丢行','quarantine/legacy_raw_json'),
('M07','用户批注与读取','原NUL/Unicode/换行逐字保留，新note也持久且真实notes API读到','notes/request/native'),
('M08','不可改迁移史与持续审计','原version1每字段/原audit事件全保，恰一次version2，新业务恰一次审计','schema_migrations/audit_events'),
('M09','完整ACK与幂等收据','全部原/新成功操作逐键逐payload/receipt保存，真实旧receipt查询相符，重试没有新身份','receipts/native'),
('M10','原子切换与明确中止','真实前/后提交故障另一连接分别v1/3与v2/4；稳定身份歧义保原全库并明确中止','checkpoint SQL/exit/retry/ambiguous SQL'),
('M11','两个旧写者跨切换','两个独立原PID实际before_begin跨切换后均stale_epoch4，历史没有其写','native/SQL'),
('M12','新版写语义与真实约束','fee/退款预算/冲突/非法类型/旧epoch/外键等真实响应正确，SQLite合法插入与六具名约束probe成立','requests/constraint-probes'),
('M13','新写进程故障恢复','真实commit前无entry/receipt、后两者均有；原键重试后各恰一次','native/checkpoint/final SQL'),
('M14','恢复决策与继续营业','不把缺新ACK/fee的旧备份覆盖活库；retain_v2完整差集/fee/integrity、保所有表并继续write/get','pre-recover/recovered/final/native'),
('M15','完整读导出与重算交付','实际API余额/九表导出与SQL一致，四场景reconciliation CSV逐字段/分币种对账','API/export/CSV'),
('M16','原输入变化真实执行','同封存programme对base/money/identity三份输入完成真实整链，机器各叶仍按各自raw核算，不能缓存旧答案','registration/raw/three native')]
human=[
('H01','调查与实现解释','完整：以当前原对象解释权威身份/异常/精度/批注/退款组的实际处理、逐原行追踪和版本唯一事实；源码与正文一致。失败：只有通用口号、解释与实际程序冲突或漏核心数据语义。','REPORT.md + actual source/raw/SQL',True),
('H02','故障与回退证据边界','完整：按实际原PID/native/另一连接SQL解释前后故障、幂等和栅栏；明确v1不能表达fee、旧备份缺新ACK、实际前向恢复；声明仅受控进程故障。失败：无证据的全部并发/掉电/任意无损降级/认证保证，或把中止称成功。正确底表不能洗掉错误强结论。','REPORT.md + original events/SQL/recover',True),
('H03','替班运营可执行性','完整：给新维护者具体命令、核对/继续条件与停手条件、未知身份/旧epoch处理、备份与前向修复、收据查证和继续业务。失败：只说安全升级/备份恢复，或命令/顺序会丢已ACK数据。','operations.md + public CLI and actual requests',True),
('H04','实际图与可读对账','完整：实际打开图，轴/币种/最小单位/本金与fee/场景可辨，和原CSV/SQL相符；文字正确说明图范围。完整等价表图形式不按美术风格扣分。失败：缺真实图/错数/单位混币/无法读。','migration.png actual visual + reconciliation CSV',False),
('H05','可复建软件与移交','完整：全部源码/依赖/输入/命令/原执行与错误处理定位，操作者能在新环境运行v1→v2→故障重试→报告；不靠评估器或宿主旧答案。失败：缺声明依赖/关键步骤或仅交结果截图。','submission/source/reproduce.md + native',True)]
leaves=[{'id':i,'weight':5,'critical':True,'assessment':'machine','title':title,'pass':text,'fail':'任一所需真实事实不成立；缺依赖为blocked，未评为unassessed，不改分母','evidence':e} for i,title,text,e in machine]
leaves += [{'id':i,'weight':4,'critical':critical,'assessment':'independent','title':title,'anchors':text,'evidence':e,'formats':'等价完整表/JSON/公式/文字可；不按字数/相同参考措辞/行序判定'} for i,title,text,e,critical in human]
rubric={'case_id':'L04','version':'0.2.0-dev','status':'construction_awaiting_whole_case_review','fixed_denominator':100,'good_rule':{'minimum_score':90,'all_critical':'verified_pass'},'states':['verified_pass','verified_fail','blocked','unassessed'],'half_or_na':False,'leaves':leaves,'limitations':['author development pilot, not professional/statistical maturity','no hour qualification from reference wall time','independent human leaves require external actual-object review; candidate cannot override machine leaves']}
(root/'rubric.json').write_text(json.dumps(rubric,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(root/'public'/'profile.json').write_text(json.dumps({'case_id':'L04','version':'0.2.0-dev','status':'construction_awaiting_whole_case_review','inputs':['app-v1.sqlite','published-v1.sql','identity-authority.json','legacy_app.py','provenance.json','TASK.md','DATA.md','EXECUTION.md','OUTPUTS.md','ENVIRONMENT.md','operations-letter.txt'],'native_dependency':'standard SQLite locally, declared runtime and plot dependency','good_comparison_rule':'score >=90 and every critical leaf passes, fixed before fresh candidates','limits':'not arbitrary downgrade, physical power loss or unrestricted concurrency; no minimum duration'},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'leaves':len(leaves),'sum':sum(x['weight'] for x in leaves)}))
