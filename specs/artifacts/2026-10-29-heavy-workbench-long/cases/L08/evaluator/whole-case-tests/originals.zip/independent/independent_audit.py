"""Review-only: reconstruct raw project facts without importing author modules."""
import csv,json,datetime,zipfile
from pathlib import Path
from fractions import Fraction

R=Path(__file__).parent
B=Path('D:/opencorvus-benchmark-runs/l08-full-case-20261030')
checks=[]
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def rows(p):
 with p.open(encoding='utf-8',newline='') as f:return list(csv.DictReader(f))
def ck(name,a,b=True):
 ok=type(a)==type(b) and a==b
 checks.append({'name':name,'pass':ok,'actual':a,'expected':b})
 if not ok:raise AssertionError(name)
def normalized(rows,key):
 return {x[key]:{k:(sorted(v) if k=='resources' else v) for k,v in x.items()} for x in rows}
def audit(root):
 raw=root/'raw';out=root/'programme/result';tr=load(raw/'treasury.json')
 rates={x['resource']:int(x['daily_cost']) for x in rows(raw/'rates.csv')}
 scope={x['task']:x for x in rows(raw/'scope.csv')}
 modes={}
 for x in rows(raw/'quotes.csv'):
  x={k:(int(v) if k in ['duration','commit_fee','start_fee','lead','earliest'] else v) for k,v in x.items()}
  x['resources']=x['resources'].split(';');x['daily']=sum(rates[r] for r in x['resources'])
  x['cost']=x['commit_fee']+x['start_fee']+x['duration']*x['daily'];modes.setdefault(x['task'],[]).append(x)
 history=[]
 for x in rows(raw/'progress.csv'):
  history.append({k:(int(v) if k in ['start','end','cost'] else v.split(';') if k=='resources' else v) for k,v in x.items()})
 paid=[{k:(int(v) if k in ['day','amount'] else v) for k,v in x.items()} for x in rows(raw/'paid-ledger.csv')]
 past=sum(x['amount'] for x in paid);cash0=tr['initial_cash']-past
 ck(str(root)+':history',normalized(load(out/'history.json'),'task'),normalized(history,'task'))
 ck(str(root)+':paid',normalized(load(out/'paid-ledger.json'),'payment_id'),normalized(paid,'payment_id'))
 ck(str(root)+':past',past,13600);ck(str(root)+':cash0',cash0,7000)
 actual=load(out/'execution.json');plans=load(out/'plans.json');proofs={};summaries={}
 for event in load(raw/'events.json'):
  sid=event['id'];prefix=root.name+'/'+sid;off={(x['resource'],int(x['day'])) for x in rows(raw/'calendar.csv')}|{tuple(x) for x in event['extra_absence']}
  mm={t:[dict(x) for x in ms] for t,ms in modes.items()}
  for t,mode,earliest in [('A08','reserved',event['supplier_earliest']),('CERT','certify',event['cert_release'])]:
   for x in mm[t]:
    if x['mode']==mode:x['earliest']=max(x['earliest'],earliest)
  def legal(x,s):return s>=max(12+x['lead'],x['earliest']) and s+x['duration']<=61 and all((r,d) not in off for d in range(s,s+x['duration']) for r in x['resources'])
  taskrows=plans[sid]['tasks'];tasks={x['task']:x for x in taskrows}
  ck(prefix+':unique',len(tasks),len(taskrows));ck(prefix+':scope',set(tasks)-{'F01'},set(t for t,x in scope.items() if x['mandatory']=='1'))
  occupancy={};expense={};derivedtasks=[]
  for t,x in tasks.items():
   m=next(v for v in mm[t] if v['mode']==x['mode']);s=x['start'];e=x['end'];ck(prefix+'/'+t+':duration',e-s,m['duration']);ck(prefix+'/'+t+':calendar',legal(m,s))
   for d in scope[t]['dependencies'].split(';'):
    if d:ck(prefix+'/'+t+':after-'+d,s>=tasks.get(d,next((h for h in history if h['task']==d),{}))['end'])
   expense[12]=expense.get(12,0)+m['commit_fee'];expense[s]=expense.get(s,0)+m['start_fee']
   for day in range(s,e):
    expense[day]=expense.get(day,0)+m['daily']
    for resource in m['resources']:
     ck(prefix+'/'+t+':capacity-'+resource+'-'+str(day),(resource,day) not in occupancy);occupancy[resource,day]=t
   derivedtasks.append(dict(x,resources=m['resources'],mode_cost=m['cost']))
  if 'F01' in tasks:ck(prefix+':F01-before-C00',tasks['F01']['end']<=tasks['C00']['start'])
  finish=tasks['HANDOFF']['end'];ck(prefix+':end',max(x['end'] for x in taskrows),finish)
  c=cash0;cost=past;ledger=[]
  for day in range(12,finish):
   inflow=(tr['funding']['amount'] if day==tr['funding']['day'] else 0)+(tr['client_milestone']['amount'] if day==tasks['R02']['end']+1 else 0)
   spend=expense.get(day,0)+tr['overhead_per_day'];c+=inflow-spend;cost+=spend;ck(prefix+':cash-'+str(day),c>=0)
   ledger.append(dict(day=day,inflow=inflow,expense=spend,cash_end=c,cumulative_cost=cost))
  expected=dict(scenario=sid,errors=[],tasks=sorted(derivedtasks,key=lambda x:x['task']),cash_ledger=ledger,finish=finish,extension_requested=max(0,finish-33),extension_approved=False,optional_retained='F01' in tasks,total_cost=cost,history=history,paid_ledger=paid,checkpoint_cash=cash0,component_accepted=True)
  ck(prefix+':full-execution',actual[sid],expected);ck(prefix+':budget',cost<=tr['budget_total'])
  # Enumerate a finite relaxation: choose cheapest mandatory modes, relax shared
  # capacities, retain each person's calendar, and prune only by valid cost LB.
  feasible={t:list(v) for t,v in mm.items()};pruned=[]
  while True:
   ends={h['task']:h['end'] for h in history};pending={t for t,x in scope.items() if x['mandatory']=='1'}
   while pending:
    ready=[t for t in pending if all(d in ends for d in scope[t]['dependencies'].split(';') if d)]
    assert ready
    for t in ready:
     lower=max([ends[d] for d in scope[t]['dependencies'].split(';') if d]+[12])
     ends[t]=min(s+m['duration'] for m in feasible[t] for s in range(lower,61) if legal(m,s));pending.remove(t)
   finish_lb=ends['HANDOFF'];fixed=past+sum(min(m['cost'] for m in feasible[t]) for t,x in scope.items() if x['mandatory']=='1')
   remove=[]
   for t,ms in feasible.items():
    for m in ms:
     lower=fixed+m['cost']-(min(v['cost'] for v in ms) if scope[t]['mandatory']=='1' else 0)+100*(finish_lb-12)
     if lower>tr['budget_total']:remove.append((t,m,lower))
   if not remove:break
   for t,m,lower in remove:feasible[t].remove(m);pruned.append(dict(task=t,mode=m['mode'],cost_lower=lower,finish_lower=finish_lb))
  ck(prefix+':matching-independent-bound',finish,finish_lb)
  ck(prefix+':F01',bool(feasible['F01']),'F01' in tasks)
  proofs[sid]=dict(finish=finish_lb,fixed_without_overhead=fixed,ends=ends,pruned=pruned)
  summaries[sid]=dict(finish=finish,cost=cost,mincash=min(x['cash_end'] for x in ledger),optional='F01' in tasks)
 # Manifest independently from actual source eligibility and top fact identities.
 cutoff=datetime.datetime.fromisoformat(load(raw/'release-clock.json')['as_of'].replace('Z','+00:00'));groups={};invalid=[];future=[]
 for x in rows(raw/'release-lines.csv'):
  if not x['tenant'] or not x['item']:invalid.append({'source_id':x['source_id'],'code':'identity'});continue
  if datetime.datetime.fromisoformat(x['released_at'].replace('Z','+00:00'))>cutoff:future.append(x['source_id']);continue
  groups.setdefault((x['tenant'],x['item']),[]).append(x)
 states=[];totals={}
 for (tenant,item),g in sorted(groups.items()):
  rev=max(int(x['revision']) for x in g);top=[x for x in g if int(x['revision'])==rev];payload=set()
  for x in top:
   n=Fraction(x['units']);payload.add((x['status'],int(n) if n>=0 and n.denominator==1 else None))
  if len(payload)>1:status,units='conflict',None
  else:
   s,n=next(iter(payload));status='invalid_units' if n is None else 'withdrawn' if s=='withdrawn' else 'ready';units=0 if status=='withdrawn' else n
  states.append(dict(tenant=tenant,item=item,revision=rev,status=status,units=units,source_ids=sorted(x['source_id'] for x in top)))
  totals[tenant]=totals.get(tenant,0)+(units if status=='ready' else 0)
 expected=dict(states=states,invalid_rows=invalid,excluded_future=future,totals_by_tenant=totals)
 ck(root.name+':manifest-programme',load(out/'manifest.json'),expected);ck(root.name+':manifest-component',load(root/'component/result/manifest.json'),expected)
 # Inspect real mounts / native lifecycle, and directly compare immutable files.
 for part in ['programme','component']:
  info=load(root/part/'inspect.json')[0];ck(root.name+':'+part+'native',info['State']['ExitCode'],0);ck(root.name+':'+part+'network',info['HostConfig']['NetworkMode'],'none')
  ck(root.name+':'+part+'cpu',info['HostConfig']['NanoCpus'],1000000000)
  mounts={x['Destination']:x for x in info['Mounts']};ck(root.name+':'+part+'program-readonly',mounts['/program']['RW'],False);ck(root.name+':'+part+'raw-readonly',mounts['/raw']['RW'],False)
  ck(root.name+':'+part+'only-three-mounts',set(mounts),{'/program','/raw','/results'})
 return dict(summary=summaries,independent_bound=proofs)

if __name__=='__main__':
 result={}
 for variant in ['base','future_quote','new_scope']:result[variant]=audit(B/'main-run'/variant)
 (R/'independent-business-audit.json').write_text(json.dumps(dict(results=result,checks=checks),default=lambda v:sorted(v) if isinstance(v,set) else v,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps(dict(all_pass=all(x['pass'] for x in checks),summaries={k:v['summary'] for k,v in result.items()}),indent=2))
