"""Whole L08 checker from raw facts and real native executions."""
import argparse,csv,json,math
from pathlib import Path
from l08_core import load,save,world,manifest,bound,replay,Candidate,Facility

def exact(a,b):
 if type(a)!=type(b):return False
 if isinstance(a,dict):return a.keys()==b.keys() and all(exact(a[k],b[k]) for k in a)
 if isinstance(a,list):return len(a)==len(b) and all(exact(x,y) for x,y in zip(a,b))
 return a==b
def list_order(a):
 if isinstance(a,dict):return {k:(sorted(v) if k in ('resources','source_ids') and type(v)==list else list_order(v)) for k,v in a.items()}
 if isinstance(a,list):return [list_order(x) for x in a]
 return a
def keyed(items,keys):
 if type(items) is not list:raise Candidate('rows_schema')
 result={}
 for row in items:
  if type(row) is not dict:raise Candidate('row_schema')
  k=tuple(row[x] for x in keys)
  if k in result:raise Candidate('row_duplicate')
  result[k]=row
 return result
def manifest_equal(a,b):
 if type(a)!=dict or a.keys()!=b.keys():return False
 try:
  return exact(list_order(keyed(a['states'],['tenant','item'])),list_order(keyed(b['states'],['tenant','item']))) and exact(keyed(a['invalid_rows'],['source_id']),keyed(b['invalid_rows'],['source_id'])) and exact(sorted(a['excluded_future']),sorted(b['excluded_future'])) and exact(a['totals_by_tenant'],b['totals_by_tenant'])
 except (KeyError,TypeError,Candidate):return False
def normalized_export(file,columns):
 with file.open(encoding='utf-8',newline='') as f:
  r=csv.DictReader(f)
  if r.fieldnames!=columns:raise Candidate('export_schema:'+file.name)
  return list(r)
def assess_variant(info):
 checks={f'M{i:02}':{'pass':True,'evidence':[]} for i in range(1,15)}
 def setcheck(code,ok,evidence):
  checks[code]['pass'] &= bool(ok);checks[code]['evidence'].append(evidence)
 root=Path(info['programme']);component=Path(info['component']);raw=Path(info['raw']);w=world(raw);expected=manifest(raw)
 # Native state comes from captured Docker inspect, not candidate JSON.
 for folder in (root,component):
  inspect=load(folder/'inspect.json');state=inspect[0]['State'];native=load(folder/'native.json')
  setcheck('M01',state['Status']=='exited' and state['ExitCode']==0 and native['exit_code']==state['ExitCode'],{'folder':str(folder),'state':state['Status'],'exit_code':state['ExitCode']})
 result=root/'result';actual_component=load(component/'result/manifest.json') if (component/'result/manifest.json').is_file() else None
 actual_manifest=load(result/'manifest.json') if (result/'manifest.json').is_file() else None
 setcheck('M02',manifest_equal(actual_component,expected) and manifest_equal(actual_manifest,expected),{'expected':expected,'actual_component':actual_component})
 component_ok=manifest_equal(actual_component,expected)
 history=load(result/'history.json');paid=load(result/'paid-ledger.json');plans=load(result/'plans.json');reported=load(result/'execution.json')
 setcheck('M03',exact(list_order(keyed(history,['task'])),list_order(keyed(list(w['history'].values()),['task']))),{'history':history})
 setcheck('M04',exact(keyed(paid,['payment_id']),keyed(w['payments'],['payment_id'])),{'past_cost':w['past_cost'],'checkpoint_cash':w['cash']})
 ids={e['id'] for e in w['events']};setcheck('M05',type(plans)==dict and set(plans)==ids,{'scenario_ids':sorted(plans)})
 setcheck('M13',type(reported)==dict and set(reported)==ids,{'execution_ids':sorted(reported)})
 derived={}
 for e in w['events']:
  p=plans.get(e['id'],{'tasks':[]});a=replay(w,e,p,component_ok);derived[e['id']]=a;codes={x['code'] for x in a['errors']}
  setcheck('M05',not(codes&{'mode_identity','duplicate_task','duration','mandatory_missing','work_after_handoff'}),a['errors'])
  setcheck('M06','calendar_or_release' not in codes,a['errors'])
  setcheck('M07',not(codes&{'dependency','optional_dependency'}),a['errors'])
  setcheck('M08','resource_overlap' not in codes,a['errors'])
  setcheck('M09','cash_negative' not in codes and len(a['cash_ledger'])==a['finish']-12,{'cash_ledger':a['cash_ledger']})
  setcheck('M10','budget' not in codes and a['total_cost'] is not None,{'total_cost':a['total_cost'],'budget':w['treasury']['budget_total']})
  proof,_=bound(w,e)
  setcheck('M11',a['finish']==proof['finish_lower_bound'],{'finish':a['finish'],'relaxed_bound':proof['finish_lower_bound'],'extension_requested':a['extension_requested']})
  setcheck('M12',a['optional_retained']==proof['optional_possible'],{'retained':a['optional_retained'],'possible':proof['optional_possible']})
  # Row order and rational explanations are free; the actual execution facts must be exact integers/bools.
  r=reported.get(e['id'],{})
  if type(r)==dict and isinstance(r.get('tasks'),list) and isinstance(r.get('history'),list) and isinstance(r.get('paid_ledger'),list):
   r=dict(r);want=dict(a)
   for field,key in [('tasks','task'),('history','task'),('paid_ledger','payment_id')]:r[field]=keyed(r[field],[key]);want[field]=keyed(want[field],[key])
   setcheck('M13',exact(list_order(r),list_order(want)),{'scenario':e['id'],'derived':a,'reported':reported[e['id']]})
  else:setcheck('M13',False,{'scenario':e['id'],'error':'execution_schema'})
 schedule=normalized_export(result/'schedule.csv',['scenario','task','mode','start','end','resources']);cash=normalized_export(result/'cash-ledger.csv',['scenario','day','inflow','expense','cash_end','cumulative_cost'])
 expected_schedule=[];expected_cash=[]
 for sid,a in derived.items():
  for row in a['tasks']:expected_schedule.append({k:str(v) for k,v in dict(scenario=sid,task=row['task'],mode=row['mode'],start=row['start'],end=row['end'],resources=';'.join(row['resources'])).items()})
  for row in a['cash_ledger']:expected_cash.append({k:str(v) for k,v in dict(scenario=sid,**row).items()})
 for row in schedule+expected_schedule:row['resources']=';'.join(sorted(row['resources'].split(';')))
 setcheck('M14',exact(keyed(schedule,['scenario','task']),keyed(expected_schedule,['scenario','task'])) and exact(keyed(cash,['scenario','day']),keyed(expected_cash,['scenario','day'])),{'schedule_rows':len(schedule),'cash_rows':len(cash)})
 return checks
def grade(run,rubric_path,out,review=None,role='candidate'):
 rubric=load(rubric_path);registry=load(run/'runs.json');findings={};variants={}
 for variant,info in registry['runs'].items():
  try:variants[variant]=assess_variant(info)
  except Facility:raise
  except (Candidate,ValueError,KeyError,TypeError,FileNotFoundError,IndexError) as ex:
   # Whole-case missing/schema errors are candidate delivery failures, with retained native evidence.
   variants[variant]={f'M{i:02}':{'pass':False,'evidence':[{'code':'candidate_delivery_invalid','detail':str(ex)}]} for i in range(1,15)}
 for i in range(1,15):
  leaf=f'M{i:02}';passed=all(a[leaf]['pass'] for a in variants.values())
  findings[leaf]={'status':'pass' if passed else 'fail','evidence':{v:a[leaf] for v,a in variants.items()}}
 transformations=set(variants)=={'base','future_quote','new_scope'}
 findings['M15']={'status':'pass' if transformations and all(all(a[k]['pass'] for k in a) for a in variants.values()) else 'fail','evidence':'same sealed programme executed on original source, a changed uncommitted quote and new mandatory tenant scope; all business predicates required'}
 trusted=None
 if review:
  trusted=load(review)
  if Path(trusted['run_root']).resolve()!=run.resolve() or trusted.get('role')!='independent_evaluator' or set(trusted['ratings'])!={f'H{i:02}' for i in range(1,6)}:raise Facility('review_binding')
 for i in range(1,6):
  key=f'H{i:02}';r=trusted['ratings'][key] if trusted else {'status':'unassessed','evidence':'actual whole-case independent review pending'}
  if r['status'] not in ('pass','fail','unassessed') or not isinstance(r.get('evidence'),str):raise Facility('review_rating')
  findings[key]=r
 unassessed=[k for k,v in findings.items() if v['status']=='unassessed'];score=sum(x['weight'] for x in rubric['leaves'] if findings[x['id']]['status']=='pass')
 critical_failed=[x['id'] for x in rubric['leaves'] if x['critical'] and findings[x['id']]['status']=='fail']
 total=None if unassessed else score;good=None if total is None else total>=rubric['good_minimum'] and not critical_failed
 report={'role':role,'run_root':str(run.resolve()),'case':rubric['case'],'total':total,'good':good,'business_success':None if unassessed else not critical_failed,'critical_failed':critical_failed,'unassessed':unassessed,'findings':findings,'limitations':'author reference and nonblind AI review are not a model candidate score, professional certification or effective-hour evidence' if role=='reference_qualification' else 'candidate score under development-pilot contract; effective hours separate'}
 save(out,report);return 4 if unassessed else (0 if good else 2)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--run',required=True,type=Path);p.add_argument('--rubric',required=True,type=Path);p.add_argument('--out',required=True,type=Path);p.add_argument('--review',type=Path);p.add_argument('--role',choices=['candidate','reference_qualification','error_control'],default='candidate');a=p.parse_args()
 try:raise SystemExit(grade(a.run,a.rubric,a.out,a.review,a.role))
 except Facility as e:save(a.out,{'status':'run_invalid','facility_error':str(e),'total':None,'good':None});raise SystemExit(3)
