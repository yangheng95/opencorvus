import argparse,json,sys,subprocess,shutil
from pathlib import Path
import l08_reference as reference
from l08_core import save,load
MODE='legacy_component'
p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--component-only',action='store_true');a=p.parse_args()
if a.component_only:
 a.out.mkdir(parents=True)
 if MODE=='legacy_component':
  subprocess.run([sys.executable,str(a.source/'legacy_manifest.py'),str(a.source/'release-lines.csv'),str(a.out/'manifest.json')],check=True)
 else:save(a.out/'manifest.json',reference.manifest(a.source))
else:
 if MODE=='cached':shutil.copytree(Path('cached-output'),a.out)
 else:reference.deliver(a.source,a.out,MODE=='weak_report')
 if MODE=='changed_history':
  v=load(a.out/'history.json');v[0]['start']=1;save(a.out/'history.json',v)
 if MODE=='refund_sunk':
  v=load(a.out/'paid-ledger.json');v=[x for x in v if x['payment_id']!='P04'];save(a.out/'paid-ledger.json',v)
 if MODE=='resource_overlap':
  plans=load(a.out/'plans.json')
  for s,v in plans.items():
   t={x['task']:x for x in v['tasks']};x=t['A02'];duration=x['end']-x['start'];x['start']=t['A01']['start'];x['end']=x['start']+duration
  save(a.out/'plans.json',plans)
 if MODE=='false_approval':
  v=load(a.out/'execution.json')
  for x in v.values():x['extension_approved']=True
  save(a.out/'execution.json',v)
