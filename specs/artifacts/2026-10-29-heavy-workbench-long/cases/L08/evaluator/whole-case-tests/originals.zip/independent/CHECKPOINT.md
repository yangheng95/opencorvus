# L08 whole-case checkpoint

Independent raw business reconstruction and source-only cold replay are complete. Initial five content ratings are recorded in initial-review.json; weak report H02 fails on its actual false guarantee. No content score is hand-written.

Blocking B01: deleting only cash-ledger.csv from a copied correct result turns all M01–M14 into fail, including captured native0/history/manifest. Exact original probe/assessment is under partial-cash-export. The current variant-wide exception handler destroys leaf-local evidence. Preserve independent readable facts, isolate required output failure to actual dependent leaves, retain real native evidence. No second business/mathematical blocker identified.

Source snapshot case-initial is unchanged. Current stage cannot freeze until B01 is corrected and the same original mutation actually rechecked. No more Docker/native matrix needed.
