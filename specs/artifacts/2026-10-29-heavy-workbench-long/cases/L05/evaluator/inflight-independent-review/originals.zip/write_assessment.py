import json
from pathlib import Path
import subprocess
ROOT=Path(__file__).resolve().parent
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
probe=load(ROOT/'operator-probes.json');sql=load(ROOT/'independent-SQL-audit.json')
result={'stage':'controlled_inflight_reachable_shutdown_contract_blocked','blocking':[{'id':'B01','priority':'P1','source':'source/public/l05_effects.py:223,238-241','contract':'stdin EOF/stop releases held HTTP and naturally joins real request execution','observed':'receiver exit0 while real application waited on an owned SQLite lock; client ConnectionResetError10054; empty final effect/request tables','evidence':'eof-held-probe/result.json','repair':'Join actual finite request lifecycles after releasing hold; govern body reads if all handlers are joined; recheck exact original probe'}],
 'cold_runs':load(ROOT/'cold-run-receipts.json'),'sql_checks':sql['count'],'sql_all_passed':sql['all_passed'],'eof_probe':probe['eof']['status'],'fresh_drop_probe':probe['drop']['status'],
 'all_owned_probe_receivers_naturally_exited':all(v['receiver_exit_code']==0 for v in probe.values()),'no_source_changes':True,'no_Provider_solver_GPU_Docker_UI':True,'delegations':0,
 'accepted_scope':['single actual held before-apply POST crossing local pause/reconcile/resume and late200same-receipt replay','no-hold original scene regression after shared primitive extraction','independent per-source SQL/receipt and stable original facts','fresh commit/drop/get/replay'],
 'not_approved':['graceful EOF/stop request completion pending B01 repair','all concurrent/crash/restart interleavings','logical-export freedom','complete professional task/rubric/freeze','hours or ten-case maturity'],'candidate_score':None}
save(ROOT/'stage-assessment.json',result)
status=subprocess.run(['git','status','--short'],cwd='D:/myhexin-local/opencorvus',capture_output=True,text=True,encoding='utf-8');(ROOT/'git-status-end.txt').write_text(status.stdout,encoding='utf-8')
print(json.dumps({'stage':result['stage'],'blocking_ids':[r['id'] for r in result['blocking']],'sql_checks':sql['count'],'own_cold_runs':2},ensure_ascii=False))
