"""One actual default-start/POST/stop contract for the final constant extraction."""
import ast
from datetime import datetime,timezone
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import time
import urllib.request

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'source/public/l05_effects.py'
CURRENT=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L05/public/l05_effects.py')
PREVIOUS=ROOT.parent/'source-repaired-final/public/l05_effects.py'
PYTHON='C:/Python314/python.exe'
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')

def main():
    tree=ast.parse(SOURCE.read_text(encoding='utf-8'));constants={}
    for n in tree.body:
        if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ('DEFAULT_READ_TIMEOUT_SECONDS','MAX_READ_TIMEOUT_SECONDS'):
            constants[n.targets[0].id]=ast.literal_eval(n.value)
    assert constants=={'DEFAULT_READ_TIMEOUT_SECONDS':20,'MAX_READ_TIMEOUT_SECONDS':60}
    class Inline(ast.NodeTransformer):
        def visit_Name(self,node):
            return ast.copy_location(ast.Constant(constants[node.id]),node) if node.id in constants else node
    tree.body=[n for n in tree.body if not (isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id in constants)]
    equivalent=ast.dump(Inline().visit(tree),include_attributes=False)==ast.dump(ast.parse(PREVIOUS.read_text(encoding='utf-8')),include_attributes=False)
    assert equivalent and SOURCE.read_bytes()==CURRENT.read_bytes()
    argv=[PYTHON,'-X','utf8','-B',str(SOURCE),'--db',str(ROOT/'remote.sqlite')]
    started=datetime.now(timezone.utc).isoformat();clock=time.perf_counter();err=(ROOT/'receiver.stderr.txt').open('w',encoding='utf-8')
    receiver=subprocess.Popen(argv,cwd=ROOT,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,text=True,encoding='utf-8',env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1'})
    receipt={};response=None;ready=None;ready_line='';remaining=''
    try:
        ready_line=receiver.stdout.readline();ready=json.loads(ready_line)
        assert ready['status']=='ready' and ready['pid']==receiver.pid and ready['read_timeout_seconds']==20
        wire={'tenant':'Config','event_id':'final-default','kind':'post','amount_minor':23,'reverses':None}
        request=urllib.request.Request(ready['url']+'/effects',data=json.dumps(wire).encode('utf-8'),headers={'Content-Type':'application/json'})
        with urllib.request.urlopen(request,timeout=5) as result:response={'http_code':result.status,'body':json.loads(result.read())}
        assert response['http_code']==201 and response['body']['status']=='applied'
        rid=response['body']['receipt']['receipt_id']
        with sqlite3.connect(ROOT/'remote.sqlite') as c:
            c.row_factory=sqlite3.Row
            effects=[dict(r) for r in c.execute('SELECT * FROM effects')]
            requests=[dict(r) for r in c.execute('SELECT * FROM requests')]
        assert len(effects)==1 and all(effects[0][k]==v for k,v in wire.items()) and effects[0]['receipt_id']==rid
        assert len(requests)==1 and requests[0]['status']=='applied' and requests[0]['receipt_id']==rid
    finally:
        if receiver.poll() is None:
            receiver.stdin.write('stop\n');receiver.stdin.flush()
        remaining,_=receiver.communicate(timeout=10);err.close()
        (ROOT/'receiver.stdout.txt').write_text(ready_line+remaining,encoding='utf-8')
        save(ROOT/'receiver-terminal.json',{'pid':receiver.pid,'exit_code':receiver.returncode,'seconds':time.perf_counter()-clock,'owned_process_only':True,'normal_operator_stop':True})
    assert receiver.returncode==0
    result={'status':'final_constant_configuration_positive_contract_passed','argv':argv,'started_utc':started,'seconds':time.perf_counter()-clock,'pid':receiver.pid,'exit_code':receiver.returncode,
      'constants':constants,'only_constant_extraction_AST_after_inline':equivalent,'snapshot_current_bytes_equal_before_and_after':SOURCE.read_bytes()==CURRENT.read_bytes(),'ready':ready,'HTTP':response,'effects':effects,'requests':requests,
      'new_receivers':1,'new_HTTP_POSTs':1,'old_EOF_body_cold_SQL_suites_repeated':False,'not_a_new_benchmark_sample':True}
    save(ROOT/'configuration-contract.json',result)
    save(ROOT/'final-source-identity.json',{'current':str(CURRENT),'executed_snapshot':str(SOURCE),'bytes':SOURCE.stat().st_size,'direct_byte_equal_at_finish':SOURCE.read_bytes()==CURRENT.read_bytes(),'previous_repair_snapshot':str(PREVIOUS),'previous_tests_did_not_execute_final_bytes':True,'relation':'exact AST after inlining named20/60 constants and removing their declarations; one fresh actual default/POST/stop test on final bytes'})
    print(json.dumps({'status':result['status'],'ready_default':ready['read_timeout_seconds'],'HTTP':response['http_code'],'exit_code':receiver.returncode,'seconds':result['seconds']},ensure_ascii=False))
if __name__=='__main__':main()
