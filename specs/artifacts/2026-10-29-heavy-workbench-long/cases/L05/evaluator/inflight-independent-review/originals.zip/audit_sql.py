"""Independent read-only SQL and issued-fact reconstruction; no HTTP or model."""
import ast
from collections import defaultdict
from contextlib import closing
import json
from pathlib import Path
import sqlite3
import time
ROOT=Path(__file__).resolve().parent
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
old=Path('D:/opencorvus-benchmark-runs/l05-scene-independent-review-20261030/independent_audit.py')
text=old.read_text(encoding='utf-8');tree=ast.parse(text)
names=['read','snapshot','target','sources','account'];nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
(ROOT/'independent-sql-primitives.py').write_text('\n\n'.join(ast.get_source_segment(text,n) for n in nodes)+'\n',encoding='utf-8')
exec(compile(ast.Module(body=nodes,type_ignores=[]),'independent_sql_primitives','exec'),globals())
start=time.perf_counter();initial=load(ROOT/'input/initial-authority.json');original=snapshot(ROOT/'input/original-local.sqlite');original_effects=read(ROOT/'input/original-remote.sqlite','effects')
expected=json.loads(json.dumps(initial))
for seq,e in enumerate(load(ROOT/'input/future-events.json'),8):expected['journal'].append({'seq':seq,**e,'payload':json.dumps(e,sort_keys=True,ensure_ascii=False,separators=(',',':'))})
expected['adjustments'].append({'tenant':'A','adjustment_id':'approved-2','amount_minor':-5,'approval':'approval-A2'})
expected['notes'].append({'tenant':'B','note_id':'new-note','body':'After repair: retain evidence'})
checks=[]
def check(name,ok,detail=None):checks.append({'name':name,'passed':bool(ok),'detail':detail})
for table in ['journal','opening','adjustments','notes']:check('raw_authority_'+table,original[table]==initial[table])
check('initial_target_from_accepted_facts',account(sources(initial))=={'A':1015,'B':710})
check('future_target_from_issued_events',account(sources(expected))=={'A':1130,'B':510})
results=[]
for label,folder,authority in [('main_inflight',ROOT/'main-originals/main-interleaving',initial),('independent_inflight',ROOT/'cold-inflight',initial),('independent_no_hold',ROOT/'cold-no-hold',expected)]:
    local=snapshot(folder/'local.sqlite');effects=read(folder/'remote.sqlite','effects');requests=read(folder/'remote.sqlite','requests')
    check(label+'.authority',load(folder/'authority.json')==authority)
    for table in ['journal','opening','adjustments','notes']:check(label+'.accepted_preserved_'+table,local[table]==authority[table])
    projection={(r['tenant'],r['event_id']):(r['revision'],r['status'],r['amount_minor']) for r in local['projection']}
    check(label+'.highest_revision_projection',projection==target(authority['journal']))
    check(label+'.control',local['control']==[{'id':1,'epoch':2,'active':1}])
    check(label+'.note_full_NUL',local['notes'][0]['body']=='核对原收据\x00保留原文')
    postings={(r['tenant'],r['event_id']):r for r in local['postings']};wire={(r['tenant'],r['event_id']):r for r in effects};contribution=defaultdict(int)
    check(label+'.exact_unique_joint_identity_coverage',len(postings)==len(local['postings'])==len(wire)==len(effects) and postings.keys()==wire.keys())
    boundary_max=max(r['seq'] for r in authority['journal']);originalmax=7;parentlinks=[]
    for key,r in postings.items():
        payload=json.loads(r['payload']);actual=wire[key]
        check(label+'.wire_receipt.'+r['event_id'],set(payload)=={'tenant','event_id','kind','amount_minor','reverses'} and all(actual[k]==v for k,v in payload.items()) and actual['receipt_id']==r['receipt_id'])
        check(label+'.epoch_boundary.'+r['event_id'],type(r['boundary_seq']) is int and type(r['epoch']) is int and (r['epoch']==1 and 0<=r['boundary_seq']<=originalmax or r['epoch']==2 and originalmax<=r['boundary_seq']<=boundary_max))
        if r['source_kind']=='business':check(label+'.business_acceptance_before_intent.'+r['event_id'],any(j['tenant']==r['tenant'] and j['event_id']==r['source_id'] and j['seq']<=r['boundary_seq'] for j in authority['journal']))
        contribution[r['tenant'],r['source_kind'],r['source_id']]+=payload['amount_minor']
        if payload['kind']=='reversal':
            parent=wire[r['tenant'],payload['reverses']]
            check(label+'.same_tenant_positive_parent.'+r['event_id'],parent['kind']=='post' and parent['amount_minor']>0)
            parentlinks.append({'tenant':r['tenant'],'source':[r['source_kind'],r['source_id']],'funding_source':[postings[r['tenant'],payload['reverses']]['source_kind'],postings[r['tenant'],payload['reverses']]['source_id']]})
    desired=sources(authority)
    check(label+'.per_source_exact',all(contribution.get(k,0)==v for k,v in desired.items()) and set(contribution)<=set(desired),[{'source':k,'actual':contribution.get(k,0),'desired':v} for k,v in desired.items()])
    accounts={t:sum(r['amount_minor'] for r in effects if r['tenant']==t) for t in ['A','B']}
    check(label+'.accounts',accounts==account(desired),accounts)
    for oldr in original['postings']:
        r=postings[oldr['tenant'],oldr['event_id']]
        check(label+'.original_posting_immutable.'+oldr['event_id'],all(r[k]==v for k,v in oldr.items() if k!='receipt_id') and (oldr['receipt_id'] is None or r['receipt_id']==oldr['receipt_id']))
    check(label+'.original_effect_receipts_immutable',all(wire[r['tenant'],r['event_id']]==r for r in original_effects))
    for r in effects:
        if r['kind']=='post':check(label+'.cumulative_reversal.'+r['event_id'],r['amount_minor']+sum(v['amount_minor'] for v in effects if v['tenant']==r['tenant'] and v['kind']=='reversal' and v['reverses']==r['event_id'])>=0)
    if 'inflight' in label:
        trace=load(folder/'interleaving.json');tenant,key=trace['held']['identity'];receipt=trace['settled']['response']['receipt']
        check(label+'.captured_complete_old_intents',trace['pause']['intent_keys']==[{k:r[k] for k in ('tenant','event_id','payload')} for r in original['postings']] and trace['pause']['accepted_boundary']==7)
        check(label+'.actual_hold_then_release',trace['held']['status']=='held_before_apply' and trace['held']['time_ns']<trace['released']['time_ns']<trace['settled']['time_ns'])
        check(label+'.late_wire_effect_stable',trace['settled']['http_code']==200 and trace['settled']['response']['status']=='replayed' and trace['old_sender']['exitcode']==0 and json.loads(trace['old_sender']['stdout'])['receipt']==receipt and receipt['receipt_id']==wire[tenant,key]['receipt_id'])
        check(label+'.SQL_applied_then_late_replayed',[(r['status'],r['receipt_id']) for r in requests if r['tenant']==tenant and r['event_id']==key and r['method']=='POST']==[('applied',receipt['receipt_id']),('replayed',receipt['receipt_id'])])
        check(label+'.guard_responses',trace['new_request']=={'status':'paused','epoch':1} and trace['accepted_retry']=={'status':'duplicate','seq':1} and trace['unresolved_resume']=={'status':'unsettled_intents','count':2} and trace['resume']=={'status':'resumed','epoch':2} and trace['old_epoch_after_resume']=={'status':'stale_epoch','epoch':2})
        check(label+'.owned_receiver_terminal',load(folder/'receiver-exit.json')['exitcode']==0)
    results.append({'label':label,'accounts':accounts,'postings':len(postings),'per_source':[{'source':k,'amount':v} for k,v in contribution.items()],'funding_links':parentlinks,'requests':requests})
result={'scope':'three saved original/cold results; independent read-only source/account/receipt SQL; no matching posting IDs or graph counts as an acceptance rule','count':len(checks),'all_passed':all(c['passed'] for c in checks),'failed':[c['name'] for c in checks if not c['passed']],'checks':checks,'audit_results':results,'seconds':time.perf_counter()-start}
save(ROOT/'independent-SQL-audit.json',result)
print(json.dumps({k:v for k,v in result.items() if k not in ('checks','audit_results')},ensure_ascii=False))
