"""Actual finite half-body/EOF-short-body/idle-connection tests of final receiver."""
import importlib.util
import json
from pathlib import Path
import socket
import time
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('owned_probe_helpers',ROOT/'probe_operator_repaired.py');helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
helper.SOURCE=ROOT/'source-repaired-final/public/l05_effects.py'
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def raw(url,payload,close_write=False):
    from urllib.parse import urlsplit
    u=urlsplit(url);started=time.perf_counter();chunks=[]
    with socket.create_connection((u.hostname,u.port),timeout=5) as client:
        client.settimeout(5);client.sendall(payload)
        if close_write:client.shutdown(socket.SHUT_WR)
        while True:
            block=client.recv(65536)
            if not block:break
            chunks.append(block)
    data=b''.join(chunks);header,body=data.split(b'\r\n\r\n',1)
    return {'http_code':int(header.split(b' ',2)[1]),'body':json.loads(body),'response_latin1':data.decode('latin1'),'seconds':time.perf_counter()-started}
def main():
    folder=ROOT/'final-read-boundaries'
    p,err,pump,q,events,db,url=helper.spawn(folder,['--read-timeout-seconds','1'])
    result={};client=None
    wire={'tenant':'B','event_id':'body','kind':'post','amount_minor':42,'reverses':None};body=json.dumps(wire).encode()
    try:
        header=b'POST /effects HTTP/1.1\r\nHost: localhost\r\nContent-Type: application/json\r\nContent-Length: '+str(len(body)).encode()+b'\r\nConnection: close\r\n\r\n'
        half=raw(url,header+body[:len(body)//2]);assert half['http_code']==408 and half['body']=={'status':'request_timeout'}
        shortheader=header.replace(b'Content-Length: '+str(len(body)).encode(),b'Content-Length: '+str(len(body)+1).encode())
        short=raw(url,shortheader+body,True);assert short['http_code']==422 and short['body']=={'status':'invalid_request','field':'body_length'}
        valid=helper.request(url+'/effects',wire);assert valid['http_code']==201 and valid['body']['status']=='applied'
        from urllib.parse import urlsplit
        u=urlsplit(url);client=socket.create_connection((u.hostname,u.port),timeout=5);client.settimeout(5)
        # A barrier GET completes on the same owned listener after this TCP
        # connection is established. Keep the first socket totally idle.
        barrier=helper.request(url+'/effects?tenant=B&event_id=body');assert barrier['http_code']==200
        p.stdin.close();p.stdin=None
        start=time.perf_counter();p.wait(timeout=5);shutdown_seconds=time.perf_counter()-start
        idle=client.recv(1024);client.close();client=None;pump.join(timeout=5)
        if pump.is_alive():raise RuntimeError('owned_event_pump_unsettled')
        rows=helper.tables(db)
        assert p.returncode==0 and len(rows['effects'])==1 and rows['effects'][0]['amount_minor']==42 and idle==b''
        result={'status':'finite_reads_and_real_join_confirmed','receiver_pid':p.pid,'receiver_exitcode':p.returncode,'half_body':half,'EOF_short_body':short,'valid_complete_body':valid,'idle_barrier_GET':barrier,'idle_connection_eof_bytes':len(idle),'shutdown_with_idle_connection_seconds':shutdown_seconds,'tables_final':rows,'events':events,'read_timeout_seconds':1,'no_sleep_mock_or_production':True}
        save(folder/'result.json',result)
    finally:
        if client is not None:client.close()
        if p.poll() is None:
            if p.stdin is not None:p.stdin.close();p.stdin=None
            p.wait(timeout=10)
        pump.join(timeout=5);err.close();save(folder/'events-final.json',events)
    print(json.dumps({'status':result['status'],'half_body_HTTP':result['half_body']['http_code'],'short_body_HTTP':result['EOF_short_body']['http_code'],'idle_shutdown_seconds':result['shutdown_with_idle_connection_seconds'],'receiver_exitcode':p.returncode},ensure_ascii=False))
if __name__=='__main__':main()
