"""Bind necessary boundary execution snapshots to the final current source."""
import ast
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
CASE=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L05')
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def tree_functions(p):
    tree=ast.parse(p.read_text(encoding='utf-8'))
    return {n.name:ast.dump(n,include_attributes=False) for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
old=tree_functions(ROOT/'source/public/l05_effects.py');new=tree_functions(ROOT/'source-repaired-final/public/l05_effects.py')
business_names=['Invalid','identity','validate','unique_object','finite_constant','decode','connect','initialize','record','receipt','apply','query']
unchanged={n:old[n]==new[n] for n in business_names}
source_facts=[]
for rel in ['public/l05_effects.py','evaluator/current-source/l05_worker.py','evaluator/scene-source/scene_app.py','evaluator/scene-source/run_scene.py','evaluator/scene-source/check_scene.py','evaluator/scene-source/qualify_inflight.py']:
    snap=ROOT/('source-repaired-final' if rel=='public/l05_effects.py' else 'source')/rel
    source_facts.append({'file':rel,'snapshot':str(snap),'bytes':snap.stat().st_size,'current_bytes_equal':snap.read_bytes()==(CASE/rel).read_bytes()})
eof=load(ROOT/'repaired-eof-held-probe/result.json');bound=load(ROOT/'final-read-boundaries/result.json');drop=load(ROOT/'repaired-fresh-drop-probe/result.json')
observed={'original_EOF_same_real_lock_repaired':eof['status']=='terminal_application_confirmed' and eof['receiver_exited_while_own_DB_lock_held'] is None and eof['receiver_exit_code']==0 and eof['client_result']['http_code']==201 and len(eof['tables_final']['effects'])==1,
 'fresh_unknown_ACK_stable_receipt':drop['status']=='fresh_commit_drop_get_replay_confirmed' and drop['receiver_exit_code']==0,
 'half_body_explicit408':bound['half_body']['http_code']==408 and bound['half_body']['body']=={'status':'request_timeout'},
 'EOF_short_body_explicit422':bound['EOF_short_body']['http_code']==422 and bound['EOF_short_body']['body']=={'status':'invalid_request','field':'body_length'},
 'complete_body_actual201':bound['valid_complete_body']['http_code']==201,
 'idle_connection_natural_join':bound['idle_connection_eof_bytes']==0 and bound['receiver_exitcode']==0 and bound['shutdown_with_idle_connection_seconds']<5}
result={'source_identity':source_facts,'business_primitives_unchanged_AST':unchanged,'repaired_behavior_checks':observed,'all_functional_checks_passed':all(unchanged.values()) and all(observed.values()) and all(r['current_bytes_equal'] for r in source_facts),
 'one_line_after_EOF_drop_tests':'removed stdout print from expire_read callback only; final half/short/valid/idle tests ran final source; original EOF/drop not pointlessly repeated',
 'scope':'functional cleanup repair and one controlled inflight qualification; not complete L05','old_failures_retained':True}
(ROOT/'final-source-and-repair-checks.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'all_functional_checks_passed':result['all_functional_checks_passed'],'business_primitives':len(unchanged),'sources':len(source_facts),'behavior_checks':len(observed)},ensure_ascii=False))
