def read(db,table):
    with closing(sqlite3.connect(db.resolve().as_uri()+'?mode=ro',uri=True)) as c:
        c.row_factory=sqlite3.Row
        return [dict(row) for row in c.execute('SELECT * FROM '+table)]

def snapshot(db):
    return {table:read(db,table) for table in ['journal','opening','adjustments','notes','projection','postings','control']}

def target(journal):
    rows=defaultdict(list)
    for row in journal:
        rows[row['tenant'],row['event_id']].append(row)
    result={}
    for key, group in rows.items():
        rev=max(row['revision'] for row in group)
        payloads={(row['kind'],row['amount_minor']) for row in group if row['revision']==rev}
        result[key]=(rev,'quarantined',0) if len(payloads)>1 else (rev,*next(iter(payloads)))
    return result

def sources(authority):
    result={(r['tenant'],'opening','opening'):r['amount_minor'] for r in authority['opening']}
    result.update({(tenant,'business',event):state[2] for (tenant,event),state in target(authority['journal']).items()})
    result.update({(r['tenant'],'adjustment',r['adjustment_id']):r['amount_minor'] for r in authority['adjustments']})
    return result

def account(source):
    result=defaultdict(int)
    for (tenant,kind,key),amount in source.items(): result[tenant]+=amount
    return dict(result)
