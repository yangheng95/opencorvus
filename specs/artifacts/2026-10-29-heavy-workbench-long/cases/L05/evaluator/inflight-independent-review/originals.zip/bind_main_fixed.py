"""Read/copy already-completed parent compatibility evidence; starts no process."""
import json
from pathlib import Path
import shutil
ROOT=Path(__file__).resolve().parent
BASE=Path('D:/opencorvus-benchmark-runs/l05-inflight-qualification-20261030')
OUT=ROOT/'main-fixed-binding';OUT.mkdir(exist_ok=False)
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for name in ['fixed-command.json']:
    shutil.copy2(BASE/name,OUT/name)
for name in ['result.json','interleaving.json','receiver-events.json','receiver-exit.json','receiver-start.json','receiver.stderr.txt']:
    shutil.copy2(BASE/'main-fixed'/name,OUT/name)
identity=[]
for p in (BASE/'source-fixed').rglob('*.py'):
    rel=p.relative_to(BASE/'source-fixed');expected=ROOT/('source-repaired-final' if str(rel).replace('\\','/')=='public/l05_effects.py' else 'source')/rel
    identity.append({'path':str(rel),'same_reviewed_bytes':p.read_bytes()==expected.read_bytes()})
r=load(OUT/'result.json');x=load(OUT/'interleaving.json');key=x['held']['identity'];receipt=x['settled']['response']['receipt']
checks={'source6_exact_reviewed':len(identity)==6 and all(row['same_reviewed_bytes'] for row in identity),'natural_parent_command_exit0':load(OUT/'fixed-command.json')['exitcode']==0,
 'initial_target_and_explicit_scope':r['accounts']=={'A':1015,'B':710} and r['status']=='business_success' and r['candidate_score'] is None,
 'same_receipt_actual_late_replayed':x['settled']['http_code']==200 and x['settled']['response']['status']=='replayed' and json.loads(x['old_sender']['stdout'])['receipt']==receipt,
 'durable_request_applied_replayed':[(v['status'],v['receipt_id']) for v in x['requests_after'] if v['method']=='POST']==[('applied',receipt['receipt_id']),('replayed',receipt['receipt_id'])],
 'owned_terminal_receiver_and_sender':load(OUT/'receiver-exit.json')['exitcode']==0 and x['old_sender']['exitcode']==0,
 'pause_full5_boundary7':len(x['pause']['intent_keys'])==5 and x['pause']['accepted_boundary']==7 and x['resume']=={'status':'resumed','epoch':2}}
save(OUT/'read-only-binding.json',{'scope':'parent supplied actual compatibility recheck only; not a new independent cold or full204SQL rerun','checks':checks,'all_passed':all(checks.values()),'source_identity':identity,'inner_seconds':r['elapsed_seconds'],'reviewer_new_HTTP_or_process_runs':0,'full_L05_or_hours':False})
print(json.dumps({'all_passed':all(checks.values()),'checks':len(checks),'inner_seconds':r['elapsed_seconds']},ensure_ascii=False))
