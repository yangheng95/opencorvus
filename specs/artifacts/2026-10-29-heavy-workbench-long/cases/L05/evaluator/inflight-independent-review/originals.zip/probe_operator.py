"""Owned real HTTP probes: EOF of held request under a real DB lock, and fresh ACK loss."""
from datetime import datetime,timezone
import http.client
import json
import os
from pathlib import Path
import queue
import sqlite3
import subprocess
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'source/public/l05_effects.py'
PYTHON='C:/Python314/python.exe'
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def request(url,wire=None):
    data=None if wire is None else json.dumps(wire).encode()
    try:
        with urllib.request.urlopen(urllib.request.Request(url,data=data,headers={'Content-Type':'application/json'}),timeout=10) as response:
            return {'http_code':response.status,'body':json.loads(response.read())}
    except urllib.error.HTTPError as e:return {'http_code':e.code,'body':json.loads(e.read())}
    except Exception as e:return {'transport_error':type(e).__name__,'message':str(e)}
def spawn(folder,extra):
    folder.mkdir()
    db=folder/'remote.sqlite';argv=[PYTHON,'-X','utf8','-B',str(SOURCE),'--db',str(db),*extra]
    err=(folder/'stderr.txt').open('w',encoding='utf-8')
    p=subprocess.Popen(argv,cwd=ROOT,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,text=True,encoding='utf-8',env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1'})
    q=queue.Queue();events=[]
    def capture():
        for line in p.stdout:
            event=json.loads(line);events.append(event);q.put(event)
    pump=threading.Thread(target=capture);pump.start();ready=q.get(timeout=10)
    assert ready['status']=='ready' and ready['pid']==p.pid
    save(folder/'launch.json',{'argv':argv,'pid':p.pid,'ready':ready,'owned':True})
    return p,err,pump,q,events,db,ready['url']
def tables(db):
    with sqlite3.connect(db) as c:
        c.row_factory=sqlite3.Row
        return {n:[dict(r) for r in c.execute('SELECT * FROM '+n)] for n in ('effects','requests','drop_once')}

def eof_probe():
    folder=ROOT/'eof-held-probe'
    p,err,pump,q,events,db,url=spawn(folder,['--hold-once','Q/held'])
    client=None;lock=None;result={};answer=queue.Queue();start=time.perf_counter()
    wire={'tenant':'Q','event_id':'held','kind':'post','amount_minor':33,'reverses':None}
    try:
        client=threading.Thread(target=lambda:answer.put(request(url+'/effects',wire)));client.start()
        held=q.get(timeout=10);assert held['status']=='held_before_apply'
        lock=sqlite3.connect(db,isolation_level=None);lock.execute('BEGIN IMMEDIATE')
        # Closing operator input is the documented graceful EOF path. The lock
        # makes actual apply wait; no mock, patch, periodic bump or sleep is used.
        p.stdin.close();p.stdin=None
        terminal_before_unlock=None
        try:terminal_before_unlock=p.wait(timeout=2)
        except subprocess.TimeoutExpired:pass
        before=tables(db)
        lock.rollback();lock.close();lock=None
        p.wait(timeout=10);client.join(timeout=12);pump.join(timeout=10)
        if client.is_alive() or pump.is_alive():raise RuntimeError('owned_probe_join_incomplete')
        client_result=answer.get(timeout=1);after=tables(db)
        outcome='terminal_application_confirmed' if client_result.get('http_code')==201 and len(after['effects'])==1 else 'premature_receiver_exit_unsettled_request'
        result={'status':outcome,'receiver_pid':p.pid,'receiver_exit_code':p.returncode,'receiver_exited_while_own_DB_lock_held':terminal_before_unlock,
          'request':wire,'client_result':client_result,'events':events,'tables_before_unlock':before,'tables_final':after,'seconds':time.perf_counter()-start,'control':'operator EOF while one genuine held HTTP request released into an owned BEGIN IMMEDIATE lock','not_candidate_or_production':True}
        save(folder/'result.json',result)
    finally:
        if lock is not None:lock.rollback();lock.close()
        if p.poll() is None:
            if p.stdin is not None:p.stdin.close();p.stdin=None
            p.wait(timeout=20)
        if client is not None:client.join(timeout=12)
        pump.join(timeout=10);err.close();save(folder/'events-final.json',events)
    return result

def drop_probe():
    folder=ROOT/'fresh-drop-probe'
    p,err,pump,q,events,db,url=spawn(folder,['--drop-once','D/fresh'])
    wire={'tenant':'D','event_id':'fresh','kind':'post','amount_minor':51,'reverses':None};start=time.perf_counter()
    try:
        initial=request(url+'/effects?'+urllib.parse.urlencode({'tenant':'D','event_id':'fresh'}))
        first=request(url+'/effects',wire)
        found=request(url+'/effects?'+urllib.parse.urlencode({'tenant':'D','event_id':'fresh'}))
        replay=request(url+'/effects',wire);rows=tables(db)
        assert initial=={'http_code':404,'body':{'status':'unknown'}}
        assert first.get('transport_error')=='RemoteDisconnected'
        assert found['http_code']==200 and found['body']['status']=='found'
        assert replay['http_code']==200 and replay['body']['status']=='replayed' and found['body']['receipt']==replay['body']['receipt']
        assert len(rows['effects'])==1 and rows['drop_once'][0]['consumed']==1
        result={'status':'fresh_commit_drop_get_replay_confirmed','request':wire,'initial':initial,'first':first,'found':found,'replay':replay,'tables':rows,'seconds':time.perf_counter()-start}
    finally:
        if p.poll() is None:p.stdin.write('stop\n');p.stdin.flush()
        p.wait(timeout=10);pump.join(timeout=10);err.close()
    result|={'receiver_pid':p.pid,'receiver_exit_code':p.returncode,'events':events};save(folder/'result.json',result);return result

if __name__=='__main__':
    result={'eof':eof_probe(),'drop':drop_probe()};save(ROOT/'operator-probes.json',result)
    print(json.dumps({'eof':result['eof']['status'],'drop':result['drop']['status'],'all_owned_receivers_terminal':all(r['receiver_exit_code']==0 for r in result.values())},ensure_ascii=False))
