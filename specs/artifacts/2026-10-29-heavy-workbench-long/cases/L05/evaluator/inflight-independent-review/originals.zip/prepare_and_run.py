"""Exactly one owned inflight cold run and one no-hold scene regression."""
from datetime import datetime,timezone
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parent
BASE=Path('D:/opencorvus-benchmark-runs/l05-inflight-qualification-20261030')
INPUT=Path('D:/opencorvus-benchmark-runs/l05-scene-qualification-20261030/original-input')
REPO=Path('D:/myhexin-local/opencorvus')
CASE=REPO/'specs/artifacts/2026-10-29-heavy-workbench-long/cases/L05'
PYTHON='C:/Python314/python.exe'
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def main():
    inventory=[]
    def copy(src,dst):
        dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
        inventory.append({'source':str(src),'copy':str(dst.relative_to(ROOT)),'bytes':dst.stat().st_size,'byte_equal':src.read_bytes()==dst.read_bytes()})
    for p in (BASE/'source').rglob('*'):
        if p.is_file() and p.suffix in ('.py','.md'):copy(p,ROOT/'source'/p.relative_to(BASE/'source'))
    for p in INPUT.iterdir():
        if p.is_file():copy(p,ROOT/'input'/p.name)
    for p in (BASE/'source-before').rglob('*.py'):copy(p,ROOT/'source-before'/p.relative_to(BASE/'source-before'))
    copy(CASE/'public/SCENE-CONTRACT.draft.md',ROOT/'public-contract/SCENE-CONTRACT.draft.md')
    copy(REPO/'specs/records/2026-10/2026-10-30-heavy-workbench-l05-qualification.md',ROOT/'record-initial.md')
    for name in ('main-command.json','main.stdout.txt','main.stderr.txt'):copy(BASE/name,ROOT/'main-originals'/name)
    for p in (BASE/'main-interleaving').iterdir():
        if p.is_file():copy(p,ROOT/'main-originals/main-interleaving'/p.name)
    save(ROOT/'snapshot-inventory.json',inventory)
    status=subprocess.run(['git','status','--short'],cwd=REPO,capture_output=True,text=True,encoding='utf-8');(ROOT/'git-status-start.txt').write_text(status.stdout,encoding='utf-8')
    commands=[('inflight','qualify_inflight.py',['--input',str(ROOT/'input'),'--output',str(ROOT/'cold-inflight')]),
      ('no-hold','run_scene.py',['--input',str(ROOT/'input'),'--output',str(ROOT/'cold-no-hold'),'--policy','newest','--style','deferred'])]
    results=[]
    for label,script,extra in commands:
        argv=[PYTHON,'-X','utf8','-B',str(ROOT/'source/evaluator/scene-source'/script),*extra]
        started=datetime.now(timezone.utc).isoformat();start=time.perf_counter()
        p=subprocess.run(argv,cwd=ROOT,capture_output=True,text=True,encoding='utf-8',env=__import__('os').environ|{'PYTHONDONTWRITEBYTECODE':'1'},timeout=60)
        (ROOT/(label+'.stdout.txt')).write_text(p.stdout,encoding='utf-8');(ROOT/(label+'.stderr.txt')).write_text(p.stderr,encoding='utf-8')
        receipt={'argv':argv,'cwd':str(ROOT),'started_utc':started,'seconds':time.perf_counter()-start,'exit_code':p.returncode,'owned_process_only':True}
        save(ROOT/(label+'-command.json'),receipt);results.append(receipt)
        if p.returncode!=0:raise RuntimeError('owned cold run failed; preserve originals '+label)
    save(ROOT/'cold-run-receipts.json',results)
    print(json.dumps(results,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
