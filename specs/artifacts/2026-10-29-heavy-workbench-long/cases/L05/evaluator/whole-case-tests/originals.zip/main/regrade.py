import json,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
for subject in ('closed-main','closed-weak','closed-alternative','closed-conflict_first','closed-ack_new_key','closed-early_sent','closed-restore_backup','closed-global_transport','closed-monitor_fake'):
    old=json.loads((ROOT/(subject+'-machine-command.json')).read_text(encoding='utf-8'));argv=old['argv'];out=ROOT/(subject+'-repaired-assessment');argv[argv.index('--out')+1]=str(out);r=subprocess.run(argv,capture_output=True,text=True,encoding='utf-8');(ROOT/(subject+'-repaired-command.json')).write_text(json.dumps({'argv':argv,'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr},ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(subject,r.returncode,r.stdout,flush=True)
