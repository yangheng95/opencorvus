from native import run,ROOT,dump,now
jobs=[('closed-main',r) for r in ('base','amount','tenant')]+[('closed-alternative','base')]+[('closed-'+s,'base') for s in ('conflict_first','ack_new_key','early_sent','restore_backup','global_transport','monitor_fake')]+[('closed-weak',r) for r in ('base','amount','tenant')]
done=[]
for subject,role in jobs:
    code=run(subject,role);done.append({'subject':subject,'role':role,'exit_code':code,'finished_at':now()});dump(ROOT/'batch-progress.json',done)
dump(ROOT/'batch-terminal.json',{'finished_at':now(),'jobs':done})
