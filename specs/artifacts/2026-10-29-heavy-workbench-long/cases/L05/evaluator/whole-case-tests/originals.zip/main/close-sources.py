import json,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parent;CASE=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L05')
for role in ('base','amount','tenant'):
    dst=ROOT/('raw-closed-'+role);shutil.copytree(CASE/'public',dst)
    for n in ('original-local.sqlite','original-remote.sqlite','incoming-operations.json'):shutil.copy2(ROOT/('raw-'+role)/n,dst/n)
for subject in ('main','alternative','conflict_first','ack_new_key','early_sent','restore_backup','global_transport','monitor_fake','weak'):
    dst=ROOT/('closed-'+subject+'-submission');shutil.copytree(ROOT/(subject+'-submission'),dst)
    for n in ('app.py','report.py','reproduce.py'):shutil.copy2(CASE/'evaluator'/n,dst/n)
for n in ('TASK.md','BUSINESS.md','EXECUTION.md','OUTPUTS.md','ENVIRONMENT.md','RECEIVER.md'):assert (CASE/'public'/n).is_file()
