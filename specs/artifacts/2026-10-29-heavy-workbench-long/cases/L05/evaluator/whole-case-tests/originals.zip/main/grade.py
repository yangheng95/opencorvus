import json,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent;CASE=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L05');sys.path.insert(0,str(CASE/'public'));from logical_store import original,remote
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def register():
    path=CASE/'evaluator/registered-inputs.json'
    if path.exists():raise ValueError('registration_exists')
    dump(path,{role:{'local':original(ROOT/('raw-'+role)/'original-local.sqlite'),'remote_effects':remote(ROOT/('raw-'+role)/'original-remote.sqlite')['effects'],'incoming':json.loads((ROOT/('raw-'+role)/'incoming-operations.json').read_text(encoding='utf-8'))} for role in ('base','amount','tenant')})
def grade(subject,roles,review=None):
    out=ROOT/(subject+('-reviewed' if review else '-machine')+'-assessment');argv=[sys.executable,'-X','utf8','-B',str(CASE/'evaluator/check_l05.py'),'--registered',str(CASE/'evaluator/registered-inputs.json'),'--rubric',str(CASE/'rubric.json'),'--out',str(out)]
    for role in roles:
        p=ROOT/(subject+'-'+role);launch=json.loads((p/'launch.json').read_text(encoding='utf-8'));argv+=['--run',str(p/'results/run'),'--raw',launch['raw']]
    if review:argv+=['--review',str(review)]
    r=subprocess.run(argv,capture_output=True,text=True,encoding='utf-8');dump(ROOT/(subject+('-reviewed' if review else '-machine')+'-command.json'),{'argv':argv,'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr});print(subject,r.returncode,r.stdout,flush=True)
if __name__=='__main__':
    if sys.argv[1]=='register':register()
    else:grade(sys.argv[1],sys.argv[2].split(','),Path(sys.argv[3]) if len(sys.argv)>3 else None)
