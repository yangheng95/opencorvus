from pathlib import Path
import json, shutil, zipfile, datetime, subprocess

ROOT=Path(__file__).resolve().parent
REPO=Path('D:/myhexin-local/opencorvus')
BASE=REPO/'specs/artifacts/2026-10-29-heavy-workbench-long'
CASE=BASE/'cases/L05'
REVIEW=ROOT.parent/'l05-whole-case-independent-review-20261031'
DEST=CASE/'evaluator/whole-case-tests'
def read(p): return json.loads(p.read_text(encoding='utf-8'))
def put(p,v): p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def write(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf-8')
assert read(REVIEW/'stage-assessment.json')['development_pilot_freeze_allowed'] is True
main=read(ROOT/'final-main-reviewed-assessment/assessment.json')
weak=read(ROOT/'final-weak-reviewed-assessment/assessment.json')
assert (main['total'],main['good'],weak['total'],weak['good'],weak['failed'])==(100,True,94,False,['H02'])
stamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
public=sorted(p.name for p in (CASE/'public').iterdir() if p.is_file())
if 'profile.json' not in public:public.append('profile.json');public.sort()
put(CASE/'public/profile.json',{'case_id':'L05','version':'0.2.0-dev','status':'frozen_development_pilot','inputs':public,'environment':'declared offline Linux runtime, SQLite and actual local HTTP; no real financial service or credentials','comparison_rule':'score >=90 and every critical leaf verified_pass; no minimum duration','limits':'finite cooperative protocol and owned processes, not arbitrary network/physical power loss/production financial certification'})
rubric=read(CASE/'rubric.json');rubric['status']='development_pilot_frozen';put(CASE/'rubric.json',rubric)
put(CASE/'FREEZE.json',{'case_id':'L05','version':'0.2.0-dev','frozen_at':stamp,'status':'development_pilot_frozen','public_inputs':public,'rubric':'rubric.json','weights_fixed':100,'good_rule':rubric['good_rule'],'review':'evaluator/whole-case-tests/independent-review/REVIEW-FINAL.md','reference_assessment':'evaluator/whole-case-tests/main-assessment.json','weak_assessment':'evaluator/whole-case-tests/weak-assessment.json','execution_lineage':['final main base uses final owner-held sender/helper bytes; amount/tenant and weak retain original actually executed helper bytes','one independent original-helper cold 11.1992800s; subsequent new-helper compatibility/schema/final base are separate necessary increments','final author base native 11.3013694s, wrapper/archive/cleanup 11.6293706s; no >20s slow probe','author app and receiver operational implementation unchanged across concentrated collector/helper repairs'],'limitations':['author references and purposeful errors, not fresh LLM scores','one familiar nonblind AI reviewer; no professional or statistical maturity certification','controlled finite processes/receipt semantics, not arbitrary faults, OS security, power loss or financial certification','suite 9/10 development contracts; L01, triggered L02/L06 upgrades, fresh distinction and effective candidate-hour evidence remain incomplete']})
DEST.mkdir(parents=True,exist_ok=True)
for subject in ('main','weak'):
    shutil.copy2(ROOT/f'final-{subject}-reviewed-assessment/assessment.json',DEST/f'{subject}-assessment.json')
    shutil.copy2(ROOT/f'final-{subject}-reviewed-command.json',DEST/f'{subject}-command.json')
    shutil.copytree(ROOT/f'final-{subject}-reviewed-assessment',DEST/f'{subject}-assessment',dirs_exist_ok=True)
shutil.copytree(ROOT/'closed-main-final-base/results/run/delivery',DEST/'reference-delivery',dirs_exist_ok=True)
shutil.copytree(ROOT/'closed-main-submission',DEST/'reference-source',dirs_exist_ok=True)
shutil.copytree(REVIEW,DEST/'independent-review',dirs_exist_ok=True)
controls=DEST/'controls';controls.mkdir(exist_ok=True)
for p in sorted(ROOT.iterdir()):
    if p.is_file() and (p.name.endswith('-repaired-command.json') or 'repaired-assessment' in p.name):shutil.copy2(p,controls/p.name)
    elif p.is_dir() and 'repaired-assessment' in p.name:shutil.copytree(p,controls/p.name,dirs_exist_ok=True)
for p in ROOT.glob('final-*-machine-command.json'):shutil.copy2(p,controls/p.name)
put(DEST/'execution-roots.json',{'role':'author_reference_or_error_control','main':main['run_roots'],'weak':weak['run_roots'],'originals_root':str(ROOT),'review_root':str(REVIEW),'correct_other_funding':'closed-alternative-base','correct_schema':'closed-schema-compat','errors':['closed-conflict_first','closed-ack_new_key','closed-early_sent','closed-restore_backup','closed-global_transport','closed-monitor_fake'],'native_lineage':'original capsules and commands in originals.zip; exact per-run source/raw/inspect retained, not relabeled as latest helper bytes'})
write(CASE/'README.md','''# L05 事故恢复与真实外部副作用

完整开发合同 **L05/0.2.0-dev** 已由一次集中整题独审批准冻结。[公开任务](public/TASK.md)、[业务原事实](public/BUSINESS.md)、[执行接口](public/EXECUTION.md)、[输出合同](public/OUTPUTS.md)和真实旧应用/两个原SQLite构成候选输入；评估器、参考、权重不能交给候选。

完整链为旧应用事故→有限旧intent与真实在途HTTP→暂停切片→取得确定收据时中断→稳定计划提交后中断→原repair_id续接→前向补偿/epoch切换→迟到旧HTTP原receipt重放→新业务/双接受者/双sender→服务重启→持久监测与零分母→逐来源账、实际图、自含复建与运营移交。原accepted、批准调整和NUL notes逐值保留；业务来源与资金parent分开，不匹配参考ID/动作数。不同正确资金分解以及实际改名outgoing_live的实现均实跑。

[真实整题证据](evaluator/whole-case-tests/README.md)包含完整产品和原始执行。基例/未来金额/新租户三输入全部真实运行；同一checker接15机器项与5实际独评，参考 **100/20pass/good=true**，数字和图正确却伪保证现实任意网络可靠性的弱报告 **94/H02关键失败/good=false**。六个实际错误程序也进入相同checker，未完成独评的控制保持总分null。以上是作者开发资格，非模型成绩。

[最终独审](evaluator/whole-case-tests/independent-review/REVIEW-FINAL.md)保留六个真实漏洞、原反例与修后必要复验，以及一个静态时间区间冲突。独立唯一原helper cold11.1992800秒；最后当前helper主基例native11.3013694秒。金额/新租户和weak仍绑定各自原helper，未声称全矩阵重跑最后字节。旧mini/scene/current-source及[原合同ZIP](evaluator/historical-mini-contracts.zip)只作历史，不是当前执行fallback。

有限合作receiver/自有进程实验不认证任意并发、无限故障、掉电、金融生产安全或职业统计成熟。模拟窗口/参考秒数不证明agent有效小时。套件开发合同9/10；完整L01、L02/L06已触发的新版本及真实候选难度证据仍未完成。
''')
write(CASE/'evaluator/README.md','''# L05 当前整题评估与历史证据

唯一当前完整实现为本目录app.py/report.py/reproduce.py，公开真实执行器为../public/exercise.py，完整grader为check_l05.py，私有原料注册为registered-inputs.json，规范权重为../rubric.json。只能交public给候选，不交作者答案或私有权重。

[整题测试与实际成品](whole-case-tests/README.md)封存三输入、正确另一资金策略/真实改表名、六个实际错误programme、弱报告、独审及原失败。check_l05接真实run/raw/registered/rubric和绑定原对象的5H评级；观察已失败、依赖未执行与设施错误分开，分母100/关键项不可补偿。实际命令在main-command/weak-command及originals.zip；总分100/94是作者开发见证，不是LLM分数。

current-source、scene-source、qualification及早期independent-review均为已退役的mini/顺序/单次在途历史源码和原收据；保留它们是证据，不是第二当前实现。旧公开草案已移到historical-mini-contracts.zip，不提供旧协议fallback。不要重跑旧40/204/EOF或已有矩阵凑资格。
''')
scene=CASE/'evaluator/scene-source/README.md'
s=scene.read_text(encoding='utf-8').replace('规范业务意图在public/SCENE-CONTRACT.draft.md','当时业务草案现封存于../historical-mini-contracts.zip内SCENE-CONTRACT.draft.md')
write(scene,'> 历史阶段证据，已退役；当前整题见[当前说明](../README.md)，下文保持当时资格边界。\n\n'+s)
write(DEST/'README.md','''# L05 完整成品、真实测试和集中整审

[参考软件](reference-source/submission.json)、[实际报告](reference-delivery/REPORT.md)、[运营手册](reference-delivery/operations.md)、[自含复建](reference-delivery/reproduce.md)、[真实图](reference-delivery/recovery.png)可直接阅读。main-assessment.json/weak-assessment.json及对应真实命令是原checker输出：100/20pass与94/H02criticalfail；作者开发资格，非LLM结果。

三输入为base、未来X最高版金额/批准调整变化、新租户真实旧HTTP/原journal。正确最终A/B为1130/545、1153/545；新租户另C360。两个修复中进程退出、原已commit接受失ACK、同键双sender、原receipt/服务重启及monitor均为真实本地HTTP/SQLite/PID，不是mock。actor10001/report65534与700/555/444从实际native和inspect绑定。

六真实错误控制覆盖冲突先到/失ACK换键/提前确认/恢复旧备份/跨租户传输混合/伪监测；另弱报告保持数字正确但强断言错误。依赖未执行/人工未评控制总分null，不能手填分。correct newest与真实改表名outgoing_live证明合法轨迹/存储自由度。

[最终独审](independent-review/REVIEW-FINAL.md)与原五对象反例、改表名真实阻断、静态20vs90时间区间冲突全部原样保存；修后只必要复验，不重整套。唯一独立cold原helper11.1992800s；最终主base新helpernative11.3013694s，其他控制仍原helper，不能声称最终字节全矩阵。未做21s人为慢跑。

originals.zip完整封存本轮外部主/独立目录及最终规范源码/合同/权重/冻结metadata，包含每次真实launch/native/inspect/source/raw/SQLite/输出/原错误与修后命令；archive-receipt.json列成员与字节，未用源码摘要代替行为验收。可变外部目录、历史初评均未倒写。熟悉参考的非盲AI开发审查，不是职业真人/统计成熟/有效候选小时证明。
''')
entry='''
## 最新Recall：L05整题交付，开发合同9/10

用户纠偏先交十题完整成品/真实测试最高优先。L05本轮由原真实旧事故两个SQLite/ACK/NUL notes到真实在途旧HTTP、固定accepted prefix/完整旧key目录、确定receipt处及计划提交后两次进程故障、原repair_id持久续接/前向补偿/epoch切换、迟到原receipt重放、新业务/两个接受者/双sender/服务重启、持久监测/零分母与三CSV/实际图/自含复建/运营移交全部真实运行。只操作自有进程、原料只读/networknone/1CPU，无Provider/凭据/UI/用户进程。跨系统副作用是本题主测，不重L04迁移。

原件D:/opencorvus-benchmark-runs/l05-full-case-20261031；最终main绑定closed-main-final-base/results/run + closed-main-amount/tenant，weak绑定原三closed-weak；另一合法newest资金策略与真实保数据改名outgoing_live也实际native0，无兼容postings对象。三控制最终A/B1130/545、1153/545，新租户另C360；初修复1015/710，新增真实B/W35不能套旧B510。最高冲突0/高唯一解除，业务source与资金parent分离，不要求参考key/动作数。

一次集中整审l05-whole-case-independent-review-20261031从原SQL/实际请求/完整wire/收据/切片/monitor独立重算，唯一额外cold11.1992800s；主/独立均实际看图。六真实缺口集中修：active_json数组；actual UID/PID隔离矛盾设施优先；完整自身持久plan/wire绑定；旧cut边界/计划key的epoch；三CSV完整语义；执行器不再直接依赖candidate.postings而用冻结原wire的sender。另静态20s旧sender对多个合法90s调用有时间区间冲突，只有owner-held sender显式None，普通app20不改；未复现实际超时/未做21s慢探针。当前最终base实际走None/held/release/replayed，native11.3013694s，wrapper11.6293706s另计。amount/tenant/weak/独立原cold保原helper字节，不回写成新源全矩阵。

原五反例/旧checker/初评、schema原阻断、partial内层continue导致误读stage、首缺monitor_after判断均保留。只读原对象复验后，已观察失败/依赖未执行/设施错误明确分开，未交或未完总分null。JSON等价重排正向控制通过，不用词法/参考ID做门。六错误programme真实进同checker；最高冲突先到、换新key、提前确认、恢复备份、全局传输dedup、伪监测均具名关键失败。

20:14:53Z单层独审允许仅devmetadata冻结，权重15M75+5H25=100/critical/90与原事实不改。主方实际check_l05 CLI接同三run和5真独评：reference100/20pass/allcritical/goodtrue，weak94/H02criticalfail/goodfalse；不是模型候选分。L05/0.2.0-dev FREEZE、规范public/完整软件/可读报告图/原件ZIP在cases/L05。旧mini/scene/current-source仅历史退役，不重旧40/204/EOF。

当前9/10完整开发合同，有效候选小时0/10、真人专业/统计成熟未认证。无新增活跃LLM/solver/独审；六旧昂贵容器只读核Paused，不恢复。下一直接完整L01：先已有权重便宜重算独立PDE误差/残差/条件质量与合理可达，study_complete与solution_reproduced分开，方法分不补质量；不按现误差倒填宽线/匹配非凸精确轨迹，不自动恢复五GPU。之后履行L02/L06真实双100已触发的另版升级与必要fresh区分度/有效小时，旧public/rubric/分数及退休API只读不重开。所有未完要求保留，心跳ACTIVE。

本轮范围commit/正常fetch merge/审全待推/必要验证/push；精确Git与外部publish-delivery.json才是推送收据。保用户overlay/删视频图片/索引排序/Bun等foreign改动。\n'''
for p in [REPO/'specs/records/2026-10/2026-10-30-heavy-workbench-l05-qualification.md',REPO/'specs/records/2026-10/2026-10-29-heavy-workbench-long.md']:
    with p.open('a',encoding='utf-8') as f:f.write(entry)
rootread=BASE/'README.md';s=rootread.read_text(encoding='utf-8').replace('8/10个完整开发版合同','9/10个完整开发版合同').replace('L02、L03、L04、L07','L02、L03、L04、L05、L07').replace('| [L05事故与外部副作用](cases/L05/README.md) | 真实HTTP两库事故/补偿与受控在途/EOF局部实证 | 完整并发/恢复/监测/交付/冻结未完成 |','| [L05事故与外部副作用](cases/L05/README.md) | 真实事故/在途/持久计划与两次中断/双sender/服务重启/逐来源账/监测/图/自含移交；三输入、真实正错程序与整审冻结 | 作者参考100、伪保证94关键失败；非fresh模型或小时证明 |').replace('L04完整开发已交，下一直接补L05/L01','L04/L05完整开发已交，下一直接补L01');write(rootread,s)
matrix=BASE/'cases/README.md';s=matrix.read_text(encoding='utf-8').replace('当前完整开发pilot合同8/10（旧L06、L02、L03、L04、L07','当前完整开发pilot合同9/10（旧L06、L02、L03、L04、L05、L07').replace('| L05事故现场与外部副作用 | 真实旧现场/逐来源补偿及单次在途交错、有限请求收尾独立资格通过，原实质失败保留 | 完整在途/并发切换/恢复、监测与交付、实现自由grader/完整rubric/冻结 |','| [L05事故与外部副作用](L05/README.md) | 真实两库旧事故/在途/计划持久续接/双sender/服务重启/monitor/逐来源账/实际图/自含移交；三输入、正确不同存储/资金轨迹、真实错误与整审开发冻 | 作者参考100；伪保证94关键失败，无fresh模型/小时证明 |');s+='\n最新整题：L05已完成三输入/不同资金及实际改表名/错误programme/图和集中整审开发冻，当前9/10；L01及L02/L06已触发新版仍待。上文阶段记载不是重复运行依据，候选有效小时仍0/10。\n';write(matrix,s)
updates={
REPO/'specs/README.md':{'- [L02发布时间输入资格]':'- [L02发布时间输入资格](records/2026-10/2026-10-30-heavy-workbench-l02-qualification.md)：L02真实双100触发升级；L03/L04/L05/L07/L08/L09/L10整题实测与独审已交，9/10开发合同不是成熟十题。','- [L05跨系统副作用资格]':'- [L05跨系统副作用资格](records/2026-10/2026-10-30-heavy-workbench-l05-qualification.md)：完整旧事故/真实在途/持久计划中断续接/双sender/服务重启/monitor/移交整审开发冻，参考100、伪保证94关键失败，非模型成绩。'},
REPO/'specs/artifacts/README.md':{'- [长程任务资格与便宜实验]':'- [长程任务资格与便宜实验](2026-10-29-heavy-workbench-long/README.md)：9/10开发成品；L05真实跨系统事故/持久恢复/并发投递/监测移交整审，参考100、弱94关键失败；L01与两已触发新版/候选难度仍待。'},
REPO/'specs/records/2026-10/README.md':{'- [2026-10-30-heavy-workbench-l02-qualification.md]':'- [2026-10-30-heavy-workbench-l02-qualification.md](2026-10-30-heavy-workbench-l02-qualification.md)：L02真实双100触发升级；[持续十题进度](2026-10-29-heavy-workbench-long.md)现9/10开发合同，有效小时未证。','- [2026-10-30-heavy-workbench-l05-qualification.md]':'- [2026-10-30-heavy-workbench-l05-qualification.md](2026-10-30-heavy-workbench-l05-qualification.md)：完整两库事故/真实在途/持久恢复/双sender/监测交付及三输入/正错程序/整审开发冻，参考100、伪保证94关键失败。'}}
for p,replacements in updates.items():
    lines=p.read_text(encoding='utf-8').splitlines()
    for prefix,value in replacements.items():
        matches=[i for i,line in enumerate(lines) if line.startswith(prefix)]
        if len(matches)!=1:raise RuntimeError((str(p),prefix,matches))
        lines[matches[0]]=value
    write(p,'\n'.join(lines)+'\n')
# Full immutable evidence, actual bytes and per-run native objects, never a correctness hash gate.
members=[];archive=DEST/'originals.zip'
assert not archive.exists(),'do not overwrite an existing originals capsule'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for origin,prefix in [(ROOT,'main'),(REVIEW,'independent')]:
        for p in sorted(origin.rglob('*')):
            if p.is_file():
                name=prefix+'/'+p.relative_to(origin).as_posix();z.write(p,name);members.append({'member':name,'bytes':p.stat().st_size})
    for p in sorted(CASE.rglob('*')):
        if p.is_file() and not p.is_relative_to(DEST) and (p.is_relative_to(CASE/'public') or p.parent==CASE or p.parent==CASE/'evaluator'):
            name='final-case/'+p.relative_to(CASE).as_posix();z.write(p,name);members.append({'member':name,'bytes':p.stat().st_size})
put(DEST/'archive-receipt.json',{'at':stamp,'archive':'originals.zip','archive_bytes':archive.stat().st_size,'members':len(members),'original_bytes':sum(m['bytes'] for m in members),'inventory':members,'scope':'complete external main/review files at closure plus final normative case files; later Git/push receipts external, current review/case objects retained plain','excluded':'no original execution files excluded; no source digest used as functional acceptance'})
print(json.dumps({'development_contracts':9,'main':main['total'],'weak':weak['total'],'archive_bytes':archive.stat().st_size,'members':len(members)},ensure_ascii=False))
