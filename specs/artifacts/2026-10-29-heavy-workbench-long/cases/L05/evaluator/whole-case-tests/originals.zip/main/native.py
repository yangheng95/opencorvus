import json,subprocess,sys,time,zipfile
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parent;IMAGE='sha256:23ff8bfbf8055caa0b9fa5745ddb27cceea2f31d7d15b7a900c81112cdfe8ddf'
def now():return datetime.now(timezone.utc).isoformat()
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def run(subject,role):
    root=ROOT/(subject+'-'+role);root.mkdir();results=root/'results';results.mkdir();source=ROOT/(subject+'-submission');raw=ROOT/(('raw-closed-' if subject.startswith('closed-') else 'raw-')+role);name='oc-l05-'+subject+'-'+role+'-20261031'
    argv=['docker','create','--name',name,'--network','none','--cpus','1','--mount',f'type=bind,source={source},target=/source,readonly','--mount',f'type=bind,source={raw},target=/raw,readonly','--mount',f'type=bind,source={results},target=/results',IMAGE,'/opt/cpsat/bin/python','-B','/source/reproduce.py','--input','/raw','--output','/results/run']
    r=subprocess.run(argv,capture_output=True,text=True);dump(root/'create-native.json',{'argv':argv,'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'at':now()})
    if r.returncode:raise RuntimeError('facility_container_create_failed')
    cid=r.stdout.strip();dump(root/'launch.json',{'cid':cid,'started_at':now(),'source':str(source),'raw':str(raw),'entry':'public only + original submission, no private grader mount'})
    t=time.monotonic();r=subprocess.run(['docker','start','--attach',cid],capture_output=True,text=True,encoding='utf-8');(root/'stdout.txt').write_text(r.stdout,encoding='utf-8');(root/'stderr.txt').write_text(r.stderr,encoding='utf-8');ins=subprocess.run(['docker','inspect',cid],capture_output=True,text=True,check=True);(root/'inspect-terminal.json').write_text(ins.stdout,encoding='utf-8');dump(root/'native-terminal.json',{'exit_code':r.returncode,'wall_seconds':time.monotonic()-t,'finished_at':now()})
    with zipfile.ZipFile(root/'completed-originals.zip','w',zipfile.ZIP_DEFLATED) as z:
        for file in root.rglob('*'):
            if file.is_file() and file.name!='completed-originals.zip':z.write(file,file.relative_to(root))
        for prefix,path in [('source',source),('raw',raw)]:
            for file in path.rglob('*'):
                if file.is_file():z.write(file,Path(prefix)/file.relative_to(path))
    q=subprocess.run(['docker','rm',cid],capture_output=True,text=True);dump(root/'cleanup.json',{'cid':cid,'exit_code':q.returncode,'stdout':q.stdout,'stderr':q.stderr});print(json.dumps({'subject':subject,'role':role,'exit_code':r.returncode,'stdout':r.stdout,'seconds':time.monotonic()-t}),flush=True)
    return r.returncode
if __name__=='__main__':raise SystemExit(run(*sys.argv[1:3]))
