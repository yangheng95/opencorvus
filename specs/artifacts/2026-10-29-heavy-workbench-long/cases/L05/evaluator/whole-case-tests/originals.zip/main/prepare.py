import json,shutil,sqlite3,subprocess,sys,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent;CASE=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L05');PUB=CASE/'public'
sys.path.insert(0,str(PUB));from logical_store import FIELDS
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def main():
    for role in ('base','amount','tenant'):
        dst=ROOT/('raw-'+role);shutil.copytree(PUB,dst)
        operations=json.loads((dst/'incoming-operations.json').read_text(encoding='utf-8'))
        if role=='amount':operations['events'][2]['amount_minor']=135;operations['adjustment']['amount_minor']=-7;dump(dst/'incoming-operations.json',operations)
        if role=='tenant':
            db=dst/'original-local.sqlite';c=sqlite3.connect(db);wire={'tenant':'C','event_id':'C-opening','kind':'post','amount_minor':300,'reverses':None};c.execute("INSERT INTO opening VALUES('C',300)");c.execute('INSERT INTO postings(tenant,event_id,payload,source_kind,source_id,boundary_seq,epoch) VALUES(?,?,?,?,?,?,?)',('C','C-opening',json.dumps(wire,sort_keys=True,separators=(',',':')),'opening','opening',7,1));c.commit();c.close()
            log=(ROOT/'tenant-construction.stderr.txt').open('w',encoding='utf-8');cmd=[sys.executable,'-X','utf8','-B',str(PUB/'l05_effects.py'),'--db',str(dst/'original-remote.sqlite')];p=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=log,text=True,encoding='utf-8');ready=json.loads(p.stdout.readline());records=[]
            for i,request in enumerate([{'action':'send','tenant':'C','event_id':'C-opening'},{'action':'ingest','epoch':1,'event':{'tenant':'C','request_id':'q1','event_id':'X','revision':1,'kind':'settle','amount_minor':60}}]):
                path=ROOT/f'tenant-construction-{i}.json';dump(path,request);argv=[sys.executable,'-X','utf8','-B',str(PUB/'legacy_app.py'),'--db',str(db),'--url',ready['url'],'--request',str(path)];r=subprocess.run(argv,capture_output=True,text=True,encoding='utf-8');records.append({'argv':argv,'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr});assert r.returncode==0
            p.stdin.write('stop\n');p.stdin.flush();out,_=p.communicate(timeout=30);log.close();dump(ROOT/'tenant-construction-native.json',{'service_argv':cmd,'ready':ready,'exit_code':p.returncode,'stdout':out,'calls':records})
    for subject,defect,policy in [('main','none','oldest'),('alternative','none','newest'),('conflict_first','conflict_first','oldest'),('ack_new_key','ack_new_key','oldest'),('early_sent','early_sent','oldest'),('restore_backup','restore_backup','oldest'),('global_transport','global_transport','oldest'),('monitor_fake','monitor_fake','oldest'),('weak','weak_report','oldest')]:
        dst=ROOT/(subject+'-submission');dst.mkdir()
        for name in ('app.py','report.py','reproduce.py'):shutil.copy2(CASE/'evaluator'/name,dst/name)
        for name in ('l05_effects.py','l05_transport.py'):shutil.copy2(PUB/name,dst/name)
        dump(dst/'settings.json',{'parent_policy':policy,'defect':defect});dump(dst/'logical-map.json',{t:{'table':t,'columns':{f:f for f in fields.split()}} for t,fields in FIELDS.items()})
        files=sorted(x.name for x in dst.iterdir());dump(dst/'submission.json',{'files':files,'app_argv':['python','-B','app.py'],'report_argv':['python','-B','report.py'],'logical_map':'logical-map.json'})
if __name__=='__main__':main()
