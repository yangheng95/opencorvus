import json,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent;CASE=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L05');REVIEW=ROOT.parent/'l05-whole-case-independent-review-20261031'
subjects={'main':['closed-main-final-base','closed-main-amount','closed-main-tenant'],'weak':['closed-weak-base','closed-weak-amount','closed-weak-tenant']}
def grade(name,review=False):
    out=ROOT/('final-'+name+('-reviewed' if review else '-machine')+'-assessment');argv=[sys.executable,'-X','utf8','-B',str(CASE/'evaluator/check_l05.py'),'--registered',str(CASE/'evaluator/registered-inputs.json'),'--rubric',str(CASE/'rubric.json'),'--out',str(out)]
    for label in subjects[name]:
        folder=ROOT/label;launch=json.loads((folder/'launch.json').read_text(encoding='utf-8'));argv+=['--run',str(folder/'results/run'),'--raw',launch['raw']]
    if review:argv+=['--review',str(REVIEW/(name+'-review.json'))]
    r=subprocess.run(argv,capture_output=True,text=True,encoding='utf-8');(ROOT/('final-'+name+('-reviewed' if review else '-machine')+'-command.json')).write_text(json.dumps({'argv':argv,'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr},ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(name,r.returncode,r.stdout,flush=True)
if __name__=='__main__':
    for name in subjects:grade(name,len(sys.argv)>1 and sys.argv[1]=='review')
