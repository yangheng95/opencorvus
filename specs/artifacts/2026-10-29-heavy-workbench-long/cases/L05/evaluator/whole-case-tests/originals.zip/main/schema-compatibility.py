from native import ROOT,run,dump
from pathlib import Path
import shutil,json
CASE=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L05')
raw=ROOT/'raw-closed-compat';shutil.copytree(ROOT/'raw-closed-base',raw)
for n in ('exercise.py','frozen_sender.py'):shutil.copy2(CASE/'public'/n,raw/n)
for name,base in [('closed-compatible','closed-main'),('closed-schema','closed-alternative')]:shutil.copytree(ROOT/(base+'-submission'),ROOT/(name+'-submission'))
p=ROOT/'closed-schema-submission/app.py';text=p.read_text(encoding='utf-8');text=text.replace('postings','outgoing_live')
start=text.index('def initialize(db):');end=text.index('\n\ndef validate_event',start)
section=text[start:end]
insert='''    with connect(db) as c:
        c.execute('BEGIN IMMEDIATE')
        c.execute('CREATE TABLE IF NOT EXISTS layout_migrations(version INTEGER PRIMARY KEY,name TEXT NOT NULL)')
        if not c.execute('SELECT 1 FROM layout_migrations WHERE version=2').fetchone():
            if c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='postings'").fetchone():c.execute('ALTER TABLE postings RENAME TO outgoing_live')
            c.execute("INSERT INTO layout_migrations VALUES(2,'stable_registered_wires_renamed')")
        c.commit()
'''
section=section.replace('def initialize(db):\n','def initialize(db):\n'+insert,1);text=text[:start]+section+text[end:];p.write_text(text,encoding='utf-8')
m=ROOT/'closed-schema-submission/logical-map.json';mapping=json.loads(m.read_text(encoding='utf-8'));mapping['postings']['table']='outgoing_live';dump(m,mapping)
for subject in ('closed-compatible','closed-schema'):
    # Native run label compat uses the same immutable base operational facts.
    run(subject,'compat')
