from grade import grade
for name in ('closed-alternative','closed-conflict_first','closed-ack_new_key','closed-early_sent','closed-restore_backup','closed-global_transport','closed-monitor_fake'):grade(name,['base'])
