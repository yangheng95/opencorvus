"""Finite arithmetic examples for a plan review, not a full implementation."""
import datetime as dt
import itertools
import json
import pathlib
import shutil
import subprocess
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parent
REPO = pathlib.Path('D:/myhexin-local/opencorvus')
started = dt.datetime.now(dt.timezone.utc).isoformat()
tick = time.perf_counter()
files = [
    REPO / 'specs/records/2026-10/2026-10-30-heavy-workbench-l05-qualification.md',
    pathlib.Path('D:/opencorvus-benchmark-runs/heavy-long-nine-upgrade-review-20261029/H05.md'),
    REPO / 'specs/artifacts/2026-10-29-heavy-workbench-cross-system/H05-v02-contract-draft.md',
    REPO / 'specs/artifacts/2026-10-29-heavy-workbench-cross-system/H05-upgrade-proposal.md',
    REPO / 'specs/artifacts/2026-10-29-heavy-workbench-long/cases/L05/public/PROTOCOL.draft.md',
]
snapshot = ROOT / 'read-sources'
snapshot.mkdir(exist_ok=False)
inventory = []
for idx, origin in enumerate(files):
    target = snapshot / (str(idx+1) + '-' + origin.name)
    shutil.copyfile(origin, target)
    inventory.append({'origin': str(origin), 'snapshot': str(target), 'direct_byte_equal_at_capture': origin.read_bytes() == target.read_bytes()})
(ROOT / 'read-source-inventory.json').write_text(json.dumps(inventory, indent=2), encoding='utf-8')

# These two policies are alternatives illustrating a missing public decision.
conflict = {'accepted': [{'revision': 1, 'amount': 100}, {'revision': 2, 'amount': 80}, {'revision': 2, 'amount': 90}], 'already_external': 100}
alternatives = [
    {'policy': 'quarantine_zero', 'target': 0, 'forward_delta': -100},
    {'policy': 'quarantine_freeze_previously_valid', 'target': 100, 'forward_delta': 0},
]
assert alternatives[0]['forward_delta'] != alternatives[1]['forward_delta']

# CONDITIONAL proposed fold (not an assertion of the unfrozen contract).
def zero_quarantine_fold(records):
    top = max(row['revision'] for row in records)
    payloads = {(row['kind'], row['amount']) for row in records if row['revision'] == top}
    if len(payloads) != 1:
        return {'revision': top, 'status': 'quarantined', 'target': 0}
    kind, amount = next(iter(payloads))
    return {'revision': top, 'status': kind, 'target': amount if kind == 'settle' else 0}

records = [{'revision': 1, 'kind': 'settle', 'amount': 100}, {'revision': 2, 'kind': 'settle', 'amount': 80}, {'revision': 2, 'kind': 'settle', 'amount': 90}]
permutations = [zero_quarantine_fold(list(order)) for order in itertools.permutations(records)]
assert all(row == permutations[0] for row in permutations)
resolved = zero_quarantine_fold(records + [{'revision': 3, 'kind': 'settle', 'amount': 60}])
assert resolved['target'] == 60

# Current external primitive: each post p>0 has total reversals >= -p.
# Exhaustive small arithmetic witnesses only; the general inequality is in REVIEW.
remaining_balances = [p + r for p in range(1, 5) for r in range(-p, 1)]
assert min(remaining_balances) == 0
negative_target = {'current_primitive_allows_minimum_tenant_net': 0, 'example_approved_target': -5, 'reachability': 'impossible_under_current_protocol_without_extra_baseline_or_different_target_semantics'}

# Two valid posting graphs for the same final business state under the primitive.
graphs = [
    {'name': 'eager_revision_updates', 'entries': [{'id': 'p1', 'amount': 100, 'reverses': None}, {'id': 'p2', 'amount': 20, 'reverses': None}, {'id': 'r2', 'amount': -20, 'reverses': 'p2'}]},
    {'name': 'deferred_final_reconciliation', 'entries': [{'id': 'q1', 'amount': 100, 'reverses': None}]},
]
for graph in graphs:
    assert sum(row['amount'] for row in graph['entries']) == 100
    posts = {row['id']: row['amount'] for row in graph['entries'] if row['amount'] > 0}
    for parent, amount in posts.items():
        assert amount + sum(row['amount'] for row in graph['entries'] if row['reverses'] == parent) >= 0

# A schedule permitted if a local epoch is mistakenly treated as a remote fence.
late_legacy = {'events': ['local_pause_commits_epoch2', 'repair_GET_old_key_returns_unknown', 'repair_posts_correct100_under_new_key', 'already_in_flight_legacy_HTTP_commits_old100'], 'final_remote': 200, 'desired': 100, 'meaning': 'need a public old-dispatch quiescence barrier or explicit no-legacy-inflight initial condition'}
assert late_legacy['final_remote'] != late_legacy['desired']

# A tenant aggregate does not distinguish misattributed business sources.
correct = {'A/x': 100, 'A/y': 0}
incorrect = {'A/x': 0, 'A/y': 100}
assert sum(correct.values()) == sum(incorrect.values()) and correct != incorrect

result = {
    'status': 'arithmetic_examples_completed',
    'scope': 'finite offline design counterexamples; not HTTP, a reference implementation, a grader, or a candidate result',
    'ambiguous_conflict': {'input': conflict, 'possible_policies': alternatives},
    'conditional_fold_example': {'policy': 'zero_quarantine_if_main_explicitly_chooses_it', 'permutations_checked': len(permutations), 'conflict_result': permutations[0], 'higher_unique_result': resolved},
    'negative_target': negative_target,
    'two_correct_posting_graphs': graphs,
    'late_legacy_after_local_epoch': late_legacy,
    'equal_total_wrong_business_attribution': {'correct': correct, 'incorrect': incorrect, 'both_tenant_total': 100},
    'argv': [sys.executable, '-X', 'utf8', '-B', str(pathlib.Path(__file__).resolve())],
    'started_utc': started,
    'ended_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
    'elapsed_seconds': time.perf_counter() - tick,
    'full_L05_frozen': False,
    'candidate_score': None,
}
(ROOT / 'math-examples.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
status = subprocess.run(['git', 'status', '--short'], cwd=REPO, capture_output=True, text=True, encoding='utf-8', check=True)
(ROOT / 'git-status-read.txt').write_text(status.stdout, encoding='utf-8')
print(json.dumps({'status': result['status'], 'conditional_fold_permutations': len(permutations), 'executed_HTTP_or_model_or_solver': False}))
