import datetime as dt
import json
from pathlib import Path
import subprocess

ROOT=Path(__file__).resolve().parent
REPO=Path('D:/myhexin-local/opencorvus')
inventory=json.loads((ROOT/'repair-source-inventory.json').read_text(encoding='utf-8'))
identity=[{**row,'current_still_equals_repaired_snapshot':Path(row['source']).read_bytes()==Path(row['snapshot']).read_bytes()} for row in inventory]
(ROOT/'final-source-identity.json').write_text(json.dumps({'checked_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'files':identity,'method':'direct object identity record, not a correctness hash gate'},indent=2),encoding='utf-8')
cold=json.loads((ROOT/'cold-command.json').read_text(encoding='utf-8'))
result=json.loads((ROOT/'newest-deferred/result.json').read_text(encoding='utf-8'))
repair=json.loads((ROOT/'repair-assessment.json').read_text(encoding='utf-8'))
sql=json.loads((ROOT/'independent-SQL-audit.json').read_text(encoding='utf-8'))
assessment={
 'reviewer':'/root/benchmark_review',
 'status':'author_schema_sequential_constructive_qualification_accepted_after_checker_repairs',
 'substantive_blockers_current':[],
 'original_findings':[
  {'id':'SCENE-CHECK-01','issue':'partial local wire payload accepted by checker; same partial comparison existed in deliver_one','initial_actual':'exit0 business_success after removing kind and reverses from a new local posting payload','fixed_actual':'exit2 business_mismatch posting_wire_invalid(fields); consumer ValueError local_posting_wire_invalid:fields'},
  {'id':'SCENE-CHECK-02','issue':'negative posting boundary and epoch accepted','initial_actual':'exit0 business_success with boundary_seq=-1 and epoch=-1','fixed_actual':'exit2 business_mismatch posting_epoch_boundary_invalid; one sequential control/source boundary range only'}
 ],
 'independent_cold_replay':{'runs':1,'policy':'newest','style':'deferred','command':cold,'result':result,'no_repair_full_cold_added':True},
 'independent_SQL':{'checks':sql['count'],'correct_graphs':3,'postings':[14,19,17],'all_current_sources_match_repaired_snapshot':all(row['current_still_equals_repaired_snapshot'] for row in identity)},
 'arithmetic':{'actual_original_remote':{'A':1100,'B':570},'initial_authority_repaired_target':{'A':1015,'B':710},'final_issued_target':{'A':1130,'B':510},'raw_and_target_are_not_equated':True},
 'verified_facts':['issued injection authority independent from repaired candidate state','original and future accepted facts','Unicode and embedded NUL notes','original postings and known receipts immutable','unknown ACK resolved with original identity','control epoch2 active1 in all three actual correct results','per-business/opening/adjustment contributions','same-tenant funding capacity independent from logical business source','three real wrong controls detected even when account total is correct'],
 'repair_rechecks':{'checker_CLIs':len(repair['readonly_checker_contracts']),'real_consumer_cases':len(repair['real_consumer_cases']),'owned_receiver_exitcode':repair['owned_receiver_exitcode'],'whole_cold_replays_added':repair['complete_cold_replays_added']},
 'limits':['only author schema and a sequential source-only construction','no full public raw packet, logical export/schema-independent grader or rubric','no certification of concurrent writers, in-flight old HTTP switching or real process crashes during repair','range tags do not establish full posting-time or approval-time causality','no monitoring or professional complete deliverable','not a model candidate score, L05 freeze, hours validation or mature ten-case benchmark'],
 'old_failure_evidence_preserved':True,
 'L06_candidate_Task_or_container_accessed':False,
 'Provider_GPU_solver_UI_or_redelegation':False,
 'repository_modified_or_committed':False,
 'full_L05_frozen':False,
 'candidate_score':None,
}
(ROOT/'stage-assessment.json').write_text(json.dumps(assessment,ensure_ascii=False,indent=2),encoding='utf-8')
status=subprocess.run(['git','status','--short'],cwd=REPO,capture_output=True,text=True,encoding='utf-8')
(ROOT/'git-status-end.txt').write_text(status.stdout+status.stderr,encoding='utf-8')
print(json.dumps({'status':assessment['status'],'repaired_source_identity':all(row['current_still_equals_repaired_snapshot'] for row in identity),'cold_replays':1,'repair_full_cold_added':0,'blockers':[]}))
