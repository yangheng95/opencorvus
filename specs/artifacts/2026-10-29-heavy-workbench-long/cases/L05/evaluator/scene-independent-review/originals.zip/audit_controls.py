"""Only read existing original/control databases; no new HTTP or scene creation."""
import json
from pathlib import Path
import sqlite3
from contextlib import closing

ROOT=Path(__file__).resolve().parent
MAIN=Path('D:/opencorvus-benchmark-runs/l05-scene-qualification-20261030')
def read(db,query):
    with closing(sqlite3.connect(db.resolve().as_uri()+'?mode=ro',uri=True)) as c:
        c.row_factory=sqlite3.Row
        return [dict(r) for r in c.execute(query)]
def load(p):return json.loads(p.read_text(encoding='utf-8'))
original_local=ROOT/'inputs/original-local.sqlite'
original_remote=ROOT/'inputs/original-remote.sqlite'
old_intents=read(original_local,'SELECT * FROM postings ORDER BY seq')
old_x=next(r for r in old_intents if r['tenant']=='A' and r['source_kind']=='business' and r['source_id']=='X')
old_z=next(r for r in old_intents if r['tenant']=='A' and r['source_kind']=='business' and r['source_id']=='Z')
old_effects=read(original_remote,'SELECT * FROM effects ORDER BY tenant,event_id')
old_requests=read(original_remote,'SELECT * FROM requests ORDER BY seq')
x_requests=[r for r in old_requests if r['tenant']=='A' and r['event_id']==old_x['event_id']]
assert [(r['method'],r['status'],r['dropped']) for r in x_requests]==[('GET','unknown',0),('POST','applied',1)]
assert old_x['receipt_id'] is None
assert any(r['tenant']=='A' and r['event_id']==old_x['event_id'] for r in old_effects)
assert all((r['tenant'],r['event_id'])!=('A',old_z['event_id']) for r in old_effects)
controls=[]
for name in ['wrong-conflict','wrong-new-key','wrong-restore']:
    folder=MAIN/name
    local=folder/'local.sqlite';remote=folder/'remote.sqlite'
    effects=read(remote,'SELECT * FROM effects ORDER BY tenant,event_id')
    postings=read(local,'SELECT * FROM postings ORDER BY seq')
    journal=read(local,'SELECT * FROM journal ORDER BY seq')
    projected=read(local,'SELECT * FROM projection ORDER BY tenant,event_id')
    accounts={tenant:sum(r['amount_minor'] for r in effects if r['tenant']==tenant) for tenant in ['A','B']}
    keys={(r['tenant'],r['event_id']) for r in postings}
    unaccounted=[r for r in effects if (r['tenant'],r['event_id']) not in keys]
    item={'name':name,'actual_accounts':accounts,'accepted_journal_rows':len(journal),'projection':projected,'unaccounted_actual_effects':unaccounted,'checker_result':load(folder/'result.json')}
    if name=='wrong-conflict':
        assert next(r for r in projected if r['tenant']=='A' and r['event_id']=='X')['amount_minor']==120
        assert accounts=={'A':1135,'B':710}
    elif name=='wrong-new-key':
        assert len(unaccounted)==1 and unaccounted[0]['tenant']=='A' and unaccounted[0]['amount_minor']==100
        assert accounts=={'A':1115,'B':710}
    else:
        assert len(journal)==7 and accounts=={'A':1130,'B':510}
        item['missing_later_business_requests']=[r['request_id'] for r in load(ROOT/'inputs/future-events.json') if r['request_id'] not in {j['request_id'] for j in journal}]
        assert item['missing_later_business_requests']==['q8','q9','q10','q11','q12','q13']
    assert item['checker_result']['status']=='business_mismatch'
    controls.append(item)
result={'status':'passed','scope':'read-only independent facts for three actual wrong controls, not new execution or a full grader','original_unknown_ACK':{'stable_intent':old_x,'actual_request_sequence':x_requests,'original_remote_effect_exists':True,'local_confirmation':None},'accepted_undelivered_original':old_z,'controls':controls,'candidate_score':None}
(ROOT/'wrong-controls-independent-SQL.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'status':'passed','wrong_controls_read':len(controls),'new_HTTP_runs':0}))
