"""One authorized newest+deferred source-only scene replay, no regeneration."""
import datetime as dt
import json
import pathlib
import shutil
import subprocess
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parent
MAIN = pathlib.Path('D:/opencorvus-benchmark-runs/l05-scene-qualification-20261030')
REPO_CASE = pathlib.Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L05')
SOURCE = ROOT/'source-initial'
SOURCE.mkdir(exist_ok=False)
inventory = []
for rel in ['evaluator/scene-source/scene_app.py','evaluator/scene-source/check_scene.py','evaluator/scene-source/run_scene.py','evaluator/current-source/l05_worker.py','public/l05_effects.py']:
    original = MAIN/'source-cold-a'/rel
    target = SOURCE/rel
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(original,target)
    inventory.append({'origin_executed_source':str(original),'snapshot':str(target),'same_bytes':original.read_bytes()==target.read_bytes(),'same_as_current_repo_at_capture':(REPO_CASE/rel).read_bytes()==target.read_bytes()})
shutil.copyfile(REPO_CASE/'public/SCENE-CONTRACT.draft.md',ROOT/'SCENE-CONTRACT-reviewed.md')
inputs = ROOT/'inputs'
inputs.mkdir(exist_ok=False)
input_bytes = {}
for name in ['original-local.sqlite','original-remote.sqlite','initial-authority.json','future-events.json','legacy-delivery.json']:
    origin = MAIN/'original-input'/name
    target = inputs/name
    shutil.copyfile(origin,target)
    input_bytes[name] = target.read_bytes()
(ROOT/'capture-inventory.json').write_text(json.dumps({'source_files':inventory,'input_origin':str(MAIN/'original-input'),'input_files':list(input_bytes),'input_was_not_generated_by_reviewer':True},indent=2),encoding='utf-8')
argv = [sys.executable,'-X','utf8','-B',str(SOURCE/'evaluator/scene-source/run_scene.py'),'--input',str(inputs),'--output',str(ROOT/'newest-deferred'),'--policy','newest','--style','deferred','--control','correct']
started = dt.datetime.now(dt.timezone.utc).isoformat()
tick = time.perf_counter()
with (ROOT/'cold.stdout.txt').open('w',encoding='utf-8') as out,(ROOT/'cold.stderr.txt').open('w',encoding='utf-8') as err:
    process = subprocess.Popen(argv,cwd=SOURCE,stdout=out,stderr=err)
    (ROOT/'cold-launch.json').write_text(json.dumps({'argv':argv,'pid':process.pid,'started_utc':started},indent=2),encoding='utf-8')
    code = process.wait(timeout=60)
receipt = {'argv':argv,'pid':process.pid,'returncode':code,'started_utc':started,'ended_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'elapsed_seconds':time.perf_counter()-tick,'input_bytes_unchanged':{name:(inputs/name).read_bytes()==value for name,value in input_bytes.items()},'scope':'exactly one newest+deferred source-only replay of existing synthetic accident inputs','candidate_score':None}
(ROOT/'cold-command.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps({'receipt':receipt,'stdout':(ROOT/'cold.stdout.txt').read_text(encoding='utf-8'),'stderr':(ROOT/'cold.stderr.txt').read_text(encoding='utf-8')}))
