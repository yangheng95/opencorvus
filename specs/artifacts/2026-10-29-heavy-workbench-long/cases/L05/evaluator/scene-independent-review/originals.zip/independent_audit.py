"""Independent raw-fact arithmetic/SQL audit plus two local checker probes."""
from collections import Counter, defaultdict
from contextlib import closing
import datetime as dt
import json
from pathlib import Path
import sqlite3
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
MAIN = Path('D:/opencorvus-benchmark-runs/l05-scene-qualification-20261030')

def save(path, value):
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
def load(path):
    return json.loads(path.read_text(encoding='utf-8'))
def read(db,table):
    with closing(sqlite3.connect(db.resolve().as_uri()+'?mode=ro',uri=True)) as c:
        c.row_factory=sqlite3.Row
        return [dict(row) for row in c.execute('SELECT * FROM '+table)]
def snapshot(db):
    return {table:read(db,table) for table in ['journal','opening','adjustments','notes','projection','postings','control']}
def target(journal):
    rows=defaultdict(list)
    for row in journal:
        rows[row['tenant'],row['event_id']].append(row)
    result={}
    for key, group in rows.items():
        rev=max(row['revision'] for row in group)
        payloads={(row['kind'],row['amount_minor']) for row in group if row['revision']==rev}
        result[key]=(rev,'quarantined',0) if len(payloads)>1 else (rev,*next(iter(payloads)))
    return result
def sources(authority):
    result={(r['tenant'],'opening','opening'):r['amount_minor'] for r in authority['opening']}
    result.update({(tenant,'business',event):state[2] for (tenant,event),state in target(authority['journal']).items()})
    result.update({(r['tenant'],'adjustment',r['adjustment_id']):r['amount_minor'] for r in authority['adjustments']})
    return result
def account(source):
    result=defaultdict(int)
    for (tenant,kind,key),amount in source.items(): result[tenant]+=amount
    return dict(result)

initial=load(ROOT/'inputs/initial-authority.json')
future=load(ROOT/'inputs/future-events.json')
expected=json.loads(json.dumps(initial))
base=max(row['seq'] for row in initial['journal'])
for index,event in enumerate(future,base+1):
    expected['journal'].append({'seq':index,**event,'payload':json.dumps(event,sort_keys=True,ensure_ascii=False,separators=(',',':'))})
# These two evaluator-issued values are explicit in run_scene.replay, not inferred
# from a candidate's current database or totals. The scope remains author schema.
expected['adjustments'].append({'tenant':'A','adjustment_id':'approved-2','amount_minor':-5,'approval':'approval-A2'})
expected['notes'].append({'tenant':'B','note_id':'new-note','body':'After repair: retain evidence'})
save(ROOT/'independent-expected-authority.json',expected)

original=snapshot(ROOT/'inputs/original-local.sqlite')
original_effects=read(ROOT/'inputs/original-remote.sqlite','effects')
checks=[]
def check(name,condition,detail=None):
    checks.append({'contract':name,'passed':bool(condition),'detail':detail})
    if not condition: raise AssertionError(name)
for table in ['journal','opening','adjustments','notes']:
    check('original_authority_matches_raw_SQL_'+table,original[table]==initial[table])
check('initial_hand_target',account(sources(initial))=={'A':1015,'B':710})
check('final_hand_target',account(sources(expected))=={'A':1130,'B':510})
original_accounts={tenant:sum(row['amount_minor'] for row in original_effects if row['tenant']==tenant) for tenant in ['A','B']}
check('raw_remote_before_repair_is_different_from_target',original_accounts=={'A':1100,'B':570})

audits=[]
for name,folder in [('main_deferred_oldest',MAIN/'deferred-oldest'),('main_incremental_newest',MAIN/'incremental-newest'),('reviewer_deferred_newest',ROOT/'newest-deferred')]:
    local=snapshot(folder/'local.sqlite')
    effects=read(folder/'remote.sqlite','effects')
    actual_authority=load(folder/'authority.json')
    check(name+'_trusted_issued_authority',actual_authority==expected)
    for table in ['journal','opening','adjustments','notes']:
        check(name+'_exact_fact_'+table,local[table]==expected[table])
    check(name+'_control_epoch_active',local['control']==[{'id':1,'epoch':2,'active':1}])
    check(name+'_Unicode_NUL_note',local['notes'][0]['body']=='核对原收据\x00保留原文')
    amounts=defaultdict(int)
    postings={(r['tenant'],r['event_id']):r for r in local['postings']}
    wire={(r['tenant'],r['event_id']):r for r in effects}
    check(name+'_unique_complete_wire_identities',len(postings)==len(local['postings'])==len(wire)==len(effects) and postings.keys()==wire.keys())
    parent_links=[]
    for key,posting in postings.items():
        payload=json.loads(posting['payload'])
        actual=wire[key]
        check(name+'_full_wire_receipt_'+posting['event_id'],set(payload)=={'tenant','event_id','kind','amount_minor','reverses'} and all(actual[k]==v for k,v in payload.items()) and posting['receipt_id']==actual['receipt_id'])
        amounts[(posting['tenant'],posting['source_kind'],posting['source_id'])]+=payload['amount_minor']
        if actual['kind']=='reversal':
            parent=postings[actual['tenant'],actual['reverses']]
            parent_wire=wire[actual['tenant'],actual['reverses']]
            check(name+'_same_tenant_positive_funding_'+posting['event_id'],parent_wire['kind']=='post' and parent_wire['amount_minor']>0)
            parent_links.append({'identity':key,'business_source':[posting['source_kind'],posting['source_id']],'funding_parent':[parent['source_kind'],parent['source_id']],'amount':actual['amount_minor']})
    check(name+'_exact_per_source_contributions',dict(amounts)=={key:value for key,value in sources(expected).items() if value!=0} or all(amounts.get(key,0)==value for key,value in sources(expected).items()) and not (amounts.keys()-sources(expected).keys()))
    balances={tenant:sum(r['amount_minor'] for r in effects if r['tenant']==tenant) for tenant in ['A','B']}
    check(name+'_account_totals',balances=={'A':1130,'B':510})
    for parent in [r for r in effects if r['kind']=='post']:
        residual=parent['amount_minor']+sum(r['amount_minor'] for r in effects if r['tenant']==parent['tenant'] and r['reverses']==parent['event_id'])
        check(name+'_parent_capacity_'+parent['event_id'],residual>=0)
    for old in original['postings']:
        current=postings[old['tenant'],old['event_id']]
        check(name+'_original_posting_immutable_'+old['event_id'],all(current[k]==v for k,v in old.items() if k!='receipt_id') and (old['receipt_id'] is None or old['receipt_id']==current['receipt_id']))
    check(name+'_original_remote_receipts_immutable',all(wire[r['tenant'],r['event_id']]==r for r in original_effects))
    check(name+'_source_and_funding_are_allowed_to_differ',any(r['business_source']!=r['funding_parent'] for r in parent_links))
    audits.append({'name':name,'posting_count':len(postings),'accounts':balances,'funding_links':parent_links,'source_contributions':[{'source':key,'amount':value} for key,value in sorted(amounts.items())],'control':local['control']})
save(ROOT/'independent-SQL-audit.json',{'status':'passed','checks':checks,'count':len(checks),'raw_remote_before_repair':original_accounts,'initial_target_from_raw':account(sources(initial)),'final_target_from_issued_facts':account(sources(expected)),'correct_strategy_audits':audits,'scope':'three correct action graphs against raw facts, not matching IDs/counts/trajectories'})

probe_root=ROOT/'checker-probes'
probe_root.mkdir(exist_ok=False)
old_keys={(row['tenant'],row['event_id']) for row in original['postings']}
local=ROOT/'newest-deferred/local.sqlite'
new_row=next(row for row in read(local,'postings') if (row['tenant'],row['event_id']) not in old_keys)
probes=[]
for name in ['partial_wire_payload','invalid_boundary_epoch']:
    folder=probe_root/name
    folder.mkdir()
    altered=folder/'local.sqlite'
    with closing(sqlite3.connect(local.resolve().as_uri()+'?mode=ro',uri=True)) as src,closing(sqlite3.connect(altered)) as dst:
        src.backup(dst)
    with sqlite3.connect(altered) as c:
        if name=='partial_wire_payload':
            payload=json.loads(new_row['payload'])
            del payload['kind'];del payload['reverses']
            c.execute('UPDATE postings SET payload=? WHERE tenant=? AND event_id=?',(json.dumps(payload),new_row['tenant'],new_row['event_id']))
        else:
            c.execute('UPDATE postings SET boundary_seq=-1,epoch=-1 WHERE tenant=? AND event_id=?',(new_row['tenant'],new_row['event_id']))
    argv=[sys.executable,'-X','utf8','-B',str(ROOT/'source-initial/evaluator/scene-source/check_scene.py'),'--authority',str(ROOT/'independent-expected-authority.json'),'--original-local',str(ROOT/'inputs/original-local.sqlite'),'--original-remote',str(ROOT/'inputs/original-remote.sqlite'),'--local',str(altered),'--remote',str(ROOT/'newest-deferred/remote.sqlite'),'--out',str(folder/'assessment.json')]
    tick=time.perf_counter();start=dt.datetime.now(dt.timezone.utc).isoformat()
    result=subprocess.run(argv,capture_output=True,text=True,encoding='utf-8',timeout=15)
    (folder/'stdout.txt').write_text(result.stdout,encoding='utf-8');(folder/'stderr.txt').write_text(result.stderr,encoding='utf-8')
    record={'name':name,'argv':argv,'returncode':result.returncode,'started_utc':start,'elapsed_seconds':time.perf_counter()-tick,'mutated_identity':[new_row['tenant'],new_row['event_id']],'actual':load(folder/'assessment.json')}
    save(folder/'command.json',record)
    probes.append(record)
save(ROOT/'checker-probe-observations.json',{'scope':'two local-only named hypotheses, no HTTP replay','probes':probes,'no_full_grader_claim':True})
print(json.dumps({'independent_SQL_checks':len(checks),'correct_graphs':len(audits),'probe_results':[{r['name']:r['actual']['status']} for r in probes]}))
