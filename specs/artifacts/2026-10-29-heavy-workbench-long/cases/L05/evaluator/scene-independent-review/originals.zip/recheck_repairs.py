"""Five readonly checker CLIs and one tiny owned receiver/consumer probe."""
from contextlib import closing
import datetime as dt
import json
from pathlib import Path
import shutil
import sqlite3
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parent
MAIN=Path('D:/opencorvus-benchmark-runs/l05-scene-qualification-20261030')
REPO=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L05')
SOURCE=ROOT/'source-repaired'
SOURCE.mkdir(exist_ok=False)
inventory=[]
for rel in ['evaluator/scene-source/scene_app.py','evaluator/scene-source/check_scene.py','evaluator/scene-source/run_scene.py','evaluator/current-source/l05_worker.py','public/l05_effects.py']:
    origin=REPO/rel;target=SOURCE/rel
    target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(origin,target)
    inventory.append({'source':str(origin),'snapshot':str(target),'byte_equal_at_capture':origin.read_bytes()==target.read_bytes(),'same_as_initial':(ROOT/'source-initial'/rel).read_bytes()==target.read_bytes()})
(ROOT/'repair-source-inventory.json').write_text(json.dumps(inventory,indent=2),encoding='utf-8')
OUT=ROOT/'repair-checks'
OUT.mkdir(exist_ok=False)
def save(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
checks=[]
cases=[('partial_wire_payload',ROOT/'checker-probes/partial_wire_payload/local.sqlite',ROOT/'newest-deferred/remote.sqlite','posting_wire_invalid'),
       ('invalid_boundary_epoch',ROOT/'checker-probes/invalid_boundary_epoch/local.sqlite',ROOT/'newest-deferred/remote.sqlite','posting_epoch_boundary_invalid'),
       ('correct_oldest_deferred',MAIN/'deferred-oldest/local.sqlite',MAIN/'deferred-oldest/remote.sqlite',None),
       ('correct_newest_incremental',MAIN/'incremental-newest/local.sqlite',MAIN/'incremental-newest/remote.sqlite',None),
       ('correct_newest_deferred',ROOT/'newest-deferred/local.sqlite',ROOT/'newest-deferred/remote.sqlite',None)]
for name,local,remote,expected_error in cases:
    folder=OUT/name;folder.mkdir()
    argv=[sys.executable,'-X','utf8','-B',str(SOURCE/'evaluator/scene-source/check_scene.py'),'--authority',str(ROOT/'independent-expected-authority.json'),'--original-local',str(ROOT/'inputs/original-local.sqlite'),'--original-remote',str(ROOT/'inputs/original-remote.sqlite'),'--local',str(local),'--remote',str(remote),'--out',str(folder/'assessment.json')]
    tick=time.perf_counter();start=datetime=dt.datetime.now(dt.timezone.utc).isoformat()
    result=subprocess.run(argv,capture_output=True,text=True,encoding='utf-8',timeout=15)
    (folder/'stdout.txt').write_text(result.stdout,encoding='utf-8');(folder/'stderr.txt').write_text(result.stderr,encoding='utf-8')
    actual=json.loads((folder/'assessment.json').read_text(encoding='utf-8'))
    passed=(result.returncode==0 and actual['status']=='business_success') if expected_error is None else (result.returncode==2 and actual['status']=='business_mismatch' and expected_error in {f['error'] for f in actual['findings']})
    item={'name':name,'argv':argv,'started_utc':start,'elapsed_seconds':time.perf_counter()-tick,'returncode':result.returncode,'expected_error':expected_error,'actual':actual,'passed':passed}
    save(folder/'command.json',item);checks.append(item)
    if not passed:raise AssertionError(item)

sys.path.insert(0,str(SOURCE/'evaluator/scene-source'))
import scene_app as app
import run_scene
delivery=OUT/'consumer-wire-check';delivery.mkdir()
def backup(source,target):
    with closing(sqlite3.connect(source.resolve().as_uri()+'?mode=ro',uri=True)) as src,closing(sqlite3.connect(target)) as dst:src.backup(dst)
backup(ROOT/'newest-deferred/remote.sqlite',delivery/'remote.sqlite')
backup(ROOT/'newest-deferred/local.sqlite',delivery/'valid.sqlite')
backup(ROOT/'newest-deferred/local.sqlite',delivery/'identity-mismatch.sqlite')
probe=json.loads((ROOT/'checker-probes/partial_wire_payload/command.json').read_text(encoding='utf-8'))
tenant,key=probe['mutated_identity']
with sqlite3.connect(delivery/'identity-mismatch.sqlite') as c:
    payload=json.loads(c.execute('SELECT payload FROM postings WHERE tenant=? AND event_id=?',(tenant,key)).fetchone()[0])
    payload['tenant']='B' if tenant=='A' else 'A'
    c.execute('UPDATE postings SET payload=? WHERE tenant=? AND event_id=?',(json.dumps(payload),tenant,key))
process,stderr,url=run_scene.start_receiver(delivery/'remote.sqlite',delivery)
consumer=[]
try:
    good=app.deliver_one(delivery/'valid.sqlite',url,tenant,key)
    assert good['status']=='confirmed'
    consumer.append({'case':'valid_full_wire','actual':good,'passed':True})
    for name,db,expected_error in [('missing_wire_fields',ROOT/'checker-probes/partial_wire_payload/local.sqlite','local_posting_wire_invalid:fields'),('local_joint_identity',delivery/'identity-mismatch.sqlite','local_posting_identity_mismatch')]:
        try:
            actual=app.deliver_one(db,url,tenant,key)
            item={'case':name,'actual':actual,'passed':False}
        except ValueError as error:
            item={'case':name,'error_type':type(error).__name__,'message':str(error),'passed':str(error)==expected_error}
        consumer.append(item)
        assert item['passed'],item
finally:
    run_scene.stop_receiver(process,stderr,delivery)
    save(delivery/'consumer-results.json',{'cases':consumer,'owned_receiver_pid':process.pid,'exitcode':process.returncode,'scope':'one tiny consumer probe only, not a second scene replay'})
save(ROOT/'repair-assessment.json',{'status':'passed','readonly_checker_contracts':checks,'real_consumer_cases':consumer,'owned_receiver_exitcode':process.returncode,'complete_cold_replays_added':0,'candidate_score':None})
print(json.dumps({'status':'passed','checker_CLIs':len(checks),'consumer_cases':len(consumer),'receiver_pid':process.pid,'exitcode':process.returncode,'new_complete_cold_runs':0}))
