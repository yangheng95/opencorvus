"""Explicit final projection/status comparison, no app/checker import."""
from collections import defaultdict
from contextlib import closing
import json
from pathlib import Path
import sqlite3

root=Path(__file__).resolve().parent
main=Path('D:/opencorvus-benchmark-runs/l05-scene-qualification-20261030')
authority=json.loads((root/'independent-expected-authority.json').read_text(encoding='utf-8'))
groups=defaultdict(list)
for row in authority['journal']:groups[row['tenant'],row['event_id']].append(row)
expected={}
for key,rows in groups.items():
    rev=max(row['revision'] for row in rows)
    top={(row['kind'],row['amount_minor']) for row in rows if row['revision']==rev}
    expected[key]=(rev,'quarantined',0) if len(top)>1 else (rev,*next(iter(top)))
results=[]
for name,db in [('oldest_deferred',main/'deferred-oldest/local.sqlite'),('newest_incremental',main/'incremental-newest/local.sqlite'),('newest_deferred',root/'newest-deferred/local.sqlite')]:
    with closing(sqlite3.connect(db.resolve().as_uri()+'?mode=ro',uri=True)) as c:
        actual={(t,e):(rev,status,amount) for t,e,rev,status,amount in c.execute('SELECT tenant,event_id,revision,status,amount_minor FROM projection')}
    result={'case':name,'passed':actual==expected,'actual':[{'business':key,'state':value} for key,value in sorted(actual.items())]}
    results.append(result)
    assert result['passed'],result
(root/'independent-projection-audit.json').write_text(json.dumps({'status':'passed','cases':results,'expected_from_issued_authority':[{'business':key,'state':value} for key,value in sorted(expected.items())]},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'correct_projections':len(results),'new_HTTP_or_cold_run':False}))
