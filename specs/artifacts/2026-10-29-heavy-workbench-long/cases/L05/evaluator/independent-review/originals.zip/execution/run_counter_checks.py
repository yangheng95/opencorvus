"""Independent cheap controls, no repeat of the original cold qualification."""
import datetime as dt
import json
import pathlib
import shutil
import sqlite3
import subprocess
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parent
CASE = pathlib.Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L05')
PY = [sys.executable, '-X', 'utf8', '-B']

def save(path, obj):
    path.write_text(json.dumps(obj, indent=2), encoding='utf-8')

def execute(argv, prefix):
    start = dt.datetime.now(dt.timezone.utc).isoformat()
    tick = time.perf_counter()
    with prefix.with_suffix('.stdout.txt').open('w', encoding='utf-8') as out, prefix.with_suffix('.stderr.txt').open('w', encoding='utf-8') as err:
        proc = subprocess.Popen(argv, stdout=out, stderr=err, text=True, encoding='utf-8')
        save(prefix.with_suffix('.launch.json'), {'argv': argv, 'pid': proc.pid, 'started_utc': start})
        code = proc.wait(timeout=45)
    receipt = {'argv': argv, 'pid': proc.pid, 'started_utc': start, 'ended_utc': dt.datetime.now(dt.timezone.utc).isoformat(), 'elapsed_seconds': time.perf_counter()-tick, 'returncode': code}
    save(prefix.with_suffix('.command.json'), receipt)
    return receipt

source = ROOT / 'counterexample-source'
source.mkdir(exist_ok=False)
paths = [CASE / 'public/l05_effects.py', CASE / 'evaluator/current-source/l05_worker.py', CASE / 'evaluator/current-source/check_l05_state.py', CASE / 'evaluator/counterexamples/bad_worker.py', CASE / 'evaluator/counterexamples/qualify_counterexamples.py']
inventory = []
for path in paths:
    target = source / path.name
    shutil.copyfile(path, target)
    inventory.append({'origin': str(path), 'snapshot': str(target), 'byte_equal_at_capture': path.read_bytes() == target.read_bytes(), 'byte_length': target.stat().st_size})
save(ROOT / 'counterexample-source-inventory.json', inventory)
for name in ['l05_effects.py', 'l05_worker.py']:
    if (ROOT / 'source-a' / name).read_bytes() != (source / name).read_bytes():
        raise AssertionError('review_subject_changed: ' + name)
events = ROOT / 'cold-a/accepted-events.json'
receipt = execute(PY + [str(source / 'qualify_counterexamples.py'), '--source', str(source), '--events', str(events), '--out', str(ROOT / 'counterexamples-independent')], ROOT / 'counterexamples')
if receipt['returncode'] != 0:
    raise AssertionError('counterexamples_failed')

probe_root = ROOT / 'checker-probes'
probe_root.mkdir(exist_ok=False)
expected = json.loads(events.read_text(encoding='utf-8'))
results = []

def backup(origin, target):
    with sqlite3.connect(origin.as_uri() + '?mode=ro', uri=True) as src, sqlite3.connect(target) as dest:
        src.backup(dest)

def probe(name, mutate, required):
    where = probe_root / name
    where.mkdir()
    local, remote = where / 'business.sqlite', where / 'remote.sqlite'
    backup(ROOT / 'cold-a/business.sqlite', local)
    backup(ROOT / 'cold-a/remote.sqlite', remote)
    chosen = where / 'events.json'
    save(chosen, expected)
    mutate(local, remote, chosen)
    record = execute(PY + [str(source / 'check_l05_state.py'), '--events', str(chosen), '--local', str(local), '--remote', str(remote), '--out', str(where / 'assessment.json')], where / 'checker')
    actual = json.loads((where / 'assessment.json').read_text(encoding='utf-8'))
    errors = {item['error'] for item in actual.get('findings', [])}
    passed = record['returncode'] == 2 and (required <= errors if required else actual['status'] == 'run_invalid')
    results.append({'name': name, 'passed': passed, 'status': actual['status'], 'error_codes': sorted(errors), 'required': sorted(required), 'actual': actual})
    if not passed:
        raise AssertionError(results[-1])

def changed_same_total(local, remote, events):
    with sqlite3.connect(local) as c:
        for event_id, amount in [('E1', 101), ('R1', -31)]:
            payload = json.loads(c.execute('SELECT payload FROM entries WHERE tenant=? AND event_id=?', ('A', event_id)).fetchone()[0])
            payload['amount_minor'] = amount
            c.execute('UPDATE entries SET payload=?,amount_minor=? WHERE tenant=? AND event_id=?', (json.dumps(payload), amount, 'A', event_id))
        if c.execute("SELECT SUM(amount_minor) FROM entries WHERE tenant='A'").fetchone()[0] != 70:
            raise AssertionError('aggregate_fixture')

def wrong_identity(local, remote, events):
    with sqlite3.connect(local) as c:
        for table in ['entries', 'outbox']:
            c.execute('UPDATE ' + table + ' SET event_id=? WHERE tenant=? AND event_id=?', ('E2', 'B', 'E1'))
    with sqlite3.connect(remote) as c:
        c.execute('UPDATE effects SET event_id=? WHERE tenant=? AND event_id=?', ('E2', 'B', 'E1'))

def duplicate(local, remote, events):
    with sqlite3.connect(local) as c:
        c.execute('ALTER TABLE entries RENAME TO original_entries')
        c.execute('CREATE TABLE entries AS SELECT * FROM original_entries')
        c.execute("INSERT INTO entries SELECT * FROM original_entries WHERE tenant='B'")

def swapped_receipts(local, remote, events):
    with sqlite3.connect(local) as c:
        rows = c.execute("SELECT event_id,receipt_id FROM outbox WHERE tenant='A' ORDER BY event_id").fetchall()
        for row, other in zip(rows, rows[::-1]):
            c.execute('UPDATE outbox SET receipt_id=? WHERE tenant=? AND event_id=?', (other[1], 'A', row[0]))

def repeated_expected(local, remote, events):
    save(events, expected + [expected[0]])

probe('same_total_wrong_per_identity', changed_same_total, {'local_entry_payload_mismatch'})
probe('missing_and_extra_same_tenant', wrong_identity, {'local_entry_missing', 'remote_effect_missing', 'unexpected_business_identity'})
probe('duplicate_actual_identity', duplicate, {'entries_duplicate_identity'})
probe('swapped_real_receipts', swapped_receipts, {'receipt_binding_mismatch'})
probe('duplicate_trusted_expected', repeated_expected, set())

# Independently inspect the two wrong controls, not just harness assertions.
controls = []
for name in ['global_event_id', 'early_sent']:
    where = ROOT / 'counterexamples-independent' / name
    with sqlite3.connect((where / 'business.sqlite').as_uri() + '?mode=ro', uri=True) as c:
        local_rows = c.execute('SELECT tenant,event_id,amount_minor FROM entries ORDER BY tenant,event_id').fetchall()
        outbox = c.execute('SELECT tenant,event_id,receipt_id FROM outbox ORDER BY tenant,event_id').fetchall()
    with sqlite3.connect((where / 'remote.sqlite').as_uri() + '?mode=ro', uri=True) as c:
        effects = c.execute('SELECT tenant,event_id,amount_minor,receipt_id FROM effects ORDER BY tenant,event_id').fetchall()
    if name == 'global_event_id':
        passed = [(r[0], r[1], r[2]) for r in local_rows] == [('A','E1',100), ('A','R1',-30)] and [(r[0], r[1], r[2]) for r in effects] == [('A','E1',100), ('A','R1',-30)]
    else:
        passed = len(local_rows) == 3 and effects == [] and len(outbox) == 3 and all(r[2] == 'sent-before-request' for r in outbox)
    controls.append({'fault': name, 'passed': passed, 'local_rows': local_rows, 'outbox': outbox, 'actual_remote_effects': effects})
    if not passed:
        raise AssertionError(controls[-1])
save(ROOT / 'checker-probe-assessment.json', {'status': 'passed', 'probes': results, 'wrong_control_SQL': controls, 'scope': 'five_small_checker_contracts_and_two_real_wrong_controls', 'candidate_score': None})
print(json.dumps({'status': 'passed', 'counterexamples_elapsed_seconds': receipt['elapsed_seconds'], 'checker_probes': len(results), 'independent_wrong_control_SQL': len(controls)}))
