"""One authorized cold mini replay; only harness-owned child processes."""
from datetime import datetime,timezone
import json,os
from pathlib import Path
import shutil,subprocess,sys,time
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
ORIGINAL=Path('D:/opencorvus-benchmark-runs/l05-effect-qualification-20261030/executed-source-a')
REPO=Path('D:/myhexin-local/opencorvus')
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def main():
    source=ROOT/'source-a';source.mkdir(exist_ok=False)
    copied=[]
    for n in ('l05_effects.py','l05_worker.py','qualify_l05.py'):
        shutil.copy2(ORIGINAL/n,source/n);copied.append({'original':str(ORIGINAL/n),'copy':str(source/n),'same_bytes_at_copy':(ORIGINAL/n).read_bytes()==(source/n).read_bytes()})
    save(ROOT/'source-inventory.json',copied)
    shutil.copy2(REPO/'specs/artifacts/2026-10-29-heavy-workbench-long/cases/L05/public/PROTOCOL.draft.md',ROOT/'PROTOCOL-reviewed.md')
    (ROOT/'Recall.md').write_text('''# Recall\n\n授权一次同范围3源码冷复跑原40小协议；源/公开协议已只读审完，Popen只拥有本harness新建服务/worker，随机loopback端口，故障仅其握手原Popen句柄。只写本目录，不改repo/主方源码/原件，不动用户/L06/旧容器，不委托或用Provider/solver/GPU/Docker/UI。先独立两库/SQL/收据/真实首次丢ACK与恢复，再读/审两个错误控制和checker；不重复原40，不当完整L05/候选评分/小时认证。\n''',encoding='utf-8')
    argv=[sys.executable,'-X','utf8','-B',str(source/'qualify_l05.py'),'--source',str(source),'--out',str(ROOT/'cold-a')]
    env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1'
    stamp=datetime.now(timezone.utc).isoformat();t=time.perf_counter();p=subprocess.Popen(argv,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8',env=env)
    save(ROOT/'launch.json',{'argv':argv,'harness_pid':p.pid,'started_utc':stamp,'only_harness_owned_children_allowed':True,'old_output_or_database_copied':False})
    stdout,stderr=p.communicate()
    (ROOT/'cold-stdout.txt').write_text(stdout,encoding='utf-8');(ROOT/'cold-stderr.txt').write_text(stderr,encoding='utf-8')
    receipt={'argv':argv,'harness_pid':p.pid,'exit_code':p.returncode,'complete_harness_seconds':time.perf_counter()-t,'started_utc':stamp,'finished_utc':datetime.now(timezone.utc).isoformat(),'scope':'one source-only local mini protocol replay, not full L05'}
    save(ROOT/'cold-command.json',receipt);print(json.dumps(receipt,ensure_ascii=False,indent=2));print(stdout);print(stderr)

if __name__=='__main__':main()
