"""Archive already-completed independent evidence; does not execute experiments."""
import datetime as dt
import json
import pathlib
import shutil

ROOT = pathlib.Path(__file__).resolve().parent
CASE = pathlib.Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L05')
def load(relative):
    return json.loads((ROOT / relative).read_text(encoding='utf-8'))
def save(relative, value):
    (ROOT / relative).write_text(json.dumps(value, indent=2), encoding='utf-8')

protocol = CASE / 'public/PROTOCOL.draft.md'
shutil.copyfile(protocol, ROOT / 'PROTOCOL-final-reviewed.md')
identities = []
for rel, snap in [
    ('public/l05_effects.py', 'source-a/l05_effects.py'),
    ('evaluator/current-source/l05_worker.py', 'source-a/l05_worker.py'),
    ('evaluator/current-source/qualify_l05.py', 'source-a/qualify_l05.py'),
    ('evaluator/current-source/check_l05_state.py', 'counterexample-source/check_l05_state.py'),
    ('evaluator/counterexamples/bad_worker.py', 'counterexample-source/bad_worker.py'),
    ('evaluator/counterexamples/qualify_counterexamples.py', 'counterexample-source/qualify_counterexamples.py'),
]:
    identities.append({'current_source': str(CASE / rel), 'reviewed_snapshot': str(ROOT / snap), 'actual_byte_equal': (CASE / rel).read_bytes() == (ROOT / snap).read_bytes()})
save('final-source-identity.json', {'checked_utc': dt.datetime.now(dt.timezone.utc).isoformat(), 'method': 'direct byte comparison, identity observation only; not a correctness gate', 'files': identities, 'protocol_current_archive': str(ROOT / 'PROTOCOL-final-reviewed.md')})
cold = load('cold-command.json')
sql = load('independent-SQL-audit.json')
controls = load('counterexamples.command.json')
probes = load('checker-probe-assessment.json')
boundary = load('http-boundaries/receipt.json')
assessment = {
    'reviewer': '/root/benchmark_review',
    'stage': 'L05 mini cooperative external-effect protocol qualification',
    'conclusion': 'mini_protocol_locally_qualified_no_current_substantive_blocker',
    'blocking_findings': [],
    'plan_initial_P1': [
        {'id': 'P1-01', 'issue': 'static schema, immutable-key replay/conflict, then dynamic reversal ordering', 'status': 'resolved_in_public_contract_source_and_real_boundaries'},
        {'id': 'P1-02', 'issue': 'true first POST commit with lost ACK, rather than preloaded/replayed effect', 'status': 'resolved_in_real_cold_HTTP_SQL_and_worker_crash_evidence'},
    ],
    'completed_evidence': {
        'source_only_cold_replays': 1,
        'cold': cold,
        'harness_contracts': 40,
        'independent_readonly_SQL_checks': sql['check_count'],
        'real_wrong_controls': 2,
        'control_command': controls,
        'checker_positive_error_contracts': len(probes['probes']),
        'additional_real_HTTP_boundaries': boundary['check_count'],
        'additional_HTTP_command': {k: boundary[k] for k in ['argv', 'pid', 'returncode', 'elapsed_seconds', 'started_utc', 'ended_utc']},
        'all_reviewed_current_execution_sources_match_snapshots': all(row['actual_byte_equal'] for row in identities),
    },
    'limits': [
        'worker ingest is only the trusted accepted-event witness, not a complete generic business ingress',
        'checker scope is the complete declared A/B tenant partition; separate T/X probes are not core accepted events',
        'SQL service decisions are not proof a client received an ACK; malformed HTTP is captured outside the request table',
        'two intentionally bad implementations and five checker probes are not exhaustive adversarial or scientific calibration',
        'no changed-key wrong worker, arbitrary dirty-database repair, revision/multicurrency, monitoring, full grader, or full candidate run was qualified',
        'one local host/process-crash run does not establish power-loss durability, authentication isolation, statistical reliability, or long-horizon difficulty',
    ],
    'qualification_approved': 'only this explicitly synthetic, cooperative loopback HTTP/SQLite mini and the tested evidence/error contracts',
    'full_L05_frozen': False,
    'hours_validated': False,
    'candidate_score': None,
    'benchmark_ten_cases_complete': False,
    'remaining_own_active_experiments': 0,
    'process_scope': 'only owned Popen handles; no user services, L06 candidate, credentials, Provider, GPU, solver, Docker, UI or delegation accessed',
}
save('stage-assessment.json', assessment)
print(json.dumps({'source_byte_identity_checks': len(identities), 'all_match': assessment['completed_evidence']['all_reviewed_current_execution_sources_match_snapshots'], 'stage_assessment': str(ROOT / 'stage-assessment.json')}))
