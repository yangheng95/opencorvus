"""Own loopback service; rejected-key recovery and identity ordering boundaries."""
import concurrent.futures
import datetime as dt
import json
import pathlib
import queue
import sqlite3
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request

ROOT = pathlib.Path(__file__).resolve().parent
OUT = ROOT / 'http-boundaries'
OUT.mkdir(exist_ok=False)
argv = [sys.executable, '-X', 'utf8', '-B', str(ROOT / 'source-a/l05_effects.py'), '--db', str(OUT / 'remote.sqlite')]
http, checks = [], []
started = dt.datetime.now(dt.timezone.utc).isoformat()
tick = time.perf_counter()

def save(name, obj):
    (OUT / name).write_text(json.dumps(obj, indent=2), encoding='utf-8')

def check(name, condition):
    checks.append({'contract': name, 'passed': bool(condition)})
    if not condition:
        raise AssertionError(name)

def payload(tenant, key, amount, parent=None):
    return {'tenant': tenant, 'event_id': key, 'kind': 'post' if parent is None else 'reversal', 'amount_minor': amount, 'reverses': parent}

def post(data):
    req = urllib.request.Request(url + '/effects', json.dumps(data).encode(), {'Content-Type': 'application/json'}, method='POST')
    try:
        with urllib.request.urlopen(req, timeout=10) as response:
            code, body = response.status, json.load(response)
    except urllib.error.HTTPError as error:
        code, body = error.code, json.load(error)
    result = {'request': data, 'code': code, 'body': body}
    http.append(result)
    return result

with (OUT / 'server.stderr.txt').open('w', encoding='utf-8') as err:
    server = subprocess.Popen(argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=err, text=True, encoding='utf-8')
    try:
        channel = queue.Queue()
        threading.Thread(target=lambda: channel.put(server.stdout.readline()), daemon=True).start()
        ready = json.loads(channel.get(timeout=10))
        save('launch.json', {'argv': argv, 'pid': server.pid, 'ready': ready, 'started_utc': started})
        check('ready_matches_owned_Popen_PID', ready['pid'] == server.pid)
        url = ready['url']
        check('parent100_applied', post(payload('X', 'P', 100))['code'] == 201)
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            raced = list(pool.map(post, [payload('X', 'R1', -60, 'P'), payload('X', 'R2', -60, 'P')]))
        check('concurrent_one_applied_one_named_overage', sorted(r['body']['status'] for r in raced) == ['applied', 'reversal_exceeds_original'])
        winner = next(r for r in raced if r['code'] == 201)
        loser = next(r for r in raced if r['code'] == 409)
        winner_id, loser_id = winner['request']['event_id'], loser['request']['event_id']
        retry = post(payload('X', loser_id, -40, 'P'))
        check('rejected_identity_can_first_apply_corrected40', retry['code'] == 201 and retry['body']['status'] == 'applied')
        conflict = post(payload('X', winner_id, -40, 'P'))
        check('successful_identity_changed_payload_conflict', conflict['code'] == 409 and conflict['body']['status'] == 'idempotency_conflict' and conflict['body']['receipt'] == winner['body']['receipt'])
        replay = post(payload('X', winner_id, -60, 'P'))
        check('original_success_replays_after_balance_zero', replay['code'] == 200 and replay['body']['status'] == 'replayed' and replay['body']['receipt'] == winner['body']['receipt'])
        bad = payload('X', winner_id, -60, 'P')
        bad['amount_minor'] = True
        rejected = post(bad)
        check('static_domain_precedes_known_key', rejected['code'] == 422 and rejected['body'] == {'status': 'invalid_request', 'field': 'amount_minor'})
        check('other_tenant_parent_applies', post(payload('U', 'P', 5))['code'] == 201)
        pending = post(payload('T', 'R', -5, 'P'))
        check('cross_tenant_parent_does_not_satisfy_dependency', pending['code'] == 409 and pending['body']['status'] == 'dependency_pending')
        check('own_tenant_parent_applies', post(payload('T', 'P', 5))['code'] == 201)
        completed = post(payload('T', 'R', -5, 'P'))
        check('pending_identity_first_applies_after_own_parent', completed['code'] == 201 and completed['body']['status'] == 'applied')
        with sqlite3.connect((OUT / 'remote.sqlite').as_uri() + '?mode=ro', uri=True) as conn:
            conn.row_factory = sqlite3.Row
            effects = [dict(row) for row in conn.execute('SELECT * FROM effects ORDER BY tenant,event_id')]
            requests = [dict(row) for row in conn.execute('SELECT * FROM requests ORDER BY seq')]
        check('X_final_zero_with_three_distinct_effects', sum(row['amount_minor'] for row in effects if row['tenant'] == 'X') == 0 and len([row for row in effects if row['tenant'] == 'X']) == 3)
        check('real_request_sequence_of_rejected_then_applied_key', [r['status'] for r in requests if r['tenant'] == 'X' and r['event_id'] == loser_id] == ['reversal_exceeds_original', 'applied'])
        save('SQL.json', {'effects': effects, 'requests': requests, 'winner': winner_id, 'loser': loser_id})
        server.stdin.write('stop\n')
        server.stdin.flush()
        stdout, stderr = server.communicate(timeout=15)
        check('own_server_graceful_exit0', server.returncode == 0)
    finally:
        if server.poll() is None:
            server.kill()
            server.communicate(timeout=15)
        save('http.json', http)
        save('receipt.json', {'checks': checks, 'check_count': len(checks), 'status': 'passed' if checks and all(c['passed'] for c in checks) else 'failed', 'argv': argv, 'pid': server.pid, 'returncode': server.returncode, 'started_utc': started, 'ended_utc': dt.datetime.now(dt.timezone.utc).isoformat(), 'elapsed_seconds': time.perf_counter()-tick, 'candidate_score': None, 'scope': 'mini_extra_boundaries_only'})
print(json.dumps({'status': 'passed', 'checks': len(checks), 'pid': server.pid, 'returncode': server.returncode}))
