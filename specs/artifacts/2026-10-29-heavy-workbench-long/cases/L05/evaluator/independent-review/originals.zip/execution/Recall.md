# Recall

授权一次同范围3源码冷复跑原40小协议；源/公开协议已只读审完，Popen只拥有本harness新建服务/worker，随机loopback端口，故障仅其握手原Popen句柄。只写本目录，不改repo/主方源码/原件，不动用户/L06/旧容器，不委托或用Provider/solver/GPU/Docker/UI。先独立两库/SQL/收据/真实首次丢ACK与恢复，再读/审两个错误控制和checker；不重复原40，不当完整L05/候选评分/小时认证。
