"""Independent read-only facts from this reviewer's one cold replay."""
from contextlib import closing
from collections import Counter
import json
from pathlib import Path
import sqlite3
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'cold-a'
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def read(db,sql):
    with closing(sqlite3.connect(db.resolve().as_uri()+'?mode=ro',uri=True)) as c:
        c.row_factory=sqlite3.Row;return [dict(r) for r in c.execute(sql)]
def main():
    effects=read(OUT/'remote.sqlite','SELECT * FROM effects ORDER BY tenant,event_id');entries=read(OUT/'business.sqlite','SELECT * FROM entries ORDER BY tenant,event_id');outbox=read(OUT/'business.sqlite','SELECT * FROM outbox ORDER BY tenant,event_id');requests=read(OUT/'remote.sqlite','SELECT * FROM requests ORDER BY seq');drop=read(OUT/'remote.sqlite','SELECT * FROM drop_once');isolation=read(OUT/'isolated.sqlite','SELECT * FROM effects')
    expected={(e['tenant'],e['event_id']):e for e in load(OUT/'accepted-events.json')};remote={(e['tenant'],e['event_id']):e for e in effects};local={(e['tenant'],e['event_id']):e for e in entries};confirmed={(e['tenant'],e['event_id']):e['receipt_id'] for e in outbox}
    checks=[]
    def check(name,ok,detail=None):checks.append({'contract':name,'passed':bool(ok),'detail':detail})
    check('all3_core_local_identities',set(local)==set(expected));check('all3_core_confirmations',set(confirmed)==set(expected))
    for key,wanted in expected.items():
        check(str(key)+'.local_payload',json.loads(local[key]['payload'])==wanted and local[key]['amount_minor']==wanted['amount_minor'])
        check(str(key)+'.real_remote_payload',all(remote[key][k]==v for k,v in wanted.items()))
        check(str(key)+'.same_receipt_binding',confirmed[key]==remote[key]['receipt_id'] and type(confirmed[key]) is str and bool(confirmed[key]))
    totals={t:sum(e['amount_minor'] for e in effects if e['tenant']==t) for t in ('A','B','T','X')};check('core_totals_from_real_external_rows',(totals['A'],totals['B'])==(70,200));check('separate_probe_totals',(totals['T'],totals['X'])==(0,40));check('remote7_and_local3',len(effects)==7 and len(entries)==3)
    sequence=[{'seq':r['seq'],'method':r['method'],'status':r['status'],'receipt_id':r['receipt_id'],'dropped':r['dropped']} for r in requests if (r['tenant'],r['event_id'])==('A','E1')]
    check('true_first_request_unknown_then_first_post_committed_drop',[(r['method'],r['status'],r['dropped']) for r in sequence[:2]]==[('GET','unknown',0),('POST','applied',1)])
    check('one_durable_drop_consumption',drop==[{'tenant':'A','event_id':'E1','consumed':1}] and sum(r['dropped'] for r in requests)==1)
    rid=remote[('A','E1')]['receipt_id'];check('later_A_observations_keep_original_receipt',all(r['receipt_id']==rid for r in sequence[1:]) and any(r['method']=='POST' and r['status']=='replayed' for r in sequence[2:]))
    t=[r['status'] for r in requests if (r['tenant'],r['event_id'])==('T','R')];check('pending_rejection_does_not_reserve_and_full_replay',t==['dependency_pending','applied','replayed'])
    x=[r['status'] for r in requests if r['tenant']=='X' and r['event_id'] in ('R1','R2')];check('concurrent_overage_has_one_winner',sorted(x)==['applied','reversal_exceeds_original'])
    b=[r['status'] for r in requests if r['tenant']=='B' and r['event_id']=='E1' and r['method']=='POST'];check('parallel_post_once_plus_replays',Counter(b)==Counter({'applied':1,'replayed':7}))
    commands=load(OUT/'commands.json');checkpoints=[c for c in commands if 'checkpoint' in c];kills=[c for c in commands if c.get('action')=='terminate_owned_checkpoint_process'];check('owned_real_worker_termination',len(checkpoints)==len(kills)==1 and checkpoints[0]['pid']==checkpoints[0]['checkpoint']['pid']==kills[0]['pid'] and kills[0]['returncode'] is not None and kills[0]['returncode']!=0)
    check('correct_worker_boundary_and_receipt',checkpoints[0]['checkpoint']['stage']=='after_remote_receipt_before_local_commit' and checkpoints[0]['checkpoint']['receipt']=={k:remote[('A','E1')][k] for k in ('receipt_id','tenant','event_id','kind','amount_minor','reverses')})
    servers=load(OUT/'servers.json');check('all3_owned_servers_naturally_joined',len(servers)==3 and all(s['returncode']==0 and s['ready']['status']=='ready' for s in servers));check('separate_instance_same_key_different_effect',len(isolation)==1 and isolation[0]['tenant']=='A' and isolation[0]['event_id']=='E1' and isolation[0]['amount_minor']==101 and remote[('A','E1')]['amount_minor']==100)
    result={'status':'passed' if all(r['passed'] for r in checks) else 'has_failures','checks':checks,'check_count':len(checks),'actual_external_effects':effects,'actual_local_entries':entries,'actual_local_confirmations':outbox,'actual_A_E1_request_sequence':sequence,'actual_probe_totals':totals,'request_decision_counts':dict(Counter(r['status'] for r in requests)),'requests_scope':'valid business POST/GET decisions, not all malformedHTTP and not proof of response observed byclient','owned_checkpoint_termination':kills,'owned_servers':servers,'source_only_cold_replays':1,'full_L05_frozen':False,'candidate_score':None}
    (ROOT/'independent-SQL-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps({'status':result['status'],'checks':len(checks),'external_effects':len(effects),'core_local_entries':len(entries),'totals':totals,'owned_kill_pid':kills[0]['pid'],'all_servers_exit0':all(s['returncode']==0 for s in servers)},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
