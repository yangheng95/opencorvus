import argparse
from pathlib import Path
from l10_core import read,save
from l10_report import report
p=argparse.ArgumentParser();p.add_argument('--data',type=Path);p.add_argument('--evidence',type=Path);p.add_argument('--out',type=Path);a=p.parse_args();report(a.data,a.evidence,a.out);j=read(a.out/'study.json');j['cash']=True;save(a.out/'study.json',j)
