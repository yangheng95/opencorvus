"""Actual L10 artifacts, authoritative plant facts, registered input and fixed rubric."""
import argparse,csv,json,math,sqlite3
from pathlib import Path
from l10_core import read,save,authority,initial,packet,transition,bill,economic
def numeric(x):return type(x) in (int,float) and math.isfinite(x)
def same(x,y):
 if numeric(x) and numeric(y):return abs(x-y)<=2e-5+1e-7*abs(y)
 if type(x) is not type(y):return False
 if isinstance(x,dict):return x.keys()==y.keys() and all(same(x[k],y[k]) for k in x)
 if isinstance(x,list):return len(x)==len(y) and all(same(a,b) for a,b in zip(x,y))
 return x==y
def fail(code,detail):raise ValueError(code+':'+str(detail))
def sqlsteps(root):
 p=(root/'plant.sqlite3').resolve();c=sqlite3.connect(p.as_uri()+'?mode=ro',uri=True);c.row_factory=sqlite3.Row
 try:
  if c.execute('pragma user_version').fetchone()[0]!=1:fail('plant_format',root)
  return [dict(r) for r in c.execute('select * from step order by i')]
 finally:c.close()
def csvrows(path):
 with path.open(encoding='utf-8',newline='') as f:return list(csv.DictReader(f))
def facts(run):
 reg=read(run/'runs.json');raw=Path(reg['raw']);cases=Path(reg['cases']);a=authority(raw);computed={};proof=[];errors={f'M{i:02d}':[] for i in range(1,15)};complete=read(run/'execution-status.json').get('execution_complete',False)
 audit=run/'prepare/model/audit.json'
 if not audit.exists() or not same(read(audit),a):errors['M01'].append('highest-revision/units/prior/devices/source audit differs')
 if not complete:errors['M02'].append({'code':'actual_programme_execution_incomplete','status':read(run/'execution-status.json')})
 casesmap={p.stem:read(p) for p in cases.glob('*.json')};expected={(c,s,d) for c in casesmap for s in a['sites'] for d in a['devices']};got={(r['scenario'],r['site'],r['device']) for r in reg['episodes']}
 if got!=expected or len(got)!=len(reg['episodes']):errors['M02'].append('full assigned episodes required')
 packetmap={};results=[];faults=[]
 for r in reg['episodes']:
  root=Path(r['root']);key=(r['scenario'],r['site'],r['device']);s=initial(a,r['site']);rr=[];case=casesmap[r['scenario']];rows=sqlsteps(root)
  if r['exit_code']!=0:errors['M02'].append({'episode':key,'native_exit':r['exit_code']});continue
  if len(rows)!=len(case['actual'][r['site']]):errors['M03'].append({'episode':key,'actual_rows':len(rows)});continue
  for row in rows:
   i=row['i'];p=json.loads(row['packet']);action=json.loads(row['action']);receipt=json.loads(row['receipt']);stored=json.loads(row['state']);expectedp=packet(a,case,r['site'],a['devices'][r['device']],i,s,rr)
   if not same(p,expectedp):errors['M09'].append({'episode':key,'step':i,'code':'actual_authorized_packet_mismatch'})
   packetmap[(key,i)]=(p,action)
   try:sn,phys=transition(a,r['site'],a['devices'][r['device']],s,expectedp['current'],action)
   except (ValueError,KeyError,TypeError) as e:errors['M03'].append({'episode':key,'step':i,'code':str(e)});break
   if not same(stored,sn):errors['M03'].append({'episode':key,'step':i,'code':'confirmed_soc_and_cumulative_state'})
   original=receipt.get('row',{})
   for leaf,fields in [('M03',['soc_before','soc_after','power_kw','charge_kw','discharge_kw','dt_hours']),('M04',['import_kw','curtail_kw','critical_unserved_kw','flex_unserved_kw']),('M05',['month','peak_after']),('M06',['energy_cost','wear_cost'])]:
    for field in fields:
     if field not in original or not same(original[field],phys[field]):errors[leaf].append({'episode':key,'step':i,'field':field,'observed':original.get(field),'expected':phys[field]})
   if receipt.get('key')!=f"{r['site']}:{r['device']}:{i}":errors['M10'].append({'episode':key,'step':i,'code':'receipt_joint_identity'})
   s=sn;rr.append(receipt)
  if abs(s['soc'])>2e-5:errors['M03'].append({'episode':key,'code':'terminal_soc_zero','value':s['soc']})
  actual=read(root/'result.json');b=bill(a,r['site'],s)
  if not same(actual['bill'],b):errors['M06'].append({'episode':key,'code':'energy_demand_wear_unserved_bill'})
  if not same(actual['state'],s) or not same(actual['ledger'],rr):errors['M10'].append({'episode':key,'code':'exported_original_ledger_binding'})
  for create in root.glob('*/create.json'):
   stage=create.parent;ins=read(stage/'terminal-inspect.json');mounts=ins['Mounts'];expectedmounts={'/program':str((run/'sealed-program').resolve()),'/model':str((run/'prepare/model').resolve())}
   norm=lambda x:str(x).replace('\\','/').lower()
   if ins['HostConfig']['NetworkMode']!='none' or {x['Destination'] for x in mounts}!=set(expectedmounts) or any(x['RW'] or norm(x['Source'])!=norm(expectedmounts[x['Destination']]) for x in mounts):errors['M09'].append({'episode':key,'code':'actual_actor_mount_and_network_contract'})
   if ins['State']['Status']!='exited' or ins['State']['ExitCode']!=0:errors['M02'].append({'episode':key,'code':'actual_actor_native_exit','exit':ins['State']['ExitCode']})
  if r['fault']:
   initialowner=read(root/'owner-initial.json');res=read(root/'owner-resume.json');committed=read(root/'committed-before-exit.json');replay=read(root/'resume/replay.json');oldrow=rr[committed['i']]
   ok=initialowner['exit_code']==73 and res['exit_code']==0 and same(committed['receipt'],oldrow) and replay['response']=={'acknowledged':oldrow['key']} and same(replay['receipt'],oldrow) and len(rows)==len({x['i'] for x in rows})
   if not ok:errors['M10'].append({'episode':key,'code':'committed_receipt_state_resume'})
   faults.append({'episode':key,'owner_initial':73,'owner_resume':res['exit_code'],'committed_soc':committed['soc'],'committed_peaks':committed['peaks'],'steps':len(rows),'receipt':oldrow['key']})
  results.append({**{k:r[k] for k in ['scenario','probability','site','device']},'bill':b});proof.append({'episode':key,'actual_steps':len(rows),'native':r['exit_code']})
 if len(faults)!=1:errors['M10'].append('one assigned real committed-write fault and original-state resume required')
 # Equal full observation prefixes must yield equal actions under the declared reproducible policy.
 for site in a['sites']:
  for device in a['devices']:
   for i in range(57):
    x=packetmap.get((('nominal',site,device),i));y=packetmap.get((('outage',site,device),i))
    if x and y and same(x[0],y[0]) and not same(x[1].get('power_kw'),y[1].get('power_kw')):errors['M09'].append({'site':site,'device':device,'step':i,'code':'equal_complete_visible_prefix_different_action'})
 expectedcost={site:{d:sum(r['probability']*r['bill']['total'] for r in results if r['site']==site and r['device']==d) for d in a['devices']} for site in a['sites']};critical={site:{d:sum(r['probability']*r['bill']['critical_unserved_kwh'] for r in results if r['site']==site and r['device']==d) for d in a['devices']} for site in a['sites']}
 if complete:
  delivery=run/'delivery/result';study=read(delivery/'study.json');cash=[];summaries=[];choices=[]
  for site in a['sites']:
   vv={}
   for device,dev in a['devices'].items():
    e=economic(a,dev,expectedcost[site]['ZERO'],expectedcost[site][device]);vv[device]=e['npv'];summaries.append({'site':site,'device':device,'expected_campaign_cost':expectedcost[site][device],'expected_critical_unserved_kwh':critical[site][device],'npv':e['npv'],'annual_initial_saving':e['annual_initial_saving']});cash.extend({'site':site,'device':device,**r} for r in e['cash'])
   best=min(vv,key=lambda d:(-vv[d],d));choices.append({'site':site,'selected':best,'npv':vv[best]})
  if not same(study['expected_costs'],expectedcost):errors['M07'].append('actual expected costs')
  indexed=lambda rr,fields:{tuple(r[k] for k in fields):r for r in rr}
  for field,ex,keys in [('summaries',summaries,('site','device')),('cash',cash,('site','device','year'))]:
   rr=study[field];gotmap=indexed(rr,keys);exmap=indexed(ex,keys)
   if len(gotmap)!=len(rr) or not same(gotmap,exmap):errors['M07'].append(field+' actual full financial components')
  cc={r['site']:r for r in study['choices']}
  for r in choices:
   if r['site'] not in cc or any(not same(cc[r['site']].get(k),v) for k,v in r.items()):errors['M08'].append(r)
  required=['REPORT.md','commissioning.png','campaigns.csv','cashflows.csv','dispatch.csv','audit.json','source-map.json','sensitivity.json','TEACHER-OPERATOR-HANDOVER.md']
  for n in required:
   if not (delivery/n).is_file():errors['M13'].append({'required':n})
  # Direct CSV values are checked against actual typed study/plant objects, not only row counts.
  for name,ex,keys in [('campaigns.csv',summaries,('site','device')),('cashflows.csv',cash,('site','device','year'))]:
   if not (delivery/name).is_file():continue
   rr=csvrows(delivery/name);mm={tuple(str(r[k]) for k in keys):r for r in ex};seen=set()
   for r in rr:
    k=tuple(r[x] for x in keys);seen.add(k)
    if k not in mm:errors['M13'].append({'csv':name,'key':k});continue
    for f,v in mm[k].items():
     try:ok=same(float(r[f]),v) if numeric(v) else r[f]==v
     except (KeyError,ValueError):ok=False
     if not ok:errors['M13'].append({'csv':name,'key':k,'field':f})
   if len(seen)!=len(rr) or seen!=set(mm):errors['M13'].append({'csv':name,'code':'complete_unique_grid'})
 return {'authority':a,'cases':casesmap,'expected_costs':expectedcost,'critical':critical,'errors':errors,'proof':proof,'faults':faults,'complete':complete}
def register(run,out):
 f=facts(run)
 if any(f['errors'][k] for k in ['M01','M02','M03','M04','M05','M06','M07','M08','M09','M10','M13']):fail('reference_not_qualified',f['errors'])
 save(out,{'format':'L10-registered-causal-reference/1','authority':f['authority'],'cases':f['cases'],'expected_costs':f['expected_costs'],'critical':f['critical'],'role':'author_causal_reachability_not_global_optimum','source_run':str(run.resolve())})
def assess(run,key):
 f=facts(run);k=read(key)
 if k['format']!='L10-registered-causal-reference/1' or not same(f['authority'],k['authority']) or not same(f['cases'],k['cases']):fail('facility_registered_input_mismatch',run)
 for site in f['authority']['sites']:
  for d in f['authority']['devices']:
   if f['expected_costs'][site][d]>1.02*k['expected_costs'][site][d]+1e-5:f['errors']['M11'].append({'site':site,'device':d,'observed':f['expected_costs'][site][d],'limit':1.02*k['expected_costs'][site][d]})
   if f['critical'][site][d]>k['critical'][site][d]+.0001:f['errors']['M12'].append({'site':site,'device':d,'observed':f['critical'][site][d],'limit':k['critical'][site][d]+.0001})
 # M14: assigned changed source is consumed by the same actual source-only programme;
 # raw/case identity and all dependent recomputation already have concrete checks.
 f['errors']['M14']=[{'dependency':m,'actual_findings':f['errors'][m]} for m in ['M01','M03','M04','M05','M06','M07','M08','M09','M10','M11','M12'] if f['errors'][m]]
 return f
def grade(runs,keys,rubric,review,out,role):
 leaves={};facility=[]
 for name,run in runs.items():
  try:f=assess(Path(run),Path(keys[name]))
  except (ValueError,KeyError,FileNotFoundError) as e:facility.append({'variant':name,'error':str(e)});continue
  for m,ee in f['errors'].items():
   leaves.setdefault(m,{'status':'pass','evidence':[]})
   if ee:leaves[m]['status']='fail'
   leaves[m]['evidence'].append({'variant':name,'errors':ee,'actual_episode_proof':f['proof'] if m=='M02' else None})
 if facility:save(out,{'case':'L10/0.2.0-dev','role':role,'total':None,'good':None,'facility':facility});return 3
 rv=read(review) if review else {'ratings':{}}
 if review and rv.get('run_roots')!={k:str(Path(v).resolve()) for k,v in runs.items()}:fail('review_actual_run_binding',rv)
 for m,v in rv['ratings'].items():leaves[m]=v
 total=0;unassessed=[];critical=[]
 for leaf in read(rubric)['leaves']:
  i=leaf['id'];s=leaves.get(i,{'status':'unassessed','evidence':'actual assessment pending'});leaves[i]=s
  if s['status']=='pass':total+=leaf['weight']
  elif s['status']=='unassessed':unassessed.append(i)
  if leaf['critical'] and s['status']!='pass':critical.append(i)
 save(out,{'case':'L10/0.2.0-dev','role':role,'total':None if unassessed else total,'good':None if unassessed else total>=90 and not critical,'critical_not_passed':critical,'unassessed':unassessed,'findings':leaves,'limits':'Author simulation and nonblind AI review are not field certification, real service probabilities, fresh LLM scores or effective-hour evidence.'})
 return 4 if unassessed else 2 if critical or total<90 else 0
if __name__=='__main__':
 p=argparse.ArgumentParser();sub=p.add_subparsers(dest='cmd',required=True);r=sub.add_parser('register');r.add_argument('--run',type=Path,required=True);r.add_argument('--out',type=Path,required=True)
 g=sub.add_parser('grade');g.add_argument('--runs',type=Path,required=True);g.add_argument('--keys',type=Path,required=True);g.add_argument('--rubric',type=Path,required=True);g.add_argument('--review',type=Path);g.add_argument('--out',type=Path,required=True);g.add_argument('--role',default='candidate');a=p.parse_args()
 if a.cmd=='register':register(a.run,a.out)
 else:raise SystemExit(grade(read(a.runs),read(a.keys),a.rubric,a.review,a.out,a.role))
