import argparse,json,tempfile,shutil
from pathlib import Path
from l10_report import report
from l10_core import read,save
p=argparse.ArgumentParser();p.add_argument('--data',type=Path);p.add_argument('--evidence',type=Path);p.add_argument('--out',type=Path);a=p.parse_args()
KIND='bad_peak'
if KIND=='bad_peak':
 with tempfile.TemporaryDirectory() as t:
  data=Path(t)/'fake-source';shutil.copytree(a.data,data);j=read(data/'prior-bills.json')
  for site in j:
   for month in j[site]['peak_kw']:j[site]['peak_kw'][month]=0.
  save(data/'prior-bills.json',j);report(data,a.evidence,a.out)
else:
 report(a.data,a.evidence,a.out);j=read(a.out/'study.json');authority=read(a.out/'audit.json')
 for r in j['cash']:
  if r['year']==0:r['net']=0.;r['discounted']=0.
 for r in j['summaries']:r['npv']+=authority['devices'][r['device']]['capital']
 for site in authority['sites']:
  rr=[r for r in j['summaries'] if r['site']==site];best=min(rr,key=lambda x:(-x['npv'],x['device']))
  j['choices']=[r for r in j['choices'] if r['site']!=site]+[{'site':site,'selected':best['device'],'npv':best['npv']}]
 save(a.out/'study.json',j)
