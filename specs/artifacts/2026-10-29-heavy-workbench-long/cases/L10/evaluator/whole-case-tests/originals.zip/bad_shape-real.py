from pathlib import Path
import subprocess,json,sys,time
from datetime import datetime,timezone
X=Path('D:/opencorvus-benchmark-runs/l10-full-case-20261031');E=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L10/evaluator')
run=X/'bad_shape-base-run';cmd=[sys.executable,'-X','utf8','-B',str(E/'run_l10.py'),'--submission',str(X/'bad_shape-submission'),'--raw',str(X/'raw/base'),'--cases',str(X/'cases/base'),'--out',str(run)];start=datetime.now(timezone.utc).isoformat();t=time.monotonic()
with (X/'bad_shape-native.stdout.txt').open('w',encoding='utf-8') as o,(X/'bad_shape-native.stderr.txt').open('w',encoding='utf-8') as e:p=subprocess.run(cmd,stdout=o,stderr=e)
(X/'bad_shape-native-terminal.json').write_text(json.dumps({'argv':cmd,'exit_code':p.returncode,'started_at':start,'finished_at':datetime.now(timezone.utc).isoformat(),'seconds':time.monotonic()-t},indent=2)+'\n')
(X/'bad_shape-runs.json').write_text(json.dumps({'base':str(run)},indent=2)+'\n');(X/'bad_shape-keys.json').write_text(json.dumps({'base':str(X/'reference-base-final.json')},indent=2)+'\n')
cmd=[sys.executable,'-X','utf8','-B',str(E/'check_l10.py'),'grade','--runs',str(X/'bad_shape-runs.json'),'--keys',str(X/'bad_shape-keys.json'),'--rubric',str(E.parent/'rubric.json'),'--out',str(X/'bad_shape-initial-assessment.json'),'--role','error_control'];p=subprocess.run(cmd,capture_output=True,text=True)
(X/'bad_shape-initial-checker-command.json').write_text(json.dumps({'argv':cmd,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'scope':'original real programme native output boundary, not a fabricated candidate result'},indent=2)+'\n')
