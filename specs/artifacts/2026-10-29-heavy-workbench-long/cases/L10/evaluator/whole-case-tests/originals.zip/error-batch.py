from pathlib import Path
import subprocess,json,time,sys
from datetime import datetime,timezone
X=Path('D:/opencorvus-benchmark-runs/l10-full-case-20261031');E=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L10/evaluator')
cmd='$own = Get-CimInstance Win32_Process -Filter "ProcessId = 97104"; if ($own -and ($own.CommandLine -like "*l10-full-case-20261031*batch.py*")) { Wait-Process -Id 97104 -ErrorAction SilentlyContinue }'
p=subprocess.run(['powershell','-NoProfile','-Command',cmd],capture_output=True,text=True)
(X/'error-batch-wait.json').write_text(json.dumps({'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr},indent=2)+'\n')
records=[]
for method in ['wrong_efficiency','wrong_resume','bad_peak','bad_cash']:
 root=X/(method+'-base-run');cmd=[sys.executable,'-X','utf8','-B',str(E/'run_l10.py'),'--submission',str(X/(method+'-submission')),'--raw',str(X/'raw/base'),'--cases',str(X/'cases/base'),'--out',str(root)];start=datetime.now(timezone.utc).isoformat();t=time.monotonic()
 with (X/(method+'.stdout.txt')).open('w',encoding='utf-8') as o,(X/(method+'.stderr.txt')).open('w',encoding='utf-8') as e:p=subprocess.run(cmd,stdout=o,stderr=e)
 records.append({'method':method,'argv':cmd,'started_at':start,'finished_at':datetime.now(timezone.utc).isoformat(),'exit_code':p.returncode,'seconds':time.monotonic()-t});(X/'error-batch-progress.json').write_text(json.dumps(records,indent=2)+'\n')
(X/'error-batch-terminal.json').write_text(json.dumps({'jobs':records,'scope':'one real programme per distinct business error; not candidate trials or effective hours'},indent=2)+'\n')
