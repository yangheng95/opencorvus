from pathlib import Path
import subprocess,json,time,sys
from datetime import datetime,timezone
X=Path('D:/opencorvus-benchmark-runs/l10-full-case-20261031');E=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L10/evaluator')
jobs=[('final','base'),('final','price'),('final','quote'),('dt_error','base'),('future_file','base'),('idle','base'),('idle','price'),('idle','quote'),('weak','base'),('weak','price'),('weak','quote')]
records=[]
for method,variant in jobs:
 root=X/(method+'-'+variant+'-run');cmd=[sys.executable,'-X','utf8','-B',str(E/'run_l10.py'),'--submission',str(X/(method+'-submission')),'--raw',str(X/'raw'/variant),'--cases',str(X/'cases'/variant),'--out',str(root)]
 start=datetime.now(timezone.utc).isoformat();t=time.monotonic()
 with (X/(method+'-'+variant+'.stdout.txt')).open('w',encoding='utf-8') as o,(X/(method+'-'+variant+'.stderr.txt')).open('w',encoding='utf-8') as e:p=subprocess.run(cmd,stdout=o,stderr=e)
 r={'method':method,'variant':variant,'argv':cmd,'started_at':start,'finished_at':datetime.now(timezone.utc).isoformat(),'exit_code':p.returncode,'seconds':time.monotonic()-t};records.append(r);(X/'batch-progress.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')
 if method in ['final','idle','weak'] and p.returncode!=0:raise SystemExit('unexpected incomplete '+method+' '+variant)
(X/'batch-terminal.json').write_text(json.dumps({'finished_at':datetime.now(timezone.utc).isoformat(),'jobs':records},indent=2)+'\n',encoding='utf-8')
