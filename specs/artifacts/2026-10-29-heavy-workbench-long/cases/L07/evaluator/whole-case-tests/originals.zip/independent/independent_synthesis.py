"""Independent extraction and exact synthesis from the supplied original HTML.
No author module is imported. Weighted moments are calculated directly.
"""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime
from collections import defaultdict
import json,csv,re,html,math

R=Path(__file__).resolve().parent
raw=R/'case-initial/public'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def csvrows(p):
    with p.open(encoding='utf-8',newline='')as f:return list(csv.DictReader(f))
def text(s):return html.unescape(re.sub('<[^>]*>','',s)).strip()
def parse_source(p):
    body=p.read_text(encoding='utf-8')
    meta={text(k):text(v)for k,v in re.findall(r'<dt>(.*?)</dt>\s*<dd>(.*?)</dd>',body,re.S)}
    table=re.search(r'<table\b[^>]*\bid="outcomes"[^>]*>(.*?)</table>',body,re.S)
    rows=[]
    if table:
        heads=[text(x)for x in re.findall(r'<th\b[^>]*>(.*?)</th>',table.group(1),re.S)]
        for tr in re.findall(r'<tr\b[^>]*>(.*?)</tr>',table.group(1),re.S):
            values=[text(x)for x in re.findall(r'<td\b[^>]*>(.*?)</td>',tr,re.S)]
            if values:assert len(values)==len(heads);rows.append(dict(zip(heads,values)))
    return meta,rows
def timestamp(s):return datetime.strptime(s,'%Y-%m-%dT%H:%M:%SZ')
policy=read(raw/'protocol.json');index=csvrows(raw/'archive/index.csv');original={x['report_id']:parse_source(raw/'archive'/x['file'])for x in index}
relations=csvrows(raw/'correspondence.csv')

def calc_pool(effects,random=False):
    names=sorted(effects)
    if not names:return {'status':'not_estimable','k':0}
    d=[effects[n]['md']for n in names];v=[effects[n]['v']for n in names];w=[1/x for x in v]
    W=sum(w);first=sum(a*b for a,b in zip(w,d));q=sum(a*b*b for a,b in zip(w,d))-first*first/W
    df=len(names)-1;I=F(0)if q==0 else max(F(0),1-F(df)/q)
    denominator=W-sum(x*x for x in w)/W
    tau=max(F(0),F(q-df)/denominator)if random and denominator else F(0)
    weights={n:1/(effects[n]['v']+tau)for n in names};total=sum(weights.values())
    mean=sum(weights[n]*effects[n]['md']for n in names)/total;var=1/total
    radius=float(F(policy['normal_critical']))*math.sqrt(float(var))
    return {'status':'estimated','studies':names,'k':len(names),'mean_exact':str(mean),'variance_exact':str(var),'q_exact':str(q),'i2_exact':str(I),'tau2_exact':str(tau),
        'lo':float(mean)-radius,'hi':float(mean)+radius,'weights':[{'registry':n,'weight_exact':str(weights[n]),'normalized_exact':str(weights[n]/total)}for n in names]}

def representatives(studies,possible,cutoff):
    valid={n for n,x in studies.items()if x['estimable']};edges=[]
    for a in valid:
        for b in valid:
            if studies[a]['meta']['Cohort code']==studies[b]['meta']['Cohort code']:edges.append((a,b))
    for row in relations:
        if timestamp(row['released_at'])<=timestamp(cutoff)and(row['relation']=='certain_same'or possible):edges.append((row['registry_a'],row['registry_b']))
    components=[{n}for n in valid]
    for a,b in edges:
        if a not in valid or b not in valid:continue
        connected=[c for c in components if a in c or b in c];merged=set().union(*connected)
        components=[c for c in components if c not in connected]+[merged]
    out={}
    for component in components:
        chosen=min(component,key=lambda n:(studies[n]['meta']['Study role']!='primary',studies[n]['meta']['Registered on'],n))
        out.update({n:chosen for n in component})
    return out

def one_stage(cutoff):
    reports=[x for x in index if timestamp(x['released_at'])<=timestamp(cutoff)]
    families=defaultdict(list)
    for row in reports:families[original[row['report_id']][0]['Registration record']].append(row)
    studies={};effects={}
    for registry,family in families.items():
        reg=next(r for r in family if r['kind']=='registry');meta=original[reg['report_id']][0]
        candidates=defaultdict(list)
        report_rows=[r for r in family if r['kind']!='registry']
        for report in report_rows:
            for row in original[report['report_id']][1]:
                key=(row['endpoint'],int(row['week']),row['arm'])
                rank=(policy['source_priority'][report['kind']],int(report['revision']),timestamp(report['released_at']))
                candidates[key].append((rank,row,report['report_id']))
        selected={}
        for key,items in candidates.items():
            rank=max(x[0]for x in items);top=[x for x in items if x[0]==rank]
            # No max-rank statistical conflict occurs in this assigned corpus.
            selected[key]=top[-1]
        status='included';endpoint=None;week=None;groups=[]
        if meta['Population']!='adult workers':status='excluded_population'
        elif(meta['Experimental condition'],meta['Comparator'])!=('simulator','routine'):status='excluded_comparison'
        elif meta['Assignment mechanism']not in['individual lottery','classroom lottery']:status='excluded_design'
        else:
            endpoint=next((e for e in policy['endpoint_priority']if any(k[0]==e and policy['week_min']<=k[1]<=policy['week_max']for k in selected)),None)
            if endpoint is None:status='no_endpoint'
            else:
                weeks=[k[1]for k in selected if k[0]==endpoint and policy['week_min']<=k[1]<=policy['week_max']]
                week=min(weeks,key=lambda t:(abs(t-policy['week_target']),-t))
                for key,(rank,row,rid)in sorted(selected.items()):
                    if key[:2]!=(endpoint,week):continue
                    n=int(row['n']);factor=F(policy['unit_factor'][row['units']]);mean=F(row['mean'])*factor*policy['endpoint_direction'][endpoint]
                    sd=None if row['spread']=='NR'else(F(row['spread'])*factor)**2*(n if row['spread_kind']=='SE'else 1)
                    groups.append({'arm':row['arm'],'n':n,'mean_points_exact':str(mean),'sd2_points_exact':None if sd is None else str(sd),'source':{'report_id':rid,'table_id':'outcomes','row_id':row['row_id']}})
                if any(x['sd2_points_exact']is None for x in groups):status='not_estimable'
        observed=sum(g['n']for g in groups)if groups else None
        randomized=int(meta['Randomized experimental'])+int(meta['Randomized control'])
        latest_report=max(report_rows,key=lambda r:(policy['source_priority'][r['kind']],int(r['revision']),timestamp(r['released_at'])))
        riskmeta=original[latest_report['report_id']][0]
        risk={'randomized_n':randomized,'observed_n':observed,'attrition_exact':None if observed is None else str(1-F(observed,randomized)),
            'high_attrition':None if observed is None else F(observed,randomized)<F(policy['observed_fraction_high_risk_below']),
            'concealment':riskmeta.get('Allocation concealment','not reported'),'assessor':riskmeta.get('Outcome assessor','not reported')}
        studies[registry]={'meta':meta,'status':status,'estimable':status=='included','groups':groups,'endpoint':endpoint,'week':week,'risk':risk}
        if status=='included':
            def combine(arms):
                N=sum(g['n']for g in arms);mean=sum(g['n']*F(g['mean_points_exact'])for g in arms)/N
                # Expand sums of squares about zero, then subtract N*mean².
                ss=sum((g['n']-1)*F(g['sd2_points_exact'])+g['n']*F(g['mean_points_exact'])**2 for g in arms)-N*mean*mean
                return N,mean,ss/(N-1)
            nt,mt,st=combine([g for g in groups if g['arm'].startswith('T')]);nc,mc,sc=combine([g for g in groups if g['arm']=='C'])
            cluster=meta['Assignment mechanism']=='classroom lottery';imputed=cluster and meta['ICC']=='not reported'
            icc=F(policy['icc_missing_main']if imputed else meta['ICC'])if cluster else None
            de=1+(F(meta['Cluster size'])-1)*icc if cluster else F(1)
            effects[registry]={'md':mt-mc,'v':(st/nt+sc/nc)*de,'de':de,'icc':icc,'icc_status':'imputed'if imputed else'reported'if cluster else'not_applicable','m':F(meta['Cluster size'])if cluster else None}
    reps=representatives(studies,True,cutoff);distinct=representatives(studies,False,cutoff)
    for n,chosen in reps.items():
        if chosen!=n:studies[n]['status']='nonindependent'
    included={n:e for n,e in effects.items()if reps[n]==n}
    def changed_icc(value):return{n:{**e,'v':e['v']/e['de']*(1+(e['m']-1)*F(value))}if e['icc_status']=='imputed'else e for n,e in included.items()}
    analyses={'main_fixed':calc_pool(included),'random_DL':calc_pool(included,True),
        'exclude_high_attrition':calc_pool({n:e for n,e in included.items()if not studies[n]['risk']['high_attrition']}),
        'icc_zero':calc_pool(changed_icc(policy['icc_missing_low'])),'icc_high':calc_pool(changed_icc(policy['icc_missing_high'])),
        'assume_distinct':calc_pool({n:e for n,e in effects.items()if distinct[n]==n})}
    loo={n:calc_pool({k:v for k,v in included.items()if k!=n})for n in included}
    return {'reports':reports,'studies':studies,'effects':effects,'reps':reps,'analyses':analyses,'leave_one_out':loo}

submitted=read(R/'good-output-initial/result.json');result={};problems=[]
def compare_pool(ours,theirs,where):
    for key in ['status','k','mean_exact','variance_exact','q_exact','i2_exact','tau2_exact']:
        if ours[key]!=theirs[key]:problems.append(where+'/'+key)
    if set(ours['studies'])!=set(theirs['studies']):problems.append(where+'/studies')
    for key in ['lo','hi']:
        if not math.isclose(ours[key],theirs[key],abs_tol=1e-12,rel_tol=1e-12):problems.append(where+'/'+key)
    om={x['registry']:(F(x['weight_exact']),F(x['normalized_exact']))for x in ours['weights']};tm={x['registry']:(F(x['weight_exact']),F(x['normalized_exact']))for x in theirs['weights']}
    if om!=tm:problems.append(where+'/weights')
for phase in policy['stages']:
    sid=phase['id'];ours=one_stage(phase['cutoff']);theirs=submitted['stages'][sid]
    ss={s['registry']:s for s in theirs['studies']}
    for n,s in ours['studies'].items():
        t=ss[n]
        if(s['status'],s['endpoint'],s['week'],ours['reps'].get(n))!=(t['status'],t['selected_endpoint'],t['selected_week'],t['main_representative']):problems.append(sid+'/'+n+'/screening')
        if s['risk']!=t['risk_facts']:problems.append(sid+'/'+n+'/risk')
        if s['groups']!=t['groups']:problems.append(sid+'/'+n+'/original_groups_sources')
    ee={e['registry']:e for e in theirs['effects']}
    for n,e in ours['effects'].items():
        if(F(ee[n]['md_exact']),F(ee[n]['variance_exact']),F(ee[n]['design_effect_exact']),None if ee[n]['icc_exact']is None else F(ee[n]['icc_exact']),ee[n]['icc_status'])!=(e['md'],e['v'],e['de'],e['icc'],e['icc_status']):problems.append(sid+'/'+n+'/effect')
    for name,analysis in ours['analyses'].items():compare_pool(analysis,theirs['analyses'][name],sid+'/'+name)
    for n,analysis in ours['leave_one_out'].items():compare_pool(analysis,theirs['leave_one_out'][n],sid+'/leave/'+n)
    result[sid]={'report_count':len(ours['reports']),'registered_count':len(ours['studies']),'analyses':ours['analyses'],'leave_one_out':ours['leave_one_out'],
        'effects':{n:{k:str(v)if isinstance(v,F)else v for k,v in e.items()}for n,e in ours['effects'].items()},'groups':{n:s['groups']for n,s in ours['studies'].items()}}
first,last=policy['stages'][0]['id'],policy['stages'][-1]['id'];delta=F(result[last]['analyses']['main_fixed']['mean_exact'])-F(result[first]['analyses']['main_fixed']['mean_exact'])
if delta!=F(submitted['changes'][0]['delta_main_exact']):problems.append('update_delta')
out={'independent_whole_case_numeric_agrees':not problems,'mismatches':problems,'stages':result,'update_delta':str(delta),'scope':'original HTML/registration/correspondence independently reconstructed; no author rule imports, no numeric programme or reader execution'}
(R/'independent-synthesis.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'whole_case_agrees':not problems,'mismatches':problems,'main_values':{k:float(F(v['analyses']['main_fixed']['mean_exact']))for k,v in result.items()}}))
