from pathlib import Path
import json,subprocess,sys,copy,shutil
R=Path('D:/myhexin-local/opencorvus');L=R/'specs/artifacts/2026-10-29-heavy-workbench-long/cases/L07';O=Path('D:/opencorvus-benchmark-runs/l07-full-case-20261030');P=Path('D:/opencorvus-benchmark-runs/l07-whole-case-independent-review-20261030');out=O/'tolerance-repair';out.mkdir();shutil.copy2(L/'evaluator/check.py',out/'actual-check.py')
probe=json.loads((P/'interval-tolerance-command.json').read_text(encoding='utf-8'));original=Path(probe['argv'][probe['argv'].index('--output')+1]);outside=out/'outside';outside.mkdir();v=json.loads((original/'result.json').read_text(encoding='utf-8'));v['stages']['updated']['analyses']['main_fixed']['hi']=probe['expected_endpoint']+3e-7;(outside/'result.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
records=[]
for name,result,expected in [('original-within-sum',original,[]),('actual-current-reference',O/'consolidated-run/base/output/result',[]),('outside-sum',outside,['M07'])]:
    argv=[sys.executable,'-X','utf8','-B',str(L/'evaluator/check.py'),'--input',str(O/'consolidated-run/base/input'),'--output',str(result),'--assessment',str(out/(name+'.json'))];p=subprocess.run(argv,cwd=R,capture_output=True,text=True,encoding='utf-8');a=json.loads((out/(name+'.json')).read_text(encoding='utf-8'));failed=[r['id'] for r in a['findings'][:10] if r['status']!='pass'];assert p.returncode==4 and failed==expected
    r={'name':name,'argv':argv,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'actual_failed':failed};records.append(r)
(out/'commands.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps([{'name':r['name'],'actual_failed':r['actual_failed']} for r in records]))
