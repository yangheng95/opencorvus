from pathlib import Path
from datetime import datetime,timezone
import json,sys,subprocess,time
R=Path('D:/myhexin-local/opencorvus');L=R/'specs/artifacts/2026-10-29-heavy-workbench-long/cases/L07';O=Path('D:/opencorvus-benchmark-runs/l07-full-case-20261030');P=Path('D:/opencorvus-benchmark-runs/l07-whole-case-independent-review-20261030')
for name,run,review,role in [('reference','consolidated-run','review.json','author_reference_qualification'),('weak-report','consolidated-weak-run','review-weak.json','real_low_quality_control')]:
    root=O/run;argv=[sys.executable,'-X','utf8','-B',str(L/'evaluator/check.py'),'--input',str(root/'base/input'),'--output',str(root/'base/output/result'),'--execution',str(root/'execution.json'),'--review',str(P/review),'--assessment',str(O/(name+'-final-grade.json'))]
    clock=time.monotonic();start=datetime.now(timezone.utc).isoformat();p=subprocess.run(argv,cwd=R,capture_output=True,text=True,encoding='utf-8');(O/(name+'-final-grade.stdout')).write_text(p.stdout,encoding='utf-8');(O/(name+'-final-grade.stderr')).write_text(p.stderr,encoding='utf-8');(O/(name+'-final-grade-command.json')).write_text(json.dumps({'argv':argv,'started_at':start,'finished_at':datetime.now(timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-clock,'exit_code':p.returncode,'subject_role':role},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    if p.returncode not in [0,2]:raise RuntimeError('actual grade incomplete/facility; inspect original '+name)
    a=json.loads((O/(name+'-final-grade.json')).read_text(encoding='utf-8'));print(json.dumps({'subject':role,'total':a['total'],'good':a['good'],'critical_failures':a['critical_failures'],'actual_exit':p.returncode}))
