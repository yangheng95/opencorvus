from pathlib import Path
from reference import deliver
deliver(Path('/input'),Path('/output/result'))
p=Path('/output/result/REVIEW.md')
p.write_text(p.read_text(encoding='utf-8')+'\n本次合成已经证明现实每位成人都会获益，个体获益概率为100%；随机效应已经消除了失访和队列重叠的全部偏倚。\n',encoding='utf-8')
