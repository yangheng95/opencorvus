from pathlib import Path
import json,sys,shutil
R=Path('D:/myhexin-local/opencorvus');L=R/'specs/artifacts/2026-10-29-heavy-workbench-long/cases/L07';O=Path('D:/opencorvus-benchmark-runs/l07-full-case-20261030')
sys.path.insert(0,str(L/'evaluator'));from run_case import inputs,seal,run_once,save
P=O/'material-repair';P.mkdir();shutil.copytree(L/'evaluator',P/'evaluator-source')
prepared=inputs(L/'public',P/'prepared-controls');raw=dict(prepared)['new-report']
assert '<dd>N</dd>' in (raw/'archive/R14-REG.html').read_text(encoding='utf-8') and '新独立N队列' in (raw/'archive/R14-REG.html').read_text(encoding='utf-8')
records=[]
for name,submission,old in [('reference',O/'final-submission',O/'final-run'),('weak-report',O/'weak-report-submission',O/'weak-report-run'),('stale',O/'stale-submission',O/'stale-run')]:
    run=P/name;run.mkdir();source,manifest=seal(submission,run);cell=run/'new-report';cell.mkdir();shutil.copytree(raw,cell/'input')
    receipt=run_once(source,manifest,cell/'input',cell,'sha256:23ff8bfbf8055caa0b9fa5745ddb27cceea2f31d7d15b7a900c81112cdfe8ddf','new-report')
    original=json.loads((old/'execution.json').read_text(encoding='utf-8'));execution={'format':'l07-case-execution/1','runs':[r for r in original['runs'] if r['variant']!='new-report']+[receipt]};save(P/(name+'-execution.json'),execution)
    a=json.loads((cell/'numeric-assessment.json').read_text(encoding='utf-8'));expected=name!='stale';assert receipt['native_exit']==0 and receipt['verified']==expected
    before=json.loads((old/'new-report/output/result/result.json').read_text(encoding='utf-8'));after=json.loads((cell/'output/result/result.json').read_text(encoding='utf-8'));assert before==after
    records.append({'programme':name,'native_exit':0,'verified':receipt['verified'],'actual_new_body':'cohort N consistent with metadata','numeric_object_unchanged':True,'original_base_unchanged':True,'execution':str(P/(name+'-execution.json'))})
save(P/'receipt.json',{'reason':'new-report fixture header/body cohort contradiction repaired without altering any programme or numeric result','records':records,'old_inputs_outputs_retained':True})
print(json.dumps(records))
