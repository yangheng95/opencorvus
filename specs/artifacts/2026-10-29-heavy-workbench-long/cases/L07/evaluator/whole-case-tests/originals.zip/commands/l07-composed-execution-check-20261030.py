from pathlib import Path
import json,subprocess,sys
R=Path('D:/myhexin-local/opencorvus');L=R/'specs/artifacts/2026-10-29-heavy-workbench-long/cases/L07';O=Path('D:/opencorvus-benchmark-runs/l07-full-case-20261030');out=O/'composed-execution-check';out.mkdir()
for name,root,expected in [('reference',O/'final-run','pass'),('weak-report',O/'weak-report-run','pass'),('stale',O/'stale-run','fail')]:
    argv=[sys.executable,'-X','utf8','-B',str(L/'evaluator/check.py'),'--input',str(root/'base/input'),'--output',str(root/'base/output/result'),'--execution',str(O/'material-repair'/(name+'-execution.json')),'--assessment',str(out/(name+'.json'))]
    p=subprocess.run(argv,cwd=R,capture_output=True,text=True,encoding='utf-8');(out/(name+'.stdout')).write_text(p.stdout,encoding='utf-8');(out/(name+'.stderr')).write_text(p.stderr,encoding='utf-8')
    a=json.loads((out/(name+'.json')).read_text(encoding='utf-8'));m=next(r for r in a['findings'] if r['id']=='M11');assert p.returncode==4 and m['status']==expected and all(r['status']=='pass' for r in a['findings'][:10])
    (out/(name+'-command.json')).write_text(json.dumps({'argv':argv,'exit':p.returncode,'M11':m['status'],'total':a['total']},indent=2)+'\n',encoding='utf-8');print(json.dumps({'programme':name,'M11':m['status'],'actual_exit':p.returncode,'total':a['total']}))
