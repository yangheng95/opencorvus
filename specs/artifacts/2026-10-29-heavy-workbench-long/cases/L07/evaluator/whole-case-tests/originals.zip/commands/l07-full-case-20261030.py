from pathlib import Path
from datetime import datetime,timezone
import json,subprocess,sys,shutil,time
R=Path('D:/myhexin-local/opencorvus');L=R/'specs/artifacts/2026-10-29-heavy-workbench-long/cases/L07';O=Path('D:/opencorvus-benchmark-runs/l07-full-case-20261030');O.mkdir(exist_ok=False)
sys.path.insert(0,str(L/'evaluator'));from run_case import seal,run_once,save
IMAGE='sha256:23ff8bfbf8055caa0b9fa5745ddb27cceea2f31d7d15b7a900c81112cdfe8ddf'
def programme(name,core=None,wrapper=None,assets=None):
    dest=O/name;dest.mkdir()
    for n in ['reference.py','review_rules.py']:shutil.copy2(L/'evaluator'/n,dest/n)
    if core is not None:(dest/'review_rules.py').write_text(core,encoding='utf-8')
    files=['reference.py','review_rules.py'];entry='reference.py'
    if wrapper:
        (dest/'wrapper.py').write_text(wrapper,encoding='utf-8');files+=['wrapper.py'];entry='wrapper.py'
    if assets:
        shutil.copytree(assets,dest/'frozen');files +=['frozen/'+p.relative_to(assets).as_posix() for p in assets.rglob('*') if p.is_file()]
    save(dest/'submission.json',{'format':'l07-submission/1','files':files,'argv':['/opt/cpsat/bin/python','-B',entry,'--input','/input','--output','/output/result']});return dest
def complete(name,submission):
    argv=[sys.executable,'-X','utf8','-B',str(L/'evaluator/run_case.py'),'--submission',str(submission),'--input',str(L/'public'),'--run',str(O/name),'--image',IMAGE]
    start=datetime.now(timezone.utc).isoformat();clock=time.monotonic();p=subprocess.run(argv,cwd=R,capture_output=True,text=True,encoding='utf-8');(O/(name+'.stdout')).write_text(p.stdout,encoding='utf-8');(O/(name+'.stderr')).write_text(p.stderr,encoding='utf-8');save(O/(name+'-command.json'),{'argv':argv,'started_at':start,'finished_at':datetime.now(timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-clock,'exit_code':p.returncode})
    if p.returncode!=4:raise RuntimeError(name+' actual error; inspect original receipt')
    a=json.loads((O/name/'assessment.json').read_text(encoding='utf-8'));print(json.dumps({'run':name,'machine':[(r['id'],r['status']) for r in a['findings'][:11]],'whole_score':a['total']}),flush=True);return a
reference=programme('reference-submission');shutil.copytree(L/'evaluator',O/'evaluator-original');shutil.copy2(L/'rubric.json',O/'rubric-original.json')
a=complete('reference-run',reference);assert all(r['status']=='pass' for r in a['findings'][:11])
source=(L/'evaluator/review_rules.py').read_text(encoding='utf-8')
faults=[
 ('duplicate-persons',"include=[internals[s['registry']] for s in studies if s['status']=='included']","include=list(internals.values())",['M07']),
 ('se-as-sd',"*(n if row['spread_kind']=='SE' else 1)","*1",['M03','M05']),
 ('select-eight-week','week=min(weeks,key=lambda w:(abs(w-policy[\'week_target\']),-w))','week=min(weeks)',['M02','M05']),
 ('ignore-cluster',"de=1+(F(meta['Cluster size'])-1)*icc","de=F(1)",['M05','M06']),
 ('reverse-errors-direction',"*policy['endpoint_direction'][endpoint]","*1",['M03','M05']),
 ('future-correction',"if r['released_at']>cutoff:continue","if False:continue",['M01','M05'])]
records=[]
for name,old,new,want in faults:
    assert source.count(old)==1,(name,'declared actual fault site')
    submitted=programme('wrong-'+name,core=source.replace(old,new));run=O/('wrong-run-'+name);run.mkdir();sealed,m=seal(submitted,run);raw=run/'input';shutil.copytree(L/'public',raw)
    rec=run_once(sealed,m,raw,run,IMAGE,'base');a=json.loads((run/'numeric-assessment.json').read_text(encoding='utf-8'));failed=[r['id'] for r in a['findings'][:10] if r['status']!='pass'];assert rec['native_exit']==0 and set(want)<=set(failed),(name,rec,failed)
    records.append({'name':name,'native_exit':0,'actual_failed':failed,'expected':want});print(json.dumps(records[-1]),flush=True)
stale=programme('stale-submission',wrapper="from pathlib import Path\nimport shutil\nshutil.copytree(Path('frozen'),Path('/output/result'))\n",assets=O/'reference-run/base/output/result')
a=complete('stale-run',stale);assert all(r['status']=='pass' for r in a['findings'][:10]) and a['findings'][10]['status']=='fail'
weak=programme('weak-report-submission',wrapper="from pathlib import Path\nfrom reference import deliver\ndeliver(Path('/input'),Path('/output/result'))\np=Path('/output/result/REVIEW.md')\np.write_text(p.read_text(encoding='utf-8')+'\\n本次合成已经证明现实每位成人都会获益，个体获益概率为100%；随机效应已经消除了失访和队列重叠的全部偏倚。\\n',encoding='utf-8')\n")
a=complete('weak-report-run',weak);assert all(r['status']=='pass' for r in a['findings'][:11])
save(O/'actual-error-programs.json',{'faults':records,'stale_actual_M11':'fail','weak_report_numeric_native':'11pass; independent content rating pending','candidate_score':None})
