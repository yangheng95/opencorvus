from pathlib import Path
import sys,json
sys.path.insert(0,'D:\\opencorvus-benchmark-runs\\l07-whole-case-independent-review-20261030\\case-initial\\evaluator')
from review_rules import review
try:
 value=review(Path('D:\\opencorvus-benchmark-runs\\l07-whole-case-independent-review-20261030\\lower-rank-conflict-input'))
 print(json.dumps({'status':'review_completed'}))
except Exception as e:
 print(json.dumps({'status':'error','type':type(e).__name__,'error':str(e)}))
