from pathlib import Path
from datetime import datetime,timezone
import json,sys,shutil,subprocess,time
R=Path('D:/myhexin-local/opencorvus');L=R/'specs/artifacts/2026-10-29-heavy-workbench-long/cases/L07';O=Path('D:/opencorvus-benchmark-runs/l07-full-case-20261030');P=Path('D:/opencorvus-benchmark-runs/l07-whole-case-independent-review-20261030')
sys.path.insert(0,str(L/'evaluator'));from run_case import seal,run_once,save
image='sha256:23ff8bfbf8055caa0b9fa5745ddb27cceea2f31d7d15b7a900c81112cdfe8ddf';shutil.copytree(L/'evaluator',O/'consolidated-evaluator-source')
for name,weak in [('consolidated',False),('consolidated-weak',True)]:
    submission=O/(name+'-submission');submission.mkdir()
    for n in ['reference.py','review_rules.py']:shutil.copy2(L/'evaluator'/n,submission/n)
    m=json.loads((O/'final-submission/submission.json').read_text())
    if weak:shutil.copy2(O/'weak-report-submission/wrapper.py',submission/'wrapper.py');m['files'].append('wrapper.py');m['argv'][2]='wrapper.py'
    save(submission/'submission.json',m)
    argv=[sys.executable,'-X','utf8','-B',str(L/'evaluator/run_case.py'),'--submission',str(submission),'--input',str(L/'public'),'--run',str(O/(name+'-run')),'--image',image]
    start=datetime.now(timezone.utc).isoformat();clock=time.monotonic();p=subprocess.run(argv,cwd=R,capture_output=True,text=True,encoding='utf-8');(O/(name+'.stdout')).write_text(p.stdout,encoding='utf-8');(O/(name+'.stderr')).write_text(p.stderr,encoding='utf-8');save(O/(name+'-command.json'),{'argv':argv,'started_at':start,'finished_at':datetime.now(timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-clock,'exit_code':p.returncode})
    if p.returncode!=4:raise RuntimeError('inspect original '+name+' error')
    a=json.loads((O/(name+'-run/assessment.json')).read_text());assert all(r['status']=='pass' for r in a['findings'][:11])
    print(json.dumps({'run':name,'native_runs':3,'machine':'11pass','content_pending':True}),flush=True)
same={n:json.loads((O/'consolidated-run'/n/'output/result/result.json').read_text(encoding='utf-8'))==json.loads((O/'final-run'/n/'output/result/result.json').read_text(encoding='utf-8')) for n in ['base','mean-change','new-report']};save(O/'consolidated-numeric-equivalence.json',same);assert all(same.values())
run=O/'lower-rank-resolved-native';run.mkdir();source,m=seal(O/'consolidated-submission',run);raw=run/'input';shutil.copytree(P/'lower-rank-conflict-input',raw)
r=run_once(source,m,raw,run,image,'lower-rank-resolved');assert r['native_exit']==0 and r['verified']
badraw=O/'final-checker-controls/conflict-input';target=O/'highest-conflict-final.json';argv=[sys.executable,'-X','utf8','-B',str(L/'evaluator/check.py'),'--input',str(badraw),'--output',str(O/'consolidated-run/base/output/result'),'--assessment',str(target)]
p=subprocess.run(argv,cwd=R,capture_output=True,text=True,encoding='utf-8');save(O/'highest-conflict-final-command.json',{'argv':argv,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr});v=json.loads(p.stdout);assert p.returncode==3 and v['status']=='facility_error' and v['error'].startswith('facility_corpus_conflict:')
save(O/'concentrated-repairs.json',{'single_current_core':'review_rules.py','lowest_conflict_resolved_by_unique_highest':'actual native0/10numeric pass','highest_unresolved_conflict':'actual facility_error/exit3','three_complete_numeric_objects_same':same,'candidate_score':None})
