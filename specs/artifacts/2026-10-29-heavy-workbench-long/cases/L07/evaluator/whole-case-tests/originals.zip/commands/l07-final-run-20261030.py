from pathlib import Path
from datetime import datetime,timezone
import sys,json,shutil,subprocess,time,copy
R=Path('D:/myhexin-local/opencorvus');L=R/'specs/artifacts/2026-10-29-heavy-workbench-long/cases/L07';O=Path('D:/opencorvus-benchmark-runs/l07-full-case-20261030')
dest=O/'final-submission';dest.mkdir();shutil.copytree(L/'evaluator',O/'evaluator-final')
for n in ['reference.py','review_rules.py']:shutil.copy2(L/'evaluator'/n,dest/n)
shutil.copy2(O/'reference-submission/submission.json',dest/'submission.json');shutil.copy2(L/'rubric.json',O/'rubric-final.json')
argv=[sys.executable,'-X','utf8','-B',str(L/'evaluator/run_case.py'),'--submission',str(dest),'--input',str(L/'public'),'--run',str(O/'final-run'),'--image','sha256:23ff8bfbf8055caa0b9fa5745ddb27cceea2f31d7d15b7a900c81112cdfe8ddf']
start=datetime.now(timezone.utc).isoformat();clock=time.monotonic();p=subprocess.run(argv,cwd=R,capture_output=True,text=True,encoding='utf-8');save=lambda path,v:Path(path).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(O/'final-run.stdout').write_text(p.stdout,encoding='utf-8');(O/'final-run.stderr').write_text(p.stderr,encoding='utf-8');save(O/'final-run-command.json',{'argv':argv,'started_at':start,'finished_at':datetime.now(timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-clock,'exit_code':p.returncode})
if p.returncode!=4:raise RuntimeError('read actual final-run stdout/stderr')
a=json.loads((O/'final-run/assessment.json').read_text(encoding='utf-8'));assert all(r['status']=='pass' for r in a['findings'][:11])
same={v:json.loads((O/'reference-run'/v/'output/result/result.json').read_text(encoding='utf-8'))==json.loads((O/'final-run'/v/'output/result/result.json').read_text(encoding='utf-8')) for v in ['base','mean-change','new-report']};save(O/'complete-business-equivalence.json',same);assert all(same.values())
out=O/'final-checker-controls';out.mkdir();records=[]
def check(name,raw,result,fail=(),exit_code=4):
    target=out/name;target.mkdir();argv=[sys.executable,'-X','utf8','-B',str(L/'evaluator/check.py'),'--input',str(raw),'--output',str(result),'--assessment',str(target/'assessment.json')];p=subprocess.run(argv,cwd=R,capture_output=True,text=True,encoding='utf-8');(target/'stdout.txt').write_text(p.stdout,encoding='utf-8');(target/'stderr.txt').write_text(p.stderr,encoding='utf-8');r={'argv':argv,'exit':p.returncode}
    if (target/'assessment.json').exists():
        a=json.loads((target/'assessment.json').read_text(encoding='utf-8'));r['failed']=[x['id'] for x in a['findings'][:10] if x['status']!='pass'];assert set(fail)<=set(r['failed']);assert bool(fail) or not r['failed']
    assert p.returncode==exit_code,(name,p.stdout,p.stderr);save(target/'command.json',r);records.append({'name':name,**r})
for folder in O.glob('wrong-run-*'):
    old=json.loads((folder/'numeric-assessment.json').read_text(encoding='utf-8'));expected=[r['id'] for r in old['findings'][:10] if r['status']=='fail'];check(folder.name,folder/'input',folder/'output/result',expected)
base=O/'final-run/base/output/result';raw=O/'final-run/base/input';original=json.loads((base/'result.json').read_text(encoding='utf-8'))
equivalent=copy.deepcopy(original)
def reformat(v):
    if type(v) is dict:
        for k,x in list(v.items()):
            if k.endswith('_exact') and x is not None:
                from fractions import Fraction
                q=Fraction(x);v[k]=str(q.numerator*2)+'/'+str(q.denominator*2)
            else:reformat(x)
    if type(v) is list:
        v.reverse()
        for x in v:reformat(x)
reformat(equivalent)
for s in equivalent['stages']['initial']['studies']:
    if s['registry']=='R02':
        for g in s['groups']:g['source']={'report_id':'R02-MAIN','table_id':'outcomes','row_id':'R02-12-'+g['arm'],'note':'another actual original supporting same current group'}
for r in equivalent['changes'][0]['studies']:
    if r['registry']=='R02':r['before_sources']=[{'report_id':'R02-MAIN','table_id':'outcomes','row_id':'R02-12-'+arm} for arm in ['T','C']]
eq=out/'equivalent-output';eq.mkdir();save(eq/'result.json',equivalent);check('equivalent-rows-rationals-real-citation',raw,eq)
bad=copy.deepcopy(original);bad['stages']['initial']['studies'][0]['groups'][0]['source']['row_id']='invented-row';bp=out/'invented-source-output';bp.mkdir();save(bp/'result.json',bad);check('unsupported-source',raw,bp,['M03'])
bad=copy.deepcopy(original);bad['stages']['initial']['studies'][0]['groups'][0]['n']=True;bp=out/'boolean-n-output';bp.mkdir();save(bp/'result.json',bad);check('boolean-n',raw,bp,['M03'])
conflict=out/'conflict-input';shutil.copytree(raw,conflict);text=(conflict/'archive/R01-MAIN.html').read_text(encoding='utf-8');text=text.replace('<td>68</td>','<td>69</td>');(conflict/'archive/R01-TIE.html').write_text(text,encoding='utf-8')
import csv
index_path=conflict/'archive/index.csv'
with index_path.open(encoding='utf-8',newline='') as f:index=list(csv.DictReader(f))
row=copy.deepcopy(next(r for r in index if r['report_id']=='R01-MAIN'));row.update(report_id='R01-TIE',file='R01-TIE.html');index.append(row)
with index_path.open('w',encoding='utf-8',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(row));w.writeheader();w.writerows(index)
check('actual-highest-source-conflict',conflict,base,exit_code=3)
save(out/'summary.json',{'actual_commands':records,'new_native':'only final correct three inputs; original six error native not repeated','reference_whole_score':None})
print(json.dumps({'final_correct_native':3,'machine':'11pass','same_complete_numerical_objects':same,'final_checker_commands':len(records),'content_review_pending':True}))
