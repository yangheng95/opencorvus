from pathlib import Path
import shutil
shutil.copytree(Path('frozen'),Path('/output/result'))
