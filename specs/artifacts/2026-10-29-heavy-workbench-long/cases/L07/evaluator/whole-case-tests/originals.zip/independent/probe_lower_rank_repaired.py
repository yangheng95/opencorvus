from pathlib import Path
import sys,json
sys.path.insert(0,'D:\\opencorvus-benchmark-runs\\l07-whole-case-independent-review-20261030\\case-reviewed\\evaluator')
from review_rules import review
a=review(Path('D:\\opencorvus-benchmark-runs\\l07-whole-case-independent-review-20261030\\input-reviewed'));b=review(Path('D:\\opencorvus-benchmark-runs\\l07-whole-case-independent-review-20261030\\lower-rank-conflict-input'))
print(json.dumps({'lower_rank_resolved':all(a['stages'][s]['analyses']==b['stages'][s]['analyses'] and a['stages'][s]['effects']==b['stages'][s]['effects'] for s in a['stages'])}))
