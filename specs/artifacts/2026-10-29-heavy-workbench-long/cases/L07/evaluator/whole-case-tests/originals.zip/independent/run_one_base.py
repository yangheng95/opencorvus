"""One authorised independent base rebuild. Does not run the four-cell driver."""
from pathlib import Path
import json,shutil,subprocess,uuid,zipfile,time
R=Path(__file__).resolve().parent
run=R/'cold-base';run.mkdir();project=run/'project';project.mkdir()
submission=R/'submission-reviewed';manifest=json.loads((submission/'submission.json').read_text(encoding='utf-8'))
for name in manifest['files']:
    p=submission/name
    assert p.resolve().is_relative_to(submission.resolve())and p.is_file()
    target=project/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
raw=run/'input';shutil.copytree(R/'input-reviewed',raw);output=run/'output';output.mkdir()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
image='sha256:23ff8bfbf8055caa0b9fa5745ddb27cceea2f31d7d15b7a900c81112cdfe8ddf'
name='oc-l07-independent-base-'+uuid.uuid4().hex[:12]
argv=['docker','create','--name',name,'--cpus','1','--network','none','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges',
    '--mount','type=bind,src='+str(project.resolve())+',dst=/project,readonly','--mount','type=bind,src='+str(raw.resolve())+',dst=/input,readonly',
    '--mount','type=bind,src='+str(output.resolve())+',dst=/output','--tmpfs','/tmp:rw,nosuid,size=256m','--env','MPLCONFIGDIR=/tmp/mpl','--env','XDG_CACHE_HOME=/tmp/cache',
    '--workdir','/project','--entrypoint',manifest['argv'][0],image,*manifest['argv'][1:]]
before=time.perf_counter();p=subprocess.run(argv,capture_output=True)
save(run/'create.json',{'argv':argv,'exit':p.returncode,'stdout':p.stdout.decode(),'stderr':p.stderr.decode()});assert p.returncode==0
cid=p.stdout.decode().strip();assert len(cid)==64 and all(x in'0123456789abcdef'for x in cid)
with(run/'stdout.txt').open('wb')as stdout,(run/'stderr.txt').open('wb')as stderr:
    started=subprocess.run(['docker','start','-a',cid],stdout=stdout,stderr=stderr)
p=subprocess.run(['docker','inspect',cid],capture_output=True);(run/'terminal-inspect.json').write_bytes(p.stdout);assert p.returncode==0
native=json.loads(p.stdout)[0];state=native['State'];assert state['Status']=='exited'
save(run/'run-receipt.json',{'container_id':cid,'name':name,'start_argv':['docker','start','-a',cid],'start_exit':started.returncode,'native_exit':state['ExitCode'],
    'native_started_at':state['StartedAt'],'native_finished_at':state['FinishedAt'],'elapsed_seconds_before_archive':time.perf_counter()-before,'source_files':manifest['files'],
    'input_files':[p.name for p in raw.iterdir()],'scope':'single independent base source-only run; no variant loop, solver, model or Provider'})
# Seal all actual objects before removing only the exact owned terminal CID.
with zipfile.ZipFile(run/'originals.zip','x',zipfile.ZIP_DEFLATED)as z:
    for path in run.rglob('*'):
        if path.is_file()and path.name!='originals.zip':z.write(path,path.relative_to(run).as_posix())
removed=subprocess.run(['docker','rm',cid],capture_output=True)
save(run/'cleanup.json',{'argv':['docker','rm',cid],'exit':removed.returncode,'stdout':removed.stdout.decode(),'stderr':removed.stderr.decode(),'sealed_before_cleanup':True})
assert removed.returncode==0 and state['ExitCode']==0
print(json.dumps({'native_exit':state['ExitCode'],'container_id':cid,'owned_terminal_sealed_then_cleaned':True,'elapsed_seconds':time.perf_counter()-before}))
