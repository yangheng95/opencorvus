from pathlib import Path
from fractions import Fraction
import json,subprocess,sys,copy,shutil
R=Path('D:/myhexin-local/opencorvus');L=R/'specs/artifacts/2026-10-29-heavy-workbench-long/cases/L07';O=Path('D:/opencorvus-benchmark-runs/l07-full-case-20261030');out=O/'standard-numeric-check';out.mkdir();shutil.copy2(L/'evaluator/check.py',out/'actual-check.py');shutil.copy2(L/'public/PROTOCOL.md',out/'actual-PROTOCOL.md')
v=json.loads((O/'consolidated-run/base/output/result/result.json').read_text(encoding='utf-8'))
def convert(x):
    if type(x) is dict:
        for k,v in list(x.items()):
            if k.endswith('_exact') and v is not None:x[k]=float(Fraction(v))
            else:convert(v)
    if type(x) is list:
        x.reverse()
        for v in x:convert(v)
convert(v);positive=out/'float-output';positive.mkdir();(positive/'result.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
bad=copy.deepcopy(v);next(e for e in bad['stages']['initial']['effects'] if e['registry']=='R01')['design_effect_exact']=True;bp=out/'boolean-quantity';bp.mkdir();(bp/'result.json').write_text(json.dumps(bad,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
records=[]
def check(name,raw,result,fail):
    path=out/(name+'.json');argv=[sys.executable,'-X','utf8','-B',str(L/'evaluator/check.py'),'--input',str(raw),'--output',str(result),'--assessment',str(path)];p=subprocess.run(argv,cwd=R,capture_output=True,text=True,encoding='utf-8');a=json.loads(path.read_text(encoding='utf-8'));failed=[r['id'] for r in a['findings'][:10] if r['status']!='pass'];assert p.returncode==4 and set(fail)==set(failed),(name,p.stdout,p.stderr,failed);records.append({'name':name,'argv':argv,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'actual_failed':failed})
check('standard-float-row-order',O/'consolidated-run/base/input',positive,[]);check('typed-boolean-is-not-one',O/'consolidated-run/base/input',bp,['M06'])
for folder in O.glob('wrong-run-*'):
    old=json.loads((folder/'numeric-assessment.json').read_text(encoding='utf-8'));failed=[r['id'] for r in old['findings'][:10] if r['status']!='pass'];check(folder.name,folder/'input',folder/'output/result',failed)
(out/'commands.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps({'finite_floating_output':'10pass','boolean_quantity':'M06fail','old_real_wrong_programme_outputs_regraded':6,'new_native_runs':0}))
