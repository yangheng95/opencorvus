import argparse
from pathlib import Path
from l09_protocol import collect,evaluate
from l09_lab import save
MODE='all_full'
p=argparse.ArgumentParser();p.add_argument('--student',type=Path,required=True);p.add_argument('--data',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();a.out.mkdir()
collect(a.student,a.data,a.out/'actual-work');g=evaluate(a.data,a.out/'actual-work')
if MODE=='all_full':
 for x in g['items'].values():x['points']=1
if MODE=='style_penalty' and 'dense_rank' in (a.out/'actual-work/lab2/queries.sql').read_text(encoding='utf-8').lower():
 for k,x in g['items'].items():
  if k.startswith('S'):x['points']=0
g['domains']={d:sum(x['points'] for k,x in g['items'].items() if k.startswith(d)) for d in ('D','S','R','A')};g['total']=sum(g['domains'].values());save(a.out/'grade.json',g)
