import argparse,shutil,os,json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--data',type=Path,required=True);p.add_argument('--state',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--route');p.add_argument('--restore');p.add_argument('--crash-after-commit',action='store_true');a=p.parse_args();n=json.loads((a.data/'packet.json').read_text())['lab'];name='lab3-commit-exit' if a.crash_after_commit else ('restored-lab4' if a.restore else 'lab'+str(n));shutil.copytree(Path('cached')/name,a.out);a.state.mkdir(parents=True,exist_ok=True);shutil.copy2(a.out/'checkpoint.json',a.state/'stale-checkpoint.json')
if a.crash_after_commit:os._exit(73)
