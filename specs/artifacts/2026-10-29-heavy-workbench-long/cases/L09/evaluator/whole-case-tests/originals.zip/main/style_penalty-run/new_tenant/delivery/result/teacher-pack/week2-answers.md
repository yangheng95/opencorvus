# Week2: Relational current state

Objective: Execute a joint-key MAX/join or DENSE_RANK SQL query; prove latest-state rather than latest-valid reasoning.

Input: original authorized packet2/packet.json and its optional events.csv, plus the real previous state. UTC and cents are explicit. W1 starts empty; later labs retain state. 0.5h retrieval/diagnostic;0.75h worked example;1.5h guided lab;1h transfer challenge;0.5h feedback/retrieval;0.75h reflection and handover =5h.

Retrieval: State what happens when revision2 is missing or cancelled and revision1 was active.

Guided route: Run the supplied join in fragments, inspect each relation and trace O3 to its selected sources.

Challenge route: Implement the equivalent window formulation; compare complete states/lineage, not SQL spelling. Both reach the same fixed business/functional contract. Support is based on an observed response, not an invented diagnosis of the person.

Run the declared lab entry with --data <packet2> --state <same-state> --out <new-out> --route guided|challenge. Inspect lab.json and checkpoint.json; queries.sql documents the actually executed SQL for the current-state lab. Expected actual result for this supplied input: journal_count 25, tenant cents {'East': 171800, 'North': 11800, 'South': 91800, 'West': 3125}, replayed False. On changed data recompute; these are answer observations, not hardcoded targets.

Failure interpretation: typed rejection preserves raw evidence; missing/conflict is unknown held value, cancelled is known zero. Exit73 is expected only for the deliberate W3 committed-write rehearsal, not a successful normal lab. Keep the exact state path and request, inspect the committed checkpoint and retry; never erase original journal to quiet an error. Unexpected native/schema failure is a stop-and-diagnose event, not evidence of conceptual incompetence.

Evidence task: point to original row IDs and the transaction/SQL/policy that explains the result. Change a legitimate value or tenant and predict which output must change and which invariant remains. Give another valid formulation. Feedback must distinguish an execution error from a wrong explanation. Exit0 alone is not a business answer.

Accessibility/support: all steps are keyboard CLI commands; use the plain text field glossary and CSV/table companions instead of color. Allow glossary-supported verbal or written explanation with the same evidence standard. No claim of independently certified accessibility is made.

## Actual answer evidence
Normal process exit 0; 1.1278s is script runtime, not lesson/agent work. Complete state and source lineage are evidence/guided/lab2/lab.json and checkpoint; query alternatives are compared by behavior.

## Debrief and partial evidence
Full explanation identifies the governing key/state/transaction or principal condition and applies it to the observed counterexample. Partial explanation gets the right result but lacks the mechanism or one required boundary. An explanation that resurrects old valid data, deletes committed history or trusts a claimed tenant is wrong even if one sample total happens to match.
