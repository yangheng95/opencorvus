select payload from observations where revision=(select max(b.revision) from observations b where b.order_id=observations.order_id);
