"""Fixed learning-task behavior contract and programme-driven work collection."""
from pathlib import Path
import csv,json,subprocess,time,shutil
from l09_lab import load,save,decode,current,access,canonical

def equal(a,b):
 def norm(x):
  if isinstance(x,dict):return {k:norm(v) for k,v in sorted(x.items())}
  if isinstance(x,tuple):return [norm(v) for v in x]
  if isinstance(x,list):return sorted((norm(v) for v in x),key=canonical)
  return x
 return canonical(norm(a))==canonical(norm(b))
def packet(source,lab,out):
 c=load(source/'course-contract.json');out.mkdir(parents=True)
 save(out/'packet.json',{'lab':lab,'request_id':'W'+str(lab),'as_of':c['as_of'][str(lab)],'principals':c['principals'],'queries':c['queries'] if lab==5 else []})
 name=c['week_sources'][str(lab)]
 if name:shutil.copy2(source/name,out/'events.csv')
def expected(source):
 c=load(source/'course-contract.json');journal={};rejected=[];receipts={};out={};audit=[]
 for lab in range(1,7):
  asof=c['as_of'][str(lab)];before,_=current(list(journal.values()),asof);incoming=[];name=c['week_sources'][str(lab)]
  if name:
   with (source/name).open(encoding='utf-8',newline='') as f:incoming=list(csv.DictReader(f))
  counts={'request_id':'W'+str(lab),'received':len(incoming),'new_records':0,'rejected':0,'equivalent_repeats':0}
  for i,row in enumerate(incoming):
   v,error=decode(row)
   if error:rejected.append({'request_id':'W'+str(lab),'row_index':i,'row_id':row.get('row_id'),'code':error});counts['rejected']+=1
   elif canonical(v) in journal:counts['equivalent_repeats']+=1
   else:journal[canonical(v)]=v;counts['new_records']+=1
  receipts[counts['request_id']]=counts;snapshot,_=current(list(journal.values()),asof)
  results=[]
  if lab==5:results,audit=access(snapshot,c['principals'],c['queries'])
  if lab==3:before=snapshot # the observed successful call is the same-key replay after a real commit/exit73.
  out[lab]={'lab':lab,'request_id':'W'+str(lab),'as_of':asof,'journal_count':len(journal),'receipt':dict(counts),'replayed':lab==3,'snapshot':snapshot,'before_snapshot':before,'rejected':list(rejected),'access':results,'audit':list(audit),'checkpoint':{'schema':1,'journal':list(journal.values()),'receipts':dict(receipts),'rejected':list(rejected),'audit':list(audit)}}
 return out
def invoke(argv,cwd,data,state,out,extra=()):
 command=[*argv,'--data',str(data),'--state',str(state),'--out',str(out),*extra];start=time.perf_counter();p=subprocess.run(command,cwd=cwd,capture_output=True)
 out.mkdir(parents=True,exist_ok=True);(out/'stdout.bin').write_bytes(p.stdout);(out/'stderr.bin').write_bytes(p.stderr);save(out/'native.json',{'argv':command,'exit_code':p.returncode,'wall_seconds':time.perf_counter()-start})
 return p.returncode
def collect(student,source,out,route='guided'):
 out.mkdir(parents=True,exist_ok=False);declaration=load(student/'student.json');argv=declaration['argv'];results={};state=out/'state';codes={}
 for lab in range(1,7):
  data=out/('packet'+str(lab));packet(source,lab,data)
  if lab==3:
   crash=out/'lab3-commit-exit';codes['crash']=invoke(argv,student,data,state,crash,['--route',route,'--crash-after-commit'])
  target=out/('lab'+str(lab));codes[str(lab)]=invoke(argv,student,data,state,target,['--route',route])
  try:results[lab]={'lab':load(target/'lab.json'),'checkpoint':load(target/'checkpoint.json')}
  except (OSError,ValueError):results[lab]={'lab':None,'checkpoint':None}
 restore=out/'restored-lab4';seed=out/'lab3-commit-exit/checkpoint.json'
 if seed.is_file():codes['restore']=invoke(argv,student,out/'packet4',out/'restored-state',restore,['--route',route,'--restore',str(seed)])
 else:codes['restore']=None
 save(out/'collection.json',{'native_codes':codes,'route':route,'scope':'actual subprocesses, planned commit-after-write exit73 and same-key retry; not human learning evidence'})
 return codes,results
def evaluate(source,collection):
 wanted=expected(source);codes=load(collection/'collection.json')['native_codes'];actual={}
 for lab in range(1,7):
  try:actual[lab]=load(collection/f'lab{lab}/lab.json')
  except (OSError,ValueError):actual[lab]={}
 def cp(lab):
  try:return load(collection/f'lab{lab}/checkpoint.json')
  except (OSError,ValueError):return {}
 def compare(lab,key):return equal(actual[lab].get(key),wanted[lab][key])
 def chosen(lab,orders):return [r for r in actual[lab].get('snapshot',{}).get('states',[]) if r.get('order_id') in orders]
 def expected_chosen(lab,orders):return [r for r in wanted[lab]['snapshot']['states'] if r['order_id'] in orders]
 predicates={
 'D1':equal(cp(1).get('journal'),wanted[1]['checkpoint']['journal']),
 'D2':compare(1,'rejected'),
 'D3':all(equal(actual[n].get('snapshot',{}).get('future_rows'),wanted[n]['snapshot']['future_rows']) for n in (2,4,6)),
 'D4':all(compare(n,'receipt') for n in (1,3)),
 'D5':all(equal([(r.get('tenant'),r.get('order_id')) for r in actual[n].get('snapshot',{}).get('states',[])],[(r['tenant'],r['order_id']) for r in wanted[n]['snapshot']['states']]) for n in (2,4,6)),
 'S1':all(equal(chosen(n,['O3']),expected_chosen(n,['O3'])) for n in (3,6)),
 'S2':all(equal(chosen(n,['O2']),expected_chosen(n,['O2'])) for n in (3,6)),
 'S3':all(equal(chosen(n,['O4','O8']),expected_chosen(n,['O4','O8'])) for n in (4,6)),
 'S4':all(equal(actual[n].get('snapshot',{}).get('totals_minor'),wanted[n]['snapshot']['totals_minor']) for n in (2,3,4,6)),
 'S5':all(equal([(x.get('tenant'),x.get('order_id'),x.get('source_ids')) for x in actual[n].get('snapshot',{}).get('states',[])],[(x['tenant'],x['order_id'],x['source_ids']) for x in wanted[n]['snapshot']['states']]) for n in (4,6)),
 'R1':False,'R2':False,'R3':equal(chosen(4,['O5']),expected_chosen(4,['O5'])) and equal(cp(4).get('journal'),wanted[4]['checkpoint']['journal']),
 'R4':False,'R5':all(codes.get(str(n))==0 and type(actual[n].get('lab')) is int and actual[n]['lab']==n for n in range(1,7)),
 'A1':False,'A2':False,'A3':False,'A4':False,'A5':compare(5,'audit') and equal(cp(5).get('audit'),wanted[5]['checkpoint']['audit'])}
 try:
  crash=load(collection/'lab3-commit-exit/checkpoint.json');predicates['R1']=codes.get('crash')==73 and equal(crash['journal'],wanted[3]['checkpoint']['journal']) and equal(crash['receipts']['W3'],wanted[3]['receipt'])
 except (OSError,ValueError,KeyError,TypeError):pass
 predicates['R2']=actual[3].get('replayed') is True and equal(cp(3),wanted[3]['checkpoint']) and compare(3,'receipt')
 try:predicates['R4']=codes.get('restore')==0 and equal(load(collection/'restored-lab4/lab.json')['snapshot'],wanted[4]['snapshot']) and equal(load(collection/'restored-lab4/checkpoint.json'),wanted[4]['checkpoint'])
 except (OSError,ValueError,KeyError,TypeError):pass
 actual_access={q.get('id'):q for q in actual[5].get('access',[]) if isinstance(q,dict)};expected_access={q['id']:q for q in wanted[5]['access']}
 unique_access=len(actual_access)==len(actual[5].get('access',[]))==len(expected_access)
 for i,q in enumerate(('own','cross','unknown','admin'),1):predicates['A'+str(i)]=unique_access and equal(actual_access.get(q),expected_access[q])
 def observed_file(name):
  try:return load(collection/name)
  except (OSError,ValueError):return None
 def context(key):
  pairs=[]
  def add(path,got,want):pairs.append({'object':'actual-work/'+path,'observed':got,'expected':want})
  if key=='D1':add('lab1/checkpoint.json#/journal',cp(1).get('journal'),wanted[1]['checkpoint']['journal'])
  if key=='D2':add('lab1/lab.json#/rejected',actual[1].get('rejected'),wanted[1]['rejected'])
  if key=='D3':
   for n in (2,4,6):add(f'lab{n}/lab.json#/snapshot/future_rows',actual[n].get('snapshot',{}).get('future_rows'),wanted[n]['snapshot']['future_rows'])
  if key=='D4':
   for n in (1,3):add(f'lab{n}/lab.json#/receipt',actual[n].get('receipt'),wanted[n]['receipt'])
  if key=='D5':
   for n in (2,4,6):add(f'lab{n}/lab.json#/snapshot/states joint identities',[(r.get('tenant'),r.get('order_id')) for r in actual[n].get('snapshot',{}).get('states',[])],[(r['tenant'],r['order_id']) for r in wanted[n]['snapshot']['states']])
  if key in ('S1','S2','S3'):
   orders={'S1':['O3'],'S2':['O2'],'S3':['O4','O8']}[key]
   for n in ((3,6) if key!='S3' else (4,6)):add(f'lab{n}/lab.json#/snapshot/states order_id='+','.join(orders),chosen(n,orders),expected_chosen(n,orders))
  if key=='S4':
   for n in (2,3,4,6):add(f'lab{n}/lab.json#/snapshot/totals_minor',actual[n].get('snapshot',{}).get('totals_minor'),wanted[n]['snapshot']['totals_minor'])
  if key=='S5':
   for n in (4,6):add(f'lab{n}/lab.json#/snapshot/states selected source_ids',[(r.get('tenant'),r.get('order_id'),r.get('source_ids')) for r in actual[n].get('snapshot',{}).get('states',[])],[(r['tenant'],r['order_id'],r['source_ids']) for r in wanted[n]['snapshot']['states']])
  if key=='R1':add('collection.json#/native_codes/crash',codes.get('crash'),73);add('lab3-commit-exit/checkpoint.json',observed_file('lab3-commit-exit/checkpoint.json'),wanted[3]['checkpoint'])
  if key=='R2':add('lab3/lab.json#/replayed',actual[3].get('replayed'),True);add('lab3/checkpoint.json',cp(3),wanted[3]['checkpoint'])
  if key=='R3':add('lab4/lab.json#/snapshot/states order_id=O5',chosen(4,['O5']),expected_chosen(4,['O5']));add('lab4/checkpoint.json#/journal',cp(4).get('journal'),wanted[4]['checkpoint']['journal'])
  if key=='R4':add('collection.json#/native_codes/restore',codes.get('restore'),0);add('restored-lab4/checkpoint.json',observed_file('restored-lab4/checkpoint.json'),wanted[4]['checkpoint'])
  if key=='R5':add('collection.json#/native_codes normal labs',{str(n):codes.get(str(n)) for n in range(1,7)},{str(n):0 for n in range(1,7)});add('lab*/lab.json#/lab',[actual[n].get('lab') for n in range(1,7)],list(range(1,7)))
  if key in ('A1','A2','A3','A4'):
   q=('own','cross','unknown','admin')[int(key[1])-1];add('lab5/lab.json#/access[id='+q+']',actual_access.get(q),expected_access[q])
  if key=='A5':add('lab5/lab.json#/audit',actual[5].get('audit'),wanted[5]['audit']);add('lab5/checkpoint.json#/audit',cp(5).get('audit'),wanted[5]['checkpoint']['audit'])
  first=next((p for p in pairs if not equal(p['observed'],p['expected'])),None)
  return {'criterion':key,'status':'contract_matched' if predicates[key] else 'behavior_mismatch','objects':[p['object'] for p in pairs],'first_counterexample':first,'note':'Specific actual evidence and source-bound expectation; matching counterparts omitted only to keep feedback concise.'}
 items={key:{'points':int(ok),'maximum':1,'evidence':context(key)} for key,ok in predicates.items()}
 scores={d:sum(x['points'] for k,x in items.items() if k.startswith(d)) for d in ('D','S','R','A')}
 return {'items':items,'domains':scores,'total':sum(scores.values()),'maximum':20,'scope':'functional coursework behaviors only; conceptual feedback and human learning outcomes are not inferred'}
