select payload from observations;
