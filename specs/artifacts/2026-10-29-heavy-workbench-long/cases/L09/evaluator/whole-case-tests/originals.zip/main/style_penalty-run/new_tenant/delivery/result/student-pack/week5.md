# Week5: Principal scope and audit

Objective: Query own tenant, cross tenant, unknown identity and admin; log decisions from the principal policy.

Input: original authorized packet5/packet.json and its optional events.csv, plus the real previous state. UTC and cents are explicit. W1 starts empty; later labs retain state. 0.5h retrieval/diagnostic;0.75h worked example;1.5h guided lab;1h transfer challenge;0.5h feedback/retrieval;0.75h reflection and handover =5h.

Retrieval: Why does request.tenant=South not authorize north_reader?

Guided route: Use the role table, predict each request then run it, inspect denied output and durable audit.

Challenge route: Add a new tenant reader and prove allowed/denied sets follow policy rather than hardcoded tenant names. Both reach the same fixed business/functional contract. Support is based on an observed response, not an invented diagnosis of the person.

Run the declared lab entry with --data <packet5> --state <same-state> --out <new-out> --route guided|challenge. Inspect lab.json and checkpoint.json; queries.sql documents the actually executed SQL for the current-state lab. Expected actual result for this supplied input: journal_count 49, tenant cents {'East': 85750, 'North': 7575, 'South': 57575, 'West': 3125}, replayed False. On changed data recompute; these are answer observations, not hardcoded targets.

Failure interpretation: typed rejection preserves raw evidence; missing/conflict is unknown held value, cancelled is known zero. Exit73 is expected only for the deliberate W3 committed-write rehearsal, not a successful normal lab. Keep the exact state path and request, inspect the committed checkpoint and retry; never erase original journal to quiet an error. Unexpected native/schema failure is a stop-and-diagnose event, not evidence of conceptual incompetence.

Evidence task: point to original row IDs and the transaction/SQL/policy that explains the result. Change a legitimate value or tenant and predict which output must change and which invariant remains. Give another valid formulation. Feedback must distinguish an execution error from a wrong explanation. Exit0 alone is not a business answer.

Accessibility/support: all steps are keyboard CLI commands; use the plain text field glossary and CSV/table companions instead of color. Allow glossary-supported verbal or written explanation with the same evidence standard. No claim of independently certified accessibility is made.
