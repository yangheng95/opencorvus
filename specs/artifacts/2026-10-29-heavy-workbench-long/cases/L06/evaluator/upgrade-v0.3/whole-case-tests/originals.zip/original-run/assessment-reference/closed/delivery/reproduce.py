from pathlib import Path
import argparse,subprocess,sys
p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);a=p.parse_args();root=Path(__file__).resolve().parent
raise SystemExit(subprocess.call([sys.executable,'-u','-B',str(root/'tools/upgrade-v0.3/run_native_whole.py'),'--public',str(root/'public'),'--policy',str(root/'policy.json'),'--out',str(a.out),'--python',sys.executable]))
