from pathlib import Path
import shutil,json,zipfile,datetime
R=Path('D:/myhexin-local/opencorvus');ROOT=Path(__file__).resolve().parent;CASE=R/'specs/artifacts/2026-10-29-heavy-workbench-long/cases/L06/evaluator/upgrade-v0.3';D=CASE/'construction-evidence';D.mkdir(exist_ok=False)
shutil.copytree(ROOT/'report-derivation',D/'report')
for name in ('result.json','native.json','audit.json','policy.json','contingency-audit.json'):
 shutil.copy2(ROOT/'results/reference'/name,D/name)
shutil.copytree(ROOT/'logical-whole-controls',D/'logical-controls')
with zipfile.ZipFile(D/'originals.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for folder in ('reference-control','source','public','logical-whole-controls','report-derivation'):
  for p in sorted((ROOT/folder).rglob('*')):
   if p.is_file():z.write(p,folder+'/'+p.relative_to(ROOT/folder).as_posix())
 for name in ('launch_reference.py','reference-owner-started.json','reference-owner.stdout.txt','reference-owner.stderr.txt'):
  z.write(ROOT/name,name)
 for p in (CASE/'source').glob('*.py'):z.write(p,'later-current-source/'+p.name)
with zipfile.ZipFile(D/'originals.zip') as z:members=len(z.infolist())
receipt={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'original_root':str(ROOT),'bytes':(D/'originals.zip').stat().st_size,'members':members,'native120_reference':'reference-control contains original pre-source/raw + completed native capsule, no re-solve','report':'later host CPU matplotlib3.10.3 derivation; plot-deps local external target excluded','logical_controls':'real producer/checker native processes and pure logical replay; NOT isolated actor or SQLite crash/resume evidence','full_case_complete':False,'source_only_online_execution':'not performed; Docker Linux engine unavailable'}
(D/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
(D/'REPORT.md').write_text('''# New multi-stage full-instance construction evidence, not a frozen case

Original raw/public/source were sealed before the one new120second CPU source-only solve. Actual native0/FEASIBLE constructed394553/8 expected cost versus legal70640,118 improving incumbents,3968 variables/3996 constraints including1564 authoritative history equalities. Original native bound47594.75 is not an exact proof or old L47380. All8 path recurrences and60 complete event-prefix nodes checked; the15percent contingency-improvement goal was declared in the original tree-contract before this solve. No repeat solve occurred.

Real error_policy native processes produced4 actual policy files and same check_tree CLI returned explicit failures. The anticipate variant combines two complete physically feasible trajectories using a future-dependent choice: business_feasible true/information_legal false. Spot alternative is business/information valid but quality false. Complete logical journal replay/same-key original receipts agree with the current policy; none of these JSON records are isolated actor execution proof. actual-commands.json is the full observed process argv/stdout/stderr/exit, not an invented score.

Later CPU report derives exact4 cost components,128 weekly rows and full commitment rows. operations.png was actually viewed; cash floor, peak storage and three information dates are visible. Host plotting uses local external --target dependencies, not global mutation or a hidden numerical retrain. Source/later-current-source namespaces distinguish actual solver source from subsequent execution/checker/report construction.

Docker became unavailable before any new online actor test. execute_policy is currently unverified source, native isolation/commit-after-ACK interruption/restart/retained prefix/schema and robust input controls remain pending. No concentrated independent whole-case review has started; rubric/public are development drafts. This archive is not approval, a candidate score, the new0.3 freeze or useful candidate-hour evidence. Full ten-case and L02/L06升级 obligations remain.
''',encoding='utf-8')
print(json.dumps(receipt))
