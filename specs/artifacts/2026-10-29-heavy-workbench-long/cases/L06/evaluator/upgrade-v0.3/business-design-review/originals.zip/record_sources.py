"""Design-review source and original-receipt inventory; no business execution."""
import json
import shutil
import subprocess
from pathlib import Path

ROOT=Path(__file__).resolve().parent
REPO=Path('D:/myhexin-local/opencorvus')
CASE=REPO/'specs/artifacts/2026-10-29-heavy-workbench-long/cases/L06'
U=CASE/'evaluator/upgrade-v0.3'
paths=[U/n for n in ['BUSINESS-CONSTRUCTION.md','PLAN.md','information_policy.py','independent-review/REVIEW.md','independent-review/PLAN-CLARIFICATION-ADDENDUM.md']]
paths += [CASE/'evaluator/qualification/current-source'/n for n in ['check_l06.py','l06_input.py','l06_numeric.py','l06_delivery.py']]
paths += [CASE/'public'/n for n in ['TASK.md','DATA.md','OUTPUTS.md']]
paths += [CASE/'rubric.json',CASE/'evaluator/FREEZE.json']
dest=ROOT/'source-reviewed';dest.mkdir(parents=True,exist_ok=False)
inventory=[]
for p in paths:
    relative=p.relative_to(REPO);target=dest/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
    inventory.append({'source':str(p),'snapshot':str(target.relative_to(ROOT)),'bytes':p.stat().st_size})
(ROOT/'source-inventory.json').write_text(json.dumps(inventory,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
q=Path('D:/opencorvus-benchmark-runs/l06-v03-transition-qualification-20261030')
shutil.copy2(q/'baseline-assessment.json',ROOT/'parent-baseline-assessment-original.json')
baseline=json.loads((q/'baseline-assessment.json').read_text(encoding='utf-8'))
observation={'source':str(q/'baseline-assessment.json'),'parent_recomputed_before_extraction':True,'reviewer_reexecuted':False,
 'results':[{'name':r['name'],'expected_cost_exact':r['expected_cost_exact'],'constraint_checks':r['constraint_checks'],'sum_reported_family_counts':sum(r['constraint_checks'].values())}for r in baseline['results']],
 'scope':'original parent receipt observed, not independent mathematical replay or future extraction qualification'}
(ROOT/'baseline-observation.json').write_text(json.dumps(observation,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
git=subprocess.run(['git','status','--short'],cwd=REPO,capture_output=True,text=True,encoding='utf-8')
(ROOT/'git-status-observed.txt').write_text(git.stdout,encoding='utf-8')
print(json.dumps({'sources':len(inventory),'baseline_receipts':len(observation['results']),'new_experiments':0,'repository_modified':False},ensure_ascii=False))
