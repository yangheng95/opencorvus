from pathlib import Path

SRC=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L06/evaluator/qualification/current-source/check_l06.py')
old=SRC.read_bytes();before=(Path(__file__).parent/'source-before/check_l06.py').read_bytes()
if old!=before:raise ValueError('current checker changed after the protected pre-edit capture')
text=old.decode('utf-8').replace('\r\n','\n')
text=text.replace('from l06_input import InputError, read_json, validate_instance,diagnostic_value\n',
    'from l06_input import InputError, read_json, validate_instance,diagnostic_value\nfrom l06_physics import initial_state, propose_week\n')
start=text.index('    results = {}\n');end=text.index('    feasible=len(violations)==0\n',start)
replacement='''    results = {}
    expected = Fraction()
    for scenario in scenarios:
        name=scenario['id'];record=decisions[name];state=initial_state(data)
        rows=[];observations=[]
        hits={key:0 for key in ('supplier_capacity','shipment_minimum','plant_capacity','raw_storage','product_storage','credit_limit')}
        for t in range(T):
            event={key:scenario[key][t] for key in ('demand','supplier_capacity_volume','plant_capacity_hours')}
            action={key:record[key][t] for key in ('order_lots','truck_on','production')}
            declared={key:record[key][t] for key in ('raw_inventory','finished_inventory') if key in record}
            proposed=propose_week(data,state,event,action,name,declared)
            # Legacy inspection intentionally continues tentative algebra to
            # collect all residuals. An invalid path never publishes finance.
            state=proposed['tentative_state'];rows.append(proposed['week_row'])
            observations.extend(proposed['observations'])
            for key,count in proposed['active_constraints'].items():hits[key]+=count
        # Preserve the established first-error contract: every order predicate
        # was historically collected before any physical-week predicate.
        for stage in ('order','physical'):
            for item in observations:
                if item['stage']==stage:
                    check(item['passed'],item['code'],item['where'],item['actual'],item['required'],item['context'])
        check(all(count==0 for count in state['finished']),'terminal_finished',name,state['finished'],'all zero')
        total=state['total_cost_minor'];receivable=sum(state['receipts_by_week'][T:])
        expected+=Fraction(total*scenario['probability_numerator'],data['probability_denominator'])
        results[name]={'total_cost_minor':total,'final_cash_minor':state['cash'],'final_receivable_minor':receivable,
            'minimum_cash_minor':min(row['cash'] for row in rows),'active_constraints':hits,'weeks':rows}
'''
text=text[:start]+replacement+text[end:]
SRC.write_text(text,encoding='utf-8',newline='\n')
print('one current recurrence extracted; legacy collector consumes its tentative observations')
