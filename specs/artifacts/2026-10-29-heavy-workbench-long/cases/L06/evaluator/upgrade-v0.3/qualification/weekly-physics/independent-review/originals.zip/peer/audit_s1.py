"""Reviewer's independent exact ledger reconstruction and one hand state card.

No optimizer, candidate code or historical checker is executed. The current
frozen kernel/checker is imported only from this review's source snapshot.
"""
import json
import sys
import subprocess
import time
from pathlib import Path
from fractions import Fraction
from copy import deepcopy

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'source'))
from l06_physics import initial_state,begin_week,propose_week,StateError
from check_l06 import inspect_plan

checks=[]
def record(name,condition,observed=None):
    checks.append({'name':name,'passed':bool(condition),'observed':observed})
    if not condition:raise AssertionError(name)
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def dump(p,x):p.write_text(json.dumps(x,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def exact(a,b):
    if type(a)!=type(b):return False
    if isinstance(a,dict):return set(a)==set(b)and all(exact(a[k],b[k])for k in a)
    if isinstance(a,list):return len(a)==len(b)and all(exact(x,y)for x,y in zip(a,b))
    return a==b

def independent_ledger(d,scenario,decision):
    """Direct prefix reconstruction, not importing either old or new equations."""
    T=d['weeks'];M=len(d['raw_materials']);J=len(d['products']);P=len(d['plants'])
    arrivals=[[0]*M for _ in range(T)]
    purchases=[0]*T;freight=[0]*T;volumes=[[]for _ in range(T)]
    for t in range(T):
        for s,supplier in enumerate(d['suppliers']):
            counts=[decision['order_lots'][t][s][m]*supplier['pack_units'][m]for m in range(M)]
            due=t+supplier['lead_weeks']
            if due<T:
                for m in range(M):arrivals[due][m]+=counts[m]
            else:record('independent valid plan has zero post-horizon raw order',sum(counts)==0)
            purchases[t]+=sum(counts[m]*supplier['price_minor'][m]for m in range(M))
            freight[t]+=decision['truck_on'][t][s]*supplier['freight_minor']
            volumes[t].append(sum(counts[m]*d['raw_volume'][m]for m in range(M)))
    raw=d['initial_raw'][:];finished=d['initial_products'][:];cash=d['initial_cash_minor'];rows=[]
    active={k:0 for k in ['supplier_capacity','shipment_minimum','plant_capacity','raw_storage','product_storage','credit_limit']}
    for t in range(T):
        made=[sum(decision['production'][t][p][j]for p in range(P))for j in range(J)]
        hours=[sum(decision['production'][t][p][j]*d['production_hours'][j]for j in range(J))for p in range(P)]
        used=[sum(made[j]*d['bom'][j][m]for j in range(J))for m in range(M)]
        raw_start=[raw[m]+arrivals[t][m]for m in range(M)]
        finished_start=[finished[j]+made[j]for j in range(J)]
        raw_peak=sum(raw_start[m]*d['raw_volume'][m]for m in range(M))
        fg_peak=sum(finished_start[j]*d['product_volume'][j]for j in range(J))
        raw=[raw_start[m]-used[m]for m in range(M)]
        finished=[finished_start[j]-scenario['demand'][t][j]for j in range(J)]
        labor=sum(decision['production'][t][p][j]*d['production_cost_minor'][p][j]for p in range(P)for j in range(J))
        holding=sum(raw[m]*d['raw_holding_minor'][m]for m in range(M))+sum(finished[j]*d['product_holding_minor'][j]for j in range(J))
        cost=purchases[t]+freight[t]+labor+holding
        past=t-d['receipt_lag_weeks']
        received=0 if past<0 else sum(scenario['demand'][past][j]*d['sales_price_minor'][j]for j in range(J))
        cash+=received-cost
        for s,supplier in enumerate(d['suppliers']):
            on=decision['truck_on'][t][s]
            active['supplier_capacity']+=int(on==1 and volumes[t][s]==scenario['supplier_capacity_volume'][t][s])
            active['shipment_minimum']+=int(on==1 and volumes[t][s]==supplier['minimum_volume'])
        for p in range(P):active['plant_capacity']+=int(scenario['plant_capacity_hours'][t][p]>0 and hours[p]==scenario['plant_capacity_hours'][t][p])
        active['raw_storage']+=int(raw_peak==d['raw_storage_volume']);active['product_storage']+=int(fg_peak==d['product_storage_volume'])
        active['credit_limit']+=int(t<T-1 and cash==-d['credit_limit_minor'])
        record('independent valid week physical/terminal cash '+scenario['id']+'/'+str(t),min(raw)>=0 and min(finished)>=0 and cash>=(0 if t==T-1 else -d['credit_limit_minor']))
        rows.append({'week':t,'raw_inventory':raw[:],'finished_inventory':finished[:],'arrivals':arrivals[t],
            'consumption':used,'made':made,'hours':hours,'raw_stage_peak_volume':raw_peak,'product_stage_peak_volume':fg_peak,
            'supplier_volume':volumes[t],'purchase_cost':purchases[t],'freight_cost':freight[t],
            'production_cost':labor,'holding_cost':holding,'cost':cost,'receipts':received,'cash':cash})
    AR=sum(sum(scenario['demand'][t][j]*d['sales_price_minor'][j]for j in range(J))for t in range(T)if t+d['receipt_lag_weeks']>=T)
    return {'total_cost_minor':sum(row['cost']for row in rows),'final_cash_minor':cash,'final_receivable_minor':AR,
        'minimum_cash_minor':min(row['cash']for row in rows),'active_constraints':active,'weeks':rows}

start=time.perf_counter()
for name in ['opencorvus','codex']:
    folder=ROOT/'inputs'/name;d=load(folder/'business-input.json');p=load(folder/'operational-plan.json')
    actual=inspect_plan(d,p);baseline=load(folder/'baseline-inspection.json')
    record(name+' exact complete pre-extraction object',exact(actual,baseline))
    independent={s['id']:independent_ledger(d,s,p['decisions'][s['id']])for s in d['scenarios']}
    expected=sum((Fraction(independent[s['id']]['total_cost_minor']*s['probability_numerator'],d['probability_denominator'])for s in d['scenarios']),Fraction())
    record(name+' all scenario ledger fields independently reconstructed',exact(independent,actual['scenarios']))
    record(name+' exact probability weighted cost',actual['expected_cost_exact']=={'numerator':expected.numerator,'denominator':expected.denominator},str(expected))
    dump(folder/'independent-ledger.json',{'scenarios':independent,'expected_cost_exact':str(expected)})
    dump(folder/'current-inspection.json',actual)

# Three-week hand card: order paid now, zero future order capacity does not
# cancel a past commitment; signed cash restores and due values settle once.
d={'format':'l06-feasibility-instance/2','weeks':3,'common_weeks':0,'probability_denominator':1,
    'raw_materials':['R'],'products':['P'],'plants':['F'],
    'suppliers':[{'id':'S','lead_weeks':1,'pack_units':[1],'price_minor':[2],'freight_minor':0,'minimum_volume':0}],
    'allowed':[[1]],'production_hours':[1],'production_cost_minor':[[0]],'bom':[[1]],
    'raw_volume':[1],'product_volume':[1],'raw_holding_minor':[0],'product_holding_minor':[0],
    'raw_storage_volume':1,'product_storage_volume':1,'initial_raw':[0],'initial_products':[0],
    'initial_cash_minor':1,'credit_limit_minor':1,'sales_price_minor':[3],'receipt_lag_weeks':1,
    'scenarios':[{'id':'public-card','probability_numerator':1,'demand':[[0],[1],[0]],'supplier_capacity_volume':[[1],[0],[0]],'plant_capacity_hours':[[0],[1],[0]]}]}
plan={'format':'l06-plan/1','decisions':{'public-card':{'order_lots':[[[1]],[[0]],[[0]]],'truck_on':[[1],[0],[0]],'production':[[[0]],[[1]],[[0]]]}}}
state=initial_state(d);states=[]
for t in range(3):
    event={k:d['scenarios'][0][k][t]for k in ['demand','supplier_capacity_volume','plant_capacity_hours']}
    action={k:plan['decisions']['public-card'][k][t]for k in ['order_lots','truck_on','production']}
    original=deepcopy(state);v=begin_week(d,state,event);v_again=begin_week(d,state,event)
    proposal=propose_week(d,state,event,action,'public-card')
    record('hand card '+str(t)+' begin pure and original unchanged',state==original and v==v_again)
    record('hand card '+str(t)+' week admissible',proposal['week_admissible'])
    record('hand card '+str(t)+' cash/due progression',proposal['tentative_state']['cash']==[-1,-1,2][t]and proposal['tentative_state']['next_week']==t+1)
    if t==2:record('receipt3 added once from post cash-1 to2',v['historical_receipts']==3 and v['cash_after_historical_receipts']==2 and state['cash']==-1 and proposal['tentative_state']['receipts_by_week'][2]==0)
    # Returned event/view copies must not modify either authority.
    v['external']['demand'][0]=999
    record('hand view external is a copy '+str(t),event['demand']==d['scenarios'][0]['demand'][t])
    state=proposal['tentative_state'];states.append(deepcopy(proposal))
record('hand final cash2 cost2 no raw no FG no unpaid past due',state['cash']==2 and state['total_cost_minor']==2 and state['raw']==[0]and state['finished']==[0]and sum(state['receipts_by_week'])==0)
try:begin_week(d,state,event)
except StateError as e:record('finished post_week input maps to phase error',e.code=='week_state_phase_invalid')
else:record('finished phase error',False)
dump(ROOT/'hand-state-card.json',{'input':d,'plan':plan,'proposals':states})

# One real checker CLI has a late order error and two early physical peak
# errors: this proves preserved first-error ordering and finance masking.
bad=deepcopy(d);bad['weeks']=2;bad['raw_storage_volume']=bad['product_storage_volume']=0
bad['suppliers'][0]['lead_weeks']=0;bad['initial_cash_minor']=10
bad['scenarios'][0].update(demand=[[1],[0]],supplier_capacity_volume=[[1],[0]],plant_capacity_hours=[[1],[0]])
badplan={'format':'l06-plan/1','decisions':{'public-card':{'order_lots':[[[1]],[[0]]],'truck_on':[[1],[2]],'production':[[[1]],[[0]]]}}}
inspection=inspect_plan(bad,badplan)
record('all residuals and legacy order first retained',[v['code']for v in inspection['violations']]==['shipment_binary','raw_storage_peak','product_storage_peak'])
record('invalid finance masked',inspection['business_feasible']is False and inspection['scenarios']is None and inspection['expected_cost_exact']is None and inspection['expected_cost_minor']is None)
dump(ROOT/'invalid-input.json',bad);dump(ROOT/'invalid-plan.json',badplan);dump(ROOT/'invalid-inspection.json',inspection)
argv=[sys.executable,'-B',str(ROOT/'source/check_l06.py'),'--input',str(ROOT/'invalid-input.json'),'--plan',str(ROOT/'invalid-plan.json'),'--out',str(ROOT/'invalid-cli-result.json')]
proc=subprocess.run(argv,capture_output=True)
dump(ROOT/'invalid-cli-command.json',{'argv':argv,'exit_code':proc.returncode,'stdout':proc.stdout.decode('utf-8'),'stderr':proc.stderr.decode('utf-8')})
result=load(ROOT/'invalid-cli-result.json')
record('real CLI error contract',proc.returncode==2 and result['error']=='shipment_binary'and result['where']=='public-card.week1.S')
dump(ROOT/'independent-assessment.json',{'checks':checks,'all_passed':all(c['passed']for c in checks),'elapsed_seconds':time.perf_counter()-start,
    'new_checker_cli':1,'new_solver_Docker_LLM_calls':0,'scope':'S1 extraction only; no online or full03 safety qualification'})
print(json.dumps({'checks':len(checks),'all_passed':all(c['passed']for c in checks),'seconds':time.perf_counter()-start,'new_checker_cli':1}))
