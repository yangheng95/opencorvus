"""Capture two previously sealed real plans before extracting the shared physics.

This is an exact read/recalculation, not a new optimization or candidate run.
"""
from pathlib import Path
import json
import shutil
import sys
import time

ROOT=Path(__file__).resolve().parent
SRC=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L06/evaluator/qualification/current-source')
PAIR=Path('D:/opencorvus-benchmark-runs/L06-paired-20261029-be2a55d1')
snapshot=ROOT/'source-before';snapshot.mkdir(parents=True,exist_ok=False)
for path in SRC.glob('*.py'):shutil.copyfile(path,snapshot/path.name)
sys.path.insert(0,str(snapshot))
from l06_packet import read_packet
from l06_input import read_json
from l06_delivery import operational_decisions
from check_l06 import inspect_plan

began=time.perf_counter();results=[]
for name in ['opencorvus','codex']:
    command=json.loads((PAIR/name/'evaluation/final-grade-command.json').read_text(encoding='utf-8'))['argv']
    raw=Path(command[command.index('--input')+1]);plan_path=Path(command[command.index('--plan')+1])
    data=read_packet(raw);original=read_json(plan_path,'plan_json');plan=operational_decisions(original)
    result=inspect_plan(data,plan)
    if not result['business_feasible']:raise AssertionError(name+': previously qualified plan no longer feasible')
    out=ROOT/name;out.mkdir()
    for filename,value in [('business-input',data),('operational-plan',plan),('baseline-inspection',result)]:
        (out/(filename+'.json')).write_text(json.dumps(value,indent=2),encoding='utf-8')
    shutil.copyfile(plan_path,out/'original-plan.json')
    results.append({'name':name,'raw':str(raw),'plan':str(plan_path),'business_feasible':True,
        'expected_cost_exact':result['expected_cost_exact'],'constraint_checks':result['constraint_checks']})
(ROOT/'baseline-assessment.json').write_text(json.dumps({'scope':'two old real sealed-plan recurrences before extraction; zero solver/LLM/new execution',
    'results':results,'wall_seconds':time.perf_counter()-began},indent=2),encoding='utf-8')
print(json.dumps({'results':[{'name':r['name'],'expected_cost_exact':r['expected_cost_exact']} for r in results],'wall_seconds':time.perf_counter()-began}))
