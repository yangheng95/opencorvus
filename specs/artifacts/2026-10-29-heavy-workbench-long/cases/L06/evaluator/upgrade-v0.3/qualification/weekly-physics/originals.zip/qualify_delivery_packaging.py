import json
from pathlib import Path
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parent
SRC=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L06/evaluator/qualification/current-source')
data={'format':'l06-feasibility-instance/2','weeks':2,'common_weeks':2,'probability_denominator':2,
    'raw_materials':['R'],'products':['P'],'plants':['F'],
    'suppliers':[{'id':'A','lead_weeks':0,'pack_units':[2],'price_minor':[1],'freight_minor':2,'minimum_volume':2}],
    'allowed':[[1]],'production_hours':[1],'production_cost_minor':[[1]],'bom':[[1]],'raw_volume':[1],'product_volume':[1],
    'raw_holding_minor':[1],'product_holding_minor':[0],'raw_storage_volume':2,'product_storage_volume':1,
    'initial_raw':[0],'initial_products':[0],'initial_cash_minor':1,'credit_limit_minor':5,
    'sales_price_minor':[10],'receipt_lag_weeks':1,
    'scenarios':[{'id':s,'probability_numerator':1,'demand':[[1],[0]],'supplier_capacity_volume':[[2],[2]],'plant_capacity_hours':[[1],[1]]} for s in ['a','b']]}
plan={'format':'l06-plan/1','decisions':{s:{'order_lots':[[[1]],[[0]]],'truck_on':[[1],[0]],'production':[[[1]],[[0]]]} for s in ['a','b']}}
for name,value in [('credit-input',data),('credit-plan',plan)]:
    (ROOT/(name+'.json')).write_text(json.dumps(value,indent=2),encoding='utf-8')
command=[sys.executable,'-X','utf8','-B',str(SRC/'qualify_delivery.py'),
    '--reference-input',str(ROOT/'opencorvus/business-input.json'),
    '--reference-plan',str(ROOT/'opencorvus/operational-plan.json'),'--expected-cost-exact','476871/10',
    '--credit-input',str(ROOT/'credit-input.json'),'--credit-plan',str(ROOT/'credit-plan.json'),
    '--output',str(ROOT/'explicit-delivery-tool')]
start=time.perf_counter();p=subprocess.run(command,capture_output=True,text=True,encoding='utf-8')
receipt={'argv':command,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'wall_seconds':time.perf_counter()-start,
    'scope':'focused source-dependency and explicit-input repair qualification; zero new optimization/model run, not case difficulty'}
(ROOT/'explicit-delivery-tool-command.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(receipt));raise SystemExit(p.returncode)
