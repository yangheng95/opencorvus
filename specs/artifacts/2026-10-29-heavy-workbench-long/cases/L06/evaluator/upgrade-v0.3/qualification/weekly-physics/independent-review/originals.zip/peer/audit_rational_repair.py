"""Only the two new rational/finite-decimal delivery contracts, no old suite."""
from pathlib import Path
import json,sys,subprocess,shutil,difflib,time
from copy import deepcopy

R=Path(__file__).resolve().parent
SRC=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L06/evaluator/qualification/current-source')
out=R/'rational-repair';out.mkdir();source=out/'source';source.mkdir()
identities=[]
for p in(R/'source').glob('*.py'):
    current=(SRC/p.name).read_bytes();(source/p.name).write_bytes(current)
    identities.append({'file':p.name,'same_initial_review_bytes':p.read_bytes()==current})
(out/'source-identity.json').write_text(json.dumps(identities,indent=2)+'\n',encoding='utf-8')
(out/'qualify_delivery.diff').write_text(''.join(difflib.unified_diff((R/'source/qualify_delivery.py').read_text().splitlines(True),(source/'qualify_delivery.py').read_text().splitlines(True),fromfile='initial-reviewed',tofile='repaired')),encoding='utf-8')
sys.path.insert(0,str(source))
from check_l06 import evaluate
from l06_delivery import expected_delivery
from l06_packet import write_packet
from qualify_delivery import unreduced_summary

def read(p):return json.loads(p.read_text(encoding='utf-8'))
def write(p,v):p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n',encoding='utf-8')
original=read(R/'third-input.json');plan=read(R/'third-plan.json')
probes=[];began=time.perf_counter()
for name in ['one-third-unreduced','one-half-exact-decimal']:
    folder=out/name;folder.mkdir()
    d=deepcopy(original);p=deepcopy(plan)
    if name=='one-half-exact-decimal':
        d['probability_denominator']=2;d['scenarios']=[s for s in d['scenarios']if s['id']!='two']
        del p['decisions']['two']
    write(folder/'input.json',d);write(folder/'plan.json',p)
    packet=folder/'raw';write_packet(d,packet)
    ledger,summary=expected_delivery(d,p,evaluate(d,p))
    if name=='one-third-unreduced':
        assert summary['expected_cost_minor']=={'numerator':1,'denominator':3}
        summary=unreduced_summary(summary)
        assert summary['expected_cost_minor']=={'numerator':100,'denominator':300}
    else:
        assert summary['expected_cost_minor']=={'numerator':1,'denominator':2}
        summary['expected_cost_minor']=0.5
    write(folder/'ledger.json',ledger);write(folder/'summary.json',summary)
    argv=[sys.executable,'-B',str(source/'l06_delivery.py'),'--input',str(packet),'--plan',str(folder/'plan.json'),'--ledger',str(folder/'ledger.json'),'--summary',str(folder/'summary.json'),'--out',str(folder/'result.json')]
    proc=subprocess.run(argv,capture_output=True)
    receipt={'argv':argv,'exit_code':proc.returncode,'stdout':proc.stdout.decode('utf-8'),'stderr':proc.stderr.decode('utf-8')}
    write(folder/'command.json',receipt)
    result=read(folder/'result.json');assert proc.returncode==0 and result['counts']['verified_pass']==10
    probes.append({'name':name,'exit_code':proc.returncode,'counts':result['counts']})
write(out/'assessment.json',{'probes':probes,'seconds':time.perf_counter()-began,'old_failure_preserved':True,'scope':'two new exact representation controls only; does not repeat old11 qualification or certify full03'})
print(json.dumps({'probes':probes,'seconds':time.perf_counter()-began}))
