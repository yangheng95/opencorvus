import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parent
SRC=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L06/evaluator/qualification/current-source')
sys.path.insert(0,str(SRC))
from check_l06 import inspect_plan
if (SRC/'l06_input.py').read_bytes()!=(ROOT/'source-before/l06_input.py').read_bytes():raise ValueError('input primitive changed')
spec=importlib.util.spec_from_file_location('l06_old_captured_checker',ROOT/'source-before/check_l06.py')
before=importlib.util.module_from_spec(spec);spec.loader.exec_module(before)
def same(a,b):
    if type(a) is not type(b):return False
    if isinstance(a,dict):return set(a)==set(b) and all(same(a[k],b[k]) for k in a)
    if isinstance(a,list):return len(a)==len(b) and all(same(x,y) for x,y in zip(a,b))
    return a==b
began=time.perf_counter();checks=[]
for case in sorted((ROOT/'cards').iterdir()):
    data=json.loads((case/'input.json').read_text());plan=json.loads((case/'plan.json').read_text())
    old=before.inspect_plan(data,plan);new=inspect_plan(data,plan)
    (case/'old-full-inspection.json').write_text(json.dumps(old,indent=2),encoding='utf-8')
    checks.append({'case':case.name,'all_rows_violations_order_context_families_counts_mask_equal':same(old,new)})
    if not checks[-1]['all_rows_violations_order_context_families_counts_mask_equal']:raise AssertionError(case.name)
grades=[]
PAIR=Path('D:/opencorvus-benchmark-runs/L06-paired-20261029-be2a55d1')
for name in ['opencorvus','codex']:
    original=json.loads((PAIR/name/'evaluation/final-grade-command.json').read_text())
    command=original['argv'].copy();target=ROOT/name/'current-complete-grade.json';command[command.index('--out')+1]=str(target)
    p=subprocess.run(command,capture_output=True,text=True,encoding='utf-8')
    receipt={'argv':command,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
    (ROOT/name/'current-complete-grade-command.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
    value=json.loads(target.read_text())
    passed=p.returncode==0 and value['total_score']==100 and value['good'] is True and value['counts']['verified_pass']==47
    grades.append({'name':name,'passed':passed,'score':value['total_score'],'counts':value['counts'],
        'scope':'same historical sealed candidate/review, current checker refactor regression only; not a fresh candidate or03 score'})
    if not passed:raise AssertionError(name)
result={'scope':'complete legacy residual/first-error/family equivalence and same historical grading through current real CLI',
    'checks':checks,'grades':grades,'wall_seconds':time.perf_counter()-began,'new_solver_LLM_Docker_calls':0,'full03_qualified':False}
(ROOT/'all-residual-equivalence.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps({'cases':len(checks),'equivalent':all(r['all_rows_violations_order_context_families_counts_mask_equal'] for r in checks),'same_old_grade_100':[g['passed'] for g in grades],'wall_seconds':result['wall_seconds']}))
