from copy import deepcopy
from datetime import datetime,timezone
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parent
SRC=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L06/evaluator/qualification/current-source')
sys.path.insert(0,str(SRC))
from check_l06 import inspect_plan,evaluate,PlanError
from l06_physics import initial_state,begin_week,propose_week,StateError

began=time.perf_counter();checks=[];commands=[]
def check(name,passed,observed=None):
    checks.append({'name':name,'passed':bool(passed),'observed':observed})
    if not passed:raise AssertionError(name)
def same(a,b):
    if type(a) is not type(b):return False
    if isinstance(a,dict):return set(a)==set(b) and all(same(a[k],b[k]) for k in a)
    if isinstance(a,list):return len(a)==len(b) and all(same(x,y) for x,y in zip(a,b))
    return a==b
def dump(path,value):path.write_text(json.dumps(value,indent=2),encoding='utf-8')
def command(argv,out):
    p=subprocess.run(argv,capture_output=True,text=True,encoding='utf-8')
    record={'argv':argv,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
    dump(out,record);commands.append(record);return p

for name in ['opencorvus','codex']:
    folder=ROOT/name;data=json.loads((folder/'business-input.json').read_text());plan=json.loads((folder/'operational-plan.json').read_text())
    expected=json.loads((folder/'baseline-inspection.json').read_text());actual=inspect_plan(data,plan)
    dump(folder/'extracted-inspection.json',actual)
    check(name+':all_old_rows_cost_AR_active_predicates_exact',same(actual,expected))

def factory(T=3,lead=1,price=2,lag=1,cash=1,credit=1):
    return {'format':'l06-feasibility-instance/2','weeks':T,'common_weeks':0,'probability_denominator':1,
        'raw_materials':['R'],'products':['P'],'plants':['F'],
        'suppliers':[{'id':'S','lead_weeks':lead,'pack_units':[1],'price_minor':[price],'freight_minor':0,'minimum_volume':0}],
        'allowed':[[1]],'production_hours':[1],'production_cost_minor':[[0]],'bom':[[1]],
        'raw_volume':[1],'product_volume':[1],'raw_holding_minor':[0],'product_holding_minor':[0],
        'raw_storage_volume':2,'product_storage_volume':2,'initial_raw':[0],'initial_products':[0],
        'initial_cash_minor':cash,'credit_limit_minor':credit,'sales_price_minor':[3],'receipt_lag_weeks':lag,
        'scenarios':[{'id':'only','probability_numerator':1,'demand':[[0] for _ in range(T)],
            'supplier_capacity_volume':[[1] for _ in range(T)],'plant_capacity_hours':[[1] for _ in range(T)]}]}
def policy(T):
    return {'format':'l06-plan/1','decisions':{'only':{'order_lots':[[[0]] for _ in range(T)],
        'truck_on':[[0] for _ in range(T)],'production':[[[0]] for _ in range(T)]}}}
def set_action(plan,t,lots,truck,production):
    r=plan['decisions']['only'];r['order_lots'][t]=[[lots]];r['truck_on'][t]=[truck];r['production'][t]=[[production]]

data=factory();data['scenarios'][0]['demand'][1]=[1]
data['scenarios'][0]['supplier_capacity_volume']=[[1],[0],[0]]
data['scenarios'][0]['plant_capacity_hours']=[[0],[1],[0]]
plan=policy(3);set_action(plan,0,1,1,0);set_action(plan,1,0,0,1)
state=initial_state(data);cards=[]
for t in range(3):
    event={k:data['scenarios'][0][k][t] for k in ('demand','supplier_capacity_volume','plant_capacity_hours')}
    action={k:plan['decisions']['only'][k][t] for k in ('order_lots','truck_on','production')}
    view=begin_week(data,state,event);repeat=begin_week(data,state,event)
    if t==2:
        check('repeatable_begin_cash2_receipt3_from_post_cash_minus1',view==repeat and view['cash_after_historical_receipts']==2 and view['historical_receipts']==3 and state['cash']==-1 and state['receipts_by_week'][2]==3)
    proposal=propose_week(data,state,event,action,'only')
    check('state_card_week'+str(t)+':admissible',proposal['week_admissible'])
    state=proposal['tentative_state'];cards.append({'view':view,'proposal':proposal})
    if t==0:check('post0_cash_minus1_due1_raw1',state['phase']=='post_week' and state['next_week']==1 and state['cash']==-1 and state['arrivals_by_week'][1]==[1])
    if t==1:check('post1_cash_minus1_due2_AR3',state['next_week']==2 and state['cash']==-1 and state['raw']==[0] and state['finished']==[0] and state['receipts_by_week'][2]==3)
check('post2_final_cash2_total_cost2_due2_settled',state['next_week']==3 and state['cash']==2 and state['total_cost_minor']==2 and state['receipts_by_week'][2]==0)
dump(ROOT/'three-week-cards.json',cards)

cases=[('signed-credit-and-receipts',data,plan,None)]
data=factory(T=1,lead=0,cash=10);data['scenarios'][0]['demand']=[[1]];data['raw_storage_volume']=data['product_storage_volume']=0
plan=policy(1);set_action(plan,0,1,1,1);cases.append(('both-stage-peaks',data,plan,'raw_storage_peak'))
data2=deepcopy(data);data2['weeks']=2;data2['scenarios'][0]['demand']=[[1],[0]];data2['scenarios'][0]['supplier_capacity_volume']=[[1],[0]];data2['scenarios'][0]['plant_capacity_hours']=[[1],[0]]
plan2=policy(2);set_action(plan2,0,1,1,1);set_action(plan2,1,0,2,0);cases.append(('later-order-before-earlier-physical-first-error',data2,plan2,'shipment_binary'))
data=factory(T=1,lead=1,cash=3);data['suppliers'][0]['freight_minor']=3;data['scenarios'][0]['supplier_capacity_volume']=[[0]]
plan=policy(1);set_action(plan,0,0,1,0);cases.append(('MOQ0-empty-truck-paid',data,plan,None))
data=factory(T=1,lead=0,cash=6);data['suppliers'][0]['pack_units']=[3];data['suppliers'][0]['minimum_volume']=3
data['scenarios'][0].update(demand=[[3]],supplier_capacity_volume=[[3]],plant_capacity_hours=[[3]])
data['raw_storage_volume']=data['product_storage_volume']=3;plan=policy(1);set_action(plan,0,1,1,3);cases.append(('pack-units-not-lot-price',data,plan,None))
data=factory(T=1,lead=0,cash=0);data['suppliers'][0]['minimum_volume']=1;plan=policy(1);set_action(plan,0,0,1,0);cases.append(('MOQ-positive-empty-truck',data,plan,'shipment_minimum'))
data=factory(T=1,lead=0,cash=0);plan=policy(1);set_action(plan,0,0,2,0);cases.append(('binary-truck',data,plan,'shipment_binary'))
data=factory(T=1,lead=0,cash=3);data['raw_holding_minor']=[1];plan=policy(1);set_action(plan,0,1,1,0);cases.append(('terminal-raw-allowed-with-holding',data,plan,None))
data=factory(T=1,lead=0,cash=10);plan=policy(1);set_action(plan,0,1,1,1);cases.append(('terminal-FG-rejected',data,plan,'terminal_finished'))
data=factory(T=1,lead=1,cash=2);plan=policy(1);set_action(plan,0,1,1,0);cases.append(('terminal-raw-pipeline-rejected',data,plan,'terminal_pipeline'))
data=factory(T=1,lead=0,lag=5,cash=2);data['scenarios'][0]['demand']=[[1]];plan=policy(1);set_action(plan,0,1,1,1);cases.append(('post-horizon-AR-allowed-not-cash',data,plan,None))
data=factory(T=1,lead=0,cash=0,credit=2);data['scenarios'][0]['demand']=[[1]];plan=policy(1);set_action(plan,0,1,1,1);cases.append(('terminal-cash-not-credit-or-AR',data,plan,'cash_limit'))
data=factory(T=1,lead=0,cash=2);data['scenarios'][0]['demand']=[[1]];data['allowed']=[[0]];plan=policy(1);set_action(plan,0,1,1,1);cases.append(('route-assignment',data,plan,'product_assignment'))

for name,data,plan,error in cases:
    folder=ROOT/'cards'/name;folder.mkdir(parents=True)
    dump(folder/'input.json',data);dump(folder/'plan.json',plan)
    actual=inspect_plan(data,plan);dump(folder/'inspection.json',actual)
    old_argv=[sys.executable,'-X','utf8','-B',str(ROOT/'source-before/check_l06.py'),'--input',str(folder/'input.json'),'--plan',str(folder/'plan.json'),'--out',str(folder/'old-cli-result.json')]
    new_argv=[sys.executable,'-X','utf8','-B',str(SRC/'check_l06.py'),'--input',str(folder/'input.json'),'--plan',str(folder/'plan.json'),'--out',str(folder/'new-cli-result.json')]
    old=command(old_argv,folder/'old-command.json');new=command(new_argv,folder/'new-command.json')
    old_value=json.loads((folder/'old-cli-result.json').read_text());new_value=json.loads((folder/'new-cli-result.json').read_text())
    check(name+':real_checker_cli_matches_prior_contract',old.returncode==new.returncode and same(old_value,new_value))
    check(name+':explicit_business_outcome',new.returncode==(0 if error is None else 2) and (new_value['business_feasible'] if error is None else new_value['error']==error))
    if name=='both-stage-peaks':check('both_peaks_collected_and_finance_masked',
        {e['code'] for e in actual['violations']}=={'raw_storage_peak','product_storage_peak'} and actual['expected_cost_exact'] is None and actual['scenarios'] is None)
    if name=='later-order-before-earlier-physical-first-error':check('order_and_both_physical_residuals_retained',
        {e['code'] for e in actual['violations']}=={'shipment_binary','raw_storage_peak','product_storage_peak'} and actual['violations'][0]['where']=='only.week1.S')
    if name=='MOQ0-empty-truck-paid':check('empty_truck_cost3_final_cash0',actual['scenarios']['only']['total_cost_minor']==3 and actual['scenarios']['only']['final_cash_minor']==0)
    if name=='pack-units-not-lot-price':check('three_units_cost6',actual['scenarios']['only']['total_cost_minor']==6)
    if name=='terminal-raw-allowed-with-holding':check('raw1_holding1_total3',actual['scenarios']['only']['weeks'][0]['raw_inventory']==[1] and actual['scenarios']['only']['total_cost_minor']==3)
    if name=='post-horizon-AR-allowed-not-cash':check('post_horizon_AR3_cash0',actual['scenarios']['only']['final_receivable_minor']==3 and actual['scenarios']['only']['final_cash_minor']==0)

snapshot=ROOT/'source-extracted';snapshot.mkdir()
for p in SRC.glob('*.py'):shutil.copyfile(p,snapshot/p.name)
dump(ROOT/'extraction-assessment.json',{'observed_at':datetime.now(timezone.utc).isoformat(),'checks':checks,
    'checker_cli_calls':len(commands),'wall_seconds':time.perf_counter()-began,
    'scope':'one shared tentative recurrence, two old full-plan exact regressions, real CLI/state cards; not full03 tree or online recovery',
    'new_solver_LLM_Docker_calls':0,'full03_qualified':False})
print(json.dumps({'checks':len(checks),'all_passed':all(c['passed'] for c in checks),'checker_cli_calls':len(commands),'wall_seconds':time.perf_counter()-began}))
