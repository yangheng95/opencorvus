from fractions import Fraction
from itertools import product
import json
from pathlib import Path
import shutil
import sys
import time

root=Path(__file__).parent;root.mkdir(parents=True,exist_ok=True)
source=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L06/evaluator/upgrade-v0.3/information_policy.py')
shutil.copyfile(source,root/'information_policy.py');sys.path.insert(0,str(root))
from information_policy import check_information,InformationError

began=time.perf_counter()
ids=['path-c','path-a','path-d','path-b'];demands=[0,2,2,4];signals=['L','L','H','H']
graph={'format':'l06-information-graph/1','weeks':3,'leaves':[{'id':name,'probability':'1/4','observations':['initial',signal,'demand-'+str(d)]} for name,signal,d in zip(ids,signals,demands)]}
rows=[]
for q0,qL,qH in product(range(5),repeat=3):
    actions={name:[[q0],[qL if signal=='L' else qH],[max(0,d-q0-(qL if signal=='L' else qH))]] for name,signal,d in zip(ids,signals,demands)}
    result=check_information(graph,actions)
    assert result['status']=='policy_information_valid'
    cost=sum(Fraction(1,4)*(Fraction(5,4)*path[0][0]+2*path[1][0]+6*path[2][0]) for path in actions.values())
    rows.append((cost,q0,qL,qH,actions))
best=min(rows,key=lambda row:row[:4]);assert best[:4]==(Fraction(9,2),2,0,2)

# Independent backward recursion over each information set, rather than complete-policy enumeration.
value={}
for q0 in range(5):
    conditional=[]
    for ds in [(0,2),(2,4)]:
        conditional.append(min(2*q1+sum(Fraction(1,2)*6*max(0,d-q0-q1) for d in ds) for q1 in range(5)))
    value[q0]=Fraction(5,4)*q0+sum(conditional)/2
assert min(value.values())==Fraction(9,2) and value[2]==Fraction(9,2)
backward=value

relaxed=[]
for orders in product(range(5),repeat=5):
    q0,*q1=orders
    cost=Fraction(5,4)*q0+sum(Fraction(1,4)*(2*q+6*max(0,d-q0-q)) for q,d in zip(q1,demands))
    relaxed.append((cost,orders))
clairvoyant=min(relaxed);assert clairvoyant[0]==Fraction(7,2)
q0,*q1=clairvoyant[1]
bad={name:[[q0],[q],[max(0,d-q0-q)]] for name,q,d in zip(ids,q1,demands)}
wrong=check_information(graph,bad)
assert wrong['status']=='policy_information_invalid' and wrong['error']=='nonanticipativity_violation'
assert wrong['violations']==[{'week':1,'observed_history':['initial','H'],'leaves':['path-d','path-b'],'actions':[[0],[2]]}]
invalid=graph.copy();invalid['weeks']=True
try:check_information(invalid,best[-1])
except InformationError as e:assert e.code=='information_graph_invalid'
else:raise AssertionError('typed graph error contract required')

for name,artifact in [('graph',graph),('causal-policy',best[-1]),('clairvoyant-policy',bad),('clairvoyant-finding',wrong)]:
    (root/(name+'.json')).write_text(json.dumps(artifact,indent=2),encoding='utf-8')
(root/'assessment.json').write_text(json.dumps({'status':'local_multistage_mechanism_qualified','complete_policies':len(rows),'clairvoyant_policies':len(relaxed),
 'causal_optimum':str(best[0]),'independent_backward_optimum':str(min(backward.values())),
 'clairvoyant_optimum':str(clairvoyant[0]),'information_gap':'1','wall_seconds':time.perf_counter()-began,
 'scope':'pre-registered 3-period information mechanism only, not full L06/0.3, freeze, candidate grade or hours'},indent=2),encoding='utf-8')
print((root/'assessment.json').read_text())
