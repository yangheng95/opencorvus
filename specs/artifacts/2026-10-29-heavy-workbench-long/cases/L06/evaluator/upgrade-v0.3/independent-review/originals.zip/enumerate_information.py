"""Independent finite arithmetic and read-only causality primitive checks."""
import copy
from fractions import Fraction as F
import importlib.util
from itertools import product
import json
from pathlib import Path
import shutil
import subprocess
import time

ROOT=Path(__file__).resolve().parent
REPO=Path('D:/myhexin-local/opencorvus')
SOURCE=REPO/'specs/artifacts/2026-10-29-heavy-workbench-long/cases/L06/evaluator/upgrade-v0.3'
ROOT.mkdir(parents=True,exist_ok=True)
SNAP=ROOT/'snapshot';SNAP.mkdir(exist_ok=True)
for n in ['PLAN.md','information_policy.py']:shutil.copy2(SOURCE/n,SNAP/n)
status=subprocess.run(['git','status','--short'],cwd=REPO,capture_output=True,text=True,encoding='utf-8');(ROOT/'git-status-start.txt').write_text(status.stdout+status.stderr,encoding='utf-8')
spec=importlib.util.spec_from_file_location('reviewed_information_primitive',SNAP/'information_policy.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
def save(name,v):(ROOT/name).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
start=time.perf_counter()
leaves=[('L0','L',0),('L2','L',2),('H2','H',2),('H4','H',4)]
graph={'format':'l06-information-graph/1','weeks':3,'leaves':[{'id':sid,'probability':'1/4','observations':['start',signal,str(demand)]}for sid,signal,demand in leaves]}
def policy(q0,q1s):return{sid:[[q0],[q1],[max(0,demand-q0-q1)]]for(sid,_,demand),q1 in zip(leaves,q1s)}
def cost(q0,q1s):return F(5,4)*q0+sum(F(1,4)*(2*q1+6*max(0,demand-q0-q1))for(_,_,demand),q1 in zip(leaves,q1s))
legal=[]
for q0,L,H in product(range(5),repeat=3):
    qs=[L,L,H,H];p=policy(q0,qs);check=module.check_information(graph,p)
    legal.append({'q0':q0,'q1L':L,'q1H':H,'cost':str(cost(q0,qs)),'information_status':check['status']})
best=min(F(r['cost'])for r in legal);legal_best=[r for r in legal if F(r['cost'])==best]
clair=[]
for q0 in range(5):
    for qs in product(range(5),repeat=4):clair.append({'q0':q0,'q1s':list(qs),'cost':str(cost(q0,qs))})
clair_min=min(F(r['cost'])for r in clair);clair_best=[r for r in clair if F(r['cost'])==clair_min]
bad=clair_best[0];bad_policy=policy(bad['q0'],bad['q1s']);bad_result=module.check_information(graph,bad_policy)
legal_policy=policy(2,[0,0,2,2]);legal_result=module.check_information(graph,legal_policy)
checks=[]
def ck(name,ok,detail=None):checks.append({'name':name,'passed':bool(ok),'detail':detail})
ck('exact125legal_policies',len(legal)==125)
ck('all125legal_information_valid',all(r['information_status']=='policy_information_valid'for r in legal))
ck('legal_exact9over2',best==F(9,2),legal_best)
ck('unique_best_q0_2_L0_H2',legal_best==[{'q0':2,'q1L':0,'q1H':2,'cost':'9/2','information_status':'policy_information_valid'}])
ck('all_four_delivery_shortages_filled_by_emergency',all(legal_policy[sid][0][0]+legal_policy[sid][1][0]+legal_policy[sid][2][0]>=d for sid,_,d in leaves))
ck('legal_best_has_zero_emergency',all(legal_policy[sid][2]==[0]for sid,_,_ in leaves))
ck('exact3125_anticipating_q1_policies',len(clair)==3125)
ck('clairvoyant_q1_exact7over2',clair_min==F(7,2),clair_best)
ck('observed_history_catches_t1_H_future_leak',bad_result['status']=='policy_information_invalid'and bad_result['error']=='nonanticipativity_violation'and any(v['week']==1 and v['observed_history']==['start','H']for v in bad_result['violations']),bad_result)
ck('only_root_prefix_check_would_falsely_accept',len({tuple(path[0])for path in bad_policy.values()})==1 and bad_result['status']=='policy_information_invalid')
ck('exact_active_information_cost_one',best-clair_min==1)
ck('all7observed_prefix_nodes_correct',legal_result['information_nodes']==7)
by_q0=[{'q0':q0,'legal_best':str(min(F(r['cost'])for r in legal if r['q0']==q0)),'clair_best':str(min(F(r['cost'])for r in clair if r['q0']==q0))}for q0 in range(5)]
ck('conditional_cost_table_independent_closed_values',[r['legal_best']for r in by_q0]==['6','21/4','9/2','19/4','5']and[r['clair_best']for r in by_q0]==['4','15/4','7/2','17/4','5'],by_q0)
reordered=copy.deepcopy(graph);reordered['leaves'].reverse()
ck('leaf_order_does_not_define_observed_information',module.check_information(reordered,legal_policy)['status']=='policy_information_valid')
recall=copy.deepcopy(graph)
for l in recall['leaves']:l['observations'][2]='same_current_observation'
recall_actions=policy(2,[0,0,2,2])
for sid,signal,_ in leaves:recall_actions[sid][2]=[0 if signal=='L'else 1]
recall_result=module.check_information(recall,recall_actions)
ck('perfect_recall_allows_prior_LH_distinction',recall_result['status']=='policy_information_valid'and recall_result['information_nodes']==5,{'scope':'Generic causality-only graph, not a claim of the micro business policy feasibility.','actual':recall_result})
invalid=copy.deepcopy(graph);invalid['leaves'][0]['probability']='1/5'
try:module.check_information(invalid,legal_policy);code='unexpected_success'
except module.InformationError as e:code=e.code
ck('bad_probability_has_named_contract',code=='information_probability_invalid',code)
invalid_actions=copy.deepcopy(legal_policy);invalid_actions['L0'][0][0]=True
try:module.check_information(graph,invalid_actions);code='unexpected_success'
except module.InformationError as e:code=e.code
ck('bool_action_has_named_contract',code=='information_action_invalid',code)
save('legal125-policies.json',legal);save('clairvoyant3125-policies.json',clair)
save('graph-and-two-witnesses.json',{'graph':graph,'legal_policy':legal_policy,'legal_result':legal_result,'clairvoyant_policy':bad_policy,'clairvoyant_result':bad_result,'q0_minima':by_q0})
save('checks.json',checks)
assessment={'checks':len(checks),'all_passed':all(c['passed']for c in checks),'failed':[c['name']for c in checks if not c['passed']],'legal_policy_count':125,'legal_optimum':str(best),'anticipating_policy_count':3125,'anticipating_optimum':str(clair_min),'information_value_exact':str(best-clair_min),'seconds':time.perf_counter()-start,'source_identity':[{'name':n,'same_current_bytes':(SOURCE/n).read_bytes()==(SNAP/n).read_bytes()}for n in ['PLAN.md','information_policy.py']],'scope':'One finite information-history arithmetic mechanism and generic primitive. Not full L06/0.3 physics/cash/runtime/state/quality/rubric/freeze/hours.','new_solver_Docker_Provider_or_candidate_calls':0}
save('enumeration-assessment.json',assessment);print(json.dumps(assessment,ensure_ascii=False))
