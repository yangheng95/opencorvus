from pathlib import Path
import subprocess,json,shutil,zipfile,datetime,time
R=Path('D:/myhexin-local/opencorvus');ROOT=Path(__file__).resolve().parent
CASE=R/'specs/artifacts/2026-10-29-heavy-workbench-long/cases/L06/evaluator';NEW=CASE/'upgrade-v0.3';CORE=CASE/'qualification/current-source'
source=ROOT/'source';source.mkdir(exist_ok=False)
for name in ('l06_packet.py','l06_input.py','l06_physics.py','check_l06.py','qualify_l06.py','l06_integer.py','l06_plan.py','l06_bound_certificate.py'):shutil.copy2(CORE/name,source/name)
for p in (NEW/'source').glob('*.py'):shutil.copy2(p,source/p.name)
(ROOT/'results').mkdir(exist_ok=False);control=ROOT/'reference-control';control.mkdir(exist_ok=False)
def put(name,x):(control/name).write_text(json.dumps(x,indent=2)+'\n')
def run(argv):
 t=time.perf_counter();p=subprocess.run(argv,capture_output=True,text=True,encoding='utf-8',errors='replace');return {'argv':argv,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'seconds':time.perf_counter()-t}
for folder,name in ((source,'pre-execution-source.zip'),(ROOT/'public','public-originals.zip')):
 with zipfile.ZipFile(control/name,'w',zipfile.ZIP_DEFLATED) as z:
  for p in sorted(folder.rglob('*')):
   if p.is_file():z.write(p,p.relative_to(folder).as_posix())
argv=['docker','create','--name','oc-l06-v03-author-policy-20261031-a','--network','none','--cpus','4','--mount',f'type=bind,source={source},target=/project,readonly','--mount',f'type=bind,source={ROOT/"public"},target=/public,readonly','--mount',f'type=bind,source={ROOT/"results"},target=/results','--workdir','/project','sha256:23ff8bfbf8055caa0b9fa5745ddb27cceea2f31d7d15b7a900c81112cdfe8ddf','/opt/cpsat/bin/python','-u','-B','solve_policy.py','--public','/public','--out','/results/reference','--seconds','120']
r=run(argv);put('create.json',r);assert r['exit_code']==0;cid=r['stdout'].strip();put('active.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cid':cid,'actual_argv':argv,'limit':'one120second author policy search, not a user budget or candidate run'})
put('start.json',run(['docker','start','-a',cid]));i=run(['docker','inspect',cid]);put('inspect.json',i);put('logs.json',run(['docker','logs',cid]));state=json.loads(i['stdout'])[0]['State'];assert state['Running'] is False
with zipfile.ZipFile(control/'completed-originals.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(control.iterdir()):
  if p.is_file() and p.name!='completed-originals.zip':z.write(p,p.name)
 for p in sorted((ROOT/'results').rglob('*')):
  if p.is_file():z.write(p,'results/'+p.relative_to(ROOT/'results').as_posix())
put('cleanup.json',run(['docker','rm',cid]));put('terminal.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'native_exit':state['ExitCode'],'meaning':'one actual source-only full-tree author policy search; no score/freeze/whole case claim'})
print(json.dumps({'native_exit':state['ExitCode'],'result':str(ROOT/'results/reference/result.json')}))
