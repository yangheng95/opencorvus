# Complete delivery contract

Use any equivalent source language and ordinary file layout. Provide a source
map, exact dependencies, a native reproduction command and a programme argv
using assigned input/output placeholders {model}, {raw_archive}, {instance},
{out}. {optimization_seconds}=180 is available when your programme takes a
budget flag; a fixed-profile programme may declare the same allocation in its
source and command without that flag. The programme reads the full assigned input and writes
new outputs; source-only execution supplies no old output vectors or caches.

For each development experiment preserve the full finite variable dictionary,
genuine native objective claim, parameter choices, actual terminal/errors,
feasible incumbent events and bound scope. Preserve failures and dependencies
that did not run. Report actual setup/validation overhead separately.

The numeric output layout declares six semantic slots:

```json
{
  "values": "relative/full-plan.json",
  "reported_objective": {"file":"relative/native-result.json", "key":"actual_objective"},
  "arcs": "relative/arcs.csv",
  "paths": "relative/paths.csv",
  "ledger": "relative/port-period.csv",
  "costs": "relative/costs.csv"
}
```

If the objective file itself is a finite number, declare key:null. All paths are
relative to the actual output directory. JSON value dictionaries contain every
MPS variable; names refer to the supplied mathematical object, not a redefined
model. CSV semantic columns are in outputs.schema.json. Extra columns and any
row order are accepted; all required rows and unique semantic keys are required.
No author file names, directory names or anonymous path IDs are forced.

Deliver every positive original arc/count/cost/service, every port-period
inventory/production/consumption/service/alpha/berth row, a complete economic
decomposition and anonymous source-to-exit path decomposition. These must agree
with the actual vector and full assigned model.

The scientific report explains method design, actual comparable experiments,
mechanisms behind improvement or failure, operating economics, uncertainty and
scope. Include real rendered figures, not promised plots. A single feasible
value without comparison or explanation is less scientific evidence than an
actually controlled mechanism study. A source map and handoff must make each
reported result traceable to actual data and execution.

Declare the programme command in submission.json, for example:

```json
{
  "argv": ["python", "solve.py", "--model", "{model}", "--raw", "{raw_archive}", "--instance", "{instance}", "--out", "{out}", "--optimization-seconds", "{optimization_seconds}"],
  "numeric_layout": "relative/layout.json",
  "report": "relative/REPORT.md",
  "source_map": "relative/source-map.json",
  "reproduce": "relative/HANDOFF.md",
  "dependencies": "relative/requirements-lock.txt",
  "figures": ["relative/actual-figure.png"]
}
```

Your own native dependency environment may replace python when declared. The
command is an argv array, not a shell command. Do not refer to the evaluator,
private reference, other candidate projects or credentials. The human-readable
report and actual images remain original delivered bytes for independent review.
