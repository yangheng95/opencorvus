# L06实质重建研究：原海运库存路径问题

这不是0.5题包、冻结合同或重型资格通过。旧0.4题面/分数只读，新candidate和重复旧测试已停止。

实施前Recall、来源比较、影响面、首轮原实例和真实输出要求在[主记录](../../../../../../records/2026-10/2026-10-29-heavy-workbench-long.md)的“实质重建”节。当前采用MIRPLIB原问题调查路线、库存、泊位、装卸和现货的实际经济质量，不能从文献声称困难就宣称本题已获区分度。

原问题资料来自[MIRPLIB](https://mirplib.scl.gatech.edu/instances)，相关成熟评价依据为[ML4CO组织者论文](https://proceedings.mlr.press/v176/gasse22a/gasse22a.pdf)。第三方数据许可尚未核清，原始下载保外部本地缓存；这里不对原资料改许可证。

当前未完成完整新题、公平可达的质量评价、完整参考/错误programme/实际图/一次整审及fresh实测，不能计作完成题数或有效小时。
