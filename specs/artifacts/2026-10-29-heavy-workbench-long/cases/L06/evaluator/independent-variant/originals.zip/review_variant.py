"""Independent cheap single-price reference review: standard library, no optimizer."""
from datetime import datetime,timezone
from fractions import Fraction
import copy,csv,importlib.util,json
from pathlib import Path
import shutil,subprocess,sys,time,zipfile
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
REPO=Path('D:/myhexin-local/opencorvus')
CASE=REPO/'specs/artifacts/2026-10-29-heavy-workbench-long/cases/L06'
REL='evaluator/qualification/v2/integer-search/quality-reference/registered-reference.json'
PYTHON='C:/Python314/python.exe'

def save(path,value):
    path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(value,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
def load(path):return json.loads(path.read_text(encoding='utf-8'))
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def diffs(a,b,path=''):
    if type(a) is not type(b):return [{'path':path,'old':a,'new':b}]
    if isinstance(a,dict):return sum((diffs(a[k],b[k],path+'/'+k) for k in a.keys()|b.keys()),[])
    if isinstance(a,list):return sum((diffs(x,y,path+'/'+str(i)) for i,(x,y) in enumerate(zip(a,b))),[]) if len(a)==len(b) else [{'path':path,'old':a,'new':b}]
    return [] if a==b else [{'path':path,'old':a,'new':b}]
def fixture(path,value):save(path,value);return path

def main():
    start=time.perf_counter();snap=ROOT/'source-initial';tools=ROOT/'reviewer-tools';case=ROOT/'case-initial';refdir=(case/REL).parent
    if '--resume-prepared' not in sys.argv:
        snap.mkdir(exist_ok=False)
        for name in ('l06_numeric.py','qualify_numeric.py','check_l06.py','l06_input.py','l06_delivery.py','l06_packet.py'):shutil.copy2(CASE/'evaluator/qualification/current-source'/name,snap/name)
        tools.mkdir();prior=Path('D:/opencorvus-benchmark-runs/l06-reference-independent-review-20261029/full-cold-replay/audit-tools')
        for name in ('independent_math.py','independent_projection.py'):shutil.copy2(prior/name,tools/name)
        (case/'public').mkdir(parents=True);shutil.copytree(CASE/'public/inputs',case/'public/inputs');shutil.copy2(CASE/'rubric.draft.json',case/'rubric.draft.json')
        refdir.mkdir(parents=True)
        for name in ('registered-reference.json','originals.zip','price-control.zip'):shutil.copy2((CASE/REL).parent/name,refdir/name)
        record=REPO/'specs/records/2026-10/2026-10-29-heavy-workbench-l06-qualification.md';shutil.copy2(record,ROOT/'Recall-source.md')
        (ROOT/'Recall.md').write_text('''# Recall\n\n本轮仅标准库廉价复核L06固定C/R0采购单价45→46变体、原唯一L47380的单调证明和numeric reader。只写本目录，不改repo；无solver/Docker/Provider/GPU/UI/用户进程/再委托。完整源冷复建已经完成，不重跑。保留初源和实际失败，17叶聚合另行审查；不批准重型冻结/小时/候选成绩。\n''',encoding='utf-8')
        git=subprocess.run(['git','status','--short'],cwd=REPO,capture_output=True,text=True,encoding='utf-8');(ROOT/'git-status-start.txt').write_text(git.stdout,encoding='utf-8')
    independent=module('reviewer_math_variant',tools/'independent_math.py').independent
    project=module('reviewer_raw_variant',tools/'independent_projection.py').independent_projection
    ref=load(refdir/'registered-reference.json');assert ref['lower_bound_minor']=={'numerator':47380,'denominator':1}
    base,counts=project(case/'public/inputs')
    with zipfile.ZipFile(refdir/'originals.zip') as z:captured=json.loads(z.read('input/full.json'))
    captured={k:v for k,v in captured.items() if k not in ('status','qualification_variant')}
    assert base==captured
    with zipfile.ZipFile(refdir/'price-control.zip') as z:
        members=z.namelist();variant=json.loads(z.read('normalized.json'));plan=json.loads(z.read('plan.json'))
        archived_business=json.loads(z.read('business.json'));proof=json.loads(z.read('monotone-proof.json'))
    save(ROOT/'archive-inventory.json',{'members':members,'proof':proof})
    variant={k:v for k,v in variant.items() if k not in ('status','qualification_variant')}
    differences=diffs(base,variant);assert differences==[{'path':'/suppliers/2/price_minor/0','old':45,'new':46}],differences
    raw=ROOT/'variant-input';shutil.copytree(case/'public/inputs',raw,dirs_exist_ok='--resume-prepared' in sys.argv);p=raw/'supplier_quotes.csv'
    with p.open(newline='',encoding='utf-8') as f:r=csv.DictReader(f);header=r.fieldnames;rows=list(r)
    changed=[]
    for row in rows:
        if row['supplier_id']=='C' and row['raw_id']=='R0':changed.append(copy.deepcopy(row));row['unit_price_minor']='46'
    assert len(changed)==1 and changed[0]['unit_price_minor']=='45'
    with p.open('w',newline='',encoding='utf-8') as f:w=csv.DictWriter(f,fieldnames=header);w.writeheader();w.writerows(rows)
    actual,_=project(raw);assert actual==variant
    before=independent(base,plan);after=independent(variant,plan)
    assert before['business_feasible'] and after['business_feasible']
    assert before['cost']==Fraction(238731,5) and after['cost']==Fraction(238818,5)
    # The cost increment is delta_price times actual purchased pieces; every
    # prefix cash delta equals the negative of cumulative purchased pieces.
    prefix=[];expected_increment=Fraction()
    for s in base['scenarios']:
        sid=s['id'];pieces=0
        for t in range(base['weeks']):
            pieces+=plan['decisions'][sid]['order_lots'][t][2][0]*base['suppliers'][2]['pack_units'][0]
            old=before['ledger']['scenarios'][sid]['weeks'][t];new=after['ledger']['scenarios'][sid]['weeks'][t]
            ok=new['cash']==old['cash']-pieces and all(new[k]==old[k] for k in ('raw_inventory','finished_inventory','arrivals','made','consumption','receipts','receivable'))
            prefix.append({'scenario':sid,'week':t,'cumulative_C_R0_pieces':pieces,'cash_old':old['cash'],'cash_new':new['cash'],'passed':ok})
        expected_increment+=Fraction(s['probability_numerator'],base['probability_denominator'])*pieces
    assert all(r['passed'] for r in prefix) and expected_increment==after['cost']-before['cost']==Fraction(87,5)
    assert min(s['minimum_cash_minor'] for s in after['summary']['scenarios'].values())==-5369
    assert archived_business['expected_cost_exact']=={'numerator':238818,'denominator':5}
    for s in base['scenarios']:
        for original,recomputed in zip(archived_business['scenarios'][s['id']]['weeks'],after['ledger']['scenarios'][s['id']]['weeks']):
            assert all(recomputed[key]==value for key,value in original.items())
    save(ROOT/'independent-monotone-check.json',{'one_fact_difference':differences,'base_matches_original_capture':True,'raw_projection_matches_archived_variant':True,'cost_old':str(before['cost']),'cost_new':str(after['cost']),'increment_exact':str(expected_increment),'fixed_L':47380,'relative_gap_exact':str((after['cost']-47380)/47380),'mincash':-5369,'prefix_checks':prefix,'all48_passed':all(r['passed'] for r in prefix),'proof_scope':'Positive price only; nonnegative purchases imply new cost>=old and new cash<=old for every fixed control plan, hence Fnew subset Fold. Existing trusted-native L remains a lower bound, not a rational dual proof.'})
    fix=ROOT/'fixtures';fix.mkdir()
    defaults={'case-root':case,'input':raw,'normalized':fixture(fix/'new-normalized.json',variant),'plan':fixture(fix/'plan.json',plan),'summary':fixture(fix/'new-summary.json',after['summary']),'ledger':fixture(fix/'new-ledger.json',after['ledger'])}
    rows=[]
    def run(label,expect_code=0,expect_error=None,expected=None,**changes):
        folder=ROOT/'executions'/label;folder.mkdir(parents=True,exist_ok=False);args=defaults|changes
        argv=[PYTHON,'-X','utf8','-B',str(snap/'l06_numeric.py')]
        for key,path in args.items():argv+=['--'+key,str(path)]
        argv+=['--out',str(folder/'result.json')]
        stamp=datetime.now(timezone.utc).isoformat();t=time.perf_counter();p=subprocess.run(argv,capture_output=True,text=True,encoding='utf-8')
        (folder/'stdout.txt').write_text(p.stdout,encoding='utf-8');(folder/'stderr.txt').write_text(p.stderr,encoding='utf-8')
        result=load(folder/'result.json') if (folder/'result.json').is_file() else None
        ok=p.returncode==expect_code and result is not None
        if ok and expect_error:ok=result['status']=='run_invalid' and result['infrastructure_error']['code']==expect_error and result['findings']==[]
        if ok and not expect_error:
            statuses={r['id']:r['status'] for r in result['findings']}
            ok=result['total_score'] is None and result['counts']['unassessed']==17 and all(statuses[i]==s for i,s in (expected or {}).items())
        receipt={'label':label,'argv':argv,'started_utc':stamp,'seconds':time.perf_counter()-t,'exit_code':p.returncode,'expected_exit_code':expect_code,'expected_error':expect_error,'expected_statuses':expected,'contract_passed':ok,'result_exists':result is not None}
        save(folder/'command.json',receipt);rows.append(receipt);save(ROOT/'receipt.progress.json',rows)
        return result
    all30={r:'verified_pass' for r in [*['A01','A02','A03','A04'],'C06']}
    result=run('registered-price-actual',expected=all30);assert result['counts']['verified_pass']==30
    baseargs={'input':case/'public/inputs','normalized':fixture(fix/'base-normalized.json',base),'ledger':fixture(fix/'base-ledger.json',before['ledger']),'summary':fixture(fix/'base-summary.json',before['summary'])}
    result=run('base-v2-current-reference',expected=all30,**baseargs);assert result['counts']['verified_pass']==30
    reordered=ROOT/'reordered-variant-input';shutil.copytree(raw,reordered)
    for p in reordered.glob('*.csv'):
        with p.open(newline='',encoding='utf-8') as f:r=csv.reader(f);head=next(r);values=list(r)
        with p.open('w',newline='',encoding='utf-8') as f:w=csv.writer(f);w.writerow(head);w.writerows(reversed(values))
    result=run('variant-real-row-reorder',expected=all30,input=reordered);assert result['counts']['verified_pass']==30
    run('stale-normalized',expect_code=2,expected={'A02':'verified_fail','C06':'verified_pass'},normalized=baseargs['normalized'])
    run('stale-cost-and-cash',expect_code=2,expected={'A02':'verified_pass','C01':'verified_fail','C07':'verified_fail','C09':'verified_fail','D05':'verified_fail','D06':'verified_fail','C06':'verified_pass'},ledger=baseargs['ledger'],summary=baseargs['summary'])
    run('all-stale-deliverables',expect_code=2,expected={'A02':'verified_fail','C01':'verified_fail','D05':'verified_fail','D06':'verified_fail','C06':'verified_pass'},normalized=baseargs['normalized'],ledger=baseargs['ledger'],summary=baseargs['summary'])
    unknown=ROOT/'unregistered-price-input';shutil.copytree(raw,unknown);p=unknown/'supplier_quotes.csv'
    with p.open(newline='',encoding='utf-8') as f:r=csv.DictReader(f);header=r.fieldnames;values=list(r)
    for row in values:
        if row['supplier_id']=='C' and row['raw_id']=='R0':row['unit_price_minor']='47'
    with p.open('w',newline='',encoding='utf-8') as f:w=csv.DictWriter(f,fieldnames=header);w.writeheader();w.writerows(values)
    run('unknown-price-47',expect_code=3,expect_error='reference_input_unregistered',input=unknown)
    def registration_case(label,mutation):
        c=ROOT/'mutated-case'/label;shutil.copytree(case,c);r=load(c/REL);mutation(r);save(c/REL,r);return c
    c=registration_case('delta-zero',lambda r:r['derived_variants'][0]['transformation'].__setitem__('delta_minor',0));run('invalid-delta-zero',expect_code=3,expect_error='reference_config_invalid',**{'case-root':c})
    c=registration_case('delta-bool',lambda r:r['derived_variants'][0]['transformation'].__setitem__('delta_minor',True));run('invalid-delta-bool',expect_code=3,expect_error='reference_config_invalid',**{'case-root':c})
    c=registration_case('unknown-supplier',lambda r:r['derived_variants'][0]['transformation'].__setitem__('supplier_id','unknown'));run('registration-unknown-supplier',expect_code=3,expect_error='reference_config_invalid',**{'case-root':c})
    c=registration_case('capture-drift',lambda r:None)
    archive=(c/REL).parent/'price-control.zip'
    with zipfile.ZipFile(archive) as z:members={n:z.read(n) for n in z.namelist()}
    drift=copy.deepcopy(variant);drift['suppliers'][2]['price_minor'][0]+=1;members['normalized.json']=(json.dumps(drift)+'\n').encode('utf-8')
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
        for n,payload in members.items():z.writestr(n,payload)
    run('registered-transform-capture-drift',expect_code=3,expect_error='reference_variant_drift',**{'case-root':c})
    c=registration_case('base-id-empty',lambda r:r.__setitem__('reference_id',''))
    run('registration-empty-base-id',expect_code=3,expect_error='reference_config_invalid',**({'case-root':c}|baseargs))
    save(ROOT/'stage-assessment-initial.json',{'status':'passed' if all(r['contract_passed'] for r in rows) else 'has_contract_failures','actual_cli_commands':len(rows),'passed':sum(r['contract_passed'] for r in rows),'failures':[r['label'] for r in rows if not r['contract_passed']],'seconds':time.perf_counter()-start,'source_snapshot':'source-initial','fixed_L':47380,'variant_cost_exact':str(after['cost']),'solver_runs':0,'Docker_runs':0,'Provider_calls':0,'GPU_work':False,'delegations':0,'full_case_freeze_approved':False,'candidate_score':None})
    print(json.dumps(load(ROOT/'stage-assessment-initial.json'),ensure_ascii=False,indent=2))

if __name__=='__main__':main()
