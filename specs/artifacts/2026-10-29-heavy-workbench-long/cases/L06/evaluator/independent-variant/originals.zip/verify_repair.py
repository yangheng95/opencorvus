"""Replay only the fixed identity contracts and normal price path; no optimizer."""
from datetime import datetime,timezone
from fractions import Fraction
import copy,json
from pathlib import Path
import shutil,subprocess,sys,time,zipfile
sys.dont_write_bytecode=True
from review_variant import ROOT,REPO,CASE,REL,PYTHON,save,load

def main():
    source=ROOT/'source-repaired';source.mkdir(exist_ok=False)
    names=('l06_numeric.py','qualify_numeric.py','check_l06.py','l06_input.py','l06_delivery.py','l06_packet.py')
    for name in names:shutil.copy2(CASE/'evaluator/qualification/current-source'/name,source/name)
    original=load(ROOT/'executions/registered-price-actual/command.json')['argv']
    # Python arguments are [python,-X,utf8,-B,script,...]; derive from flag names.
    original_args={original[i]:original[i+1] for i in range(5,len(original)-2,2)}
    executions=[]
    def run(label,case,code,error=None,base=False):
        folder=ROOT/'repair-executions'/label;folder.mkdir(parents=True,exist_ok=False);args=dict(original_args);args['--case-root']=str(case)
        if base:
            args.update({'--input':str(ROOT/'case-initial/public/inputs'),'--normalized':str(ROOT/'fixtures/base-normalized.json'),'--summary':str(ROOT/'fixtures/base-summary.json'),'--ledger':str(ROOT/'fixtures/base-ledger.json')})
        argv=[PYTHON,'-X','utf8','-B',str(source/'l06_numeric.py')]
        for key,value in args.items():argv += [key,value]
        argv += ['--out',str(folder/'result.json')]
        stamp=datetime.now(timezone.utc).isoformat();t=time.perf_counter();p=subprocess.run(argv,capture_output=True,text=True,encoding='utf-8')
        (folder/'stdout.txt').write_text(p.stdout,encoding='utf-8');(folder/'stderr.txt').write_text(p.stderr,encoding='utf-8')
        result=load(folder/'result.json') if (folder/'result.json').exists() else None
        passed=p.returncode==code and result is not None
        if passed and error:passed=result['status']=='run_invalid' and result['infrastructure_error']['code']==error and result['findings']==[] and result['total_score'] is None
        elif passed:passed=result['counts']['verified_pass']==30 and result['counts']['unassessed']==17 and result['total_score'] is None
        receipt={'label':label,'argv':argv,'started_utc':stamp,'seconds':time.perf_counter()-t,'exit_code':p.returncode,'expected_exit_code':code,'expected_error':error,'passed':passed};save(folder/'command.json',receipt);executions.append(receipt)
    run('normal-price-control',ROOT/'case-initial',0)
    run('same-empty-base-id',ROOT/'mutated-case/base-id-empty',3,'reference_config_invalid',base=True)
    def changed(label,mutate):
        case=ROOT/'repair-cases'/label;shutil.copytree(ROOT/'case-initial',case);r=load(case/REL);mutate(r);save(case/REL,r);return case
    run('invalid-bound-kind-type',changed('bad-kind',lambda r:r['bound_source'].__setitem__('kind',[])),3,'reference_config_invalid')
    run('whitespace-base-id',changed('whitespace-base-id',lambda r:r.__setitem__('reference_id',' \t')),3,'reference_config_invalid',base=True)
    run('whitespace-derived-id',changed('whitespace-derived-id',lambda r:r['derived_variants'][0].__setitem__('reference_id',' \t')),3,'reference_config_invalid')
    proof=load(ROOT/'independent-monotone-check.json')
    archive=ROOT/'case-initial'/Path(REL).parent/'price-control.zip'
    with zipfile.ZipFile(archive) as z:b=json.loads(z.read('business.json'))
    sizes={sid:len(s['weeks']) for sid,s in b['scenarios'].items()};assert all(v==16 for v in sizes.values()) and len(sizes)==3
    save(ROOT/'archive-row-counts.json',{'scenarios':sizes,'checked_business_rows':sum(sizes.values()),'matches_independent48_prefixes':sum(sizes.values())==len(proof['prefix_checks'])})
    save(ROOT/'repair-receipt.json',{'all_passed':all(r['passed'] for r in executions),'commands':len(executions),'executions':executions})
    result={'result':'single_monotone_price_reference_and_reader_qualified' if all(r['passed'] for r in executions) else 'repair_has_failures','initial_cli':{'commands':12,'passed_expected_contract':11,'actual_P2':'empty base reference_id accepted; initial source/output preserved'},'repaired_cli':{'commands':len(executions),'passed':sum(r['passed'] for r in executions)},'independent_fact_differences':1,'independent_prefix_checks':48,'variant_cost_exact':'238818/5','fixed_lower_bound':47380,'relative_gap_exact':proof['relative_gap_exact'],'relative_gap_percent':float(Fraction(proof['relative_gap_exact'])*100),'reuses_identical_business_controls':True,'mincash':-5369,'formal_candidate_grade':None,'full_case_freeze':False,'hours_claim':False,'solver_runs':0,'Docker_runs':0,'Provider_calls':0,'GPU_work':False,'delegations':0}
    save(ROOT/'stage-assessment.json',result)
    (ROOT/'tooling-note.md').write_text('First reviewer script stopped before any numeric CLI because it compared a business-row schema directly with richer ledger rows (ledger additionally has controls and AR). Intersection values were identical. Reviewer fixed this projection comparison and resumed the already frozen source/input snapshot; this was reviewer tooling, not a business/numeric failure. The first real product defect was the separately preserved empty-reference-ID CLI.\n',encoding='utf-8')
    (ROOT/'REVIEW.md').write_text(f'''# L06 单一变价参考独立审查\n\n结论：仅认可C/R0单价45→46的精确单调变体参考与本轮修后reader。基例唯一L47380保持；没有新solver、Docker、Provider、GPU或委托。此结论不是候选评分/整题冻结/小时级验证。\n\n## 原材料与数学\n\n独立从11CSV+facility投影的基例与原注册ZIP输入相同；变体只有`suppliers[2].price_minor[0]`从45变46，联合身份C/R0，其他全部事实相同。自己按CSV联合身份生成变价raw，投影等于price-control.zip捕获。\n\n对任一合法非负采购动作，累计额外成本恰为已下单C/R0件数乘1。物理/信息/交付/终期约束相同，销售回款不变，因此任一周新现金不高于旧现金。新业务可行集是原可行集子集，且新目标不小于旧目标，故原trusted-native L仍有效；不把这个推导称作新的精确整数最优或有理dual/search证明。该论证只覆盖此正向单价变化，不授权任意报价/容量变化。\n\n现成同一完整控制计划旧C=238731/5=47746.2，新C=238818/5=47763.6，增量87/5=17.4；三场景最后累计受影响件数15/21/18。48个周前缀逐项核对现金差与不变的物理库存/到货/耗料/回款/应收，全部通过；原business48行也逐字段一致。最低现金仍−5369。固定L的gap=959/118450≈{result['relative_gap_percent']:.10f}%，因此有达标可行见证，允许动作不变。\n\n## 真实CLI及实际缺陷\n\n初源`source-initial/`与初次12条命令/原始输出`executions/`保留：正常基例、注册变价、真实反转行序均30pass/17unassessed；旧normalized指向A02错误；旧费用/现金账指向C01/C07/C09/D05/D06错误，C06仍按真实新动作独立计算。未知47报价、delta0/bool、未知供应商、捕获变换漂移均具名run_invalid，没有候选分。\n\n第12条实际发现P2：base reference_id空字符串仍exit0并C06pass，身份元数据不合法却被接纳。它不否定当前正确L或单调证明。修后`source-repaired/`统一要求基例ID、derived ID与bound_source.kind为strip后非空字符串；原空ID、kind坏类型、两类空白ID与正常变价共5条必要CLI全部按预期（正常30pass/17unassessed，其余reference_config_invalid/run_invalid、无总分）。原反例未覆盖。\n\n## 边界与证据\n\n精确命令/exit/stdout/stderr在executions/、repair-executions/及review-execution.json；输入/注册/两个原始ZIP在case-initial/，独立数学在independent-monotone-check.json，48原行数在archive-row-counts.json，源码与审查脚本均保留。source-initial对应修前，source-repaired对应修后，不以当前漂移源码替换历史。\n\n此处证明了一个有公开类别的私有数值控制能可靠评价与反缓存；未运行候选源码实际变价完整重建，不能据此自动给D02满分。17叶聚合器、真实多质量审查、专业匿名校准、最终冻结和十题小时级资格仍另行未完成。\n''',encoding='utf-8')
    p=subprocess.run(['git','status','--short'],cwd=REPO,capture_output=True,text=True,encoding='utf-8');(ROOT/'git-status-end.txt').write_text(p.stdout,encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
