from pathlib import Path
import os,json,shutil,zipfile,datetime
R=Path('D:/myhexin-local/opencorvus'); C=R/'specs/artifacts/2026-10-29-heavy-workbench-long/cases/L06/evaluator/upgrade-v0.4'
O=Path('D:/opencorvus-benchmark-runs/l06-v04-full-case-20261031'); P=Path('D:/opencorvus-benchmark-runs/l06-v04-whole-case-independent-review-20261031'); D=C/'whole-case-tests'
def copy(src,dst):
 if src.is_dir():shutil.copytree(src,dst,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__'))
 else:dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
def write(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
D.mkdir(exist_ok=True)
copy(O/'reference-delivery-final',D/'reference')
copy(O/'weak-delivery/REPORT.md',D/'weak-report/REPORT.md')
copy(O/'wrong-iid/delivery/REPORT.md',D/'wrong-model/REPORT.md')
copy(O/'wrong-iid/delivery/quality-gap.png',D/'wrong-model/quality-gap.png') if (O/'wrong-iid/delivery/quality-gap.png').is_file() else None
# Assessment records are readable; the original immutable closed copies remain fully retained externally.
for name in ['assessment-main','assessment-weak','assessment-iid','assessment-early-inspection-initial']:
 for p in (O/name).iterdir():
  if p.is_file():copy(p,D/'assessments'/name/p.name)
for name in ['native-first-command.json','logical-export-command.json','report-command.json','weak-report-command.json','weak-prepare-command.json','overlap-guard-command.json','bellman-certificate.json']:
 copy(O/name,D/'commands'/name)
for p in (O/'concentrated-fix-checks').glob('*.json'):copy(p,D/'concentrated-fix-checks'/p.name)
for p in P.iterdir():
 if p.is_file() and p.suffix in ['.json','.md','.py']:copy(p,D/'independent-review'/p.name)
for name in ['main','weak']:
 for file in ['actual-grade-command.json','final-grade.json']:
  p=O/f'assessment-{name}'/file
  if p.exists():copy(p,D/'assessments'/f'assessment-{name}'/file)
# Include all unique native/source/failure/proof objects, retaining every omission with its actual reason.
# Never descend into the known first failed self-copy recursion trees.
manifest=[];omitted=[];archive=D/'originals.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for label,root in [('author',O),('independent-review',P)]:
  for dirpath,dirs,files in os.walk(root):
   current=Path(dirpath);rel=current.relative_to(root)
   for name in list(dirs):
    sub=current/name;parts=sub.relative_to(root).parts;reason=None
    if name=='__pycache__':reason='derived Python bytecode; original source retained'
    elif label=='author' and parts[:1]==('report-environment',) and name in ['venv','pip-cache','mpl-config']:reason='third-party runtime/download/font cache; exact installed lock/preparation retained; full external environment retained'
    elif label=='author' and len(parts)==3 and parts[0]=='wrong-programmes' and parts[2]=='assessment':reason='original failed recursive self-copy temporary tree; original errors/source/run retained here and complete partial tree retained externally; never traversed'
    elif name=='closed':reason='duplicate immutable assignment closed inputs; all original run and delivery bytes retained elsewhere in this archive; exact external closed copy retained'
    elif label=='independent-review' and parts[0] in ['cache','matplotlib-cache','sql-read-copies','temp']:reason='independent derived cache/read-only SQL scratch; original native SQL and independent audit retained; external scratch retained'
    if reason:dirs.remove(name);omitted.append({'root':label,'path':sub.relative_to(root).as_posix(),'reason':reason})
   for name in files:
    p=current/name;member=label+'/'+p.relative_to(root).as_posix();z.write(p,member);manifest.append({'path':member,'bytes':p.stat().st_size})
write(D/'archive.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'roots':{'author':str(O),'independent-review':str(P)},'members':len(manifest),'bytes':archive.stat().st_size,'member_manifest':manifest,'excluded_external_retained':omitted,'scope':'complete unique first scientific/native/source/correct and actual wrong programmes/failed tool/review evidence; duplicates, partial recursive temporary tree and third-party cache explicitly external; not candidate/effective-hour evidence'})
print(json.dumps({'members':len(manifest),'bytes':archive.stat().st_size,'omitted_directories':len(omitted),'readable_reference':str(D/'reference')}))
