from pathlib import Path
import json
from fractions import Fraction as F
import matplotlib;matplotlib.use("Agg")
import matplotlib.pyplot as plt
root=Path(__file__).resolve().parents[1]
v=json.loads((root/"data/quality-comparison.json").read_text(encoding="utf-8"));x=list(range(len(v)));f,a=plt.subplots(figsize=(11,5));a.bar(x,[float(F(q["actual_cost"])) for q in v],label="Actual wrong-IID-class policy");a.scatter(x,[float(F(q["true_same_information_optimum"])*F(101,100)) for q in v],color="red",marker="x",s=100,label="Registered1% ceiling");a.set_xticks(x,[q["input"] for q in v]);a.set_ylabel("Expected expense (synthetic minor units)");a.set_title("Physical and posterior validity do not repair a wrong planning law");a.legend();f.tight_layout();f.savefig(root/"figures/quality-gap.png",dpi=150)
