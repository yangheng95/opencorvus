# L06/0.4完整主动验货业务：实施前Recall与合同

## Recall和影响面

用户要求原生Windows完成完整十题/真实整题测试；禁止Docker/WSL/UI自动化、重复组件资格/旧矩阵/故意耗时。0.3的fresh Codex与新OC已同冻结真正各100/allcritical，原结果在dcf447652及两个pilot，故另升0.4；不是改旧60044或重旧solver。L01原GPU矩阵继续且源不热改。此处只新增一个完整case，旧版本/生产Task/Mission/Session/LLM路由/用户数据与UI均不改；无现存用户DB迁移问题，新题是新独立实验数据，旧真实数据库原件只读。

已读当前AGENTS、最新长程Recall、0.3完整public/业务/runner/checker及两pilot。全仓当前L06只有固定公开联合树：信息到达不受行动影响，完整因果政策可以直接用共享前缀整数模型表达。两个新系统均自然通过是原题缺少区分度的真实证据，不是其程序错误。0.4新增内在问题为：购买/保留/选择验货决定何时观察哪家供应商，观测改变后验与后续采购，同时已付成本、物料、实验室峰值和已收现金必须逐原承诺保留。不能给actor所选未来，不能从有限随机观测推断不可识别的供应商别名。

## 首次完整实验前登记的业务与科学底线

完整8周、每周实验室和运营两阶段。两供应商每包2件；正常订单下周到，一周最多订一包，每供应商最多保留一包未验货料，验货前有空仓才可抽该包。每周最多验一包，结果要么2件合格、要么0件；包在验后消耗，不可把期望产量当已收库存。已知好料容量4，验后/消耗前峰值也受限；当周生产必须完整满足公开需求，生产每件成本1，销售每件12，销售款两周后到。紧急认证原料即到，每周价格公开可变；可依法提前储备，但持有每件每周1。正常采购价格A3/B4，验货费用1。周末好料持有，末周好料及未验包按每件/包1自动结清，未到订单不得越过终期。正常期不能任意销毁保留好料/未验货包、改旧订单或借用未来应收款。

信用：base初始现金18，期初旧业务应收10在周1结算；每个阶段真实已收现金不得低于−15，最后现金必须非负。应收周8/9按绝对到期日列示，不提前收；末期合格料及未验货包清零。需求和认证价格由原CSV给出。另两个完整公开输入只改变先验/期初融资，非任意扰动认证；每个均须完整可行、相同科学底线。行序控制不改变ID语义。

四个潜在标签，A1/A2有完全相同的全部供应商结果律，B1/B2同理。A类验A合格概率17/20、验B3/20，B类相反；条件于类，各批结果独立。base标签先验1/8、3/8、3/8、1/8，故同类标签比率不能由任何自适应试验改变；只可识别分布类，不能索要未知标签或未来单批结果。后验必须从全部实际验货观测及真实选择更新；未验货/延迟验货不是失败/成功样本。此完整来源律是定义，不从作者未来结果倒填。

正式质量预登记：每个完整输入的合法策略期望经营成本≤1.01×同信息最优值；逐正概率路径物理/现金/原承诺/后验/原键恢复均critical，不能用期望值或方法分补。恰当声明不可识别性也是critical。最优值必须依据同信息精确有限动态规划或独立可证界，不拿偷看真实类/未来结果作可执行目标。另报“预先知道分布类但不知道未来批结果”的精确下界，明确其信息价值；禁把禁止验货同时失去实物的成本差叫纯信息价值。不预设动作必须翻转，也不匹配非凸轨迹或唯一最优policy。

## 直接整题建设与一次便宜完整实验

首次计算直接使用上述完整8周base原料/4标签/全部正概率验货分支，非三期toy、组件资格或旧solver；先封全部public、源和登记。用缓存的有限状态Bellman递推和Fraction精确算术，状态包括周/阶段、真实库存/未验包/现金及完整观测对应的后验；必须给出压缩状态充分性和风险可达理由。根据后验与原物料/现金在所有结果上可行才接受动作，不用期望现金筛掉坏路径。先记录实际时间/状态/最优值与信息松弛，不设最低时长、不把参考运行/队列/评估算候选小时；若工具失败保存原件并修真实根因，不能改质量线凑通过。优先本机CPU/stdlib，不与L01新开GPU。

随后直接完成同case公开唯一exercise、任意语言stdio actor/全部可见原prefix、持久SQLite原键receipt、真正订单commit失ACK和验货result commit失ACK两中断后续、完整原账/逐观测后验/概率/成本/现金/AR、实际图、报告/自含重建、同checker实际错误programme、原子rubric与真实grade。所有源首次执行前封；所选未来只在parent stdin/内存，原SQLite只含已观察事实，不授同用户OS侧信道/掉电/任意并发安全认证。验货receipt必须保原结果，不能在恢复时重抽。事件切换/两个阶段不属于产品工作流/LLM工具路由，不新增通用框架。

只有完整产品/全部真实正错/图/原子评分齐后才复用唯一benchmark_review一次集中整题独审，实质阻断集中修、仅必要复验；不做组件review。开发freeze/fresh真实比较/有效小时尚未完成，不因此称第十题或难度成熟。新candidate仍仅公开材料/依赖、fork none/nooverride，不给私有评价/参照/旧答案；自然交付先封所有workspace/Git/untracked/失败，再同冻结实际执行/内容独评/真正grade。两个good仍需另版，快而正确始终允许。

## 完整首次科学与原生链后的证书核验登记

三个原8周输入的首次Fraction Bellman均自然0（各约.7–.8秒），base300834939/4000000、shifted90125954529/1280000000、cash-tight11287373277/128000000；提前知道分布类的差值各严格正。原planner/源与输入在首次计算前封，不改原输出或1%目标。真实完整actor三输入/全部自身政策分支/两commit中断与行序控制随后一次native0/90.9964303秒；这是完整新case，不拿秒数/分支数当难度或小时。

必须闭合的科学证据是同信息“最优”而非仅可行。原planner已保存每个可行状态的实际最优action，现只对这份原policy做一次完整Bellman证书核：通过唯一public物理primitive枚举所有合法动作/两正概率结果，验证原选择等于局部最小、遗漏状态确不可行，用有限时域归纳闭合根界；不import/重跑Planner、不生成另一policy、不重actor/native/旧solver/组件资格。此核验若失败保原错误和数据，不能把可行root值当最优或倒填阈值。独立整审之后只读本完整证据，不做阶段review。

## 首次账和图后补齐稳定历史身份（不改数值/政策）

首report真实0/3152stage行与三原生期望值相同、3图已生成。设计完整私有checker时确认episode随机目录只为不泄漏未来，不能用它要求候选的原账匹配另一次私有随机目录（公共合同也未限定episodeID）。直接根因是新auditor导出AR以episode作键，未来M05若照此绑定会误拒同一个真实策略；尚未跑该错误checker/无候选失败，不假报观测反例。原源/CSV/summary/实际图先完整封pre-logical-path-export.zip。当前唯一导出改用完整实际付费验货历史的可读逻辑path（周/供应商/观察），instance+path+seq定位；保episode作为原件坐标但不当跨执行身份。确定性策略下同一付费观测史唯一决定全过程；全部正概率支持仍用原完整账/原似然核，不能hash替功能。只派生新导出/AR定位并证明其余原字段与图逐值同一，不重actor/native/优化/旧矩阵。源/public在开发冻结前明确此合同，不留自动旧格式fallback。独立整审的一次自含新源完整重建将天然换episode目录，实际同时验证该身份合同。

## 完整同checker错误programme登记

原正确reference的全部native/数学/导出已齐，不重这些对象。四个真实独立actor programme各只把声明argv加一个具名故障（原源/三计划不改）：prior-belief忽略已观察验货、expected-stock在reject后把一件期望料当实物、ar-credit用未来应收提前买满4件、random-key在新进程重放换随机key。预期分别产生精确后验/实际需求/已收现金/原键重放的具名错误；从各原实际wire/SQLite核，不从故障命名判断，未执行的依赖blocked/总分null。每个先封源码再通过同一public真实exercise与同一private prepare，不额外组件资格或重正确矩阵。另一真实report.py --claim false-certainty只在正确原native数据上生成完整数字/图正确但断言有限观测精确识别别名及现实无限保证的弱报告；同checker全部M和一次整题独审5H判断，不能由作者手写aggregate或拿它当LLM成绩。

## 原错误programme的prepare设施阻断集中修复

四programme原生实际分别已bayesian_original_observations、complete_current_demand、settled_cash_floor及原键重放错误；第一次prepare均是工具RecursionError/native1，不是候选成绩。直接触发为owner将assessment置于delivery自身内部，prepare复制交付时把新closed目录继续包含进源；根因是private CLI未先校验输出/输入边界。主方正确reference先前12Mpass的assessment在交付外，未受影响。已搜当前prepare/copytree同语义：仅新增0.4设施和该四调用需要本轮修，旧已交题/0.3只读且其既有assessment都在交付外，不扩泛化框架或重审。原source/wrapper/全部失败命令已封pre-overlap-facility-source.zip，原partial目录和独立原programme/run保外部，不删除失败。新增明确FacilityInvalid assignment_output_overlaps_input先于创建/复制；正确调用用原programme作为交付根、layout programme为.，assessment置独立error-assessments，不再复制failed assessment树。只原四run重新prepare，不重actor/native/优化/正向矩阵；主方main原对象仍同一闭合来源。它是实验设施路径错误，无生产调度/Task/Mission/Session/共享恢复调用。
