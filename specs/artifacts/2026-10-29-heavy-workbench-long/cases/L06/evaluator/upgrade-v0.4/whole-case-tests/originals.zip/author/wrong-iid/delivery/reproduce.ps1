param([Parameter(Mandatory=$true)][string]$Out,[string]$Python="C:/Python314/python.exe")
$ErrorActionPreference="Stop"
if(Test-Path -LiteralPath $Out){throw "output_directory_already_exists"}
& $Python -X utf8 -u -B "$PSScriptRoot/public/exercise.py" --project "$PSScriptRoot/programme" --public "$PSScriptRoot/public" --out $Out --python $Python
if($LASTEXITCODE -ne 0){throw "actual_native_execution_failed"}
