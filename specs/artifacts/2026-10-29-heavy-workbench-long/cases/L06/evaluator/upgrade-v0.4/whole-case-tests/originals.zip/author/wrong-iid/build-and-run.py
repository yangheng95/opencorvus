from pathlib import Path
import sys,json,datetime,subprocess,zipfile
root=Path(__file__).resolve().parent;case=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L06/evaluator/upgrade-v0.4');sys.path[:0]=[str(case/'public'),str(root/'source')];from planner import Planner
from model import load
class IndependentClassEachBatch(Planner):
 def p(self,k,v):return sum(x['prior']*x[v] for x in self.d['modes'].values())
science={}
for ident in ['base','cash-tight','shifted-prior']:
 data=load(case/'public/instances'/ident);p=IndependentClassEachBatch(data);value=p.solve();assert value is not None
 policy={'format':'l06-inspection-policy/1','instance':ident,'lab':{','.join(map(str,k)):v for k,v in p.lab_policy.items()},'ops':{','.join(map(str,k)):v for k,v in p.ops_policy.items()}}
 (root/'programme/plans'/f'{ident}.json').write_text(json.dumps(policy,separators=(',',':'))+'\n',encoding='utf-8');science[ident]={'predicted_cost_under_wrong_IID_class_assumption':str(value),'not_actual_persistent_class_expected_cost':True}
(root/'wrong-assumption-science.json').write_text(json.dumps(science,indent=2)+'\n',encoding='utf-8')
with zipfile.ZipFile(root/'pre-execution-source.zip','w',zipfile.ZIP_DEFLATED) as z:
 for folder in ['programme','source']:
  for p in sorted((root/folder).rglob('*')):
   if p.is_file():z.write(p,p.relative_to(root).as_posix())
 z.write(Path(__file__),Path(__file__).name)
argv=['C:/Python314/python.exe','-X','utf8','-u','-B',str(case/'public/exercise.py'),'--project',str(root/'programme'),'--public',str(case/'public'),'--out',str(root/'run'),'--python','C:/Python314/python.exe'];start=datetime.datetime.now(datetime.timezone.utc).isoformat();r=subprocess.run(argv,capture_output=True,text=True,encoding='utf-8');(root/'actual-command.json').write_text(json.dumps({'started_at':start,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':argv,'native_exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr},indent=2)+'\n',encoding='utf-8');print(json.dumps({'native_exit':r.returncode,'stdout_tail':r.stdout[-1000:],'stderr_tail':r.stderr[-1200:]}));raise SystemExit(r.returncode)
