from pathlib import Path
import json,datetime
R=Path('D:/myhexin-local/opencorvus');B=R/'specs/artifacts/2026-10-29-heavy-workbench-long';C=B/'cases/L06/evaluator/upgrade-v0.4';O=Path('D:/opencorvus-benchmark-runs/l06-v04-full-case-20261031');P=Path('D:/opencorvus-benchmark-runs/l06-v04-whole-case-independent-review-20261031')
def append(p,s):
 text=p.read_text(encoding='utf-8');assert s.splitlines()[0] not in text;p.write_text(text.rstrip()+'\n\n'+s.strip()+'\n',encoding='utf-8')
def line(p,prefix,new):
 lines=p.read_text(encoding='utf-8').splitlines();assert sum(v.startswith(prefix) for v in lines)==1;p.write_text('\n'.join(new if v.startswith(prefix) else v for v in lines)+'\n',encoding='utf-8')
main=json.loads((O/'assessment-main/final-grade.json').read_text());weak=json.loads((O/'assessment-weak/final-grade.json').read_text());archive=json.loads((C/'whole-case-tests/archive.json').read_text())
assert main['good'] is True and main['total']==100 and weak['good'] is False
append(C/'BUILD-PLAN.md',f'''## 集中修后唯一结案与真实grade

最终独审见whole-case-tests/independent-review，B01/B02仅原对象必要复验，主/弱/IID原closed重算保正确输出，未重actor/native/DP/cold。FREEZE只登记L06/0.4.0-dev开发metadata，原raw/17ID/权重100/critical/90及各输入101/100不变。真正grade对子项重新从closed原run/source/delivery计算，再接原绑定5H：主参考{main['total']}/allcritical/goodtrue；弱{weak['total']}、H01/H05criticalfail/goodfalse。两次直接原生exit分别0/4，全argv/真实时间/stdout/stderr保存；非LLM候选或手写聚合。四原故障、真实badLab和完整IID错误模型仍按原已知失败/未执行blocked，未伪造整分。

静止全原件唯一archive {archive['bytes']:,}bytes/{archive['members']}members，逐成员及排除理由在archive.json；保全部独特原DP/native/SQL/wire/源码/正确错误/初评误过/修后/唯一cold。第三方report-env/cache、assignment重复closed副本和首次递归自复制临时树原封外部，不谎称小ZIP包含那些字节。不重复任何旧0.3/旧solver/原训练/已完审查。fresh比较尚未启动，作者秒数/业务阶段不当有效小时；全目标ACTIVE。
''')
(C/'whole-case-tests/README.md').write_text(f'''# L06/0.4完整整题实测、一次整审与真实评分

[完整可读参考](reference/REPORT.md)、[源码与原生自含复建](reference/HANDOFF.md)、[实际账](reference/data/stage-ledger.csv)、[实际三PNG](reference/figures/cost-and-information.png)及[正式grade](assessments/assessment-main/final-grade.json)保原交付。主方与独审均实际打开科学图。公料为原创合成，有限8周定义不是现实供应商样本。

事前各输入101/100同信息最优质量；首次三个完整Fraction DP均不到1秒，另原stored政策完整Bellman物理核37.1349805秒。实际source-only actor三输入197终结观测史/3152SQLite阶段/两controller73后原order与lab-result键/receipt恢复+16行序控制native0/90.9964303秒。worker切断前EOF自然0，未声称kill/掉电或同用户OS隔离。唯一独立source-only全重建168.5232507秒自然0，独立CSV/Fraction/SQL/科学和图全核；不再cold或solver。

一次集中[最终审查](independent-review/REVIEW-FINAL.md)发现B01布尔AR误过、B02真实坏lab归因blocked，两项集中修后仅原反例/原正向闭合对象复核，初源和实际错误全保。开发metadata冻后真实grader从closed重算12M再接绑定5H：主参考100/17pass/allcritical/goodtrue；数字/图正确却假识别与无限现实保证的真实report programme{weak['total']}/H01及H05关键失败/goodfalse。它不是模型试跑或职业/统计认证。

四真实bad actors分别后验/实物/现金/原键关键失败，另真实无包验货M02失败；完整IID-class错误规划策略真实可行且后验/恢复正确，2768阶段成本均超事前1%界，只有M04失败。未执行依赖blocked、未全独评总分null，不手写整分。

[originals.zip](originals.zip)为{archive['bytes']:,}bytes/{archive['members']}members；[逐成员/外部排除范围](archive.json)明确第三方report环境/cache、重复closed副本、原递归自复制临时树全外部保留。ZIP保独特原source/native/SQL/wire/命令/真实错误/初评与修复/唯一cold，身份绑定不替功能证明。候选有效小时资格仍0/10；L01原矩阵继续、套件9/10，fresh0.4尚未启动。
''',encoding='utf-8')
text=(C/'README.md').read_text(encoding='utf-8').replace('（完整开发对象，待唯一集中整审）','（完整整题实测与一次整审开发冻）')
text=text.replace('等待同一次整题内容独审','同一次整题独审H01/H05关键失败')
text=text.replace('未给metadata冻或fresh成绩','已仅metadata开发冻，真实参考100/弱90关键失败；尚无fresh0.4成绩')
text+='\n[全链原件、正式评分与集中修后结案](whole-case-tests/README.md)包含全部真实正错、初误过/初审与唯一修后复验；旧版本完全只读。\n'
(C/'README.md').write_text(text,encoding='utf-8')
append(B/'cases/L06/README.md','''## 最新L06/0.4完整交付

0.3双100后已完成[另版主动验货完整case](evaluator/upgrade-v0.4/README.md)：采购/实际验货选择内生信息，真实库存/已收现金/原order及结果receipt恢复耦合，且别名在任何自适应实验下不可识别。三个完整输入、事前各1%同信息最优质量、实际全链/三图/同checker真错误programme/17原子叶与一次集中整审均闭合，仅metadata开发冻；参考100，假识别/现实保证弱90但H01/H05关键失败。完整IID错误策略物理/后验/恢复正确而实际超原质量界，仅M04fail。作者结果不是模型成绩/有效小时，fresh0.4待同公开输入真实比较；不再重0.3或本参考矩阵/冷跑。
''')
for p in [B/'README.md',B/'cases/README.md']:
 lines=p.read_text(encoding='utf-8').splitlines()
 for i,v in enumerate(lines):
  if v.startswith('| ') and ('L06耦合' in v):
   if 'cases/README' in str(p).replace('\\','/'):
    lines[i]='| [L06主动验货采购/现金](L06/evaluator/upgrade-v0.4/README.md) | 旧0.2/新0.3各真实双100；另版0.4三个完整内生观测输入/全链/实际图/真错误programme/一次整审开发冻 | 参考100、假识别弱90关键失败；fresh0.4区分度/有效小时仍待，旧线只读 |'
   else:lines[i]='| [L06主动验货经营](cases/L06/evaluator/upgrade-v0.4/README.md) | 旧0.2/新0.3真实双100均保；0.4完整内生观测/实物现金/原结果恢复、图与一次整审开发冻 | 参考100/弱90关键失败；同信息1%事前目标不改，fresh0.4与小时仍待 |'
 p.write_text('\n'.join(lines)+'\n',encoding='utf-8')
append(R/'specs/records/2026-10/2026-10-29-heavy-workbench-long.md',f'''## L06/0.4主动验货完整整题与一次独审结案Recall（2026-10-31）

0.3新OC与fresh Codex同冻结双100触发另版，本轮仅新增cases/L06/evaluator/upgrade-v0.4，未动旧public/权重/质量/分数，也未改生产路由/Task/Mission/Session/UI。实施前BUILD-PLAN已登记完整8周/三输入/实物与现金逐阶段/两真实commit丢ACK/内生付费观测/别名不可识别及每输入101/100同信息最优；非加大旧树或故意耗时。全部本机stdlivPython3.14、独立report3.12venv；无Docker/WSL/UI/新GPU或L01热改。

首次完整三个Fraction根base300834939/4000000、cash-tight11287373277/128000000、shifted90125954529/1280000000，各不到1秒；按public真实advance完整核原stored政策Bellman证书37.1349805秒，class-known比较仍未知未来批结果，不能把禁验货的材料损失当纯信息价值。真实source-only actor native0/90.9964303秒，三输入197观测终史/3152SQLstage与两controller73→新process原order/lab-result键payloadreceipt续接，另16行序控制。workerEOF0在每次cut前，非kill/掉电；所选未来只parent stdin/内存，未认证同用户OS侧信道。三实际PNG主方与独审已view。

完整主报告/账/概率/后验/现金/绝对AR与自含源封后，一次集中benchmark_review独立CSV/Fraction/原SQL/wire/科学与图实核，唯一自含source-only新完整cold168.5232507秒自然0，新随机episode仍按paid observation path接受跨执行原导出。主H全pass，弱H01/H05fail。仅B01 JSON true冒充ARdue整数误过、B02真实无包lab错误归blocked两项；初源/实际误过/真实错误先封，集中修strict AR类型与partial lab advance，只原反例和主/弱/IID closed复核，不重native/cold/DP。最终无实质阻断，FREEZE只开发metadata，17ID/100/90/critical/raw/101/100不改。

真正grade直接native0/4，从closed重新12M加绑定5H：参考100/allcritical/goodtrue；真实数字图正确但假识别与无限现实保证弱{weak['total']}/H01+H05criticalfail/goodfalse。四真实错误actor具名后验/物料/信用/原键失败；额外真实seq0无包验货具名M02fail；完整IID-class错模型2768阶段物理/后验/恢复正确但三个实际成本均超原1%，只有M04fail，未全内容评总分null。原prepare重叠输入导致递归工具失败和全部初结果保留，不扣作候选分，不扩为产品调度异常。

完整产品/全source/真实命令/原错误/独审初终评/唯一cold保whole-case-tests，originals{archive['bytes']:,}bytes/{archive['members']}members，逐成员/外部保留范围明确。第三方report环境/cache、重复closed副本、递归自复制临时树不谎称全在小ZIP。没有fresh0.4成绩，不把作者/错误programme或秒数/分支/阶段当模型小时；全套仍9/10、有效候选小时0/10，真人/统计成熟未认证。

L01原唯一owner23296/实际训练18416继续：08:33Z只读观察reaction纯L-BFGS已于08:24:19Z41000/loss1.27270296e-6自然转原hybrid，08:32:35Z其LBFGS4000/loss3.25040151e-6，stage终态/新error均无、stderr0。loss不替独立final1%解质量；没有重同格、恢复旧Paused、热改source或持续监听。L01完整论文/合法质量可达/175独评与冻结仍待；新L02升级义务仍保。定时ACTIVE，只原生Windows；已完成旧候选/API53962/56591/59471不重启、不请求。结束本任务范围commit/正常fetch merge/审全部待推/必要检查与完整hook/push，foreign全部保留。
''')
line(R/'specs/README.md','- [L02发布时间输入资格]','- [L02发布时间输入资格](records/2026-10/2026-10-30-heavy-workbench-l02-qualification.md)：旧双100升级仍待；[最新长程Recall](records/2026-10/2026-10-29-heavy-workbench-long.md)保L01原生原矩阵、L06/0.4完整整题真测试/一次整审开发冻，fresh与小时仍待。')
line(R/'specs/artifacts/README.md','- [长程任务资格与便宜实验]','- [长程任务资格与便宜实验](2026-10-29-heavy-workbench-long/README.md)：L01本机原pending继续；L06/0.4内生观测完整整题/真错误programme/一次整审开发冻，仍9/10、候选小时未认证。')
line(R/'specs/records/2026-10/README.md','- [2026-10-30-heavy-workbench-l02-qualification.md]','- [2026-10-30-heavy-workbench-l02-qualification.md](2026-10-30-heavy-workbench-l02-qualification.md)：旧双100另版仍待；[最新十题Recall](2026-10-29-heavy-workbench-long.md)保L01本机原矩阵和L06/0.4完整整题实测/一次整审开发冻，小时未认证。')
print(json.dumps({'updated':'0.4 whole-case docs/Recall and exact3 shared index lines','foreign':'preserved'}))
