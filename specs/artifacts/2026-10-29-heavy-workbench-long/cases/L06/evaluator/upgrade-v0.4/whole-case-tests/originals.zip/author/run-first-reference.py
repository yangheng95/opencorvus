from pathlib import Path
import zipfile,datetime,json,subprocess,os
root=Path(__file__).resolve().parent; project=root/'author-project'; ev=root/'author-study';now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
with zipfile.ZipFile(ev/'pre-execution-source.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(project.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(project).as_posix())
argv=['C:/Python314/python.exe','-X','utf8','-u','-B',str(project/'reference-source/planner.py'),'--inputs',str(project/'public/instances/base'),'--out',str(project/'work/base'),'--known-class']
start=now()
with (ev/'stdout.txt').open('w',encoding='utf-8') as out,(ev/'stderr.txt').open('w',encoding='utf-8') as err:
 p=subprocess.Popen(argv,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
 record={'at':start,'owner_pid':os.getpid(),'actual_python_pid':p.pid,'argv':argv,'scope':'first registered complete8week base/Bayes+advance-class reference; no candidate, no old solver or component qualification','source_capsule':str(ev/'pre-execution-source.zip')}
 (ev/'owner-started.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
 Path('D:/opencorvus-benchmark-runs/L06-v04-current-reference-20261031.json').write_text(json.dumps(record|{'root':str(root),'phase':'full_reference_running'},indent=2)+'\n',encoding='utf-8')
 code=p.wait()
terminal={'started_at':start,'finished_at':now(),'native_exit':code,'actual_python_pid':p.pid,'owner_pid':os.getpid(),'results':str(project/'work/base'),'scope':'complete first reference attempt; preserve failures and original source, no automatic restart'}
(ev/'owner-terminal.json').write_text(json.dumps(terminal,indent=2)+'\n',encoding='utf-8');print(json.dumps(terminal));raise SystemExit(code)
