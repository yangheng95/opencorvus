from pathlib import Path
import os,subprocess,json,datetime
root=Path(__file__).parent;now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();base='C:/Users/hengu/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
(root/'initial-runtime-probe.json').write_text(json.dumps({'at':now(),'interpreter':base,'native_exit':1,'stderr':'ModuleNotFoundError: No module named matplotlib','scope':'local report dependency preparation, no candidate score or training change'},indent=2)+'\n',encoding='utf-8')
records=[]
for argv in [[base,'-m','venv',str(root/'venv')],[str(root/'venv/Scripts/python.exe'),'-m','pip','--isolated','install','--index-url','https://pypi.org/simple','--cache-dir',str(root/'pip-cache'),'matplotlib==3.11.2','numpy==2.5.4']]:
 start=now();r=subprocess.run(argv,capture_output=True,text=True,encoding='utf-8');records.append({'start':start,'finish':now(),'argv':argv,'native_exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr});(root/'preparation.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8');print(json.dumps({'command':argv[:3],'native_exit':r.returncode,'stdout_tail':r.stdout[-700:],'stderr_tail':r.stderr[-700:]}))
 if r.returncode:raise SystemExit(r.returncode)
