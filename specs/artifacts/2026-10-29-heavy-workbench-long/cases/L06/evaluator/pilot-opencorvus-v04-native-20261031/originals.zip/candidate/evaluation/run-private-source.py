from pathlib import Path
import json,zipfile,shutil,subprocess,datetime,os
O=Path('D:/opencorvus-benchmark-runs/l06-v04-opencorvus-native-20261031');E=O/'evaluation';S=O/'project/submission';assert (E/'complete-workspace-receipt.json').is_file() and (E/'normal-dispose-receipt.json').is_file();assert not (E/'source-project').exists() and not (E/'private-run').exists(),'do not repeat private source-only execution'
def write(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
shutil.copytree(S/'actor',E/'source-project');public=E/'public-inputs';public.mkdir()
with zipfile.ZipFile(O/'public-inputs.zip') as z:
 for n in z.namelist():
  p=public/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(n))
layout={'format':'l06-inspection-layout/1','paths':{'programme':'actor','report':'report.md','ledger':'exports-complete/stage-ledger.csv','summary':'exports-complete/summary.json','source_map':'OPERATOR-HANDOFF.txt','reproduce':'OPERATOR-HANDOFF.txt','requirements':'requirements-lock.txt','figures':['figures/decisions.png','figures/cost-information.png','figures/cash.png','figures/material.png','figures/belief-information.png']}};write(E/'delivery-layout.json',layout)
argv=['C:/Python314/python.exe','-X','utf8','-u','-B',str(public/'exercise.py'),'--project',str(E/'source-project'),'--public',str(public),'--out',str(E/'private-run'),'--python','C:/Python314/python.exe']
write(E/'private-execution-registration.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':argv,'source_programme':str(S/'actor'),'only_inputs':'exact original21 public bytes and actually delivered actor/tables source-only; no old results/reference/evaluator/credentials/future files','readonly_copy_attribute_resolution':'new work input files written from original byte capsule have default writable attributes; candidate original public unchanged; source/controller/model unchanged','layout_scope':'original handoff contains both source map and actual reproduction commands; no invented wrapper or author filenames','scope':'first actual external private source-only native run after full workspace/Git/untracked/failed/dependency and Task database seal; finite controlled process/dataflow only'})
with zipfile.ZipFile(E/'pre-execution-private-inputs.zip','w',zipfile.ZIP_DEFLATED) as z:
 for label,root in [('programme',E/'source-project'),('public',public)]:
  for p in sorted(root.rglob('*')):
   if p.is_file():z.write(p,label+'/'+p.relative_to(root).as_posix())
 z.write(E/'private-execution-registration.json','private-execution-registration.json')
(E/'temp').mkdir(exist_ok=True);env=os.environ.copy();env.update({'PYTHONDONTWRITEBYTECODE':'1','TMP':str(E/'temp'),'TEMP':str(E/'temp')});at=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (E/'private-stdout.txt').open('w',encoding='utf-8') as out,(E/'private-stderr.txt').open('w',encoding='utf-8') as err:
 p=subprocess.Popen(argv,cwd=E/'source-project',env=env,stdout=out,stderr=err,text=True);write(E/'private-owner-started.json',{'at':at,'actual_native_owner_pid':p.pid,'argv':argv});print(json.dumps({'started_at':at,'actual_native_owner_pid':p.pid}),flush=True)
 locator=Path('D:/opencorvus-benchmark-runs/L06-v04-current-pair-native-20261031.json');pair=json.loads(locator.read_text());pair.update({'at':at,'phase':'codex_graded_good_opencorvus_private_source_running','active_evaluation':{'subject':'opencorvus','stage':'private-native-source-only','root':str(E),'actual_owner_pid':p.pid},'opencorvus_business_score':None});write(locator,pair);code=p.wait()
v={'started_at':at,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'native_exit':code,'actual_native_owner_pid':p.pid,'argv':argv,'stdout':str(E/'private-stdout.txt'),'stderr':str(E/'private-stderr.txt'),'scope':'actual first source-only private native execution; original candidate content/policy/report unchanged'};write(E/'actual-execution-command.json',v);print(json.dumps(v));raise SystemExit(code)
