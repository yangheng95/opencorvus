from pathlib import Path
import json,zipfile,shutil,os,datetime
R=Path('D:/myhexin-local/opencorvus');B=R/'specs/artifacts/2026-10-29-heavy-workbench-long';O=Path('D:/opencorvus-benchmark-runs/l06-v04-opencorvus-native-20261031');E=O/'evaluation';S=O/'project/submission';P=Path('D:/opencorvus-benchmark-runs/l06-v04-opencorvus-independent-review-20261031');D=B/'cases/L06/evaluator/pilot-opencorvus-v04-native-20261031'
def copy(a,b):
 if a.is_dir():shutil.copytree(a,b,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__'))
 else:b.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(a,b)
def write(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
assert (E/'final-grade.json').is_file() and (E/'pre-evaluation-publication.zip').is_file();grade=json.loads((E/'final-grade.json').read_text());assert not (D/'originals.zip').exists()
copy(O/'project/public',D/'public')
for name in ['actor','certificates','figures','review','exports-complete']:copy(S/name,D/'submission'/name)
for p in S.iterdir():
 if p.is_file() and p.name not in ['dependencies.zip','native-evidence.zip']:copy(p,D/'submission'/p.name)
for name in ['complete-workspace-receipt.json','delivery-layout.json','private-execution-registration.json','actual-execution-command.json','actual-prepare-command.json','actual-grade-command.json','final-grade.json','normal-dispose-receipt.json','settlement-before-normal-dispose.json','inspect-lifecycle.json','primary-visual-observations.json']:
 copy(E/name,D/'evaluation'/name)
for p in E.glob('original-git-*.txt'):copy(p,D/'evaluation'/p.name)
for p in (E/'assessment').iterdir():
 if p.is_file():copy(p,D/'evaluation/assessment'/p.name)
for p in P.iterdir():
 if p.is_file() and p.suffix in ['.json','.md','.py']:copy(p,D/'independent-review'/p.name)
for name in ['server-result.json','usage.json']:copy(O/'evidence'/name,D/'runtime-terminal'/name)
manifest=[];omitted=[]
with zipfile.ZipFile(D/'originals.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for label,root in [('candidate',O),('independent-review',P)]:
  for folder,dirs,files in os.walk(root):
   current=Path(folder)
   for name in list(dirs):
    q=current/name;parts=q.relative_to(root).parts;reason=None
    if name=='__pycache__':reason='derived bytecode; complete original workspace remains external'
    elif label=='candidate' and parts==('runtime',):reason='sensitive owned runtime excluded; original Task SQLite backup/Inspect/persistence retained external; credentials normally removed, no source credentials copied to archive'
    elif label=='candidate' and parts in [('project','.git'),('project','.ruff_cache'),('project','.opencorvus')]:reason='original Git/internal/native cache metadata fully retained by complete-workspace.zip; avoid duplicating unrelated internal execution transport here'
    elif label=='candidate' and len(parts)==3 and parts[:2]==('project','submission') and parts[2] in ['env','cache','mpl','wheels','tmp']:reason='third-party environment/download/plot/temporary files; complete original workspace retains all bytes externally, declarations/locks/versions retained here'
    elif label=='candidate' and parts==('evaluation','temp'):reason='private reader temporary SQL copies; raw original private native SQL retained'
    elif label=='candidate' and name=='closed':reason='duplicate immutable assignment input snapshots remain fully external; original native and delivered science bytes retained here'
    elif label=='independent-review' and parts[0] in ['sql-read-copies','temp','cache','matplotlib-cache']:reason='independent read-only temporary/cache copies; raw native and independent audit source/results retained'
    if reason:dirs.remove(name);omitted.append({'root':label,'path':q.relative_to(root).as_posix(),'reason':reason})
   for name in files:
    q=current/name;rel=q.relative_to(root).as_posix()
    if label=='candidate' and rel in ['evaluation/complete-workspace.zip','evaluation/native-task-database.sqlite3','evaluation/native-task-persistence.zip','project/submission/dependencies.zip']:
     omitted.append({'root':label,'path':rel,'reason':'full complete workspace483935603bytes /actual Task database and persistence /third-party wheel transport retained externally; exact scope in original receipt'});continue
    member=label+'/'+rel;z.write(q,member);manifest.append({'path':member,'bytes':q.stat().st_size})
receipt={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'roots':{'candidate':str(O),'independent-review':str(P)},'bytes':(D/'originals.zip').stat().st_size,'members':len(manifest),'member_manifest':manifest,'excluded_external_retained':omitted,'complete_original_workspace':str(E/'complete-workspace.zip'),'complete_original_workspace_bytes':(E/'complete-workspace.zip').stat().st_size,'original_Task_SQLite_backup':str(E/'native-task-database.sqlite3'),'original_Task_database_bytes':(E/'native-task-database.sqlite3').stat().st_size,'scope':'full unique candidate science/source/raw/native/failed and repaired original runs/private controlled source execution/actual grade/one content review; exact Git/deps/internal caches/Task DB retained external, credentials never part of publication'};write(D/'archive.json',receipt)
(D/'README.md').write_text(f'''# L06/0.4原生OpenCorvus：自然交付与真正同冻结整题评分

唯一原Task tsk_g00VZcBwhb00fHHP9RSj自然completed，provider189/tool186请求均有实际outcome；191真实source-reader请求含preflight全gpt-6.1-sol/streaming/HTTP200/settled。Inspect08:44:56→09:39:06 success只生命周期，不是有效小时或业务分。自然终态先完整封28,533workspace文件/947,008,393原bytes、Git f35e85f7c43fd32f6b3dc0c5650c49f72f330c3b/untracked/deps/cache/失败为483,935,603byte胶囊；原21public无变化无extras。实际TaskSQLite备份26,066,944bytes/持久化ZIP4,956,717bytes外部保。随后09:59:27正常dispose/runtimeDisposed+credentialsRemoved true，API58512/原Task已退休，禁止请求/重启；源凭据不动。

[原完整研究](submission/report.md)、[原PDF](submission/report.pdf)、[原操作者移交/源码复建命令](submission/OPERATOR-HANDOFF.txt)、[实际账](submission/exports-complete/stage-ledger.csv)、[原五PNG](submission/figures/decisions.png)均保原字节。候选初native-original因readonly复制导致row-order PermissionError保原；只新建同21字节可写工作副本后native-complete/源重建完整执行，源模型/控制器未改。内部tester与证书是原自审证据，未冒外部独评。

全原件封后唯一新的外部私有source-only native10:01:17→10:02:44Z直接0/owner31008/wrapper86.630037秒，只原actor/tables与同21公料、全新结果，无旧输出/optimizer/参考/未来文件。实际197终史3152stage/两controller73原order/lab-result键payloadreceipt续接+16row控制，全12M真实prepare通过。真实布局的OPERATOR-HANDOFF.txt同时载source map与reproduction指令，未补wrapper/换报告或要求作者文件名。原workerEOF0而非kill/掉电，同用户不授OS/侧信道安全。

[唯一候选内容独评](independent-review/review.json)精确绑定d030f401348d4e5f8c98b978ca843884；原raw CSV/Fraction/私有SQL-wire/AR/原两receipt、源与科学、五实际PNG均核，未再native/DP/solver/cold/证书器/旧Codex或作者审查。真正[grade](evaluation/actual-grade-command.json)从closed重算12M接绑定5H，total={grade['total']}、allcritical={grade['all_critical_pass']}、good={grade['good']}、subject_rolecandidate；不是手写总分/自报/作者分/Inspect分。

[originals.zip](originals.zip)为{receipt['bytes']:,}bytes/{receipt['members']}members，[逐成员与外部保留范围](archive.json)明确483MB全workspace/实际Task数据库/Git/第三方cache不冒称都在本ZIP。凭据未进入模型prompt/spec/提交，正常清暂存，完整源码/失败/账/图/真评分与一次审查均保。Codex actualmodel/usage未知、comparablefalse；不作同模型费用速度因果排名，内部cost0不称外部免费。两系统若真正都good按事前规则另版保本线，不以100称难度成熟；L01原矩阵继续，套件9/10、有效候选小时0/10、职业统计成熟未认证。''',encoding='utf-8')
print(json.dumps({'pilot':str(D),'bytes':receipt['bytes'],'members':receipt['members'],'actual_grade':grade['total'],'good':grade['good']}))
