from pathlib import Path
import subprocess,json,datetime
R=Path('D:/myhexin-local/opencorvus');O=Path('D:/opencorvus-benchmark-runs/l06-v04-opencorvus-native-20261031');argv=['git','push','origin','main'];at=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (O/'publish-push.stdout.txt').open('w',encoding='utf-8') as out,(O/'publish-push.stderr.txt').open('w',encoding='utf-8') as err:
 p=subprocess.Popen(argv,cwd=R,stdout=out,stderr=err,text=True);(O/'publish-push.started.json').write_text(json.dumps({'at':at,'pid':p.pid,'argv':argv},indent=2)+'\n');code=p.wait()
v={'argv':argv,'started_at':at,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'native_exit':code,'stdout':str(O/'publish-push.stdout.txt'),'stderr':str(O/'publish-push.stderr.txt')};(O/'publish-push.terminal.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v));raise SystemExit(code)
