from pathlib import Path
import os,json,zipfile,sqlite3,subprocess,datetime
O=Path('D:/opencorvus-benchmark-runs/l06-v04-opencorvus-native-20261031');P=O/'project';E=O/'evaluation';assert not E.exists(),'do not repeat native candidate closure'
status=json.loads((O/'observations/heartbeat-0952-task-status.json').read_text());closure=json.loads((O/'observations/terminal-request-closure.json').read_text());assert status['lifecycleStatus']=='completed' and status['activity']['running']==0 and closure['open_tool_requests']==closure['open_provider_requests']==0
E.mkdir();started=datetime.datetime.now(datetime.timezone.utc).isoformat();manifest=[];links=[]
with zipfile.ZipFile(E/'complete-workspace.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for folder,dirs,files in os.walk(P,followlinks=False):
  current=Path(folder)
  for name in list(dirs):
   q=current/name
   if q.is_symlink() or q.is_junction():dirs.remove(name);links.append({'path':q.relative_to(P).as_posix(),'target':str(q.resolve()),'scope':'link metadata retained, external targets not traversed'})
  for name in files:
   q=current/name;rel=q.relative_to(P).as_posix()
   if q.is_symlink():links.append({'path':rel,'target':str(q.resolve()),'scope':'file link metadata retained; actual outside bytes not copied'});continue
   z.write(q,rel);manifest.append({'path':rel,'bytes':q.stat().st_size})
changes=[];extras=[]
with zipfile.ZipFile(O/'public-inputs.zip') as z:
 names=set(z.namelist())
 for n in names:
  q=P/'public'/n
  if not q.is_file() or q.read_bytes()!=z.read(n):changes.append(n)
 extras=[q.relative_to(P/'public').as_posix() for q in (P/'public').rglob('*') if q.is_file() and q.relative_to(P/'public').as_posix() not in names]
for label,args in [('status',['status','--short']),('head',['rev-parse','HEAD']),('untracked',['ls-files','--others','--exclude-standard']),('git-dir',['rev-parse','--absolute-git-dir']),('git-common-dir',['rev-parse','--git-common-dir'])]:
 p=subprocess.run(['git','-C',str(P),*args],capture_output=True,text=True,encoding='utf-8',errors='replace');(E/f'original-git-{label}.txt').write_text(p.stdout+p.stderr,encoding='utf-8')
source=sqlite3.connect('file:'+str(O/'runtime/data/opencorvus.db')+'?mode=ro',uri=True);dest=sqlite3.connect(E/'native-task-database.sqlite3');source.backup(dest);dest.close();source.close()
with zipfile.ZipFile(E/'native-task-persistence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 z.write(E/'native-task-database.sqlite3','native-task-database.sqlite3')
 for q in (O/'observations').glob('*.json'):z.write(q,'observations/'+q.name)
 for q in (O/'inspect-logs').glob('*.eval'):z.write(q,'inspect-logs/'+q.name)
v={'started_at':started,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'project':str(P),'archive_bytes':(E/'complete-workspace.zip').stat().st_size,'members':len(manifest),'original_file_bytes':sum(q['bytes'] for q in manifest),'member_manifest':manifest,'links_not_followed':links,'public_original_source_changes':changes,'public_extras':extras,'git_head':(E/'original-git-head.txt').read_text().strip(),'actual_task_database_snapshot_bytes':(E/'native-task-database.sqlite3').stat().st_size,'task_persistence_zip_bytes':(E/'native-task-persistence.zip').stat().st_size,'scope':'complete natural project workspace incl actual Git/untracked/deps/cache/failures and separate actual own Task SQLite backup/Inspect/persistent outcomes; runtime auth/models excluded from candidate workspace and never published; no functional grade/effective-hour inference'};(E/'complete-workspace-receipt.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:v[k] for k in ['archive_bytes','members','original_file_bytes','public_original_source_changes','public_extras','git_head','actual_task_database_snapshot_bytes','task_persistence_zip_bytes']}),flush=True)
p=Path('D:/opencorvus-benchmark-runs/L06-v04-current-pair-native-20261031.json');pair=json.loads(p.read_text());pair.update({'at':v['finished_at'],'phase':'codex_graded_good_opencorvus_delivered_originals_sealed','opencorvus_status':'completed_originals_sealed_unassessed','opencorvus_workspace':str(E/'complete-workspace.zip'),'opencorvus_workspace_receipt':str(E/'complete-workspace-receipt.json'),'active_evaluation':'opencorvus_source_only_preparation','opencorvus_business_score':None});p.write_text(json.dumps(pair,indent=2)+'\n')
