import json,subprocess,sys,time,zipfile
from pathlib import Path
sys.path.insert(0,str(Path('/work/backend-contracts/source')))
from l06_packet import read_packet
from qualify_l06 import build_model
r=Path('/work/backend-contracts');known=Path('/work/integer-qualification/results')
data=read_packet(Path('/case/public/inputs'));model=build_model(data).payload()
with zipfile.ZipFile('/case/evaluator/qualification/v2/integer-search/quality-reference/originals.zip') as archive:
    original=json.loads(archive.read('input/full-model.json'))
assert model==original
hand=json.loads((known/'hand-input.json').read_text());warm=json.loads((known/'hand-integer.json').read_text())['plan']
(r/'warm-plan.json').write_text(json.dumps(warm));bad=json.loads(json.dumps(hand));bad['scenarios'][0]['demand']=[[3]];(r/'infeasible-input.json').write_text(json.dumps(bad))
events=[]
for name,input_file,extra,expected in [('warm',known/'hand-input.json',['--warm-start-plan',str(r/'warm-plan.json'),'--relative-gap','0'],'OPTIMAL'),('infeasible',r/'infeasible-input.json',[],'INFEASIBLE')]:
    out=r/name;cmd=[sys.executable,'-B',str(r/'source/qualify_l06.py'),'--input',str(input_file),'--output',str(out),*extra]
    start=time.perf_counter();p=subprocess.run(cmd,capture_output=True,text=True);(r/(name+'-stdout.log')).write_text(p.stdout);(r/(name+'-stderr.log')).write_text(p.stderr)
    result=json.loads((out/'solver.json').read_text());assert p.returncode==0 and result['status']==expected and result['solver']=='OR-Tools CP-SAT'
    if name=='warm':assert result['objective']==result['dual_bound']==6 and result['warm_start']['model_objective_exact']=='6' and result['warm_start']['variables_projected']==5
    else:assert result['termination']=='infeasible' and result['objective'] is None
    assert result['native_time_policy']=='unset default infinite'
    events.append({'case':name,'argv':cmd,'exit_code':p.returncode,'seconds':time.perf_counter()-start,'native_status':result['status']})
(r/'receipt.json').write_text(json.dumps({'status':'passed','full_compiled_model_equals_registered':True,'model_variables':len(model['variable_keys']),'model_rows':len(model['rows']),'actual_cli_commands':len(events),'executions':events,'scope':'backend/identity qualification only; no full optimization or candidate score'},indent=2)+'\n')
print(json.dumps({'status':'passed','compiled_model_equal':True,'variables':len(model['variable_keys']),'rows':len(model['rows']),'native_contracts':['OPTIMAL warm6','INFEASIBLE'],'unbounded_time_policy':True}))
