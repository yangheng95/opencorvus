"""Cheap constructive checks against independent hand-computed optima."""
import argparse
import json
from fractions import Fraction
from pathlib import Path
import time

from check_l06 import evaluate
from l06_bound_certificate import evaluate_certificate
from l06_input import read_json
from qualify_l06 import solve,solve_relaxation


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    args.output.mkdir(parents=True,exist_ok=False)
    data={'format':'l06-feasibility-instance/2','weeks':1,'common_weeks':1,'probability_denominator':1,
          'raw_materials':['R'],'products':['P'],'plants':['F'],
          'suppliers':[{'id':'A','lead_weeks':0,'pack_units':[2],'price_minor':[1],'freight_minor':2,'minimum_volume':2}],
          'allowed':[[1]],'production_hours':[1],'production_cost_minor':[[1]],'bom':[[1]],
          'raw_volume':[1],'product_volume':[1],'raw_holding_minor':[1],'product_holding_minor':[1],
          'raw_storage_volume':2,'product_storage_volume':1,'initial_raw':[0],'initial_products':[0],
          'initial_cash_minor':100,'credit_limit_minor':0,'sales_price_minor':[10],'receipt_lag_weeks':1,
          'scenarios':[{'id':'only','probability_numerator':1,'demand':[[1]],'supplier_capacity_volume':[[2]],'plant_capacity_hours':[[1]]}]}
    def write(name,value):
        (args.output/(name+'.json')).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
    start=time.perf_counter()
    write('hand-input',data)
    integer,plan=solve(data)
    business=evaluate(data,plan)
    assert integer['objective']==integer['dual_bound']==business['expected_cost_minor']==6
    write('hand-integer',{'solver':integer,'plan':plan,'independent_business':business})
    linear,proof=solve_relaxation(data)
    assert linear['objective']==3 and Fraction(linear['certified_lower_bound_exact'])==3
    assert proof['fractional_solution'][0]==0.5
    write('hand-relaxation',{'solver':linear,**proof})
    scalar={'format':'l06-linear-relaxation/1','variable_lower':[0],'variable_upper':[4],
            'objective_numerators':[1],'objective_denominator':1,'rows':[{'lower':2,'upper':None,'terms':[[0,1]]}]}
    corrected=evaluate_certificate(scalar,{'format':'l06-row-dual-certificate/1','multipliers':[{'row':0,'side':'lower','value':'-2'}]})
    assert corrected['row_dual_constant_exact']=='4' and corrected['box_correction_exact']=='-4' and corrected['lower_bound_exact']=='0'
    write('known-inexact-dual-correction',corrected)
    tiny=read_json(Path(__file__).parent/'v2/inputs/tiny.json','instance_invalid')
    regression,tiny_plan=solve(tiny)
    tiny_business=evaluate(tiny,tiny_plan)
    assert regression['objective']==regression['dual_bound']==tiny_business['expected_cost_minor']==4.5
    write('registered-tiny-integer',{'solver':regression,'plan':tiny_plan,'independent_business':tiny_business})
    write('receipt',{'status':'passed','hand_integer':6,'hand_continuous':3,'hand_exact_certificate':'3',
                     'inexact_dual_example_true_optimum':2,'inexact_dual_certified_lower_bound':'0',
                     'registered_tiny_integer':4.5,'seconds':time.perf_counter()-start,
                     'scope':'local numeric/build regression, not heavy-case completion or cost certificate for the full instance'})
    print(json.dumps({'cheap_checks':'passed','output':str(args.output)}),flush=True)


if __name__=='__main__':main()
