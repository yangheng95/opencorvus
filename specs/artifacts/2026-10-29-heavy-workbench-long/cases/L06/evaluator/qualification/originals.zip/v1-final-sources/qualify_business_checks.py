"""Enumerate the tiny domain independently; explicit error contracts, no solver."""
import copy
from fractions import Fraction
import itertools
import json
from pathlib import Path

from check_l06 import evaluate, PlanError

root = Path(__file__).resolve().parent
data = json.loads((root/'tiny-v1/instance.json').read_text())
reference = json.loads((root/'tiny-v1/plan.json').read_text())
tested, feasible, best, best_plan = 0, 0, None, None
for a1,b10,b11,a2,b20,b21 in itertools.product(range(2),range(3),range(3),range(2),range(3),range(3)):
    plan = {'format':'l06-plan/1','decisions':{}}
    for name,a,b0,b1,demand1 in [('one',a1,b10,b11,1),('two',a2,b20,b21,2)]:
        plan['decisions'][name] = {'order_lots':[[[a],[b0]],[[0],[b1]]],
                                   'truck_on':[[int(a>0),int(b0>0)],[0,int(b1>0)]],
                                   'production':[[[1]],[[demand1]]]}
    tested += 1
    try:
        result = evaluate(data,plan)
    except PlanError:
        continue
    feasible += 1
    value = Fraction(result['expected_cost_exact']['numerator'],result['expected_cost_exact']['denominator'])
    if best is None or value<best:
        best, best_plan = value, copy.deepcopy(plan)
assert best == Fraction(9,2), best
solver = json.loads((root/'tiny-v1/solver.json').read_text())
assert solver['objective'] == float(best) and solver['dual_bound'] == float(best)
(root/'tiny-v1/enumerated-best-plan.json').write_text(json.dumps(best_plan,indent=2)+'\n')

cases = []
def probe(label, expected, modify_plan=None, modify_data=None):
    inp, plan = copy.deepcopy(data), copy.deepcopy(reference)
    if modify_plan: modify_plan(plan)
    if modify_data: modify_data(inp)
    try:
        result = evaluate(inp,plan)
        observed = 'business_feasible'
    except PlanError as error:
        result = {'code':error.code,'where':error.where,'actual':error.actual,'required':error.required}
        observed = error.code
    assert observed == expected, (label,observed,expected,result)
    cases.append({'label':label,'expected':expected,'observed':observed,'result':{k:v for k,v in result.items() if k!='scenarios'}})

probe('fractional_lots_have_typed_integer_error','decision_integer',
      lambda p:p['decisions']['one']['order_lots'][0][0].__setitem__(0,0.5))
probe('future_specific_early_commitment','common_commitment',
      lambda p:p['decisions']['two']['order_lots'][0][0].__setitem__(0,0))
def late_order(p):
    for record in p['decisions'].values():
        record['order_lots'][1][0][0]=1;record['truck_on'][1][0]=1
probe('order_arriving_after_horizon','terminal_pipeline',late_order)
def unfulfilled(p):
    for record in p['decisions'].values():record['production'][1][0][0]=0
    for record in p['decisions'].values():record.pop('raw_inventory',None);record.pop('finished_inventory',None)
probe('last_week_unfulfilled','fulfilment',unfulfilled)
probe('real_cost_recomputed_despite_reported_zero','business_feasible',lambda p:p.update(expected_cost_minor=0))
assert cases[-1]['result']['expected_cost_minor']==4.5
probe('cash_cut_observed_from_same_plan','cash_limit',modify_data=lambda d:d.update(initial_cash_minor=0))
def over_capacity(p):
    for record in p['decisions'].values():record['order_lots'][0][1][0]=3;record['truck_on'][0][1]=1
probe('supplier_total_volume_capacity','supplier_capacity',over_capacity)
probe('minimum_shipment_volume','shipment_minimum',modify_data=lambda d:d['suppliers'][0].update(minimum_volume=3))
probe('line_product_qualification','product_assignment',modify_data=lambda d:d.update(allowed=[[0]]))
report={'scope':'tiny exhaustive functional qualification plus typed contracts, not full instance or candidate score',
        'enumerated_joint_plans':tested,'feasible_joint_plans':feasible,'best_exact':str(best),
        'solver_objective_and_bound_match_enumeration':True,'probes':cases}
(root/'tiny-v1/enumeration-and-probes.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'enumerated':tested,'feasible':feasible,'best':str(best),'typed_and_recomputed_contracts':len(cases),'all_passed':True}))
