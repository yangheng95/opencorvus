"""Independent delivered-Codex audit only; starts no solver or candidate program."""
import ast
from collections import Counter
import csv
from fractions import Fraction
from itertools import product
import json
from pathlib import Path
import shutil
import subprocess
import time
ROOT=Path(__file__).resolve().parent
REPO=Path('D:/myhexin-local/opencorvus')
CASE=REPO/'specs/artifacts/2026-10-29-heavy-workbench-long/cases/L06'
SUB=Path('D:/opencorvus-benchmark-runs/L06-paired-20261029-be2a55d1/codex/completed/submission')
DEL=SUB/'validation/source-only-reordered/result'
OLD=Path('D:/opencorvus-benchmark-runs/l06-candidate-independent-assessment-20261030')
PYTHON='C:/Python314/python.exe'
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def extract(p,names):
    source=p.read_text(encoding='utf-8');nodes=[n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name in names]
    dest=ROOT/(p.name if p.name.startswith('independent') else 'pure_review_functions.py');dest.write_text('\n\n'.join(ast.get_source_segment(source,n) for n in nodes)+'\n',encoding='utf-8')
    exec(compile(ast.Module(body=nodes,type_ignores=[]),str(dest),'exec'),globals())
def rational(v):return Fraction(v) if type(v) is int else Fraction(v['numerator'],v['denominator'])
def canonical_summary(s):
    import copy
    s=copy.deepcopy(s)
    for row in s['scenarios'].values():row['probability']=rational(row['probability'])
    s['expected_cost_minor']=rational(s['expected_cost_minor']);return s
def main():
    started=time.perf_counter();inventory=[]
    def cp(p,q):q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q);inventory.append({'source':str(p),'copy':str(q.relative_to(ROOT)),'bytes':q.stat().st_size,'same_bytes':p.read_bytes()==q.read_bytes()})
    for n in ('reproduce.py','verify_saved.py','audit_results.py','README.md','requirements.txt','DELIVERY.md','DATA.md','TASK.md','SOURCE.md','OUTPUTS.md','ENVIRONMENT.md','profile.json'):
        cp(SUB/n,ROOT/'snapshot/source'/n)
    for p in (SUB/'src').glob('*.py'):cp(p,ROOT/'snapshot/source/src'/p.name)
    for p in (SUB/'inputs').iterdir():
        if p.is_file():cp(p,ROOT/'snapshot/original-inputs'/p.name)
    for p in DEL.rglob('*'):
        if p.is_file():cp(p,ROOT/'snapshot/delivery'/p.relative_to(DEL))
    for p in (CASE/'public/inputs').iterdir():
        if p.is_file():cp(p,ROOT/'snapshot/frozen-inputs'/p.name)
    cp(CASE/'rubric.json',ROOT/'snapshot/rubric.json');cp(CASE/'evaluator/GRADING.md',ROOT/'snapshot/GRADING.md')
    for n in ('seal-receipt.json','git-log.txt','git-status.txt','owned-containers.json'):cp(SUB.parent/n,ROOT/'snapshot/receipts'/n)
    for n in ('validation/results.json','validation/original-facts-check.log','validation/additional-diagnostics.log','validation/source-only-reordered/source-files.json','validation/source-only-reordered/console.log'):
        cp(SUB/n,ROOT/'snapshot/candidate-evidence'/n)
    extract(OLD/'independent_projection.py',['table','independent_projection']);extract(OLD/'independent_business.py',['independent'])
    out=ROOT/'snapshot/delivery';d,counts=independent_projection(ROOT/'snapshot/frozen-inputs');original,_=independent_projection(ROOT/'snapshot/original-inputs');checks=[]
    def check(name,ok,detail=None):checks.append({'name':name,'passed':bool(ok),'detail':detail})
    check('original_input_same_frozen_semantics',original==d,counts);check('delivered_normalized_all_facts_exact',load(out/'normalized.json')==d)
    save(ROOT/'independent-normalized.json',d)
    results={}
    for label,path in [('primary','plan.json'),('alternative','alternative/plan.json')]:
        r=independent(d,load(out/path));results[label]=r;save(ROOT/(label+'-independent.json'),{k:str(v) if isinstance(v,Fraction) else v for k,v in r.items()})
        check(label+'_full_business_feasibility',r['business_feasible']);check(label+'_complete_ledger_exact',r['ledger']==load(out/('ledger.json' if label=='primary' else 'alternative/ledger.json')))
        check(label+'_complete_summary_exact',canonical_summary(r['summary'])==canonical_summary(load(out/('summary.json' if label=='primary' else 'alternative/summary.json'))))
    a,alt=results['primary'],results['alternative'];C=a['cost'];L=Fraction(47380)
    check('actual_delivered_cost',C==Fraction(95283,2),str(C));check('fixed_reference_quality_not_native_bound',L<=C<=L*Fraction(101,100),{'C':str(C),'L':str(L),'gap_exact':str((C-L)/L)})
    check('actual_alternate_cost_and_tradeoff',alt['cost']==Fraction(95839,2) and alt['cost']-C==278)
    p=load(out/'plan.json');ap=load(out/'alternative/plan.json');diffs=[]
    def walk(x,y,path):
        if isinstance(x,dict):
            for k in x:walk(x[k],y[k],path+[k])
        elif isinstance(x,list):
            for i,(u,v) in enumerate(zip(x,y)):walk(u,v,path+[i])
        elif x!=y:diffs.append({'path':path,'from':x,'to':y})
    walk(p,ap,[]);save(ROOT/'alternative-control-differences.json',diffs)
    check('same_arrivals_production_inventory_for_alternative',all(all(a['ledger']['scenarios'][s['id']]['weeks'][t][k]==alt['ledger']['scenarios'][s['id']]['weeks'][t][k] for k in ('arrivals','made','production','raw_inventory','finished_inventory','raw_stage_peak_volume','product_stage_peak_volume')) for s in d['scenarios'] for t in range(d['weeks'])))
    check('alternative_scenario_premiums_and_payment_deferral',[(alt['summary']['scenarios'][s['id']]['total_cost_minor']-a['summary']['scenarios'][s['id']]['total_cost_minor']) for s in d['scenarios']]==[290,290,230] and len(diffs)==9,diffs)
    parts={k:sum(Fraction(s['probability_numerator'],d['probability_denominator'])*sum(r[k] for r in a['ledger']['scenarios'][s['id']]['weeks']) for s in d['scenarios']) for k in ('purchase_cost','freight_cost','production_cost','holding_cost')}
    check('report_cost_components_exact',list(parts.values())==[Fraction(180742,5),Fraction(5286),Fraction(29004,5),Fraction(4063,10)] and sum(parts.values())==C,{k:str(v) for k,v in parts.items()})
    cash=[];prestock=[]
    for s in d['scenarios']:
        sid=s['id'];rs=a['ledger']['scenarios'][sid]['weeks'];t=min(range(16),key=lambda t:rs[t]['cash']);cash.append({'scenario':sid,'week':t,**a['summary']['scenarios'][sid]})
        for t,j in [(6,0),(9,3)]:
            upper=sum(s['plant_capacity_hours'][t][f]//d['production_hours'][j] for f in range(len(d['plants'])) if d['allowed'][f][j]);stock=rs[t-1]['finished_inventory'][j]
            prestock.append({'scenario':sid,'week':t,'product':d['products'][j],'demand':s['demand'][t][j],'upper':upper,'necessary_stock':max(0,s['demand'][t][j]-upper),'actual_stock':stock})
    check('report_all_tightest_cash_values',all(r['week']==3 and r['minimum_cash_minor']==-5369 for r in cash) and [r['total_cost_minor'] for r in cash]==[47043,47998,48603] and [r['final_cash_minor'] for r in cash]==[32307,31352,32907] and [r['final_receivable_minor'] for r in cash]==[24150,24150,25230],cash)
    check('prestock_bounds_and_actual_quantities',[(r['upper'],r['necessary_stock'],r['actual_stock']) for r in prestock]==[(0,10,10),(3,1,2),(0,10,10),(3,1,1),(0,11,11),(3,2,2)],prestock)
    check('baseline_analytic_infeasibility',d['allowed'][0][0]==1 and d['allowed'][1][0]==0 and all(s['plant_capacity_hours'][6][0]==0 and s['demand'][6][0]>0 for s in d['scenarios']))
    sc=d['scenarios'][1];rs=a['ledger']['scenarios'][sc['id']]['weeks'];raw_volume_demand=sum(sc['demand'][t][j]*sum(d['bom'][j][m]*d['raw_volume'][m] for m in range(len(d['raw_materials']))) for t in [7,8,9] for j in range(len(d['products'])))
    inventory6=sum(rs[6]['raw_inventory'][m]*d['raw_volume'][m] for m in range(len(d['raw_materials'])))+sum(rs[6]['finished_inventory'][j]*sum(d['bom'][j][m]*d['raw_volume'][m] for m in range(len(d['raw_materials']))) for j in range(len(d['products'])))
    check('extra_handoff_interruption_lower_bound',raw_volume_demand==367 and inventory6==87 and all(sc['supplier_capacity_volume'][t][0]==15<d['suppliers'][0]['minimum_volume']==20 for t in [6,7,8]) and all(sc['supplier_capacity_volume'][t][1]==75 for t in [5,6,7]) and all(sc['supplier_capacity_volume'][t][2]==30 for t in [7,8,9]) and all(v==10 for v in d['suppliers'][1]['pack_units']),{'three_week_demand_raw_volume':raw_volume_demand,'B_discrete_max':70,'C_max':30,'three_week_arrival_upper':300,'necessary_buffer':67,'actual_buffer':inventory6})
    # Actual candidate first-pass files are self-delivered evidence; no solver
    # metadata is granted execution points until assessment-side replay closes.
    run=load(out/'run.json');primary=load(out/'primary.json');log=(out/'primary-solver.log').read_text(encoding='utf-8');baseline=(out/'baseline-solver.log').read_text(encoding='utf-8')
    check('native_self_evidence_consistent_and_qualified',run['native_solver']==primary['native_solver'] and run['native_solver']['status']=='Time limit reached' and run['algorithm']['termination_kind']=='resource_limit' and not run['exact_integer_optimum'] and 'Infeasible' in baseline and 'Time limit reached' in log)
    # Run the real frozen stdlib numeric checker, never candidate code/model.
    numeric=ROOT/'numeric-delivered.json';argv=[PYTHON,'-X','utf8','-B',str(CASE/'evaluator/qualification/current-source/l06_numeric.py'),'--case-root',str(CASE),'--input',str(SUB/'inputs'),'--normalized',str(DEL/'normalized.json'),'--plan',str(DEL/'plan.json'),'--summary',str(DEL/'summary.json'),'--ledger',str(DEL/'ledger.json'),'--out',str(numeric)]
    start=time.perf_counter();r=subprocess.run(argv,cwd=ROOT,capture_output=True,text=True,encoding='utf-8',timeout=20)
    (ROOT/'numeric.stdout.txt').write_text(r.stdout,encoding='utf-8');(ROOT/'numeric.stderr.txt').write_text(r.stderr,encoding='utf-8');save(ROOT/'numeric-command.json',{'argv':argv,'exit_code':r.returncode,'seconds':time.perf_counter()-start})
    nr=load(numeric);check('actual_frozen_numeric30_not_self_PASS',r.returncode==0 and nr['counts']['verified_pass']==30 and nr['counts']['unassessed']==17 and nr['total_score'] is None,nr['counts'])
    save(ROOT/'snapshot-inventory.json',inventory);save(ROOT/'checks.json',checks)
    result={'stage':'Codex_delivered_phase1_nonblind','checks':len(checks),'all_passed':all(v['passed'] for v in checks),'failed':[v['name'] for v in checks if not v['passed']],'C':str(C),'alternate_C':str(alt['cost']),'L':str(L),'gap_exact':str((C-L)/L),'gap_percent':float((C-L)/L*100),'purchase_share_exact':str(parts['purchase_cost']/C),'seconds':time.perf_counter()-started,'total_score':None,'business_success':None,'good':None,'new_solver_Provider_Docker_or_candidate_program_calls':0}
    save(ROOT/'arithmetic-assessment.json',result);print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
