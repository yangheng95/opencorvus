"""Read a completed evaluator run; run only independent stdlib arithmetic."""
from collections import Counter
from datetime import datetime, timezone
from fractions import Fraction
from itertools import product
import copy
import csv
import json
from pathlib import Path
import shutil
import time
import zipfile

ROOT=Path(__file__).resolve().parent
BASE=Path('D:/opencorvus-benchmark-runs/L06-paired-20261029-be2a55d1/codex/evaluation/base-cold')
SUB=Path('D:/opencorvus-benchmark-runs/L06-paired-20261029-be2a55d1/codex/completed/submission')
OUT=ROOT/'base-addendum'
OUT.mkdir(exist_ok=True)

def load(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def save(name,v):
    (OUT/name).parent.mkdir(parents=True,exist_ok=True)
    (OUT/name).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def rational(v): return Fraction(v) if type(v) is int else Fraction(v['numerator'],v['denominator'])
def summary(v):
    v=copy.deepcopy(v)
    v['expected_cost_minor']=rational(v['expected_cost_minor'])
    for s in v['scenarios'].values(): s['probability']=rational(s['probability'])
    return v

started=time.perf_counter()
copied=[]
for p in BASE.rglob('*'):
    if p.is_file():
        q=OUT/'snapshot'/p.relative_to(BASE)
        q.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(p,q)
        copied.append({'name':p.relative_to(BASE).as_posix(),'bytes':p.stat().st_size,'same_bytes':p.read_bytes()==q.read_bytes()})
save('snapshot-identity.json',copied)
exec(compile((ROOT/'independent_projection.py').read_text(encoding='utf-8'),'reviewer_independent_projection','exec'),globals())
exec(compile((ROOT/'independent_business.py').read_text(encoding='utf-8'),'reviewer_independent_business','exec'),globals())
checks=[]
def check(name,passed,detail=None): checks.append({'name':name,'passed':bool(passed),'detail':detail})

src=OUT/'snapshot/source'; raw=OUT/'snapshot/raw'; delivery=OUT/'snapshot/results/base'
terminal=load(OUT/'snapshot/terminal-inspect.json')
launch=load(OUT/'snapshot/launch.json')
identity=[]
for p in src.rglob('*'):
    if p.is_file(): identity.append({'file':p.relative_to(src).as_posix(),'same_sealed_source_bytes':p.read_bytes()==(SUB/p.relative_to(src)).read_bytes()})
check('all12mounted_source_files_match_actual_sealed',len(identity)==12 and all(r['same_sealed_source_bytes'] for r in identity),identity)
check('source_mount_contains_only_declared_source_readme_dependencies_tests',set(r['file'] for r in identity)=={'README.md','requirements.txt','reproduce.py','verify_saved.py','src/__init__.py','src/facts.py','src/model.py','src/warm_solver.py','src/accounting.py','src/alternative.py','src/reporting.py','tests/test_contract.py'})
d,counts=independent_projection(raw); frozen,_=independent_projection(ROOT/'snapshot/frozen-inputs')
check('actual_raw_full_semantics_same_frozen',d==frozen,counts)
check('actual_normalized_all_values_same_raw',load(delivery/'normalized.json')==d)
state=terminal['State']; cid=terminal['Id']
check('actual_natural_terminal_exit0',state['Status']=='exited' and not state['Running'] and state['ExitCode']==0 and not state['OOMKilled'] and not state['Error'],state)
check('launch_cid_binds_saved_terminal',launch['exitcode']==0 and launch['stdout'].strip()==cid and cid=='b8af7d5f558d6c64923b19b4fd344df99cd6261e4795b3467c4b507cfcd80dbb')
mounts={r['Destination']:r for r in terminal['Mounts']}
check('three_real_mounts_source_raw_readonly_new_results_writable',set(mounts)=={'/project','/raw','/results'} and not mounts['/project']['RW'] and not mounts['/raw']['RW'] and mounts['/results']['RW'] and all(Path(mounts[k]['Source'])==BASE/v for k,v in [('/project','source'),('/raw','raw'),('/results','results')]),terminal['Mounts'])
check('real_network_none_8cpu_dependency_image',terminal['HostConfig']['NetworkMode']=='none' and terminal['HostConfig']['NanoCpus']==8000000000 and terminal['Image']=='sha256:23ff8bfbf8055caa0b9fa5745ddb27cceea2f31d7d15b7a900c81112cdfe8ddf')
check('real_command_uses_only_raw_and_fresh_output_defaults',terminal['Config']['WorkingDir']=='/project' and terminal['Config']['Cmd']==['/opt/cpsat/bin/python','reproduce.py','--input','/raw','--output','/results/base'])
run=load(delivery/'run.json'); primary=load(delivery/'primary.json'); baseline=load(delivery/'baseline.json'); native=primary['native_solver']
check('run_actual_argv_and_input_match_terminal',run['command']==terminal['Config']['Cmd'] and run['input_path']=='/raw')
check('actual_declared_dependency_versions',run['dependencies']=={'python':'3.11.13','numpy':'2.4.6','scipy':'1.15.3','ortools':'9.15.6755','matplotlib':'3.10.3','highspy':'1.8.0'},run['dependencies'])
results={}
for label,folder in [('primary',delivery),('alternative',delivery/'alternative')]:
    r=independent(d,load(folder/'plan.json'));results[label]=r
    save(label+'-independent.json',{k:str(v) if isinstance(v,Fraction) else v for k,v in r.items()})
    check(label+'_all_physical_cash_terminal_information_constraints',r['business_feasible'],r.get('violations'))
    check(label+'_complete_new_ledger_exact',r['ledger']==load(folder/'ledger.json'))
    check(label+'_complete_new_summary_exact',summary(r['summary'])==summary(load(folder/'summary.json')))
C=results['primary']['cost']; AC=results['alternative']['cost']; L=Fraction(47380)
check('primary_fixed_reference_quality',L<=C<=L*Fraction(101,100),{'C':str(C),'L':str(L),'gap_exact':str((C-L)/L)})
check('fresh_result_is_different_valid_policy_not_copied_sealed_answer',C==Fraction(476167,10) and load(delivery/'plan.json')!=load(ROOT/'snapshot/delivery/plan.json'))
log=(delivery/'primary-solver.log').read_text(encoding='utf-8')
check('actual_primary_log_json_console_integer_objective_agree',native['status']=='Time limit reached' and 'Time limit reached' in log and run['native_solver']==native and rational(load(delivery/'summary.json')['expected_cost_minor'])==C and Fraction(native['objective_numerator'],10)==C and load(OUT/'snapshot/container.stdout.txt')['native']==native)
check('actual_primary_global_search_unrestricted_and_conditional_distinguished',primary['restrictions']=={'just_in_time':False,'reserve':None} and run['algorithm']['termination_kind']=='resource_limit' and not run['exact_integer_optimum'] and all('not a global' in v['bound_scope'] for v in primary['phases']['conditional_neighborhoods'].values()))
check('actual_default_staged_solver_options_projected',primary['parameters']['time_limit']==300 and primary['parameters']['threads']==1 and primary['parameters']['mip_rel_gap']==.001 and primary['phases']['initial']['parameters']['max_time_in_seconds']==600 and primary['phases']['initial']['parameters']['num_search_workers']==8 and all(v['parameters']['time_limit']==180 for v in primary['phases']['conditional_neighborhoods'].values()))
blog=(delivery/'baseline-solver.log').read_text(encoding='utf-8')
check('actual_baseline_process_output_correct_infeasibility_and_nulls',baseline==run['comparison_runs']['baseline'] and baseline['restrictions']['just_in_time'] and baseline['native_solver']['status']=='Infeasible' and 'Status            Infeasible' in blog and baseline['native_solver']['objective_minor'] is None and baseline['native_solver']['best_bound_minor'] is None)
check('independent_baseline_contradiction',d['allowed'][0][0]==1 and d['allowed'][1][0]==0 and all(s['plant_capacity_hours'][6][0]==0 and s['demand'][6][0]>0 for s in d['scenarios']))
check('unknowns_and_infeasibility_honestly_reported',baseline['feasibility']=='infeasible' and run['feasibility']=='feasible' and run['algorithm']['termination_kind']=='resource_limit' and not run['exact_integer_optimum'] and '未提供独立有理证明' in (delivery/'report.md').read_text(encoding='utf-8'))
assess=load(OUT/'snapshot/numeric-assessment.json');cmd=load(OUT/'snapshot/numeric-command.json')
check('actual_root_numeric_cli30_pass_paths_bound_to_this_run',cmd['exitcode']==0 and cmd['stderr']=='' and assess['counts']['verified_pass']==30 and assess['counts']['unassessed']==17 and assess['total_score'] is None and str(BASE/'raw') in cmd['argv'] and str(BASE/'results/base/plan.json') in cmd['argv'])
archive=[]
with zipfile.ZipFile(OUT/'snapshot/completed-originals.zip') as z:
    names=set(z.namelist())
    for p in (OUT/'snapshot').rglob('*'):
        if p.is_file() and p.name!='completed-originals.zip' and p.relative_to(OUT/'snapshot').parts[0] in ('source','raw','results'):
            rel=p.relative_to(OUT/'snapshot').as_posix()
            candidates=[n for n in names if n==rel or n.endswith('/'+rel)]
            archive.append({'file':rel,'members':candidates,'bytes_equal':len(candidates)==1 and z.read(candidates[0])==p.read_bytes()})
check('all_sealed_source_raw_new_result_archive_members_exact',all(r['bytes_equal'] for r in archive),{'members':len(archive)})
save('archive-member-identity.json',archive)
check('cleanup_record_follows_seal_and_same_cid',load(OUT/'snapshot/cleanup.json')['exitcode']==0 and load(OUT/'snapshot/cleanup.json')['container_id']==cid and load(OUT/'snapshot/cleanup.json')['precondition']=='natural terminal and originals sealed')
save('checks.json',checks)
wall=(datetime.fromisoformat(state['FinishedAt'][:-1]+'+00:00')-datetime.fromisoformat(state['StartedAt'][:-1]+'+00:00')).total_seconds()
save('arithmetic-and-process-assessment.json',{'checks':len(checks),'all_passed':all(c['passed'] for c in checks),'failed':[c['name'] for c in checks if not c['passed']],'C':str(C),'fixed_L':str(L),'gap_exact':str((C-L)/L),'gap_percent':float((C-L)/L*100),'alternate_C':str(AC),'alternate_premium':str(AC-C),'container_wall_seconds':wall,'candidate_main_seconds':run['timing']['total_seconds'],'reviewer_audit_seconds':time.perf_counter()-started,'native_global_bound':native['best_bound_minor'],'native_bound_is_rational_certificate':False,'total_score':None,'business_success':None,'good':None,'new_solver_Docker_Provider_candidate_program_calls':0})
print(json.dumps(load(OUT/'arithmetic-and-process-assessment.json'),ensure_ascii=False))
