"""Record the completed quote component; keep overall D02 unassessed."""
from collections import Counter
from datetime import datetime, timezone
import copy
import json
from pathlib import Path
import subprocess

ROOT=Path(__file__).resolve().parent
def load(name):return json.loads((ROOT/name).read_text(encoding='utf-8-sig'))
def save(name,v):(ROOT/name).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
review=copy.deepcopy(load('independent-review-base-addendum.json'))
f=next(v for v in review['findings']if v['id']=='D02')
f.update(judgement='unassessed',observation='The exact registered C/R0 unit-price45→46 control is now actually completed by the independent evaluator using the same sealed source/default command. Natural exit0, readonly raw/source, fresh results, netnone8CPU, source bytes and input identity are verified. All30 numeric leaves and independent full primary/alternative business/ledger/summary recurrence pass; primary47646.7 uses unchanged registeredL47380. Registered row reversal is not yet completed/accepted here, so D02 remains unassessed overall, not candidate0.',evidence=[
 {'path':'quote-addendum/snapshot/terminal-inspect.json','kind':'process_receipt','locator':'Id/State/Config/Mounts/HostConfig','observation':'Actual registered quote run naturally exited0 using same readonly source and only registered quote input with new output.'},
 {'path':'quote-addendum/stage-assessment.json','kind':'business_oracle','locator':'25checks, exactC/alternate/L/gap, quote component and overall status','observation':'Exact independent full new policies/ledger/summary, sole quote change, valid reference, process/native/archive and numeric checks pass; row still pending.'},
 {'path':'quote-addendum/checks.json','kind':'source_audit','locator':'same12archived_executed_source_files; single registered raw difference','observation':'Archived source is byte-identical to sealed submission and base; raw full semantic equality to registered variant excludes cached normalized state.'}])
review['rater']['assignment']+=' Quote addendum: exact registered quote component accepted; overall D02 kept unassessed until actual row control. Original phase1/base findings preserved.'
assert len(review['findings'])==17 and dict(Counter(v['judgement']for v in review['findings']))=={'full':16,'unassessed':1}
for v in review['findings']:
    for e in v['evidence']:
        assert (ROOT/e['path']).is_file()and (ROOT/e['path']).resolve().is_relative_to(ROOT.resolve())
save('independent-review-quote-addendum.json',review)
save('quote-addendum/actual-visual-review.json',{'method':'Actual tools.view_image opened all three new quote-run PNGs; no path-only/keyword/UI automation substitute.','figures':[{'path':'quote-addendum/snapshot/results/quote/figures/cash.png','actual_viewed':True,'observation':'Readable three-scenario cash and AR panels, minor units/week indices, -5369 floor and reveal boundary; new exact full cash/AR ledger matches report and plotted trajectories.'},{'path':'quote-addendum/snapshot/results/quote/figures/procurement.png','actual_viewed':True,'observation':'Scenario supplier-order-volume bars, IDs, units/legends and interruption shade readable. Disruption A zeros and different branch orders correctly expressed; bars are not mislabeled arrivals.'},{'path':'quote-addendum/snapshot/results/quote/figures/warehouse.png','actual_viewed':True,'observation':'Six raw/FG plots label stage peak/end stock/cap240/100 with clear scenario/volume/week axes. New ledger/stage data were independently recomputed; no physical-capacity loophole inferred from lower ending stock.'}],'scope':'Only new quote control reconstruction; original submitted F04 findings remain their actual bound object.'})
arith=load('quote-addendum/stage-assessment.json')
save('stage-assessment-quote-addendum.json',{'case':'L06/0.2.0','submission_id':review['submission_id'],'registered_quote_component':'verified','registered_row_component':'pending evaluator completion, no active-container inspection or interference','D02_overall':'unassessed','review_counts':{'full':16,'unassessed':1},'actual_quote_audit':arith,'candidate_business_defects_found':[],'total_score':None,'business_success':None,'good':None,'new_solver_Docker_Provider_candidate_program_calls':0,'original_phase1_and_base_preserved':True,'nonblind_AI_reference_and_prior_OC_familiarity':True,'actual_model_or_usage_known':False,'comparable':False,'completed_utc':datetime.now(timezone.utc).isoformat()})
(ROOT/'QUOTE-COLD-ADDENDUM.md').write_text('''# Codex L06 registered quote control addendum

The exact registered quote component passes independent verification. D02 overall remains unassessed until the registered row control is actually completed and checked; no total, business-success or good verdict is produced. `independent-review-quote-addendum.json` is a valid17-leaf additive review with16full/1unassessed, the same stable submission ID and original five sealed-delivery bindings. Phase1/base files remain unchanged.

## Input, source and reference

Actual archived raw differs from frozen baseline in exactly one CSV field: supplier_quotes.csv C/R0 unit price45→46; all normalized facts otherwise equal. The full variant matches captured normalized.json from the sole registered price-control ZIP and its declared transformation. All12 archived executed source/docs/dependency/test files directly match both sealed eef74425dcd9 and the base-cold source. No cached normalized data is accepted: fresh normalized includes46, and both complete new ledgers are independently reconstructed from that raw and actual actions.

The unchanged L47380 remains applicable under the registered native-bound trust policy. For any nonnegative action policy, the quote increase adds1 per purchased C/R0 unit, never lowers spending, and subtracts its cumulative amount from every subsequent cash balance. Physical/information conditions are unchanged. Thus a quote-feasible policy is base-feasible and has no lower cost than its base-price counterpart, including terminal cash. Consequently the base L also lower-bounds the quote problem; no new MIP or tighter bound is claimed. This inherits the original trusted numerical solver bound, not a new rational search proof. Historical pending wording inside the immutable proof artifact is preserved; registration separately records the reviewed variant.

## Actual terminal and new accounting

Root-owned CID67ae66c71bc5c3da02d46c77cf06eea9b95e0cad746a46f2d73b414ae695c433 naturally exited0:01:44:57.762997342Z→01:59:42.076927847Z, wall884.313930s, main883.059282s. Actual argv is `/opt/cpsat/bin/python reproduce.py --input /raw --output /results/quote` in /project. Source/raw readonly, fresh results writable, netnone8CPU and dependency image unchanged; real defaults and declared versions match base. Fresh in-invocation hints are computed from this raw, and old result directories are not mounted. Archived source/raw are read from executed-source/ and executed-raw/, not guessed from result prefixes. All33 new result ZIP members match the actual output files. Cleanup references only the naturally completed own CID after sealing.

`audit_quote_addendum.py` actual stdlib-only run took.450362s;25 checks pass. No candidate program, solver, Docker, Provider or GPU ran in this review. Full main and alternate physical/information/cash/terminal checks and every ledger/summary field match independent arithmetic. Main C476467/10=47646.7; fixed-L gap2667/473800≈0.56289574%. Alternate479367/10=47936.7, premium290, is a distinct complete feasible policy. In each branch it moves10 R2 units from B/week13 to C/week15 and delays payment2weeks, preserving arrival/production/inventory.

As a separate controlled calculation, evaluating these exact same plans at old prices gives47631.1 and47921.1 respectively; both expected increases are78/5=15.6. For each scenario/week, quote cash equals the same-policy old-price cash minus cumulative changed units. This confirms actual price/cash/cost semantics. The difference between separate base search47616.7 and quote search47646.7 is not asserted to be the exact quote marginal effect because policies differ. Correct actions need not flip.

True root numeric CLI is bound to this registered input and new output, exit0/30pass/17unassessed. Actual HiGHS global native Time limit reached, primal476467 and bound474627 (denominator10), resource_limit/no exact-optimum declaration, agrees with new stdout/run/native log. Numerical bound47462.7 is not substituted for fixed47380 or presented as a rational certificate.

All three new cash/procurement/warehouse PNGs were actually opened with view_image. Labels, units, scenarios/legends and new ledger-consistent values are readable; observations are in quote-addendum/actual-visual-review.json. No candidate report/figure/data contradiction was found in this scope.

The only remaining review leaf is D02's row component. This review does not touch its active container, launch another solver, repeat old main facts, grant a final grade, or claim professional-human/statistical maturity, comparable model cost or effective hours. Nonblind AI familiarity and unknown actual Codex model/usage remain explicit.
''',encoding='utf-8')
status=subprocess.run(['git','status','--short'],cwd='D:/myhexin-local/opencorvus',capture_output=True,text=True,encoding='utf-8')
(ROOT/'quote-addendum/git-status-end.txt').write_text(status.stdout+status.stderr,encoding='utf-8')
save('quote-addendum/review-file-check.json',{'findings':17,'counts':{'full':16,'unassessed':1},'all_evidence_files_exist_within_private_root':True,'original_five_bindings_unchanged':review['artifact_bindings']==load('independent-review-phase1.json')['artifact_bindings'],'grade_cli_called':False,'total_score_computed':False,'git_status_exit':status.returncode})
print(json.dumps({'review':str(ROOT/'independent-review-quote-addendum.json'),'D02_quote_component':'verified','D02_overall':'unassessed','total_score':None},ensure_ascii=False))
