"""Cold reproducible entry: raw public files -> fresh models -> checked deliverables."""
import argparse
import copy
import json
import os
import platform
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from importlib.metadata import version
from src.facts import load_facts, SOURCE_MAPPING, CandidateInputError
from src.model import solve
from src.accounting import simulate
from src.alternative import spot_substitution
from src.reporting import dump, exports, figures, report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--seconds", type=float, default=300, help="Unrestricted joint HiGHS search limit, seconds")
    parser.add_argument("--gap", type=float, default=0.001, help="Native relative MIP gap tolerance")
    parser.add_argument("--warm-seconds", type=float, default=600, help="Fresh CP-SAT first-feasible initialization limit (returns as soon as found)")
    parser.add_argument("--scenario-seconds", type=float, default=180, help="Each fixed-prefix scenario neighborhood search limit")
    args = parser.parse_args()
    if min(args.seconds, args.warm_seconds, args.scenario_seconds) <= 0 or not 0 <= args.gap < 1:
        parser.error("positive time limits and 0<=gap<1 required")
    started = time.monotonic()
    timestamp = datetime.now(timezone.utc).isoformat()
    source = Path(args.input).resolve()
    output = Path(args.output).resolve()
    if output.exists():
        raise CandidateInputError(f"OUTPUT_ALREADY_EXISTS: {output}")
    n = load_facts(source)
    output.mkdir(parents=True)
    dump(output / "normalized.json", n)
    dump(output / "source_mapping.json", SOURCE_MAPPING)
    dependencies = {"python": platform.python_version(), **{package: version(package) for package in ("numpy", "scipy", "ortools", "matplotlib", "highspy")}}
    run = {"format": "l06-run/1", "input_path": str(source),
           "command": [sys.executable, *sys.argv], "started_utc": timestamp,
           "dependencies": dependencies, "resources": {"visible_logical_cpus": os.cpu_count(),
              "native_threads": {"CP-SAT initialization": 8, "HiGHS": 1}, "child_agents_spawned": 0,
              "candidate_role": "independent Codex execution candidate", "external_models_or_accounts_used": False},
           "timing": {"method": "sequential wall clock via time.monotonic; no phase overlap"}}
    try:
        seed_plan, initialization = solve(n, output, "initial", args.warm_seconds, args.gap, 8, backend="cpsat", first_solution=True)
        dump(output / "initial.json", initialization)
        if seed_plan is None:
            run.update(initialization)
            raise RuntimeError("INITIAL_POLICY_UNAVAILABLE: native " + initialization["native_solver"]["status"])
        dump(output / "initial-plan.json", seed_plan)
        _, initial_summary, initial_violations = simulate(n, seed_plan)
        if initial_violations:
            raise RuntimeError("INITIAL_CHECKER_VIOLATIONS: " + repr(initial_violations))
        neighborhood = {"format": "l06-plan/1", "decisions": {}}
        neighborhoods = {}
        for s in n["scenarios"]:
            local = copy.deepcopy(n)
            local["scenarios"] = [copy.deepcopy(s)]
            local["scenarios"][0]["probability_numerator"] = 1
            local["probability_denominator"] = 1
            local_plan, local_run = solve(local, output, "conditional-"+s["id"], args.scenario_seconds, args.gap, 1,
                backend="warm", warm_seconds=0, hint=seed_plan, fixed_prefix=seed_plan)
            local_run["bound_scope"] = "conditional on freshly computed common prefix; not a global joint bound"
            neighborhoods[s["id"]] = local_run
            if local_plan is None:
                raise RuntimeError("CONDITIONAL_POLICY_UNAVAILABLE: " + s["id"])
            neighborhood["decisions"][s["id"]] = local_plan["decisions"][s["id"]]
        _, neighborhood_summary, neighborhood_violations = simulate(n, neighborhood)
        if neighborhood_violations:
            raise RuntimeError("CONDITIONAL_CHECKER_VIOLATIONS: " + repr(neighborhood_violations))
        dump(output / "neighborhood-plan.json", neighborhood)
        dump(output / "neighborhood.json", {"scenarios": neighborhoods, "summary": neighborhood_summary})
        plan, primary = solve(n, output, "primary", args.seconds, args.gap, 1, backend="warm", warm_seconds=0, hint=neighborhood)
        primary["phases"] = {"initial": initialization, "conditional_neighborhoods": neighborhoods}
        primary["algorithm"]["name"] = "fresh joint CP-SAT seed; conditional scenario neighborhoods; unrestricted joint HiGHS search"
        dump(output / "primary.json", primary)
        run.update(primary)
        if plan is None:
            raise RuntimeError("PRIMARY_POLICY_UNAVAILABLE: native " + primary["native_solver"]["status"])
        ledger, summary, violations = simulate(n, plan)
        verification = {"format": "l06-verification/1", "method": "independent exact integer recurrence and rule checks", "violations": violations,
                        "checked_scenarios": len(n["scenarios"]), "checked_weeks_per_scenario": n["weeks"],
                        "rules": ["identity_and_action_shapes", "integer_nonnegative_actions", "common_information_set", "package_and_lead_time",
                                  "supplier_shared_capacity_and_minimum", "route_and_shared_hours", "raw_and_finished_balances",
                                  "both_stage_peaks", "credit_per_scenario_per_week", "terminal_cash", "terminal_finished", "exact_receivable"]}
        dump(output / "verification.json", verification)
        if violations:
            run["feasibility"] = "infeasible"
            raise RuntimeError("PRIMARY_CHECKER_VIOLATIONS: see verification.json")
        for name, value in (("plan", plan), ("ledger", ledger), ("summary", summary)):
            dump(output / f"{name}.json", value)
        exports(n, plan, ledger, output)
        _, baseline = solve(n, output, "baseline", min(30, args.seconds), args.gap, 1, just_in_time=True, backend="warm")
        dump(output / "baseline.json", baseline)
        alternate_dir = output / "alternative"
        alternate_dir.mkdir()
        alternate, alt_ledger, alt_summary, alternative = spot_substitution(n, plan)
        dump(output / "alternative.json", alternative)
        if alternate is not None:
            _, _, alt_violations = simulate(n, alternate)
            dump(alternate_dir / "verification.json", {"format": "l06-verification/1", "violations": alt_violations})
            if alt_violations:
                raise RuntimeError("ALTERNATIVE_CHECKER_VIOLATIONS")
            for name, value in (("plan", alternate), ("ledger", alt_ledger), ("summary", alt_summary)):
                dump(alternate_dir / f"{name}.json", value)
            exports(n, alternate, alt_ledger, alternate_dir)
        figures(n, ledger, output / "figures")
        report(n, plan, ledger, summary, primary, baseline, alternative, alt_ledger, alt_summary, output)
        run["comparison_runs"] = {"baseline": baseline, "alternative": alternative}
        run["delivery_complete"] = alternate is not None
        run["timing"]["total_seconds"] = time.monotonic()-started
        run["finished_utc"] = datetime.now(timezone.utc).isoformat()
        dump(output / "run.json", run)
        dump(output / "manifest.json", {"format": "l06-manifest/1", "outputs": {key: f"{key}.json" for key in ("normalized", "plan", "ledger", "summary", "run")}
             | {"report": "report.md"}, "reproduce_command": run["command"],
             "source_mapping": "source_mapping.json", "operator_actions": "actions.csv", "weekly_accounting": "weekly.csv",
             "figure_data": {name: "ledger.json/scenarios/*/weeks" for name in ("figures/cash.png", "figures/warehouse.png", "figures/procurement.png")},
             "alternative": {key: f"alternative/{key}.json" for key in ("plan", "ledger", "summary")},
             "baseline": "baseline.json", "primary_solver_log": "primary-solver.log"})
        print(json.dumps({"output": str(output), "expected_cost_minor": summary["expected_cost_minor"], "native": primary["native_solver"],
                          "feasibility": run["feasibility"], "delivery_complete": run["delivery_complete"]}, ensure_ascii=False, indent=2))
        if alternate is None:
            raise RuntimeError("ALTERNATIVE_POLICY_UNAVAILABLE: incomplete operational delivery")
    except Exception as exc:
        run["failure"] = {"type": type(exc).__name__, "message": str(exc)}
        run["timing"]["total_seconds"] = time.monotonic()-started
        dump(output / "run.json", run)
        raise


if __name__ == "__main__":
    try:
        main()
    except CandidateInputError as exc:
        print(json.dumps({"error": "CandidateInputError", "detail": str(exc)}, ensure_ascii=False), file=sys.stderr)
        sys.exit(2)
