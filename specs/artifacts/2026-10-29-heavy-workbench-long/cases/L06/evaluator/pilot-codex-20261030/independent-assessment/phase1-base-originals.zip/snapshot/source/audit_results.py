"""Post-run fact/control/ledger audit. This is not an external evaluator or score."""
import copy
import json
from pathlib import Path
from src.facts import load_facts
from src.accounting import simulate
from src.reporting import dump, fraction


def audit(input_directory, result_directory):
    target = Path(result_directory)
    def read(name):
        return json.loads((target/name).read_text(encoding="utf-8"))
    facts = load_facts(input_directory)
    assert facts == read("normalized.json"), "business projection discrepancy"
    rows, summary, violations = simulate(facts, read("plan.json"))
    assert len(violations) == 0, violations
    assert rows == read("ledger.json"), "primary ledger discrepancy"
    assert summary == read("summary.json"), "primary summary discrepancy"
    alternate_rows, alternate_summary, alternate_violations = simulate(facts, read("alternative/plan.json"))
    assert len(alternate_violations) == 0, alternate_violations
    assert alternate_rows == read("alternative/ledger.json"), "alternative ledger discrepancy"
    assert alternate_summary == read("alternative/summary.json"), "alternative summary discrepancy"
    for sid in rows["scenarios"]:
        for original, alternate in zip(rows["scenarios"][sid]["weeks"], alternate_rows["scenarios"][sid]["weeks"]):
            for key in ("arrivals", "consumption", "raw_inventory", "made", "production", "finished_inventory", "hours",
                        "raw_stage_peak_volume", "product_stage_peak_volume", "production_cost", "holding_cost", "receipts", "receivable"):
                assert original[key] == alternate[key], (sid, original["week"], key, "substitution invariant")
    run = read("run.json")
    objective_numerator = fraction(summary["expected_cost_minor"])*facts["probability_denominator"]
    assert objective_numerator == run["native_solver"]["objective_numerator"], "native objective discrepancy"
    assert run["delivery_complete"] is True
    assert run["feasibility"] == "feasible"
    manifest = read("manifest.json")
    for key in ("normalized", "plan", "ledger", "summary", "run", "report"):
        location = (target/manifest["outputs"][key]).resolve()
        assert target.resolve() in location.parents and location.is_file(), (key, "manifest location")
    return {"result_directory": str(target), "physical_and_cash_feasibility": "verified by exact candidate simulator",
            "complete_primary_and_alternative": True, "primary_summary": summary, "alternative_summary": alternate_summary,
            "native_solver": run["native_solver"], "algorithm": run["algorithm"],
            "baseline_status": read("baseline.json")["native_solver"]["status"],
            "same_arrival_production_inventory_verified": True}


if __name__ == "__main__":
    original = load_facts("inputs")
    reordered = load_facts("validation/source-only-reordered/inputs")
    assert original == reordered, "row reordering changed business facts"
    changed = load_facts("validation/spot-quote-increase/inputs")
    expected = copy.deepcopy(original)
    supplier = next(i for i, term in enumerate(expected["suppliers"]) if term["id"] == "C")
    raw = expected["raw_materials"].index("R0")
    expected["suppliers"][supplier]["price_minor"][raw] += 7
    assert changed == expected, "quote control changed more than the declared fact"
    results = {"format": "l06-candidate-validation/1", "scope": "candidate post-run audit; no external score or reference-bound claim",
        "row_order_control": "all normalized business facts exactly equal to original",
        "numeric_control": {"supplier_id": "C", "raw_id": "R0", "old_unit_price_minor": 45, "new_unit_price_minor": 52,
                            "only_declared_fact_changed": True},
        "source_only_run": audit("validation/source-only-reordered/inputs", "validation/source-only-reordered/result"),
        "numeric_run": audit("validation/spot-quote-increase/inputs", "validation/spot-quote-increase/result-final")}
    dump("validation/results.json", results)
    print(json.dumps(results, indent=2))
