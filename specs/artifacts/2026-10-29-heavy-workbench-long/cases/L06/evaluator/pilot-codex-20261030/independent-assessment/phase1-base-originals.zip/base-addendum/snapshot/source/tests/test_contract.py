"""Focused positive accounting, identity and input-error contract tests; no UI."""
import copy
import csv
import random
import shutil
import tempfile
import unittest
from pathlib import Path
from src.accounting import simulate
from src.facts import load_facts, CandidateInputError
from src.alternative import spot_substitution
from src.model import solve


class AccountingContract(unittest.TestCase):
    def test_complete_two_week_ledger(self):
        n = dict(weeks=2, common_weeks=1, raw_materials=["r"], products=["p"], plants=["f"],
                 raw_volume=[2], product_volume=[3], initial_raw=[1], initial_products=[0],
                 raw_holding_minor=[1], product_holding_minor=[2], production_hours=[1], sales_price_minor=[100],
                 production_cost_minor=[[4]], allowed=[[1]], bom=[[1]], probability_denominator=1,
                 raw_storage_volume=8, product_storage_volume=9, initial_cash_minor=20, credit_limit_minor=10,
                 receipt_lag_weeks=1, suppliers=[dict(id="v", lead_weeks=0, pack_units=[2], price_minor=[5], freight_minor=3, minimum_volume=4)],
                 scenarios=[dict(id="s", probability_numerator=1, demand=[[1], [2]], supplier_capacity_volume=[[8], [8]], plant_capacity_hours=[[2], [2]])])
        plan = {"format": "l06-plan/1", "decisions": {"s": {"order_lots": [[[1]], [[0]]], "truck_on": [[1], [0]], "production": [[[2]], [[1]]]}}}
        ledger, summary, violations = simulate(n, plan)
        expected = [dict(week=0, order_lots=[[1]], truck_on=[1], production=[[2]], arrivals=[2], consumption=[2],
                         raw_inventory=[1], made=[2], finished_inventory=[1], hours=[2], supplier_volume=[4],
                         raw_stage_peak_volume=6, product_stage_peak_volume=6, purchase_cost=10, freight_cost=3,
                         production_cost=8, holding_cost=3, cost=24, receipts=0, cash=-4, receivable=100),
                    dict(week=1, order_lots=[[0]], truck_on=[0], production=[[1]], arrivals=[0], consumption=[1],
                         raw_inventory=[0], made=[1], finished_inventory=[0], hours=[1], supplier_volume=[0],
                         raw_stage_peak_volume=2, product_stage_peak_volume=6, purchase_cost=0, freight_cost=0,
                         production_cost=4, holding_cost=0, cost=4, receipts=100, cash=92, receivable=200)]
        self.assertEqual(ledger["scenarios"]["s"]["weeks"], expected)
        self.assertEqual(summary, {"format": "l06-summary/1", "expected_cost_minor": 28,
            "scenarios": {"s": dict(probability=1, total_cost_minor=28, minimum_cash_minor=-4, final_cash_minor=92, final_receivable_minor=200)}})
        self.assertEqual({"feasible": len(violations) == 0}, {"feasible": True})

    def test_delayed_order_arrival_and_receipts(self):
        # Golden example: week-0 order arrives at week 1, after the initial stock is used.
        n = dict(weeks=2, common_weeks=0, raw_materials=["r"], products=["p"], plants=["f"],
                 raw_volume=[1], product_volume=[1], initial_raw=[1], initial_products=[0],
                 raw_holding_minor=[0], product_holding_minor=[0], production_hours=[1], sales_price_minor=[10],
                 production_cost_minor=[[1]], allowed=[[1]], bom=[[1]], probability_denominator=3,
                 raw_storage_volume=2, product_storage_volume=1, initial_cash_minor=10, credit_limit_minor=0,
                 receipt_lag_weeks=1, suppliers=[dict(id="v", lead_weeks=1, pack_units=[1], price_minor=[2], freight_minor=0, minimum_volume=1)],
                 scenarios=[dict(id="s", probability_numerator=3, demand=[[1], [1]], supplier_capacity_volume=[[1], [1]], plant_capacity_hours=[[1], [1]])])
        plan = {"format": "l06-plan/1", "decisions": {"s": {"order_lots": [[[1]], [[0]]], "truck_on": [[1], [0]], "production": [[[1]], [[1]]]}}}
        ledger, summary, violations = simulate(n, plan)
        self.assertEqual([w["arrivals"] for w in ledger["scenarios"]["s"]["weeks"]], [[0], [1]])
        self.assertEqual([w["cash"] for w in ledger["scenarios"]["s"]["weeks"]], [7, 16])
        self.assertEqual(summary["expected_cost_minor"], 4)
        self.assertEqual({"feasible": len(violations) == 0}, {"feasible": True})


class IdentityContract(unittest.TestCase):
    def test_explicit_indices_survive_csv_reordering(self):
        original = load_facts("inputs")
        with tempfile.TemporaryDirectory(dir=".") as target:
            target = Path(target)
            for source in Path("inputs").iterdir():
                if source.suffix == ".csv":
                    with source.open(encoding="utf-8-sig", newline="") as handle:
                        reader = csv.reader(handle)
                        header, *rows = list(reader)
                    random.Random(20261030).shuffle(rows)
                    with (target/source.name).open("w", encoding="utf-8", newline="") as handle:
                        csv.writer(handle).writerows([header, *rows])
                else:
                    shutil.copyfile(source, target/source.name)
            self.assertEqual(load_facts(target), original)
        self.assertEqual(original["suppliers"][1]["price_minor"], [22, 30, 25, 38])
        self.assertEqual(original["scenarios"][1]["supplier_capacity_volume"][6], [15, 75, 30])
        self.assertEqual(original["bom"][2], [1, 0, 2, 1])

    def test_duplicate_identity_has_named_input_error(self):
        with tempfile.TemporaryDirectory(dir=".") as target:
            target = Path(target)
            for source in Path("inputs").iterdir():
                shutil.copyfile(source, target/source.name)
            quote = target/"supplier_quotes.csv"
            with quote.open(encoding="utf-8") as handle:
                first = handle.read().splitlines()[1]
            with quote.open("a", encoding="utf-8") as handle:
                handle.write(first+"\n")
            with self.assertRaisesRegex(CandidateInputError, "DUPLICATE_KEY: supplier_quotes.csv"):
                load_facts(target)


class OptimizationAndAlternativeContract(unittest.TestCase):
    @staticmethod
    def tiny():
        return dict(weeks=2, common_weeks=0, raw_materials=["r"], products=["p"], plants=["f"],
                    raw_volume=[1], product_volume=[1], initial_raw=[1], initial_products=[0],
                    raw_holding_minor=[0], product_holding_minor=[0], production_hours=[1], sales_price_minor=[10],
                    production_cost_minor=[[1]], allowed=[[1]], bom=[[1]], probability_denominator=1,
                    raw_storage_volume=2, product_storage_volume=1, initial_cash_minor=10, credit_limit_minor=0,
                    receipt_lag_weeks=1, suppliers=[dict(id="A", lead_weeks=1, pack_units=[1], price_minor=[2], freight_minor=0, minimum_volume=1),
                                                  dict(id="C", lead_weeks=0, pack_units=[1], price_minor=[5], freight_minor=0, minimum_volume=1)],
                    scenarios=[dict(id="s", probability_numerator=1, demand=[[1], [1]], supplier_capacity_volume=[[1,1], [1,1]], plant_capacity_hours=[[1], [1]])])

    def test_real_integer_model_has_hand_computed_optimum(self):
        n = self.tiny()
        with tempfile.TemporaryDirectory(dir=".") as output:
            plan, native = solve(n, output, "tiny", 5, 0, 1, backend="warm", warm_seconds=0)
        ledger, summary, violations = simulate(n, plan)
        self.assertEqual(native["native_solver"]["status"], "Optimal")
        self.assertEqual(native["native_solver"]["objective_numerator"], 4)
        self.assertEqual(summary["expected_cost_minor"], 4)
        self.assertEqual([w["cash"] for w in ledger["scenarios"]["s"]["weeks"]], [7,16])
        self.assertEqual({"feasible": len(violations) == 0}, {"feasible": True})

    def test_spot_policy_defers_payment_and_preserves_arrival(self):
        n = self.tiny()
        primary = {"format": "l06-plan/1", "decisions": {"s": {
            "order_lots": [[[1],[0]], [[0],[0]]], "truck_on": [[1,0], [0,0]], "production": [[[1]], [[1]]]}}}
        plan, ledger, summary, metadata = spot_substitution(n, primary)
        self.assertEqual(plan["decisions"]["s"]["order_lots"], [[[0],[0]], [[0],[1]]])
        self.assertEqual([w["cash"] for w in ledger["scenarios"]["s"]["weeks"]], [9,13])
        self.assertEqual([w["arrivals"] for w in ledger["scenarios"]["s"]["weeks"]], [[0], [1]])
        self.assertEqual(summary["expected_cost_minor"], 7)
        self.assertEqual(metadata["algorithm"]["termination_kind"], "completed")
        self.assertEqual(metadata["moves"][0]["payment_deferral_weeks"], 1)


if __name__ == "__main__":
    unittest.main()
