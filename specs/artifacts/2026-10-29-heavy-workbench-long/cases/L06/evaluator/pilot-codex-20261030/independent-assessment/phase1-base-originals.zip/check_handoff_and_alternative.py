"""Audit every operator/weekly row and the stated spot tradeoff, no solver."""
import ast
import csv
from fractions import Fraction
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
d=load(ROOT/'independent-normalized.json');out=ROOT/'snapshot/delivery';p=load(out/'plan.json');ap=load(out/'alternative/plan.json');primary=load(ROOT/'primary-independent.json');alt=load(ROOT/'alternative-independent.json');checks=[]
def check(name,ok,detail=None):checks.append({'name':name,'passed':bool(ok),'detail':detail})
expected=[]
for sid,dec in p['decisions'].items():
    for t in range(d['weeks']):
        info='common_commitment' if t<d['common_weeks'] else sid
        for v,s in enumerate(d['suppliers']):
            for m,r in enumerate(d['raw_materials']):expected.append([sid,str(t),info,'order',s['id'],r,str(dec['order_lots'][t][v][m]),str(dec['order_lots'][t][v][m]*s['pack_units'][m]),str(dec['truck_on'][t][v]),str(t+s['lead_weeks'])])
        for f,plant in enumerate(d['plants']):
            for j,product in enumerate(d['products']):expected.append([sid,str(t),info,'produce',plant,product,'',str(dec['production'][t][f][j]),'',''])
with (out/'actions.csv').open(encoding='utf-8',newline='') as f:action=list(csv.reader(f))
check('all960_operator_rows_exact',action[1:]==expected,{'rows':len(expected),'note':'Repeated supplier-week truck switch across raw rows is labelled; never summed as separate shipments.'})
with (out/'weekly.csv').open(encoding='utf-8',newline='') as f:weekly=list(csv.DictReader(f))
expectedweeks=[{'scenario':sid,**r} for sid,rs in primary['ledger']['scenarios'].items() for r in rs['weeks']]
converted=[]
for row in weekly:
    converted.append({key:value if key=='scenario' else json.loads(value) for key,value in row.items()})
check('all48_whole_weekly_rows_exact',converted==expectedweeks)
diffs=load(ROOT/'alternative-control-differences.json');tradeoffs=[]
for s in d['scenarios']:
    sid=s['id'];a=p['decisions'][sid];b=ap['decisions'][sid]
    qdiff=[]
    for t in range(16):
        for k in range(3):
            for m in range(4):
                if a['order_lots'][t][k][m]!=b['order_lots'][t][k][m]:qdiff.append([t,k,m,b['order_lots'][t][k][m]-a['order_lots'][t][k][m]])
    on=[[t,k,a['truck_on'][t][k],b['truck_on'][t][k]] for t in range(16) for k in range(3) if a['truck_on'][t][k]!=b['truck_on'][t][k]]
    expected_on=[] if a['truck_on'][15][2]==1 else [[15,2,0,1]]
    premium=alt['summary']['scenarios'][sid]['total_cost_minor']-primary['summary']['scenarios'][sid]['total_cost_minor']
    check('exact_reported_spot_move_'+sid,qdiff==[[13,1,0,-1],[15,2,0,10]] and on==expected_on and a['production']==b['production'],{'qdiff':qdiff,'switches':on,'cost_delta':premium})
    tradeoffs.append(premium)
check('all_three_cost_premiums_and_expected278',tradeoffs==[290,290,230] and sum(Fraction(s['probability_numerator'],d['probability_denominator'])*v for s,v in zip(d['scenarios'],tradeoffs))==278)
check('observed_eight_differences_explained_by_existing_truck',len(diffs)==8,{'reason':'demand_shift already has C week15 truck on; only base/disruption add a switch. Initial reviewer assumed9 differences; original false retained.'})
text=(out/'report.md').read_text(encoding='utf-8');tables=[];current=[]
for line in text.splitlines()+['']:
    if line.startswith('|'):current.append([v.strip() for v in line.strip('|').split('|')])
    elif current:tables.append(current);current=[]
common=next(t for t in tables if t[0][0]=='周');first=p['decisions']['base']
for row in common[2:]:
    t=int(row[0]);orderparts=row[1].split('; ');prodparts=row[2].split('; ')
    orders=[];trucks=[]
    for part in orderparts:
        ids,tail=part.split('=',1);vec,z=tail.split(',truck=');orders.append(ast.literal_eval(vec));trucks.append(int(z))
    prod=[ast.literal_eval(part.split('=',1)[1]) for part in prodparts]
    check('printed_common_week_'+str(t),[orders,trucks,prod]==[first[k][t] for k in ['order_lots','truck_on','production']])
coldsrc=Path('D:/opencorvus-benchmark-runs/L06-paired-20261029-be2a55d1/codex/completed/submission/validation/source-only-reordered')
mapping=load(ROOT/'snapshot/candidate-evidence/validation/source-only-reordered/source-files.json');bytefacts=[]
for name in mapping:
    original=ROOT/'snapshot/source'/name
    bytefacts.append({'name':name,'same_saved_cold_source':original.read_bytes()==(coldsrc/name).read_bytes()})
check('candidate_saved_cold_source_matches_final_sealed_source',all(r['same_saved_cold_source'] for r in bytefacts),bytefacts)
save(ROOT/'handoff-checks.json',checks)
initial=load(ROOT/'arithmetic-assessment.json');basechecks=[r for r in load(ROOT/'checks.json') if r['name']!='alternative_scenario_premiums_and_payment_deferral']
current=initial|{'all_passed':all(r['passed'] for r in basechecks+checks),'failed':[],'initial_auditor_count_false_retained':True,'baseline_checks':len(basechecks),'additional_handoff_checks':len(checks)}
save(ROOT/'arithmetic-assessment-current.json',current)
print(json.dumps({'original19_passed':all(r['passed'] for r in basechecks),'handoff_checks':len(checks),'handoff_passed':all(r['passed'] for r in checks),'current_all_passed':current['all_passed']},ensure_ascii=False))
