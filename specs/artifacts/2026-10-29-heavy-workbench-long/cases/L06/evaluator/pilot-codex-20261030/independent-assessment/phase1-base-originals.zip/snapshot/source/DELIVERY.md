# 已完成的运营交付

主交付是 [完整运营报告](validation/source-only-reordered/result/report.md)，机器入口是 [reproduce.py](reproduce.py)，依赖与运行方法在 [README](README.md)。完整产物清单见 [manifest.json](validation/source-only-reordered/result/manifest.json)。不要把早期 `delivery-v1`、`delivery-v2` 当作最终交付。

|真实运行|期望成本 C|原生全局数值界 L|(C−L)/L|完整可行替代成本|终态|
|---|---:|---:|---:|---:|---|
|原业务事实，源码隔离冷复跑及 CSV 行序控制|47641.5|47431.4|0.4430%|47919.5|Time limit reached，feasible|
|仅 C/R0 单价 45→52|47745.9|47611.9|0.2814%|48009.9|Time limit reached，feasible|

这里 CSV 是 Comma-Separated Values（逗号分隔值）。两次运行使用同一源码；第一轮仅挂载 `validation/source-only-reordered` 中复制的源码与重排原始行的资料，启动时没有任何旧结果。其完整 normalized 业务事实与冻结 `inputs/` 完全相同，且 [另一次原始资料核账](validation/original-facts-check.log)直接读取未改动的 `inputs/`，重算主/替代策略的全部账并核对完全一致。报价控制只改变了声明的一项事实；[实际核验结果](validation/results.json)记录两套完整政策的物理、现金、费用、应收及替代策略流量相等性。候选自行选择的控制值不代表评估者封存的值。

两次原生搜索都因真实时间上限停止；没有精确最优或独立有理最优证明。表中的界是各次不固定共同前缀的联合模型原生搜索界，条件分支界没有冒充全局界。评估者的预注册参考界、1% 外部解质量判定、独立评分均未知，本文不编造外部通过或分数。两个可行候选的成本差 104.4 还包含各次搜索所得政策差异，不是报价变动的严格边际成本。

原事实下，base / supplier_disruption / demand_shift 的总成本分别为 47043 / 47998 / 48603，最低现金均在周 3 达到 −5369，信用余量为 0；末周现金分别为 32307 / 31352 / 32907。末周应收分别为 24150 / 24150 / 25230，单列且未充作现金。采购费用的期望金额 36148.4，占总成本约 75.88%。

现在执行报告中的共同周 0–3 动作，周 4 开始前按实际情景 ID 选择后续完整分支。原来下单的在途到货不能更改。操作表 [actions.csv](validation/source-only-reordered/result/actions.csv)逐项列出包数/件数、供应商周开关和分线产量；[weekly.csv](validation/source-only-reordered/result/weekly.csv)及 [ledger.json](validation/source-only-reordered/result/ledger.json)提供完整物料、阶段峰值、费用与现金。

按周交付且不留成品库存的基线真实结果为不可行：周 6 的 P0 只能由停产 F0 提供，必须在周 5 前完成；周 9 的 P3 又受 F1 的 10 工时限制。主方案实际在周 5 留 P0 10/10/11 件，并在周 8 留 P3 2/1/2 件。

供应中断下，A 在下单周 6–8 的容量 15 小于最低装运 20，所以实际不能装运，造成周 7–9 的 A 到货为零。B 包装为 10 件，体积离散为 10 的倍数，容量 75 每周实际至多利用 70；加上 C 的 30，这三周新到货至多 300 体积。三周交付需求折合原料体积为 367，故周 6 期末的原料加成品内含原料至少需储备 67 体积。主方案实际储备 87，参见 [实际计算记录](validation/additional-diagnostics.log)和逐周账。这说明必须在中断到货窗口前形成库存，而不是只在中断周改供应商。

完整可行替代在三个情景均把 B 周 13 的一个 R0 包装（10 件），改为 C 周 15 购买同样件数：原到货周、生产和库存不变，晚承诺/付款两周。主方案各情景实际加价为 290/290/230，概率加权增加 278；demand_shift 原有 C 合单，因此不多付该次运费。末周现金相应减少；这项晚期灵活性并不改善周 3 的信用瓶颈。[替代完整计划](validation/source-only-reordered/result/alternative/plan.json)、[账](validation/source-only-reordered/result/alternative/ledger.json)及 [汇总](validation/source-only-reordered/result/alternative/summary.json)均已实际检查。

复跑：准备 README 声明的依赖，在项目根运行以下入口，输出必须是不存在的新目录。

```text
python reproduce.py --input inputs --output new-output
python verify_saved.py --input inputs --output new-output
python -m unittest discover -s tests -v
```

若在已准备的 Docker 镜像运行，使用 README 的挂载命令。最终两次运行的真实 argv、所有阶段参数、版本、原生状态与日志分别在 [原事实 run.json](validation/source-only-reordered/result/run.json)及 [报价控制 run.json](validation/spot-quote-increase/result-final/run.json)。每次运行内部阶段顺序执行，实测总墙钟分别为 994.810 秒和 942.912 秒；两次验收彼此并行，不能相加冒充总墙钟。求解器使用 CP-SAT 初始化 8 个工作线程、HiGHS 1 个线程，没有候选再创建的子 agent。CP-SAT 是结合 Constraint Programming（约束规划）与 Boolean Satisfiability（布尔可满足性）的整数求解器。

六个聚焦正向契约测试通过：[日志](focused-tests-final.log)。两次 3 情景×16 周的主/替代策略均由精确整数模拟器重算；这属于候选自身验证，不是外部评估。六张最终图已实际查看，见 [视觉记录](specs/records/2026-10/visual-review.md)。原生有限搜索、失败与未知完整保留在 [实施记录](specs/records/2026-10/operating-policy.md)中，包括无解的 A/R0 加价压力实验、无解的额外 P0 储备实验和 120 秒未找到可行起点的运行。

源码已提交于本项目本地 Git。项目交付前不存在 Git 仓库，未修改其他项目；当前无 remote 或 upstream，`git rev-parse --abbrev-ref --symbolic-full-name '@{upstream}'` 返回 `no upstream configured`，因此无法执行推送。后续若需要推送，需提供远端及上游分支配置。未创建 Release、tag 或拉取请求。
