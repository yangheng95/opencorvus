"""Read-only quote-run audit: exact stdlib business arithmetic, no solver."""
from collections import Counter
from datetime import datetime
from fractions import Fraction
from itertools import product
import copy
import csv
import json
from pathlib import Path
import shutil
import time
import zipfile

ROOT=Path(__file__).resolve().parent
RUN=Path('D:/opencorvus-benchmark-runs/L06-paired-20261029-be2a55d1/codex/evaluation/quote-cold')
SUB=Path('D:/opencorvus-benchmark-runs/L06-paired-20261029-be2a55d1/codex/completed/submission')
REF=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L06/evaluator/qualification/v2/integer-search/quality-reference')
OUT=ROOT/'quote-addendum';OUT.mkdir(exist_ok=True)
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def save(name,v):
    p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def rat(v):return Fraction(v) if type(v)is int else Fraction(v['numerator'],v['denominator'])
def canon(v):
    v=copy.deepcopy(v);v['expected_cost_minor']=rat(v['expected_cost_minor'])
    for s in v['scenarios'].values():s['probability']=rat(s['probability'])
    return v
start=time.perf_counter()
for p in RUN.rglob('*'):
    if p.is_file():
        q=OUT/'snapshot'/p.relative_to(RUN);q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
for n in ('registered-reference.json','price-control.zip'):
    q=OUT/'reference'/n;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(REF/n,q)
archive_records=[]
with zipfile.ZipFile(OUT/'snapshot/completed-originals.zip')as z:
    for name in z.namelist():
        if name.startswith('executed-source/')or name.startswith('executed-raw/'):
            q=OUT/'snapshot'/name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(z.read(name))
        elif name.startswith('results/'):
            p=OUT/'snapshot'/name
            archive_records.append({'member':name,'same_original_file_bytes':p.is_file()and p.read_bytes()==z.read(name)})
exec(compile((ROOT/'independent_projection.py').read_text(encoding='utf-8'),'reviewer_independent_projection','exec'),globals())
exec(compile((ROOT/'independent_business.py').read_text(encoding='utf-8'),'reviewer_independent_business','exec'),globals())
checks=[]
def check(name,ok,detail=None):checks.append({'name':name,'passed':bool(ok),'detail':detail})
d,_=independent_projection(OUT/'snapshot/executed-raw');base,_=independent_projection(ROOT/'snapshot/frozen-inputs')
expected=copy.deepcopy(base);expected['suppliers'][2]['price_minor'][0]=46
check('one_and_only_raw_semantic_change_C_R0_45_to46',base['suppliers'][2]['id']=='C'and base['raw_materials'][0]=='R0'and base['suppliers'][2]['price_minor'][0]==45 and d==expected)
rawdiff=[]
for p in (OUT/'snapshot/executed-raw').iterdir():
    frozen=ROOT/'snapshot/frozen-inputs'/p.name
    if p.suffix=='.csv':
        a=p.read_text(encoding='utf-8').splitlines();b=frozen.read_text(encoding='utf-8').splitlines()
        rawdiff.extend({'file':p.name,'line':i+1,'base':x,'quote':y}for i,(x,y)in enumerate(zip(b,a))if x!=y)
    else:check('raw_json_identical_'+p.name,load(p)==load(frozen))
check('physical_csv_just_one_registered_quote_field',len(rawdiff)==1 and rawdiff[0]['file']=='supplier_quotes.csv',rawdiff)
registration=load(OUT/'reference/registered-reference.json');L=rat(registration['lower_bound_minor'])
variant=next(v for v in registration['derived_variants']if v['reference_id']=='L06-v2-price-C-R0-plus1-20261029')
with zipfile.ZipFile(OUT/'reference/price-control.zip')as z:
    captured=json.loads(z.read('normalized.json'));proof=json.loads(z.read('monotone-proof.json'))
save('registered-monotone-proof.json',proof)
check('quote_raw_equals_exact_registered_private_variant',d==captured and variant['transformation']=={'kind':'monotone_supplier_price_increase','supplier_id':'C','raw_id':'R0','delta_minor':1}and L==47380)
source=[]
for p in (OUT/'snapshot/executed-source').rglob('*'):
    if p.is_file():
        rel=p.relative_to(OUT/'snapshot/executed-source');source.append({'file':rel.as_posix(),'same_sealed_source_bytes':p.read_bytes()==(SUB/rel).read_bytes(),'same_base_cold_source_bytes':p.read_bytes()==(ROOT/'base-addendum/snapshot/source'/rel).read_bytes()})
check('same12archived_executed_source_files',len(source)==12 and all(r['same_sealed_source_bytes']and r['same_base_cold_source_bytes']for r in source),source)
terminal=load(OUT/'snapshot/terminal-inspect.json');state=terminal['State'];launch=load(OUT/'snapshot/launch.json');cid=terminal['Id'];mounts={m['Destination']:m for m in terminal['Mounts']}
check('actual_quote_natural_terminal_exit0',state['Status']=='exited'and state['ExitCode']==0 and not state['Running']and not state['OOMKilled']and not state['Error'],state)
check('actual_quote_cid_binds_launch',launch['stdout'].strip()==cid and launch['exitcode']==0 and cid=='67ae66c71bc5c3da02d46c77cf06eea9b95e0cad746a46f2d73b414ae695c433')
check('same_source_and_registered_quote_readonly_fresh_result_rw_mounts',set(mounts)=={'/project','/raw','/results'}and not mounts['/project']['RW']and not mounts['/raw']['RW']and mounts['/results']['RW']and Path(mounts['/project']['Source'])==RUN.parent/'base-cold/source'and Path(mounts['/raw']['Source'])==RUN.parent/'input-controls/quote-C-R0-plus1'and Path(mounts['/results']['Source'])==RUN/'results')
check('same_dependency_image_netnone8cpu_actual_default_command',terminal['Image']=='sha256:23ff8bfbf8055caa0b9fa5745ddb27cceea2f31d7d15b7a900c81112cdfe8ddf'and terminal['HostConfig']['NetworkMode']=='none'and terminal['HostConfig']['NanoCpus']==8000000000 and terminal['Config']['Cmd']==['/opt/cpsat/bin/python','reproduce.py','--input','/raw','--output','/results/quote']and terminal['Config']['WorkingDir']=='/project')
delivery=OUT/'snapshot/results/quote';run=load(delivery/'run.json');primary=load(delivery/'primary.json');native=run['native_solver']
check('new_normalized_uses_quote_not_cached_base',load(delivery/'normalized.json')==d and load(delivery/'normalized.json')!=base)
result={};same_plan_price=[]
for label,folder in [('primary',delivery),('alternative',delivery/'alternative')]:
    plan=load(folder/'plan.json');r=independent(d,plan);old=independent(base,plan);result[label]=r
    save(label+'-independent.json',{k:str(v)if isinstance(v,Fraction)else v for k,v in r.items()})
    check(label+'_full_business_feasible',r['business_feasible'])
    check(label+'_full_new_ledger_exact',r['ledger']==load(folder/'ledger.json'))
    check(label+'_full_new_summary_exact',canon(r['summary'])==canon(load(folder/'summary.json')))
    increment=sum(Fraction(s['probability_numerator'],d['probability_denominator'])*sum(plan['decisions'][s['id']]['order_lots'][t][2][0]*d['suppliers'][2]['pack_units'][0]for t in range(d['weeks']))for s in d['scenarios'])
    nonincreasing=True
    for s in d['scenarios']:
        prefix=0;sid=s['id']
        for t in range(d['weeks']):
            prefix+=plan['decisions'][sid]['order_lots'][t][2][0]*d['suppliers'][2]['pack_units'][0]
            a=r['ledger']['scenarios'][sid]['weeks'][t];b=old['ledger']['scenarios'][sid]['weeks'][t]
            nonincreasing=nonincreasing and a['cash']==b['cash']-prefix and a['cash']<=b['cash']
    check(label+'_price_effect_exact_and_cash_monotone',old['business_feasible']and r['cost']-old['cost']==increment and increment>=0 and nonincreasing,{'quote_C':str(r['cost']),'same_plan_old_price_C':str(old['cost']),'expected_price_increment':str(increment)})
    same_plan_price.append({'policy':label,'quote_C':str(r['cost']),'same_plan_old_price_C':str(old['cost']),'expected_price_increment':str(increment)})
C=result['primary']['cost'];AC=result['alternative']['cost']
check('primary_cost_and_registered_fixedL_quality',C==Fraction(476467,10)and L<=C<=L*Fraction(101,100),{'C':str(C),'L':str(L),'gap_exact':str((C-L)/L)})
check('complete_alternative_real_cost_and_distinct_controls',AC==Fraction(479367,10)and AC-C==290 and load(delivery/'plan.json')!=load(delivery/'alternative/plan.json'))
check('real_argv_input_options_dependencies',run['command']==terminal['Config']['Cmd']and run['input_path']=='/raw'and run['dependencies']==load(ROOT/'base-addendum/snapshot/results/base/run.json')['dependencies']and run['parameters']['time_limit']==300 and run['parameters']['threads']==1 and primary['phases']['initial']['parameters']['max_time_in_seconds']==600 and all(p['parameters']['time_limit']==180 for p in primary['phases']['conditional_neighborhoods'].values()))
log=(delivery/'primary-solver.log').read_text(encoding='utf-8')
check('native_global_objective_status_numerical_bound_and_unknowns',native['status']=='Time limit reached'and native==primary['native_solver']and native==load(OUT/'snapshot/container.stdout.txt')['native']and Fraction(native['objective_numerator'],10)==C and native['best_bound_minor']==47462.7 and 'Time limit reached'in log and run['algorithm']['termination_kind']=='resource_limit'and not run['exact_integer_optimum'])
numeric=load(OUT/'snapshot/numeric-assessment.json');ncmd=load(OUT/'snapshot/numeric-command.json')
check('real_numeric30_pass_with_exact_quote_input_and_output_paths',ncmd['exitcode']==0 and not ncmd['stderr']and numeric['counts']['verified_pass']==30 and numeric['counts']['unassessed']==17 and numeric['total_score']is None and mounts['/raw']['Source']in ncmd['argv']and str(RUN/'results/quote/plan.json')in ncmd['argv'])
check('all33new_result_archive_members_same_files',all(r['same_original_file_bytes']for r in archive_records),{'count':len(archive_records)})
cleanup=load(OUT/'snapshot/cleanup.json');check('same_owned_cid_cleanup_after_sealing',cleanup['exitcode']==0 and cleanup['container_id']==cid and cleanup['precondition']=='natural terminal and originals sealed')
save('checks.json',checks);save('archive-result-identity.json',archive_records);save('same-plan-price-effects.json',same_plan_price)
wall=(datetime.fromisoformat(state['FinishedAt'][:-1]+'+00:00')-datetime.fromisoformat(state['StartedAt'][:-1]+'+00:00')).total_seconds()
assessment={'stage':'Codex registered quote component only','checks':len(checks),'all_passed':all(c['passed']for c in checks),'failed':[c['name']for c in checks if not c['passed']],'C':str(C),'alternative_C':str(AC),'fixed_L':str(L),'gap_exact':str((C-L)/L),'gap_percent':float((C-L)/L*100),'container_wall_seconds':wall,'candidate_main_seconds':run['timing']['total_seconds'],'reviewer_seconds':time.perf_counter()-start,'D02_quote_component':'verified','D02_overall':'unassessed','total_score':None,'business_success':None,'good':None,'new_solver_Docker_Provider_candidate_program_calls':0}
save('stage-assessment.json',assessment);print(json.dumps(assessment,ensure_ascii=False))
