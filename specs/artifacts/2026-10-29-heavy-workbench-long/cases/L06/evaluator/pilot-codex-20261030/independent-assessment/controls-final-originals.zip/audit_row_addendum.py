"""Independent read-only row-control audit; no candidate/solver execution."""
from collections import Counter
from datetime import datetime
from fractions import Fraction
from itertools import product
import copy
import csv
import json
from pathlib import Path
import shutil
import time
import zipfile

ROOT=Path(__file__).resolve().parent
RUN=Path('D:/opencorvus-benchmark-runs/L06-paired-20261029-be2a55d1/codex/evaluation/row-cold')
SUB=Path('D:/opencorvus-benchmark-runs/L06-paired-20261029-be2a55d1/codex/completed/submission')
CASE=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L06')
OUT=ROOT/'row-addendum';OUT.mkdir(exist_ok=True)
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def save(name,v):
    p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def rat(v):return Fraction(v)if type(v)is int else Fraction(v['numerator'],v['denominator'])
def summary(v):
    v=copy.deepcopy(v);v['expected_cost_minor']=rat(v['expected_cost_minor'])
    for s in v['scenarios'].values():s['probability']=rat(s['probability'])
    return v
start=time.perf_counter()
for p in RUN.rglob('*'):
    if p.is_file():
        q=OUT/'snapshot'/p.relative_to(RUN);q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
archive_records=[]
with zipfile.ZipFile(OUT/'snapshot/completed-originals.zip')as z:
    for n in z.namelist():
        if n.startswith('executed-source/')or n.startswith('executed-raw/'):
            q=OUT/'snapshot'/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(z.read(n))
        elif n.startswith('results/'):
            q=OUT/'snapshot'/n;archive_records.append({'member':n,'same_original_file_bytes':q.is_file()and q.read_bytes()==z.read(n)})
exec(compile((ROOT/'independent_projection.py').read_text(encoding='utf-8'),'reviewer_independent_projection','exec'),globals())
exec(compile((ROOT/'independent_business.py').read_text(encoding='utf-8'),'reviewer_independent_business','exec'),globals())
checks=[]
def ck(n,v,d=None):checks.append({'name':n,'passed':bool(v),'detail':d})
raw=OUT/'snapshot/executed-raw';source=OUT/'snapshot/executed-source';delivery=OUT/'snapshot/results/row'
rows=[]
for p in sorted(raw.glob('*.csv')):
    with p.open(encoding='utf-8',newline='')as f:a=list(csv.reader(f))
    with (ROOT/'snapshot/frozen-inputs'/p.name).open(encoding='utf-8',newline='')as f:b=list(csv.reader(f))
    rows.append({'file':p.name,'same_header':a[0]==b[0],'data_rows':len(a)-1,'exact_reverse':a[1:]==b[:0:-1]})
ck('eleven_CSV_headers_exact_data_rows_reversed',len(rows)==11 and all(v['same_header']and v['exact_reverse']for v in rows),rows)
ck('facility_unchanged_semantics',load(raw/'facility.json')==load(ROOT/'snapshot/frozen-inputs/facility.json'))
d,_=independent_projection(raw);frozen,_=independent_projection(ROOT/'snapshot/frozen-inputs')
ck('full_reordered_raw_semantics_same_frozen',d==frozen)
ck('new_normalized_all_fact_values_exact',load(delivery/'normalized.json')==d)
identity=[]
for p in source.rglob('*'):
    if p.is_file():
        rel=p.relative_to(source);identity.append({'file':rel.as_posix(),'same_sealed_source_bytes':p.read_bytes()==(SUB/rel).read_bytes(),'same_base_executed_source_bytes':p.read_bytes()==(ROOT/'base-addendum/snapshot/source'/rel).read_bytes()})
ck('same12sealed_and_base_executed_source_files',len(identity)==12 and all(r['same_sealed_source_bytes']and r['same_base_executed_source_bytes']for r in identity),identity)
terminal=load(OUT/'snapshot/terminal-inspect.json');state=terminal['State'];cid=terminal['Id'];launch=load(OUT/'snapshot/launch.json');mounts={r['Destination']:r for r in terminal['Mounts']}
ck('actual_row_natural_terminal_exit0',state['Status']=='exited'and state['ExitCode']==0 and not state['Running']and not state['OOMKilled']and not state['Error'],state)
ck('actual_cid_launch_identity',launch['exitcode']==0 and launch['stdout'].strip()==cid and cid=='7fcb31b74f57dccbdb7e562323a511613f65ed884846ede42eb6b6a3dc38a79f')
ck('actual_mount_source_raw_readonly_results_fresh_writable',set(mounts)=={'/project','/raw','/results'}and not mounts['/project']['RW']and not mounts['/raw']['RW']and mounts['/results']['RW']and Path(mounts['/project']['Source'])==RUN.parent/'base-cold/source'and Path(mounts['/raw']['Source'])==RUN.parent/'input-controls/row-reversed'and Path(mounts['/results']['Source'])==RUN/'results')
ck('actual_image_netnone8cpu_command',terminal['Image']=='sha256:23ff8bfbf8055caa0b9fa5745ddb27cceea2f31d7d15b7a900c81112cdfe8ddf'and terminal['HostConfig']['NetworkMode']=='none'and terminal['HostConfig']['NanoCpus']==8000000000 and terminal['Config']['WorkingDir']=='/project'and terminal['Config']['Cmd']==['/opt/cpsat/bin/python','reproduce.py','--input','/raw','--output','/results/row'])
results={}
for label,folder in [('primary',delivery),('alternative',delivery/'alternative')]:
    r=independent(d,load(folder/'plan.json'));results[label]=r
    save(label+'-independent.json',{k:str(v)if isinstance(v,Fraction)else v for k,v in r.items()})
    ck(label+'_complete_business_constraints',r['business_feasible'])
    ck(label+'_complete_ledger_exact',r['ledger']==load(folder/'ledger.json'))
    ck(label+'_complete_summary_exact',summary(r['summary'])==summary(load(folder/'summary.json')))
C=results['primary']['cost'];AC=results['alternative']['cost'];L=Fraction(47380)
ck('primary_fixed_registeredL_quality',L<=C<=L*Fraction(101,100),{'C':str(C),'L':str(L),'gap_exact':str((C-L)/L)})
ck('alternate_complete_distinct_policy',load(delivery/'plan.json')!=load(delivery/'alternative/plan.json'),{'C':str(AC),'premium':str(AC-C)})
run=load(delivery/'run.json');primary=load(delivery/'primary.json');native=run['native_solver']
ck('actual_run_argv_dependencies_defaults_match',run['command']==terminal['Config']['Cmd']and run['input_path']=='/raw'and run['dependencies']==load(ROOT/'base-addendum/snapshot/results/base/run.json')['dependencies']and run['parameters']['time_limit']==300 and run['parameters']['threads']==1 and primary['phases']['initial']['parameters']['max_time_in_seconds']==600 and all(v['parameters']['time_limit']==180 for v in primary['phases']['conditional_neighborhoods'].values()))
ck('real_native_log_stdout_primary_objective_bound_status_agree',native==primary['native_solver']and native==load(OUT/'snapshot/container.stdout.txt')['native']and Fraction(native['objective_numerator'],10)==C and native['status']=='Time limit reached'and 'Time limit reached'in(delivery/'primary-solver.log').read_text(encoding='utf-8')and run['algorithm']['termination_kind']=='resource_limit'and not run['exact_integer_optimum'])
numeric=load(OUT/'snapshot/numeric-assessment.json');ncmd=load(OUT/'snapshot/numeric-command.json')
ck('root_actual_numeric30pass_exact_input_output_binding',ncmd['exitcode']==0 and not ncmd['stderr']and numeric['counts']['verified_pass']==30 and numeric['counts']['unassessed']==17 and numeric['total_score']is None and mounts['/raw']['Source']in ncmd['argv']and str(RUN/'results/row/plan.json')in ncmd['argv'])
ck('all33new_result_archive_members_exact',len(archive_records)==33 and all(v['same_original_file_bytes']for v in archive_records))
cleanup=load(OUT/'snapshot/cleanup.json');ck('cleanup_same_owned_terminal_CID_after_seal',cleanup['exitcode']==0 and cleanup['container_id']==cid and cleanup['precondition']=='natural terminal and originals sealed')
current=load(CASE/'rubric.json');old=load(ROOT/'snapshot/rubric.json');leaves=[v for g in current['groups']for v in g['criteria']]
ck('same_frozen47leaf100contract_D02critical',current==old and current['status']=='frozen'and len(leaves)==47 and sum(v['weight']for v in leaves)==100 and next(v for v in leaves if v['id']=='D02')['critical'])
save('checks.json',checks);save('archive-result-identity.json',archive_records)
wall=(datetime.fromisoformat(state['FinishedAt'][:-1]+'+00:00')-datetime.fromisoformat(state['StartedAt'][:-1]+'+00:00')).total_seconds()
report={'case':'L06/0.2.0','stage':'Codex registered row control only','checks':len(checks),'all_passed':all(v['passed']for v in checks),'failed':[v['name']for v in checks if not v['passed']],'primary_C':str(C),'alternate_C':str(AC),'alternate_premium':str(AC-C),'fixed_L':str(L),'gap_exact':str((C-L)/L),'gap_percent':float((C-L)/L*100),'native_global_bound':native['best_bound_minor'],'container_wall_seconds':wall,'candidate_main_seconds':run['timing']['total_seconds'],'reviewer_seconds':time.perf_counter()-start,'registered_row_component':'verified','D02_overall_judgement_not_yet_aggregated':'pending actual manual final synthesis','total_score':None,'business_success':None,'good':None,'new_solver_Docker_Provider_candidate_program_calls':0}
save('stage-assessment.json',report);print(json.dumps(report,ensure_ascii=False))
