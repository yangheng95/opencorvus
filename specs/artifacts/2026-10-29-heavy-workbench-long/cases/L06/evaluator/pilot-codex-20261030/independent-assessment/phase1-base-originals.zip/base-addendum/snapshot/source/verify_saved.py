"""Rebuild accounting from original inputs and compare exact saved artifacts."""
import argparse
import json
from pathlib import Path
from src.facts import load_facts
from src.accounting import simulate
from src.reporting import fraction


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--input", required=True)
    p.add_argument("--output", required=True)
    a = p.parse_args()
    target = Path(a.output)
    n = load_facts(a.input)
    def read(name):
        return json.loads((target/name).read_text(encoding="utf-8"))
    assert n == read("normalized.json"), "normalized projection mismatch"
    ledger, summary, violations = simulate(n, read("plan.json"))
    assert ledger == read("ledger.json"), "ledger mismatch"
    assert summary == read("summary.json"), "summary mismatch"
    assert len(violations) == 0, violations
    native = read("run.json")["native_solver"]
    expected_num = fraction(summary["expected_cost_minor"])*n["probability_denominator"]
    assert expected_num == native["objective_numerator"], "native/checker objective mismatch"
    alt = target/"alternative"
    al, su, av = simulate(n, json.loads((alt/"plan.json").read_text()))
    assert len(av) == 0, av
    assert al == json.loads((alt/"ledger.json").read_text())
    assert su == json.loads((alt/"summary.json").read_text())
    print(json.dumps({"verified": True, "scenarios": len(n["scenarios"]), "weeks_per_scenario": n["weeks"],
        "primary_expected_cost": summary["expected_cost_minor"], "alternative_expected_cost": su["expected_cost_minor"]}, indent=2))
