"""Identity-based projection of the complete public business packet."""
import csv
import json
import re
from pathlib import Path


class CandidateInputError(ValueError):
    """A named input/schema/numeric-domain error, safe for CLI reporting."""


def integer(value, label, minimum=0):
    if isinstance(value, bool) or not re.fullmatch(r"[0-9]+", str(value)):
        raise CandidateInputError(f"INVALID_INTEGER: {label}={value!r}")
    result = int(value)
    if not minimum <= result <= 2**50:
        raise CandidateInputError(f"NUMERIC_RANGE: {label}")
    return result


def load_facts(directory):
    directory = Path(directory)

    def rows(name):
        with (directory / name).open(encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            if reader.fieldnames is None or len(set(reader.fieldnames)) != len(reader.fieldnames):
                raise CandidateInputError(f"INVALID_HEADER: {name}")
            result = list(reader)
        if any(None in row or any(v is None for v in row.values()) for row in result):
            raise CandidateInputError(f"INVALID_ROW: {name}")
        return result

    def catalog(name, index, identity):
        result = rows(name)
        for row in result:
            row[index] = integer(row[index], f"{name}.{index}")
        result.sort(key=lambda row: row[index])
        if [row[index] for row in result] != list(range(len(result))) or not result:
            raise CandidateInputError(f"INVALID_INDEX: {name}")
        ids = [row[identity] for row in result]
        if len(set(ids)) != len(ids) or any(not item for item in ids):
            raise CandidateInputError(f"DUPLICATE_ID: {name}")
        return result, ids, {item: i for i, item in enumerate(ids)}

    raws, raw_ids, ri = catalog("raw_materials.csv", "raw_index", "raw_id")
    prods, product_ids, pi = catalog("products.csv", "product_index", "product_id")
    _, plant_ids, fi = catalog("plants.csv", "plant_index", "plant_id")
    terms, supplier_ids, vi = catalog("supplier_terms.csv", "supplier_index", "supplier_id")
    scen, scenario_ids, si = catalog("scenarios.csv", "scenario_index", "scenario_id")
    with (directory / "facility.json").open(encoding="utf-8-sig") as handle:
        facility = json.load(handle)
    required = ("weeks", "common_weeks", "probability_denominator", "raw_storage_volume",
                "product_storage_volume", "initial_cash_minor", "credit_limit_minor", "receipt_lag_weeks")
    n = {"format": "l06-feasibility-instance/2"}
    for key in required:
        n[key] = integer(facility[key], key, 1 if key in ("weeks", "probability_denominator", "receipt_lag_weeks") else 0)
    if n["common_weeks"] > n["weeks"]:
        raise CandidateInputError("INVALID_COMMON_WEEKS")
    n.update(raw_materials=raw_ids, products=product_ids, plants=plant_ids)
    for source, destination, items, positive in (
        ("volume", "raw_volume", raws, True), ("holding_minor", "raw_holding_minor", raws, False),
        ("initial_units", "initial_raw", raws, False), ("volume", "product_volume", prods, True),
        ("holding_minor", "product_holding_minor", prods, False), ("initial_units", "initial_products", prods, False),
        ("hours", "production_hours", prods, True), ("sales_price_minor", "sales_price_minor", prods, False)):
        n[destination] = [integer(row[source], destination, int(positive)) for row in items]
    T, R, P, F, V, S = n["weeks"], len(raw_ids), len(product_ids), len(plant_ids), len(supplier_ids), len(scenario_ids)
    n["suppliers"] = [{"id": row["supplier_id"], **{key: integer(row[key], f"supplier.{key}")
                            for key in ("lead_weeks", "freight_minor", "minimum_volume")},
                       "pack_units": [None] * R, "price_minor": [None] * R} for row in terms]
    n["allowed"] = [[None] * P for _ in range(F)]
    n["production_cost_minor"] = [[None] * P for _ in range(F)]
    n["bom"] = [[None] * R for _ in range(P)]
    n["scenarios"] = [{"id": row["scenario_id"],
        "probability_numerator": integer(row["probability_numerator"], "probability_numerator", 1),
        "demand": [[None] * P for _ in range(T)],
        "supplier_capacity_volume": [[None] * V for _ in range(T)],
        "plant_capacity_hours": [[None] * F for _ in range(T)]} for row in scen]
    if sum(s["probability_numerator"] for s in n["scenarios"]) != n["probability_denominator"]:
        raise CandidateInputError("INVALID_PROBABILITY_SUM")

    def unique_table(name, key_columns, expected, consume):
        seen = set()
        for row in rows(name):
            key = tuple(integer(row[column], f"{name}.week") if column == "week" else row[column] for column in key_columns)
            if key in seen:
                raise CandidateInputError(f"DUPLICATE_KEY: {name} {key}")
            seen.add(key)
            try:
                consume(row)
            except KeyError as exc:
                raise CandidateInputError(f"UNKNOWN_ID_OR_COLUMN: {name} {key}: {exc}") from exc
        if len(seen) != expected:
            raise CandidateInputError(f"INCOMPLETE_TABLE: {name}: {len(seen)} vs {expected}")

    def quote(row):
        v, r = vi[row["supplier_id"]], ri[row["raw_id"]]
        n["suppliers"][v]["pack_units"][r] = integer(row["pack_units"], "pack_units", 1)
        n["suppliers"][v]["price_minor"][r] = integer(row["unit_price_minor"], "unit_price_minor")

    def route(row):
        f, p = fi[row["plant_id"]], pi[row["product_id"]]
        allowed = integer(row["allowed"], "allowed")
        if allowed not in (0, 1):
            raise CandidateInputError("INVALID_ALLOWED")
        n["allowed"][f][p] = allowed
        n["production_cost_minor"][f][p] = integer(row["production_cost_minor"], "production_cost_minor")

    def bom(row):
        n["bom"][pi[row["product_id"]]][ri[row["raw_id"]]] = integer(row["units"], "bom.units")

    def weekly(row, dimension, key, field):
        s = si[row["scenario_id"]]
        week = integer(row["week"], "week")
        if week >= T:
            raise CandidateInputError("WEEK_OUT_OF_RANGE")
        index = dimension[row[key]]
        source = {"demand": "units", "supplier_capacity_volume": "volume", "plant_capacity_hours": "hours"}[field]
        n["scenarios"][s][field][week][index] = integer(row[source], f"{field}.{source}")

    unique_table("supplier_quotes.csv", ("supplier_id", "raw_id"), V * R, quote)
    unique_table("routes.csv", ("plant_id", "product_id"), F * P, route)
    unique_table("bom.csv", ("product_id", "raw_id"), P * R, bom)
    for name, dimension, key, field in (
        ("demand.csv", pi, "product_id", "demand"),
        ("supplier_capacity.csv", vi, "supplier_id", "supplier_capacity_volume"),
        ("plant_capacity.csv", fi, "plant_id", "plant_capacity_hours")):
        unique_table(name, ("scenario_id", "week", key), S * T * len(dimension),
                     lambda row, d=dimension, k=key, f=field: weekly(row, d, k, f))
    def check_complete(value):
        if value is None:
            raise CandidateInputError("INCOMPLETE_PROJECTION")
        if isinstance(value, dict):
            for child in value.values():
                check_complete(child)
        if isinstance(value, list):
            for child in value:
                check_complete(child)
    check_complete(n)
    for s in n["scenarios"][1:]:
        for key in ("demand", "supplier_capacity_volume", "plant_capacity_hours"):
            if s[key][:n["common_weeks"]] != n["scenarios"][0][key][:n["common_weeks"]]:
                raise CandidateInputError(f"INCONSISTENT_INFORMATION_SET: {key}")
    return n


SOURCE_MAPPING = {
    "identity": "raw_materials/products/plants ID arrays and suppliers/scenarios ordered by explicit index; CSV row order ignored",
    "raw_materials.csv": "raw_materials,raw_volume,raw_holding_minor,initial_raw",
    "products.csv": "products,product_volume,product_holding_minor,initial_products,production_hours,sales_price_minor",
    "plants.csv": "plants", "supplier_terms.csv": "suppliers[].id,lead_weeks,freight_minor,minimum_volume",
    "supplier_quotes.csv": "suppliers[].pack_units,price_minor indexed by raw_materials",
    "routes.csv": "allowed,production_cost_minor [plant][product]", "bom.csv": "bom [product][raw]",
    "scenarios.csv": "scenarios[].id,probability_numerator",
    "demand.csv": "scenarios[].demand [week][product]",
    "supplier_capacity.csv": "scenarios[].supplier_capacity_volume [week][supplier]",
    "plant_capacity.csv": "scenarios[].plant_capacity_hours [week][plant]",
    "facility.json": "same-named top-level integer fields (input format is replaced by normalized format)",
}
