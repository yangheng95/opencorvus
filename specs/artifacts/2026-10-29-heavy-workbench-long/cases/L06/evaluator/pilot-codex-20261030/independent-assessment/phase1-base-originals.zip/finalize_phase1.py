"""Write independent phase-one observations; no candidate execution or grading."""
from collections import Counter
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = Path('D:/myhexin-local/opencorvus')
SUB = Path('D:/opencorvus-benchmark-runs/L06-paired-20261029-be2a55d1/codex/completed/submission')
DEL = SUB / 'validation/source-only-reordered/result'
SUBMISSION_ID = 'codex-L06-eef74425dcd9-phase1'

def save(name, value):
    p = ROOT / name
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

def write(name, value):
    (ROOT / name).write_text(value, encoding='utf-8')

def ev(path, kind, locator, observation):
    assert (ROOT / path).is_file(), path
    return {'path': path, 'kind': kind, 'locator': locator, 'observation': observation}

write('Recall.md', '''# Independent Codex L06 phase-one Recall

Parent assigned one-level read-only evaluation of the naturally completed Codex candidate, HEAD eef74425dcd9b9d6e161c9aa303b38c90f400e25. No redelegation, candidate execution, solver, Provider, GPU, Docker, UI automation, user-process or active-container operations are authorized in this phase. Only this external reviewer directory is writable; repository and sealed submission remain read-only.

The sole final delivery is validation/source-only-reordered/result. Earlier delivery-v1/v2 are retained experiments, not the final submission. Same frozen L06/0.2.0 rubric/GRADING and original 18 public files apply. No actual model or usage identity is available; comparable=false. This reviewer is an AI agent familiar with the reference, development calibration, and the earlier OpenCorvus outcome. Review is nonblind, not professional-human or statistical certification.

Read: frozen rubric/GRADING; root README/DELIVERY and public input documents; reproduce/verify and src facts/model/warm_solver/accounting/alternative/reporting; actual final normalized/plan/ledger/summary/run/manifest/report, baseline/native and conditional logs, full alternative, operator tables and three rendered PNGs; original raw and seal receipts. No credentials, reasoning or unrelated fresh projects read.

Completed: one independent stdlib raw projection and whole-plan physical/financial recurrence for both complete policies; actual frozen numeric CLI; additional full operator-table and alternative-action accounting. No candidate code is imported or run. Pure reviewer functions reused from the prior independent evaluator, not from candidate code. Exact commands/output/snapshots retained. Own first audit expected 9 changed scalar controls; actual 8 are correct because demand_shift already had C/week15 switched on. Initial false and source remain; an additive targeted audit explains/corrects this reviewer assumption. Do not call it candidate failure.

Pending evaluator work: independent source-only terminal/native/input binding and registered quote/row controls. Parent owns the sole base cold run. Keep D01/D02/D08-D10/F05 and E01 execution provenance unassessed; do not manufacture a total, good flag, or candidate omission. E01 executable definition and mathematical infeasibility are already verified, but delivered native logs are not independently terminal-authenticated in this phase.
''')

write('SOURCE-AUDIT.md', '''# Source and provenance observations

Object: snapshot/source, byte copies of the sealed eef74425dcd9 source; final delivery is snapshot/delivery. Source correctness was evaluated by code/data/control-flow inspection and exact whole-plan accounting, not source digests. snapshot-inventory.json records direct byte identity for these copies. handoff-checks.json additionally compares the candidate's retained cold source files directly with the sealed root source; this identifies which source was supplied, not whether it ran correctly.

reproduce.py:19-38 parses input/output and real staged solver options, rejects an existing output, reads load_facts(args.input) and writes newly decoded normalized facts. It does not read old result/model/plan/reference or evaluator files. Lines48-76 compute a fresh CP-SAT feasible initialization, improve each continuation with its common prefix fixed, then call a fresh unrestricted joint HiGHS model with only a freshly computed hint. Conditional bounds are explicitly labelled nonglobal. Lines82-111 simulate exact actions, export a full ledger, actually request the JIT baseline solve, construct/check a full alternative, render figures and report. Final run/manifest retain actual parameters and terminal descriptions. README declares the same stages and numeric solver limits; those are candidate algorithm parameters, not user task budgets.

src/facts.py joins all twelve raw files by explicit catalogue indices and business identities, retaining units, prices, package sizes, lead times, allowed routes, BOM, probabilities, capacities and facility terms. Independent normalized comparison establishes all registered raw values, rather than accepting the source map by name alone. Source map + DATA + public OUTPUTS give the four required fact groups and units.

src/model.py:9-107 constructs one joint model. Shared action keys implement weeks0-3 nonanticipativity; lead-time/package bounds, supplier MOQ/shared capacity and freight switches, qualified plant shared hours, material and FG recurrences, raw-after-arrival/FG-after-production peaks, zero terminal FG/in-transit, delayed per-scenario cash and terminal cash are explicit. Nonnegative weekly cost and finite money boxes are safe here: initial cash + available credit + all receipts bounds spend and cash with nonnegative costs. Scenario numerators scale one integer objective, divided by the common probability denominator on reporting.

src/warm_solver.py:10-62 exports that same CpModel proto's objective, boxes and unconditional interval linear rows to HiGHS. Only action variables need integer declaration because the other variables are uniquely integer affine recurrences of integer actions. Native rounded actions are checked by the exact accounting program; they are not trusted solely because the numerical MIP solver accepts them. The source rejects unsupported nonlinear/reified export forms. This is a staged algorithm over one business model, not a cached fallback or competing business implementation.

src/accounting.py recomputes arrival/production/material/inventory/stage peaks, supplier volume, costs, delayed cash and AR from facts and actions, with Fraction expectation, without importing native solver state. The review additionally uses independent review code and the frozen checker, not only this candidate self-check. src/alternative.py constructs a distinct full action policy, preserving common prefix and testing whole-policy legality. Actual final moves are B/week13/R0 one10-unit package to C/week15 per scenario, preserving arrivals/production/inventory, delaying payment and paying the correct extra freight.

src/reporting.py was read through the full export/figure/report path. Curves/bars come from ledger fields. Report hardcoded business examples are correct for this registered instance; the raw-derived values and complete table agree with independent recomputation. This phase does not certify arbitrary unregistered structural inputs or unknown business universes. The candidate's self-run +7 quote perturbation is candidly distinguished from the evaluator's registered +1 quote control and cannot close D02.

Actual delivered metadata is internally consistent: primary HiGHS1.8 Time limit reached/resource_limit, cost47641.5, numerical bound47431.4, no exact optimum; initial CP-SAT first feasible49264.4; three conditional bounds labelled conditional; baseline native Infeasible with null cost/bound; alternate constructive completed with native_solver=null. The logarithmic and JSON files are candidate-delivered process evidence. Independent evaluator terminal/input/source binding remains outstanding, so D08-D10 are not yet granted.

No substantive source/report/data contradiction found in this inspected scope. This statement does not close actual source-only execution, registered control behavior, general software correctness, or the 47-leaf grade.
''')

visual = {
 'format': 'independent-rendered-figure-review/1',
 'reviewer': '/root/benchmark_review',
 'method': 'Actual tools.view_image display of the three final PNGs during this phase; no UI automation or text-only surrogate.',
 'figures': [
  {'path':'snapshot/delivery/figures/cash.png','actual_viewed':True,'observation':'Two readable panels: per-scenario cash and receivables, weeks and minor-currency units, floor -5369, legend and revelation boundary. AR is visibly separate from available cash. Independently recomputed cash/AR ledger matches its source data.'},
  {'path':'snapshot/delivery/figures/procurement.png','actual_viewed':True,'observation':'Three scenario panels, stacked order-volume bars by supplier, week0-15 and volume units, legend and disruption window readable. This is order-week volume, not arrivals; A disruption zeros match independently recomputed supplier volumes.'},
  {'path':'snapshot/delivery/figures/warehouse.png','actual_viewed':True,'observation':'Six scenario/raw-FG panels distinguish stage peak, end inventory and physical cap240/100, with readable units and legends. Values use exact full ledger and are consistent with the inspected report peaks; low end stock is not portrayed as a stage-capacity substitute.'}
 ],
 'limits':'Visual accuracy/readability of these delivered figures, not product UI or a statistical visual test. No new solver or image generation.'
}
save('manual-visual-review.json', visual)

source_ev = ev('SOURCE-AUDIT.md','source_audit','entry, model, exporter, accounting, alternative and report paths','Source reads raw, computes fresh model and outputs; no old answer read observed. Actual process closure remains pending.')
oracle_ev = ev('arithmetic-assessment-current.json','business_oracle','C/gap/alternate; see primary-independent.json, alternative-independent.json and checks.json','Exact independent cumulative raw/action accounting for full primary and alternate, complete ledgers and summaries.')
handoff_ev = ev('handoff-checks.json','business_oracle','all960_operator_rows_exact; all48_whole_weekly_rows_exact; printed_common_week_0..3','All actionable instructions and whole-week tables reconstructed from raw and plan; repeated supplier truck switch is not summed per raw.')
report_ev = ev('snapshot/delivery/report.md','candidate_artifact','named report sections and full numeric tables','Actual final report read with all delivered materials; no candidate PASS or file presence used as scoring proof.')
readme_ev = ev('snapshot/source/README.md','candidate_artifact','Execution; method; operator contract; declared staged defaults','Readable cold-run instructions and algorithm/resource disclosure exist; successful independent execution is not yet authenticated.')
run_ev = ev('snapshot/delivery/run.json','candidate_artifact','native_solver,algorithm,phases,parameters,command,timing','Sealed self-delivered process metadata internally matches logs and source; not an independently closed evaluator execution.')

findings = []
def finding(i, judgement, observation, evidence):
    findings.append({'id':i,'judgement':judgement,'observation':observation,'evidence':evidence})

finding('D01','unassessed','The sealed source/output and fresh raw-only path have been inspected. Parent owns the pending independent source-only evaluator run; no natural terminal from that run has been accepted in this phase. This is missing evaluator evidence, not candidate0.',[source_ev,readme_ev])
finding('D02','unassessed','Candidate self-runs use shuffled rows and C/R0 +7 and are clearly labelled self-controls. The frozen evaluator registered +1 quote and exact row-reversal controls have not yet been independently completed/accepted here. Do not substitute the self-controls or a valid variant witness.',[source_ev,ev('snapshot/source/DELIVERY.md','candidate_artifact','Final same-source controls paragraph','Candidate explicitly distinguishes its own quote control from evaluator values.')])
finding('D07','full','All four fact groups have accurate raw-file identities, explicit index/join rules and unit mapping: raw/product/plant catalogues; supplier terms/quotes; BOM/routes; scenarios/demand/capacity/facility. Source mapping, DATA and normalized facts close the trace; independent raw projection confirms all actual values.',[ev('snapshot/delivery/source_mapping.json','candidate_artifact','all twelve raw file keys plus identity entry','Mappings agree with exact independent frozen raw projection.'),ev('snapshot/source/DATA.md','candidate_artifact','catalogue, business identity, quantity/currency/index definitions','Public source identities and units read with candidate map.'),oracle_ev])
for i, obs in [
 ('D08','Delivered native log/metadata says Time limit reached and resource_limit and does not claim exact optimum. Independently observed evaluator terminal/native association remains pending; not inferred from source or self-log.'),
 ('D09','Delivered report separates known feasible result, numerical solver bound and absence of exact proof; baseline nulls and unsuccessful experiments are honestly retained. This execution-evidence leaf awaits actual evaluator process evidence; no manufactured failure branch is required.'),
 ('D10','Delivered run/manifest specifies input /work/inputs, actual reproduce argv and staged parameters. Byte identity with retained cold source is checked, but evaluator real mounts/argv/terminal binding remains pending.')]:
    finding(i,'unassessed',obs,[run_ev,source_ev])
finding('E01','unassessed','Executable baseline is the entire same joint model plus zero FG end inventory every week. Independent raw arithmetic proves it infeasible: P0 only F0, week6 F0 capacity0 while demand10/10/11 and no prior FG allowed. Candidate retains baseline-solver.log (Infeasible), baseline.json (null objective/bound) and console metadata. These are delivered logs; this phase has not independently closed their native-process provenance. Keep the leaf unassessed until the evaluator baseline invocation is terminal, rather than penalizing an evaluator evidence gap or inventing a feasible baseline cost.',[ev('snapshot/delivery/baseline-solver.log','candidate_artifact','Presolve Infeasible / Solving report','Retained candidate native artifact read; not a newly executed reviewer solve.'),ev('snapshot/delivery/baseline.json','candidate_artifact','restrictions.just_in_time; native_solver.status/objective/bound','Correct executable JIT definition and honest null cost/bound.'),source_ev,oracle_ev])
finding('E02','full','Report correctly identifies P0/F0 week6, same-week capacity0 and required prior stock10/10/11. It also explains P3/F1 week9 upper3 (10h/3h), giving required excess through the demand table and formula. Actual prior inventory2/1/2 may exceed necessary1/1/2; it is not mislabelled a unique minimum. Independent raw/ledger arithmetic confirms both bottlenecks.',[report_ev,oracle_ev])
finding('E03','full','A disruption capacity15 is below MOQ20 in orderweeks6-8, excluding its arrivalsweeks7-9; B has lead2 and discrete max70, C is contemporaneous expensive capacity30. Report and DELIVERY explain prebuy/buffer plus C use, distinguish order and arrival windows, avoid sole-cause trajectory claims, and give a complete verified alternative. Independent interruption check finds demand raw-equivalent367, new-arrival upper300 and required prior buffer67; actual87.',[report_ev,ev('snapshot/source/DELIVERY.md','candidate_artifact','immediate execution/interruption operating instructions','Complete actionable explanation includes raw-equivalent67 minimum buffer and observed87.'),oracle_ev])
finding('E04','full','All three scenarios minimum cash -5369 at week3, credit slack0, are correctly located. Report gives exact delayed-receipt/cost recursion, explains no receipts in first4weeks, locates ledger/weekly fields and distinguishes AR from spendable cash. Independently recomputed final cash32307/31352/32907 and AR24150/24150/25230 agree. Closed explanation does not require copying every ledger value.',[report_ev,oracle_ev,handoff_ev])
finding('E05','full','Largest expected component is purchase180742/5=36148.4, share361484/476415≈75.88% of47641.5. Other components5286,29004/5,4063/10 close exactly. Actions/units/package and source map trace purchase cost to full supplier orders; explanation includes whole-package, freight, lead-time and holding tradeoffs.',[report_ev,oracle_ev,handoff_ev])
finding('E06','full','A distinct full policy is independently feasible and costs95839/2=47919.5. It moves one10-unit R0 package per scenario from B/week13 to C/week15; receipts/production/inventory remain equal, payment/commitment moves2weeks later. Premiums290/290/230 and expected278 match whole-policy calculation. demand_shift already had that C truck, so no extra freight there; late flexibility does not improve week3 liquidity.',[report_ev,oracle_ev,ev('handoff-checks.json','business_oracle','exact_reported_spot_move_*; all_three_cost_premiums_and_expected278','All actual alternative controls and costs checked, not a prose-only strategy.')])
finding('F01','full','All common weeks0-3 procurement packages, shared truck switches and qualified per-plant production are accurately locatable in report, complete plan and operator table. Catalogue IDs/indices, units, zero-based weeks and common information set are explicit; four printed rows and all operator rows match the actual plan. Repeated truck switch per raw is explicitly one supplier-week instruction.',[report_ev,handoff_ev,readme_ev])
finding('F02','full','At the start of week4 choose actual scenario ID and execute its complete remaining policy; orders already placed keep their lead-time arrivals. All three post-reveal branches have complete action rows and plan tensors with correct units/identities and information-set flags. Both policies preserve the common prefix, and text says select one complete policy, not splice them.',[report_ev,handoff_ev,readme_ev])
finding('F03','full','Report/README/DELIVERY honestly separate feasible time-limited incumbent, conditional versus global numerical bounds, and lack of rational or exact-optimal proof; external score/reference unknown. It correctly separates AR and cash, failed earlier policies, finite self-control scope and tradeoff limits, and warns self-run intervals overlap rather than summing them. Numerical native gap is not substituted for evaluator fixed47380 quality.',[report_ev,readme_ev,run_ev,oracle_ev])
finding('F04','full','Actual tools.view_image display of all three final PNGs shows readable scenario labels, axes/units and legends for cash/AR, supplier order volumes, stage peaks/end inventory/caps. Curves/bars agree with exact source ledger and inspected report; input/figure data are not accepted by filename alone.',[ev('manual-visual-review.json','rendered_figure','all three actual_viewed records','Actual rendered pixels viewed; independent ledger reconstruction and source figure mapping confirm the data.'),oracle_ev])
finding('F05','unassessed','README includes dependencies/image, correct raw/source command, new output requirement and real default stage limits. Actual another-executor source-only rebuild is still parent-owned/pending in this phase. Do not treat candidate self-rebuild, clean source inspection or an active launch as a completed independent reconstruction.',[readme_ev,source_ev])

rubric = json.loads((ROOT/'snapshot/rubric.json').read_text(encoding='utf-8'))
expected = {x['id'] for g in rubric['groups'] for x in g['criteria'] if x['method'] in ('independent_review','source_only_replay','input_variation','execution_evidence')}
assert len(expected) == 17 and {x['id'] for x in findings} == expected
review = {
 'format':'l06-review-evidence/1','case':'L06','submission_id':SUBMISSION_ID,
 'rater':{'id':'independent-agent-/root/benchmark_review','role':'independent_evaluator','assignment':'Parent-authorized one-level independent Codex eef74425dcd9 actual sealed-delivery phase-one evaluation. Nonblind AI agent familiar with reference, development calibration and prior OpenCorvus outcome. No delegation. No professional-human/statistical/hours certification.'},
 'artifact_bindings':{'input':str(SUB/'inputs'),'normalized':str(DEL/'normalized.json'),'plan':str(DEL/'plan.json'),'summary':str(DEL/'summary.json'),'ledger':str(DEL/'ledger.json')},
 'findings':findings
}
save('independent-review-phase1.json',review)
for k,p in review['artifact_bindings'].items():
    assert Path(p).exists(), (k,p)
for f in findings:
    assert f['evidence']
    for e in f['evidence']:
        assert (ROOT/e['path']).resolve().is_relative_to(ROOT.resolve())
        assert (ROOT/e['path']).is_file()
counts=dict(Counter(f['judgement'] for f in findings))
initial=json.loads((ROOT/'arithmetic-assessment.json').read_text(encoding='utf-8'))
handoff=json.loads((ROOT/'handoff-checks.json').read_text(encoding='utf-8'))
checks=json.loads((ROOT/'checks.json').read_text(encoding='utf-8'))
status=subprocess.run(['git','status','--short'],cwd=REPO,capture_output=True,text=True,encoding='utf-8')
write('git-status-end.txt',status.stdout+status.stderr)
save('git-status-end-command.json',{'argv':['git','status','--short'],'cwd':str(REPO),'exit_code':status.returncode,'note':'Read-only repository status at phase-finalization; unrelated workspace changes retained. No repository file changed by reviewer.'})
stage={
 'format':'independent-stage-assessment/1','case':'L06/0.2.0','stage':'Codex sealed final delivery phase1',
 'submission_id':SUBMISSION_ID,'candidate_head':'eef74425dcd9b9d6e161c9aa303b38c90f400e25',
 'review_counts':counts,'numeric_counts':{'verified_pass':30,'unassessed':17},
 'unassessed_review_leaves':[f['id'] for f in findings if f['judgement']=='unassessed'],
 'candidate_business_defects_found':[],
 'phase_evidence_gaps':['Independent source-only base terminal/native/source/argv authentication','Registered quote and row controls','E01 actual evaluator baseline receipt'],
 'exact_primary_cost':'95283/2','fixed_reference_L':47380,'quality_gap_exact':'523/94760','quality_gap_percent':0.5519206416209371,
 'exact_alternative_cost':'95839/2','alternative_cost_increment':278,
 'actual_independent_work':{'original_checks':20,'original_checks_true':19,'reviewer_count_assumption_false':1,'additional_targeted_checks':len(handoff),'additional_targeted_checks_true':sum(x['passed'] for x in handoff),'current_independent_assertions_true':19+len(handoff),'operator_rows':960,'complete_weekly_rows':48,'full_policies_recomputed':2,'rendered_figures_actually_viewed':3,'numeric_cli_seconds':0.18165550008416176},
 'initial_false_retained':'checks.json/arithmetic-assessment.json/audit_phase1.py retain len(diffs)==9; actual8 due to previously active demand_shift C/week15 truck. handoff-checks explains and validates all actual moves. No candidate penalty.',
 'accounting_timing_scope':'Original audit .7961186s includes snapshot, raw/accounting and numeric; extra handoff receipt records actual argv/exit but no independently recorded elapsed time. Do not invent duration or call this candidate runtime.',
 'independent_review_file':'independent-review-phase1.json','total_score':None,'business_success':None,'good':None,
 'model_identity':None,'model_usage':None,'comparable':False,
 'reviewer_limit':'Nonblind AI agent with prior reference/OpenCorvus familiarity; no professional-human or statistical certification.',
 'forbidden_actions_performed':{'new_solver':0,'candidate_program':0,'Provider':0,'Docker':0,'GPU':0,'UI_automation':0,'delegation':0,'user_process_operations':0,'repository_edits':0},
 'completed_utc':datetime.now(timezone.utc).isoformat()
}
save('stage-assessment-phase1.json',stage)
write('REVIEW-PHASE1.md','''# Codex L06/0.2.0 independent phase-one review

The sealed final delivery has no identified business/reporting defect in the inspected scope. The actual frozen numeric CLI passed all30 numeric leaves; this phase grants10 review leaves full and leaves7 unassessed. There is no total score, business-success or good decision. Missing evaluator execution evidence is not candidate0.

This is a nonblind AI-agent review by /root/benchmark_review, already familiar with the reference, component calibration and prior OpenCorvus result. It is not professional-human review, statistical reliability evidence, a controlled same-model comparison, or effective-hours certification. Candidate actual model/usage are unknown and comparable=false.

## Exact objects and evidence

Candidate HEAD eef74425dcd9b9d6e161c9aa303b38c90f400e25, naturally completed according to the parent seal. The designated final delivery is `validation/source-only-reordered/result`; early delivery-v1/v2 are not graded. The stable submission ID is `codex-L06-eef74425dcd9-phase1`. Five actual original bindings and17 leaf-specific observations/evidence are in `independent-review-phase1.json` (l06-review-evidence/1). `snapshot/receipts/seal-receipt.json`, source/data/output copies and direct byte-copy inventory preserve the reviewed object. Byte checks establish object identity only, not correctness.

`audit_phase1.py` independently projects all frozen raw and recomputes the two complete policies with a reviewer's cumulative integer/Fraction oracle. It imports no candidate program or solver. It also invokes the actual frozen l06_numeric.py on the sealed five paths. `numeric-command.json`, actual stdout/stderr and numeric-delivered.json preserve the exit0 result:30 verified_pass,17 unassessed,totalnull. No candidate PASS was accepted as an oracle.

Primary expected cost is95283/2=47641.5. Against the unchanged registered L47380, (C-L)/L=523/94760≈0.55192064%, so this delivered policy meets C06 independently of its own numerical bound47431.4. Scenario costs47043/47998/48603 and all complete ledgers/summaries match the reviewer. All scenarios attain minimum cash−5369 at week3; final cash32307/31352/32907 and final AR24150/24150/25230 are correct. Expected purchase36148.4 is the largest component, exact share361484/476415≈75.88%.

The complete alternative costs95839/2=47919.5, an expected278 premium. Actual B/week13 R0−one10-unit package and C/week15 +ten1-unit packages per scenario preserve arrival/production/inventory, defer payment2weeks and incur290/290/230. It is feasible; no unique optimum or causal trajectory is required. `check_handoff_and_alternative.py` independently validates all960 action rows,48 complete week rows, four common tables, every changed alternative control and candidate saved-source identity.

The original audit had20 assertions,19 true and one reviewer mistake: expected9 scalar action changes. Actual8 are right because demand_shift already had C/week15 truck on. Initial source/false receipt remain;12 additive targeted checks all pass and explain the discrepancy. Current substantive evidence therefore comprises19 original valid assertions plus12 additional assertions, not a quietly rewritten original pass. `arithmetic-assessment-current.json` retains the original `checks:20` metadata; authoritative actual counts and correction are explicit in stage-assessment-phase1.json and handoff-checks.json.

`SOURCE-AUDIT.md` records actual code paths and mathematical coverage. The method creates a fresh joint model, fresh initial feasible policy, conditional scenario improvements and a final unrestricted joint search; only fresh in-invocation hints are used. Full exact accounting follows. Conditional bounds are explicitly nonglobal. `manual-visual-review.json` records actual tools.view_image display of cash.png, procurement.png and warehouse.png, all readable with correct units/scenarios/legends and ledger-consistent values.

## Seventeen review leaves

Full: D07; E02,E03,E04,E05,E06; F01,F02,F03,F04. Each finding points to the actual report/source/table/independent arithmetic or viewed PNG. Complete JSON/CSV/report information is assessed together without enforcing reference format or action IDs.

Unassessed: D01,D02,D08,D09,D10,E01,F05. Source-only correctness/registered controls and evaluator process/native/parameter association await parent-owned actual runs. README dependencies/entry/options are explicit; a launch alone does not close F05. Candidate shuffled-row and +7 own-price runs do not replace the registered evaluator +1 quote and row controls. For E01 the executable JIT baseline and its infeasibility are independently correct (week6 P0/F0 capacity0 with positive demand), and candidate native baseline logs are retained. Its actual native process provenance has not yet been independently closed, so this phase leaves E01 unassessed rather than subtracting for missing evaluator evidence. No feasible baseline cost is invented.

The candidate reports Time limit reached/resource_limit, lack of exact proof, failed earlier experiments, finite self-control scope and overlapping self-run intervals honestly. Those support semantic F03; they do not automatically authenticate execution leaves. Internal solver seconds are candidate algorithm settings, not a user task total budget. No candidate runtime or effective-hours claim is inferred from the subsecond reviewer arithmetic.

## Scope and next evidence

No actual candidate defect warrants a zero/half or critical failure from this phase. Close only the pending leaves with real independent base and registered same-source quote/row results, preserve this phase file, then invoke the actual grader; never handwrite a total. Parent owns the sole active base evaluation; this reviewer launched no candidate, solver, Provider, Docker, GPU or user process, and did not edit repository/shared files or delegate. The benchmark's other nine upgrades, broader maturity and hours are outside this assessment.
''')
save('phase1-schema-and-evidence-check.json',{'review_format':review['format'],'findings':len(findings),'expected_ids_exact':True,'counts':counts,'five_actual_bindings_exist':True,'all_private_evidence_resolves_within_root':True,'total_score_computed':False,'grade_cli_called':False,'source_oracle_note':'This is a structural/path check of the reviewers actual ratings, not proof their scientific judgment is true.'})
print(json.dumps({'review':str(ROOT/'independent-review-phase1.json'),'report':str(ROOT/'REVIEW-PHASE1.md'),'counts':counts,'numeric_verified_pass':30,'score':None,'candidate_defects_found':[]},ensure_ascii=False))
