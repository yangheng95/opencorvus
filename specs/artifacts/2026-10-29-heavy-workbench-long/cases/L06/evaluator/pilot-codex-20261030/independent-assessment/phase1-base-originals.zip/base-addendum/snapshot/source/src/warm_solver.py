"""Sequential primal initialization and linear branch-and-cut on one model."""
import time
from pathlib import Path
import numpy as np
import highspy
from scipy.sparse import coo_matrix
from ortools.sat.python import cp_model


def solve_warm(model, actions, n, output, label, seconds, gap, workers, just_in_time, reserve, hint=None, warm_seconds=120):
    proto = model.proto
    size = len(proto.variables)
    lp = highspy.HighsLp()
    lp.num_col_ = size
    lp.num_row_ = len(proto.constraints)
    # pybind array properties return copies: assign once after constructing costs.
    objective = np.zeros(size)
    for variable, coefficient in zip(proto.objective.vars, proto.objective.coeffs):
        objective[variable] += coefficient
    lp.col_cost_ = objective
    lp.col_lower_ = [v.domain[0] for v in proto.variables]
    lp.col_upper_ = [v.domain[1] for v in proto.variables]
    rows, cols, values, lo, hi = [], [], [], [], []
    for i, constraint in enumerate(proto.constraints):
        if len(constraint.enforcement_literal) or len(constraint.linear.domain) != 2:
            raise ValueError("LINEAR_EXPORT: expected unconditional convex linear constraint")
        for variable, coefficient in zip(constraint.linear.vars, constraint.linear.coeffs):
            rows.append(i)
            cols.append(variable)
            values.append(coefficient)
        a, b = constraint.linear.domain
        lo.append(-highspy.kHighsInf if a <= -(2**62) else a)
        hi.append(highspy.kHighsInf if b >= 2**62 else b)
    matrix = coo_matrix((np.asarray(values, dtype=float), (rows, cols)), shape=(len(lo), size)).tocsc()
    lp.row_lower_, lp.row_upper_ = lo, hi
    lp.a_matrix_.format_ = highspy.MatrixFormat.kColwise
    lp.a_matrix_.start_ = matrix.indptr.astype(np.int32)
    lp.a_matrix_.index_ = matrix.indices.astype(np.int32)
    lp.a_matrix_.value_ = matrix.data
    integrality = [highspy.HighsVarType.kContinuous] * size
    hint_indices, hint_values = {}, {}
    def mark(items, numbers=None):
        for i, item in enumerate(items):
            if isinstance(item, list):
                mark(item, numbers[i] if numbers is not None else None)
            else:
                integrality[item.index] = highspy.HighsVarType.kInteger
                if numbers is not None:
                    hint_indices[item.index] = item.index
                    hint_values[item.index] = numbers[i]
    for sid, decisions in actions.items():
        for key, value in decisions.items():
            mark(value, hint["decisions"][sid][key] if hint is not None else None)
    lp.integrality_ = integrality
    high = highspy.Highs()
    parameters = {"time_limit": seconds, "mip_rel_gap": gap, "presolve": "on", "threads": workers,
                  "random_seed": 20261030, "log_to_console": False,
                  "log_file": str(Path(output) / f"{label}-solver.log")}
    for key, value in parameters.items():
        if high.setOptionValue(key, value) != highspy.HighsStatus.kOk:
            raise RuntimeError(f"HIGHS_PARAMETER_ERROR: {key}")
    if high.passModel(lp) != highspy.HighsStatus.kOk:
        raise RuntimeError("HIGHS_MODEL_ERROR")
    warm = None
    supplied_solution = False
    if not just_in_time and warm_seconds > 0:
        seed = cp_model.CpSolver()
        warm_parameters = {"max_time_in_seconds": warm_seconds, "num_search_workers": 8,
                           "random_seed": 20261030, "relative_gap_limit": gap,
                           "log_search_progress": True, "log_to_stdout": False}
        for key, value in warm_parameters.items():
            setattr(seed.parameters, key, value)
        with (Path(output) / f"{label}-initialization.log").open("w", encoding="utf-8") as stream:
            seed.log_callback = lambda message: (stream.write(message + "\n"), stream.flush())
            seed_status = seed.solve(model)
        feasible_seed = seed_status in (cp_model.OPTIMAL, cp_model.FEASIBLE)
        warm = {"parameters": warm_parameters, "name": "OR-Tools CP-SAT", "status": seed.status_name(seed_status),
                "objective_minor": seed.objective_value/n["probability_denominator"] if feasible_seed else None,
                "best_bound_minor": seed.best_objective_bound/n["probability_denominator"] if feasible_seed else None,
                "wall_time_seconds": seed.wall_time, "response_stats": seed.response_stats()}
        if feasible_seed:
            native_solution = highspy.HighsSolution()
            native_solution.col_value = list(seed.response_proto.solution)
            native_solution.value_valid = True
            if high.setSolution(native_solution) != highspy.HighsStatus.kOk:
                raise RuntimeError("HIGHS_INITIAL_SOLUTION_ERROR")
            supplied_solution = True
    if not supplied_solution and hint_values:
        indices = np.asarray(list(hint_indices), dtype=np.int32)
        values_array = np.asarray([hint_values[i] for i in indices], dtype=float)
        if high.setSolution(len(indices), indices, values_array) != highspy.HighsStatus.kOk:
            raise RuntimeError("HIGHS_PARTIAL_INITIAL_SOLUTION_ERROR")
    start = time.monotonic()
    return_code = high.run()
    elapsed = time.monotonic()-start
    state = high.getModelStatus()
    info = high.getInfo()
    solution = high.getSolution()
    feasible = info.primal_solution_status == highspy.SolutionStatus.kSolutionStatusFeasible
    den = n["probability_denominator"]
    native = {"name": "HiGHS", "version": high.version(), "status": high.modelStatusToString(state),
              "return_code": str(return_code), "objective_minor": info.objective_function_value/den if feasible else None,
              "best_bound_minor": info.mip_dual_bound/den if feasible else None,
              "objective_numerator": round(info.objective_function_value) if feasible else None,
              "best_bound_numerator": info.mip_dual_bound if feasible else None,
              "native_mip_gap": info.mip_gap if feasible else None, "node_count": info.mip_node_count,
              "measured_solve_seconds": elapsed}
    completed = state in (highspy.HighsModelStatus.kOptimal, highspy.HighsModelStatus.kInfeasible)
    limited = state in (highspy.HighsModelStatus.kTimeLimit, highspy.HighsModelStatus.kIterationLimit, highspy.HighsModelStatus.kSolutionLimit)
    exact = feasible and state == highspy.HighsModelStatus.kOptimal and abs(info.objective_function_value-info.mip_dual_bound) < 0.5
    metadata = {"parameters": parameters, "native_solver": native, "initialization": warm,
                "algorithm": {"name": "fresh CP-SAT primal initialization then HiGHS linear branch-and-cut on one joint model",
                              "termination_kind": "completed" if completed else "resource_limit" if limited else "failed",
                              "termination_detail": high.modelStatusToString(state) + (" at configured nonzero MIP tolerance; no strict optimum claim" if state == highspy.HighsModelStatus.kOptimal and not exact else "")},
                "feasibility": "feasible" if feasible else "infeasible" if state == highspy.HighsModelStatus.kInfeasible else "unknown",
                "exact_integer_optimum": exact, "restrictions": {"just_in_time": just_in_time, "reserve": reserve}}
    if not feasible:
        return None, metadata
    max_rounding = 0
    def values(items):
        nonlocal max_rounding
        result = []
        for item in items:
            if isinstance(item, list):
                result.append(values(item))
            else:
                value = solution.col_value[item.index]
                max_rounding = max(max_rounding, abs(value-round(value)))
                result.append(round(value))
        return result
    plan = {"format": "l06-plan/1", "decisions": {sid: {key: values(value) for key, value in decisions.items()} for sid, decisions in actions.items()}}
    metadata["maximum_action_rounding"] = max_rounding
    if max_rounding > 1e-4:
        raise ValueError(f"NONINTEGRAL_NATIVE_ACTION: {max_rounding}")
    return plan, metadata
