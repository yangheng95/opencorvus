"""Append newly authenticated base execution findings; no grading/solver."""
from collections import Counter
from datetime import datetime, timezone
import copy
import json
from pathlib import Path
import subprocess

ROOT=Path(__file__).resolve().parent
def load(name):return json.loads((ROOT/name).read_text(encoding='utf-8-sig'))
def save(name,v):(ROOT/name).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def ev(path,kind,locator,observation):
    assert (ROOT/path).is_file(),path
    return {'path':path,'kind':kind,'locator':locator,'observation':observation}

original=load('independent-review-phase1.json'); review=copy.deepcopy(original)
process=ev('base-addendum/snapshot/terminal-inspect.json','process_receipt','Id/State/Config/Mounts/HostConfig','Actual root-owned independent evaluator base naturally exited0; readonly source/raw, fresh writable results, networknone8CPU; new output archive and stdout are independently read.')
launch=ev('base-addendum/snapshot/launch.json','process_receipt','command/source_files/exitcode/stdout','Exact CID and real source-only argv bind the run; sole12 source/docs/dependency/test files match sealed source bytes.')
audit=ev('SOURCE-AUDIT.md','source_audit','reproduce/model/export/accounting/report entry','Previously inspected same sealed source creates fresh raw-derived model and fresh same-invocation incumbents, not old result reads.')
business=ev('base-addendum/arithmetic-and-process-assessment.json','business_oracle','all28 checks / costs / fixed gap / native vs exact distinctions','Full independent new primary and alternative raw/action ledger/summary recurrence passed; real numeric CLI source/input/output association checked.')
checks=ev('base-addendum/checks.json','source_audit','all12mounted_source_files_match_actual_sealed; raw/command/dependencies/native/baseline/archive checks','Actual cold source/data/output/process artifacts inspected;57 archive member bytes and12 source files match declared objects without correctness-by-checksum.')
run=ev('base-addendum/snapshot/results/base/run.json','process_receipt','command/dependencies/parameters/phases/native_solver/comparison_runs/timing','This JSON is now bound to the actual independent base process and its stdout/native logs, not treated as self-authenticating metadata.')
notes={
 'D01':('full','Actual independent evaluator source-only base succeeded from only12 sealed source/docs/dependency/test files and the frozen raw packet; project/raw readonly, new results writable, networknone8CPU. Natural exit0 and complete new outputs are archived. Independently recomputed primary47616.7 and full alternative47880.7 are feasible with exact ledgers/summaries; different actions from sealed delivery are accepted. No old results/model/hint/reference was mounted.',[process,launch,audit,business,checks]),
 'D08':('full','Actual independent primary native HiGHS1.8 log says Time limit reached, feasible objective476167/10 and native bound473887/10. run algorithm resource_limit, no exact optimum, console and log agree; conditional scenario bounds remain labelled conditional. Baseline Infeasible/completed and constructive alternate completed/null native solver are also tied to this terminal run.',[process,run,business,ev('base-addendum/snapshot/results/base/primary-solver.log','process_receipt','final Solving report','True status Time limit reached, primal476167, dual473887, integer/row violations0,16513 nodes; raw native numerical result, not exact rational certificate.')]),
 'D09':('full','The actual primary obtained a feasible policy and native numerical bound and reports both honestly with no exact optimum. Actual JIT baseline is Infeasible and its objective/bound are null, not fabricated numbers. The alternate is a complete constructive feasible policy without optimum claim. No additional artificial failing branch is required. Exact fixed47380 quality remains independent of the native47388.7 bound.',[process,run,business,ev('base-addendum/snapshot/results/base/baseline.json','process_receipt','native_solver status/objective/bound; algorithm','Actually executed baseline infeasible with honest null primal/bound, not an asserted baseline cost.')]),
 'D10':('full','Actual working directory /project, executable /opt/cpsat/bin/python, raw /raw and new /results/base match run/manifest. Dependencies match Python3.11.13,NumPy2.4.6,SciPy1.15.3,ORtools9.15.6755,Matplotlib3.10.3,HiGHS1.8.0. Real default stages were600s8worker initial-first-feasible,3x180s1thread conditional,300s1thread unrestricted, gap.001 and seed20261030; these are candidate solver parameters, not user total budgets.',[process,launch,run,checks]),
 'E01':('full','The previously mathematically verified executable JIT baseline is now actually reached within the independently completed raw/source reproduction: same full joint model plus zero end-FG every week. Fresh baseline.json and native baseline-solver.log record presolve Infeasible in.0030178s and null cost/bound. Week6 P0 has positive10/10/11 demand but its sole qualified F0 has0hours and JIT prevents prior stock, independently proving the same infeasibility. Correctly no feasible baseline cost is invented.',[process,audit,business,ev('base-addendum/snapshot/results/base/baseline-solver.log','process_receipt','Presolve Infeasible / final Solving report','Fresh native baseline file is a member of the sealed output of the actual completed independent execution.')]),
 'F05':('full','Another executor actually followed the README default raw/source command with its declared dependency image and a new output directory. No dependency/command amendment was needed. The evaluator mounted only source/raw, completed naturally and produced normalized/plan/ledger/summary/run/manifest/report/three actual PNGs plus executable baseline and full alternative, independently verified. Reconstruction need not reproduce identical optimizer decisions.',[process,launch,audit,business,ev('snapshot/source/README.md','candidate_artifact','Execution + staged default method','Exact instructions used by the actual independent executor, rather than a proposed or active launch.')])
}
for f in review['findings']:
    if f['id'] in notes:
        judgement,observation,evidence=notes[f['id']]
        f.update(judgement=judgement,observation=observation,evidence=evidence)
review['rater']['assignment']+=' Base terminal addendum: only six findings supported by newly authenticated independent source-only base are updated; original phase1 file retained. D02 registered controls remain unassessed.'
assert len(notes)==6
counts=dict(Counter(f['judgement'] for f in review['findings']))
assert counts=={'full':16,'unassessed':1} and next(f for f in review['findings'] if f['id']=='D02')['judgement']=='unassessed'
assert review['artifact_bindings']==original['artifact_bindings'] and review['submission_id']==original['submission_id']
for f in review['findings']:
    for e in f['evidence']:
        assert (ROOT/e['path']).is_file() and (ROOT/e['path']).resolve().is_relative_to(ROOT.resolve())
save('independent-review-base-addendum.json',review)
save('base-addendum/actual-visual-review.json',{'method':'Actual tools.view_image opened all three new independent-base PNGs; rendered images shown to reviewer. No UI automation.','figures':[{'path':'base-addendum/snapshot/results/base/figures/cash.png','actual_viewed':True,'observation':'Readable scenario cash/AR panels with correct week/minor units, credit floor and information boundary. Week3 floor and final balances agree with exact fresh ledger.'},{'path':'base-addendum/snapshot/results/base/figures/procurement.png','actual_viewed':True,'observation':'All three scenario order-week supplier bars readable, IDs/volume/legend/disruption window correct, actual outage zeros and branch procurement differ appropriately.'},{'path':'base-addendum/snapshot/results/base/figures/warehouse.png','actual_viewed':True,'observation':'Six panels distinguish raw/FG stage peak, end inventory and cap240/100, with readable scenarios/units/legend. All fresh full ledger values were recomputed, and report peaks/cash/cost tables inspected.'}],'limitation':'These new figures support the actual completed reconstruction. Original F04 binding/phase1 observation remains the actual sealed submitted delivery.'})
arith=load('base-addendum/arithmetic-and-process-assessment.json')
save('stage-assessment-base-addendum.json',{'case':'L06/0.2.0','submission_id':review['submission_id'],'updated_leaves':list(notes),'review_counts':counts,'D02':'unassessed','real_root_numeric':{'verified_pass':30,'unassessed':17},'independent_base_checks':arith,'basis':'Same source successful reconstruction and full independent arithmetic, no forced reference policy or exact solver trajectory. Original five artifact bindings unchanged.','total_score':None,'business_success':None,'good':None,'candidate_defects_found':[],'new_solver_Docker_Provider_candidate_program_calls':0,'completed_utc':datetime.now(timezone.utc).isoformat()})
(ROOT/'BASE-COLD-ADDENDUM.md').write_text('''# Codex L06 base-cold independent addendum

The actual independent raw/source reconstruction is now verified. Six previously unassessed leaves D01,D08,D09,D10,E01,F05 become full. The additive legal review is `independent-review-base-addendum.json`, same stable submission ID and original sealed five artifact bindings. Phase1 JSON/report remain unchanged. Current17 review findings are16full and D02unassessed; no total/business-success/good decision is published or calculated.

## Actual process and source object

The root-owned CID b8af7d5f558d6c64923b19b4fd344df99cd6261e4795b3467c4b507cfcd80dbb naturally ran2026-10-30T01:26:50.364863071Z to01:41:38.140249409Z, exit0, no OOM/error. Container wall887.775386s, program self-monotonic885.699749s. Real argv was `/opt/cpsat/bin/python reproduce.py --input /raw --output /results/base` in /project. Terminal inspection confirms readonly /project and /raw, sole fresh writable /results, networknone,8CPU and dependency image sha256:23ff8bfbf8055caa0b9fa5745ddb27cceea2f31d7d15b7a900c81112cdfe8ddf. The image identity is an immutable dependency-resource identity, not a source-correctness gate.

All12 mounted files (10Python plusREADME andrequirements) directly match sealed eef74425dcd9 source. No old plan/model/output/reference/hint was mounted. The raw facts independently equal the original frozen packet. All57 source/raw/result archive members match the sealed new run object. Saved launch/terminal/native/stdout/argv bind the actual run, and cleanup records the same CID only after natural terminal and original sealing. This reviewer merely read these records and operated no container.

## Fresh business and native results

`audit_base_addendum.py` starts no candidate, solver, Docker or Provider. Its actual stdlib audit took.472348s and28 checks all pass, with command/stdout/stderr retained. Both complete new policies' material, package, qualification, shared capacities, information, stage storage, cash, terminal and cost rules pass independent cumulative arithmetic; complete ledger and summary match. Root's saved true numeric CLI exit0 is bound to these exact raw/new-output paths,30pass/17unassessed/totalnull.

Fresh primary cost476167/10=47616.7 differs from sealed delivery47641.5, which is allowed. Fixed registered L47380 yields2367/473800≈0.49957788%, meeting the same quality contract. Fresh full alternate cost478807/10=47880.7, premium264; its demand_shift branch uses A/week14 R2five units to C/week15 (one-week deferral), while the other two use B/week13 R0ten units to C/week15. Different correct policies/moves do not lose credit.

The actual unrestricted HiGHS native log reports Time limit reached, primal476167/den10, native numerical bound473887/den10=47388.7,16513nodes and feasible action incumbent. Run says resource_limit/exact_integer_optimumfalse. It correctly distinguishes prior conditional bounds from this global numerical bound. Actual default stage parameters are initial600s8worker first-feasible, each conditional180s1thread, final300s1thread and gap.001; these settings are the candidate's internal search choices, not a user task total allowance. Numerical solver bound is not called a rational certificate, and fixed L remains unchanged.

E01 provenance is now closed: fresh execution reached the baseline call, and fresh native log/JSON record JIT infeasible in.0030178s with null objective/bound. The already independent week6 P0/F0 contradiction confirms the same mathematical result; no fictional baseline cost is used. The source model's baseline is complete, not a printed failure string.

All three fresh PNGs were actually opened via view_image and inspected: cash/AR panels, scenario supplier order-volume bars and six-panel stage/end-stock/cap charts. Units, scenarios, legends and values are readable and consistent with the new exact full ledger and report. `base-addendum/actual-visual-review.json` records these actual views. This augments reconstruction evidence without replacing original submitted F04 observations.

## Remaining boundary

D02 remainsunassessed pending both real registered private +1 quote and row controls. Candidate self +7/shuffle runs and reference feasibility cannot substitute. No genuine candidate defect was found in this new scope. Source-only success/finite solver wall are not proof of user-level effective hours, controlled model-cost comparison, professional-human validation or suite maturity. Nonblind AI familiarity and unknown actual Codex model/usage remain disclosed. Do not handwrite a total; use the actual grader only after the outstanding evaluator controls and ratings close.
''',encoding='utf-8')
status=subprocess.run(['git','status','--short'],cwd='D:/myhexin-local/opencorvus',capture_output=True,text=True,encoding='utf-8')
(ROOT/'base-addendum/git-status-end.txt').write_text(status.stdout+status.stderr,encoding='utf-8')
save('base-addendum/review-file-check.json',{'findings':17,'counts':counts,'original_five_bindings_unchanged':True,'all_evidence_files_exist_within_private_root':True,'original_phase1_preserved':True,'grade_cli_called':False,'total_score_computed':False,'git_status_exit':status.returncode})
print(json.dumps({'review':str(ROOT/'independent-review-base-addendum.json'),'counts':counts,'D02':'unassessed','total_score':None},ensure_ascii=False))
