"""Human handoff, tables and figures generated only from checked integer ledgers."""
import csv
import json
from fractions import Fraction
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


def fraction(value):
    return Fraction(value["numerator"], value["denominator"]) if isinstance(value, dict) else Fraction(value)


def number(value):
    value = fraction(value)
    return str(value.numerator) if value.denominator == 1 else f"{value.numerator}/{value.denominator} ({float(value):.2f})"


def dump(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def exports(n, plan, ledger, directory):
    directory = Path(directory)
    with (directory / "actions.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["scenario", "week", "information_set", "action", "supplier_or_plant", "raw_or_product", "order_lots", "units", "truck_on", "arrival_week"])
        for sid, d in plan["decisions"].items():
            for t in range(n["weeks"]):
                info = "common_commitment" if t < n["common_weeks"] else sid
                for v, term in enumerate(n["suppliers"]):
                    for r, raw in enumerate(n["raw_materials"]):
                        lots = d["order_lots"][t][v][r]
                        writer.writerow([sid, t, info, "order", term["id"], raw, lots, lots*term["pack_units"][r], d["truck_on"][t][v], t+term["lead_weeks"]])
                for f, plant in enumerate(n["plants"]):
                    for p, product in enumerate(n["products"]):
                        writer.writerow([sid, t, info, "produce", plant, product, "", d["production"][t][f][p], "", ""])
    rows = [{"scenario": sid, **row} for sid, value in ledger["scenarios"].items() for row in value["weeks"]]
    with (directory / "weekly.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        for row in rows:
            writer.writerow({key: json.dumps(value) if isinstance(value, list) else value for key, value in row.items()})


def figures(n, ledger, directory):
    directory = Path(directory)
    directory.mkdir(exist_ok=True)
    ids = list(ledger["scenarios"])
    fig, axes = plt.subplots(2, 1, figsize=(11, 7), constrained_layout=True)
    for sid in ids:
        weeks = ledger["scenarios"][sid]["weeks"]
        axes[0].plot(range(n["weeks"]), [w["cash"] for w in weeks], marker="o", label=sid)
        axes[1].plot(range(n["weeks"]), [w["receivable"] for w in weeks], marker=".", label=sid)
    axes[0].axhline(-n["credit_limit_minor"], color="red", linestyle="--", label="credit floor")
    for ax, title in zip(axes, ["Weekly available cash (after receipts and expenses)", "Delivered but unpaid sales (not available cash)"]):
        ax.set(title=title, xlabel="Week (zero-based)", ylabel="Minor currency units", xticks=range(n["weeks"]))
        ax.axvline(n["common_weeks"]-0.5, color="gray", linestyle=":")
        ax.grid(alpha=.25)
        ax.legend(loc="best", fontsize=8)
    fig.savefig(directory / "cash.png", dpi=160)
    plt.close(fig)
    fig, axes = plt.subplots(len(ids), 2, figsize=(12, 3*len(ids)), constrained_layout=True, squeeze=False)
    for i, sid in enumerate(ids):
        weeks = ledger["scenarios"][sid]["weeks"]
        for j, key, volume, limit, title in ((0, "raw_stage_peak_volume", n["raw_volume"], n["raw_storage_volume"], "Raw: arrivals before production"),
                                            (1, "product_stage_peak_volume", n["product_volume"], n["product_storage_volume"], "Finished: made before delivery")):
            ax = axes[i][j]
            end_key = "raw_inventory" if j == 0 else "finished_inventory"
            ax.plot(range(n["weeks"]), [w[key] for w in weeks], marker="o", label="stage peak")
            ax.plot(range(n["weeks"]), [sum(a*b for a, b in zip(w[end_key], volume)) for w in weeks], linestyle="--", label="end inventory")
            ax.axhline(limit, color="red", linestyle=":", label="capacity")
            ax.set(title=f"{sid}: {title}", xlabel="Week", ylabel="Volume", xticks=range(n["weeks"]))
            ax.grid(alpha=.2)
            ax.legend(fontsize=8)
    fig.savefig(directory / "warehouse.png", dpi=160)
    plt.close(fig)
    fig, axes = plt.subplots(1, len(ids), figsize=(14, 4), constrained_layout=True, squeeze=False)
    for i, sid in enumerate(ids):
        weeks = ledger["scenarios"][sid]["weeks"]
        ax = axes[0][i]
        bottoms = [0]*n["weeks"]
        for v, term in enumerate(n["suppliers"]):
            values = [w["supplier_volume"][v] for w in weeks]
            ax.bar(range(n["weeks"]), values, bottom=bottoms, label=term["id"])
            bottoms = [a+b for a, b in zip(bottoms, values)]
        ax.set(title=sid, xlabel="Order week", ylabel="Ordered raw volume", xticks=range(n["weeks"]))
        ax.axvspan(5.5, 8.5, color="red", alpha=.08)
        ax.legend(title="Supplier", fontsize=8)
    fig.savefig(directory / "procurement.png", dpi=160)
    plt.close(fig)


def report(n, plan, ledger, summary, primary, baseline, alternative, alt_ledger, alt_summary, directory):
    ids = list(ledger["scenarios"])
    out = Path(directory)
    main_cost = fraction(summary["expected_cost_minor"])
    native = primary["native_solver"]
    bound = native["best_bound_minor"]
    gap = (float(main_cost)-bound)/bound if bound is not None and bound > 0 else None
    lines = ["# 16 周情景采购与生产运营交接", "",
        "所有金额为合成资料的整数最小单位；周序从 0 开始。本文数据由完整整数动作逐周重算，图表同源。", "",
        f"主方案期望成本 **{number(summary['expected_cost_minor'])}**。原生求解器状态 `{native['status']}`，终止类型 `{primary['algorithm']['termination_kind']}`：{primary['algorithm']['termination_detail']}。",
        f"本次求解器数值搜索下界为 {bound}，相对该界的成本差约 {100*gap:.4f}%。" if gap is not None else "未得到可用的求解器界。",
        "此下界来自本次整数模型原生搜索，未提供独立有理证明；参考方的预注册界和外部成绩未知，不能用本文 gap 代替外部质量判定。", "",
        "## 现在承诺与情景选择", "",
        f"前 {n['common_weeks']} 周是共同信息集，下表动作在全部情景完全相同。第 {n['common_weeks']} 周开始前取得真实情景 ID，再执行该 ID 后续全部动作。提前下单形成的在途到货仍按原下单周和提前期执行，不能切换历史。",
        "[完整机器计划](plan.json)和[逐项操作表](actions.csv)包含每周每种物料的采购包装数、供应商装运开关以及每条产线的产品件数；CSV 中 order_lots 为包、units 为件，装运开关按供应商周合单。零动作明确列出。", "",
        "|周|供应商采购包数（R 顺序）/装运开关|产量（F 顺序，每条线为 P 向量）|",
        "|---:|---|---|"]
    common = plan["decisions"][ids[0]]
    for t in range(n["common_weeks"]):
        orders = "; ".join(f"{term['id']}={common['order_lots'][t][v]},truck={common['truck_on'][t][v]}" for v, term in enumerate(n["suppliers"]))
        production = "; ".join(f"{plant}={common['production'][t][f]}" for f, plant in enumerate(n["plants"]))
        lines.append(f"|{t}|{orders}|{production}|")
    lines += ["", f"向量身份：R={n['raw_materials']}；P={n['products']}；F={n['plants']}。显式目录 index 决定位置，CSV 物理行序无关。",
        "[来源映射](source_mapping.json)逐表定位 normalized 字段；[完整业务投影](normalized.json)保留库存、体积、价格、工时、持有费、概率、资格与所有周容量。", "",
        "## 基线与提前生产的必要性", "",
        "基线明确规定：在全部原模型约束之外，每种产品每周期末库存都为 0，即只生产当周交付量。实际运行完整模型得到原生状态 " +
        f"`{baseline['native_solver']['status']}`；[原生日志](baseline-solver.log)和[运行参数](baseline.json)可复核。基线无可执行成本，不能拿一个虚构成本与主方案作节省比较。", "",
        "P0 只能在 F0 生产，而第 6 周 F0 工时为 0。因此第 6 周 P0 的全部需求须在第 5 周结束前存在。第 9 周 F1 只有 10 工时，P3 每件需 3 工时且只能由 F1 生产，最多当周完成 3 件；即使 F1 全部做 P3，也需要事先储备其超出 3 件的需求。其他产品共享产能使真实储备可能更高。补救是解除零成品库存限制，并把生产前置到有资格且有余量的周；主方案已落实。", "",
        "|情景|周6 P0 需求|周5期末 P0|周9 P3需求|周8期末 P3|",
        "|---|---:|---:|---:|---:|"]
    for s in n["scenarios"]:
        weeks = ledger["scenarios"][s["id"]]["weeks"]
        lines.append(f"|{s['id']}|{s['demand'][6][0]}|{weeks[5]['finished_inventory'][0]}|{s['demand'][9][3]}|{weeks[8]['finished_inventory'][3]}|")
    lines += ["", "## 供应中断与情景后操作", "",
        "A 的正常周容量为 80，supplier_disruption 在下单周 6–8 降为 15，低于最低装运体积 20；故这些周 A 装运必须为 0，提前期 1 意味着不能依赖它在周 7–9 补给。这是可行动作集合收缩，不是把缺货解释为额外需求。B 仍有两周提前期，C 可当周到货但单价高；模型允许在周 4 揭示后预购 A/B、调整原料和成品库存并使用 C，均受现金和阶段仓容约束。", "",
        "下表为周 6–8 下单的实际供应体积（不是到货量）；完整后续细节在操作表。最优解可能不唯一，表内同时发生的变化不声称是某一个约束的唯一因果效应。", "",
        "|情景|A 周6/7/8|B 周6/7/8|C 周6/7/8|",
        "|---|---|---|---|"]
    for sid in ids:
        weeks = ledger["scenarios"][sid]["weeks"]
        values = [" / ".join(str(weeks[t]["supplier_volume"][v]) for t in (6,7,8)) for v in range(len(n["suppliers"]))]
        lines.append(f"|{sid}|" + "|".join(values) + "|")
    lines += ["", "![各情景采购](figures/procurement.png)", "",
        "## 费用、现金瓶颈与应收", "",
        "每周现金 = 上周现金 + 四周前已交付需求×售价 − 本周采购 − 本周合单运费 − 生产费 − 期末两类持有费。初始原料是已有资产；其采购费不重复计入。本周下单全额付款，包括整包多买的数量。应收只包括已经交付而尚未回款的销售，不能充当现金。收入固定且强制交付，因此目标只最小化支出。", "",
        "|情景|概率|总成本|最低现金（周）|剩余信用余量|末周现金|末周应收|",
        "|---|---:|---:|---|---:|---:|---:|"]
    for sid in ids:
        su = summary["scenarios"][sid]
        weeks = ledger["scenarios"][sid]["weeks"]
        low_weeks = [w["week"] for w in weeks if w["cash"] == su["minimum_cash_minor"]]
        lines.append(f"|{sid}|{number(su['probability'])}|{su['total_cost_minor']}|{su['minimum_cash_minor']} ({low_weeks})|{su['minimum_cash_minor']+n['credit_limit_minor']}|{su['final_cash_minor']}|{su['final_receivable_minor']}|")
    lines += ["", "前四周尚无销售回款，却要支付生产、持有费与支持提前期的订单，因此这段时间形成信用压力；具体最低点及余量见上表。每个情景逐周分别检查信用，不能用期望余额抵消某一情景缺口。", "",
        "|情景|采购|合单运费|生产|持有|",
        "|---|---:|---:|---:|---:|"]
    components = ("purchase_cost", "freight_cost", "production_cost", "holding_cost")
    expected_components = [Fraction(0) for _ in components]
    for s in n["scenarios"]:
        weeks = ledger["scenarios"][s["id"]]["weeks"]
        values = [sum(w[key] for w in weeks) for key in components]
        for i, value in enumerate(values):
            expected_components[i] += Fraction(s["probability_numerator"], n["probability_denominator"])*value
        lines.append(f"|{s['id']}|" + "|".join(map(str, values)) + "|")
    lines.append("|概率加权|" + "|".join(number(value) for value in expected_components) + "|")
    largest = max(range(len(components)), key=lambda i: expected_components[i])
    lines += ["", f"最大的费用项是 {['原料采购','合单运费','生产','库存持有'][largest]}，期望金额 {number(expected_components[largest])}，占总成本约 {100*float(expected_components[largest]/main_cost):.2f}%。按整包、合单、到货提前期和库存持有共同权衡，不能单以最低单位报价选择供应商。", "",
        "![现金和应收](figures/cash.png)", "",
        "## 仓容与物料控制", "",
        "原料峰值 = 上周期末原料 + 本周到货，在生产消耗前计算；成品峰值 = 上周期末成品 + 本周完工，在需求交付前计算。下表和图同时显示峰值与期末库存，期末库存较低不代表周内可收下同样规模的货。", "",
        "|情景|最大原料阶段峰值 / 容量（周）|最大成品阶段峰值 / 容量（周）|末周原料件数|",
        "|---|---|---|---|"]
    for sid in ids:
        weeks = ledger["scenarios"][sid]["weeks"]
        cells = []
        for key, limit in (("raw_stage_peak_volume", n["raw_storage_volume"]), ("product_stage_peak_volume", n["product_storage_volume"])):
            value = max(w[key] for w in weeks)
            ts = [w["week"] for w in weeks if w[key] == value]
            cells.append(f"{value} / {limit} ({ts})")
        lines.append(f"|{sid}|{'|'.join(cells)}|{weeks[-1]['raw_inventory']}|")
    lines += ["", "末周成品均为零。原料剩余没有残值，仍支付末周持有费；不下达周期结束后才到货的正订单。每条线共享工时与每家供应商共享体积均由账重新核验。", "",
        "![阶段仓容与期末库存](figures/warehouse.png)", "", "## 完整可行替代策略", ""]
    if alt_summary is not None:
        alt_cost = fraction(alt_summary["expected_cost_minor"])
        lines += ["替代方案在每个情景揭示后，把一个原本向有提前期供应商采购的完整包装，改成在原到货周向提前期为 0 的供应商采购。到货件数、到货周、生产、库存与仓容轨迹保持相同；原订单周少付采购费，到货周支付较贵的即期采购和必要合单运费。它以采购溢价换取晚承诺与晚付款的灵活性，仍逐周满足信用、共享容量和最低装运量。", "",
            f"实际期望成本 **{number(alt_summary['expected_cost_minor'])}**，相对主方案变化 **{number(alt_cost-main_cost)}**。构造算法终止类型 `{alternative['algorithm']['termination_kind']}`：{alternative['algorithm']['termination_detail']}。这是完整可行构造，没有成本最优性声明。",
            "完整 [替代计划](alternative/plan.json)、[逐周账](alternative/ledger.json)、[汇总](alternative/summary.json)以及[操作表](alternative/actions.csv)均已按相同规则实际核验。", "",
            "|情景|替代总成本|替代最低现金|成本变化|",
            "|---|---:|---:|---:|"]
        for sid in ids:
            au, su = alt_summary["scenarios"][sid], summary["scenarios"][sid]
            lines.append(f"|{sid}|{au['total_cost_minor']}|{au['minimum_cash_minor']}|{au['total_cost_minor']-su['total_cost_minor']}|")
        lines += ["", "|情景|原供应商/下单周|物料件数|新供应商/下单周=原到货周|晚付款周数|", "|---|---|---|---|---:|"]
        for move in alternative["moves"]:
            lines.append(f"|{move['scenario']}|{move['original_supplier']} / {move['original_order_week']}|{move['raw_id']} × {move['units']}|{move['destination_supplier']} / {move['new_order_week']}|{move['payment_deferral_weeks']}|")
        lines.append("\n费用差按真实包装和两处供应商合单运费重算；生产与库存不变，故两者费用变化为 0。这是一个确定的可行备选，不声称它是该灵活性政策的最小成本。两套政策共同前缀相同；此后只能执行所选整套政策的对应情景行。早期尝试的额外 P0 库存缓冲被两种求解器判为不可行，其记录保留在项目 delivery-v1/alternative.json，不将它冒充可行备选。")
    else:
        lines += ["替代策略尚未找到可行解；不得视为运营交付完成。详见 alternative.json 的真实终态。"]
    lines += ["", "## 复跑、验证与局限", "",
        "从项目根按 README 执行 `python reproduce.py --input <原始目录> --output <不存在的新目录>`；每次从 CSV/JSON 新建模型、求解并模拟，不读取任何旧计划。依赖、真实 argv、时间、线程数、所有实际参数及求解状态在 [run.json](run.json)，原生日志保留在本目录。全部计算顺序运行；数值求解器内部使用工作线程，没有候选自行创建的子 agent。", "",
        "[规范逐周账](ledger.json)、[人读周账](weekly.csv)、[精确汇总](summary.json)是本报告全部业务数字和图形的数据来源。独立模拟器不读取求解器库存或现金变量，重新计算每笔到货与每周结余；[检查结果](verification.json)列出规则核验。", "",
        "求解器搜索界是数值结果，未构造可独立验证的有理最优证明。时间上限或 gap 达标停止都如实保留；CP-SAT 的 OPTIMAL 标签在设置非零 relative_gap_limit 时不自动表示严格精确最优。此交付不声称任何外部评分或真实商业认证。价格扰动和行序复跑的真实证据在项目 validation 目录中独立记录；它们验证声明的单一数值类别和身份稳定性，不穷举任意业务语义变更。", ""]
    (out / "report.md").write_text("\n".join(lines), encoding="utf-8")
