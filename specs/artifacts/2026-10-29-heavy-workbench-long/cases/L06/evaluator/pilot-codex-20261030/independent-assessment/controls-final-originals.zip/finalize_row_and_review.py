"""Final factual17-leaf review; deliberately does not compute a score."""
from collections import Counter
from datetime import datetime, timezone
import copy
import json
from pathlib import Path
import subprocess

ROOT=Path(__file__).resolve().parent
def load(name):return json.loads((ROOT/name).read_text(encoding='utf-8-sig'))
def save(name,v):(ROOT/name).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
review=copy.deepcopy(load('independent-review-quote-addendum.json'))
f=next(v for v in review['findings']if v['id']=='D02')
f.update(judgement='full',observation='Both actual registered same-source controls are now independently verified: C/R0 unit price45→46 and exact data-row reversal of all11 CSVs with unchanged headers/facility and semantic identities. Each completed with the same sealed12 source/docs/dependency/test files, original README defaults, readonly source/raw, fresh outputs, networknone8CPU, natural exit0 and actual30numeric pass. Independent full primary/alternative ledger/summary business recurrences pass. Quote C47646.7 and row C47658.4 satisfy fixedL47380 quality, with no forced optimizer actions or row-identical answer. Same-policy quote cost/cash change is exact. D02 is full from the two actual runs, not from candidate self-controls, witness plans or self-PASS.',evidence=[
 {'path':'quote-addendum/snapshot/terminal-inspect.json','kind':'process_receipt','locator':'actual quote CID/State/Config/Mounts/HostConfig','observation':'Registered quote control naturally exit0 under same sealed source and actual readonly input/new output.'},
 {'path':'quote-addendum/stage-assessment.json','kind':'business_oracle','locator':'25 actual checks; full new main/alternate ledger/summary; sole registered difference; fixedL','observation':'Independent quote raw/accounting plus real numeric association pass; native bound not substituted for registeredL.'},
 {'path':'row-addendum/snapshot/terminal-inspect.json','kind':'process_receipt','locator':'actual row CID/State/Config/Mounts/HostConfig','observation':'Registered row control naturally exit0 with same sealed source, readonly reversed raw and new output.'},
 {'path':'row-addendum/checks.json','kind':'business_oracle','locator':'all23 checks: eleven_CSV_headers_exact_data_rows_reversed, semantics, full ledgers, numeric, process/source/ZIP','observation':'Actual all11 CSVs fully reversed; raw and normalized facts identical semantically, both whole plans exact feasible accounting and fixed reference quality pass.'}])
review['rater']['assignment']='Parent-authorized one-level final independent review of actual sealed Codex L06 eef74425dcd9b9d6e161c9aa303b38c90f400e25. Nonblind AI agent familiar with reference/development calibration and earlier OpenCorvus outcome. Original final delivery, actual separate evaluator base and both registered source-only controls inspected; no reviewer solver/Provider/Docker/candidate run or redelegation. Prior phase files preserved. Not professional-human/statistical certification or controlled same-model comparison; actual Codex model and usage unknown.'
assert dict(Counter(v['judgement']for v in review['findings']))=={'full':17}
assert review['submission_id']=='codex-L06-eef74425dcd9-phase1'
assert review['artifact_bindings']==load('independent-review-phase1.json')['artifact_bindings']
for v in review['findings']:
    for e in v['evidence']:
        assert (ROOT/e['path']).is_file()and (ROOT/e['path']).resolve().is_relative_to(ROOT.resolve())
save('review-final.json',review)
save('row-addendum/actual-visual-review.json',{'method':'Actual tools.view_image opened all3 new row PNGs and rendered their pixels to reviewer.','figures':[{'path':'row-addendum/snapshot/results/row/figures/cash.png','actual_viewed':True,'observation':'Readable cash/AR two panels, all three scenarios, correct units/week indices, -5369 floor and reveal boundary; final balances and entire underlying ledger independently recomputed.'},{'path':'row-addendum/snapshot/results/row/figures/procurement.png','actual_viewed':True,'observation':'Three scenario order-volume panels have supplier IDs/units/legends and actual disruption zeros. Different lawful branch policy allowed; this is not a requirement to match base trajectories.'},{'path':'row-addendum/snapshot/results/row/figures/warehouse.png','actual_viewed':True,'observation':'Six raw/FG panels distinguish stagepeak/endstock/cap240/100 and have readable axes/scenarios/legends. Correct inventory stages expressed, full data independently recomputed.'}],'scope':'Adds evidence that row reconstruction includes real reviewed figures. Original submitted F04 review object remains bound to the original final delivery.'})
row=load('row-addendum/stage-assessment.json')
save('stage-assessment-final-review.json',{'case':'L06/0.2.0','submission_id':review['submission_id'],'review_findings':17,'review_counts':{'full':17},'known_candidate_defects':[],'source_only_base':'verified','registered_quote_control':'verified','registered_row_control':'verified','row_audit':row,'original_delivery_numeric_counts':load('numeric-delivered.json')['counts'],'actual_grade_cli_called_by_reviewer':False,'total_score':None,'business_success':None,'good':None,'next_step':'Parent must invoke actual frozen l06_grade on original sealed five paths with this review; do not infer or handwrite the aggregate.','model_identity':None,'model_usage':None,'comparable':False,'nonblind_AI_prior_reference_and_OC_familiarity':True,'original_phase_files_retained':True,'new_solver_Docker_Provider_candidate_program_calls':0,'completed_utc':datetime.now(timezone.utc).isoformat()})
(ROOT/'ROW-COLD-ADDENDUM.md').write_text('''# Codex L06 row control and final17-leaf synthesis

The actual registered row control passes; D02 is now full based on both separate actual controls. The final private legal review is `review-final.json`, l06-review-evidence/1, stable ID `codex-L06-eef74425dcd9-phase1`, retaining the original sealed input/normalized/plan/summary/ledger five bindings. All17 findings now have full judgments. The reviewer does not compute total_score/business_success/good; parent must use the real frozen grader. Original phase1/base/quote files and the first reviewer action-count false remain unchanged.

## Exact row control and process

All11 archived raw CSV headers are unchanged and every complete data-row list is the exact reverse of the original frozen file; facility is unchanged. Explicit business indices/identities reconstruct the entire same normalized object. This validates actual row reordering, not merely a renamed directory or a self-report. All12 archived executed source/docs/dependency/test files match sealed eef74425dcd9 and the earlier independent base source. No old model/plan/result/reference is mounted.

Actual root-owned CID7fcb31b74f57dccbdb7e562323a511613f65ed884846ede42eb6b6a3dc38a79f ran02:02:00.441745306Z→02:18:33.171571644Z and naturally exited0; wall992.729826s/main990.764372s. Real readonly /project and /raw, fresh writable /results, netnone8CPU and same dependency image/versions/default staged solver command are saved. Actual entry is `/opt/cpsat/bin/python reproduce.py --input /raw --output /results/row`. Launch/terminal/output/native facts and same-CID cleanup after sealing are tied together; all33 new result archive members directly match the output files. No reviewer container or solver operation occurred.

## New output arithmetic and visuals

`audit_row_addendum.py` actual independent stdlib-only audit took.384646s;23 checks all pass. Both entire primary and alternate policy material/package/qualification/sharedcapacity/information/stagewarehouse/cash/terminal constraints pass; every complete ledger and summary value matches. Main C238292/5=47658.4, fixed L47380 gap348/59225≈0.58758970%, alternate239417/5=47883.4, premium225. Different correct actions from original/base/quote are accepted; nondeterministic finite search need not return the same plan.

Saved actual numeric CLI is bound to this reordered input/new output and exited0 with30pass/17unassessed/totalnull. Real global HiGHS Time limit reached log primal476584/den10, numerical bound474866/den10=47486.6, resource_limit/no exact-optimum claim agrees with run/stdout. Fixed evaluator L47380 is unchanged; the new solver bound is not a rational proof or substituted quality gate.

All3 new cash/procurement/warehouse PNGs were actually displayed via view_image and inspected. Units/scenarios/legends, credit floor, supplier order-volume outage window, stage/endstock distinctions and capacities are readable and consistent with exact new whole ledger. See row-addendum/actual-visual-review.json. The new result does not replace the original submitted F04 review object.

## Final review boundary

Only D02 changes relative to the quote-stage file. All other16 original, business, source, process or visual judgments stay as supported by earlier actual observations. The two registered controls are real new source-only executions and their complete policies are valid under their respective registered references, which closes the former last evaluator evidence gap. Current frozen47 leaves/100-weight contract including criticalD02 is semantically identical to the phase1 snapshot; no new requirement, changed threshold, action-identity or formatting rule was introduced.

No candidate business defect was found. This is familiar-reference nonblind AI review with earlier OpenCorvus-outcome familiarity, not professional-human or statistical certification. Actual Codex model/usage are unknown and comparable=false. These finite evaluator run durations do not establish effective user-task hours, model efficiency/causality, ten-case completion or benchmark maturity. The final aggregate must come from the actual grader, not this narrative or manual arithmetic.
''',encoding='utf-8')
status=subprocess.run(['git','status','--short'],cwd='D:/myhexin-local/opencorvus',capture_output=True,text=True,encoding='utf-8')
(ROOT/'row-addendum/git-status-end.txt').write_text(status.stdout+status.stderr,encoding='utf-8')
save('row-addendum/review-file-check.json',{'format':review['format'],'findings':17,'all_full':True,'all_evidence_paths_within_private_root_and_existing':True,'same_submission_id_and_original_five_paths':True,'grade_cli_called':False,'total_score_computed':False,'git_status_exit':status.returncode})
print(json.dumps({'review':str(ROOT/'review-final.json'),'findings':17,'judgements':{'full':17},'grade_cli_called':False,'total_score':None},ensure_ascii=False))
