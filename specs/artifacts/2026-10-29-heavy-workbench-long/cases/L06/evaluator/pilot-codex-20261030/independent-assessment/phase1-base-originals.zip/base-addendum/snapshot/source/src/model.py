"""Joint stochastic integer model, with a shared nonanticipative prefix."""
import time
import ortools
from pathlib import Path
from ortools.sat.python import cp_model
from .facts import CandidateInputError


def solve(n, output, label, seconds, gap, workers, *, just_in_time=False,
          reserve=None, hint=None, backend="cpsat", warm_seconds=120, fixed_prefix=None, first_solution=False):
    T, R, P, F, V = n["weeks"], len(n["raw_materials"]), len(n["products"]), len(n["plants"]), len(n["suppliers"])
    model = cp_model.CpModel()
    shared = {}
    actions, raw, finished, cash, costs = {}, {}, {}, {}, {}
    objective = []
    max_money = max(n["initial_cash_minor"] + n["credit_limit_minor"] +
                    sum(sum(a * b for a, b in zip(d, n["sales_price_minor"])) for d in s["demand"])
                    for s in n["scenarios"])

    def action(sid, t, kind, indices, ub):
        key = ("common" if t < n["common_weeks"] else sid, t, kind, *indices)
        if key not in shared:
            shared[key] = model.new_int_var(0, ub, "_".join(map(str, key)))
        return shared[key]

    for s in n["scenarios"]:
        sid = s["id"]
        q = [[[action(sid, t, "q", (v, r), 0 if t + term["lead_weeks"] >= T else
                       s["supplier_capacity_volume"][t][v] // (term["pack_units"][r] * n["raw_volume"][r]))
               for r in range(R)] for v, term in enumerate(n["suppliers"])] for t in range(T)]
        z = [[action(sid, t, "truck", (v,), 1) for v in range(V)] for t in range(T)]
        p = [[[action(sid, t, "p", (f, j), s["plant_capacity_hours"][t][f] // n["production_hours"][j]
                      if n["allowed"][f][j] else 0) for j in range(P)] for f in range(F)] for t in range(T)]
        actions[sid] = {"order_lots": q, "truck_on": z, "production": p}
        raw[sid] = [[model.new_int_var(0, n["raw_storage_volume"] // n["raw_volume"][r], f"raw_{sid}_{t}_{r}")
                     for r in range(R)] for t in range(T)]
        finished[sid] = [[model.new_int_var(0, n["product_storage_volume"] // n["product_volume"][j], f"finished_{sid}_{t}_{j}")
                          for j in range(P)] for t in range(T)]
        cash[sid] = [model.new_int_var(-n["credit_limit_minor"], max_money, f"cash_{sid}_{t}") for t in range(T)]
        costs[sid] = []
        for t in range(T):
            made = [sum(p[t][f][j] for f in range(F)) for j in range(P)]
            arrivals = [sum(q[t - term["lead_weeks"]][v][r] * term["pack_units"][r]
                            for v, term in enumerate(n["suppliers"]) if t >= term["lead_weeks"])
                        for r in range(R)]
            rprev = raw[sid][t-1] if t else n["initial_raw"]
            fprev = finished[sid][t-1] if t else n["initial_products"]
            for r in range(R):
                model.add(raw[sid][t][r] == rprev[r] + arrivals[r] - sum(n["bom"][j][r] * made[j] for j in range(P)))
            for j in range(P):
                model.add(finished[sid][t][j] == fprev[j] + made[j] - s["demand"][t][j])
                if t == T-1 or just_in_time:
                    model.add(finished[sid][t][j] == 0)
            model.add(sum(n["raw_volume"][r] * (rprev[r] + arrivals[r]) for r in range(R)) <= n["raw_storage_volume"])
            model.add(sum(n["product_volume"][j] * (fprev[j] + made[j]) for j in range(P)) <= n["product_storage_volume"])
            for v, term in enumerate(n["suppliers"]):
                volume = sum(n["raw_volume"][r] * term["pack_units"][r] * q[t][v][r] for r in range(R))
                model.add(volume <= s["supplier_capacity_volume"][t][v] * z[t][v])
                model.add(volume >= term["minimum_volume"] * z[t][v])
            for f in range(F):
                model.add(sum(n["production_hours"][j] * p[t][f][j] for j in range(P)) <= s["plant_capacity_hours"][t][f])
            cost = model.new_int_var(0, max_money, f"cost_{sid}_{t}")
            model.add(cost ==
                      sum(q[t][v][r] * term["pack_units"][r] * term["price_minor"][r]
                          for v, term in enumerate(n["suppliers"]) for r in range(R)) +
                      sum(z[t][v] * term["freight_minor"] for v, term in enumerate(n["suppliers"])) +
                      sum(p[t][f][j] * n["production_cost_minor"][f][j] for f in range(F) for j in range(P)) +
                      sum(raw[sid][t][r] * n["raw_holding_minor"][r] for r in range(R)) +
                      sum(finished[sid][t][j] * n["product_holding_minor"][j] for j in range(P)))
            receipt = (sum(a * b for a, b in zip(s["demand"][t - n["receipt_lag_weeks"]], n["sales_price_minor"]))
                       if t >= n["receipt_lag_weeks"] else 0)
            model.add(cash[sid][t] == (cash[sid][t-1] if t else n["initial_cash_minor"]) + receipt - cost)
            costs[sid].append(cost)
            objective.append(s["probability_numerator"] * cost)
        model.add(cash[sid][-1] >= 0)
        if reserve is not None:
            week, product, minima = reserve
            model.add(finished[sid][week][product] >= minima[sid])
    model.minimize(sum(objective))
    if fixed_prefix is not None:
        for sid, decisions in actions.items():
            for key, arrays in decisions.items():
                def fix(variables, numbers):
                    for variable, number in zip(variables, numbers):
                        if isinstance(variable, list):
                            fix(variable, number)
                        else:
                            model.add(variable == number)
                fix(arrays[:n["common_weeks"]], fixed_prefix["decisions"][sid][key][:n["common_weeks"]])
    if hint is not None:
        hinted = set()
        for sid, decisions in actions.items():
            for kind, values in decisions.items():
                def add_hints(variables, numbers):
                    for variable, number in zip(variables, numbers):
                        if isinstance(variable, list):
                            add_hints(variable, number)
                        elif variable.index not in hinted:
                            model.add_hint(variable, number)
                            hinted.add(variable.index)
                add_hints(values, hint["decisions"][sid][kind])
    validation = model.validate()
    if validation:
        raise CandidateInputError(f"MODEL_NUMERIC_OR_DOMAIN_ERROR: {validation}")
    if backend == "warm":
        from .warm_solver import solve_warm
        return solve_warm(model, actions, n, output, label, seconds, gap, workers, just_in_time, reserve, hint, warm_seconds)
    if backend != "cpsat":
        raise ValueError(f"UNKNOWN_SOLVER_PHASE: {backend}")
    solver = cp_model.CpSolver()
    parameters = {"max_time_in_seconds": seconds, "relative_gap_limit": gap,
                  "num_search_workers": workers, "random_seed": 20261030,
                  "log_search_progress": True, "log_to_stdout": False,
                  "stop_after_first_solution": first_solution}
    for key, value in parameters.items():
        setattr(solver.parameters, key, value)
    path = Path(output) / f"{label}-solver.log"
    start = time.monotonic()
    with path.open("w", encoding="utf-8") as log:
        solver.log_callback = lambda message: (log.write(message + "\n"), log.flush())
        status = solver.solve(model)
        log.write("\n" + solver.response_stats() + "\n")
    elapsed = time.monotonic() - start
    name = solver.status_name(status)
    feasible = status in (cp_model.OPTIMAL, cp_model.FEASIBLE)
    denominator = n["probability_denominator"]
    native = {"name": "OR-Tools CP-SAT", "version": ortools.__version__, "status": name,
              "objective_minor": solver.objective_value / denominator if feasible else None,
              "best_bound_minor": solver.best_objective_bound / denominator if feasible else None,
              "objective_numerator": round(solver.objective_value) if feasible else None,
              "best_bound_numerator": solver.best_objective_bound if feasible else None,
              "wall_time_seconds": solver.wall_time, "measured_solve_seconds": elapsed,
              "response_stats": solver.response_stats()}
    # CP-SAT's OPTIMAL can mean the requested nonzero relative gap was reached.
    exact_bound = feasible and abs(solver.objective_value - solver.best_objective_bound) < 0.5
    gap_reached = feasible and name == "OPTIMAL" and not exact_bound
    if status == cp_model.INFEASIBLE or exact_bound:
        termination = ("completed", "native infeasibility proof" if status == cp_model.INFEASIBLE else "native integer objective and search bound coincide")
    elif first_solution and feasible:
        termination = ("completed", "requested first feasible integer incumbent found; this is initialization, not an optimum claim")
    elif gap_reached:
        termination = ("completed", "native relative_gap_limit reached; exact optimum is not claimed")
    elif feasible or status == cp_model.UNKNOWN:
        termination = ("resource_limit", "native search returned after configured time limit; see raw solver log")
    else:
        termination = ("failed", f"native status {name}")
    metadata = {"parameters": parameters, "native_solver": native,
                "algorithm": {"name": "joint scenario integer CP-SAT", "termination_kind": termination[0],
                              "termination_detail": termination[1]},
                "feasibility": "feasible" if feasible else "infeasible" if status == cp_model.INFEASIBLE else "unknown",
                "exact_integer_optimum": exact_bound,
                "restrictions": {"just_in_time": just_in_time, "reserve": reserve}}
    if not feasible:
        return None, metadata
    def values(a):
        return [values(x) if isinstance(x, list) else solver.value(x) for x in a]
    plan = {"format": "l06-plan/1", "decisions": {sid: {key: values(value) for key, value in act.items()}
                                                    for sid, act in actions.items()}}
    return plan, metadata
