"""A complete feasible flexibility policy, checked through exact accounting."""
import copy
from .accounting import simulate


def spot_substitution(n, primary):
    """Move one package per scenario to spot purchase at its original arrival.

    Enumerate latest arrival, longest payment deferral, then smallest premium.
    Every candidate is an actual full action plan; the common prefix is kept.
    """
    alternative = copy.deepcopy(primary)
    moves = []
    tested = 0
    for scenario in n["scenarios"]:
        sid = scenario["id"]
        current = alternative["decisions"][sid]
        candidates = []
        for source, term in enumerate(n["suppliers"]):
            if term["lead_weeks"] == 0:
                continue
            for t in range(n["common_weeks"], n["weeks"]-term["lead_weeks"]):
                arrival = t+term["lead_weeks"]
                for raw, lots in enumerate(current["order_lots"][t][source]):
                    if lots == 0:
                        continue
                    units = term["pack_units"][raw]
                    for destination, spot in enumerate(n["suppliers"]):
                        if spot["lead_weeks"] != 0 or units % spot["pack_units"][raw]:
                            continue
                        premium = units*(spot["price_minor"][raw]-term["price_minor"][raw])
                        if current["truck_on"][arrival][destination] == 0:
                            premium += spot["freight_minor"]
                        candidates.append((-arrival, -term["lead_weeks"], premium, source, t, raw, destination))
        candidates.sort()
        selected = None
        for _, _, _, source, t, raw, destination in candidates:
            tested += 1
            candidate = copy.deepcopy(alternative)
            d = candidate["decisions"][sid]
            term, spot = n["suppliers"][source], n["suppliers"][destination]
            arrival = t+term["lead_weeks"]
            units = term["pack_units"][raw]
            d["order_lots"][t][source][raw] -= 1
            if sum(d["order_lots"][t][source]) == 0:
                d["truck_on"][t][source] = 0
            d["order_lots"][arrival][destination][raw] += units//spot["pack_units"][raw]
            d["truck_on"][arrival][destination] = 1
            _, _, violations = simulate(n, candidate)
            if len(violations) == 0:
                alternative = candidate
                selected = dict(scenario=sid, original_supplier=term["id"], original_order_week=t,
                    raw_id=n["raw_materials"][raw], units=units, destination_supplier=spot["id"],
                    new_order_week=arrival, arrival_week=arrival, payment_deferral_weeks=term["lead_weeks"])
                moves.append(selected)
                break
        if selected is None:
            raise RuntimeError(f"ALTERNATIVE_CONSTRUCTION_BLOCKED: no feasible spot substitution in {sid}")
    ledger, summary, violations = simulate(n, alternative)
    if violations:
        raise RuntimeError("ALTERNATIVE_CONSTRUCTION_CHECKER_ERROR")
    metadata = {"algorithm": {"name": "enumerated same-arrival spot substitution with exact full-policy checking",
                              "termination_kind": "completed", "termination_detail": "one verified substitution found for every scenario"},
                "native_solver": None, "feasibility": "feasible", "parameters": {"priority": ["latest arrival", "longest payment deferral", "lowest quoted premium"],
                    "changes_per_scenario": 1, "candidates_checked": tested}, "moves": moves,
                "optimality": "constructive feasible policy; no cost optimum claim"}
    return alternative, ledger, summary, metadata
