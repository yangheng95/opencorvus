"""Independent exact integer checker/simulator; does not inspect solver variables."""
from fractions import Fraction


def rational(value):
    value = Fraction(value)
    return value.numerator if value.denominator == 1 else {"numerator": value.numerator, "denominator": value.denominator}


def simulate(n, plan):
    T, R, P, F, V = n["weeks"], len(n["raw_materials"]), len(n["products"]), len(n["plants"]), len(n["suppliers"])
    violations = []
    ledger = {"format": "l06-ledger/1", "scenarios": {}}
    summary = {"format": "l06-summary/1", "scenarios": {}}
    expected = Fraction(0)

    def check(condition, sid, week, rule, actual, limit):
        if not condition:
            violations.append(dict(scenario=sid, week=week, rule=rule, actual=actual, limit=limit))

    def shape(value, dimensions):
        if not dimensions:
            return type(value) is int and value >= 0
        return isinstance(value, list) and len(value) == dimensions[0] and all(shape(v, dimensions[1:]) for v in value)

    if plan["format"] != "l06-plan/1" or set(plan["decisions"]) != {s["id"] for s in n["scenarios"]}:
        raise ValueError("PLAN_SCHEMA: format/scenario identities")
    for s in n["scenarios"]:
        d = plan["decisions"][s["id"]]
        for key, dims in (("order_lots", [T, V, R]), ("truck_on", [T, V]), ("production", [T, F, P])):
            if not shape(d[key], dims):
                raise ValueError(f"PLAN_SCHEMA: {s['id']}.{key}")
            check(d[key][:n["common_weeks"]] == plan["decisions"][n["scenarios"][0]["id"]][key][:n["common_weeks"]],
                  s["id"], None, "common_information_set", d[key][:n["common_weeks"]], "same as first scenario")
    for s in n["scenarios"]:
        sid = s["id"]
        d = plan["decisions"][sid]
        raw = n["initial_raw"][:]
        finished = n["initial_products"][:]
        cash, total = n["initial_cash_minor"], 0
        weeks = []
        sales = [sum(a*b for a, b in zip(row, n["sales_price_minor"])) for row in s["demand"]]
        for t in range(T):
            q, trucks, production = d["order_lots"][t], d["truck_on"][t], d["production"][t]
            made = [sum(production[f][j] for f in range(F)) for j in range(P)]
            arrivals = [sum(d["order_lots"][t-term["lead_weeks"]][v][r] * term["pack_units"][r]
                            for v, term in enumerate(n["suppliers"]) if t >= term["lead_weeks"]) for r in range(R)]
            consumption = [sum(made[j] * n["bom"][j][r] for j in range(P)) for r in range(R)]
            raw_peak = sum((raw[r]+arrivals[r]) * n["raw_volume"][r] for r in range(R))
            product_peak = sum((finished[j]+made[j]) * n["product_volume"][j] for j in range(P))
            raw = [raw[r]+arrivals[r]-consumption[r] for r in range(R)]
            finished = [finished[j]+made[j]-s["demand"][t][j] for j in range(P)]
            hours = [sum(production[f][j] * n["production_hours"][j] for j in range(P)) for f in range(F)]
            volumes = [sum(q[v][r] * term["pack_units"][r] * n["raw_volume"][r] for r in range(R))
                       for v, term in enumerate(n["suppliers"])]
            purchase = sum(q[v][r] * term["pack_units"][r] * term["price_minor"][r]
                           for v, term in enumerate(n["suppliers"]) for r in range(R))
            freight = sum(trucks[v] * term["freight_minor"] for v, term in enumerate(n["suppliers"]))
            production_cost = sum(production[f][j] * n["production_cost_minor"][f][j] for f in range(F) for j in range(P))
            holding = sum(a*b for a, b in zip(raw, n["raw_holding_minor"])) + sum(a*b for a, b in zip(finished, n["product_holding_minor"]))
            cost = purchase + freight + production_cost + holding
            receipts = sales[t-n["receipt_lag_weeks"]] if t >= n["receipt_lag_weeks"] else 0
            receivable = sum(sales[max(0, t-n["receipt_lag_weeks"]+1):t+1])
            cash += receipts-cost
            total += cost
            check(min(raw) >= 0, sid, t, "raw_balance", raw, ">=0 each raw")
            check(min(finished) >= 0, sid, t, "demand_fulfillment", finished, ">=0 each product")
            check(raw_peak <= n["raw_storage_volume"], sid, t, "raw_stage_peak", raw_peak, n["raw_storage_volume"])
            check(product_peak <= n["product_storage_volume"], sid, t, "product_stage_peak", product_peak, n["product_storage_volume"])
            check(cash >= -n["credit_limit_minor"], sid, t, "credit_limit", cash, -n["credit_limit_minor"])
            for v, term in enumerate(n["suppliers"]):
                check(trucks[v] in (0, 1), sid, t, "truck_binary", trucks[v], [0, 1])
                check(term["minimum_volume"]*trucks[v] <= volumes[v] <= s["supplier_capacity_volume"][t][v]*trucks[v],
                      sid, t, f"supplier_shared_volume:{term['id']}", volumes[v],
                      [term["minimum_volume"]*trucks[v], s["supplier_capacity_volume"][t][v]*trucks[v]])
                check(t+term["lead_weeks"] < T or sum(q[v]) == 0, sid, t, "arrival_within_horizon", sum(q[v]), T)
            for f in range(F):
                check(hours[f] <= s["plant_capacity_hours"][t][f], sid, t, f"plant_hours:{n['plants'][f]}", hours[f], s["plant_capacity_hours"][t][f])
                for j in range(P):
                    check(n["allowed"][f][j] == 1 or production[f][j] == 0, sid, t,
                          f"route:{n['plants'][f]}:{n['products'][j]}", production[f][j], n["allowed"][f][j])
            row = dict(week=t, order_lots=q, truck_on=trucks, production=production, arrivals=arrivals,
                       consumption=consumption, raw_inventory=raw, made=made, finished_inventory=finished, hours=hours,
                       supplier_volume=volumes, raw_stage_peak_volume=raw_peak, product_stage_peak_volume=product_peak,
                       purchase_cost=purchase, freight_cost=freight, production_cost=production_cost, holding_cost=holding,
                       cost=cost, receipts=receipts, cash=cash, receivable=receivable)
            weeks.append(row)
        check(finished == [0]*P, sid, T-1, "terminal_finished", finished, [0]*P)
        check(cash >= 0, sid, T-1, "terminal_cash", cash, ">=0")
        ledger["scenarios"][sid] = {"weeks": weeks}
        probability = Fraction(s["probability_numerator"], n["probability_denominator"])
        summary["scenarios"][sid] = dict(probability=rational(probability), total_cost_minor=total,
            minimum_cash_minor=min(w["cash"] for w in weeks), final_cash_minor=cash, final_receivable_minor=weeks[-1]["receivable"])
        expected += total*probability
    summary["expected_cost_minor"] = rational(expected)
    return ledger, summary, violations
