# L06 executable procurement and production policy

This project reads only the twelve files in the supplied `inputs/` packet and computes a joint 16-week policy. The six root task/data/output/environment/source/profile documents describe the other public inputs. No evaluator, reference answer, account or external model is used.

## Run from raw files

Use Python 3.11.13 with the pinned packages in [requirements.txt](requirements.txt). The supplied dependency image already contains these versions. From this project on Windows:

```powershell
docker run --rm --network none --name l06-reproduce `
  --mount "type=bind,source=$($PWD.Path),target=/work" --workdir /work `
  opencorvus-benchmark-reference:20261029 `
  /opt/cpsat/bin/python reproduce.py --input /work/inputs --output /work/new-output
```

With the dependencies directly available, the required thin entry is:

```text
python reproduce.py --input <raw-input-directory> --output <nonexistent-new-output-directory>
```

The output directory must not already exist. Its path may be outside the source tree. The dependency image ID supplied in ENVIRONMENT.md is `sha256:23ff8bfbf8055caa0b9fa5745ddb27cceea2f31d7d15b7a900c81112cdfe8ddf`; this identifies an immutable dependency resource, not a source correctness checksum. Only this project's own files are mounted. No network, GPU, Docker access inside the container or credentials are required.

Default primary solve: fresh joint CP-SAT initialization (eight workers, return immediately on the first feasible integer incumbent, at most 600 seconds); three conditional HiGHS neighborhood solves (at most 180 seconds each, one thread), preserving that fresh common prefix; finally unrestricted joint HiGHS branch-and-cut (at most 300 seconds, one thread), initialized with the improved complete policy. Only the unrestricted search bound is a global bound. The baseline is a separate solve of the same model with just-in-time production. The alternative is an exactly checked constructive spot-substitution policy. Phases run sequentially. The complete entry can take up to about 24 minutes at these limits; a normal early feasible initialization returns sooner. There is no claim that a time-limit feasible incumbent is exact optimal. `--seconds`, `--warm-seconds`, `--scenario-seconds` and `--gap` are optional real solver controls; actual values are recorded. Every run starts from the supplied raw files and does not read old outputs.

## Model and accounting

[src/facts.py](src/facts.py) builds the full `l06-feasibility-instance/2` projection by explicit indices and joined identities. It checks complete matrices, positive probability sum, duplicate identities and the shared information set. All physical units, prices, pack sizes, route costs and initial assets are retained. Out-of-range integer values raise a named `CandidateInputError`; output directories are never overwritten.

[src/model.py](src/model.py) constructs a single joint linear integer model with shared action variables for weeks 0–3. Procurement is integer packages; supplier capacity/minimum volume/freight use one supplier-week switch. Production shares qualified plant hours. All lead times, both stage warehouse peaks, inventories, terminal conditions and each scenario's delayed cash constraints are explicit. The objective is the probability-numerator-weighted integer cost; the common denominator rescales the reported monetary objective.

[src/warm_solver.py](src/warm_solver.py) exports the very same linear constraints to HiGHS and accepts freshly computed action incumbents. The reproduction entry first calls the joint model's CP-SAT phase, then improves conditional scenario continuations and passes their assembled policy into the unrestricted model. This is a staged warm-start algorithm, not a cached policy or a second business model. In HiGHS, only actions need integrality: inventory/cost/cash auxiliaries are uniquely integer recurrences once actions are integer. All rounded actions are independently checked in integer arithmetic; native tolerances are not used to excuse a physical or cash discrepancy. Search bounds are numerical solver evidence, distinct from an independent rational certificate. HiGHS and CP-SAT native logs are retained separately.

[src/accounting.py](src/accounting.py) reconstructs the entire ledger from normalized facts and integer actions without using solver inventory or cash values. It checks each scenario/week and computes exact rational expected cost with `fractions.Fraction`. The report, operational CSVs and figures all use this ledger. [verify_saved.py](verify_saved.py) can reconstruct accounting again from raw files and compare the saved primary and alternative outputs exactly:

```text
python verify_saved.py --input inputs --output new-output
python -m unittest discover -s tests -v
```

Focused tests use two hand-calculated accounting examples, identity-based row reordering and the named duplicate-input error contract. These are local contract tests; actual solver runs and checked ledgers provide the full-path evidence. No UI automation is used.

## Deliverables and operator use

The new output directory contains the required `normalized.json`, `plan.json`, `ledger.json`, `summary.json`, `run.json`, `report.md`, `manifest.json` and actual `figures/`. Also included are `source_mapping.json`, `actions.csv`, `weekly.csv`, native logs and a fully checked `alternative/` policy.

An operator must choose one whole policy before week 0, execute its common prefix, and at the start of week 4 select the actual scenario ID's remaining rows. The `actions.csv` field `information_set` marks those boundaries. Orders show both package count and raw units plus arrival week; production is pieces by plant/product. A truck switch is one shared supplier-week instruction even though it repeats across that supplier's raw rows. Do not add the repeated switches or freight per raw. Previously placed orders remain committed after scenario reveal. Array identities and units are given in the generated report and source map.

The baseline is the full model with zero finished end inventory every week; its infeasibility is an actual native result, with the week-6 P0 outage and week-9 P3 bottleneck explained. The alternative moves one package per scenario from an advance supplier order to spot procurement at its original arrival week. It preserves arrivals/production/inventory, defers payment and incurs the actual quote/freight difference; it has its own complete plan and checked cost. An earlier attempt to add one extra P0 before the outage was proven infeasible and is retained as a failed experiment, not advertised as an alternative. Do not splice policies.

## Input controls and evidence

[prepare_controls.py](prepare_controls.py) generates fresh copies inside `validation/`, leaving the original packet intact. `--kind reordered` shuffles CSV physical rows with a fixed seed; `--kind spot-quote-increase` raises C/R0's unit quote by 7; `--kind quote-increase` raises A/R0 by 7 as a separately retained cash stress experiment. `--kind all` prepares all three in new directories. Run the exact same `reproduce.py` on each copied input and a new output directory. The latter A/R0 stress was actually infeasible, and is recorded as such rather than inventing a cost or silently changing credit. These are self-declared controls, not the evaluator's sealed values.

The [spec plan](specs/records/2026-10/operating-policy.md) records analysis, measured experiments, status and limitations. Early solver experiments and important failures remain in `experiments/` and `validation/`. They are not read by the reproduction entry. No external score or independent review is claimed. Authoritative final run locations and visual inspection notes are recorded in `DELIVERY.md` after actual completion.

Official solver interfaces consulted: [SciPy 1.15.3 MILP](https://docs.scipy.org/doc/scipy-1.15.3/reference/generated/scipy.optimize.milp.html), [OR-Tools v9.15 parameters](https://raw.githubusercontent.com/google/or-tools/v9.15/ortools/sat/sat_parameters.proto), [HiGHS Python examples](https://ergo-code.github.io/HiGHS/stable/interfaces/python/example-py/). Actual installed APIs and version strings were checked in the dependency image.
