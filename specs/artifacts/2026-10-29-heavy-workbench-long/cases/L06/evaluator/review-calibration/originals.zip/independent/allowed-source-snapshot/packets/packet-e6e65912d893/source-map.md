# 来源
R0按supplier_terms的supplier_id定位，pack_units的单位是卡车开关。
