"""Follow the explicitly migrated canonical path; preserve the old failed attempt."""
import json
from pathlib import Path
import subprocess,time
ROOT=Path(__file__).resolve().parent
text=(ROOT/'adjudicate_original.py').read_text(encoding='utf-8')
text=text.replace("out=ROOT/'post-initial-adjudication';","out=ROOT/'post-initial-adjudication-final';")
text=text.replace('cases/L06/rubric.draft.json','cases/L06/rubric.json')
path=ROOT/'adjudicate_original_final.py'
path.write_text(text,encoding='utf-8')
argv=['C:/Python314/python.exe','-X','utf8','-B',str(path)]
t=time.perf_counter();p=subprocess.run(argv,capture_output=True,text=True,encoding='utf-8')
(ROOT/'adjudication-final-stdout.txt').write_text(p.stdout,encoding='utf-8');(ROOT/'adjudication-final-stderr.txt').write_text(p.stderr,encoding='utf-8')
(ROOT/'adjudication-final-command.json').write_text(json.dumps({'argv':argv,'exit_code':p.returncode,'seconds':time.perf_counter()-t,'path_migration':'explicit current rubric.json only; original draft-path FileNotFound retained'},indent=2)+'\n',encoding='utf-8')
print(p.stdout);print(p.stderr)
