"""Append fairness adjudication after initial8; preserve original36 and author-key boundary."""
from datetime import datetime,timezone
import copy,json
from pathlib import Path
import shutil
ROOT=Path(__file__).resolve().parent
CAL=ROOT.parent.parent
OLD=CAL/'independent/allowed-source-snapshot/packets/packet-97ad1f63e52c'
CONTEXT=ROOT/'allowed-source-snapshot/context'
REPO=Path('D:/myhexin-local/opencorvus')
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,x):
    if p.exists():raise RuntimeError('preserve original '+str(p))
    p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def main():
    initial8=load(ROOT/'INITIAL-8-RATINGS.json');assert len(initial8['ratings'])==8
    out=ROOT/'post-initial-adjudication-final';out.mkdir(exist_ok=False)
    for n in ('plan.json','normalized.json','ledger.json','report.md','source-map.md','operations.csv','baseline-plan.json','baseline-business.json'):shutil.copy2(OLD/n,out/('old-'+n))
    shutil.copytree(CAL/'common/execution-cards',out/'common-execution-cards')
    for n in ('PUBLIC-TASK.draft.md','PUBLIC-OUTPUTS.draft.md'):shutil.copy2(CAL/'common'/n,out/n)
    rubric=REPO/'specs/artifacts/2026-10-29-heavy-workbench-long/cases/L06/rubric.json';shutil.copy2(rubric,out/'current-rubric.json')
    p=load(OLD/'plan.json');d=load(OLD/'normalized.json');ledger=load(OLD/'ledger.json');control_fields=('order_lots','truck_on','production')
    assert p==load(CONTEXT/'oracle-plan.json') and d==load(CONTEXT/'oracle-normalized.json')
    scenarios=[s['id'] for s in d['scenarios']];assert set(p['decisions'])==set(scenarios) and p['format']=='l06-plan/1'
    schema=[]
    for sid in scenarios:
        a=p['decisions'][sid]
        for t in range(d['weeks']):
            q,z,production=(a[f][t] for f in control_fields)
            ok=len(q)==3 and all(len(r)==4 and all(type(x) is int and x>=0 for x in r) for r in q) and len(z)==3 and all(type(x) is int and x in (0,1) for x in z) and len(production)==2 and all(len(r)==4 and all(type(x) is int and x>=0 for x in r) for r in production)
            ok &= all(ledger['scenarios'][sid]['weeks'][t][f]==a[f][t] for f in control_fields)
            schema.append({'scenario':sid,'week':t,'actual_three_control_arrays_complete_and_ledger_same':bool(ok)})
    assert all(r['actual_three_control_arrays_complete_and_ledger_same'] for r in schema)
    assert all(p['decisions'][sid][f][:4]==p['decisions']['base'][f][:4] for sid in scenarios for f in control_fields)
    original=load(CAL/'independent/INITIAL-RATINGS.json');oldratings=[r for r in original['ratings'] if r['packet_id']=='packet-97ad1f63e52c' and r['leaf'] in ('F01','F02')];assert all(r['judgement']=='half' for r in oldratings)
    actualfacts={'all48_scenario_weeks_controls_actual_in_original_plan':schema,'ordered_catalogs':{'suppliers':[s['id'] for s in d['suppliers']],'raw':d['raw_materials'],'plants':d['plants'],'products':d['products']},'supplied_pack_units':{s['id']:s['pack_units'] for s in d['suppliers']},'complete_common_weeks':[0,1,2,3],'complete_recourse_branches':scenarios,'public_abi_locator':'context/OUTPUTS.draft.md plan.json format and array indices; DATA.md explicit-index-to-array mapping','public_information_set_locator':'context/TASK.draft.md decision timing, week0-origin, common_weeks and revelation','old_report_locator':'report.md lines24 and67 name4 common weeks, scenario separation and plan.json; line72 only describes unfinished CSV summary','private_oracle_used_to_supply_missing_old_actions':False,'action_values_taken_from':'old packet actual plan.json and duplicate ledger only; public contract supplies meaning, oracle verifies equality'}
    save(out/'old-complete-information-audit.json',actualfacts)
    decisions=[{'packet_id':'packet-97ad1f63e52c','leaf':leaf,'original_sealed_judgement':'half','adjudicated_judgement':'full','reason':'Original review looked at CSV coverage and omitted the complete co-submitted plan.json/ledger controls plus the public input/output semantic contract. All required actions already exist and are locatable with identities, units, indexes, week and information set; no missing action is filled from private oracle. Correcting a format bias, not matching an author label.','evidence':['old-plan.json decisions all3scenarios/16weeks/order_lots/truck_on/production','old-normalized.json ordered entity catalogs/suppliers.pack_units','old-ledger.json scenarios.*.weeks.* control duplicates','old-report.md lines24,67 and72','public OUTPUTS plan ABI; public DATA indexes/units; TASK common/reveal semantics']} for leaf in ('F01','F02')]
    save(out/'ADJUDICATION.json',{'adjudicated_utc':datetime.now(timezone.utc).isoformat(),'scope':'Explicit supplementary fairness ruling, original36 and initial8 preserved unchanged','rater':'independent-agent-benchmark_review','author_key_read':False,'new_control_key_read':False,'decisions':decisions,'candidate_score':None,'maturity_approved':False})
    event=load(out/'common-execution-cards/baseline-first-event.json');first=load(out/'common-execution-cards/baseline-first-plan.json');assert event['updates']==1 and event['objective_exact']=='241299/5' and first==load(OLD/'baseline-plan.json')
    save(out/'E01-execution-card-review.json',{'event_exact_cost':event['objective_exact'],'updates':1,'event_observed_utc':event['observed_utc'],'first_plan_equals_original_packet_baseline_plan':True,'baseline_business_expected_cost':load(OLD/'baseline-business.json')['expected_cost_exact'],'meaning':'Additional located original first-incumbent evidence resolves material attribution; not a new cold execution or new edited-report generation. Original E01 ratings remain historical.'})
    oldanchors={r['id']:r for r in load(CAL/'independent/allowed-source-snapshot/anchors.json')['criteria']};current={c['id']:c for g in load(out/'current-rubric.json')['groups'] for c in g['criteria']}
    compared=[]
    for i in ('D07','E03','E04','E05','F01','F02'):
        assert oldanchors[i]['weight']==current[i]['weight']==2 and oldanchors[i]['critical']==current[i]['critical']==False
        compared.append({'leaf':i,'old_anchors':oldanchors[i]['anchors'],'current_anchors':current[i]['anchors'],'weight_and_critical_changed':False})
    save(out/'anchor-clarification-comparison.json',compared)
    (out/'ADJUDICATION.md').write_text('''# 旧packet-97ad1f63e52c F01/F02公平性追加裁决\n\nF01与F02均从原half改判full。原36初评和新8初评保持不变。此前我按operations.csv只覆盖周0/base分支判half，却没有把同包完整机器计划、重复动作账和完整公开语义一起评估；这是不应保留的格式偏差。不是为了与作者预存标签相同，也没有读取任一key。\n\n实际plan.json已给全部三场景16周order_lots/truck_on/production。normalized已有有序A/B/C、R0–3、F0/1、P0–3与真实pack_units。公开OUTPUTS明确三数组维度/单位，DATA明确显式index及单位映射，TASK/报告明确周从0、共同0–3和周4揭示后依观测scenario ID选分支。report67直接定位plan.json；ledger每个场景每周也重复同一动作。48场景周的数组形状/整数/开关/账同值逐一验证，四共同周一致。运营者无需重新求解、读代码或拿私有oracle补动作，就能定位全部共同承诺及三个后续分支。\n\nCSV只有299行仍是事实，但它只是一个未完摘要，不等于全部已交材料缺621行动。report72的待整理表述不佳，但没有撤回明确已交的规范计划；没有错误动作。在现合同允许完整可操作JSON的情况下，它不能成为强行要求重复CSV的隐藏门。私有oracle只核对旧包本来就交出的值，没有向旧包提供动作。\n\n新控制则实际不同：其中只有299行动的包确实未交完整plan/ledger，只有common0及base后续，故F01/F02半分仍正确；另一无CSV但完整JSON+说明的包满分。两种材料的差别是信息真实完整性，不是文件后缀。\n\n原共同E01现在追加真实首incumbent事件updates1、cost241299/5、observed_utc2026-10-29T17:44:48.102847Z及first-plan。first-plan与旧包baseline-plan逐对象相同，结合既有source/launch/terminal定位真实基线而非编辑报告的新执行。这补足了材料来源明确性，不是新实验；原E01初评不改写。\n\nD07四组、E03缺任一full必要解释可half、E04/E05公式与实际定位字段等价，都延续原任务要求，未加业务数据/动作/权重。F01/F02是纠正对旧锚点的格式偏读；它会改变两项裁决，因此不能用原始标签一致就声称当前规则已完全校准。原作者36/36是主方对其预期的报告，非本审查读取验证；当前追加裁决应独立记录，不回改旧key或旧初评来维持表面一致率。\n\n仍有一处应继续实质裁决的边界：旧packet97 E04在report24已给全局现金恒等式/4周滞后，表30–32给最紧周3/现金，report67又定位ledger，且公开OUTPUTS给cash/receipts/cost字段。若这些共同足以让读者直接定位该周来源，就不应因未重复数字或缺逐字JSONPath继续half；若认为仍只给一般规则，需说明为什么其定位不足。本轮授权明确改判F01/F02，故未顺手改旧E04，只把这个具体残余暴露；不能把格式澄清宣称所有旧36争议已自动关闭。\n\n没有新solver、Docker、Provider、GPU、UI或委托；没有候选总分、专家一致/统计成熟或最终冻结批准。\n''',encoding='utf-8')
    save(ROOT/'stage-assessment.json',{'status':'initial8_sealed_then_old_F01_F02_fairness_adjudicated','initial8_count':8,'new_control_labels_read':False,'author_preparation_script_read':False,'old_initial36_modified':False,'new_initial8_modified':False,'old_packet97_F01_F02_current_adjudication':{'F01':'full','F02':'full'},'E01_additional_original_first_incumbent_card_located':True,'clarifications_add_business_requirements_or_weights':False,'remaining_specific_issue':'old packet97 E04 generic cash formula + exact week + ledger/public schema locator needs equivalent-information adjudication; not changed in this scoped F01/F02 ruling','AI_agent_prior_familiarity_disclosed':True,'candidate_score':None,'professional_maturity_or_freeze_approved':False,'solver_Docker_Provider_GPU_UI_runs':0,'delegations':0})
    print(json.dumps({'adjudication':str(out/'ADJUDICATION.md'),'old_F01':'full','old_F02':'full','initials_unchanged':True,'remaining_issue':'old E04 equivalent information boundary'},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
