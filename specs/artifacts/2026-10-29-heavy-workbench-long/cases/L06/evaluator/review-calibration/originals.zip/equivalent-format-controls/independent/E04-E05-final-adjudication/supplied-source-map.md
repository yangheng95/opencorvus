# 已完成的事实来源映射

A01：raw_materials/products/plants按index定位，单位分别件/体积单位/工时，normalized对应raw_materials/products/plants及其库存/体积/持有费/工时/售价属性。
A02：supplier_terms按supplier_id，supplier_quotes按supplier_id+raw_id定位；normalized suppliers保存lead_weeks、pack_units、price_minor、freight_minor、minimum_volume。价格为每件最小金额，包装为每包件数，提前期为周。
另外两类事实映射待补。
