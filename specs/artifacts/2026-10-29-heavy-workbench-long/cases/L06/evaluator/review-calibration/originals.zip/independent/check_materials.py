"""Allowed-material factual audit for label-masked review; no label/key reads."""
from collections import Counter
from fractions import Fraction
import csv,json
from pathlib import Path
import sys
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent;SNAP=ROOT/'allowed-source-snapshot'
sys.path.insert(0,str(SNAP/'common/source'))
from l06_packet import read_packet
from check_l06 import evaluate
from l06_delivery import expected_delivery
def load(path):return json.loads(path.read_text(encoding='utf-8'))
def save(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def main():
    data=read_packet(SNAP/'common/input');results=[]
    for folder in sorted((SNAP/'packets').iterdir()):
        plan=load(folder/'plan.json');business=evaluate(data,plan);ledger,summary=expected_delivery(data,plan,business)
        strategies={}
        for name in ('baseline','alternative'):
            result=evaluate(data,load(folder/(name+'-plan.json')))
            strategies[name]={'exact_cost':result['expected_cost_exact'],'actual_archived_business_agrees':result==load(folder/(name+'-business.json')),'business_feasible':True}
        expected={};first=data['scenarios'][0]['id']
        for s in data['scenarios']:
            name=s['id'];record=plan['decisions'][name]
            for t in range(data['weeks']):
                if t<data['common_weeks'] and name!=first:continue
                information='all_scenarios' if t<data['common_weeks'] else name
                for k,supplier in enumerate(data['suppliers']):
                    expected[(information,t,'shipment',supplier['id'],'','0_or_1')]=record['truck_on'][t][k]
                    for m,raw in enumerate(data['raw_materials']):expected[(information,t,'order',supplier['id'],raw,'pack_lots')]=record['order_lots'][t][k][m]
                for p,plant in enumerate(data['plants']):
                    for j,product in enumerate(data['products']):expected[(information,t,'production',plant,product,'pieces')]=record['production'][t][p][j]
        with (folder/'operations.csv').open(newline='',encoding='utf-8') as f:rows=list(csv.DictReader(f))
        wrong=[];seen=Counter();common=Counter();recourse=Counter()
        for line,row in enumerate(rows,2):
            key=(row['scenario_or_information_set'],int(row['week']),row['action'],row['entity'],row['secondary_entity'],row['unit']);seen[key]+=1
            if key not in expected or int(row['quantity'])!=expected.get(key):wrong.append({'line':line,'key':key,'actual':row['quantity'],'expected':expected.get(key)})
            if row['scenario_or_information_set']=='all_scenarios':common[str(row['week'])]+=1
            else:recourse[row['scenario_or_information_set']]+=1
        # Facts underpinning report anchors, not automated keyword ratings.
        record=ledger['scenarios']['supplier_disruption']['weeks'][6];sc=next(s for s in data['scenarios'] if s['id']=='supplier_disruption')
        arrivals={}
        for label,p in [('primary',plan),('baseline',load(folder/'baseline-plan.json'))]:
            arrivals[label]=[{'supplier':sup['id'],'order_week':6-sup['lead_weeks'],'arrival_week':6,'pieces':[p['decisions']['supplier_disruption']['order_lots'][6-sup['lead_weeks']][k][m]*sup['pack_units'][m] for m in range(len(data['raw_materials']))]} for k,sup in enumerate(data['suppliers'])]
        fact={'packet':folder.name,'actual_plan_cost':business['expected_cost_exact'],'same_ledger_as_business':ledger==load(folder/'ledger.json'),'same_summary_as_business':summary==load(folder/'summary.json'),'strategies':strategies,'operation_rows':len(rows),'expected_all_rows':len(expected),'present_common_rows_by_week':dict(common),'recourse_rows_by_scenario':dict(recourse),'wrong_operation_rows':wrong,'duplicate_action_keys':[list(k) for k,n in seen.items() if n>1],'missing_action_keys':sum(k not in seen for k in expected),'source_truth':{'P0_week6_demand_base':data['scenarios'][0]['demand'][6][0],'P0_week6_single_product_capacity':sum(data['scenarios'][0]['plant_capacity_hours'][6][p]//data['production_hours'][0] for p in range(len(data['plants'])) if data['allowed'][p][0]),'A_week6_capacity':sc['supplier_capacity_volume'][6][0],'A_MOQ':data['suppliers'][0]['minimum_volume'],'actual_A_week6_switch':plan['decisions']['supplier_disruption']['truck_on'][6][0],'disruption_week6_arrivals':arrivals,'P2_hours':data['production_hours'][2],'P2_F0_cost':data['production_cost_minor'][0][2],'P2_F1_cost':data['production_cost_minor'][1][2]},'cash_week3':{s['id']:ledger['scenarios'][s['id']]['weeks'][3] for s in data['scenarios']},'largest_expected_component':{'field':'purchase_cost','exact':str(sum(Fraction(s['probability_numerator'],data['probability_denominator'])*sum(w['purchase_cost'] for w in ledger['scenarios'][s['id']]['weeks']) for s in data['scenarios']))}}
        results.append(fact)
    save(ROOT/'factual-audit.json',{'scope':'Only allowed common/packets, reused pure business recurrence plus exact handoff arithmetic; no solver or source cold execution. Findings are factual support, not keyword-assigned ratings.','packets':results});print(json.dumps([{k:r[k] for k in ['packet','operation_rows','present_common_rows_by_week','recourse_rows_by_scenario','wrong_operation_rows','missing_action_keys']} for r in results],ensure_ascii=False,indent=2))

if __name__=='__main__':main()
