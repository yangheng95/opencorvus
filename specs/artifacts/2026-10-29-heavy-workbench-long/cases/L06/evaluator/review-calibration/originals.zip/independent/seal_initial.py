"""Seal 36 independent first judgements without reading any author label."""
from datetime import datetime,timezone
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent;SNAP=ROOT/'allowed-source-snapshot'
def save(path,value):
    if path.exists():raise RuntimeError('preserve sealed original '+str(path))
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def ev(packet,path,locator,observation):return {'path':'allowed-source-snapshot/packets/'+packet+'/'+path,'locator':locator,'observation':observation}
def common(path,locator,observation):return {'path':'allowed-source-snapshot/common/'+path,'locator':locator,'observation':observation}

def main():
    ratings=[]
    def row(packet,leaf,judgement,observation,*evidence):ratings.append({'packet_id':packet,'leaf':leaf,'judgement':judgement,'observation':observation,'evidence':list(evidence)})
    p='packet-97ad1f63e52c'
    row(p,'D07','half','来源表准确完成目录与供应两类身份/单位映射，另外BOM/产线及情景/设施两类明确待补；符合2至3类完整的半分锚点。',ev(p,'source-map.md','lines3–5','A01/A02给出index、联合ID、每件价格/包装/提前期单位，其他两类未提供。'))
    row(p,'E01','full','包内基线定义为本次首个真实incumbent，完整策略/业务结果可执行，重新计价241299/5=48259.8与报告相同。本轮明确底层真实执行/账未编辑，未把校准报告改写称新执行。',ev(p,'report.md','lines13–19','准确的基线定义和精确费用。'),ev(p,'baseline-plan.json','decisions all3 scenarios/16weeks','完整可执行基线控制。'),ev(p,'baseline-business.json','expected_cost_exact/scenarios','与本次标准库业务回放全对象一致；事实收据见factual-audit.json。'),ev(p,'run.json','algorithm/command/execution_evidence','包内保留的真实底层运行元数据。'))
    row(p,'E02','half','周/产品/需求/同周上界正确，但没有写必需预存数量；能由读者相减不等于交付已明确给出。',ev(p,'report.md','lines37–42','例如P0周6需求10、上界0，但删去了至少10件预存结论。'))
    row(p,'E03','half','正确定位A周6–8容量15<MOQ20、开关0及真实流量；但仍只是指向其他供方/早期承诺，没有具体命名提前期替代或保持策略的依据。',ev(p,'report.md','lines44–48','约束正确，替代解释不完整。'),ev(p,'plan.json','decisions.supplier_disruption.truck_on[6:9][0]','真实开关均0，非错误分析。'))
    row(p,'E04','half','三场景最紧周3和现金−5369正确，但表中只剩末余额，没有对应开周现金/回款/支出分解。',ev(p,'report.md','lines26–32','省略实际−3389+0−1980来源。'),ev(p,'ledger.json','scenarios.*.weeks[3]','底层账可以验证，但说明没有完成解释分解。'))
    row(p,'E05','half','最大分量材料采购362509/10正确；表中没有比例和具体采购动作来源解释，符合部分锚点。',ev(p,'report.md','lines50–57','金额正确但比例未给出。'))
    row(p,'E06','half','另一个完整真实可行策略及费用477391/10成立，描述了调线动作，但没有说明1.5增量和产线费用/工时权衡。',ev(p,'report.md','lines15–19','只有策略成本对照和泛化声明。'),ev(p,'alternative-search.json','change/scenarios/week','base周15一件P2 F0→F1。'),ev(p,'alternative-business.json','expected_cost_exact','本次回放确认真实合法替代，但分析不足。'))
    row(p,'F01','half','运营表完整提供周0共同动作23行，全部数量正确；共同周1–3缺失，不能用机器plan已完整替代运营交接缺口。',ev(p,'operations.csv','all_scenarios week0,23rows','无错误动作，但共同后3周共69行未交接。'),ev(p,'report.md','line72','作者明确其余共同周待整理。'))
    row(p,'F02','half','base揭示后周4–15的276行动行完整正确；另两分支交接缺失。',ev(p,'operations.csv','base weeks4–15','实际只有base分支。'),ev(p,'report.md','line72','明确另两分支待整理。'))
    row(p,'F03','half','真实可行/非零gap与不是精确最优的措辞正确，但没有说明合成情景/新中断/信用等运营限制与应对影响。',ev(p,'report.md','lines7–9,72','保留数学终态限定，未保留运营局限段。'))
    row(p,'F04','full','已实际打开三张PNG；16周三场景的现金−5369信用线、费用堆叠和周内仓容240/100均与包内真实账一致，单位/图例可读。',ev(p,'figures/cash.png','entire rendered PNG','三曲线和正确信用底线。'),ev(p,'figures/cost.png','entire rendered PNG','三场景总费用与四分量。'),ev(p,'figures/storage.png','both rendered panels','阶段口径、零起点、仓容与图例准确。'))
    p='packet-e6e65912d893'
    row(p,'D07','zero','来源表把R0错误定位到supplier_terms.supplier_id，又把pack_units称卡车开关，属于明确身份/单位错误。',ev(p,'source-map.md','line2','R0应为raw_id，pack_units为每包件数。'))
    row(p,'E01','zero','报告声称已验证基线成本1，实际完整基线业务为241299/5=48259.8；已有正确附件不补偿明确错误结论。',ev(p,'report.md','line4','基线成本1错误。'),ev(p,'baseline-business.json','expected_cost_exact','numerator241299/denominator5。'))
    row(p,'E02','zero','报告称P0周6无须预存且同周能力足够；公开产能上界0而需求10，必要预存10，结论相反。',ev(p,'report.md','line5','错误否认必需预存。'),ev(p,'normalized.json','scenarios.base.plant_capacity_hours[6]/demand[6][0]','资格/工时计算同周P0上界0。'))
    row(p,'E03','zero','把容量15下的MOQ20解释为可启运并要求A开关1，与约束及实际策略开关0相反。',ev(p,'report.md','line6','不可执行的供应建议。'),ev(p,'operations.csv','line416','同时把该中断场景周6A开关改为1，真实plan为0。'))
    row(p,'E04','zero','把应收24150加入现金，得到18781而否认实际−5369；回款未到账，不能补周3信用。',ev(p,'report.md','line7','AR当现金的明确错误。'),ev(p,'ledger.json','scenarios.*.weeks[3].cash/receipts','实际cash−5369、receipts0。'))
    row(p,'E05','zero','声称生产为最大费用来源；实际材料采购36250.9远高于生产5800.8。',ev(p,'report.md','line8','主导费用结论错误。'),ev(p,'ledger.json','all scenario purchase_cost/production_cost weighted totals','公开概率加权可直接重算。'))
    row(p,'E06','zero','称替代比主方案便宜1.5；实际替代47739.1比主47737.6贵1.5，经济结论方向相反。',ev(p,'report.md','line4','错误成本权衡。'),ev(p,'alternative-business.json','expected_cost_exact','477391/10，主方案238688/5。'))
    row(p,'F01','zero','共同动作表周0A/R0订单给6包而真实策略5包，运营者将执行错误承诺；不能因其余行完整给半分。',ev(p,'operations.csv','line3','all_scenarios,0,order,A,R0,6应为5。'),ev(p,'plan.json','decisions.base.order_lots[0][0][0]','真实5包。'))
    row(p,'F02','zero','后续分支交接把supplier_disruption周6A开关设1，与实际条件策略0及容量/MOQ不符。',ev(p,'operations.csv','line416','错误条件行动。'),ev(p,'report.md','lines6,10','明确要求立即按错误行动执行。'))
    row(p,'F03','zero','断言精确全局最优且保证所有未给中断履约，超出非零gap与有限场景的可核验结果。',ev(p,'report.md','line3','两项明确过度结论。'),ev(p,'solver-result.json','termination/solver_gap_scaled_by_primal','非零gap，不是全局精确或未列情景保证。'))
    row(p,'F04','zero','已实际打开三张PNG：只有only一个场景/单周点，cash约94与floor0、cost6、仓容4/1。它们不是本16周三场景和cap240/100的数据，核心对象错误而非仅缺图例。',ev(p,'figures/cash.png','actual rendered image','only/一周与94现金错误对象。'),ev(p,'figures/cost.png','actual rendered image','单场景总6不是约4.8万。'),ev(p,'figures/storage.png','actual rendered image','cap4/1不是240/100。'),ev(p,'report.md','line10','明确声称图代表本16周三场景。'))
    p='packet-ec4f68ffa499'
    row(p,'D07','full','四类事实的文件、显式index、联合身份和单位均准确定位，涵盖全部目录/供应/BOM产线/情景设施。',ev(p,'source-map.md','lines3–19','11CSV和facility完整映射。'))
    row(p,'E01','full','完整基线为本次首incumbent，241299/5与真实业务回放相同，定义和验证一致；本轮底层真实执行未编辑。',ev(p,'report.md','lines13–19','正确基线定义与结果。'),ev(p,'baseline-plan.json','all controls','实际可执行全期基线。'),ev(p,'baseline-business.json','expected_cost_exact/scenarios','与本次标准库回放完整一致。'),ev(p,'run.json','algorithm/command/execution_evidence','保留真实底层运行元数据。'))
    row(p,'E02','full','给出六处正确周/产品、同周能力和最低预存量，并核对实际前周库存。',ev(p,'report.md','lines38–43','例如P0周6上界0/需求10→最低库存10；P3周9上界3/需求4→1。'))
    row(p,'E03','full','准确说明A中断排除当周正装运而不抹掉在途；按A一周/B两周/C当周提前期列出实际来源和真实基线替代，解释可行选择集及不强迫翻转。',ev(p,'report.md','lines76–87','具体主方案/基线订单周与到货件数，与包内真实计划一致。'),ev(p,'plan.json','supplier_disruption orders weeks4–6/truck_on[6]','表内真实流量可重算，开关0。'),ev(p,'baseline-plan.json','supplier_disruption orders weeks4–6','替代完整基线真实可行。'))
    row(p,'E04','full','明确定位三场景周3资金瓶颈，开周−3389/收款0/支出1980→−5369，并明确AR24150不是现金。',ev(p,'report.md','lines28–34','实际来源分解完整准确。'),ev(p,'ledger.json','scenarios.*.weeks[3]','数值与真实账一致。'))
    row(p,'E05','full','最大采购362509/10与75.94%正确，四费用和比例准确，可追溯到采购/装运/生产/库存动作。',ev(p,'report.md','lines53–58,68','量化费用及运营账定位。'),ev(p,'ledger.json','per-week order_lots/purchase_cost','概率加权采购构成可重算。'))
    row(p,'E06','full','另一完整可行策略使base周15P2 F0→F1：每件成本14→17，概率1/2故总增1.5；说明工时转移、库存不变及无模型外收益，权衡与事实相符。',ev(p,'report.md','line89','明确增量费用与产能含义。'),ev(p,'alternative-business.json','expected_cost_exact/scenarios','完整合法策略验证477391/10。'),ev(p,'normalized.json','production_cost_minor[*][2]/production_hours[2]','成本14/17，工时1。'))
    row(p,'F01','full','共同周0–3共92条采购/装运/生产动作齐全准确，身份/数量/单位可直接操作。',ev(p,'operations.csv','all_scenarios weeks0–3','本次逐条比较92行无错误/缺漏。'))
    row(p,'F02','full','三个揭示后分支周4–15各276条动作完整准确，分支ID与信息边界清楚，不改已承诺动作。',ev(p,'operations.csv','base/supplier_disruption/demand_shift weeks4–15','本次逐条比较828行正确。'),ev(p,'report.md','lines24,68','说明共同前缀与后续场景定位。'))
    row(p,'F03','full','限制科学措辞准确，并说明有限情景/信用/新中断下需重建复核的运营影响，不将5369当最小信用或非零gap当精确最优。',ev(p,'report.md','lines7–9,72,91','未知边界与具体决策影响清楚。'))
    row(p,'F04','full','已实际打开三张真实PNG，16周三场景/正确现金与费用/仓容阶段数据和图例单位准确可读；与包内账一致。',ev(p,'figures/cash.png','entire rendered image','正确3场景/信用−5369/周0–15。'),ev(p,'figures/cost.png','entire rendered image','总费用47142/48040/48773与四分量。'),ev(p,'figures/storage.png','both rendered panels','raw cap240、FGcap100、阶段口径和零起点准确。'))
    for p in ['packet-97ad1f63e52c','packet-e6e65912d893','packet-ec4f68ffa499']:
        row(p,'F05','full','按本轮明确隔离合同，只评共同未编辑README/raw/source与真实完整独立冷复建卡。声明依赖/命令已由另一执行者（即此前此独立审查者）实际照说明重建成功，无缺失步骤；不声称任一编辑报告由该源码新执行产生。',common('source/README.md','dependency paragraph/command/defaults','声明环境与真实调用一致。'),common('terminal-inspect.json','Config.Cmd/Mounts/State','readonly原输入源码、新结果、自然exit0。'),common('REVIEW.md','实际执行与输入身份/独立结果','真实完整1253.251231s冷复建卡，非此轮新运行。'))
    ids=[r['id'] for r in json.loads((SNAP/'anchors.json').read_text(encoding='utf-8'))['criteria']]
    ratings.sort(key=lambda r:(r['packet_id'],ids.index(r['leaf'])))
    assert len(ratings)==36 and len({(r['packet_id'],r['leaf']) for r in ratings})==36 and all(r['judgement'] in ('full','half','zero') for r in ratings)
    result={'format':'l06-label-masked-initial-review/1','sealed_utc':datetime.now(timezone.utc).isoformat(),'rater':'independent-agent-benchmark_review','prior_familiarity':'Previously audited original reference/source/full execution; this is label masking only, not novel content or human double-blind.','author_key_read':False,'author_construction_script_read':False,'scope':'36 original independent first judgements on controlled components; not candidate grades, overall47 score, expert consensus or benchmark maturity','underlying_execution_interpretation':'Per supplied scope, baseline/plan/business/real underlying execution are shared unchanged facts; report/maps/operations/PNG are edited components. Non-F05 judgements evaluate packet content against those facts; F05 separately evaluates the common real cold-rebuild card.','ratings':ratings,'candidate_total_score':None,'maturity_approved':False}
    save(ROOT/'INITIAL-RATINGS.json',result)
    lines=['# 原始独立初评（标签未揭示）','','已先封存36项full/half/zero；未读取作者key或构造脚本。此前熟悉原始参考，身份为独立AI agent；本轮只构成标签遮蔽的组件开发校准，不是真人双盲或候选成绩。','','| 匿名包 | 叶 | 初评 | 实际依据 |','| --- | --- | --- | --- |']
    for r in ratings:lines.append('| '+r['packet_id']+' | '+r['leaf']+' | '+r['judgement']+' | '+r['observation'].replace('|','/')+' |')
    (ROOT/'INITIAL-RATINGS.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    save(ROOT/'visual-observations.json',{'actual_view_image_calls':9,'images_deduplicated':False,'packets':{'packet-97ad1f63e52c':'All3 PNGs actually opened: correct16-week/3-scenario cash, costs, stage caps240/100; units/legend readable.','packet-e6e65912d893':'All3 PNGs actually opened: only one scenario/week; cash94/floor0, totalcost6, rawcap4/FGcap1 contradict target16-week3-scenario ledger. Core object/data error.','packet-ec4f68ffa499':'All3 PNGs actually opened: correct16-week3-scenario data/units/legend; axes and stage capacities match.'},'method':'view_image actual rendered pixels, not source string or image existence','author_labels_observed':False})
    counts={p:{j:sum(r['packet_id']==p and r['judgement']==j for r in ratings) for j in ('full','half','zero')} for p in sorted({r['packet_id'] for r in ratings})}
    print(json.dumps({'sealed_file':str(ROOT/'INITIAL-RATINGS.json'),'count':36,'descriptive_counts_only':counts,'candidate_total_score':None},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
