"""Verify provided information and seal eight label-masked first ratings."""
from datetime import datetime,timezone
from fractions import Fraction
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent;SNAP=ROOT/'allowed-source-snapshot';CONTEXT=SNAP/'context'
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,x):
    if p.exists():raise RuntimeError('preserve original '+str(p))
    p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def main():
    oracle=load(CONTEXT/'oracle-plan.json');d=load(CONTEXT/'oracle-normalized.json');led=load(CONTEXT/'oracle-ledger.json');summary=load(CONTEXT/'oracle-summary.json')
    first='material-ae256af46be0';second='material-ee7b28ad5ec8';a=SNAP/'packets'/first;b=SNAP/'packets'/second
    partial=load(a/'handoff.json');full=load(b/'plan.json');fields=('order_lots','truck_on','production')
    assert full==oracle
    assert all(load(b/n)==load(CONTEXT/('oracle-'+n)) for n in ('ledger.json','normalized.json','summary.json'))
    assert set(partial['common'])=={'0'} and set(partial['conditional'])=={'base'}
    assert all(partial['common']['0'][f]==oracle['decisions']['base'][f][0] for f in fields)
    branch=partial['conditional']['base'];assert branch['when_scenario']=='base' and branch['first_week']==4 and all(branch['actions'][f]==oracle['decisions']['base'][f][4:] for f in fields)
    for folder in (a,b):
        c=load(folder/'operator-context.json');assert c['timing']=={'common_weeks':[0,1,2,3],'reveal_before_week':4,'week_index_origin':0}
        assert c['catalogs']=={'suppliers':[r['id'] for r in d['suppliers']],'raw_materials':d['raw_materials'],'plants':d['plants'],'products':d['products']}
        assert c['pack_units']=={r['id']:r['pack_units'] for r in d['suppliers']}
    assert all(full['decisions'][s][f][:4]==full['decisions']['base'][f][:4] for s in full['decisions'] for f in fields)
    x=load(b/'EXPLANATIONS.json');cash_facts=[]
    for sid,claim in x['cash'].items():
        t=claim['week'];r=load(b/'ledger.json')['scenarios'][sid]['weeks'];cash_facts.append({'scenario':sid,'week':t,'cash':claim['cash'],'identity_passed':claim['cash']==claim['opening']+claim['receipts']-claim['spending']==r[t]['cash'],'opening_located':claim['opening']==r[t-1]['cash'],'receipts_spending_located':(claim['receipts'],claim['spending'])==(r[t]['receipts'],r[t]['cost']),'actually_tightest':claim['cash']==min(w['cash'] for w in r)})
    assert all(all(v for k,v in r.items() if k not in ('scenario','week','cash')) for r in cash_facts)
    numerator=sum(Fraction(s['probability_numerator'],d['probability_denominator'])*sum(w['purchase_cost'] for w in led['scenarios'][s['id']]['weeks']) for s in d['scenarios'])
    denominator=Fraction(summary['expected_cost_minor']['numerator'],summary['expected_cost_minor']['denominator']);major=x['major_cost']
    assert Fraction(major['numerator_exact'])==numerator==Fraction(major['amount_exact']) and Fraction(major['denominator_exact'])==denominator and Fraction(major['share_exact'])==numerator/denominator
    action_purchase=sum(Fraction(s['probability_numerator'],d['probability_denominator'])*sum(full['decisions'][s['id']]['order_lots'][t][k][m]*r['pack_units'][m]*r['price_minor'][m] for t in range(d['weeks']) for k,r in enumerate(d['suppliers']) for m in range(len(d['raw_materials']))) for s in d['scenarios']);assert action_purchase==numerator
    e=load(a/'EXPLANATIONS.json');assert e['cash_conclusion']['cash']==led['scenarios']['base']['weeks'][3]['cash'] and Fraction(e['major_cost_conclusion']['amount_exact'])==numerator
    audit={'scope':'Context oracle only verifies actually supplied values; no oracle actions are inserted into either package. No solver/Provider/Docker/GPU/UI.','partial':{'common_weeks_actually_supplied':[0],'complete_branch_actually_supplied':['base'],'partial_handoff_values_match_oracle':True,'other_common_weeks_present':[],'other_branch_actions_present':[],'operative_scalar_actions_available':299},'full':{'plan_object_equals_oracle':True,'all3_branches_all16_weeks3_control_arrays_actual':True,'operator_index_units_information_sets_explicit':True,'common_prefix_same_across_scenarios':True,'operative_scalar_actions_available':920,'cash_formula_actual_data_checks':cash_facts,'purchase_action_sum_exact':str(action_purchase),'share_exact':str(numerator/denominator),'all_explanation_located_files_present_in_package':True},'oracle_used_to_fill_missing_package_information':False}
    save(ROOT/'factual-audit.json',audit)
    ratings=[]
    def row(p,i,j,o,evidence):ratings.append({'packet_id':p,'leaf':i,'judgement':j,'observation':o,'evidence':evidence})
    def ref(p,n,locator,note):return {'path':'allowed-source-snapshot/packets/'+p+'/'+n,'locator':locator,'observation':note}
    row(first,'E04','half','base周3现金−5369正确，但只交结论，未给回款/支出来源或对应公式和字段；公共现金定义和评估oracle不能替候选写出解释。',[ref(first,'EXPLANATIONS.json','cash_conclusion','仅scenario/week/cash，无来源解释。')])
    row(first,'E05','half','最大采购分量362509/10正确，但只交金额，缺份额表达式/可定位分子分母和采购动作解释。',[ref(first,'EXPLANATIONS.json','major_cost_conclusion','component与amount_exact正确，未交份额/动作。')])
    row(first,'F01','half','包内JSON确实只提供周0完整共同动作；其他共同周不存在于任何已交动作材料。现有动作与目录/单位正确，不因JSON而扣分，不用评估oracle补周1–3。',[ref(first,'handoff.json','common keys=[0]','周0三类动作完整准确。'),ref(first,'HANDOFF.md','entire text','明确其他共同周未提供，且包内无完整plan。'),ref(first,'operator-context.json','timing/catalogs/units/pack_units','索引和包装/件数/0/1说明充分。')])
    row(first,'F02','half','JSON只交base条件分支first_week4的完整12周动作，另两分支在已交材料中均无动作；半分原因是真实缺信息，不是表格格式。',[ref(first,'handoff.json','conditional.base.when_scenario/first_week/actions','base完整且数值正确，其他分支未交。'),ref(first,'HANDOFF.md','entire text','说明另两分支无动作，不得读oracle代用。')])
    row(second,'E04','full','JSON按三个场景定位真实最紧周3、现金−5369，明确opening−3389+receipts0−spending1980及恒等式/实际账字段和四周回款/AR边界；无需换成固定表或再抄账。',[ref(second,'EXPLANATIONS.json','cash.*','实际字段与公式经独立数值核对。'),ref(second,'ledger.json','scenarios.*.weeks[2:4]','所有引用真实提供，来源数值和最紧周正确。')])
    row(second,'E05','full','JSON给采购362509/10、期望总成本238688/5、份额362509/477376及采购包装×件数×单价×概率公式；引用本包计划/规范事实/账/汇总真实齐全，比例与动作可追溯，未打印百分数不影响满分。',[ref(second,'EXPLANATIONS.json','major_cost','明确份额公式、精确分子分母与action_trace/locators。'),ref(second,'plan.json','decisions.*.order_lots','已交真实全量采购动作。'),ref(second,'normalized.json','suppliers/scenarios','包装/单价/概率已交。'),ref(second,'summary.json','expected_cost_minor','精确分母已交。')])
    row(second,'F01','full','完整JSON实际覆盖全部场景16周三动作，前0–3周相同；HANDOFF明确采用base共同前缀，有序身份/单位/周序/信息集齐备，不需要CSV或程序才能定位执行。',[ref(second,'plan.json','decisions.*.{order_lots,truck_on,production}[0:4]','全共同周动作真实齐全且一致。'),ref(second,'HANDOFF.md','entire text','明确共同动作路径与数组索引。'),ref(second,'operator-context.json','timing/catalogs/units/pack_units','完整索引/单位与公开事实相符。')])
    row(second,'F02','full','同一JSON完整提供三条观测scenario ID对应周4–15的动作，HANDOFF说明揭示后选分支且不重写前缀，身份/单位和所有动作可直接定位。',[ref(second,'plan.json','decisions.{base,supplier_disruption,demand_shift} controls[4:16]','实际每分支每周数组完整，与oracle仅作验证比对一致。'),ref(second,'HANDOFF.md','entire text','明确观测ID触发与三动作数组使用。'),ref(second,'operator-context.json','reveal_before_week/week_index_origin/catalogs','信息边界、周序、索引正确。')])
    assert len(ratings)==8 and len({(r['packet_id'],r['leaf']) for r in ratings})==8
    save(ROOT/'INITIAL-8-RATINGS.json',{'format':'l06-equivalent-format-label-masked-initial/1','sealed_utc':datetime.now(timezone.utc).isoformat(),'rater':'independent-agent-benchmark_review','author_key_read':False,'construction_script_read':False,'prior_reference_familiarity':True,'context_oracle_used_to_fill_candidate_material':False,'scope':'Controlled format/information calibration only, not candidates or total scores. Initial8 sealed before old-packet adjudication.','ratings':ratings,'candidate_score':None,'professional_maturity_approved':False})
    lines=['# 8项原始独立初评（标签未揭示）','','只按实际已交信息评级；oracle仅核算，不补交付。已熟悉原参考，独立AI agent，非真人双盲。','','| 匿名包 | 叶 | 初评 | 依据 |','| --- | --- | --- | --- |']
    for r in ratings:lines.append('| '+r['packet_id']+' | '+r['leaf']+' | '+r['judgement']+' | '+r['observation']+' |')
    (ROOT/'INITIAL-8-RATINGS.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(json.dumps({'initial8_file':str(ROOT/'INITIAL-8-RATINGS.json'),'ratings':[{k:r[k] for k in ('packet_id','leaf','judgement')} for r in ratings]},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
