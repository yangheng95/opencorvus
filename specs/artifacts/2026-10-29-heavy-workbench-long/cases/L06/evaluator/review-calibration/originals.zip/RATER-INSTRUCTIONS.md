# 标签遮蔽的人评开发校准

只读取packets/三个匿名包、anchors.json和common/真实原始事实/执行卡；禁止读取AUTHOR-KEY-DO-NOT-PASS-TO-RATER.json或本准备脚本。逐包评价12个independent_review叶full/half/zero，逐叶给可定位证据和说明。请先独立保存初评，不讨论或看主方预期，再指出歧义；不要为一致率而迁就假定标签。全部F04必须用view_image看该包实际三PNG（可同一张图去重打开时明确其真实文件同值身份，但不能只按文件名）。不要运行新solver、Docker、Provider、GPU、UI自动化或再委托。

材料是受控编辑的组件校准，不是候选；F05明确共用独立真实源码复建卡，其他11叶按各包自己的报告/来源/操作表/图。评级不构成47叶总分或benchmark难度。你此前熟悉原参考，请披露这种熟悉程度和agent身份，标签未知不等于内容完全新鲜或真人双盲。写到新independent/目录，保留原始初评与证据，不改包/主方key。
