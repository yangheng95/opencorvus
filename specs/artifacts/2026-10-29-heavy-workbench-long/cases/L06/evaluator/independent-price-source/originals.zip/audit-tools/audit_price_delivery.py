"""Audit the single naturally completed source-only replay; runs no optimizer."""
import ast
import csv
from datetime import datetime
from decimal import Decimal
from fractions import Fraction
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import sys
import time
sys.dont_write_bytecode=True
from reviewer_io import ROOT,save

OUT=ROOT/'results/delivery'
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def module(name,p):
    spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def command(argv,label,code=0):
    start=time.perf_counter();p=subprocess.run(argv,cwd=ROOT,capture_output=True,text=True,encoding='utf-8')
    folder=ROOT/'assessment'/label;folder.mkdir(parents=True,exist_ok=False)
    (folder/'stdout.txt').write_text(p.stdout,encoding='utf-8');(folder/'stderr.txt').write_text(p.stderr,encoding='utf-8')
    receipt={'argv':argv,'exit_code':p.returncode,'seconds':time.perf_counter()-start,'expected_exit_code':code}
    save(folder/'command.json',receipt);return receipt

def exact_vector(d,plan,business,model):
    lookup={};M=len(d['raw_materials']);J=len(d['products']);P=len(d['plants']);S=len(d['suppliers'])
    for s in d['scenarios']:
        name=s['id'];a=plan['decisions'][name]
        for t,row in enumerate(business['scenarios'][name]['weeks']):
            for k in range(S):
                lookup[('truck',name,t,k)]=a['truck_on'][t][k]
                for m in range(M):lookup[('q',name,t,k,m)]=a['order_lots'][t][k][m]
            for p in range(P):
                for j in range(J):lookup[('produce',name,t,p,j)]=a['production'][t][p][j]
            for m in range(M):lookup[('raw',name,t,m)]=row['raw_inventory'][m]
            for j in range(J):lookup[('fg',name,t,j)]=row['finished_inventory'][j]
    v=[lookup[tuple(k)] for k in model['variable_keys']]
    boxes=all(type(x) is int and lo<=x<=hi for lo,x,hi in zip(model['variable_lower'],v,model['variable_upper']))
    violations=[]
    for i,row in enumerate(model['rows']):
        a=sum(c*v[j] for j,c in row['terms'])
        if row['lower'] is not None and a<row['lower'] or row['upper'] is not None and a>row['upper']:violations.append({'row':i,'activity':a})
    objective=Fraction(sum(c*x for c,x in zip(model['objective_numerators'],v)),model['objective_denominator'])
    return {'variable_keys':model['variable_keys'],'values':v,'integer_box_passed':boxes,'rows':len(model['rows']),'row_violations':violations,'objective_exact':str(objective)}

def main():
    if not (ROOT/'terminal-inspect.json').is_file():raise RuntimeError('wait for saved natural terminal inspection')
    terminal=load(ROOT/'terminal-inspect.json')
    if terminal['State']['Running']:raise RuntimeError('active snapshots are not final assessment')
    if terminal['State']['ExitCode']!=0:save(ROOT/'stage-assessment.json',{'result':'program_failed','terminal':terminal['State'],'full_case_approved':False});return
    data=load(ROOT/'independent-normalized.json');model=load(OUT/'model.json');run=load(OUT/'run.json');native=load(OUT/'solver-result.json')
    own=module('independent_business_math',ROOT/'audit-tools/independent_math.py')
    checks=[]
    def check(name,ok,detail=None):checks.append({'contract':name,'passed':bool(ok),'detail':detail})
    check('registered_price_input_and_independent_model_coverage',load(ROOT/'input-model-identity.json')['same_complete_business_facts_as_registered_capture'] and load(ROOT/'business-model-coverage.json')['all_business_model_checks_passed'])
    check('actual_program_normalization_matches_independent',load(OUT/'normalized.json')==data)
    business={};vectors={};independent={};python='C:/Python314/python.exe'
    for label,file in [('primary','plan.json'),('baseline','baseline-plan.json'),('alternative','alternative-plan.json')]:
        plan=load(OUT/file);path=ROOT/'assessment'/(label+'-business.json');path.parent.mkdir(exist_ok=True)
        receipt=command([python,'-X','utf8','-B',str(ROOT/'evaluation-source/check_l06.py'),'--input',str(ROOT/'independent-normalized.json'),
          '--plan',str(OUT/file),'--out',str(path)],label+'-business')
        check(label+'.actual_business_checker',receipt['exit_code']==0)
        business[label]=load(path);independent[label]=own.independent(data,plan)
        check(label+'.independent_business_feasible',independent[label]['business_feasible'])
        vector=exact_vector(data,plan,business[label],model);vectors[label]=vector;save(ROOT/'assessment'/(label+'-exact-vector.json'),vector)
        check(label+'.1488_integer_boxes_1096_rows',len(vector['values'])==1488 and vector['rows']==1096 and vector['integer_box_passed'] and not vector['row_violations'])
    check('full_primary_ledger_and_summary_match_independent',independent['primary']['ledger']==load(OUT/'ledger.json') and independent['primary']['summary']==load(OUT/'summary.json'))
    namespace={'Fraction':Fraction,'time':time,'save':save,'load':load}
    tree=ast.parse((ROOT/'audit-tools/prefix925.py').read_text(encoding='utf-8'));fun=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='audit_full')
    exec(compile(ast.Module(body=[fun],type_ignores=[]),'independent_prefix925','exec'),namespace)
    workspace=ROOT/'assessment/prefix'
    for path,value in [(workspace/'snapshot/v2/inputs/full.json',data),(workspace/'snapshot/v2/full-witness/plan.json',load(OUT/'plan.json')),
      (workspace/'replay/v2/full-business-contracts/complete-feasible-credit-witness/result.json',business['primary'])]:save(path,value)
    namespace['ROOT']=workspace;namespace['SNAP']=workspace/'snapshot';prefix=namespace['audit_full']()
    check('independent925_prefix_checks',prefix['all_checks_passed'])
    numeric_out=ROOT/'assessment/numeric30.json'
    nr=command([python,'-X','utf8','-B',str(ROOT/'evaluation-source/l06_numeric.py'),'--case-root',str(ROOT/'evaluation-case'),
       '--input',str(ROOT/'input'),'--normalized',str(OUT/'normalized.json'),'--plan',str(OUT/'plan.json'),
       '--summary',str(OUT/'summary.json'),'--ledger',str(OUT/'ledger.json'),'--out',str(numeric_out)],'numeric30')
    numeric=load(numeric_out)
    check('30_numeric_pass_17_unassessed_no_total',nr['exit_code']==0 and numeric.get('counts',{}).get('verified_pass')==30 and numeric.get('counts',{}).get('unassessed')==17 and numeric['total_score'] is None)
    C=independent['primary']['cost'];L=Fraction(47380);gap=(C-L)/L
    check('fixed47380_not_merely_native_gap',C>=L and gap<=Fraction(1,100),{'C':str(C),'L':str(L),'relative_gap_exact':str(gap)})
    events=[json.loads(x) for x in (OUT/'solver/events.jsonl').read_text(encoding='utf-8').splitlines()]
    check('actual_first_incumbent_baseline',load(OUT/'baseline-plan.json')==load(OUT/'solver/first-plan.json') and
      str(Fraction(events[0]['objective_exact']))==vectors['baseline']['objective_exact'])
    check('strict_improving_event_sequence',len(events)==native['improving_incumbents'] and all(a['objective_scaled_exact']>b['objective_scaled_exact'] for a,b in zip(events,events[1:])))
    final_values=load(OUT/'solver/final-values.json');native_cost=Fraction(native['objective_exact'])
    native_vector_obj=Fraction(sum(c*v for c,v in zip(model['objective_numerators'],final_values['values'])),model['objective_denominator'])
    check('native_saved_vector_objective',final_values['variable_keys']==model['variable_keys'] and native_vector_obj==native_cost)
    expected_native_label='primary' if C==native_cost else 'alternative'
    check('delivered_vs_native_policy_distinction',C<=native_cost and final_values['values']==vectors[expected_native_label]['values'])
    check('real_alternative_different_controls',any(load(OUT/'plan.json')['decisions'][s['id']][f]!=load(OUT/'alternative-plan.json')['decisions'][s['id']][f]
      for s in data['scenarios'] for f in ('order_lots','truck_on','production')))
    check('run_metadata_versions_and_parameters',run['parameters']=={'workers':8,'seed':20261029,'relative_gap':.009,'solver_seconds':None,'warm_start':None} and
       native['native_time_policy']=='unset default infinite' and native['warm_start'] is None)
    check('observed_native_gap_status_is_qualified_not_exact_optimum',native['status']=='OPTIMAL' and native['termination']=='optimal_within_requested_gap' and
       native['solver_options']=={'relative_gap_limit':.009,'num_search_workers':8,'random_seed':20261029,'requested_max_time_in_seconds':None,'native_max_time_in_seconds':None} and
       native['solver_gap_scaled_by_primal']<=.009 and run['algorithm']['termination_kind']=='completed')
    stats=(OUT/'solver/response-stats.txt').read_text(encoding='utf-8')
    scaled_objective=Fraction(re.search(r'^objective: (.+)$',stats,re.M)[1]);scaled_bound=Fraction(re.search(r'^best_bound: (.+)$',stats,re.M)[1])
    check('native_response_stats_scaled_objective_bound_match',scaled_objective/native['objective_denominator']==native_cost and
       scaled_bound/native['objective_denominator']==Fraction(str(native['dual_bound'])))
    check('run_delivered_vs_native_cost_facts',Fraction(str(run['delivered_cost_minor']))==C and Fraction(str(run['native_solver']['objective_minor']))==native_cost)
    manifest=load(OUT/'manifest.json')
    check('manifest_resolves_new_output_only',all((OUT/p).resolve().is_relative_to(OUT.resolve()) and (OUT/p).is_file() for p in manifest['outputs'].values()))
    # Rebuild every handoff action from actual controls, without importing the
    # delivery's writer. This includes zeroes and all scenario branches.
    expected_actions=[];primary_plan=load(OUT/'plan.json')
    for si,s in enumerate(data['scenarios']):
        sid=s['id'];decisions=primary_plan['decisions'][sid]
        for t in range(data['weeks']):
            if t<data['common_weeks'] and si>0:continue
            information='all_scenarios' if t<data['common_weeks'] else sid
            for k,supplier in enumerate(data['suppliers']):
                expected_actions.append([information,str(t),'shipment',supplier['id'],'',str(decisions['truck_on'][t][k]),'0_or_1'])
                for m,raw in enumerate(data['raw_materials']):expected_actions.append([information,str(t),'order',supplier['id'],raw,str(decisions['order_lots'][t][k][m]),'pack_lots'])
            for p,plant in enumerate(data['plants']):
                for j,product in enumerate(data['products']):expected_actions.append([information,str(t),'production',plant,product,str(decisions['production'][t][p][j]),'pieces'])
    with (OUT/'operations.csv').open(newline='',encoding='utf-8') as f:
        rows=list(csv.reader(f))
    check('complete_handoff_all_common_and_recourse_actions',rows[0]==['scenario_or_information_set','week','action','entity','secondary_entity','quantity','unit'] and rows[1:]==expected_actions,{'actions':len(expected_actions),'common_weeks':data['common_weeks']})
    # Parse the generated report's numeric tables against independent monetary facts.
    report=(OUT/'report.md').read_text(encoding='utf-8');tables=[];current=[]
    for line in report.splitlines()+['']:
        if line.startswith('|'):current.append([x.strip() for x in line.strip('|').split('|')])
        elif current:tables.append(current);current=[]
    comparison=next(t for t in tables if t[0][0]=='策略')
    expected_costs={'本方案':C,'基线':independent['baseline']['cost'],'替代方案':independent['alternative']['cost']}
    check('report_cost_comparison_truth',all(Fraction(r[1])==expected_costs[r[0]] for r in comparison[2:]))
    cash_table=next(t for t in tables if t[0][0]=='场景');cash_ok=True
    for row in cash_table[2:]:
        sid,t=row[0],int(row[1]);ledger=independent['primary']['ledger']['scenarios'][sid]['weeks'];r=ledger[t]
        opening=data['initial_cash_minor'] if t==0 else ledger[t-1]['cash']
        cash_ok &= r['cash']==min(x['cash'] for x in ledger) and list(map(int,row[2:]))==[opening,r['receipts'],r['cost'],r['cash'],r['receivable']]
    check('report_bottleneck_week_cash_and_AR_truth',cash_ok)
    totals={key:sum((Fraction(s['probability_numerator'],data['probability_denominator'])*sum(r[key] for r in independent['primary']['ledger']['scenarios'][s['id']]['weeks']) for s in data['scenarios']),Fraction())
      for key in ('purchase_cost','freight_cost','production_cost','holding_cost')}
    labels={'材料采购':'purchase_cost','固定运费':'freight_cost','生产':'production_cost','持有':'holding_cost'}
    cost_table=next(t for t in tables if t[0][0]=='分量')
    check('report_component_cost_and_display_ratio_truth',all(Fraction(r[1])==totals[labels[r[0]]] and abs(Fraction(r[2].strip('%'))-totals[labels[r[0]]]/C*100)<=Fraction(1,200) for r in cost_table[2:]))
    prebuild=[]
    pattern=r'- (\w+)周(\d+)产品(\w+)需求(\d+)，即使独占各合资格产线，同周上界仅(\d+)，故进入该周前至少须有(\d+)件库存；实际前周库存为(\d+)。'
    for sid,t,prod,demand,upper,required,stock in re.findall(pattern,report):
        t=int(t);j=data['products'].index(prod);s=next(s for s in data['scenarios'] if s['id']==sid)
        cap=sum(s['plant_capacity_hours'][t][p]//data['production_hours'][j] for p in range(len(data['plants'])) if data['allowed'][p][j])
        actual=independent['primary']['ledger']['scenarios'][sid]['weeks'][t-1]['finished_inventory'][j]
        prebuild.append({'scenario':sid,'week':t,'product':prod,'passed':int(demand)==s['demand'][t][j] and int(upper)==cap and int(required)==int(demand)-cap>0 and int(stock)==actual>=int(required)})
    check('report_necessary_prebuild_claims_truth',bool(prebuild) and all(r['passed'] for r in prebuild));save(ROOT/'assessment/report-prebuild-claims.json',prebuild)
    mounts=terminal['Mounts'];check('actual_three_mount_isolation',len(mounts)==3 and {m['Destination']:m['RW'] for m in mounts}=={'/project':False,'/input':False,'/results':True} and terminal['HostConfig']['NetworkMode']=='none')
    started=datetime.fromisoformat(terminal['State']['StartedAt'].replace('Z','+00:00'));ended=datetime.fromisoformat(terminal['State']['FinishedAt'].replace('Z','+00:00'))
    save(ROOT/'assessment/checks.json',checks)
    result={'result':'complete_independent_raw_source_replay_numeric_and_report_passed' if all(c['passed'] for c in checks) else 'independent_replay_has_failures',
      'checks':len(checks),'all_passed':all(c['passed'] for c in checks),'failed_checks':[c['contract'] for c in checks if not c['passed']],
      'terminal_exit':terminal['State']['ExitCode'],'complete_container_seconds':(ended-started).total_seconds(),'main_seconds':run['elapsed_seconds'],'solver_seconds':native['seconds'],
      'cost_exact':str(C),'native_cost_exact':str(native_cost),'native_bound':native['dual_bound'],'fixed_registered_L':47380,'gap_relative_to_fixed_L_exact':str(gap),'gap_relative_to_fixed_L_percent':float(gap*100),
      'baseline_cost_exact':str(independent['baseline']['cost']),'alternative_cost_exact':str(independent['alternative']['cost']),
      'independent_prefix925':prefix,'numeric30':{'status':numeric['status'],'counts':numeric.get('counts'),'total_score':numeric['total_score'],'business_success':numeric['business_success']},
      'manual_figures_review':'pending','remaining17_leaves_scored':False,'DUT_hour_claim':False,'full47_grader_approved':False,'heavy_freeze_approved':False,
      'full16week_optimization_runs_by_reviewer':1,'Provider_calls':0,'GPU_work':False,'delegations':0}
    save(ROOT/'stage-assessment.json',result);print(json.dumps({k:v for k,v in result.items() if k!='independent_prefix925'},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
