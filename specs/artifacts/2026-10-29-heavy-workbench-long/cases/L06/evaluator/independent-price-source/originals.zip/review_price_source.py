"""Read-only audit of the completed price-source job; no optimizer/container calls."""
from datetime import datetime,timezone
import importlib.util,json
from pathlib import Path
import shutil,subprocess,sys,zipfile
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
RUN=Path('D:/opencorvus-benchmark-runs/l06-source-price-control-20261029')
BASE=Path('D:/opencorvus-benchmark-runs/l06-reference-chain-20261029/full-cold')
ROW=Path('D:/opencorvus-benchmark-runs/l06-reference-independent-review-20261029/full-cold-replay')
REPO=Path('D:/myhexin-local/opencorvus')
CASE=REPO/'specs/artifacts/2026-10-29-heavy-workbench-long/cases/L06'
REL='evaluator/qualification/v2/integer-search/quality-reference/registered-reference.json'
def save(path,value):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(value,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
def load(path):return json.loads(path.read_text(encoding='utf-8'))
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def main():
    (ROOT/'Recall.md').write_text('''# Recall\n\n仅只读已完成报价source-only真实运行，使用既有独立标准库输入/业务/模型/报告审计，不启动solver/Docker/Provider/GPU/UI或委托，不操作容器。只写本目录；完成后另获授权在既有grading私有根收集控制证据、追加D02 full文件而不覆盖原评级/未评结果。固定L47380/D02critical，其他具体评级不变；仍未冻结，不发布总分/成功。\n''',encoding='utf-8')
    tools=ROOT/'audit-tools';tools.mkdir(exist_ok=False)
    for n in ('independent_projection.py','independent_math.py','prefix925.py'):shutil.copy2(ROW/'audit-tools'/n,tools/n)
    shutil.copy2(Path('D:/opencorvus-benchmark-runs/l06-relaxation-independent-review-20261029/review_bound.py'),tools/'independent_model.py')
    shutil.copytree(RUN/'project',ROOT/'project');shutil.copytree(RUN/'input',ROOT/'input');shutil.copytree(RUN/'results',ROOT/'results')
    raw=ROOT/'run-originals';raw.mkdir()
    for n in ('prelaunch.json','launch.json','initial-inspect.json','terminal-inspect.json','stdout.log','stderr.log','log-collection.json','container.cid'):shutil.copy2(RUN/n,raw/n)
    terminal=load(raw/'terminal-inspect.json');terminal=terminal[0] if isinstance(terminal,list) else terminal
    reduced={k:terminal[k] for k in ('Id','Name','State','Path','Args','Image','Mounts')};reduced['Config']={k:terminal['Config'][k] for k in ('Cmd','Image','WorkingDir')};reduced['HostConfig']={k:terminal['HostConfig'][k] for k in ('NetworkMode','NanoCpus','CpusetCpus','DeviceRequests','Runtime')};save(ROOT/'terminal-inspect.json',reduced)
    assert terminal['Id']=='2e09ae3f0a13ce0331ed67aec39ecb687953aed155f793e41570a7b03cced6fd' and terminal['Name']=='/oc-l06-source-price-20261029-a' and terminal['State']['Status']=='exited' and terminal['State']['ExitCode']==0
    (ROOT/'stdout.log').write_bytes((raw/'stdout.log').read_bytes());(ROOT/'stderr.log').write_bytes((raw/'stderr.log').read_bytes())
    names=sorted(p.name for p in (ROOT/'project').iterdir() if p.is_file())
    identity=[{'name':n,'same_first_base_source_bytes':(ROOT/'project'/n).read_bytes()==(BASE/'project'/n).read_bytes(),'same_independent_row_source_bytes':(ROOT/'project'/n).read_bytes()==(ROW/'project'/n).read_bytes()} for n in names]
    assert len(names)==11 and sum(n.endswith('.py') for n in names)==9 and all(r['same_first_base_source_bytes'] and r['same_independent_row_source_bytes'] for r in identity)
    save(ROOT/'source-identity.json',{'files':identity,'meaning':'real source/README/DATA object identity only; functionality separately checked','same11_files':True})
    evaluate=ROOT/'evaluation-source';evaluate.mkdir()
    for n in ('l06_numeric.py','l06_grade.py','l06_input.py','l06_delivery.py','l06_packet.py','check_l06.py'):shutil.copy2(CASE/'evaluator/qualification/current-source'/n,evaluate/n)
    case=ROOT/'evaluation-case';(case/'public').mkdir(parents=True);shutil.copytree(CASE/'public/inputs',case/'public/inputs');shutil.copy2(CASE/'rubric.draft.json',case/'rubric.draft.json');(case/REL).parent.mkdir(parents=True)
    for n in ('registered-reference.json','originals.zip','price-control.zip'):shutil.copy2((CASE/REL).parent/n,(case/REL).parent/n)
    projection=module('price_raw_projection',tools/'independent_projection.py');data,counts=projection.independent_projection(ROOT/'input');base,_=projection.independent_projection(case/'public/inputs')
    expected=load(Path('D:/opencorvus-benchmark-runs/l06-variant-independent-review-20261029/fixtures/new-normalized.json'))
    assert data==expected
    with zipfile.ZipFile((case/REL).parent/'price-control.zip') as archive:captured=json.loads(archive.read('normalized.json'))
    captured={k:v for k,v in captured.items() if k not in ('status','qualification_variant')};assert data==captured
    save(ROOT/'independent-normalized.json',data)
    model=load(ROOT/'results/delivery/model.json');m=module('independent_price_model',tools/'independent_model.py');m.ROOT=ROOT;coverage=m.audit_model(data,model);assert coverage['all_business_model_checks_passed']
    save(ROOT/'input-model-identity.json',{'same_complete_business_facts_as_registered_capture':True,'semantic_input':'registered exact C/R0 45-to46 price control','row_counts':counts,'independent_business_model_all1488_variables1096_rows':True})
    # Reuse the previous independent audit code; only environment plumbing and
    # the identity predicate change. Model coverage is now reconstructed from
    # this variant raw, rather than compared with a base matrix.
    old=(ROW/'audit_full.py').read_text(encoding='utf-8')
    adapted=old.replace('from launch_full import ROOT,save','from reviewer_io import ROOT,save').replace("'semantic_raw_row_reorder_and_full_model_identity'","'registered_price_input_and_independent_model_coverage'").replace("model==load(ROOT/'registered-model.json')","load(ROOT/'business-model-coverage.json')['all_business_model_checks_passed']")
    (tools/'audit_price_delivery.py').write_text(adapted,encoding='utf-8')
    (tools/'reviewer_io.py').write_text("from pathlib import Path\nimport json\nROOT=Path(__file__).resolve().parent.parent\ndef save(p,v):\n p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\\n',encoding='utf-8')\n",encoding='utf-8')
    save(ROOT/'audit-adaptation.json',{'origin':str(ROW/'audit_full.py'),'changes':['ROOT/save import replaced by local IO only','first identity check renamed and uses independent raw model reconstruction for price variant'],'business_recurrence_or_report_arithmetic_changed':False})
    sys.path.insert(0,str(tools));audit=module('independent_price_delivery',tools/'audit_price_delivery.py');audit.main()
    git=subprocess.run(['git','status','--short','--','specs/artifacts/2026-10-29-heavy-workbench-long/cases/L06','specs/records/2026-10/2026-10-29-heavy-workbench-l06-qualification.md'],cwd=REPO,capture_output=True,text=True,encoding='utf-8');(ROOT/'git-status-start.txt').write_text(git.stdout,encoding='utf-8')

if __name__=='__main__':main()
