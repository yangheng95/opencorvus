# 交付与复跑合同（审查稿）

项目根含reproduce.py、依赖/构建说明和README。调用`python reproduce.py --input <原始inputs目录> --output <不存在的新目录>`，从传入资料计算并写新输出，不读取既有结果作为求解。其他语言可由该薄入口调用，不能依赖评估端模型/答案。

输出目录：

- `normalized.json`：DATA.md的完整业务事实投影。
- `plan.json`：下述唯一机器计划格式。允许不同的正确策略，不匹配参考轨迹。
- `ledger.csv`：每场景每周的物料/生产/装运/库存/费用/现金和应收明细；可以拆为清晰命名的多张CSV，在manifest中说明。
- `summary.json`：独立可复算的各场景总成本/最低与期末现金/期末应收、期望成本及概率；期望成本允许数值或分子/分母。
- `run.json`：真实执行的输入路径、命令、依赖/solver版本、实际参数、终态、可行性及已得界；未知值明确null/unknown，不把设施失败/限额状态写成最优。是否分线程、调用子agent及测时口径如实记录，不把重叠阶段相加。
- `report.md`和它引用的实际图表：基线核验、约束与动作的因果解释、费用和现金、运营交接、局限。图形须由交付数据生成；评分包含实际查看图形，不能只交脚本文字或图片文件名。
- `manifest.json`：上述文件/命令与报告依据的定位；不以无意义hash/摘要作为正确性条件。

plan.json对象的`format`为`l06-plan/1`，`decisions`恰按全部公开场景ID索引。每场景记录包含非负整数数组：

```text
order_lots[week][supplier_index][raw_index]
truck_on[week][supplier_index]                 # 每个值0或1
production[week][plant_index][product_index]
```

可另附`raw_inventory[week][raw_index]`和`finished_inventory[week][product_index]`，若提供必须与真实业务递推一致。它们是期末库存，不能代替TASK要求的两种阶段峰值。所有必须的现金/成本由评估者自己重算，不以自报summary或manifest证明物理可行。

若未完成，保留实际运行结果和未知原因；不能用空数组、伪造日志或未实际执行的命令冒充成功。研究交付完成与运营可行/成本达标分列。正式版本冻结前还需完成逐叶评价适配器、成本参考和输入变体可达性；当前不发布总分。
