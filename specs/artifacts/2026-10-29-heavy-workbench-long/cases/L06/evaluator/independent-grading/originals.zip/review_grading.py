"""Independent aggregation protocols and real non-blind reference observations."""
from datetime import datetime,timezone
from fractions import Fraction
import copy,json
from pathlib import Path
import shutil,subprocess,sys,time
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
REPO=Path('D:/myhexin-local/opencorvus')
CASE=REPO/'specs/artifacts/2026-10-29-heavy-workbench-long/cases/L06'
FULL=Path('D:/opencorvus-benchmark-runs/l06-reference-independent-review-20261029/full-cold-replay')
PYTHON='C:/Python314/python.exe'
REL='evaluator/qualification/v2/integer-search/quality-reference/registered-reference.json'
SID='anonymous-reference-development-01'
def save(path,value):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(value,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
def load(path):return json.loads(path.read_text(encoding='utf-8'))
def execute(argv,folder):
    folder.mkdir(parents=True,exist_ok=False);t=time.perf_counter();stamp=datetime.now(timezone.utc).isoformat();p=subprocess.run(argv,capture_output=True,text=True,encoding='utf-8')
    (folder/'stdout.txt').write_text(p.stdout,encoding='utf-8');(folder/'stderr.txt').write_text(p.stderr,encoding='utf-8')
    r={'argv':argv,'started_utc':stamp,'seconds':time.perf_counter()-t,'exit_code':p.returncode};save(folder/'command.json',r);return r

def main():
    source=ROOT/'source-initial';source.mkdir(exist_ok=False)
    for n in ('l06_grade.py','qualify_grading.py','l06_numeric.py','l06_input.py','l06_packet.py','l06_delivery.py','check_l06.py'):shutil.copy2(CASE/'evaluator/qualification/current-source'/n,source/n)
    case=ROOT/'case-initial';(case/'public').mkdir(parents=True);shutil.copytree(CASE/'public/inputs',case/'public/inputs');shutil.copy2(CASE/'rubric.draft.json',case/'rubric.draft.json');(case/REL).parent.mkdir(parents=True)
    for n in ('registered-reference.json','originals.zip','price-control.zip'):shutil.copy2((CASE/REL).parent/n,(case/REL).parent/n)
    shutil.copy2(CASE/'evaluator/GRADING.md',ROOT/'GRADING-initial.md')
    (ROOT/'Recall.md').write_text('''# Recall\n\n单层独立廉价审查l06_grade/qualify_grading、GRADING、publication；固定100/critical/half/未评/设施/未冻结不发分。只写本目录；无solver/Docker/Provider/GPU/UI/用户进程/再次委托。先运行协议资格，明确synthetic fixtures不等于实际评分；另为既有完整参考实际观察17叶制作私有rating。D02未跑源码变价保留unassessed，参考已熟悉，非盲、非真人专业校准、未冻结。\n''',encoding='utf-8')
    git=subprocess.run(['git','status','--short'],cwd=REPO,capture_output=True,text=True,encoding='utf-8');(ROOT/'git-status-start.txt').write_text(git.stdout,encoding='utf-8')
    protocol=ROOT/'protocol-replay'
    r=execute([PYTHON,'-X','utf8','-B',str(source/'qualify_grading.py'),'--case-root',str(case),'--reference-delivery',str(FULL/'results/delivery'),'--output',str(protocol)],ROOT/'protocol-command')
    if r['exit_code']:raise RuntimeError('protocol CLI qualification failed; preserve raw receipt')
    # Copy only observed evidence for private references. Nothing is passed to
    # an optimization program, and no fabricated rating is used in this file.
    evidence=ROOT/'actual-evidence';inventory=[]
    names=['launch.json','terminal-inspect.json','image-identity.json','source-inventory.json','input-model-identity.json','stage-assessment.json','manual-visual-review.json','REVIEW.md','remaining17-observations.json','assessment/checks.json','assessment/numeric30.json','assessment/prefix/independent-full-audit.json','assessment/report-prebuild-claims.json','assessment/report-interruption-checks.json','stdout.log','stderr.log','project/reproduce.py','project/README.md','project/DATA.md','project/l06_integer.py','results/delivery/report.md','results/delivery/source-map.md','results/delivery/operations.csv','results/delivery/run.json','results/delivery/manifest.json','results/delivery/alternative-search.json','results/delivery/solver-result.json','results/delivery/solver/response-stats.txt','results/delivery/figures/cash.png','results/delivery/figures/cost.png','results/delivery/figures/storage.png']
    for n in names:
        target=evidence/n;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(FULL/n,target);inventory.append({'original':str(FULL/n),'evidence_copy':str(target),'byte_equal_at_copy':(FULL/n).read_bytes()==target.read_bytes()})
    save(ROOT/'evidence-origin-map.json',inventory)
    bindings={'input':str((FULL/'input').resolve()),**{n:str((FULL/'results/delivery'/(n+'.json')).resolve()) for n in ('normalized','plan','summary','ledger')}}
    def ref(path,kind,locator,observation):return {'path':'actual-evidence/'+path,'kind':kind,'locator':locator,'observation':observation}
    terminal=ref('terminal-inspect.json','process_receipt','State/Config.Cmd/Mounts/HostConfig.NetworkMode','Actual owned independent container naturally exited0; readonly source/raw and fresh results, no network.')
    source_audit=ref('project/reproduce.py','source_audit','main, read_packet/build_model/solve_integer and alternative_policy','I read the actual source-only input/data flow and this run\u2019s fresh-search route; no archived answer or supplied hint read.')
    roworder=ref('input-model-identity.json','business_oracle','same_complete_business_facts_as_registered_capture/new_model_same_as_frozen_registered','Actual CSV-row reversal preserved all business facts; this is not a numerical variant source execution.')
    report=ref('results/delivery/report.md','report_or_table','actual report tables and limitations','I read the generated report and compared all numeric claims with the independent business oracle.')
    business=ref('assessment/prefix/independent-full-audit.json','business_oracle','925 checks/scenarios/objective','Independent cumulative physical and financial arithmetic passed all925 checks.')
    evidence_rows=[]
    def finding(i,judgement,observation,items):evidence_rows.append({'id':i,'judgement':judgement,'observation':observation,'evidence':items})
    finding('D01','full','Actual complete16-week independent source-only cold rebuild naturally exited0 and produced freshly evaluated delivery; no prior plan/model/hint/reference/rubric supplied.',[terminal,source_audit,business])
    finding('D02','unassessed','I observed real semantic CSV-row reversal, but this same sealed source was not actually cold-run on the registered numeric price control. A feasible variant witness cannot replace that execution.',[roworder])
    finding('D07','full','I checked all11 raw source families, joint identities, explicit index mapping and units; source-map and DATA correctly trace complete normalized business facts.',[ref('results/delivery/source-map.md','source_audit','all listed raw filenames/keys/units and facility mapping','Located source identities and units checked against raw packet and independent projection.'),roworder])
    finding('D08','full','Run/native report and actual exit agree: OPTIMAL means within requested gap. Saved native/API/response stats consistent; no exact-optimum claim.',[terminal,ref('results/delivery/solver-result.json','process_receipt','status/termination/objective/options','Actual solver reported OPTIMAL within requested nonzero gap; main and native costs47737.6 agree.')])
    finding('D09','full','This successful run really obtained a feasible plan and native bound47371. Report preserves their trust limits and does not fabricate unknown results; contract does not require extra failure executions.',[terminal,report])
    finding('D10','full','Actual readonly input/source paths, image, command and8workers/seed20261029/.009/no time limit/no hint match run metadata and launch.',[terminal,ref('launch.json','process_receipt','argv/container identity/solver_time_cap','Exact actual launch preserved.'),ref('results/delivery/run.json','process_receipt','command/dependencies/parameters','Metadata matches observed invocation and declared image.')])
    finding('E01','full','This run\u2019s first actual incumbent is a real feasible baseline:48259.8. It equals saved first-plan and independent business/matrix checks; no invented baseline.',[ref('assessment/checks.json','business_oracle','actual_first_incumbent_baseline/baseline checks','Baseline equality, business feasibility and full1488/1096 integer checks passed.'),report])
    finding('E02','full','Six necessary prebuild witnesses correctly identify weeks/products, independent same-week upper bounds and necessary prior stock, matching actual inventory.',[ref('assessment/report-prebuild-claims.json','business_oracle','all six passed entries','Independent demand/capacity arithmetic and actual prior inventories agree.'),report])
    finding('E03','half','The report correctly identifies supplierA capacity15<MOQ20 in disruption weeks6..8, switch0, actual arrivals/consumption and the infeasible choice. It points generically to other suppliers/early commitments but does not name and quantify a concrete supplier/lead-time substitute or clearly explain the strategy\u2019s retained sourcing choice. This meets the partial anchor; actual constraint facts are not wrong.',[ref('assessment/report-interruption-checks.json','business_oracle','three passed interruption entries','Actual supplier capacity, MOQ, switch, arrivals and consumption independently match.'),report])
    finding('E04','full','All scenarios\u2019 tightest week3: opening-3389 + receipts0 - spending1980 = -5369. Report gives actual cash/AR24150, four-week lag and clear future-AR warning; detailed costs are located in ledger.',[business,report])
    finding('E05','full','Actual largest cost purchase36250.9 and75.94% are accurate, all expected components/proportions checked, and quantities are traceable through the operational ledger/actions.',[ref('assessment/checks.json','business_oracle','report_component_cost_and_display_ratio_truth','Exact cost components and rounded display ratios independently recomputed.'),report])
    finding('E06','half','Actual second full feasible policy/cost verified: base week15 transfer1P2 F0\u2192F1, cost47739.1 versus47737.6. Report lists actions and costs but does not explain the incremental1.5 and production-line cost/capacity tradeoff, so the explicit partial economic-explanation anchor applies.',[ref('results/delivery/alternative-search.json','report_or_table','production_transfer/scenarios/week/attempts','Actual distinct controls were independently verified feasible.'),ref('assessment/checks.json','business_oracle','alternative business/model checks and report_cost_comparison_truth','Alternative47739.1 is feasible and exact; it is not counted as better.'),report])
    finding('F01','full','All92 common shipment/order/production actions for weeks0..3, with identity/quantity/units, match actual plan; includes zeroes and no scenario-specific early rewrite.',[ref('results/delivery/operations.csv','report_or_table','all_scenarios week0..3','Complete actionable common handoff compared row by row.'),ref('assessment/checks.json','business_oracle','complete_handoff_all_common_and_recourse_actions','All920 handoff rows match controls exactly.')])
    finding('F02','full','All828 recourse action rows for actual three scenario branches and weeks4..15 match the observed policy and declared revelation boundary.',[ref('results/delivery/operations.csv','report_or_table','scenario-specific weeks4..15','Branches accurately locate actions, without rewriting committed prefix.'),roworder])
    finding('F03','full','Report accurately qualifies native gap/trust, feasibility, synthetic scenarios, no-interest credit and ungiven futures; it does not use AR as cash or claim exact optimum, live-world validity or hours.',[report,terminal,business])
    finding('F04','full','I actually opened all three full-run PNGs with view_image and compared them with independent ledger. Cash floor/scenarios, stacked cost components and two physical storage stages are readable and faithful; storage axes start0.',[ref('results/delivery/figures/cash.png','rendered_figure','complete displayed image','Actual image viewed; cashfloor-5369 and final32208/31310/32737 match.'),ref('results/delivery/figures/cost.png','rendered_figure','complete displayed image','Actual image viewed; total47142/48040/48773, components/units/legend readable.'),ref('results/delivery/figures/storage.png','rendered_figure','both displayed panels','Actual image viewed; caps240/100, raw peak191, FG85/85/91 match.'),ref('manual-visual-review.json','report_or_table','all three detailed observations','Contemporaneous manual visualization review retained, not an image-existence test.')])
    finding('F05','full','As another executor I followed the README declared image/dependencies and command from new source/raw directories. Actual complete rebuild succeeded without supplied old results or additional missing setup.',[terminal,ref('project/README.md','source_audit','command/dependencies/defaults','Instructions matched actual successful execution.')])
    review={'format':'l06-review-evidence/1','case':'L06','submission_id':SID,'rater':{'id':'independent-agent-benchmark_review','role':'independent_evaluator','assignment':'Authorized parent task in this conversation: one-layer independent full cold replay and subsequent actual17-leaf reference-evidence review; no redelegation.'},'artifact_bindings':bindings,'findings':evidence_rows,'review_disclosure':{'non_blind_development_reference':True,'previously_familiar_with_reference':True,'human_professional_certification':False,'candidate_score':False,'schema_and_references_do_not_prove_rating_truth':True}}
    save(ROOT/'actual-review.json',review)
    def grade(label,review_path,submission_id=SID,evidence_root=ROOT):
        folder=ROOT/'executions'/label;argv=[PYTHON,'-X','utf8','-B',str(source/'l06_grade.py'),'--case-root',str(case),'--delivery-root',str(FULL/'results/delivery'),'--submission-id',submission_id]
        for key,path in bindings.items():argv+=['--'+key,str(path)]
        argv+=['--review',str(review_path),'--evidence-root',str(evidence_root),'--out',str(folder/'assessment.json')]
        receipt=execute(argv,folder);return receipt,load(folder/'assessment.json')
    receipt,assessment=grade('actual-reference-review',ROOT/'actual-review.json')
    assert receipt['exit_code']==4 and assessment['status']=='assessment_incomplete' and assessment['total_score'] is None and assessment['business_success'] is None
    assert assessment['unassessed']==['D02'] and assessment['counts']['verified_partial']==2 and assessment['counts']['verified_pass']==44
    # One new independent identity probe, explicitly synthetic. No real rating
    # is changed or promoted to a candidate score.
    bad=copy.deepcopy(review);bad['submission_id']='';save(ROOT/'synthetic-empty-submission.json',bad)
    rr,rv=grade('empty-submission-id-protocol-probe',ROOT/'synthetic-empty-submission.json',submission_id='')
    expected=rr['exit_code']==3 and rv['status']=='run_invalid' and rv['infrastructure_error']['code']=='review_evidence_invalid'
    algebra=load(protocol/'aggregation-fixtures.json');r=load(case/'rubric.draft.json');criteria=[c for g in r['groups'] for c in g['criteria']];weights={c['id']:Fraction(c['weight']) for c in criteria}
    independent_values={'full':100,'missing-critical-keeps-denominator':100-weights['D01'],'all-human-half':100-sum(weights[c['id']] for c in criteria if 'half' in c['anchors'])/2,'quality-failure-cannot-be-compensated':100-weights['C06']}
    assert all(Fraction(x['exact_points'])==independent_values[x['fixture']] for x in algebra['checks']) and sum(weights.values())==100
    save(ROOT/'independent-algebra.json',{'fixed_weight_sum':100,'expected_protocol_scores':{k:str(v) for k,v in independent_values.items()},'author_protocol_outputs_match':True,'scope':'Synthetic algebra only; no actual reference/candidate total score.'})
    result={'result':'has_identity_contract_gap' if not expected else 'aggregation_local_contract_qualified','protocol_cli_count':13,'protocol_exit':0,'independent_extra_cli_count':2,'actual_reference_status':assessment['status'],'actual_reference_counts':assessment['counts'],'actual_reference_total_score':assessment['total_score'],'D02_unassessed':True,'actual_half_leaves':['E03','E06'],'empty_submission_identity_rejected':expected,'full47_frozen':False,'candidate_grade':None,'blind_calibration':False,'solver_runs':0,'Docker_runs':0,'Provider_calls':0,'GPU_work':False,'delegations':0}
    save(ROOT/'stage-assessment-initial.json',result);print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
