# Recall

单层独立廉价审查l06_grade/qualify_grading、GRADING、publication；固定100/critical/half/未评/设施/未冻结不发分。只写本目录；无solver/Docker/Provider/GPU/UI/用户进程/再次委托。先运行协议资格，明确synthetic fixtures不等于实际评分；另为既有完整参考实际观察17叶制作私有rating。D02未跑源码变价保留unassessed，参考已熟悉，非盲、非真人专业校准、未冻结。
