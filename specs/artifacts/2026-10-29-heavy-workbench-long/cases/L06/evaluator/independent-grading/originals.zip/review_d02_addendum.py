"""One synthetic D02-critical aggregation call; no solver or new full run."""
from datetime import datetime,timezone
from fractions import Fraction
import copy,json
from pathlib import Path
import shutil,subprocess,sys,time
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
REPO=Path('D:/myhexin-local/opencorvus')
CASE=REPO/'specs/artifacts/2026-10-29-heavy-workbench-long/cases/L06'
def load(path):return json.loads(path.read_text(encoding='utf-8'))
def save(path,value):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def main():
    out=ROOT/'d02-critical-addendum';out.mkdir(exist_ok=False);source=out/'source';source.mkdir()
    for n in ('l06_grade.py','l06_numeric.py','l06_input.py','l06_packet.py','l06_delivery.py','check_l06.py'):shutil.copy2(CASE/'evaluator/qualification/current-source'/n,source/n)
    shutil.copy2(CASE/'rubric.draft.json',out/'rubric-current.json');shutil.copy2(CASE/'evaluator/GRADING.md',out/'GRADING-current.md');shutil.copy2(REPO/'specs/records/2026-10/2026-10-29-heavy-workbench-l06-qualification.md',out/'Recall-source.md')
    previous=load(ROOT/'case-initial/rubric.draft.json');current=load(out/'rubric-current.json')
    old={c['id']:c for g in previous['groups'] for c in g['criteria']};new={c['id']:c for g in current['groups'] for c in g['criteria']}
    changes=[{'leaf':i,'field':k,'old':old[i][k],'new':v} for i,c in new.items() for k,v in c.items() if old[i][k]!=v]
    assert changes==[{'leaf':'D02','field':'critical','old':False,'new':True}],changes
    assert len(new)==47 and new['D02']['weight']==4 and sum(Fraction(c['weight']) for c in new.values())==100
    sys.path.insert(0,str(source));from l06_numeric import load_rubric;from l06_grade import aggregate
    rubric,criteria=load_rubric(out/'rubric-current.json')
    # Explicitly synthetic, otherwise the current unclosed readiness correctly
    # suppresses total_score. This object is never the real case configuration.
    projection=copy.deepcopy(rubric);projection['status']='frozen'
    for name in projection['publication']['requires_readiness']:projection['readiness'][name]=True
    rows=copy.deepcopy(load(ROOT/'protocol-replay/executions/complete-draft-evidence/assessment.json')['findings'])
    next(r for r in rows if r['id']=='D02')['status']='verified_fail'
    t=time.perf_counter();result=aggregate(projection,criteria,rows);elapsed=time.perf_counter()-t
    assert (result['status'],result['fixed_denominator'],result['total_score'],result['business_success'],result['good'],result['known_critical_failures'])==('graded',100,96,False,False,['D02'])
    save(out/'synthetic-input-findings.json',{'scope':'aggregation algebra only; not actual reference/candidate findings','findings':rows})
    save(out/'synthetic-aggregation-result.json',{'scope':'exactly one real aggregate() call on a synthetic frozen protocol projection; not current case freeze/score','seconds':elapsed,'result':result})
    actual=load(ROOT/'repair-executions/actual-partial-reference/assessment.json');d02=next(r for r in actual['findings'] if r['id']=='D02')
    assert (d02['status'],actual['status'],actual['total_score'],actual['business_success'],actual['good'])==('unassessed','assessment_incomplete',None,None,None)
    reference=load(CASE/'evaluator/qualification/v2/integer-search/quality-reference/registered-reference.json')
    assert reference['lower_bound_minor']=={'numerator':47380,'denominator':1} and current['quality_reference']['maximum_relative_gap']==.01
    summary={'status':'D02_required_input_behavior_contract_qualified','criterion_change':changes,'criterion_count':47,'total_weight':100,'D02_weight':4,'synthetic_failed_D02_score':96,'synthetic_business_success':False,'synthetic_good':False,'actual_D02_status':'unassessed','actual_assessment_status':'assessment_incomplete','actual_total_score':None,'fixed_L':47380,'maximum_relative_gap':.01,'new_aggregate_calls':1,'previous13CLI_repeated':False,'solver_runs':0,'full_execution_runs':0,'Provider_calls':0,'Docker_runs':0,'GPU_work':False,'delegations':0,'freeze_approved':False,'observed_utc':datetime.now(timezone.utc).isoformat()}
    save(out/'stage-assessment.json',summary)
    (out/'ADDENDUM.md').write_text('''# D02必需输入行为的合同追加复核\n\n认可本次尚未冻结、尚无新候选时的合同完整性修正：公开任务原已要求同一源码处理传入raw及预注册数值变体，D02明确失败而仍判好会违背这项必需交付。将D02设critical是使成功判定与公开要求一致；它不增加业务约束、计算时长或难度实证，也不靠critical数量证明更难。\n\n独立逐叶对照原快照与当前rubric：47叶中只有D02.critical从false变true；D02仍4分、总100，固定L47380及1%不变。读取最新Recall确认先记录原因；GRADING中的D09仍是取得/未得可行解与界的真实报告口径，与原rubric一致，不是manifest完整性，也不要求成功程序额外跑失败分支。\n\n只执行一次真实aggregate代码调用，使用明确synthetic的冻结协议投影关闭发布前置以核验代数：其余full、D02 verified_fail，结果96分、known_critical_failures=[D02]、business_success=false、good=false。该96仅为代数夹具，绝非当前未冻结参考或候选成绩；没有重复13CLI、求解或新完整执行。精确输入/结果/执行命令与源码在本追加目录。\n\n既有真实参考的D02仍unassessed；原实际44pass/2partial/1unassessed与assessment_incomplete、total/business_success/good=null不改写。评估侧尚未提供并审查变价源码实跑，不能据此把候选D02判失败或0分。新运行终态另待主方封存，本轮没有访问或干预。旧REVIEW/实际评级/原失败和所有源码快照保持不变。\n\n只认可本条局部合同和聚合代数。匿名多质量校准、最终冻结、fresh候选与十题有效小时资格仍未完成。\n''',encoding='utf-8')
    git=subprocess.run(['git','status','--short','--','specs/artifacts/2026-10-29-heavy-workbench-long/cases/L06','specs/records/2026-10/2026-10-29-heavy-workbench-l06-qualification.md'],cwd=REPO,capture_output=True,text=True,encoding='utf-8');(out/'git-status-end.txt').write_text(git.stdout,encoding='utf-8')
    print(json.dumps(summary,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
