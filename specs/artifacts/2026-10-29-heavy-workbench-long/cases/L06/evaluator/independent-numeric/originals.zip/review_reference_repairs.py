"""Only necessary post-repair reference/reader/normal-grade real CLI checks."""
from decimal import Decimal
import copy
import csv
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time
sys.dont_write_bytecode=True

ROOT=Path(__file__).resolve().parent
SOURCE=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L06/evaluator/qualification/current-source')

def load(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,v):
    p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')

def main():
    source=ROOT/'source-repaired';source.mkdir(exist_ok=False)
    inventory=[]
    for n in ('check_l06.py','l06_input.py','l06_numeric.py','l06_delivery.py','l06_packet.py','qualify_numeric.py'):
        shutil.copy2(SOURCE/n,source/n);inventory.append({'source':str(SOURCE/n),'snapshot':str(source/n),'unchanged_from_initial':(ROOT/'source-initial'/n).read_bytes()==(source/n).read_bytes()})
    save(ROOT/'repair-source-inventory.json',inventory)
    defaults={'case-root':ROOT/'case','input':ROOT/'case/public/inputs','normalized':ROOT/'fixtures/normalized.json','plan':ROOT/'fixtures/plan.json',
      'summary':ROOT/'fixtures/summary.json','ledger':ROOT/'fixtures/ledger.json'}
    tests=[]
    def run(label,code,expected_status=None,infra=None,**changes):
        folder=ROOT/'repaired-runs'/label;folder.mkdir(parents=True)
        argv=['C:/Python314/python.exe','-X','utf8','-B',str(source/'l06_numeric.py')]
        for k,v in (defaults|changes).items():argv+=['--'+k,str(v)]
        argv+=['--out',str(folder/'result.json')];begin=time.perf_counter()
        p=subprocess.run(argv,cwd=ROOT,capture_output=True,text=True,encoding='utf-8');seconds=time.perf_counter()-begin
        (folder/'stdout.txt').write_text(p.stdout,encoding='utf-8');(folder/'stderr.txt').write_text(p.stderr,encoding='utf-8')
        result=load(folder/'result.json') if (folder/'result.json').is_file() else None
        checks={'exit_code':p.returncode==code,'machine_result':result is not None}
        if result is not None:
            checks['total_score_null']=result['total_score'] is None
            if infra:checks['named_run_invalid']=result['status']=='run_invalid' and result['infrastructure_error']['code']==infra and result['business_success'] is None
            else:
                finding={f['id']:f['status'] for f in result['findings']}
                checks['partial_47_30_17']=len(finding)==47 and result['numeric_leaf_count']==30 and result['counts']['unassessed']==17
                for identifier,status in (expected_status or {}).items():checks[identifier]=finding[identifier]==status
                if code==0:checks['30_numeric_pass']=result['counts']['verified_pass']==30
        receipt={'argv':argv,'exit_code':p.returncode,'seconds':seconds,'checks':checks,'all_passed':all(checks.values())}
        save(folder/'command.json',receipt);tests.append({'test':label,**receipt})
    run('normal-base',0)
    run('original-public-target-drift',3,infra='reference_public_input_drift',**{'case-root':ROOT/'case-reference-target-drift','input':ROOT/'case-reference-target-drift/public/inputs',
        'normalized':ROOT/'fixtures/drift-normalized.json','summary':ROOT/'fixtures/drift-summary.json','ledger':ROOT/'fixtures/drift-ledger.json'})
    run('original-bound-contradiction',3,infra='reference_bound_contradicted',**{'case-root':ROOT/'case-contradictory-bound'})
    run('separate-input-variant',3,infra='reference_input_unregistered',input=ROOT/'variant-outside-registration')
    reordered=ROOT/'case-row-order';shutil.copytree(ROOT/'case',reordered)
    for f in (reordered/'public/inputs').glob('*.csv'):
        with f.open(newline='',encoding='utf-8') as s:r=csv.reader(s);header=next(r);rows=list(r)
        with f.open('w',newline='',encoding='utf-8') as s:w=csv.writer(s);w.writerow(header);w.writerows(reversed(rows))
    run('semantic-current-public-row-reorder',0,**{'case-root':reordered,'input':reordered/'public/inputs'})
    raw=load(ROOT/'fixtures/summary.json');raw.pop('expected_cost_minor')
    for v in raw['scenarios'].values():
        q=v['probability'];v['probability']={'numerator':q['numerator']*100,'denominator':q['denominator']*100}
    decimal=ROOT/'fixtures/repaired-decimal-summary.json';decimal.write_text(json.dumps(raw)[:-1]+',"expected_cost_minor":47808.0}',encoding='utf-8')
    run('exact-decimal-and-unreduced',0,summary=decimal)
    huge=ROOT/'fixtures/huge-exponent-summary.json';huge.write_text(json.dumps(raw)[:-1]+',"expected_cost_minor":1e9999999999999999999}',encoding='utf-8')
    run('decimal-exception-input-contract',2,{i:'candidate_incomplete' for i in ('C01','C07','C08','C09','C10','C11')},summary=huge)
    overflow=ROOT/'fixtures/default-overflow-plan.json';overflow.write_text('1e999',encoding='utf-8')
    run('default-finite-input-contract',2,{'B01':'candidate_incomplete','C06':'blocked_candidate'},plan=overflow)
    run('archived-hand-fixture',0,{'C02':'verified_pass','C03':'verified_pass','C06':'verified_pass'},**{'case-root':ROOT/'hand-good','input':ROOT/'hand-good/public/inputs',
      'normalized':ROOT/'hand-good/normalized.json','plan':ROOT/'hand/plan.json','summary':ROOT/'hand/summary.json','ledger':ROOT/'hand/ledger.json'})
    # A genuinely feasible but insufficient-quality existing policy exercises a positive failed-quality result.
    spec=importlib.util.spec_from_file_location('own_numeric_oracle',ROOT/'review_numeric.py');own=importlib.util.module_from_spec(spec);spec.loader.exec_module(own)
    old=load(Path('D:/opencorvus-benchmark-runs/l06-cpsat-independent-review-20261029/source-snapshot/cpsat-full/plan.json'))
    d=load(ROOT/'fixtures/normalized.json');oracle=own.independent(d,old)
    for n,v in [('plan',old),('ledger',oracle['ledger']),('summary',oracle['summary'])]:save(ROOT/'fixtures'/('feasible-low-quality-'+n+'.json'),v)
    run('feasible-policy-fails-quality',2,{'C06':'verified_fail','C02':'verified_pass','C03':'verified_pass','D03':'verified_pass'},
       plan=ROOT/'fixtures/feasible-low-quality-plan.json',ledger=ROOT/'fixtures/feasible-low-quality-ledger.json',summary=ROOT/'fixtures/feasible-low-quality-summary.json')
    spec=importlib.util.spec_from_file_location('repaired_shared_reader',source/'l06_input.py');reader=importlib.util.module_from_spec(spec);spec.loader.exec_module(reader)
    reader_tests=[]
    for label,raw,flag,expected in [('decimal-bytes',b'{"x":1.25}',True,('Decimal','1.25')),('default-bytes',b'{"x":1.25}',False,('float','1.25')),
       ('overflow-default-bytes',b'1e999',False,('InputError','probe_json')),('duplicate-bytes',b'{"x":1,"x":2}',False,('InputError','probe_json'))]:
        try:v=reader.decode_json(raw,'probe_json',source='explicit byte fixture',decimal_numbers=flag);actual=(type(v['x']).__name__,str(v['x']))
        except reader.InputError as e:actual=('InputError',e.code)
        reader_tests.append({'name':label,'actual':actual,'expected':expected,'passed':actual==expected})
    save(ROOT/'repaired-reader-contracts.json',reader_tests);save(ROOT/'repaired-cli-contracts.json',tests)
    result={'scope':'reference identity, contradicted lower bound, shared decoder and affected normal paths',
      'actual_cli_calls':len(tests),'all_cli_passed':all(t['all_passed'] for t in tests),'reader_contract_count':len(reader_tests),
      'all_reader_contracts_passed':all(t['passed'] for t in reader_tests),'source_initial_and_original_false_passes_preserved':True,
      'full_grader_or_freeze_approved':False,'solver_calls':0,'Provider_calls':0,'GPU_work':False}
    save(ROOT/'repair-assessment.json',result);print(json.dumps(result,ensure_ascii=False,indent=2))
    if not result['all_cli_passed'] or not result['all_reader_contracts_passed']:raise SystemExit(1)

if __name__=='__main__':main()
