from pathlib import Path
p=Path('source/export.py')
s=p.read_text(encoding='utf-8-sig').replace("'native_run_original':'native-run-01'","'native_run_original':a.run.name")
p.write_text(s,encoding='utf-8')
