from pathlib import Path
import json,zipfile,shutil,os,datetime
R=Path('D:/myhexin-local/opencorvus');B=R/'specs/artifacts/2026-10-29-heavy-workbench-long';O=Path('D:/opencorvus-benchmark-runs/l06-v04-codex-fresh-native-20261031');E=O/'evaluation';S=O/'submission';P=Path('D:/opencorvus-benchmark-runs/l06-v04-codex-fresh-independent-review-20261031');D=B/'cases/L06/evaluator/pilot-codex-v04-native-20261031'
def copy(src,dst):
 if src.is_dir():shutil.copytree(src,dst,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__'))
 else:dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
def write(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
assert (E/'final-grade.json').is_file(),'actual bound grade must exist first';assert not D.exists(),'one candidate publication object'
grade=json.loads((E/'final-grade.json').read_text());D.mkdir()
copy(O/'public',D/'public')
for name in ['programme','source','runner','figures','derivation']:copy(S/name,D/'submission'/name)
for p in S.iterdir():
 if p.is_file():copy(p,D/'submission'/p.name)
for name in ['complete-workspace-receipt.json','delivery-layout.json','private-execution-registration.json','actual-execution-command.json','actual-prepare-command.json','actual-grade-command.json','final-grade.json','primary-visual-observations.json']:copy(E/name,D/'evaluation'/name)
for p in (E/'assessment').iterdir():
 if p.is_file():copy(p,D/'evaluation/assessment'/p.name)
for p in P.iterdir():
 if p.is_file() and p.suffix in ['.md','.json','.py']:copy(p,D/'independent-review'/p.name)
manifest=[];omitted=[]
with zipfile.ZipFile(D/'originals.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for label,root in [('candidate',O),('independent-review',P)]:
  for folder,dirs,files in os.walk(root):
   current=Path(folder)
   for name in list(dirs):
    p=current/name;parts=p.relative_to(root).parts;reason=None
    if name=='__pycache__':reason='derived bytecode; full original external workspace capsule retains candidate files'
    elif label=='candidate' and len(parts)==2 and parts[0]=='submission' and parts[1] in ['dependencies','download-cache','plot-cache']:reason='third-party dependency/download/plot cache; full original complete-workspace.zip retained external; declared lock and versions retained here'
    elif label=='candidate' and name=='closed':reason='duplicate closed assignment full input snapshot retained external; original delivered bytes and private run retained here'
    elif label=='candidate' and parts==('evaluation','temp'):reason='private reader temporary SQL copies; original private SQLite and independent audit retained'
    elif label=='independent-review' and parts[0] in ['temp','sql-read-copies','cache','matplotlib-cache']:reason='independent read-only SQL scratch/cache; original audit/source and exact raw native input retained'
    if reason:dirs.remove(name);omitted.append({'root':label,'path':p.relative_to(root).as_posix(),'reason':reason})
   for name in files:
    p=current/name;rel=p.relative_to(root).as_posix()
    if label=='candidate' and rel=='evaluation/complete-workspace.zip':omitted.append({'root':label,'path':rel,'reason':'full original workspace capsule78,896,976bytes retained external; every original member and full scope in copied receipt; avoid republishing third-party caches'});continue
    member=label+'/'+rel;z.write(p,member);manifest.append({'path':member,'bytes':p.stat().st_size})
receipt={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'roots':{'candidate':str(O),'independent-review':str(P)},'bytes':(D/'originals.zip').stat().st_size,'members':len(manifest),'member_manifest':manifest,'excluded_external_retained':omitted,'complete_original_workspace':{'file':str(E/'complete-workspace.zip'),'bytes':(E/'complete-workspace.zip').stat().st_size,'receipt':'evaluation/complete-workspace-receipt.json'},'scope':'candidate genuine full science/source/correct-native/original failed-native and repair/private source native/actual prepare+grade/one content review; not OS filesystem confinement or useful-hour proof'};write(D/'archive.json',receipt)
(D/'README.md').write_text(f'''# L06/0.4全新Codex候选：真正私有全链与同冻结评分

候选只获同Git35ba746e5的21public及声明本机runtime，fork none/无模型override/禁再委托。自然交付后先完整封6363文件/78,896,976byte workspace（含public、原源/Git事实/失败/deps/cache），原21public字节无变/无extras、实际无Git；actualmodel/usage未暴露unknown/comparablefalse，不作同模型费用速度因果排名。[原始产品](submission/REPORT.md)、[实际账](submission/stage-ledger.csv)、[原生移交](submission/HANDOFF.md)和三[实际图](submission/figures/policy-decisions.png)按原字节保。

首候选native-run-01完整前段后遇copytree继承readonly CSV属性的行序PermissionError，原失败/源/两恢复保；只自有runner给自有副本加可写位、diff保，第二轮真实完整0。这是设施错，非策略错/成功或生产调度异常。主方在全原件封后按原21字节新建默认可写工作输入，不改任何公料/源码/动作，真正一次私有source-only native08:55:19→08:56:54Z/native0：197终态3152阶段、两controller73原order/lab-result键payloadreceipt恢复+16row控制。原programme/旧输出/solver/参考/未来文件不混入输入。workerEOF0不冒kill/掉电，同用户native不授OS安全隔离。

[实际prepare](evaluation/actual-prepare-command.json)12Mpass；单层[唯一候选内容独评](independent-review/review.json)绑定原assignment72f574ca6fdc466d816410dda95e8b3e，独立原CSV/Fraction/SQL-wire/AR/源/科学及3实际PNG核。没有再native/DP/solver/cold/作者整审。真正[grade](evaluation/actual-grade-command.json)从closed重算12M后接原5H，total={grade['total']}、allcritical={grade['all_critical_pass']}、good={grade['good']}，subject_role=candidate，不手写聚合，不拿作者100替模型分。

[originals.zip](originals.zip)为{receipt['bytes']:,}bytes/{receipt['members']}members；[逐成员/外部保留范围](archive.json)明确全78MB工作区胶囊、第三方依赖/cache和重复closed副本外部留，不谎称本ZIP含全第三方字节。完整原失败和源/真实private/native/实际评分及唯一审查均保。当前只是一个新0.4候选结果；OC0.4另在原Task自然运行，无两good结论。参考/评估侧秒数/业务周/叶数/模型生命周期不是有效小时，套件仍9/10/有效小时0/10，L01原GPU矩阵继续。''',encoding='utf-8')
print(json.dumps({'pilot':str(D),'bytes':receipt['bytes'],'members':receipt['members'],'actual_grade':grade['total'],'good':grade['good']}))
