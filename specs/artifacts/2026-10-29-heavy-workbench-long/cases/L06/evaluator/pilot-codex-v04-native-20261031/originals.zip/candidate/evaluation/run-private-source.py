from pathlib import Path
import json,zipfile,shutil,subprocess,datetime,os
O=Path('D:/opencorvus-benchmark-runs/l06-v04-codex-fresh-native-20261031');E=O/'evaluation';S=O/'submission';R=Path('D:/myhexin-local/opencorvus');assert (E/'complete-workspace-receipt.json').is_file();assert not (E/'private-run').exists() and not (E/'source-project').exists(),'no duplicate source-only run'
def write(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
shutil.copytree(S/'programme',E/'source-project');public=E/'public-inputs';public.mkdir()
with zipfile.ZipFile(O/'public-inputs.zip') as z:
 for n in z.namelist():
  p=public/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(n))
layout={'format':'l06-inspection-layout/1','paths':{'programme':'programme','report':'REPORT.md','ledger':'stage-ledger.csv','summary':'summary.json','source_map':'REVIEW-INDEX.md','reproduce':'REPRODUCE.ps1','requirements':'DEPENDENCIES.txt','figures':['figures/policy-decisions.png','figures/cost-information.png','figures/cash-material.png']}};write(E/'delivery-layout.json',layout)
argv=['C:/Python314/python.exe','-X','utf8','-u','-B',str(public/'exercise.py'),'--project',str(E/'source-project'),'--public',str(public),'--out',str(E/'private-run'),'--python','C:/Python314/python.exe']
write(E/'private-execution-registration.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':argv,'source_programme':str(S/'programme'),'only_inputs':'exact21 original public bytes + original delivered source-only programme, new native outputs; no old weights/results/reference/evaluator/credential/future files','readonly_copy_attribute_resolution':'immutable original public files unchanged; newly written working input files have default writable attributes, so public row-order copy can be written without changing any source/table bytes','scope':'same frozen private native exercise; finite controlled process/dataflow only, no OS/network or arbitrary-failure isolation certification'})
with zipfile.ZipFile(E/'pre-execution-private-inputs.zip','w',zipfile.ZIP_DEFLATED) as z:
 for label,root in [('programme',E/'source-project'),('public',public)]:
  for p in sorted(root.rglob('*')):
   if p.is_file():z.write(p,label+'/'+p.relative_to(root).as_posix())
 z.write(E/'private-execution-registration.json','private-execution-registration.json')
(E/'temp').mkdir();env=os.environ.copy();env.update({'PYTHONDONTWRITEBYTECODE':'1','TMP':str(E/'temp'),'TEMP':str(E/'temp')})
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (E/'private-stdout.txt').open('w',encoding='utf-8') as out,(E/'private-stderr.txt').open('w',encoding='utf-8') as err:
 p=subprocess.Popen(argv,cwd=E/'source-project',env=env,stdout=out,stderr=err,text=True);write(E/'private-owner-started.json',{'at':started,'actual_native_owner_pid':p.pid,'argv':argv});print(json.dumps({'started_at':started,'actual_native_owner_pid':p.pid}),flush=True);code=p.wait()
v={'started_at':started,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'native_exit':code,'actual_native_owner_pid':p.pid,'argv':argv,'stdout':str(E/'private-stdout.txt'),'stderr':str(E/'private-stderr.txt'),'scope':'first actual private source-only execution after complete original workspace capsule; no policy/optimizer/report changes'};write(E/'actual-execution-command.json',v);print(json.dumps(v));raise SystemExit(code)
