# Specification index

- [plan.md](plan.md): Recall, problem/impact analysis, implementation and verification plan.
- [../REPORT.md](../REPORT.md): exact finite-model derivation and observed native results.
- [../HANDOFF.md](../HANDOFF.md): operator and source-rebuild handoff.

This standalone submission has no package.json/document checker; all specification records stay under this specs directory.
