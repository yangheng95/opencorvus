from pathlib import Path
import json
r=Path('D:/opencorvus-benchmark-runs/l06-v04-codex-fresh-native-20261031/submission');checks={}
for path in (r/'programme/policies').glob('*.json'):
    a=json.loads(path.read_text());b=json.loads((r/'derivation/rebuild-02/policies'/path.name).read_text());assert a==b;checks[path.stem]={'complete_rebuilt_policy':'equal','initial_value_exact':a['initial_value_exact'],'policy_states':len(a['states'])}
a=json.loads((r/'derivation/build-01/values.json').read_text());b=json.loads((r/'derivation/rebuild-02/values.json').read_text())
for ident in a:
    for comparison in ['same-information','class-A','class-B','no-inspection']:assert a[ident][comparison]['value_exact']==b[ident][comparison]['value_exact']
(r/'derivation/rebuild-reconciliation.json').write_text(json.dumps({'status':'passed','checks':checks,'comparison':'parsed full policy content and exact rational values, not source digests'},indent=2)+'\n')
print(json.dumps(checks))
