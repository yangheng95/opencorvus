from pathlib import Path
p=Path('source/report.py');s=p.read_text(encoding='utf-8-sig');needle='## Results and actual scope'
s=s.replace(needle,'Terminology: CSV = comma-separated values; JSON = JavaScript Object Notation; AR = accounts receivable; PID = process identifier; SQL = Structured Query Language; WAL = write-ahead log; EOF = end of file; PNG = Portable Network Graphics; SVG = Scalable Vector Graphics; PDF = Portable Document Format.\n\n'+needle)
p.write_text(s,encoding='utf-8')
p=Path('HANDOFF.md');s=p.read_text(encoding='utf-8-sig').replace('A changed payload at the original key is a conflict, not a retry.','A changed payload at the original key is a conflict (`original_payload_after_process_loss` in the supplied recovery controller), not a retry.');p.write_text(s,encoding='utf-8')
