"""Independent input/physical/financial oracle and actual numeric-adapter CLI review."""
from collections import Counter
from fractions import Fraction
import copy
import csv
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time
import zipfile
sys.dont_write_bytecode=True

ROOT=Path(__file__).resolve().parent
REPO=Path('D:/myhexin-local/opencorvus')
CASE=REPO/'specs/artifacts/2026-10-29-heavy-workbench-long/cases/L06'
SOURCE=CASE/'evaluator/qualification/current-source'
PREVIOUS=Path('D:/opencorvus-benchmark-runs/l06-public-contract-independent-review-20261029')
PYTHON='C:/Python314/python.exe'

def save(p,v):
    p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def module(name,p):
    spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def independent(d,plan):
    """Independent cumulative constraints; financial values only used when physical predicates hold."""
    violations=Counter();counts=Counter();led={'format':'l06-ledger/1','scenarios':{}};summary={'format':'l06-summary/1','scenarios':{}}
    T=d['weeks'];M=len(d['raw_materials']);J=len(d['products']);P=len(d['plants']);S=len(d['suppliers'])
    expected=Fraction();first=plan['decisions'][d['scenarios'][0]['id']]
    def predicate(family,ok):counts[family]+=1;violations[family]+=int(not ok)
    for s in d['scenarios']:
        sid=s['id'];a=plan['decisions'][sid];raw=d['initial_raw'].copy();fg=d['initial_products'].copy();cash=d['initial_cash_minor'];rows=[];total=collected=delivered=0
        for f in ('order_lots','truck_on','production'):predicate('B02',a[f][:d['common_weeks']]==first[f][:d['common_weeks']])
        for t in range(T):
            supplier_volume=[];purchasing=freight=0
            for k,rule in enumerate(d['suppliers']):
                z=a['truck_on'][t][k];volume=sum(a['order_lots'][t][k][m]*rule['pack_units'][m]*d['raw_volume'][m] for m in range(M))
                supplier_volume.append(volume)
                predicate('B03',z in (0,1));predicate('B04',volume>=rule['minimum_volume']*z)
                predicate('B05',volume<=s['supplier_capacity_volume'][t][k]*z)
                predicate('C04',t+rule['lead_weeks']<T or sum(a['order_lots'][t][k])==0)
                purchasing+=sum(a['order_lots'][t][k][m]*rule['pack_units'][m]*rule['price_minor'][m] for m in range(M))
                freight+=z*rule['freight_minor']
            arrivals=[sum(a['order_lots'][u][k][m]*d['suppliers'][k]['pack_units'][m] for u in range(T) for k in range(S) if u+d['suppliers'][k]['lead_weeks']==t) for m in range(M)]
            made=[sum(a['production'][t][p][j] for p in range(P)) for j in range(J)]
            hours=[];labor=0
            for p in range(P):
                for j in range(J):predicate('B06',d['allowed'][p][j] or a['production'][t][p][j]==0)
                h=sum(a['production'][t][p][j]*d['production_hours'][j] for j in range(J));hours.append(h)
                predicate('B07',h<=s['plant_capacity_hours'][t][p])
                labor+=sum(a['production'][t][p][j]*d['production_cost_minor'][p][j] for j in range(J))
            consumed=[sum(made[j]*d['bom'][j][m] for j in range(J)) for m in range(M)]
            rawpeak=sum((raw[m]+arrivals[m])*d['raw_volume'][m] for m in range(M))
            fgpeak=sum((fg[j]+made[j])*d['product_volume'][j] for j in range(J))
            predicate('B10',rawpeak<=d['raw_storage_volume']);predicate('B11',fgpeak<=d['product_storage_volume'])
            raw=[raw[m]+arrivals[m]-consumed[m] for m in range(M)];fg=[fg[j]+made[j]-s['demand'][t][j] for j in range(J)]
            predicate('B08',min(raw)>=0);predicate('B09',min(fg)>=0)
            holding=sum(raw[m]*d['raw_holding_minor'][m] for m in range(M))+sum(fg[j]*d['product_holding_minor'][j] for j in range(J))
            cost=purchasing+freight+labor+holding;total+=cost
            lagged=t-d['receipt_lag_weeks'];received=sum(s['demand'][lagged][j]*d['sales_price_minor'][j] for j in range(J)) if lagged>=0 else 0
            cash+=received-cost;collected+=received;delivered+=sum(s['demand'][t][j]*d['sales_price_minor'][j] for j in range(J))
            predicate('C03' if t==T-1 else 'C02',cash>=(0 if t==T-1 else -d['credit_limit_minor']))
            rows.append({'week':t,'order_lots':a['order_lots'][t],'truck_on':a['truck_on'][t],'production':a['production'][t],
                'arrivals':arrivals,'made':made,'consumption':consumed,'raw_inventory':raw.copy(),'finished_inventory':fg.copy(),'supplier_volume':supplier_volume,'hours':hours,
                'raw_stage_peak_volume':rawpeak,'product_stage_peak_volume':fgpeak,'purchase_cost':purchasing,'freight_cost':freight,'production_cost':labor,
                'holding_cost':holding,'cost':cost,'receipts':received,'cash':cash,'receivable':delivered-collected})
        predicate('C05',all(x==0 for x in fg));led['scenarios'][sid]={'weeks':rows}
        expected+=Fraction(total*s['probability_numerator'],d['probability_denominator'])
        summary['scenarios'][sid]={'probability':{'numerator':s['probability_numerator'],'denominator':d['probability_denominator']},'total_cost_minor':total,
           'minimum_cash_minor':min(r['cash'] for r in rows),'final_cash_minor':cash,'final_receivable_minor':delivered-collected}
    summary['expected_cost_minor']={'numerator':expected.numerator,'denominator':expected.denominator}
    status={i:'verified_fail' if violations[i] else 'verified_pass' for i in ('B02','B03','B04','B05','B06','B07','B08','B09','B10','B11','C04','C05')}
    if status['B03']!='verified_pass':status['B04']=status['B05']='blocked_candidate'
    physical=all(v=='verified_pass' for v in status.values())
    for i in ('C02','C03'):status[i]=('verified_fail' if violations[i] else 'verified_pass') if physical else 'blocked_candidate'
    feasible=physical and status['C02']==status['C03']=='verified_pass'
    return {'physical_statuses':status,'violations':dict(violations),'predicate_counts':dict(counts),'business_feasible':feasible,
        'ledger':led if feasible else None,'summary':summary if feasible else None,'cost':expected if feasible else None}

def main():
    snap=ROOT/'source-initial';snap.mkdir(exist_ok=False)
    for n in ('check_l06.py','l06_input.py','l06_numeric.py','l06_delivery.py','l06_packet.py','qualify_numeric.py'):shutil.copy2(SOURCE/n,snap/n)
    case=ROOT/'case';case.mkdir();shutil.copytree(CASE/'public',case/'public');shutil.copy2(CASE/'rubric.draft.json',case/'rubric.draft.json')
    rubric=load(case/'rubric.draft.json');relative=rubric['quality_reference']['registration_file'];registration=CASE/relative
    (case/relative).parent.mkdir(parents=True);shutil.copy2(registration,case/relative)
    shutil.copy2(registration.parent/'originals.zip',(case/relative).parent/'originals.zip')
    (ROOT/'Recall.md').write_text('''# Recall\n\n单层独立只读审查30数值叶采集/依赖/注册引用。仅自有新目录CLI和标准库逐谓词/现金/事实核算；不运行solver、Provider、GPU、Docker、UI或用户进程，不恢复暂停容器、不再次委托、不改主仓。保留前期全部原件；47中仅30数值叶可评、17执行/人评未评，总分null，不批准冻结/候选/小时。\n''',encoding='utf-8')
    status=subprocess.run(['git','status','--short'],cwd=REPO,capture_output=True,text=True,encoding='utf-8');(ROOT/'git-status-before.txt').write_text(status.stdout,encoding='utf-8')
    helper=module('own_previous_projection',PREVIOUS/'review_packet.py');data,_=helper.independent_projection(case/'public/inputs')
    with zipfile.ZipFile((case/relative).parent/'originals.zip') as z:
        plan=json.loads(z.read('quality-proof/plan.json'));captured=json.loads(z.read('input/full.json'))
    assert data=={k:v for k,v in captured.items() if k not in ('status','qualification_variant')}
    oracle=independent(data,plan);assert oracle['business_feasible'] and oracle['cost']==47808
    for n,v in [('normalized.json',data),('plan.json',plan),('ledger.json',oracle['ledger']),('summary.json',oracle['summary'])]:save(ROOT/'fixtures'/n,v)
    defaults={'case-root':case,'input':case/'public/inputs','normalized':ROOT/'fixtures/normalized.json','plan':ROOT/'fixtures/plan.json',
      'ledger':ROOT/'fixtures/ledger.json','summary':ROOT/'fixtures/summary.json'}
    events=[];contracts=[];all_ids=[c['id'] for g in rubric['groups'] for c in g['criteria']]
    def run(label,expected=None,exit_code=None,**changes):
        folder=ROOT/'runs'/label;folder.mkdir(parents=True)
        args=defaults|changes;out=folder/'result.json';argv=[PYTHON,'-X','utf8','-B',str(snap/'l06_numeric.py')]
        for k,v in args.items():argv+=['--'+k,str(v)]
        argv+=['--out',str(out)];start=time.perf_counter();p=subprocess.run(argv,cwd=ROOT,capture_output=True,text=True,encoding='utf-8');elapsed=time.perf_counter()-start
        (folder/'stdout.txt').write_text(p.stdout,encoding='utf-8');(folder/'stderr.txt').write_text(p.stderr,encoding='utf-8')
        result=load(out) if out.exists() else None;f={} if result is None else {r['id']:r for r in result['findings']}
        checks={'machine_result':result is not None}
        if exit_code is not None:checks['exit_code']=p.returncode==exit_code
        if expected is not None:checks.update({i:f.get(i,{}).get('status')==v for i,v in expected.items()})
        if result is not None:
            checks['total_score_null']=result['total_score'] is None
            if result['status']!='run_invalid':checks['47_findings_30_numeric_17_unassessed']=len(f)==47 and result['numeric_leaf_count']==30 and result['counts']['unassessed']==17
        receipt={'argv':argv,'exit_code':p.returncode,'seconds':elapsed,'checks':checks,'all_expected_contracts_passed':all(checks.values())}
        save(folder/'command.json',receipt);events.append(receipt);contracts.append({'case':label,**receipt})
        return result,f
    base,f=run('base-reference',exit_code=0);assert base['counts']['verified_pass']==30
    for label,path,new,leaf in [('norm-property','sales_price_minor',data['sales_price_minor'][0]+1,'A01'),('norm-bool',None,None,'A03')]:
        bad=copy.deepcopy(data)
        if path:bad[path][0]=new
        else:bad['allowed'][0][0]=True
        target=ROOT/'fixtures'/(label+'.json');save(target,bad)
        run(label,{leaf:'verified_fail','C06':'verified_pass'},exit_code=2,normalized=target)
    joint=copy.deepcopy(plan);sid=data['scenarios'][0]['id'];t=data['weeks']-1
    joint['decisions'][sid]['truck_on'][t][0]=2
    p,j=next((p,j) for p,row in enumerate(data['allowed']) for j,allowed in enumerate(row) if not allowed)
    joint['decisions'][sid]['production'][t][p][j]+=1000
    joint['decisions'][sid]['order_lots'][t][2][0]+=1000
    target=ROOT/'fixtures/multiple-violations.json';save(target,joint);independent_joint=independent(data,joint)
    result,f=run('multiple-violations',independent_joint['physical_statuses']|{'C06':'blocked_candidate'},2,plan=target)
    save(ROOT/'independent-multiple-violation-oracle.json',{k:v for k,v in independent_joint.items() if k not in ('ledger','summary','cost')})
    zero=copy.deepcopy(plan)
    def zeros(x):return [zeros(v) for v in x] if isinstance(x,list) else 0
    for record in zero['decisions'].values():
        for k in ('order_lots','truck_on','production'):record[k]=zeros(record[k])
    target=ROOT/'fixtures/zero-actions.json';save(target,zero);independent_zero=independent(data,zero)
    run('zero-actions',independent_zero['physical_statuses']|{'C06':'blocked_candidate','C01':'blocked_candidate'},2,plan=target)
    bad=copy.deepcopy(plan);bad['decisions'][sid]['raw_inventory'][0][0]+=1;target=ROOT/'fixtures/optional-inventory.json';save(target,bad)
    run('optional-inventory',{'D03':'verified_fail','B08':'verified_pass','C06':'verified_pass'},2,plan=target)
    variant=ROOT/'variant-outside-registration';shutil.copytree(case/'public/inputs',variant)
    def cheaper_quotes(folder):
        path=folder/'supplier_quotes.csv'
        with path.open(encoding='utf-8',newline='') as f:r=csv.DictReader(f);fields=r.fieldnames;rows=list(r)
        target=next(r for r in rows if r['supplier_id']=='A' and r['raw_id']=='R0');target['unit_price_minor']=str(int(target['unit_price_minor'])-1)
        with path.open('w',encoding='utf-8',newline='') as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
    cheaper_quotes(variant);result,_=run('variant-outside-registration',exit_code=3,input=variant);assert result['infrastructure_error']['code']=='reference_input_unregistered'
    coefficient,k,m=max((s['pack_units'][m]*data['raw_volume'][m],k,m) for k,s in enumerate(data['suppliers']) for m in range(len(data['raw_materials'])))
    huge=copy.deepcopy(plan);huge['decisions'][sid]['order_lots'][t][k][m]=9*10**4299;huge['decisions'][sid]['truck_on'][t][k]=1
    target=ROOT/'fixtures/large-scaled-plan.json';save(target,huge)
    result,f=run('large-scaled-integer',{'B05':'verified_fail','C06':'blocked_candidate'},2,plan=target)
    projected=f['B05']['detail']['first_violation']['actual'];assert projected['kind']=='large_exact_integer'
    expected_volume=sum(huge['decisions'][sid]['order_lots'][t][k][i]*data['suppliers'][k]['pack_units'][i]*data['raw_volume'][i] for i in range(len(data['raw_materials'])))
    assert projected['bit_length']==expected_volume.bit_length()
    save(ROOT/'large-integer-exact-diagnostic.json',{'input_digits':4300,'coefficient':coefficient,'actual_projection':projected,'expected_derived_bit_length':expected_volume.bit_length(),'exact_predicate_compared':True})
    # Direct real API asserts infeasible strategies publish no trusted finance/cost ledger.
    sys.path.insert(0,str(snap));checker=module('reviewed_business',snap/'check_l06.py')
    for label,probed in [('multiple',joint),('zero',zero)]:
        stripped={**probed,'decisions':{n:{k:v for k,v in rec.items() if k not in ('raw_inventory','finished_inventory')} for n,rec in probed['decisions'].items()}}
        inspected=checker.inspect_plan(data,stripped)
        assert not inspected['business_feasible'] and inspected['scenarios'] is None and inspected['expected_cost_exact'] is None and inspected['expected_cost_minor'] is None
        save(ROOT/(label+'-inspection-summary.json'),{'business_feasible':False,'scenarios':None,'expected_cost_exact':None,'violations':inspected['violations'],'constraint_checks':inspected['constraint_checks']})
    # Mutating the public target of registration while keeping its archived captured input unchanged must not rebind L silently.
    drift=ROOT/'case-reference-target-drift';shutil.copytree(case,drift);cheaper_quotes(drift/'public/inputs')
    drift_data,_=helper.independent_projection(drift/'public/inputs');drift_oracle=independent(drift_data,plan);assert drift_oracle['business_feasible']
    for n,v in [('normalized',drift_data),('summary',drift_oracle['summary']),('ledger',drift_oracle['ledger'])]:save(ROOT/'fixtures'/('drift-'+n+'.json'),v)
    drift_result,df=run('reference-target-drift',exit_code=3,**{'case-root':drift,'input':drift/'public/inputs',
        'normalized':ROOT/'fixtures/drift-normalized.json','summary':ROOT/'fixtures/drift-summary.json','ledger':ROOT/'fixtures/drift-ledger.json'})
    # A known feasible objective below a registered alleged lower bound is an evaluator/reference contradiction.
    high=ROOT/'case-contradictory-bound';shutil.copytree(case,high);reference=load(high/relative);reference['lower_bound_minor']={'numerator':100000,'denominator':1};save(high/relative,reference)
    contradictory,cf=run('reference-bound-contradicted',exit_code=3,**{'case-root':high})
    # Hand analytical fixture: total7, cash[-5,4], AR[10,0], no optimization.
    hand_root=ROOT/'hand';hand_root.mkdir();hand_packet=PREVIOUS/'delivery-review/credit-packet';shutil.copytree(hand_packet,hand_root/'packet')
    hand_data,_=helper.independent_projection(hand_root/'packet');hand_plan=load(PREVIOUS/'delivery-review/credit-plan.json')
    hand_oracle=independent(hand_data,hand_plan);assert hand_oracle['cost']==7
    for n,v in [('normalized',hand_data),('plan',hand_plan),('ledger',hand_oracle['ledger']),('summary',hand_oracle['summary'])]:save(hand_root/(n+'.json'),v)
    packet=module('reviewed_packet_writer',snap/'l06_packet.py')
    for label,hd,expected_status in [('hand-good',hand_data,{'C02':'verified_pass','C03':'verified_pass','C06':'verified_pass'}),
      ('hand-credit',hand_data|{'credit_limit_minor':4},{'C02':'verified_fail','C03':'verified_pass','C06':'blocked_candidate'}),
      ('hand-terminal',hand_data|{'sales_price_minor':[0]},{'C02':'verified_pass','C03':'verified_fail','C06':'blocked_candidate'})]:
        hcase=ROOT/label;hcase.mkdir();(hcase/'public').mkdir();packet.write_packet(hd,hcase/'public/inputs')
        hr=copy.deepcopy(rubric);hr['quality_reference']['registration_file']='reference.json';save(hcase/'rubric.draft.json',hr)
        with zipfile.ZipFile(hcase/'captured.zip','w') as z:z.writestr('input/full.json',json.dumps(hd))
        save(hcase/'reference.json',{'format':'l06-quality-reference/1','status':'base_registered_before_fresh_candidate','reference_id':label+'-analytical-not-benchmark',
            'case_version':'HeavyWorkBench-Long/0.2.0-dev','input_identity':{'public':'public/inputs','captured_input':'captured.zip:input/full.json'},
            'lower_bound_minor':{'numerator':7,'denominator':1},'bound_source':{'kind':'analytical_hand_fixture'}})
        normalized=hcase/'normalized.json';save(normalized,hd)
        result,_=run(label,expected_status,0 if label=='hand-good' else 2,**{'case-root':hcase,'input':hcase/'public/inputs','normalized':normalized,
            'plan':hand_root/'plan.json','ledger':hand_root/'ledger.json','summary':hand_root/'summary.json'})
    save(ROOT/'cli-contracts.json',contracts)
    save(ROOT/'initial-assessment.json',{'scope':'independent 30 numeric leaf qualification only','actual_numeric_cli_calls':len(events),
       'passed_expected_contracts':sum(c['all_expected_contracts_passed'] for c in contracts),'failed_expected_contracts':[c['case'] for c in contracts if not c['all_expected_contracts_passed']],
       'observed_reference_drift_status':drift_result['status'],'observed_reference_drift_C06':df.get('C06'),
       'observed_contradictory_bound_status':contradictory['status'],'observed_contradictory_bound_C06':cf.get('C06'),
       'full_grader_or_freeze_approved':False,'solver_calls':0,'Provider_calls':0,'GPU_work':False})
    status=subprocess.run(['git','status','--short'],cwd=REPO,capture_output=True,text=True,encoding='utf-8');(ROOT/'git-status-after.txt').write_text(status.stdout,encoding='utf-8')
    print(json.dumps({'actual_cli_calls':len(events),'failed_expected_contracts':[c['case'] for c in contracts if not c['all_expected_contracts_passed']],
       'drift_status':drift_result['status'],'contradictory_status':contradictory['status'],'solver_calls':0},ensure_ascii=False))

if __name__=='__main__':main()
