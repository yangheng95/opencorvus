# Recall

用户授权单层独立审查唯一当前整数后端及source-only微型参考。只复制源码/README/DATA和一周手算raw输入，唯一微型CPU Docker --rm/networknone；project和input只读，新output独立可写。不读旧plan作hint，不挂载任何旧输出/注册L/评分器/16周输入，不运行完整16周、Provider或GPU，不动用户服务/进程，不再次委托。

审数据→同一build_model→新CP-SAT→真实first-incumbent基线/可行替代→机器账/报告/3图；实际查看图形，核对6/10、AR10、cash94。此微型资格不证明完整职业参考/其余17叶/小时或冻结。
