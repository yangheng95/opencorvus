"""Independent scalar enumeration, output audit and manual-figure evidence record."""
import ast
from fractions import Fraction
import importlib.util
import itertools
import json
from pathlib import Path
import shutil
import subprocess
import sys
sys.dont_write_bytecode=True

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'cold-output/run'

def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def module(name,p):
    spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def ast_body(p,name):
    t=ast.parse(p.read_text(encoding='utf-8'));return ast.dump(next(n for n in t.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name==name),include_attributes=False)

def main():
    tools=ROOT/'audit-tools';tools.mkdir(exist_ok=False)
    projection=Path('D:/opencorvus-benchmark-runs/l06-public-contract-independent-review-20261029/review_packet.py')
    independent=Path('D:/opencorvus-benchmark-runs/l06-numeric-independent-review-20261029/review_numeric.py')
    shutil.copy2(projection,tools/'projection-used.py');shutil.copy2(independent,tools/'independent-used.py')
    project=module('own_public_projection',tools/'projection-used.py')
    own=module('own_independent_math',tools/'independent-used.py')
    data,_=project.independent_projection(ROOT/'input');plan=load(OUT/'plan.json');baseline=load(OUT/'baseline-plan.json');alternate=load(OUT/'alternative-plan.json')
    checks=[]
    def check(name,ok,detail=None):checks.append({'contract':name,'passed':bool(ok),'detail':detail})
    check('input_is_declared_one_week_one_scenario_micro',data['weeks']==1 and len(data['scenarios'])==1 and len(data['raw_materials'])==len(data['products'])==len(data['plants'])==len(data['suppliers'])==1)
    check('independent_normalization_matches_generated',data==load(OUT/'normalized.json'))
    primary=own.independent(data,plan);base=own.independent(data,baseline);alt=own.independent(data,alternate)
    check('complete_primary_ledger_matches_independent_physical_and_financial_math',primary['business_feasible'] and primary['ledger']==load(OUT/'ledger.json'))
    check('complete_summary_matches_independent',primary['summary']==load(OUT/'summary.json'))
    check('primary_cost6_AR10_cash94',primary['cost']==6 and all(v['final_receivable_minor']==10 and v['final_cash_minor']==94 for v in primary['summary']['scenarios'].values()))
    check('actual_baseline_cost6_first_incumbent',base['business_feasible'] and base['cost']==6 and baseline==load(OUT/'solver/first-plan.json'))
    check('alternative_real_feasible_cost10',alt['business_feasible'] and alt['cost']==10)
    check('alternative_has_different_control_actions',any(plan['decisions'][sid][k]!=alternate['decisions'][sid][k] for sid in plan['decisions'] for k in ('order_lots','truck_on','production')))
    check('alternative_business_record_is_cost10',load(OUT/'alternative-business.json')['expected_cost_exact']=={'numerator':10,'denominator':1})
    # Complete tiny joint domain, not a mirror of the optimizer constraints.
    sid=data['scenarios'][0]['id'];pack=data['suppliers'][0]['pack_units'][0];volume=data['raw_volume'][0]
    qmax=min(data['raw_storage_volume']//(pack*volume),data['scenarios'][0]['supplier_capacity_volume'][0][0]//(pack*volume))
    pmax=data['scenarios'][0]['plant_capacity_hours'][0][0]//data['production_hours'][0]
    cases=[]
    for q,z,p in itertools.product(range(qmax+1),range(2),range(pmax+1)):
        trial={'format':'l06-plan/1','decisions':{sid:{'order_lots':[[[q]]],'truck_on':[[z]],'production':[[[p]]]}}}
        d=own.independent(data,trial);cases.append({'q':q,'truck':z,'production':p,'business_feasible':d['business_feasible'],'cost_exact':str(d['cost']) if d['business_feasible'] else None})
    feasible=[c for c in cases if c['business_feasible']]
    check('complete_micro_enumeration_optimum6_alternative10',len(cases)==12 and [c['cost_exact'] for c in feasible]==['6','10'])
    save(ROOT/'independent-scalar-enumeration.json',{'all_joint_choices':cases,'feasible':feasible,'completeness':'one week, all one-dimensional integer lots0..2, binary shipment0..1, production0..1; inventories derived, not independently free variables',
       'no_solver_used_by_this_audit':True})
    solver=load(OUT/'solver-result.json');run=load(OUT/'run.json');manifest=load(OUT/'manifest.json')
    check('actual_versions_in_declared_reference_environment',run['dependencies']=={'python':'3.11.13','numpy':'2.4.6','scipy':'1.15.3','matplotlib':'3.10.3','ortools':'9.15.6755'})
    check('default_no_time_cap_and_no_supplied_hint',solver['native_time_policy']=='unset default infinite' and solver['solver_options']['requested_max_time_in_seconds'] is None and solver['solver_options']['native_max_time_in_seconds'] is None and solver['warm_start'] is None and run['parameters']['warm_start'] is None)
    check('native_status_and_cost_scaling',solver['native_status_code']==4 and solver['objective_exact']=='6' and solver['objective_denominator']==1 and solver['native_best_bound_scaled']==solver['dual_bound']==6)
    check('run_native_and_delivered_truth',run['native_solver']['objective_minor']==6 and run['native_solver']['best_bound_minor']==6 and run['delivered_cost_minor']==6 and run['feasibility']=='feasible')
    check('manifest_declared_relative_outputs_resolve_within_new_output',manifest['format']=='l06-manifest/1' and all((OUT/v).resolve().is_relative_to(OUT.resolve()) and (OUT/v).is_file() for v in manifest['outputs'].values()))
    check('actual_cli_matches_run_argv',run['command']==['/opt/cpsat/bin/python','reproduce.py','--input','/inputs','--output','/output/run'])
    model=load(OUT/'model.json');values=[]
    for key in model['variable_keys']:
        kind,s,*indices=key;record=plan['decisions'][s]
        if kind in ('q','truck','produce'):
            value=record[{'q':'order_lots','truck':'truck_on','produce':'production'}[kind]]
            for i in indices:value=value[i]
        else:value=primary['ledger']['scenarios'][s]['weeks'][indices[0]][{'raw':'raw_inventory','fg':'finished_inventory'}[kind]][indices[1]]
        values.append(value)
    bounds=all(lo<=v<=hi for lo,v,hi in zip(model['variable_lower'],values,model['variable_upper']))
    row_results=[]
    for i,row in enumerate(model['rows']):
        a=sum(c*values[j] for j,c in row['terms']);row_results.append({'row':i,'activity':a,'lower':row['lower'],'upper':row['upper'],
          'passed':(row['lower'] is None or a>=row['lower']) and (row['upper'] is None or a<=row['upper'])})
    objective=Fraction(sum(c*v for c,v in zip(model['objective_numerators'],values)),model['objective_denominator'])
    check('new_model5_columns8_rows_and_exact_objective6',len(values)==5 and len(row_results)==8 and bounds and all(r['passed'] for r in row_results) and objective==6)
    save(ROOT/'new-model-vector-audit.json',{'keys':model['variable_keys'],'values':values,'bounds_passed':bounds,'rows':row_results,'objective_exact':str(objective)})
    previous=Path('D:/opencorvus-benchmark-runs/l06-cpsat-independent-review-20261029/source-snapshot/executed-source-cross-seed/qualify_l06.py')
    check('build_model_unchanged_from_previously_exactly_audited_constructor',ast_body(ROOT/'project/qualify_l06.py','build_model')==ast_body(previous,'build_model'))
    check('LinearModel_payload_unchanged',ast_body(ROOT/'project/qualify_l06.py','LinearModel')==ast_body(previous,'LinearModel'))
    events=[json.loads(x) for x in (OUT/'solver/events.jsonl').read_text(encoding='utf-8').splitlines()]
    check('real_first_incumbent_records_this_run',len(events)==solver['improving_incumbents']==1 and events[0]['objective_exact']=='6')
    report=(OUT/'report.md').read_text(encoding='utf-8')
    check('report_comparison_and_cash_numbers_have_actual_evidence','| 本方案 | 6/1 |' in report and '| 替代方案 | 10/1 |' in report and '| only | 0 | 100 | 0 | 6 | 94 | 10 |' in report)
    # The following is an actual human/model visual observation from view_image, not pixel/DOM automation.
    visual={'method':'three generated PNGs actually opened through view_image and manually inspected after this cold run',
      'cash':{'observed':'only scenario at week0 cash94; credit floor0; readable title/units/week/legend','matches_independent_data':True},
      'cost':{'observed':'stack total6 with purchase2/freight2/production1/holding1; legend outside, zero baseline','matches_independent_data':True},
      'storage':{'observed':'raw peak2 vs cap4; finished peak1 equals cap1; both axes start0 and outside legends readable','matches_independent_data':True},
      'scope':'only the one-week tiny figures; no16-week/multi-scenario visual qualification'}
    save(ROOT/'manual-visual-review.json',visual)
    save(ROOT/'independent-checks.json',checks)
    current=subprocess.run(['git','status','--short'],cwd='D:/myhexin-local/opencorvus',capture_output=True,text=True,encoding='utf-8');(ROOT/'git-status-after.txt').write_text(current.stdout,encoding='utf-8')
    result={'scope':'one-week source-only reference pipeline and current integer backend local review',
      'result':'local_micro_source_only_passed' if all(c['passed'] for c in checks) else 'review_failed','checks':len(checks),'all_passed':all(c['passed'] for c in checks),
      'cold_docker_exit':load(ROOT/'cold-command.json')['exit_code'],'cold_complete_process_seconds':load(ROOT/'cold-command.json')['seconds'],
      'program_main_seconds_excluding_imports':run['elapsed_seconds'],'native_solver_seconds':solver['seconds'],
      'primary_cost_exact':'6','alternative_cost_exact':'10','AR':10,'cash':94,'enumerated_joint_plans':len(cases),'feasible_joint_plans':len(feasible),
      'actual_figures_viewed':3,'micro_Docker_runs_by_reviewer':1,'full16_week_solver_runs_by_reviewer':0,'Provider_calls':0,'GPU_work':False,
      'full_professional_reference_approved':False,'remaining17_leaves_graded':False,'hours_validated':False,'heavy_freeze_approved':False,'delegations':0}
    save(ROOT/'stage-assessment.json',result);print(json.dumps(result,ensure_ascii=False,indent=2))
    if not result['all_passed']:raise SystemExit(1)

if __name__=='__main__':main()
