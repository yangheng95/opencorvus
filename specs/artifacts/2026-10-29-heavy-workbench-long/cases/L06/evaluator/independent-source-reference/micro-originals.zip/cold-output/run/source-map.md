# 原始事实来源与单位

目录按显式index定位，联合键与单位沿用随源码提供的DATA.md；没有按物理行序或文件摘要定义身份。

- raw_materials.csv：raw_index, raw_id, volume, holding_minor, initial_units
- products.csv：product_index, product_id, volume, holding_minor, initial_units, hours, sales_price_minor
- plants.csv：plant_index, plant_id
- supplier_terms.csv：supplier_index, supplier_id, lead_weeks, freight_minor, minimum_volume
- supplier_quotes.csv：supplier_id, raw_id, pack_units, unit_price_minor
- routes.csv：plant_id, product_id, allowed, production_cost_minor
- bom.csv：product_id, raw_id, units
- scenarios.csv：scenario_index, scenario_id, probability_numerator
- demand.csv：scenario_id, week, product_id, units
- supplier_capacity.csv：scenario_id, week, supplier_id, volume
- plant_capacity.csv：scenario_id, week, plant_id, hours

原料/产品目录分别提供体积、持有费、初始件数，以及产品每件工时/销售最小单位价格；供应条款按supplier_id，报价按supplier_id/raw_id；BOM按product_id/raw_id，资格/生产费按plant_id/product_id；情景分子配facility分母，需求/容量按scenario_id/week/实体ID。

facility提供周长、共同前缀、两仓容量、初始现金/信用和正回款滞后。数量为件/包装数，容量为表定体积/工时单位；所有金额为合成最小单位。normalized.json是这些业务事实的完整投影，ledger中的应收为已交付未回款销售额。
