"""One authorized source-only micro Docker replay. No full-case input is mounted."""
import ast
from datetime import datetime,timezone
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time
import uuid
sys.dont_write_bytecode=True

ROOT=Path(__file__).resolve().parent
REPO=Path('D:/myhexin-local/opencorvus')
CASE=REPO/'specs/artifacts/2026-10-29-heavy-workbench-long/cases/L06'
SOURCE=CASE/'evaluator/qualification/current-source'
AUTHOR=Path('D:/opencorvus-benchmark-runs/l06-reference-chain-20261029')
IMAGE='opencorvus-benchmark-reference:20261029'

def save(p,v):
    p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')

def main():
    project=ROOT/'project';project.mkdir(exist_ok=False)
    (ROOT/'Recall.md').write_text('''# Recall\n\n用户授权单层独立审查唯一当前整数后端及source-only微型参考。只复制源码/README/DATA和一周手算raw输入，唯一微型CPU Docker --rm/networknone；project和input只读，新output独立可写。不读旧plan作hint，不挂载任何旧输出/注册L/评分器/16周输入，不运行完整16周、Provider或GPU，不动用户服务/进程，不再次委托。\n\n审数据→同一build_model→新CP-SAT→真实first-incumbent基线/可行替代→机器账/报告/3图；实际查看图形，核对6/10、AR10、cash94。此微型资格不证明完整职业参考/其余17叶/小时或冻结。\n''',encoding='utf-8')
    names=('reproduce.py','l06_integer.py','qualify_l06.py','l06_plan.py','check_l06.py','l06_input.py','l06_delivery.py','l06_packet.py','l06_bound_certificate.py')
    inventory=[]
    for n in names:
        shutil.copy2(SOURCE/n,project/n);inventory.append({'source':str(SOURCE/n),'copy':str(project/n),'byte_equal_at_copy':(SOURCE/n).read_bytes()==(project/n).read_bytes()})
    for src,dst in [(SOURCE/'README-reference.md',project/'README.md'),(CASE/'public/DATA.md',project/'DATA.md')]:
        shutil.copy2(src,dst);inventory.append({'source':str(src),'copy':str(dst),'byte_equal_at_copy':src.read_bytes()==dst.read_bytes()})
    shutil.copytree(AUTHOR/'preflight/input',ROOT/'input')
    parent=ROOT/'cold-output';parent.mkdir()
    save(ROOT/'source-inventory.json',inventory)
    p=subprocess.run(['git','status','--short'],cwd=REPO,capture_output=True,text=True,encoding='utf-8');(ROOT/'git-status-before.txt').write_text(p.stdout,encoding='utf-8')
    image=subprocess.run(['docker','image','inspect',IMAGE,'--format','{{.Id}}'],capture_output=True,text=True,encoding='utf-8')
    save(ROOT/'image-identity.json',{'argv':['docker','image','inspect',IMAGE,'--format','{{.Id}}'],'exit_code':image.returncode,'image_id':image.stdout.strip(),'stderr':image.stderr})
    if image.returncode:raise RuntimeError('reference_image_unavailable')
    name='oc-l06-review-micro-'+uuid.uuid4().hex[:12]
    argv=['docker','run','--rm','--name',name,'--network','none','--cidfile',str(ROOT/'owned-container.cid'),
      '--mount',f'type=bind,source={project},target=/project,readonly',
      '--mount',f'type=bind,source={ROOT/"input"},target=/inputs,readonly',
      '--mount',f'type=bind,source={parent},target=/output',
      '-w','/project','-e','PYTHONDONTWRITEBYTECODE=1','-e','MPLBACKEND=Agg',IMAGE,
      '/opt/cpsat/bin/python','-B','reproduce.py','--input','/inputs','--output','/output/run']
    stamp=datetime.now(timezone.utc).isoformat();start=time.perf_counter()
    p=subprocess.run(argv,cwd=ROOT,capture_output=True,text=True,encoding='utf-8');elapsed=time.perf_counter()-start
    (ROOT/'cold.stdout.log').write_text(p.stdout,encoding='utf-8');(ROOT/'cold.stderr.log').write_text(p.stderr,encoding='utf-8')
    save(ROOT/'cold-command.json',{'argv':argv,'cwd':str(ROOT),'started_utc':stamp,'seconds':elapsed,'exit_code':p.returncode,
       'container_name':name,'source_only_project_files':[q.name for q in project.iterdir()],
       'input_files':[q.name for q in (ROOT/'input').iterdir()],
       'output_existed_at_start':False,'scope':'single one-week synthetic input; no full16 week input or previous results mounted'})
    print(json.dumps({'exit_code':p.returncode,'complete_docker_process_seconds':elapsed,'container_name':name,'output':str(parent/'run')},ensure_ascii=False))
    if p.returncode:raise SystemExit(p.returncode)

if __name__=='__main__':main()
