# Recall

本轮明确授权唯一一次16周完整独立source-only冷复建。project只取第一完整cold封存9源码+README/DATA；input只取公开11CSV+facility，反转所有CSV数据行、header/index不变。project/input只读，唯一新/results可写，networknone，无warm hint/旧plan/model/L/rubric挂载，默认8worker/seed20261029/gap.009、不设solver-seconds。

仅自有新容器，定时读取真实progress/容器状态而非持续日志；自然终态保存inspect/mount/image/argv/日志/exit后才可移除该自有容器。不动用户服务/其他容器/六个Paused任务，不做GPU/Provider或再次委托。终态按固定L47380核对真实C、独立业务925/全部向量/30numeric/报告和实际3图，允许不同正确策略。此次是参考交付独立重建，不是新候选小时级或全47/十题认证。
