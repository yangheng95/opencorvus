"""Freeze assessment-side tools and input identity outside all program mounts."""
import importlib.util
import json
from pathlib import Path
import shutil
import zipfile
from launch_full import ROOT,CASE,save

def load(p):return json.loads(p.read_text(encoding='utf-8'))
def module(name,p):
    spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def main():
    tools=ROOT/'audit-tools';tools.mkdir(exist_ok=False)
    previous=Path('D:/opencorvus-benchmark-runs/l06-public-contract-independent-review-20261029/review_packet.py')
    shutil.copy2(previous,tools/'independent_projection.py')
    helper=module('reviewer_input_projection',tools/'independent_projection.py')
    data,counts=helper.independent_projection(ROOT/'input');save(ROOT/'independent-normalized.json',data)
    evalsource=ROOT/'evaluation-source';evalsource.mkdir()
    source=Path('D:/opencorvus-benchmark-runs/l06-numeric-independent-review-20261029/source-repaired')
    for n in ('check_l06.py','l06_input.py','l06_numeric.py','l06_delivery.py','l06_packet.py','qualify_numeric.py'):shutil.copy2(source/n,evalsource/n)
    case=ROOT/'evaluation-case';case.mkdir();shutil.copytree(CASE/'public',case/'public');shutil.copy2(CASE/'rubric.draft.json',case/'rubric.draft.json')
    rubric=load(case/'rubric.draft.json');relative=rubric['quality_reference']['registration_file'];ref=load(CASE/relative)
    (case/relative).parent.mkdir(parents=True);shutil.copy2(CASE/relative,case/relative);shutil.copy2((CASE/relative).parent/'originals.zip',(case/relative).parent/'originals.zip')
    assert ref['lower_bound_minor']=={'numerator':47380,'denominator':1}
    locator=ref['input_identity']['captured_input'];archive_name,member=locator.split(':',1)
    with zipfile.ZipFile((case/relative).parent/archive_name) as z:captured=json.loads(z.read(member))
    expected={k:v for k,v in captured.items() if k not in ('status','qualification_variant')}
    result={'same_complete_business_facts_as_registered_capture':data==expected,'row_counts':counts,
      'all11_tables_reversed':len(load(ROOT/'row-reorder.json'))==11,
      'same_original_facility':(ROOT/'input/facility.json').read_bytes()==(CASE/'public/inputs/facility.json').read_bytes(),
      'frozen_reference_lower':47380,'evaluation_paths_are_not_program_mounts':['evaluation-case','evaluation-source','audit-tools'],
      'scope':'identity/assessment setup only; active output is not graded'}
    if (ROOT/'results/delivery/model.json').is_file():
        model_locator=ref['input_identity']['captured_model'];archive_name,member=model_locator.split(':',1)
        with zipfile.ZipFile((case/relative).parent/archive_name) as z:old_model=json.loads(z.read(member))
        save(ROOT/'registered-model.json',old_model)
        result['new_model_same_as_frozen_registered']=load(ROOT/'results/delivery/model.json')==old_model
    for src,n in [(Path('D:/opencorvus-benchmark-runs/l06-numeric-independent-review-20261029/review_numeric.py'),'independent_math.py'),
      (Path('D:/opencorvus-benchmark-runs/l06-cpsat-independent-review-20261029/source-snapshot/reviewer-tools/independent_checks.py'),'prefix925.py')]:shutil.copy2(src,tools/n)
    save(ROOT/'input-model-identity.json',result);print(json.dumps(result,ensure_ascii=False,indent=2))
    if not result['same_complete_business_facts_as_registered_capture']:raise SystemExit(1)

if __name__=='__main__':main()
