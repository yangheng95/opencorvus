"""Bounded periodic observation of only the owned reference container."""
from datetime import datetime,timezone
import json
from pathlib import Path
import subprocess
from launch_full import ROOT,FORMAT,save

def main():
    launch=json.loads((ROOT/'launch.json').read_text(encoding='utf-8'));cid=launch['container_id']
    inspected=subprocess.run(['docker','inspect',cid,'--format',FORMAT],capture_output=True,text=True,encoding='utf-8')
    if inspected.returncode:raise RuntimeError(inspected.stderr)
    state=json.loads(inspected.stdout)
    if state['Id']!=cid or state['Name']!='/'+launch['container_name']:raise RuntimeError('owned container identity mismatch')
    now=datetime.now(timezone.utc).isoformat();observation={'observed_utc':now,'container_state':state['State']}
    progress=ROOT/'results/delivery/solver/progress.json'
    observation['actual_progress']=json.loads(progress.read_text(encoding='utf-8')) if progress.is_file() else None
    stats=subprocess.run(['docker','stats',cid,'--no-stream','--format','{{json .}}'],capture_output=True,text=True,encoding='utf-8') if state['State']['Running'] else None
    if stats is not None:observation['actual_stats']=json.loads(stats.stdout) if stats.returncode==0 and stats.stdout.strip() else {'exit_code':stats.returncode,'stderr':stats.stderr}
    folder=ROOT/'observations';folder.mkdir(exist_ok=True);stamp=now.replace(':','-')
    save(folder/(stamp+'.json'),observation)
    if not state['State']['Running']:
        save(ROOT/'terminal-inspect.json',state)
        logs=subprocess.run(['docker','logs',cid],capture_output=True,text=True,encoding='utf-8')
        (ROOT/'stdout.log').write_text(logs.stdout,encoding='utf-8');(ROOT/'stderr.log').write_text(logs.stderr,encoding='utf-8')
        save(ROOT/'log-collection.json',{'argv':['docker','logs',cid],'exit_code':logs.returncode})
    print(json.dumps(observation,ensure_ascii=False))

if __name__=='__main__':main()
