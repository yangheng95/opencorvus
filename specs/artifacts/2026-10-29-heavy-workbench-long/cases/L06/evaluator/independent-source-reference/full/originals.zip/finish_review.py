"""Seal the completed independent review and remove only its exited container."""
from datetime import datetime,timezone
from fractions import Fraction
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
sys.dont_write_bytecode=True
from launch_full import ROOT,REPO,FORMAT,save

def load(path):return json.loads(path.read_text(encoding='utf-8'))

def main():
    stage=load(ROOT/'stage-assessment.json');out=ROOT/'results/delivery';d=load(ROOT/'independent-normalized.json')
    ledger=load(out/'ledger.json');report=(out/'report.md').read_text(encoding='utf-8')
    visual={
      'status':'actually_viewed_and_manually_checked','method':'view_image of all three actual completed full-replay PNGs; no UI automation',
      'viewed_utc':datetime.now(timezone.utc).isoformat(),
      'cash':{'path':str(out/'figures/cash.png'),'observations':'Three scenario identities, zero-based weeks 0..15, minor-unit cash axis and dashed credit floor are readable. All curves meet the -5369 floor at week3, recover after lagged receipts, and end base32208/disruption31310/shift32737, consistent with independent ledger.'},
      'cost':{'path':str(out/'figures/cost.png'),'observations':'Stacked scenario totals47142/48040/48773; purchases dominate, with freight/production/holding separately legended. Axis starts0, units and outside legend readable, no clipping.'},
      'storage':{'path':str(out/'figures/storage.png'),'observations':'Raw after-arrival/before-production and FG after-production/before-delivery are separate. Both axes start0; dashed caps240/100, three scenario legends outside axes; raw max191 and FG maxima85/85/91 agree with independent ledger. Common-prefix overlaps are legitimate.'},
      'all_three_readable_and_data_faithful':True,'formal_F04_score':None}
    save(ROOT/'manual-visual-review.json',visual)
    # Independently verify every supply-interruption quantity printed in prose.
    flow_checks=[]
    pattern=r'- (\w+)周(\d+)供方(\w+)容量(\d+)<最低装运(\d+)，因此该周不能启运；实际开关(\d+)。合法履约政策使用实际到货(\[[^\]]*\])与前存供给耗料(\[[^\]]*\])'
    plan=load(out/'plan.json')
    for sid,t,supplier,cap,moq,on,arrivals,consumption in re.findall(pattern,report):
        t=int(t);k=next(i for i,r in enumerate(d['suppliers']) if r['id']==supplier);s=next(r for r in d['scenarios'] if r['id']==sid);row=ledger['scenarios'][sid]['weeks'][t]
        flow_checks.append({'scenario':sid,'week':t,'supplier':supplier,'passed':int(cap)==s['supplier_capacity_volume'][t][k] and int(moq)==d['suppliers'][k]['minimum_volume'] and int(cap)<int(moq) and int(on)==plan['decisions'][sid]['truck_on'][t][k]==0 and json.loads(arrivals)==row['arrivals'] and json.loads(consumption)==row['consumption']})
    if not flow_checks or not all(x['passed'] for x in flow_checks):raise RuntimeError('report_interruption_arithmetic')
    save(ROOT/'assessment/report-interruption-checks.json',flow_checks)
    observations=[
      ('D01','observed_positive_full_base_rebuild','One actual source-only full16-week cold run, row-reversed public CSV, readonly mounts/networknone. Natural exit0, fresh new model and delivery; no supplied hint or old answer.'),
      ('D02','unassessed','Row reordering preserves the same business instance and is not a numeric variant. No new numerical variant search was run.'),
      ('D07','observed_positive_source_mapping','source-map lists all11 filenames/header families, joint identities, explicit index mapping and units; DATA.md gives normalized field mapping. Independent raw projection equals captured registered facts.'),
      ('D08','observed_positive_terminal_consistency','Native OPTIMAL is explicitly qualified optimal_within_requested_gap. Container exit0, run completed and native response stats agree; nonzero gap is not exact optimality.'),
      ('D09','current_success_path_observed_only','This run has a real feasible plan and numeric native bound; no fabricated unavailable result. Unknown/infeasible failure branches were not exercised by this full instance.'),
      ('D10','observed_positive_execution_identity','Saved launch/actual mounts/image/argv/terminal inspect, source copies and run parameters locate this execution. Input/source readonly; no source-version hash gate used.'),
      ('E01','observed_positive_baseline','First real callback plan equals baseline, independently feasible; cost241299/5. It is this run\u2019s initial solution, not an invented business-as-usual policy.'),
      ('E02','observed_positive_necessary_inventory','All six report witnesses independently recomputed: P0 week6 capacity0 requires10/10/11 prior units; P3 week9 capacity3 requires1/1/2. Actual stocks match.'),
      ('E03','observed_constraint_and_flow_with_narrative_limit','All three interruption paragraphs match capacity15<MOQ20, actual switch0, arrivals and consumption. They point to real alternative suppliers/early commitments in operations. Before a full human anchor claim, a clearer named supplier/lead-time comparison would strengthen the explanation; no action flip is forced.'),
      ('E04','observed_positive_cash_explanation','All scenarios\u2019 actual tightest week3: opening-3389 + receipts0 - spending1980 = -5369; AR24150 is not cash. Report states four-week lag and points to real detailed costs.'),
      ('E05','observed_positive_quantified_costs','Expected purchase362509/10 (75.94%), freight5310, production29004/5, holding3759/10; exact weighted totals and displayed percentages checked. Actions/ledger provide underlying quantities.'),
      ('E06','observed_real_small_tradeoff','A different complete feasible strategy transfers one P2 from F0 to F1 in base week15. Independent cost477391/10 is1.5 higher. Report does not invent external benefits; the economic comparison is narrow and could state the incremental cost explicitly.'),
      ('F01','observed_positive_complete_common_handoff','operations.csv contains all92 common-prefix shipment/order/production action rows for weeks0..3, including zeros, with suppliers/products/plants/units; independently exact against plan.'),
      ('F02','observed_positive_complete_recourse_handoff','All828 action rows for three actual scenario branches weeks4..15 are independently exact; common commitments appear once as all_scenarios. This is policy handoff under declared scenario observations, not live-world deployment.'),
      ('F03','observed_positive_limits','Report accurately distinguishes native nonzero gap, feasibility and qualification; synthetic scenarios/no-interest/ungiven futures remain limitations. Native bound47371 is not promoted over fixed registered47380 or to a rational certificate.'),
      ('F04','actually_viewed_positive','All three actual full-run PNGs were opened and manually compared with independent ledger; readable axes/units/scenarios/legends, cash floor and physical storage stages.'),
      ('F05','observed_positive_independent_instructions_replay','README command/dependencies/defaults used by a distinct evaluator in the declared image. Real complete replay succeeded; no missing setup step or old output supplied.')]
    save(ROOT/'remaining17-observations.json',{'scope':'Non-blind development reference observations; not a47-leaf grade or rater calibration','formal_scores_assigned':False,'observations':[{'leaf':i,'observation_status':s,'evidence_note':e,'score':None} for i,s,e in observations]})
    shutil.copy2(ROOT/'stage-assessment.json',ROOT/'stage-before-visual.json')
    stage.update({'manual_figures_review':'actually_viewed_and_checked_all_three','report_interruption_prose_checks':len(flow_checks),'remaining17_observation_file':'remaining17-observations.json','remaining17_leaves_scored':False,'current_substantive_full_reference_replay_blocker':None,'open_narrative_improvements':['E03 named alternative-supplier/lead-time explanation','E06 explicit incremental-cost explanation'],'full_reference_qualification_scope':'independent full base replay, business/30numeric/report facts/actual figures; not full47 formal scoring or rater calibration'})
    save(ROOT/'stage-assessment.json',stage)
    text=f'''# L06 完整参考交付：独立冷复建审查

结论：唯一一次授权的16周source-only独立复建已自然成功。完整业务账、固定注册界质量、30数值叶、报告算术与三张实际图均通过本轮核验；没有发现阻断这条完整基例参考复建的实质错误。未批准47叶全评分、重型冻结、小时级候选、专业校准或十题完成。

## 实际执行与输入身份

- 自有容器`oc-l06-review-full-c64dbeffe256`，CID`d7015f68ddd337d5e40a821bb3603bd4462781a74fd74a5c4f8052b22c58cdc5`。
- 2026-10-29T17:43:27.048293392Z → 18:04:20.299524696Z，自然exit0，无OOM。完整容器{stage['complete_container_seconds']:.6f}s；main{stage['main_seconds']:.9f}s；实际CP-SAT{stage['solver_seconds']:.9f}s。
- 仅第一完整参考封存的9源码+README/DATA和公开raw；11个CSV的数据行全部真实反转，header/显式index保留。独立投影与封存原输入语义一致，新建1488变量/1096行模型逐值一致。没有旧plan/model/hint/L/rubric挂载给程序。
- `/project`、`/input`只读，唯一新`/results`可写，networknone，8worker/seed20261029/gap.009，solver-seconds未设置，warm_start=null。实际image ID和完整argv/mounts在launch/terminal-inspect/image-identity.json。
- 本次只有一次完整优化；未运行Provider/GPU、未委托、未触碰其他容器或六个暂停任务。31项审查合同均过；原始command/source/日志/terminal及中间真实观察保留。

## 独立结果

- 实际C=238688/5=47737.6，固定预注册L=47380。`(C-L)/L=447/59225≈0.7547488392%`，满足C06的1%，没有改变L或使用原生OPTIMAL替代此计算。
- 本次原生界47371，原生primal分母gap约0.7679481164%，状态OPTIMAL仅为requested_gap内终态，不是精确最优证明，也不是独立有理dual/search证书。它与较强的既有注册L47380并不矛盾。
- 基线241299/5=48259.8为本次第一个真实incumbent；替代477391/10=47739.1，base周15把1件P2从F0转F1，期望成本高1.5。三份计划均实际业务CLI与独立递推可行，分别通过1488整数盒/1096行精确检查。
- 主方案925项独立累计前缀/阶段物理/现金检查全过；完整ledger/summary和独立实现完全一致，920条运营动作逐条相同。各场景最低现金-5369，最终现金32208/31310/32737，应收24150/24150/25230；raw峰191，FG峰85/85/91，不沿用旧期末容量口径。
- 真实numeric CLI给30 verified_pass、17 unassessed；total_score/business_success均null。31项审核不是31评分叶。

## 报告与人工呈现观察

报告的成本对照、六个必须提前生产见证、三处中断容量/实际到货/耗料、资金瓶颈和费用分量均从公开事实与真实动作重新算过。全部三张真实PNG已用view_image打开：现金、费用堆叠、两阶段仓容的单位/场景/图例可读，仓容轴从0起，数据与独立账相符。详见manual-visual-review.json。

remaining17-observations.json逐叶保留观察而不伪填正式分。D02数值变体仍未做；倒序行不是数值变体。E03供应中断段的实际事实正确，但命名供应商/提前期/替代比较可更具体；E06真实替代与费用已验证，但可明确写出增量1.5。这些叙述细化不构成业务或复建失败，也不能据此自动给所有人评叶满分。

## 证据与边界

运行原件：launch.json、source-inventory.json、row-reorder.json、initial-inspect.json、terminal-inspect.json、stdout.log/stderr.log及observations/。输入/模型身份：input-model-identity.json、independent-normalized.json、registered-model.json（评估侧，未挂载）。审核源码：audit_full.py、finish_review.py、audit-tools/，真实CLI及输出assessment/，完整925结果assessment/prefix/independent-full-audit.json，机器结论stage-assessment.json。

没有把首轮主方计划当期望策略；本次成本/轨迹/耗时不同仍按同一公开合同实核。耗时1253秒是参考程序完整复建壁钟时间，不是LLM有效工作时长或小时级困难的实证。剩余变体参考、17叶评分适配/专业多质量校准、盲评、正式候选执行与整十题资格仍未达。
'''
    (ROOT/'REVIEW.md').write_text(text,encoding='utf-8')
    # Save actual terminal/mounts/image/argv/logs first; then remove this exact
    # owned exited container, with no force flag and no other process action.
    launch=load(ROOT/'launch.json');cid=launch['container_id']
    inspected=subprocess.run(['docker','inspect',cid,'--format',FORMAT],capture_output=True,text=True,encoding='utf-8')
    if inspected.returncode:raise RuntimeError(inspected.stderr)
    actual=json.loads(inspected.stdout)
    if actual['Id']!=cid or actual['Name']!='/'+launch['container_name'] or actual['State']['Running'] or actual['State']['ExitCode']!=0:raise RuntimeError('owned_terminal_identity')
    if not all((ROOT/n).is_file() for n in ('terminal-inspect.json','stdout.log','stderr.log','log-collection.json','image-identity.json','launch.json')):raise RuntimeError('preserve_evidence_before_cleanup')
    save(ROOT/'pre-cleanup-inspect.json',actual)
    argv=['docker','rm',cid];p=subprocess.run(argv,capture_output=True,text=True,encoding='utf-8')
    save(ROOT/'cleanup.json',{'argv':argv,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'only_owned_exited_container':True,'observed_utc':datetime.now(timezone.utc).isoformat()})
    if p.returncode:raise RuntimeError(p.stderr)
    git=subprocess.run(['git','status','--short'],cwd=REPO,capture_output=True,text=True,encoding='utf-8');(ROOT/'git-status-end.txt').write_text(git.stdout,encoding='utf-8')
    print(json.dumps({'review':str(ROOT/'REVIEW.md'),'stage':str(ROOT/'stage-assessment.json'),'cost':stage['cost_exact'],'fixed_gap_percent':stage['gap_relative_to_fixed_L_percent'],'all31_checks_passed':stage['all_passed'],'visual':visual['status'],'owned_exited_container_cleanup_exit':p.returncode,'formal_full47_grade':False},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
