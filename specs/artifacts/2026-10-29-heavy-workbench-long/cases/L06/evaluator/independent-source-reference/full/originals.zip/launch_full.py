"""One authorized full source-only replay with semantically reordered public raw tables."""
from datetime import datetime,timezone
import csv
import json
from pathlib import Path
import shutil
import subprocess
import sys
import uuid
sys.dont_write_bytecode=True

ROOT=Path(__file__).resolve().parent
REPO=Path('D:/myhexin-local/opencorvus')
CASE=REPO/'specs/artifacts/2026-10-29-heavy-workbench-long/cases/L06'
AUTHOR=Path('D:/opencorvus-benchmark-runs/l06-reference-chain-20261029/full-cold')
IMAGE='opencorvus-benchmark-reference:20261029'
FORMAT='{"Id":{{json .Id}},"Name":{{json .Name}},"State":{{json .State}},"Path":{{json .Path}},"Args":{{json .Args}},"Image":{{json .Image}},"Mounts":{{json .Mounts}},"Config":{"Cmd":{{json .Config.Cmd}},"Image":{{json .Config.Image}},"WorkingDir":{{json .Config.WorkingDir}}},"HostConfig":{"NetworkMode":{{json .HostConfig.NetworkMode}},"NanoCpus":{{json .HostConfig.NanoCpus}},"CpusetCpus":{{json .HostConfig.CpusetCpus}},"DeviceRequests":{{json .HostConfig.DeviceRequests}},"Runtime":{{json .HostConfig.Runtime}}}}'

def save(p,v):
    p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')

def main():
    project=ROOT/'project';project.mkdir(exist_ok=False);raw=ROOT/'input';raw.mkdir();results=ROOT/'results';results.mkdir()
    (ROOT/'Recall.md').write_text('''# Recall\n\n本轮明确授权唯一一次16周完整独立source-only冷复建。project只取第一完整cold封存9源码+README/DATA；input只取公开11CSV+facility，反转所有CSV数据行、header/index不变。project/input只读，唯一新/results可写，networknone，无warm hint/旧plan/model/L/rubric挂载，默认8worker/seed20261029/gap.009、不设solver-seconds。\n\n仅自有新容器，定时读取真实progress/容器状态而非持续日志；自然终态保存inspect/mount/image/argv/日志/exit后才可移除该自有容器。不动用户服务/其他容器/六个Paused任务，不做GPU/Provider或再次委托。终态按固定L47380核对真实C、独立业务925/全部向量/30numeric/报告和实际3图，允许不同正确策略。此次是参考交付独立重建，不是新候选小时级或全47/十题认证。\n''',encoding='utf-8')
    names=['reproduce.py','qualify_l06.py','l06_integer.py','l06_plan.py','check_l06.py','l06_input.py','l06_delivery.py','l06_packet.py','l06_bound_certificate.py','README.md','DATA.md']
    inventory=[]
    for n in names:
        shutil.copy2(AUTHOR/'project'/n,project/n);inventory.append({'source':str(AUTHOR/'project'/n),'copy':str(project/n),'byte_equal_at_copy':(AUTHOR/'project'/n).read_bytes()==(project/n).read_bytes()})
    rows=[]
    for p in sorted((CASE/'public/inputs').iterdir()):
        if p.suffix=='.csv':
            with p.open(newline='',encoding='utf-8') as f:r=csv.reader(f);header=next(r);values=list(r)
            with (raw/p.name).open('w',newline='',encoding='utf-8') as f:w=csv.writer(f);w.writerow(header);w.writerows(reversed(values))
            rows.append({'file':p.name,'rows_reversed':len(values),'header':header})
        elif p.name=='facility.json':shutil.copy2(p,raw/p.name)
        else:raise RuntimeError('unexpected public input '+p.name)
    if len(rows)!=11:raise RuntimeError('expected11 rawCSV')
    save(ROOT/'source-inventory.json',inventory);save(ROOT/'row-reorder.json',rows)
    status=subprocess.run(['git','status','--short'],cwd=REPO,capture_output=True,text=True,encoding='utf-8');(ROOT/'git-status-start.txt').write_text(status.stdout,encoding='utf-8')
    image=subprocess.run(['docker','image','inspect',IMAGE,'--format','{{.Id}}'],capture_output=True,text=True,encoding='utf-8')
    save(ROOT/'image-identity.json',{'argv':['docker','image','inspect',IMAGE,'--format','{{.Id}}'],'exit_code':image.returncode,'image_id':image.stdout.strip(),'stderr':image.stderr})
    if image.returncode:raise RuntimeError('reference image unavailable')
    name='oc-l06-review-full-'+uuid.uuid4().hex[:12]
    argv=['docker','run','-d','--name',name,'--network','none','--cidfile',str(ROOT/'owned-container.cid'),
      '--mount',f'type=bind,source={project},target=/project,readonly',
      '--mount',f'type=bind,source={raw},target=/input,readonly',
      '--mount',f'type=bind,source={results},target=/results',
      '-w','/project','-e','PYTHONDONTWRITEBYTECODE=1','-e','MPLBACKEND=Agg',IMAGE,
      '/opt/cpsat/bin/python','-B','reproduce.py','--input','/input','--output','/results/delivery']
    stamp=datetime.now(timezone.utc).isoformat();p=subprocess.run(argv,cwd=ROOT,capture_output=True,text=True,encoding='utf-8')
    receipt={'argv':argv,'started_utc':stamp,'launcher_exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'container_name':name,
       'container_id':p.stdout.strip(),'solver_time_cap':None,'fixed_reference_lower_bound_for_external_check_only':47380,
       'micro_or_old_outputs_mounted':False,'scope':'one complete independent reference replay, not candidate or hours'}
    save(ROOT/'launch.json',receipt)
    if p.returncode:raise RuntimeError(receipt)
    inspected=subprocess.run(['docker','inspect',receipt['container_id'],'--format',FORMAT],capture_output=True,text=True,encoding='utf-8')
    if inspected.returncode:raise RuntimeError(inspected.stderr)
    save(ROOT/'initial-inspect.json',json.loads(inspected.stdout));print(json.dumps({'container_name':name,'container_id':receipt['container_id'],'launcher_exit':p.returncode},ensure_ascii=False))

if __name__=='__main__':main()
