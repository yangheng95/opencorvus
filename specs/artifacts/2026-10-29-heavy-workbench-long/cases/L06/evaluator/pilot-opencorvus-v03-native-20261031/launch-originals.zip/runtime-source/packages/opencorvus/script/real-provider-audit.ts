import assert from "node:assert/strict"
import { createHash } from "node:crypto"
import { ProviderError } from "../src/provider/error"
import { registerProviderResponseObserver, type ProviderRequestContext } from "../src/util/provider-response-observation"
import type { ReadableStreamActivitySettlement, ReadableStreamErrorFacts } from "../src/util/stream-activity"

export interface ProviderResponseReaderObservation {
  boundary: "provider-source-reader"
  state: "awaiting_response" | "awaiting_binding" | "reading" | "settled" | "body_absent" | "http_error" | "fetch_failed" | "binding_failed"
  receivedAt?: number
  boundAt?: number
  chunkCount?: number
  byteCount?: number
  firstByteReadAt?: number | null
  lastByteReadAt?: number | null
  terminal?: { kind: ReadableStreamActivitySettlement; at: number; error?: ReadableStreamErrorFacts }
  observationError?: "callback_failed"
  identityState?: "observed" | "unknown" | "redacted"
  requestContext?: ProviderRequestContext
}

export class ProviderAuditProbeConfigurationError extends Error {
  override readonly name = "ProviderAuditProbeConfigurationError"
}

export type ProviderInputProbe = { id: string; text: string }
export type ProviderInputEvidence = {
  body_utf8_bytes: number
  body_sha256: string
  probes: Array<{
    id: string
    text_utf8_bytes: number
    text_sha256: string
    matches: Array<{
      json_pointer: string
      pointer_redacted: boolean
      message_role: string | null
      role_json_pointer: string | null
      decoded_value_utf8_start: number
      value_sha256: string
    }>
  }>
}

const sha256 = (text: string) => createHash("sha256").update(text, "utf8").digest("hex")

/** Exact known-text evidence only; offsets are in decoded string values, not serialized JSON. */
function registerInputObservation(input: { probes: unknown; redactor: CredentialRedactor }) {
  if (!Array.isArray(input.probes) || input.probes.length === 0)
    throw new ProviderAuditProbeConfigurationError("Provider input observation requires a non-empty probe array")
  const ids = new Set<string>()
  const probes: ProviderInputProbe[] = input.probes.map((probe: unknown) => {
    if (
      !probe ||
      typeof probe !== "object" ||
      Array.isArray(probe) ||
      Object.keys(probe).sort().join(",") !== "id,text" ||
      !("id" in probe) ||
      typeof probe.id !== "string" ||
      !/^[a-z][a-z0-9_.-]*$/.test(probe.id) ||
      !("text" in probe) ||
      typeof probe.text !== "string" ||
      probe.text.length === 0 ||
      Buffer.from(probe.text, "utf8").toString("utf8") !== probe.text ||
      ids.has(probe.id)
    )
      throw new ProviderAuditProbeConfigurationError(
        "Each input probe requires one unique ID and non-empty, well-formed text",
      )
    if (input.redactor.containsCredential(probe.id) || input.redactor.containsCredential(probe.text))
      throw new ProviderAuditProbeConfigurationError("Registered input evidence contains a known credential")
    ids.add(probe.id)
    // Copy the declaration once. Later caller edits cannot redefine the observed object.
    return { id: probe.id, text: probe.text }
  })
  return (body: string, parsed: unknown): ProviderInputEvidence => {
    const evidence: ProviderInputEvidence = {
      body_utf8_bytes: Buffer.byteLength(body, "utf8"),
      body_sha256: sha256(body),
      probes: probes.map((probe) => ({
        id: probe.id,
        text_utf8_bytes: Buffer.byteLength(probe.text, "utf8"),
        text_sha256: sha256(probe.text),
        matches: [],
      })),
    }
    const pending: Array<{
      value: unknown
      pointer: string
      pointerRedacted: boolean
      role?: { value: string; pointer: string }
    }> = [{ value: parsed, pointer: "", pointerRedacted: false }]
    while (pending.length) {
      const { value, pointer, pointerRedacted, role } = pending.pop()!
      if (typeof value === "string") {
        let valueSHA: string | undefined
        for (const [index, probe] of probes.entries()) {
          let from = 0
          let previousIndex = 0
          let decodedByteOffset = 0
          for (;;) {
            const at = value.indexOf(probe.text, from)
            if (at < 0) break
            decodedByteOffset += Buffer.byteLength(value.slice(previousIndex, at), "utf8")
            previousIndex = at
            const safePointer = input.redactor.redact(pointer)
            evidence.probes[index]!.matches.push({
              json_pointer: safePointer,
              pointer_redacted: pointerRedacted || safePointer !== pointer,
              message_role: role ? input.redactor.redact(role.value) : null,
              role_json_pointer: role ? input.redactor.redact(role.pointer) : null,
              decoded_value_utf8_start: decodedByteOffset,
              value_sha256: (valueSHA ??= sha256(value)),
            })
            from = at + 1
          }
        }
      } else if (Array.isArray(value)) {
        for (let index = value.length - 1; index >= 0; index--)
          pending.push({ value: value[index], pointer: `${pointer}/${index}`, pointerRedacted, role })
      } else if (value && typeof value === "object") {
        const declaredRole = "role" in value ? value.role : undefined
        const contextRole =
          typeof declaredRole === "string" &&
          ["system", "developer", "user", "assistant", "tool"].includes(declaredRole)
            ? { value: declaredRole, pointer: `${pointer}/role` }
            : role
        for (const [key, item] of Object.entries(value).reverse()) {
          const redactedKey = input.redactor.redact(key)
          const safeKey = redactedKey.replaceAll("~", "~0").replaceAll("/", "~1")
          pending.push({
            value: item,
            pointer: `${pointer}/${safeKey}`,
            pointerRedacted: pointerRedacted || redactedKey !== key,
            role: contextRole,
          })
        }
      }
    }
    return evidence
  }
}

export class CopiedOAuthCredentialExpiredError extends Error {
  override readonly name = "CopiedOAuthCredentialExpiredError"
  readonly code = "COPIED_OAUTH_CREDENTIAL_EXPIRED"
  constructor(readonly expiresAt: number) {
    super("Copied OAuth access has expired; reconnect or refresh through the original Provider authority")
  }
}

export class CopiedOAuthRefreshForbiddenError extends Error {
  override readonly name = "CopiedOAuthRefreshForbiddenError"
  constructor() { super("Copied OAuth authority cannot refresh the source credential generation") }
}

export function assertCopiedOAuthAccess(expiresAt: number) {
  assert(Number.isFinite(expiresAt) && expiresAt > 0, "Copied OAuth access requires a finite positive expiry")
  if (Date.now() >= expiresAt) throw new CopiedOAuthCredentialExpiredError(expiresAt)
}

/** Test-runner evidence only. Retain identities/positions, never prompt bodies, headers or credentials. */
export type ProviderToolSchemaShape = {
  path: "parameters" | "function.parameters"
  strict: "true" | "false" | "unknown" | "invalid"
  rootKind: "object" | "array" | "string" | "number" | "integer" | "boolean" | "null" | "unknown" | "invalid"
  propertiesCount?: number
  requiredCount?: number
  nullableCount?: number
  unknownNullableCount?: number
  additionalProperties: "true" | "false" | "unknown" | "invalid"
}

function schemaBoolean(owner: Record<string, unknown>, field: string): ProviderToolSchemaShape["strict"] {
  if (!Object.hasOwn(owner, field)) return "unknown"
  return owner[field] === true ? "true" : owner[field] === false ? "false" : "invalid"
}

function nullableSchema(value: unknown): boolean | undefined {
  if (!value || typeof value !== "object" || Array.isArray(value)) return undefined
  const schema = value as Record<string, unknown>
  if (Object.hasOwn(schema, "$ref") || Object.hasOwn(schema, "not") || Object.hasOwn(schema, "allOf")) return undefined
  const types = ["object", "array", "string", "number", "integer", "boolean", "null"]
  if (typeof schema.type === "string" && types.includes(schema.type)) return schema.type === "null"
  if (Array.isArray(schema.type) && schema.type.length > 0 && schema.type.every((type) => typeof type === "string" && types.includes(type))) return schema.type.includes("null")
  const union = Object.hasOwn(schema, "anyOf") ? schema.anyOf : schema.oneOf
  if (!Array.isArray(union) || union.length === 0) return undefined
  // Recognize explicit immediate branches only; nested or unresolved domains
  // are unknown diagnostics, not a second schema normalizer.
  let unknown = false
  for (const branch of union) {
    if (!branch || typeof branch !== "object" || Array.isArray(branch)) { unknown = true; continue }
    const node = branch as Record<string, unknown>
    if (Object.hasOwn(node, "$ref") || Object.hasOwn(node, "not") || Object.hasOwn(node, "allOf") || Object.hasOwn(node, "anyOf") || Object.hasOwn(node, "oneOf")) { unknown = true; continue }
    if (node.type === "null") return true
    if (Array.isArray(node.type) && node.type.length > 0 && node.type.every((type) => typeof type === "string" && types.includes(type))) {
      if (node.type.includes("null")) return true
    } else if (typeof node.type !== "string" || !types.includes(node.type)) unknown = true
  }
  return unknown ? undefined : false
}

function projectSchemaShape(owner: Record<string, unknown>, path: ProviderToolSchemaShape["path"]): ProviderToolSchemaShape {
  const value = owner.parameters
  const shape: ProviderToolSchemaShape = { path, strict: schemaBoolean(owner, "strict"), rootKind: "unknown", additionalProperties: "unknown" }
  if (!Object.hasOwn(owner, "parameters") || typeof value === "boolean") return shape
  if (!value || typeof value !== "object" || Array.isArray(value)) return { ...shape, rootKind: "invalid" }
  const schema = value as Record<string, unknown>
  const kinds = ["object", "array", "string", "number", "integer", "boolean", "null"] as const
  if (Object.hasOwn(schema, "type")) shape.rootKind = kinds.find((kind) => kind === schema.type) ?? (Array.isArray(schema.type) ? "unknown" : "invalid")
  shape.additionalProperties = schemaBoolean(schema, "additionalProperties")
  if (schema.properties && typeof schema.properties === "object" && !Array.isArray(schema.properties)) {
    const values = Object.values(schema.properties)
    shape.propertiesCount = values.length
    shape.nullableCount = 0
    shape.unknownNullableCount = 0
    for (const property of values) {
      const nullable = nullableSchema(property)
      if (nullable === true) shape.nullableCount++
      else if (nullable === undefined) shape.unknownNullableCount++
    }
  }
  if (Array.isArray(schema.required)) shape.requiredCount = schema.required.length
  return shape
}

export type ProviderToolDeclarations = {
  state: "absent" | "null" | "array" | "invalid"
  entries: Array<{
    index: number
    type?: string
    type_state: "present" | "absent" | "redacted" | "invalid"
    name_state: "absent" | "observed"
    names: Array<{ path: "name" | "function.name"; state: "present" | "redacted" | "invalid"; value?: string }>
    schema_shapes: ProviderToolSchemaShape[]
  }>
}

function projectToolDeclarations(parsed: Record<string, unknown>, redactor: CredentialRedactor): ProviderToolDeclarations {
  if (!Object.hasOwn(parsed, "tools")) return { state: "absent", entries: [] }
  if (parsed.tools === null) return { state: "null", entries: [] }
  if (!Array.isArray(parsed.tools)) return { state: "invalid", entries: [] }
  const identifier = (value: unknown): { state: "present" | "redacted" | "invalid"; value?: string } => {
    if (typeof value !== "string") return { state: "invalid" }
    if (redactor.containsCredential(value)) return { state: "redacted" }
    if (!/^[A-Za-z0-9_-]{1,64}$/.test(value)) return { state: "invalid" }
    return { state: "present", value }
  }
  return { state: "array", entries: parsed.tools.map((tool, index) => {
    const names: ProviderToolDeclarations["entries"][number]["names"] = []
    const schema_shapes: ProviderToolSchemaShape[] = []
    if (!tool || typeof tool !== "object" || Array.isArray(tool))
      return { index, type_state: "invalid", name_state: "absent", names, schema_shapes }
    if (Object.hasOwn(tool, "parameters") || Object.hasOwn(tool, "name") || (tool.type === "function" && !Object.hasOwn(tool, "function"))) schema_shapes.push(projectSchemaShape(tool, "parameters"))
    if (Object.hasOwn(tool, "name")) names.push({ path: "name", ...identifier(tool.name) })
    if (Object.hasOwn(tool, "function")) {
      const fn = tool.function
      if (fn && typeof fn === "object" && !Array.isArray(fn)) {
        schema_shapes.push(projectSchemaShape(fn, "function.parameters"))
        if (Object.hasOwn(fn, "name")) names.push({ path: "function.name", ...identifier(fn.name) })
      } else names.push({ path: "function.name", state: "invalid" })
    }
    const type = Object.hasOwn(tool, "type") ? identifier(tool.type) : { state: "absent" as const, value: undefined }
    return { index, ...(type.value === undefined ? {} : { type: type.value }), type_state: type.state,
      name_state: names.length ? "observed" : "absent", names, schema_shapes }
  }) }
}

export class RealProviderAudit implements Disposable {
  readonly requests: Array<{ model: string; streaming: true; status?: number; input_evidence?: ProviderInputEvidence; tool_declarations?: ProviderToolDeclarations; response_reader: ProviderResponseReaderObservation }> = []
  readonly localOrigins = new Set<string>()
  readonly nativeFetch = globalThis.fetch
  exhausted = false
  readonly #wrapped: typeof fetch

  #publish(entry?: (typeof this.requests)[number]) {
    try {
      this.onUpdate?.()
    } catch {
      if (entry) entry.response_reader.observationError = "callback_failed"
    }
  }

  constructor(readonly modelID: string, readonly maxRequests: number | null, readonly onUpdate?: () => void,
    readonly authority?: { copiedOAuthExpiresAt: number },
    observation?: { probes: unknown; redactor: CredentialRedactor },
    toolDeclarations?: { redactor: CredentialRedactor }) {
    assert(maxRequests === null || (Number.isSafeInteger(maxRequests) && maxRequests >= 0), "Request budget must be null or a nonnegative integer")
    if (authority) assertCopiedOAuthAccess(authority.copiedOAuthExpiresAt)
    const observeInput = observation ? registerInputObservation(observation) : undefined
    if (toolDeclarations && !(toolDeclarations.redactor instanceof CredentialRedactor))
      throw new ProviderAuditProbeConfigurationError("Tool declaration observation requires its initialized CredentialRedactor")
    this.#wrapped = Object.assign(async (input: RequestInfo | URL, init?: RequestInit) => {
      const url = input instanceof Request ? input.url : String(input)
      let entry: (typeof this.requests)[number] | undefined
      if (!this.localOrigins.has(new URL(url).origin)) {
        // A copy has access authority only. Refreshing it would fork the source's
        // rotating credential generation into an independent, disposable store.
        if (authority) assertCopiedOAuthAccess(authority.copiedOAuthExpiresAt)
        const body = typeof init?.body === "string" ? init.body : input instanceof Request ? await input.clone().text() : undefined
        if (body) {
          let parsed: any
          try { parsed = JSON.parse(body) } catch {}
          if (authority && (parsed?.grant_type === "refresh_token" || new URLSearchParams(body).get("grant_type") === "refresh_token")) {
            throw new CopiedOAuthRefreshForbiddenError()
          }
          if (parsed?.model) {
            assert.equal(parsed.model, modelID, "Actual outgoing request model differs from authorized model")
            assert.equal(parsed.stream, true, "Every real Provider request must stream")
            if (maxRequests !== null && this.requests.length >= maxRequests) {
              this.exhausted = true
              this.#publish()
              throw new Error("E2E_REQUEST_BUDGET_EXHAUSTED")
            }
            entry = { model: parsed.model, streaming: true,
              response_reader: { boundary: "provider-source-reader", state: "awaiting_response" },
              ...(toolDeclarations ? { tool_declarations: projectToolDeclarations(parsed, toolDeclarations.redactor) } : {}),
              ...(observeInput ? { input_evidence: observeInput(body, parsed) } : {}) }
            this.requests.push(entry)
            this.#publish(entry)
          }
        }
      }
      let response: Response
      try {
        response = await this.nativeFetch(input, init)
      } catch (error) {
        if (entry) {
          entry.response_reader.state = "fetch_failed"
          this.#publish(entry)
        }
        throw error
      }
      if (entry) {
        entry.status = response.status
        const observed = entry.response_reader
        observed.receivedAt = Date.now()
        // Fetch null-body statuses have no source reader, even when a host
        // exposes an empty ReadableStream for the response body.
        const bodyAbsent = !response.body || [101, 103, 204, 205, 304].includes(response.status)
        observed.state = bodyAbsent ? "body_absent" : !response.ok ? "http_error" : "awaiting_binding"
        if (observed.state === "awaiting_binding") {
          try {
            registerProviderResponseObserver(response, {
              onBind: (context) => {
                if (observed.state !== "awaiting_binding") throw new Error("Response reader observation already has its owner")
                observed.state = "reading"
                observed.boundAt = Date.now()
                observed.chunkCount = 0
                observed.byteCount = 0
                observed.firstByteReadAt = null
                observed.lastByteReadAt = null
                const identityRedactor = observation?.redactor ?? toolDeclarations?.redactor
                if (!context) observed.identityState = "unknown"
                else if ([context.sessionID, ...Object.values(context.streamRequest), ...Object.values(context.activity ?? {}).filter((value): value is string => typeof value === "string")]
                  .some((value) => identityRedactor?.containsCredential(value))) observed.identityState = "redacted"
                else {
                  observed.identityState = "observed"
                  observed.requestContext = { sessionID: context.sessionID, streamRequest: { ...context.streamRequest }, ...(context.activity ? { activity: { ...context.activity } } : {}) }
                }
                // Readers of disk snapshots need the bound identity before EOF.
                this.#publish(entry)
              },
              onChunk: (byteLength) => {
                if (observed.state !== "reading") throw new Error("Response reader observation requires its bound reader")
                observed.chunkCount! += 1
                observed.byteCount! += byteLength
                if (byteLength > 0) {
                  const readAt = Date.now()
                  observed.firstByteReadAt ??= readAt
                  observed.lastByteReadAt = readAt
                }
              },
              onSettlement: (kind, error) => {
                observed.state = "settled"
                observed.terminal = { kind, at: Date.now(), ...(error ? { error: { ...error } } : {}) }
                this.#publish(entry)
              },
              onObservationError: () => { observed.observationError = "callback_failed" },
            })
          } catch {
            observed.state = "binding_failed"
          }
        }
        this.#publish(entry)
      }
      return response
    }, this.nativeFetch) as typeof fetch
    globalThis.fetch = this.#wrapped
  }

  [Symbol.dispose]() {
    if (globalThis.fetch === this.#wrapped) globalThis.fetch = this.nativeFetch
  }

  async preflight(input: {
    serverURL: URL
    model: string
    inactivityMs: number
    activity: (sessionID: string) => unknown
    pollIntervalMs?: number
  }) {
    this.localOrigins.add(input.serverURL.origin)
    const request = async (route: string, body?: unknown, directory?: string) => {
      const url = new URL(route, input.serverURL)
      if (directory) url.searchParams.set("directory", directory)
      const response = await this.nativeFetch(url, {
        method: body === undefined ? "GET" : "POST",
        headers: { "content-type": "application/json" },
        ...(body === undefined ? {} : { body: JSON.stringify(body) }),
        signal: AbortSignal.timeout(input.inactivityMs),
      })
      assert(response.ok, `Provider preflight ${route}: HTTP ${response.status}`)
      return await response.json() as any
    }
    const firstRequest = this.requests.length
    const chat = await request("/global/chat/start", { requestID: crypto.randomUUID(), text: "Reply with OK.", model: input.model })
    let signature = ""
    let lastActivity = Date.now()
    for (;;) {
      const messages = await request(`/session/${chat.session.id}/message`, undefined, chat.session.directory)
      const assistant = messages.find((entry: any) => entry.info.role === "assistant" && entry.info.parentID === chat.messageID)
      const next = JSON.stringify({ messages, activity: input.activity(chat.session.id) })
      if (next !== signature) { signature = next; lastActivity = Date.now() }
      if (this.exhausted) throw new Error("E2E_REQUEST_BUDGET_EXHAUSTED")
      if (assistant?.info.error) throw new Error(`PROVIDER_PREFLIGHT: ${JSON.stringify(assistant.info.error)}`)
      if (assistant?.info.time.completed) {
        assert(assistant.parts.some((part: any) => part.type === "text" && part.text.trim()), "Credential preflight must receive a persisted streamed reply")
        assert(this.requests.slice(firstRequest).some((entry) => entry.status === 200), "Actual outgoing model request must be observed")
        return { sessionID: chat.session.id as string, credential: "usable", catalog: "projected", actualModel: this.modelID, streaming: true }
      }
      if (Date.now() - lastActivity > input.inactivityMs) throw new Error("PROVIDER_PREFLIGHT_INACTIVITY")
      await new Promise((resolve) => setTimeout(resolve, input.pollIntervalMs ?? 500))
    }
  }
}

const processAuditIdentity = Symbol.for("opencorvus.native-provider-audit")
type ProcessProviderAudit = { audit: RealProviderAudit; persist: () => void }
const processAuditState = globalThis as typeof globalThis & { [processAuditIdentity]?: ProcessProviderAudit }

/** One audit per process, shared by the explicit checker and its loaded plugin. */
export function installProcessProviderAudit(create: () => ProcessProviderAudit): ProcessProviderAudit {
  return processAuditState[processAuditIdentity] ??= create()
}

export function requireProcessProviderAudit(): ProcessProviderAudit {
  const value = processAuditState[processAuditIdentity]
  if (!value) throw new Error("Native Provider audit has not been initialized")
  return value
}

/** Known credential values stay in memory; only redacted diagnostics leave the checker. */
export class CredentialRedactor {
  readonly #values = new Set<string>()

  collect(value: unknown): void {
    if (!value || typeof value !== "object") return
    for (const [key, item] of Object.entries(value)) {
      const segments = key.replace(/([a-z0-9])([A-Z])/g, "$1_$2").split(/[^a-zA-Z0-9]+/).filter(Boolean)
      const credentialField = segments.some((_, index) => {
        const suffix = segments.slice(index).join("_")
        return ProviderError.isStructuredCredentialField(suffix) || ["key", "access", "refresh"].includes(suffix.toLowerCase())
      })
      if (credentialField && typeof item === "string" && item.length > 0) {
        this.#values.add(item)
      } else if (item && typeof item === "object") this.collect(item)
    }
  }

  private encodings(): string[] {
    const encodings = new Set<string>()
    for (const value of [...this.#values].sort((a, b) => b.length - a.length)) {
      for (const encoded of new Set([value, JSON.stringify(value).slice(1, -1), encodeURIComponent(value)])) {
        encodings.add(encoded)
      }
    }
    return [...encodings]
  }

  containsCredential(text: string): boolean {
    return this.encodings().some((value) => text.includes(value))
  }

  redact(text: string): string {
    for (const value of this.encodings()) text = text.replaceAll(value, "[REDACTED]")
    return text
  }

  /** Audit field names are schema-owned. Redact their string values before JSON
   * escaping, preserving typed counters and valid syntax even for numeric secrets. */
  serialize(value: unknown, space?: number): string {
    const serialized = JSON.stringify(value, (_key, item) => typeof item === "string" ? this.redact(item) : item, space)
    if (serialized === undefined) throw new Error("Audit output must be JSON serializable")
    return serialized
  }
}
