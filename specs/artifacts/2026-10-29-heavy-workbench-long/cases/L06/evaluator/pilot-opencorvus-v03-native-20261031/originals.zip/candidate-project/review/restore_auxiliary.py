"""Remove only two empty reviewer-created original-control SQLite sidecars.

The pre-review git status had neither file. No tracked or original WAL is removed.
This is a one-time preservation correction, not part of business verification.
"""

from pathlib import Path
import json
import subprocess

ROOT = Path(__file__).resolve().parents[1]
base = ROOT / "exercise/run-001/control-ae409a32d57c/journal.sqlite3"
files = [Path(str(base) + "-wal"), Path(str(base) + "-shm")]
assert files[0].stat().st_size == 0, "Never remove a WAL with transaction data"
result = []
for p in files:
    rel = p.relative_to(ROOT).as_posix()
    tracked = subprocess.run(
        ["git", "ls-files", "--", rel],
        cwd=ROOT,
        text=True,
        capture_output=True,
        check=True,
    )
    assert not tracked.stdout.strip(), "Never remove an original tracked sidecar"
    result.append(
        {
            "path": rel,
            "bytes": p.stat().st_size,
            "reason": "Created by reviewer read-only SQLite observation; absent from initial git status",
        }
    )
for p in files:
    p.unlink()
(ROOT / "review/auxiliary-correction.json").write_text(
    json.dumps(result, indent=2) + "\n"
)
print(
    "Removed only the reviewer-created empty WAL and its SHM; original tracked evidence preserved."
)
