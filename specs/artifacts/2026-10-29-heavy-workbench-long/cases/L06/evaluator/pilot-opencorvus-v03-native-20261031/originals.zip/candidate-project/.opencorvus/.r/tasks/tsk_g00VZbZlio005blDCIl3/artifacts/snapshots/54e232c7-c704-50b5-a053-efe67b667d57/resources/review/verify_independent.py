"""Tester-owned raw-CSV recurrence; no producer or public physics imports.

Run from the primary project with C:/Python314/python.exe -B review/verify_independent.py.
Only review/ outputs are written. Original evidence is opened read-only.
"""

import copy
import csv
from fractions import Fraction as F
import json
from pathlib import Path
import sqlite3
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "review"


def read(p):
    def pairs(xs):
        d = {}
        for k, v in xs:
            assert k not in d, ("duplicate JSON key", k)
            d[k] = v
        return d

    return json.loads(
        Path(p).read_text(encoding="utf-8"),
        object_pairs_hook=pairs,
        parse_constant=lambda v: (_ for _ in ()).throw(ValueError(v)),
    )


def table(n):
    with (ROOT / "public/inputs" / (n + ".csv")).open(
        newline="", encoding="utf-8"
    ) as f:
        return list(csv.DictReader(f))


def index(n, field):
    rows = table(n)
    rows.sort(key=lambda r: int(r[field]))
    assert [int(r[field]) for r in rows] == list(range(len(rows)))
    return rows


R = index("raw_materials", "raw_index")
J = index("products", "product_index")
P = index("plants", "plant_index")
S = index("supplier_terms", "supplier_index")
SC = index("scenarios", "scenario_index")
facts = read(ROOT / "public/inputs/facility.json")
rv = [int(r["volume"]) for r in R]
jv = [int(r["volume"]) for r in J]
bom = {(r["product_id"], r["raw_id"]): int(r["units"]) for r in table("bom")}
quotes = {(r["supplier_id"], r["raw_id"]): r for r in table("supplier_quotes")}
routes = {(r["plant_id"], r["product_id"]): r for r in table("routes")}
demand = {
    (r["scenario_id"], int(r["week"]), r["product_id"]): int(r["units"])
    for r in table("demand")
}
supply = {
    (r["scenario_id"], int(r["week"]), r["supplier_id"]): int(r["volume"])
    for r in table("supplier_capacity")
}
hours = {
    (r["scenario_id"], int(r["week"]), r["plant_id"]): int(r["hours"])
    for r in table("plant_capacity")
}
assert (
    len(demand) == 8 * 16 * 4 and len(supply) == 8 * 16 * 3 and len(hours) == 8 * 16 * 2
)
assert len(bom) == 16 and len(quotes) == 12 and len(routes) == 8


def event(pid, t):
    return dict(
        demand=[demand[pid, t, j["product_id"]] for j in J],
        supplier_capacity_volume=[supply[pid, t, s["supplier_id"]] for s in S],
        plant_capacity_hours=[hours[pid, t, p["plant_id"]] for p in P],
    )


def initial():
    return dict(
        format="l06-week-state/1",
        phase="post_week",
        next_week=0,
        raw=[int(r["initial_units"]) for r in R],
        finished=[int(j["initial_units"]) for j in J],
        cash=facts["initial_cash_minor"],
        total_cost_minor=0,
        arrivals_by_week=[[0] * len(R) for _ in range(16)],
        receipts_by_week=[0] * (16 + facts["receipt_lag_weeks"]),
    )


def view(st, e):
    t = st["next_week"]
    return dict(
        week=t,
        historical_arrivals=st["arrivals_by_week"][t],
        historical_receipts=st["receipts_by_week"][t],
        raw_before_new_orders=[
            a + b for a, b in zip(st["raw"], st["arrivals_by_week"][t])
        ],
        finished_before_production=st["finished"],
        cash_after_historical_receipts=st["cash"] + st["receipts_by_week"][t],
        external=e,
    )


def tensor(x, dims, binary=False):
    if not dims:
        assert type(x) is int and x >= 0 and (not binary or x <= 1), x
    else:
        assert type(x) is list and len(x) == dims[0]
        for y in x:
            tensor(y, dims[1:], binary)


def advance(st, e, a):
    assert set(a) == {"order_lots", "truck_on", "production"}
    tensor(a["order_lots"], [3, 4])
    tensor(a["truck_on"], [3], True)
    tensor(a["production"], [2, 4])
    st = copy.deepcopy(st)
    t = st["next_week"]
    v = view(st, e)
    available = v["raw_before_new_orders"].copy()
    # Consumed historical queues are cleared in the delivered state representation.
    st["arrivals_by_week"][t] = [0] * len(R)
    purchase = freight = production = 0
    for si, s in enumerate(S):
        units = [
            a["order_lots"][si][m]
            * int(quotes[s["supplier_id"], r["raw_id"]]["pack_units"])
            for m, r in enumerate(R)
        ]
        vol = sum(q * u for q, u in zip(units, rv))
        on = a["truck_on"][si]
        assert (
            int(s["minimum_volume"]) * on
            <= vol
            <= e["supplier_capacity_volume"][si] * on
        )
        due = t + int(s["lead_weeks"])
        assert not any(units) or due < 16
        for m, r in enumerate(R):
            purchase += units[m] * int(
                quotes[s["supplier_id"], r["raw_id"]]["unit_price_minor"]
            )
            if due == t:
                available[m] += units[m]
            elif due < 16:
                st["arrivals_by_week"][due][m] += units[m]
        freight += on * int(s["freight_minor"])
    made = [sum(a["production"][pi][j] for pi in range(2)) for j in range(4)]
    for pi, p in enumerate(P):
        assert (
            sum(a["production"][pi][j] * int(J[j]["hours"]) for j in range(4))
            <= e["plant_capacity_hours"][pi]
        )
        for ji, j in enumerate(J):
            route = routes[p["plant_id"], j["product_id"]]
            q = a["production"][pi][ji]
            assert int(route["allowed"]) or q == 0
            production += q * int(route["production_cost_minor"])
    raw_peak = sum(q * u for q, u in zip(available, rv))
    finished_peak = sum((st["finished"][j] + made[j]) * jv[j] for j in range(4))
    assert (
        raw_peak <= facts["raw_storage_volume"]
        and finished_peak <= facts["product_storage_volume"]
    )
    st["raw"] = [
        available[m]
        - sum(made[j] * bom[J[j]["product_id"], R[m]["raw_id"]] for j in range(4))
        for m in range(4)
    ]
    st["finished"] = [st["finished"][j] + made[j] - e["demand"][j] for j in range(4)]
    assert min(st["raw"]) >= 0 and min(st["finished"]) >= 0
    holding = sum(q * int(r["holding_minor"]) for q, r in zip(st["raw"], R)) + sum(
        q * int(j["holding_minor"]) for q, j in zip(st["finished"], J)
    )
    cost = purchase + freight + production + holding
    receipts = st["receipts_by_week"][t]
    st["receipts_by_week"][t] = 0
    st["cash"] += receipts - cost
    st["total_cost_minor"] += cost
    st["next_week"] += 1
    st["receipts_by_week"][t + facts["receipt_lag_weeks"]] += sum(
        e["demand"][j] * int(J[j]["sales_price_minor"]) for j in range(4)
    )
    assert st["cash"] >= (0 if t == 15 else -facts["credit_limit_minor"])
    if t == 15:
        assert st["finished"] == [0] * 4
    return st, dict(
        purchase=purchase,
        freight=freight,
        production=production,
        holding=holding,
        cost=cost,
        receipts=receipts,
        cash=st["cash"],
        raw_peak=raw_peak,
        finished_peak=finished_peak,
    )


def canonical_action(st, e):
    made = [max(0, e["demand"][j] - st["finished"][j]) for j in range(4)]
    prod = [[0] * 4 for _ in range(2)]
    cap = e["plant_capacity_hours"].copy()
    for j in [0, 3, 1, 2]:
        left = made[j]
        for p in range(2):
            if int(routes[P[p]["plant_id"], J[j]["product_id"]]["allowed"]):
                q = min(left, cap[p] // int(J[j]["hours"]))
                prod[p][j] = q
                left -= q
                cap[p] -= q * int(J[j]["hours"])
        assert left == 0
    lots = [[0] * 4 for _ in range(3)]
    avail = view(st, e)["raw_before_new_orders"]
    lots[-1] = [
        max(
            0,
            sum(made[j] * bom[J[j]["product_id"], R[m]["raw_id"]] for j in range(4))
            - avail[m],
        )
        for m in range(4)
    ]
    on = int(any(lots[-1]))
    vol = sum(q * u for q, u in zip(lots[-1], rv))
    if on and vol < int(S[-1]["minimum_volume"]):
        lots[-1][0] += int(S[-1]["minimum_volume"]) - vol
    return dict(order_lots=lots, truck_on=[0, 0, on], production=prod)


def db_rows(p):
    # Even mode=ro may create WAL/SHM sidecars. Inspect an exact local copy of
    # the full SQLite resource set, including any real pending WAL transactions.
    import shutil
    import tempfile
    from contextlib import closing

    with tempfile.TemporaryDirectory(prefix="sqlite-read-", dir=OUT) as temp:
        target = Path(temp) / p.name
        for suffix in ("", "-wal", "-shm"):
            source = Path(str(p) + suffix)
            if source.exists():
                shutil.copy2(source, Path(str(target) + suffix))
        with closing(
            sqlite3.connect("file:" + target.as_posix() + "?mode=ro", uri=True)
        ) as con:
            assert con.execute("PRAGMA user_version").fetchone()[0] == 2
            return [
                json.loads(r[0])
                for r in con.execute("SELECT item_json FROM commits ORDER BY week")
            ]


def run():
    policy = read(ROOT / "policy.json")
    assert (
        set(policy) == {"format", "decisions"}
        and policy["format"] == "l06-tree-policy/1"
    )
    assert policy == read(ROOT / "actor/policy.json")
    ids = [r["scenario_id"] for r in SC]
    assert set(policy["decisions"]) == set(ids)
    probs = {
        r["scenario_id"]: F(
            int(r["probability_numerator"]), facts["probability_denominator"]
        )
        for r in SC
    }
    assert sum(probs.values()) == 1
    with (ROOT / "results/weekly-ledger.csv").open(newline="") as f:
        ledger = list(csv.DictReader(f))
    with (ROOT / "results/commitment-policy.csv").open(newline="") as f:
        coords = list(csv.DictReader(f))
    assert len(ledger) == len({(r["path"], r["week"]) for r in ledger}) == 128
    assert (
        len(coords)
        == len(
            {(r["path"], r["week"], r["kind"], r["entity"], r["item"]) for r in coords}
        )
        == 2944
    )
    lc = {(r["path"], int(r["week"])): r for r in ledger}
    cc = {
        (r["path"], int(r["week"]), r["kind"], r["entity"], r["item"]): int(
            r["quantity"]
        )
        for r in coords
    }
    original = read(ROOT / "exercise/run-001/journals.json")
    fresh = read(OUT / "native-001/journals.json")
    assert original == fresh
    canonical_policy = read(ROOT / "results/canonical-alternative.json")
    records = {}
    info = {}
    expected = F(0)
    alternative = F(0)
    lower = F(0)
    components = {
        k: F(0)
        for k in ("purchase_cost", "freight_cost", "production_cost", "holding_cost")
    }
    states = {}
    zero_count = 0
    for pid in ids:
        dec = policy["decisions"][pid]
        assert set(dec) == {"order_lots", "truck_on", "production"}
        tensor(dec["order_lots"], [16, 3, 4])
        tensor(dec["truck_on"], [16, 3], True)
        tensor(dec["production"], [16, 2, 4])
        st = initial()
        base = initial()
        cash = []
        history = []
        path_states = []
        for t in range(16):
            e = event(pid, t)
            a = {k: dec[k][t] for k in dec}
            history.append(e)
            key = json.dumps(history, sort_keys=True)
            assert key not in info or info[key] == a
            info[key] = a
            path_states.append(copy.deepcopy(st))
            st, row = advance(st, e, a)
            cash.append(st["cash"])
            assert all(F(lc[pid, t][k]) == v for k, v in row.items())
            item = original[pid][t]
            assert (
                set(item) == {"request_id", "week", "event", "action", "receipt"}
                and item["week"] == t
            )
            assert item["event"] == e and item["action"] == a
            assert item["receipt"] == dict(
                request_id=item["request_id"],
                committed_week=t,
                next_week=t + 1,
                cost_minor=row["cost"],
                cash_minor=row["cash"],
            )
            for si, s in enumerate(S):
                assert cc[pid, t, "truck", s["supplier_id"], ""] == a["truck_on"][si]
                zero_count += int(a["truck_on"][si] == 0)
                for m, r in enumerate(R):
                    assert (
                        cc[pid, t, "order_lots", s["supplier_id"], r["raw_id"]]
                        == a["order_lots"][si][m]
                    )
                    zero_count += int(a["order_lots"][si][m] == 0)
            for p, pp in enumerate(P):
                for j, jj in enumerate(J):
                    assert (
                        cc[pid, t, "production", pp["plant_id"], jj["product_id"]]
                        == a["production"][p][j]
                    )
                    zero_count += int(a["production"][p][j] == 0)
            for k, field in zip(
                components, ["purchase", "freight", "production", "holding"]
            ):
                components[k] += probs[pid] * row[field]
            ca = canonical_action(base, e)
            assert ca == {k: canonical_policy["decisions"][pid][k][t] for k in dec}
            base, _ = advance(base, e, ca)
        states[pid] = path_states
        tail = st["receipts_by_week"][16:]
        records[pid] = dict(
            final_cash=st["cash"],
            minimum_cash=min(cash),
            final_receivable=sum(tail),
            due_after_horizon={
                str(w): st["receipts_by_week"][w]
                for w in range(16, 20)
                if st["receipts_by_week"][w]
            },
        )
        expected += probs[pid] * st["total_cost_minor"]
        alternative += probs[pid] * base["total_cost_minor"]
        needs = [sum(demand[pid, t, j["product_id"]] for t in range(16)) for j in J]
        lb = sum(
            max(
                0,
                sum(needs[j] * bom[J[j]["product_id"], r["raw_id"]] for j in range(4))
                - int(r["initial_units"]),
            )
            * min(
                int(quotes[s["supplier_id"], r["raw_id"]]["unit_price_minor"])
                for s in S
            )
            for r in R
        )
        lb += sum(
            needs[j]
            * min(
                int(routes[p["plant_id"], J[j]["product_id"]]["production_cost_minor"])
                for p in P
                if int(routes[p["plant_id"], J[j]["product_id"]]["allowed"])
            )
            for j in range(4)
        )
        lower += probs[pid] * lb
    assert read(ROOT / "results/receivables.json") == records
    sm = read(ROOT / "results/summary.json")
    assert F(sm["expected_cost_exact"]) == expected <= F(85, 100) * alternative
    assert (
        F(sm["alternative_exact"]) == alternative
        and F(sm["saving_exact"]) == alternative - expected
    )
    assert sm["full_path_count"] == len(ids) and sm["information_nodes"] == len(info)
    assert sm["minimum_cash"] == min(r["minimum_cash"] for r in records.values())
    assert {k: F(v) for k, v in sm["components_exact"].items()} == components
    assert {k: F(v) for k, v in sm["probabilities_exact"].items()} == probs
    assert sm["exact_analytic_lower_bound"] == lower
    executions = []
    packets = []
    for folder in [ROOT / "exercise/run-001", OUT / "native-001"]:
        episodes = read(folder / "episodes.json")
        cmds = read(folder / "actual-commands.json")
        assert len(episodes) == 8 and [c["native_exit"] for c in cmds] == [73] + [0] * 9
        for ep in episodes:
            f = folder / ep["directory"]
            rows = db_rows(f / "journal.sqlite3")
            pid = ep["path"]
            assert rows == original[pid]
            export = read(f / "completed/journal-export.json")
            final, _ = advance(
                states[pid][-1], event(pid, 15), original[pid][-1]["action"]
            )
            assert export["state"] == final
            phases = (
                ["before-loss", "completed"]
                if ep["has_real_commit_loss"]
                else ["completed"]
            )
            for phase in phases:
                term = read(f / phase / "worker-terminal.json")
                active = read(f / phase / "active.json")
                assert (
                    term["native_exit"] == 0
                    and term["pid"] == active["worker_pid"]
                    and term["argv"] == active["argv"]
                )
                assert active["environment"].get("PYTHONNOUSERSITE") == "1"
                trace = [
                    json.loads(line)
                    for line in (f / phase / "visible-exchange.jsonl")
                    .read_text()
                    .splitlines()
                ]
                assert len(trace) % 2 == 0
                for i in range(0, len(trace), 2):
                    packet = trace[i]["packet"]
                    t = packet["week"]
                    e = event(pid, t)
                    exp = dict(
                        format="l06-current-operation/1",
                        week=t,
                        committed=original[pid][:t],
                        history=[event(pid, w) for w in range(t + 1)],
                        post_week_state=states[pid][t],
                        decision_view=view(states[pid][t], e),
                    )
                    assert packet == exp
                    response = trace[i + 1]["response"]
                    assert response == dict(
                        format="l06-action-response/1",
                        request_id=original[pid][t]["request_id"],
                        action=original[pid][t]["action"],
                    )
                    if folder == OUT / "native-001":
                        packets.append(packet)
            if ep["has_real_commit_loss"]:
                cut = db_rows(f / "after-commit-original.sqlite3")
                assert len(cut) == 8 and cut == rows[:8]
                crash = read(f / "before-loss/crash-after-commit.json")
                recovery = read(f / "completed/resume-receipt.json")
                assert (
                    crash["week"] == 7
                    and crash["database_commit"]
                    and not crash["next_packet_sent"]
                    and crash["planned_exit"] == 73
                )
                assert crash["receipt"] == cut[-1]["receipt"] == recovery["receipt"]
                assert recovery["replayed"] and recovery["next_week"] == 8
            executions.append(
                dict(
                    directory=str(f.relative_to(ROOT)),
                    path=pid,
                    committed_rows=len(rows),
                    original_prefix_preserved=ep["has_real_commit_loss"],
                )
            )
        terminal = read(folder / "owner-terminal.json")
        control = folder / terminal["row_order_control"]
        assert (
            db_rows(control / "journal.sqlite3")
            == original[terminal["control_path_after_terminal"]]
        )
    # Fresh actor restarts on complete packets. Negative tests modify only copies.
    argv = [
        sys.executable,
        "-u",
        "-B",
        str(OUT / "source-only/actor/actor.py"),
        "--public",
        str(OUT / "source-only/public"),
    ]
    tests = []

    def invoke(name, ps, success=True):
        r = subprocess.run(
            argv,
            input="".join(json.dumps(p) + "\n" for p in ps),
            text=True,
            encoding="utf-8",
            capture_output=True,
            cwd=OUT,
        )
        assert (r.returncode == 0) == success, (name, r.stderr)
        tests.append(
            dict(name=name, exit=r.returncode, stdout=r.stdout, stderr=r.stderr)
        )
        return r

    p = next(p for p in packets if p["week"] == 8)
    one = invoke("fresh restart week8", [p])
    twice = invoke("duplicate complete packet", [p, p])
    assert twice.stdout.splitlines() == one.stdout.splitlines() * 2
    for field in ["cash", "raw", "finished", "arrivals_by_week", "receipts_by_week"]:
        bad = copy.deepcopy(p)
        v = bad["post_week_state"][field]
        if type(v) is int:
            bad["post_week_state"][field] += 1
        elif type(v[0]) is list:
            v[0][0] += 1
        else:
            v[0] += 1
        invoke("reject forged state " + field, [bad], False)
    bad = copy.deepcopy(p)
    bad["decision_view"]["cash_after_historical_receipts"] += 1
    invoke("reject forged decision view", [bad], False)
    bad = copy.deepcopy(p)
    bad["committed"][-1]["receipt"]["cash_minor"] += 1
    invoke("reject changed receipt", [bad], False)
    (OUT / "actor-probes.json").write_text(json.dumps(tests, indent=2) + "\n")
    result = dict(
        status="passed",
        primary_revision="575a7ad",
        expected_cost_exact=str(expected),
        alternative_exact=str(alternative),
        saving_exact=str(alternative - expected),
        information_nodes=len(info),
        weekly_rows=len(ledger),
        action_coordinates=len(coords),
        zero_coordinates=zero_count,
        components_exact={k: str(v) for k, v in components.items()},
        minimum_cash=sm["minimum_cash"],
        analytic_lower_bound=str(lower),
        receivables=records,
        execution_checks=executions,
        actor_probe_count=len(tests),
        method="Independent original indexed CSV parser and integer recurrence; no producer/public physics imported.",
    )
    (OUT / "independent-check.json").write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            {
                k: v
                for k, v in result.items()
                if k not in ["execution_checks", "receivables"]
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    run()
