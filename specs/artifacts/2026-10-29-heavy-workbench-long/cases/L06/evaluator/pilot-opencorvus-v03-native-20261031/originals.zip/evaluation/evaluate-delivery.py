from pathlib import Path
import datetime,json,subprocess,zipfile
root=Path(__file__).resolve().parent; case=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L06/evaluator/upgrade-v0.3'); delivery=root.parent/'project'; now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
assert json.loads((root/'workspace-seal-terminal.json').read_text(encoding='utf-8'))['native_exit']==0
public=root/'frozen-public';public.mkdir(exist_ok=False);names=[];differences=[]
with zipfile.ZipFile('D:/opencorvus-benchmark-runs/l06-v03-codex-fresh-native-20261031/public-inputs.zip') as z:
 for n in z.namelist():
  if n.endswith('/'):continue
  rel=n.removeprefix('public/'); p=public/rel; assert p.resolve().is_relative_to(public.resolve());p.parent.mkdir(parents=True,exist_ok=True); data=z.read(n);p.write_bytes(data);names.append(rel)
  live=delivery/'public'/rel
  if not live.is_file() or live.read_bytes()!=data:differences.append(rel)
extras=sorted(p.relative_to(delivery/'public').as_posix() for p in (delivery/'public').rglob('*') if p.is_file() and p.relative_to(delivery/'public').as_posix() not in names)
write(root/'public-scope-observation.json',{'at':now(),'immutable_public_git':'24c0132396519498432bd9f07780c1509d58140f','original_files':len(names),'source_byte_differences':differences,'extra_public_files':extras,'identity_only':'same immutable inputs, not functional proof or OS history confinement'})
assert len(names)==25 and not differences
layout={'format':'l06-delivery-layout/1','paths':{'policy':'policy.json','programme':'actor','report':'REPORT.md','weekly_ledger':'results/weekly-ledger.csv','commitments':'results/commitment-policy.csv','summary':'results/summary.json','receivables':'results/receivables.json','source_map':'results/source-map.json','reproduce':'HANDOFF.md','requirements':'requirements-lock.txt','figures':['figures/cash-and-storage.png','figures/cost-comparison.png']},'provenance':'Owner locator for the original natural native Task delivery; HANDOFF contains the actual public-exercise/rebuild commands. No delivery bytes or wrapper changed.'}
write(root/'delivery-layout.json',layout)
def invoke(name,argv):
 start=now();r=subprocess.run(argv,capture_output=True,text=True,encoding='utf-8');write(root/name,{'started_at':start,'finished_at':now(),'argv':argv,'native_exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'scope':'post-seal controlled evaluation; not candidate effective hours'});print(json.dumps({'command':name,'native_exit':r.returncode,'stdout_tail':r.stdout[-1500:],'stderr':r.stderr[-1000:]}));return r.returncode
native=invoke('private-run-command.json',['C:/Python314/python.exe','-X','utf8','-B',str(case/'run_native_whole.py'),'--public',str(public),'--project',str(delivery/'actor'),'--policy',str(delivery/'policy.json'),'--out',str(root/'private-run'),'--python','C:/Python314/python.exe'])
if native:raise SystemExit(native)
raise SystemExit(invoke('prepare-command.json',['C:/Python314/python.exe','-X','utf8','-B',str(case/'check_whole.py'),'prepare','--run',str(root/'private-run'),'--delivery',str(delivery),'--layout',str(root/'delivery-layout.json'),'--role','candidate','--out',str(root/'assignment')]))
