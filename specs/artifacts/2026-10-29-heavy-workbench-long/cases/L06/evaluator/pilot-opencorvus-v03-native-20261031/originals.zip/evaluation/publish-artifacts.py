from pathlib import Path
import shutil,json,zipfile,datetime
root=Path('D:/opencorvus-benchmark-runs/l06-v03-opencorvus-native-20261031');ev=root/'evaluation';review=Path('D:/opencorvus-benchmark-runs/l06-v03-opencorvus-independent-review-20261031')
dest=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L06/evaluator/pilot-opencorvus-v03-native-20261031'); project=root/'project'
assert (ev/'final-grade.json').exists() and (review/'review.json').exists()
def cp(src,target):
 target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,target);assert target.read_bytes()==src.read_bytes()
plain=[]
for name in ['REPORT.md','REPORT.pdf','HANDOFF.md','requirements.txt','requirements-lock.txt','policy.json','delivery-source.zip','diagnostic-evidence.zip']:
 cp(project/name,dest/'candidate-delivery'/name);plain.append(name)
for folder in ['actor','tools','results','figures']:
 for p in sorted((project/folder).rglob('*')):
  if p.is_file() and '__pycache__' not in p.parts:
   rel=p.relative_to(project);cp(p,dest/'candidate-delivery'/rel);plain.append(rel.as_posix())
for name in ['handover-observed.json','native-lifecycle-terminal.json','workspace-seal-started.json','private-run-command.json','prepare-command.json','delivery-layout.json','public-scope-observation.json','model-stream-final.json','owned-dispose-request.json','actual-grade-command.json','final-grade.json','visual-observations.json','git-head.txt','git-history.txt']:
 if (ev/name).exists():cp(ev/name,dest/'final-assessment'/name)
cp(ev/'assignment/assignment.json',dest/'final-assessment/assignment.json');cp(root/'evidence/server-result.json',dest/'final-assessment/server-result.json')
for p in sorted(review.rglob('*')):
 if p.is_file() and p.suffix.lower() in ['.json','.md','.py','.txt'] and '__pycache__' not in p.parts:
  cp(p,dest/'independent-review'/p.relative_to(review))
entries=[];excluded=collections=0
blocked={'.venv','.cache','.git','.ruff_cache','__pycache__'}
with zipfile.ZipFile(dest/'originals.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(project.rglob('*')):
  if not p.is_file():continue
  rel=p.relative_to(project)
  if any(x in blocked for x in rel.parts):excluded+=1;continue
  name='candidate-project/'+rel.as_posix();z.write(p,name);entries.append({'member':name,'bytes':p.stat().st_size})
 for p in sorted(ev.rglob('*')):
  if not p.is_file():continue
  rel=p.relative_to(ev)
  if rel.name in {'complete-workspace.zip','native-task-original.sqlite3','workspace-seal-terminal.json'} or rel.parts[0] in {'frozen-public','assignment'} or any(x in blocked for x in rel.parts):continue
  name='evaluation/'+rel.as_posix();z.write(p,name);entries.append({'member':name,'bytes':p.stat().st_size})
 for p in sorted((ev/'assignment').rglob('*')):
  if p.is_file() and 'closed' not in p.relative_to(ev/'assignment').parts and '__pycache__' not in p.parts:
   name='evaluation/assignment/'+p.relative_to(ev/'assignment').as_posix();z.write(p,name);entries.append({'member':name,'bytes':p.stat().st_size})
 for folder in ['launch','observations','inspect-logs','evidence']:
  for p in sorted((root/folder).rglob('*')):
   if p.is_file():
    name=folder+'/'+p.relative_to(root/folder).as_posix();z.write(p,name);entries.append({'member':name,'bytes':p.stat().st_size})
 for p in sorted(review.rglob('*')):
  if p.is_file() and '__pycache__' not in p.parts:
   name='independent-review/'+p.relative_to(review).as_posix();z.write(p,name);entries.append({'member':name,'bytes':p.stat().st_size})
seal=json.loads((ev/'workspace-seal-terminal.json').read_text(encoding='utf-8'))
receipt={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'originals_zip_bytes':(dest/'originals.zip').stat().st_size,'members':entries,'member_count':len(entries),'plain_candidate_relative_files':plain,'plain_copies_byte_identical_to_original':True,'complete_external_workspace_capsule':str(ev/'complete-workspace.zip'),'complete_external_capsule_bytes':seal['archive_bytes'],'complete_external_capsule_members':seal['member_count'],'all_workspace_files_originally_preserved':seal['all_workspace_files_preserved'],'repository_archive_scope':'all original candidate scientific/source/native/review products, actual private run and prepared facts, independent review, Task persistence capsule and full streaming audit; dependency/cache/Git byte files and duplicate closed/frozen-public only in complete external capsule','excluded_candidate_dependency_cache_git_files':excluded,'sensitive_auth_models':'not in any capsule or repository; separate runtime staging normally disposed','functional_evidence':'real source-only native run, raw SQL/wire/CSV and same checker plus independent review; byte identity proves only original object preservation'}
(dest/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in receipt.items() if k not in ['members','plain_candidate_relative_files']}))
