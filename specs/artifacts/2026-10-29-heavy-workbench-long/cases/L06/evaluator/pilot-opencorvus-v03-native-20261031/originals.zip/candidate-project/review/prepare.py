"""Extract the delivered source without touching the original delivery."""

from pathlib import Path
import json
import zipfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "review"
target = OUT / "source-only"
assert not target.exists()
with zipfile.ZipFile(ROOT / "delivery-source.zip") as z:
    assert z.testzip() is None
    names = z.namelist()
    assert len(names) == len(set(names))
    for n in names:
        assert not Path(n).is_absolute() and ".." not in Path(n).parts
        assert z.read(n) == (ROOT / n).read_bytes(), n
    z.extractall(target)
with zipfile.ZipFile(ROOT / "diagnostic-evidence.zip") as z:
    assert z.testzip() is None
    evidence = z.namelist()
    for n in evidence:
        assert z.read(n) == (ROOT / n).read_bytes(), n
(OUT / "archive-check.json").write_text(
    json.dumps(
        {
            "source_archive_entries": names,
            "diagnostic_archive_entries": evidence,
            "all_archive_entries_equal_primary_bytes": True,
            "source_only_directory": str(target),
        },
        indent=2,
    )
    + "\n",
    encoding="utf-8",
)
print(
    "Archive integrity and direct primary-byte equivalence passed:",
    len(names),
    len(evidence),
)
