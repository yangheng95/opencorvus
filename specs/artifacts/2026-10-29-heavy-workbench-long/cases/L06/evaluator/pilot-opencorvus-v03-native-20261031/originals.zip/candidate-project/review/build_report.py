"""Build the requested reusable independent report and evidence archive."""

from pathlib import Path
from xml.sax.saxutils import escape
import json
import zipfile
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer

ROOT = Path(__file__).resolve().parents[1]
HERE = ROOT / "review"
styles = getSampleStyleSheet()
styles["BodyText"].fontSize = 9
styles["BodyText"].leading = 12
styles["BodyText"].spaceAfter = 6
story = []
for line in (HERE / "REPORT.md").read_text(encoding="utf-8").splitlines():
    if not line:
        continue
    if line.startswith("# "):
        story.append(Paragraph(escape(line[2:]), styles["Title"]))
    elif line.startswith("## "):
        story.append(Paragraph(escape(line[3:]), styles["Heading1"]))
    elif line.startswith("### "):
        story.append(Paragraph(escape(line[4:]), styles["Heading2"]))
    else:
        story.append(
            Paragraph(
                escape(line.replace("**", "").replace("`", "")), styles["BodyText"]
            )
        )
    story.append(Spacer(1, 2))


def footer(canvas, doc):
    canvas.saveState()
    canvas.setFont("Helvetica", 8)
    canvas.setFillColor(colors.gray)
    canvas.drawString(
        0.6 * inch,
        0.35 * inch,
        "Independent finite-outcome verification | primary revision 575a7ad",
    )
    canvas.drawRightString(7.7 * inch, 0.35 * inch, str(doc.page))
    canvas.restoreState()


doc = SimpleDocTemplate(
    str(HERE / "REPORT.pdf"),
    leftMargin=0.6 * inch,
    rightMargin=0.6 * inch,
    topMargin=0.6 * inch,
    bottomMargin=0.6 * inch,
    title="Independent staged-factory verification",
    author="Independent Tester",
)
doc.build(story, onFirstPage=footer, onLaterPages=footer)
paths = [
    p
    for p in HERE.iterdir()
    if p.is_file() and p.suffix in (".py", ".json", ".md", ".pdf")
]
paths += [p for p in (HERE / "native-001").rglob("*") if p.is_file()]
paths += [HERE / "source-only/results/information-relaxation.json"]
with zipfile.ZipFile(HERE / "evidence.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in sorted(paths):
        z.write(p, p.relative_to(ROOT).as_posix())
with zipfile.ZipFile(HERE / "evidence.zip") as z:
    assert z.testzip() is None
    for n in z.namelist():
        assert z.read(n) == (ROOT / n).read_bytes()
print(
    json.dumps(
        {
            "report": "review/REPORT.pdf",
            "evidence": "review/evidence.zip",
            "archived_files": len(paths),
        }
    )
)
