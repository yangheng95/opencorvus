"""Focused public protocol tests; no destination mutation or producer output writes."""

import copy
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
PUBLIC = ROOT / "review/source-only/public"
sys.path[:0] = [
    str(PUBLIC / "exercise-tools/upgrade-v0.3/source"),
    str(PUBLIC / "exercise-tools/qualification/current-source"),
]
from tree_business import load_data, append, packet, validate_action, BusinessError
from verify_independent import initial, event, advance, canonical_action, view

d, _ = load_data(PUBLIC)
rows = json.loads((ROOT / "review/native-001/journals.json").read_text())["T00"][:8]
item = rows[-1]
results = []
same, receipt, replay = append(
    d, rows, item["event"], item["action"], item["request_id"]
)
assert same == rows and receipt == item["receipt"] and replay
results.append(
    {
        "name": "original complete payload replay",
        "observed": "identical original receipt and rows",
    }
)
wrong = copy.deepcopy(item["action"])
wrong["truck_on"][0] = 1 - wrong["truck_on"][0]
try:
    append(d, rows, item["event"], wrong, item["request_id"])
    raise AssertionError("accepted conflicting payload")
except BusinessError as e:
    assert e.code == "idempotency_payload_conflict"
    results.append({"name": "conflicting old request ID", "code": e.code})
try:
    append(d, rows, item["event"], item["action"], "new-id-for-completed-week")
    raise AssertionError("accepted completed week under new ID")
except BusinessError as e:
    results.append({"name": "completed week under new ID", "code": e.code})
for label, change in [
    ("boolean quantity", lambda a: a["order_lots"][0].__setitem__(0, True)),
    ("extra coordinate", lambda a: a["production"][0].append(0)),
]:
    a = copy.deepcopy(item["action"])
    change(a)
    try:
        validate_action(d, a, 7)
        raise AssertionError("invalid numeric schema accepted")
    except BusinessError as e:
        assert e.code in ("decision_integer", "decision_shape")
        results.append({"name": label, "code": e.code})
bad = copy.deepcopy(item["action"])
bad["production"][0][0] = 100000
try:
    append(d, rows, event("T00", 8), bad, "invalid-proposal")
    raise AssertionError("invalid physical action accepted")
except BusinessError as e:
    assert e.week == 8 and not any(s["id"] in str(e.detail) for s in d["scenarios"])
    results.append(
        {
            "name": "neutral infeasibility diagnostic",
            "code": e.code,
            "week": e.week,
            "detail": e.detail,
        }
    )

# Valid alternative prefix, not a forged state: actor must reject mixing it with
# its installed policy. Build its complete state independently from original CSVs.
st = initial()
alternate = []
for t in range(8):
    e = event("T00", t)
    a = canonical_action(st, e)
    st, row = advance(st, e, a)
    rid = "alternate-" + str(t)
    alternate.append(
        dict(
            request_id=rid,
            week=t,
            event=e,
            action=a,
            receipt=dict(
                request_id=rid,
                committed_week=t,
                next_week=t + 1,
                cost_minor=row["cost"],
                cash_minor=row["cash"],
            ),
        )
    )
p = dict(
    format="l06-current-operation/1",
    week=8,
    committed=alternate,
    history=[event("T00", t) for t in range(9)],
    post_week_state=st,
    decision_view=view(st, event("T00", 8)),
)
assert packet(d, alternate, event("T00", 8)) == p
argv = [
    sys.executable,
    "-u",
    "-B",
    str(ROOT / "review/source-only/actor/actor.py"),
    "--public",
    str(PUBLIC),
]
r = subprocess.run(
    argv,
    input=json.dumps(p) + "\n",
    text=True,
    encoding="utf-8",
    capture_output=True,
    cwd=ROOT / "review",
)
assert (
    r.returncode != 0 and "committed action differs from installed policy" in r.stderr
)
results.append(
    dict(
        name="valid but different committed policy prefix",
        exit=r.returncode,
        stderr=r.stderr,
    )
)
(ROOT / "review/protocol-probes.json").write_text(json.dumps(results, indent=2) + "\n")
print("All", len(results), "focused protocol and preservation probes passed.")
