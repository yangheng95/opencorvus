"""Defined integrity comparison to independently published immutable catalog bytes.

These values were read from original snapshot 81fe8728 and delivery snapshot
a4802667, not calculated from the worktree as expected values. This proves only
source/publication identity; business correctness is checked separately.
"""

from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
frozen = {
    "public/OPERATIONS.md": "e56275959e09f93d33748a03068fb72d3c78c6f67a3c58e264560754381f3ba0",
    "public/OUTPUTS.md": "cf2626dcdb1d6963894a9c9c135f95ab44e820bfd02546e4261654a7d7c517be",
    "public/TASK.md": "d7830134beef2ee8c7468d10ce8aef105a3d8d05128d4b47dfb62651c0cd7599",
    "public/exercise-tools/qualification/current-source/check_l06.py": "afc5b5857ef2dcddf38115a2db1fff261fe2b7ef68c9add72bce766a3d45915f",
    "public/exercise-tools/qualification/current-source/l06_input.py": "1c15423fac055e4eca175fa1f403b81fc32c038aa639ce30b373fb8737bb491a",
    "public/exercise-tools/qualification/current-source/l06_packet.py": "c935c7321d81676d0da506ebd01c31adb2164fe985ae863f178ba58c1a348b24",
    "public/exercise-tools/qualification/current-source/l06_physics.py": "f9e0ee17170a35096ec3d55efefd2b0252edfedba88e32beb8fc5599ea91a188",
    "public/exercise-tools/upgrade-v0.3/run_native_whole.py": "55532c83df7e93691a14b6bd9ac95fceae48fe3b94717300d2eceff04b1b44a2",
    "public/exercise-tools/upgrade-v0.3/source/check_tree.py": "8d818aaa557fa015026b19acb412b6cac46a78b5ac536f157e8529b12584b4ed",
    "public/exercise-tools/upgrade-v0.3/source/execute_policy.py": "f19795e9c361547700518c9d2bb249e329a7e8c432d64e5a06c83bde523077b8",
    "public/exercise-tools/upgrade-v0.3/source/tree_business.py": "46e9641fde5fff747be1f15b860534b74e511c4ef7c9acdcde9ace0d1baae0b7",
    "public/exercise.py": "5a1ec1a50005b97c44f056b14b1cdaea118272b4bf875e780bd0ec6d7d54c022",
    "public/inputs/bom.csv": "516920625a44974d6b4e0626732cb14495a7b0847fb1d3526fcdbc12fc0191de",
    "public/inputs/demand.csv": "9f2bcf0d6f8c13e4e967ab03a243d8d200859489532abf67a380a437b244ccf6",
    "public/inputs/facility.json": "d78596c2541f8a7d33d243320fb2029c651b2b6cbf109c42908789de66a5992e",
    "public/inputs/plant_capacity.csv": "24854c51025781717a201f3ce31aadb1e7a9deafb43f56d33a97b1368d1c06bd",
    "public/inputs/plants.csv": "20b967b6bca04f317c3eab1f1958f3c89223da98444d8816b9e2f96b42971ff0",
    "public/inputs/products.csv": "01e4bed90603085372d5fa30e8365cc95c1cf411ba942b67f6eaa019b5b00c9c",
    "public/inputs/raw_materials.csv": "dff4fe8921f5fe239b193673562541709bc7f7f58b8d9d3ff24ab0ebaadc90ea",
    "public/inputs/routes.csv": "1a7bf80473018057ac5ff3685e21d1ad16f13b9a465468e4b8cad1958aca0483",
    "public/inputs/scenarios.csv": "6e2f98d036ed84a09f115c046f5d45adcc64e0a7c7a61aac4db74c8cef3fad14",
    "public/inputs/supplier_capacity.csv": "fea4e99ae341eb97b8d89f3a928abe18bf4be2134592b06a4c3cbab7e4ff05dd",
    "public/inputs/supplier_quotes.csv": "6ff7d7adb4af092f837f9d4f177936e9b16713ffa3ab3abd0d018dedccdd26d4",
    "public/inputs/supplier_terms.csv": "52edd332ead85ae7c73c66de95991ba942c18905dd3ea9e43d44afde44dbe026",
    "public/tree-contract.json": "49bde161c95feaae3b62bb11cadf267cfb4cc30154674cb202504ae40d33b3b1",
}
published = {
    "HANDOFF.md": "b08e422cd3f3f5de0f722d1922dc40e96d54ab1e77784d209a536b01c908d442",
    "REPORT.md": "d2ae8e85d0dcaea14d7d5ea592d40350f3b2a2fd50393590a156f3c7b4afec82",
    "REPORT.pdf": "1b24835cdb94b59675f9af88fbeec94e12b1e44b9758e905c9406cd2d4d8c152",
    "actor/actor.py": "7c59a1ded56e50571e56282074c852c988fe28cfbf521b26f3812db4fd48878f",
    "actor/policy.json": "e005b1b7d19536dd22d907264fb125640ea0a31a6368e5d9c3242b1d921ab99e",
    "actor/submission.json": "bbd2eb8bb37cda01d185676c716a0de7c64e51ec8e452b2330aebbbc7c1c62df",
    "delivery-source.zip": "df24adc0c9df904ed00682d520a398b3e1b3a8ffc0ae708cd37f48b58bc50a8a",
    "diagnostic-evidence.zip": "2038b1fe21e5280f69d13b5f9a7a8f5c890dd3124bb239217de0d07733ad59ea",
    "figures/cash-and-storage.png": "ac80484f41354742238d2921277643c6a63ed53cc10e79df5632edcd8bc0c209",
    "figures/cost-comparison.png": "6d495afaaf6eb3762d5a1b02d34297625b5c1f8fd8cae10f9ac3b828fac2c1dd",
    "policy.json": "e005b1b7d19536dd22d907264fb125640ea0a31a6368e5d9c3242b1d921ab99e",
    "requirements-lock.txt": "b78e834cfedc68f997a31615b1f69d6339f2a8552de29ddb67a12804285bb5b4",
    "requirements.txt": "9451f82376c77985397508aab7c00399bec390c5a520f95efb40e315575818fc",
    "results/canonical-alternative.json": "a8269865d832d5536cc6e82ded710a10ffff6ba7b5405c4278eaf16b47110f84",
    "results/canonical-audit.json": "e2a3559ae601c3fb22140256d2e62f5b56b07c3f1355d74e38f9c049a27890c2",
    "results/commitment-policy.csv": "a6d4e457d0438ffc467500e5c0df4470ba4b51810b7e16b5175ea0bd6e212e40",
    "results/information-relaxation.json": "78eaad6c01dc2958f4ba89a059a1771425ad68fc589fdaf23b2b5b84c6ebd262",
    "results/negative-packet-diagnostic.json": "063491d8af748434b3f184b73207721166318a83be05e89ebacbbb576cf8be94",
    "results/optimization.json": "da3f768e7fee9ea9f0ec99c910b635d57a41992761aa424cd676ce99843faade",
    "results/policy-audit.json": "5f52f8c5a23e3c1dd8f95c0ffcf4bc52bfa25f66746214cc29ce2059e12a771e",
    "results/receivables.json": "522dbce470a0d1d3eb3d80fdc0806daffbb1c542d31e8b5bcfae64b743d1b0b5",
    "results/self-check.json": "243bb1df7f57858810585c05d3498edda921b39b1f45b689251660de202ac3ec",
    "results/source-map.json": "7b31e0cf9fbeb4363163e952f7143d2b6d27b2c9c44f957c2f542c75918eb1a0",
    "results/summary.json": "0491a1ad24f7dd79f32c0409c6a9b1c853ee75eb5330782295c8d26df8f9cbca",
    "results/weekly-ledger.csv": "e464a7cd184e9cd899b37c2bc325c39852d171db30b5c2f108b8e1fa635fe57b",
    "tools/common.py": "a31ea518aa221606c58ec9040562223ad4f93ac328b06f8c45395f3f584006bc",
    "tools/deliver.py": "5d49b135cac9e131f373818d8e6efbd0a2e2d7953d373eef2ad82f36a347d8c0",
    "tools/package.py": "260f2a4a1c049c64e35bb316b3ce5f4fa1f0781dbd7e5a1cc7d6a639dd555fc9",
    "tools/solve.py": "e1de341cefd1de168175f80e92f110e015b2d44dbf504a16c3b6ce1e03a0bc31",
    "tools/test_actor.py": "cefd6bb0e4659515ee7d8ca3ec1e305679832fb911efd5ef2bd121743e82dfba",
    "tools/verify.py": "3d899af754648c5b5e6d34d212b03be2510db2c914915c3df7279247719eb3b7",
}
results = []
for role, ref in [
    ("original_snapshot", frozen),
    ("published_delivery_snapshot", published),
]:
    for path, expected in ref.items():
        actual = hashlib.sha256((ROOT / path).read_bytes()).hexdigest()
        results.append(dict(path=path, reference=role, equal=actual == expected))
assert all(r["equal"] for r in results), [r for r in results if not r["equal"]]
(ROOT / "review/identity-check.json").write_text(
    json.dumps(
        {
            "scope": "Exact immutable catalog byte identity only; not product correctness",
            "original_snapshot": "81fe8728-1f2a-5a66-a97f-687e4652237c",
            "delivery_snapshot": "a4802667-20a2-5a0d-a80d-c46b3ac83e77",
            "checks": results,
        },
        indent=2,
    )
    + "\n"
)
print(
    "Original 25 files and all 31 published delivery resources match immutable references."
)
