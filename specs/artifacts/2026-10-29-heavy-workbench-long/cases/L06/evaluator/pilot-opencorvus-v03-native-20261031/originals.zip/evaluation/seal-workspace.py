from pathlib import Path
import datetime,json,os,subprocess,zipfile
root=Path('D:/opencorvus-benchmark-runs/l06-v03-opencorvus-native-20261031'); out=root/'evaluation'; project=root/'project'
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
commands={}
for name,args in {'status':['git','status','--porcelain=v1','--untracked-files=all'],'history':['git','log','--format=%H %s'],'diff':['git','diff','--binary'],'head':['git','rev-parse','HEAD']}.items():
 r=subprocess.run(args,cwd=project,capture_output=True)
 (out/f'git-{name}.txt').write_bytes(r.stdout)
 commands[name]={'argv':args,'native_exit':r.returncode,'stderr':r.stderr.decode('utf-8',errors='replace')}
files=sorted(p for p in project.rglob('*') if p.is_file())
(out/'handover-observed.json').write_text(json.dumps({'at':now(),'task_id':'tsk_g00VZbZlio005blDCIl3','task_lifecycle':'completed','status_source':str(root/'observations/20261031T0701Z-task-status.json'),'inspect_launcher_5804_observed_terminal':True,'project_child_processes_observed':0,'workspace_files':len(files),'workspace_bytes':sum(p.stat().st_size for p in files),'git':commands,'score':None,'scope':'all original workspace/Git/untracked/dependencies/caches and genuine failures first; no programme/report edits'},indent=2)+'\n',encoding='utf-8')
(out/'workspace-seal-started.json').write_text(json.dumps({'at':now(),'pid':os.getpid(),'scope':'complete natural-handover project plus original Inspect/launch/observations; runtime home/auth/models excluded'},indent=2)+'\n',encoding='utf-8')
index=[]
with zipfile.ZipFile(out/'complete-workspace.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in files:
  n=p.relative_to(root).as_posix(); z.write(p,n); index.append({'member':n,'bytes':p.stat().st_size})
 for folder in ['inspect-logs','observations','launch']:
  for p in sorted((root/folder).rglob('*')):
   if p.is_file():
    n=p.relative_to(root).as_posix(); z.write(p,n); index.append({'member':n,'bytes':p.stat().st_size})
 for n in ['registration.json','candidate-request.txt','dataset.jsonl','inspect-launch.json']:
  z.write(root/n,n); index.append({'member':n,'bytes':(root/n).stat().st_size})
 for p in sorted(out.glob('git-*.txt')):
  z.write(p,'handover/'+p.name); index.append({'member':'handover/'+p.name,'bytes':p.stat().st_size})
receipt={'at':now(),'pid':os.getpid(),'native_exit':0,'archive_bytes':(out/'complete-workspace.zip').stat().st_size,'member_count':len(index),'workspace_files':len(files),'all_workspace_files_preserved':True,'members':index,'excluded':'only separate runtime service home with staged credentials; not candidate workspace'}
(out/'workspace-seal-terminal.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in receipt.items() if k!='members'}))
