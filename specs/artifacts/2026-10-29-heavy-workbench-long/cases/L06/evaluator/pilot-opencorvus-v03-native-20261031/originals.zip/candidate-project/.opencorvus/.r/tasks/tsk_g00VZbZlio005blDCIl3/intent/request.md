---
taskID: tsk_g00VZbZlio005blDCIl3
projectID: prj_hx56kGOHRtX7KfQuM1vm
source: inspect-ai
createdAt: 2026-10-31T06:13:21.582Z
---

# Task request

Complete the frozen staged-factory task in public/TASK.md, OPERATIONS.md, OUTPUTS.md, tree-contract.json and all raw tables under public/. Those25 files are the complete problem inputs. Historical draft labels in those frozen files do not relax the stated contract. Implement a complete causal purchasing/production policy, current-observation actor/submission.json, actual end-to-end public exercise and durable receipt recovery, exact ledgers/financial deliverables, meaningful report/actual figures and self-contained reproduction/operational handoff. Any correct language/method/representation is allowed. Work until the complete task is delivered; preserve true failures and limitations.

Use only this project, the provided public inputs, standard runtime/documentation and declared dependencies. Do not read other benchmark/project directories, evaluator/rubric/weights, author references, previous candidate answers or credentials. Treat public as read-only. Native Windows only; no Docker/WSL or user-process/service/window actions and no UI automation. Available base runtimes include C:/Python314/python.exe and C:/Users/hengu/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe (Python3.12). If dependencies are needed, create an environment/cache inside this project; never modify global or other-task environments. Use the real public exercise with your own executable programme and policy. Actual scientific PNGs must be viewed, not merely generated.

There is no user total token/wall-clock limit or minimum duration. Do not sleep, repeat work or deliberately slow algorithms to create hours. Do not stop at a plan or component qualification. Do not score yourself or claim unverified real-world approvals. Your complete workspace/Git/untracked/failed attempts/dependencies will be preserved after natural handover, then independently executed and reviewed. Keep exact source/output paths and reproducible commands in the handover. Self reports are not the independent assessment.
