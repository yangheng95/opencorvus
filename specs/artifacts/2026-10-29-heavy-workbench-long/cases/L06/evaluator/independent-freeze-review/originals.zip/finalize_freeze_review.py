"""Record the final scoped approval; never change or freeze the repository here."""
from datetime import datetime,timezone
import json
from pathlib import Path
import subprocess
from review_final_contract import ROOT,CASE,REPO,save,load

def main():
    checks=load(ROOT/'contract-checks.json');case=ROOT/'case-snapshot'
    unchanged=[]
    for p in (case/'public').rglob('*'):
        if p.is_file():unchanged.append({'file':str(p.relative_to(case)).replace('\\','/'),'same_bytes_at_final_review':p.read_bytes()==(CASE/p.relative_to(case)).read_bytes()})
    for name in ('rubric.json','evaluator/GRADING.md','evaluator/FREEZE.json'):
        unchanged.append({'file':name,'same_bytes_at_final_review':(case/name).read_bytes()==(CASE/name).read_bytes()})
    if not all(r['same_bytes_at_final_review'] for r in unchanged):raise RuntimeError('reviewed contract changed; inspect the exact semantic diff before approval')
    save(ROOT/'reviewed-contract-identity.json',{'scope':'Actual exact reviewed object/version identity only; all functional correctness evidence is separate. No source-hash functional gate.','files':unchanged})
    official={'checked_sources':[{'url':'https://raw.githubusercontent.com/scipy/scipy/v1.15.3/pyproject.toml','fact':'Pinned1.15.3 runtime requirement NumPy>=1.23.5,<2.5; actual2.4.6 is within this declaration.'},{'url':'https://raw.githubusercontent.com/google/or-tools/v9.15/ortools/sat/sat_parameters.proto','fact':'Pinnedv9.15 defines relative gap using the primal objective denominator; reaching a nonzero requested gap can report OPTIMAL. Its solver-native gap is distinct from the benchmark fixed-L gap.'}],'method':'Official primary sources read for the two public ENVIRONMENT links; existing image/runtime qualifications remain the execution evidence.'}
    save(ROOT/'official-source-checks.json',official)
    audit_rows=[
      ('candidate_materials','pass','Exact18-file public whitelist;6contract/provenance/environment/profile files plus11CSV/facility. Separate private rubric/evaluator/reference/calibration. Task states allowed sources and no outside answers.'),
      ('raw_and_identity','pass','Independent raw projection equals registered archived base business facts. Explicit indices and complete joint keys define identity; line reorder does not change it.'),
      ('business_and_reachability','pass','Physical-stage storage, shared supplier/plant capacities, packing/MOQ/leads/BOM, nonanticipativity and delayed cash contract agree with one business recurrence and independent actual1488/1096 model/925prefix checks.'),
      ('fixed_reference','pass_scoped','UniqueL47380 under declared trusted-native search-bound policy, not rational dual/search proof. Exactbase registration and monotone positive-price control checked; feasible1% witnesses and actual same-source control completed.'),
      ('rubric','pass','47unique leaves/100weight;28critical(weight69),D01/D02critical;12specific human half anchors. Current numeric30+private execution/review17 exactly cover all47.'),
      ('failure_and_dependencies','pass','Finite exact money/domain controls, multiple semantic residuals, blocked derived finance/quality, candidate missing0 versus evaluator unassessed/no-score and run_invalid distinguished. Reference drift or feasible cost<L cannot receive a score.'),
      ('aggregation_and_publication','pass','Fixed100;critical failure cannot be offset;90author threshold. Current3canonical CLIs pass and remain score/success/good null. Only final audit readiness and frozen status currently prevent publication.'),
      ('actual_reference_and_controls','pass','Complete raw-only baseline and independent CSV-row cold run, plussame9source numerical price control. Actualprogram/source/input/terminal/model/business/report/3renderedfigures checked; no policy-trajectory matching.'),
      ('review_semantics','pass_scoped','All-material/action-format equivalence, closed cash/component/whole arithmetic, explicit factual taxonomy and explanatory completeness adjudicated. Original36/new8/four corrections preserved; all specified semantic disputes closed.'),
      ('rater_trust','pass_declared_boundary','Private evaluator identity/assignment/artifact-binding/evidence kinds structurally checked; actual trusted independent judgement remains necessary. File existence or a role string is not proof of truth/authentication.'),
      ('dependency_environment','pass_local','Exact existing imageID matches completedruns;27-layer history and fourrecipes show task-era additions limited to package/venv/import setup. Task source/data/answers came from external readonly mounts. Concrete usable command provided; other correct methods/languages allowed.'),
      ('scope_and_next_stage','pass','Approval only for this executableL06/0.2.0development contract. Freshnative/Codex/candidate source-only evaluation/useful time and remainingnine belong after freeze, not circular prerequisites.')]
    save(ROOT/'audit-matrix.json',[{'area':a,'decision':v,'basis':b} for a,v,b in audit_rows])
    stage={'decision':'APPROVE_L06_0_2_0_DEVELOPMENT_CASE_FREEZE','approved_to_freeze_for_fresh_development_OpenCorvus_Codex_pilots':True,'case_version':'L06/0.2.0','benchmark_scope':'HeavyWorkBench-Long/0.2.0-dev remains under development','substantive_blockers':[],'unresolved_review_semantic_items':[],'current_repository_state_frozen':False,'current_state':'pending_final_independent_audit/draft_not_frozen','approval_utc':datetime.now(timezone.utc).isoformat(),'canonical_public_file_count':18,'criterion_count':47,'weight_sum':100,'critical_count':28,'critical_weight':69,'fixed_L':47380,'maximum_relative_gap':.01,'good_score_at_least':90,'actual_canonical_cli_commands':3,'canonical_base_numeric_pass':30,'canonical_price_numeric_pass':30,'complete_draft_reference':{'verified_pass':45,'verified_partial':2,'unassessed':0,'total_score':None,'business_success':None,'good':None},'allowed_author_transition':'Only already reviewed status/title/readiness closure and README/index updates, then real complete-grade positive/doc checks and scoped commit/push. Keep publicbusinessfacts/semantics/weights/critical/threshold/L/controls unchanged.','state_consistency_notes':['Close fulfilled development pending-readiness wording without claiming professional calibration.','The registration retains the earlier suite-dev case_version provenance label; currentcase identity is unambiguouslyL06/0.2.0inFREEZE/profile/rubric plus exact registered semantic input. Preserve original registration evidence and clarify label provenance rather than silently rewriting historical receipts.'],'new_solver_Docker_Provider_GPU_UI_runs':0,'delegations':0,'repo_modified_by_reviewer':False,'approval_includes_runtime_security_qualification':False,'approval_includes_ten_cases_complete':False,'approval_includes_hours_difficulty':False,'approval_includes_professional_human_or_statistical_certification':False,'approval_includes_same_model_causal_ranking':False,'future_pilot_or_hours_are_current_freeze_preconditions':False}
    save(ROOT/'stage-assessment.json',stage)
    (ROOT/'REVIEW.md').write_text('''# L06/0.2.0 最终独立case冻结审查

**结论：批准将所审L06/0.2.0可执行合同冻结，用于fresh development OpenCorvus/Codex pilot。没有剩余实质阻断或本轮未裁决语义项。** 当前仓库仍是pending/draft；本审查没有替主方改文件、提前发布分数或执行冻结。批准仅覆盖本case开发合同，不是十题完成、小时级难度、专业人类/统计成熟或同模型因果排名认证。

## 所审准确对象

当前唯一CASE路径下rubric.json、public/{TASK,OUTPUTS,DATA,ENVIRONMENT,SOURCE}.md、profile.json和全部raw，以及evaluator/GRADING.md、evaluator/FREEZE.json、current-source规范入口与唯一参考注册。FREEZE位于evaluator/，不是case根。case-snapshot/保存最后实审版本并与当前对象逐文件核对。期间ENV仅将过时“尚无候选”句改为每次真实注册及无难度推断，已检查并保留前后文本；没有业务或评分语义变化。对象身份与功能正确性证据分开，没有用源码摘要当行为验收。

候选只得到public/的18个明确文件：六份合同/环境/来源/profile加11CSV/facility。没有参考计划、源实现、rubric、私有控制值、评级或key。公开文本准确说明身份/index/单位、共同4周/揭示、周内阶段容量、采购包装/最低量/共享供应容量、BOM/产线工时、下单支付/4周滞后/应收和终期条件。任意正确算法/语言、可执行基线/另一真实策略均可，既不强迫CP-SAT，也不匹配参考动作或强迫翻转；未强制字数、页数、运行时长或token/墙钟上限。规范账/汇总/状态和路径ABI给定，实际公式与所有已交格式按语义评价。

## 输入、参考与真实可达证据

独立raw投影与注册原始ZIP业务事实全同，CSV物理行序不构成身份。唯一L仍47380，1%按(C−L)/L计算。该界来自已独立核对同一1488变量/1096行整数模型及原生终态的成熟工具信任，不冒称独立有理dual/search证明。

正向单因素报价控制只改C/R0每件45→46。非负采购使固定动作成本不减/每周现金不增，其他业务约束相同，因此新可行集是旧集子集，原L有效。独立曾检查完整48周前缀、控制可达计划47763.6及原注册绑定/未知变化/漂移错误；原失败和修复均保留。

真实交付链也已闭合：主基例47746.2、独立真实11CSV反转复建47737.6以及同9源码报价执行47773.3都不是只读旧答案的新目录伪运行。独立从raw核模型/实际三策略/全账和925前缀，实际打开所引用的全部三图。报价运行固定L的差距约0.83010%，独立行序运行约0.75475%，没有要求相同动作。可行见证、源码实际执行、业务质量和Task生命周期是分别核查的结论。

## 47叶、错误与评分规则

47唯一叶/权重100，28关键叶共69分，D01与D02都关键。数值30叶复用一个严格业务递推，17执行/审查叶由候选外私有评估判断补齐；12人评叶才有具体half锚点。完整计划的实际物理/资金/质量由评估者重算，候选normalized/库存声明/summary不能替代权威事实。坏schema/缺交0与真实物理违例分开；依赖阻断不伪称已算通过；评估/参考故障run_invalid、缺评unassessed均不发总分、不删分母。可行成本低于L会抛参考矛盾而非负gap满分。

固定100、总分至少90加全部critical通过是预先声明作者规则。D02失败虽可96分仍不能判好；missing evaluator ratings不当作候选0分。真正完成且冻结/前置资格闭合才发布成绩，非关键叶不足允许按规则扣分，不能看见候选结果后再新增硬项。私有review校验路径、身份、证据类别及锚点，只能做结构约束；可信委托来源和实际源码/执行/业务/视觉判断仍由主评估者负责，角色字符串、文件存在、schema通过不证明真或认证身份。

本次仅补三条必要规范路径CLI（无新优化）：基例和实际报价控制各30numeric pass/17unassessed；既有完整私有参考评级45pass/2partial/0unassessed，exit0/draft_assessment_complete。总分、business_success、good均null，publication_blockers恰为rubric_not_frozen和最终独立审查readiness。旧15协议仅读取既有6.497秒原收据及源码，没有再跑；它们的all-full是显式synthetic代数夹具，不是参考或候选100分。

## 人评公平性与校准边界

逐条审了初36、格式控制8以及四项追加改判的归档；封存之后才获授权读取作者key，确认原始初评与原文件逐对象同值、原标签比较36/36和8/8，四裁决亦完整保留。特别保留“初一致仍共享了CSV/展示偏差”：旧packet97的F01/F02与E04/E05由half改full，不回写原key/原half以维持一致率。

四组来源、E03必要解释组合、现金公式/字段闭合、费用分量与整体的精确关系及动作链、所有已交JSON/文字/表的行动可定位性均已明确。错误动作或错误结论仍0，只有原始数据待另建分析并不自动full；私有oracle不能补候选漏交。这些语义的实际等价/缺信息控制已检查，没有剩余本轮语义争议。F05独立根据真实未编辑源码/原材料/README冷复建卡判断，E01有真实首incumbent事件及first-plan来源，不把受控编辑报告声称为新源码输出。

但这是三相关组件包和两聚焦控制、一位熟悉参考的AI独立审查者；不是五个候选，也不是职业专家、真人双盲或统计可靠性证书。top-level review_calibration=true只能指这项明确限定的开发组件资格，不能据高一致率给整个benchmark贴成熟标签。

## 依赖、候选材料与下一执行阶段

现有27层image history、四份构建recipe及真实冷跑terminal imageID交叉一致：任务时期增加的是pip/venv/import依赖层，题目源码/输入/答案通过各次外部readonly挂载提供，并未COPY进依赖镜像。public ENVIRONMENT给出实际可用imageID、/opt/cpsat/bin/python与自有项目挂载命令；没有要求在容器中再访问Docker，也允许其他可准备的正确方法。没有完整传递依赖lock或跨主机性能保证的夸大。

两个公开技术链接亦核对官方固定源码：[SciPy1.15.3依赖](https://raw.githubusercontent.com/scipy/scipy/v1.15.3/pyproject.toml)支持其声明NumPy范围；[OR-Tools v9.15参数](https://raw.githubusercontent.com/google/or-tools/v9.15/ortools/sat/sat_parameters.proto)说明native非零gap可报告OPTIMAL，和本题固定L质量口径分开。历史highspy库存在于依赖祖先层，不等于当前参考有另一执行后端；current-source整数实现仍唯一CP-SAT。

正式pilot须只给public新项目，以准确版本/源码身份/输入/权限/运行环境/模型实际绑定和原始事件注册；原始reference、控制、评级与key维持评估侧。独立重建只带候选源码/声明依赖/冻结raw与新输出，实际核其策略、控制、业务说明与图形。原生Task完成不等于业务得分；参考程序7/21/11分钟壁钟也不等于LLM有效小时。运行/队列/准备/暂停/工具/请求活动和重叠须如实区分，未观测空档仍未知。没有控制模型/运行环境就不得作因果排名。

## 批准的状态转换与明确边界

允许主方只把已审状态/标题/最终审查readiness切换到frozen，更新README/索引，关闭已经达成的开发pending措辞，然后对真实完整参考做一次规范grade正向与文档检查、范围commit/push。原始业务数据、47叶/权重/critical、控制、L47380、1%和90比较规则不得借此改变；语义改变须另审。保留过去的原始运行/源/错误/评级历史，不增加旧.draft路径fallback。

两个非阻断来源说明应在状态收敛中清楚保留：人评多质量“pending”若指职业范围，不应与已关闭的开发组件资格混写；注册case_version沿用早期suite-dev来源标签，而当前case版本由rubric/profile/FREEZE与精确业务身份确定，应明确其历史来源，不静默篡改原收据。它们不改变参考有效性或打分。

case冻结是后续fresh development pilot的输入，不需要先有未来pilot成绩或小时结果；不能形成循环前置。那些后续结果及其余九题升级仍未完成，不能以本次case批准冒充十题/小时级或专业成熟。此审查不批准应用发布、正式排行榜或生产runtime安全/隔离认证。

证据主索引：contract-checks.json、audit-matrix.json、reviewed-contract-identity.json、case-snapshot/、current-source/、三原CLI commands/、dependency-evidence/、official-source-checks.json、calibration-summary/post-seal-independent-archive-check.json、existing-grading-qualification/。本轮只写此外部目录，repo未改，无solver/Docker/Provider/GPU/UI或再次委托。
''',encoding='utf-8')
    git=subprocess.run(['git','status','--short','--','specs/artifacts/2026-10-29-heavy-workbench-long/cases/L06','specs/records/2026-10/2026-10-29-heavy-workbench-l06-qualification.md'],cwd=REPO,capture_output=True,text=True,encoding='utf-8');(ROOT/'git-status-end.txt').write_text(git.stdout,encoding='utf-8')
    print(json.dumps({'review':str(ROOT/'REVIEW.md'),'decision':stage['decision'],'substantive_blockers':[],'current_repo_already_frozen':False,'approved_scope':'L06/0.2.0development executable contract only','new_full_solver_or_Docker_runs':0,'ten_cases_or_hours_or_professional_maturity_approved':False},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
