"""Final development-case contract audit and three cheap canonical CLIs."""
from datetime import datetime,timezone
from fractions import Fraction
import ast,csv,importlib.util,json,re
from pathlib import Path
import shutil,subprocess,sys,time,zipfile
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
REPO=Path('D:/myhexin-local/opencorvus')
CASE=REPO/'specs/artifacts/2026-10-29-heavy-workbench-long/cases/L06'
ROW=Path('D:/opencorvus-benchmark-runs/l06-reference-independent-review-20261029/full-cold-replay')
PRICE=Path('D:/opencorvus-benchmark-runs/l06-price-source-independent-review-20261029')
GRADE=Path('D:/opencorvus-benchmark-runs/l06-grading-independent-review-20261029')
REL='evaluator/qualification/v2/integer-search/quality-reference/registered-reference.json'
PYTHON='C:/Python314/python.exe'
def load(path):return json.loads(path.read_text(encoding='utf-8'))
def save(path,x):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def command(argv,label):
    folder=ROOT/'commands'/label;folder.mkdir(parents=True,exist_ok=False);stamp=datetime.now(timezone.utc).isoformat();t=time.perf_counter();p=subprocess.run(argv,capture_output=True,text=True,encoding='utf-8')
    (folder/'stdout.txt').write_text(p.stdout,encoding='utf-8');(folder/'stderr.txt').write_text(p.stderr,encoding='utf-8');r={'argv':argv,'started_utc':stamp,'seconds':time.perf_counter()-t,'exit_code':p.returncode};save(folder/'command.json',r);return r

def main():
    (ROOT/'Recall.md').write_text('''# Recall\n\n仅最后独立L06/0.2.0开发case冻结合同审查；只写本目录、不改repo、不再委托，不运行solver/Docker/Provider/GPU/UI。核对准确public/权威raw/唯一注册/47叶/100/critical/依赖/设施/half/格式公平/发布合同和已验真实原件。仅3次必要canonical numeric/grade读取既有完成输出，不再跑15协议或优化。未来fresh候选、活动时长与其余九题是冻结后实证，不作为本轮循环前置；本轮不认证十题/小时级/专业人类或同模型因果排名。\n''',encoding='utf-8')
    git=subprocess.run(['git','status','--short','--','specs/artifacts/2026-10-29-heavy-workbench-long/cases/L06','specs/records/2026-10/2026-10-29-heavy-workbench-l06-qualification.md'],cwd=REPO,capture_output=True,text=True,encoding='utf-8');(ROOT/'git-status-start.txt').write_text(git.stdout,encoding='utf-8')
    snapshot=ROOT/'case-snapshot';snapshot.mkdir(exist_ok=False);shutil.copytree(CASE/'public',snapshot/'public');shutil.copy2(CASE/'rubric.json',snapshot/'rubric.json');(snapshot/'evaluator').mkdir();shutil.copy2(CASE/'evaluator/GRADING.md',snapshot/'evaluator/GRADING.md');shutil.copy2(CASE/'evaluator/FREEZE.json',snapshot/'evaluator/FREEZE.json')
    for n in ('registered-reference.json','originals.zip','price-control.zip'):(snapshot/REL).parent.mkdir(parents=True,exist_ok=True);shutil.copy2((CASE/REL).parent/n,(snapshot/REL).parent/n)
    source=ROOT/'current-source';source.mkdir()
    for n in ('l06_grade.py','l06_numeric.py','qualify_numeric.py','qualify_grading.py','l06_input.py','l06_delivery.py','l06_packet.py','check_l06.py'):
        shutil.copy2(CASE/'evaluator/qualification/current-source'/n,source/n);ast.parse((source/n).read_text(encoding='utf-8'))
    rubric=load(snapshot/'rubric.json');criteria=[c for g in rubric['groups'] for c in g['criteria']];freeze=load(snapshot/'evaluator/FREEZE.json');profile=load(snapshot/'public/profile.json');ref=load(snapshot/REL)
    files=sorted(str(p.relative_to(snapshot)).replace('\\','/') for p in (snapshot/'public').rglob('*') if p.is_file())
    assert files==sorted(freeze['public_files']) and len(files)==18
    assert len(criteria)==len({c['id'] for c in criteria})==47 and sum(Fraction(c['weight']) for c in criteria)==100
    assert next(c for c in criteria if c['id']=='D02')['critical'] is True and next(c for c in criteria if c['id']=='D02')['weight']==4
    assert rubric['quality_reference']['maximum_relative_gap']==.01 and rubric['publication']['good_score_at_least']==profile['comparison_policy']['good_score_at_least']==90
    assert profile['budget']=={'total_model_tokens':None,'total_wall_seconds':None} and profile['minimum_runtime_seconds'] is None
    assert rubric['status']!='frozen' and freeze['status']==profile['status']=='pending_final_independent_audit' and rubric['readiness']['independent_full_case_freeze'] is False
    required=rubric['publication']['requires_readiness'];assert [k for k in required if not rubric['readiness'][k]]==['independent_full_case_freeze']
    assert ref['lower_bound_minor']=={'numerator':47380,'denominator':1} and ref['derived_variants'][0]['transformation']=={'kind':'monotone_supplier_price_increase','supplier_id':'C','raw_id':'R0','delta_minor':1}
    links=[]
    for name in ('TASK.md','OUTPUTS.md','DATA.md','ENVIRONMENT.md','SOURCE.md'):
        text=(snapshot/'public'/name).read_text(encoding='utf-8')
        for label,target in re.findall(r'\[([^\]]+)\]\(([^)]+)\)',text):
            if target.startswith(('http://','https://')):links.append({'source':name,'target':target,'external':True});continue
            path=(snapshot/'public'/target.split('#')[0]).resolve();links.append({'source':name,'target':target,'exists':path.exists(),'inside_candidate_public':path.is_relative_to((snapshot/'public').resolve())})
    assert all(r.get('external') or r['exists'] and r['inside_candidate_public'] for r in links)
    tools=ROOT/'audit-tools';tools.mkdir();shutil.copy2(ROW/'audit-tools/independent_projection.py',tools/'independent_projection.py');independent=module('freeze_raw_projection',tools/'independent_projection.py');data,counts=independent.independent_projection(snapshot/'public/inputs')
    with zipfile.ZipFile((snapshot/REL).parent/'originals.zip') as archive:captured=json.loads(archive.read('input/full.json'))
    captured={k:v for k,v in captured.items() if k not in ('status','qualification_variant')};assert data==captured
    with zipfile.ZipFile((snapshot/REL).parent/'price-control.zip') as archive:control=json.loads(archive.read('normalized.json'));proof=json.loads(archive.read('monotone-proof.json'))
    control={k:v for k,v in control.items() if k not in ('status','qualification_variant')};expected=json.loads(json.dumps(data));expected['suppliers'][2]['price_minor'][0]+=1;assert control==expected
    # Dependencies are only read as existing recipes/history, not Docker calls.
    dep=ROOT/'dependency-evidence';dep.mkdir()
    recipes=[(Path('D:/opencorvus-benchmark-runs/l06-reference-chain-20261029/Dockerfile'),'Dockerfile.reference'),(Path('D:/opencorvus-benchmark-runs/l06-procurement-qualification-20261029/v2/root-node-diagnostic-20261029/Dockerfile.cpsat'),'Dockerfile.cpsat'),(Path('D:/opencorvus-benchmark-runs/l06-procurement-qualification-20261029/v2/root-node-diagnostic-20261029/Dockerfile.highspy'),'Dockerfile.operations'),(REPO/'specs/artifacts/2026-10-29-heavy-workbench-long/evaluator/qualification/Dockerfile.science','Dockerfile.science'),(Path('D:/opencorvus-benchmark-runs/l06-reference-chain-20261029/dependency-image-history.json'),'dependency-image-history.json')]
    for original,n in recipes:shutil.copy2(original,dep/n)
    history=load(dep/'dependency-image-history.json');image=history['layers'][0]['ID'];assert history['exit_code']==0 and image==load(ROW/'terminal-inspect.json')['Image']==load(PRICE/'terminal-inspect.json')['Image']
    # Exact current-path smoke, reading already independently validated output.
    def numeric(label,input,delivery):
        output=ROOT/'commands'/label/'result.json';argv=[PYTHON,'-X','utf8','-B',str(source/'l06_numeric.py'),'--case-root',str(snapshot),'--input',str(input)]
        for n in ('normalized','plan','summary','ledger'):argv+=['--'+n,str(delivery/(n+'.json'))]
        argv+=['--out',str(output)];r=command(argv,label);value=load(output);assert r['exit_code']==0 and value['counts']['verified_pass']==30 and value['counts']['unassessed']==17 and value['total_score'] is None;return value
    base=numeric('canonical-base',ROW/'input',ROW/'results/delivery');price=numeric('canonical-price',PRICE/'input',PRICE/'results/delivery')
    review=load(GRADE/'actual-review-with-price-source.json');output=ROOT/'commands/canonical-complete-grade/result.json';argv=[PYTHON,'-X','utf8','-B',str(source/'l06_grade.py'),'--case-root',str(snapshot),'--delivery-root',str(ROW/'results/delivery'),'--submission-id',review['submission_id']]
    for key,path in review['artifact_bindings'].items():argv+=['--'+key,path]
    argv+=['--review',str(GRADE/'actual-review-with-price-source.json'),'--evidence-root',str(GRADE),'--out',str(output)];r=command(argv,'canonical-complete-grade');grade=load(output)
    assert r['exit_code']==0 and grade['status']=='draft_assessment_complete' and grade['counts']=={'verified_pass':45,'verified_partial':2,'verified_fail':0,'candidate_incomplete':0,'blocked_candidate':0,'unassessed':0} and grade['total_score'] is None and grade['business_success'] is None and grade['good'] is None
    assert grade['publication_blockers']==['rubric_not_frozen','readiness:independent_full_case_freeze']
    # Current criteria anchors must cover each declared required delivery,
    # with review evidence trusted/actual rather than candidate self-report.
    save(ROOT/'contract-checks.json',{'public_files':files,'public_local_links':links,'case_version':profile['case_version'],'benchmark':profile['benchmark'],'row_counts':counts,'all_raw_business_facts_equal_archived_registration':True,'control_exact_positive_single_price_change':True,'monotone_proof_captured':proof,'criterion_count':47,'weight_sum':100,'critical_count':sum(c['critical'] for c in criteria),'critical_weight':sum(c['weight'] for c in criteria if c['critical']),'half_anchors':[c['id'] for c in criteria if 'half' in c['anchors']],'only_pending_publication_readiness':'independent_full_case_freeze','image_ID_matches_actual_base_and_price_execution':image,'canonical_cli':{'base':base['counts'],'price':price['counts'],'complete_grade':grade['counts'],'current_publication_blockers':grade['publication_blockers']},'future_pilot_hours_nine_cases_are_freeze_preconditions':False,'candidate_total_score':None,'solver_Docker_Provider_GPU_UI_runs':0,'delegations':0})
    calibration=ROOT/'calibration-summary';calibration.mkdir();shutil.copy2(CASE/'evaluator/review-calibration/FINAL-CALIBRATION-SUMMARY.json',calibration/'FINAL-CALIBRATION-SUMMARY.json');shutil.copy2(CASE/'evaluator/review-calibration/README.md',calibration/'README.md')
    calibration_summary=load(calibration/'FINAL-CALIBRATION-SUMMARY.json');assert calibration_summary['shared_bias_detected_despite_initial_agreement'] is True and calibration_summary['specified_disputes_resolved'] is True and calibration_summary['professional_certification'] is False and calibration_summary['benchmark_maturity_achieved'] is False
    # Archive qualifications' names only. Key examination is now authorized
    # after all independent initial ratings were sealed; no author script runs.
    with zipfile.ZipFile(CASE/'evaluator/review-calibration/originals.zip') as archive:save(calibration/'archive-members.json',archive.namelist())
    print(json.dumps({'canonical_public_files':len(files),'criteria':47,'total_weight':100,'critical_count':sum(c['critical'] for c in criteria),'canonical_cli_commands':3,'base_numeric_pass':30,'price_numeric_pass':30,'current_complete_grade':grade['counts'],'current_score':None,'only_readiness_pending':'independent_full_case_freeze','image_layers_observed':len(history['layers']),'new_optimization_or_Docker_runs':0},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
