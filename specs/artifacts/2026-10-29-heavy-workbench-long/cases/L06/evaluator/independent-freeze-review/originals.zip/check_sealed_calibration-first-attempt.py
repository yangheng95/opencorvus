"""Authorized post-seal archive comparison only; do not execute author constructors."""
from datetime import datetime,timezone
import json
from pathlib import Path
import shutil,zipfile
ROOT=Path(__file__).resolve().parent
CASE=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L06')
CAL=Path('D:/opencorvus-benchmark-runs/l06-review-calibration-20261029')
def load(path):return json.loads(path.read_text(encoding='utf-8'))

def main():
    with zipfile.ZipFile(CASE/'evaluator/review-calibration/originals.zip') as archive:
        original=json.loads(archive.read('independent/INITIAL-RATINGS.json'));new=json.loads(archive.read('equivalent-format-controls/independent/INITIAL-8-RATINGS.json'))
        assert original==load(CAL/'independent/INITIAL-RATINGS.json') and new==load(CAL/'equivalent-format-controls/independent/INITIAL-8-RATINGS.json')
        key=json.loads(archive.read('AUTHOR-KEY-DO-NOT-PASS-TO-RATER.json'));key2=json.loads(archive.read('equivalent-format-controls/AUTHOR-KEY-DO-NOT-READ.json'))
        matches=[key['packets'][r['packet_id']]['ratings'][r['leaf']]==r['judgement'] for r in original['ratings']]
        matches2=[key2[r['packet_id']][r['leaf']]==r['judgement'] for r in new['ratings']]
        paths=['equivalent-format-controls/independent/post-initial-adjudication-final/ADJUDICATION.json','equivalent-format-controls/independent/E04-E05-final-adjudication/ADJUDICATION.json']
        changed=[]
        for n in paths:
            a=json.loads(archive.read(n));assert a==load(CAL/n)
            changed += [r['leaf'] for r in a['decisions']]
        assert set(changed)=={'F01','F02','E04','E05'}
    source=Path('D:/opencorvus-benchmark-runs/l06-grading-qualification-20261029/main-c-canonical');receipt=load(source/'receipt.json');assert receipt['status']=='passed' and receipt['actual_cli_count']==15
    target=ROOT/'existing-grading-qualification';target.mkdir();shutil.copy2(source/'receipt.json',target/'main-c-canonical-receipt.json');shutil.copy2(source/'aggregation-fixtures.json',target/'synthetic-algebra.json')
    result={'scope':'Read original keys only now, after all independent initial ratings and adjudications were sealed and delivered. Never executed/read author preparation script. Agreement is not maturity evidence.','observed_utc':datetime.now(timezone.utc).isoformat(),'initial_archive_exactly_preserves_independent36':True,'format_control_archive_exactly_preserves_independent8':True,'initial_label_matches':sum(matches),'initial_label_total':len(matches),'new_format_matches':sum(matches2),'new_format_total':len(matches2),'four_supplementary_rulings_exactly_preserved':sorted(changed),'shared_format_bias_exposed_despite_initial_agreement':True,'professional_or_statistical_certification':False,'existing15CLI_receipt_read_not_reexecuted':True,'new_solver_or_Docker_or_Provider_runs':0}
    (ROOT/'calibration-summary/post-seal-independent-archive-check.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
