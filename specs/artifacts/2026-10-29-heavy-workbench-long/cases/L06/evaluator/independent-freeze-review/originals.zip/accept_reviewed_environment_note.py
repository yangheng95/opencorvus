"""Capture the one inspected non-normative runtime-note edit without rerunning tests."""
import json
from pathlib import Path
import shutil
ROOT=Path(__file__).resolve().parent
CASE=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L06')
changes=json.loads((ROOT/'changes-during-review.json').read_text(encoding='utf-8'))
assert list(changes)==['public/ENVIRONMENT.md']
folder=ROOT/'changes-during-review';folder.mkdir(exist_ok=False)
shutil.copy2(ROOT/'case-snapshot/public/ENVIRONMENT.md',folder/'ENVIRONMENT-before.md')
shutil.copy2(CASE/'public/ENVIRONMENT.md',folder/'ENVIRONMENT-accepted.md')
shutil.copy2(CASE/'public/ENVIRONMENT.md',ROOT/'case-snapshot/public/ENVIRONMENT.md')
(folder/'decision.json').write_text(json.dumps({'observed_change':changes,'decision':'accepted after actual text review','semantic_reason':'Only replaces an expiring no-candidate status sentence with per-run registration and no difficulty/time inference; requirements, dependency versions/image/command and data/grading unchanged.','functional_checks_repeated':False,'initial_copy_preserved':True},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
