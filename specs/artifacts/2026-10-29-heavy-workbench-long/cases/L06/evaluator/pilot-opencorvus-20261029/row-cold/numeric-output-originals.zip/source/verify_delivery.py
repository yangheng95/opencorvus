"""Independently regenerate accounts and verify serialized user deliverables."""

import argparse
import json
from pathlib import Path
from fractions import Fraction
from l06_data import load
from l06_simulate import simulate


def verify(inputs, output):
    n, _ = load(inputs)

    def read(name):
        return json.loads((output / name).read_text(encoding="utf-8"))

    assert n == read("normalized.json"), "raw inputs and normalized facts differ"
    for prefix in ("", "alternative-"):
        ledger, summary, errors = simulate(n, read(prefix + "plan.json"))
        assert not errors
        assert ledger == read(prefix + "ledger.json"), prefix + "ledger mismatch"
        saved = read(prefix + "summary.json")
        saved.pop("change", None)
        assert summary == saved, prefix + "summary mismatch"
        for sc in n["scenarios"]:
            rows = ledger["scenarios"][sc["id"]]["weeks"]
            # A separate total-cash identity cross-check, not model feasibility.
            total_receipts = sum(r["receipts"] for r in rows)
            assert rows[-1]["cash"] == n["initial_cash_minor"] + total_receipts - sum(
                r["cost"] for r in rows
            )
    _, _, errors = simulate(n, read("baseline-plan.json"), strict=False)
    assert errors == read("baseline-check.json")["violations"]
    assert read("plan.json") != read("alternative-plan.json")
    run = read("run.json")
    summary = read("summary.json")
    fraction = Fraction(**summary["expected_cost_minor"])
    assert run["native_solver"]["objective_minor"] == float(fraction)
    assert run["native_solver"]["best_bound_minor"] <= float(fraction)
    manifest = read("manifest.json")
    for rel in [*manifest["outputs"].values(), *manifest["supplementary"]]:
        path = output / rel
        assert path.resolve().is_relative_to(output.resolve()) and path.is_file(), rel
    from PIL import Image

    for filename in ("operations.png", "costs.png"):
        with Image.open(output / filename) as image:
            image.verify()
    return {
        "input": str(inputs),
        "output": str(output),
        "scenario_weeks_checked": n["weeks"] * len(n["scenarios"]),
        "main_and_alternative_feasible": True,
        "serialized_ledgers_exact": True,
        "expected_cost_minor": summary["expected_cost_minor"],
        "baseline_violations": len(errors),
        "native_solver": run["native_solver"],
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    print(json.dumps(verify(args.input, args.output), ensure_ascii=False, indent=2))
