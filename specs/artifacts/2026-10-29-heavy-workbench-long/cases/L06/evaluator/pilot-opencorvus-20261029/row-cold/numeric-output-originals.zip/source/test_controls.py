"""Fresh source-only reruns for the declared numerical and row-order controls."""

import argparse
import csv
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

from l06_data import load
from verify_delivery import verify


SOURCES = [
    "reproduce.py",
    "l06_data.py",
    "l06_simulate.py",
    "l06_optimize.py",
    "l06_report.py",
]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--seconds", type=float, default=1800)
    parser.add_argument("--workers", type=int, default=8)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    dest = args.output.resolve()
    dest.mkdir(parents=True, exist_ok=False)
    cold = dest / "cold-source"
    cold.mkdir()
    for name in SOURCES:
        shutil.copyfile(root / name, cold / name)
    evidence = {
        "declared_controls": {
            "row_order": "reverse every CSV data row, keeping headers",
            "price_increase": "C supplier R0 unit_price_minor +1; all other facts unchanged",
        },
        "cold_source_files": SOURCES,
        "runs": [],
    }
    reference, _ = load(root / "inputs")
    for kind in ("row-reordered", "C-R0-price-plus-one"):
        inputs = dest / (kind + "-inputs")
        shutil.copytree(root / "inputs", inputs)
        names = (
            list(inputs.glob("*.csv"))
            if kind == "row-reordered"
            else [inputs / "supplier_quotes.csv"]
        )
        for file in names:
            with file.open(encoding="utf-8", newline="") as stream:
                reader = csv.DictReader(stream)
                fields, rows = reader.fieldnames, list(reader)
            if kind == "row-reordered":
                rows.reverse()
            else:
                for row in rows:
                    if row["supplier_id"] == "C" and row["raw_id"] == "R0":
                        row["unit_price_minor"] = str(int(row["unit_price_minor"]) + 1)
            with file.open("w", encoding="utf-8", newline="") as stream:
                writer = csv.DictWriter(stream, fieldnames=fields)
                writer.writeheader()
                writer.writerows(rows)
        actual, _ = load(inputs)
        if kind == "row-reordered":
            assert actual == reference, "row-order control changed business facts"
        else:
            expected = json.loads(json.dumps(reference))
            supplier = next(s for s in expected["suppliers"] if s["id"] == "C")
            supplier["price_minor"][expected["raw_materials"].index("R0")] += 1
            assert actual == expected, "price control changed unexpected business facts"
        output = dest / kind
        command = [
            sys.executable,
            "reproduce.py",
            "--input",
            str(inputs),
            "--output",
            str(output),
            "--seconds",
            str(args.seconds),
            "--workers",
            str(args.workers),
        ]
        start = time.perf_counter()
        with (dest / (kind + "-stdout.txt")).open("w", encoding="utf-8") as log:
            completed = subprocess.run(
                command, cwd=cold, stdout=log, stderr=subprocess.STDOUT, check=False
            )
        assert completed.returncode == 0, f"{kind} failed, inspect its stdout"
        checked = verify(inputs, output)
        evidence["runs"].append(
            {
                "kind": kind,
                "command": command,
                "working_directory": str(cold),
                "elapsed_seconds": time.perf_counter() - start,
                "exit_code": completed.returncode,
                "verification": checked,
            }
        )
        (dest / "results.json").write_text(
            json.dumps(evidence, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )
        print(json.dumps(evidence["runs"][-1], ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
