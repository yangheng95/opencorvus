"""Business handoff and figures generated exclusively from current accounts."""

from fractions import Fraction
import csv
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt


def generate(out, n, plan, ledger, summary, alternative, baseline, stats):
    scenarios = n["scenarios"]
    fig, axes = plt.subplots(3, 1, figsize=(11, 11), constrained_layout=True)
    for sc in scenarios:
        rows = ledger["scenarios"][sc["id"]]["weeks"]
        axes[0].plot(
            [r["week"] for r in rows],
            [r["cash"] for r in rows],
            marker="o",
            label=sc["id"],
        )
        axes[1].plot(
            [r["week"] for r in rows],
            [sum(r["finished_inventory"]) for r in rows],
            marker="o",
            label=sc["id"],
        )
        axes[2].plot(
            [r["week"] for r in rows],
            [r["raw_stage_peak_volume"] for r in rows],
            label=sc["id"] + " raw",
        )
        axes[2].plot(
            [r["week"] for r in rows],
            [r["product_stage_peak_volume"] for r in rows],
            linestyle="--",
            label=sc["id"] + " finished",
        )
    axes[0].axhline(
        -n["credit_limit_minor"], color="red", linestyle="--", label="credit floor"
    )
    axes[2].axhline(
        n["raw_storage_volume"], color="black", linestyle=":", label="raw limit"
    )
    axes[2].axhline(
        n["product_storage_volume"], color="red", linestyle=":", label="finished limit"
    )
    for ax, label in zip(
        axes,
        [
            "Cash (minor units)",
            "End finished inventory (units)",
            "Stage peak (volume units)",
        ],
    ):
        ax.set(xlabel="Week (zero-based)", ylabel=label, xticks=range(n["weeks"]))
        ax.legend(fontsize=8, ncol=2)
        ax.grid(alpha=0.2)
    fig.savefig(out / "operations.png", dpi=150)
    plt.close(fig)
    fields = ["purchase_cost", "freight_cost", "production_cost", "holding_cost"]
    expected_parts = [
        sum(
            Fraction(sc["probability_numerator"], n["probability_denominator"])
            * sum(r[f] for r in ledger["scenarios"][sc["id"]]["weeks"])
            for sc in scenarios
        )
        for f in fields
    ]
    fig, ax = plt.subplots(figsize=(9, 4), constrained_layout=True)
    ax.bar(
        ["Procurement", "Freight", "Production", "Holding"],
        [float(x) for x in expected_parts],
    )
    ax.set(
        ylabel="Expected expenditure (minor units)",
        title="Exact source: ledger.json, probability-weighted categories",
    )
    fig.savefig(out / "costs.png", dpi=150)
    plt.close(fig)
    with (out / "weekly.csv").open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            [
                "scenario",
                "week",
                "cash",
                "receipts",
                "cost",
                *fields,
                "raw_stage_peak_volume",
                "product_stage_peak_volume",
                "end_finished_units",
            ]
        )
        for sc in scenarios:
            for row in ledger["scenarios"][sc["id"]]["weeks"]:
                writer.writerow(
                    [
                        sc["id"],
                        row["week"],
                        row["cash"],
                        row["receipts"],
                        row["cost"],
                        *[row[f] for f in fields],
                        row["raw_stage_peak_volume"],
                        row["product_stage_peak_volume"],
                        sum(row["finished_inventory"]),
                    ]
                )

    def exact(x):
        if isinstance(x, dict):
            x = Fraction(x["numerator"], x["denominator"])
        return str(x)

    text = [
        "# 16周合成制造采购与生产运营方案",
        "",
        "本报告所有金额为合成整数最小单位，不是真实采购指令。周从0开始。报告、图和CSV均由本次原始输入求解及独立逐周模拟生成。",
        "## 执行摘要",
        f"主方案精确期望总支出 **{exact(summary['expected_cost_minor'])}**；替代方案 **{exact(alternative['expected_cost_minor'])}**。",
        f"联合整数求解终态 `{stats['status']}`，本地数值下界 {stats['best_bound_minor']}，目标 {stats['objective_minor']}。",
        f"相对本地下界的差距 {(stats['objective_minor'] - stats['best_bound_minor']) / stats['best_bound_minor']:.6%}（若下界为正）。非零差距不称精确最优；该数值界不是独立有理证明，也不是评估者预注册界，正式1%质量仍需独立评估。",
        "",
        "|情景|概率|支出|最低周末现金|末周现金|末期应收|",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for sc in scenarios:
        a = summary["scenarios"][sc["id"]]
        text.append(
            f"|{sc['id']}|{exact(a['probability'])}|{a['total_cost_minor']}|{a['minimum_cash_minor']}|{a['final_cash_minor']}|{a['final_receivable_minor']}|"
        )
    text += [
        "",
        "## 操作交接与身份",
        "",
        f"原料index→ID：{list(enumerate(n['raw_materials']))}；产品：{list(enumerate(n['products']))}；产线：{list(enumerate(n['plants']))}；供应商：{[(j, s['id']) for j, s in enumerate(n['suppliers'])]}。",
        "完整动作在[plan.json](plan.json)的`decisions[情景ID]`：`order_lots[周][供应商index][原料index]`为整包数；乘normalized中该供应商的pack_units得件数，price_minor为每件价格。`truck_on[周][供应商index]`为装运开关；`production[周][产线index][产品index]`为生产件数。非上述动作不由本报告授权。",
        f"周0至{n['common_weeks'] - 1}只执行一份共同承诺（任一情景同值），不可按未来选择前缀；周{n['common_weeks']}开始前确认情景ID，之后逐周执行该情景分支。早期订单按原下单周加lead_weeks到货，情景揭示不撤销在途。没有初始在途。",
        "每周按先到货、再生产、再交付、再计期末库存的次序操作。现金先收已到期销售款，再支付当周支出。供应共享体积、产线共享工时及两个阶段峰值不是期末库存约束的替代。",
        "",
        "### 共同承诺（完整数值）",
        "",
        "|周|采购包数[供应商][原料]|装运开关|生产[线][产品]|",
        "|---:|---|---|---|",
    ]
    common = plan["decisions"][scenarios[0]["id"]]
    for w in range(n["common_weeks"]):
        text.append(
            f"|{w}|{common['order_lots'][w]}|{common['truck_on'][w]}|{common['production'][w]}|"
        )
    text += [
        "",
        "## 为什么必须提前生产",
        "",
        "以下用原始需求与资格/工时计算当周可生产的产品上界；需求超过上界的部分，必须由此前期末成品覆盖。该上界甚至忽略其他产品竞争，因此缺口是必要条件，而非凭求解轨迹推测。",
        "",
        "|情景|周|产品|需求|当周宽松产量上界|必须提前持有至少|实际上周期末持有|",
        "|---|---:|---|---:|---:|---:|---:|",
    ]
    for sc in scenarios:
        rows = ledger["scenarios"][sc["id"]]["weeks"]
        for w in range(n["weeks"]):
            for p in range(len(n["products"])):
                upper = sum(
                    sc["plant_capacity_hours"][w][f] // n["production_hours"][p]
                    for f in range(len(n["plants"]))
                    if n["allowed"][f][p]
                )
                deficit = sc["demand"][w][p] - upper
                if deficit > 0:
                    previous = (
                        rows[w - 1]["finished_inventory"][p]
                        if w
                        else n["initial_products"][p]
                    )
                    text.append(
                        f"|{sc['id']}|{w}|{n['products'][p]}|{sc['demand'][w][p]}|{upper}|{deficit}|{previous}|"
                    )
    text += [
        "",
        "共享工时还会要求在其他周预制，实际期末成品见图及ledger.finished_inventory；上述表仅陈述可直接证明的必要缺口。",
        "",
        "## 供应中断及情景后应对",
        "",
        "下表逐一列出相对首情景的供应容量差异，并列实际下单体积。最低装运量高于容量时，该供应商只能关闭，绝不能把原料分别占满一份供应容量。",
        "",
        "|情景|周|供应商|基准容量→当前容量|最低量|基准下单体积→当前体积|",
        "|---|---:|---|---:|---:|---:|",
    ]
    base = scenarios[0]
    for sc in scenarios[1:]:
        for w in range(n["weeks"]):
            for j, supplier in enumerate(n["suppliers"]):
                old, new = (
                    base["supplier_capacity_volume"][w][j],
                    sc["supplier_capacity_volume"][w][j],
                )
                if old != new:
                    a = ledger["scenarios"][base["id"]]["weeks"][w]["supplier_volume"][
                        j
                    ]
                    b = ledger["scenarios"][sc["id"]]["weeks"][w]["supplier_volume"][j]
                    text.append(
                        f"|{sc['id']}|{w}|{supplier['id']}|{old}→{new}|{supplier['minimum_volume']}|{a}→{b}|"
                    )
    text += [
        "",
        "共同期不能预知中断；揭示后通过此前/其他供应商订单的到货和库存弥补。下表给出分支中各供应商累计下单体积和成品总产量，逐周采购、到货与耗料分别可在plan和ledger对应字段直接定位。相同动作仅在容量和全部其他约束仍满足时保留，不要求人为翻转。",
        "",
        "|情景|情景后供应商累计体积|情景后各产品产量|与首情景不同动作周|",
        "|---|---|---|---|",
    ]
    for sc in scenarios:
        rows = ledger["scenarios"][sc["id"]]["weeks"][n["common_weeks"] :]
        d = plan["decisions"][sc["id"]]
        diff = [
            w
            for w in range(n["common_weeks"], n["weeks"])
            if any(
                d[k][w] != common[k][w]
                for k in ("order_lots", "truck_on", "production")
            )
        ]
        text.append(
            f"|{sc['id']}|{[sum(r['supplier_volume'][j] for r in rows) for j in range(len(n['suppliers']))]}|{[sum(r['made'][p] for r in rows) for p in range(len(n['products']))]}|{diff}|"
        )
    text += [
        "",
        "## 现金瓶颈、费用与仓容",
        "",
        "每周`cost = purchase_cost + freight_cost + production_cost + holding_cost`。采购=包数×每包件数×每件报价，运费=每供应商装运开关×固定运费。持有费=两类期末件数×单位持有费；初始库存不重复购入，没有残值冲减。",
        f"`cash[t] = cash[t-1] + receipts[t] - cost[t]`，初值{n['initial_cash_minor']}；receipts[t]为t−{n['receipt_lag_weeks']}周已交付的需求×销售价，早于0则为0。应收只含已交付未到期销售，不能用于本周付款。",
        "",
        "|情景|最低现金周|现金|剩余信用空间|该周收款|该周支出|原料峰值最大|成品峰值最大|",
        "|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for sc in scenarios:
        rows = ledger["scenarios"][sc["id"]]["weeks"]
        row = min(rows, key=lambda r: r["cash"])
        text.append(
            f"|{sc['id']}|{row['week']}|{row['cash']}|{row['cash'] + n['credit_limit_minor']}|{row['receipts']}|{row['cost']}|{max(r['raw_stage_peak_volume'] for r in rows)}|{max(r['product_stage_peak_volume'] for r in rows)}|"
        )
    text += [
        "",
        "信用紧张来自先付订单与生产、销售回款滞后的时间错配；每个情景独立守住信用底线，不能用期望现金抵销某分支缺口。",
        "",
        "|期望费用类别|精确金额|",
        "|---|---:|",
    ]
    for f, v in zip(fields, expected_parts):
        text.append(f"|{f}|{exact(v)}|")
    text += [
        "",
        f"最大期望费用项为`{fields[max(range(len(fields)), key=lambda k: expected_parts[k])]}`，先比较整包原料价差与运费/库存代价，再考虑产线分配费用。分解之和严格等于期望成本。",
        "",
        "![现金、期末成品与阶段峰值](operations.png)",
        "",
        "图源：[weekly.csv](weekly.csv)，来自[ledger.json](ledger.json)；成品件数曲线不是体积，仓容图采用阶段体积。",
        "",
        "![期望支出构成](costs.png)",
        "",
        "图源：ledger四类费用乘summary的精确概率；绘图浮点显示不参与核算。",
        "",
        "## 基线与完整可行替代",
        "",
        "基线定义：保留主方案全部采购/装运，将生产改成逐周按净当周需求即时生产（先耗初始成品），每种产品只选允许路线中单件生产费最低者，不预制。它是明确、可执行计算的常见局部贪心基线，但不是可行承诺。完整动作见[baseline-plan.json](baseline-plan.json)，实际逐周模拟违例见[baseline-check.json](baseline-check.json)，不将非法轨迹费用冒充可行成本。",
        f"模拟共发现{len(baseline['violations'])}项违例；首项为`{baseline['violations'][0] if baseline['violations'] else None}`。",
        "第6周F0容量0、P0仅F0合格，故不持成品的即时生产策略必然失败；补救是提前完成表中最低缺口，并联合安排其他产品共享工时、原料到货、仓容与现金，正是主方案所执行。",
        "替代方案由主方案的一次有工时余量的合格路线调配产生（共同期若改则所有情景一起改），不改变采购、到货、产品数量及交付。完整策略、规范账与汇总分别见[alternative-plan.json](alternative-plan.json)、[alternative-ledger.json](alternative-ledger.json)、[alternative-summary.json](alternative-summary.json)，已重新通过独立整数模拟全部约束。",
        f"调配详情：{alternative['change']}。替代期望成本比主方案变化{exact(Fraction(alternative['expected_cost_minor']['numerator'], alternative['expected_cost_minor']['denominator']) - Fraction(summary['expected_cost_minor']['numerator'], summary['expected_cost_minor']['denominator']))}。这展示以较高生产费换取原产线工时余量的可行选择，而非假称另一全局最优方案。",
        "",
        "## 模型、复跑、输入控制与局限",
        "",
        "模型为联合情景的CP-SAT（Constraint Programming with Boolean Satisfiability，布尔可满足性约束规划）整数模型。共同期使用同一组动作变量，后续分支仍引用原订单的到货项。目标乘概率共同分母后为整数。库存递推、两个阶段仓容、资格、共享容量、末期成品零、每周期现金与末期现金均显式约束。独立模拟器不导入求解模型，按周重算全部业务字段并检查整数形状、身份与共同期。",
        "normalized所有向量按目录显式index排序；source-map.json记录每张表的联合身份、数值字段和记录数，DATA.md给出列映射。缺失、重复、非法索引、未引用身份、错误数值/单位域或共同信息不一致直接拒绝，不把缺失当零。",
        f"实际参数、依赖版本、终态、耗时在[run.json](run.json)。本轮求解墙钟{stats['elapsed_seconds']:.3f}秒，线程{stats['parameters']['num_search_workers']}。无子代理，不读旧输出，冷启动也不需要本次策略作为热启动。",
        "声明控制类别：仅增加单一供应商某项原料的unit_price_minor，或任意CSV物理行重排。程序始终读取输入数字，不硬编码报价/动作；自测脚本执行反向行序与仅C的R0每件报价+1，并到全新目录复跑。正式封存控制不由本报告推断，其结果仍需独立验证。",
        "求解器浮点原生界按整数目标的概率分母缩放，仅作为成熟求解器的数值界；可行性及账目用Python精确整数/有理数，不用容差。任何限时/正gap不能被解释为精确最优。有限资源下可能只有可行解；本报告不宣称评估得分或业务成功判定。",
        "",
    ]
    (out / "report.md").write_text("\n".join(text), encoding="utf-8")
