"""Targeted business-rule checks on hand-computable data and raw-input parsing."""

import copy
import csv
import json
from pathlib import Path
import shutil
import tempfile
import unittest

from l06_data import load, InputError
from l06_simulate import simulate
from l06_optimize import solve


def tiny():
    n = dict(
        weeks=3,
        common_weeks=1,
        probability_denominator=2,
        raw_materials=["r"],
        products=["p"],
        plants=["f"],
        raw_volume=[1],
        product_volume=[1],
        raw_holding_minor=[1],
        product_holding_minor=[2],
        initial_raw=[2],
        initial_products=[0],
        production_hours=[1],
        sales_price_minor=[20],
        allowed=[[1]],
        production_cost_minor=[[1]],
        bom=[[1]],
        raw_storage_volume=4,
        product_storage_volume=3,
        initial_cash_minor=10,
        credit_limit_minor=10,
        receipt_lag_weeks=1,
        suppliers=[
            dict(
                id="j",
                lead_weeks=1,
                freight_minor=2,
                minimum_volume=2,
                pack_units=[2],
                price_minor=[3],
            )
        ],
        scenarios=[
            dict(
                id=s,
                probability_numerator=1,
                demand=[[1], [1], [1]],
                supplier_capacity_volume=[[2], [2], [2]],
                plant_capacity_hours=[[2], [2], [2]],
            )
            for s in ("a", "b")
        ],
    )
    plan = {
        "format": "l06-plan/1",
        "decisions": {
            s: dict(
                order_lots=[[[1]], [[0]], [[0]]],
                truck_on=[[1], [0], [0]],
                production=[[[1]], [[1]], [[1]]],
            )
            for s in ("a", "b")
        },
    }
    return n, plan


class SimulationTests(unittest.TestCase):
    def test_exact_positive_account(self):
        n, p = tiny()
        ledger, summary, errors = simulate(n, p)
        rows = ledger["scenarios"]["a"]["weeks"]
        self.assertFalse(errors)
        self.assertEqual([r["arrivals"] for r in rows], [[0], [2], [0]])
        self.assertEqual([r["raw_stage_peak_volume"] for r in rows], [2, 3, 2])
        self.assertEqual([r["raw_inventory"] for r in rows], [[1], [2], [1]])
        self.assertEqual([r["cash"] for r in rows], [0, 17, 35])
        self.assertEqual([r["receivable"] for r in rows], [20, 20, 20])
        self.assertEqual(
            summary["expected_cost_minor"], {"numerator": 15, "denominator": 1}
        )
        self.assertEqual(summary["scenarios"]["a"]["final_cash_minor"], 35)

    def test_lead_zero_and_package_payment(self):
        n, p = tiny()
        n["suppliers"][0]["lead_weeks"] = 0
        n["initial_raw"] = [0]
        n["suppliers"][0]["pack_units"] = [1]
        n["suppliers"][0]["minimum_volume"] = 1
        for d in p["decisions"].values():
            d["order_lots"] = [[[1]], [[1]], [[1]]]
            d["truck_on"] = [[1], [1], [1]]
        ledger, _, _ = simulate(n, p)
        self.assertEqual(
            [r["arrivals"] for r in ledger["scenarios"]["a"]["weeks"]], [[1], [1], [1]]
        )
        self.assertEqual(ledger["scenarios"]["a"]["weeks"][0]["purchase_cost"], 3)

    def test_peak_not_end_storage(self):
        n, p = tiny()
        n["raw_storage_volume"] = 2
        _, _, errors = simulate(n, p, False)
        self.assertTrue(
            any(e["week"] == 1 and e["rule"] == "raw_stage_storage" for e in errors)
        )
        n, p = tiny()
        n["product_storage_volume"] = 0
        _, _, errors = simulate(n, p, False)
        self.assertTrue(any(e["rule"] == "product_stage_storage" for e in errors))

    def test_individual_rules(self):
        cases = [
            (
                "credit",
                lambda n, p: n.update(initial_cash_minor=0, credit_limit_minor=0),
            ),
            (
                "terminal_cash",
                lambda n, p: n.update(
                    initial_cash_minor=0, credit_limit_minor=100, receipt_lag_weeks=3
                ),
            ),
            (
                "line_hours:f",
                lambda n, p: n["scenarios"][0]["plant_capacity_hours"][0].__setitem__(
                    0, 0
                ),
            ),
            ("route:0:0", lambda n, p: n["allowed"][0].__setitem__(0, 0)),
            (
                "supplier_shared_volume:j",
                lambda n, p: n["scenarios"][0]["supplier_capacity_volume"][
                    0
                ].__setitem__(0, 1),
            ),
            (
                "supplier_shared_volume:j",
                lambda n, p: n["suppliers"][0].update(minimum_volume=3),
            ),
            (
                "late_order",
                lambda n, p: (
                    p["decisions"]["a"]["order_lots"][2][0].__setitem__(0, 1),
                    p["decisions"]["a"]["truck_on"][2].__setitem__(0, 1),
                ),
            ),
            (
                "nonanticipativity",
                lambda n, p: p["decisions"]["b"]["production"][0][0].__setitem__(0, 2),
            ),
            ("raw_nonnegative", lambda n, p: n.update(initial_raw=[0])),
            (
                "delivery_no_backlog",
                lambda n, p: p["decisions"]["a"]["production"][1][0].__setitem__(0, 0),
            ),
            (
                "terminal_finished",
                lambda n, p: p["decisions"]["a"]["production"][2][0].__setitem__(0, 2),
            ),
        ]
        for rule, mutate in cases:
            with self.subTest(rule=rule):
                n, p = tiny()
                mutate(n, p)
                _, _, errors = simulate(n, p, False)
                self.assertTrue(any(e["rule"] == rule for e in errors), errors)

    def test_reject_boolean_and_shape(self):
        n, p = tiny()
        p["decisions"]["a"]["production"][0][0][0] = True
        with self.assertRaises(ValueError):
            simulate(n, p)

    def test_joint_solver_positive(self):
        n, _ = tiny()
        plan, stats = solve(n, 10, 1)
        _, summary, errors = simulate(n, plan)
        self.assertFalse(errors)
        # One package, one freight, three products and two unavoidable raw holding units.
        self.assertEqual(stats["objective_minor"], 6 + 2 + 3 + 2)
        self.assertEqual(stats["best_bound_minor"], 13)
        self.assertEqual(
            stats["objective_minor"],
            summary["expected_cost_minor"]["numerator"]
            / summary["expected_cost_minor"]["denominator"],
        )
        self.assertEqual(
            plan["decisions"]["a"]["order_lots"][0],
            plan["decisions"]["b"]["order_lots"][0],
        )

    def test_pre_revelation_orders_arrive_unchanged_in_both_branches(self):
        n, _ = tiny()
        n["scenarios"][1]["demand"] = [[1], [2], [0]]
        plan, _ = solve(n, 10, 1)
        ledger, _, errors = simulate(n, plan)
        self.assertFalse(errors)
        for identity in ("a", "b"):
            self.assertEqual(plan["decisions"][identity]["order_lots"][0], [[1]])
            self.assertEqual(ledger["scenarios"][identity]["weeks"][1]["arrivals"], [2])
            self.assertEqual(plan["decisions"][identity]["order_lots"][-1], [[0]])

    def test_shared_supplier_capacity_multiple_materials(self):
        n, p = tiny()
        n.update(
            raw_materials=["r", "r2"],
            raw_volume=[1, 1],
            raw_holding_minor=[1, 1],
            initial_raw=[2, 2],
            bom=[[1, 1]],
        )
        n["suppliers"][0].update(pack_units=[2, 2], price_minor=[3, 3])
        for d in p["decisions"].values():
            d["order_lots"] = [[[1, 1]], [[0, 0]], [[0, 0]]]
        _, _, errors = simulate(n, p, False)
        self.assertTrue(
            any(
                e["rule"] == "supplier_shared_volume:j" and e["actual"] == 4
                for e in errors
            )
        )
        n["raw_storage_volume"] = 8
        for s in n["scenarios"]:
            s["supplier_capacity_volume"] = [[4], [4], [4]]
        n["initial_cash_minor"] = 20
        _, _, errors = simulate(n, p)
        self.assertFalse(errors)


class DataTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name) / "inputs"
        shutil.copytree(Path(__file__).parent / "inputs", self.root)

    def tearDown(self):
        self.temp.cleanup()

    def rows(self, name):
        with (self.root / name).open(encoding="utf-8", newline="") as f:
            reader = csv.DictReader(f)
            return reader.fieldnames, list(reader)

    def save(self, name, fields, rows):
        with (self.root / name).open("w", encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writeheader()
            writer.writerows(rows)

    def test_complete_projection_and_row_order(self):
        original, _ = load(self.root)
        self.assertEqual(original["raw_materials"], ["R0", "R1", "R2", "R3"])
        self.assertEqual(original["initial_raw"], [30, 40, 20, 20])
        self.assertEqual(original["production_hours"], [1, 2, 1, 3])
        self.assertEqual(original["suppliers"][1]["price_minor"], [22, 30, 25, 38])
        self.assertEqual(
            original["scenarios"][1]["supplier_capacity_volume"][6], [15, 75, 30]
        )
        for path in self.root.glob("*.csv"):
            fields, rows = self.rows(path.name)
            self.save(path.name, fields, list(reversed(rows)))
        reordered, _ = load(self.root)
        self.assertEqual(original, reordered)

    def test_duplicate_missing_foreign_index_and_domains(self):
        fields, rows = self.rows("bom.csv")
        self.save("bom.csv", fields, rows + [rows[0]])
        with self.assertRaises(InputError):
            load(self.root)
        self.save("bom.csv", fields, rows[:-1])
        with self.assertRaises(InputError):
            load(self.root)
        foreign = copy.deepcopy(rows)
        foreign[0]["raw_id"] = "not-a-raw"
        self.save("bom.csv", fields, foreign)
        with self.assertRaises(InputError):
            load(self.root)
        self.save("bom.csv", fields, rows)
        f, raw = self.rows("raw_materials.csv")
        raw[0]["raw_index"] = "1"
        self.save("raw_materials.csv", f, raw)
        with self.assertRaises(InputError):
            load(self.root)
        raw[0]["raw_index"] = "0"
        raw[0]["volume"] = "0"
        self.save("raw_materials.csv", f, raw)
        with self.assertRaises(InputError):
            load(self.root)

    def test_quote_controls_are_numeric_inputs(self):
        n, _ = load(self.root)
        fields, rows = self.rows("supplier_quotes.csv")
        for row in rows:
            if row["supplier_id"] == "B":
                row["unit_price_minor"] = str(int(row["unit_price_minor"]) + 1)
        self.save("supplier_quotes.csv", fields, rows)
        changed, _ = load(self.root)
        self.assertEqual(changed["suppliers"][1]["price_minor"], [23, 31, 26, 39])
        self.assertNotEqual(n, changed)


if __name__ == "__main__":
    unittest.main()
