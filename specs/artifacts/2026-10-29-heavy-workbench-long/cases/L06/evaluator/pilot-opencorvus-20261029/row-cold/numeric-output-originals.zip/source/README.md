# L06/0.2.0 可执行情景运营方案

此项目只处理公开的合成制造数据，不执行外部采购或付款。业务依据为根目录的TASK.md、DATA.md、OUTPUTS.md、ENVIRONMENT.md、SOURCE.md、profile.json与inputs/。周序从0开始，金额为整数模拟最小单位。

## 依赖与构建

Python 3.11；直接依赖固定在[requirements.txt](requirements.txt)。可在隔离环境执行`python -m pip install -r requirements.txt`。无编译步骤，不需GPU、不需联网求解。run.json记录实际Python及主要数值依赖版本，未提供完整传递依赖锁；依赖镜像是本次准备环境，不是答案或模型来源。

本项目已在ENVIRONMENT.md提供的镜像`opencorvus-benchmark-reference:20261029`及其中`/opt/cpsat/bin/python`实际运行。只挂载本项目：

```text
docker run --rm --name l06-reproduce --network none --mount "type=bind,source=<本项目绝对路径>,target=/work" --workdir /work opencorvus-benchmark-reference:20261029 /opt/cpsat/bin/python reproduce.py --input inputs --output new-output
```

Windows Git Bash需要在docker命令前设置`MSYS_NO_PATHCONV=1`，避免将容器路径改成Windows路径。容器名必须未被占用，不能删除或停止不属于自己的容器。本次长求解使用显式命名的独立容器并保留退出状态和日志；早期短命令也使用过`--rm`。仅管理自己记录的容器身份，不操作已有运行。

标准入口：

```text
python reproduce.py --input inputs --output new-output
```

输出目录必须不存在，可位于项目外。程序只读传入原始目录和源码/声明依赖，完全不读旧计划或输出。默认单次联合求解上限1800秒、8线程、随机种子20261029、相对gap限制0.001；可用`--seconds`和`--workers`调整。不同并行求解运行可能得到不同策略，业务与成本需从其新账重算。限时可行不等于精确最优。无可行解时入口报错，不生成伪造策略。

## 交付导航

- [output/report.md](output/report.md)：业务报告，包含真实PNG图、共同承诺、必要提前生产、中断应对、现金瓶颈、费用来源、基线及可行替代。
- [output/plan.json](output/plan.json)：主政策；共同周0–3执行同值动作，周4前按揭示情景选择之后分支，保留既有订单到货。数组索引由normalized.json的实体数组明确对应。
- [output/ledger.json](output/ledger.json)、[output/summary.json](output/summary.json)：独立精确模拟的逐场景规范账和有理期望。
- [output/alternative-plan.json](output/alternative-plan.json)：完整不同可行策略，有独立重算的账和汇总；不以局部动作说明替代完整策略。
- [output/baseline-plan.json](output/baseline-plan.json)、[output/baseline-check.json](output/baseline-check.json)：保留采购但即时按最低生产费路线生产的基线，实际不可行；不报虚假可行成本。
- [output/run.json](output/run.json)、[output/manifest.json](output/manifest.json)：本次真实命令、主要依赖版本、参数、资源/终态与文件定位。候选求解界不替代评估者预注册界。
- [verification/controls/results.json](verification/controls/results.json)：CSV行序与单一供应商报价增加控制的真实冷复跑核验。
- [verification/main-check.json](verification/main-check.json)、[verification/unit-tests.txt](verification/unit-tests.txt)：已序列化交付的重新核算和规则测试记录。
- `l06-delivery.zip`：可移交的源码、公开输入、主输出与冷复跑证据集合。`python package_delivery.py`在全部文件齐备后创建新压缩包，并逐文件直接比较归档与原文件字节；它不参与求解，不替代业务核验，也不会覆盖已有压缩包。

所有机器账中数量、成本、现金均为精确整数；概率与期望使用分子/分母。绘图的浮点转换只用于显示。

`verification/initial-output/`保留早期可行运行；`verification/interrupted-output/`仅保留中断时写出的输入规范化文件，不是完整方案。当前交付以`output/`和`verification/controls/results.json`为准，压缩包不混入这些历史输出。

## 数据映射与严格校验

CSV（Comma-Separated Values，逗号分隔值）按UTF-8读取。所有目录按显式index排序，ID唯一，索引连续且唯一；联合表必须完整笛卡尔覆盖，缺失、重复、未知引用及错误字段/整数域均拒绝。不得把容量0当缺值。来源字段与联合键见每次输出的source-map.json。

|原表|normalized字段（按显式index）|
|---|---|
|raw_materials|raw_materials ID数组、raw_volume、raw_holding_minor、initial_raw|
|products|products ID数组、product_volume、product_holding_minor、initial_products、production_hours、sales_price_minor|
|plants|plants ID数组|
|supplier_terms、supplier_quotes|suppliers[].id/lead_weeks/freight_minor/minimum_volume；pack_units和price_minor为原料向量|
|routes|allowed[产线][产品]、production_cost_minor[产线][产品]|
|bom|bom[产品][原料]|
|scenarios、demand、supplier_capacity、plant_capacity|scenarios[].id/probability_numerator；demand[周][产品]、supplier_capacity_volume[周][供应商]、plant_capacity_hours[周][产线]|
|facility|同名数值字段，format改为l06-feasibility-instance/2|

报价单位是每原料件，不是每包；生产工时/费用是每产品件；仓容及最低装运量为体积，不能和件数混用。初始库存是已有资产。概率共同分母与分子严格核对。

## 源码职责与验证

- l06_data.py：身份、维度、域、共同事实校验和规范化。
- l06_optimize.py：CP-SAT（Constraint Programming with Boolean Satisfiability，布尔可满足性约束规划）联合整数模型，共同期共享变量；采购按下单周付款，提前期到货、包装、最低/共享装运容量、共享工时、资格、两个周内峰值、末期成品与逐场景现金全部约束。
- l06_simulate.py：不导入求解模型；按业务时序独立整数模拟全部动作、账目与违例，分数精确汇总。
- l06_report.py：从本次账生成报告、CSV和PNG，不使用模板填入旧数字。
- verify_delivery.py：重新读原始输入与已写输出，逐字段核对主/替代账和汇总、基线违例、总现金恒等式、模型目标、图片格式及清单路径。

```text
python -m unittest test_l06
python verify_delivery.py --input inputs --output output
python test_controls.py --output fresh-control-directory
```

单元测试包含可手算正例、提前期0/1、整包付款、两个阶段峰值、逐情景现金、末期规则、共同动作、共享容量、资格、重复/缺失/未知引用、显式index及数值报价变化。

预先声明的控制类别：只提高单一供应商的某项原料unit_price_minor（其他事实不变），或者重排CSV物理行序。实际自测将全部CSV数据行倒序，以及仅将C的R0每件报价+1；test_controls.py复制且仅复制5个求解源文件到全新cold-source目录，再分别调用入口到全新输出并精确核账。两项控制不引入新业务语义，正式封存值由独立评估提供。原始输入不会被测试修改。B全部原料每件报价+1曾用旧策略预核验，发现旧策略违反信用底线，未据此断言变价实例不可行，也未将它作为已通过的正式控制测试。

### 已完成的冷复跑结果

|输入|精确期望成本|原生终态|本次搜索界|独立精确复核|
|---|---:|---|---:|---|
|原始输入（output）|476871/10|FEASIBLE|47372.3|主/替代各48情景周通过|
|所有CSV数据行倒序|239199/5|FEASIBLE|47345.9|主/替代各48情景周通过|
|仅C/R0每件报价+1|477847/10|FEASIBLE|47367.7|主/替代各48情景周通过|

三次均达到1800秒求解时限，不是精确最优。主运行8线程，两项控制各4线程，均未读取旧策略；各次参数、真实命令和账见相应run.json与results.json。行序控制的规范化业务事实与原始输入严格同值；多线程搜索轨迹不同，不能要求输出动作或成本逐字相同。该控制单次搜索界的差距约1.043%，不宣称其单次求解界达到1%；主运行的0.665%及变价运行约0.880%也不能替代评估者的预注册质量判定。11项单元测试已通过，基线在三个输入运行中均实际检出33项违例。

这些检查不替代后续独立Tester，也不自行判定正式成本门槛。求解器的数值下界不是独立有理证明。所有结果只适用所述合成语义，不是实际商业认证。
