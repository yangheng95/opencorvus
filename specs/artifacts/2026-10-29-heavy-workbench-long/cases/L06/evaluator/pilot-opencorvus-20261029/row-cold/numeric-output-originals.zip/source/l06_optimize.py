"""Joint stochastic integer model with shared pre-revelation variables."""

import json
import time
from ortools.sat.python import cp_model


def solve(n, seconds=1800, workers=8):
    m = cp_model.CpModel()
    W, R, P, F, S = (
        n["weeks"],
        len(n["raw_materials"]),
        len(n["products"]),
        len(n["plants"]),
        len(n["suppliers"]),
    )
    order, truck, production, inventories, costs = {}, {}, {}, {}, []

    def variable(store, key, bound):
        if key not in store:
            store[key] = m.new_int_var(0, bound, str(key))
        return store[key]

    def key(s, w, *indices):
        return (0 if w < n["common_weeks"] else s, w, *indices)

    allvars = []
    for s, sc in enumerate(n["scenarios"]):
        oq, ty, px, rv, fv, weekly_cost = [], [], [], [], [], []
        for w in range(W):
            oq.append(
                [
                    [
                        variable(
                            order,
                            key(s, w, j, r),
                            0
                            if w + n["suppliers"][j]["lead_weeks"] >= W
                            else min(
                                x["supplier_capacity_volume"][w][j]
                                for x in n["scenarios"]
                            )
                            // (n["suppliers"][j]["pack_units"][r] * n["raw_volume"][r])
                            if w < n["common_weeks"]
                            else sc["supplier_capacity_volume"][w][j]
                            // (
                                n["suppliers"][j]["pack_units"][r] * n["raw_volume"][r]
                            ),
                        )
                        for r in range(R)
                    ]
                    for j in range(S)
                ]
            )
            ty.append([variable(truck, key(s, w, j), 1) for j in range(S)])
            px.append(
                [
                    [
                        variable(
                            production,
                            key(s, w, f, p),
                            sc["plant_capacity_hours"][w][f] // n["production_hours"][p]
                            if n["allowed"][f][p]
                            else 0,
                        )
                        for p in range(P)
                    ]
                    for f in range(F)
                ]
            )
            rv.append(
                [
                    m.new_int_var(
                        0,
                        n["raw_storage_volume"] // n["raw_volume"][r],
                        f"raw:{s}:{w}:{r}",
                    )
                    for r in range(R)
                ]
            )
            fv.append(
                [
                    m.new_int_var(
                        0,
                        n["product_storage_volume"] // n["product_volume"][p],
                        f"fg:{s}:{w}:{p}",
                    )
                    for p in range(P)
                ]
            )
        for w in range(W):
            for j, supplier in enumerate(n["suppliers"]):
                volume = sum(
                    oq[w][j][r] * supplier["pack_units"][r] * n["raw_volume"][r]
                    for r in range(R)
                )
                m.add(volume >= supplier["minimum_volume"] * ty[w][j])
                m.add(volume <= sc["supplier_capacity_volume"][w][j] * ty[w][j])
            for f in range(F):
                m.add(
                    sum(px[w][f][p] * n["production_hours"][p] for p in range(P))
                    <= sc["plant_capacity_hours"][w][f]
                )
            made = [sum(px[w][f][p] for f in range(F)) for p in range(P)]
            available = []
            for r in range(R):
                arrivals = sum(
                    oq[w - supplier["lead_weeks"]][j][r] * supplier["pack_units"][r]
                    for j, supplier in enumerate(n["suppliers"])
                    if w >= supplier["lead_weeks"]
                )
                available.append(
                    (rv[w - 1][r] if w else n["initial_raw"][r]) + arrivals
                )
                m.add(
                    rv[w][r]
                    == available[r] - sum(made[p] * n["bom"][p][r] for p in range(P))
                )
            m.add(
                sum(available[r] * n["raw_volume"][r] for r in range(R))
                <= n["raw_storage_volume"]
            )
            fgpeak = []
            for p in range(P):
                fgpeak.append(
                    (fv[w - 1][p] if w else n["initial_products"][p]) + made[p]
                )
                m.add(fv[w][p] == fgpeak[p] - sc["demand"][w][p])
                if w == W - 1:
                    m.add(fv[w][p] == 0)
            m.add(
                sum(fgpeak[p] * n["product_volume"][p] for p in range(P))
                <= n["product_storage_volume"]
            )
            expenditure = (
                sum(
                    oq[w][j][r] * sup["pack_units"][r] * sup["price_minor"][r]
                    for j, sup in enumerate(n["suppliers"])
                    for r in range(R)
                )
                + sum(
                    ty[w][j] * sup["freight_minor"]
                    for j, sup in enumerate(n["suppliers"])
                )
                + sum(
                    px[w][f][p] * n["production_cost_minor"][f][p]
                    for f in range(F)
                    for p in range(P)
                )
                + sum(rv[w][r] * n["raw_holding_minor"][r] for r in range(R))
                + sum(fv[w][p] * n["product_holding_minor"][p] for p in range(P))
            )
            weekly_cost.append(expenditure)
            lag = n["receipt_lag_weeks"]
            collected = sum(
                sc["demand"][t][p] * n["sales_price_minor"][p]
                for t in range(max(0, w - lag + 1))
                for p in range(P)
            )
            m.add(
                sum(weekly_cost)
                <= n["initial_cash_minor"]
                + collected
                + (0 if w == W - 1 else n["credit_limit_minor"])
            )
        costs.append(sc["probability_numerator"] * sum(weekly_cost))
        allvars.append((oq, ty, px))
        inventories[s] = (rv, fv)
    m.minimize(sum(costs))
    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = seconds
    solver.parameters.num_search_workers = workers
    solver.parameters.random_seed = 20261029
    solver.parameters.relative_gap_limit = 0.001

    class Progress(cp_model.CpSolverSolutionCallback):
        def on_solution_callback(self):
            print(
                json.dumps(
                    {
                        "event": "incumbent",
                        "solver_elapsed_seconds": self.wall_time,
                        "objective_minor": self.objective_value
                        / n["probability_denominator"],
                        "best_bound_minor": self.best_objective_bound
                        / n["probability_denominator"],
                    }
                ),
                flush=True,
            )

    start = time.perf_counter()
    status = solver.solve(m, Progress())
    elapsed = time.perf_counter() - start
    if status not in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        raise RuntimeError(
            f"solver produced no policy: {solver.status_name(status)}; {solver.response_stats()}"
        )
    plan = {"format": "l06-plan/1", "decisions": {}}

    def values(arr):
        return [values(v) for v in arr] if isinstance(arr, list) else solver.value(arr)

    for s, sc in enumerate(n["scenarios"]):
        oq, ty, px = allvars[s]
        plan["decisions"][sc["id"]] = dict(
            order_lots=values(oq), truck_on=values(ty), production=values(px)
        )
    denominator = n["probability_denominator"]
    stats = dict(
        status=solver.status_name(status),
        objective_minor=solver.objective_value / denominator,
        best_bound_minor=solver.best_objective_bound / denominator,
        elapsed_seconds=elapsed,
        response_stats=solver.response_stats(),
        parameters={
            "max_time_in_seconds": seconds,
            "num_search_workers": workers,
            "random_seed": 20261029,
            "relative_gap_limit": 0.001,
        },
    )
    return plan, stats
