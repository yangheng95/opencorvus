"""Package only the explicitly scoped source, public inputs, outputs and test evidence."""

from pathlib import Path
import zipfile


def collect(root):
    names = [
        "reproduce.py",
        "l06_data.py",
        "l06_optimize.py",
        "l06_simulate.py",
        "l06_report.py",
        "test_l06.py",
        "test_controls.py",
        "verify_delivery.py",
        "package_delivery.py",
        "requirements.txt",
        "README.md",
        "TASK.md",
        "DATA.md",
        "OUTPUTS.md",
        "ENVIRONMENT.md",
        "SOURCE.md",
        "profile.json",
        "verification/main-check.json",
        "verification/unit-tests.txt",
        "verification/controls/results.json",
    ]
    files = [root / name for name in names]
    for directory in ("inputs", "output", "verification/controls"):
        for path in (root / directory).rglob("*"):
            if (
                path.is_file()
                and "__pycache__" not in path.parts
                and path.suffix in {".py", ".json", ".csv", ".md", ".png", ".txt"}
            ):
                files.append(path)
    files = sorted(set(files))
    if not all(path.is_file() for path in files):
        raise ValueError("Required deliverable/evidence file is missing")
    for name in (
        "reproduce.py",
        "l06_data.py",
        "l06_optimize.py",
        "l06_simulate.py",
        "l06_report.py",
    ):
        if (root / name).read_bytes() != (
            root / "verification/controls/cold-source" / name
        ).read_bytes():
            raise ValueError(f"Cold controls did not run the submitted source: {name}")
    return files


def main():
    root = Path(__file__).resolve().parent
    files = collect(root)
    destination = root / "l06-delivery.zip"
    with zipfile.ZipFile(destination, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in files:
            archive.write(path, path.relative_to(root).as_posix())
    with zipfile.ZipFile(destination) as archive:
        expected = {path.relative_to(root).as_posix(): path for path in files}
        assert set(archive.namelist()) == set(expected)
        for name, path in expected.items():
            assert archive.read(name) == path.read_bytes(), (
                f"Archive content differs: {name}"
            )
    print(f"Packaged and byte-compared {len(files)} scoped files: {destination.name}")


if __name__ == "__main__":
    main()
