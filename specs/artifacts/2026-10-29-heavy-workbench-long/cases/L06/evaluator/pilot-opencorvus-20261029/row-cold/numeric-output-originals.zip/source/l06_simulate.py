"""Exact procedural accounts. Does not import or inspect the solver model."""

from fractions import Fraction


def rational(value):
    value = Fraction(value)
    return {"numerator": value.numerator, "denominator": value.denominator}


def simulate(n, plan, strict=True):
    W, R, P, F, S = (
        n["weeks"],
        len(n["raw_materials"]),
        len(n["products"]),
        len(n["plants"]),
        len(n["suppliers"]),
    )
    violations = []

    def check(condition, sc, w, rule, actual=None, limit=None):
        if not condition:
            violations.append(
                {
                    "scenario": sc,
                    "week": w,
                    "rule": rule,
                    "actual": actual,
                    "limit": limit,
                }
            )

    def shape(value, dims, binary=False):
        if not dims:
            return type(value) is int and value >= 0 and (not binary or value <= 1)
        return (
            isinstance(value, list)
            and len(value) == dims[0]
            and all(shape(v, dims[1:], binary) for v in value)
        )

    if plan.get("format") != "l06-plan/1" or set(plan.get("decisions", {})) != {
        s["id"] for s in n["scenarios"]
    }:
        raise ValueError("invalid plan format/scenario identities")
    for sc in n["scenarios"]:
        d = plan["decisions"][sc["id"]]
        for key, dims, binary in [
            ("order_lots", [W, S, R], False),
            ("truck_on", [W, S], True),
            ("production", [W, F, P], False),
        ]:
            if not shape(d.get(key), dims, binary):
                raise ValueError(f"{sc['id']}:{key}: invalid shape/integer domain")
            reference = plan["decisions"][n["scenarios"][0]["id"]][key]
            check(
                d[key][: n["common_weeks"]] == reference[: n["common_weeks"]],
                sc["id"],
                None,
                "nonanticipativity",
            )
    ledger = {"format": "l06-ledger/1", "scenarios": {}}
    summary = {"format": "l06-summary/1", "scenarios": {}}
    expected = Fraction(0)
    for sc in n["scenarios"]:
        identity = sc["id"]
        d = plan["decisions"][identity]
        raw, finished = n["initial_raw"][:], n["initial_products"][:]
        cash = n["initial_cash_minor"]
        pipeline = [[0] * R for _ in range(W)]
        rows = []
        sales = [
            sum(a * b for a, b in zip(row, n["sales_price_minor"]))
            for row in sc["demand"]
        ]
        for w in range(W):
            orders, switches, production = (
                d["order_lots"][w],
                d["truck_on"][w],
                d["production"][w],
            )
            purchase, freight, volumes = 0, 0, []
            for j, supplier in enumerate(n["suppliers"]):
                units = [orders[j][r] * supplier["pack_units"][r] for r in range(R)]
                volume = sum(units[r] * n["raw_volume"][r] for r in range(R))
                volumes.append(volume)
                check(
                    supplier["minimum_volume"] * switches[j]
                    <= volume
                    <= sc["supplier_capacity_volume"][w][j] * switches[j],
                    identity,
                    w,
                    f"supplier_shared_volume:{supplier['id']}",
                    volume,
                    [
                        supplier["minimum_volume"] * switches[j],
                        sc["supplier_capacity_volume"][w][j] * switches[j],
                    ],
                )
                arrival = w + supplier["lead_weeks"]
                check(
                    not any(units) or arrival < W,
                    identity,
                    w,
                    "late_order",
                    arrival,
                    W - 1,
                )
                if arrival < W:
                    for r in range(R):
                        pipeline[arrival][r] += units[r]
                purchase += sum(units[r] * supplier["price_minor"][r] for r in range(R))
                freight += supplier["freight_minor"] * switches[j]
            arrivals = pipeline[w]
            raw = [raw[r] + arrivals[r] for r in range(R)]
            raw_peak = sum(raw[r] * n["raw_volume"][r] for r in range(R))
            check(
                raw_peak <= n["raw_storage_volume"],
                identity,
                w,
                "raw_stage_storage",
                raw_peak,
                n["raw_storage_volume"],
            )
            hours = [
                sum(production[f][p] * n["production_hours"][p] for p in range(P))
                for f in range(F)
            ]
            for f in range(F):
                check(
                    hours[f] <= sc["plant_capacity_hours"][w][f],
                    identity,
                    w,
                    f"line_hours:{n['plants'][f]}",
                    hours[f],
                    sc["plant_capacity_hours"][w][f],
                )
                for p in range(P):
                    check(
                        n["allowed"][f][p] or production[f][p] == 0,
                        identity,
                        w,
                        f"route:{f}:{p}",
                        production[f][p],
                        0,
                    )
            made = [sum(production[f][p] for f in range(F)) for p in range(P)]
            consumption = [
                sum(made[p] * n["bom"][p][r] for p in range(P)) for r in range(R)
            ]
            raw = [raw[r] - consumption[r] for r in range(R)]
            check(min(raw) >= 0, identity, w, "raw_nonnegative", raw, 0)
            finished = [finished[p] + made[p] for p in range(P)]
            product_peak = sum(finished[p] * n["product_volume"][p] for p in range(P))
            check(
                product_peak <= n["product_storage_volume"],
                identity,
                w,
                "product_stage_storage",
                product_peak,
                n["product_storage_volume"],
            )
            finished = [finished[p] - sc["demand"][w][p] for p in range(P)]
            check(min(finished) >= 0, identity, w, "delivery_no_backlog", finished, 0)
            production_cost = sum(
                production[f][p] * n["production_cost_minor"][f][p]
                for f in range(F)
                for p in range(P)
            )
            holding = sum(raw[r] * n["raw_holding_minor"][r] for r in range(R)) + sum(
                finished[p] * n["product_holding_minor"][p] for p in range(P)
            )
            cost = purchase + freight + production_cost + holding
            lag = n["receipt_lag_weeks"]
            receipts = sales[w - lag] if w >= lag else 0
            cash += receipts - cost
            check(
                cash >= -n["credit_limit_minor"],
                identity,
                w,
                "credit",
                cash,
                -n["credit_limit_minor"],
            )
            receivable = sum(sales[max(0, w - lag + 1) : w + 1])
            row = dict(
                week=w,
                order_lots=orders,
                truck_on=switches,
                production=production,
                arrivals=arrivals,
                consumption=consumption,
                raw_inventory=raw[:],
                made=made,
                finished_inventory=finished[:],
                hours=hours,
                supplier_volume=volumes,
                raw_stage_peak_volume=raw_peak,
                product_stage_peak_volume=product_peak,
                purchase_cost=purchase,
                freight_cost=freight,
                production_cost=production_cost,
                holding_cost=holding,
                cost=cost,
                receipts=receipts,
                cash=cash,
                receivable=receivable,
            )
            rows.append(row)
            for field, actual in [
                ("raw_inventory", raw),
                ("finished_inventory", finished),
            ]:
                if field in d:
                    check(d[field][w] == actual, identity, w, f"reported_{field}")
        check(
            finished == [0] * P, identity, W - 1, "terminal_finished", finished, [0] * P
        )
        check(cash >= 0, identity, W - 1, "terminal_cash", cash, 0)
        total = sum(row["cost"] for row in rows)
        prob = Fraction(sc["probability_numerator"], n["probability_denominator"])
        expected += prob * total
        ledger["scenarios"][identity] = {"weeks": rows}
        summary["scenarios"][identity] = dict(
            probability=rational(prob),
            total_cost_minor=total,
            minimum_cash_minor=min(row["cash"] for row in rows),
            final_cash_minor=cash,
            final_receivable_minor=receivable,
        )
    summary["expected_cost_minor"] = rational(expected)
    if strict and violations:
        raise ValueError(f"policy infeasible: {violations[:5]}")
    return ledger, summary, violations
