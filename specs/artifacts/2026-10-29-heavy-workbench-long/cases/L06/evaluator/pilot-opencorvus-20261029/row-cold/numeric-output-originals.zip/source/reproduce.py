"""Thin command-line entry point; never consumes existing solutions."""

import argparse
import copy
import importlib.metadata
import json
from pathlib import Path
import platform
import sys
import time

from l06_data import load
from l06_optimize import solve
from l06_simulate import simulate
from l06_report import generate


def write(out, name, value):
    (out / name).write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )


def alternative_policy(n, plan):
    # Prefer a higher-cost route: demonstrate the economic price of freeing line hours.
    for w in reversed(range(n["common_weeks"], n["weeks"])):
        for sc in n["scenarios"]:
            identity = sc["id"]
            for f in range(len(n["plants"])):
                for g in range(len(n["plants"])):
                    for p in range(len(n["products"])):
                        if (
                            f == g
                            or not n["allowed"][g][p]
                            or n["production_cost_minor"][g][p]
                            <= n["production_cost_minor"][f][p]
                            or not plan["decisions"][identity]["production"][w][f][p]
                        ):
                            continue
                        candidate = copy.deepcopy(plan)
                        candidate["decisions"][identity]["production"][w][f][p] -= 1
                        candidate["decisions"][identity]["production"][w][g][p] += 1
                        ledger, summary, errors = simulate(n, candidate, strict=False)
                        if not errors:
                            summary["change"] = {
                                "scenario": identity,
                                "week": w,
                                "product": n["products"][p],
                                "units": 1,
                                "from_line": n["plants"][f],
                                "to_line": n["plants"][g],
                                "extra_production_cost_minor": n[
                                    "production_cost_minor"
                                ][g][p]
                                - n["production_cost_minor"][f][p],
                            }
                            return candidate, ledger, summary
    raise RuntimeError("No verified higher-cost line-reallocation alternative found")


def baseline_policy(n, plan):
    candidate = copy.deepcopy(plan)
    for sc in n["scenarios"]:
        initial = n["initial_products"][:]
        for w in range(n["weeks"]):
            prod = [[0] * len(n["products"]) for _ in n["plants"]]
            for p in range(len(n["products"])):
                amount = max(0, sc["demand"][w][p] - initial[p])
                initial[p] = max(0, initial[p] - sc["demand"][w][p])
                f = min(
                    (f for f in range(len(n["plants"])) if n["allowed"][f][p]),
                    key=lambda f: n["production_cost_minor"][f][p],
                )
                prod[f][p] = amount
            candidate["decisions"][sc["id"]]["production"][w] = prod
    _, _, errors = simulate(n, candidate, strict=False)
    return candidate, {
        "definition": "same procurement; cheapest allowed route; produce only current net demand; no advance production",
        "feasible": not errors,
        "violations": errors,
        "feasible_cost_minor": None,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--seconds", type=float, default=1800)
    parser.add_argument("--workers", type=int, default=8)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output directory must not exist")
    if args.seconds <= 0 or args.workers <= 0:
        parser.error("positive seconds/workers required")
    start = time.perf_counter()
    n, mapping = load(args.input)
    args.output.mkdir(parents=True)
    write(args.output, "normalized.json", n)
    write(args.output, "source-map.json", mapping)
    plan, stats = solve(n, args.seconds, args.workers)
    ledger, summary, _ = simulate(n, plan)
    ap, al, asu = alternative_policy(n, plan)
    bp, bc = baseline_policy(n, plan)
    for name, value in [
        ("plan.json", plan),
        ("ledger.json", ledger),
        ("summary.json", summary),
        ("alternative-plan.json", ap),
        ("alternative-ledger.json", al),
        ("alternative-summary.json", asu),
        ("baseline-plan.json", bp),
        ("baseline-check.json", bc),
    ]:
        write(args.output, name, value)
    generate(args.output, n, plan, ledger, summary, asu, bc, stats)
    exact_optimal = stats["objective_minor"] == stats["best_bound_minor"]
    run = {
        "format": "l06-run/1",
        "input_path": str(args.input),
        "command": [sys.executable, *sys.argv],
        "dependencies": {
            "python": platform.python_version(),
            **{
                k: importlib.metadata.version(k)
                for k in ("ortools", "numpy", "matplotlib")
            },
        },
        "parameters": stats["parameters"],
        "algorithm": {
            "name": "joint scenario CP-SAT with independent exact simulation",
            "termination_kind": "completed"
            if stats["status"] == "OPTIMAL"
            else "resource_limit",
            "termination_detail": "native optimal status (may be gap-limit termination)"
            if stats["status"] == "OPTIMAL"
            else "native FEASIBLE at configured time limit",
        },
        "native_solver": {
            "name": "OR-Tools CP-SAT",
            "version": importlib.metadata.version("ortools"),
            **{k: stats[k] for k in ("status", "objective_minor", "best_bound_minor")},
        },
        "feasibility": "feasible",
        "exact_optimal_claim": exact_optimal,
        "solver_wall_seconds": stats["elapsed_seconds"],
        "total_wall_seconds": time.perf_counter() - start,
        "subagents": False,
        "solver_response_stats": stats["response_stats"],
    }
    write(args.output, "run.json", run)
    write(
        args.output,
        "manifest.json",
        {
            "format": "l06-manifest/1",
            "outputs": {
                k: k + ext
                for k, ext in [
                    ("normalized", ".json"),
                    ("plan", ".json"),
                    ("ledger", ".json"),
                    ("summary", ".json"),
                    ("run", ".json"),
                    ("report", ".md"),
                ]
            },
            "reproduce_command": [sys.executable, *sys.argv],
            "supplementary": [
                "source-map.json",
                "weekly.csv",
                "operations.png",
                "costs.png",
                "alternative-plan.json",
                "alternative-ledger.json",
                "alternative-summary.json",
                "baseline-plan.json",
                "baseline-check.json",
            ],
            "report_sources": [
                "normalized.json",
                "plan.json",
                "ledger.json",
                "summary.json",
                "baseline-check.json",
                "alternative-summary.json",
            ],
        },
    )
    print(
        json.dumps(
            {"output": str(args.output), "summary": summary, "solver": stats},
            ensure_ascii=False,
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
