"""Compile UTF-8 business tables using explicit catalog identities."""

import csv
import itertools
import json
import re
from pathlib import Path


class InputError(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise InputError(message)


def integer(value, label, minimum=0):
    require(
        isinstance(value, str) and re.fullmatch(r"0|[1-9][0-9]*", value),
        f"{label}: expected canonical nonnegative integer, got {value!r}",
    )
    result = int(value)
    require(minimum <= result <= 10**12, f"{label}: value outside supported range")
    return result


def load(directory):
    root = Path(directory)
    mapping = {}

    def table(name, keys, numeric, expected=None):
        with (root / name).open(encoding="utf-8", newline="") as stream:
            reader = csv.DictReader(stream)
            fields = list(keys) + list(numeric)
            require(
                reader.fieldnames is not None
                and len(reader.fieldnames) == len(fields)
                and set(reader.fieldnames) == set(fields),
                f"{name}: invalid columns",
            )
            records = {}
            for line, row in enumerate(reader, 2):
                require(
                    None not in row and all(v is not None for v in row.values()),
                    f"{name}:{line}: malformed record",
                )
                key = tuple(row[k] for k in keys)
                require(
                    all(key) and key not in records,
                    f"{name}:{line}: empty/duplicate identity {key}",
                )
                for field, minimum in numeric.items():
                    row[field] = integer(row[field], f"{name}:{line}:{field}", minimum)
                records[key] = row
            if expected is not None:
                expected = set(expected)
                require(
                    set(records) == expected,
                    f"{name}: missing {sorted(expected - set(records))}; unexpected {sorted(set(records) - expected)}",
                )
        mapping[name] = {
            "identity": list(keys),
            "numeric_fields": numeric,
            "rows": len(records),
        }
        return records

    def catalog(name, prefix, attrs):
        idx, identity = prefix + "_index", prefix + "_id"
        rows = list(table(name, [identity], {idx: 0, **attrs}).values())
        rows.sort(key=lambda row: row[idx])
        require(
            [r[idx] for r in rows] == list(range(len(rows))) and bool(rows),
            f"{name}: indices must be unique contiguous 0..n-1",
        )
        return rows, [r[identity] for r in rows]

    raw, rid = catalog(
        "raw_materials.csv",
        "raw",
        {"volume": 1, "holding_minor": 0, "initial_units": 0},
    )
    products, pid = catalog(
        "products.csv",
        "product",
        {
            "volume": 1,
            "holding_minor": 0,
            "initial_units": 0,
            "hours": 1,
            "sales_price_minor": 0,
        },
    )
    plants, fid = catalog("plants.csv", "plant", {})
    suppliers, sid = catalog(
        "supplier_terms.csv",
        "supplier",
        {"lead_weeks": 0, "freight_minor": 0, "minimum_volume": 0},
    )
    scenarios, scid = catalog("scenarios.csv", "scenario", {"probability_numerator": 1})
    with (root / "facility.json").open(encoding="utf-8") as stream:

        def unique(pairs):
            obj = {}
            for k, v in pairs:
                require(k not in obj, f"facility.json: duplicate field {k}")
                obj[k] = v
            return obj

        facility = json.load(stream, object_pairs_hook=unique)
    fkeys = {
        "weeks",
        "common_weeks",
        "probability_denominator",
        "raw_storage_volume",
        "product_storage_volume",
        "initial_cash_minor",
        "credit_limit_minor",
        "receipt_lag_weeks",
    }
    require(
        set(facility) == fkeys | {"format"}
        and facility["format"] == "l06-operational-facts/1",
        "facility.json: invalid fields/format",
    )
    for k in fkeys:
        require(type(facility[k]) is int, f"facility.json:{k}: integer required")
        integer(
            str(facility[k]),
            f"facility.json:{k}",
            1 if k in {"weeks", "probability_denominator", "receipt_lag_weeks"} else 0,
        )
    W = facility["weeks"]
    require(facility["common_weeks"] <= W, "common_weeks exceeds horizon")
    require(
        sum(s["probability_numerator"] for s in scenarios)
        == facility["probability_denominator"],
        "probabilities do not sum to one",
    )
    quotes = table(
        "supplier_quotes.csv",
        ["supplier_id", "raw_id"],
        {"pack_units": 1, "unit_price_minor": 0},
        itertools.product(sid, rid),
    )
    routes = table(
        "routes.csv",
        ["plant_id", "product_id"],
        {"allowed": 0, "production_cost_minor": 0},
        itertools.product(fid, pid),
    )
    require(
        all(r["allowed"] in (0, 1) for r in routes.values()),
        "routes.csv: allowed must be 0/1",
    )
    bom = table(
        "bom.csv", ["product_id", "raw_id"], {"units": 0}, itertools.product(pid, rid)
    )
    weeks = list(map(str, range(W)))
    demand = table(
        "demand.csv",
        ["scenario_id", "week", "product_id"],
        {"units": 0},
        itertools.product(scid, weeks, pid),
    )
    supply = table(
        "supplier_capacity.csv",
        ["scenario_id", "week", "supplier_id"],
        {"volume": 0},
        itertools.product(scid, weeks, sid),
    )
    capacity = table(
        "plant_capacity.csv",
        ["scenario_id", "week", "plant_id"],
        {"hours": 0},
        itertools.product(scid, weeks, fid),
    )
    n = {
        "format": "l06-feasibility-instance/2",
        **{k: facility[k] for k in fkeys},
        "raw_materials": rid,
        "products": pid,
        "plants": fid,
        "raw_volume": [r["volume"] for r in raw],
        "raw_holding_minor": [r["holding_minor"] for r in raw],
        "initial_raw": [r["initial_units"] for r in raw],
        "product_volume": [r["volume"] for r in products],
        "product_holding_minor": [r["holding_minor"] for r in products],
        "initial_products": [r["initial_units"] for r in products],
        "production_hours": [r["hours"] for r in products],
        "sales_price_minor": [r["sales_price_minor"] for r in products],
        "allowed": [[routes[f, p]["allowed"] for p in pid] for f in fid],
        "production_cost_minor": [
            [routes[f, p]["production_cost_minor"] for p in pid] for f in fid
        ],
        "bom": [[bom[p, r]["units"] for r in rid] for p in pid],
        "suppliers": [],
        "scenarios": [],
    }
    for row, s in zip(suppliers, sid):
        n["suppliers"].append(
            {
                "id": s,
                **{
                    k: row[k] for k in ("lead_weeks", "freight_minor", "minimum_volume")
                },
                "pack_units": [quotes[s, r]["pack_units"] for r in rid],
                "price_minor": [quotes[s, r]["unit_price_minor"] for r in rid],
            }
        )
    for row, s in zip(scenarios, scid):
        n["scenarios"].append(
            {
                "id": s,
                "probability_numerator": row["probability_numerator"],
                "demand": [
                    [demand[s, str(w), p]["units"] for p in pid] for w in range(W)
                ],
                "supplier_capacity_volume": [
                    [supply[s, str(w), j]["volume"] for j in sid] for w in range(W)
                ],
                "plant_capacity_hours": [
                    [capacity[s, str(w), f]["hours"] for f in fid] for w in range(W)
                ],
            }
        )
    for sc in n["scenarios"][1:]:
        for field in ("demand", "supplier_capacity_volume", "plant_capacity_hours"):
            require(
                sc[field][: n["common_weeks"]]
                == n["scenarios"][0][field][: n["common_weeks"]],
                f"{sc['id']}:{field}: common information differs",
            )
    # Keep all arithmetic well within the solver's signed integer representation.
    largest = max(
        [1] + [v for sc in n["scenarios"] for row in sc["demand"] for v in row]
    )
    prices = max([1] + [v for s in n["suppliers"] for v in s["price_minor"]])
    require(
        largest
        * prices
        * W
        * len(pid)
        * max(1, max(sum(row) for row in n["bom"]))
        * n["probability_denominator"]
        < 10**15,
        "numeric_range: input exceeds supported model arithmetic",
    )
    return n, mapping
