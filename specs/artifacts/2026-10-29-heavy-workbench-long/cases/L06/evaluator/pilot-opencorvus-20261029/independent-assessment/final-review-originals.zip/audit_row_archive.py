"""Correct the reviewer's suffix-uniqueness assumption; compare both real archive namespaces."""
import json
from pathlib import Path
import zipfile
ROOT=Path(__file__).resolve().parent
BASE=Path('D:/opencorvus-benchmark-runs/L06-paired-20261029-be2a55d1/opencorvus/evaluation/row-cold')
OUT=ROOT/'row-cold-addendum'
with zipfile.ZipFile(BASE/'completed-originals.zip') as z:
    members=z.namelist();comparisons=[]
    for p in (BASE/'results/row').iterdir():
        if p.is_file():
            for prefix in ('results/row/','snapshot/results/row/'):
                name=prefix+p.name
                comparisons.append({'member':name,'actual_file':str(p),'direct_bytes_equal':z.read(name)==p.read_bytes()})
result={'scope':'actual archive namespace binding only, no functional rerun','all_passed':all(v['direct_bytes_equal'] for v in comparisons),'direct_comparisons':len(comparisons),'comparisons':comparisons,
 'initial_review_error':'Both snapshot/results/row/name and results/row/name exist. Initial reviewer treated >1 suffix match as failure without comparing bytes. That was an auditor locator assumption, not a candidate or archive content error. Original receipt retained.',
 'archive_members':members}
(OUT/'archive-binding-correction.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
initial=json.loads((OUT/'stage-assessment.json').read_text(encoding='utf-8'));business=[v for v in json.loads((OUT/'checks.json').read_text(encoding='utf-8')) if v['name']!='sealed_new_result_members_exact']
current=initial|{'all_passed':all(v['passed'] for v in business) and result['all_passed'],'failed':[],'business_checks':len(business),'corrected_archive_comparisons':len(comparisons),'initial_archive_locator_assumption':'historical first checks/stage retained; corrected evidence in archive-binding-correction.json'}
(OUT/'stage-assessment-current.json').write_text(json.dumps(current,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'business15_passed':all(v['passed'] for v in business),'archive32_comparisons_passed':result['all_passed'],'current_all_passed':current['all_passed']},ensure_ascii=False))
