"""Read-only, standard-library delivered-artifact audit; never starts an optimizer."""
import ast
from collections import Counter
import csv
from datetime import datetime, timezone
from fractions import Fraction
from itertools import product
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
REPO = Path('D:/myhexin-local/opencorvus')
CASE = REPO/'specs/artifacts/2026-10-29-heavy-workbench-long/cases/L06'
RUN = Path('D:/opencorvus-benchmark-runs/L06-paired-20261029-be2a55d1/opencorvus')
SUB = RUN/'completed/submission'

def load(p): return json.loads(p.read_text(encoding='utf-8'))
def save(p, v):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(v, ensure_ascii=False, indent=2, allow_nan=False)+'\n', encoding='utf-8')

def extract(source, names, destination, globals_):
    raw=source.read_text(encoding='utf-8')
    tree=ast.parse(raw)
    nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
    assert len(nodes)==len(names)
    text='\n\n'.join(ast.get_source_segment(raw,n) for n in nodes)+'\n'
    destination.write_text(text,encoding='utf-8')
    exec(compile(ast.Module(body=nodes,type_ignores=[]),str(destination),'exec'),globals_)

def main():
    start=time.perf_counter()
    snap=ROOT/'snapshot-initial';snap.mkdir(exist_ok=False)
    inventory=[]
    def copy(src,dst):
        dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
        inventory.append({'source':str(src),'copy':str(dst.relative_to(ROOT)),'bytes':dst.stat().st_size,'byte_equal':src.read_bytes()==dst.read_bytes()})
    for p in SUB.glob('*.py'):copy(p,snap/'candidate-source'/p.name)
    for name in ('README.md','DATA.md','ENVIRONMENT.md','OUTPUTS.md','SOURCE.md','TASK.md','profile.json','requirements.txt'):
        copy(SUB/name,snap/'candidate-source'/name)
    for p in (SUB/'inputs').iterdir():
        if p.is_file():copy(p,snap/'candidate-inputs'/p.name)
    for p in (SUB/'output').iterdir():
        if p.is_file():copy(p,snap/'delivery'/p.name)
    for name in ('rubric.json','FREEZE.json','evaluator/GRADING.md'):
        copy(CASE/name,snap/'frozen-case'/name)
    for p in (CASE/'public').glob('*.md'):copy(p,snap/'frozen-case/public'/p.name)
    for p in (CASE/'public/inputs').iterdir():
        if p.is_file():copy(p,snap/'frozen-case/public/inputs'/p.name)
    for name in ('seal-receipt.json','usage-summary.json','l06-final-main-inspect.json'):
        copy(RUN/'completed'/name,snap/'external-receipts'/name)
    copy(RUN/'evaluation/delivered-numeric/assessment.json',snap/'external-receipts/delivered-numeric.json')
    copy(RUN/'evaluation/base-cold/launch.json',snap/'external-receipts/base-cold-launch.json')
    for name in ('verification/main-check.json','verification/unit-tests.txt','verification/controls/results.json'):
        copy(SUB/name,snap/'candidate-evidence'/name)
    save(ROOT/'snapshot-inventory.json',inventory)
    s=subprocess.run(['git','status','--short'],cwd=REPO,capture_output=True,text=True,encoding='utf-8')
    (ROOT/'git-status-start.txt').write_text(s.stdout,encoding='utf-8')
    # These are this independent reviewer's previously authored arithmetic functions.
    # Extract only pure functions; none of their older CLI/solver orchestration runs.
    extract(Path('D:/opencorvus-benchmark-runs/l06-public-contract-independent-review-20261029/review_packet.py'),
       ['table','independent_projection'],ROOT/'independent_projection.py',globals())
    extract(Path('D:/opencorvus-benchmark-runs/l06-reference-independent-review-20261029/full-cold-replay/audit-tools/independent_math.py'),
       ['independent'],ROOT/'independent_business.py',globals())
    d,counts=independent_projection(snap/'frozen-case/public/inputs')
    candidate,cc=independent_projection(snap/'candidate-inputs')
    out=snap/'delivery';checks=[]
    def check(name,ok,detail=None):checks.append({'name':name,'passed':bool(ok),'detail':detail})
    check('candidate_inputs_same_complete_public_facts',candidate==d,counts)
    check('candidate_normalization_exact',load(out/'normalized.json')==d)
    save(ROOT/'independent-normalized.json',d)
    results={}
    for label,name in [('primary','plan.json'),('alternative','alternative-plan.json'),('baseline','baseline-plan.json')]:
        p=load(out/name);r=independent(d,p);results[label]=r
        save(ROOT/(label+'-independent.json'),{k:(str(v) if isinstance(v,Fraction) else v) for k,v in r.items()})
    a=results['primary'];alt=results['alternative'];baseline=results['baseline']
    check('primary_feasible',a['business_feasible']);check('alternative_feasible',alt['business_feasible'])
    check('primary_complete_ledger_exact',a['ledger']==load(out/'ledger.json'))
    check('primary_summary_exact',a['summary']==load(out/'summary.json'))
    als=load(out/'alternative-summary.json');als.pop('change')
    check('alternative_complete_ledger_exact',alt['ledger']==load(out/'alternative-ledger.json'))
    check('alternative_summary_exact',alt['summary']==als)
    check('primary_expected_cost',a['cost']==Fraction(476871,10),str(a['cost']))
    check('fixed_registered_quality',Fraction(47380)<=a['cost']<=Fraction(47380)*Fraction(101,100),
       {'L':47380,'gap_exact':str((a['cost']-47380)/47380)})
    check('baseline_actual_infeasible',not baseline['business_feasible'],baseline['violations'])
    # Independent construction of the declared baseline, including all zero actions.
    p=load(out/'plan.json');bp=load(out/'baseline-plan.json')
    import copy
    expected=copy.deepcopy(p)
    for sc in d['scenarios']:
        stock=d['initial_products'].copy()
        for w in range(d['weeks']):
            production=[[0]*len(d['products']) for _ in d['plants']]
            for j in range(len(d['products'])):
                units=max(0,sc['demand'][w][j]-stock[j]);stock[j]=max(0,stock[j]-sc['demand'][w][j])
                f=min((f for f in range(len(d['plants'])) if d['allowed'][f][j]),key=lambda f:d['production_cost_minor'][f][j])
                production[f][j]=units
            expected['decisions'][sc['id']]['production'][w]=production
    check('baseline_complete_controls_follow_declared_algorithm',expected==bp)
    first=d['scenarios'][0];hours=sum(bp['decisions'][first['id']]['production'][2][1][j]*d['production_hours'][j] for j in range(len(d['products'])))
    check('baseline_first_reported_violation',hours==26 and first['plant_capacity_hours'][2][1]==25)
    # Every necessary pre-stock claim in the report is independently arithmetic.
    claims=[]
    for sc in d['scenarios']:
        for t,j in [(6,0),(9,3)]:
            cap=sum(sc['plant_capacity_hours'][t][f]//d['production_hours'][j] for f in range(len(d['plants'])) if d['allowed'][f][j])
            need=sc['demand'][t][j]-cap
            stock=a['ledger']['scenarios'][sc['id']]['weeks'][t-1]['finished_inventory'][j]
            claims.append({'scenario':sc['id'],'week':t,'product':d['products'][j],'demand':sc['demand'][t][j],'upper':cap,'necessary':need,'actual_previous_inventory':stock})
    check('reported_preproduction_claims',[(r['demand'],r['upper'],r['necessary'],r['actual_previous_inventory']) for r in claims]==[(10,0,10,10),(4,3,1,1),(10,0,10,10),(4,3,1,1),(11,0,11,11),(5,3,2,2)],claims)
    # Compare the real alternative controls; no solver or candidate function called.
    ap=load(out/'alternative-plan.json');diffs=[]
    def walk(x,y,path):
        if isinstance(x,dict):
            for k in x:walk(x[k],y[k],path+[k])
        elif isinstance(x,list):
            for i,(u,v) in enumerate(zip(x,y)):walk(u,v,path+[i])
        elif x!=y:diffs.append({'path':path,'from':x,'to':y})
    walk(p,ap,[])
    check('alternative_route_and_exact_economic_tradeoff',len(diffs)==2 and diffs[0]['path']==['decisions','base','production',15,0,2] and diffs[1]['path']==['decisions','base','production',15,1,2] and diffs[0]['to']==diffs[0]['from']-1 and diffs[1]['to']==diffs[1]['from']+1 and alt['cost']-a['cost']==Fraction(3,2),diffs)
    parts={k:sum(Fraction(s['probability_numerator'],d['probability_denominator'])*sum(r[k] for r in a['ledger']['scenarios'][s['id']]['weeks']) for s in d['scenarios']) for k in ('purchase_cost','freight_cost','production_cost','holding_cost')}
    check('all_four_reported_expected_components',list(parts.values())==[Fraction(180908,5),Fraction(5298),Fraction(29007,5),Fraction(4061,10)] and sum(parts.values())==a['cost'],{k:str(v) for k,v in parts.items()})
    tight=[];disruption=[]
    for sc in d['scenarios']:
        rows=a['ledger']['scenarios'][sc['id']]['weeks'];t=min(range(len(rows)),key=lambda t:rows[t]['cash']);r=rows[t]
        tight.append({'scenario':sc['id'],'week':t,'cash':r['cash'],'receipts':r['receipts'],'cost':r['cost'],'receivable':r['receivable'],'raw_peak_max':max(v['raw_stage_peak_volume'] for v in rows),'fg_peak_max':max(v['product_stage_peak_volume'] for v in rows)})
    check('all_actual_tightest_cash_claims',all(r['week']==3 and r['cash']==-5369 and r['receipts']==0 and r['cost']==1980 and r['raw_peak_max']==191 for r in tight) and [r['fg_peak_max'] for r in tight]==[85,85,91],tight)
    for t in (6,7,8):
        sc=d['scenarios'][1];base=d['scenarios'][0]
        disruption.append({'week':t,'base_capacity':base['supplier_capacity_volume'][t][0],'current_capacity':sc['supplier_capacity_volume'][t][0],'MOQ':d['suppliers'][0]['minimum_volume'],'base_volume':a['ledger']['scenarios'][base['id']]['weeks'][t]['supplier_volume'][0],'current_volume':a['ledger']['scenarios'][sc['id']]['weeks'][t]['supplier_volume'][0]})
    check('interruption_choice_set_and_actual_actions',[(r['base_capacity'],r['current_capacity'],r['MOQ'],r['base_volume'],r['current_volume']) for r in disruption]==[(80,15,20,80,0),(80,15,20,80,0),(80,15,20,0,0)],disruption)
    weekly=[]
    for sc in d['scenarios']:
        for r in a['ledger']['scenarios'][sc['id']]['weeks']:
            weekly.append([sc['id'],str(r['week']),*[str(r[k]) for k in ('cash','receipts','cost','purchase_cost','freight_cost','production_cost','holding_cost','raw_stage_peak_volume','product_stage_peak_volume')],str(sum(r['finished_inventory']))])
    with (out/'weekly.csv').open(encoding='utf-8',newline='') as f:csvrows=list(csv.reader(f))
    check('all_48_plotted_weekly_rows_exact',csvrows[1:]==weekly)
    numeric=load(snap/'external-receipts/delivered-numeric.json')
    check('main_actual_numeric30_receipt',numeric['counts']['verified_pass']==30 and numeric['counts']['unassessed']==17 and numeric['total_score'] is None)
    save(ROOT/'checks-initial.json',checks)
    save(ROOT/'arithmetic-assessment.json',{'timestamp':datetime.now(timezone.utc).isoformat(),'checks':len(checks),'all_passed':all(r['passed'] for r in checks),'failed':[r['name'] for r in checks if not r['passed']],
       'cost_exact':str(a['cost']),'alternative_cost_exact':str(alt['cost']),'fixed_L':47380,'gap_relative_to_fixed_L_exact':str((a['cost']-47380)/47380),'purchase_share_exact':str(parts['purchase_cost']/a['cost']),
       'arithmetic_seconds':time.perf_counter()-start,'own_solver_calls':0,'own_Provider_calls':0,'own_Docker_calls':0,'total_score':None,'business_success':None,'review_scope':'delivered files and actual saved receipts; source-only execution leaves remain pending'})
    print(json.dumps(load(ROOT/'arithmetic-assessment.json'),ensure_ascii=False,indent=2))

if __name__=='__main__':main()
