def independent(d,plan):
    """Independent cumulative constraints; financial values only used when physical predicates hold."""
    violations=Counter();counts=Counter();led={'format':'l06-ledger/1','scenarios':{}};summary={'format':'l06-summary/1','scenarios':{}}
    T=d['weeks'];M=len(d['raw_materials']);J=len(d['products']);P=len(d['plants']);S=len(d['suppliers'])
    expected=Fraction();first=plan['decisions'][d['scenarios'][0]['id']]
    def predicate(family,ok):counts[family]+=1;violations[family]+=int(not ok)
    for s in d['scenarios']:
        sid=s['id'];a=plan['decisions'][sid];raw=d['initial_raw'].copy();fg=d['initial_products'].copy();cash=d['initial_cash_minor'];rows=[];total=collected=delivered=0
        for f in ('order_lots','truck_on','production'):predicate('B02',a[f][:d['common_weeks']]==first[f][:d['common_weeks']])
        for t in range(T):
            supplier_volume=[];purchasing=freight=0
            for k,rule in enumerate(d['suppliers']):
                z=a['truck_on'][t][k];volume=sum(a['order_lots'][t][k][m]*rule['pack_units'][m]*d['raw_volume'][m] for m in range(M))
                supplier_volume.append(volume)
                predicate('B03',z in (0,1));predicate('B04',volume>=rule['minimum_volume']*z)
                predicate('B05',volume<=s['supplier_capacity_volume'][t][k]*z)
                predicate('C04',t+rule['lead_weeks']<T or sum(a['order_lots'][t][k])==0)
                purchasing+=sum(a['order_lots'][t][k][m]*rule['pack_units'][m]*rule['price_minor'][m] for m in range(M))
                freight+=z*rule['freight_minor']
            arrivals=[sum(a['order_lots'][u][k][m]*d['suppliers'][k]['pack_units'][m] for u in range(T) for k in range(S) if u+d['suppliers'][k]['lead_weeks']==t) for m in range(M)]
            made=[sum(a['production'][t][p][j] for p in range(P)) for j in range(J)]
            hours=[];labor=0
            for p in range(P):
                for j in range(J):predicate('B06',d['allowed'][p][j] or a['production'][t][p][j]==0)
                h=sum(a['production'][t][p][j]*d['production_hours'][j] for j in range(J));hours.append(h)
                predicate('B07',h<=s['plant_capacity_hours'][t][p])
                labor+=sum(a['production'][t][p][j]*d['production_cost_minor'][p][j] for j in range(J))
            consumed=[sum(made[j]*d['bom'][j][m] for j in range(J)) for m in range(M)]
            rawpeak=sum((raw[m]+arrivals[m])*d['raw_volume'][m] for m in range(M))
            fgpeak=sum((fg[j]+made[j])*d['product_volume'][j] for j in range(J))
            predicate('B10',rawpeak<=d['raw_storage_volume']);predicate('B11',fgpeak<=d['product_storage_volume'])
            raw=[raw[m]+arrivals[m]-consumed[m] for m in range(M)];fg=[fg[j]+made[j]-s['demand'][t][j] for j in range(J)]
            predicate('B08',min(raw)>=0);predicate('B09',min(fg)>=0)
            holding=sum(raw[m]*d['raw_holding_minor'][m] for m in range(M))+sum(fg[j]*d['product_holding_minor'][j] for j in range(J))
            cost=purchasing+freight+labor+holding;total+=cost
            lagged=t-d['receipt_lag_weeks'];received=sum(s['demand'][lagged][j]*d['sales_price_minor'][j] for j in range(J)) if lagged>=0 else 0
            cash+=received-cost;collected+=received;delivered+=sum(s['demand'][t][j]*d['sales_price_minor'][j] for j in range(J))
            predicate('C03' if t==T-1 else 'C02',cash>=(0 if t==T-1 else -d['credit_limit_minor']))
            rows.append({'week':t,'order_lots':a['order_lots'][t],'truck_on':a['truck_on'][t],'production':a['production'][t],
                'arrivals':arrivals,'made':made,'consumption':consumed,'raw_inventory':raw.copy(),'finished_inventory':fg.copy(),'supplier_volume':supplier_volume,'hours':hours,
                'raw_stage_peak_volume':rawpeak,'product_stage_peak_volume':fgpeak,'purchase_cost':purchasing,'freight_cost':freight,'production_cost':labor,
                'holding_cost':holding,'cost':cost,'receipts':received,'cash':cash,'receivable':delivered-collected})
        predicate('C05',all(x==0 for x in fg));led['scenarios'][sid]={'weeks':rows}
        expected+=Fraction(total*s['probability_numerator'],d['probability_denominator'])
        summary['scenarios'][sid]={'probability':{'numerator':s['probability_numerator'],'denominator':d['probability_denominator']},'total_cost_minor':total,
           'minimum_cash_minor':min(r['cash'] for r in rows),'final_cash_minor':cash,'final_receivable_minor':delivered-collected}
    summary['expected_cost_minor']={'numerator':expected.numerator,'denominator':expected.denominator}
    status={i:'verified_fail' if violations[i] else 'verified_pass' for i in ('B02','B03','B04','B05','B06','B07','B08','B09','B10','B11','C04','C05')}
    if status['B03']!='verified_pass':status['B04']=status['B05']='blocked_candidate'
    physical=all(v=='verified_pass' for v in status.values())
    for i in ('C02','C03'):status[i]=('verified_fail' if violations[i] else 'verified_pass') if physical else 'blocked_candidate'
    feasible=physical and status['C02']==status['C03']=='verified_pass'
    return {'physical_statuses':status,'violations':dict(violations),'predicate_counts':dict(counts),'business_feasible':feasible,
        'ledger':led if feasible else None,'summary':summary if feasible else None,'cost':expected if feasible else None}
