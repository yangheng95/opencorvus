import json
from pathlib import Path
import subprocess
ROOT=Path(__file__).resolve().parent
def load(p):return json.loads(p.read_text(encoding='utf-8'))
result=load(ROOT/'quote-cold-addendum/stage-assessment.json')
evidence={'format':'l06-d02-component-evidence/1','component':'registered_quote_C_R0_plus1','component_execution_verified':result['all_passed'],'D02_judgement':'unassessed','remaining':'actual same-source row-order execution and independent numeric binding not yet supplied',
 'rater':'/root/benchmark_review; nonblind AI agent familiar with benchmark/reference; no further delegation','actual_cost':result['exact_cost'],'reference_id':result['reference_id'],'registered_L':result['registered_L'],'gap_exact':result['relative_gap_exact'],
 'evidence':[{'path':'quote-cold-addendum/receipts/terminal-inspect.json','kind':'process_receipt','observation':'Actual quote source-only invocation naturally exited0 with readonly mounts and original defaults'},
 {'path':'quote-cold-addendum/checks.json','kind':'business_oracle','observation':'Exact unique registered raw price change, full quote main/alternate business ledger, fixed-L quality and actual numeric30 independently verified'},
 {'path':'SOURCE-AUDIT.md','kind':'source_audit','observation':'Inspected actual source rebuilds from supplied raw; quote checks bind9sources exactly to sealed candidate'}],
 'total_score':None,'business_success':None,'good':None,'new_reviewer_solver_Docker_Provider_calls':0}
(ROOT/'D02-quote-component-evidence.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
status=subprocess.run(['git','status','--short'],cwd='D:/myhexin-local/opencorvus',capture_output=True,text=True,encoding='utf-8');(ROOT/'git-status-end.txt').write_text(status.stdout,encoding='utf-8')
print(json.dumps({'quote_component_verified':evidence['component_execution_verified'],'D02':'unassessed','total_score':None},ensure_ascii=False))
