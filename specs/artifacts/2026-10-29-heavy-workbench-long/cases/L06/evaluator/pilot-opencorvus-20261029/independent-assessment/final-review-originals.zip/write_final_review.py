"""Finalize actual17 evidence only. Never calculate or handwrite benchmark score."""
import json
from pathlib import Path
import subprocess
ROOT=Path(__file__).resolve().parent
CASE=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L06')
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def ev(path,kind,locator,observation):return {'path':path,'kind':kind,'locator':locator,'observation':observation}
phase1=load(ROOT/'independent-review-phase1.json');review=load(ROOT/'independent-review-phase2-base.json')
review['submission_id']=phase1['submission_id'];review['artifact_bindings']=phase1['artifact_bindings']
review['rater']['assignment']='Actual user-authorized one-level independent review of sealed OpenCorvus L06 submission and naturally finished base/registered quote/row-order source-only replays. Nonblind AI agent familiar with benchmark/reference; no redelegation, not professional-human or statistical certification. Original phase ratings preserved; only newly evidenced execution leaves were updated.'
assert load(ROOT/'quote-cold-addendum/stage-assessment.json')['all_passed'] and load(ROOT/'row-cold-addendum/stage-assessment-current.json')['all_passed']
for finding in review['findings']:
    if finding['id']=='D02':
        assert finding['judgement']=='unassessed'
        finding.update(judgement='full',observation='Both required input controls actually completed with the same sealed nine-source program/defaults in new outputs and isolated readonly raw/source mounts. Registered C/R0 price45→46 exactly matches captured control; complete quote policy ledger/summary independently correct C47761.2, fixedL47380 gap953/118450. All11 CSV data rows are actually reversed with unchanged complete semantic facts; new row policy correct C47643.2, gap329/59225. Both actual numeric30 pass. Correct differing strategies are allowed; the original47687.1 delivery and each replay remain distinct observations. This binary leaf is full only now both controls are closed.',evidence=[
          ev('quote-cold-addendum/receipts/terminal-inspect.json','process_receipt','Exact retired CID f956306.../State/Args/Mounts','Real quote execution naturally exited0 with original documented defaults and no old answer mount.'),
          ev('row-cold-addendum/receipts/terminal-inspect.json','process_receipt','Exact retired CID b6754c.../State/Args/Mounts','Real row-order execution naturally exited0 using the same sealed source and new output.'),
          ev('quote-cold-addendum/checks.json','business_oracle','15 actual input/source/account/reference/native predicates all pass','Only one actual registered price change; full independent quote business/quality and actual numeric30 verified.'),
          ev('row-cold-addendum/checks.json','business_oracle','First15 business predicates pass; last archival locator assumption corrected separately','All11 physical reversals and complete unchanged raw semantics; full independent new accounts/quality and actual numeric30 verified.'),
          ev('row-cold-addendum/archive-binding-correction.json','artifact_review','32 actual result member byte comparisons','Both snapshot/results and results archive namespaces match; initial reviewer suffix-uniqueness assumption was not a content error.'),
          ev('SOURCE-AUDIT.md','source_audit','Actually inspected data-loading/model/account/report path','Source consumes supplied raw and creates model/output anew; both control inventories directly match original sealed bytes.')])
expected={c['id'] for g in load(CASE/'rubric.json')['groups'] for c in g['criteria'] if c['method'] in ('independent_review','source_only_replay','input_variation','execution_evidence')}
assert len(review['findings'])==17 and {v['id'] for v in review['findings']}==expected and len({v['id'] for v in review['findings']})==17
assert review['artifact_bindings']==phase1['artifact_bindings'] and all(v['judgement']=='full' for v in review['findings'])
files=[]
for finding in review['findings']:
    for evidence in finding['evidence']:
        p=(ROOT/evidence['path']).resolve();assert p.is_relative_to(ROOT.resolve()) and p.is_file()
        files.append({'leaf':finding['id'],'path':evidence['path'],'kind':evidence['kind'],'file_exists':True})
    required={'D01':{'process_receipt','source_audit'},'D02':{'process_receipt','business_oracle'},'D08':{'process_receipt'},'D09':{'process_receipt'},'D10':{'process_receipt'},'F05':{'process_receipt'},'F04':{'rendered_figure'}}.get(finding['id'],set())
    assert required<={e['kind'] for e in finding['evidence']}
save(ROOT/'review-final.json',review)
save(ROOT/'review-final-binding-check.json',{'submission_id':review['submission_id'],'exact_original_artifact_bindings':review['artifact_bindings']==phase1['artifact_bindings'],'17_exact_canonical_review_leaves':True,'required_actual_evidence_kinds_present':True,'located_evidence':files,'note':'File/schema checks only confirm this review file structure. Judgements are based on actual prior views/source/accounts/process evidence; structure is not correctness.'})
save(ROOT/'row-cold-addendum/manual-visual-review.json',{'method':'actual tools.view_image displays of both new row PNGs by this reviewer','images':['snapshot/delivery/operations.png','snapshot/delivery/costs.png'],'observation':'All3 scenario cash/inventory/volume panels and four weighted costs readable; units/legends/credit/storage lines match independent48 rows and components. Actual policy may differ from base/original.','not_UI_automation':True})
save(ROOT/'stage-assessment-final-review.json',{'stage':'17_independent_review_leaves_complete_waiting_real_grader','submission_id':review['submission_id'],'review_file':'review-final.json','all17_judgements_full':True,'unassessed':[],
 'original_delivery_C':'476871/10','base_replay_C':'238241/5','quote_replay_C':'238806/5','row_replay_C':'238216/5','fixed_reference_L':47380,'all_actual_registered_control_components_verified':True,
 'total_score':None,'business_success':None,'good':None,'aggregation_status':'parent must execute actual frozen l06_grade CLI; no handwritten total','nonblind_AI_reference_familiarity_disclosed':True,
 'old_guard_overload_auto_continuation_history_retained':True,'old_runtime_not_hotfixed':True,'Inspect_completion_not_business_score':True,'effective_hours_not_certified_here':True,'no_professional_human_statistical_or_same_model_causal_rank_claim':True,'ten_case_completion_not_approved':True,'new_reviewer_solver_Docker_Provider_or_delegations':0})
status=subprocess.run(['git','status','--short'],cwd='D:/myhexin-local/opencorvus',capture_output=True,text=True,encoding='utf-8');(ROOT/'git-status-end.txt').write_text(status.stdout,encoding='utf-8')
print(json.dumps({'final_review':'review-final.json','submission_id':review['submission_id'],'findings':len(review['findings']),'D02':'full','total_score':None,'business_success':None,'good':None},ensure_ascii=False))
