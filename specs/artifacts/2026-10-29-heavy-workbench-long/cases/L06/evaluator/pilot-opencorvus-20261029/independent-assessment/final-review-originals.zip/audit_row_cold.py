"""Only audit the naturally finished row control; never start a solver/container."""
import csv
from datetime import datetime
from fractions import Fraction
import importlib.util
import json
from pathlib import Path
import shutil
import time
import zipfile
ROOT=Path(__file__).resolve().parent
BASE=Path('D:/opencorvus-benchmark-runs/L06-paired-20261029-be2a55d1/opencorvus/evaluation/row-cold')
OUT=ROOT/'row-cold-addendum'
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def main():
    OUT.mkdir(exist_ok=False);start=time.perf_counter();inventory=[]
    def copy(p,q):
        q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q);inventory.append({'source':str(p),'copy':str(q.relative_to(OUT)),'byte_equal':p.read_bytes()==q.read_bytes(),'bytes':q.stat().st_size})
    for name in ('terminal-inspect.json','cleanup.json','launch.json','numeric-assessment.json','numeric-command.json','container.stdout.txt','container.stderr.txt'):
        copy(BASE/name,OUT/'receipts'/name)
    t=load(OUT/'receipts/terminal-inspect.json');mount={r['Destination']:r for r in t['Mounts']}
    for name,source in [('raw',Path(mount['/raw']['Source'])),('source',Path(mount['/project']['Source'])),('delivery',BASE/'results/row')]:
        for p in source.rglob('*'):
            if p.is_file():copy(p,OUT/'snapshot'/name/p.relative_to(source))
    spec=importlib.util.spec_from_file_location('own_quote_helpers',ROOT/'audit_quote_cold.py');q=importlib.util.module_from_spec(spec);spec.loader.exec_module(q)
    q.extract(ROOT/'independent_projection.py',['table','independent_projection']);q.extract(ROOT/'independent_business.py',['independent'])
    d,counts=q.independent_projection(OUT/'snapshot/raw');base=load(ROOT/'independent-normalized.json');out=OUT/'snapshot/delivery';checks=[]
    def check(name,ok,detail=None):checks.append({'name':name,'passed':bool(ok),'detail':detail})
    reversal=[]
    for path in sorted((OUT/'snapshot/raw').glob('*.csv')):
        with path.open(encoding='utf-8',newline='') as f:actual=list(csv.reader(f))
        with (ROOT/'snapshot-current/frozen-case/public/inputs'/path.name).open(encoding='utf-8',newline='') as f:original=list(csv.reader(f))
        reversal.append({'file':path.name,'rows':len(actual)-1,'header_equal':actual[0]==original[0],'data_rows_exactly_reversed':actual[1:]==original[:0:-1]})
    check('all11_CSV_physical_row_reversal',len(reversal)==11 and all(v['header_equal'] and v['data_rows_exactly_reversed'] for v in reversal),reversal)
    check('all_semantic_raw_facts_and_facility_unchanged',d==base and load(OUT/'snapshot/raw/facility.json')==load(ROOT/'snapshot-current/frozen-case/public/inputs/facility.json'))
    check('new_normalization_uses_correct_identity_indexes',load(out/'normalized.json')==base)
    sf=[p for p in (OUT/'snapshot/source').rglob('*') if p.is_file()]
    identity=[{'file':p.name,'same_sealed_bytes':p.read_bytes()==(ROOT/'snapshot-current/candidate-source'/p.name).read_bytes()} for p in sf]
    check('same_sealed9py_README_requirements',len(sf)==11 and sum(p.suffix=='.py' for p in sf)==9 and all(v['same_sealed_bytes'] for v in identity),identity)
    check('natural_exit_exact_retiredCID_isolated_mounts',t['Id']=='b6754c2763c623da0ac1e6c176d7fabd8c269c60e1dd2d5020ea1c5d66998b17' and t['State']['Status']=='exited' and t['State']['ExitCode']==0 and {k:v['RW'] for k,v in mount.items()}=={'/project':False,'/raw':False,'/results':True} and len(mount)==3 and t['HostConfig']['NetworkMode']=='none' and t['HostConfig']['NanoCpus']==8_000_000_000)
    a=q.independent(d,load(out/'plan.json'));alt=q.independent(d,load(out/'alternative-plan.json'))
    for name,r in [('primary',a),('alternative',alt)]:save(OUT/(name+'-independent.json'),{k:str(v) if isinstance(v,Fraction) else v for k,v in r.items()})
    check('new_primary_full_business_ledger',a['business_feasible'] and a['ledger']==load(out/'ledger.json'))
    check('new_primary_full_summary',q.summary(a['summary'])==q.summary(load(out/'summary.json')))
    check('new_alternative_full_business_ledger_summary',alt['business_feasible'] and alt['ledger']==load(out/'alternative-ledger.json') and q.summary(alt['summary'])==q.summary(load(out/'alternative-summary.json')))
    L=Fraction(47380);check('registered_fixed_L_quality',a['cost']==Fraction(238216,5) and L<=a['cost']<=L*Fraction(101,100),{'C':str(a['cost']),'L':str(L),'gap_exact':str((a['cost']-L)/L)})
    run=load(out/'run.json');final=json.loads((OUT/'receipts/container.stdout.txt').read_text(encoding='utf-8').splitlines()[-1]);stats=final['solver'];response=dict(line.split(': ',1) for line in stats['response_stats'].splitlines() if ': ' in line)
    check('same_original_defaults_actual_new_input_output',run['parameters']=={'max_time_in_seconds':1800,'num_search_workers':8,'random_seed':20261029,'relative_gap_limit':.001} and run['command']==t['Config']['Cmd'] and t['Args']==['reproduce.py','--input','/raw','--output','/results/row'])
    check('actual_stdout_native_metadata_scale',stats['status']==response['status']==run['native_solver']['status']=='FEASIBLE' and Fraction(response['objective'])/d['probability_denominator']==a['cost'] and Fraction(response['best_bound'])/d['probability_denominator']==Fraction(str(run['native_solver']['best_bound_minor'])) and run['algorithm']['termination_kind']=='resource_limit' and not run['exact_optimal_claim'])
    numeric=load(OUT/'receipts/numeric-assessment.json');check('real_main_numeric30_pass',load(OUT/'receipts/numeric-command.json')['exitcode']==0 and numeric['counts']['verified_pass']==30 and numeric['counts']['unassessed']==17 and numeric['total_score'] is None)
    check('sealed_terminal_then_exact_cleanup',load(OUT/'receipts/cleanup.json')['container_id']==t['Id'] and load(OUT/'receipts/cleanup.json')['exitcode']==0)
    weekly=[]
    for s in d['scenarios']:
        for r in a['ledger']['scenarios'][s['id']]['weeks']:weekly.append([s['id'],str(r['week']),*[str(r[k]) for k in ('cash','receipts','cost','purchase_cost','freight_cost','production_cost','holding_cost','raw_stage_peak_volume','product_stage_peak_volume')],str(sum(r['finished_inventory']))])
    with (out/'weekly.csv').open(encoding='utf-8',newline='') as f:rows=list(csv.reader(f))
    check('new48_plotted_rows_match_independent_ledger',rows[1:]==weekly)
    parts={k:sum(Fraction(s['probability_numerator'],d['probability_denominator'])*sum(r[k] for r in a['ledger']['scenarios'][s['id']]['weeks']) for s in d['scenarios']) for k in ('purchase_cost','freight_cost','production_cost','holding_cost')}
    check('plotted_weighted_components_sum_exactly',sum(parts.values())==a['cost'],{k:str(v) for k,v in parts.items()})
    with zipfile.ZipFile(BASE/'completed-originals.zip') as z:
        direct=[]
        for p in (BASE/'results/row').iterdir():
            if p.is_file():
                found=[n for n in z.namelist() if n.endswith('results/row/'+p.name)];direct.append({'file':p.name,'archive_byte_equal':len(found)==1 and z.read(found[0])==p.read_bytes()})
        check('sealed_new_result_members_exact',len(direct)==len(list((BASE/'results/row').iterdir())) and all(v['archive_byte_equal'] for v in direct),direct)
    began=datetime.fromisoformat(t['State']['StartedAt'].replace('Z','+00:00'));ended=datetime.fromisoformat(t['State']['FinishedAt'].replace('Z','+00:00'))
    save(OUT/'snapshot-inventory.json',inventory);save(OUT/'checks.json',checks)
    result={'scope':'actual same-source row-order control; final D02 component only','checks':len(checks),'all_passed':all(v['passed'] for v in checks),'failed':[v['name'] for v in checks if not v['passed']],
       'cost_exact':str(a['cost']),'alternate_cost_exact':str(alt['cost']),'fixed_L':str(L),'fixed_L_gap_exact':str((a['cost']-L)/L),'fixed_L_gap_percent':float((a['cost']-L)/L*100),'native_bound':run['native_solver']['best_bound_minor'],'native_status':run['native_solver']['status'],
       'container_seconds':(ended-began).total_seconds(),'program_seconds':run['total_wall_seconds'],'solver_seconds':run['solver_wall_seconds'],'reviewer_audit_seconds':time.perf_counter()-start,'new_solver_Docker_Provider_calls':0,'total_score':None,'business_success':None,'good':None}
    save(OUT/'stage-assessment.json',result);print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
