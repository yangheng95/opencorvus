"""Record this assigned reviewer's actual phase-one observations; no grade released."""
import json
from pathlib import Path
from datetime import datetime, timezone
import subprocess

ROOT=Path(__file__).resolve().parent
SUB=Path('D:/opencorvus-benchmark-runs/L06-paired-20261029-be2a55d1/opencorvus/completed/submission')
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def ev(path,kind,locator,observation):return {'path':path,'kind':kind,'locator':locator,'observation':observation}
def item(id_,judgement,observation,evidence):return {'id':id_,'judgement':judgement,'observation':observation,'evidence':evidence}

report='snapshot-current/delivery/report.md'
oracle=ev('checks-initial.json','business_oracle','20 named checks; all passed','Independent stdlib projection and cumulative physical/financial arithmetic; does not import candidate or solver code.')
findings=[]
for id_,why in [
 ('D01','The assessment-side source-only base invocation has a saved launch but its natural terminal and complete numeric results have not been supplied to this reviewer. Launch is not successful rebuild evidence.'),
 ('D02','Candidate self-tests are delivered and accurately labelled as such. Assessment-side registered price and row-order executions remain pending; self-tests are not substituted for this mandatory execution leaf.')]:
    findings.append(item(id_,'unassessed',why,[ev('snapshot-current/external-receipts/base-cold-launch.json','process_receipt','command/started_at/stdout','A real evaluator launch is recorded, not a completed replay.')]))
findings.append(item('D07','full','All four fact categories are traceable across source-map, README mapping table, DATA and original input. Explicit identities/index, pack-vs-piece, per-piece price/cost, shared volume/hours and facility same-name fields are located. The source-map numeric_fields values are declared minimum domains, not claimed business values; the actual values reside in normalized/raw.',[
 ev('snapshot-current/delivery/source-map.json','artifact_review','11 file names; identity/numeric_fields/rows','Keys match raw catalog/relation joint identities.'),
 ev('snapshot-current/candidate-source/README.md','document_review','数据映射与严格校验 table and following unit paragraph','All four categories including facility fields and units are mapped.'),oracle]))
for id_,why in [
 ('D08','The sealed original Docker inspection records exit0 and the candidate reports native FEASIBLE/time-limit with scaled stats. The independent evaluator base is not yet terminal; retain unassessed until actual native execution/output association is independently closed.'),
 ('D09','The delivered text carefully separates known feasible result, native numerical bound and exact optimum, but this execution leaf will be closed with the real evaluator terminal/native evidence rather than candidate prose alone.'),
 ('D10','The declared command/default1800s/8workers/seed20261029/gap.001 agree with inspected source and original Docker invocation. Final evaluation-input/source/output association is still pending, so no execution judgement is inferred from matching strings.')]:
    findings.append(item(id_,'unassessed',why,[ev('snapshot-current/external-receipts/l06-final-main-inspect.json','process_receipt','State/Args/Config/Mounts','The original candidate main container exited0; its mount was the writable original project, unlike the pending independent source-only evaluation.')]))

findings.extend([
 item('E01','full','The baseline is a complete, executable declared policy: keep procurement/trucks, use cheapest allowed route for net current demand, no prebuild. I reconstructed every control from raw and main plan and obtained the exact baseline plan. Independent arithmetic finds33 shared-line-hours violations; first base/week2/F1 is26>25. The actual original main process exit0 and retained baseline-check corroborate the delivered calculation; it does not invent a feasible baseline cost.',[
  ev(report,'document_review','基线与完整可行替代','Declared algorithm, first actual violation and corrective preproduction are explicit.'),
  ev('baseline-independent.json','business_oracle','violations.B07=33; physical_statuses','Only shared-line capacity fails; financial ledger is not published as trusted feasible cost.'),oracle,
  ev('snapshot-current/external-receipts/l06-final-main-inspect.json','process_receipt','State.ExitCode=0; Args','The actual candidate main invocation completed and produced this retained baseline evidence.')]),
 item('E02','full','All six pre-stock claims are correct: week6/P0 has same-week upper0 and requires10/10/11 units; week9/P3 upper3 requires1/1/2. Previous ending inventories exactly meet these minima. These are independent generous capacity bounds, not trajectory matching.',[
  ev(report,'document_review','为什么必须提前生产 table','Week, identity, demand, upper, minimum and actual pre-stock are all given.'),oracle]),
 item('E03','full','The interruption changes supplier A feasibility: weeks6–8 capacity15<minimum20 forces switch0. Report shows base→disrupted volumes80→0,80→0,0→0, names the selected replacement mechanism through earlier/other-supplier arrivals and stocks, and quantifies B/C branch volumes610→700 and50→129 while A640→470. The complete identified/dated branch controls and ledger expose the executable replacement policy; an additional artificially different sourcing trajectory is not required. The supplied complete feasible alternative preserves this valid response. This is more than a generic suggestion to use another supplier.',[
  ev(report,'document_review','供应中断及情景后应对; 操作交接与身份; 基线与完整可行替代','A choice-set exclusion plus actual quantified sourcing substitutions, dates/units/identities and complete executable policies are supplied.'),oracle]),
 item('E04','full','Each scenario minimum is week3 cash−5369, receipts0, spend1980, exactly reaching credit floor. Report supplies cash recurrence, initial7000, sales lag4 and cost components tied to real plan/normalized fields. It distinguishes receivables from available cash and scenario-specific constraints. This is closed explanatory information, not merely an unanalyzed ledger.',[
  ev(report,'document_review','现金瓶颈、费用与仓容 equations/table and following paragraph','Tight week/scenario/value and payment-versus-collection timing are explicit.'),oracle]),
 item('E05','full','Expected purchase36181.6 is the largest component; freight5298, production5801.4, holding406.1 sum exactly to47687.1. The same-scope component table and total yield exact share361816/476871 without requiring a printed percentage. Formula pack lots×pack units×unit quote and plan/normalized identities trace expenditure to actions.',[
  ev(report,'document_review','现金瓶颈、费用与仓容 component table/formulas; 执行摘要','Exact component, total, procurement action formula and price/pack mapping are present.'),oracle]),
 item('E06','full','A second complete feasible policy is independently verified. Only base/week15/P2 shifts one unit F0→F1; it frees F0 hours and costs3 more in that scenario, hence expected increase3/2. Alternate ledger/summary exactly match independent arithmetic and report correctly explains the economic tradeoff.',[
  ev(report,'document_review','基线与完整可行替代 last paragraph','Correct explicit one-unit route change and economic price.'),
  ev('alternative-independent.json','business_oracle','business_feasible/ledger/summary/cost','Full alternate policy physically/informationally/financially feasible.'),oracle]),
 item('F01','full','All common weeks0–3 orders/trucks/production are explicitly tabulated and agree with the full plan. Catalog indexes, unit conventions, zero-based time, common information set and carry-over arrivals are explained. No CSV-specific format requirement is imposed.',[
  ev(report,'document_review','操作交接与身份 and 共同承诺 table','Complete executable common commitments with identities and units.'),oracle]),
 item('F02','full','All three revealed branches are locatable in complete decisions[scenarioID] using the supplied identities, array axes, units and week4 reveal rule. Existing orders retain original arrival timing and no common prefix is rewritten. Complete JSON is an operational handoff, not penalized for lacking a separate per-action CSV.',[
  ev(report,'document_review','操作交接与身份; 情景后应对','Complete policy reference, trigger, axes, units and chronology are explicit.'),oracle]),
 item('F03','full','The report/README accurately call results FEASIBLE with1800s internal solver limit and a nonzero numerical gap; distinguish native numerical bound from evaluator reference and rational proof; do not claim exact optimum, automatic formal business success, real purchasing authority or universal validity. They explain limited-resource feasible-only outcomes, per-scenario liquidity and that AR cannot fund orders. The runtime/provider incident is evaluator history, not relabelled a candidate mathematical error.',[
  ev(report,'document_review','执行摘要; 现金瓶颈; 模型、复跑、输入控制与局限','Unknown optimum, finite search, numerical-bound trust and operational implications are accurately limited.'),
  ev('snapshot-current/candidate-source/README.md','document_review','已完成的冷复跑结果 and final paragraph','Candidate notes row-order own-bound gap>1% and does not replace registered evaluator quality with it.'),oracle]),
 item('F04','full','I actually opened both delivered PNGs with view_image. Operations has readable zero-based weeks, scenario names/legends, cash minor units and floor−5369, inventory pieces and stage volume axes; costs shows all four correctly weighted expenditure categories in minor units. Values agree with48 independently reconstructed weekly rows and exact component totals. The stage chart y-axis starts around50, which is visually apparent and not an accuracy failure under this criterion.',[
  ev('snapshot-current/delivery/operations.png','rendered_figure','Actually viewed via tools.view_image in this review turn, all3 panels','Scenario curves/credit floor/storage caps and data/units are readable.'),
  ev('snapshot-current/delivery/costs.png','rendered_figure','Actually viewed via tools.view_image in this review turn','Four bars and expected-expenditure unit match independent36181.6/5298/5801.4/406.1.'),oracle]),
 item('F05','unassessed','README gives runnable source/raw entry, exact direct dependencies/image and parameters. Another executor has launched a fresh source-only rebuild, but it is not yet a saved successful terminal. This missing evaluator evidence is not candidate0.',[
  ev('snapshot-current/candidate-source/README.md','document_review','依赖与构建; 标准入口','A clear command exists; completion cannot be inferred from instructions.'),
  ev('snapshot-current/external-receipts/base-cold-launch.json','process_receipt','actual command/CID','Launch only; natural terminal pending.')])])

assert len(findings)==17 and len({f['id'] for f in findings})==17
review={'format':'l06-review-evidence/1','case':'L06','submission_id':'opencorvus-L06-b4ae96c73ae82-phase1',
 'rater':{'id':'independent-agent-/root/benchmark_review','role':'independent_evaluator','assignment':'Parent-assigned one-level actual OpenCorvus L06 sealed candidate review; phase1 delivered artifacts only; no redelegation. Nonblind AI reviewer previously familiar with benchmark/reference; not professional-human or statistical certification.'},
 'artifact_bindings':{'input':str(SUB/'inputs'),'normalized':str(SUB/'output/normalized.json'),'plan':str(SUB/'output/plan.json'),'summary':str(SUB/'output/summary.json'),'ledger':str(SUB/'output/ledger.json')},'findings':findings}
save(ROOT/'independent-review-phase1.json',review)
save(ROOT/'manual-visual-review.json',{'method':'tools.view_image actual pixels','images':[{'path':str(SUB/'output/operations.png'),'original_dimensions':[1650,1650],'observed':'cash all3, −5369 floor, piece inventory and stage-volume panels; all units/scenarios/legends readable; source current plotted rows verified'}, {'path':str(SUB/'output/costs.png'),'observed':'expected weighted four components; correct readable minor-unit y-axis/categories'}],'not_UI_automation':True,'independently_verified_weekly_rows':48,'source_plot_code_read':True})
assessment={'stage':'phase1_delivered_candidate_nonblind_independent_review','timestamp':datetime.now(timezone.utc).isoformat(),'human_leaves_full':[f['id'] for f in findings if f['judgement']=='full'],'unassessed':[f['id'] for f in findings if f['judgement']=='unassessed'],'actual_review_findings':17,'numeric_receipt_passes':30,'numeric_arithmetic':load(ROOT/'arithmetic-assessment.json'),'total_score':None,'business_success':None,'good':None,'phase_not_final':True,'candidate_executions_started_by_reviewer':0,'Provider_calls':0,'Docker_calls':0,'delegations':0,'known_material_errors':[],
 'scope_limits':['D01/D02/D08/D09/D10/F05 pending actual independent execution closure; not candidate failure','one actual nonblind AI-agent reviewer familiar with reference; no professional-human/statistical certification','runtime Task completed/Inspect1 is not business rubric success','old pause guard/Provider overload/auto-continuation preserved, not retroactively repaired','no cross-system/model causal rank or ten-case/hour-level maturity claim']}
save(ROOT/'stage-assessment-phase1.json',assessment)
status=subprocess.run(['git','status','--short'],cwd='D:/myhexin-local/opencorvus',capture_output=True,text=True,encoding='utf-8')
(ROOT/'git-status-end.txt').write_text(status.stdout,encoding='utf-8')
print(json.dumps({'human_full':assessment['human_leaves_full'],'unassessed':assessment['unassessed'],'total_score':None,'known_material_errors':[]},ensure_ascii=False))
