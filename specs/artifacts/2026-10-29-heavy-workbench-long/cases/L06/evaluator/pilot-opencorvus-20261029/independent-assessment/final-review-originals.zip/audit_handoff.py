"""Additional second-scale checks of every printed operational action table."""
import ast,csv,json,time
from pathlib import Path
from fractions import Fraction
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'snapshot-current/delivery'
def load(p):return json.loads(p.read_text(encoding='utf-8'))
start=time.perf_counter();d=load(ROOT/'independent-normalized.json');p=load(OUT/'plan.json');a=load(ROOT/'primary-independent.json');ledger=a['ledger'];text=(OUT/'report.md').read_text(encoding='utf-8')
tables=[];current=[]
for line in text.splitlines()+['']:
    if line.startswith('|'):current.append([v.strip() for v in line.strip('|').split('|')])
    elif current:tables.append(current);current=[]
checks=[]
def check(name,ok,detail=None):checks.append({'name':name,'passed':bool(ok),'detail':detail})
table=next(t for t in tables if t[0][0]=='周')
first=p['decisions']['base'];parsed=[]
for row in table[2:]:
    w=int(row[0]);values=[ast.literal_eval(v) for v in row[1:]]
    parsed.append(w);check('common_week_'+str(w),values==[first[k][w] for k in ('order_lots','truck_on','production')])
check('all_common_weeks_covered',parsed==list(range(d['common_weeks'])))
table=next(t for t in tables if t[0][0]=='情景' and t[0][1]=='情景后供应商累计体积')
branch=[]
for row in table[2:]:
    sid=row[0];rows=ledger['scenarios'][sid]['weeks'][d['common_weeks']:]
    volumes=[sum(r['supplier_volume'][k] for r in rows) for k in range(len(d['suppliers']))]
    made=[sum(r['made'][j] for r in rows) for j in range(len(d['products']))]
    diff=[w for w in range(d['common_weeks'],d['weeks']) if any(p['decisions'][sid][k][w]!=first[k][w] for k in ('order_lots','truck_on','production'))]
    check('revealed_branch_'+sid,[volumes,made,diff]==[ast.literal_eval(v) for v in row[1:]],{'actual_volumes':volumes,'actual_made':made,'actual_changed_weeks':diff})
    branch.append(sid)
check('all_revealed_branches_covered',branch==[s['id'] for s in d['scenarios']])
# Store directly locatable stock/arrival/consumption facts; this is not a claim
# that a particular reference allocation is required.
bridge=[]
for w in (5,6,7,8,9):
    sid='supplier_disruption';sc=next(s for s in d['scenarios'] if s['id']==sid);r=ledger['scenarios'][sid]['weeks'][w]
    by_supplier=[]
    for k,sup in enumerate(d['suppliers']):
        source_week=w-sup['lead_weeks']
        units=[p['decisions'][sid]['order_lots'][source_week][k][m]*sup['pack_units'][m] if source_week>=0 else 0 for m in range(len(d['raw_materials']))]
        by_supplier.append({'id':sup['id'],'order_week':source_week,'arrival_units':units})
    check('arrival_by_supplier_'+str(w),[sum(v['arrival_units'][m] for v in by_supplier) for m in range(len(d['raw_materials']))]==r['arrivals'])
    bridge.append({'week':w,'arrivals_by_supplier':by_supplier,'opening_raw':d['initial_raw'] if w==0 else ledger['scenarios'][sid]['weeks'][w-1]['raw_inventory'],'consumption':r['consumption'],'closing_raw':r['raw_inventory']})
(ROOT/'disruption-arrival-bridge.json').write_text(json.dumps(bridge,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
sm=load(OUT/'source-map.json');counts={}
for path in (ROOT/'snapshot-current/frozen-case/public/inputs').glob('*.csv'):
    with path.open(encoding='utf-8',newline='') as f:reader=csv.DictReader(f);fields=reader.fieldnames;rows=list(reader)
    counts[path.name]=len(rows)
    check('source_map_'+path.name,sm[path.name]['rows']==len(rows) and set(sm[path.name]['identity'])|set(sm[path.name]['numeric_fields'])==set(fields))
run=load(OUT/'run.json');stats=dict(line.split(': ',1) for line in run['solver_response_stats'].splitlines() if ': ' in line)
check('native_embedded_stats_scaled',stats['status']==run['native_solver']['status']=='FEASIBLE' and Fraction(stats['objective'])/d['probability_denominator']==Fraction(str(run['native_solver']['objective_minor']))==Fraction(a['cost']) and Fraction(stats['best_bound'])/d['probability_denominator']==Fraction(str(run['native_solver']['best_bound_minor'])))
result={'checks':len(checks),'all_passed':all(c['passed'] for c in checks),'failed':[c['name'] for c in checks if not c['passed']],'checks_detail':checks,'seconds':time.perf_counter()-start,'solver_calls':0,'Provider_calls':0,'Docker_calls':0,'not_execution_leaf_closure':True}
(ROOT/'handoff-extra-checks.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k!='checks_detail'},ensure_ascii=False))
