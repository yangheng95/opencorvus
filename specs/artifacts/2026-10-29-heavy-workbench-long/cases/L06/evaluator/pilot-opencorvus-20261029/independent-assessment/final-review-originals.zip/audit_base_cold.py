"""Independent cheap audit of parent's naturally finished source-only base replay."""
import ast
from collections import Counter
import csv
from datetime import datetime,timezone
from fractions import Fraction
from itertools import product
import json
from pathlib import Path
import re
import shutil
import subprocess
import time
import zipfile

ROOT=Path(__file__).resolve().parent
RUN=Path('D:/opencorvus-benchmark-runs/L06-paired-20261029-be2a55d1/opencorvus')
BASE=RUN/'evaluation/base-cold'
DEST=ROOT/'base-cold-addendum'
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def extract(p,names):
    tree=ast.parse(p.read_text(encoding='utf-8'));nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
    exec(compile(ast.Module(body=nodes,type_ignores=[]),str(p),'exec'),globals())
def frac(v):return Fraction(v['numerator'],v['denominator'])
def summary_canonical(s):
    import copy
    s=copy.deepcopy(s)
    for row in s['scenarios'].values():row['probability']=frac(row['probability'])
    s['expected_cost_minor']=frac(s['expected_cost_minor']);s.pop('change',None);return s
def main():
    DEST.mkdir(exist_ok=False);start=time.perf_counter();inventory=[]
    def copy(p,q):
        q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
        inventory.append({'source':str(p),'copy':str(q.relative_to(DEST)),'bytes':q.stat().st_size,'byte_equal':p.read_bytes()==q.read_bytes()})
    for n in ('terminal-inspect.json','cleanup.json','launch.json','numeric-assessment.json','numeric-command.json','container.stdout.txt','container.stderr.txt'):
        copy(BASE/n,DEST/'receipts'/n)
    for name in ('source','raw','results/base'):
        for p in (BASE/name).rglob('*'):
            if p.is_file():copy(p,DEST/'snapshot'/name/p.relative_to(BASE/name))
    terminal=load(DEST/'receipts/terminal-inspect.json')[0];out=DEST/'snapshot/results/base'
    extract(ROOT/'independent_projection.py',['table','independent_projection']);extract(ROOT/'independent_business.py',['independent'])
    d,counts=independent_projection(DEST/'snapshot/raw');checks=[]
    def check(name,ok,detail=None):checks.append({'name':name,'passed':bool(ok),'detail':detail})
    check('natural_terminal_exit0',terminal['State']['Status']=='exited' and terminal['State']['ExitCode']==0)
    check('exact_retired_CID_identity',terminal['Id']=='3338994be91322b4c95a9130ea672566982cff43efe4cd082f7ae50a56653bc8' and load(DEST/'receipts/cleanup.json')['exact_container']==terminal['Id'] and load(DEST/'receipts/cleanup.json')['exitcode']==0)
    mounts=terminal['Mounts'];check('actual_mount_modes_network_isolation',{r['Destination']:r['RW'] for r in mounts}=={'/project':False,'/raw':False,'/results':True} and len(mounts)==3 and terminal['HostConfig']['NetworkMode']=='none')
    sf=list((DEST/'snapshot/source').rglob('*'));sf=[p for p in sf if p.is_file()]
    source_facts=[{'name':p.name,'same_sealed_bytes':p.read_bytes()==(ROOT/'snapshot-current/candidate-source'/p.name).read_bytes()} for p in sf]
    check('only9python_sources_README_requirements_and_all_sealed_bytes',len(sf)==11 and sum(p.suffix=='.py' for p in sf)==9 and set(p.name for p in sf)==set([p.name for p in (ROOT/'snapshot-current/candidate-source').glob('*.py')]+['README.md','requirements.txt']) and all(v['same_sealed_bytes'] for v in source_facts),source_facts)
    check('all_frozen_raw_facts_exact',d==load(ROOT/'independent-normalized.json') and load(out/'normalized.json')==d,counts)
    result={}
    for label,name in [('primary','plan.json'),('alternative','alternative-plan.json'),('baseline','baseline-plan.json')]:
        r=independent(d,load(out/name));result[label]=r
        save(DEST/(label+'-independent.json'),{k:str(v) if isinstance(v,Fraction) else v for k,v in r.items()})
    a=result['primary'];alt=result['alternative'];baseline=result['baseline']
    check('primary_full_business_ledger_exact',a['business_feasible'] and a['ledger']==load(out/'ledger.json'))
    check('primary_full_summary_exact',summary_canonical(a['summary'])==summary_canonical(load(out/'summary.json')))
    check('alternate_full_business_ledger_exact',alt['business_feasible'] and alt['ledger']==load(out/'alternative-ledger.json'))
    check('alternate_full_summary_exact',summary_canonical(alt['summary'])==summary_canonical(load(out/'alternative-summary.json')))
    check('quality_fixed_registered_L_not_native_bound',a['cost']==Fraction(238241,5) and Fraction(47380)<=a['cost']<=Fraction(47380)*Fraction(101,100),{'C':str(a['cost']),'L':47380,'gap_exact':str((a['cost']-47380)/47380)})
    check('baseline_actual_33_hours_violations',not baseline['business_feasible'] and baseline['violations']['B07']==33 and len(load(out/'baseline-check.json')['violations'])==33)
    check('alternative_actual_expected_cost_plus_1_5',alt['cost']-a['cost']==Fraction(3,2))
    run=load(out/'run.json');params={'max_time_in_seconds':1800,'num_search_workers':8,'random_seed':20261029,'relative_gap_limit':0.001}
    check('original_README_defaults_really_executed',run['parameters']==params and terminal['Args']==['reproduce.py','--input','/raw','--output','/results/base'] and run['command']==terminal['Config']['Cmd'])
    check('dependencies_actual_recorded',run['dependencies']=={'python':'3.11.13','ortools':'9.15.6755','numpy':'2.4.6','matplotlib':'3.10.3'})
    stdout=(DEST/'receipts/container.stdout.txt').read_text(encoding='utf-8');events=[json.loads(line) for line in stdout.splitlines() if line.strip()]
    final=events[-1];stats=final['solver'];native=run['native_solver']
    check('actual_stdout_native_status_and_objective',stats['status']==native['status']=='FEASIBLE' and Fraction(str(stats['objective_minor']))==Fraction(str(native['objective_minor']))==a['cost'] and stats['parameters']==params)
    rstats=dict(line.split(': ',1) for line in stats['response_stats'].splitlines() if ': ' in line)
    check('actual_response_stats_scale',Fraction(rstats['objective'])/d['probability_denominator']==a['cost'] and Fraction(rstats['best_bound'])/d['probability_denominator']==Fraction(str(native['best_bound_minor']))==Fraction(94721,2))
    check('reported_resource_terminal_no_optimality_overclaim',run['algorithm']['termination_kind']=='resource_limit' and run['exact_optimal_claim'] is False and rstats['status']=='FEASIBLE' and run['solver_response_stats']==stats['response_stats'])
    numeric=load(DEST/'receipts/numeric-assessment.json');check('actual_main_numeric30_valid',numeric['counts']['verified_pass']==30 and numeric['counts']['unassessed']==17 and numeric['total_score'] is None and load(DEST/'receipts/numeric-command.json')['exitcode']==0)
    # These are newly generated report tables/CSV for the new correct policy,
    # not assumed identical to the original candidate's decisions.
    tables=[];current=[]
    for line in (out/'report.md').read_text(encoding='utf-8').splitlines()+['']:
        if line.startswith('|'):current.append([v.strip() for v in line.strip('|').split('|')])
        elif current:tables.append(current);current=[]
    cash=next(t for t in tables if t[0][:2]==['情景','最低现金周'])
    for row in cash[2:]:
        sid=row[0];t=int(row[1]);rows=a['ledger']['scenarios'][sid]['weeks'];r=rows[t]
        check('report_tight_cash_'+sid,r['cash']==min(v['cash'] for v in rows) and list(map(int,row[2:]))==[r['cash'],r['cash']+d['credit_limit_minor'],r['receipts'],r['cost'],max(v['raw_stage_peak_volume'] for v in rows),max(v['product_stage_peak_volume'] for v in rows)])
    parts={k:sum(Fraction(s['probability_numerator'],d['probability_denominator'])*sum(r[k] for r in a['ledger']['scenarios'][s['id']]['weeks']) for s in d['scenarios']) for k in ('purchase_cost','freight_cost','production_cost','holding_cost')}
    ctable=next(t for t in tables if t[0][0]=='期望费用类别');check('all_reported_component_amounts',all(Fraction(row[1])==parts[row[0]] for row in ctable[2:]) and sum(parts.values())==a['cost'],{k:str(v) for k,v in parts.items()})
    weekly=[]
    for s in d['scenarios']:
        for r in a['ledger']['scenarios'][s['id']]['weeks']:weekly.append([s['id'],str(r['week']),*[str(r[k]) for k in ('cash','receipts','cost','purchase_cost','freight_cost','production_cost','holding_cost','raw_stage_peak_volume','product_stage_peak_volume')],str(sum(r['finished_inventory']))])
    with (out/'weekly.csv').open(encoding='utf-8',newline='') as f:rows=list(csv.reader(f))
    check('all48_plotted_data_rows',rows[1:]==weekly)
    began=datetime.fromisoformat(terminal['State']['StartedAt'].replace('Z','+00:00'));ended=datetime.fromisoformat(terminal['State']['FinishedAt'].replace('Z','+00:00'))
    with zipfile.ZipFile(BASE/'completed-originals.zip') as z:
        members=z.namelist();mismatches=[];compared=0
        for p in (BASE/'results').rglob('*'):
            if p.is_file():
                names=[n for n in members if n.endswith(str(p.relative_to(BASE)).replace('\\','/'))]
                if len(names)==1:compared+=1;mismatches.extend([] if z.read(names[0])==p.read_bytes() else [names[0]])
        save(DEST/'sealed-archive-direct-comparison.json',{'members':members,'direct_result_files_compared':compared,'mismatches':mismatches,'not_a_functional_hash_gate':True})
        check('sealed_original_archive_real_result_bytes',compared==len(list((BASE/'results/base').iterdir())) and not mismatches)
    save(DEST/'snapshot-inventory.json',inventory);save(DEST/'checks.json',checks)
    assessment={'scope':'independent read-only audit of actual evaluator source-only base, no new optimization','checks':len(checks),'all_passed':all(r['passed'] for r in checks),'failed':[r['name'] for r in checks if not r['passed']],
      'cost_exact':str(a['cost']),'alternate_cost_exact':str(alt['cost']),'registered_L':47380,'fixed_L_gap_exact':str((a['cost']-47380)/47380),'native_bound':native['best_bound_minor'],'native_status':native['status'],
      'container_seconds':(ended-began).total_seconds(),'solver_seconds':run['solver_wall_seconds'],'program_seconds':run['total_wall_seconds'],'audit_seconds':time.perf_counter()-start,
      'new_reviewer_solver_Provider_Docker_calls':0,'total_score':None,'business_success':None,'D02':'unassessed'}
    save(DEST/'stage-assessment.json',assessment);print(json.dumps(assessment,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
