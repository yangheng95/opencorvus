"""Targeted independent quote-control audit; no optimization/container/API calls."""
import ast
from collections import Counter
import csv
from datetime import datetime
from fractions import Fraction
from itertools import product
import json
from pathlib import Path
import shutil
import time
import zipfile
ROOT=Path(__file__).resolve().parent
BASE=Path('D:/opencorvus-benchmark-runs/L06-paired-20261029-be2a55d1/opencorvus/evaluation/quote-cold')
CASE=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L06')
OUT=ROOT/'quote-cold-addendum'
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def extract(p,names):
    tree=ast.parse(p.read_text(encoding='utf-8'));nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
    exec(compile(ast.Module(body=nodes,type_ignores=[]),str(p),'exec'),globals())
def summary(s):
    import copy
    s=copy.deepcopy(s)
    for row in s['scenarios'].values():row['probability']=Fraction(row['probability']['numerator'],row['probability']['denominator'])
    v=s['expected_cost_minor'];s['expected_cost_minor']=Fraction(v['numerator'],v['denominator']);s.pop('change',None);return s
def diff(a,b,path=()):
    if isinstance(a,dict):return [r for k in a for r in diff(a[k],b[k],path+(k,))]
    if isinstance(a,list):return [r for i,(x,y) in enumerate(zip(a,b)) for r in diff(x,y,path+(i,))]
    return [] if a==b else [{'path':list(path),'base':a,'quote':b}]
def main():
    OUT.mkdir(exist_ok=False);start=time.perf_counter();inventory=[]
    def copy(p,q):
        q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q);inventory.append({'source':str(p),'copy':str(q.relative_to(OUT)),'byte_equal':p.read_bytes()==q.read_bytes(),'bytes':q.stat().st_size})
    for name in ('terminal-inspect.json','cleanup.json','launch.json','numeric-assessment.json','numeric-command.json','container.stdout.txt','container.stderr.txt'):
        copy(BASE/name,OUT/'receipts'/name)
    t=load(OUT/'receipts/terminal-inspect.json')[0];mount={r['Destination']:r for r in t['Mounts']}
    for dirname,destination in [('raw',Path(mount['/raw']['Source'])),('source',Path(mount['/project']['Source'])),('delivery',BASE/'results/quote')]:
        for p in destination.rglob('*'):
            if p.is_file():copy(p,OUT/'snapshot'/dirname/p.relative_to(destination))
    rubric=load(CASE/'rubric.json');refpath=CASE/rubric['quality_reference']['registration_file'];ref=load(refpath);copy(refpath,OUT/'registered-reference.json')
    derived=next(v for v in ref['derived_variants'] if v['transformation']=={'kind':'monotone_supplier_price_increase','supplier_id':'C','raw_id':'R0','delta_minor':1})
    archive,member=derived['input_identity']['captured_input'].split(':',1)
    with zipfile.ZipFile(refpath.parent/archive) as z:
        captured=json.loads(z.read(member));save(OUT/'registered-control-normalized.json',captured)
        _,proofmember=derived['bound_derivation']['proof'].split(':',1);save(OUT/'registered-monotone-proof.json',json.loads(z.read(proofmember)))
    extract(ROOT/'independent_projection.py',['table','independent_projection']);extract(ROOT/'independent_business.py',['independent'])
    d,counts=independent_projection(OUT/'snapshot/raw');base=load(ROOT/'independent-normalized.json');out=OUT/'snapshot/delivery';checks=[]
    def check(name,ok,detail=None):checks.append({'name':name,'passed':bool(ok),'detail':detail})
    changes=diff(base,d);k=next(i for i,s in enumerate(d['suppliers']) if s['id']=='C');m=d['raw_materials'].index('R0')
    check('unique_actual_semantic_price_change',changes==[{'path':['suppliers',k,'price_minor',m],'base':45,'quote':46}],changes)
    check('actual_registered_captured_control_exact',d==captured and derived['bound_derivation']['source_reference_id']==ref['reference_id'])
    check('new_normalization_matches_actual_quote_raw',load(out/'normalized.json')==d)
    L=Fraction(ref['lower_bound_minor']['numerator'],ref['lower_bound_minor']['denominator'])
    check('only_fixed_registered_bound_used',L==47380 and rubric['quality_reference']['relative_gap_definition']=='(C-L)/L')
    sources=list((OUT/'snapshot/source').rglob('*'));sources=[p for p in sources if p.is_file()]
    identity=[{'file':p.name,'same_sealed_bytes':p.read_bytes()==(ROOT/'snapshot-current/candidate-source'/p.name).read_bytes()} for p in sources]
    check('same_sealed_9sources_README_requirements',len(sources)==11 and sum(p.suffix=='.py' for p in sources)==9 and all(v['same_sealed_bytes'] for v in identity),identity)
    check('actual_natural_terminal_and_isolation',t['Id']=='f956306113ba1b2ce7ab31087c1961c46c408f8bbd4b3ea88269d0e6af3d96b7' and t['State']['Status']=='exited' and t['State']['ExitCode']==0 and {k:v['RW'] for k,v in mount.items()}=={'/project':False,'/raw':False,'/results':True} and len(mount)==3 and t['HostConfig']['NetworkMode']=='none')
    a=independent(d,load(out/'plan.json'));alt=independent(d,load(out/'alternative-plan.json'))
    for label,r in [('primary',a),('alternative',alt)]:save(OUT/(label+'-independent.json'),{k:str(v) if isinstance(v,Fraction) else v for k,v in r.items()})
    check('full_primary_actions_and_complete_ledger',a['business_feasible'] and a['ledger']==load(out/'ledger.json'))
    check('full_primary_summary_exact',summary(a['summary'])==summary(load(out/'summary.json')))
    check('alternate_feasible_full_ledger_summary',alt['business_feasible'] and alt['ledger']==load(out/'alternative-ledger.json') and summary(alt['summary'])==summary(load(out/'alternative-summary.json')))
    check('quote_quality_fixed_L',a['cost']==Fraction(238806,5) and L<=a['cost']<=L*Fraction(101,100),{'C':str(a['cost']),'L':str(L),'gap':str((a['cost']-L)/L),'all_scenario_min_cash':[r['minimum_cash_minor'] for r in a['summary']['scenarios'].values()]})
    run=load(out/'run.json');last=json.loads((OUT/'receipts/container.stdout.txt').read_text(encoding='utf-8').splitlines()[-1]);stats=last['solver']
    check('actual_original_defaults_and_input_argv',run['parameters']=={'max_time_in_seconds':1800,'num_search_workers':8,'random_seed':20261029,'relative_gap_limit':0.001} and run['command']==t['Config']['Cmd'] and t['Args']==['reproduce.py','--input','/raw','--output','/results/quote'])
    response=dict(line.split(': ',1) for line in stats['response_stats'].splitlines() if ': ' in line)
    check('actual_native_result_scales_to_independent_cost',response['status']==stats['status']==run['native_solver']['status']=='FEASIBLE' and Fraction(response['objective'])/d['probability_denominator']==a['cost'] and Fraction(response['best_bound'])/d['probability_denominator']==Fraction(str(run['native_solver']['best_bound_minor'])) and run['algorithm']['termination_kind']=='resource_limit' and not run['exact_optimal_claim'])
    numeric=load(OUT/'receipts/numeric-assessment.json');check('actual_main30_numeric_pass',load(OUT/'receipts/numeric-command.json')['exitcode']==0 and numeric['counts']['verified_pass']==30 and numeric['counts']['unassessed']==17 and numeric['total_score'] is None)
    cleanup=load(OUT/'receipts/cleanup.json');check('only_sealed_retired_exact_CID_cleanup',cleanup['exact_container']==t['Id'] and cleanup['exitcode']==0)
    with zipfile.ZipFile(BASE/'completed-originals.zip') as z:
        actual=[]
        for p in (BASE/'results/quote').iterdir():
            if p.is_file():
                matches=[n for n in z.namelist() if n.endswith('results/quote/'+p.name)]
                actual.append({'file':p.name,'direct_same_archive_bytes':len(matches)==1 and z.read(matches[0])==p.read_bytes()})
        check('sealed_new_result_direct_member_identity',len(actual)==len(list((BASE/'results/quote').iterdir())) and all(v['direct_same_archive_bytes'] for v in actual),actual)
    began=datetime.fromisoformat(t['State']['StartedAt'].replace('Z','+00:00'));ended=datetime.fromisoformat(t['State']['FinishedAt'].replace('Z','+00:00'))
    save(OUT/'snapshot-inventory.json',inventory);save(OUT/'checks.json',checks)
    result={'scope':'D02 registered price half only; actual same-source quote execution independently verified','checks':len(checks),'all_passed':all(v['passed'] for v in checks),'failed':[v['name'] for v in checks if not v['passed']],
      'registered_transformation':derived['transformation'],'reference_id':derived['reference_id'],'exact_cost':str(a['cost']),'registered_L':str(L),'relative_gap_exact':str((a['cost']-L)/L),'relative_gap_percent':float((a['cost']-L)/L*100),'native_bound':run['native_solver']['best_bound_minor'],'native_status':run['native_solver']['status'],
      'container_seconds':(ended-began).total_seconds(),'solver_seconds':run['solver_wall_seconds'],'main_seconds':run['total_wall_seconds'],'reviewer_audit_seconds':time.perf_counter()-start,'new_reviewer_solver_Docker_Provider_calls':0,'D02_overall':'unassessed_waiting_row_control','total_score':None,'business_success':None,'good':None,'quote_figures_not_separately_visually_scored':'D02 proof is actual source/input/business behavior; F04 actual original/base views remain in prior ratings'}
    save(OUT/'stage-assessment.json',result);print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
