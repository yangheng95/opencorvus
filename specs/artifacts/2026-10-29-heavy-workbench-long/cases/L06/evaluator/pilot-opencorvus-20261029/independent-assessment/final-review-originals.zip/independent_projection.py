def table(folder,name):
    with (folder/(name+'.csv')).open(encoding='utf-8',newline='') as f:
        reader=csv.DictReader(f);return reader.fieldnames,list(reader)

def independent_projection(folder):
    provenance=[];counts={}
    def directory(name,index,identity):
        columns,rows=table(folder,name);counts[name]=len(rows)
        indexed={int(r[index]):r for r in rows}
        assert len(indexed)==len(rows) and set(indexed)==set(range(len(rows)))
        ordered=[indexed[i] for i in range(len(rows))]
        assert len({r[identity] for r in rows})==len(rows)
        return ordered,[r[identity] for r in ordered]
    def relation(name,fields,expected):
        _,rows=table(folder,name);counts[name]=len(rows)
        lookup={tuple(r[k] for k in fields):r for r in rows}
        assert len(lookup)==len(rows) and set(lookup)==set(expected),(name,'coverage')
        return lookup
    def number(row,field):return int(row[field])
    raws,R=directory('raw_materials','raw_index','raw_id')
    prods,J=directory('products','product_index','product_id')
    plants,P=directory('plants','plant_index','plant_id')
    suppliers,S=directory('supplier_terms','supplier_index','supplier_id')
    scenarios,A=directory('scenarios','scenario_index','scenario_id')
    facility=load(folder/'facility.json');T=facility['weeks']
    q=relation('supplier_quotes',('supplier_id','raw_id'),product(S,R))
    routes=relation('routes',('plant_id','product_id'),product(P,J))
    bom=relation('bom',('product_id','raw_id'),product(J,R))
    demand=relation('demand',('scenario_id','week','product_id'),product(A,map(str,range(T)),J))
    supply=relation('supplier_capacity',('scenario_id','week','supplier_id'),product(A,map(str,range(T)),S))
    capacity=relation('plant_capacity',('scenario_id','week','plant_id'),product(A,map(str,range(T)),P))
    d={'format':'l06-feasibility-instance/2',**{k:v for k,v in facility.items() if k!='format'},
       'raw_materials':R,'products':J,'plants':P,
       'raw_volume':[number(r,'volume') for r in raws],'raw_holding_minor':[number(r,'holding_minor') for r in raws],
       'initial_raw':[number(r,'initial_units') for r in raws],
       'product_volume':[number(r,'volume') for r in prods],'product_holding_minor':[number(r,'holding_minor') for r in prods],
       'initial_products':[number(r,'initial_units') for r in prods],
       'production_hours':[number(r,'hours') for r in prods],'sales_price_minor':[number(r,'sales_price_minor') for r in prods],
       'allowed':[[number(routes[(p,j)],'allowed') for j in J] for p in P],
       'production_cost_minor':[[number(routes[(p,j)],'production_cost_minor') for j in J] for p in P],
       'bom':[[number(bom[(j,r)],'units') for r in R] for j in J],
       'suppliers':[{'id':r['supplier_id'],'lead_weeks':number(r,'lead_weeks'),'freight_minor':number(r,'freight_minor'),
            'minimum_volume':number(r,'minimum_volume'),'pack_units':[number(q[(r['supplier_id'],m)],'pack_units') for m in R],
            'price_minor':[number(q[(r['supplier_id'],m)],'unit_price_minor') for m in R]} for r in suppliers],
       'scenarios':[{'id':r['scenario_id'],'probability_numerator':number(r,'probability_numerator'),
          'demand':[[number(demand[(r['scenario_id'],str(t),j)],'units') for j in J] for t in range(T)],
          'supplier_capacity_volume':[[number(supply[(r['scenario_id'],str(t),k)],'volume') for k in S] for t in range(T)],
          'plant_capacity_hours':[[number(capacity[(r['scenario_id'],str(t),p)],'hours') for p in P] for t in range(T)]} for r in scenarios]}
    return d,counts
