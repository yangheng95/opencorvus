# Specification index

- [Implementation plan and Recall](plan.md): original task, hard constraints, raw/contract/code reads, analysis, node-model and actor design, acceptance and validation.
- [Completed delivery record](records/2026-10/delivery.md): actual commands, outputs, inspected figures, limits and disclosed issues.
