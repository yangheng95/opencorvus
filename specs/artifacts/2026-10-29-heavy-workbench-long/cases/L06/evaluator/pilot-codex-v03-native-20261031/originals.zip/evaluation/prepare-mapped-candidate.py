from pathlib import Path
import json,subprocess,datetime
root=Path(__file__).resolve().parent;submission=root.parent/'submission';base=Path('D:/myhexin-local/opencorvus/specs/artifacts/2026-10-29-heavy-workbench-long/cases/L06/evaluator/upgrade-v0.3')
argv=['C:/Python314/python.exe','-X','utf8','-B',str(base/'check_whole.py'),'prepare','--run',str(root/'private-run'),'--delivery',str(submission),'--layout',str(root/'delivery-layout.json'),'--role','candidate','--out',str(root/'assignment')]
start=datetime.datetime.now(datetime.timezone.utc).isoformat();r=subprocess.run(argv,capture_output=True,text=True,encoding='utf-8');(root/'prepare-command.json').write_text(json.dumps({'started_at':start,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':argv,'native_exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr},indent=2)+'\n',encoding='utf-8');print(r.stdout);print(r.stderr);raise SystemExit(r.returncode)
