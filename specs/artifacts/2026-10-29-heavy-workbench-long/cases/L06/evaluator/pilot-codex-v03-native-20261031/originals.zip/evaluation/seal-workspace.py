from pathlib import Path
import json,zipfile,datetime,os
root=Path(__file__).resolve().parent.parent;out=root/'evaluation';members=[]
with zipfile.ZipFile(out/'complete-workspace.zip','w',zipfile.ZIP_DEFLATED) as z:
 for folder in ['submission','public']:
  for p in sorted((root/folder).rglob('*')):
   if p.is_file():
    name=p.relative_to(root).as_posix();z.write(p,name);members.append({'member':name,'bytes':p.stat().st_size})
 for name in ['public-inputs.zip','public-preparation.json']:
  z.write(root/name,name)
(out/'workspace-seal-terminal.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':os.getpid(),'native_exit':0,'bytes':(out/'complete-workspace.zip').stat().st_size,'member_count':len(members),'members':members,'all_candidate_workspace_bytes_preserved':True,'no_git_repository_was_supplied':True},indent=2)+'\n',encoding='utf-8')
print('complete original candidate/public archive sealed')
