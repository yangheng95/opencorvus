from datetime import datetime,timezone
from pathlib import Path
import sys
sys.dont_write_bytecode=True
from review_bound import ROOT,REPO,command,save,load

r=load(ROOT/'review-summary.json');w=load(ROOT/'witness-model-mapping.json');a=load(ROOT/'additional-facts.json')
result={'assessment':'independent_exact_relaxation_bound_qualification','completed_utc':datetime.now(timezone.utc).isoformat(),
    'report':'REVIEW.md','local_mathematical_qualification_passed':r['bound']['matches_recorded_exact_fields'] and r['model_coverage']['all_business_model_checks_passed'] and w['all_passed'] and r['local_checks_passed'],
    'exact_lower_bound':r['bound']['lower_bound_exact'],'lower_bound_approx':r['bound']['lower_bound'],
    'exact_feasible_upper':'51263','model_variables':1488,'model_rows':1096,'input_based_model_reconstruction_passed':True,
    'integer_witness_mapping_passed':w['all_passed'],'active_constraints':{k:v['active_counts'] for k,v in w['scenarios'].items()},
    'nonbinding_mechanisms_in_this_witness':['raw_stage_storage','finished_stage_storage'],
    'binding_is_not_causal_optimality_or_ablation_evidence':True,
    'certificate_load_and_exact_compute_seconds':r['bound']['independent_load_and_exact_arithmetic_seconds'],
    'bound_interval':r['interval'],'financing_repair':a['financing_repair'],'repair_source_identity_only':a['source_identity_only'],
    'issue_found_and_fixed':'float objective numerators in financing-relaxation branch; type precheck and row-index contract repaired; full cost branch unchanged',
    'remaining_confirmed_local_blockers':[],
    'scope_limits':{'reader_general_security_or_adversarial_certification':False,'full_L06_frozen':False,'one_percent_qualified':False,
        'actual_integer_optimality_gap_known':False,'candidate_grade':False,'hours_validated':False,'entire_benchmark_mature':False},
    'constraints':{'repo_writes':False,'extra_delegation':False,'numpy_scipy_or_optimizer_import_run':False,
        'LP_MIP_or_GPU_run':False,'Provider_or_credentials':False,'paused_container_or_user_service_action':False},
    'evidence':['source-snapshot/','commands/review-bound-tool-receipt.json','exact-certificate-recalculation.json',
        'business-model-coverage.json','witness-model-mapping.json','local-checks.json','additional-facts.json','bound-interval.json']}
save(ROOT/'stage-assessment.json',result)
command(['git','-C',str(REPO),'status','--short'],'git-status-final')
print({'local_math_qualification_passed':result['local_mathematical_qualification_passed'],
    'lower_bound':result['lower_bound_approx'],'upper':51263,'certified_gap_percent':r['interval']['gap_over_lower_percent'],
    'one_percent_qualified':False,'freeze_approved':False,'new_optimization_runs':0})
