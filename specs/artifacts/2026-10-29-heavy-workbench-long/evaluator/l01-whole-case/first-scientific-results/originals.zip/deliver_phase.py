from pathlib import Path
import json,shutil,datetime,zipfile,subprocess
ROOT=Path(__file__).resolve().parent;REPO=Path('D:/myhexin-local/opencorvus');BASE=REPO/'specs/artifacts/2026-10-29-heavy-workbench-long';CASE=BASE/'evaluator/l01-whole-case';DEST=CASE/'first-scientific-results';DEST.mkdir(parents=True,exist_ok=False)
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def write(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf-8')
def put(p,x):write(p,json.dumps(x,ensure_ascii=False,indent=2)+'\n')
at=datetime.datetime.now(datetime.timezone.utc).isoformat();active=read(ROOT/'author-study/active.json')
inspect=subprocess.run(['docker','inspect',active['cid']],capture_output=True,text=True,encoding='utf-8')
stats=subprocess.run(['docker','stats','--no-stream',active['cid']],capture_output=True,text=True,encoding='utf-8')
observation={'at':at,'active_locator':active,'inspect_exit':inspect.returncode,'inspect':json.loads(inspect.stdout) if inspect.returncode==0 else None,'inspect_error':inspect.stderr,'stats':stats.stdout,'scope':'actual observation only; naturally terminal/cleaned CID must be resolved through original owner receipts'}
put(ROOT/'progress-observation-end.json',observation)
pauses=[]
for c in read(ROOT.parent/'cheap-first-20261029/pause-receipt.json')['containers']:
    p=subprocess.run(['docker','inspect',c['id']],capture_output=True,text=True,encoding='utf-8');q=json.loads(p.stdout)[0] if p.returncode==0 else None
    pauses.append({'name':c['name'],'id':c['id'],'state':q['State'] if q else None,'inspect_exit':p.returncode,'terminal_reason':'reaction naturally completed0 and AutoRemove; original wait/closure-addendum' if c['name']=='oc-pinn-reaction-convergence-20261029-a' and q is None else None})
put(ROOT/'paused-observation-end.json',{'at':at,'rows':pauses,'meaning':'five old tasks remain paused; completed reaction is not a missing failure or restart target'})
put(ROOT.parent/'L01-current-reference-20261031.json',{'at':at,'root':str(ROOT),'phase':'author_full_reference_in_progress_unfrozen','active_locator':str(ROOT/'author-study/active.json'),'owner_launch':str(ROOT/'author-owner-launch.json'),'owner_pid':active['owner_pid'],'author_project':str(ROOT/'author-project'),'formal_source':str(ROOT/'author-study/pre-execution-source.zip'),'old_reaction_terminal':str(ROOT/'reaction-completion/closure-addendum.json'),'transfer_terminal':str(ROOT/'reaction-transfer/owner-terminal.json'),'whole_case_frozen':False,'candidate_score':None,'do_not_restart':'old reaction/transfer/old L02 or L06; only observe/continue the original owner and sealed matrix'})
for name in ('existing-evaluation','representability','render'):
    shutil.copytree(ROOT/name,DEST/name)
for name in ('reaction-completion/closure-addendum.json','reaction-completion/reaction-final-numpy.json','reaction-completion/owner-error.json','reaction-completion/wait.json','reaction-completion/inspect-terminal.json','reaction-completion/resume.json','reaction-transfer/owner-terminal.json','reaction-transfer/run/result.json','engine-check/run/assessment.json','engine-check/terminal.json','author-owner-launch.json','progress-observation-end.json','paused-observation-end.json'):
    source=ROOT/name;target=DEST/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
write(CASE/'README.md','''# L01整题研究软件与真实科学结果（未冻结）

[实施前Recall/影响面](BUILD-PLAN.md)登记科学目标与每个新增实验。唯一完整研究源在reference-source，由build_reference.py封原public与当前维护的Torch/NumPy primitive到新项目。默认执行原19基础+5续训，真实初始化/共享前缀/计数/closure、状态保存、显式恢复/新进程对照、谱/PCG、论文PDF/图和复建均有源码；源码不等于这些环节已全数通过。

[本轮真实结果](first-scientific-results/README.md)包括已有权重重算、原reaction自然终态、真实新NNCG移植、实际同架构结构控制和两张已view_image的图。结构控制证明容量，却不属于旧Xavier优化器轨迹，不能加入旧合法选择、冒充已解决固定优化合同或候选分。

唯一新正式作者研究在D:/opencorvus-benchmark-runs/l01-full-case-20261031/author-project/work/results；动态入口D:/opencorvus-benchmark-runs/L01-current-reference-20261031.json和author-study/active.json优先于本文旧计数。首注册纯L-BFGS自然段完成才由同一已封源--continue-study执行其余原格，首格不重跑；当前仍在实际训练。来源为首私有更新前pre-execution-source.zip，不热改source/工作PID。仅一个新GPU组；原reaction已AutoRemove自然0，其余五旧任务暂停。

完整注册矩阵/实际论文图、当前合同三PDE质量可达、正式全grader/错误programme/原子锚点/一次集中整审/冻结仍待，因此套件仍9/10、有效候选小时0/10。此目录的positive selfcheck和科学诊断不充当第十题。旧公开合同仍审查稿，14质量叶仍未冻结；先前189叶/局部资格和原失败保留。不要重旧36/53/恢复窗口或旧矩阵来凑量。
''')
write(DEST/'README.md','''# L01第一份真实科学结果：不是整题完成

实施前固定可达性目标为每PDE同一final的相对L2<=.01、独立评价残差RMSE<=.01、每初边值族RMSE<=.01；未按旧误差改线，当前仍待完整合同可达/冻结。

已有7实际导出与6个实际常数网络经唯一NumPy路径约6.5秒重算，三原数据数组逐值同生成规则。早期accepted120不当terminal。旧convection NNCG200残差.00763却L2.28798/周期.0564，常数残差0却解/初值失败。完整原输出在existing-evaluation。

原reaction仅恢复同一CID剩余约4100接受更新，20:38:00Z自然完成11000Adam+30000L-BFGS，docker wait0。其原AutoRemove=true使随后inspect为空，owner IndexError原件保留；closure-addendum只用真实wait/complete event/NPZ封末态，没有重跑/伪造inspect。原perf135274秒含长暂停，529.321秒是新增wait观察区间，不称候选工作小时。终值loss1.87858e-6/残差.001561/初值.001537/周期.000303均小，解误差3.5651%仍失败。

在相同旧terminal上新执行一次reaction NNCG移植：mu.01、rank20、最多200、同PCG1e-8/Armijo、20步刷新，实际200接受更新/native0/357.532秒；解误差仅降至3.3074%，仍失败，不换参数或把它说成旧注册convection续训。原source/trace/PCG/Armijo/inspect/exit全在外部封存及本ZIP。

一次预登记的结构表达控制，用原PDE/初边值推导特征线、奇反射和logit变量分离，拟合初值派生的一维特征，再导出相同三隐藏层width100/tanh的八数组。实际独立全点重算convection/reaction/wave L2RE为.000234517/.000525030/.002389601，全部残差和条件过同一目标。未来解析评价解只在导出后作评价，没有作为fit标签。这不是旧随机初始化/优化协议，证明表示容量，不证明注册优化器可达；具体固定构造/实际值在representability。

render的两图已主方实际view_image，标清结构对照与旧训练/新移植的不同身份。新engine另一次CPU13.349秒11正向契约/两步实际网络更新只证明新engine；不重旧数值套件，不当完整矩阵。

当前author-study是真正第一份原19+5源码矩阵；首完整注册L-BFGS和随后剩余格用同一只读项目/原输出续接，全部天然终态/原artifact reader后才进入后段，不重首格。实际active locator/progress snapshot附后，尚未全数完成、评分/整审/冻结均未做。

originals.zip只封本阶段已经静止的原数字/命令/来源/实际图；不打包正在写入的正式矩阵。原reaction大型state-100.pt及重复完整原capsule留外部reaction-completion/originals.zip（31,993,357bytes），不是宣称此小ZIP包含它。未来完整作者source/研究仍须自然完成后单独封末态。所有分数为null，非模型候选、小时或专业统计成熟资格。
''')
archive=DEST/'originals.zip';members=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    selected=[]
    for label in ('existing-evaluation','representability','render','engine-check'):
        selected += [p for p in (ROOT/label).rglob('*') if p.is_file()]
    for p in (ROOT/'reaction-completion').rglob('*'):
        if p.is_file() and p.suffix!='.pt' and p.name!='originals.zip':selected.append(p)
    for p in (ROOT/'reaction-transfer').rglob('*'):
        if p.is_file():selected.append(p)
    selected += [p for p in ROOT.iterdir() if p.is_file() and p.suffix in ('.py','.json','.txt')]
    selected += [ROOT/'author-study/pre-execution-source.zip',ROOT/'author-study/owner-started.json',ROOT/'author-study/active.json']
    for p in sorted(set(selected)):
        name=p.relative_to(ROOT).as_posix();z.write(p,name);members.append({'member':name,'bytes':p.stat().st_size})
put(DEST/'archive-receipt.json',{'at':at,'archive':'originals.zip','archive_bytes':archive.stat().st_size,'members':len(members),'original_bytes':sum(v['bytes'] for v in members),'inventory':members,'explicit_exclusions':['live author-project/work/results and live author-study attach streams, to be sealed only at true terminal','old reaction state-100.pt and duplicate full reaction originals.zip preserved externally, no loss of original'],'scope':'first scientific results/current genuine activity, not a completed full case or score'})
write(BASE/'cases/L01/README.md','''# L01 PINN论文派生研究（整题仍在建设）

唯一公开合同在[根任务](../../public/TASK.md)，本目录不复制第二public或评分协议。[当前完整研究源/真实科学记录](../../evaluator/l01-whole-case/README.md)与[Recall](../../../../records/2026-10/2026-10-29-heavy-workbench-long.md)记录正在实际执行的首份完整作者矩阵。

原reaction41000更新自然完成仍3.5651%误差，新200步NNCG移植仍3.3074%，不改1%目标。结构控制三PDE同架构误差.0235%/.0525%/.2390%证明容量，但不属于旧Xavier优化轨迹，不给旧方法/候选分。完整矩阵、当前选择合同可达、全grader/正错程序/整审/冻结仍待；套件仍9/10，有效小时0/10。
''')
entry=f'''
## 最新L01 Recall（{at}）：完整研究源与第一份真实矩阵进行中，仍9/10

本轮读当前AGENTS/长程L05/R9/原源码与公开profile，实施前方案evaluator/l01-whole-case/BUILD-PLAN。用户先交完整题与真实测试/cheap-first优先；不再扩平台或重复已有资格。根public仍未冻，189叶/14critical质量9分未填，未伪称十题或作者通过。

先于本轮重算登记科学目标：相对L2<=.01、独立评价残差RMSE<=.01、每族条件RMSE<=.01，与浮点容差分开。唯一NumPy读7原权重+6常数实际导出约6.5秒，三原数据数组逐值相同，常数PDE残差0而解/初值失败。原convection NNCG200 L2.28798且周期.0564，不因残差.00763给成功。

只恢复原reaction精确CID b815b942032a843f26403bf3b6398388d3f886d4bba4fab9496d6e89a65e9f1c，20:29:15Z→20:38:00Z自然完成11000+30000，docker wait0；原AutoRemove=true，随后owner.inspect空数组导致IndexError的真实工具错误保留。追加只用原wait/complete event/final NPZ封终态，不重训练/不伪造terminal inspect。旧perf135274秒含长暂停不计，新增wait529.321秒单列。独立final loss1.87858e-6、评价残差.001561、初值.001537/周期.000303，但L2RE.035651仍失败。该旧容器已自然清理，不按旧六Paused表恢复它。

一个必要新移植分支reaction NNCG mu.01/rank20/200更新/20刷新/原PCG1e-8和Armijo，native0/200接受/357.532秒，L2RE.033074仍未过目标，不换阻尼/算法/隐藏失败；这是原terminal上的新科学诊断，不属旧convection续训或完整选择。新engine真实CPU13.349秒/11正向与实际width100两步Adam/L-BFGS和closure映射过，仅证明新源基本契约。

另一次预登记便宜表示容量控制由原初边值与PDE特征线/奇反射/logit结构生成同八数组raw width100/tanh网络，独立全点L2RE convection.000234517/reaction.000525030/wave.002389601、残差/各条件全部过同目标。未来解析解未作为fit标签。源/全部真实NPZ及图保留；它违旧随机初始化/固定训练合同，明确不入旧解选择，不冒充优化器/候选成功。它提供容量与物理先验对照，不能从“能表示”推断“旧优化器能训练”。两张真实PNG已主方view_image。

完整author源run_study/study_engine/finish_study已落evaluator/l01-whole-case/reference-source；从当前唯一科学primitive/public打包到D:/opencorvus-benchmark-runs/l01-full-case-20261031/author-project。逐attempt/closure/计数、共享前缀、显式状态分叉/newPID恢复、谱与PCG、论文PDF/图/复建均有代码，尚待全部实际验收，不能用源码替代完成。首私有更新前author-study/pre-execution-source.zip封37文件输入与programme。

唯一新正式作者研究owner PID{active['owner_pid']}，20:58:58Z启动注册convection-lbfgs-s345-lrnone（原41000上限、真实合法早停），CID{active['cid']}；原阶段自然0+同artifact reader才顺序--continue-study对同一输出执行其余原注册格，首格不重跑。动态唯一入口D:/opencorvus-benchmark-runs/L01-current-reference-20261031.json及author-study/active.json，后者可能自动进入remaining；不可按此静态首CID重复启动。原public/profile/门槛未热改，只有一个新GPU组，无总量截断。stdout可缓冲，真实progress/trace/inspect优先；终态先封原native/全部结果，thin artifact退出不等科学或整题通过。还未开始新的独审，完整成品齐后复用唯一benchmark_review一次集中审。

本轮静止原件evaluator/l01-whole-case/first-scientific-results，实际图/命令/原错误与新增数值封ZIP；不封活跃matrix伪完成。原reaction32MB完整capsule和大型旧optimizer状态明确保外部。其余五旧任务实际Paused（四GPU+旧L06），reaction/移植已经自然终态。L02/L06双100升级义务仍保留，退休API/旧矩阵不重。

完整L01当前合同的全矩阵/质量可达、正式全checker/真实坏programme/原子锚点/整审/冻结仍未完成，套件9/10、有效候选小时0/10、专业统计成熟未认证；不拿本阶段代替第十题。后续接续原owner/真实末态，普通工具/科学问题据实际根因解决，禁止恢复全部GPU或重复旧测试凑量。本轮范围commit/fetch-merge/审待推/必要检查/push，Git及publish-delivery才是收据，保foreign所有改动。\n'''
with (REPO/'specs/records/2026-10/2026-10-29-heavy-workbench-long.md').open('a',encoding='utf-8') as f:f.write(entry)
for p in (BASE/'README.md',BASE/'cases/README.md'):
    text=p.read_text(encoding='utf-8');text+='\n最新L01：[完整研究源与真实科学结果]('+('evaluator/l01-whole-case/README.md' if p.parent==BASE else '../evaluator/l01-whole-case/README.md')+')已接首份19+5实际矩阵；原reaction完整训练仍3.5651%误差，结构对照的同架构可达不能替代旧优化轨迹。当前仍9/10，未冻L01、不报小时。动态入口与原失败见最新Recall，不重复启动原矩阵。\n';write(p,text)
p=BASE/'evaluator/README.md'
with p.open('a',encoding='utf-8') as f:f.write('\n当前L01整题建设入口为[l01-whole-case](l01-whole-case/README.md)：实际自然reaction终态与新NNCG诊断失败、同架构结构控制/原图、完整研究源码及唯一正在执行的作者矩阵。上文旧组件/活跃表仅历史，不当重启依据。未有完整L01评分或冻结。\n')
updates={REPO/'specs/README.md':('- [L02发布时间输入资格]','- [L02发布时间输入资格](records/2026-10/2026-10-30-heavy-workbench-l02-qualification.md)：L02双100触发升级；套件9/10开发合同，L01已开始完整作者矩阵，原reaction自然终态质量失败与结构容量对照分列，未宣称第十题/小时。'),REPO/'specs/artifacts/README.md':('- [长程任务资格与便宜实验]','- [长程任务资格与便宜实验](2026-10-29-heavy-workbench-long/README.md)：9/10开发成品；L01完整研究源/首份真实矩阵进行中，真实解质量失败不放宽目标，结构对照不充旧优化器成功。'),REPO/'specs/records/2026-10/README.md':('- [2026-10-30-heavy-workbench-l02-qualification.md]','- [2026-10-30-heavy-workbench-l02-qualification.md](2026-10-30-heavy-workbench-l02-qualification.md)：L02双100触发升级；[最新十题Recall](2026-10-29-heavy-workbench-long.md)保L01真实科学失败/同架构控制和进行中的作者矩阵，仍9/10、小时未证。')}
for p,(prefix,new) in updates.items():
    lines=p.read_text(encoding='utf-8').splitlines();indexes=[i for i,v in enumerate(lines) if v.startswith(prefix)];assert len(indexes)==1;lines[indexes[0]]=new;write(p,'\n'.join(lines)+'\n')
print(json.dumps({'at':at,'phase_archive_bytes':archive.stat().st_size,'phase_members':len(members),'formal_stage':active['stage'],'old_paused':sum(bool(r['state'] and r['state']['Paused']) for r in pauses),'completed_old_reaction':True}))
