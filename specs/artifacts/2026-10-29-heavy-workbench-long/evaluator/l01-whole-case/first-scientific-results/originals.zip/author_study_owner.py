"""Owned sequential author study segments. A natural first cell is never repeated."""
from pathlib import Path
import subprocess,json,datetime,time,os,zipfile,traceback
ROOT=Path(__file__).resolve().parent;PROJECT=ROOT/'author-project';CONTROL=ROOT/'author-study';CONTROL.mkdir(exist_ok=False)
(PROJECT/'work').mkdir(exist_ok=False)
IMAGE='sha256:366454c0a7b7f023131af29ec68696859c8d39f1a1b2a3a61e32c35ff03ae9dc'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def run(argv):
    t=time.perf_counter();p=subprocess.run(argv,capture_output=True,text=True,encoding='utf-8',errors='replace');return {'argv':argv,'started_wall_seconds':t,'finished_at':now(),'seconds':time.perf_counter()-t,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
write(CONTROL/'owner-started.json',{'at':now(),'pid':os.getpid(),'argv':__import__('sys').argv,'source_project':str(PROJECT),'scope':'one source-only formal author matrix with nonrepeated naturally terminal first registered cell, not a model candidate or difficulty qualification'})
with zipfile.ZipFile(CONTROL/'pre-execution-source.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(PROJECT.rglob('*')):
        if p.is_file():z.write(p,p.relative_to(PROJECT).as_posix())
try:
    for stage,flags in [('first-registered-cell',['--only','convection-lbfgs-s345-lrnone']),('remaining-registered-cells',['--continue-study'])]:
        out=CONTROL/stage;out.mkdir()
        argv=['docker','create','--name','oc-l01-author-'+('first' if stage.startswith('first') else 'remaining')+'-20261031-a','--network','none','--gpus','all','--cpus','4','--mount',f'type=bind,source={PROJECT},target=/project,readonly','--mount',f'type=bind,source={PROJECT/"work"},target=/project/work',IMAGE,'python','-u','-B','/project/run_study.py','--inputs','/project/inputs','--output','/project/work/results','--device','cuda',*flags]
        create=run(argv);write(out/'create.json',create);assert create['exit_code']==0;cid=create['stdout'].strip()
        write(CONTROL/'active.json',{'at':now(),'stage':stage,'cid':cid,'project':str(PROJECT),'results':str(PROJECT/'work/results'),'owner_pid':os.getpid(),'actual_argv':argv,'meaning':'currently executing, not complete'})
        start=run(['docker','start','-a',cid]);write(out/'start.json',start)
        inspect=run(['docker','inspect',cid]);write(out/'inspect.json',inspect);write(out/'logs.json',run(['docker','logs',cid]));state=json.loads(inspect['stdout'])[0]['State'];assert state['Running'] is False
        with zipfile.ZipFile(out/'segment-native-originals.zip','w',zipfile.ZIP_DEFLATED) as z:
            for p in sorted(out.rglob('*')):
                if p.is_file() and p.name!='segment-native-originals.zip':z.write(p,p.name)
            for p in sorted((PROJECT/'work/results').rglob('*')):
                if p.is_file():z.write(p,'results/'+p.relative_to(PROJECT/'work/results').as_posix())
        write(out/'cleanup.json',run(['docker','rm',cid]));write(out/'native-terminal.json',{'at':now(),'native_exit':state['ExitCode'],'seconds':start['seconds']})
        if state['ExitCode']!=0:raise RuntimeError(f'{stage} native exit {state["ExitCode"]}; preserve original results, no automatic replacement/restart')
        check=['C:/Python314/python.exe','-X','utf8','-B','D:/myhexin-local/opencorvus/script/benchmark/pinn_submission_check.py','--root',str(PROJECT),'--manifest','work/results/manifest.json','--profile',str(PROJECT/'inputs/profile.json'),'--out',str(out/'artifact-assessment.json')]
        assessment=run(check);write(out/'artifact-command.json',assessment)
        if assessment['exit_code']!=0:raise RuntimeError(f'{stage} artifact contract incomplete; no automatic new matrix')
        write(out/'segment-complete.json',{'at':now(),'native_exit':0,'artifact_exit':0,'scope':'real source execution and artifact identity; not science/whole-case score'})
    write(CONTROL/'owner-terminal.json',{'at':now(),'owner_pid':os.getpid(),'native_exit':0,'scope':'full author source execution finished; requires independent whole-case science/quality/actual visual review before freeze'})
    write(CONTROL/'active.json',{'at':now(),'stage':None,'cid':None,'owner_pid':os.getpid(),'meaning':'all requested native segments naturally terminal'})
except Exception as e:
    write(CONTROL/'owner-error.json',{'at':now(),'type':type(e).__name__,'error':str(e),'traceback':traceback.format_exc(),'action':'preserve original source/results/capsules; no restart/new matrix/changed threshold'})
    raise
