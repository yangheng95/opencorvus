"""Resume exactly the owned existing reaction process, then archive its natural end."""
from pathlib import Path
import json,subprocess,datetime,time,os,shutil,sys,traceback,zipfile
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'reaction-completion'
CID='b815b942032a843f26403bf3b6398388d3f886d4bba4fab9496d6e89a65e9f1c'
OLD=ROOT.parent/'paperbench-discovery-20261029'
REPO=Path('D:/myhexin-local/opencorvus')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def put(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def cmd(argv):
    started=now();b=time.perf_counter();r=subprocess.run(argv,capture_output=True,text=True,encoding='utf-8',errors='replace')
    return {'argv':argv,'started_at':started,'finished_at':now(),'wall_seconds':time.perf_counter()-b,'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
OUT.mkdir(exist_ok=False)
put(OUT/'owner-started.json',{'at':now(),'pid':os.getpid(),'argv':sys.argv,'cid':CID,'scope':'one existing registered representative only; not full study or candidate score'})
try:
    r=cmd(['docker','inspect',CID]);put(OUT/'inspect-before.json',r)
    q=json.loads(r['stdout'])[0]
    assert q['Id']==CID and q['Name']=='/oc-pinn-reaction-convergence-20261029-a' and q['State']['Paused'] is True
    assert q['Config']['Cmd']==['python','-u','qualify_problem_convergence.py','--problem','reaction','--output','/work/reaction-convergence-qualification']
    assert any(x['Source'].lower().replace('\\','/').rstrip('/')==str(OLD).lower().replace('\\','/').rstrip('/') and x['Destination']=='/work' for x in q['Mounts'])
    shutil.copy2(OLD/'reaction-convergence-qualification/events.json',OUT/'events-before.json')
    shutil.copy2(OLD/'reaction-convergence-qualification/executed-source.py',OUT/'executed-source.py')
    # The running process already loaded its original code; never replace or exec into it.
    resume=cmd(['docker','unpause',CID]);put(OUT/'resume.json',resume);assert resume['exit_code']==0
    start=time.perf_counter()
    wait=cmd(['docker','wait',CID]);put(OUT/'wait.json',wait)
    after=cmd(['docker','inspect',CID]);put(OUT/'inspect-terminal.json',after)
    logs=cmd(['docker','logs',CID]);put(OUT/'native-log.json',logs)
    q=json.loads(after['stdout'])[0];assert q['State']['Running'] is False and q['State']['Paused'] is False
    # Preserve true terminal objects even on native nonzero. Never call restart/run.
    shutil.copytree(OLD/'reaction-convergence-qualification',OUT/'originals')
    native=q['State']['ExitCode']
    if native==0:
        checkpoint=OUT/'originals/reaction-checkpoint.npz';assert checkpoint.is_file()
        env=os.environ.copy();env.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
        argv=[sys.executable,'-X','utf8','-B',str(REPO/'script/benchmark/pinn_numeric_check.py'),'evaluate','--problem','reaction','--checkpoint',str(checkpoint),'--out',str(OUT/'independent-numpy.json')]
        p=subprocess.run(argv,capture_output=True,text=True,encoding='utf-8',env=env)
        put(OUT/'evaluation-command.json',{'argv':argv,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr});assert p.returncode==0
        m=json.loads((OUT/'independent-numpy.json').read_text(encoding='utf-8'))
        components={'l2re':m['l2re']<=.01,'residual':m['evaluation_residual_rmse']<=.01,**{k:v['rmse']<=.01 for k,v in m['constraint_families'].items()}}
    else:components=None
    with zipfile.ZipFile(OUT/'originals.zip','w',zipfile.ZIP_DEFLATED) as z:
        for p in sorted((OUT/'originals').rglob('*')):
            if p.is_file():z.write(p,'originals/'+p.relative_to(OUT/'originals').as_posix())
        for p in sorted(OUT.glob('*.json')):z.write(p,p.name)
        z.write(OUT/'executed-source.py','executed-source.py')
    put(OUT/'owner-terminal.json',{'at':now(),'owner_pid':os.getpid(),'cid':CID,'native_exit':native,'resume_through_archive_seconds':time.perf_counter()-start,'target_components':components,'all_quality_components':all(components.values()) if components else None,'training_scope':'one actual old hybrid representative, not full19+5/complete case/candidate score','time_scope':'resume interval explicit; old perf seconds include prior long pause and are not active training wall or candidate hours','container_cleanup':'terminal own container preserved for forensic inspection; no restart'})
except Exception as e:
    put(OUT/'owner-error.json',{'at':now(),'type':type(e).__name__,'error':str(e),'traceback':traceback.format_exc(),'cid':CID,'action':'preserve original container; no retry/restart/cancel'})
    raise
