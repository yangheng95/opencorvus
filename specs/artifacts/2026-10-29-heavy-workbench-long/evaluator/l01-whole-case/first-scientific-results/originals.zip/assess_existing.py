"""Read-only numerical reconstruction of actual existing exports, never training."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
os.environ['MKL_NUM_THREADS']='1'
from pathlib import Path
import importlib.util,json,time,datetime,sys
import numpy as np
ROOT=Path(__file__).resolve().parent
OLD=ROOT.parent/'paperbench-discovery-20261029'
SOURCE=Path('D:/myhexin-local/opencorvus/script/benchmark/pinn_numeric_check.py')
spec=importlib.util.spec_from_file_location('numeric',SOURCE);numeric=importlib.util.module_from_spec(spec);spec.loader.exec_module(numeric)
out=ROOT/'existing-evaluation';out.mkdir(exist_ok=False)
targets=[(p,f'{p}-convergence-qualification/accepted-120.npz','intermediate accepted120, not terminal') for p in ('reaction','wave')]
targets += [('convection','convection-contract-qualification/accepted-120.npz','intermediate accepted120, not terminal'),('convection','convergence-qualification/convection-checkpoint.npz','older terminal representative, no complete learning-rate selection'),('convection','late-newton-200-qualification/nncg-mu-1.0/final.npz','actual 200 accepted NNCG updates from older representative parent'),('convection','convection-lr003-qualification/accepted-120.npz','intermediate lr1e-3 accepted120, not terminal'),('convection','convection-lr002-qualification/accepted-120.npz','intermediate lr1e-2 accepted120, not terminal')]
policy={'registered_before_this_evaluation':'evaluator/l01-whole-case/BUILD-PLAN.md','l2re_max':.01,'evaluation_residual_rmse_max':.01,'each_condition_rmse_max':.01,'candidate_score':None,'role':'feasibility of current known PDE solution, not final frozen case'}
(out/'target-policy.json').write_text(json.dumps(policy,indent=2)+'\n',encoding='utf-8')
def record(problem,layers,label,provenance):
    start=time.perf_counter();m=numeric.metrics(problem,layers,numeric.canonical_data(problem))
    flags={'relative_solution':m['l2re']<=policy['l2re_max'],'independent_residual':m['evaluation_residual_rmse']<=policy['evaluation_residual_rmse_max']}
    flags.update({k:v['rmse']<=policy['each_condition_rmse_max'] for k,v in m['constraint_families'].items()})
    row={'problem':problem,'label':label,'source':provenance,'metrics':m,'target_components':flags,'all_target_components':all(flags.values()),'recompute_seconds':time.perf_counter()-start,'training_certified':False,'candidate_score':None}
    (out/(label+'.json')).write_text(json.dumps(row,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'label':label,'l2re':m['l2re'],'evaluation_residual_rmse':m['evaluation_residual_rmse'],'conditions':{k:v['rmse'] for k,v in m['constraint_families'].items()},'all':all(flags.values()),'seconds':row['recompute_seconds']}),flush=True)
    return row
start=time.perf_counter();rows=[];identity=[]
for problem in ('convection','reaction','wave'):
    data=OLD/f'{problem}-convergence-qualification/{problem}-data.npz'
    if problem=='convection':data=OLD/'convection-contract-qualification/convection-data.npz'
    with np.load(data,allow_pickle=False) as existing:
        current=numeric.canonical_data(problem)
        checks={k:np.array_equal(existing[k],v) for k,v in current.items()}
    identity.append({'problem':problem,'old_data':str(data),'same_arrays':checks});assert all(checks.values()),identity[-1]
for i,(problem,relative,scope) in enumerate(targets):
    p=OLD/relative;rows.append(record(problem,numeric.load_network(p),f'actual-{i}-{problem}',{'path':str(p),'scope':scope,'bytes':p.stat().st_size}))
for problem in ('convection','reaction','wave'):
    for value in (0.,1.):
        layers=[(np.zeros((b,a),dtype=np.float64),np.zeros(b,dtype=np.float64)) for a,b in zip((2,100,100,100),(100,100,100,1))]
        layers[-1][1][0]=value
        target=out/f'constant-{problem}-{int(value)}.npz'
        np.savez(target,**{key:v for i,(w,b) in enumerate(layers) for key,v in ((f'weight_{i}',w),(f'bias_{i}',b))})
        rows.append(record(problem,numeric.load_network(target),f'constant-{problem}-{int(value)}',{'path':str(target),'scope':'untrained actual width100 constant export, low-quality diagnostic only'}))
summary={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'python':sys.version,'numpy':np.__version__,'source':str(SOURCE),'total_seconds':time.perf_counter()-start,'original_data_identity':identity,'evaluations':rows,'policy':policy}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
