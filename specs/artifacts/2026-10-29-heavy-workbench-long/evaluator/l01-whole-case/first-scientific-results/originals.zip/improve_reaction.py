"""Prospective transfer of the specified NNCG mechanism, not an old registered run."""
from pathlib import Path
import argparse,json,os,time,sys
import numpy as np
import torch
import study_engine as e
from pinn_numeric_check import load_network,metrics,canonical_data
def main():
    p=argparse.ArgumentParser();p.add_argument('--inputs',type=Path,required=True);p.add_argument('--checkpoint',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
    torch.set_default_dtype(torch.float64);torch.set_num_threads(4);a.out.mkdir(parents=True,exist_ok=False)
    parameters=e.load_parameters(a.checkpoint,'cuda');data=e.data_from_public(a.inputs,'reaction','cuda');oracle=e.Oracle('reaction',parameters,data)
    e.export(parameters,a.out/'initial.npz');initial=metrics('reaction',load_network(a.out/'initial.npz'),canonical_data('reaction'))
    e.write_json(a.out/'started.json',{'at':e.utc(),'pid':os.getpid(),'argv':sys.argv,'parent':str(a.checkpoint),'initial':initial,'config':{'method':'nncg','problem':'reaction','mu':.01,'max_updates':200,'rank':20,'sketch_seed':20261029},'scope':'new pre-freeze cross-PDE mechanism diagnosis, not a registered convection continuation or complete study'})
    result=e.optimize(oracle,'nncg',200,a.out/'nncg',{'spec':{'id':'reaction-terminal-nncg-mu.01-transfer-diagnostic','problem':'reaction','method':'nncg','value':.01,'updates':200},'parent':'actual old reaction hybrid natural terminal'},parameter=.01,branch_index=0)
    final=metrics('reaction',load_network(a.out/'nncg/final.npz'),canonical_data('reaction'))
    components={'solution':final['l2re']<=.01,'residual':final['evaluation_residual_rmse']<=.01,**{k:v['rmse']<=.01 for k,v in final['constraint_families'].items()}}
    e.write_json(a.out/'result.json',{'initial':initial,'final':final,'execution':result,'target_components':components,'all_quality_components':all(components.values()),'old_profile_eligible':False,'whole_case_complete':False,'candidate_score':None})
    print(json.dumps({'execution':result,'final':final,'target_components':components}),flush=True)
if __name__=='__main__':main()
