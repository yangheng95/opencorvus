"""Post-terminal closure using the preserved real wait result, without rerunning training."""
from pathlib import Path
import json,shutil,datetime,zipfile
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'reaction-completion';OLD=ROOT.parent/'paperbench-discovery-20261029/reaction-convergence-qualification'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
before=read(OUT/'inspect-before.json');q=json.loads(before['stdout'])[0]
wait=read(OUT/'wait.json');assert q['HostConfig']['AutoRemove'] is True and wait['exit_code']==0 and wait['stdout'].strip()=='0'
events=read(OLD/'events.json');terminal=events[-1];assert terminal['event']=='complete' and terminal['lbfgs_accepted_updates']==30000 and terminal['adam_updates']==11000
shutil.copytree(OLD,OUT/'originals')
m=read(OUT/'reaction-final-numpy.json');components={'relative_solution':m['l2re']<=.01,'evaluation_residual':m['evaluation_residual_rmse']<=.01,**{k:v['rmse']<=.01 for k,v in m['constraint_families'].items()}}
summary={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'native_exit':0,'native_exit_evidence':'preserved docker wait exit0 and payload0, plus actual complete event and final numeric export','auto_removed':True,'post_terminal_inspect':'unavailable after predeclared AutoRemove; original inspect error/index error preserved, not fabricated','actual_terminal_event':terminal,'metrics':m,'target_components':components,'all_quality_components':all(components.values()),'resume_wait_seconds':wait['wall_seconds'],'time_scope':'explicit resumed wait interval only; old perf elapsed includes long pause, not candidate active hours','whole_case_complete':False,'role':'one author hybrid representative, not full19+5 or candidate score'}
(OUT/'closure-addendum.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
with zipfile.ZipFile(OUT/'originals.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(OUT.rglob('*')):
        if p.is_file() and p.name!='originals.zip':z.write(p,p.relative_to(OUT).as_posix())
print(json.dumps({'native_exit':0,'l2re':m['l2re'],'target_components':components,'archive_bytes':(OUT/'originals.zip').stat().st_size}))
