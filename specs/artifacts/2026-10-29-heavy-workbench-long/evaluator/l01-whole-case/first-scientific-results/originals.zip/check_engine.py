from pathlib import Path
import subprocess,json,time,datetime
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'engine-check';OUT.mkdir(exist_ok=False)
def run(argv):
    t=time.perf_counter();p=subprocess.run(argv,capture_output=True,text=True,encoding='utf-8',errors='replace');r={'argv':argv,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'seconds':time.perf_counter()-t};return r
def put(name,v):(OUT/name).write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
argv=['docker','create','--name','oc-l01-engine-check-20261031-a','--network','none','--cpus','1','--mount',f'type=bind,source={ROOT/"engine-project"},target=/project,readonly','--mount',f'type=bind,source={OUT},target=/results','sha256:366454c0a7b7f023131af29ec68696859c8d39f1a1b2a3a61e32c35ff03ae9dc','python','-B','/project/selfcheck.py','--inputs','/project/inputs','--out','/results/run']
c=run(argv);put('create.json',c);assert c['exit_code']==0;cID=c['stdout'].strip()
put('started.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cid':cID,'role':'CPU new source positive contracts; no GPU/full study'})
s=run(['docker','start','-a',cID]);put('start.json',s)
i=run(['docker','inspect',cID]);put('inspect.json',i);q=json.loads(i['stdout'])[0]
put('logs.json',run(['docker','logs',cID]));native=q['State']['ExitCode']
assert q['State']['Running'] is False
put('terminal.json',{'native_exit':native,'start_attach_seconds':s['seconds']})
put('cleanup.json',run(['docker','rm',cID]))
print(json.dumps({'native_exit':native,'attach_seconds':s['seconds'],'stdout':s['stdout'],'stderr':s['stderr']}))
raise SystemExit(native)
