from pathlib import Path
import sys,json
sys.path.insert(0,'/checker')
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from pinn_numeric_check import canonical_data,load_network,forward_jets,exact_jets
ROOT=Path('/evidence');OUT=Path('/output')
fig,axs=plt.subplots(3,3,figsize=(12,10))
for i,problem in enumerate(('convection','reaction','wave')):
    data=canonical_data(problem);layers=load_network(ROOT/'representability'/f'{problem}.npz')
    prediction=forward_jets(layers,data['evaluation'])['u'];truth=exact_jets(problem,data['evaluation'])['u'];extent=[0,1,0,1 if problem=='wave' else 2*np.pi]
    for j,(values,label) in enumerate(((truth,'Known solution'),(prediction,'Structured neural control'),(np.abs(prediction-truth),'Absolute error'))):
        ax=axs[i,j];kw={'vmin':min(truth.min(),prediction.min()),'vmax':max(truth.max(),prediction.max())} if j<2 else {}
        image=ax.imshow(values.reshape(129,65),origin='lower',aspect='auto',extent=extent,cmap='magma' if j==2 else 'viridis',**kw);ax.set_title(problem+': '+label,fontsize=10);ax.set_xlabel('t');ax.set_ylabel('x');fig.colorbar(image,ax=ax)
fig.suptitle('Same width100/tanh architecture: PDE/initial-condition structure controls\nNot eligible old Xavier/optimizer trajectories',fontsize=12)
fig.tight_layout(rect=[0,0,1,.94]);fig.savefig(OUT/'structure-neural-fields.png',dpi=150);plt.close(fig)
old=json.loads((ROOT/'reaction-completion/reaction-final-numpy.json').read_text());transfer=json.loads((ROOT/'reaction-transfer/run/result.json').read_text());control=next(v for v in json.loads((ROOT/'representability/assessment.json').read_text())['rows'] if v['problem']=='reaction')
labels=['Actual old hybrid\n11000 +30000 updates','New NNCG transfer\n200 actual updates','Structured neural\ninitial-condition fit'];values=[old['l2re'],transfer['final']['l2re'],control['metrics']['l2re']]
fig,ax=plt.subplots(figsize=(10,5));ax.bar(labels,values,color=['#667085','#175cd3','#039855']);ax.axhline(.01,color='#b42318',linestyle='--',label='Prospectively recorded1% solution target')
for i,v in enumerate(values):ax.text(i,v+.0005,f'{100*v:.4f}%',ha='center')
ax.set_ylabel('Relative L2 solution error');ax.set_title('Reaction: small residual is insufficient; distinct methods remain labeled');ax.legend(loc='upper right');ax.set_ylim(0,max(values)*1.2)
fig.tight_layout();fig.savefig(OUT/'reaction-distinct-methods.png',dpi=150)
(OUT/'plot-data.json').write_text(json.dumps({'labels':labels,'l2re':values,'target':.01,'scope':'postprocessing actual existing network exports and real new200-update transfer; no training, registered selection, formal score or optimizer success inferred'},indent=2)+'\n')
