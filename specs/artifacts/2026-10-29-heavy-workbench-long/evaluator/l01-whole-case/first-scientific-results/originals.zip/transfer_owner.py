from pathlib import Path
import subprocess,json,datetime,shutil,time,zipfile,os
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'reaction-transfer';OUT.mkdir(exist_ok=False)
SOURCE=ROOT/'reaction-transfer-source';shutil.copytree(ROOT/'engine-project',SOURCE);shutil.copy2(ROOT/'improve_reaction.py',SOURCE/'improve_reaction.py')
def run(argv):
    t=time.perf_counter();p=subprocess.run(argv,capture_output=True,text=True,encoding='utf-8',errors='replace');return {'argv':argv,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'seconds':time.perf_counter()-t}
def put(n,v):(OUT/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
argv=['docker','create','--name','oc-l01-reaction-transfer-20261031-a','--network','none','--gpus','all','--cpus','4','--mount',f'type=bind,source={SOURCE},target=/project,readonly','--mount',f'type=bind,source={ROOT/"reaction-completion/originals"},target=/parent,readonly','--mount',f'type=bind,source={OUT},target=/results','sha256:366454c0a7b7f023131af29ec68696859c8d39f1a1b2a3a61e32c35ff03ae9dc','python','-u','-B','/project/improve_reaction.py','--inputs','/project/inputs','--checkpoint','/parent/reaction-checkpoint.npz','--out','/results/run']
c=run(argv);put('create.json',c);assert c['exit_code']==0;cid=c['stdout'].strip()
put('owner-started.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':os.getpid(),'cid':cid,'scope':'one new GPU method-transfer diagnostic, no full-matrix or old-profile eligibility claim'})
s=run(['docker','start','-a',cid]);put('start.json',s);i=run(['docker','inspect',cid]);put('inspect.json',i);put('logs.json',run(['docker','logs',cid]));q=json.loads(i['stdout'])[0];assert q['State']['Running'] is False
with zipfile.ZipFile(OUT/'native-originals.zip','w',zipfile.ZIP_DEFLATED) as z:
    for r,prefix in ((OUT,'execution'),(SOURCE,'source')):
        for p in sorted(r.rglob('*')):
            if p.is_file() and p.name!='native-originals.zip':z.write(p,prefix+'/'+p.relative_to(r).as_posix())
put('cleanup.json',run(['docker','rm',cid]));put('owner-terminal.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'native_exit':q['State']['ExitCode'],'seconds':s['seconds'],'scope':'terminal already archived; no restart or repeated experiment'})
raise SystemExit(q['State']['ExitCode'])
