# HeavyWorkBench-Long · 0.2.0-dev

**状态：资格与独立审查中，尚未冻结、尚无候选长程成绩。** 这是独立派生研究任务，不是官方PaperBench或完整原论文复现分数。[Recall与未满足项](../../records/2026-10/2026-10-29-heavy-workbench-long.md)是当前工作记录。旧H05两方100点与难度天花板见[横向证据](../2026-10-29-heavy-workbench-cross-system/README.md)。

L01针对Rathore等ICML2024论文《Challenges in Training PINNs: A Loss Landscape Perspective》，包括独立实现、三方程比较、配对实验、优化器数值验证、真实训练、恢复、谱诊断、图表与可清洁复训的论文。工作量来自实际科学问题和依赖链，不设最少运行时长，不用sleep或空转达标；总模型token/总墙钟不设截止。

拟公开合同见[public/TASK.md](public/TASK.md)，尚须根据真实收敛资格和独立审查收敛后冻结。当前只有L01在进行环境/数值资格；不能把原有其余九题或整个十题套件宣称为已完成小时级升级。

[public/profile.json](public/profile.json)列出19基础配置、5续训分支及有效父状态选择规则；[rubric.draft.json](rubric.draft.json)含189个二元原子叶、100分组权重，**其中9分结果锚点待校准，禁止发布总成绩**。原子数量不是难度证据。公开论文、数据与各自许可在`public/`，评估侧原官方rubric、真实资格源码/导出/回执在[evaluator/](evaluator/README.md)，不进入候选项目。

## 数值资格

使用本地隔离Docker GPU容器，基础镜像固定为`pytorch/pytorch@sha256:c16f4c749e2d9e96878875cdf6cc45cddda1d1a36fddd371dd6f2360f1b6e2a2`，PyTorch2.7.1/CUDA12.8，RTX5090。科学依赖镜像仅作本地准备，未发布。实际全批10,000残差点、width100、float64训练/二阶导数/Hessian-vector product及真实closure路径通过。NumPy独立读取权重重算三个方程全网格结果；与GPU自动微分的一/二阶导数最大绝对差5.33e-15，损失/L2RE在1e-9相对、1e-10绝对容差内吻合。资格训练264 Adam+16 L-BFGS步，**不证明论文结论、完整矩阵或小时级难度**。

真实稳态Adam每步convection0.01722秒、reaction0.01751秒、wave0.04664秒；L-BFGS16步分别1.093/0.863/2.211秒，33–36次closure。已知正定线性系统PCG显式残差7.62e-10；实际PINN高阻尼资格PCG显式残差7.24e-10。高阻尼1e4只是设备/导数/线性代数路径资格，不冒充论文小阻尼NNCG成功。

独立审查发现并关闭评分数据控制漏洞：正式数值CLI自行生成权威网格，不能读取候选提供的点文件。常数模型在完整权威网格上有明确非零误差。数值primitive不证明训练真实发生，仍需源码、实际完整执行和清洁复训证据。

最新[独立阶段审查](evaluator/independent-review/REVIEW.md)及[机器可读结论](evaluator/independent-review/stage-assessment.json)实际另起环境重跑15项NumPy、3项Torch测试及边界见证，核对9组真实GPU收据；认可已关闭上述点控制、native零步、分量零导数与合同冲突，**未批准正式冻结**。其自有源码副本、精确命令/输出与历史/新复跑身份都保存在该目录。仍缺晚期NNCG、R9锚点、完整候选长跑和清洁复训，不能把工具资格通过写成成熟benchmark已完成。

后续[晚期资格](evaluator/late-qualification/README.md)已取得真实60分钟代表训练、非正曲率失败与21步低秩刷新路径。原小阻尼两分支失败保留，新增μ=1为冻结前派生阻尼敏感性；μ=10仅为资格探索。21步与单一代表配置不能证明完整200步、选优父配置或整个19-run研究已通过。R9及正式候选长跑继续待完成。

最新[完整续训和恢复资格](evaluator/full-continuation-and-restore/README.md)已取得μ1×200实际接受、10刷新与Adam/L-BFGS真实新进程恢复，后者逐参数最大差0。[R9独立设计审查](evaluator/r9-design-review/REVIEW.md)同时指出原非关键9分的加权通过漏洞；当前待校准PDE质量叶均为关键项，公开区分研究完成与解复现成功。阈值及完整选择合同的可达性继续待证据，不能由91分方法成绩代替物理解质量。

[最终注册工具审查](evaluator/registration-review-uncapped/REVIEW.md)实际通过4项元数据合同测试与定向类型/格式检查。当前薄启动只接受显式null token政策，已删除原总量阈值取消路径；真实模型/Provider/Task端到端仍待冻结后的pilot。科学资格、注册检查和候选成绩分别记录。

本轮补充[OUTPUTS.md机器交付合同](public/OUTPUTS.md)：24配置覆盖、逐阶段计数/路径、初始化及续训父配对、实际执行证据与每PDE同一final的训练loss选优。评估侧`pinn_submission_check.py`是薄只读结构/权重端点检查，训练来源、日志内容与科学状态仍待实际完整复训和审查，不能用合成记录通过冒充科学验收。

[新增质量指标独立复核](evaluator/quality-metrics-review/REVIEW.md)实际重跑18项测试、三份真实导出CLI与独立CPU自动微分；完整评价网格残差和逐条件族指标匹配，低质量网络/解析诊断分开保留。没有填写R9阈值或批准freeze。当前三代表资格及另两注册convection学习率仍按Recall继续，尚无新候选成绩。

[机器交付独立审查](evaluator/manifest-review/REVIEW.md)实际找出并复核修复了项目/输出根混淆、未开始记录的非null引用、plateau/stalled声明计数矛盾；最终15项manifest测试与独立端点/两种tie探针通过。当前工具全范围[36项实跑](evaluator/artifact-contract-validation/README.md)仅证明数值与结构合同。R9已拆为14个pending关键质量叶、共9分，阈值仍null，完整选择可达性仍待终态证据。
