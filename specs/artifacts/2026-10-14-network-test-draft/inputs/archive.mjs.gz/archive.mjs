import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import {gzipSync} from 'node:zlib'
import {execFileSync} from 'node:child_process'
const scratch='.tmp-codex-network-draft-01a133',artifact='specs/artifacts/2026-10-14-network-test-draft',files=[],runs=[]
const gz=(from,to)=>{const bytes=fs.readFileSync(from);fs.mkdirSync(path.dirname(to),{recursive:true});fs.writeFileSync(to,gzipSync(bytes));files.push({source:from,saved:to.slice(artifact.length+1),originalBytes:bytes.length})}
for(const stage of ['before','after']){
 const root=`${scratch}/${stage}`,out=`${artifact}/runs/${stage}`,read=name=>JSON.parse(fs.readFileSync(root+'/'+name,'utf8')),ready=read('ready.json'),owner=read('owner.json'),cleanup=read('physical-pair-cleanup.json'),terminal=read('terminal.json'),proxy=read('proxy-terminal.json')
 assert.equal(ready.pid,owner.pid);assert.equal(cleanup.pid,owner.pid);assert.equal(cleanup.actualExit,0);assert.equal(cleanup.listeners,0)
 assert.deepEqual(cleanup.pair.map(({name,removed})=>({name,removed})),[{name:'auth.json',removed:true},{name:'models.json',removed:true}])
 assert.equal(terminal.normalRuntimeSettlement,true);assert.equal(proxy.normalServersClosed,true);assert.equal(proxy.activeSockets,0)
 for(const r of proxy.requests){assert.equal(r.firstLine,'CONNECT www.gstatic.com:443 HTTP/1.1');assert.equal(r.status,r.label==='A'?502:503);assert.ok(r.closedAt>=r.sentAt)}
 for(const name of fs.readdirSync(root))if(name.endsWith('.json')&&name!=='privacy-ready.json')gz(root+'/'+name,out+'/'+name+'.gz')
 for(const name of fs.readdirSync(root+'/redacted-logs'))gz(root+'/redacted-logs/'+name,out+'/logs/'+name+'.gz')
 runs.push({stage,pid:ready.pid,occurrence:ready.occurrence,port:ready.port,participantPort:ready.participantPort,proxyPorts:ready.proxyPorts,uiDirectory:ready.uiDirectory,physicalExit:cleanup.actualExit,proxyRequests:proxy.requests.length,inferenceRequests:terminal.requests,privacy:read('privacy-qualified.json').files})
}
const passed=['before-parent','privacy-before','after-parent','privacy-after','formal-before-ready','formal-after','formal-ui-final','overlay-typecheck','ui-build','docs-current','architecture-current']
for(const name of ['docs-final','architecture-final'])if(fs.existsSync(`${scratch}/${name}.exit`))passed.push(name)
for(const name of passed)assert.equal(fs.readFileSync(`${scratch}/${name}.exit`,'utf8').trim(),'0',name+' original actual exit')
const failed=['formal-before'],failureExits=Object.fromEntries(failed.map(name=>[name,fs.readFileSync(`${scratch}/${name}.exit`,'utf8').trim()]))
for(const name of [...passed,...failed])for(const ext of ['log','exit'])gz(`${scratch}/${name}.${ext}`,`${artifact}/checks/${name}.${ext}.gz`)
for(const name of ['setup.mjs','runtime.ts','launch.ps1','privacy.ts','run.mjs','check.mjs','check.initial.mjs','NetworkPanel.before.tsx','baseline.json','prepare-git.mjs','stage-final.mjs','commit-final.mjs','shared-final.json','archive.mjs'])gz(`${scratch}/${name}`,`${artifact}/inputs/${name}.gz`)
const rawGroups=[['before','check-formal-progress.json'],['before','check-formal-ready-receipts.json'],['after','check-formal-receipts.json'],['after','check-ui-final-receipts.json']].map(([stage,name])=>({stage,name,count:JSON.parse(fs.readFileSync(`${scratch}/${stage}/${name}`,'utf8')).receipts.length})),retained=rawGroups.reduce((n,r)=>n+r.count,0)
assert.equal(retained,7)
fs.writeFileSync(artifact+'/manifest.json',JSON.stringify({capturedAt:new Date().toISOString(),purpose:'Lossless original evidence and exact resource identity, not mutable-source checksum or a functional hash gate.',runs,failureExits,retainedHTTPReceipts:retained,rawGroups,limits:['Six formal current proxy error contracts and one original DirectoryRequiredError body.','Nine manual UI test-button requests have TCP/screenshot/log evidence; their HTTP response bodies are not separately retained.','No external reachability, real credentials or Provider inference qualification.'],files},null,2)+'\n')
fs.writeFileSync(artifact+'/README.md',`# 第25批：代理测试的编辑草稿所有权

对应[Recall、完整根因、失败和实际资格](../../records/2026-10/2026-10-14-network-test-draft.md)。Root独立实施，15原图逐张人工复核；没有子agent、聊天消息、UI自动化或真实模型请求。

- [screenshots](screenshots/README.md)：01–03修前A在途改B、旧A502落入B和新B503；04–06最终英文当前B值/真实结算/新B503；07/08中文URL A→B→A及实际恢复按钮；09未编辑当前A新502正确呈现；10首locator点击两开关仍0，仅观测未计成功；11/12实际Space改变两用途，保留Web开启的当前草稿和正常结算；13该当前草稿的新B503；14重开上部，15另自有tab32补拍真实空代理字段/7890占位和可用控件。未编辑原图，不把AX、类型或分数当视觉。
- [runs](runs/README.md)：before PID77252、18670/71/72/73；after PID69440、18674/75/76/77。真实公共/config/proxy/test与同PID loopback代理，A8秒502、B即时503，均只CONNECT后拒绝、不拨公网。两轮共15原TCP请求完整首行/时序/status/closedAt；正式${retained}个HTTP原body（六当前error合同、一首工具400），UI另9次不冒独立保存其HTTP body。原400 DirectoryRequiredError来自checker漏directory，修工具后重跑0，原输入/旧checker/非零保留。
- [checks](checks/README.md)：overlay类型0、Node build58.87s0/原warnings、docs345/26与架构20当前0；两实际父退出/四端口/配对清理/全日志隐私0。正式checker只核对真实HTTP200/status:error/502或503、固定target/duration和实际CONNECT，不是UI测试或外网成功。
- [inputs](inputs/README.md)：修前NetworkPanel、原/修正checker和真实服务/代理生命周期、精确提交工具。产品仅复用现有代际为draftGeneration，在原clearFeedback推进它；原action owner/finally保持，编辑不假装物理取消或新调度。没有新state/后台协议/格式/迁移。
- [previous-delivery](previous-delivery/README.md)：B24 5449398be范围正常commit/push0与fresh upstream确认；8354原资格只读复核不当Root新Provider使用。

自有tab30/31/32均关闭。两轮server/socket正常关闭、runtime settlement/父exit0及四端口0，再精确删除假auth/models同对；完整后台92519/136802字节，stdout/stderr0，隐私0。零Provider inference/realSolCalls，未保存/删除代理或发送模型消息。用户名/密码编辑、外网成功、真实认证、换服务/Task/Project和在途关页未独立验收；开关首直接点击原因未知，实际键盘资格分别保留。架构、未发布中英日志、三索引同步，Git交付按后续原回执结算。见[原清单](manifest.json)。
`)
for(const [name,title,description]of [['screenshots','真实桌面原图','15个原PNG由Root逐一查看；10仅原观测，11/12才计真实用途切换；15补拍原14未覆盖区域。'],['runs','真实代理与运行收尾','两独立occurrence、真实TCP和公共HTTP；无header/凭据/数据库归档。'],['checks','原检查与退出','首400/原1与修正重跑0均保留；不运行UI自动化。'],['inputs','原方案输入与工具','真实本机拒绝代理，没有目标外网成功或Provider模拟结论。']]){fs.mkdirSync(`${artifact}/${name}`,{recursive:true});fs.writeFileSync(`${artifact}/${name}/README.md`,`# ${title}\n\n${description} 见[主说明](../README.md)。\n`)}
fs.writeFileSync(scratch+'/status-before-commit.txt',execFileSync('git',['status','--short']))
console.log(JSON.stringify({artifact,capturedFiles:files.length,retainedHTTPReceipts:retained,runs:runs.map(({stage,pid,physicalExit,proxyRequests})=>({stage,pid,physicalExit,proxyRequests})),failureExits}))
