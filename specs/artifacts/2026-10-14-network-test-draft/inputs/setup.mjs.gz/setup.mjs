import fs from 'node:fs'
import path from 'node:path'
import {gzipSync} from 'node:zlib'
import {execFileSync} from 'node:child_process'
const root='.tmp-codex-network-draft-01a133',prior='.tmp-codex-palette-item-identity-01a133',artifact='specs/artifacts/2026-10-14-network-test-draft'
fs.mkdirSync(root,{recursive:true});fs.mkdirSync(artifact+'/screenshots',{recursive:true});fs.mkdirSync(artifact+'/previous-delivery',{recursive:true})
for(const name of ['runtime.ts','launch.ps1','privacy.ts','run.mjs'])fs.writeFileSync(root+'/'+name,fs.readFileSync(prior+'/'+name,'utf8').replaceAll(prior,root).replaceAll('palette item identity','network test draft').replaceAll('18666','18670').replaceAll('18667','18671').replaceAll('18668','18674').replaceAll('18669','18675'))
for(const name of ['commit-final.log','commit-final.exit','commit-final-created.json','commit-final-receipt.json','pending-final-review.json','push-final.log','push-final.exit','push-final-receipt.json','push-final.mjs','fetch-current.log','fetch-current.exit','merge-current.log','merge-current.exit','fetch-final.log','fetch-final.exit','exact-module.log','exact-module.exit','exact-release.log','exact-release.exit','reconcile-check.log','reconcile-check.exit','peer-retirement-review.json','peer-retirement-review.log','peer-retirement-review.exit','review-peer-retirement.mjs'])fs.writeFileSync(artifact+'/previous-delivery/'+name+'.gz',gzipSync(fs.readFileSync(prior+'/'+name)))
const head=execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),source='packages/overlay/src/components/settings/NetworkPanel.tsx'
fs.writeFileSync(root+'/NetworkPanel.before.tsx',execFileSync('git',['show',head+':'+source]))
fs.writeFileSync(root+'/baseline.json',JSON.stringify({head,source,capturedAt:new Date().toISOString()},null,2)+'\n')
fs.writeFileSync(artifact+'/previous-delivery/README.md','# 第24批真实交付\n\n5449398be范围正常提交0，117路径/产品仅CommandPalette一文件，normal push0、原全部工作区hooks通过，upstream/ls-remote与own祖先确认。另保留8354的只读原证据复核，不当成本任务新模型请求或验收。\n')
console.log(JSON.stringify({root,head,beforePorts:[18670,18671,18672,18673],afterPorts:[18674,18675,18676,18677]}))
