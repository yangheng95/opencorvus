import fs from 'node:fs/promises'
import path from 'node:path'
import assert from 'node:assert/strict'
async function main(){
 const [stage,mode='formal']=process.argv.slice(2);assert.match(stage??'',/^(before|after)([0-9]{2})?$/)
 const root=path.resolve('.tmp-codex-network-draft-01a133',stage),deadline=Date.now()+30_000
 while(!await fs.access(root+'/ready.json').then(()=>true,()=>false)){assert.ok(Date.now()<deadline,'Bounded own backend readiness');await new Promise(resolve=>setTimeout(resolve,250))}
 const ready=JSON.parse(await fs.readFile(root+'/ready.json','utf8')),receipts=[]
 for(const [index,url]of ready.proxyURLs.entries()){
  const body={proxy:{url,llmProvider:false,webResearch:false}},route='/config/proxy/test?'+new URLSearchParams({directory:ready.projects[0].directory}),response=await fetch(`http://127.0.0.1:${ready.port}`+route,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}),raw=await response.text()
  receipts.push({method:'POST',path:route,body,status:response.status,raw})
  await fs.writeFile(root+`/check-${mode}-progress.json`,JSON.stringify({receipts},null,2)+'\n')
  assert.equal(response.status,200);const value=JSON.parse(raw);receipts.at(-1).response=value
  assert.equal(value.ok,false);assert.equal(value.status,'error');assert.equal(value.targetUrl,'https://www.gstatic.com/generate_204');assert.equal(typeof value.message,'string');assert.equal(typeof value.durationMs,'number')
  if(index===0)assert.ok(value.durationMs>=7500,'Actual delayed A proxy request duration')
 }
 const tcp=JSON.parse(await fs.readFile(root+'/proxy-requests.json','utf8'))
 for(const [index,label]of ['A','B'].entries()){
  const receipt=tcp.filter(r=>r.label===label).at(-1)
  assert.equal(receipt.firstLine,'CONNECT www.gstatic.com:443 HTTP/1.1');assert.equal(receipt.status,index===0?502:503);assert.equal(typeof receipt.sentAt,'number')
 }
 await fs.writeFile(root+`/check-${mode}-receipts.json`,JSON.stringify({receipts,tcp},null,2)+'\n')
 console.log(JSON.stringify({stage,mode,actualHTTP:receipts.length,results:receipts.map(r=>({status:r.status,...r.response})),observedProxyRequests:tcp.length}))
}
await main().catch(error=>{console.error(error);process.exitCode=1})
