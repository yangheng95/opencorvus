import fs from 'node:fs'
import {execFileSync} from 'node:child_process'
import {gunzipSync} from 'node:zlib'
const commit='8354ac3319bdf66a0292beb615c56208c6f0d8f7',root='specs/artifacts/2026-10-14-message-continuation-retirement-407/delivery01/'
const read=name=>gunzipSync(execFileSync('git',['show',`${commit}:${root}${name}.gz`],{maxBuffer:8*1024*1024})).toString('utf8')
const receipts=[]
for(const group of ['focused-green03','process-green01','public-reply04','related01','related-tool-publication02','types01']){
 const owner=JSON.parse(read(`implementation/${group}/owner.json`)),stderr=read(`implementation/${group}/stderr.log`)
 receipts.push({group,owner,summary:stderr.split('\n').filter(line=>/\d+ (pass|fail)|expect\(\) calls|Ran \d+ tests|tests across/.test(line))})
}
const business=JSON.parse(read('sol-business-evidence.json'))
const files=execFileSync('git',['diff-tree','--no-commit-id','--name-only','-r',commit],{encoding:'utf8'}).trim().split('\n')
const result={commit,readAt:new Date().toISOString(),scopePaths:files.length,nonArtifactFiles:files.filter(p=>!p.startsWith('specs/artifacts/')),receipts,business,limits:'Read-only immutable original evidence review, not a fresh test, UI run or Provider call. Other task ownership/qualification retained; no delegation or messages.'}
fs.writeFileSync('.tmp-codex-palette-item-identity-01a133/peer-retirement-review.json',JSON.stringify(result,null,2)+'\n')
console.log(JSON.stringify(result,null,2))
