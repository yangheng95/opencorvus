"""Read-only source/status audit capture. No runtime requests or processes."""
import datetime as dt
import json
import pathlib
import shutil
import subprocess

ROOT = pathlib.Path(__file__).resolve().parent
REPO = pathlib.Path('D:/myhexin-local/opencorvus')
EVIDENCE = pathlib.Path('D:/opencorvus-benchmark-runs/L06-paired-20261029-be2a55d1/opencorvus/evidence/idle-unsafe-retry-20261029/status-original.json')
FILES = [
 'packages/opencorvus/src/llm/activity.ts', 'packages/opencorvus/src/llm/api.ts',
 'packages/opencorvus/src/util/stream-activity.ts', 'packages/opencorvus/src/engine/config.ts',
 'packages/opencorvus/src/session/processor.ts', 'packages/opencorvus/src/session/llm.ts',
 'packages/opencorvus/src/session/status.ts', 'packages/opencorvus/src/session/index.ts',
 'packages/opencorvus/src/session/loop.ts', 'packages/opencorvus/src/session/provider-activity-facts.ts',
 'packages/opencorvus/src/session/prompt/run.ts', 'packages/opencorvus/src/session/prompt/state.ts',
 'packages/opencorvus/src/session/prompt/owner.ts', 'packages/opencorvus/src/session/wake.ts',
 'packages/opencorvus/src/tool/bash.ts', 'packages/opencorvus/src/tool/tool.ts',
 'packages/opencorvus/src/tool/task-tool-invocation.ts', 'packages/opencorvus/src/tool/live-metadata-sink.ts',
 'packages/opencorvus/src/tool/delegate-agent.ts', 'packages/opencorvus/src/shell/process-supervisor.ts',
 'packages/opencorvus/src/agent/runner.ts', 'packages/opencorvus/src/orchestrator/agent.ts',
 'packages/opencorvus/src/engine/cancellation-scope.ts', 'packages/opencorvus/src/engine/task-agent-lifecycle.ts',
 'packages/opencorvus/src/engine/task-root-ingress-delivery.ts',
 'packages/opencorvus/src/mission/process-recovery.ts', 'packages/opencorvus/src/mission/execution-closure.ts',
 'packages/opencorvus/src/scheduler/execution-inactivity.ts',
 'packages/opencorvus/src/scheduler/event-service.ts', 'packages/opencorvus/src/scheduler/automation-service.ts',
 'packages/opencorvus/src/mcp/index.ts', 'packages/opencorvus/src/interactive-artifact/mcp-app-host.ts',
 'packages/opencorvus/src/expert-squad/package-tool-capsule.ts',
 'packages/opencorvus/src/server/routes/session.ts',
 'packages/opencorvus/src/session/actor.ts', 'packages/opencorvus/src/session/shell-exec.ts',
 'specs/current/architecture/06-provider.md', 'specs/current/architecture/task-control-plane.md',
 'specs/current/architecture/03-control.md',
]
source = ROOT / 'source-initial'
source.mkdir(exist_ok=False)
inventory = []
for rel in FILES:
    origin = REPO / rel
    target = source / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(origin, target)
    inventory.append({'origin': str(origin), 'snapshot': str(target), 'byte_equal_at_capture': origin.read_bytes() == target.read_bytes()})
sdk = REPO / 'packages/opencorvus/node_modules/ai/dist/index.js'
sdk_lines = sdk.read_text(encoding='utf-8').splitlines()
(ROOT / 'sdk-primary-source-excerpts.txt').write_text('\n'.join(f'{index+1}: {sdk_lines[index]}' for start, end in [(3178,3303),(7811,7950)] for index in range(start-1,end)), encoding='utf-8')
shutil.copyfile(EVIDENCE, ROOT / 'status-original.json')
data = json.loads(EVIDENCE.read_text(encoding='utf-8'))
occurrences = []
def walk(value):
    if isinstance(value, dict):
        if isinstance(value.get('events'), list) and value.get('sessionID'):
            events = value['events']
            terminal = [row for row in events if row.get('status', {}).get('type') == 'terminal']
            if any('ProcessorUnsafeRetryError' in row.get('status', {}).get('error', '') for row in terminal):
                occurrences.append({key: value.get(key) for key in ['sessionID','inputMessageID','agent','kind','preparedAt','latest']})
                occurrences[-1]['last_events'] = events[-8:]
        for item in value.values():
            walk(item)
    elif isinstance(value, list):
        for item in value:
            walk(item)
walk(data)
summary = {'source': str(EVIDENCE), 'observed_error_occurrences': occurrences, 'error_emitted_at_utc': dt.datetime.fromtimestamp(1793306687927/1000, dt.timezone.utc).isoformat(), 'previous_reported_tool_start': '20:24:46Z (main statement, not independently read from a Tool Part in this stage)', 'twenty_minute_pause_cause': 'consistent with interval and source; original status stores only generic LLMActivity idle label, not the underlying pause monitor reason', 'limitations': 'No new request to actual Task, server, container, database or Provider; no reasoning read.'}
(ROOT / 'status-extract.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
(ROOT / 'source-inventory.json').write_text(json.dumps({'captured_utc': dt.datetime.now(dt.timezone.utc).isoformat(), 'files': inventory}, indent=2), encoding='utf-8')
commands = []
for argv, name in [
 (['git','status','--short'], 'git-status.txt'),
 (['git','rev-parse','HEAD'], 'source-HEAD.txt'),
 (['rg','-n','registerActivityMonitor|pauseActivity|resumeActivity|session_tool_idle|session_llm_idle|abortActivityMonitor|observeActivity\\(','packages/opencorvus/src','--glob','*.ts'], 'activity-call-sites.txt'),
 (['rg','-n','SessionPrompt\\.(prompt|loop)|SessionLoop\\.(loop|run)|runSessionPrompt\\(','packages/opencorvus/src','--glob','*.ts'], 'entry-call-sites.txt'),
 (['rg','-n','callToolWithTaskRecovery\\(|callScopedToolDefinition|callScopedTool\\(|convertMcpTool|signal: input.signal','packages/opencorvus/src/mcp/index.ts','packages/opencorvus/src/interactive-artifact/mcp-app-host.ts'], 'mcp-call-sites.txt'),
]:
    result = subprocess.run(argv, cwd=REPO, capture_output=True, text=True, encoding='utf-8')
    (ROOT / name).write_text(result.stdout + result.stderr, encoding='utf-8')
    commands.append({'argv': argv, 'returncode': result.returncode, 'output': name})
(ROOT / 'read-command-receipts.json').write_text(json.dumps(commands, indent=2), encoding='utf-8')
print(json.dumps({'captured_sources': len(inventory), 'error_occurrences': len(occurrences), 'error_utc': summary['error_emitted_at_utc'], 'runtime_operated': False}))
