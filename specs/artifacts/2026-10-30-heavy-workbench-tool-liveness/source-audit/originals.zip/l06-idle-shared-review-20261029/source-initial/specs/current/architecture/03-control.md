# 03 — 控制面与消息路由

> 对应代码：`src/channel/` · `src/control/` · `src/panel/capability.ts` ·
> `src/bus/` · `src/trace/` · `src/workspace/` · `src/server/`

## 设计原则

1. **消息直达**。外部消息进入 channel 后不经过无关 LLM 二次推理，直接路由到目标 task session（若该 session 有 pending interaction，确定性回填）。
2. **对话层只产出白名单 action**。`ControlMessage` 是对话层 LLM 入口，但不给它自由 tool 集合；它的输出必须匹配 `PanelCapabilityRegistry` 中的 capability schema（`create_task` / `send_task_message` / `respond_interaction` / `cancel_task` / …）。系统执行 action 时走既有 `EngineService` / `Session` API。
3. **control ≠ workspace**。`control/` 保存外部控制账号，并用普通 Session message/tool part
   记录 Control Agent 的真实对话；`workspace/` 是多工作区代理层。不存在独立 control timeline。

## 入站路径总览

显式持续目标通过 [continuous goal](continuous-goal.md) 的唯一 reconciler 生成可见的
goal-controller 参与者输入，仍进入下述 Session、Task 和 Mission 原始入口。
其暂停、预算和精确轮次授权不替代原控制面或权限合同。

```
 外部渠道                                      本地用户
 (Slack, HTTP, 自建 bot)                       (overlay, CLI)
        │                                           │
        ▼                                           ▼
 ┌────────────────────────┐              ┌────────────────────────┐
 │ ChannelIngress.message │              │  ControlMessage.handle │
 │ channel/ingress.ts     │              │  control/message.ts    │
 │                        │              │                        │
 │ - ChannelId 校验       │              │  Primary control +     │
 │ - task_id 绑定查找     │              │  PanelCapability 白名单│
 │   (engine_channel_     │              │                        │
 │    binding)            │              │  调用一个或多个 panel  │
 │ - 有 pending 交互 →    │              │  tool action           │
 │   确定性 reply_        │              │    create_task         │
 │   interaction          │              │    send_task_message   │
 │ - 否则 → Control       │              │    respond_interaction   │
 │   Message.handle       │              │    cancel_task …       │
 │                        │              │                        │
 └───────────┬────────────┘              └───────────┬────────────┘
             │                                       │
             └───────────────┬───────────────────────┘
                             ▼
                  EngineService (task-api/index.ts)
                  createTask / handleTaskMessage / replyInteraction /
                  cancelTask / current Task control inputs / …
```

### 两个入站入口的分工

| 入口                       | 场景                                                         | 是否过 LLM                                                         |
| -------------------------- | ------------------------------------------------------------ | ------------------------------------------------------------------ |
| **ChannelIngress.message** | 外部 bot / HTTP webhook；消息已有明确语义（reply / 新 task） | 否（确定性路由）；若无 pending interaction 则委托给 ControlMessage |
| **ControlMessage.handle**  | 用户自然语言对话（panel / slack / local）                    | 是（一次 LLM 推理 → 若干 capability action）                       |

两者最终都调 `EngineService.createTask` 或 `Session` / `Question` 等既有 API。

Workspace create/delete API 只触发 durable lifecycle reducer，不直接把 Git mutation 当作完成结果。
调用者提供的 Workspace ID 是 aggregate identity；Host 在 mutation 前冻结 named worktree plan 或 exact
removal plan，之后每次 retry 都校验相同 Project generation、directory occurrence、registration、branch
target 与 sandbox authority。identity drift 返回 typed conflict，未完整的外部阶段返回 typed pending；
不存在 catch-only rollback、随机重建或 registry-prune 后丢弃 branch authority 的成功路径。

Directory occurrence 的 device、inode 和 birthtimeNs 使用 bigint stat 的规范十进制字符串，序列化不得经过 Number。
ManagedRemovalPlan v3、reset operation v2、Project worktree deletion payload v3 与 Workspace delete payload v2
使用这一精确身份；scope/discovery namespace 保持稳定，使已有 journal 和 frontier 继续可见。旧数值格式不提供
当前 mutation authority，也不通过重采样或转字符串升级。其解析错误保留原 journal/frontier；Workspace recovery
可能因此拒绝启动恢复。Project child 的已 committed 旧回执也在同一 scope 内解析，可能阻止同路径重建后的
新 child 删除；仅结算旧操作不足以解除升级障碍。旧历史回执的安全整理尚未交付，包含这些记录的现有安装
不得直接升级此格式。operator 必须根据独立证据处理，不能自动丢弃旧所有权。

Workspace create 在 journal/Git 之前写入 transaction-local lifecycle admission，并一直持有到 lifecycle
terminal。Project deletion 关闭 registry admission 的同一 immediate transaction 必须证明该 Project 没有
Workspace create admission；Project identity convergence 也必须保留其 exact Project occurrence。恢复只在
旧 physical process occurrence 确认死亡或复用后接管，未知或仍存活的 owner 返回 typed conflict。

Worktree remove 在进入 Git writer lease 前只把 live/unknown overlapping registration 当作 owned；死亡
registration 会继续进入 canonical directory-admission acquire，由该 immediate transaction 原子删除旧
generation 并取得 reclamation generation。该 preflight 只避免 live registration 与 Git lease 互等，不是
第二个 mutation authority。

Project deletion 的 runtime-settlement 先让 Task/Session 与 Build-observation owner 收敛，再在仍持有
Project admission 和 deletion fence 时结算全部 Workspace/managed-worktree children。Project cascade
transaction 必须再次校验 exact fenced registry snapshot、零 Workspace rows 和 canonical child terminal
receipts。Project-specific child reducer不会另造 filesystem bypass；它只把 sandbox-row removal延后到
同一个 aggregate transaction。

`cancelTask` 在显式停止窗口内持有 root-Session destructive scope，遍历真实
Session tree，并只取消当前进程实际持有的 `SessionPromptState` controller。
controller 不存在时必须返回物理 ownership mismatch 并保留记录，不能用
Session status、Goal activity/acceptance projection 或其他持久化投影伪造取消成功。root wake queue
settle 后才允许写入 Task cancellation；该 scope 只保护不可逆操作边界，不是
持久化 workflow state。

停止既有工作只需要原 Project 身份：Chat/Work/普通 Session abort、Mission abort、
Task cancel 与 Task child Session cancel 的精确公开入口使用 identity admission，
仍检查原领域权限、Session lineage（血缘）和 projected worker runtime identity。
Task 的异步取消通过独立 identity lease 持有原操作，沿原 RuntimeExecutionSettlement
结算；HTTP 请求结束不释放物理取消所有权，当前模型不可用不阻止停止。

Host 启动恢复在执行初始化前，按原 Task/Mission 发现与 Project scope（范围）调用
现有取消、Mission closing 和 retention（保留策略）清理。清理后重新发现待执行事实，
实际唤醒仍走完整模型/能力初始化；清理计数不计入 woken（已唤醒）。未结清物理工作
保留原 cancelling/closing 意图与请求身份，不提前写终态。唯一清理初始化供完整
Bootstrap、原Task取消、Mission关闭及启动清理共用，绑定原稳定取消回调和原Task/Mission
driver。周期回入显式持有已缓存的identity租约，仍受Project删除、全局结算、rollback
及释放边界约束，不重新发现或复活缓存。扫描先收束原取消/关闭/retention；实际执行
扫描再进入原默认runtime准入，Task意图文件投影也归此执行阶段。冷identity清理失败
由原driver按已有backoff（退避）重试，同一request/operation继续收敛；物理owner真正
finish后才写终态。完整能力初始化、普通会话Prompt所有权和执行准入合同不变。

Cancellation provenance follows the real caller boundary. A Mission-issued
`panel.cancel_task` or Mission-issued `session.delete` records the canonical
`metadata.mission.id` together with the caller Session, assistant message,
tool call, and ToolPart identity. Control and right-sidebar callers cannot
invent a Mission ID. The protocol event and `TaskCancellationProjection` are
the single durable source consumed by Debug Info; Task metadata does not mirror
that provenance.

The same initiating identity also flows into physical Session cancellation as
one strict `ExecutionCancellationOrigin`. A Task cancellation reuses the
canonical cancellation-request occurrence and references its protocol event;
it does not mint a parallel Task-lifecycle authority. Direct Hypertext Transfer
Protocol requests, Control stream disconnects, Mission operations, scheduler
timeouts, and process shutdown each supply their own existing request or
occurrence identity. The exact `ExecutionCancellationError` object aborts the
prompt owner and activity monitor, and its origin is preserved in the assistant
error and durable `session.error` event. Downstream layers never reconstruct a
caller from the reason string.

The Task-root write/renewal fence uses that same durable cancellation authority
while the original lease and execution epoch still own an unconsumed activation.
It rejects new work with the original typed cancellation, preserving its request
and causation event through Message error projection. Replaced leases, consumed
activations and superseded epochs retain their existing fence classification;
accepted activity settlement retains its separate exact-outcome contract.

Orchestrator and standalone delegation treat an original typed Prompt
cancellation as cancellation independently of their outer wake or parent
signal. After physical Prompt settlement, the Orchestrator publishes aborted
for its captured input Message through the existing settled publication owner.
That input comes from its actual control/scheduler Message or the occurrence
bound to its captured Prompt owner. Later Session inputs keep their own facts;
ordinary Provider failures retain terminal/error and the first-terminal latch
keeps its existing authority.
The physical finally retains its exact owner's original CancellationReceipt
before joining cleanup. That receipt's admitted input controls cancellation
publication: a previously idle/terminal input or another input keeps its
original lifecycle. A typed fence rejection without a physical cancellation
receipt retains its typed cancellation authority; current post-cleanup status
does not reconstruct what was active when cancellation began.

A standalone Session shell owns the same physical Prompt lifecycle. Once its
process, output and progress have settled, an execution without attached Prompt
callbacks awaits `SessionPromptState.finish` with its captured AbortSignal and
directory. A cancellation request cannot substitute for this executor-owned
completion. With attached callbacks, the existing resumed SessionLoop inherits
the owner and completes it through its own finally; normal shell completion
does not manufacture cancellation provenance. Public replay keeps its original
Message and Tool outcome, while a subsequent command receives a new occurrence.
The direct shell binds its committed user Message to that captured owner and
publishes the same execution lifecycle as other producers. Its start is
streaming; once the original process, output, progress and fenced terminal
Message/Tool commit have settled, the shared current-project terminal publisher
records that input and final Message. An observed nonzero command exit is a
completed command; an original cancellation is aborted, and an execution failure
or recovered interruption is error. The publisher accepts an optional Task
identity, preserves the first terminal fact, and leaves newer occurrences alone.
Replay returns the original terminal history; recovery publishes only the exact
occurrence whose durable shell result it has actually converged.
The shell input Message contains the user's original command verbatim, including
spacing, line breaks and Unicode. After physical/output settlement, the original
abort signal closes an operator-stopped shell as canonical MessageAbortedError in
both Message and Tool, carrying the same cancellation authority and failure
occurrence. Its final committed progress retains the observed output and exit.
Only a naturally completed command uses the completed Tool result, including a
natural nonzero exit. No English placeholder or output note substitutes for those
participant and cancellation facts.

Graceful shutdown distinguishes physical Prompt ownership from Task execution.
The exact cancellation receipt captures the current input occurrence before
requesting physical abort. A genuinely published idle or terminal input retains
that fact when its reusable standby Prompt is released. A current input without
its first publication, or with streaming/retry, receives its exact cancellation;
unconsumed queued Messages retain their existing delivery authority. Pending
callbacks receive the original typed cancellation before abort listeners can
synchronously finish the owner. Physical completion, captured-input publication
and receipt/reuse release keep their existing order. Ordinary Session and right
sidebar abort share this publication path; Task and Mission domain closure keep
their independent durable assignment authority and retention policy.
The handoff transaction reads the canonical lifecycle and writes new recovery
evidence/ingress only for active Task occurrences. Cancelling and terminal Tasks
retain their existing cancellation or conversation-input authority. All physically
owned Prompts, including terminal cleanup tails and non-Task Sessions, still receive
cancellation and are awaited before runtime ownership is released. One terminal
Task therefore does not reject an active sibling's durable shutdown handoff.
Task-control activation admission closes and its owned activation signals are
cancelled in the initial runtime fence, before Session Prompt admission closes.
Terminal publications still drain before the final activation idle wait. This
prevents a shutdown-induced prompt refusal from becoming a Task failure and
retains the existing durable ingress for recovery. A rolled-back handoff reopens
the same activation authority and reconciles the captured project frontiers.

Task 的 execution epoch（执行轮次）、reopen（重新打开）准入、终态输入、native wait 和
dispatch continuation 的唯一当前契约见 [Task control plane](task-control-plane.md)。
公开控制输入进入同一 immutable ingress / protocol event（不可变入口与协议事件）链，
由该契约的 reducer（归约器）和当前 lease（租约）决定可执行性。该概览不另行定义
Retry/Replan 协议、可变 Task row 生命周期或兼容旧 wait writer。

物理 Server readiness、共享数据库协调与 restart handoff 的唯一当前契约见
[Server runtime readiness](server-runtime-readiness.md)。多个物理 backend 可共享同一 SQLite
数据库，通过精确进程 occurrence、Project durable fence、Task activation lease 与事务协调；
`Server.listen` 不另行创建数据库路径级 host lock。同一进程内 listener 共用 Question、Permission、
Bus、Instance 与数据库 runtime。restart 清算该物理进程的执行并移交其独立 listener；Windows
native committed receipt 才能解除原 owner 对继任进程的取消权。隔离体验与并行开发继续使用独立
`OPENCORVUS_HOME`，避免改动生产数据。Interaction row 是 durable 可见事实，不替代
Question/Permission 的进程内 waiter；reply 必须到达创建该 pending occurrence 的精确物理 owner。

Instance context 的 `git` 是所属 Project 主工作树 `project.worktree` 的 Git 状态快照。
构建、刷新和后续刷新判断均观察同一主工作树；注册执行子目录的 `directory` 和
`worktree` 不替代这个事实来源。global/root 身份发现仍独立观察执行目录中新出现的
本地 Git 仓库。刷新继续使用原有独占准备、初始化、服务租约及退出收敛路径，不通过
跳过初始化、路由旁路或额外状态来处理主根与子目录的差异。

## 对话层 — ControlMessage + Panel Capability

**代码**：`src/control/message.ts` · `src/panel/capability.ts`

旧 Gateway Agent / `channel_key` / `session_gateway_singleton_idx` / gateway SessionKind **全部删除**。对话层统一由 `ControlMessage` 承担。

> 注：当前代码没有旧 gateway 包；gateway 只作为 `server/routes/gateway.ts` 暴露的 control-plane surface 存在，并复用 `PanelCapabilityRegistry` / `ControlMessage`。

- 每次 `ControlMessage.handle()` 启动（或复用）一个真实 `assistant` Session；Task-scoped
  Control Session 挂在 Task root 下
- 精确加载 `PrimaryAssistantRegistry.get("control")`，并注入 `PanelCapabilityRegistry` 为白名单
- panel tool call 产生结构化 action/Host 事实；普通最终 assistant message 是 Control
  叙事文本的唯一来源
- 物理流结束不要求 `StructuredOutput` 或任何 terminal tool；返回值携带真实
  `message_id`、`control_session_id` 和完成的 panel tool-result refs，不复制 assistant
  文本。Channel Runtime 等需要文本的消费者通过这些 refs 读取真实 Session message
- 支持流式 `ControlMessage.handleStream`（SSE，overlay 实时消费）
- `surface` 区分入口：`panel` · `gateway` · `ChannelId` 枚举（Slack、Telegram、Discord 等，见 `channel/catalog.ts` / `packages/channel-config/src/index.ts`）

**Capability action 真源**：`packages/opencorvus/src/panel/capability.ts` 的 `PanelCapabilityRegistry`。本文档只说明控制流职责，不复制完整 action 清单或数量。

> `PanelLocalActionType`（前端 only，不属于 capability registry）当前是
> `select_task` / `select_session` / `invalidate_session`；其中 `invalidate_session`
> **只**是 local action 类型，没有对应的 mutation capability，请勿当作可向后端发送的 action。
> 历史版本提到的 `export_session_html` 现仍未注册。

## Mission operator draft acceptance

`mission.editDraft` updates only an existing pending operator text. The strict
request carries the desired `request` and its opening `expectedRequest`. The
existing immediate metadata transaction rereads and validates exact Session,
Mission, Project and directory ownership before comparing the current text.
Archived Missions require restoration before editing. Missing, changed and
archived drafts return `MissionDraftEditConflictError` (HTTP 409); wrong
ownership uses the existing NotFound response. A current draft already equal
to the desired text returns its unchanged record after those checks. Save
creates no Message or execution occurrence, and cannot revive a consumed draft.

`mission.dispatch` binds one pending operator draft to the deterministic
Session/source/request Message. A replay reads that Message's accepted text
after validating its opened occurrence and Project lineage; mutable draft
metadata is not replay authority. New acceptance consumes the exact current
draft in the same immediate transaction as the User Message, Parts, controls,
config overlay and opened authority. A changed or missing draft returns
`MissionDispatchDraftConflictError` (409) and rolls back that acceptance.
Existing-Message replay retains later drafts, and activation never clears a
draft afterward. Other Mission wake entry points do not consume drafts.

The existing Session metadata writer remains the single owner. Draft setters
read the current row inside that transaction before replacing the Mission
subobject, preserving concurrent metadata rather than rebuilding a stale
Session snapshot. Request input/model and closed-occurrence conflicts retain
their exact existing contracts across retry and restart.

## channel 子系统

**代码**：`src/channel/`

| 文件                           | 作用                                                                                  |
| ------------------------------ | ------------------------------------------------------------------------------------- |
| `ingress.ts`                   | `ChannelIngress.message()` 入口；绑定查找；`panel_response` 回复；委托 ControlMessage |
| `catalog.ts`                   | `ChannelId` / `ChannelSurface` 枚举                                                   |
| `registry.ts`                  | channel 注册表                                                                        |
| `supervisor.ts`                | channel runtime 子进程生命周期管理                                                    |
| `slack.ts` + `slack-config.ts` | Slack 适配                                                                            |
| `attachment.ts`                | 附件处理                                                                              |

`engine_channel_binding` 表在 `engine/engine.sql.ts` 定义，记录 `(platform, channel, thread) ↔ task_id` 绑定关系。

## workspace —— 多工作区代理

**代码**：`src/workspace/`

| 文件                                | 作用                            |
| ----------------------------------- | ------------------------------- |
| `workspace.ts` + `workspace.sql.ts` | `workspace` 表 + 多工作区元数据 |
| `config.ts`                         | workspace 配置读写              |

**已删除的旧 control-plane 结构**（旧文档残留）：

- ~~`control-plane/workspace-server/`~~
- ~~`control-plane/session-proxy-middleware.ts`~~
- ~~`control-plane/adaptors/`~~
- ~~`control-plane/config.ts`~~
- `control-plane/sse.ts` → `util/sse.ts`
- `control-plane/workspace.ts` → `workspace/workspace.ts`

多工作区的代理 / SSE 透传不再需要单独一层 server，统一由 `src/server/` 承载路由。

## Project runtime residency

注册过的 Project 是持久历史，不等于常驻进程 Runtime。`project/instance.ts` 是 Plugin、
FileWatcher、Version Control System（VCS）、scheduler、
channel 等 project-scoped State 的唯一缓存与释放 owner。Server 在 project request owner
关闭后以 one-running/one-dirty 方式合并调度、并在 started-incomplete Task 启动恢复后调用同一
串行 cache convergence；请求响应不等待无关 Project 的清理。活跃 lease 保持完整权威；
无 lease 的 least-recently-used entry 通过 canonical `State.dispose` 收敛到
`OPENCORVUS_PROJECT_RUNTIME_CACHE_LIMIT`。单个 disposer 超过
`OPENCORVUS_PROJECT_RUNTIME_DISPOSAL_TIMEOUT_MS` 会保留真实 lease、异步完成并报告目录级失败，
而不会阻断后续 idle candidate。参数只限定 idle process resources，不删除或
改写 Project、Task、Session、Artifact 或 message 历史，也不按内存阈值重启进程。

全局 `Instance.disposeAll` 先取消已捕获 Project 的后台工作并结算全局 Scheduler，
再等待各 Project lease 释放和执行 `State.dispose`。定时任务可能持有 Project lease
直到收到 Scheduler 取消信号，也可能等待 Project 后台工作；这两类 owner 必须先取消、
后排空，避免全局清理反向等待自己的取消步骤。Server 的进程终态协议仍负责更广的
Session/Task 终态事实与数据库交接，此顺序不替代该协议。

Server 在 Instance disposal 之前取得的 process settlement gate 也遵守这一顺序：
`waitForIdle` 校验仍持有同一准入 token 后，使用现有后台 controller 向全部缓存 Project
广播取消，再等待真实 lease 的 closed signal。取得 gate 本身只关闭新准入，返回的 handle
先由 Server 持有，因此取消或排空失败可通过原 rollback 释放准入并重试。普通前台 lease
仍需完整退出；已经取消的后台信号不在 rollback 中复活，原持久化状态与下一次合法触发
负责恢复。此步骤不改变 Task/Mission occurrence、Session 消息或其终态事实。

## control —— 外部控制账号与真实 Session 消息

**代码**：`src/control/`

| 文件                | 作用                                                                 |
| ------------------- | -------------------------------------------------------------------- |
| `control.sql.ts`    | `control_account` 外部账号表                                         |
| `message-schema.ts` | 入站 schema 与真实 message/tool-result refs 的返回 projection        |
| `message.ts`        | `ControlMessage.handle` / `handleStream` — 普通流式 Session 对话入口 |

`ChannelIngressResult` 是 Control result 与确定性 interaction result 的显式 union；
只有真实 Control Agent 调用返回 `message_id`、`control_session_id` 和 tool-result refs。

Channel ingress的accepted、实际effect选择和首次lease在同一writer冻结。Permission与
Question按原interaction/request/type及`channel.ingress` causation的真实terminal恢复；
Control按原Session/user Message与规范完成reply恢复，再复用原buildResult。调用者不能
自述结果补回执。当前Project registry与Instance generation都须匹配原accepted；原owner
活跃返回processing，明确OS死亡或真实lease release才可接管，结果与lease release同提交。
未知旧effect保持可审阅历史；`GET /channel/message/:platform/:requestID`可用只读projectID
读取已删除Project原件，正文按4096原字节分页，因果source列表最多32条，409只附首有界页。

Scheduler的回复完成判定复用`session/completed-reply`的同一公共存储投影：受理集合来自
`acceptedInputMessageIDs`（历史缺省为parent），普通tool-calls只是步骤完成；只有真实
completed Tool outcome携带规范park/handoff control才是该类步骤的最终回复。summary、
缺finish及失败回复不能当成功。持久单项读取、Project discovery与unanswered分页共同
使用该合同，避免重启遗漏工具后续步骤或重复恢复已经被同一reply批量回答的输入。

## Bus — 全局事件总线

Event 的执行目录由真实目标决定：既有 Session 使用其持久 directory，独立新会话使用原 Project 同 generation 的当前 worktree。在线与冷恢复均进入同一执行入口并重验 owner；Bus 来源目录只是来源事实，不作为另一份 Event 目标。合法 Project 目录迁移不会更换原 occurrence 或伪装为 owner 退休。

**代码**：`src/bus/`

- `bus-event.ts` — 类型安全事件定义
- `global.ts` — 全局实例
- `index.ts` — 公共导出

所有横切事件（Task 状态、Slice revision、Session/dispatch、Artifact/review、workspace
ready/failed、trace、config.changed）统一走 Bus。Goal 面板在这些真实事件上刷新并按读时
投影 current revision、独立 activity/evidence/review association 与 Completion Decision
acceptance；Control API 不提供 Goal status、attempt、retry 或 workspace lifecycle action。
SSE 消费者订阅 Bus → overlay 实时刷新。事件定义集中在 `engine/model.ts` 的 `Event.*`。

## Task Orchestrator 调度控制面

Task 对外只有 `running` 与 `inactive` 两种活动状态；`queued`、`completed`、`failed`、
`cancelled` 只作为底层物理生命周期和恢复诊断事实保留，不构成成功/失败业务状态。
Task 是否被接受由 Orchestrator 根据当前 Artifact、worker result、tool evidence 与
completion decision 判断，而不是从 inactivity reason 推断。任何可恢复的 product finding、
provider/tool interruption 或本地环境问题都必须留在同一 Task、同一固定 Squad 与绑定 lineage
内继续完成。`fail_task` 只表示有精确证据的不可抗力物理停止：Task 权限无法取得的外部授权、
被拒绝的破坏性批准、不同固定 Squad、不可约的 operator 产品决策，或 Task 无法修复也无法等待
的外部平台条件。

Task lifecycle（生命周期）以 [Task control plane](task-control-plane.md) 定义的当前 epoch
和 canonical protocol events（规范协议事件）为权威。终态结算、终态对话和重新打开必须读取
该同一投影；Task row 的展示字段、普通 `task.updated` 通知和 Tool 名称不产生第二份生命周期。

Task 内的 worker 调度使用当前投影的委派工具，条目的 `dispatch.target` 必须是精确的 active projected Agent ID。
每个真实单独调用或 collection member 都通过同一执行器创建一个
不可变 `dispatch_lineage`，绑定调用方 tool part/call、精确 worker identity、work scope 与 child Session。
它不表达 admission、running 或 terminal 状态。typed adapter 不再创建 Build/Integrity 等内层 owner；
`base_role` 只选择运行模板和 adapter ABI，不决定取消策略。每条 lineage 还记录
`workflow_occurrence_id`；首次 dispatch 令它等于自身 `dispatch_id`，continuation
沿用原值与原 `child_session_id`。面板可以在同一 Session 下列出多个 Turn，同时仍只投影该真实派发的逻辑 occurrence；可选参考节点可被多个独立派发引用。

Agent coordination 只追加四类不可变事实：request、scheduler response、action plan 和 terminal
action outcome。request 没有可变 status，action 没有 progress row；当前 frontier 由单一 reducer
按 `(task_id, execution_epoch, target_session_id)` 从这些事实推导。response 精确 claim request 本身，
或上一条 failed outcome；同一 frontier 只能有一个 response，Task reopen 只通过既有
`execution_epoch` 使旧 epoch 的 pending request 失效，不再写第二套 cancellation authority。

worker 的 `redispatch` 请求也不直接执行 adapter。`respond_agent_coordination` 只追加可见的
response 与 action；Orchestrator 随后必须在当前投影的委派工具中提交带 `coordination_action_id` 且不带 `workflow_subject` 的
continuation 条目。action 冻结原 dispatch lineage、原派发的可选参考 snapshot、logical occurrence
和 Slice subjects；Host 从该绑定派生 continuation，caller 不能另选 workflow 或制造第二 occurrence。
action 绑定到不可变 child Session，进程重启后仍从同一持久 action 继续。只有 completed 或 failed
terminal outcome；completed outcome 必须由 action-specific durable effect authority 证明，不能由 Tool
输出文本或 generic receipt 自证完成。

Targeted operator steer 的入口是
`POST /task/:taskID/session/:sessionID/operator-steer`。入口只校验持久化
Task/Session/project lineage 与 descriptor 数据完整性。caller 必须提供 `request_id`；服务先全局查找
该 identity 的 immutable request，再决定是否需要读取目标 Session，从而让丢失响应后的 replay 不依赖
当前可变 target 状态。新 request 从目标 Session 最新的 hash-verified `WorkerTurnDescriptor` 冻结
exact projected identity，并在同一个 immediate transaction 写入
`origin="operator_steer"` 的 durable coordination request 与 Task-root ingress。相同 identity 与相同
canonical input 返回原 receipt；相同 identity 与不同 input 返回稳定 typed conflict，不能产生第二次 wake。
旧进程中的 `SessionRuntimeContract` 是否存在、历史 `session.status` 是否 terminal，
都不是准入条件。

`respond_agent_coordination decision=redispatch` 只记录可见的 Agent-to-Agent
operation 与 `redispatch_worker` action。Orchestrator 随后通过当前投影的委派工具中绑定
`coordination_action_id` 的 continuation 条目，在同一 Session 写入一条新的真实输入消息并启动下一
Turn。Runtime 闭包不是可持久化的续跑协议；历史 terminal execution 只是前一条输入消息的执行证据，
不能成为 Session 续跑准入条件。

## Trace — 追踪横切

见 [02-data.md #Trace](02-data.md) — 此处不重复。
简言之：`AgentTrace.record*` → JSONL + Bus 双写。

## server/ — HTTP 路由

**代码**：`src/server/`

- 承载 overlay / CLI / 外部 bot 的 HTTP API
- 关键路由（文件清单以 `src/server/routes/` 为唯一真源）：
  - `routes/channel.ts` — `ChannelIngress.message` HTTP 端点
  - `routes/panel.ts` — `ControlMessage.handle` / `handleStream`（含 panel SSE 流）
  - `routes/orchestrator.ts` — EngineService.createTask 等 task API（含 task-list change stream 与 task event stream 两条 SSE 主线；`describeRoute` 数量以源码为唯一真源）
  - `routes/session.ts` — session mutation
  - `routes/permission.ts` · `routes/project.ts` · `routes/config.ts` · `routes/question.ts` ·
    `routes/provider.ts` · `routes/mcp.ts` · `routes/file.ts` · `routes/skill.ts` ·
    `routes/browser-preview.ts` · `routes/terminal.ts` · `routes/pty.ts` ·
    `routes/gateway.ts` · `routes/global.ts` · `routes/app.ts` · `routes/attachment.ts` ·
    `routes/auth.ts` · `routes/coding.ts` · `routes/documentation.ts` · `routes/mission.ts` ·
    `routes/plugin.ts` · `routes/experimental.ts` · `routes/export.ts`
- **SSE 端点**：通过 `server/sse.ts` 的同一传输边界，入口位于
  `routes/orchestrator.ts`（Task）· `routes/session.ts`（Session/Mission/Side Chat）·
  `routes/work-ledger.ts` · `routes/panel.ts` · `routes/global.ts` · `routes/app.ts` ·
  `routes/interactive-artifact.ts` · `routes/pty.ts`。app 同时承载两处流入口。
  `src/server/event.ts` **不是** SSE 端点，只是一个 7 行的 BusEvent 类型声明文件（`server.connected` / `global.disposed`）。历史文档中"`routes/task-event.ts`"路径不存在；该角色已并入 `routes/orchestrator.ts`。

## 关键文件一览

```
channel/ingress.ts              入站确定性路由
control/message.ts              对话层 LLM + capability 路由
panel/capability.ts             对话层 action 白名单
task-api/index.ts               EngineService（task / session / interaction API）
session/session.sql.ts          session 表（已无 channel_key / gateway 索引）
workspace/workspace.ts          多工作区
control/control.sql.ts          外部控制账号
bus/bus-event.ts                事件总线
trace/index.ts                  JSONL + Bus 双写
server/event.ts                 BusEvent 类型声明（`server.connected` / `global.disposed`，**不是** SSE 端点）
server/routes/orchestrator.ts   task / task event SSE 主线（`streamSSE`）
server/routes/panel.ts          ControlMessage HTTP 入口 + control stream SSE
```

## 相关文档

- [task-control-plane.md](task-control-plane.md) — 进入 EngineService 之后的 Task Control Loop
- [04-extensions.md](04-extensions.md) — channel 类型与 ACP/MCP/plugin 的边界

## Standalone scheduled results

Standalone Event fires and project-scoped Automation runs create their reserved
result Session through the canonical Work conversation factory. The original
fire/run still owns the exact Session and wake Message identities; the Work
metadata makes that result discoverable in the existing ledger and opens it
through the existing Work route. New result titles use the definition name.
Session-bound, Task, Mission and global conversation targets retain their own
identity and creation authority. Versioned data migration exposes historical
standalone results without replaying their input or rewriting Message authors.

## Canonical diagnostic logging

Worktree collection uses the current Project physical Git predicate after root availability and before managed/Git enumeration. An available non-Git Project yields explicit `non-git-project` preservation and an informational diagnostic; an unreadable physical Git marker yields `git-state-unavailable`, while a present invalid Git repository retains `registry-unavailable`. The domain owns one preservation-reason schema and the public cleanup inspection references it. Public reason/code/operation projection excludes internal paths/details; original ownership, candidate qualification and apply/removal contracts remain current.

Backend diagnostic records use one Pino producer: International Organization for Standardization (ISO) 8601 event `time`, method `level` and explicit `message`, optional explicit logger `service`, and actual SessionContext-owned `logDomain`/`sessionID`. Caller tags and extra fields merge as structured `data`; extra wins within that subject namespace. A caller sessionID remains subject data and does not create an ambient Session. Immediate and initialization-buffered records share the same prepared bindings/attributes dispatcher, capturing ambient identity once. Buffered event time retains Pino's drain-time semantics.

Entity lifecycle times remain under `data.time`; diagnostic event time does not replace durable Task, Mission, Session, queue, lease or occurrence chronology. Error serializers and existing redaction run on original method attributes before the library nests them. Empty subject data may be omitted. Raw log read/tail/file/export transport retains its current string/byte contracts. Historical ambiguous timestamps remain unknown and their original raw data is retained; no lifecycle-time, timestamp/ts or plaintext parser reconstructs a current clock.
