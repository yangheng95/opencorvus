import { Bus } from "@/bus"
import { Instance, reenterActiveInstance, runInstanceBackgroundWork } from "@/project/instance"
import { createRightSidebarConversationSession } from "@/chat/session"
import { createInstanceState } from "@/project/instance-state"
import { Database, and, desc, eq, sql } from "@/storage/db"
import { Log } from "@/util/log"
import { Session } from "@/session"
import { MessageTable, SessionTable } from "@/session/session.sql"
import type { SessionWake } from "@/session/wake"
import { Wildcard } from "@/util/wildcard"
import { Identifier } from "@/id/id"
import { createHash, randomUUID } from "node:crypto"
import { isDeepStrictEqual } from "node:util"
import {
  EventJobDefinitionTombstoneTable,
  EventJobFireReceiptTable,
  EventJobFireTable,
  EventJobTable,
  EventOccurrenceTable,
  type EventJobFireCausationEntry,
} from "./event.sql"
import { BusPublicationOutboxTable, BusPublicationOwnerTable } from "@/bus/bus.sql"
import {
  completedOneShotEventDefinitionIDsInTransaction,
  currentEventDefinitionPageInTransaction,
  currentEventFireHeadForDefinitionInTransaction,
  currentEventFireHeadForOccurrenceInTransaction,
  currentEventFireHeadPageInTransaction,
  nextEventFireQueuePositionsInTransaction,
  projectEventFireInTransaction,
  projectEventJobForFireInTransaction,
  projectEventJobInTransaction,
  unresolvedEventProjectPageInTransaction,
  type EventJobFireRow,
  type EventJobRow,
} from "./event-projection"
import {
  acquireControlLeaseInTransaction,
  currentControlLeaseInTransaction,
  releaseControlLeaseInTransaction,
  renewControlLease,
} from "@/engine/control-lease"
import { RuntimeExecutionAdmissionClosedError, RuntimeExecutionSettlement } from "@/runtime/execution-settlement"
import { Project } from "@/project/project"
import { runWithInitializedIndependentProject } from "@/project/independent-project-owner"
import { createSchedulerExecutionInactivityFence } from "./execution-inactivity"
import { requireMissionSession } from "@/mission/session"
import {
  admitMissionExecutionWake,
  MissionExecutionWakeClosedError,
  MissionExecutionWakeNotOpenedError,
  type MissionExecutionWakeAdmission,
} from "@/mission/execution-closure"
import { SchedulerEventWakeReason, schedulerEventWakeReasonJSONPath } from "@/protocol/scheduler-event-wake-reason"
import {
  assertMissionSchedulerOccurrenceAdmission,
  MissionSchedulerOccurrenceClosedError,
  missionSchedulerOccurrenceDisposition,
  type MissionSchedulerOccurrenceDisposition,
} from "@/protocol/delivery"
import { schedulerMissionReservationInTransaction } from "./mission-reservation"
import {
  assertScheduledToolOccurrenceInTransaction,
  scheduledToolOccurrenceConflict,
  type ScheduledToolOccurrence,
} from "./tool-occurrence"
import { FifoPermitPool } from "@/util/queue"
import { globalExecutionCapacity } from "@/runtime/execution-capacity"
import { assertSchedulerProjectOwner, schedulerProjectDisposition } from "./project-owner"
import { Filesystem } from "@/util/filesystem"

type Match = Record<string, string | number | boolean>
type EventEnvelope = Bus.Envelope
type EventJob = EventJobRow
type ScheduleToolCausation = { occurrence: ScheduledToolOccurrence; inputDigest: string }
type EventJobFire = EventJobFireRow

export type EventJobView = {
  id: string
  name: string
  eventType: string
  match: Match
  prompt: string
  enabled: boolean
  oneShot: boolean
  cooldownMs: number
  lastRun: number | null
  lastEvent: string | null
  failureCount: number
  lastError: string | null
}

export type CreateEventJobInput = {
  name: string
  eventType: string
  match?: Match
  prompt: string
  projectId: string
  sessionId?: string
  oneShot?: boolean
  cooldownMs?: number
}

type FireCausation = {
  parentFireID?: string
  ancestry: EventJobFireCausationEntry[]
}

type EventWakeExecutor = (input: {
  fire: EventJobFire
  job: EventJob
  ownerID: string
  signal: AbortSignal
}) => Promise<{ sessionID: string; messageID: string }>
type EventSessionWakePort = Pick<typeof SessionWake, "resumePersistedWakeWithReceipt" | "wakeWithReceipt">
type EventFireAcceptedHook = (fire: EventJobFire) => void | Promise<void>
type BeforeSessionWakeHook = (input: {
  fire: EventJobFire
  ownerID: string
  signal: AbortSignal
}) => void | Promise<void>
type AfterEventFireClaimHook = (input: {
  fire: EventJobFire
  ownerID: string
  signal: AbortSignal
}) => void | Promise<void>

export namespace EventService {
  const log = Log.create({ service: "event-service" })
  const FIRE_LEASE_MS = 30_000
  /**
   * A recovery timer floor. A row whose retry time has already passed while a
   * lease is still live would otherwise re-enter claim every millisecond until
   * that lease expires, which is a hot loop rather than a wait.
   */
  const FIRE_RECOVERY_MIN_DELAY_MS = 250
  /**
   * How often a queued fire re-checks a head that is live in another runtime.
   * The head's own settlement wakes only its runtime, so this poll is what
   * hands the queue over here; the head's full lease is the crash bound.
   */
  const FIRE_RUNNING_HEAD_POLL_MS = 2_500
  const FIRE_LEASE_RENEW_MS = 5_000
  const FIRE_RETRY_BASE_MS = 1_000
  const FIRE_RETRY_MAX_MS = 60_000
  const executionPermits = new FifoPermitPool(4)
  let executionCapacityForTest: number | undefined
  let afterExecutionPermitForTest: ((cancel: (reason: unknown) => void) => void | Promise<void>) | undefined

  async function acquireExecutionPermit(signal: AbortSignal): Promise<() => void> {
    executionPermits.resize(executionCapacityForTest ?? (await globalExecutionCapacity("event")))
    return executionPermits.acquire(signal)
  }

  let wakeExecutorForTest: EventWakeExecutor | undefined
  let fireAcceptedHookForTest: EventFireAcceptedHook | undefined
  let occurrenceAcceptedHookForTest:
    | ((input: { occurrenceID: string; fireIDs: string[]; replayed: boolean }) => void | Promise<void>)
    | undefined
  let beforeSessionWakeForTest: BeforeSessionWakeHook | undefined
  let afterEventFireClaimForTest: AfterEventFireClaimHook | undefined
  let createFireFailuresForTest = 0
  let beforeProcessRollbackRecoveryForTest: (() => void | Promise<void>) | undefined
  let processSettlementGate: { token: symbol; projectIDs: Set<string> } | undefined

  function latestEventDefinitionInTransaction(db: Database.TxOrDb, definitionID: string) {
    const row = db
      .select()
      .from(EventJobTable)
      .where(eq(EventJobTable.definition_id, definitionID))
      .orderBy(sql`${EventJobTable.revision} DESC`, sql`${EventJobTable.id} DESC`)
      .get()
    const tombstone = db
      .select()
      .from(EventJobDefinitionTombstoneTable)
      .where(eq(EventJobDefinitionTombstoneTable.definition_id, definitionID))
      .orderBy(sql`${EventJobDefinitionTombstoneTable.revision} DESC`, sql`${EventJobDefinitionTombstoneTable.id} DESC`)
      .get()
    return row && (!tombstone || row.revision > tombstone.revision) ? row : undefined
  }

  function appendEventDefinitionTombstoneInTransaction(
    db: Database.TxOrDb,
    row: typeof EventJobTable.$inferSelect,
    now: number,
    causation?: ScheduleToolCausation,
  ) {
    if (causation) assertScheduledToolOccurrenceInTransaction(db, causation.occurrence)
    db.insert(EventJobDefinitionTombstoneTable)
      .values({
        id: causation
          ? Identifier.deterministic("event_job", `event-job-tombstone-v1\0${causation.occurrence.toolPartID}`)
          : Identifier.ascending("event_job"),
        definition_id: row.definition_id,
        revision: row.revision + 1,
        tool_part_id: causation?.occurrence.toolPartID,
        tool_input_digest: causation?.inputDigest,
        time_created: now,
      })
      .run()
  }

  const state = createInstanceState(
    () => ({
      unsub: undefined as undefined | (() => void),
      lifecycle: new AbortController(),
      ownerID: `event-fire-owner:${randomUUID()}`,
      directory: Instance.directory,
      running: new Map<string, Promise<void>>(),
      discovery: undefined as Promise<void> | undefined,
      discoveryRequested: false,
      discoveryCursor: undefined as string | undefined,
      discoveryWake: Promise.withResolvers<void>(),
      discoveryRetry: undefined as ReturnType<typeof setTimeout> | undefined,
      recoveryTimers: new Map<string, ReturnType<typeof setTimeout>>(),
      recoveryOperations: new Set<Promise<void>>(),
      runtimeReopen: undefined as Disposable | undefined,
      sessionWake: undefined as EventSessionWakePort | undefined,
    }),
    async (s) => {
      s.unsub?.()
      s.unsub = undefined
      s.runtimeReopen?.[Symbol.dispose]()
      s.runtimeReopen = undefined
      s.lifecycle.abort(new Error("EventService Instance is disposing"))
      for (const timer of s.recoveryTimers.values()) clearTimeout(timer)
      s.recoveryTimers.clear()
      clearTimeout(s.discoveryRetry)
      while (s.recoveryOperations.size > 0) await Promise.allSettled([...s.recoveryOperations])
      while (s.running.size > 0) await Promise.allSettled([...s.running.values()])
      // Instance teardown reaches State disposal only after every serving
      // lease has drained. A discovery promise still present here is therefore
      // waiting for admission behind this same lifecycle turn, not executing
      // an Event effect. Its aborted Instance background owner will settle
      // after the turn releases; awaiting it here would make each side wait on
      // the other.
      const queuedDiscovery = s.discovery
      s.discovery = undefined
      if (queuedDiscovery) void queuedDiscovery.catch(() => undefined)
      s.sessionWake = undefined
    },
    "event-service",
  )

  export function init(input: { sessionWake: EventSessionWakePort }) {
    const s = state()
    if (s.unsub) {
      if (s.sessionWake !== input.sessionWake) {
        throw new Error("EventService is already initialized with a different Session wake owner")
      }
      return
    }
    if (s.lifecycle.signal.aborted) throw new Error("EventService cannot initialize while its Instance is disposing")
    s.sessionWake = input.sessionWake
    s.unsub = Bus.subscribeAll(
      async (event: EventEnvelope) => {
        await accept(event)
      },
      { durableID: "scheduler.event-service", effect: "idempotent_by_occurrence" },
    )
    s.runtimeReopen = RuntimeExecutionSettlement.onAdmissionReopened("scheduler_event_fire", () => {
      runRecoveryOperation(s, recoverProjectFires)
    })
    recoverProjectFires()
    log.info("event service initialized")
  }

  export type ProcessSettlementGate = Disposable & {
    commit(): void
    rollback(): () => Promise<void>
  }

  async function resumeProcessSettlementProjects(projectIDs: ReadonlySet<string>): Promise<void> {
    await beforeProcessRollbackRecoveryForTest?.()
    const failures: unknown[] = []
    for (const projectID of projectIDs) {
      const project = Project.get(projectID)
      if (!project) {
        failures.push(new Error(`Event fire recovery references missing project ${projectID}`))
        continue
      }
      try {
        await runWithInitializedIndependentProject({
          directory: project.worktree,
          fn: async () => {
            if (Instance.project.id !== projectID) {
              throw new Error(`Event fire rollback resolved project ${Instance.project.id}, expected ${projectID}`)
            }
            recoverProjectFires()
            await TestHooks.waitForIdle()
          },
        })
      } catch (error) {
        failures.push(error)
      }
    }
    if (failures.length > 0) {
      throw new AggregateError(failures, "Failed to resume Event fire projects after runtime rollback")
    }
  }

  export function acquireProcessSettlementGate(): ProcessSettlementGate {
    if (processSettlementGate) throw new Error("Event fire process settlement is already in progress")
    const token = Symbol("event-fire-process-settlement")
    const projectIDs = Database.use((db) => {
      const selected = new Set<string>()
      let afterProjectID: string | undefined
      while (true) {
        const page = unresolvedEventProjectPageInTransaction(db, { afterProjectID })
        for (const projectID of page.projectIDs) selected.add(projectID)
        if (!page.hasMore) break
        afterProjectID = page.projectIDs.at(-1)
        if (!afterProjectID) throw new Error("Event unresolved Project page has no cursor")
      }
      return selected
    })
    processSettlementGate = { token, projectIDs }
    let decision: "pending" | "commit" | "rollback" = "pending"
    let disposed = false
    let rollbackCompleted = false
    let rollbackOperation: Promise<void> | undefined
    return {
      commit() {
        if (decision === "rollback") throw new Error("Event fire process settlement rollback is already authoritative")
        decision = "commit"
      },
      rollback() {
        if (decision === "commit") throw new Error("Event fire process settlement commit is already authoritative")
        decision = "rollback"
        return async () => {
          if (!disposed) throw new Error("Event fire rollback can resume only after all runtime admission gates reopen")
          if (rollbackCompleted) return
          if (rollbackOperation) return await rollbackOperation
          rollbackOperation = resumeProcessSettlementProjects(projectIDs).then(() => {
            rollbackCompleted = true
          })
          try {
            await rollbackOperation
          } finally {
            rollbackOperation = undefined
          }
        }
      },
      [Symbol.dispose]() {
        if (processSettlementGate?.token !== token) return
        if (decision === "pending") {
          throw new Error("Event fire process settlement gate requires an explicit commit or rollback decision")
        }
        processSettlementGate = undefined
        disposed = true
      },
    }
  }

  export function list(projectID: string): EventJobView[] {
    const rows = Database.use((db) => {
      const selected: Array<typeof EventJobTable.$inferSelect> = []
      let afterDefinitionID: string | undefined
      while (true) {
        const page = currentEventDefinitionPageInTransaction(db, { projectID, afterDefinitionID })
        selected.push(...page.rows)
        if (!page.hasMore) break
        afterDefinitionID = page.rows.at(-1)?.definition_id
        if (!afterDefinitionID) throw new Error("Event definition page has no cursor")
      }
      return selected
    })
    return rows
      .map((row) => Database.use((db) => projectEventJobInTransaction(db, row, Date.now())))
      .map((j) => ({
        id: j.id,
        name: j.name,
        eventType: j.event_type,
        match: j.match_json ?? {},
        prompt: j.prompt,
        enabled: j.enabled,
        oneShot: j.one_shot,
        cooldownMs: j.cooldown_ms,
        lastRun: j.last_run,
        lastEvent: j.last_event ?? null,
        failureCount: j.failure_count,
        lastError: j.last_error ?? null,
      }))
  }

  async function assertSessionInProject(input: { sessionId?: string; projectId: string }) {
    const sessionId = input.sessionId
    if (!sessionId) return
    await Session.assertLineageInProject({ sessionID: sessionId, projectID: input.projectId })
  }

  export function definitionReceiptInTransaction(row: typeof EventJobTable.$inferSelect) {
    return {
      id: row.definition_id,
      name: row.name,
      eventType: row.event_type,
      oneShot: row.one_shot,
      cooldownMs: row.cooldown_ms,
      match: row.match_json ?? {},
    }
  }

  export function deletionReceiptInTransaction(
    db: Database.TxOrDb,
    tombstone: typeof EventJobDefinitionTombstoneTable.$inferSelect,
  ) {
    const definition = db
      .select()
      .from(EventJobTable)
      .where(
        and(
          eq(EventJobTable.definition_id, tombstone.definition_id),
          eq(EventJobTable.revision, tombstone.revision - 1),
        ),
      )
      .get()
    if (!definition) throw new Error(`Event tombstone ${tombstone.id} has no terminated definition`)
    return { id: definition.definition_id, name: definition.name, projectID: definition.project_id }
  }

  export async function create(input: CreateEventJobInput): Promise<{ id: string; name: string; eventType: string }> {
    const receipt = await createEventJob(input)
    return { id: receipt.id, name: receipt.name, eventType: receipt.eventType }
  }

  export async function createFromTool(
    input: CreateEventJobInput,
    causation: ScheduleToolCausation,
  ): Promise<ReturnType<typeof definitionReceiptInTransaction>> {
    return createEventJob(input, causation)
  }

  async function createEventJob(
    input: CreateEventJobInput,
    causation?: ScheduleToolCausation,
  ): Promise<ReturnType<typeof definitionReceiptInTransaction>> {
    if (causation) {
      const replay = Database.immediateTransaction((db) => {
        assertScheduledToolOccurrenceInTransaction(db, causation.occurrence)
        const existing = db
          .select()
          .from(EventJobTable)
          .where(eq(EventJobTable.tool_part_id, causation.occurrence.toolPartID))
          .get()
        if (!existing) return undefined
        const expectedID = Identifier.deterministic(
          "event_job",
          `event-job-definition-v1\0${causation.occurrence.toolPartID}`,
        )
        if (existing.id !== expectedID || existing.tool_input_digest !== causation.inputDigest) {
          throw scheduledToolOccurrenceConflict(causation.occurrence, "changed its Event create input")
        }
        return existing
      })
      if (replay) return definitionReceiptInTransaction(replay)
    }
    await assertSessionInProject({ sessionId: input.sessionId, projectId: input.projectId })
    const id = causation
      ? Identifier.deterministic("event_job", `event-job-definition-v1\0${causation.occurrence.toolPartID}`)
      : Identifier.ascending("event_job")
    const row = Database.immediateTransaction((db) => {
      assertSchedulerProjectOwner(db, {
        occurrenceID: id,
        projectID: input.projectId,
        generation: Instance.projectGeneration,
      })
      if (causation) {
        assertScheduledToolOccurrenceInTransaction(db, causation.occurrence)
        const existing = db
          .select()
          .from(EventJobTable)
          .where(eq(EventJobTable.tool_part_id, causation.occurrence.toolPartID))
          .get()
        if (existing) {
          if (existing.id !== id || existing.tool_input_digest !== causation.inputDigest) {
            throw scheduledToolOccurrenceConflict(causation.occurrence, "changed its Event create input")
          }
          return existing
        }
      }
      db.insert(EventJobTable)
        .values({
          id,
          definition_id: id,
          revision: 1,
          project_id: input.projectId,
          session_id: input.sessionId,
          name: input.name,
          event_type: input.eventType,
          match_json: input.match,
          prompt: input.prompt,
          enabled: true,
          one_shot: input.oneShot ?? false,
          cooldown_ms: input.cooldownMs ?? 0,
          tool_part_id: causation?.occurrence.toolPartID,
          tool_input_digest: causation?.inputDigest,
        })
        .run()
      return db.select().from(EventJobTable).where(eq(EventJobTable.id, id)).get()!
    })
    return definitionReceiptInTransaction(row)
  }

  export function remove(id: string, projectID: string): boolean {
    return removeEventJob(id, projectID)
  }

  export function removeFromTool(
    id: string,
    projectID: string,
    causation: ScheduleToolCausation,
  ): { id: string; name: string } | undefined {
    return Database.immediateTransaction((db) => {
      assertScheduledToolOccurrenceInTransaction(db, causation.occurrence)
      const replay = db
        .select()
        .from(EventJobDefinitionTombstoneTable)
        .where(eq(EventJobDefinitionTombstoneTable.tool_part_id, causation.occurrence.toolPartID))
        .get()
      if (replay) {
        if (replay.definition_id !== id || replay.tool_input_digest !== causation.inputDigest) {
          throw scheduledToolOccurrenceConflict(causation.occurrence, "changed its Event cancel input")
        }
        const receipt = deletionReceiptInTransaction(db, replay)
        if (receipt.projectID !== projectID) throw new Error(`Cancelled Event task ${id} lost its project identity`)
        return { id: receipt.id, name: receipt.name }
      }
      const row = latestEventDefinitionInTransaction(db, id)
      if (!row || row.project_id !== projectID) return undefined
      appendEventDefinitionTombstoneInTransaction(db, row, Date.now(), causation)
      return { id, name: row.name }
    })
  }

  function removeEventJob(id: string, projectID: string): boolean {
    return Database.immediateTransaction((db) => {
      assertSchedulerProjectOwner(db, { occurrenceID: id, projectID, generation: Instance.projectGeneration })
      const row = latestEventDefinitionInTransaction(db, id)
      if (!row || row.project_id !== projectID) return false
      appendEventDefinitionTombstoneInTransaction(db, row, Date.now())
      return true
    })
  }

  async function accept(event: EventEnvelope): Promise<void> {
    if (event.type === Bus.InstanceDisposed.type) return
    const s = state()
    if (s.lifecycle.signal.aborted) return
    const now = Date.now()
    let replayed = false
    const fires = Database.immediateTransaction((db) => {
      assertSchedulerProjectOwner(db, {
        occurrenceID: event.occurrenceID,
        projectID: Instance.project.id,
        generation: Instance.projectGeneration,
      })
      const outbox = db
        .select()
        .from(BusPublicationOutboxTable)
        .where(eq(BusPublicationOutboxTable.occurrence_id, event.occurrenceID))
        .get()
      if (
        outbox &&
        (outbox.project_id !== Instance.project.id ||
          outbox.event_type !== event.type ||
          !isDeepStrictEqual(outbox.properties, event.properties))
      )
        throw new Error(`Event occurrence ${event.occurrenceID} conflicts with its immutable input fact`)
      if (outbox) {
        const owner = db
          .select()
          .from(BusPublicationOwnerTable)
          .where(eq(BusPublicationOwnerTable.occurrence_id, outbox.occurrence_id))
          .get()
        if (!owner) throw new Error(`Event source ${event.occurrenceID} has no immutable owner fact`)
        assertSchedulerProjectOwner(db, {
          occurrenceID: event.occurrenceID,
          projectID: outbox.project_id,
          generation: owner.project_generation,
        })
      }
      const existing = db
        .select()
        .from(EventOccurrenceTable)
        .where(eq(EventOccurrenceTable.id, event.occurrenceID))
        .get()
      const occurrence = {
        id: event.occurrenceID,
        bus_outbox_id: outbox?.occurrence_id ?? null,
        project_id: outbox ? null : Instance.project.id,
        event_type: outbox ? null : event.type,
        properties: outbox ? null : event.properties,
        time_created: now,
      }
      if (existing) {
        if (
          existing.bus_outbox_id !== occurrence.bus_outbox_id ||
          existing.project_id !== occurrence.project_id ||
          existing.event_type !== occurrence.event_type ||
          !isDeepStrictEqual(existing.properties, occurrence.properties)
        )
          throw new Error(`Event occurrence ${event.occurrenceID} conflicts with its immutable input fact`)
        replayed = true
        return []
      }
      // This fact and all matched Fires share this writer snapshot. Durable
      // empty acceptance is an effect too; a later definition cannot consume it.
      if (outbox) db.insert(EventOccurrenceTable).values(occurrence).run()
      const accepted: EventJobFire[] = []
      let afterDefinitionID: string | undefined
      let causation: FireCausation | undefined
      while (true) {
        const page = currentEventDefinitionPageInTransaction(db, {
          projectID: Instance.project.id,
          afterDefinitionID,
        })
        const completedOneShot = completedOneShotEventDefinitionIDsInTransaction(db, page.rows)
        const matches = page.rows.filter(
          (job) =>
            job.enabled &&
            !completedOneShot.has(job.definition_id) &&
            Wildcard.match(event.type, job.event_type) &&
            ok(event, job.match_json ?? {}),
        )
        if (matches.length > 0) {
          if (!outbox && accepted.length === 0) db.insert(EventOccurrenceTable).values(occurrence).run()
          causation ??= resolveCausation(event)
          accepted.push(
            ...createFires({
              jobs: matches,
              occurrenceID: event.occurrenceID,
              causation,
              now,
            }),
          )
        }
        if (!page.hasMore) break
        afterDefinitionID = page.rows.at(-1)?.definition_id
        if (!afterDefinitionID) throw new Error("Event definition page has no cursor")
      }
      return accepted
    })
    await occurrenceAcceptedHookForTest?.({
      occurrenceID: event.occurrenceID,
      fireIDs: fires.map((fire) => fire.id),
      replayed,
    })
    if (fires.length === 0 && !replayed) return
    processSettlementGate?.projectIDs.add(Instance.project.id)
    for (const fire of fires) {
      await fireAcceptedHookForTest?.(fire)
    }
    recoverProjectFires()
  }

  function createFires(input: {
    jobs: Array<typeof EventJobTable.$inferSelect>
    occurrenceID: string
    causation: FireCausation
    now: number
  }): EventJobFire[] {
    if (createFireFailuresForTest > 0) {
      createFireFailuresForTest -= 1
      throw new Error("injected Event fire durable insert failure")
    }
    return Database.immediateTransaction((db) => {
      const queuePositions = nextEventFireQueuePositionsInTransaction(
        db,
        input.jobs.map((job) => job.definition_id),
      )
      return input.jobs.map((job) => {
        const fireID = Identifier.ascending("call")
        const queuePosition = queuePositions.get(job.definition_id)
        if (!queuePosition) throw new Error(`Event definition ${job.definition_id} has no queue position`)
        const cycle = input.causation.ancestry.some((entry) => entry.jobID === job.definition_id)
        const missionReservation = schedulerMissionReservationInTransaction(db, job.session_id)
        const inserted = db
          .insert(EventJobFireTable)
          .values({
            id: fireID,
            definition_id: job.definition_id,
            queue_position: queuePosition,
            event_job_revision_id: job.id,
            event_occurrence_id: input.occurrenceID,
            project_generation: Instance.projectGeneration,
            causation_fire_id: input.causation.parentFireID,
            causal_cycle: cycle,
            created_session_id: job.session_id === null ? Identifier.ascending("session") : null,
            mission_opened_event_id: missionReservation.openedEventID,
            mission_disposition: missionReservation.disposition,
            mission_closure_event_id: missionReservation.closureEventID,
            time_created: input.now,
          })
          .onConflictDoNothing({
            target: [EventJobFireTable.event_job_revision_id, EventJobFireTable.event_occurrence_id],
          })
          .returning()
          .get()
        if (inserted) {
          return projectEventFireInTransaction(db, inserted, input.now)
        }
        const existing = db
          .select()
          .from(EventJobFireTable)
          .where(
            and(
              eq(EventJobFireTable.event_job_revision_id, job.id),
              eq(EventJobFireTable.event_occurrence_id, input.occurrenceID),
            ),
          )
          .get()
        if (!existing) {
          throw new Error(
            `Event occurrence ${input.occurrenceID} conflict has no durable fire for job ${job.definition_id}`,
          )
        }
        return projectEventFireInTransaction(db, existing, input.now)
      })
    })
  }

  function resolveCausation(event: EventEnvelope): FireCausation {
    if (event.causation?.source === "scheduler.event") {
      const parent = requireParentFire(event.causation.occurrenceID)
      return causationFromParent(parent)
    }
    const wakeReason = eventWakeReason(event)
    if (wakeReason?.source === "scheduler.event") {
      const parent = requireParentFire(wakeReason.fireID)
      if (parent.event_job_id !== wakeReason.jobID) {
        throw new Error(
          `Event wake ${wakeReason.fireID} names job ${wakeReason.jobID}, expected ${parent.event_job_id}`,
        )
      }
      return causationFromParent(parent)
    }
    if (event.type !== Session.Event.Created.type) return { ancestry: [] }
    const sessionID = eventInfoID(event)
    if (!sessionID) return { ancestry: [] }
    const parent = Database.use((db) => {
      const candidate = db
        .select({ fire: EventJobFireTable })
        .from(EventJobFireTable)
        .innerJoin(EventJobTable, eq(EventJobTable.id, EventJobFireTable.event_job_revision_id))
        .where(
          and(eq(EventJobFireTable.created_session_id, sessionID), eq(EventJobTable.project_id, Instance.project.id)),
        )
        .orderBy(desc(EventJobFireTable.time_created), desc(EventJobFireTable.id))
        .get()
      return candidate ? projectEventFireInTransaction(db, candidate.fire, Date.now()) : undefined
    })
    return parent ? causationFromParent(parent) : { ancestry: [] }
  }

  function eventWakeReason(event: EventEnvelope): SchedulerEventWakeReason | undefined {
    const properties = objectRecord(event.properties)
    const info = objectRecord(properties?.info)
    const extra = objectRecord(info?.extra)
    const parsed = SchedulerEventWakeReason.safeParse(extra?.wake_reason)
    return parsed.success ? parsed.data : undefined
  }

  function eventInfoID(event: EventEnvelope): string | undefined {
    const properties = objectRecord(event.properties)
    const info = objectRecord(properties?.info)
    return typeof info?.id === "string" ? info.id : undefined
  }

  function requireParentFire(fireID: string): EventJobFire {
    const parent = Database.use((db) => {
      const row = db.select().from(EventJobFireTable).where(eq(EventJobFireTable.id, fireID)).get()
      return row ? projectEventFireInTransaction(db, row, Date.now()) : undefined
    })
    if (!parent || parent.project_id !== Instance.project.id)
      throw new Error(`Event wake ${fireID} has no durable Event Job fire authority`)
    return parent
  }

  function causationFromParent(parent: EventJobFire): FireCausation {
    return {
      parentFireID: parent.id,
      ancestry: [...parent.causation_ancestry, { fireID: parent.id, jobID: parent.event_job_id }],
    }
  }

  function recoverProjectFires(): void {
    const s = state()
    if (s.lifecycle.signal.aborted) return
    s.discoveryRequested = true
    s.discoveryWake.resolve()
    if (s.discovery) return
    s.discoveryRequested = false
    let discovery!: Promise<void>
    discovery = Database.runOutsideContext(() =>
      runInstanceBackgroundWork(
        "event-fire-discovery",
        async (signal) => {
          try {
            while (!signal.aborted && !s.lifecycle.signal.aborted) {
              s.discoveryRequested = false
              s.discoveryWake = Promise.withResolvers<void>()
              const head = nextRunnableProjectHead()
              if (!head) {
                if (s.running.size === 0) return
                await Promise.race([...s.running.values(), s.discoveryWake.promise])
                continue
              }
              const release = await acquireExecutionPermit(signal)
              try {
                signal.throwIfAborted()
                enqueueFire(head.fire.id, head.definitionID, release, signal)
              } catch (error) {
                release()
                if (error instanceof RuntimeExecutionAdmissionClosedError && error.kind === "scheduler_event_fire")
                  return
                throw error
              }
            }
          } catch (error) {
            if (!signal.aborted && !s.lifecycle.signal.aborted && !s.discoveryRetry) {
              s.discoveryRetry = setTimeout(() => {
                s.discoveryRetry = undefined
                runRecoveryOperation(s, recoverProjectFires)
              }, FIRE_RECOVERY_MIN_DELAY_MS)
            }
            throw error
          } finally {
            await Promise.allSettled(s.running.values())
          }
        },
        s.lifecycle.signal,
      ).finally(() => {
        if (s.discovery === discovery) s.discovery = undefined
        if (s.discoveryRequested && !s.lifecycle.signal.aborted) runRecoveryOperation(s, recoverProjectFires)
      }),
    )
    s.discovery = discovery
  }

  function nextRunnableProjectHead() {
    const s = state()
    const now = Date.now()
    let afterDefinitionID = s.discoveryCursor
    let wrapped = afterDefinitionID === undefined
    while (true) {
      const page = Database.use((db) =>
        currentEventFireHeadPageInTransaction(db, {
          projectID: Instance.project.id,
          now,
          afterDefinitionID,
        }),
      )
      for (const head of page.rows) {
        if (s.running.has(head.fire.id) || s.recoveryTimers.has(head.fire.id)) continue
        if (head.status === "pending") {
          s.discoveryCursor = head.definitionID
          return head
        }
        scheduleLeaseRecovery(head.fire.id)
      }
      if (!page.hasMore) {
        if (wrapped) break
        afterDefinitionID = undefined
        wrapped = true
        continue
      }
      afterDefinitionID = page.nextDefinitionID
      if (!afterDefinitionID) throw new Error("Event Fire head page has no cursor")
    }
  }

  function enqueueFire(fireID: string, jobID: string, release: () => void, discoverySignal: AbortSignal): void {
    const s = state()
    const runtimeReservation = RuntimeExecutionSettlement.reserve("scheduler_event_fire", `event-fire:${fireID}`)
    let current!: Promise<void>
    current = Promise.resolve()
      .then(async () => {
        if (s.lifecycle.signal.aborted) return
        runtimeReservation.signal.throwIfAborted()
        await afterExecutionPermitForTest?.((reason) => runtimeReservation.cancel(reason))
        runtimeReservation.signal.throwIfAborted()
        await processFire(fireID, AbortSignal.any([runtimeReservation.signal, discoverySignal]))
      })
      .catch((error) => {
        scheduleLeaseRecovery(fireID)
        log.error("event fire execution failed", {
          fireID,
          jobID,
          error: error instanceof Error ? error.message : String(error),
        })
      })
      .finally(() => {
        if (s.running.get(fireID) === current) s.running.delete(fireID)
        release()
      })
    s.running.set(fireID, current)
    runtimeReservation.settleWith(current)
  }

  async function admitEventSessionWake<Receipt extends { activation: Promise<unknown> }>(
    session: Session.Info,
    wake: (admission?: MissionExecutionWakeAdmission) => Receipt | Promise<Receipt>,
  ): Promise<Receipt> {
    if (session.kind !== "mission") return wake()
    const mission = await requireMissionSession(session.id)
    return admitMissionExecutionWake({
      missionID: mission.missionID,
      sessionID: mission.id,
      wake: (admission) => wake(admission),
    })
  }

  async function resumeEventWake(input: {
    session: Session.Info
    messageID: string
    fire: EventJobFire
  }): Promise<void> {
    await admitEventSessionWake(input.session, (missionAdmission) =>
      requireSessionWake().resumePersistedWakeWithReceipt({
        sessionID: input.session.id,
        messageID: input.messageID,
        directory: input.session.directory,
        ownerPreflight: (db) => {
          assertEventProjectOwner(db, input.fire)
          missionAdmission?.ownerPreflight?.(db)
        },
        ownerLifecycle: missionAdmission?.ownerLifecycle,
      }),
    )
  }

  function missionDispositionForEventFire(
    fire: Pick<
      EventJobFire,
      "target_session_id" | "mission_opened_event_id" | "mission_disposition" | "mission_closure_event_id"
    >,
  ): MissionSchedulerOccurrenceDisposition | undefined {
    const session = Database.use((db) =>
      db
        .select({ id: SessionTable.id })
        .from(SessionTable)
        .where(and(eq(SessionTable.id, fire.target_session_id), eq(SessionTable.kind, "mission")))
        .get(),
    )
    if (!session) return undefined
    if (fire.mission_disposition === "mission_closed" && fire.mission_closure_event_id) {
      return {
        kind: "mission_closed",
        openedEventID: null,
        closureEventID: fire.mission_closure_event_id,
      }
    }
    return missionSchedulerOccurrenceDisposition({
      sessionID: session.id,
      openedEventID: fire.mission_opened_event_id,
    })
  }

  async function processFire(fireID: string, runtimeSignal: AbortSignal): Promise<void> {
    const s = state()
    const claimed = claimFire(fireID, s.ownerID)
    if (!claimed) {
      scheduleLeaseRecovery(fireID)
      return
    }
    const leaseFence = createEventFireLeaseFence(claimed.id, s.ownerID)
    using inactivityFence = await createSchedulerExecutionInactivityFence({
      occurrence: `Event fire ${claimed.id}`,
      signals: [s.lifecycle.signal, runtimeSignal, leaseFence.signal],
      initialPhase: "claimed",
      configurationOwner: "project",
    })
    const signal = inactivityFence.signal
    const renewTimer = setInterval(() => leaseFence.renewOrAbort(), FIRE_LEASE_RENEW_MS)
    renewTimer.unref()
    let job: EventJob | undefined
    try {
      await afterEventFireClaimForTest?.({ fire: claimed, ownerID: s.ownerID, signal })
      throwIfAborted(signal)
      const ownerDisposition = Database.use((db) =>
        schedulerProjectDisposition(db, {
          projectID: claimed.project_id,
          generation: claimed.project_generation,
        }),
      )
      if (ownerDisposition) {
        settleDisposition(claimed, s.ownerID, ownerDisposition, null)
        return
      }
      Database.use((db) => assertEventProjectOwner(db, claimed))
      inactivityFence.touch("wake reconciliation")
      const existingMessageID = findWakeMessageID(claimed)
      job = Database.use((db) => {
        const persisted = db
          .select()
          .from(EventJobTable)
          .where(
            and(eq(EventJobTable.id, claimed.event_job_revision_id), eq(EventJobTable.project_id, claimed.project_id)),
          )
          .get()
        return persisted ? projectEventJobForFireInTransaction(db, persisted, claimed) : undefined
      })
      inactivityFence.touch("job resolved")
      const missionDisposition = missionDispositionForEventFire(claimed)
      if (missionDisposition?.kind === "mission_closed") {
        settleDisposition(claimed, s.ownerID, "mission_closed", null, missionDisposition.closureEventID)
        return
      }
      if (claimed.causal_cycle) {
        settleDisposition(claimed, s.ownerID, "causal_cycle", "Event causation cycle")
        return
      }
      if (Database.use((db) => Session.deletedInTransaction(db, claimed.target_session_id))) {
        settleDisposition(claimed, s.ownerID, "target_deleted", null)
        return
      }
      if (existingMessageID) {
        const session = await Session.get(claimed.target_session_id)
        throwIfAborted(signal)
        await resumeEventWake({ session, messageID: existingMessageID, fire: claimed })
        settleSuccess(claimed, job, s.ownerID, claimed.target_session_id, existingMessageID)
        return
      }
      if (!job || !job.enabled) {
        settleDisposition(claimed, s.ownerID, "job_disabled", "Event Job is no longer enabled")
        return
      }
      if (!ready(job, Date.now())) {
        settleDisposition(claimed, s.ownerID, "cooldown", "Event Job cooldown has not elapsed")
        return
      }

      const activeJob = job
      inactivityFence.touch("wake dispatch")
      const result = await Bus.withCausation(
        {
          source: "scheduler.event",
          occurrenceID: claimed.id,
        },
        () => (wakeExecutorForTest ?? executeWake)({ fire: claimed, job: activeJob, ownerID: s.ownerID, signal }),
      )
      throwIfAborted(signal)
      inactivityFence.touch("durable success settlement")
      settleSuccess(claimed, activeJob, s.ownerID, result.sessionID, result.messageID)
    } catch (error) {
      try {
        const reconciledMessageID = findWakeMessageID(claimed)
        const missionAdmissionRejected =
          MissionExecutionWakeClosedError.isInstance(error) ||
          MissionExecutionWakeNotOpenedError.isInstance(error) ||
          MissionSchedulerOccurrenceClosedError.isInstance(error)
        const ownerDisposition = Database.use((db) =>
          schedulerProjectDisposition(db, {
            projectID: claimed.project_id,
            generation: claimed.project_generation,
          }),
        )
        if (ownerDisposition && !leaseFence.lost) {
          settleDisposition(claimed, s.ownerID, ownerDisposition, null)
        } else if (missionAdmissionRejected && !leaseFence.lost) {
          const disposition = missionDispositionForEventFire(claimed)
          if (disposition?.kind !== "mission_closed") throw error
          settleDisposition(claimed, s.ownerID, "mission_closed", null, disposition.closureEventID)
        } else if (
          !leaseFence.lost &&
          Database.use((db) => Session.deletedInTransaction(db, claimed.target_session_id))
        ) {
          settleDisposition(claimed, s.ownerID, "target_deleted", null)
        } else if (reconciledMessageID && !leaseFence.lost) {
          const session = await Session.get(claimed.target_session_id)
          throwIfAborted(leaseFence.signal)
          await resumeEventWake({ session, messageID: reconciledMessageID, fire: claimed })
          settleSuccess(claimed, job, s.ownerID, claimed.target_session_id, reconciledMessageID)
        } else if (leaseFence.lost) {
          scheduleLeaseRecovery(claimed.id)
        } else if (s.lifecycle.signal.aborted || runtimeSignal.aborted) {
          deferFire(claimed, s.ownerID, error)
        } else {
          scheduleRetry(claimed, job, s.ownerID, error)
        }
      } catch (settlementError) {
        log.error("event fire failure settlement failed", {
          fireID: claimed.id,
          jobID: claimed.event_job_id,
          error: errorMessage(error),
          settlementError: errorMessage(settlementError),
        })
      }
    } finally {
      clearInterval(renewTimer)
      // Every nonterminal claim exit retains a same-identity recovery owner.
      // Terminal rows make this a no-op. A retry_wait receipt now ends its own
      // lease, so its recovery schedule is the receipt's `retry_at`; a
      // deferred or lost claim still rides the current owner's lease.
      scheduleLeaseRecovery(claimed.id)
    }
  }

  /**
   * Take the fire owner for the exact fire that is still at the head of its
   * job's queue.
   *
   * Head-of-queue validation and lease acquisition share one write
   * transaction. Split apart, another process can settle or supersede the fire
   * between the two, and this claim then holds a lease over a fire it never
   * validated.
   */
  function claimFire(fireID: string, ownerID: string): EventJobFire | undefined {
    const now = Date.now()
    return Database.immediateTransaction((db) => {
      const candidate = db
        .select({ fire: EventJobFireTable, projectID: EventJobTable.project_id })
        .from(EventJobFireTable)
        .innerJoin(EventJobTable, eq(EventJobTable.id, EventJobFireTable.event_job_revision_id))
        .where(eq(EventJobFireTable.id, fireID))
        .get()
      if (!candidate) return undefined
      const head = currentEventFireHeadForOccurrenceInTransaction(db, {
        projectID: candidate.projectID,
        fireID,
        now,
      })
      if (!head || head.status !== "pending") return undefined
      const acquired = acquireControlLeaseInTransaction(db, {
        target: "event_fire",
        targetID: fireID,
        ownerOccurrenceID: ownerID,
        now,
        leaseMilliseconds: FIRE_LEASE_MS,
      })
      if (!acquired.acquired) return undefined
      // Re-project inside the same transaction. `attempt` and `time_started`
      // are derived from the lease rows, so a projection taken before the
      // acquire under-counts this very attempt — and `attempt` is the retry
      // backoff exponent.
      return projectEventFireInTransaction(db, candidate.fire, now)
    })
  }

  function scheduleLeaseRecovery(fireID: string): void {
    const s = state()
    if (s.lifecycle.signal.aborted || s.recoveryTimers.has(fireID)) return
    let row: { status: EventJobFire["status"]; lease: number } | undefined
    try {
      row = Database.use((db) => {
        const persisted = db
          .select({
            fire: EventJobFireTable,
            projectID: EventJobTable.project_id,
            definitionID: EventJobTable.definition_id,
          })
          .from(EventJobFireTable)
          .innerJoin(EventJobTable, eq(EventJobTable.id, EventJobFireTable.event_job_revision_id))
          .where(eq(EventJobFireTable.id, fireID))
          .get()
        if (!persisted) return undefined
        const now = Date.now()
        const head = currentEventFireHeadForDefinitionInTransaction(db, {
          projectID: persisted.projectID,
          definitionID: persisted.definitionID,
          now,
        })
        if (!head || head.fire.id !== persisted.fire.id) return undefined
        // Only the current head has an in-memory recovery timer. Remote
        // completion may advance it before its lease expires; retry deadlines
        // remain owned by their immutable receipt.
        const deadline =
          head.status === "running"
            ? Math.min(head.leaseUntil, now + FIRE_RUNNING_HEAD_POLL_MS)
            : (head.retryAt ?? head.leaseUntil)
        return {
          status: head.status,
          lease: deadline,
        }
      })
    } catch (error) {
      log.warn("event fire recovery metadata read failed", { fireID, error: errorMessage(error) })
      scheduleRecoveryControlRetry(s, fireID)
      return
    }
    if (!row || (row.status !== "pending" && row.status !== "running" && row.status !== "retry_wait")) return
    const timer = setTimeout(
      () => {
        s.recoveryTimers.delete(fireID)
        try {
          // Recovery owns the definition frontier, not the Fire that happened
          // to seed this timer. A remote owner may have terminalized that Fire
          // and crashed before its process-local FIFO handoff; rereading here
          // transfers recovery to the durable successor.
          runRecoveryOperation(s, recoverProjectFires)
        } catch (error) {
          if (error instanceof RuntimeExecutionAdmissionClosedError && error.kind === "scheduler_event_fire") {
            log.info("event fire recovery deferred while runtime admission is closed", { fireID })
            return
          }
          log.error("event fire recovery enqueue failed", { fireID, error: errorMessage(error) })
          scheduleRecoveryControlRetry(s, fireID)
        }
      },
      // A row with no deadline of its own was refused by something else —
      // usually a head-of-queue fire running in another runtime — and this
      // timer is the only thing that will ask the definition frontier again.
      // Re-asking immediately is
      // a poll for the whole of that other attempt, so every refused claim
      // backs off. The head-of-queue handoff inside this runtime does not come
      // through here; completion requests durable head discovery directly.
      Math.max(FIRE_RECOVERY_MIN_DELAY_MS, row.lease - Date.now() + 1),
    )
    s.recoveryTimers.set(fireID, timer)
  }

  function scheduleRecoveryControlRetry(s: ReturnType<typeof state>, fireID: string): void {
    if (s.lifecycle.signal.aborted || s.recoveryTimers.has(fireID)) return
    const timer = setTimeout(() => {
      s.recoveryTimers.delete(fireID)
      runRecoveryOperation(s, () => scheduleLeaseRecovery(fireID))
    }, 250)
    s.recoveryTimers.set(fireID, timer)
  }

  function runRecoveryOperation(s: ReturnType<typeof state>, recover: () => void): void {
    if (s.lifecycle.signal.aborted) return
    let operation!: Promise<void>
    operation = Database.runOutsideContext(() =>
      reenterActiveInstance({
        directory: s.directory,
        signal: s.lifecycle.signal,
        fn: () => {
          if (state() === s && !s.lifecycle.signal.aborted) recover()
        },
      }),
    )
      .catch((error) => {
        if (s.lifecycle.signal.aborted) return
        log.error("event recovery operation failed", { directory: s.directory, error: errorMessage(error) })
      })
      .finally(() => s.recoveryOperations.delete(operation))
    s.recoveryOperations.add(operation)
  }

  function renewFireLease(fireID: string, ownerID: string): boolean {
    const now = Date.now()
    const lease = Database.use((db) => currentControlLeaseInTransaction(db, "event_fire", fireID))
    if (!lease || lease.owner_occurrence_id !== ownerID || lease.expires_at <= now) return false
    renewControlLease({
      target: "event_fire",
      targetID: fireID,
      leaseID: lease.id,
      ownerOccurrenceID: ownerID,
      now,
      expiresAt: now + FIRE_LEASE_MS,
    })
    return true
  }

  function createEventFireLeaseFence(
    fireID: string,
    ownerID: string,
    renewLease: (fireID: string, ownerID: string) => boolean = renewFireLease,
  ) {
    const controller = new AbortController()
    let lost = false
    const lose = (cause: unknown) => {
      if (lost) return
      lost = true
      const reason = cause instanceof Error ? cause : new Error(String(cause))
      controller.abort(reason)
      log.warn("event fire lease fence lost", { fireID, ownerID, error: reason.message })
    }
    return {
      signal: controller.signal,
      get lost() {
        return lost
      },
      renewOrAbort(): boolean {
        try {
          if (renewLease(fireID, ownerID)) return true
          lose(new Error(`Event fire ${fireID} lease owner changed`))
        } catch (error) {
          lose(error)
        }
        return false
      },
    }
  }

  async function executeWake(input: {
    fire: EventJobFire
    job: EventJob
    ownerID: string
    signal: AbortSignal
  }): Promise<{ sessionID: string; messageID: string }> {
    throwIfAborted(input.signal)
    Database.use((db) => assertEventProjectOwner(db, input.fire))
    const target = Database.use((db) =>
      db
        .select({ directory: SessionTable.directory })
        .from(SessionTable)
        .where(eq(SessionTable.id, input.fire.target_session_id))
        .get(),
    )
    if (target)
      await Session.assertLineageInProject({
        sessionID: input.fire.target_session_id,
        projectID: input.fire.project_id,
      })
    // Event definitions name a Project or an existing Session. Their source
    // publication's ambient working directory is not another target identity.
    const directory = target?.directory ?? Project.get(input.fire.project_id)!.worktree
    if (Filesystem.resolve(Instance.directory) !== Filesystem.resolve(directory)) {
      return runWithInitializedIndependentProject({ directory, signal: input.signal, fn: () => executeWake(input) })
    }
    if (input.fire.creates_session) {
      const existing = Database.use((db) =>
        db
          .select({ id: SessionTable.id })
          .from(SessionTable)
          .where(eq(SessionTable.id, input.fire.target_session_id))
          .get(),
      )
      if (!existing) {
        await createRightSidebarConversationSession("work", {
          id: input.fire.target_session_id,
          title: input.job.name,
          commitInTransaction: (_db, session) =>
            fenceEventWakeCommit({
              fireID: input.fire.id,
              ownerID: input.ownerID,
              sessionID: session.id,
            }),
        })
      }
    }
    throwIfAborted(input.signal)
    const messageID = deterministicEventWakeID("msg", input.fire.id)
    const textPartID = deterministicEventWakeID("prt", input.fire.id)
    await beforeSessionWakeForTest?.({ fire: input.fire, ownerID: input.ownerID, signal: input.signal })
    throwIfAborted(input.signal)
    const session = await Session.get(input.fire.target_session_id)
    const receipt = await admitEventSessionWake(session, (missionAdmission) => {
      if (missionAdmission) {
        if (!input.fire.mission_opened_event_id) {
          throw new Error(`Event fire ${input.fire.id} has no exact Mission opened occurrence binding`)
        }
        assertMissionSchedulerOccurrenceAdmission({
          sessionID: input.fire.target_session_id,
          openedEventID: input.fire.mission_opened_event_id,
          admissionOpenedEventID: missionAdmission.closureEventID,
        })
      }
      return requireSessionWake().wakeWithReceipt({
        sessionID: input.fire.target_session_id,
        messageID,
        textPartID,
        signal: input.signal,
        prompt: input.job.prompt,
        author: "orchestrator",
        agent: input.job.agent === "default" ? undefined : input.job.agent,
        reason: {
          source: "scheduler.event",
          jobID: input.job.id,
          jobName: input.job.name,
          fireID: input.fire.id,
          eventType: input.fire.event_type,
          oneShot: input.job.one_shot,
        },
        commitBundle: (message, parts) => {
          if (message.id !== messageID || !parts.some((part) => part.id === textPartID)) {
            throw new Error(`Event fire ${input.fire.id} wake materialized identities outside its durable authority`)
          }
          fenceEventWakeCommit({
            fireID: input.fire.id,
            ownerID: input.ownerID,
            sessionID: message.sessionID,
          })
        },
        preflightBundle: missionAdmission?.preflightBundle,
        ownerPreflight: (db) => {
          assertEventProjectOwner(db, input.fire)
          missionAdmission?.ownerPreflight?.(db)
        },
        ownerLifecycle: missionAdmission?.ownerLifecycle,
      })
    })
    const sessionID = receipt.sessionID
    const persistedMessageID = findWakeMessageID(input.fire)
    if (persistedMessageID !== messageID) {
      throw new Error(`Event fire ${input.fire.id} wake returned outside its deterministic Message identity`)
    }
    return { sessionID, messageID: persistedMessageID }
  }

  function fenceEventWakeCommit(input: { fireID: string; ownerID: string; sessionID: string }): void {
    const committedAt = Date.now()
    const authority = Database.use((db) => {
      const row = db.select().from(EventJobFireTable).where(eq(EventJobFireTable.id, input.fireID)).get()
      const fire = row ? projectEventFireInTransaction(db, row, committedAt) : undefined
      if (fire) assertEventProjectOwner(db, fire)
      return fire
    })
    if (
      authority?.status !== "running" ||
      authority.owner_id !== input.ownerID ||
      authority.lease_until <= committedAt ||
      authority.target_session_id !== input.sessionID
    ) {
      throw new Error(`Event fire ${input.fireID} lost its lease before wake Message commit`)
    }
  }

  function assertEventProjectOwner(db: Database.TxOrDb, fire: EventJobFire, requireInstance = true): void {
    assertSchedulerProjectOwner(
      db,
      { occurrenceID: fire.id, projectID: fire.project_id, generation: fire.project_generation },
      requireInstance,
    )
  }

  function deterministicEventWakeID(prefix: "msg" | "prt", fireID: string): string {
    const digest = createHash("sha256").update(fireID).digest("hex")
    return `${prefix}_event_${digest.slice(0, 32)}`
  }

  function findWakeMessageID(fire: Pick<EventJobFire, "id" | "target_session_id">): string | undefined {
    const rows = Database.use((db) =>
      db
        .select({ id: MessageTable.id })
        .from(MessageTable)
        .where(
          and(
            eq(MessageTable.session_id, fire.target_session_id),
            sql`json_extract(${MessageTable.data}, ${schedulerEventWakeReasonJSONPath("source")}) = 'scheduler.event'`,
            sql`json_extract(${MessageTable.data}, ${schedulerEventWakeReasonJSONPath("fireID")}) = ${fire.id}`,
          ),
        )
        .orderBy(MessageTable.time_created, MessageTable.id)
        .limit(2)
        .all(),
    )
    if (rows.length > 1) throw new Error(`Event fire ${fire.id} has ${rows.length} persisted wake Messages`)
    return rows[0]?.id
  }

  function settleSuccess(
    fire: EventJobFire,
    job: EventJob | undefined,
    ownerID: string,
    sessionID: string,
    messageID: string,
  ): void {
    const now = Date.now()
    Database.immediateTransaction((db) => {
      assertEventProjectOwner(db, fire)
      const terminal = db
        .select()
        .from(EventJobFireReceiptTable)
        .where(
          and(eq(EventJobFireReceiptTable.fire_id, fire.id), sql`${EventJobFireReceiptTable.outcome} <> 'retry_wait'`),
        )
        .get()
      if (terminal) {
        if (terminal.outcome !== "succeeded" || terminal.message_id !== messageID)
          throw new Error(`Event fire ${fire.id} conflicts with its immutable terminal receipt`)
        return
      }
      const lease = currentControlLeaseInTransaction(db, "event_fire", fire.id)
      if (
        !lease ||
        lease.owner_occurrence_id !== ownerID ||
        lease.expires_at <= now ||
        fire.target_session_id !== sessionID
      )
        throw new Error(`Event fire ${fire.id} owner is no longer authoritative at success`)
      db.insert(EventJobFireReceiptTable)
        .values({
          id: Identifier.ascending("call"),
          fire_id: fire.id,
          definition_id: fire.definition_id,
          queue_position: fire.queue_position,
          outcome: "succeeded",
          disposition: null,
          message_id: messageID,
          retry_at: null,
          error: null,
          time_created: now,
        })
        .run()
      releaseControlLeaseInTransaction(db, {
        target: "event_fire",
        targetID: fire.id,
        leaseID: lease.id,
        ownerOccurrenceID: ownerID,
        now,
      })
    })
    recoverProjectFires()
    log.info("event job fire settled", {
      jobId: fire.event_job_id,
      fireID: fire.id,
      event: fire.event_type,
      sessionID,
      messageID,
      oneShot: job?.one_shot ?? false,
    })
  }

  function settleDisposition(
    fire: EventJobFire,
    ownerID: string,
    disposition:
      | "causal_cycle"
      | "cooldown"
      | "job_disabled"
      | "mission_closed"
      | "target_deleted"
      | "owner_unresolved",
    error: string | null,
    closureEventID: string | null = null,
  ): void {
    const now = Date.now()
    const settled = Database.immediateTransaction((db) => {
      const terminal = db
        .select()
        .from(EventJobFireReceiptTable)
        .where(
          and(eq(EventJobFireReceiptTable.fire_id, fire.id), sql`${EventJobFireReceiptTable.outcome} <> 'retry_wait'`),
        )
        .get()
      if (terminal) {
        if (
          terminal.outcome !== "disposition" ||
          terminal.disposition !== disposition ||
          terminal.closure_event_id !== closureEventID ||
          terminal.error !== error
        )
          throw new Error(`Event fire ${fire.id} conflicts with its immutable terminal receipt`)
        return true
      }
      const lease = currentControlLeaseInTransaction(db, "event_fire", fire.id)
      if (!lease || lease.owner_occurrence_id !== ownerID || lease.expires_at <= now) return false
      db.insert(EventJobFireReceiptTable)
        .values({
          id: Identifier.ascending("call"),
          fire_id: fire.id,
          definition_id: fire.definition_id,
          queue_position: fire.queue_position,
          outcome: "disposition",
          disposition,
          closure_event_id: closureEventID,
          message_id: null,
          retry_at: null,
          error,
          time_created: now,
        })
        .run()
      releaseControlLeaseInTransaction(db, {
        target: "event_fire",
        targetID: fire.id,
        leaseID: lease.id,
        ownerOccurrenceID: ownerID,
        now,
      })
      return true
    })
    if (settled) recoverProjectFires()
  }

  function deferFire(fire: EventJobFire, ownerID: string, error: unknown): void {
    log.info("event fire deferred to its current owner", { fireID: fire.id, ownerID, error: errorMessage(error) })
  }

  function scheduleRetry(fire: EventJobFire, job: EventJob | undefined, ownerID: string, error: unknown): void {
    const now = Date.now()
    const message = errorMessage(error)
    const retryAt = now + Math.min(FIRE_RETRY_MAX_MS, FIRE_RETRY_BASE_MS * 2 ** Math.min(16, fire.attempt - 1))
    const settled = Database.immediateTransaction((db) => {
      const lease = currentControlLeaseInTransaction(db, "event_fire", fire.id)
      if (!lease || lease.owner_occurrence_id !== ownerID || lease.expires_at <= now) return false
      db.insert(EventJobFireReceiptTable)
        .values({
          id: Identifier.ascending("call"),
          fire_id: fire.id,
          definition_id: fire.definition_id,
          queue_position: fire.queue_position,
          outcome: "retry_wait",
          disposition: null,
          message_id: null,
          retry_at: retryAt,
          error: message,
          time_created: now,
        })
        .run()
      // The receipt owns the retry time. Holding the lease past it would make
      // the lease duration the retry period instead.
      releaseControlLeaseInTransaction(db, {
        target: "event_fire",
        targetID: fire.id,
        leaseID: lease.id,
        ownerOccurrenceID: ownerID,
        now,
      })
      return true
    })
    if (settled) scheduleLeaseRecovery(fire.id)
  }

  function ready(job: EventJob, now: number) {
    if (!job.last_run) return true
    return now - job.last_run >= job.cooldown_ms
  }

  function ok(event: EventEnvelope, match: Match) {
    for (const [key, value] of Object.entries(match)) {
      const got = pick({ type: event.type, properties: event.properties }, key)
      if (got !== value) return false
    }
    return true
  }

  function pick(input: unknown, key: string): unknown {
    const parts = key.split(".").filter(Boolean)
    let current: unknown = input
    for (const part of parts) {
      if (!current || typeof current !== "object") return undefined
      current = (current as Record<string, unknown>)[part]
    }
    return current
  }

  function objectRecord(value: unknown): Record<string, unknown> | undefined {
    return value && typeof value === "object" && !Array.isArray(value) ? (value as Record<string, unknown>) : undefined
  }

  function throwIfAborted(signal: AbortSignal): void {
    if (!signal.aborted) return
    throw signal.reason instanceof Error ? signal.reason : new Error("Event fire execution aborted")
  }

  function requireSessionWake(): EventSessionWakePort {
    const sessionWake = state().sessionWake
    if (!sessionWake) throw new Error("EventService has no configured Session wake owner")
    return sessionWake
  }

  function errorMessage(error: unknown): string {
    if (!(error instanceof Error)) return String(error)
    const prefix = `${error.name}: `
    return error.message.startsWith(prefix) ? error.message : `${prefix}${error.message}`
  }

  export const TestHooks = {
    installOccurrenceAcceptedHook(hook: NonNullable<typeof occurrenceAcceptedHookForTest>): Disposable {
      if (occurrenceAcceptedHookForTest) throw new Error("Event occurrence acceptance hook is already installed")
      occurrenceAcceptedHookForTest = hook
      return {
        [Symbol.dispose]() {
          occurrenceAcceptedHookForTest = undefined
        },
      }
    },
    installAfterExecutionPermit(hook: (cancel: (reason: unknown) => void) => void | Promise<void>): Disposable {
      if (afterExecutionPermitForTest) throw new Error("Event post-permit test hook is already installed")
      afterExecutionPermitForTest = hook
      return {
        [Symbol.dispose]() {
          if (afterExecutionPermitForTest === hook) afterExecutionPermitForTest = undefined
        },
      }
    },
    installExecutionCapacity(limit: number): Disposable {
      if (executionCapacityForTest !== undefined) throw new Error("Event execution capacity test override is installed")
      executionCapacityForTest = limit
      executionPermits.resize(limit)
      return {
        [Symbol.dispose]() {
          executionCapacityForTest = undefined
        },
      }
    },
    installBeforeProcessRollbackRecovery(hook: () => void | Promise<void>): Disposable {
      if (beforeProcessRollbackRecoveryForTest) {
        throw new Error("Event fire rollback recovery test hook is already installed")
      }
      beforeProcessRollbackRecoveryForTest = hook
      return {
        [Symbol.dispose]() {
          if (beforeProcessRollbackRecoveryForTest === hook) beforeProcessRollbackRecoveryForTest = undefined
        },
      }
    },
    acceptEnvelope(event: EventEnvelope): Promise<void> {
      return accept(event)
    },
    installWakeExecutor(executor: EventWakeExecutor): Disposable {
      if (wakeExecutorForTest) throw new Error("EventService test wake executor is already installed")
      wakeExecutorForTest = executor
      return {
        [Symbol.dispose]() {
          if (wakeExecutorForTest === executor) wakeExecutorForTest = undefined
        },
      }
    },
    installFireAcceptedHook(hook: EventFireAcceptedHook): Disposable {
      if (fireAcceptedHookForTest) throw new Error("EventService fire-accepted test hook is already installed")
      fireAcceptedHookForTest = hook
      return {
        [Symbol.dispose]() {
          if (fireAcceptedHookForTest === hook) fireAcceptedHookForTest = undefined
        },
      }
    },
    installBeforeSessionWake(hook: BeforeSessionWakeHook): Disposable {
      if (beforeSessionWakeForTest) throw new Error("EventService before-session-wake test hook is already installed")
      beforeSessionWakeForTest = hook
      return {
        [Symbol.dispose]() {
          if (beforeSessionWakeForTest === hook) beforeSessionWakeForTest = undefined
        },
      }
    },
    installAfterEventFireClaim(hook: AfterEventFireClaimHook): Disposable {
      if (afterEventFireClaimForTest) throw new Error("EventService after-fire-claim test hook is already installed")
      afterEventFireClaimForTest = hook
      return {
        [Symbol.dispose]() {
          if (afterEventFireClaimForTest === hook) afterEventFireClaimForTest = undefined
        },
      }
    },
    failNextCreateFires(count = 1): Disposable {
      const previous = createFireFailuresForTest
      createFireFailuresForTest = count
      return {
        [Symbol.dispose]() {
          createFireFailuresForTest = previous
        },
      }
    },
    createLeaseFence: createEventFireLeaseFence,
    claimFire,
    recoverProjectFires,
    scheduleLeaseRecovery,
    recoveryTimerActive(fireID: string): boolean {
      return state().recoveryTimers.has(fireID)
    },
    messageID: (fireID: string) => deterministicEventWakeID("msg", fireID),
    async waitForIdle(): Promise<void> {
      const s = state()
      while (s.recoveryOperations.size > 0 || s.discovery || s.running.size > 0) {
        await Promise.allSettled([
          ...s.recoveryOperations,
          ...s.running.values(),
          ...(s.discovery ? [s.discovery] : []),
        ])
      }
    },
    executionSnapshot() {
      return { ...executionPermits.snapshot, reservations: state().running.size, discovery: Boolean(state().discovery) }
    },
    fires(projectID: string): EventJobFire[] {
      return Database.use((db) =>
        db
          .select()
          .from(EventJobFireTable)
          .orderBy(EventJobFireTable.time_created, EventJobFireTable.id)
          .all()
          .map((row) => projectEventFireInTransaction(db, row, Date.now()))
          .filter((row) => row.project_id === projectID),
      )
    },
  }
}
