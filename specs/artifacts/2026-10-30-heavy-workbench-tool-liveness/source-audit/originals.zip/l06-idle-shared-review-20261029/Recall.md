# Recall

用户要求真正重型端到端benchmark，独立单层审查，便宜优先；不能把运行时问题扣成数学候选错误。主方最新要求先封存L05完整预案（已完成），再对L06 idle/unsafe-retry现象做共享机制横向只读审计。

当前范围：全部生产Task/Mission/Session入口汇聚、正常/终态/重试/重启、串并行/多项目、长Tool时idle所有权及取消传播。主方正在审activity/processor/bash；本独立审查不改源码，不再委托，不操作原候选/容器/用户服务，不取消/重启，不运行LLM、GPU、solver或UI。

公开错误原件由主方提供status-original.json；只摘状态/身份/时间，不读reasoning或凭据。当前source-only审读不等于重现实跑。先报告已证代码根因、影响面、拟实际execute委托的风险与必要正向验收。主方之后实现另需复核，不能只改180s数字掩盖错误。
