"""Append newly read primary source and search receipts; no tests or runtime I/O."""
import datetime as dt
import json
import pathlib
import shutil
import subprocess

ROOT = pathlib.Path(__file__).resolve().parent
REPO = pathlib.Path('D:/myhexin-local/opencorvus')
extra = [
 'packages/opencorvus/src/util/physical-operation-scope.ts',
 'packages/opencorvus/src/session/compaction.ts',
 'packages/opencorvus/src/provider/operations.ts',
 'packages/opencorvus/src/tool/metric-judge-runner.ts',
 'packages/opencorvus/src/task-api/index.ts',
 'packages/opencorvus/src/task-api/global-task-service.ts',
]
inventory = []
for rel in extra:
    origin = REPO / rel
    target = ROOT / 'source-additional' / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(origin, target)
    inventory.append({'origin': str(origin), 'snapshot': str(target), 'direct_byte_equal_at_capture': origin.read_bytes() == target.read_bytes()})
(ROOT / 'source-additional-inventory.json').write_text(json.dumps({'captured_utc': dt.datetime.now(dt.timezone.utc).isoformat(), 'files': inventory}, indent=2), encoding='utf-8')
fragments = []
for rel, spans in [
 ('packages/opencorvus/node_modules/@modelcontextprotocol/sdk/dist/esm/types.js', [(20,39),(620,645)]),
 ('packages/opencorvus/node_modules/@modelcontextprotocol/sdk/dist/esm/experimental/tasks/client.js', [(55,102),(155,166)]),
 ('packages/opencorvus/node_modules/@ai-sdk/provider-utils/dist/index.js', [(4653,4677)]),
]:
    lines = (REPO / rel).read_text(encoding='utf-8').splitlines()
    fragments.append(rel)
    for start, end in spans:
        fragments.extend(f'{idx+1}: {lines[idx]}' for idx in range(start-1, min(end,len(lines))))
(ROOT / 'additional-primary-SDK-excerpts.txt').write_text('\n'.join(fragments), encoding='utf-8')
records = []
for argv, filename in [
 (['rg','-n','streamText\\(|withLLMActivity\\(|collectLLMText\\(|SessionProcessor\\.create\\(','packages/opencorvus/src','--glob','*.ts'], 'production-stream-entry-sites.txt'),
 (['git','status','--short'], 'git-status-end.txt'),
]:
    result = subprocess.run(argv,cwd=REPO,capture_output=True,text=True,encoding='utf-8')
    (ROOT / filename).write_text(result.stdout + result.stderr, encoding='utf-8')
    records.append({'argv': argv, 'returncode': result.returncode, 'output': filename})
(ROOT / 'additional-read-command-receipts.json').write_text(json.dumps(records, indent=2), encoding='utf-8')
print(json.dumps({'additional_sources': len(inventory), 'runtime_or_test_executed': False}))
