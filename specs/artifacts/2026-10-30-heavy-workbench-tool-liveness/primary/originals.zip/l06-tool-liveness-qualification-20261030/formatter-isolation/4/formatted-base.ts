/**
 * Single-source chunk-driven activity monitor.
 *
 * Purpose: detect "no byte moved in N ms" on any streaming surface
 * (LLM stream.stream, executor event queue, SSE bridge) without
 * each layer inventing its own setTimeout/reset dance.
 *
 * Semantics (physical-liveness probe, NOT a state machine):
 *   - Caller pulls `signal` and composes it into whatever `AbortSignal`
 *     its producer already honours.
 *   - Caller invokes `observe()` on every real chunk / event. Each call
 *     resets the inactivity timer.
 *   - If `idleMs` elapses with no `observe()` call AND the external
 *     `signal` has not fired, the monitor aborts its own controller with
 *     an `AbortError` carrying a deterministic reason. The chain then
 *     unwinds naturally through the existing `throwIfAborted()` / abort
 *     listeners — no custom status codes, no separate error taxonomy.
 *   - Disposal is idempotent; after `dispose()` the monitor stops all
 *     timers and stops observing.
 *
 * Rules: CLAUDE.md #1 (no fallback — we *abort*, the caller decides),
 * #22 (single source for activity monitoring), #24 (pattern is extracted,
 * not copy-pasted into each consumer), #26 (no over-engineering —
 * observe() / dispose() / signal / lastActivityAt and that's it).
 */

export interface StreamActivityMonitor {
  /** Abort signal combined from external signal + internal idle controller. */
  readonly signal: AbortSignal
  /** Call on every chunk / event. Resets the inactivity timer. */
  observe(): void
  /**
   * Suspend the inactivity timer until `resume()` is called. Use when the
   * stream is legitimately paused waiting on a long synchronous tool call —
   * the LLM provider holds the connection open but emits no chunks during
   * tool execution, so the chunk-driven probe would false-positive trip.
   * Per rule 23 we don't infer "tool running" from internal state; the
   * caller explicitly pauses around the tool-call → tool-result boundary.
   *
   * Calls nest: each `pause()` requires a matching `resume()`. Excess
   * `resume()` calls are a no-op so callers don't need pair-tracking.
   */
  pause(): void
  /** Counterpart to pause(); reschedules the idle timer. */
  resume(): void
  /** True while one or more explicit stream-pause owners remain active. */
  paused(): boolean
  /** Millisecond timestamp of the most recent observe() (or construction). */
  lastActivityAt(): number
  /** True once the monitor's own controller has aborted due to inactivity. */
  timedOut(): boolean
  /** Read-only physical liveness facts for failure evidence and operator diagnostics. */
  diagnostics(): {
    lastActivityAt: number
    paused: boolean
    pauseDepth: number
    pauseOwners: string[]
    timedOut: boolean
    abortReason?: string
  }
  /** Abort the monitor from its owning session cancellation path. */
  abort(reason?: unknown): void
  /** Idempotent. Clears all timers and detaches listeners. */
  dispose(): void
}

export interface StreamActivityOptions {
  /** Maximum idle window before the monitor aborts itself. Must be > 0. */
  idleMs: number
  /** Caller-owned signal that the monitor propagates alongside its own. */
  signal?: AbortSignal
  /**
   * Human-readable tag appended to the AbortError reason (e.g.
   * "session-llm", "executor-events"). Helps triage in logs; does NOT
   * change control flow.
   */
  label?: string
  /**
   * Upper bound on one continuous pause region. A pause hands liveness to
   * another owner; it never means "stop watching forever". If that owner never
   * resumes — because it hung before recording its own durable fact — the
   * monitor trips on this bound instead of waiting out the total deadline with
   * no diagnostic. Must be > 0 when provided; omit to allow unbounded pauses.
   */
  maxPauseMs?: number
  /**
   * Names the live pause owners for the maxPauseMs trip message. The monitor
   * itself tracks only depth; the caller owns the owner identities, and the
   * trip error is the stall's only surviving diagnostic.
   */
  describePause?: () => string
}

export type ReadableStreamActivitySettlement = "eof" | "error" | "cancelled" | "aborted"

const STREAM_ERROR_CODES = [
  "ECONNRESET",
  "ECONNREFUSED",
  "ETIMEDOUT",
  "EPIPE",
  "ENOTFOUND",
  "EAI_AGAIN",
  "EHOSTUNREACH",
  "ENETUNREACH",
  "EPROTO",
  "UND_ERR_SOCKET",
  "UND_ERR_HEADERS_TIMEOUT",
  "UND_ERR_BODY_TIMEOUT",
] as const

export type ReadableStreamErrorFacts = Readonly<{
  origin: "read" | "on_chunk" | "enqueue"
  type:
    | "Error"
    | "TypeError"
    | "RangeError"
    | "SyntaxError"
    | "ReferenceError"
    | "URIError"
    | "EvalError"
    | "DOMException"
    | "unknown"
  code?: (typeof STREAM_ERROR_CODES)[number]
}>

function streamErrorFacts(origin: ReadableStreamErrorFacts["origin"], error: unknown): ReadableStreamErrorFacts {
  try {
    const type =
      error instanceof TypeError
        ? "TypeError"
        : error instanceof RangeError
          ? "RangeError"
          : error instanceof SyntaxError
            ? "SyntaxError"
            : error instanceof ReferenceError
              ? "ReferenceError"
              : error instanceof URIError
                ? "URIError"
                : error instanceof EvalError
                  ? "EvalError"
                  : error instanceof DOMException
                    ? "DOMException"
                    : error instanceof Error
                      ? "Error"
                      : "unknown"
    const descriptor =
      error !== null && (typeof error === "object" || typeof error === "function")
        ? Object.getOwnPropertyDescriptor(error, "code")
        : undefined
    const code = STREAM_ERROR_CODES.find(
      (candidate) => descriptor && "value" in descriptor && descriptor.value === candidate,
    )
    return { origin, type, ...(code ? { code } : {}) }
  } catch {
    return { origin, type: "unknown" }
  }
}

export interface ActivityTrackedReadableStreamOptions<T> {
  source: ReadableStream<T>
  activity: StreamActivityMonitor
  onChunk?: (chunk: T) => void
  onSettlement?: (settlement: ReadableStreamActivitySettlement, error?: ReadableStreamErrorFacts) => void
}

export interface SettlementTrackedReadableStreamOptions<T> {
  source: ReadableStream<T>
  signal?: AbortSignal
  onChunk?: (chunk: T) => void
  onSettlement: (settlement: ReadableStreamActivitySettlement, error?: ReadableStreamErrorFacts) => void
}

/** Own one upstream reader and converge EOF, error, consumer cancellation and
 * owner abort on one exact physical settlement callback. */
export function settlementTrackedReadableStream<T>(
  options: SettlementTrackedReadableStreamOptions<T>,
): ReadableStream<T> {
  const reader = options.source.getReader()
  let controller: ReadableStreamDefaultController<T> | undefined
  let settlementStarted = false
  let settlementFinished = false
  let cancelPromise: Promise<void> | undefined

  const cancelUnderlying = (reason: unknown) => {
    cancelPromise ??= reader.cancel(reason)
    return cancelPromise
  }
  const beginSettlement = () => {
    if (settlementStarted) return false
    settlementStarted = true
    options.signal?.removeEventListener("abort", onAbort)
    return true
  }
  const finishSettlement = (settlement: ReadableStreamActivitySettlement, error?: ReadableStreamErrorFacts) => {
    if (settlementFinished) return
    settlementFinished = true
    options.onSettlement(settlement, error)
  }
  const onAbort = () => {
    if (!beginSettlement()) return
    const reason = options.signal?.reason ?? new DOMException("stream owner aborted", "AbortError")
    try {
      controller?.error(reason)
    } catch {
      // The consumer may already have closed its side of the stream.
    }
    void cancelUnderlying(reason).then(
      () => finishSettlement("aborted"),
      () => finishSettlement("aborted"),
    )
  }

  return new ReadableStream<T>({
    start(streamController) {
      controller = streamController
      if (options.signal?.aborted) onAbort()
      else options.signal?.addEventListener("abort", onAbort, { once: true })
    },
    async pull(streamController) {
      let origin: ReadableStreamErrorFacts["origin"] = "read"
      try {
        const result = await reader.read()
        if (settlementStarted) return
        if (result.done) {
          if (!beginSettlement()) return
          finishSettlement("eof")
          streamController.close()
          return
        }
        origin = "on_chunk"
        options.onChunk?.(result.value)
        origin = "enqueue"
        streamController.enqueue(result.value)
      } catch (error) {
        if (!beginSettlement()) return
        finishSettlement("error", streamErrorFacts(origin, error))
        streamController.error(error)
      }
    },
    async cancel(reason) {
      if (!beginSettlement()) return
      try {
        await cancelUnderlying(reason)
      } finally {
        finishSettlement("cancelled")
      }
    },
  })
}

/**
 * Project one physical ReadableStream through the shared activity monitor.
 *
 * The returned stream owns both the upstream reader and the monitor. Every
 * terminal edge converges on one settlement: ordinary EOF, read error,
 * consumer cancellation, or activity/external abort. Abort requests upstream
 * cancellation without awaiting an untrusted parked reader; an ordinary
 * consumer cancel still awaits the upstream cleanup contract.
 */
export function activityTrackedReadableStream<T>(options: ActivityTrackedReadableStreamOptions<T>): ReadableStream<T> {
  return settlementTrackedReadableStream({
    source: options.source,
    signal: options.activity.signal,
    onChunk: (chunk) => {
      options.activity.observe()
      options.onChunk?.(chunk)
    },
    onSettlement: (settlement, error) => {
      options.activity.dispose()
      options.onSettlement?.(settlement, error)
    },
  })
}

/**
 * Race every `next()` of an async iterable against an `AbortSignal` so the
 * iterator throws as soon as the signal aborts — even when the underlying
 * source has parked on a network read that doesn't honour signal abort
 * (Bun fetch + AI SDK readers exhibit this: AbortController.abort() closes
 * the connection but does not reject an already-pending reader.read()
 * promise, so the consumer's `for await` hangs forever).
 *
 * Pairs with `withStreamActivity` — the monitor's combined signal flips, this
 * wrapper guarantees the consumer's loop actually exits with the
 * AbortError. Requests upstream cleanup via `iter.return?.()` so
 * provider-side resources (response body, fetch socket) can be released,
 * but does not await that untrusted cleanup promise: some provider iterators
 * park `return()` on the same network read as `next()`, and awaiting it would
 * turn a completed cancellation back into an indefinitely pending one.
 */
const STREAM_EVENT_LOOP_YIELD_INTERVAL = 256

function yieldToEventLoop(): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, 0))
}

export async function* abortableIterable<T>(source: AsyncIterable<T>, signal: AbortSignal): AsyncGenerator<T> {
  const iter = source[Symbol.asyncIterator]()
  let chunksSinceEventLoopYield = 0
  try {
    while (true) {
      if (signal.aborted) throw signal.reason
      let onAbort: (() => void) | null = null
      let result: IteratorResult<T>
      const abortPromise = new Promise<never>((_, reject) => {
        onAbort = () => reject(signal.reason)
        signal.addEventListener("abort", onAbort, { once: true })
      })
      try {
        result = await Promise.race([iter.next(), abortPromise])
      } finally {
        if (onAbort) signal.removeEventListener("abort", onAbort)
      }
      if (result.done) return
      yield result.value

      chunksSinceEventLoopYield += 1
      if (chunksSinceEventLoopYield >= STREAM_EVENT_LOOP_YIELD_INTERVAL) {
        chunksSinceEventLoopYield = 0
        // Some provider/SDK iterators can resolve next() immediately forever
        // while emitting only non-semantic chunks. Promise/microtask fairness
        // alone cannot let timer-backed idle and cancellation authorities run.
        await yieldToEventLoop()
      }
    }
  } finally {
    try {
      const cleanup = iter.return?.()
      if (cleanup) {
        if (signal.aborted) void Promise.resolve(cleanup).catch(() => undefined)
        else await cleanup
      }
    } catch {
      /* upstream already torn down */
    }
  }
}

export function withStreamActivity(options: StreamActivityOptions): StreamActivityMonitor {
  if (!Number.isFinite(options.idleMs) || options.idleMs <= 0) {
    throw new Error(`withStreamActivity: idleMs must be a positive finite number (got ${options.idleMs})`)
  }
  if (options.maxPauseMs !== undefined && (!Number.isFinite(options.maxPauseMs) || options.maxPauseMs <= 0)) {
    throw new Error(`withStreamActivity: maxPauseMs must be a positive finite number (got ${options.maxPauseMs})`)
  }
  const label = options.label ?? "stream"
  const inactivity = new AbortController()
  const manual = new AbortController()
  const combined = options.signal
    ? AbortSignal.any([options.signal, inactivity.signal, manual.signal])
    : AbortSignal.any([inactivity.signal, manual.signal])

  let last = Date.now()
  let disposed = false
  let timer: ReturnType<typeof setTimeout> | null = null
  let pauseTimer: ReturnType<typeof setTimeout> | null = null
  /** Pause depth — `pause()` increments, `resume()` decrements. The timer is
   *  scheduled only when depth === 0. Allows nested pause regions (e.g. one
   *  tool dispatched inside another). */
  let pauseDepth = 0

  const trip = () => {
    if (disposed) return
    if (inactivity.signal.aborted) return
    inactivity.abort(new DOMException(`stream idle > ${options.idleMs}ms (${label})`, "AbortError"))
  }

  const tripPause = () => {
    if (disposed) return
    if (inactivity.signal.aborted) return
    // Name the live pause owners in the trip itself: this error is the only
    // survivor of the stall, and an anonymous trip forces the next diagnosis
    // back to guessing which caller paused (luna9 cost a full isolated run to
    // learn there was no way to know).
    const owners = options.describePause?.()
    inactivity.abort(
      new DOMException(
        `stream paused > ${options.maxPauseMs}ms without resume (${label}${owners ? `; owners: ${owners}` : ""})`,
        "AbortError",
      ),
    )
  }

  const clear = () => {
    if (timer !== null) {
      clearTimeout(timer)
      timer = null
    }
  }

  const clearPause = () => {
    if (pauseTimer !== null) {
      clearTimeout(pauseTimer)
      pauseTimer = null
    }
  }

  const schedule = () => {
    if (disposed) return
    clear()
    if (pauseDepth > 0) return
    timer = setTimeout(trip, options.idleMs)
    // Timer is intentionally ref'd: unref would let Bun idle out while an
    // async iterator is parked on `await new Promise`, defeating the monitor.
  }

  const schedulePause = () => {
    if (disposed) return
    clearPause()
    if (pauseDepth <= 0 || options.maxPauseMs === undefined) return
    pauseTimer = setTimeout(tripPause, options.maxPauseMs)
  }

  schedule()

  return {
    signal: combined,
    observe() {
      if (disposed) return
      last = Date.now()
      if (pauseDepth > 0) {
        schedulePause()
        return
      }
      schedule()
    },
    pause() {
      if (disposed) return
      pauseDepth++
      clear()
      // Bound the outermost pause region only: nested owners share one handoff
      // window, and restarting it per owner would let a chain of nested pauses
      // extend the disarm indefinitely.
      if (pauseDepth === 1 && options.maxPauseMs !== undefined && pauseTimer === null) {
        schedulePause()
      }
    },
    resume() {
      if (disposed) return
      if (pauseDepth === 0) return
      pauseDepth--
      if (pauseDepth === 0) {
        clearPause()
        last = Date.now()
        schedule()
      }
    },
    paused() {
      return !disposed && pauseDepth > 0
    },
    lastActivityAt() {
      return last
    },
    timedOut() {
      return inactivity.signal.aborted
    },
    diagnostics() {
      const owners = options.describePause?.()
      return {
        lastActivityAt: last,
        paused: !disposed && pauseDepth > 0,
        pauseDepth,
        pauseOwners: owners
          ? owners
              .split(",")
              .map((owner) => owner.trim())
              .filter(Boolean)
          : [],
        timedOut: inactivity.signal.aborted,
        ...(combined.aborted ? { abortReason: String(combined.reason) } : {}),
      }
    },
    abort(reason?: unknown) {
      if (disposed) return
      if (manual.signal.aborted) return
      manual.abort(reason ?? new DOMException(`stream aborted (${label})`, "AbortError"))
    },
    dispose() {
      if (disposed) return
      disposed = true
      clear()
      clearPause()
    },
  }
}
