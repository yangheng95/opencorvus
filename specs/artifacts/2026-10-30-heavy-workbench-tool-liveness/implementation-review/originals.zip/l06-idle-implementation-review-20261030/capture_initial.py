import datetime as dt
import json
import pathlib
import shutil
import subprocess

root = pathlib.Path(__file__).resolve().parent
repo = pathlib.Path('D:/myhexin-local/opencorvus')
items = [
 'packages/opencorvus/src/tool/execution-deadline.ts', 'packages/opencorvus/src/tool/bash.ts',
 'packages/opencorvus/src/llm/activity.ts', 'packages/opencorvus/src/util/stream-activity.ts',
 'packages/opencorvus/src/session/processor.ts', 'packages/opencorvus/src/session/loop.ts',
 'packages/opencorvus/src/mcp/index.ts', 'packages/opencorvus/src/shell/process-supervisor.ts',
 'specs/records/2026-10/2026-10-30-heavy-workbench-tool-liveness.md',
]
dest = root / 'source-initial'
dest.mkdir(exist_ok=False)
inventory = []
for rel in items:
    target = dest / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(repo / rel, target)
    inventory.append({'source': str(repo / rel), 'snapshot': str(target), 'byte_equal_at_capture': (repo/rel).read_bytes() == target.read_bytes()})
(root / 'source-inventory-initial.json').write_text(json.dumps({'captured_utc': dt.datetime.now(dt.timezone.utc).isoformat(), 'files': inventory}, indent=2), encoding='utf-8')
status = subprocess.run(['git','status','--short'], cwd=repo, capture_output=True,text=True,encoding='utf-8')
(root / 'git-status-initial.txt').write_text(status.stdout+status.stderr, encoding='utf-8')
print(json.dumps({'captured': len(inventory), 'experiments_started': 0}))
