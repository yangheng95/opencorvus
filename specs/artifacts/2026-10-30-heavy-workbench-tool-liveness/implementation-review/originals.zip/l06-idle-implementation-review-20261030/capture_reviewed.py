import datetime as dt
import json
import pathlib
import shutil

root = pathlib.Path(__file__).resolve().parent
repo = pathlib.Path('D:/myhexin-local/opencorvus')
old = json.loads((root/'source-inventory-initial.json').read_text(encoding='utf-8'))
dest = root/'source-reviewed'
dest.mkdir(exist_ok=False)
records = []
for item in old['files']:
    origin = pathlib.Path(item['source'])
    rel = origin.relative_to(repo)
    target = dest/rel
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(origin,target)
    records.append({'source':str(origin),'snapshot':str(target),'same_bytes_at_capture':origin.read_bytes()==target.read_bytes(),'same_as_initial':pathlib.Path(item['snapshot']).read_bytes()==target.read_bytes()})
(root/'source-inventory-reviewed.json').write_text(json.dumps({'captured_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'files':records},indent=2),encoding='utf-8')
base = (root/'probe-sdk-iterable-repaired.ts').read_text(encoding='utf-8')
base = base.replace('/source-initial/', '/source-reviewed/')
base = base.replace('/extracted-repaired-exact-sdk-wrapper.ts','/extracted-reviewed-exact-sdk-wrapper.ts').replace('/extracted-repaired-sdk-wrapper.js','/extracted-reviewed-sdk-wrapper.js')
base = base.replace('async function run(wrapped: boolean)', 'async function run(wrapped: boolean, kind: "iterable" | "plain" | "promise")')
old_execute = '''  const execute = async function* () {
    yielded++
    yield { value: "first" }
    yielded++
    yield { value: "final" }
  }'''
new_execute = '''  const execute = () => {
    if (kind === "plain") return { value: "plain", [Symbol.asyncIterator]: undefined }
    if (kind === "promise") return Promise.resolve({ value: "promised" })
    return (async function* () {
      yielded++
      yield { value: "first" }
      yielded++
      yield { value: "final" }
    })()
  }'''
assert old_execute in base
base = base.replace(old_execute,new_execute).replace('return { wrapped, yielded, activity, tool_events: toolEvents }','return { wrapped, kind, yielded, activity, tool_events: toolEvents }')
start = base.index('const baseline = await run(false)')
base = base[:start] + '''const observations = []
for (const kind of ["iterable", "plain", "promise"] as const) {
  const baseline = await run(false, kind)
  const currentWrapper = await run(true, kind)
  const passed = baseline.yielded === currentWrapper.yielded && JSON.stringify(baseline.tool_events) === JSON.stringify(currentWrapper.tool_events)
  observations.push({kind,baseline,currentWrapper,passed})
}
const result = {scope:"three exact captured wrapper return contracts with actual installed SDK, deterministic local participant only", observations,
  actual_full_SessionProcessor_run:false,Provider_or_HTTP_or_candidate_run:false}
await fs.writeFile(root + "/sdk-return-shapes-observation.json",JSON.stringify(result,null,2))
console.log(JSON.stringify({passed:observations.filter(x=>x.passed).length,total:observations.length}))
if (!observations.every(x=>x.passed)) throw new Error("SDK return contract changed")
'''
(root/'probe-sdk-return-shapes.ts').write_text(base,encoding='utf-8')
print(json.dumps({'captured_sources':len(records),'source_identity_is_not_correctness_check':True}))
