(...args: Parameters<typeof execute>) => {
                            run.signal.throwIfAborted()
                            // The SDK can execute a Tool before the consumer admits its Tool-call event.
                            markToolExecutionStarted(run.attempt)
                            const toolCallID = args[1].toolCallId
                            const execution = { run, settled: false }
                            sdkExecutions.set(toolCallID, execution)
                            // Execution proves that upstream arrived before its queued
                            // event reaches the consumer. This is transport proof, not
                            // an invented second semantic Tool-call chunk.
                            run.bump("first-byte")
                            run.pause(toolPauseOwner(toolCallID))
                            const settle = () => {
                              if (sdkExecutions.get(toolCallID) === execution) execution.settled = true
                              run.resume(toolPauseOwner(toolCallID))
                            }
                            try {
                              const output = execute(...args)
                              if (
                                output &&
                                typeof (output as AsyncIterable<unknown>)[Symbol.asyncIterator] === "function"
                              ) {
                                // SDK streaming Tool outputs must remain AsyncIterable,
                                // rather than becoming a Promise of an iterator object.
                                const iterable = output as AsyncIterable<unknown>
                                return (async function* () {
                                  try {
                                    yield* iterable
                                  } finally {
                                    settle()
                                  }
                                })()
                              }
                              if (output && typeof (output as PromiseLike<unknown>).then === "function") {
                                return Promise.resolve(output).finally(settle)
                              }
                              settle()
                              return output
                            } catch (error) {
                              settle()
                              throw error
                            }
                          }