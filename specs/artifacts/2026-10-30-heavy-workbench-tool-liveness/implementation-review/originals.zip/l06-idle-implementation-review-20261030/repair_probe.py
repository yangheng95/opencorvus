"""Preserve the failed reviewer harness and create a corrected new probe."""
import datetime as dt
import json
import pathlib
import subprocess
import time

root = pathlib.Path(__file__).resolve().parent
source = (root/'probe-sdk-iterable.ts').read_text(encoding='utf-8')
old = 'transformSync("(" + exact + ")")'
assert source.count(old) == 1
source = source.replace(old, 'transformSync("globalThis.__L06ReviewerExecute = (" + exact + ")")')
old = '"toolPauseOwner", "return " + javascript)'
assert source.count(old) == 1
source = source.replace(old, '"toolPauseOwner", javascript + "; return globalThis.__L06ReviewerExecute;")')
source = source.replace('  const result = streamText({', '  if (typeof callback !== "function") throw new Error("Reviewer wrapper extraction did not produce a callback")\n  const result = streamText({')
source = source.replace('/extracted-exact-sdk-wrapper.ts', '/extracted-repaired-exact-sdk-wrapper.ts').replace('/extracted-sdk-wrapper.js', '/extracted-repaired-sdk-wrapper.js').replace('/sdk-iterable-observation.json', '/sdk-iterable-repaired-observation.json')
target = root/'probe-sdk-iterable-repaired.ts'
target.write_text(source,encoding='utf-8')
(root/'INVALID-PROBE-INITIAL.md').write_text('The first SDK probe is invalid reviewer harness evidence. Bun.Transpiler removed an unused top-level arrow expression, so the callback was undefined and the wrapped test did not invoke production code. sdk-iterable-observation.json regression_observed=true must not be used as a product finding. The captured source had already incorporated the AsyncIterable repair. Original script, empty extracted JS, command/stdout and mistaken local result are preserved. Repaired probe uses an observable global assignment and asserts the extracted callback is a function before using the actual SDK.\n',encoding='utf-8')
argv = ['C:/Users/hengu/.bun/bin/bun.exe',str(target)]
started = dt.datetime.now(dt.timezone.utc).isoformat()
tick = time.perf_counter()
with (root/'sdk-probe-repaired.stdout.txt').open('w',encoding='utf-8') as out, (root/'sdk-probe-repaired.stderr.txt').open('w',encoding='utf-8') as err:
    process = subprocess.Popen(argv,cwd=root,stdout=out,stderr=err)
    code = process.wait(timeout=30)
(root/'sdk-probe-repaired-command.json').write_text(json.dumps({'argv':argv,'pid':process.pid,'returncode':code,'started_utc':started,'ended_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'elapsed_seconds':time.perf_counter()-tick},indent=2),encoding='utf-8')
print(json.dumps({'returncode':code,'stdout':(root/'sdk-probe-repaired.stdout.txt').read_text(encoding='utf-8'),'stderr':(root/'sdk-probe-repaired.stderr.txt').read_text(encoding='utf-8')}))
