import datetime as dt
import json
import pathlib
import subprocess
import time

root = pathlib.Path(__file__).resolve().parent
argv = ['C:/Users/hengu/.bun/bin/bun.exe',str(root/'probe-sdk-return-shapes.ts')]
started = dt.datetime.now(dt.timezone.utc).isoformat()
tick = time.perf_counter()
with (root/'sdk-shapes.stdout.txt').open('w',encoding='utf-8') as out, (root/'sdk-shapes.stderr.txt').open('w',encoding='utf-8') as err:
    process = subprocess.Popen(argv,cwd=root,stdout=out,stderr=err)
    code = process.wait(timeout=30)
(root/'sdk-shapes-command.json').write_text(json.dumps({'argv':argv,'pid':process.pid,'returncode':code,'started_utc':started,'ended_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'elapsed_seconds':time.perf_counter()-tick},indent=2),encoding='utf-8')
print(json.dumps({'returncode':code,'stdout':(root/'sdk-shapes.stdout.txt').read_text(encoding='utf-8'),'stderr':(root/'sdk-shapes.stderr.txt').read_text(encoding='utf-8')}))
