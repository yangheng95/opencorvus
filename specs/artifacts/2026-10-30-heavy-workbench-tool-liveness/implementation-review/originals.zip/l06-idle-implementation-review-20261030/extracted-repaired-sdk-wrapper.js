globalThis.__L06ReviewerExecute = (...args) => {
  run.signal.throwIfAborted();
  markToolExecutionStarted(run.attempt);
  const toolCallID = args[1].toolCallId;
  const execution = { run, settled: false };
  sdkExecutions.set(toolCallID, execution);
  run.bump("first-byte");
  run.pause(toolPauseOwner(toolCallID));
  const settle = () => {
    if (sdkExecutions.get(toolCallID) === execution)
      execution.settled = true;
    run.resume(toolPauseOwner(toolCallID));
  };
  try {
    const output = execute(...args);
    if (output && typeof output === "object" && Symbol.asyncIterator in output) {
      const iterable = output;
      return async function* () {
        try {
          yield* iterable;
        } finally {
          settle();
        }
      }();
    }
    if (output && typeof output.then === "function") {
      return Promise.resolve(output).finally(settle);
    }
    settle();
    return output;
  } catch (error) {
    settle();
    throw error;
  }
};
