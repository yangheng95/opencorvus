import fs from "node:fs/promises"
import { withStreamActivity } from "./source-initial/packages/opencorvus/src/util/stream-activity"

const root = "D:/opencorvus-benchmark-runs/l06-idle-implementation-review-20261030"
const results: unknown[] = []
const abort = (signal: AbortSignal) => signal.aborted ? Promise.resolve(signal.reason)
  : new Promise<any>(resolve => signal.addEventListener("abort", () => resolve(signal.reason), {once:true}))
const assert = (condition: unknown, name: string) => { if (!condition) throw new Error(name) }

{
  const monitor = withStreamActivity({idleMs:35,maxPauseMs:45,label:"ordinary-idle"})
  const start = Date.now()
  const hold = monitor.holdPauseUntil(start+500)
  try {
    const reason = await abort(monitor.signal)
    const elapsed = Date.now()-start
    assert(reason.message === "stream idle > 35ms (ordinary-idle)" && elapsed < 300, "hold_must_not_extend_provider_idle")
    results.push({contract:"hold_has_no_effect_without_pause",reason:reason.message,elapsed_ms:elapsed,diagnostics:monitor.diagnostics(),passed:true})
  } finally { hold[Symbol.dispose](); monitor.dispose() }
}
{
  const monitor = withStreamActivity({idleMs:35,maxPauseMs:45,label:"parallel-owner"})
  monitor.pause()
  const first = monitor.holdPauseUntil(Date.now()+500)
  monitor.pause()
  const second = monitor.holdPauseUntil(Date.now()+350)
  try {
    first[Symbol.dispose]()
    monitor.resume()
    await Bun.sleep(90)
    const middle = monitor.diagnostics()
    assert(middle.pauseDepth === 1 && middle.timedOut === false, "second_owner_must_retain_own_hold")
    second[Symbol.dispose]()
    monitor.resume()
    const reason = await abort(monitor.signal)
    assert(reason.message === "stream idle > 35ms (parallel-owner)", "last_release_restores_provider_idle")
    results.push({contract:"parallel_release_is_independent_and_last_resume_restores_idle",middle,reason:reason.message,passed:true})
  } finally { first[Symbol.dispose](); second[Symbol.dispose](); monitor.dispose() }
}
{
  const monitor = withStreamActivity({idleMs:500,maxPauseMs:16,label:"finite-expiry",describePause:()=>"tool-call:owned"})
  monitor.pause()
  const start = Date.now()
  const deadlineAt = start+70
  const hold = monitor.holdPauseUntil(deadlineAt)
  try {
    const reason = await abort(monitor.signal)
    assert(Date.now()>=deadlineAt && reason.message.includes("stream paused > 16ms") && reason.message.includes("tool-call:owned"), "finite_hold_expiry_is_real_pause")
    results.push({contract:"unreleased_hold_expires_with_pause_identity",deadlineAt,observedAt:Date.now(),reason:reason.message,passed:true})
  } finally { hold[Symbol.dispose](); monitor.dispose() }
}
{
  const controller = new AbortController()
  const monitor = withStreamActivity({idleMs:500,maxPauseMs:500,label:"external-cancel",signal:controller.signal})
  monitor.pause()
  const hold = monitor.holdPauseUntil(Date.now()+1000)
  try {
    const expected = new DOMException("Owned reviewer cancellation", "AbortError")
    controller.abort(expected)
    const actual = await abort(monitor.signal)
    assert(actual===expected,"hold_must_preserve_exact_external_cancel")
    results.push({contract:"hold_preserves_exact_external_abort",same_reason_identity:actual===expected,name:actual.name,message:actual.message,passed:true})
  } finally { hold[Symbol.dispose](); monitor.dispose() }
}
await fs.writeFile(root+"/finite-monitor-observation.json",JSON.stringify({scope:"four pure monitor contracts using captured actual source; no Tool/Provider/service execution",results},null,2))
console.log(JSON.stringify({passed:results.length,scope:"pure monitor contracts only"}))
