# Task control plane

This chapter is the current authority for Task execution input, lifecycle, physical activation, external-effect settlement, Session continuation, scheduler delivery, cancellation, closure, and restart recovery.

Worker continuation retains one visible incremental user text Part. In the central runner, explicitly selected `session_message` locators that identify this Task's settled dispatch reports add attributed quotations through the same authenticated source selector as `read_agent_message`. They retain source, Session, Message, author, completion time and text-Part identities; Provider-secret redaction and explicit excerpt offsets use the existing evidence reader. At most eight selected reports are quoted in caller order, with at most 8000 characters per report and 30000 aggregate text characters; further selected report sources are explicitly deferred. Full reports, earlier visible worker narration and causal Tool facts remain available through the public reader. Other valid locator kinds and non-terminal messages retain their reference contracts. The quotes, current guidance and attachment context share the actual persisted Part and its existing input authority; no hidden Message or copied Artifact body is created. Participant reports and coordinator candidates remain claims to reconcile against original authority, not a Host-derived acceptance decision or new requirement.

## Authority rule

The control plane persists only facts that cannot be reconstructed after process loss:

- immutable accepted inputs and their causal identities;
- immutable business decisions and explicit Interaction requests/outcomes;
- immutable write-ahead external-effect requests and exact outcomes;
- immutable Task and Mission lifecycle events;
- immutable policy/deadline choices;
- append-only, expiring physical activation leases.

Every public `status`, `running`, `waiting`, `attempt`, `answered`, `completed`, `retry_at`, `last_error`, queue position, owner, recovery progress, Task timestamp, Mission closure state, Automation/Event execution state, Protocol delivery state, Tool state, and Provider state is a reducer projection. No projection is written back into its input row.

The canonical equation is:

```text
Projection = Reduce(immutable facts, immutable policy, valid leases, current time)
Queue       = Hint(unresolved projection)
```

A hint may be lost or duplicated. Reconciliation always rereads facts before execution or commit.

Public Task input and Interaction receipts acknowledge their persisted facts.
Operator steering uses its request-and-ingress transaction's existing post-commit
scan; exact and concurrent replays return the original receipt after signalling
that same project-owned scanner. Activity-reconciliation answers likewise return
the persisted answered view. These acceptance paths never await the Orchestrator
Turn, repeat ingress persistence, or infer acceptance from an activation count.
The detached scanner owns its fresh Instance lease, completion, and recovery.
Task background dispatch and scan handoffs also leave the caller's database
transaction and post-commit effect context before acquiring that lease. Task and
Mission control-driver heartbeat, hint, retry and rearm callbacks do the same at
their independent reentry adapters. A callback whose original post-commit effect
returned therefore executes under its own live owner; database closed-owner
checks and physical completion tracking remain authoritative.

Event fire discovery and its lease, retry and rollback recovery callbacks leave
the initiating database transaction and effect context before entering their
independently owned Instance work. Native HEAD and Parcel file callbacks use the
same database boundary before their original lifecycle reentry. Session wake
execution already enters through the initialized independent Project owner;
its standby and terminal continuations retain that execution's owner. These
boundaries preserve the original Project, occurrence, cancellation, leases and
completion joins; they do not weaken database closed-owner checks.

A global Task create carrying `requestID` first freezes the complete canonical caller request in
`global_creation_allocation` before anonymous Project filesystem work. That occurrence owns one directory, one initial
configuration snapshot, one append-once Task-resolution snapshot (profile, package revision, checks and process policy),
and one append-once accepted `(project_id, task_id, accepted_at)` receipt. The Task/root Session/creation contract/initial
ingress transaction appends the accepted receipt itself. Replay compares only caller request semantics, reads the stored
resolved snapshot instead of mutable defaults, and re-enters the accepted Task only to request level-driven reconciliation.
If explicit retention has removed the accepted Project or Task, replay returns the typed unavailable terminal for that same
occurrence; it never allocates a second aggregate. `global_chat_start` uses the same allocation/accepted-receipt rule for its
carrying Project and Session. Its current request identity is v2 only: the allocation derives its fingerprint from the shared
canonical JSON contract and the accepted Session stores that exact fingerprint. Runtime has no alternate-contract or v1
identity reader. Database startup applies declared migrations from the current version-1 baseline before business access;
future creation-contract/allocation changes must preserve their exact authority through the shared [data contract](02-data.md).

Inside a Project, `engine_task_creation_contract` separates the immutable canonical request from the first-accept resolved
snapshot. Request ID, channel binding and persisted Panel Tool Part are claims on that one Task. One immediate-transaction
intersection reducer reads every supplied claim: zero winners may create, one winner may atomically acquire missing aliases,
and different winners return a typed identity conflict. Database uniqueness chooses a cross-process winner; no process lock
owns business identity or spans reconciliation/Provider work. A narrow process lock may serialize only physical publication
of the already-allocated directory.

Durable operator-message, scheduler-delivery and Mission acceptance-resume receipts acknowledge the committed ingress, not completion of its model Turn. `dispatchPersistedTaskLoop` validates current-project ownership and the exact accepted ingress, then requests the existing detached project-owned scan. The reconciler, FIFO leases, replay and restart sweep remain the sole execution authority; request lifetime cannot own or block the enabled Turn.

A Mission acceptance-resume ingress references its real Mission-authored root Message. During normal activation and recovery, the Message's typed provenance resolves the exact same-transaction resume receipt by Task and ingress identity; that receipt and its named immutable ledger reconstruct `missionAcceptanceResume`. The loader validates Message/Task/Session ownership, ledger epoch, gap and reviewed terminal identity before acquisition. It does not downgrade a structured resume into a generic Mission follow-up or copy the event into a parallel inline payload. Source-integrity failures are reduced through the existing ingress evidence-fault contract. Ordinary participant messages and scheduler-delivery references retain their own event forms.

## Outcome and delegated input

An accepted Task-root participant Message may move, with its original Part
identities, into the same Task's Orchestrator Session. The atomic writer commits
one complete `message.moved` snapshot. Delayed original durable increments are
consumed as covered only after the bridge proves their exact outbox occurrence,
Project/Task ownership, original canonical keys and the complete matching Move
against current immutable Message/Part facts. This check precedes the shared
message-info cache. Historical Message updates retain the same participant
identity. Text/reasoning Parts can have pre-acceptance revisions; other surviving
Parts must match exactly. An absent Part update additionally requires its exact
durable removal fact, including type and source ownership. Both transfer and
removal seeks use versioned partial indexes. The existing Move subscriber alone
emits that full projection. Unproven ownership changes remain integrity errors.

The original operator outcome and relevant authoritative facts define semantic success. A Mission-authored `panel_create_task.request` is an execution assignment: the coordinator may paraphrase, organize, clarify wording and include necessary implementation guidance while preserving the intended outcome and applicable constraints. It is not required to be a byte-for-byte fragment of a user Message. The original user messages remain immutable authority; delegation and external content do not create additional permissions. The Host validates the real creator, project and Session lineage, exact Tool occurrence, held Squad and opened Mission occurrence, and consistency between the accepted Tool input, creation contract and persisted Task request. These are data-integrity checks, not a natural-language authoring gate. Canonical attachments are forwarded independently from request prose; rendered attachment indexes identify source material. Once an assistant accepts a user Message, every Part in the complete `acceptedInputMessageIDs` batch is immutable, including non-parent batch members, so later writes cannot change the input that reply consumed. Task title, selected Squad, dependencies, structured Artifact authorities and accepted Delivery Slice revisions carry allocation. Task input rendering labels the request as the creator's assignment rather than promising it is a literal user quotation. A plan or report remains a claim to inspect against the operator outcome.

The Provider projection preserves every real-user TextPart verbatim. Guidance that a later user message is current input and live project-memory/task-plan context are labeled runtime system parts; neither is inserted into a user Message. Preserving recorded participant content does not require a coordinator to copy that wording when authoring a distinct Task request.

A completed Task's `task_completion_decision` remains an identity and evidence index; it does not copy the Orchestrator's narrative judgment or materialize an acceptance aggregate. A Mission first binds the current terminal occurrence through `panel_query_task`, reads the exact current Completion Decision Artifact, deduplicates its exact Orchestrator identity with decision-named `session_message` locators, and splits only a unique set larger than eight into consecutive `panel_read_task_message` batches. The Host atomically validates every identity in each batch and returns real visible text-Part windows with persisted Message/Part and agent identities, UTF-8 offsets, lengths, digests, and text under aggregate bounds of 30000 text bytes and 64 Parts per call. An initial Message identity may omit `byte_offset` or explicitly use zero; a positive offset is a continuation and must carry the exact Host-returned `text_part_id`. Short finals complete in one call; longer or many-Part evidence returns exact `next_messages`, which is the only continuation input and is passed unchanged until `complete=true`. It preserves real participant content while excluding reasoning and Tool payloads; it does not retain the old inventory/chunk protocol, synthesize an acceptance aggregate, select latest Messages, or enumerate Task history. Task lineage, Mission ownership, active Project, current terminal time, the single Completion Decision, and its locator set are revalidated on every continuation. An earlier planning Artifact's stage-local statement that execution had not happened does not establish a present omission after concrete later execution and verification evidence resolves it. Persistent user constraints, authoritative source facts, and contradictions not resolved by later concrete evidence remain acceptance inputs; recency alone does not establish truth.

## Task lifecycle and execution epoch

`protocol_event` is the sole Task lifecycle authority. Task aggregate identity is stored once as `(aggregate_type='task', aggregate_id=task_id)`; `protocol_event.task_id` is `NULL` for Task aggregate events and is reserved for correlation from non-Task aggregates.

Execution lifecycle and Session error projections originate once from their real Bus participant and persist through one protocol bridge. A Task-owned Session keeps the Task aggregate above with immutable `session_id` correlation; a Session with no explicit or durable Task lineage uses `(aggregate_type='session', aggregate_id=session_id)` and leaves `session_id` null by the aggregate identity rule. The public Session event stream subscribes to all Session-aggregate public events plus only `agent.execution.lifecycle` and `session.error` from Task aggregates, then applies immutable Project/Session-lineage filtering. Connection cutover replays at most the latest terminal lifecycle and latest error for each Session in the selected tree, using the same immutable event IDs as live delivery; its overlap set is discarded after buffered events flush. Cross-aggregate latest selection orders by `emitted_at` and globally comparable event ID, never aggregate-local sequence. The process-local Session mirror does not publish either durable event type, so reconnect and live delivery observe the same fact rather than parallel projections. Process-local physical lifecycle wins for every Session in the tree: after restart, historical `streaming` or `retry` cannot project a live owner, while a durable terminal may restore the last settled occurrence.

Every physical Build Turn publishes its required Host observation through the
same provenance, publication and cleanup owner before returning, including a
coordination handoff. Its result carries that publication receipt and the original
final Message identity alongside the real coordination request. The sole Build
adapter projects coordination only after successful publication; collection or
publication failures retain the existing typed partial outcome. The independently
persisted coordination request remains available with its original Task/Session
lineage. A continuation captures its own physical baseline and cannot substitute
for a missing earlier observation. Retained observations and immutable content
remain readable across continuation through their existing canonical readers.

Task run evidence retains the immutable creation workspace identity and the current
execution occurrence's Git baseline as separate facts. A resumed Task can retain
earlier correct output and therefore capture a different baseline. `EngineGit.prepare`
owns the creation-to-first-execution workspace check; evidence readers preserve both
identities and the current epoch's checkpoint rather than comparing different occurrences.

The domain writer and its canonical Protocol fact share one database transaction. Task creation inserts `task.created` beside the Task/root-Session/creation-contract/ingress facts; Interaction request and outcome writers insert `interaction.requested` and `interaction.resolved` beside their immutable domain rows. Requirements, Architect, Browser Preview target, and Orchestrator Delivery Slice writers append `task.updated` in the same transaction as the exact Artifact or GoalGraph mutation. A failed Protocol insert therefore rolls back the owning domain mutation. Post-commit live dispatch remains a projection of the committed Protocol fact, and reconnect reads that fact; no post-commit effect is allowed to manufacture the canonical lifecycle event.

Execution actor identity is resolved from the exact durable user Message named by `inputMessageID` and its owning Session. `persistedExecutionIdentity` is shared by lifecycle, assistant-message ownership, and Task execution projections. An `assistant` Session is a container; its occurrence actor is the input Message's `agent`, including when a historical scheduled result later gains a visible Work surface. Exact WorkerTurnDescriptor identity remains binding and must agree with that input. Current right-sidebar Chat/Work metadata owns new-input routing and Session-level notifications, not the actors of earlier occurrences. Helper and Mission receipt messages retain their real participant identity while `sessionAgentID` identifies the input's execution owner. User-message removal projects the original event snapshot through the same identity resolver because the row has already been deleted. Session-level notifications and empty containers have no fabricated execution; the root control inbox keeps its distinct addressing semantics. Historical occurrences never derive an actor from a newer input, the latest descriptor, or the current configuration.

Persisted history resolves that execution identity once for each parent Message. Its Parts must name the same Message and Session, and retain the shared durable Part/Tool-request ownership and timeline-order checks. History does not recompute discarded actor metadata per Part; live events still expose and validate their complete actor metadata. Descriptor schema and immutable hash validation remain part of the parent identity resolution.

Session-local delegates classify the returned canonical assistant Message before
publishing a terminal fact. They use the same hard-error conversion as Task
workers and Orchestrator, preserve the original error as its cause, handle
cancelled replies through the cancellation path, and require a completed reply
with a nonempty text handoff before publishing `completed`. A returned reply
pins publication to its own `inputMessageID` and `final_message_id`. The first
terminal remains immutable; a later handoff-validation exception cannot be used
to repair an already-published success. Original failed Message/Part evidence is
retained, and an independent retry has its own execution identity.

Public Session executions capture their actual prompt generation owner. When
that exact owner rejects a request with its cancellation reason, the HTTP writer
waits for its physical finish before reading the canonical settled reply for the
request's input Message. A persisted aborted reply remains the reply; cancellation
does not become a generic transport error or trigger another model attempt.
The initializer's boolean result uses the same completed-reply contract. Unknown
errors and cancellation without a canonical settled reply retain their error
path; no assistant Message is synthesized to fill a missing fact.

The lifecycle event family is:

```text
task.execution.opened(epoch)
task.cancellation.requested(epoch)
task.cancelled(epoch) | task.completed(epoch) | task.failed(epoch)
task.execution.reopened(epoch + 1)
task.deleted(epoch)
```

One epoch has one open boundary, at most one cancellation request boundary, and one mutually exclusive terminal boundary. Cancellation is the only boundary request: a Task is left by completing, failing, or cancelling it, and there is no separate close request or close terminal. `engine_task` contains durable Task definition/input fields only; lifecycle status, start/completion time, terminal error, cancellation metadata, and rewind cursors are reduced from Protocol Events.

A late activation, decision, or effect request carries its exact epoch and is rejected after a newer epoch opens. An already-requested external effect may still append or reconcile its exact outcome after cancellation, because discarding an unknown outcome would permit duplicate side effects.

Three exact authorities may open the next occurrence. An explicit operator Message opens completed, failed, or cancelled Tasks. A Mission acceptance resume opens only a completed or failed Mission-owned Task, and must bind the exact current terminal lifecycle reference, current acceptance-ledger revision, completely read evidence, exact acceptance responsibility, and one visible Mission-authored structured repair Message. An active [continuous goal](continuous-goal.md) may open completed/failed Tasks only through a receipt bound to that goal's current intent revision and exact settled frontier, committed with its visible goal-controller Message and ingress. These authorities append `epoch + 1`; the prior occurrence stays intact as an immutable fact at its old epoch. There is no separate retry or replan control. Ordinary scheduler delivery, agent coordination, recovery, and late Tool/Provider outcomes must match an existing occurrence and cannot obtain reopen authority. A status or report question also arrives on the reopened epoch. The Orchestrator may reuse verified historical evidence and reports, deliver the visible answer and complete this epoch through the ordinary lifecycle Tool when no independent progress remains. The Host neither classifies prose nor infers completion.

Mission acceptance obligation is an append-only `task_acceptance_ledger` Artifact lineage, not another lifecycle. Each revision points to the prior revision, names its exact execution epoch, stores one typed state (`open`, `accepted`, or `blocked`) per criterion with canonical evidence locators, and never copies Task/Session status or Artifact bodies. Every state carries all five append-only evidence arrays: observation, attempted-repair, resolution, invalidating, and irreducible-blocker locators never move between roles. An unchanged open criterion may be carried forward exactly while another criterion changes. A changed `open -> open` requires a new locator or a changed canonical structured repair-action hash; `open -> accepted` requires new resolution evidence; `open -> blocked` requires new irreducible-blocker evidence; `accepted -> open` retains resolution evidence in that role and requires `stale_evidence` plus new invalidating evidence. Accepted and blocked states otherwise retain exact immutable facts. Each revision must contain at least one new or validly changed criterion; changing the gap label, reviewed terminal or criteria order alone does not create a revision. The structured repair action is the single authority for its expected evidence kind and canonical identity hash. Responsibility identifies an immutable virtual-workflow node, an exact direct-dispatch package revision/Agent/`dispatch_lineage` Artifact, or `task_initialization` bound to a real failed terminal event of the same Task before any dispatch at or before that execution epoch. A new initialization criterion binds the currently reviewed failure; later ledger revisions retain its original reference. Criterion responsibility attributes historical work; current repair or independent verification is assigned by the Orchestrator from actual capability/evidence needs and exact Task gap/criterion/epoch authority. Workflow ancestry does not gate that assignment. Initialization responsibility covers the subsequent actual execution graph and its verification, without inventing a workflow or dispatch that did not happen.

An active Mission repair can grow through `panel_extend_task_acceptance`. The Mission must query the active execution and completely read all cited evidence in that same observation, name the exact current ledger, retain every existing open criterion byte-for-byte, and add an open obligation or reopen an accepted criterion with invalidating evidence. It retains the original reviewed terminal baseline and the current execution epoch. It cannot change or revoke in-flight grants; those require actual coordination and settlement. Prior worker descriptors still reference their original immutable ledger and effective criterion subset.

Admission atomically records the real Mission Message, existing durable ingress, and one immutable `mission_acceptance_extension_request`. This is pending input, not another ledger. The canonical root lease-acquisition transaction applies the request only after prior FIFO inputs have settled, checking the exact active execution and ledger compare-and-swap. It appends the single ledger and an immutable application outcome together with the lease. Structural conflicts produce a typed rejected outcome, not a Task failure, assistant decision, or infrastructure fault. The reducer projects `input_rejected` from that outcome, and its exact immutable disposition releases the queue. Earlier completion/cancellation/reopen uses the existing `terminal_inapplicable` authority instead. Admission replay validates the original Tool identity and returns that request with its derived application status. Outcomes and requests are readable through the existing Artifact catalog; reception is not proof the Agent has consumed the result.

Source reconstruction validates the real Message/Task/Mission/epoch and, after application, the exact request-to-ledger link. A shared repair projection feeds the root tools and checkpoint while preserving whether the source resumed a terminal Task or extended an active one. Normal and recovered activations use the same loader and transaction. No second mutable acceptance status, hidden Message, additional worker grant, or business-semantic gate is introduced.

The Task-root Orchestrator and every acceptance-repair worker continuation retain their physical Session lineage. Before the next Provider request, each consumes the current attempt of a logical compaction checkpoint keyed by Task, epoch, ledger revision, gap, and Session. Every failed attempt remains immutable and recovery creates a new deterministic attempt; the durable control reduction points to the pending attempt or latest consumed control and its exact summary Message binding. The checkpoint preserves Task authority, workflow/dispatch identity, criterion states, and canonical locators. It copies no Artifact body. Every repair Turn names the current gap and open criterion subset. An existing worker continues its original dispatch occurrence. A newly chosen capable responsibility may start an independent initial Turn when its actual inputs are available; its first durable input and WorkerTurnDescriptor bind the original request, acceptance ledger revision, evidence locators, and criterion responsibility before Provider processing. `checkpoint_required=false` is fixed by the initial Turn schema because there is no prior history to compact; continuation fixes it to true and consumes the existing compaction checkpoint. Both paths validate the referenced ledger gap and epoch. Historical direct-dispatch responsibility validates its exact package/Agent/lineage provenance; new repair allocation does not require a graph selection. A validated initialization gap permits an as-yet-unselected workflow: its first actual initial Turn uses an exact fixed-Squad capability and binds the current acceptance obligation. Any workflow snapshot is optional provenance, not a Task-wide execution constraint. Initial repair includes the original adapter request plus the acceptance obligation; it never receives a continuation prompt in place of that request.

Acceptance-repair selection scopes the authorized work; it does not require endorsing earlier conclusions contradicted by new evidence. Root and worker input projections share guidance to preserve still-supported business effects and report exact new evidence against the affected original obligation through real participant results or existing coordination. Reporting a finding does not expand mutation authority or revise the canonical ledger. The terminal-bound Mission resume contract above remains the authority for ledger revision.

Mission may inspect immutable Artifacts from its own active Tasks through the existing query/read tools. Task query, catalog pages, locator references and read chunks carry one observation authority: an exact terminal reference, or a null terminal reference plus `active_execution_reference` naming the canonical opened event and epoch. Every page/read revalidates that observation before and after access, so a new terminal or reopened occurrence requires a fresh query. These are projections of existing lifecycle facts, not another state store. Active inspection remains read-only coordination evidence. Formal cross-Task handoff and Mission complete/block/resume retain terminal authority; terminal actions count complete byte coverage only from that terminal occurrence, including when an earlier active read covered the same immutable Artifact.

The observation schema, value normalization and equality live in the pure `engine/task-artifact-observation-schema.ts` contract. Current-lifecycle lookup and revalidation live in `engine/task-artifact-observation.ts`. Evidence and database-integrity parsers import the pure contract directly; parsing a retained observation does not acquire a runtime lifecycle dependency.

Deletion is the boundary that does fence a reopen, per the retention rule below; the reopen transaction checks it directly rather than relying on the ingress acceptance that refuses a moment later.

Archive and delete are operator-owned retention controls, not fact-reconciliation decisions. After physical prompt/process owners have stopped, no unresolved Provider, Tool, queue, ingress, Message, Task, Mission, or Session event may veto either control. Cancellation publishes the Task terminal boundary without completing an assistant or inventing an external-effect outcome; the unresolved fact remains part of the immutable audit graph and may receive only its exact outcome later.

Before Task cancellation commits its terminal event, pending Permission decisions in its
Project-verified Session tree converge through the existing Permission ledger cancellation
writer. This retires approval waits, without inventing outcomes for effects that already
started. The public replay and Project bootstrap also reconcile earlier cancelled Tasks.
Host startup discovers residual waits from canonical pending Permission requests even when
the Task is absent from runnable discovery, then enters only independent Project identity.
It reports recovered cancelled-permission Tasks separately from initialized execution
Projects. Exact request identities captured under the cancelled lifecycle transaction bound
historical reconciliation across concurrent reopen; a new occurrence retains its decisions.

`task.deleted` is an explicit operator retention boundary after terminal convergence, not another execution status. It hides the Task from ordinary lists and fences every new ingress, lease, reopen, scheduler, Artifact, and activity write while preserving the Task definition, root Session, Messages, accepted ingress, lifecycle, decision, and effect facts as one replayable audit graph. Repeating the same explicit deletion is idempotent.

Deleting a Task-root, Mission, Panel-created, or Global-Chat Session tree uses `session.deleted` on each Session aggregate and, when requested, `task.deleted` on each bound Task in the same transaction. Those tombstones hide the public aggregates and fence new work; they do not physically cascade through immutable causal Messages, Parts, Protocol Events, or receipts. Prompt-owner and Permission-request writers read the exact tombstone inside their immediate admission transaction. The Session repository applies the same mandatory check inside every canonical root/child Session insert, Message upsert, Part update/data/progress, Message/Part removal and public Session-row mutation before any row or visibility effect. Standalone mutations take the SQLite immediate writer reservation; aggregate writers reuse their caller-owned writer transaction. Prompt, shell, clone, recovery, direct update and snapshot callers therefore cannot bypass the fence with a wrapper preflight, and a deterministic root identity cannot recreate a physically removed row. Deterministic find-or-create readers, including Mission launch/replay, first assert the existing identity inside the same immediate read transaction. Runtime-root materialization then creates only the exact missing root, and a second immediate admission assertion defines its durable serial order: a deletion which committed first rejects the replay and removes only that attempt's newly created empty root, while a deletion which commits later observes a root materialized before its own terminal boundary. Child creation checks both its identity and parent; snapshot import checks the imported identity and parent before any Session, Message or Part upsert. Retained deletion repeatedly refreshes the exact Session subtree, requests exact Prompt cancellation, and settles at most one fixed Permission batch per Session page in each outer round under one absolute deadline. That deadline is checked before every selected row and bounds waiter release, continuation resume and execution-outcome polling rather than only the batch query. Its tombstone transaction recomputes exact tree membership and proves the durable Prompt-owner set empty. For every Permission request, it also proves either a durable deny/cancel/stale retirement or an exact `execution_started` attempt with a durable outcome; a positive authorization before start and a started effect without outcome remain live deletion blockers even after a local deadline detached its waiter. Effect outcome and effect-lease release commit together. A concurrent child, Prompt owner or live Permission continuation that commits first makes the transaction fail with the typed runtime-not-settled result; the expanded tree and admitted work are incorporated and settled in a later bounded round. Retained terminal retries wait between attempts and may run no more than 256 transaction rounds within the same absolute deadline, so a live continuation cannot produce a hot SQL loop. A tombstone transaction that commits first makes each later admission writer fail with the typed deletion-fence result. Whichever transaction commits first therefore defines one serial order: a pre-boundary fact remains auditable, while every post-boundary mutation is rejected. The public deletion result is `tombstoned` and explicitly reports that Session causal history and authorization audit are retained; no route or Tool describes this disposition as permanent data erasure.

A standalone Session without those durable domain owners may cross the physical-retention boundary after every Prompt runtime and scheduler delivery converges. Before any row is removed, one stable Session-deletion occurrence binds the database instance, Project, root Session, exact tree membership, each Session directory, root public authority, and the exact `conversations/<session-id>` runtime root. The occurrence atomically acquires one non-expiring `session_deletion` control fence per tree member; an already-running Prompt is the exact cancellation target rather than a reason to create an admission gap. New Prompt owners and new Permission `requested` rows read that same fence inside their immediate admission transaction. Every filesystem manifest reassertion after fence acquisition remains inside the sole rollback/liveness `try/finally`. Reconciliation is advisory until it proves a committed or rolled-back winner: its own read, parse, evidence, or immutable-input failure is retained as diagnostic context but cannot bypass rollback through the first validated durable plan. Therefore any reassert failure restores the roots, releases the permanent fences, and closes the runtime owner. Deletion requests Prompt cancellation, reduces pending Permission occurrences through fixed 64-row pages, waits for the Prompt owner to finish, then reduces the exact pages once more. The terminal transaction proves no Prompt owner remains; no Permission request can enter after the fence. The fence is released only by explicit rollback or the terminal database transaction. A peer preserves a live physical process and may supersede only after exact PID/process-instance observation proves the owner dead or reused. Existing roots are durably renamed to occurrence-specific quarantine paths. One immediate transaction then revalidates the fences, ownership and tree membership, authorizes each exact physical terminal boundary while its Session row still exists, removes the exact Session tree, appends operation-bound `session.deleted` facts through that narrow authority, and retains the fences for committed physical cleanup; either all database effects commit or all roll back. Generic Protocol writers cannot append a missing-Session tombstone. Rollback first restores every admitted runtime root, then releases the permanent database fences, and only then retires the discoverable manifest; a crash after fence release leaves an idempotent manifest rather than an undiscoverable permanent lock. Cleanup validates and retains the same exact authority while removing committed quarantines and retiring the manifest; its finally boundary then releases the fences and process liveness. Request replay validates its Project and root-surface authority against the immutable manifest before any claim or physical effect, including completed-receipt replay. Replay and internal startup recovery then claim deletion authority before either rollback or committed cleanup. A live owner yields the existing in-progress contract, while only an exact dead-or-reused owner permits takeover. A committed residue returns `physically_deleted_with_residue`, and a repeated Session, right-sidebar or Panel request resumes the same operation identity before attempting to load the removed Session. Public results distinguish retained Session causal history from the immutable authorization audit, which remains available after physical Session removal. Recovery reads fixed 64-identity pages and restores quarantine only while the complete Session tree still exists with no operation-bound delete boundary; after the database boundary it only rolls forward. The Session repository exports no second recursive physical-remove operation: all public and internal whole-Session deletion enters this one retention authority. No Task-artifact cleanup, Project-deletion manifest, empty target set, process-local callback or manifest timestamp substitutes for that owner.

## Task-root ingress

`engine_task_root_ingress` is an immutable accepted input:

```text
IngressAccepted {
  id, task_id, execution_epoch, sequence,
  source: task | message | protocol_event | engine_artifact | inline,
  source_id, inline_payload?, policy_id, time_accepted
}
```

The source locator is validated in the acceptance transaction. A Message source must belong to the Task root Session. A Protocol source must be a Task aggregate event for that Task. Inline input uses the ingress identity as its producer identity. The same normalized source can be accepted only once across all epochs.

`sequence` is the immutable FIFO order inside an epoch. Lease acquisition itself verifies that every prior ingress has released head-of-line order — `resolved`, `terminal_inapplicable`, `input_rejected`, `exhausted`, or a durably `operator_abandoned` Host fault, the states with immutable release evidence; no caller-local queue check is trusted. That release is one predicate shared by the durable fence and the scan, so a state cannot hold the line in one and not the other.

The ingress reducer first preserves an immutable operator abandonment, then detects source integrity errors and immutable input rejection. Otherwise its total order is:

1. `host_fault` for a broken Host write invariant, named by which one;
2. `terminal_inapplicable` for a cancelled, closed, or superseded epoch;
3. `resolved` for exactly one valid assistant-owned decision set and no conflict; one completed assistant Turn may own multiple sibling `dispatch_agent` receipts, while one `dispatch_agents` receipt is itself the complete ordered collection occurrence and every other decision set contains exactly one receipt;
4. `leased` for one still-valid, unconsumed activation;
5. `reconcile_required` for a write-ahead external request whose outcome is unknown;
6. `waiting` for one unresolved explicit Interaction/deadline decision;
7. `cancelling` for the active lifecycle fence;
8. `exhausted` when immutable semantic/physical budget or deadline is exhausted;
9. `ready` otherwise.

There is no mutable ingress disposition, delivery-result, semantic-attempt, activation-attempt, retry-owner, current-owner, or blocker row. Immutable `task_root_ingress_disposition` Artifacts memoize release evidence; the reducer remains the authority. A rejected input names its exact Mission extension outcome and original request; it does not fabricate an assistant-owned decision. `exhausted` is an exceptional terminal reducer result derived from policy plus facts; it permits the FIFO to admit a later explicit operator input when malformed or repeatedly undecided output reaches its finite fence. Normal quiescence never uses exhaustion: the Orchestrator records the real non-mutating `no_action` decision receipt.

## Decision-gap continuation

A Task-root activation retains its one deterministic assistant Message across
healthy Provider steps and automatic context maintenance. Successful usage overflow
and predictive compaction preserve that Message and its real Parts; the separate
summary and consumed control do not settle the reply owner. Actual decisions,
park/handoff, failure and cancellation retain their own completion boundaries.
A genuine Provider context-overflow failure remains on its completed original
assistant; the existing ingress recovery may create a successor activation with
that assistant as its exact predecessor. It never reopens the completed original.

A completed root assistant must satisfy the shared settled-reply predicate using
its accepted input and real Tool results. Violating that completion contract is
a typed Task-root integrity fault. The durable evidence reader derives the same
`host_fault/evidence_violation`, whose surfaced gate and abandonment release this
ingress while preserving the Task for a later authorized input. Prose without a
decision continues to use its existing finite semantic budget.

A completed Tool transport receipt is not sufficient dispatch acceptance. The live
decision coordinator, reopened assistant Message reader and ingress reducer use
the same typed output contract. An `infrastructure_failure` requires a subsequent
model decision. A collection contributes its dispatch decision when at least one
member has a valid non-infrastructure outcome; an all-failed collection requires
follow-up. In-flight reservations still serialize incompatible decisions and
preserve independently accepted siblings. A malformed completed receipt is a
contract error. The shared projected Tool boundary propagates the provider-visible
Tool name so adapter validation checks the real persisted outer invocation.

Session Message causality is allocated by the Session persistence boundary, not by caller wall-clock order. A new Message obtains SQLite's writer reservation before reading its exact Session frontier and persists `time.created = max(requested_created, latest_session_created + 1)`; existing Message creation time remains immutable. Moving a real Task-root participant Message into its Orchestrator Session obtains the same writer reservation before allocating that target Session's next frontier. Message events, timeline order keys and child Parts use the persisted frontier, and a Part cannot precede its parent Message. The frontier is scoped to one Session, so concurrent projects and Sessions do not share a global sequence.

Every accepted current Task-root participant input uses that same original-Message delivery before Orchestrator model execution, including operator, goal-controller and non-scheduler Mission/orchestrator messages. Delivery preserves Message/Part identity, body, role and author within the same Task lineage; replay reuses an already delivered Message. The current participant is therefore visible as original history to normal execution and compaction, rather than surviving only as quoted Tool output. `read_task_message` remains an exact current-wake retrieval capability for the same source and attachments, not a required step to expose the original message or broad access to other root history. Scheduler delivery retains its additional immutable provenance checks. Initial creator input and worker-specific steering keep their existing ownership paths.

Delivery admission prepares the original participant without changing its Session.
The scheduler first constructs the exact runtime contract, then commits the Move
and its wake before visibility effects can resume a retained Session loop. When
that occurrence also requires an Orchestrator control Message, the original Move
and control bundle commit in the same transaction; the control's existing wake
hook arms their prepared runtime. Failed scheduler preparation retains the input
under its original Task-root owner. This ordering does not create a second
participant, weaken continuation identity, or select a model workflow.

A fresh typed Task occurrence requires both the real task-creator Message and its deterministic Orchestrator control Message. The Session prompt writer prepares them under one runtime-contract write claim and commits both bundles in one immediate transaction before arming the runtime wake. Observers therefore see either the complete creator/control cut or neither participant; replay validates the existing deterministic control identity and never synthesizes or reorders a Message after visibility.

A prose-only Provider step is visible content, not a business completion. While the current live activation is otherwise safe to continue, it remains inside the same assistant Message and activation:

Every Provider step receives two JSON values: the canonical current `TaskDesc` baseline and a strict `task-projection-delta-v1` envelope. The first step uses that same shape with an empty, cursor-bound operation list. Later steps apply ordered JSON Pointer `replace`, `append`, and `remove` operations only when the envelope's previous cursor matches the supplied baseline; the resulting cursor must match the envelope's current cursor. Optional TypeScript fields are omitted by normal JSON value materialization before canonical key ordering, so `undefined` never becomes a second projection contract.

Every dispatch settlement projection retains its existing outcome's exact
`final_message_id` (or explicit null when that outcome has none), for both direct
and declared workflows. This is the persisted settlement's participant report
reference, not a latest-Message selection. The completed assistant-Message
inventory retains each recorded `finish` reason because a completed Tool step
is not by itself a terminal worker report. The exact Message reader exposes the
same finish/completion facts without inferring success. Its required input is
an ordered set of one to eight globally unique terminal dispatch-settlement
Message IDs. A later dispatch does not revoke an earlier terminal worker
Message whose evidence remains material. The
first read also returns a bounded, redacted page of real text and Tool Message/Part
identities from the same Session, the same accepted input parent and no later
than each selected final in persisted `(time,id)` order. A compact reference
`causal_part_reference_index` lists every causal Part's exact Message/Part identity,
`part_type` and redacted short text or input preview when its serialized size fits
the declared bound; `complete=false` and `part_count` explicitly mark an oversized
index. `causal_part_message_inventory` groups at most 16 Parts per source into
`part_facts`. Text belongs to the selected final's exact worker agent; other actors
and reasoning Parts are outside this projection. A prose-only earlier Message is
readable through its original identity without becoming a dispatch-result anchor.
This is another density of the same persisted facts, not a second authority or
an inferred business decision. Older detailed pages use the returned per-final
`inventory_next_before` cursor. A caller may then supply up
to eight exact `message_id+part_id` pairs returned by that final's index or inventory
in this or an earlier call through
`evidence_reads` with an explicit `text`, `input`, `output`, or `failure` field; the
same reader returns a structured-redacted projection of that persisted Part
field in chunks whose requested total is at most 30000 characters, with
`next_offset` until complete. Final-Message Tool parts use the same safe
metadata projection rather than bypassing this chunk path. Materialized
truncated outputs resolve through the same authoritative source primitive as
compaction. Runtime validation rejects non-settlement Messages and Messages
from another Task, occurrence, Session, or later causal frontier. The reader
does not enumerate an unbounded history in its Provider schema; it validates
each submitted final ID against the Task's immutable dispatch settlements. A
`dispatch_agents` collection has at most eight members, so all of its final
Messages fit one read; a larger legal direct fan-out is read in caller-selected
ordered chunks of at most eight. The reader neither reconstructs dispatch
groups nor copies historical settlement identities into the Tool schema. Its
executor resolves and verifies every persisted Session owner
against the current Task, then returns the exact Message projections in caller
order. It does not accept a caller-supplied Session identity, select a latest
Message, correct an identifier, retry a rejected read, or retain a
singular compatibility input. Fresh and reconstructed Task baseline/delta
views carry these facts through the existing single read path; a sibling's
terminal wake never establishes another sibling's completion.

```text
accepted ingress
  -> Orchestrator control/participant Message
  -> streaming assistant Message, Provider step without decision
  -> ephemeral decision-repair context
  -> next streamed Provider step in the same assistant Message
  -> valid decision receipt or immutable semantic limit
```

The control and assistant Messages live in the same immutable `kind=orchestrator` child Session of the Task root Session; that existing Session parent edge supplies Task ownership and must match the Task project. The assistant stores only its physical `activationID`; its parent Message supplies the ingress identity. Every non-`tool-calls` `StepFinishPart` is an immutable decision-gap attempt. The ingress's immutable semantic limit bounds same-assistant repair; the final bounded step completes the assistant and projects `exhausted/semantic_limit`. Historical completed prose-only assistant Messages without StepFinish evidence remain legacy attempt facts, but current execution never mints a successor activation merely to ask for the missing decision. No prose is parsed and the Host never chooses or synthesizes a decision.

The core instructions distinguish the visible conversational answer from the required scheduler or lifecycle receipt in the same streamed response. Restrictions on product operations remain binding while the model records the decision supported by the live epoch; a short answer alone cannot settle the ingress. Decision-repair context tells the model that its preceding text is already visible and asks it to supply the missing receipt through the exact callable Tool schema. It permits material corrections or new information, rather than another copy of the answer. Task completion uses `manage_task action=complete_task` with actual evidence and deliverable identities. Neither this context nor the Host classifies operator prose, forces a Tool choice, manufactures a receipt, or restarts historical work.

An operating-system process loss remains a real physical-attempt boundary, not a same-assistant continuation. On reconciler entry, after an append-only lease fence expires, recovery terminalizes the exact abandoned open assistant before reducing exhaustion or acquiring a successor. The lease expiry is the deterministic terminal timestamp, so concurrent reconcilers converge on one byte-equivalent completion instead of conflicting over wall-clock time. The resulting completed provider-error Turn is therefore the predecessor of any successor activation; deterministic control and assistant identities cannot collide with the abandoned physical attempt. At the semantic limit the same recovery boundary terminalizes the abandoned assistant and converges directly to `exhausted/semantic_limit` without another Provider activation. Recovery never treats a persisted `StepFinishPart` alone as proof that the corresponding Provider activity has a unique successful outcome: missing outcomes still project the existing explicit activity-reconciliation path. It never broadens or reuses physical-Turn Artifact references across that recovery boundary.

The Orchestrator inactivity observer is part of the physical prompt owner, not detached diagnostic work. Prompt settlement clears future polls and joins any observation tick already reading the Session tree before project ownership may be released. An in-flight observer therefore cannot reopen or read a disposed project after the owning prompt has completed.

Provider transport activity and Session semantic activity are separate authorities. Response headers and every streamed byte renew only the Provider fetch transport monitor. The Session LLM activity monitor starts at the first accepted upstream event and renews only for a chunk that publishes observable incremental progress: text or reasoning content, a Tool input/result transition, or a step boundary. Reasoning framing made only of whitespace or square brackets does not trigger the canonical writer's periodic reasoning-delta publication and therefore cannot continuously renew semantic idle; `chunkHeartbeatKind` and that incremental writer share the same content predicate. Reasoning-end may still persist the complete accumulated Part. The same semantic mapping is used by normal Session processing and standalone streamed LLM helpers. Retry owns a fresh physical attempt under the existing total and class budgets, while the logical Provider activity keeps one request and one terminal outcome receipt across those attempts.

An accepted Tool call pauses Provider chunk-idle observation, but not without a finite inactivity contract: `assistant.activity.session_tool_idle_ms` bounds the interval since the latest durable Tool progress. Each changed live metadata payload appends an immutable `tool_part_progress` fact under the exact request Part; the latest fact is projected into the visible running Tool Part and renews only that Session's pause window after commit. Bash maintains its real cumulative output byte count incrementally and samples a fixed 4 KiB preview only when a real chunk crosses five seconds since the prior sample or adds 64 KiB since it; progress therefore remains monotone after preview truncation without rescanning history, an unbounded fact rate, or a timer heartbeat. An in-memory sample, duplicate payload, failed append, timer, filesystem mutation, or another Session's progress cannot renew it. The terminal Tool outcome supersedes the live projection and closes further progress appends, while Tool result/error resumes the same prompt owner's ordinary chunk-idle observer. Foreground timeouts and background leases remain properties of the Tool and its process supervisor, so Provider inactivity does not become a second absolute Tool-runtime limit; if a Provider boundary fails after an effect began, the existing unsafe-retry fence still prevents replay.

A real executor can hand off a fixed, actually armed execution deadline plus its bounded physical settlement deadline. SessionLoop accepts the runtime-branded object through its internal call-bound observer, persists it through the same `tool_part_progress` writer, and grants only that active SDK call a finite pause hold. A lookalike dictionary in Tool metadata, MCP Task retention TTL, or repeating `working` status does not grant a hold. Bash uses that same deadline signal for timeout/abort and one absolute cleanup cutoff for termination and disposal; background readiness and leases retain their own contract. SDK execution establishes pause ownership before a queued consumer event can arrive, and releases only its own owner on synchronous, Promise, or AsyncIterable settlement. An already settled call cannot acquire a late consumer pause. Ordinary Provider idle and ungoverned handoffs retain their finite guards; handoff completion restores observation without a timer heartbeat. Restart does not recreate a live executor grant from arbitrary stored metadata. Timeout diagnostics retain the real pause boundary and owner rather than relabeling it as the shorter Provider-idle threshold.

Artifact locator/read/selection references remain capability-like facts scoped to the exact control parent and physical Turn. The exact current Tool Part identifies its persisted Provider step, whose `step-start` Part is the exclusive causal read boundary: only completed producer Parts from prior Provider steps are visible, so same-step parallel siblings cannot leak forward regardless of execution order. Same-activation repair therefore preserves prior-step references naturally. A later independent ingress or genuinely new physical Turn must search/read/select again; the Host never broadens a reference to compensate for a scheduler retry.

The activation is consumed only at a final non-Tool-call assistant boundary with zero outstanding activities, or at a wait/provider-failure boundary with zero outstanding activities. An intermediate Provider step or one completed sibling Tool does not release the activation.

Lifecycle cancellation or a terminal Task decision fences every new Provider/Tool request immediately. It does not erase an activity accepted before that boundary: the latest matching activation may append the exact outstanding outcomes and then the immutable completed assistant boundary after every accepted activity is settled. Lease expiry and absolute deadline do not convert that exact settlement into a new request; a newer activation, epoch mismatch, causal-parent mismatch, or any outstanding outcome still rejects it.

A completed exclusive Tool outcome whose metadata carries the typed `immediate_park` control is itself the durable reply boundary for that assistant Turn, even though the Provider finish reason remains `tool-calls`. Session completion and recovery reduce that persisted outcome control; they do not infer reply completion from prose or require a synthetic follow-up assistant message.

An active acceptance ledger does not by itself veto `no_action` for every later input. The Agent distinguishes a status/coordination input from work that still needs action. Settling an input leaves the Task lifecycle and every acceptance criterion unchanged; the ledger remains binding until independently evidenced repair and review. The Host validates the declared lifecycle observation, not the semantic sufficiency of that decision.

`no_action({reason, observed_task})` is the sole non-mutating Orchestrator decision. Its completed assistant-owned Tool request/outcome resolves only the current ingress and uses `immediate_park` to close the physical Turn. It creates no timer, Automation, Interaction, worker action, Task lifecycle fact, future wake, or durable waiting state. The model declares the current Task epoch, status, opened event and nullable terminal event in `observed_task`; the Tool validates those facts against the canonical reducer and returns `TaskLifecycleObservationConflictError` with the actual observation on mismatch. Matching active, cancelling and terminal observations are valid: this integrity check does not judge whether no_action is semantically sufficient or prescribe the next Tool. The model uses this receipt after answering an already terminal conversation, or reconciling a non-terminal input with independently continuing worker, wait, Interaction or accepted successor authority. Status/report questions have no exemption from the current epoch's closure responsibility. Existing report content must actually be delivered, not merely promised, before ending the Turn. Scheduled `wait` remains a distinct decision that names an external event and carries a defensible duration. Under Task authority it registers one epoch-bound native Task wait whose due materialization is an exact Task ingress; under conversation authority it creates one Session-delay Automation. It is never child polling or an alias for `no_action`.

The live Orchestrator Task description includes `execution_lifecycle` from the canonical Task lifecycle reducer: current epoch, exact opened event, status, any current-epoch request or terminal event, and an optional `previousTerminal` with its own epoch/status/event/time. Task detail/list API exposes that same projection as `executionLifecycle`. Its display status and terminal error derive from the current epoch. Full baseline, incremental delta, and markdown context retain this identity for distinguishing old completion from current reopened execution work. This is a read projection, not another stored lifecycle or a Host decision rule. Complete frontend board snapshots reconcile removed fields as well as updated fields, so a prior epoch's terminal reason or completion decision cannot survive an active snapshot as unscoped current state.

Task conversation report summaries bind each exact completed Protocol occurrence to its completion decision and real owning assistant Message. Both turn-artifact and conversation hydration routes project these historical deliveries during subsequent active, failed or cancelled epochs. Catalog pagination and exact revision/resource reads remain authoritative; an existing structured record remains inspectable without pretending it is a published file. Reopening never erases an earlier report or reassigns it to a later Message.

Task terminal publication retires retained live message payloads and advances their retention floor, while preserving the per-Task live sequence within its process-wide live epoch. Open subscriptions and reconnecting clients retain that same cursor domain across completion, failure, cancellation and operator/Mission reopen. Restart changes the process live epoch; lifecycle changes do not. Resetting sequence numbers at Task terminal would drop subsequent real participant messages on an already mounted stream.

## Physical leases

`engine_control_activation_lease` is the only durable physical owner coordinate. Targets include Task ingress, lifecycle operation, Interaction deadline, domain effect, Protocol delivery, Bus delivery, Automation definition/run, Event fire, Session control, standalone Session deletion, and build cleanup.

Each row contains one activation identity, target identity, owner occurrence, activation time, and mutable live expiry. A successor inserts a new row only when no latest valid lease exists. Acquisition and every renewal also append one immutable `engine_control_activation_lease_grant(lease_id, ordinal, expires_at, time_created)` row before the transaction commits; release shortens only the live expiry and never rewrites the grant history. A durable business attempt freezes the exact retained lease, grant ordinal, and admission-time expiry. Live admission chooses the current lease by `(time_activated DESC, id DESC)` and the latest grant ordinal in the same writer transaction. A grant appended after an attempt remains valid historical renewal rather than reinterpreting the original admission.

Before an external effect or resolution append, the worker rereads the exact lease, epoch, deadline, and unresolved facts. Lease validity never proves business completion. Process-local owner maps and runtime settlement registries are performance and shutdown primitives only.

## Tool and Provider effects

Mutable Tool Part state is not stored. A Tool effect uses:

```text
tool_part_request(id, message_id, request_data, time_created)
tool_part_outcome(request_part_id, outcome_data, time_created)
```

The public `ToolPart.state` is projected from those two facts. Pending streamed input drafts are transport only and are not durable evidence that an effect started.

A Provider call uses:

```text
provider_activity_request(id, assistant_message_id, time_created)
provider_activity_outcome(request_id, outcome_data, time_created)
```

The parent Message uniquely supplies Session identity, so Part, Tool request, and Provider request tables do not repeat `session_id`. An unreceipted request projects `reconcile_required`; replay is allowed only with the same provider idempotency key or after an authoritative outcome query.

The first Tool request row owns its transport timestamp and display metadata. Re-observation from the Provider stream and the execution wrapper is the same immutable request when call identity, Tool identity, input and metadata are structurally equal; JSON object property insertion order is not semantic identity. A genuine value change fails with the explicit immutable-request conflict before execution.

Git, filesystem, dispatch, build cleanup, Permission, Channel ingress, Interaction, and Bus effects follow the same request/outcome rule using their domain-specific sole fact types. In particular:

- `engine_git_checkpoint_request` is written before repository publication and `engine_git_checkpoint_outcome` is its only result authority. The same Task mandatory and auxiliary process write leases remain held through the awaited checkpoint callback success or failure. Other Task keys remain isolated; the separate Git tree owner still owns repository consistency. This lease lifetime changes no execution epoch, cancellation barrier or retry policy. Task metadata and progress rows project Git evidence at read time and never store a second copy. An unreceipted request is not replayed; an authoritative repository query or explicit operator reconciliation appends its exact result.

  Baseline, result and acceptance-round checkpoints retain commit objects through
  private `refs/opencorvus/task-checkpoints/<request>/<repository>` anchors. The
  exact write-ahead request and repository identity determine each anchor; native
  compare-and-swap creates it only from a missing ref, with no dereferencing.
  Even a `recorded_head` outcome receives a retained anchor. `checkpoint_ref`
  identifies that anchor, while `ref` and `head_before` retain the observed user
  checkout identity. These snapshots preserve the user's branch, detached or
  unborn HEAD, canonical index and staged content. Temporary indexes assemble
  snapshots only. A completed or failed Task is not permission to publish a user
  commit. Actual user commits remain explicit VCS or authorized Tool effects.
  Rollback releases only this operation's exact created anchors; an external
  winner returns a recovery conflict and retains its commit. Snapshot history,
  like the prior checkpoint commits, can remain in the repository after Task
  removal; it is distinct from temporary Build-observation refs and their cleanup.
  Subsequent checkpoints derive explicitly declared ignored files from successful
  acceptance requests and outcomes in the same epoch, preserving readable
  artifacts without promoting those paths into the user's index. Historical
  outcomes remain immutable facts; no new required storage field, schema or
  alternate historical writer is introduced.
  Checkpoint `dirty` compares its captured tree with the observed HEAD tree;
  live staging, worktree and upstream counts remain VCS facts rather than
  synthetic zero-valued fields in a snapshot outcome.
- `channel_ingress_accepted` requires the caller's stable `request_id`; an ingress without that causal identity is rejected before execution. Every production Channel adapter maps its provider event/message identity into that field; synthetic injection uses the exact newly-created provider message identity. Its envelope columns own `platform` and `request_id`, while the JSON payload excludes both. `channel_ingress_outcome` owns the result. If execution completed before the outcome commit, ordinary replay returns the typed unknown-outcome contract until exact downstream evidence reconciles it.
- one `permission_ledger(requested)` row owns authorization input. Decision/execution rows contain only their branch delta. The canonical Tool result is stored once as `(attempt_id, result, time_created)` in `permission_execution_result`; Session and Tool identities are derived through the attempt/request chain, and Tool outcome points to that attempt identity instead of copying the payload or its hash.

Build cleanup acquires its activation before the first private ref is created, renews that same activation throughout the physical Build, and appends retained, failed, or complete only under its fence; restart reconciliation can take over only an expired or receipt-consumed activation. A generic completion receipt is prohibited when a canonical domain receipt already exists.

## Protocol delivery and scheduler inputs

Scheduler execution inactivity owns preparation until a durable execution owner exists. Project/worktree entry, Session/database admission, Provider/model resolution, and activation persistence remain inside the scheduler inactivity interval. Session wakes await their durable activation receipt. A delayed Task wake passes an owner-completion wrapper into Task-root reconciliation; each physical activation invokes that wrapper only after its exact ingress lease commits and only around that activation runner. The wrapper settles and rearms scheduler inactivity before reduction continues, so post-owner scanning and every later lease acquisition are timed again. An already-owned or non-activating scan never delegates. Multiple simultaneously delegated owners retain suspension until the last owner settles, while a stall before owner establishment expires under the scheduler interval instead of escaping both timers.

`protocol_event` is the immutable envelope. `protocol_inbox` is one immutable recipient occurrence. Delivery attempts use generic control leases. `protocol_delivery_receipt` stores one discriminated `receipt` JSON fact per settlement:

```text
retry_wait(visible_at, error)
task_ingress(message_id, ingress_id)
session_wake(message_id)
mission_closed(closure_event_id)
dead_letter(error_name, message)
```

Delivery `status`, owner, lease expiry, attempt count, visibility, last error, result, update time, and completion time are projections. The receipt does not repeat these as independent columns.

`sendSchedulerMessage` returns the durable enqueue receipt for requests, replies, and notifications in every direction. The sender's Tool does not join recipient materialization, activation, or execution completion: the recipient may itself need that sender to finish its current Tool before it can consume a correlated reply. The enqueue transaction signals the existing delivery owner; inbox scanning and restart recovery retain ownership of eventual delivery and settlement. Callers use the envelope and inbox identities to inspect later delivery facts, and never treat the enqueue receipt as business completion.

Scheduler messages freeze exact source and target Task execution epochs. Materialization revalidates the target epoch before committing a real Message, Task ingress, Session control, or terminal receipt. The source body is reread from its exact Message/Part or terminal-event locator and never copied into a second authority.

Every Scheduler Message, Automation run, and Event fire targeting a Mission freezes its exact causal lifecycle boundary. An active occurrence names the observed `mission.execution.opened`; a fact created after closing began names that exact `closing` or `closed` event as its terminal disposition. Actual wake admission reasserts the opened event. If the Mission closes before admission, all three surfaces reduce the first closure after that opened event to one exact `mission_closed` terminal disposition; they do not retry the old occurrence into a later reopen. Scheduler Message replay derives this reservation from the envelope's aggregate sequence, while Automation and Event persist the same strict union with their run/fire. Validation never resolves an old fact against the Mission's current frontier.

Once a Scheduler Message has committed `session_wake`, that receipt remains its immutable delivery outcome. Mission close settles the real Session Prompt/assistant lineage rather than appending a second delivery terminal. Before `closed`, one bounded exact-occurrence query proves that every `session_wake` between the frozen opened and closing Protocol sequence has a completed assistant reply; the query returns at most one blocker and never rescans earlier Mission occurrences. A completed business error settles its physical wake while preserving the visible failure. Automatic recovery applies to unfinished replies and the runtime's exact typed `ProcessExecutionInterruptedError` only while the enqueue-time opened event remains current. Scheduler discovery, wake paging, admission rechecks, delivery audit and Mission process recovery share this settled-reply boundary: completed final steps, typed control handoffs and accepted input batches count as business replies; compaction summaries do not. Later real inputs and explicit retries retain their own execution authority. A fixed SQL page excludes closed history before applying its limit, so an old reply cannot cross a reopen or keep the one-second poll hot. Recipient drain selects only each recipient's current unresolved, due and unleased FIFO head in SQL. Fixed pages of wake, Mission-recipient, and Task-recipient identities are interleaved into one work-conserving frontier under the global Scheduler Message physical-capacity limit; a stalled effect does not leave a released slot idle, and terminal inbox history is not projected into that physical work set. Current writers and readers accept only canonical `session_wake`; future receipt changes require an explicit versioned data migration that preserves the original delivery authority.

Mailbox Protocol events follow the same envelope/body boundary. `mailbox.message` stores Task identity in the Task aggregate and Session identity in the envelope correlation; `mailbox.acknowledged` stores Task identity in the aggregate. Their strict durable bodies contain no repeated envelope identity. One shared EventView projector reconstructs the full public Mailbox properties for direct mailbox reads, idempotent replay, Orchestrator description, notification resolution and SSE delivery. Consumers never parse the raw body as the original ingress object and never patch persisted payloads.

## Automation, Event, Bus, and Session control

Automation and Event configuration changes append immutable definition revisions or tombstones. Execution is immutable and references the exact definition revision:

Recurring Automation public views and creation receipts expose the current
physical revisionId. Configuration update, pause/resume and deletion require
the caller-observed expectedRevisionId through HTTP and the Schedule Tool.
The sole writer validates exact revision before running Fire/lease admission
and repeats that validation in its immediate commit transaction. A changed
revision has its own named conflict; running conflicts retain their distinct
contract. No mutation silently accepts a newer version or retries over a peer.

Accepted Schedule configuration Tool occurrences recover from their exact
immutable definition/tombstone fact, original normalized input digest and real
Session/Message/Part/call identity, sharing the live receipt and result owners.
Current schema requirements apply to new acceptance, not rewriting old accepted
facts. Create normalization uses the same current default schemas once; no
version is invented and no second write occurs during receipt recovery. An
accepted nonterminal run still belongs to its existing Fire continuation/lease
owner and is not presented as completion.

- Automation: immutable definition revision/tombstone, logical `automation_fire`, ordered physical `automation_fire_attempt` plus attempt receipt, real `automation_run` plus ordered run receipts, the generic Automation lease, and at most one `automation_fire_frontier` physical-delivery authority per current definition. An active revision with a future occurrence atomically publishes its scheduled Fire and frontier. A valid exhausted recurrence projects `nextRun: null` and keeps its definition available for manual execution. Claim/renewal, retry, terminal settlement, manual-to-scheduled restoration, pause/tombstone and one-shot Session admission change the frontier in the same writer transaction as the fact that changes delivery authority. One global poll owner lazily reads indexed 64-row `available_at` pages into bounded physical workers. Released slots, new poll hints and the existing one-second cadence revisit due work while earlier workers remain active. Exact claim revalidates current revision, Fire and lease. Terminal scheduled reservation either publishes its exact successor or proves exhaustion before the terminal transaction commits. A zero-run terminal Fire is a real public occurrence. Current writers emit only `scheduled`, `manual_api`, or Tool-bound `manual_tool` provenance. Executor and retry read origin and due time from that immutable Fire. Manual execution is allowed while paused and preserves paused status; terminal settlement restores the existing pristine scheduled sibling when one exists, and a missing sibling requires recurrence-exhaustion evidence. Retry identity and supersession remain immutable facts; the mutable frontier owns no business outcome and is not a second recurrence calculator;
- Each Automation physical attempt freezes the exact lease ID, lease-grant ordinal, and admission-time expiry in its writer transaction. Historical ownership remains bound to that immutable admission, independently of the lease row's later mutable expiry.
- Event: `event_job_fire` input plus ordered `event_job_fire_receipt` facts and leases;

Event acceptance keyset-pages only the latest untombstoned definition revisions
for the active Project and creates matching Fires under that same immediate
writer snapshot. Each Fire receives one immutable definition-local queue
position. A terminal receipt carries the same DDL-verified relation and may
advance only the contiguous terminal frontier. Startup recovery, exact claim,
same-definition handoff and lease recovery seek that frontier through the
partial terminal index and then seek exactly its Fire successor. Each
64-definition page loads latest retry receipts and current leases through fixed
set queries; retained terminal Fires never enter the scheduling work set.
Exact claim repeats that head reduction inside the immediate lease transaction,
and a recovery timer rereads the definition frontier instead of assuming its
seed Fire is still current. Public Event history remains an explicit history
projection and is not reused as a scheduler selector.

Event acceptance records durable Fires and signals one Project-owned discovery loop. Only runnable definition heads acquire bounded physical permits; the persisted backlog is not duplicated into pending Promises or per-Fire runtime reservations. A canonical deleted Session target settles with `target_deleted` and advances its exact head, while transient failures retain their bounded retry. Current lease selection uses the existing target/time/ID index to seek one latest winner per requested target; it does not compare every historical lease with every newer lease.

Recurrence uses one patched `rrule` implementation with the existing Luxon timezone primitive. Generated nonexistent local times are discarded before `COUNT` and `BYSETPOS`; ambiguous local times choose the earliest instant. Absolute `UNTIL`, explicitly zoned `RDATE`/`EXDATE`, and UTC anchors remain independent of the host timezone. A syntactically invalid rule raises the typed recurrence error; a valid finite set without a future instant returns null.

When either target is a Mission, the immutable run/fire reservation is a strict union committed under the same immediate writer boundary: an active target carries its exact `mission.execution.opened` event, while a target already closing or closed carries `mission_closed` plus its exact closure event. Automation writes its matching terminal run receipt at admission; Event preserves definition FIFO and writes the matching Fire receipt only when that reserved Fire becomes the head. A non-Mission target carries none of those fields. Projection validates the stored event aggregate/type and, once terminal, the exact receipt; it never resolves a nullable Mission row against a later reopen. Rows without an exact causal pointer are not a current-schema fact and cannot be opened.
- Bus: publication/delivery inputs plus phase, attempt, and delivery receipts;
- Session control: `session_control_record` input plus amendment/consumed/failed events.

Task waits are native Task-control facts: one immutable `engine_task_wait_registration` names its creator Tool Part, Task execution epoch, creator ingress and activation; one optional `engine_task_wait_settlement` names the exact accepted ingress. The registration ID is also the due ingress `source_id`, `taskWaitWake.jobID`, and logical `fireID`; `dueAt` must equal the registered boundary and the ingress cannot be accepted early. The canonical ingress writer validates that complete identity against the still-unsettled registration before inserting anything; an arbitrary inline payload cannot exempt a wait from supersede or create a semantic Turn. A superseding ingress must follow the creator ingress in the same Task epoch. Registration, settlement and ingress are immutable while the owning Task exists, then cascade together through the canonical Task/Project retention delete. Current schema declares the canonical foreign keys and due identity directly; future wait-identity changes require a declared migration preserving the registration, ingress and settlement graph. Session one-shot waits remain Automation delays. Their due-wake-versus-ordinary-input winner is appended as `automation_delay_settlement` inside the same assistant Message transaction that accepts the input batch; that transaction may also append the exact superseded run receipt and tombstone. No post-commit Bus subscriber owns either decision.

Their legacy running, lease, attempt, failure-count, next-run, last-error, completion, and recovery columns do not exist. Public views reduce inputs, receipts, current time, and generic leases.

## Mission closure

Mission occurrence closure is an append-only Session aggregate Protocol Event family:

```text
mission.execution.opened
mission.execution.closing
mission.execution.closed
```

`opened` contains `missionID`, `requestID`, and the canonical accepted-input fingerprint. The fingerprint covers prompt text, explicit model, materialized attachment semantics, the complete accepted configuration patch, and caller context. Its Protocol event identity and operation UUID derive from the same immutable occurrence key; concurrent peers therefore join one winner. Reusing a request with input drift is a typed idempotency conflict. `closing` and `closed` additionally contain one strict close provenance. Session identity, operation identity, source, state, and event time come from the Protocol envelope and event type; they are not repeated in payload. Current DDL requires that strict shape at write time; older optional-provenance rows are another database epoch and have no current reader.

The `closing` event is the write-ahead close request and the sole close-recovery input. HTTP control, startup recovery, and peer takeover invoke one Mission-domain reconciler; routes do not inject a physical-close callback. A lifecycle-lease owner rereads the exact closing occurrence immediately after acquisition, derives every Prompt and child-Task cancellation from its persisted provenance, and propagates one bounded cancellation signal through Prompt settlement, child cancellation waits, lease renewal, and terminal commit. Active child identity comes from one current-lifecycle SQL authority; the reconciler cancels fixed pages of four through the canonical Task reducer, and the terminal transaction performs only a `LIMIT 1` active-child existence query. A contender returns the typed current-closing projection instead of polling. `closed` commits only in the same transaction that proves the exact live fence, no durable Session Prompt owner, and no active Mission child Task.

Retention is a later monotonic operation over that immutable close provenance. Archive and restore update the canonical `Session.time_archived` projection in one immediate transaction that proves an exact `closed` event and the absence of a delete request; an initial archive close performs the same update in its terminal transaction. Delete appends one `mission.retention.delete_requested` Session event with the accepted request provenance. An initial delete close appends that event in the same terminal transaction, while an already abort-closed or archive-closed Mission appends it under the exact existing-closed fence. The immutable request is the no-reopen and no-restore gate and remains the startup/heartbeat recovery input until the existing Session deletion authority appends the unique `session.deleted` boundary. Mission deletion follows that authority's tombstone contract: immutable Mission/Task/Session audit rows remain available for replay while current Session readers exclude the deleted boundary. The lifecycle lease owns only physical cleanup; it does not replace the request or completion facts. A plain abort close has no delete intent and is never deleted. Operator wake and archive/restore admission check the same retention facts in their own write transactions.

Operator wake admission plans a deterministic opened event and Message/Part/control identity from the accepted fingerprint. The opened event, real user Message bundle, and accepted configuration overlay commit under one immediate transaction that reasserts the prior closure; Prompt-owner acquisition reasserts that same opened event in its own ownership transaction. An exact replay reads the persisted bundle and outcome rather than rewriting it. A close that wins first prevents both Message persistence and Provider ownership. A wake that wins first becomes a stable input which close must settle. Non-operator wake and Mission-child Task creation use the same exact-opened occurrence fence and cannot open or reopen an occurrence. The Prompt owner observes the admitted opened occurrence for its lifetime and cancels itself when a peer commits closing, so `closed` cannot race a live remote Prompt.

When closing starts, scheduler deliveries not yet admitted receive the exact `mission_closed` receipt for their frozen opened occurrence. A delivery that already committed `session_wake` keeps that immutable receipt; close settles its real Prompt/assistant lineage, and the final close transaction uses a one-row exact-occurrence blocker query to require a terminal assistant reply. A never-dispatched draft closes as `closing -> closed` without inventing an opened event; its bounded final assertion accepts the empty admitted-wake set and rejects any impossible `session_wake`. A draft, closing, or closed occurrence produces its typed domain outcome without a parallel Mission status row.

Standalone Mission process recovery has no mutable marker, attempt counter, or second queue. Its reducer uses bounded SQL frontier reads over the current opened event, exact incomplete assistant Messages, deterministic recovery Messages/controls, terminal assistant replies, the generic lifecycle lease, and the durable Session Prompt owner. A live or unknown owner is preserved. For a proved-dead owner generation, the semantic occurrence identity is the opened event plus that generation plus the canonical interrupted-frontier digest. One immediate transaction writes its deterministic Message/TextPart/control, establishes the durable Prompt-acquisition fence, and releases only that generation. The canonical, re-entrant Session terminalizer then settles the exact frontier behind the write-ahead boundary; a crash at any later point leaves the same unanswered Message discoverable. Close uses the same strict actionable-Message/frontier reader: before `closed`, it terminalizes the exact interrupted assistants and appends one deterministic completed `MessageAbortedError` reply under the real recovery Message, so close takeover neither starts a second Provider effect nor leaves an actionable ingress behind. A physical interruption resumes that Message, while another terminal reply settles only that exact generation/frontier; a later dead generation in the same opened occurrence has a distinct Message. Lease loss and caller cancellation stop terminalization, activation, and completion waiting through one signal and return the lease for successor takeover. The absolute recovery admission deadline bounds only reconciliation and acquisition of a physical Prompt owner; activation clears its timer, and the existing execution activity policy governs the admitted reply. Typed caller cancellation retains its original actor and source through SessionWake; an ordinary caller abort is runtime.prompt_owner, while runtime settlement cancellation is process.shutdown. Every recovery Message names its exact opened event and cannot cross close/reopen. Current readers accept only the typed `ProcessExecutionInterruptedError`; predecessor wrappers have no compatibility reader.

## Reconciliation and recovery

Every successful Project bootstrap installs the existing instance-owned Mission
reconciliation driver, including Projects opened after scoped host startup.
Its bounded heartbeat reenters the serving Instance and uses the same recovery,
closing and deletion reducers as startup discovery. Bootstrap does not wait for
a recovered model reply; host discovery and later hints share the one driver
and its disposal owner. Project-scoped candidate reads preserve sibling isolation.

Project reconciliation is the only Task-control recovery algorithm:

1. enumerate Tasks whose lifecycle projection is open or cancelling;
2. read epoch ingresses in sequence order;
3. reduce the FIFO head from immutable facts and valid leases;
4. reconcile exact unknown effects before ordinary replay;
5. acquire and hint only `ready` work;
6. stop at waiting, lifecycle fence, blocker, or unknown effect;
7. continue after an exact receipt changes the projection.

Normal acceptance, prose-only completion, retry deadline, startup, process rollback, and receipt completion invoke this same reconciler. Startup does not persist scanner progress. Runtime queues, timers, pending Promises, and owner maps may accelerate a wake but cannot change reducer output.

### Liveness

Reduction is total, so safety never depends on scheduling. Liveness does, and the reducer cannot supply it: a `ready` ingress is executed only inside a scan, and scans are started by edges. The enabled set

```text
E(t) = { i : Reduce(i,t) = ready and every prior epoch ingress is resolved | terminal_inapplicable | exhausted }
```

can grow in exactly two ways. Either a fact is appended — a newly accepted ingress, a decision receipt, a terminalized assistant, an answered Interaction, an effect outcome — or time crosses one of the finitely many instants reduction reads: a lease `expires_at`, an Interaction resume deadline, an absolute deadline. Reduction is piecewise-constant in time between those instants, so that enumeration is exhaustive.

The reconciler owns one liveness coordinate per Task, and it is process-local runtime state, never a durable projection:

- every producer records demand by incrementing a monotone revision;
- one owner scans, and re-scans while the revision it observed is stale, so a scan always *begins strictly after* any given append;
- each scan re-reads its epoch ingress list, so an ingress accepted during a long activation is visible to the next pass;
- each settled scan arms one timer at the earliest instant its own projections can change, reading the immutable absolute deadline alongside the projection so a deadline is a real wake instant;
- an activation that loses its acquisition paces on the projection the acquisition transaction reread, never on the `ready` that led into it.

Those are *edge* obligations distributed across every producer in the program, so a single unwired call site is a silent permanent stall rather than a delay. The reconciler therefore also sweeps: one level-triggered heartbeat per project requests every live Task on a fixed period. Reduction is total and `resolved`, `terminal_inapplicable`, and `exhausted` absorb further appends, so a settled ingress costs one projection.

The heartbeat discovers enabling facts even when their producer missed an edge. Admission shares the Project concurrency bound, so latency also depends on available capacity and the finite fault retry deadline. A partially admitted source page retains only its unadmitted suffix/items: a repeated fast prefix cannot starve the tail. Edges keep the common path immediate.

The sweep covers exactly the Tasks whose lifecycle can still enable an ingress — `active`, `cancelling`, and one deliberate exception: a terminal Task holding an ingress accepted at-or-after its terminal instant. Acceptance keeps admitting operator and coordination input after the terminal boundary — the post-completion conversation — and that input relies on the same wake edges as everything else, so excluding its Task from the sweep reintroduces the lost-wake class the sweep exists to close. A terminal Task whose post-terminal ingresses this process has verified settled leaves the sweep; one with none never enters it, because an ordinary terminal Task absorbs every further fact and its dispatches are already settled by the completion gate. Recovery sweeps run once per scan rather than once per fixpoint pass, since their own effects re-enter the fixpoint and a later pass reads no new evidence.

The scan keeps two process-local absorbing-verdict caches: ingresses reduced to `resolved`, `terminal_inapplicable`, or `exhausted`, and dispatches verified settled-and-delivered or deliberately suppressed. Those verdicts are monotone in the durable facts — appends to a resolved activation are fenced, epochs only advance, budgets only fill — so a cached verdict cannot silently become wrong, and the caches hold no authority: losing one costs exactly one re-verification per entry. Without them each heartbeat re-reads full evidence for the entire settled history of every swept Task, a per-period cost that grows with the Task's lifetime instead of its frontier.

A project-wide reconciliation request drives every Task concurrently. A scan owns the whole Orchestrator Turn it activates, so sequential awaiting would make one Task's Provider call a prerequisite of the next Task's first scan, and one slow recovery would serialize the entire project behind it.

Startup installs the first heartbeat tick during Project open. Physical scans begin after initialization and each holds its own re-entered Project lease through completion. Discovery leaves its own read scope before acquiring scan owners, then commits a source cursor after admission rather than after the slowest Turn completes. Project open and later source pages therefore do not join a recovered Turn.

Re-entry provides an instance lease exactly for its callback's duration. Every scan completion stays inside that scan's callback; discovery awaits only its admission receipt. Instance lease admission can be cancelled while it waits for lifecycle transitions. Once admitted, cancellation still waits for the callback and settlement to finish before closing the lease. Background state owners bind that admission to their lifecycle so disposal cannot wait on an operation queued behind the same disposal.

Fault pacing uses a retry-not-before lower bound independently of ordinary readiness timers and their maximum wake interval. A reducer-proven future transition from the current or an earlier pass bounds that retry deadline: a later fault, no-progress result or exhausted fixpoint cannot postpone the earlier still-future obligation. The current pass's future transition remains eligible even if an older accumulated minimum has expired. Past-due readiness alone does not shorten backoff. Repeated hints keep the resulting deadline. A changed canonical Task input revision (latest epoch/ingress sequence and Task protocol sequence), or a changed Mission Message/closure identity, may retry immediately. The revision belongs to the facts observed by a scan pass, so new input arriving during an old failed pass receives a fresh pass. Failure to read the revision itself uses the same backoff, with an unknown revision unable to prove new input.

Lease renewal is a liveness and resource concern, never a safety one: every durable append re-asserts its activation against the lease fence, so a renewal that fails cannot admit a conflicting write. A transient renewal fault is retried while the current lease still leaves room for another attempt, instead of destroying a live Provider Turn and consuming an immutable semantic attempt.

Worker completion is delivered by the dispatching runtime's own in-process owner. A dispatch is accepted only after its deterministic child Session and exact Worker Turn descriptor are durable. Before that boundary, the immutable lineage is a write-ahead request owned by the generic `dispatch_admission` lease: a live owner renews it, and after owner death one successor takes the expired lease and resumes the same occurrence from persisted input. Task-control never synthesizes acceptance or abandonment from lineage alone. After the descriptor-backed accepted boundary, an owner that dies leaves no ready ingress, no lease, and no timer — a stall no ingress projection can express, because the missing fact is the worker's outcome. Every scan therefore reconciles only descriptor-backed lineages whose delivery owner is gone: a worker whose lifecycle is already terminal has its lost delivery replayed idempotently, and an accepted worker with no terminal lifecycle has its interruption recorded as an infrastructure outcome and admitted as an ordinary ingress.

Session terminalization can precede the adapter's domain settlement and post-turn
effects. A missing domain settlement therefore requires the same delivery-owner
liveness check before terminal-lifecycle recovery as before nonterminal abandonment.
A live local pipeline or live/unknown peer keeps its bounded recheck authority;
it cannot be replaced by a recovered partial while publishing its actual outcome.
An already durable settlement remains eligible for idempotent delivery replay even
while its original owner is live. Owner death still permits recovery of the exact
unsettled occurrence without rewriting any previously committed outcome.

An accepted infrastructure settlement also closes its exact input lifecycle.
The recovery reader validates its complete Worker Turn snapshot, original
dispatch/Session/Task/Project ancestry and durable user Message before publishing
the missing error terminal through the existing Session Bus/protocol owner.
It adds no final-message authority to interrupted narration. Existing physical
terminals retain their own outcome; a failed preparation's predecessor snapshot
cannot close another Turn. The original bounded descriptor pages discover these
gaps even after delivery, epoch advancement or Task completion. This reconciliation
publishes only the missing lifecycle fact and creates no new ingress or model
input. Discovery carries a descriptor integrity fault to that Task's strict scan
and backoff, so its Project's other source rows remain discoverable.

Descriptor-backed delivery admits ordinary ingress only for the current active
Task epoch. Its bounded recovery classifier reads the same immutable cancellation
request boundary as lifecycle admission, so an already cancelling epoch settles
its detached delivery without requesting another Orchestrator input. Exact worker
outcomes remain durable; cancellation convergence continues through its dedicated
Task-control source. A Session-only abort on an active Task still follows the
normal failure-delivery contract.

Typed execution cancellation retains its exact identity and provenance across
projected adapter error boundaries; ordinary execution failures retain adapter
context through their error cause.

Each continuation may supply a complete target-typed `turn.input` for its new physical Turn. Omission inherits the exact predecessor input; an explicit input replaces it without merging or expanding empty selections. The predecessor package/reference snapshot, logical dispatch occurrence, work scope and Session placement remain fixed. A different independent responsibility may reuse the same projected capability or reference node. Prior-dispatch, coordination-action, collection and Mission-repair continuations use the same admission path: validate the explicit input, derive current Delivery Slice subjects through the adapter registry, then persist the effective input and subjects in the new immutable lineage. The normal visible continuation Message includes those effective inputs, so workload tool authorization and worker context agree. Replay and restart consume the committed lineage; they never reselect Task-latest subjects or rewrite a prior Turn. A pending worker coordination request requires an explicit orchestrator response; pursuing another workstream does not answer it, and no Host semantic routing gate substitutes for that decision.

Initial and continuation dispatch preparation validate every explicit `attachment_refs` selection against that Task's canonical attachment URLs or SHA-256 references before claiming a new immutable lineage. The shared selector raises `PromptAttachmentReferenceError` for missing references; participant Message and Artifact identities are never reinterpreted as attachments. A corrected initial Tool call can therefore claim its actual dispatch occurrence with valid input. Exact settled replay retains its original receipt; already committed invalid historical inputs are not rewritten. Integrity fact projection uses the same strict selection primitive.

Task-input source completeness is Host-owned. Intent Analysis, Requirements and Architect adapter inputs contain the instruction reason, while their executors derive the complete canonical attachment URL set from the Task row. Build uses the same projection and stages the original bytes under its worktree `references/` directory. General delegated workers receive the current Task attachment inventory with their original request. Every worker continuation also receives the current inventory, so follow-up uploads remain discoverable after the initial Turn. These visible reference lists provide access, not proof of reading; the worker must read the source and preserve its requirements. Frontend-design semantic role bindings and Integrity's explicit evidence selection retain their typed contracts. Attachment identities remain separate from Artifact provenance and never become evidence-read receipts merely by being projected.

Worker continuation materialization combines current guidance and the canonical Task attachment inventory into one visible text Part before computing control-text authority. The exact-one-Part and exact-content checks apply to that complete canonical text, including follow-up attachments, rather than a pre-attachment string.

Infrastructure settlement snapshots the last accepted physical descriptor in the existing `worker_turn` outcome field. Its `current_dispatch_id` is the explicit continuation source; `recovery_authority` continues to identify the failed dispatch for immutable accounting. When preparation fails on an existing Session, Session existence alone does not imply that the attempted Turn was accepted: its outcome omits `session_id` and admission-owned preparation settlement consumes the lease. With no accepted descriptor, recovery uses the reserved failed-dispatch identity. Durable replay returns the original snapshot, while a later accepted Turn still makes older continuation sources stale. No host substitution, new recovery protocol or historical rewrite is involved.

Requirement coverage finalization measures complete requirement definitions and acceptance obligations, independently of downstream product acceptance. Known future implementation, browser, screenshot, version-locking and external-study obligations stay in the RequirementSet with their owners and observation methods. Their pending evidence alone is not a definition-coverage gap; genuine unresolved scope, source conflicts and operator decisions remain incomplete. Coverage completion never claims delivered or verified product behavior.

A preparation failure before worker acceptance is a final dispatch settlement.
Its settlement retains the lineage's reserved Session identity, while the
infrastructure outcome omits `session_id` because that attempt accepted no worker.
The exact admission owner writes this fact and releases its lease in one immediate
transaction. A stale owner cannot settle a peer's attempt, and a settled preparation
failure prevents later acceptance of a descriptor for that dispatch. An explicit
prior-dispatch continuation retains the original workflow occurrence, reserved
child identity and placement. When no worker descriptor exists yet, it performs
the first worker Turn with the original Task authority and the real Orchestrator's
recovery guidance; otherwise it uses the ordinary incremental continuation.

The same scan closes the opposite gap for accepted workers. A dispatch is settled before its outcome is handed to the Orchestrator, so a failure in between leaves a settled lineage — invisible to abandonment recovery, which looks for unsettled work — that woke nothing. Every ingress reduces to `resolved`, no timer is owed, and the Task rests permanently behind a database that looks healthy. A descriptor-backed settled lineage with no ingress carrying its outcome is therefore replayed, keyed to the settlement artifact so the replay collapses through the ingress source index. Pre-acceptance failures reach the Orchestrator through the original visible Tool receipt.

`dispatch_agents` completion is reduced at the collection boundary rather than
delivered once per member. The exact Task epoch, orchestrator Message, Tool
part/call and member count in every immutable lineage identify the collection.
An index with no lineage is terminal only when the exact outer Tool request's
append-only progress contains a typed failed checkpoint or a completed
infrastructure outcome whose authority says `occurrence_not_committed`. Once a
lineage exists, outer wrapper status cannot replace the occurrence: its immutable
settlement is required, and only an `occurrence_committed` infrastructure
settlement may terminalize the member before its Worker Turn descriptor. Every
other declared index requires matching lineage, descriptor and settlement. The representative
source is deterministic among admitted, settled workers: the lowest-index
infrastructure failure when one exists, otherwise the lowest-index terminal
lifecycle (or its settlement when recovery proves no lifecycle projection).
Any member callback or restart scan can admit that same source, but the
immediate admission transaction accepts it only once. An accepted ingress or
the representative's budget-suppressed disposition excludes all sibling
lineages from later recovery. Participant Messages, lifecycle events,
settlements and typed pre-lineage outer-member failures remain individually visible; only
redundant root scheduler Turns are removed. A direct `dispatch_agent` retains
its one-dispatch/one-wake contract.

**Owner liveness names a physical process, never a heartbeat deadline.** Each runtime occurrence registers its exact PID and OS start identity in one permanent `runtime_process` receipt. Every Project driver joins the same local reference owner; disposal releases its admission reference but preserves the physical receipt. Task activation and dispatch-lineage admission assert that exact registered identity in their writer transaction. Peer abandonment recovery reads the receipt and uses the shared OS process-instance observer outside a writer transaction; only `dead_or_reused` proves exit. Exact-live and uncertain owners remain protected and are rechecked at the normal Task-control heartbeat cadence. The recheck time is scheduling, not authority expiry. Missing or historical opaque process identity is an explicit unresolved evidence error, never a fabricated death or database reset. Completed outcomes can still be delivered independently of owner liveness. Local execution registries remain authoritative for this process's own lineages. Business execution leases retain their independent exact-occurrence contracts.

### Wake totality

Every non-terminal projection owes exactly one of two things, and the classification is exhaustive over the projection union by construction:

- **a finite wake instant**, which the scan returns for the driver to arm — `leased` at lease expiry, `waiting` at its resume deadline, `cancelling` at a fixed reconciliation period, and anything under an absolute deadline at that deadline;
- **a durable operator-visible surface**, for the states no timer and no fact append can leave. `waiting` without a deadline and `reconcile_required` are surfaced by the pending Interaction that gates them. `host_fault` and `exhausted` have no such row, so the first scan that observes one records a deterministic infrastructure fact naming the ingress, its state, and its reason.

A resting state with neither is indistinguishable from a deadlock, and that is precisely how these states used to present: an ingress exhausted after three decision-less Turns, or stopped on an integrity conflict, would stop silently while head-of-line blocking starved every operator message behind it. Both now release the line, so the surface is the abandoned ingress's only trace rather than a notice pinned to a stalled Task. Surfacing is an observability obligation, not a scheduling one — losing it must never convert a resting Task into a faulting one.

Reduction is total over persisted facts. An evidence reader that finds a violation of the persisted integrity contract raises a typed integrity error, which the fact store catches at its single boundary and the reduction turns into `host_fault/evidence_violation`. Untyped throws stay reserved for infrastructure faults, which the driver may retry. Without that separation an immutable violation escapes as a fault forever: the driver retries every sixty seconds, the designed value is never reached, and the Task is wedged with no surface. Everything an activation derives from immutable sources is computed before its lease is acquired, so a violation cannot consume one of the ingress's four activations on every heartbeat.

A Host fault is local to the ingress that observed it. It executes nothing — the reduction returns it before any decision set can be read as one — so the Task's FIFO continues to the next ingress, each of which reads its own evidence and therefore never runs under the violation. The Host's broken write costs exactly one abandoned ingress and one durable surfaced fact, not a Task that no ordinary user action can leave. It is deliberately the one settled state the scan does not memoize: the invariant it names can be repaired by a later append, and a process-local memo would blind that process to the repair until it restarted.

### Well-founded retry

Retry budgets are frozen per ingress, but an infrastructure failure mints a *new* ingress, and each arrives with a full budget. A worker failing the same way every time therefore had no bound at all, and each cycle cost a whole Orchestrator Turn. Automatic retry must be quantified over something the retry cannot create, so the infrastructure-failure budget is per **epoch** — which changes only at one of the two canonical reopen authorities above. Beyond it the failure is still recorded and surfaced; only the wake is suppressed. Recovery facts carry deterministic identities so a crash between settlement and acceptance replays to the same artifact and dedupes through the ingress source index, rather than minting a second wake with a second budget.

The budget binds every path back in, not just the original wake. A settlement recorded before its wake was suppressed is later observed by the settled-undelivered recovery sweep, and an infrastructure settlement re-entering there is routed through the same infrastructure-failure gate — never as a generic recovery wake, which would continue the exact loop the budget terminates at one wake per crash cycle under a different event name. A suppressed re-entry closes the dispatch: the budget's own surfaced gate is its durable trace, and the sweep stops re-checking it.

`cancelling` is a non-absorbing rest state that expects an owner to finish it. Where a converger is wired, the scan re-attempts convergence on each pass over the boundary; where none is — engine-only runtimes carry none — the periodic wake alone would poll silently forever, so the scan surfaces one deterministic unconverged-boundary gate per (Task, epoch, status) naming the exit. Settled ingress surfaces likewise name their exit, and neither holds the line: `host_fault` names the Host invariant to repair and `exhausted` names the spent budget; both are redone by the same ordinary act, a new operator message.

A boundary request that fails midway leaves the Task in `cancelling`, a status no fact append can leave. Convergence is therefore re-attempted by the scan on every pass over such a Task, with a finite wake until it settles; running it only at project bootstrap made a restart the sole escape. Ownership of that convergence is bounded in the same spirit: the durable lease guarantees some process eventually acquires, so waiting forever only hides a stuck owner.

The completion closure is committed before the terminal transaction runs, and that transaction can refuse — an unsettled dispatch is the common case. The closure is released on refusal. Otherwise the Task rejects every completion for the full lease while the model retries into that window, and the conflict and the retry feed each other.

Fresh-worker authority starts from the write-ahead lineage claimed before child
Session creation. The later user Message and Worker Turn descriptor transaction
therefore sees that exact lineage at descriptor insertion, as required by the
current-DDL foreign-authority trigger. Its synchronous post-insert callback
materializes the descriptor-backed workflow occurrence and consumes the
admission lease before the same transaction commits; it does not create a
second lineage.

The reduction accepts one assistant turn's decision set only when it is a sibling `dispatch_agent` fan-out or one single decision. `dispatch_agents` is one such single decision: its real persisted Tool request owns the complete member array, and each immutable lineage binds that request plus exact member index/count rather than a fabricated child Tool occurrence. The Provider schema exposes each array item as that one direct `{ dispatch: ... }` object; it does not intersect the same wrapper twice or publish an `allOf` duplicate that can be misread as another nesting level. Initial direct and collection-member lineages atomically insert that write-ahead request and acquire its fenced `dispatch_admission` owner before any child Session, worktree or Provider effect, using the deterministic child Session identity derived from the dispatch. Coordination continuations use the same admission before reopening their existing Session. A concurrent claimant waits for the exact descriptor or terminal settlement; after an expired owner it may take over the same occurrence, but a lineage by itself never returns `accepted`. The owner renews the lease while preparation runs; exact fence loss aborts the combined per-dispatch signal consumed by every physical adapter, and the stale executor cannot publish descriptor or workflow authority under the successor's lease. Descriptor persistence, workflow projection and lease consumption commit together. Lease consumption retains the latest `dispatch_admission` attempt row as the descriptor-backed lineage's delivery-owner transfer receipt; peer recovery checks that latest attempt's process owner even after its preparation lease is consumed, while the immutable runtime-process lineage owner remains the write-ahead owner fact before descriptor acceptance. No predecessor owner variant is accepted in the current database epoch. An initial claim reserves its exact Tool/member dispatch occurrence; optional workflow nodes have no uniqueness fence or readiness gate. Package authority, Session foreign keys and single-effect replay remain intact. Each collection member disposition is also appended to the outer Tool request's canonical progress facts before the aggregate completes; recovery merges all immutable member checkpoints and never reruns a settled member. Anything mixed is `host_fault/decision_ambiguous` — fail-closed for that ingress, never a guess at which decision was meant. Because a model can emit that combination in ordinary output, the turn coordinator refuses the second, different decision while it is still only a call. A refused call leaves no completed receipt, so the model may still commit a different decision; once a valid collection starts, typed member failures settle inside that collection and cannot release or erase the occurrence. The fault verdict survives as the backstop rather than the mechanism.

The one-assistant-per-continuation conflict refuses a second *turn*, not every sibling row. Session compaction parents its summary assistant — authored `compaction`, carrying no activation — under the newest user Message, which in an Orchestrator Session is the just-written control occurrence, so any Session that lives long enough to compact produces exactly this sibling mid-turn. Counting it inverted the guarantee: the fence refused the legitimate activation assistant while the unfenced summary stood. Compaction summaries are therefore exempt from the continuation conflict; every other authored sibling stays fatal. An integrity violation raised while a Turn is being prepared follows the same rule as one raised while it runs: the Task stays open — the ingress reduces to `host_fault`, the surfaced fact is its trace, and the line moves on — and is never terminally failed over a refused append, on the startup path or any other. A Host defect may not become a durable user Task state.

A request never joins a running scan. A scan may await a whole Orchestrator Turn whose Tools re-enter the control plane; joining would deadlock a caller against its own activation. A non-owner therefore leaves its revision and returns. A hint may still be lost or duplicated; the revision it leaves behind cannot be.

Every `continue` inside a scan is justified by a strictly decreasing well-founded measure — an abandoned assistant terminalized, a reconciliation Interaction created, an abandoned dispatch settled, an activation consumed against its immutable budget. A bounded step guard converts a measure that stops decreasing into the same exponential backoff a fault receives, never into minimum-delay pacing, so a Task that cannot reduce can never spin the reconciler. A fixpoint that will not settle within its pass bound is the same liveness fault and is paced the same way; pacing it at the minimum delay would run a full round of scans every few milliseconds forever. A scan fault is a physical fault, not a fact: it is isolated per Task, re-armed under exponential backoff, and cannot starve a sibling Task. Backoff decays only after a fault-free window as long as the maximum delay, so a Task alternating faults with apparent progress still escalates. Wakes accumulate by minimum across passes: a pass that reports no wake means it owes none, not that an earlier pass's obligation is cancelled.

Database startup follows the versioned migration contract in [Data architecture](02-data.md). Starting from the current version-1 baseline, declared structural and semantic revisions run with a pre-upgrade backup and one transaction before business access. Schema, foreign-key and data validation must pass before the version commits. Failure retains the original data and backup for recovery. Unversioned pre-baseline databases require explicitly authorized baseline maintenance; runtime readers only accept the current format.

## Overlay live-delivery ownership

The Overlay projects one selected conversation through a single explicit SSE lifecycle: `idle`, initial `connecting`, `connected`, or failure `reconnecting`. Task selection, Project selection, and server-directed live-cursor reset are initial connection work and cannot become an outage warning. Only an established stream that closes unexpectedly or stalls enters `reconnecting`; successful open is the only transition to `connected`, and explicit disposal returns to `idle`.

The selected child Session transcript keeps its backend route as the transcript authority, but streamed transcript revisions are invalidations rather than request identities. The Overlay performs the initial target load immediately, coalesces later revisions on a short cadence, permits one refresh in flight, and retains at most one trailing refresh. Target identity includes the exact source, Session, and Project directory, and changing it disposes all pending work for the old target.

Persisted child transcript hydration and live delivery are consecutive phases of that same transcript. The selected Task SSE is the live authority: the dock applies exact selected-Session full-Part snapshots, Part deltas, and removals over its persisted base in process, without polling or opening another stream. A full Part snapshot supersedes earlier deltas for that Part; later deltas append by exact field. The projection is disposed on target change. Its reactive growth feeds the shared conversation scroll owner, which suspends follow only after an operator input produces actual upward movement away from the bottom and restores follow when the viewport returns to the bottom.

The shared Session processor checkpoints its current text accumulator into the
canonical Part through the existing streamed-Part publication queue. That queue
uses a 200ms cadence, one publication in flight and one dirty trailing update;
it also publishes pending Tool input drafts. Existing text deltas remain live
transport for all consumers, including CLI and ACP. A late or reconnected reader
hydrates the retained prefix rather than an empty Part, while publication
backpressure can delay its next checkpoint. Natural text completion joins the
queue before the final Part write, and failed or cancelled streams retain their
last accepted partial text before assistant completion. Retry settles the queue
before retiring the attempt's Parts. No separate text store or per-token
database writer participates in this contract.

Child transcript reconciliation respects the same completion boundary: canonical
completed assistant Info and ordinary Parts supersede retained live drafts.
Existing Tool requests keep their independent outcome lifecycle, and persisted
terminal Tool outcomes supersede older live running states. Actual removals and
new post-completion compaction checkpoints retain their existing semantics. A live
sequence or request-start time does not acknowledge that every streamed character
has been checkpointed; active text retains its full live value.

## Verification authority

The following gates define the maintained control-plane proof:

- `bun run check:control-state-redundancy` inventories every scoped persisted field and rejects derived or unclassified columns plus known cross-table functional dependencies;
- focused reducer, current-schema/versioned-migration, Task continuation, lifecycle, Tool/Provider, Protocol delivery, Scheduler, Bus, Mission, process-occurrence/physical-lease, and terminal closure tests assert positive fact/projection contracts;
- storage schema-contract and schema-migration tests prove canonical SQLite Data Definition Language, versioned upgrades, retained facts, rollback and cross-process convergence; explicit reset remains a separate administrative contract;
- `bun run typecheck`, `bun run docs:check`, and `git diff --check` remain required;
- the real streaming Provider checker is run only when credential and exact model projection use is explicitly authorized.
