# 06 — LLM Provider 适配层

> 对应代码：`src/provider/` · `src/session/llm.ts` · `src/config/config.ts`
>
> 实际目录：`provider/llm.ts` · `provider.ts` · `transform.ts` · `vendor.ts` ·
> `vendor-headers.ts` · `vendor-messages.ts` · `auth.ts` · `bundled.ts` · `error.ts` ·
> `base-url.ts` · `models.ts` · `dashscope.ts` · `install.ts` ·
> `policy.ts` · `hexin-discovery.ts` · `hexin-profiles.ts`
>
> `vendor.ts` 已拆分为三块：核心 loader 在 `vendor.ts`、HTTP header 注入在 `vendor-headers.ts`、
> 消息修复在 `vendor-messages.ts`。`hexin-discovery.ts` / `hexin-profiles.ts` 是项目特化的内部供应商
> 发现机制（同心同德）。`policy.ts` 提供模型策略 / 限制校验。原 `codex-live.ts` 已删除；Codex 认证由 Provider Auth Plugin 承担。

MCP OAuth uses the extension credential owner, not Provider account OAuth. Its persisted tokens and client information retain their authorization-server issuer; pre-registered clients declare `mcp.oauth.issuer`. Legacy unbound MCP credentials require explicit re-authorization. See [04-extensions.md](04-extensions.md) for the single revision/snapshot-bound lifecycle.

## 核心挑战

Canonical model declarations are one recursively immutable parsed `ModelsDev.Data`
generation; catalog refresh and model replacement atomically publish the canonical
file and reset that generation. Readers retain their original generation across a
later publication. Runtime Provider projections have separate mutable data
ownership. `fromModelsDevProvider` eagerly creates a fresh environment list, model
headers, nested declarative options and interleaved-capability object for every
projection. Project plugins may customize that projection; the canonical ModelsDev
declaration, another Project and the global projection retain their own values.
The internal builder projects Provider metadata immediately and materializes that
Provider's owned `models` field on its first read from the retained immutable
generation. Assigning the field replaces its current value; JSON and structured
cloning still expose complete models. Frozen Provider records remain readable and
sealed writable records accept an authored model collection. No getter performs
I/O or consults a later catalog generation. Environment credential selection reads
projected model URLs only when DashScope classification can change the selected
key; the existing declared-key priority and ambiguous multi-key behavior remain.
The existing per-Project configuration/cache lifecycle remains authoritative;
projection isolation does not introduce another catalog or shared mutable template.

The Project builder derives plugin hooks from the same complete Config snapshot
as its Provider options and model references. Explicit candidate additions,
replacements and empty selections therefore use their own declared plugin input.
The shared Plugin loader may retain existing hook identity for the exact loaded
selection; it does not silently substitute the saved Project selection. Global
builders keep their existing project-independent built-in hooks. Candidate
projection does not activate plugin services or publish runtime plugin state.

`validationCatalog` constructs an operation-owned candidate through the same
builder, global options and catalog projection as runtime reads. It retains one
catalog for all reference lookups and leaves the runtime cache unchanged;
rejected candidates therefore cannot retain a stale failure for the next attempt.
`getModelFromCatalog` is the shared model-resolution implementation for this
snapshot and the existing asynchronous model readers. Config validation treats
the structured `plugin.catalog` stage as a candidate error; ordinary Provider
catalogs continue to report that issue beside readable healthy models.

不同 LLM 提供商在 4 个维度上各不相同：

| 维度         | 差异                                                                                          |
| ------------ | --------------------------------------------------------------------------------------------- |
| **API 协议** | OpenAI Chat/Responses · Anthropic Messages · Google GenerateContent · Bedrock InvokeModel     |
| **认证方式** | API Key (env) · OAuth · AWS IAM Role · GCP Service Account · 嵌入式密钥                       |
| **参数格式** | reasoning → `thinking` / `reasoningEffort` / `thinkingConfig` / `reasoningConfig`（四种写法） |
| **模型能力** | tool_call · vision · audio · reasoning · streaming · caching — 每个模型组合不同               |

## 主流方案对比

| 方案                           | 示例                   | 优缺点                                                               |
| ------------------------------ | ---------------------- | -------------------------------------------------------------------- |
| **A. 统一 SDK 适配**（本项目） | Vercel AI SDK          | ✓ 类型安全 · 灵活 · 官方维护 · 可定制 · ✗ provider-specific 逻辑分散 |
| **B. 代理网关**                | LiteLLM / OpenRouter   | ✓ 零代码 · 100+ provider · ✗ 额外跳转 · 参数丢失 · 第三方依赖        |
| **C. 抽象基类**                | LangChain / LlamaIndex | ✓ 清晰分层 · OOP · ✗ 抽象泄漏 · TypeScript 生态弱                    |

**本项目采用方案 A 深度定制**，围绕 OpenCorvus runtime 维护 provider 装载、认证与消息适配，当前注册 24 个 bundled provider package（见 `provider/bundled.ts`），六层适配。

## 六层适配架构

调用顺序 **Agent → Provider API**：

```
┌─ Layer 1 · Model Registry ──────────────────────────────────┐
│  canonical models.json + config.provider 覆盖              │
│  → 统一 Provider.Model 对象                                │
└─────────────────────────────────────────────────────────────┘
                           ↓
┌─ Layer 2 · SDK Router ─────────────────────────────────────┐
│  BUNDLED_PROVIDERS (24 package) + 动态 npm install         │
│  + canonical SHA-256 索引与 exact-source equality 缓存      │
└─────────────────────────────────────────────────────────────┘
                           ↓
┌─ Layer 3 · Auth ───────────────────────────────────────────┐
│  env API Key · OAuth Plugin · AWS IAM · GCP SA             │
│  · DashScope 动态密钥 · 配置覆盖                            │
└─────────────────────────────────────────────────────────────┘
                           ↓
┌─ Layer 4 · Custom Loader ──────────────────────────────────┐
│  OpenAI / Azure responses API · Bedrock 区域路由 ·         │
│  Vertex GCP Auth · Anthropic beta header · OpenCorvus 内置 │
│  free-tier 过滤 · DashScope 动态密钥                        │
└─────────────────────────────────────────────────────────────┘
                           ↓
┌─ Layer 5 · Parameter Transform ────────────────────────────┐
│  reasoning: thinking/reasoningEffort/thinkingConfig        │
│  caching: cacheControl/promptCacheKey/cachePoint           │
│  message 修复: Mistral tool ID · Anthropic 空内容过滤       │
│              · 缓存标记注入 · 不支持模态降级                │
└─────────────────────────────────────────────────────────────┘
                           ↓
┌─ Layer 6 · Error + Streaming ──────────────────────────────┐
│  Overflow 检测 (19 regex) · HTTP 错误提取                   │
│  流不活跃超时 (300s) · 可重试判定                           │
└─────────────────────────────────────────────────────────────┘
```

## Provider.Model — 统一模型抽象

### OpenAI continuation item identity

OpenAI Responses 的普通重放项只对既有六种类型（message、reasoning、function_call、
local_shell_call、custom_tool_call、web_search_call）归一化可选上游 ID；Azure 的
store=true 保留行为不变。compaction 的原始 ID 与 encrypted_content、item_reference
的必需 ID，以及其他协议项的身份字段必须原样传递，不能被“删除所有 input.id”的
通用处理破坏。模型配置和流式 SDK 仍通过同一个 Provider fetch 边界。

原生压缩的专用输出尚未进入产品 Session checkpoint 契约。实验 checker 可以通过
LLM.stream 请求 compaction_trigger，将真实返回的 native context 写入隔离产物并重读后
续行；该产物是对照实验记录，不是另一份产品 MEMORY.MD。正式产品集成仍需定义消息
持久化、可见性、复制、模型绑定与恢复边界，不能以 SDK 已支持或单次实验通过代替。

### Final route budget authority

每次真实流式请求只有一个 final resolved route/model record。它同时绑定 Provider ID、请求模型
ID、API 模型 ID、endpoint、catalog revision，以及该请求实际使用的 `context` / `input` /
`output` limits。Session 的预测预算不得继续读取 transform 之前的另一个 model projection。

- `context` 是 prompt 与 generated output 的组合窗口；
- `input` 是可选的独立 prompt 上限；
- `output` 是 Provider 声明的 generated-output 上限；
- `effective_output` 是当前 request transform 对 output 的进一步收窄。

context-derived prompt budget 为 `context - reserved_output`。同时存在独立 `input` 时使用
`min(input, context-derived)`，不能再从 `input` 重复扣除 output reservation。只有 `input` 时
直接使用 input；只有 `context` 时使用 context-derived。最终 prompt budget 还与显式运行配置
`compaction.max_context_tokens` 相交；该配置默认 **256000 tokens**，超过 256k 必须明确配置更大值。
Provider 的未知物理容量保持未知；配置窗口提供已知的运行预算，不冒充 Provider 上限。
估算器在同一单位中计算 system blocks、可见 messages、Tool schemas、附件/媒体
估算与 output reservation。禁止动态学习第二阈值或自动换模型。

例如，在现有 `opencorvus.jsonc` 配置中允许最多 512k 的 prompt context：

```json
{
  "compaction": {
    "max_context_tokens": 512000
  }
}
```

默认自动触发线仍为运行预算的 90%，因此 256k 窗口在估算达到 230400 tokens 时压缩。
预测、实际 usage 触发、普通/摘要流式请求的最终容量校验共享 `ContextBudget`；较小的模型容量或
output reservation 可以进一步收窄窗口。`auto=false` 只关闭自动压缩，最终请求仍受配置窗口限制。
新字段必须是正整数，并由同一配置 schema 生成 API（Application Programming Interface，应用程序接口）
与 SDK（Software Development Kit，软件开发工具包）契约；没有另一个模型目录或 UI 状态来源。

Provider 原始流错误只在 `Message.fromError(raw, { providerID })` 规范化一次。Tool cleanup 只消费
canonical Message error 的严格投影；它不得重新解析 Provider object。predictive 与 reactive
compaction 都由 SessionLoop 通过同一个 `ContextBudget` 驱动；Provider 在声明上限以下拒绝时，
canonical reactive overflow 仍负责可见压缩和同 Session continuation，但不能反推真实未知上限。
Assistant、受影响 Tool 与 `session.error` 共用一个
`session_id + assistant_message_id + error_name` occurrence。Tool terminal 写入即使在提交后的事件发布处
抛错，也必须从数据库读回后再报告真实未收敛 Part；写入/发布错误、物理未收敛 ID 与读回失败是
不同字段。Snapshot patch 等次生 observation 只能附着于该 occurrence，不能替换主 Provider 错误。
所有合法持久化 Session kind 走同一自动压缩路径，不存在按 kind 禁用的 policy gate。

`session/request-budget.ts` 是普通请求、压缩请求与最终流式请求的共同估算器；system、实际 Tool
schema、messages 与独立媒体估算采用同一口径。`session/llm.ts` 在 system/parameter hooks 后和每个
Provider step 发送前复核最终输入容量，使用该请求实际的 output cap。媒体数字是预算估算，
不冒充供应商的精确图像计费或从错误中学习第二容量阈值。`compaction.reserved` 是组合窗口的
最低 output reservation，不能低于实际请求 output；独立 input cap 不重复扣减 reservation。

只有正常 `stop`、有最终可见正文且替换后估算 token 少于被替换历史的摘要才可发布 checkpoint。
达到输出上限、异常终止或不缩小的结果保留为 typed failed assistant/control，上一有效 Session
memory 与原始历史继续权威。所有摘要识别、持久化与 memory 重建共享这一完成判定。
默认近期保留预算为配置窗口与模型容量相交后可用 prompt 的 25%（默认窗口对应 64000 tokens）；
明确配置的近期保留量也以触发线为上限。保留边界可以是
用户消息或已完成、Tool/result 完整配对的 assistant step，选择与重建共用同一判定。
大 Tool 输出在送入 summarizer 前使用现有精确结果引用与有界 preview，reader 可分页读取原文；
不是额外的不可见历史替换。历史附件保留可寻址 locator，摘要里的截图/焦点不授予当前桌面状态。

所有 agent 消费同一 Zod 类型：

```ts
{
  id: string                 // "qwen3.5-plus"
  providerID: string         // "alibaba-cn"
  api: { id, url, npm }      // API model ID · base URL · SDK package
  capabilities: {
    temperature, reasoning, toolcall, attachment,
    input:  { text, audio, image, video, pdf },
    output: { text, audio, image, video, pdf },
    interleaved: boolean | { field: "reasoning_content" | "reasoning_details" },
  }
  cost: { input, output, cache, available? } // $/M token + 请求时价格是否已知
  limit: { context, output }        // token 限制
  variants: Record                  // reasoning effort (low/medium/high)
  options: Record                   // provider 透传
  headers: Record                   // 自定义 HTTP 头
}
```

## 调用链路

```
Agent.run()                                     agent 发起 LLM 调用
  │
  └→ ProviderLLM.stream({ model, system, ... })  统一 LLM 入口 (provider/llm.ts)
       ├→ Provider.getLanguage(model)             Layer 1-4: 解析 + SDK + Auth + LanguageModel
       ├→ ProviderTransform.options(model)        Layer 5: 参数适配 (reasoning, caching, store)
       ├→ ProviderTransform.providerOptions()     Layer 5: SDK namespace 封装
       ├→ ProviderTransform.maxOutputTokens()     Layer 5: 输出 token 限制
       ├→ ProviderLLM.wrapModel() + message()     Layer 5: 消息格式修复 middleware
       └→ streamText({ wrappedModel, ... })       Vercel AI SDK 统一调用
  │
  └→ Error Normalization                          Layer 6: 错误分类 + 超时
```

**session/llm.ts** 复用 `ProviderLLM.wrapModel()` + `baseHeaders()`，叠加 session 特有逻辑
（plugin / trace / permission / inactivity）。

生产调用通过 `ProviderTransform.instructionOptions` 投影受信行为指令：普通请求使用 AI SDK 的
`instructions`，OpenAI OAuth（开放授权）使用既有 Provider 顶层指令合同。`messages` 承载原用户、
助手和工具对话数据。主会话、VCS 提交主题和 Metric Judge 都复用规范 Provider 默认值、模型配置及
SDK 命名空间映射，辅助调用不得使用空选项遗漏 `store` 等服务商约束。VCS 保留当前 Git 差异及近期
主题，Judge 保留冻结 criteria、rubric 与不可变证据。Provider 线协议中的 system 角色由标准化边界
生成，不能与调用方把指令混入对话数组等同。验收应实际经过该 SDK 边界并观察明确
流式输出，替换整个 `streamText` 返回值只能验证局部消费行为。

原生 OpenAI / Azure OpenAI 在复杂 Tool surface 上采用单步串行 function-call 策略。凡
`requiresSerializedOpenAIToolCalls(model)` 为真且当前请求携带 Tool，参数转换层必须在进入
`providerOptions()` 命名空间封装前设置 `parallelToolCalls: false`。这是 `tool-call-policy.ts` 拥有的
Provider 执行策略，不是 Structured Outputs 或 `tools[].strict` 声明；Provider-bound schema 继续作为
best-effort function definition，并由 canonical Zod schema 在执行前完成最终校验与默认值 materialization。
Zod 开放 record 的 provider projection 必须保留可接受非空 JSON map 的语义。当前 SDK 7 保留
`additionalProperties` 的真实值 schema；未知值采用空 schema `{}`，不再修补旧 SDK 的 `false` 投影。该策略只串行化
单个 Provider step 内的 Tool calls，不得串行化不同 Session、Task、Agent、Project 或 scheduler
delivery，也不得通过兼容输入、Host 重试或 prompt 顺序指令另建协议。`@ai-sdk/openai-compatible`
不暴露 parallel-call request option，不能伪装为已约束；其他 Provider 保留其显式配置的并行策略。

## Provider 物理容量

每个真实语言模型 SDK fetch 在进入网络传输前取得一个跨进程物理容量槽。槽的资源键只包含
Provider ID、credential generation 的非明文 SHA-256 身份和 `language-model` resource class；
表中不保存 key、URL、请求、Session、Task、重试或业务状态。全局
`execution_capacity.provider` 是唯一配置来源，Project 配置不能覆盖它。

容量槽是当前物理租约，不是第二套 scheduler。请求等待槽时尚未进入网络；响应 body 的正常 EOF、
读取错误、consumer cancel、调用方 abort、activity timeout 和无 body 响应都收敛到同一次 fenced
release。abort 可立即终止下游读取，但只有上游 reader 的 cancel 已完成或拒绝后才释放容量；无法证明
物理清理完成时继续持有并续租该槽。进程崩溃由有限 lease expiry 接管，同一 SQLite data root 上的并行 backend 因而共享同一
上限。Provider 的业务重试、幂等、usage 和 Message 终态仍由原有 occurrence owner 管理；退避期间
不持有物理槽，下一次真实 fetch 重新 admission。

真实 Provider checker 的响应观测绑定实际 `Response` 对象，且只使用上述现有 body reader。
`provider-response-observation.ts` 的瞬时 WeakMap 交接同一对象的诊断 owner；读取时仅记录实际
chunk 数、byte 数及首尾非空读取时间，物理清理完成后记录 `eof/error/cancelled/aborted`。
同一 reader 的实际 error 结算还记录固定的 `read/on_chunk/enqueue` 操作位置、标准错误类型和
允许的原生错误码。安全提取只读取自身数据属性，不读取任意 getter、错误文案、堆栈、嵌套 cause、
响应正文或 header。未知类型或码保持未知；这些标量不改变原异常、结算胜者、清理或重试策略。
时间表示应用 source reader 收到字节，不表示网络到达，也不能替代持久化语义进度。观测不 tee、
缓冲或解析响应体，不新增 reader、重试、超时或容量策略。无 body、HTTP 错误、fetch 失败和
未绑定响应保留各自明确状态；重构或替换 `Response` 后不猜测关联，未观测不等于零字节 EOF。
audit 的现有发布回调通过唯一保护边界执行，失败记录关联请求的 `callback_failed`，保留原响应、
原错误和预算错误；每 chunk 只更新内存标量。`LLM.stream` 从实际输入构造既有
`StreamRequestIdentity`，与真实 SessionID 一起显式传给请求拥有的 language/SDK/fetch 闭包。
Provider 在首次异步边界前冻结复制该上下文；携带上下文的实例不读写共享 model/SDK 缓存。
同一实例的延迟 step 与物理重试保留原因果 caller，多个实例互不改变身份。context-free 调用
保持原缓存合同，缺少身份的直接 helper 仍为 unknown。现有 exact Response 的安全 onBind
交付该上下文，audit 仅在未命中已知 credential redactor 时记录 observed 身份；否则为 redacted。
替换 Response 不推测关联。此身份不计 SDK 事件、不定义物理 attempt、不证明语义进度或恢复正确性，
也不改变 byte/semantic timeout、重试、容量和执行轮次。

## Token 与计费统计单一链路

所有 bundled 与动态安装的语言模型 Provider 都必须通过 `llm/api.ts` 的共享流式
`streamText` wrapper。该 wrapper 的 `onStepEnd` 是每次真实上游 step 的唯一用量
落账点；Session、Provider 连通性、提交信息生成、Metric Judge 和验收翻译不得各自维护
统计旁路。统计层不得新增 Provider 分支或本地 Tokenizer 估算。当前归一化读取 AI SDK 7 的
`inputTokenDetails.{noCacheTokens,cacheReadTokens,cacheWriteTokens}` 与
`outputTokenDetails.{textTokens,reasoningTokens}`，以 SDK 的输入/输出总量为权威。

当前运行时图为 AI SDK 7、Provider 4 和 provider-utils 5；官方 Provider 与公共 override
一起升级，由 `check-ai-runtime.ts` 检查实际安装图。共享入口消费 `stream`，使用
`instructions`、`onEnd` / `onStepEnd`、`telemetry` 和 `repairToolCall` 当前契约。
ProviderLLM 中间件使用 V4。SDK 官方原生接收 V3 模型，因此现有 Copilot/Venice
适配器仍通过这一入口，不新增 host 兼容实现或第二套依赖图。

Venice 的当前 bundled 2.0.2 适配器通过根 `patchedDependencies` 的单一可读补丁交付，
ESM（ECMAScript Modules，模块导入）与 CJS（CommonJS，模块导入）入口保持相同合同。
聊天流默认发送 `stream_options.include_usage:true`，显式 constructor false 保留，
per-call `streamOptions.includeUsage` 优先于 constructor，并映射到协议 snake 字段。
适配器把 prompt 作为输入总量，cache-read/cache-creation 从 no-cache 输入中扣除；
reasoning 从 completion 文本中拆出，并由响应 schema 保留。SDK 只相加一次输入/输出总量。
修复位于唯一适配器，不在 Session、Provider factory 或统计层按厂商改数；历史账本缺少
原始详细 usage，继续保留已记录事实，不推测重算。

`outputTokens` 是包含 reasoning 的输出总量。持久化的 `tokens.output` 只保存 text
output，`tokens.reasoning` 单独保存 reasoning，因此成本与总量都只能各计一次。
输入总量同理以 Provider total 为权威；当特定 Provider family 不返回 total 时才由
no-cache、cache-read、cache-write 三个归一化分量组成。非法、非有限或负计数统一
归零，禁止让一个 Provider 的异常 usage 污染全局账本。

模型价格仍来自请求时的 canonical model metadata 或显式 Provider config。
`cost.available` 是必填布尔值，区分真实零价格与缺少价格；catalog、config 和动态
Plugin projection 都必须在模型进入 registry 时归一化它。超过 200K 的费率选择包含
no-cache、cache-read 和 cache-write 全部输入分量，config merge 必须保留 catalog 的
long-context rate。每次调用把 `priced` / `unpriced` 和请求时计算的 USD cost 写入
`provider_usage_event`。统计不得按当前 catalog 重算历史成本。

`provider_usage_event` 是当前本地请求账本的唯一事实源，保存 event time、Provider、model、
purpose、Token 分量、total、成本和价格覆盖。共享 stream wrapper 对每个完成的 upstream step
写一行，所以 multi-step Session 与非 Session helper 都按真实 API 调用计数。注册迁移
`2026-08-11-provider-usage-ledger` 创建该表，并把历史 assistant `step-finish` Part 精确回填；
旧 Part 没有覆盖字段时写成 `unknown`。Session 继续保留 Part/assistant aggregate 只服务于
对话投影，统计不再双读它们。

Evolution Lab 的 Trial 用量同样只读这张账本：`TaskRunEvidenceHost.usage` 按 Task 的 durable
Session 树求和已记录 token，所有已记录 step 均为 `priced` 时才给出 USD 估计（否则为 null，
表示未知而非免费），并返回实际服务过这些 step 的 `provider/model` 集合。未完成的 upstream
step 不入账，所以它是已记录用量而不是账单；Session 树之外的 preflight 与协调 Mission 不计入 Trial。

`GET /global/usage` 是 Overlay 的唯一自然周期聚合 API：按严格 IANA 时区计算
day/week/month/year 半开区间和上一周期，补齐真实 DST（Daylight Saving Time，夏令时）
hourly/daily buckets，并返回总量、比较、Provider/model 分组和计费覆盖。所有自然周期边界
统一取该当地起点的最早合法实际时刻；不存在的午夜取当天实际起点，相邻周期重新归一化。
小时桶从自然起点按真实经过的一小时推进，日桶按相邻自然日起点推进，末桶截到周期终点。
记录按实际 event time 归入同一组半开桶区间，分桶的 Token、成本与调用次数保持完整汇总。
自然周从周一开始；year heatmap 使用真实 weekday offset。

同一路由还返回独立的 official-source inventory：

- `OPENAI_ADMIN_KEY` 只调用 OpenAI Organization Usage + Costs；
- `ANTHROPIC_ADMIN_KEY` 只调用 Anthropic Messages Usage Report + Cost Report；
- `OPENROUTER_MANAGEMENT_KEY` 分别调用 OpenRouter Credits 与 Keys List；Keys 以官方每页 100 条、
  `offset` 递增的契约分页并显式设置 `include_disabled=true`，保留默认工作区中每个活动或已禁用
  Key 的 lifetime/daily/weekly/monthly usage、BYOK usage、limit、remaining 和 reset，不把不同重置
  周期的额度相加；未配置 `workspace_id` 的接口事实不得声明为跨工作区完整账户账本；
- AWS Bedrock、Azure OpenAI、Google Vertex AI 声明其 CloudWatch/Azure Monitor/Cloud Monitoring
  与官方账单控制面所需的 account/project/subscription scope，在这些身份尚未配置时保持
  `requires_configuration`，不得复用普通 inference key 或猜测 URL；
- 一个官方子接口失败时保留另一个已验证子接口的事实并返回 `partial`，分页缺 cursor、未知币种、
  非法 schema 或超过有界页数都显式失败；
- Provider 日桶对非 UTC 自然周期返回明确的 `utc_day_envelope`。只有官方窗口与本地窗口完全一致
  才返回 reconciliation；组织用量可能含其他客户端且与本地调用重叠，规则永远是
  `compare_never_sum`。本地 request-time cost 是估算，官方 Costs/Cost Report 是财务权威。

API 始终返回完整 inventory 以保留配置与诊断事实；Overlay 不渲染状态为 `unconfigured` 的
admin-key source，只有管理凭据存在后才显示其 connected/partial/error 事实。云控制面不是普通
API key，仍显示 `requires_configuration` 以说明账户、项目或订阅级统计边界。

## Runtime identity -> Model 映射

固定身份、worker 模板和精确动态 worker 分层配置：

```jsonc
// opencorvus.jsonc
{
  "agent": {
    "orchestrator": { "model": "anthropic/claude-sonnet-4-..." }, // 协调者，最强
    "coding": { "model": "openai/gpt-5" }, // Primary Assistant
  },
  "runtime_templates": {
    "requirements": { "model": "anthropic/claude-sonnet-4-..." },
    "build": { "model": "anthropic/claude-sonnet-4-..." },
  },
  "expert_squads": {
    "review-team": {
      "agents": {
        "security-reviewer": {
          "runtime": { "model": "openai/gpt-5" },
        },
      },
    },
  },
  "model": "anthropic/claude-sonnet-4-...", // 全局默认
}
```

**格式**：`{providerID}/{modelID}` → 运行时通过 `Provider.getModel()` 解析为 `Provider.Model`。

精确 worker 覆盖 runtime template，runtime template 覆盖全局默认。`base_role` 只选择模板，不是 agent identity。
所有 Task worker 都使用这条统一流式 Provider 链路；人类显式启动的 coding CLI 不构成 Task worker。
Project `MEMORY.MD` Organizer 是固定身份中的显式例外：配置 schema 不提供 `agent.memory.model`。它只读取待整理 FIFO 队首证据所属 Task/Session 的有效顶层 `model`，请求入口不携带或覆盖模型所有权。

## 核心文件

| 文件                                                | 职责                                                                               |
| --------------------------------------------------- | ---------------------------------------------------------------------------------- |
| `llm/api.ts`                                        | 所有生产 `streamText` 的共享 wrapper、per-step 用量唯一落账点                       |
| `provider/llm.ts`                                   | `wrapModel` / `baseHeaders` 与 request-time model metadata                         |
| `provider/provider.ts`                              | Model Registry + SDK Router + 状态管理                                             |
| `provider/transform.ts`                             | Parameter Transform + Message 标准化                                               |
| `provider/vendor.ts`                                | Custom Loaders — per-provider 特殊逻辑                                             |
| `provider/vendor-headers.ts`                        | per-provider HTTP header 注入（拆自 vendor.ts）                                    |
| `provider/vendor-messages.ts`                       | per-provider 消息修复（拆自 vendor.ts）                                            |
| `provider/policy.ts`                                | 模型策略 / 输入限制校验                                                            |
| `provider/hexin-discovery.ts` · `hexin-profiles.ts` | 内部供应商发现 / profile 管理（项目特化）                                          |
| `provider/hexin-endpoint.ts`                        | Hexin 私网连接地址、原始 HTTPS hostname/TLS SNI 与共享请求 transport               |
| `provider/auth.ts`                                  | Auth 管理 — API Key / OAuth / IAM                                                  |
| `provider/error.ts`                                 | Error Normalization + Overflow 检测                                                |
| `provider/bundled.ts`                               | 24 个打包 Provider package 映射                                                     |
| `session/index.ts`                                  | AI SDK usage 归一化、一次计费与覆盖状态                                             |
| `usage/usage.sql.ts`                                | `provider_usage_event` 本地请求账本 schema                                          |
| `usage/index.ts`                                    | 严格 IANA 自然周期、本地账本聚合与唯一 HTTP response contract                       |
| `usage/official.ts`                                 | 官方组织用量/成本/额度 source inventory、分页、部分成功与对账                       |
| `provider/base-url.ts`                              | 自定义 base URL 解析                                                               |
| `provider/models.ts`                                | canonical model catalog 的读取、校验与显式刷新                                     |
| `provider/dashscope.ts`                             | 特殊 provider 实现（动态密钥）                                                     |
| `session/llm.ts`                                    | Session LLM — 复用 ProviderLLM helpers + plugin/trace/permission                   |
| `config/config.ts`                                  | Agent model 配置 + Provider 配置                                                   |

## 刷新语义

- 启动和普通模型解析只读取 `OPENCORVUS_MODELS_PATH` 指向的 JSON；未配置时读取 durable data 目录下的 canonical `models.json`，该文件不属于版本化 cache 清理范围。默认 durable catalog 从旧版（曾主动移除 OpenCorvus declaration）升级时，由 catalog owner 在同一文件锁内一次性原子补入 bundled OpenCorvus declaration；显式 `OPENCORVUS_MODELS_PATH` 是用户完整 authority，缺少 required local provider 时仍严格失败，不自动迁移。
- fresh install 缺少默认 canonical 文件时，runtime 从编译进 executable 的唯一 bootstrap asset 离线校验并原子创建该文件；这是安装 provisioning，不是 lookup fallback。已有默认文件永不被 bootstrap 覆盖，普通启动不隐式访问 models.dev 或 Hexin `/v1/models`。
- 显式 override、已有默认 catalog 的 JSON 无效、schema 无效或缺少必需本地 provider 时立即报错；不存在 snapshot read、空 catalog 或其他来源的回退链。
- Provider 目录与已配置 Provider 的实时模型身份是两个独立显式刷新入口：`Provider.refreshCatalog()` 只由设置面板 `/provider/refresh` 和 CLI `models --refresh` 刷新 registry declaration；`Provider.refreshModels()` 只由 `/provider/models/refresh` 刷新 live model identities。两者都写入同一个 canonical catalog，但不得彼此调用。任一 writer 提交后由同一个 canonical invalidation owner 清除 global、全部 project Provider projection 与全部 native-agent registry projection；发起刷新的 project scope 不得限制共享 catalog revision 的可见范围。
- `ModelsDev.refresh()` 合并远端 registry 与必需本地 provider（OpenCorvus / Kilo），校验后原子替换同一个 catalog 文件。
- 当当前配置可解析出 OpenCorvus API key 时，`Provider.refreshModels()` 使用 `config.provider.opencorvus.api`（未覆盖时为 canonical OpenCorvus declaration 的 top-level `api`）作为唯一 discovery endpoint；`/models` 是 identity authority，`/model/info` 提供完整严格 metadata。已知 identity 缺少新 metadata 时可保留同一 canonical declaration 中已有 metadata；新 identity 缺少完整 metadata 必须失败，禁止伪造 capability、release date 或 token limits。全部 response 校验完成后一次原子写回统一 `models.json`，再由 route owner reset provider/agent 缓存。畸形 response、空 identity 集或冲突 duplicate 严格失败且不改写旧 catalog。
- ProviderState 保留同一份已解析且通过 enabled/disabled、loader 与失败排除的 Provider 事实，零模型或模型全部过滤不会删除发现所需的配置与凭据。普通 list/catalog/getProvider、模型选择、suggestions 和语言模型准入从该事实派生仅包含真实可用模型的集合；显式 generic/live discovery 读取同一事实，不新增影子状态或伪模型。
- `Provider.Info.apiKeyConfigured` 是可选 boolean，表示已经观察到非空 API Key 配置存在，独立于模型可推理、SDK 最终选中认证与联网有效性。唯一 builder 使用原 config、已读 API Auth 与原环境解析的正向事实；OAuth dummy/access 或 SDK 自管来源不能当作 API Key。已确认存在为 true，完整观察且没有为 false，读取或来源不明确时字段缺席。后期 loader 失败保留此前已解析环境的正向存在事实及原 issue，但不恢复失败 Provider 的推理资格。Config 观察是否成功与 config 快照共同进入现有缓存身份，失败空配置不能复用成功空配置。两个目录路由传递自己的观察结果；Overlay 行内/编辑与状态共用这个字段，当前 catalog 请求失败时旧目录可保留，但凭据事实为未知，不再用 raw key、config 或保存成功影子状态猜测。
- generic saved-key discovery 使用当前 scope 的唯一 top-level `config.provider[id].api ?? canonical declaration.api`，以及原有真实 model.api.url 集合作为地址归属。配置覆盖的旧 catalog top-level 地址不同时获得许可；明确 config.api 时不额外读取独立 catalog，保留 catalog issue 与完整配置可用的部分成功边界。显式 key 与 saved API Auth 的原输入合同、未知地址 HTTP400、损坏 Auth 的 typed503 保持。
- live model refresh 使用该 top-level Provider endpoint、与 SDK 同源的字符串 `options.apiKey` 优先于 provider.key 的选择（包括显式空字符串），以及 `network.proxy.llmProvider` transport 配置；不得从 per-model inference endpoint 反推 discovery endpoint，也不得另建 refresh-only credential 或 transport authority。
- 打开 Providers 配置页时只按当前 project/global scope 读取稳定的 Provider catalog、Auth method 和 config owner；不得隐式执行网络刷新。Provider 目录刷新和实时模型刷新只由两个显式按钮分别触发，各自完成后重读 Provider owner，各自拥有独立错误面。
- 没有活动项目目录的桌面首次启动使用 `/global/providers`、`/global/providers/refresh`、`/global/providers/models/refresh`、`/global/providers/discover-models` 和 `/global/providers/:providerID/test`；这些路由把 `Config.getGlobal()` 显式传入与项目路由共用的 Provider 实现。`/auth/:providerID` 仍是唯一 API credential 写入面，项目目录不是新增 Provider、保存 API key、发现模型、测试连接或使用内置 Provider OAuth 的前置条件。`Plugin.listGlobalProviderHooks()` 是唯一 project-independent built-in hook catalog，同时投影 auth method、OAuth loader 和 Provider model projection；installed project plugins 仍只由真实 Project `Instance` 的 `Plugin.list()` 拥有。

OpenAI Codex OAuth 的目录投影由同一个内置插件拥有。模型家族版本按整数 major 与可选整数 minor 比较，支持 `gpt-6-luna` 这类整数主版本，也正确排序多位 minor；不得用浮点数比较版本或为新型号逐一添加例外。现有接纳边界和历史例外保持，目录身份、能力与限制仍来自原声明。全局、项目和 helper 使用同一投影；目录可见性不等于远端账户已获准调用，实际请求结果单独记录。

### Provider 连接测试回执

项目 `/provider/:providerID/test` 与全局 `/global/providers/:providerID/test` 共用 `testProviderConnection` 和唯一 `ProviderConnectionTestResult`。`modelID` 可省略，默认选择从当前配置的有效模型目录按原排序派生；空声明不阻止测试。当前配置不可用与零有效模型分别返回 HTTP400 `provider_unavailable`、`no_models`，不从这两个条件推断凭据缺失。原 validator BadRequest400 与 AuthReadError503 保持其明确合同；识别出的嵌套 AuthReadError 使用原 cause，而不是 SDK 初始化包装。

流式请求保持原模型解析、认证、错误脱敏与30秒取消边界。回执包含实际 providerID/modelID、status/code/message 及单个流收到的 `output` 文本；错误前的部分文本也保留。`connected` 只证明本次选中模型的实际请求，不代表整个服务商或其他模型永久有效。测试不创建 Session/Task/Mission，不新增持久测试状态或第二模型/凭据事实来源。

### Provider 声明与可运行模型

`config.provider[id].models` 是可选配置覆盖，明确空对象也是合法声明。保存声明、名称、地址或环境变量不以 textarea 至少有一个 ID 为前提；模型可稍后添加或发现。Provider state 仍从 canonical catalog、配置和 Auth 派生，模型执行保持现有 loader、过滤与模型引用校验。零声明数量不能用作可运行模型数量。

空到空的编辑保留 models 缺席或明确 `{}`，保存时重读当前配置并只应用用户字段意图。清空旧表单中的 ID 只删除原覆盖，保留保存前已新增的模型与其元数据；项目覆盖删除可以恢复全局同 ID，配置覆盖删除可以恢复 catalog 同 ID。此操作不表达屏蔽继承模型。清空仍被引用的唯一自定义模型继续返回 ProviderModelNotFoundError；Auth 存在事实保持独立。

### Provider Auth occurrence authority

`ProviderAuth` 是 plugin 认证 method 执行的唯一 owner；`ProviderCredentialExchange` 是所有远端 Provider
credential exchange 与 credential commit 的唯一 owner。HTTP project/global route、Overlay 和
`opencorvus auth login` 都只通过它的 `execute`、`authorize`、`callback` 和 `cancel` 进入；`execute` 只接受 API
credential method，OAuth 只能通过 `authorize` 开始。CLI 只负责 method/prompt
呈现和输入收集，不得直接调用 plugin `authorize` / OAuth callback closure，也不得解释 callback result 后自行
写 `Auth`。CLI 在当前 Project `Instance` 中使用 project scope，因而保留 installed project plugin catalog；它
不能改用只包含 built-in hooks 的 global scope。

每次 OAuth authorize 先从 method-level `credentialProvider` 得到静态 credential target，为其建立/读取持久化
Auth generation，并由 `ProviderOAuthFlowStore` 在任何 loopback server、browser open 或 device-code request 之前持久化
exact flow occurrence。pending executor 自身持有 Provider-wide renewable owner；同 source 或 target 的另一授权/refresh
在其存活期间得到 typed 409，不能替换 executor 或让其资源失去结算路径。plugin executor 创建成功后才以 `flowID`
绑定；callback 必须携带该 exact `flowID` 和 owner，不存在按 provider/scope 查找 current flow 的后备路径。
同一进程再次 authorize 遇到 durable conflict 时，仅在 provider/credential target、scope、method、inputs digest、
Auth generation 和有效 owner 全部一致时返回同一个 executor/flowID。pending code/auto 可以继续；已经开始的 auto
callback 由 executor 持有单一 completion Promise，重入观察同一次 exchange。code exchange、外部进程 owner 和
终态不能重放。`cancel` 携带 exact flowID/method/scope，只能通过 failPending 原子结算 pending；exchange 先赢得
claim 时仍返回 typed 409。已终态取消可幂等回收 executor。CLI/Overlay 取消 code prompt 时必须调用 cancel；
Overlay 打开外部页面失败时也须回收 pending，不能静默遗留续租。
Overlay 每个交互式认证动作捕获一次 ApiAuthority，贯穿 method 选择、prompt、execute、authorize、callback 与 cancel；
打开下一 dialog 或消费 dialog 回答前复核原 token，不能在 await 后借用新连接发送旧输入。
上述 Overlay cancel 义务只在原 ApiAuthority 仍有效时通过原 flowID/method/scope 执行。原连接退休后，
客户端返回本地 ApiAuthorityChangedError，不通过新连接或旧凭据快照重放 cancel，也不能宣称原服务已经物理取消。
失联 pending 继续由既有 durable owner、Project disposal 与下述五分钟绝对期限结算；此客户端修复没有实际验证其终态或期限。
原请求 accepted、committed_with_residue、transport failure 等真实结果仍保留原 private outcome；退休只停止旧界面反馈，
不能把已接受事实改称失败或自动重试到新连接。exchange/credential_ready 保持其原有独立终态协议。
`pending` authorization 的有效 lease 为进程 lease 与 `timeCreated + PENDING_AUTHORIZATION_TIMEOUT_MS` 的较早者；
总期限为五分钟，续租只能维持存活证明，不能延长该期限。所有 admission、claim、renewal 和 recovery 使用同一
`ownerLeaseExpiresAt` 定义。后台 renewal observer 或后续 admission/callback 将到期 occurrence 结算为 `failed`，
同 scope 新授权先回收已到期 executor；迟到的 preparation result 必须重新验证 owner 并在失效时释放。
此期限只约束 pending 阶段；已 claim 的 exchange/credential_ready 和 runtime refresh 保持各自的可续租事务契约。
method/scope mismatch、settled、generation replacement 和 executor 丢失均使用 typed refusal。
Project `Instance` 释放时，Provider auth state 先停止 owner renewal，再把仍属该 exact owner 的 pending occurrence 结算为
`failed` 并释放 plugin executor；loopback listener 等 process-local 资源由 OAuth result 的 `dispose` 生命周期统一回收。
同一 executor 的并发清理共享一条 disposal Promise，失败后才允许后续重试；清理旧 settled executor 在新 durable
occurrence 和新 plugin side effect 之前完成。pending owner 过期后的结算与资源回收会在瞬态文件锁或 disposer 故障后重试。
新授权前的清理只处理终态 executor；`pending`、`exchanging` 和 `credential_ready` 仍由当前 owner 持有。
新请求必须先由同一 durable admission 返回 live-owner conflict，不能在被拒绝前释放旧 callback 的 listener 或其他资源。
code method 缺少 code 时返回 typed refusal 且不 claim/settle flow，因此调用者可携带 code 完成同一 occurrence。

内置 OpenAI、GitHub Copilot 和 xAI device callback 由 `ManagedOAuthDeviceAuthorization` 持有五分钟上限；有效的
provider expiry 可缩短期限。poll、token exchange 的 fetch/body read 和等待共享同一 AbortSignal，期限到达或
executor disposal 会中止操作，callback rejection 进入现有 exchange failure 结算。成功 callback 释放 timer。
Overlay authorize/callback 请求仍使用现有有限请求超时；观察端超时不等于服务端 flow 已结算。
浏览器 callback lease 的同一期限覆盖回调数据到达后的网络操作，直到 consumer 在 finally 中调用 `complete()`。
timeout、supersession 和 disposal 以原错误中止同一 AbortSignal。OpenAI、xAI、Snowflake 的浏览器 token exchange
使用 claimed owner 的 signal；GitLab 保持在 ProviderAuth claim 后交换 token，使用 callback lease 的 signal。
DigitalOcean 路由发现同时受 lease signal 与原有十秒请求期限约束。callback 返回 credential 前检查 signal。
上述三个内置 device 方法的初始授权码请求使用同一五分钟策略的 AbortSignal.timeout，覆盖 fetch 和响应体读取；
准备失败进入现有 pending failure 结算。该请求期限与返回 executor 后的 callback 期限分别计时，durable pending 总期限仍然适用。
插件网络取消契约仍不覆盖任意 preparation 的主动取消、其他 preparation、runtime refresh 或任意外部插件。

callback 在调用 token endpoint 前核对 authorize 时绑定的 `expectedCredentialGeneration`。远端调用前 occurrence 从
`pending` 进入 `exchanging`，返回 credential 后先写 `credential_ready`、credential digest 和预铸的 output generation，
再以 compare-and-swap 提交 `auth.json`，只有该 generation 的 credential commit 成功后才能进入 `consumed`。
普通 API/CLI writer、remove 后的 tombstone 以及值相同但 generation 不同的 ABA 都会赢过陈旧 exchange。
owner 过期时，已落盘 credential 的 generation 与 digest 同时相符才收敛为 `consumed`；否则进入
`exchange_uncertain`。Project、global 和 runtime refresh 共用 Provider ID fence，因为 `auth.json` 是 data-root-global。
credential alias 是 OAuth method 的静态声明，因此 source 与 target 在任何 plugin side effect 前共同参与 admission。
Flow store 是 admission/phase/terminal fact；PKCE callback closure 仍是 process-local live capability，restart 后不可伪造恢复。
pending/exchange renewal 遇到 thrown file-lock 或 I/O observation 时继续重试，只有 store 返回 exact owner 已不存在才视为
owner loss。journal 的 `error` 只写阶段化固定诊断，不持久化 plugin、token endpoint 或任意 exception message；这些文本可能
含 `refresh_token`、`access_token`、client secret 或响应 body，不能依赖通用日志 redactor 后落盘。

运行期 OAuth refresh 通过 `PluginInput.credentials.refresh` 进入同一 exchange owner；OpenAI account usage 也复用该
primitive。plugin 不获得完整 SDK client，只获得受管 credential 能力和 Provider header 装饰所需的窄只读 Session facts，
不能通过公开 transport 或反射在 token endpoint 返回后自行写 credential。
并发 refresh 等待 live owner 并返回其已提交 credential；过期且无法由 digest 证明已提交的 refresh 拒绝自动 replay，
refresh closure 的网络/协议异常同样视为远端结果不确定；该 fence 在其 expected Auth generation 仍是当前代时不按
24 小时 terminal retention 淘汰，只有显式 credential generation 前进后才能回收。非网络 API credential metadata 只允许
`PluginInput.credentials.updateApiMetadata` 对 observed API key 做 compare-and-update，不能发布 OAuth token 或恢复陈旧 key。

`authorize` 是 total OAuth-only contract：未知 Provider、未知 method index 和 API method 误入分别返回具名的
`ProviderAuthProviderNotFound`、`ProviderAuthMethodNotFound` 和
`ProviderAuthMethodAuthorizationTypeMismatch`，成功则总是返回非空 `ProviderAuthAuthorization`，不存在 undefined
成功响应。普通 `ProviderAuth*` 具名拒绝在 HTTP 边界映射为 400；live exchange owner 冲突明确映射为 409，
而不是泄漏为通用 500。authorize 在创建 occurrence 前读取 generation，因此 malformed、schema-invalid 或不可读取的
saved Auth authority 与 callback 一样投影 typed `AuthReadError` 503；Project/global OpenAPI 都必须声明该响应。

## Provider 故障隔离

- Provider/config 管理与修复路由只需要 project identity，不得先运行完整 `InstanceBootstrap`。失效模型或其他 runtime bootstrap 输入不能阻塞读取 catalog/Auth/config、保存 key、刷新模型或修复 config；Task/runtime 路由仍严格执行完整 bootstrap。
- Provider state 是同一个 canonical catalog/config/Auth 的部分成功投影，并携带结构化 issues。catalog 读取、插件 catalog、单个 Provider model projection、Auth store、plugin auth loader 和 custom loader 各自拥有错误边界；单个 Provider 阶段失败只移除该 connected projection，不得清空其他 Provider 或吞掉错误。
- Auth 持久化读取以 typed `Auth.ReadError` 区分合法缺失与 `io`、`malformed_json`、`invalid_credential`。只有缺失的 `auth.json` 表示空 authority；已经存在但不可观察或损坏的 authority 必须让 project-effective Config fail closed，不能把 declared well-known organization layer静默替换为合法本地配置。直接 Config/Auth consumers收到严格的安全 503，不公开凭据路径、credential key、原始 API URL、parser input 或 token。Provider catalog 的现有结构化 `issues` 是唯一允许的部分成功投影：它只报告一次共享 `auth.read` 根因，插件阶段因同一 typed cause 失败时不得重复放大。Global Config 本身不枚举 Auth，仍可独立读取；需要 saved Auth 的 global Provider 操作遵守同一 typed failure。
- 显式刷新 durable writer 的成功与后续 cache invalidation 分开报告。cache invalidation 的问题必须作为 issue 返回，不能把已经成功的 catalog/model 写入改写成不相关的顶层 HTTP 400。
- Auth 写入/删除的 durable commit 与后续 Provider/Agent cache invalidation 分开报告；cache issue 不能把已成功保存或删除的 key 改写成失败。
- Overlay 的 catalog、Auth method 和 global config 请求独立 settle、独立校验、独立提交；失败 owner 保留旧值并显示 resource-tagged 错误，成功 sibling 必须立即可用。禁止 `Promise.all` 让单个请求拒绝阻止全部 Provider 数据落库。

`models.dev` 的模型级 `experimental` 是可选对象，不是布尔开关。当前唯一合法结构是
`{ modes: Record<string, { cost?: { input, output, cache_read?, cache_write?, reasoning?, input_audio?, output_audio? }, provider: { body, headers? } }> }`。
基础、长上下文和实验模式成本复用同一组数值字段，保留音频与推理价格；实验模式仍严格拒绝未知字段及错误类型。
普通读取与显式刷新复用同一个严格 Zod schema；历史布尔结构、未知字段或不完整 mode 都直接失败，刷新失败时不得改写现有 catalog。

## 设置页数据所有权

Provider 设置页直接展示无需凭据的“刷新模型目录”，通过原 catalog writer 更新全部 Provider 和模型声明。
更多菜单中的 OpenCorvus 专用实时刷新复用 canonical `apiKeyConfigured`：明确未配置时展开原 Provider 密钥配置区，
未知时等待目录可读，已配置时进入原 live writer。该专用入口不是所有 Provider 的通用模型刷新。

目录请求使用 Installation 的唯一 HTTP product/version User-Agent，channel/client 放入独立 comment；
保持真实产品身份和同一远端 URL，不以更换身份或备用目录绕过网络错误。

- `config` 与 `channel` 属于基础配置 owner，并在同一 owner 内原子提交。
- `provider` 与 `provider/auth` 是 Provider 设置面的两个独立只读资源；每个成功响应独立提交，失败资源保留旧值并进入同一 Provider diagnostics 列表。
- Provider 表单配置明确提交（200或typed committed receipt）后，不论是否填写 Key，都通过原 loadProviderInfo 观察当前目录。普通保存和行内 Key 保存共享原串行后续结算：Auth成功才清理配置凭据覆盖，任一后续拒绝不阻断独立目录观察；fulfilled读取issues与原phase/resource/providerID保留。凭据状态仍只来自目录 owner，不能从表单或提交事实补成true/false。
- 无活动目录时，Provider 设置读取全局 config/catalog/auth methods 并写入全局 config/Auth；内置 Provider subscription/API auth 通过 `/global/providers/**` 的显式控制面执行，不创建或读取 Project `Instance`。Overlay 不再提供 Agent Models 设置面；Composer 是当前新建草稿或当前 Task / Chat / Work / Mission 根 Session 模型的唯一前端投影。切换持久化会话时，它通过根 Session Config 重新加载该会话自己的有效模型。显式模型选择写回当前根 Session（如果存在），并通过既有 Overlay settings 的 `lastSelectedModel` 保存新对话偏好；应用重开与空白新对话均读取该偏好，浏览已有会话不改写偏好。空白草稿首次提交前不创建 Project 或 Session，也不改写全局模型配置。每次 Chat、Work、Task 创建或 follow-up 请求仍显式传递当前投影。后端保留 top-level 与 `agent.<id>.model` 配置和解析能力，供非 Overlay 调用方使用。
- Projected scheduler 的每个 continued model Turn 都从当前 Task 根 Session overlay 解析模型；Orchestrator 子 Session 的历史 user Turn 只属于审计历史，不能作为当前请求的 `explicitModel` 覆盖根 Session。Projected worker 仍使用不可变 worker Turn runtime model，普通 Session 仍使用最新可见 user Turn 的显式模型。
- `config/prompt` 属于 Prompt owner，独立校验和提交。
- Settings 可并发刷新三个 owner，但任一 owner 失败只能阻止该 owner 的提交；错误仍必须显式上抛并进入通知面，不能清空或阻断其他已成功 owner。模型选择面只消费 Provider owner 的 canonical catalog。

## 新增 Provider 三条路径

### 上游 OpenCode Provider/API 同步边界

- `provider/bundled.ts` 是 bundled SDK（Software Development Kit，软件开发工具包）唯一注册表，
  覆盖 Bedrock/Mantle、Anthropic、Azure、Google Generative AI、Google Vertex、Vertex Anthropic、
  OpenAI、OpenAI-compatible、OpenRouter、xAI、Mistral、Groq、DeepInfra、Cerebras、Cohere、
  Vercel AI Gateway、Together、Perplexity、Vercel、Alibaba、GitLab、GitHub Copilot 和 Venice。
- `plugin/openai/codex.ts`、`plugin/github-copilot/**`、`plugin/digitalocean.ts`、
  `plugin/snowflake-cortex.ts`、`plugin/xai.ts`、`plugin/cloudflare.ts` 和 `plugin/azure.ts` 来源固定为
  上游固定提交 `8e2d422ffe56f3b2eb52e3f7195a2f9722a9fc46`；包名、客户端调用形态和产品 header
  只做 OpenCorvus 适配。上游的静默模型目录、持久化、浏览器启动和 transport fallback 不保留。
- Auth 的 `metadata` / `enterpriseUrl`、声明式 prompt `when`、Provider model projection 通过
  `@opencorvus-ai/plugin` 契约、`auth.json` 和 `Provider.buildState()` 单路流转；CLI、Server、Overlay
  不另存订阅状态。
- Google Vertex 明确投影 `GOOGLE_VERTEX_PROJECT` / `GOOGLE_VERTEX_LOCATION`，ADC 使用
  `cloud-platform` scope；Vertex Anthropic 的 `eu` / `us` 使用 regional endpoint。
- Hexin 仍由本地 canonical catalog、显式 refresh、profile、budget、sticky header 与 request
  transform 拥有；上游同步不得扫描、覆盖或替换这些 owner。

### Path 1 — OpenAI 兼容（零代码）

```jsonc
// config.provider 配置 api URL + env API Key
{ "provider": { "my-oai-compat": { "api": "https://...", "env": ["MY_KEY"] } } }
```

自动使用 `@ai-sdk/openai-compatible`。

### Path 2 — 有 Vercel AI SDK 包（一行代码）

在 `bundled.ts` 加映射：

```ts
"@ai-sdk/new-provider": createNewProvider
```

自动参数适配。

### Path 3 — 特殊行为（vendor.ts）

```ts
CUSTOM_LOADERS["new-provider"] = {
  getModel,
  options, // 区域路由 / 认证流 / API 切换
}
```

**所有路径**：models.dev 或 `config.provider` 定义模型元数据 + capabilities + cost。

## 与 Agent 架构的集成原则

1. **所有生产调用使用 `llm/api.ts` 的 `streamText`** — 不直接 import AI SDK 原始实现，统计和 tool-call repair 都由共享 wrapper 拥有
2. **session/llm.ts 复用 `ProviderLLM.wrapModel()` + `baseHeaders()`** — session 特有逻辑留在 session 层
3. **每个 Agent 通过 config 独立选模型** — Orchestrator 可用 Claude，Eval 可用 GPT
4. **新增 provider 只改 `provider/`** — agent 代码零变更

Session processor 通过统一流式调用的 `prepareStep` 在每个 Provider 请求前提交步骤快照与 `step-start`。SDK 只有在该异步准备成功后才能调用 Provider 和执行其工具；步骤消费者只观察 `start-step`，不重复创建事实。所有 Mission、Task Orchestrator 和 Worker 共用此顺序。步骤准备失败或取消会中止请求，重试清理由原 attempt 的持久化记录负责。不能用吞掉回调异常的 telemetry hook 代替该数据完整性边界。

SDK 7 在 Provider `finish` 转换为 `model-call-end` 后执行本次已收集的 Tool；流式测试参与者必须先交付该事件，再观察或等待实际副作用。HTTP 成功响应正文的物理读取错误由 SDK 包装在 `APICallError.cause` 中，统一 LLMActivity 分类器在保留明确 HTTP/Host/取消优先级后沿该 typed cause 分类，并终止循环 cause。只有原有可重试类别能进入同一 attempt cleanup；未知/语义错误仍按明确终态结算，已开始工具执行的 attempt 继续由原保护拒绝重放。

实际 SDK Tool execute 入口在 consumer 事件之前建立精确 call 的暂停所有权，并保持同步值、PromiseLike 和直接 AsyncIterable 的原返回契约。只有真实执行器已武装的固定 deadline/有界物理 cleanup 对象，经 SessionLoop 内部 typed observer 与同一 Tool progress 写者提交后，才可有限延长该 call 的暂停观察；无治理 Promise/普通 metadata/保留期不能关闭 guard。实际执行结束与晚到结果交接重新适用有限观察，外部取消仍以原 signal/cause 传播。普通 Catalog、Scoped 定义和直接 Scoped MCP 调用将 caller signal 传入同一既有 MCP 请求/Task恢复函数；取消查询不被宣称为远端 Task 已停止。进程 CLI 退出也不被宣称为 Docker daemon 中的外部工作已停止。

拒绝重放的 `ProcessorUnsafeRetryError` 保留真实 `Error.cause` 链中的名称、消息与自身字符串 code，并在循环引用处留下明确标记。落入现有 Message 错误文案前使用共享 Provider 脱敏规则，避免 SDK 外层通用文案遮掉连接重置等物理原因。该诊断文本不改变重试资格、attempt 边界或已执行 Tool 的持久事实；没有新增错误协议或独立故障状态。

Provider 流式正文 TextPart 的 `time.start` 是该 Part 实际接受 `text-start` 时记录的时间；前缀持久化、正常 `text-end` 与中止闭合都保留这个值，只在实际完成时追加 `time.end`。正常结束时点仍位于前缀队列等待和 `experimental.text.complete` 插件完成之后。重试成功 Part 使用自身尝试的开始事实，不继承失败尝试的时间。持久 Part 和 `PartUpdated` 事件使用同一组数值，没有估算、界面计时来源、历史回填或第二组时钟。用户/控制正文的可选时间定义保持原契约。

Tool-result text attachments are decoded through the same byte-prefix utility as
webfetch and Bash previews. Both inline and persisted attachments retain their
existing integrity checks and 200000-byte decode budget. A budget cut emits only
complete UTF-8 characters followed by the existing truncation notice; complete
input preserves BOM content and normal malformed-input replacement behavior.
The complete stored attachment and its identity remain authoritative for replay.

## 相关文档

- [17-code-work-agent-platform.md](17-code-work-agent-platform.md) — 哪些 agent 消费 Provider
- [04-extensions.md](04-extensions.md) — Provider 与 Expert Squad/Plugin/MCP/ACP 的独立关系

Physical stream error provenance: session.error retains optional streamRequest containing the actual requestID, agentID, providerID, catalog modelID and apiModelID for LLM.stream errors. Session channel/agent routing remains derived from the persisted Session and is separate from the physical caller. Non-stream processor, command and preparation errors retain their existing failure-occurrence or Session authority and do not invent a stream request. Worker and Orchestrator collectors match the Session and, when physical provenance exists, the executing agent identity. Auxiliary errors remain persisted/replayable and cannot become another agent's stream-failure evidence merely because both use the same Session. This diagnostic contract does not itself provide a visible helper transcript or UI attribution acceptance.

Task Board processIncidents preserve the same optional streamRequest identity from each persisted session_stream error. The Board and Session event contracts reuse the single StreamRequestIdentity schema; a Board read does not replace physical caller identity with Session routing or synthesize it for older/non-stream incidents. Debug UI formatting is a separate consumer of this contract.

The processor's existing fullStream consumer observes each actual yielded event before its caller hook, then the original handler and abort fence. Bounded scalar counters separate received event types, handler acceptance, heartbeat eligibility and actual semantic run.bump calls; delta lengths are UTF-16 code units, not bytes or semantic progress. The existing Task AgentTrace writer records an immediate abort snapshot with its current waiting phase and a separate consumer-settled snapshot. Neither snapshot proves physical Response settlement. Trace observation failures are isolated from execution, and unhandled events log only a fixed normalized type category.

The real logical activity ID and zero-based attempt are explicitly carried through the existing immutable Provider request context. SessionProcessor also supplies its actual assistant Message ID; the processor consumption Trace contract requires that ID. Title and Memory Organizer forward their existing collectLLMText run identity inside each attempt without inventing an assistant Message. Exact Response-reader observation and logical attempt consumption share their actual caller reference without claiming independent SDK counts for every physical request. Direct helpers without a formal request/activity identity retain the explicit unknown boundary; the VCS helper is outside this projection change. Non-Task consumption has no invented Task trace. Reader ownership, semantic policy, retry cleanup, physical joins and deadlines remain with their existing owners; transport bytes and diagnostic counters never renew semantic liveness.

At the same abort/consumer-settled Trace boundaries, current-attempt pending Tool drafts may contribute a bounded aggregate JSON structure observation. It reads only that attempt's tracked pending raw strings, parses each original string with native JSON.parse and discards values immediately; Trace retains fixed state/type counts and UTF-16 lengths. A complete object is not a schema-valid or executable Tool call. Syntax errors do not establish incompleteness or string position. Total parsed source UTF-16 code units are bounded by half the existing single configured Trace event-byte budget; over-budget drafts remain unobserved_size_limit and execution is unchanged. Disabled/non-Task Trace does not perform this work. Actual outgoing Tool declarations separately project fixed schema shape from the already parsed request body; absent strict/nullability facts remain unknown, with no schema or argument bodies retained.

Typed Provider stream error events use the shared transport decoder for nested and flat error payloads. Message stores a readable APIError message plus structurally redacted responseBody; a stream event does not invent an HTTP status. The activity class provider_stream_error is terminal without automatic replay because output may already have been consumed. Context overflow retains its dedicated classification. Conversation consumers project one message's summary and optional diagnostic body together; historic raw structured errors use the same decoder without rewriting persisted messages.
