"""Final identity and receipt audit only: no tests, runtime calls or services."""
import datetime as dt
import json
import pathlib
import re
import shutil
import subprocess

root = pathlib.Path(__file__).resolve().parent
repo = pathlib.Path('D:/myhexin-local/opencorvus')
qualification = pathlib.Path('D:/opencorvus-benchmark-runs/l06-tool-liveness-qualification-20261030')
frozen = qualification/'executed-source-final'
dest = root/'source-final'
dest.mkdir(exist_ok=False)
files = []
for source in sorted(path for path in frozen.rglob('*') if path.is_file()):
    rel = source.relative_to(frozen)
    current = repo/'packages/opencorvus'/rel
    target = dest/rel
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(source,target)
    files.append({'frozen_source':str(source),'current_source':str(current),'reviewer_copy':str(target),'current_equals_frozen_bytes':current.read_bytes()==source.read_bytes(),'reviewer_copy_equals_frozen_bytes':target.read_bytes()==source.read_bytes()})
evidence = root/'final-qualification-receipts'
evidence.mkdir(exist_ok=False)
names = ['final-tests-command.json','final-tests.stdout.txt','final-tests.stderr.txt','typecheck-command.json','typecheck.stdout.txt','typecheck.stderr.txt','real-loop-final.stdout.txt','real-loop-final.stderr.txt']
for name in names:
    shutil.copyfile(qualification/name,evidence/name)
test_command = json.loads((evidence/'final-tests-command.json').read_text(encoding='utf-8'))
type_command = json.loads((evidence/'typecheck-command.json').read_text(encoding='utf-8'))
test_log = (evidence/'final-tests.stderr.txt').read_text(encoding='utf-8')
physical_log = (evidence/'real-loop-final.stderr.txt').read_text(encoding='utf-8')
def extract(log):
    return {
        'pass':int(re.search(r'(\d+) pass\b',log).group(1)),
        'fail':int(re.search(r'(\d+) fail\b',log).group(1)),
        'assertions':int(re.search(r'(\d+) expect\(\) calls',log).group(1)),
        'reported_seconds':float(re.search(r'\[(\d+(?:\.\d+)?)s\]\s*$',log).group(1)),
    }
docs = root/'final-documents'
docs.mkdir(exist_ok=False)
doc_inventory = []
for rel in ['specs/current/architecture/06-provider.md','specs/current/architecture/task-control-plane.md','specs/records/2026-10/2026-10-30-heavy-workbench-tool-liveness.md']:
    target = docs/pathlib.Path(rel).name
    shutil.copyfile(repo/rel,target)
    doc_inventory.append({'source':str(repo/rel),'snapshot':str(target)})
identity = {'checked_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'method':'direct byte identity of executed final sources; functional evidence is separately the actual checks, not hashes or formatting gates','file_count':len(files),'files':files,'all_current_match':all(row['current_equals_frozen_bytes'] for row in files)}
(root/'final-source-identity.json').write_text(json.dumps(identity,indent=2),encoding='utf-8')
assessment = {
    'reviewer':'/root/benchmark_review',
    'status':'implementation_review_and_final_qualification_accepted_with_stated_scope',
    'substantive_blockers':[],
    'final_source_identity':{'count':len(files),'all_current_match_executed_snapshot':identity['all_current_match'],'evidence':'final-source-identity.json'},
    'main_final_regression':{**extract(test_log),'files':7,'command_exitcode':test_command['exitcode'],'execution_start':test_command['start'],'execution_end':test_command['end'],'main_before_after_source_receipt':test_command['executed_sources_still_same'],'reviewer_reexecuted':False},
    'main_real_tool_paths':{**extract(physical_log),'scope':'actual SessionLoop/SDK/Bash/SQLite/file and two physical timeout/caller-abort paths; controlled finite Provider participant','reviewer_reexecuted':False},
    'typecheck':{'command':type_command['command'],'exitcode':type_command['exitcode'],'raw_stdout_stderr_copied':True,'reviewer_reexecuted':False},
    'docs_check':{'source':'main provided original tool receipt identifier, not an independently read raw log','chunk_id':'957534','exitcode':0,'ops':351,'groups':26,'reviewer_reexecuted':False},
    'documents_read':doc_inventory,
    'formatter_scope':'main retained original/current/formatted-base three-way artifacts; not treated as functional correctness evidence',
    'prior_history_preserved':['source-initial/','source-reviewed/','ROUND1.md','stage-assessment.json','INVALID-PROBE-INITIAL.md','sdk-probe-command.json'],
    'limits':[
        'acceptance is for reviewed finite trusted Tool lifecycle, SDK shape and MCP signal propagation implementation',
        'no arbitrary third-party promise receives unbounded delegation or a fake deadline from TTL/working/metadata',
        'no real Provider run by reviewer and no operation or hot fix of old L06 candidate or containers',
        'old runtime interference history, mathematical candidate outcome and fresh pilot remain separate',
        'not ten-case completion, professional benchmark maturity or hour-level validation'
    ],
    'new_tests_or_runtime_invocations':False,
    'repository_modified_or_committed':False,
    'old_L06_hot_fixed':False,
    'candidate_score':None,
}
(root/'stage-assessment-final.json').write_text(json.dumps(assessment,indent=2),encoding='utf-8')
status = subprocess.run(['git','status','--short'],cwd=repo,capture_output=True,text=True,encoding='utf-8')
(root/'git-status-final.txt').write_text(status.stdout+status.stderr,encoding='utf-8')
print(json.dumps({'files':len(files),'all_current_equal':identity['all_current_match'],'regression':extract(test_log),'physical':extract(physical_log),'typecheck_exit':type_command['exitcode'],'tests_reexecuted':False}))
