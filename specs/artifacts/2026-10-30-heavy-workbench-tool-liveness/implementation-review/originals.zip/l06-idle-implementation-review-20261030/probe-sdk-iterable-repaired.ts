// Execute the exact captured wrapper AST with real local SDK consumption.
// The provider is the SDK's finite in-memory test participant: no HTTP/model.
import fs from "node:fs/promises"
import ts from "D:/myhexin-local/opencorvus/node_modules/typescript/lib/typescript.js"
import { streamText, tool, stepCountIs } from "D:/myhexin-local/opencorvus/packages/opencorvus/node_modules/ai/dist/index.js"
import { MockLanguageModelV3, simulateReadableStream } from "D:/myhexin-local/opencorvus/packages/opencorvus/node_modules/ai/dist/test/index.js"
import z from "D:/myhexin-local/opencorvus/node_modules/zod/index.js"

const root = "D:/opencorvus-benchmark-runs/l06-idle-implementation-review-20261030"
const text = await fs.readFile(root + "/source-initial/packages/opencorvus/src/session/processor.ts", "utf8")
const ast = ts.createSourceFile("captured-processor.ts", text, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS)
const matches: ts.ArrowFunction[] = []
function find(node: ts.Node) {
  if (ts.isPropertyAssignment(node) && node.name.getText(ast) === "execute" && ts.isArrowFunction(node.initializer)
      && node.initializer.getText(ast).includes("sdkExecutions.set")) matches.push(node.initializer)
  ts.forEachChild(node, find)
}
find(ast)
if (matches.length !== 1) throw new Error("Expected exact single production SDK execute wrapper")
const exact = matches[0]!.getText(ast)
await fs.writeFile(root + "/extracted-repaired-exact-sdk-wrapper.ts", exact)
const javascript = new Bun.Transpiler({ loader: "ts" }).transformSync("globalThis.__L06ReviewerExecute = (" + exact + ")")
await fs.writeFile(root + "/extracted-repaired-sdk-wrapper.js", javascript)

async function run(wrapped: boolean) {
  let yielded = 0
  const activity: Array<{type:string; owner?:string}> = []
  const controller = new AbortController()
  const run = { attempt: 0, signal: controller.signal, bump(kind: string) { activity.push({type:kind}) },
    pause(owner:string) { activity.push({type:"pause",owner}) }, resume(owner:string) { activity.push({type:"resume",owner}) } }
  const execute = async function* () {
    yielded++
    yield { value: "first" }
    yielded++
    yield { value: "final" }
  }
  const callback = wrapped
    ? new Function("run", "execute", "sdkExecutions", "markToolExecutionStarted", "toolPauseOwner", javascript + "; return globalThis.__L06ReviewerExecute;")
      (run, execute, new Map(), () => activity.push({type:"execution-started"}), (id:string) => "tool-call:"+id)
    : execute
  if (typeof callback !== "function") throw new Error("Reviewer wrapper extraction did not produce a callback")
  const result = streamText({
    model: new MockLanguageModelV3({ doStream: async () => ({ stream: simulateReadableStream({ chunks: [
      { type: "stream-start", warnings: [] },
      { type: "tool-call", toolCallId: "iterable-call", toolName: "iterable", input: "{}" },
      { type: "finish", finishReason: { unified: "tool-calls", raw: "tool_calls" }, usage: {
        inputTokens: { total: 1, noCache: 1, cacheRead: 0, cacheWrite: 0 },
        outputTokens: { total: 1, text: 1, reasoning: 0 },
      } },
    ] }) }) }),
    tools: { iterable: tool({ inputSchema: z.object({}), execute: callback }) },
    messages: [{role:"user",content:"Use the local test tool."}], stopWhen: stepCountIs(1),
  })
  const toolEvents: unknown[] = []
  for await (const event of result.stream) {
    if (event.type === "tool-result") toolEvents.push({type:event.type, preliminary:event.preliminary ?? false,
      output:event.output, output_is_async_iterable: !!event.output && typeof (event.output as any)[Symbol.asyncIterator] === "function"})
    if (event.type === "error") throw event.error
  }
  return { wrapped, yielded, activity, tool_events: toolEvents }
}
const baseline = await run(false)
const currentWrapper = await run(true)
const observation = { scope:"exact captured production wrapper AST and actual installed SDK, deterministic in-memory provider participant only",
  baseline, currentWrapper,
  regression_observed: baseline.yielded === 2 && currentWrapper.yielded === 0,
  actual_full_SessionProcessor_run:false, Provider_or_HTTP_or_candidate_run:false }
await fs.writeFile(root + "/sdk-iterable-repaired-observation.json", JSON.stringify(observation,null,2))
console.log(JSON.stringify(observation))
