import fs from 'node:fs'
const root='.tmp-codex-git-stage-01a133';let runner=fs.readFileSync(root+'/run-native.mjs','utf8')
for(const [before,after] of [["'native-dry-run-diagnostic'","'native-link-index-protocol'"],["tools/dry-run-diagnostic.ts","tools/link-index-protocol.ts"]]){if(runner.split(before).length!==2)throw Error('Original namespace seam missing');runner=runner.replace(before,after)}fs.writeFileSync(root+'/run-link-protocol.mjs',runner,{flag:'wx'})
