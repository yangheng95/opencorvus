import fs from 'node:fs'
import path from 'node:path'
import {pathToFileURL} from 'node:url'
const evidence=path.resolve(process.argv[2]);fs.mkdirSync(evidence)
const {Process}=await import(pathToFileURL(path.resolve(import.meta.dir,'../../packages/opencorvus/src/util/process.ts')).href)
const events:any[]=[];const fact=(type:string,value:any)=>{const item={type,...value,utc:new Date().toISOString(),wallMs:Date.now()};events.push(item);fs.writeFileSync(path.join(evidence,'events.json'),JSON.stringify(events,null,2)+'\n');console.log(JSON.stringify(item))}
fact('admitted',{inactivityTimeoutMs:10000,extraAtomicProbe:false,extraTimer:false})
let joined:any
const result=await Process.runHost(['C:/Program Files/nodejs/node.exe','-e','setInterval(()=>{},1000)'],{cwd:process.cwd(),nothrow:true,inactivityTimeoutMs:10000,onSpawned:(handle:any)=>{fact('spawned',{pid:handle.pid,occurrenceID:handle.occurrenceID});const terminate=handle.terminate.bind(handle);handle.terminate=(reason:any)=>{fact('terminate',{reason});return terminate(reason)};joined=Promise.allSettled([handle.terminal,handle.settled,handle.outputSettled])}} as any)
fact('returned',{code:result.code,stderr:result.stderr.toString(),joins:await joined});fs.writeFileSync(path.join(evidence,'summary.json'),JSON.stringify({events},null,2)+'\n',{flag:'wx'})
