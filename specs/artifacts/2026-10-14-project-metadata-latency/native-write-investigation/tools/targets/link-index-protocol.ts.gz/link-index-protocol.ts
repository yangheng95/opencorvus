import fs from 'node:fs'
import path from 'node:path'
import {pathToFileURL} from 'node:url'
const evidence=path.resolve(process.argv[2]);fs.mkdirSync(evidence)
const root=path.join(evidence,'repository');fs.mkdirSync(root)
const {hostGit}=await import(pathToFileURL(path.resolve(import.meta.dir,'../../packages/opencorvus/src/util/git.ts')).href)
const records:any[]=[]
async function git(args:string[],bytes?:Buffer){const number=records.length+1,start=Date.now();async function* input(){yield bytes!}const result=await hostGit(args,{cwd:root,input:bytes?input():undefined,timeoutProfile:'default'});fs.writeFileSync(path.join(evidence,number+'-stdout.bin'),result.stdout,{flag:'wx'});fs.writeFileSync(path.join(evidence,number+'-stderr.bin'),result.stderr,{flag:'wx'});if(bytes)fs.writeFileSync(path.join(evidence,number+'-input.bin'),bytes,{flag:'wx'});const item={number,args,start,end:Date.now(),code:result.exitCode,stdout:result.stdout.toString(),stderr:result.stderr.toString()};records.push(item);fs.writeFileSync(path.join(evidence,'records.json'),JSON.stringify(records,null,2)+'\n');console.log(JSON.stringify(item));if(result.exitCode!==0)throw Error('Original Git command failed '+number);return result}
await git(['init','--quiet']);await git(['config','user.name','Root link protocol']);await git(['config','user.email','root-link-protocol@example.invalid']);await git(['config','commit.gpgsign','false'])
fs.writeFileSync(path.join(root,'note.txt'),'one physical source\n',{flag:'wx'});await git(['add','--','note.txt'])
fs.symlinkSync(root,path.join(root,'root-link'),process.platform==='win32'?'junction':'dir')
const raw=fs.readlinkSync(path.join(root,'root-link'),{encoding:'buffer'});fs.writeFileSync(path.join(evidence,'raw-link.bin'),raw,{flag:'wx'})
const objectID=(await git(['hash-object','-w','--stdin'],raw)).stdout.toString().trim();await git(['update-index','-z','--index-info'],Buffer.from('120000 '+objectID+'\troot-link\0'))
await git(['ls-files','--stage','-z']);await git(['status','--porcelain=v1','-z','--untracked-files=no']);await git(['commit','-m','Actual raw terminal link protocol']);await git(['status','--porcelain=v1','-z','--untracked-files=no']);await git(['-c','core.symlinks=true','status','--porcelain=v1','-z','--untracked-files=no']);await git(['diff','--no-ext-diff','--no-renames','--raw','-z','HEAD']);const committed=await git(['cat-file','blob','HEAD:root-link']);if(!committed.stdout.equals(raw))throw Error('Actual immutable link blob differs')
fs.writeFileSync(path.join(evidence,'summary.json'),JSON.stringify({root,records,rawLinkBytes:raw.length,qualification:'Actual fresh repository, real 120000 index/commit/raw blob/status contracts. No production staging change, original cyclic fixture remains preserved.'},null,2)+'\n',{flag:'wx'})
