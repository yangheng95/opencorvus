import fs from 'node:fs'
import path from 'node:path'
import {pathToFileURL} from 'node:url'
const evidence=path.resolve(process.argv[2]);fs.mkdirSync(evidence)
const source=(name:string)=>pathToFileURL(path.resolve(import.meta.dir,'../../packages/opencorvus/src',name)).href
const {Process}=await import(source('util/process.ts'))
const events:any[]=[];const fact=(type:string,value:any)=>{const item={type,...value,atUtc:new Date().toISOString(),atMs:Date.now()};events.push(item);fs.writeFileSync(path.join(evidence,'events.json'),JSON.stringify(events,null,2)+'\n');console.log(JSON.stringify(item))}
const cell=new Int32Array(new SharedArrayBuffer(4)),start=Date.now(),atomic=Atomics.waitAsync(cell,0,0,25)
fact('atomic-created',{async:atomic.async,valueType:typeof atomic.value})
void Promise.resolve(atomic.value).then(value=>fact('atomic-resolved',{value,elapsedMs:Date.now()-start}))
setTimeout(()=>fact('host-timer-fired',{elapsedMs:Date.now()-start}),100)
const joins:any[]=[]
fact('silent-admitted',{inactivityTimeoutMs:500})
const result=await Process.runHost(['C:/Program Files/nodejs/node.exe','-e','setInterval(()=>{},1000)'],{cwd:process.cwd(),stdin:'ignore',nothrow:true,inactivityTimeoutMs:500,inactivityTimeoutMessage:'actual silent process inactive for 500ms',onSpawned:(handle:any)=>{
 fact('silent-spawned',{pid:handle.pid,occurrenceID:handle.occurrenceID})
 const terminate=handle.terminate.bind(handle);handle.terminate=async(reason:any)=>{fact('silent-terminate',{reason});return await terminate(reason)}
 joins.push(Promise.allSettled([handle.terminal,handle.settled,handle.outputSettled]).then(value=>{fact('silent-joins',{value});return value}))
}} as any)
fact('silent-returned',{code:result.code,stdoutBytes:result.stdout.length,stderr:result.stderr.toString()})
const outcomes=await Promise.all(joins);fs.writeFileSync(path.join(evidence,'summary.json'),JSON.stringify({events,outcomes,result:{code:result.code,stdoutBase64:result.stdout.toString('base64'),stderrBase64:result.stderr.toString('base64')}},null,2)+'\n',{flag:'wx'})
