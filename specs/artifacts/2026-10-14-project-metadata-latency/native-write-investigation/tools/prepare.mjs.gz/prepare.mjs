import fs from 'node:fs'
import path from 'node:path'
const root=path.resolve('.tmp-codex-git-stage-01a133');fs.mkdirSync(path.join(root,'tools'),{recursive:true})
fs.copyFileSync('.tmp-codex-project-meta-01a133/tools/native-host.ts',path.join(root,'tools/native-host.ts'),fs.constants.COPYFILE_EXCL)
let runner=fs.readFileSync('.tmp-codex-project-meta-01a133/run-source-remaining.mjs','utf8')
for(const [from,to] of [["path.resolve('.tmp-codex-project-meta-01a133')","path.resolve('.tmp-codex-git-stage-01a133')"],["'native-source-remaining'","'native-dry-run-diagnostic'"],["tools/source-remaining.ts","tools/dry-run-diagnostic.ts"]]){if(runner.split(from).length!==2)throw Error('Original owned runner seam missing');runner=runner.replace(from,to)}
fs.writeFileSync(path.join(root,'run-native.mjs'),runner,{flag:'wx'})
fs.writeFileSync(path.join(root,'preparation.json'),JSON.stringify({nativeHostSource:'.tmp-codex-project-meta-01a133/tools/native-host.ts',runnerSource:'.tmp-codex-project-meta-01a133/run-source-remaining.mjs',qualification:'New isolated diagnostic namespace, same mature Host, current Bun1.4 and unchanged 900000/120000 outer limits. Existing preserved finite fixture only.'},null,2)+'\n',{flag:'wx'})
