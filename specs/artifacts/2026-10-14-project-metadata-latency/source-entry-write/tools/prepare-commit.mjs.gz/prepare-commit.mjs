import fs from 'node:fs'
let value=fs.readFileSync('.tmp-codex-project-meta-01a133/commit-source-read-r2.mjs','utf8')
const start=value.indexOf("scopes=["),end=value.indexOf("],entries=",start)
if(start<0||end<0)throw Error('Original exact scope seam absent')
value=value.slice(0,start)+"scopes=['specs/records/2026-10/2026-10-14-project-metadata-latency.md','specs/artifacts/2026-10-14-project-metadata-latency/README.md',artifact"+value.slice(end)
for(const [from,to] of [["path.resolve('.tmp-codex-project-meta-01a133')","path.resolve('.tmp-codex-git-stage-01a133')"],["source-entry-read'","native-write-investigation'"],["source-index-entries.json","index-entries.json"],["path.join(scratch,'source-ui-bundle/bin')","path.resolve('.tmp-codex-project-meta-01a133/source-ui-bundle/bin')"],["fix(git): enumerate physical source entries through directory links","docs(git): record buffered activity and junction staging semantics"]]){if(value.split(from).length!==2)throw Error('Original commit seam missing: '+from);value=value.replace(from,to)}
fs.writeFileSync('.tmp-codex-git-stage-01a133/commit.mjs',value,{flag:'wx'})
