import fs from 'node:fs';
const root='.tmp-codex-git-stage-01a133';
let s=fs.readFileSync(root+'/run-engine-recovery-first-r2.mjs','utf8').replaceAll('native-engine-recovery-first-r2','native-engine-recovery-first-r3');
s=s.replace("['--cwd',path.resolve('packages/opencorvus'),'run','test','--test-name-pattern=restores the published checkpoint when final project-lease verification fails','test/engine-git-batched-transaction.test.ts']", "[path.resolve('packages/opencorvus/script/run-tests.ts'),'--test-name-pattern=restores the published checkpoint when final project-lease verification fails','test/engine-git-batched-transaction.test.ts']");fs.writeFileSync(root+'/run-engine-recovery-first-r3.mjs',s);
fs.copyFileSync('.tmp-codex-project-meta-01a133/tools/server-entry.ts',root+'/tools/server-entry.ts',fs.constants.COPYFILE_EXCL);
s=fs.readFileSync('.tmp-codex-project-meta-01a133/run-source-serve-final.mjs','utf8').replace("path.resolve('.tmp-codex-project-meta-01a133')","path.resolve('.tmp-codex-git-stage-01a133')").replaceAll('native-source-serve-final','native-stage-serve').replaceAll('project-metadata-before-01a133','project-source-stage-after-01a133').replaceAll("'18463'","'18465'").replaceAll("'.tmp-codex-project-meta-01a133/source-ui-bundle/bin/bun.exe'","'.tmp-codex-git-stage-01a133/stage-ui-bundle/bin/bun.exe'");
fs.writeFileSync(root+'/run-stage-serve.mjs',s);
