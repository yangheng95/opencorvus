import fs from 'node:fs';
const root='.tmp-codex-git-stage-01a133';let s=fs.readFileSync(root+'/run-stage-serve.mjs','utf8').replaceAll('native-stage-serve','native-stage-serve-types').replaceAll('18465','18466');fs.writeFileSync(root+'/run-stage-serve-types.mjs',s,{flag:'wx'});
