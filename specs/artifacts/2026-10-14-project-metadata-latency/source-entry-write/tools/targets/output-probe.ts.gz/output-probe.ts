import fs from 'node:fs'
import path from 'node:path'
import {pathToFileURL} from 'node:url'
const evidence=path.resolve(process.argv[2]);fs.mkdirSync(evidence)
const source=(file:string)=>pathToFileURL(path.resolve(import.meta.dir,'../../packages/opencorvus/src',file)).href
const {Process}=await import(source('util/process.ts')),{ProcessSupervisor}=await import(source('shell/process-supervisor.ts')),{hostGit,resolveGitTimeoutMs,gitProcessArgs}=await import(source('util/git.ts'))
const root='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/project-metadata-before-01a133/combined',args=['add','--dry-run','--all','--','.'],index=path.join(root,'.git/index'),events:any[]=[],observations:any[]=[]
const diagnostic=(error:any):any=>({name:error?.name??typeof error,code:error?.code,message:error?.message??String(error),stack:error?.stack,cause:error?.cause?diagnostic(error.cause):undefined})
const publish=(type:string,value:any)=>{const event={type,utc:new Date().toISOString(),wallMs:Date.now(),...value};events.push(event);fs.writeFileSync(path.join(evidence,'events.json'),JSON.stringify(events,null,2)+'\n');console.log(JSON.stringify(event))}
const restoreObserver=ProcessSupervisor.setWindowsRequestObserverForTest((request:any)=>{
 const number=observations.length+1,dir=path.join(evidence,'request-'+number);fs.mkdirSync(dir);observations.push(request);fs.writeFileSync(path.join(dir,'input.json'),JSON.stringify(request,null,2)+'\n',{flag:'wx'})
 const found=new Set<string>(),capture=()=>{for(const [name,field] of [['ready','ready_file'],['settled','settled_file'],['launch-failed','launch_failed_file']]){if(found.has(name))continue;try{fs.writeFileSync(path.join(dir,name+'.json'),fs.readFileSync(request[field]),{flag:'wx'});found.add(name)}catch(error:any){if(error.code!=='ENOENT')fs.writeFileSync(path.join(dir,'capture-error.json'),JSON.stringify(diagnostic(error),null,2)+'\n')}}if(found.has('settled')||found.has('launch-failed'))watcher.close()}
 const watcher=fs.watch(path.dirname(request.ready_file),capture);watcher.unref();capture()
})
const originalRun=Process.runHost,joins:Promise<PromiseSettledResult<any>[]>[]=[],terminations:Promise<any>[]=[]
Process.runHost=(command:any,options:any)=>originalRun(command,{...options,maxOutputBytes:4194304,onSpawned:async(handle:any)=>{
 publish('spawned',{pid:handle.pid,occurrenceID:handle.occurrenceID,command,cwd:options.cwd,inactivityTimeoutMs:options.inactivityTimeoutMs})
 for(const channel of ['stdout','stderr']){
  const original=handle[channel];let bytes=0,volume=0
  handle[channel]={async *[Symbol.asyncIterator](){for await(const chunk of original){fs.appendFileSync(path.join(evidence,'observed-'+channel+'.bin'),Buffer.from(chunk));const before=bytes;bytes+=chunk.byteLength;fs.appendFileSync(path.join(evidence,'output-chunks.ndjson'),JSON.stringify({channel,bytes:chunk.byteLength,total:bytes,utc:new Date().toISOString(),wallMs:Date.now()})+'\n');if(before===0||Math.floor(bytes/1048576)>volume){volume=Math.floor(bytes/1048576);publish('actual-output',{channel,bytes,chunkBytes:chunk.byteLength})}yield chunk}}}
 }
 const terminate=handle.terminate.bind(handle)
 handle.terminate=(reason:any)=>{publish('terminate-requested',{pid:handle.pid,reason});const promise=terminate(reason).then((result:any)=>{publish('terminate-returned',{pid:handle.pid,result});return result},(error:any)=>{publish('terminate-rejected',{pid:handle.pid,error:diagnostic(error)});throw error});terminations.push(promise);return promise}
 joins.push(Promise.allSettled([handle.terminal,handle.settled,handle.outputSettled]).then((results:any)=>{publish('original-joins',{pid:handle.pid,results:results.map((value:any)=>value.status==='fulfilled'?value:{status:value.status,error:diagnostic(value.reason)})});return results}))
 await options.onSpawned?.(handle)
}})
const before=fs.readFileSync(index);fs.writeFileSync(path.join(evidence,'index-before.bin'),before,{flag:'wx'})
fs.writeFileSync(path.join(evidence,'input.json'),JSON.stringify({root,args,command:gitProcessArgs(args),inactivityTimeoutMs:resolveGitTimeoutMs({timeoutProfile:'default'}),indexBytes:before.length,qualification:'Actual hostGit wrapper with transparent original handle observations; no periodic activity or product timeout change; explicit diagnostic 4MiB retention cap'},null,2)+'\n',{flag:'wx'})
publish('admitted',{args,root})
let result:any,error:any
try{result=await hostGit(args,{cwd:root,timeoutProfile:'default'});publish('returned',{code:result.exitCode,stdoutBytes:result.stdout.length,stderrBytes:result.stderr.length})}catch(value){error=diagnostic(value);publish('failed',{error})}finally{Process.runHost=originalRun;restoreObserver()}
const joined=await Promise.all(joins),terminated=await Promise.allSettled(terminations),after=fs.readFileSync(index);fs.writeFileSync(path.join(evidence,'index-after.bin'),after,{flag:'wx'})
if(result){fs.writeFileSync(path.join(evidence,'stdout.bin'),result.stdout,{flag:'wx'});fs.writeFileSync(path.join(evidence,'stderr.bin'),result.stderr,{flag:'wx'})}
fs.writeFileSync(path.join(evidence,'summary.json'),JSON.stringify({events,error,code:result?.exitCode,indexEqual:before.equals(after),joined,terminated,requests:observations.length,qualification:'Diagnostic result retained, command timeout is not write success'},null,2)+'\n',{flag:'wx'});if(!before.equals(after)||joined.some(value=>value.some(item=>item.status!=='fulfilled')))throw Error('Original diagnostic integrity or joins failed')
