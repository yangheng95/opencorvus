import fs from 'node:fs';
const r=JSON.parse(fs.readFileSync('.tmp-codex-git-stage-01a133/native-stage-contract-r1/evidence/native-host-settled.json','utf8'));
console.log(JSON.stringify({terminal:r.terminal,joins:r.originalJoins,bytes:r.bytes,targetState:r.targetState,closure:r.wholeJobClosed,error:r.runError},null,2));
let s=fs.readFileSync('.tmp-codex-git-stage-01a133/run-stage-contract-r1.mjs','utf8').replaceAll('native-stage-contract-r1','native-stage-contract-r2');
s=s.replace(",'test/engine-git-batched-transaction.test.ts'",'');fs.writeFileSync('.tmp-codex-git-stage-01a133/run-stage-contract-r2.mjs',s);
