import fs from 'node:fs';
let file='packages/opencorvus/test/engine-git-batched-transaction.test.ts',s=fs.readFileSync(file,'utf8');if(s.split('"--no-verify", ').length!==5)throw Error('fixture commit sites');s=s.replaceAll('"--no-verify", ','');fs.writeFileSync(file,s);
const root='.tmp-codex-git-stage-01a133';
s=fs.readFileSync(root+'/run-stage-contract-r1.mjs','utf8').replaceAll('native-stage-contract-r1','native-engine-recovery-r1');
s=s.replace("['--cwd',path.resolve('packages/opencorvus'),'test','test/git-source-stage.test.ts','test/git-source-consumers.test.ts','test/engine-git-batched-transaction.test.ts']", "['--cwd',path.resolve('packages/opencorvus'),'test','--timeout=60000','--parallel=1','--test-name-pattern','restores the published checkpoint when final project-lease verification fails','test/engine-git-batched-transaction.test.ts']");
fs.writeFileSync(root+'/run-engine-recovery-r1.mjs',s);
s=fs.readFileSync('.tmp-codex-project-meta-01a133/build-source-ui.mjs','utf8').replace("path.resolve('.tmp-codex-project-meta-01a133')","path.resolve('.tmp-codex-git-stage-01a133')").replaceAll('source-ui-bundle','stage-ui-bundle').replaceAll('source-ui-build','stage-ui-build');
fs.writeFileSync(root+'/build-stage-ui.mjs',s);
