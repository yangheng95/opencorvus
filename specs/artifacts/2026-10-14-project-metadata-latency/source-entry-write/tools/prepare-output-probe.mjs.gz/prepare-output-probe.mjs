import fs from 'node:fs'
import path from 'node:path'
const root='.tmp-codex-git-stage-01a133'
let tool=fs.readFileSync(root+'/tools/dry-run-diagnostic.ts','utf8')
const from="Process.runHost=(command:any,options:any)=>originalRun(command,{...options,onSpawned:async(handle:any)=>{"
const to="Process.runHost=(command:any,options:any)=>originalRun(command,{...options,maxOutputBytes:4194304,onSpawned:async(handle:any)=>{"
if(tool.split(from).length!==2)throw Error('Original output-capacity seam missing');tool=tool.replace(from,to)
const seam=" const terminate=handle.terminate.bind(handle)"
const observer=` for(const channel of ['stdout','stderr']){
  const original=handle[channel];let bytes=0,volume=0
  handle[channel]={async *[Symbol.asyncIterator](){for await(const chunk of original){fs.appendFileSync(path.join(evidence,'observed-'+channel+'.bin'),Buffer.from(chunk));const before=bytes;bytes+=chunk.byteLength;fs.appendFileSync(path.join(evidence,'output-chunks.ndjson'),JSON.stringify({channel,bytes:chunk.byteLength,total:bytes,utc:new Date().toISOString(),wallMs:Date.now()})+'\\n');if(before===0||Math.floor(bytes/1048576)>volume){volume=Math.floor(bytes/1048576);publish('actual-output',{channel,bytes,chunkBytes:chunk.byteLength})}yield chunk}}}
 }
`
if(tool.split(seam).length!==2)throw Error('Original observation seam missing');tool=tool.replace(seam,observer+seam).replace("no periodic activity or product timeout change","no periodic activity or product timeout change; explicit diagnostic 4MiB retention cap")
fs.writeFileSync(root+'/tools/output-probe.ts',tool,{flag:'wx'})
let runner=fs.readFileSync(root+'/run-native.mjs','utf8');for(const [before,after] of [["'native-dry-run-diagnostic'","'native-output-probe'"],["tools/dry-run-diagnostic.ts","tools/output-probe.ts"]]){if(runner.split(before).length!==2)throw Error('Original namespace seam missing');runner=runner.replace(before,after)}
fs.writeFileSync(root+'/run-output-probe.mjs',runner,{flag:'wx'})
