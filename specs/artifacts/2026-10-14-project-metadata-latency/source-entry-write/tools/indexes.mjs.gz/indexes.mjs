import fs from 'node:fs'
const entries=[
 ['specs/README.md','- [原生 Git 写入根因](records/2026-10/2026-10-14-project-metadata-latency.md)：真实字节活动、共享期限排查及junction index/dirty语义；完整修复继续进行。'],
 ['specs/artifacts/README.md','- [原生 Git 写入证据](2026-10-14-project-metadata-latency/native-write-investigation/README.md)：138原capture、4MiB输出/原结算及raw link原生状态冲突。'],
 ['specs/records/2026-10/README.md','- [原生 Git 写入根因](2026-10-14-project-metadata-latency.md)：活动性取证、raw-link实际Git协议与全部写入口影响；无产品写入修复通过声明。'],
]
for(const [file,line] of entries){const value=fs.readFileSync(file,'utf8');if(value.includes(line))throw Error('Owned line already exists');const position=value.indexOf('\n')+1;if(position===0)throw Error('Current index heading missing');const ending=value.includes('\r\n')?'\r\n':'\n';fs.writeFileSync(file,value.slice(0,position)+ending+line+ending+value.slice(position))}
fs.writeFileSync('.tmp-codex-git-stage-01a133/index-entries.json',JSON.stringify({entries},null,2)+'\n',{flag:'wx'})
