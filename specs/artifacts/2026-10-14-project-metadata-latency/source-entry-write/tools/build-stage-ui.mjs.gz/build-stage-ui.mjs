import fs from 'node:fs'
import path from 'node:path'
import {spawnSync} from 'node:child_process'
const scratch=path.resolve('.tmp-codex-git-stage-01a133'),bin=path.join(scratch,'stage-ui-bundle/bin')
fs.mkdirSync(path.dirname(bin));fs.mkdirSync(bin)
fs.copyFileSync(path.resolve('.tmp-codex-directory-target-01a133/browse-ui-bundle/bin/bun.exe'),path.join(bin,'bun.exe'),fs.constants.COPYFILE_EXCL)
const cwd=path.resolve('packages/overlay'),args=[path.join(cwd,'node_modules/vite/bin/vite.js'),'build','--outDir',path.join(bin,'ui')],start=new Date().toISOString()
const r=spawnSync(process.execPath,args,{cwd,windowsHide:true,maxBuffer:128*1024*1024})
fs.writeFileSync(path.join(scratch,'stage-ui-build.stdout.bin'),r.stdout??Buffer.alloc(0),{flag:'wx'});fs.writeFileSync(path.join(scratch,'stage-ui-build.stderr.bin'),r.stderr??Buffer.alloc(0),{flag:'wx'})
const receipt={command:[process.execPath,...args],cwd,start,end:new Date().toISOString(),exitCode:r.status,signal:r.signal,error:r.error?{name:r.error.name,code:r.error.code,message:r.error.message}:null,qualification:'Current working source Node Vite build to a new private immutable bin/ui; no standalone frontend server or visual acceptance claim'}
fs.writeFileSync(path.join(scratch,'stage-ui-build.exit.json'),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(receipt));if(r.status!==0)process.exitCode=r.status??1
