import fs from 'node:fs';
const file='packages/opencorvus/src/worktree/index.ts';let s=fs.readFileSync(file,'utf8');
s=s.replace('import { stageGitSourceEntries } from "../util/git-source-stage"','import { stageGitSourceEntries } from "../util/git-source-stage"\nimport { gitSourceStatus } from "../util/git-source-links"');
const pairs=[
['runGit(["-c", "core.quotepath=false", "status", "--porcelain"], {','gitSourceStatus({'],
['runGit(["status", "--porcelain=v1"], {','gitSourceStatus({']
];let count=0;
for(const [old,next] of pairs)while(s.includes(old)){
 const start=s.indexOf(old),end=s.indexOf('})',start);
 if(end<0||end-start>300)throw Error('status boundary');
 s=s.slice(0,start)+s.slice(start,end).replace(old,next)+'}, "lines")'+s.slice(end+2);count++;
}
if(count!==3)throw Error(`expected 3 status sites got ${count}`);fs.writeFileSync(file,s);
const gc='packages/opencorvus/src/worktree/gc.ts';s=fs.readFileSync(gc,'utf8');
s='import { gitSourceStatus } from "../util/git-source-links"\n'+s;
s=s.replace('runGit(["status", "--porcelain"], {','gitSourceStatus({');fs.writeFileSync(gc,s);
