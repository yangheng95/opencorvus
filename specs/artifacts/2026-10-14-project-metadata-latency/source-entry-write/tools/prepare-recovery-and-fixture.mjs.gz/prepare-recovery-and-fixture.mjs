import fs from 'node:fs';
const root='.tmp-codex-git-stage-01a133';
let s=fs.readFileSync(root+'/run-stage-contract-r2.mjs','utf8').replaceAll('native-stage-contract-r2','native-engine-recovery-first-r2');
s=s.replace("['--cwd',path.resolve('packages/opencorvus'),'test','test/git-source-stage.test.ts','test/git-source-consumers.test.ts']", "['--cwd',path.resolve('packages/opencorvus'),'run','test','--test-name-pattern=restores the published checkpoint when final project-lease verification fails','test/engine-git-batched-transaction.test.ts']");
fs.writeFileSync(root+'/run-engine-recovery-first-r2.mjs',s);
s=fs.readFileSync('.tmp-codex-project-meta-01a133/tools/fixture.mjs','utf8').replaceAll('project-metadata-before-01a133','project-source-stage-after-01a133');fs.writeFileSync(root+'/tools/stage-fixture.mjs',s);
s=fs.readFileSync(root+'/run-native.mjs','utf8').replaceAll("'native-prepare'","'native-stage-prepare'").replaceAll("'tools/fixture.mjs'","'tools/stage-fixture.mjs'");fs.writeFileSync(root+'/run-stage-prepare.mjs',s);
