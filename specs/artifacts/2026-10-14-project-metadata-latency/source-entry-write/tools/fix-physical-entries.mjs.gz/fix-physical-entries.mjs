import fs from 'node:fs';
let file='packages/opencorvus/src/project/vcs.ts',s=fs.readFileSync(file,'utf8');
// Only source comparisons use physical entry semantics; branch/commit/checkout keep their own options.
const a=s.indexOf('async function statUntracked('),b=s.indexOf('export namespace Vcs {',a);let segment=s.slice(a,b);
segment=segment.replaceAll('git(\n', 'gitSourceEntryGit(\n').replaceAll('git(["diff"','gitSourceEntryGit(["diff"');s=s.slice(0,a)+segment+s.slice(b);
s=s.replace('git(["status", "--porcelain=v1", "-z", "--branch", "--untracked-files=no"]','gitSourceEntryGit(["status", "--porcelain=v1", "-z", "--branch", "--untracked-files=no"]');fs.writeFileSync(file,s);
file='packages/opencorvus/src/file/index.ts';s=fs.readFileSync(file,'utf8');s=s.replace('["-c", "core.fsmonitor=false", "-c", "core.quotepath=false", "diff", "--name-only", "-z", "--diff-filter=D", ref]', '["-c", "core.fsmonitor=false", "-c", "core.quotepath=false", ...gitSourceEntryArgs(["diff", "--name-only", "-z", "--diff-filter=D", ref])]');fs.writeFileSync(file,s);
file='packages/opencorvus/src/worktree/index.ts';s=fs.readFileSync(file,'utf8');const x=s.indexOf('  function statusLinePaths('),y=s.indexOf('  function uniqueStrings(',x);if(x<0||y<0)throw Error('unused status boundaries');s=s.slice(0,x)+s.slice(y);const j=s.indexOf('  function chunks<T>('),k=s.indexOf('  function failed(',j);if(j<0||k<0)throw Error('unused chunks boundaries');s=s.slice(0,j)+s.slice(k);fs.writeFileSync(file,s);
