import fs from 'node:fs'
let value=fs.readFileSync('.tmp-codex-project-meta-01a133/deliver-source-read.mjs','utf8')
for(const [from,to] of [["path.resolve('.tmp-codex-project-meta-01a133')","path.resolve('.tmp-codex-git-stage-01a133')"],["path.join(scratch,'source-ui-bundle/bin')","path.resolve('.tmp-codex-project-meta-01a133/source-ui-bundle/bin')"]]){if(value.split(from).length!==2)throw Error('Original delivery seam missing');value=value.replace(from,to)}
const begin=value.indexOf(" const peer=JSON.parse("),end=value.indexOf(" await git(['diff','--check'",begin);if(begin<0||end<0)throw Error('Original outgoing review seam missing')
value=value.slice(0,begin)+" if(pending.some(id=>id!==own.commit))throw Error('Additional pending commits require complete independent review; actual diffs retained')\n"+value.slice(end)
fs.writeFileSync('.tmp-codex-git-stage-01a133/deliver.mjs',value,{flag:'wx'})
