import fs from 'node:fs';const file='packages/opencorvus/src/util/git-source-links.ts';let s=fs.readFileSync(file,'utf8');s=s.replace('import { gitSourcePaths } from "./git-source-paths"','import { gitSourcePaths, gitSourceIndexEntries } from "./git-source-paths"');
const a=s.indexOf('  const [source, projected] ='),b=s.indexOf('  const candidates =',a);if(a<0||b<0)throw Error('index projection boundaries');s=s.slice(0,a)+`  const [source, indexed, projected] = await Promise.all([
    gitSourcePaths(options.cwd, run),
    ref === "index" ? gitSourceIndexEntries(run) : Promise.resolve([]),
    ref === "index" ? Promise.resolve(undefined) : checkedSourceGit(run, ["ls-tree", "-r", "-z", ref, "--", "."]),
  ])
  const entries = new Map<string, { mode: string; object: string }>()
  const conflicts = new Set<string>()
  for (const entry of indexed) {
    if (entry.stage !== 0) { conflicts.add(entry.pathname); continue }
    entries.set(entry.pathname, { mode: entry.mode, object: entry.object })
  }
  for (const record of projected ? nulRecords(projected.stdout) : []) {
    const tab = record.indexOf("\\t")
    const [mode, type, object] = record.slice(0, tab).split(" ")
    const pathname = record.slice(tab + 1)
    if (tab < 0 || !mode || !type || !object || !pathname) throw new Error("Git source link projection returned an invalid tree entry")
    entries.set(pathname, { mode, object })
  }
`+s.slice(b);fs.writeFileSync(file,s);
