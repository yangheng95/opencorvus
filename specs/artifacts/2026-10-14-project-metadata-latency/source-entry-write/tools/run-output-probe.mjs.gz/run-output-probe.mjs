import fs from 'node:fs/promises'
import path from 'node:path'
import {spawn} from 'node:child_process'
import {randomUUID} from 'node:crypto'
const scratch=path.resolve('.tmp-codex-git-stage-01a133'),mode=process.argv[2],key=process.argv[3]
if(mode!=='source-remaining'&&mode!=='prepare'&&mode!=='serve'&&mode!=='directory-query'&&mode!=='semantic-query'&&!(mode==='stage'&&['control','healthy','self','ancestor','combined'].includes(key)))throw Error('Exact reviewed mode required')
if(mode!=='stage'&&key)throw Error('Only stage has a case argument')
const root=path.join(scratch,mode==='source-remaining'?'native-output-probe':mode==='prepare'?'native-prepare':mode==='serve'?'native-serve':mode==='directory-query'?'native-directory-query':mode==='semantic-query'?'native-semantic-query':'native-stage-'+key);await fs.mkdir(root)
for(const name of ['evidence','runtime','home','appdata','localappdata','temp','xdg-config','xdg-data','xdg-cache','xdg-state'])await fs.mkdir(path.join(root,name))
const environment={};for(const name of ['PATH','SystemRoot','WINDIR','ComSpec','PATHEXT','LANG','LC_ALL','LC_CTYPE'])if(process.env[name]!==undefined)environment[name]=process.env[name]
for(const [name,dir] of Object.entries({HOME:'home',USERPROFILE:'home',APPDATA:'appdata',LOCALAPPDATA:'localappdata',TEMP:'temp',TMP:'temp',TMPDIR:'temp',XDG_CONFIG_HOME:'xdg-config',XDG_DATA_HOME:'xdg-data',XDG_CACHE_HOME:'xdg-cache',XDG_STATE_HOME:'xdg-state',OPENCORVUS_HOME:'runtime'}))environment[name]=path.join(root,dir)
environment.HOMEDRIVE=path.parse(environment.HOME).root.slice(0,2);environment.HOMEPATH=environment.HOME.slice(2);environment.OPENCORVUS_TASK_PROCESS_MODE='native';environment.OPENCORVUS_DISABLE_EXTERNAL_SKILLS='1';environment.OPENCORVUS_DISABLE_AUTOUPDATE='1'
const bun=path.resolve(mode==='serve'?'.tmp-codex-project-meta-01a133/metadata-ui-bundle/bin/bun.exe':'.tmp-codex-project-meta-01a133/source-ui-bundle/bin/bun.exe'),executable=mode==='prepare'?'C:/Program Files/nodejs/node.exe':bun
environment.PATH=path.dirname(bun)+path.delimiter+environment.PATH
const executionCapMs=mode==='prepare'?60000:900000,inactivityTimeoutMs=mode==='prepare'?20000:120000,occurrence='metadata-'+mode+'-'+(key??'five-roots')+'-'+randomUUID(),deadlineAt=Date.now()+executionCapMs,evidence=path.join(root,'evidence')
const targetArgs=mode==='source-remaining'?[path.join(scratch,'tools/output-probe.ts'),path.join(root,'queries')]:mode==='semantic-query'?[path.join(scratch,'tools/semantic-query.ts'),path.join(root,'queries')]:mode==='directory-query'?[path.join(scratch,'tools/directory-query.ts'),path.join(root,'queries')]:mode==='prepare'?[path.join(scratch,'tools/fixture.mjs')]:mode==='serve'?[path.join(scratch,'tools/server-entry.ts'),path.join(evidence,'inner-requests'),'serve','--hostname','127.0.0.1','--port','18460','--project-dir','C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/project-metadata-before-01a133/control','--startup-receipt',path.join(root,'startup.json'),'--startup-occurrence',occurrence,'--log-level','INFO','--print-logs']:[path.join(scratch,'tools/stage-qualifier.ts'),key]
const hostArgs=[path.join(scratch,'tools/native-host.ts'),'--owned-host',evidence,occurrence,String(deadlineAt),String(inactivityTimeoutMs),executable,...targetArgs]
const input={mode,key,occurrence,root,evidence,hostExecutable:bun,hostArgs,executable,targetArgs,deadlineAt,executionCapMs,inactivityTimeoutMs,environmentNames:Object.keys(environment),parentPID:process.pid,admittedAtUtc:new Date().toISOString(),credentialCatalogStaging:'none',modelCallsRequested:'none',qualification:'Existing unchanged production Native Host owns streams, actual output inactivity and original three joins; isolated new directories only'}
await fs.writeFile(path.join(root,'original-input.json'),JSON.stringify(input,null,2)+'\n',{flag:'wx'})
const child=spawn(bun,hostArgs,{cwd:root,env:environment,windowsHide:true,stdio:['ignore','pipe','pipe']})
const collect=async(stream)=>{const chunks=[];for await(const chunk of stream)chunks.push(Buffer.from(chunk));return Buffer.concat(chunks)}
const terminal=new Promise(resolve=>{const errors=[];child.on('error',e=>errors.push({name:e.name,code:e.code,message:e.message}));child.once('close',(code,signal)=>resolve({code,signal,errors}))})
const outcomes=await Promise.allSettled([terminal,collect(child.stdout),collect(child.stderr)])
for(const [index,name] of [[1,'stdout.bin'],[2,'stderr.bin']])if(outcomes[index].status==='fulfilled')await fs.writeFile(path.join(root,name),outcomes[index].value,{flag:'wx'})
const receipt={occurrence,hostPID:child.pid,parentPID:process.pid,terminal:outcomes[0].status==='fulfilled'?outcomes[0].value:null,outputJoins:outcomes.slice(1).map((r,i)=>({stream:i?'stderr':'stdout',status:r.status,bytes:r.status==='fulfilled'?r.value.length:null,error:r.status==='rejected'?String(r.reason):undefined})),joinedAtUtc:new Date().toISOString()}
await fs.writeFile(path.join(root,'parent-joined.json'),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({root,receipt}))
process.exitCode=outcomes.some(r=>r.status==='rejected')?1:receipt.terminal.code??1
