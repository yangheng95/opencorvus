import fs from 'node:fs'
import path from 'node:path'
const scratch=path.resolve('.tmp-codex-git-stage-01a133'),fixture=JSON.parse(fs.readFileSync('C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/project-source-stage-after-01a133/prepared-fixture.json','utf8')),evidence=path.join(scratch,'stage-http-write'),records=[]
fs.mkdirSync(evidence)
async function request(key,route,method='GET',body){
 const item=fixture.cases.find(c=>c.key===key),url=new URL(route,'http://127.0.0.1:18465');url.searchParams.set('directory',item.directory)
 const number=records.length+1,record={number,key,url:String(url),method,requestBody:body,timeoutMs:15000,startUtc:new Date().toISOString(),startMs:Date.now()};records.push(record)
 fs.writeFileSync(path.join(evidence,number+'-input.json'),JSON.stringify(record,null,2)+'\n',{flag:'wx'})
 try{const response=await fetch(url,{method,headers:{'content-type':'application/json'},body:body===undefined?undefined:JSON.stringify(body),signal:AbortSignal.timeout(15000)});const bytes=Buffer.from(await response.arrayBuffer());fs.writeFileSync(path.join(evidence,number+'-body.bin'),bytes,{flag:'wx'});Object.assign(record,{status:response.status,body:JSON.parse(bytes.toString()),headers:Object.fromEntries(response.headers),error:null})}
 catch(error){Object.assign(record,{status:null,error:{name:error.name,message:error.message,stack:error.stack}})}
 Object.assign(record,{endUtc:new Date().toISOString(),elapsedMs:Date.now()-record.startMs});fs.writeFileSync(path.join(evidence,number+'-result.json'),JSON.stringify(record,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({number,key,route,status:record.status,elapsedMs:record.elapsedMs,error:record.error?.name}));return record
}

for(const key of ['control','healthy','self','ancestor']){
 const before=await request(key,'/vcs');if(before.status!==200||before.body.dirty!==true)throw Error('Real dirty input differs '+key);
 const committed=await request(key,'/vcs/commit','POST',{message:'Preserve physical source entries '+key});if(committed.status!==200||committed.body.info.clean!==true)throw Error('Actual write contract differs '+key);
}
for(const key of ['control','healthy','self','ancestor','combined']){
 const info=await request(key,'/vcs');if(info.status!==200||info.body.clean!==true||info.body.dirty!==false||info.body.untracked!==0||info.body.modified!==0||info.body.staged!==0)throw Error('Post-commit source not clean '+key);
 const status=await request(key,'/file/status');if(status.status!==200||JSON.stringify(status.body)!=='[]')throw Error('File status contract differs '+key);
}
const concurrent=await Promise.all(['combined','control','combined','control'].map(key=>request(key,'/vcs')));for(const result of concurrent)if(result.status!==200||result.body.branch!=='metadata-'+result.key||result.body.clean!==true)throw Error('Project isolation output differs');
fs.writeFileSync(path.join(evidence,'summary.json'),JSON.stringify({fixtureID:fixture.fixtureID,records,qualification:'Actual source CLI TCP writes and clean reads on all five finite physical fixtures; combined committed manually through desktop UI; no model success claim'},null,2)+'\n',{flag:'wx'});
