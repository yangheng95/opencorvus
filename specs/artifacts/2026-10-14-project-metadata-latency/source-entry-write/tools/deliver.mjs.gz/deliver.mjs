import fs from 'node:fs'
import path from 'node:path'
import {spawn} from 'node:child_process'
const scratch=path.resolve('.tmp-codex-git-stage-01a133'),own=JSON.parse(fs.readFileSync(path.join(scratch,'source-commit.json'),'utf8')),env={...process.env,PATH:path.resolve('.tmp-codex-project-meta-01a133/source-ui-bundle/bin')+path.delimiter+process.env.PATH}
async function git(args){
 const startUtc=new Date().toISOString(),prefix=path.join(scratch,'source-delivery-'+Date.now()+'-'+args[0]),child=spawn('git',args,{env,windowsHide:true,stdio:['ignore','pipe','pipe']})
 const read=async stream=>{const chunks=[];for await(const chunk of stream)chunks.push(chunk);return Buffer.concat(chunks)}
 const [terminal,stdout,stderr]=await Promise.all([new Promise(resolve=>child.once('close',(code,signal)=>resolve({code,signal}))),read(child.stdout),read(child.stderr)])
 fs.writeFileSync(prefix+'-stdout.bin',stdout,{flag:'wx'});fs.writeFileSync(prefix+'-stderr.bin',stderr,{flag:'wx'});fs.writeFileSync(prefix+'-result.json',JSON.stringify({args,startUtc,endUtc:new Date().toISOString(),terminal,stdoutBytes:stdout.length,stderrBytes:stderr.length},null,2)+'\n',{flag:'wx'})
 if(terminal.code!==0)throw Error('Original Git failure retained: '+prefix);return stdout.toString()
}
if(process.argv.includes('--sync')){
 await git(['fetch','origin']);await git(['merge','--no-edit','@{upstream}'])
 const head=(await git(['rev-parse','HEAD'])).trim(),upstream=(await git(['rev-parse','@{upstream}'])).trim(),pending=(await git(['rev-list','--reverse','@{upstream}..HEAD'])).trim().split('\n').filter(Boolean),commits=[]
 for(const id of pending){const completeDiff=await git(['show','--format=fuller',id]);commits.push({id,completeDiff})}
 const review={head,upstream,pending,commits,ownedCommit:own.commit,atUtc:new Date().toISOString()};fs.writeFileSync(path.join(scratch,'source-outgoing-'+Date.now()+'.json'),JSON.stringify(review,null,2)+'\n',{flag:'wx'})
 if(pending.some(id=>id!==own.commit))throw Error('Additional pending commits require complete independent review; actual diffs retained')
 await git(['diff','--check','@{upstream}','HEAD'])
 const productScopes=own.scopes.filter(scope=>scope.startsWith('packages/')||scope.startsWith('specs/current/')||scope.startsWith('specs/records/')||scope.endsWith('/README.md'))
 if((await git(['status','--short','--',...productScopes])).trim()||(await git(['diff',own.commit,head,'--',...own.scopes])).trim())throw Error('Owned accepted source changed')
 fs.writeFileSync(path.join(scratch,'source-outgoing-latest.json'),JSON.stringify(review,null,2)+'\n');console.log(JSON.stringify({head,upstream,pending,reviewed:true}))
}else if(process.argv.includes('--push')){
 const review=JSON.parse(fs.readFileSync(path.join(scratch,'source-outgoing-latest.json'),'utf8'))
 if((await git(['rev-parse','HEAD'])).trim()!==review.head)throw Error('HEAD advanced before push; fresh sync required')
 console.log(await git(['push']))
}else if(process.argv.includes('--final')){
 await git(['fetch','origin'])
 const head=(await git(['rev-parse','HEAD'])).trim(),upstream=(await git(['rev-parse','@{upstream}'])).trim(),remote=(await git(['ls-remote','origin','refs/heads/main'])).trim();await git(['merge-base','--is-ancestor',own.commit,'@{upstream}'])
 const ownScope=await git(['status','--short','--',...own.scopes]),staged=await git(['diff','--cached','--name-only']),status=await git(['status','--short'])
 if(ownScope.trim()||staged.trim())throw Error('Own files or index remain uncommitted')
 const proof={head,upstream,remote,ownedCommit:own.commit,ownScope,staged,status,atUtc:new Date().toISOString(),qualification:'Actual normal push and fresh own commit ancestry. Source reading delivered; continuous iteration and native-write investigation remain active.'}
 fs.writeFileSync(path.join(scratch,'source-final-proof-'+Date.now()+'.json'),JSON.stringify(proof,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({head,upstream,remote,ownedCommit:own.commit,ownScopeClean:true,indexEmpty:true}))
}else throw Error('Explicit sync/push/final required')
