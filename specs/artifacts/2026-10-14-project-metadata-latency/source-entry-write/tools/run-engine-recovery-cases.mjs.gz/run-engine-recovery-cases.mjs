import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
const root='.tmp-codex-git-stage-01a133';
const patterns=[
'restores a child ref and index after post-CAS index installation failure, then records nested gitlinks',
'restores the frozen owning ref when symbolic HEAD moves to another predecessor branch',
'preserves an external winner ref and index when rollback loses its compare-and-swap authority',
'preserves the published unborn-ref checkpoint when recovery ref inspection fails',
'preserves an external staged index when recovery no longer owns the canonical index'];
const base=fs.readFileSync(root+'/run-engine-recovery-first-r3.mjs','utf8');
for(const [index,pattern] of patterns.entries()){
 const s=base.replaceAll('native-engine-recovery-first-r3',`native-engine-recovery-case-${index+2}`).replace('restores the published checkpoint when final project-lease verification fails',pattern);
 const file=root+`/run-engine-recovery-case-${index+2}.mjs`;fs.writeFileSync(file,s,{flag:'wx'});
}
const outcomes=[];
for(let index=2;index<=6;index++){
 const startedAt=new Date().toISOString(),result=spawnSync(process.execPath,[root+`/run-engine-recovery-case-${index}.mjs`,'source-remaining'],{windowsHide:true,stdio:['ignore','pipe','pipe'],maxBuffer:8*1024*1024});
 outcomes.push({case:index,startedAt,endedAt:new Date().toISOString(),exitCode:result.status,stdout:result.stdout.toString(),stderr:result.stderr.toString()});
 fs.writeFileSync(root+'/engine-recovery-case-receipts.json',JSON.stringify(outcomes,null,2));console.log(JSON.stringify(outcomes.at(-1)));if(result.status!==0){process.exitCode=result.status??1;break}
}
