import fs from 'node:fs';
const filename='packages/opencorvus/src/engine/git.ts';
let source=fs.readFileSync(filename,'utf8');
const start=source.indexOf('async function readOptionalFile('),end=source.indexOf('async function restoreRepositoryTransaction(',start);
if(start<0||end<0)throw Error('function boundaries');
const replacement=`async function prepareCanonicalIndexLock(transaction: RepositoryTransaction, temporaryIndex: string) {
  return prepareGitIndexLock({
    indexPath: transaction.indexPath,
    predecessor: transaction.indexExisted ? await fs.readFile(transaction.indexBackup) : undefined,
    preparedIndex: temporaryIndex,
    label: transaction.repository.path,
  })
}

async function installCanonicalIndexLock(lock: OwnedIndexLock, transaction: RepositoryTransaction) {
  await installGitIndexLock(lock, transaction.indexPath)
}

`;
fs.writeFileSync(filename,source.slice(0,start)+replacement+source.slice(end));
