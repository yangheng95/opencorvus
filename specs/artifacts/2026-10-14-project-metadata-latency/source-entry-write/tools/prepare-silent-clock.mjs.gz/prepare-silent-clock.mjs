import fs from 'node:fs'
const root='.tmp-codex-git-stage-01a133';let value=fs.readFileSync(root+'/run-native.mjs','utf8')
for(const [from,to] of [["'native-dry-run-diagnostic'","'native-silent-clock'"],["tools/dry-run-diagnostic.ts","tools/silent-clock.ts"],["mode==='prepare'?60000:900000","mode==='prepare'?60000:20000"],["mode==='prepare'?20000:120000","mode==='prepare'?20000:10000"]]){if(value.split(from).length!==2)throw Error('Original diagnostic seam missing');value=value.replace(from,to)}
fs.writeFileSync(root+'/run-silent-clock.mjs',value,{flag:'wx'})
