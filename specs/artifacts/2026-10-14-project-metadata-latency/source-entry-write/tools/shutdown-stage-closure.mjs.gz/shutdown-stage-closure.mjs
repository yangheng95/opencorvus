import fs from 'node:fs'
import path from 'node:path'
import {spawnSync} from 'node:child_process'
const scratch=path.resolve('.tmp-codex-git-stage-01a133'),run=path.join(scratch,'native-stage-serve-closure'),ready=JSON.parse(fs.readFileSync(path.join(run,'evidence/native-host-ready.json'),'utf8')),pid=ready.target.pid
if(!Number.isSafeInteger(pid)||pid<=0)throw Error('Original owned PID invalid')
const command=`$taskProcess = Get-Process -Id ${pid}; $taskListener = @(Get-NetTCPConnection -LocalPort 18467 -State Listen -ErrorAction SilentlyContinue); [pscustomobject]@{ pid = $taskProcess.Id; birth = ('win32:' + $taskProcess.StartTime.ToUniversalTime().Ticks.ToString()); listeners = @($taskListener | Select-Object LocalAddress,LocalPort,OwningProcess) } | ConvertTo-Json -Depth 5 -Compress`
const identity=spawnSync('powershell.exe',['-NoProfile','-Command',command],{windowsHide:true,encoding:'utf8'})
fs.writeFileSync(path.join(scratch,'stage-closure-shutdown-identity.json'),JSON.stringify({command,code:identity.status,stdout:identity.stdout,stderr:identity.stderr},null,2)+'\n',{flag:'wx'})
if(identity.status!==0)throw Error('Owned physical identity inspection failed')
const fact=JSON.parse(identity.stdout);if(fact.pid!==pid||fact.birth!==ready.target.processInstanceID||fact.listeners.length!==1||fact.listeners[0].OwningProcess!==pid)throw Error('Owned service identity differs')
const inner=fs.readdirSync(path.join(run,'evidence/inner-requests')).map(name=>{
 const dir=path.join(run,'evidence/inner-requests',name),request=JSON.parse(fs.readFileSync(path.join(dir,'request.json'),'utf8')),settled=JSON.parse(fs.readFileSync(path.join(dir,'settled.json'),'utf8'))
 if(settled.request_id!==request.actualRequest.request_id||settled.active_processes!==0||request.actualRequest.owner_pid!==pid)throw Error('Current request has not settled')
 return {name,requestID:settled.request_id,activeProcesses:settled.active_processes}
})
const input={url:'http://127.0.0.1:18467/shutdown',method:'POST',timeoutMs:15000,startUtc:new Date().toISOString(),identity:fact,inner}
fs.writeFileSync(path.join(scratch,'stage-closure-shutdown-input.json'),JSON.stringify(input,null,2)+'\n',{flag:'wx'})
const response=await fetch(input.url,{method:'POST',signal:AbortSignal.timeout(15000)}),body=await response.text(),result={status:response.status,body,endUtc:new Date().toISOString()}
fs.writeFileSync(path.join(scratch,'stage-closure-shutdown-response.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({identity:fact.pid,requests:inner.length,result}));if(response.status!==200)throw Error('Original shutdown HTTP failed')
