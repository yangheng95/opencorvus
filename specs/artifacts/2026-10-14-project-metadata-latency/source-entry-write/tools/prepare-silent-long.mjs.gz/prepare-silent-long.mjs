import fs from 'node:fs'
const root='.tmp-codex-git-stage-01a133';let value=fs.readFileSync(root+'/run-silent-clock.mjs','utf8')
for(const [from,to] of [["'native-silent-clock'","'native-silent-long'"],["tools/silent-clock.ts","tools/silent-long.ts"],["mode==='prepare'?60000:20000","mode==='prepare'?60000:30000"],["mode==='prepare'?20000:10000","mode==='prepare'?20000:20000"]]){if(value.split(from).length!==2)throw Error('Original checker seam missing');value=value.replace(from,to)}fs.writeFileSync(root+'/run-silent-long.mjs',value,{flag:'wx'})
