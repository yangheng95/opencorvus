import fs from 'node:fs';
let s=fs.readFileSync('.tmp-codex-git-stage-01a133/run-native.mjs','utf8');
s=s.replace("'native-dry-run-diagnostic'","'native-stage-contract-r1'");
const a=s.indexOf("mode==='source-remaining'?[path.join(scratch,'tools/dry-run-diagnostic.ts'),path.join(root,'queries')]");
if(a<0)throw Error('target boundary');
s=s.replace("mode==='source-remaining'?[path.join(scratch,'tools/dry-run-diagnostic.ts'),path.join(root,'queries')]", "mode==='source-remaining'?['--cwd',path.resolve('packages/opencorvus'),'test','test/git-source-stage.test.ts','test/git-source-consumers.test.ts','test/engine-git-batched-transaction.test.ts']");
fs.writeFileSync('.tmp-codex-git-stage-01a133/run-stage-contract-r1.mjs',s);
