import fs from 'node:fs'
import path from 'node:path'
import {spawnSync} from 'node:child_process'
import {gunzipSync} from 'node:zlib'
const scratch=path.resolve('.tmp-codex-git-stage-01a133'),artifact='specs/artifacts/2026-10-14-project-metadata-latency/native-write-investigation',scopes=['specs/records/2026-10/2026-10-14-project-metadata-latency.md','specs/artifacts/2026-10-14-project-metadata-latency/README.md',artifact],entries=JSON.parse(fs.readFileSync(path.join(scratch,'index-entries.json'),'utf8')).entries
const env={...process.env,PATH:path.resolve('.tmp-codex-project-meta-01a133/source-ui-bundle/bin')+path.delimiter+process.env.PATH}
function git(args,options={}){const r=spawnSync('git',args,{env,...options,windowsHide:true,maxBuffer:128*1024*1024});if(args[0]==='commit'||r.status!==0)fs.writeFileSync(path.join(scratch,'source-git-'+Date.now()+'.json'),JSON.stringify({args,code:r.status,stdout:r.stdout.toString(),stderr:r.stderr.toString()},null,2));if(r.status!==0)throw Error('Original Git failure retained: '+args.join(' '));return r.stdout}
if(git(['diff','--cached','--name-only']).length)throw Error('Shared index is occupied')
const base=git(['rev-parse','HEAD']).toString().trim(),index=path.join(scratch,'source-private-index-'+Date.now()),privateEnv={...env,GIT_INDEX_FILE:index}
git(['read-tree',base],{env:privateEnv});git(['add','-f','--',...scopes],{env:privateEnv})
for(const [file,line] of entries){if(fs.readFileSync(file,'utf8').split(line).length!==2)throw Error('Own working index line differs');const original=git(['show',base+':'+file]).toString();if(original.includes(line))throw Error('Own new line is already committed');const content=original.replace(/^(#[^\n]*\n)/,'$1\n'+line+'\n'),blob=git(['hash-object','-w','--stdin'],{env:privateEnv,input:content}).toString().trim();git(['update-index','--cacheinfo','100644',blob,file],{env:privateEnv})}
git(['diff','--cached','--check'],{env:privateEnv})
const files=git(['diff','--cached','--name-only'],{env:privateEnv}).toString().trim().split('\n'),matches=file=>scopes.some(scope=>file===scope||file.startsWith(scope+'/'))||entries.some(entry=>entry[0]===file)
if(files.some(file=>!matches(file)))throw Error('Prepared scope escaped')
const captures=JSON.parse(fs.readFileSync(artifact+'/manifest.json','utf8')).files
const batch=git(['cat-file','--batch'],{env:privateEnv,input:captures.map(item=>':'+artifact+'/'+item.file).join('\n')+'\n'})
let offset=0
for(const item of captures){const end=batch.indexOf(10,offset),header=batch.subarray(offset,end).toString(),match=/^[a-f0-9]+ blob (\d+)$/.exec(header);if(end<0||!match)throw Error('Original staged batch record malformed');const size=Number(match[1]),staged=batch.subarray(end+1,end+1+size),stored=fs.readFileSync(artifact+'/'+item.file);if(batch[end+1+size]!==10||!stored.equals(staged)||!(item.gzip?gunzipSync(stored):stored).equals(fs.readFileSync(item.source)))throw Error('Actual staged capture differs: '+item.file);offset=end+size+2}
if(offset!==batch.length)throw Error('Original staged batch has excess data')
const patch=git(['diff','--cached','--binary'],{env:privateEnv});fs.writeFileSync(path.join(scratch,'source-prepared-r2.patch'),patch,{flag:'wx'});fs.writeFileSync(path.join(scratch,'source-prepared-r2.json'),JSON.stringify({base,index,files,scopes,entries,qualification:'Owned product/source contracts, tests, original evidence and exact three index lines. Foreign working files/index order retained.'},null,2)+'\n',{flag:'wx'})
if(git(['rev-parse','HEAD']).toString().trim()!==base)throw Error('HEAD advanced before own commit')
const stdout=git(['commit','-m','docs(git): record buffered activity and junction staging semantics'],{env:privateEnv}).toString(),short=stdout.match(/\[[^\]\r\n]+ ([a-f0-9]{7,40})\]/)?.[1]
if(!short)throw Error('Original commit identity missing')
const commit=git(['rev-parse',short]).toString().trim(),parent=git(['rev-parse',commit+'^']).toString().trim(),actual=git(['diff-tree','--no-commit-id','--name-only','-r',commit]).toString().trim().split('\n')
if(parent!==base||actual.length!==files.length||actual.some(file=>!files.includes(file)))throw Error('Actual commit scope differs')
const ownPatch=git(['diff',base,commit,'--binary']);git(['apply','--cached','--check'],{input:ownPatch});git(['apply','--cached'],{input:ownPatch})
const receipt={base,commit,files:actual,scopes,entries,atUtc:new Date().toISOString(),staged:git(['diff','--cached','--name-only']).toString()};fs.writeFileSync(path.join(scratch,'source-commit.json'),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({base,commit,files:files.length,staged:receipt.staged}))
