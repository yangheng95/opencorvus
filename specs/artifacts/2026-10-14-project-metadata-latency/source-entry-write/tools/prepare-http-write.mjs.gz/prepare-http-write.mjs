import fs from 'node:fs';
let s=fs.readFileSync('.tmp-codex-project-meta-01a133/source-http-final.mjs','utf8');s=s.replace("path.resolve('.tmp-codex-project-meta-01a133')","path.resolve('.tmp-codex-git-stage-01a133')").replaceAll('project-metadata-before-01a133','project-source-stage-after-01a133').replaceAll('18463','18465').replaceAll('source-http-final','stage-http-write');
const a=s.indexOf('const scopes=[]');if(a<0)throw Error('probe boundary');s=s.slice(0,a)+`
for(const key of ['control','healthy','self','ancestor']){
 const before=await request(key,'/vcs');if(before.status!==200||before.body.dirty!==true)throw Error('Real dirty input differs '+key);
 const committed=await request(key,'/vcs/commit','POST',{message:'Preserve physical source entries '+key});if(committed.status!==200||committed.body.info.clean!==true)throw Error('Actual write contract differs '+key);
}
for(const key of ['control','healthy','self','ancestor','combined']){
 const info=await request(key,'/vcs');if(info.status!==200||info.body.clean!==true||info.body.dirty!==false||info.body.untracked!==0||info.body.modified!==0||info.body.staged!==0)throw Error('Post-commit source not clean '+key);
 const status=await request(key,'/file/status');if(status.status!==200||JSON.stringify(status.body)!=='[]')throw Error('File status contract differs '+key);
}
const concurrent=await Promise.all(['combined','control','combined','control'].map(key=>request(key,'/vcs')));for(const result of concurrent)if(result.status!==200||result.body.branch!=='metadata-'+result.key||result.body.clean!==true)throw Error('Project isolation output differs');
fs.writeFileSync(path.join(evidence,'summary.json'),JSON.stringify({fixtureID:fixture.fixtureID,records,qualification:'Actual source CLI TCP writes and clean reads on all five finite physical fixtures; combined committed manually through desktop UI; no model success claim'},null,2)+'\\n',{flag:'wx'});
`;fs.writeFileSync('.tmp-codex-git-stage-01a133/stage-http-write.mjs',s);
