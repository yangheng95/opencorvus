import fs from 'node:fs'
import path from 'node:path'
const scratch=path.resolve('.tmp-codex-git-stage-01a133'),root=path.resolve('C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/project-source-stage-after-01a133'),fixture=JSON.parse(fs.readFileSync(path.join(root,'prepared-fixture.json'),'utf8')),mode=process.argv[2]
if(!['register','baseline','cycle-short','cycle-complete'].includes(mode))throw Error('Exact planned probe mode required')
const evidence=path.join(scratch,'stage-final-http-'+mode);fs.mkdirSync(evidence)
const stamp=()=>({utc:new Date().toISOString(),wallMs:Date.now(),monotonicNs:process.hrtime.bigint().toString()})
const errorFact=e=>({name:e?.name??typeof e,code:e?.code,message:e?.message??String(e),stack:e?.stack,cause:e?.cause?errorFact(e.cause):undefined})
const records=[]
async function request(key,route,timeoutMs=15000,method='GET',body){
 const item=fixture.cases.find(c=>c.key===key);if(!item)throw Error('Exact case required')
 const url=new URL(route,'http://127.0.0.1:18466');url.searchParams.set('directory',item.directory)
 const number=records.length+1,start=stamp(),headers={'content-type':'application/json'},input={number,key,url:String(url),method,headers,body,timeoutMs,start}
 fs.writeFileSync(path.join(evidence,number+'-input.json'),JSON.stringify(input,null,2)+'\n',{flag:'wx'})
 let record
 try{const response=await fetch(url,{method,headers,body:body===undefined?undefined:JSON.stringify(body),signal:AbortSignal.timeout(timeoutMs)}),bytes=Buffer.from(await response.arrayBuffer()),end=stamp();fs.writeFileSync(path.join(evidence,number+'-body.bin'),bytes,{flag:'wx'});record={...input,end,elapsedMs:end.wallMs-start.wallMs,status:response.status,responseHeaders:Object.fromEntries(response.headers),body:JSON.parse(bytes.toString()),bodyBytes:bytes.length,error:null}}
 catch(e){const end=stamp();record={...input,end,elapsedMs:end.wallMs-start.wallMs,status:null,error:errorFact(e)}}
 records.push(record);fs.writeFileSync(path.join(evidence,number+'-result.json'),JSON.stringify(record,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({key,route,status:record.status,elapsedMs:record.elapsedMs,error:record.error?.name}))
 return record
}
if(mode==='register'){
 const scopes=[]
 for(const key of ['control','combined']){
  const project=await request(key,'/project/current',30000),chat=project.status===200?await request(key,'/coding/chat/session',30000,'POST',{}):null
  if(project.status!==200||chat?.status!==201||chat.body.session.projectID!==project.body.id)throw Error('Original Project/empty Chat registration failure retained')
  scopes.push({key,directory:fixture.cases.find(c=>c.key===key).directory,projectID:project.body.id,sessionID:chat.body.session.id})
 }
 fs.writeFileSync(path.join(evidence,'scopes.json'),JSON.stringify({fixtureID:fixture.fixtureID,scopes},null,2)+'\n',{flag:'wx'})
}else if(mode==='baseline'){
 for(const key of ['control','healthy'])for(const route of ['/path','/vcs']){const r=await request(key,route);if(r.status!==200)throw Error('Original baseline failure retained')}
}else if(mode==='cycle-short'){
 const r=await request('combined','/vcs');if(r.status!==null||r.error?.name!=='TimeoutError')throw Error('Short client did not return the expected timeout contract; original observation retained')
}else{
 const r=await request('combined','/vcs',120000);if(r.status!==200||r.body.branch!=='metadata-combined')throw Error('Original complete combined read failed')
}
fs.writeFileSync(path.join(evidence,'summary.json'),JSON.stringify({fixtureID:fixture.fixtureID,mode,records,qualification:'Actual TCP URL/query/response/client deadline records; complete-read120s is diagnostic only, product UI deadline unchanged'},null,2)+'\n',{flag:'wx'})
