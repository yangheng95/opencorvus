import fs from 'node:fs'
import path from 'node:path'
const root=path.resolve('C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/project-metadata-before-01a133'),scratch=path.resolve('.tmp-codex-project-meta-01a133'),fixture=JSON.parse(fs.readFileSync(path.join(root,'prepared-fixture.json'),'utf8')),cases=[]
for(const item of fixture.cases){
 const directory=path.join(root,'stages-'+item.key),summary=JSON.parse(fs.readFileSync(path.join(directory,'summary.json'),'utf8'))
 if(summary.records.length!==5)throw Error('Actual phase count differs')
 const phases=summary.records.map(r=>{
  if(r.error||r.receipt.exitCode!==0||r.joins.length!==3||r.joins.some(j=>j.status!=='fulfilled')||r.terminalObservation.status!=='fulfilled'||r.requests.length!==1)throw Error('Original Git phase incomplete: '+item.key+'/'+r.phase)
  const request=r.requests[0],ready=JSON.parse(fs.readFileSync(path.join(directory,r.phase+'-'+request.request_id+'-ready.json'),'utf8')),settled=JSON.parse(fs.readFileSync(path.join(directory,r.phase+'-'+request.request_id+'-settled.json'),'utf8'))
  if(ready.request_id!==request.request_id||settled.request_id!==request.request_id||ready.target_pid!==r.receipt.pid||settled.target_pid!==ready.target_pid||settled.active_processes!==0||!ready.target_process_instance_id)throw Error('Native original identity/retirement differs')
  return {phase:r.phase,elapsedMs:r.elapsedMs,spawnMs:r.spawned.at.wallMs-r.start.wallMs,afterTerminalMs:r.end.wallMs-r.terminalAt.wallMs,stdoutBytes:r.stdoutBytes,stderrBytes:r.stderrBytes,ready,settled}
 })
 const text=fs.readFileSync(path.join(directory,'status-stdout.bin')).toString(),records=text.split('\0').filter(Boolean),untracked=records.filter(r=>r.startsWith('?? '))
 const native=JSON.parse(fs.readFileSync(path.join(scratch,'native-stage-'+item.key+'/evidence/native-host-settled.json'),'utf8')),parent=JSON.parse(fs.readFileSync(path.join(scratch,'native-stage-'+item.key+'/parent-joined.json'),'utf8'))
 if(native.terminal.exitCode!==0||!native.physicalCompletion||!native.outputDrainComplete||!native.requestCleanupComplete||parent.terminal.code!==0||parent.outputJoins.some(r=>r.status!=='fulfilled'))throw Error('Original Native outer owner incomplete')
 cases.push({key:item.key,phases,status:{records:records.length,untracked:untracked.length,maxPathChars:Math.max(...untracked.map(r=>r.length-3)),first:untracked.slice(0,2),last:untracked.slice(-2)},native,parent})
}
const report={atUtc:new Date().toISOString(),fixtureID:fixture.fixtureID,cases,qualification:'Twenty-five actual Git/Native phase receipts with original ready PID/birth, zero active descendants and three joins; no HTTP, visual or Task/Mission qualification. Two actual files per root are only243B total; recursive aliases multiply status output. Old163-second requests remain separate historical evidence.'}
fs.writeFileSync(path.join(scratch,'stages-root-review.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify(cases.map(c=>({key:c.key,statusMs:c.phases.find(r=>r.phase==='status').elapsedMs,untracked:c.status.untracked,maxPathChars:c.status.maxPathChars,gitStages:c.phases.length,originalNativeExit:c.native.terminal.exitCode}))))
