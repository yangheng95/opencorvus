import fs from 'node:fs'
import path from 'node:path'
import {gzipSync,gunzipSync} from 'node:zlib'
const scratch=path.resolve('.tmp-codex-project-meta-01a133'),fixtureRoot=path.resolve('C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/project-metadata-before-01a133'),target=path.resolve('specs/artifacts/2026-10-14-project-metadata-latency/investigation')
fs.mkdirSync(target)
const files=[]
function retain(source,file,nativeImage=false){const bytes=fs.readFileSync(source),stored=nativeImage?bytes:gzipSync(bytes),name=nativeImage?file:file+'.gz',full=path.join(target,name);fs.mkdirSync(path.dirname(full),{recursive:true});fs.writeFileSync(full,stored,{flag:'wx'});const decoded=nativeImage?fs.readFileSync(full):gunzipSync(fs.readFileSync(full));if(!decoded.equals(bytes))throw Error('Original capture bytes differ: '+source);files.push({source,file:name,originalBytes:bytes.length,gzip:!nativeImage,decodedEqualsOriginalCapture:true})}
function retainDirectory(source,base,nativeImages=false){for(const name of fs.readdirSync(source)){const full=path.join(source,name),stat=fs.lstatSync(full);if(stat.isSymbolicLink())throw Error('Capture source must be direct');if(stat.isDirectory())retainDirectory(full,base+'/'+name,nativeImages);else retain(full,base+'/'+name,nativeImages&&name.endsWith('.jpg'))}}
for(const name of ['prepared-fixture.json','setup-receipts.json'])retain(path.join(fixtureRoot,name),'fixture/'+name)
for(const key of ['control','healthy','self','ancestor','combined'])retainDirectory(path.join(fixtureRoot,'stages-'+key),'stages/'+key)
for(const name of ['native-prepare','native-stage-control','native-stage-healthy','native-stage-self','native-stage-ancestor','native-stage-combined','native-serve']){
 for(const file of ['original-input.json','parent-joined.json','stdout.bin','stderr.bin'])retain(path.join(scratch,name,file),'runtime/'+name+'/'+file)
 retainDirectory(path.join(scratch,name,'evidence'),'runtime/'+name+'/evidence')
}
retain(path.join(scratch,'native-serve/startup.json'),'runtime/native-serve/startup.json');retain(path.join(scratch,'native-serve/runtime/log/dev.log'),'runtime/native-serve/dev.log')
for(const mode of ['register','baseline','cycle-short','cycle-complete'])retainDirectory(path.join(scratch,'http-'+mode),'http/'+mode)
retainDirectory(path.join(scratch,'ui'),'ui',true);retainDirectory(path.join(scratch,'tools'),'tools')
for(const name of ['run-native.mjs','build-ui.mjs','http-probe.mjs','review-stages.mjs','review-runtime.mjs','archive-current.mjs','stages-root-review.json','runtime-root-review.json','ui-build.stdout.bin','ui-build.stderr.bin','ui-build.exit.json','shutdown-input.json','shutdown-response.json'])retain(path.join(scratch,name),'checks/'+name)
fs.writeFileSync(path.join(target,'manifest.json'),JSON.stringify({atUtc:new Date().toISOString(),files,qualification:'Complete exact original capture bytes; gzip is lossless transport only, no mutable-source checksum gate. Private runtime homes, auth/catalog, SQLite database, Git roots and private bin/UI assets are excluded; native JPEGs remain directly viewable. Reproduction and shared audit, not a product fix.'},null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({originals:files.length,originalBytes:files.reduce((n,r)=>n+r.originalBytes,0),nativeImages:files.filter(r=>!r.gzip).length}))
