import fs from 'node:fs'
import path from 'node:path'
import {spawnSync} from 'node:child_process'
import {randomUUID} from 'node:crypto'
const root=path.resolve('C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/project-metadata-before-01a133')
fs.mkdirSync(root)
if(path.resolve(fs.realpathSync(root)).toLowerCase()!==root.toLowerCase())throw Error('Direct new physical root required')
const keys=['control','healthy','self','ancestor','combined'],cases=[],setup=[]
const git=(cwd,args)=>{const r=spawnSync('git',['-c','core.longPaths=true',...args],{cwd,env:process.env,windowsHide:true,timeout:15000,maxBuffer:2*1024*1024});setup.push({cwd,args,status:r.status,signal:r.signal,stdoutBase64:r.stdout.toString('base64'),stderrBase64:r.stderr.toString('base64'),error:r.error?{name:r.error.name,code:r.error.code,message:r.error.message}:null});fs.writeFileSync(path.join(root,'setup-receipts.json'),JSON.stringify(setup,null,2));if(r.status!==0)throw Error('Original fixture Git failure retained');return r.stdout.toString().trim()}
for(const key of keys){
 const directory=path.join(root,key),branch='metadata-'+key
 fs.mkdirSync(directory);fs.mkdirSync(path.join(directory,'data'));fs.mkdirSync(path.join(directory,'aliases'))
 const tracked='METADATA TRACKED '+key+'\r\n',untracked='METADATA DATA '+key+'\r\n'
 fs.writeFileSync(path.join(directory,'README.md'),tracked,{flag:'wx'});fs.writeFileSync(path.join(directory,'data/note.txt'),untracked,{flag:'wx'})
 git(directory,['init','-b',branch]);git(directory,['config','user.name','OpenCorvus Isolated Metadata']);git(directory,['config','user.email','metadata@opencorvus.local']);git(directory,['config','commit.gpgsign','false']);git(directory,['add','README.md']);git(directory,['commit','-m','Owned metadata baseline']);const head=git(directory,['rev-parse','HEAD'])
 const links=[]
 const link=(relative,target)=>{const full=path.join(directory,relative);fs.symlinkSync(target,full,'junction');const stat=fs.lstatSync(full,{bigint:true});links.push({relative,full,target,readlink:fs.readlinkSync(full),realpath:fs.realpathSync(full),entry:{device:String(stat.dev),inode:String(stat.ino),birthtimeNs:String(stat.birthtimeNs),symbolicLink:stat.isSymbolicLink()}})}
 if(key==='healthy')link('alias-data',path.join(directory,'data'))
 if(key==='self'||key==='combined')link('root-link',directory)
 if(key==='ancestor'||key==='combined')link('aliases/root-back',directory)
 cases.push({key,directory,branch,head,links,files:[{path:'README.md',bytesBase64:Buffer.from(tracked).toString('base64')},{path:'data/note.txt',bytesBase64:Buffer.from(untracked).toString('base64')}]})
}
const bytes=cases.reduce((n,c)=>n+c.files.reduce((m,f)=>m+Buffer.from(f.bytesBase64,'base64').length,0),0)
if(bytes>4096)throw Error('Declared literal budget exceeded')
const fixture={schema:'project-metadata.fixture/v1',fixtureID:randomUUID(),root,atUtc:new Date().toISOString(),cases,totalLiteralBytes:bytes,credentialCatalogStaging:'none',modelCallsRequested:'none',qualification:'Five finite physical Git inputs; preparation is not metadata, UI or model acceptance'}
fs.writeFileSync(path.join(root,'prepared-fixture.json'),JSON.stringify(fixture,null,2)+'\n',{flag:'wx'})
console.log(JSON.stringify({root,fixtureID:fixture.fixtureID,cases:cases.length,bytes,links:cases.reduce((n,c)=>n+c.links.length,0)}))
