import fs from 'node:fs'
import path from 'node:path'
import {randomUUID} from 'node:crypto'
import {pathToFileURL} from 'node:url'
const source=(relative:string)=>pathToFileURL(path.resolve(import.meta.dir,'../../packages/opencorvus',relative)).href
const {supervisedHostProcessFacade}=await import(source('src/util/process-facade.ts'))
const {gitProcessArgs,resolveGitTimeoutMs}=await import(source('src/util/git.ts'))
const {ProcessSupervisor}=await import(source('src/shell/process-supervisor.ts'))
const key=process.argv[2],root=path.resolve('C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/project-metadata-before-01a133')
const fixture=JSON.parse(fs.readFileSync(path.join(root,'prepared-fixture.json'),'utf8')),item=fixture.cases.find((c:any)=>c.key===key)
if(!item||fixture.schema!=='project-metadata.fixture/v1'||fixture.root!==root||fixture.credentialCatalogStaging!=='none')throw Error('Exact prepared case required')
const evidence=path.join(root,'stages-'+key);fs.mkdirSync(evidence)
const plans=[{name:'has-head',args:['rev-parse','--verify','--quiet','HEAD'],profile:'fast'},{name:'current-commit',args:['rev-parse','--short','HEAD'],profile:'fast'},{name:'current-branch',args:['symbolic-ref','--quiet','--short','HEAD'],profile:'fast'},{name:'status',args:['status','--porcelain=v1','-z','--branch','--untracked-files=all'],profile:'default'},{name:'remote',args:['remote'],profile:'fast'}]
const stamp=()=>({utc:new Date().toISOString(),wallMs:Date.now(),monotonicNs:process.hrtime.bigint().toString()})
const errorFact=(e:any):any=>({name:e?.name??typeof e,code:e?.code,message:e?.message??String(e),stack:e?.stack,cause:e?.cause?errorFact(e.cause):undefined})
const records:any[]=[]
for(const plan of plans){
 const occurrence='metadata-'+key+'-'+plan.name+'-'+randomUUID(),start=stamp(),command=gitProcessArgs(plan.args),inactivityTimeoutMs=resolveGitTimeoutMs({timeoutProfile:plan.profile}),requests:any[]=[]
 let spawned:any,joins:Promise<PromiseSettledResult<unknown>[]>|undefined,result:any,error:any,terminalAt:any,terminalObservation:Promise<void>|undefined
 const publish=(name:string,value:any)=>fs.writeFileSync(path.join(evidence,plan.name+'-'+name+'.json'),JSON.stringify(value,null,2)+'\n',{flag:'wx'})
 const copyMarker=(request:any,name:string,field:string)=>{try{const bytes=fs.readFileSync(request[field]);fs.writeFileSync(path.join(evidence,plan.name+'-'+request.request_id+'-'+name+'.json'),bytes,{flag:'wx'});return {name,state:'captured',bytes:bytes.length}}catch(e){return {name,state:'unavailable',error:errorFact(e)}}}
 const restore=ProcessSupervisor.setWindowsRequestObserverForTest((request:any)=>{const capture={...request};requests.push(capture);publish('request-'+requests.length,capture)})
 publish('input',{fixtureID:fixture.fixtureID,key,directory:item.directory,plan,command,occurrence,start,inactivityTimeoutMs,maxOutputBytes:4194304,qualification:'Direct current production Host Facade and Git argv/profile; not the hostGit wrapper, API or UI acceptance'})
 console.log(JSON.stringify({key,phase:plan.name,event:'admitted',at:start.utc}))
 try{
  result=await supervisedHostProcessFacade('process:run-host',false).run({command:{executable:command[0],args:command.slice(1)},cwd:item.directory,env:process.env,stdin:'ignore',stdout:'pipe',stderr:'pipe',ownership:'owned_tree',occurrenceID:occurrence,nothrow:true,inactivityTimeoutMs,maxOutputBytes:4194304,
   async onSpawned(handle:any){
    spawned={pid:handle.pid,occurrenceID:handle.occurrenceID,at:stamp(),ready:requests.map(r=>copyMarker(r,'ready','ready_file'))}
    joins=Promise.allSettled([handle.terminal,handle.settled,handle.outputSettled])
    terminalObservation=handle.terminal.then(()=>{terminalAt=stamp();publish('terminal-marker-observation',{at:terminalAt,markers:requests.map(r=>copyMarker(r,'settled','settled_file'))})})
    void terminalObservation.catch(()=>undefined)
    publish('spawned',spawned)
   }})
 }catch(e:any){error=e;result=e?.result}
 finally{restore()}
 const outcomes=joins?await joins:undefined,observation=terminalObservation?(await Promise.allSettled([terminalObservation]))[0]:undefined,end=stamp()
 if(result){fs.writeFileSync(path.join(evidence,plan.name+'-stdout.bin'),result.stdout,{flag:'wx'});fs.writeFileSync(path.join(evidence,plan.name+'-stderr.bin'),result.stderr,{flag:'wx'})}
 const record={fixtureID:fixture.fixtureID,key,phase:plan.name,start,end,elapsedMs:end.wallMs-start.wallMs,spawned,terminalAt,receipt:result?.receipt,stdoutBytes:result?.stdout?.length,stderrBytes:result?.stderr?.length,joins:outcomes?.map(r=>r.status==='fulfilled'?{status:r.status,value:r.value}:{status:r.status,error:errorFact(r.reason)}),terminalObservation:observation?.status==='fulfilled'?{status:observation.status}:observation?.status==='rejected'?{status:observation.status,error:errorFact(observation.reason)}:null,requests,error:error?errorFact(error):null,qualification:'Original handle joins and complete facade result preserved; original markers unavailable remain unknown, never synthesized'}
 publish('result',record);records.push(record)
 console.log(JSON.stringify({key,phase:plan.name,event:'settled',elapsedMs:record.elapsedMs,receipt:record.receipt,error:record.error}))
 if(error||!outcomes?.every(r=>r.status==='fulfilled')||observation?.status!=='fulfilled'||result?.receipt?.exitCode!==0)throw Error('Original first stage failure retained: '+plan.name)
 if(plan.name==='has-head'&&Buffer.from(result.stdout).toString().trim()!==item.head)throw Error('Actual HEAD identity differs')
 if(plan.name==='current-commit'&&!item.head.startsWith(Buffer.from(result.stdout).toString().trim()))throw Error('Actual short commit differs')
 if(plan.name==='current-branch'&&Buffer.from(result.stdout).toString().trim()!==item.branch)throw Error('Actual branch differs')
}
fs.writeFileSync(path.join(evidence,'summary.json'),JSON.stringify({fixtureID:fixture.fixtureID,key,records,qualification:'Five actual local Git/Native phase receipts; no HTTP/UI/Task/Mission acceptance claimed'},null,2)+'\n',{flag:'wx'})
