import fs from 'node:fs'
import path from 'node:path'
const scratch=path.resolve('.tmp-codex-project-meta-01a133')
let value=fs.readFileSync(path.join(scratch,'build-ui.mjs'),'utf8')
for(const [before,after] of [["metadata-ui-bundle/bin","source-ui-bundle/bin"],["'ui-build.","'source-ui-build."]]){
 if(!value.includes(before))throw Error('Original build seam missing')
 value=value.replaceAll(before,after)
}
fs.writeFileSync(path.join(scratch,'build-source-ui.mjs'),value,{flag:'wx'})
let runner=fs.readFileSync(path.join(scratch,'run-native.mjs'),'utf8')
for(const [before,after] of [["'native-serve'","'native-source-serve'"],["metadata-ui-bundle/bin/bun.exe","source-ui-bundle/bin/bun.exe"],["'18460'","'18462'"]]){
 if(runner.split(before).length!==2)throw Error('Original service seam missing')
 runner=runner.replace(before,after)
}
fs.writeFileSync(path.join(scratch,'run-source-serve.mjs'),runner,{flag:'wx'})
