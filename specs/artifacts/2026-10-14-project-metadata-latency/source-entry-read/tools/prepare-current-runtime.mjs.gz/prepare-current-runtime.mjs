import fs from 'node:fs'
import path from 'node:path'
import {spawnSync} from 'node:child_process'
const scratch=path.resolve('.tmp-codex-project-meta-01a133'),source=path.resolve('.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64/bun.exe'),destination=path.join(scratch,'source-ui-bundle/bin/bun.exe')
const before=spawnSync(destination,['--version'],{windowsHide:true,encoding:'utf8'}),check=spawnSync(source,['--version'],{windowsHide:true,encoding:'utf8'})
if(check.status!==0||check.stdout.trim()!=='1.4.0')throw Error('Required actual Bun 1.4 runtime not available')
fs.copyFileSync(source,destination)
const after=spawnSync(destination,['--version'],{windowsHide:true,encoding:'utf8'})
fs.writeFileSync(path.join(scratch,'source-runtime-version.json'),JSON.stringify({source,destination,before:{code:before.status,stdout:before.stdout,stderr:before.stderr},after:{code:after.status,stdout:after.stdout,stderr:after.stderr},qualification:'Private validation executable repair, no user process or historical receipt changed'},null,2)+'\n',{flag:'wx'})
if(after.status!==0||after.stdout.trim()!=='1.4.0')throw Error('Private executable version differs')
let runner=fs.readFileSync(path.join(scratch,'run-source-consumers.mjs'),'utf8')
for(const [before,after] of [["'native-source-consumers'","'native-source-consumers-r3'"],["browse-ui-bundle/bin/bun.exe","../opencorvus/.tmp-codex-project-meta-01a133/source-ui-bundle/bin/bun.exe"]]){
 if(runner.split(before).length!==2)throw Error('Original checker seam missing')
 runner=runner.replace(before,after)
}
// Replace the complete old path, not a shell-computed executable.
runner=runner.replace(".tmp-codex-directory-target-01a133/../opencorvus/.tmp-codex-project-meta-01a133/source-ui-bundle/bin/bun.exe",".tmp-codex-project-meta-01a133/source-ui-bundle/bin/bun.exe")
fs.writeFileSync(path.join(scratch,'run-source-consumers-r3.mjs'),runner,{flag:'wx'})
