import fs from 'node:fs'
import path from 'node:path'
const scratch=path.resolve('.tmp-codex-project-meta-01a133')
let value=fs.readFileSync(path.join(scratch,'run-source-consumers-r3.mjs'),'utf8')
const edits=[["'native-source-consumers-r3'","'native-source-consumers-r4'"],["const executionCapMs=", "environment.PATH=path.dirname(bun)+path.delimiter+environment.PATH\nconst executionCapMs="]]
for(const [before,after] of edits){if(value.split(before).length!==2)throw Error('Original runtime seam missing');value=value.replace(before,after)}
fs.writeFileSync(path.join(scratch,'run-source-consumers-r4.mjs'),value,{flag:'wx'})
fs.writeFileSync(path.join(scratch,'runtime-r4-changes.json'),JSON.stringify({edits,qualification:'Package test script child bun inherits the verified private 1.4 executable via PATH. r3 child test output was 1.3.14, explicitly unqualified for 1.4.'},null,2)+'\n',{flag:'wx'})
