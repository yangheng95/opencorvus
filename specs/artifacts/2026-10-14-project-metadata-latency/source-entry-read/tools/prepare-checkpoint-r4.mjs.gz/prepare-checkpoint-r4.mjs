import fs from 'node:fs'
import path from 'node:path'
import {spawnSync} from 'node:child_process'
const scratch=path.resolve('.tmp-codex-project-meta-01a133'),value=fs.readFileSync(path.join(scratch,'run-source-checkpoint.mjs'),'utf8')
if(value.split("'native-source-checkpoint'").length!==2)throw Error('Original namespace seam missing')
fs.writeFileSync(path.join(scratch,'run-source-checkpoint-r4.mjs'),value.replace("'native-source-checkpoint'","'native-source-checkpoint-r4'"),{flag:'wx'})
const executable=path.join(scratch,'source-ui-bundle/bin/bun.exe'),args=[path.join(scratch,'expect-identity-probe.ts')],r=spawnSync(executable,args,{windowsHide:true})
fs.writeFileSync(path.join(scratch,'expect-identity-probe-stdout.bin'),r.stdout,{flag:'wx'});fs.writeFileSync(path.join(scratch,'expect-identity-probe-stderr.bin'),r.stderr,{flag:'wx'});fs.writeFileSync(path.join(scratch,'expect-identity-probe-result.json'),JSON.stringify({executable,args,code:r.status,qualification:'Actual local matcher mutates the inspected nested commit value; checker reads original identities and uses primitive assertions thereafter'},null,2)+'\n',{flag:'wx'})
if(r.status!==0)throw Error('Original matcher probe failed')
