import fs from 'node:fs'
import path from 'node:path'
const scratch=path.resolve('.tmp-codex-project-meta-01a133')
let value=fs.readFileSync(path.join(scratch,'run-source-consumers-r4.mjs'),'utf8')
for(const [before,after] of [["'native-source-consumers-r4'","'native-source-breadth'"],["'test/engine-git-batched-raw-import.test.ts'","'test/engine-git-batched-raw-import.test.ts','test/engine-git-batched-scale.test.ts'"]]){
 if(value.split(before).length!==2)throw Error('Original checker seam missing')
 value=value.replace(before,after)
}
fs.writeFileSync(path.join(scratch,'run-source-breadth.mjs'),value,{flag:'wx'})
let server=fs.readFileSync(path.join(scratch,'run-source-serve.mjs'),'utf8')
for(const [before,after] of [["'native-source-serve'","'native-source-serve-final'"],["'18462'","'18463'"]]){
 if(server.split(before).length!==2)throw Error('Original service seam missing')
 server=server.replace(before,after)
}
fs.writeFileSync(path.join(scratch,'run-source-serve-final.mjs'),server,{flag:'wx'})
let http=fs.readFileSync(path.join(scratch,'source-http.mjs'),'utf8').replace("'source-http'","'source-http-final'").replace('127.0.0.1:18462','127.0.0.1:18463')
fs.writeFileSync(path.join(scratch,'source-http-final.mjs'),http,{flag:'wx'})
