import fs from 'node:fs'
import path from 'node:path'
import {pathToFileURL} from 'node:url'
const root=path.resolve('C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/project-metadata-before-01a133'),fixture=JSON.parse(fs.readFileSync(path.join(root,'prepared-fixture.json'),'utf8')),evidence=path.resolve(process.argv[2])
fs.mkdirSync(evidence)
const {hostGit}=await import(pathToFileURL(path.resolve(import.meta.dir,'../../packages/opencorvus/src/util/git.ts')).href)
const plans=[{name:'cached',args:['ls-files','--cached','-z','--','.']},{name:'directory',args:['ls-files','--others','--exclude-standard','--directory','-z','--','.']},{name:'literal-data',args:['ls-files','--others','--exclude-standard','--directory','-z','--',':(literal)data/note.txt']},{name:'literal-alias-boundary',args:['ls-files','--others','--exclude-standard','--directory','-z','--',':(literal)aliases/root-back']}]
const records=[]
for(const key of ['control','healthy','combined']){
 const item=fixture.cases.find((c:any)=>c.key===key)
 for(const plan of plans){
  const prefix=key+'-'+plan.name,start={utc:new Date().toISOString(),wallMs:Date.now()},input={fixtureID:fixture.fixtureID,key,directory:item.directory,plan,start,timeoutProfile:'default'}
  fs.writeFileSync(path.join(evidence,prefix+'-input.json'),JSON.stringify(input,null,2)+'\n',{flag:'wx'})
  console.log(JSON.stringify({key,phase:plan.name,event:'admitted'}))
  const result=await hostGit(plan.args,{cwd:item.directory,timeoutProfile:'default'}),end=Date.now()
  fs.writeFileSync(path.join(evidence,prefix+'-stdout.bin'),result.stdout,{flag:'wx'});fs.writeFileSync(path.join(evidence,prefix+'-stderr.bin'),result.stderr,{flag:'wx'})
  const record={...input,endUtc:new Date().toISOString(),elapsedMs:end-start.wallMs,code:result.exitCode,stdoutBytes:result.stdout.length,stderrBytes:result.stderr.length,paths:result.stdout.toString().split('\0').filter(Boolean)}
  fs.writeFileSync(path.join(evidence,prefix+'-result.json'),JSON.stringify(record,null,2)+'\n',{flag:'wx'});records.push(record);console.log(JSON.stringify({key,phase:plan.name,code:record.code,elapsedMs:record.elapsedMs,paths:record.paths}))
  if(result.exitCode!==0)throw Error('Original directory boundary qualification failed: '+prefix)
 }
}
fs.writeFileSync(path.join(evidence,'summary.json'),JSON.stringify({fixtureID:fixture.fixtureID,records,qualification:'Actual production hostGit directory boundary protocol only; aggregates are not a completed per-file replacement, no product or UI fix'},null,2)+'\n',{flag:'wx'})
