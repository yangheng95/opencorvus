import fs from 'node:fs'
import path from 'node:path'
import {pathToFileURL} from 'node:url'
const evidence=path.resolve(process.argv[2]),root=path.resolve('C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/project-metadata-before-01a133/combined')
fs.mkdirSync(evidence)
const source=(name:string)=>pathToFileURL(path.resolve(import.meta.dir,'../../packages/opencorvus/src/util',name)).href
const {hostGit,gitProcessArgs}=await import(source('git.ts'))
const {Process}=await import(source('process.ts'))
const records:any[]=[]
for(const relative of ['aliases','data','.opencorvus']){
 const args=['ls-files','--others','--exclude-standard','--directory','-z','--',':(top,glob)'+relative+'/*'],start=Date.now(),result=await hostGit(args,{cwd:root,timeoutProfile:'default'})
 fs.writeFileSync(path.join(evidence,relative+'-stdout.bin'),result.stdout,{flag:'wx'});fs.writeFileSync(path.join(evidence,relative+'-stderr.bin'),result.stderr,{flag:'wx'})
 const record={relative,args,start,end:Date.now(),code:result.exitCode,paths:result.stdout.toString().split('\0').filter(Boolean)};records.push(record);console.log(JSON.stringify(record));if(result.exitCode!==0)throw Error('Original glob query failed')
}
const paths=['README.md','data/note.txt','aliases/','aliases/root-back','root-link','.opencorvus/.r/','missing-marker'],bytes=Buffer.from(paths.join('\0')+'\0'),args=['check-ignore','--no-index','--verbose','--non-matching','-z','--stdin'],start=Date.now()
async function* input(){yield bytes}
fs.writeFileSync(path.join(evidence,'check-ignore-input.bin'),bytes,{flag:'wx'})
const command=gitProcessArgs(args),result=await Process.runHost(command,{cwd:root,stdin:'pipe',input:input(),nothrow:true,inactivityTimeoutMs:15000})
fs.writeFileSync(path.join(evidence,'check-ignore-stdout.bin'),result.stdout,{flag:'wx'});fs.writeFileSync(path.join(evidence,'check-ignore-stderr.bin'),result.stderr,{flag:'wx'})
const record={args,paths,start,end:Date.now(),code:result.code,fields:result.stdout.toString().split('\0')};records.push(record);console.log(JSON.stringify(record));if(![0,1].includes(result.code))throw Error('Original ignore protocol error')
fs.writeFileSync(path.join(evidence,'summary.json'),JSON.stringify({records,qualification:'Actual Git direct-child glob and NUL stdin ignore protocol; no product change or UI acceptance'},null,2)+'\n',{flag:'wx'})
