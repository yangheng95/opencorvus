import fs from 'node:fs'
import path from 'node:path'
const scratch=path.resolve('.tmp-codex-project-meta-01a133')
let value=fs.readFileSync(path.join(scratch,'run-source-checks.mjs'),'utf8')
for(const [before,after] of [["'source-checks'","'source-final-checks'"],["'--write',...files","'--write',...files.filter(file=>/git-source-(paths|consumers)\\.test\\.ts$|git-source-paths\\.ts$/.test(file))"],["run('docs',path.join(scratch,'source-ui-bundle/bin/bun.exe'),['run','docs:check'],root),","run('docs',path.join(scratch,'source-ui-bundle/bin/bun.exe'),['run','docs:check'],root),\n run('architecture',path.join(scratch,'source-ui-bundle/bin/bun.exe'),['run','check:architecture-index'],root),\n run('module',path.join(scratch,'source-ui-bundle/bin/bun.exe'),['run','check:module-topology'],root),"]]){
 if(value.split(before).length!==2)throw Error('Exact checker seam absent')
 value=value.replace(before,after)
}
fs.writeFileSync(path.join(scratch,'run-source-final-checks.mjs'),value,{flag:'wx'})
let shutdown=fs.readFileSync(path.join(scratch,'shutdown-source.mjs'),'utf8')
if(shutdown.split("'native-source-serve'").length!==2)throw Error('Exact retirement seam absent')
shutdown=shutdown.replace("'native-source-serve'","'native-source-serve-final'").replaceAll('18462','18463').replaceAll("'source-shutdown-","'source-final-shutdown-")
fs.writeFileSync(path.join(scratch,'shutdown-source-final.mjs'),shutdown,{flag:'wx'})
