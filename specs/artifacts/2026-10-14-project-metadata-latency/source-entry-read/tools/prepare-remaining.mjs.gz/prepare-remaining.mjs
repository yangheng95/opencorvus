import fs from 'node:fs'
import path from 'node:path'
const scratch=path.resolve('.tmp-codex-project-meta-01a133')
let value=fs.readFileSync(path.join(scratch,'run-source-checkpoint.mjs'),'utf8')
for(const [before,after] of [["'native-source-checkpoint'","'native-source-remaining'"],["['--cwd',path.resolve('packages/opencorvus'),'test','test/git-source-consumers.test.ts']","[path.join(scratch,'tools/source-remaining.ts'),path.join(root,'queries')]"]]){
 if(value.split(before).length!==2)throw Error('Original checker seam missing')
 value=value.replace(before,after)
}
value=value.replaceAll("'source-tests'","'source-remaining'")
fs.writeFileSync(path.join(scratch,'run-source-remaining.mjs'),value,{flag:'wx'})
