import fs from 'node:fs'
import path from 'node:path'
const scratch=path.resolve('.tmp-codex-project-meta-01a133'),fixture=JSON.parse(fs.readFileSync('C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/project-metadata-before-01a133/prepared-fixture.json','utf8')),evidence=path.join(scratch,'source-http-final'),records=[]
fs.mkdirSync(evidence)
async function request(key,route,method='GET',body){
 const item=fixture.cases.find(c=>c.key===key),url=new URL(route,'http://127.0.0.1:18463');url.searchParams.set('directory',item.directory)
 const number=records.length+1,record={number,key,url:String(url),method,requestBody:body,timeoutMs:15000,startUtc:new Date().toISOString(),startMs:Date.now()};records.push(record)
 fs.writeFileSync(path.join(evidence,number+'-input.json'),JSON.stringify(record,null,2)+'\n',{flag:'wx'})
 try{const response=await fetch(url,{method,headers:{'content-type':'application/json'},body:body===undefined?undefined:JSON.stringify(body),signal:AbortSignal.timeout(15000)});const bytes=Buffer.from(await response.arrayBuffer());fs.writeFileSync(path.join(evidence,number+'-body.bin'),bytes,{flag:'wx'});Object.assign(record,{status:response.status,body:JSON.parse(bytes.toString()),headers:Object.fromEntries(response.headers),error:null})}
 catch(error){Object.assign(record,{status:null,error:{name:error.name,message:error.message,stack:error.stack}})}
 Object.assign(record,{endUtc:new Date().toISOString(),elapsedMs:Date.now()-record.startMs});fs.writeFileSync(path.join(evidence,number+'-result.json'),JSON.stringify(record,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({number,key,route,status:record.status,elapsedMs:record.elapsedMs,error:record.error?.name}));return record
}
const scopes=[]
for(const key of ['control','combined']){
 const project=await request(key,'/project/current'),chat=project.status===200?await request(key,'/coding/chat/session','POST',{}):null
 if(project.status!==200||chat?.status!==201||chat.body.session.projectID!==project.body.id)throw Error('Real empty Chat registration failed')
 scopes.push({key,projectID:project.body.id,sessionID:chat.body.session.id,directory:fixture.cases.find(c=>c.key===key).directory})
}
fs.writeFileSync(path.join(evidence,'scopes.json'),JSON.stringify({fixtureID:fixture.fixtureID,scopes},null,2)+'\n',{flag:'wx'})
const counts={control:4,healthy:2,self:2,ancestor:2,combined:6}
for(const key of Object.keys(counts)){
 const record=await request(key,'/vcs')
 if(record.status!==200||record.body.branch!=='metadata-'+key||record.body.untracked!==counts[key]||record.body.dirty!==true)throw Error('Declared physical VCS output differs: '+key)
}
for(let round=0;round<2;round++){
 const batch=await Promise.all(['combined','control','combined','control'].map(key=>request(key,'/vcs')))
 for(const record of batch)if(record.status!==200||record.body.branch!=='metadata-'+record.key||record.body.untracked!==counts[record.key])throw Error('Concurrent VCS output differs')
}
fs.writeFileSync(path.join(evidence,'summary.json'),JSON.stringify({fixtureID:fixture.fixtureID,records,qualification:'Real current development server TCP reads, original product 15 second deadline, fixed physical counts, sequential and concurrent Projects; no model/message creation'},null,2)+'\n',{flag:'wx'})
