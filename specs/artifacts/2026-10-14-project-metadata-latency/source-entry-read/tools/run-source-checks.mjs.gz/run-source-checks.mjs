import fs from 'node:fs'
import path from 'node:path'
import {spawn} from 'node:child_process'
const root=path.resolve('.'),scratch=path.resolve('.tmp-codex-project-meta-01a133'),dir=path.join(scratch,'source-checks');fs.mkdirSync(dir)
const files=['src/util/git.ts','src/util/filesystem.ts','src/project/project.ts','src/util/git-source-paths.ts','src/engine/git-process.ts','src/engine/git.ts','src/execution-capsule/tree-digest.ts','src/project/vcs.ts','src/file/index.ts','src/engine/task-project-archive.ts','test/git-source-paths.test.ts','test/git-source-consumers.test.ts'].map(name=>path.join(root,'packages/opencorvus',name))
const environment={...process.env,PATH:path.join(scratch,'source-ui-bundle/bin')+path.delimiter+process.env.PATH}
async function run(key,executable,args,cwd){
 const start=new Date().toISOString(),child=spawn(executable,args,{cwd,env:environment,windowsHide:true,stdio:['ignore','pipe','pipe']})
 const read=async(stream)=>{const chunks=[];for await(const chunk of stream)chunks.push(chunk);return Buffer.concat(chunks)}
 const [terminal,stdout,stderr]=await Promise.all([new Promise(resolve=>child.once('close',(code,signal)=>resolve({code,signal}))),read(child.stdout),read(child.stderr)])
 fs.writeFileSync(path.join(dir,key+'-stdout.bin'),stdout,{flag:'wx'});fs.writeFileSync(path.join(dir,key+'-stderr.bin'),stderr,{flag:'wx'})
 const result={key,executable,args,cwd,start,end:new Date().toISOString(),terminal,stdoutBytes:stdout.length,stderrBytes:stderr.length};fs.writeFileSync(path.join(dir,key+'-result.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(result));return terminal.code
}
if(await run('format',process.execPath,[path.join(root,'node_modules/prettier/bin/prettier.cjs'),'--write',...files],root)!==0)throw Error('Actual formatter failed')
const results=await Promise.all([
 run('typecheck',process.execPath,[path.join(root,'packages/opencorvus/node_modules/typescript/bin/tsc'),'--noEmit'],path.join(root,'packages/opencorvus')),
 run('docs',path.join(scratch,'source-ui-bundle/bin/bun.exe'),['run','docs:check'],root),
])
if(results.some(value=>value!==0))process.exitCode=1
