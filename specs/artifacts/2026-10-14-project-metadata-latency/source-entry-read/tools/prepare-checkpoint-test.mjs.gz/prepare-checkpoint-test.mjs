import fs from 'node:fs'
import path from 'node:path'
const scratch=path.resolve('.tmp-codex-project-meta-01a133')
let value=fs.readFileSync(path.join(scratch,'run-source-consumers-r4.mjs'),'utf8')
for(const [before,after] of [["'native-source-consumers-r4'","'native-source-checkpoint'"],["'test/git-source-paths.test.ts','test/git-source-consumers.test.ts','test/server/vcs-read-identity.test.ts','test/execution-capsule-source-tree.test.ts','test/engine-git-batched-raw-import.test.ts'","'test/git-source-consumers.test.ts'"]]){
 if(value.split(before).length!==2)throw Error('Original checker seam missing')
 value=value.replace(before,after)
}
fs.writeFileSync(path.join(scratch,'run-source-checkpoint.mjs'),value,{flag:'wx'})
