import fs from 'node:fs'
import path from 'node:path'
const scratch=path.resolve('.tmp-codex-project-meta-01a133')
let value=fs.readFileSync(path.join(scratch,'run-source-tests.mjs'),'utf8')
const from="'native-source-tests'",to="'native-source-tests-r2'"
if(value.split(from).length!==2)throw Error('Original isolated namespace seam missing')
value=value.replace(from,to)
fs.writeFileSync(path.join(scratch,'run-source-tests-r2.mjs'),value,{flag:'wx'})
