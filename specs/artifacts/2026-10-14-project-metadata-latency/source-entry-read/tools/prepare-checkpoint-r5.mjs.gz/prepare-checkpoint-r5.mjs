import fs from 'node:fs'
import path from 'node:path'
const scratch=path.resolve('.tmp-codex-project-meta-01a133'),value=fs.readFileSync(path.join(scratch,'run-source-checkpoint.mjs'),'utf8')
if(value.split("'native-source-checkpoint'").length!==2)throw Error('Original namespace seam missing')
fs.writeFileSync(path.join(scratch,'run-source-checkpoint-r5.mjs'),value.replace("'native-source-checkpoint'","'native-source-checkpoint-r5'"),{flag:'wx'})
