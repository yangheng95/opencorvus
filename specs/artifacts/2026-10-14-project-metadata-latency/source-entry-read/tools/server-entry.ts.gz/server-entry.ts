import fs from 'node:fs'
import path from 'node:path'
import {pathToFileURL} from 'node:url'
const evidence=process.argv[2]
if(!evidence||!path.isAbsolute(evidence))throw Error('Explicit owned diagnostic directory required')
process.argv.splice(2,1)
const packageRoot=path.resolve(import.meta.dir,'../../packages/opencorvus'),source=(relative:string)=>pathToFileURL(path.join(packageRoot,relative)).href
fs.mkdirSync(evidence)
const {ProcessSupervisor}=await import(source('src/shell/process-supervisor.ts'))
let ordinal=0
ProcessSupervisor.setWindowsRequestObserverForTest((request:any)=>{
 const number=++ordinal,directory=path.join(evidence,String(number).padStart(4,'0'));fs.mkdirSync(directory)
 fs.writeFileSync(path.join(directory,'request.json'),JSON.stringify({atUtc:new Date().toISOString(),monotonicNs:process.hrtime.bigint().toString(),actualRequest:request,actualCallStack:new Error('Transparent original request observation').stack},null,2)+'\n',{flag:'wx'})
 const found=new Set<string>(),failures:any[]=[]
 const capture=()=>{
  for(const [name,field] of [['ready','ready_file'],['settled','settled_file'],['launch-failed','launch_failed_file']]){
   if(found.has(name))continue
   try{const bytes=fs.readFileSync(request[field]);fs.writeFileSync(path.join(directory,name+'.json'),bytes,{flag:'wx'});found.add(name);fs.writeFileSync(path.join(directory,'observations.json'),JSON.stringify({atUtc:new Date().toISOString(),captured:[...found],failures},null,2)+'\n')}
   catch(error:any){if(error.code!=='ENOENT') {failures.push({name,error:{name:error.name,code:error.code,message:error.message}});fs.writeFileSync(path.join(directory,'capture-errors.json'),JSON.stringify(failures,null,2)+'\n')}}
  }
  if(found.has('settled')||found.has('launch-failed'))watcher.close()
 }
 const watcher=fs.watch(path.dirname(request.ready_file),capture);watcher.unref();watcher.on('error',(error:any)=>{failures.push({boundary:'watch',error:{name:error.name,code:error.code,message:error.message}});fs.writeFileSync(path.join(directory,'capture-errors.json'),JSON.stringify(failures,null,2)+'\n')})
 capture()
})
await import(source('src/index.ts'))
