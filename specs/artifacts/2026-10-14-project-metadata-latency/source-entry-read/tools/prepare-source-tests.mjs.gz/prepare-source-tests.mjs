import fs from 'node:fs'
import path from 'node:path'
const scratch=path.resolve('.tmp-codex-project-meta-01a133')
let value=fs.readFileSync(path.join(scratch,'run-native.mjs'),'utf8')
const edits=[
  ["if(mode!=='prepare'", "if(mode!=='source-tests'&&mode!=='prepare'"],
  ["path.join(scratch,mode==='prepare'?", "path.join(scratch,mode==='source-tests'?'native-source-tests':mode==='prepare'?"],
  ["const targetArgs=mode==='semantic-query'?", "const targetArgs=mode==='source-tests'?['--cwd',path.resolve('packages/opencorvus'),'test','test/git-source-paths.test.ts']:mode==='semantic-query'?"],
]
for(const [before,after] of edits){if(value.split(before).length!==2)throw Error('Exact source seam missing: '+before);value=value.replace(before,after)}
fs.writeFileSync(path.join(scratch,'run-source-tests.mjs'),value,{flag:'wx'})
fs.writeFileSync(path.join(scratch,'source-test-runner-changes.json'),JSON.stringify({source:'run-native.mjs',destination:'run-source-tests.mjs',edits,qualification:'Same original Native Host joins and supervised production runtime; real backend tests only'},null,2)+'\n',{flag:'wx'})
