import { expect } from "bun:test"
const actual = { task: { metadata: { git: { baseline: { commit: "literal-original-commit" } } } } }
console.log(JSON.stringify({ boundary: "before", actual }))
expect(actual).toMatchObject({ task: { metadata: { git: { baseline: { commit: expect.any(String) } } } } })
console.log(JSON.stringify({ boundary: "after", actual, type: typeof actual.task.metadata.git.baseline.commit }))
