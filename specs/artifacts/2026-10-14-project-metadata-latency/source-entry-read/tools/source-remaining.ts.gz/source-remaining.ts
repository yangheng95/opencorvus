import fs from 'node:fs'
import path from 'node:path'
import {pathToFileURL} from 'node:url'
const evidence=path.resolve(process.argv[2]),fixture=JSON.parse(fs.readFileSync('C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/project-metadata-before-01a133/prepared-fixture.json','utf8'))
fs.mkdirSync(evidence)
const {hostGit}=await import(pathToFileURL(path.resolve(import.meta.dir,'../../packages/opencorvus/src/util/git.ts')).href)
const records:any[]=[]
for(const key of ['control','healthy','self','ancestor','combined']){
 const item=fixture.cases.find((value:any)=>value.key===key),args=['status','--porcelain=v1','-z'],start=Date.now(),result=await hostGit(args,{cwd:item.directory,timeoutProfile:'default'})
 fs.writeFileSync(path.join(evidence,key+'-stdout.bin'),result.stdout,{flag:'wx'});fs.writeFileSync(path.join(evidence,key+'-stderr.bin'),result.stderr,{flag:'wx'})
 const record={key,args,start,end:Date.now(),code:result.exitCode,records:result.stdout.toString().split('\0').filter(Boolean)};records.push(record);console.log(JSON.stringify(record));if(result.exitCode!==0)throw Error('Original normal status failed')
}
const root=fixture.cases.find((value:any)=>value.key==='combined').directory,index=path.join(root,'.git/index'),before=fs.readFileSync(index),args=['add','--dry-run','--all','--','.'],start=Date.now(),result=await hostGit(args,{cwd:root,timeoutProfile:'default'}),after=fs.readFileSync(index)
fs.writeFileSync(path.join(evidence,'dry-run-stdout.bin'),result.stdout,{flag:'wx'});fs.writeFileSync(path.join(evidence,'dry-run-stderr.bin'),result.stderr,{flag:'wx'});fs.writeFileSync(path.join(evidence,'index-before.bin'),before,{flag:'wx'});fs.writeFileSync(path.join(evidence,'index-after.bin'),after,{flag:'wx'})
const writeRecord={key:'combined',args,start,end:Date.now(),code:result.exitCode,stdoutBytes:result.stdout.length,stderrBytes:result.stderr.length,indexBytesEqual:before.equals(after)};records.push(writeRecord);console.log(JSON.stringify(writeRecord))
fs.writeFileSync(path.join(evidence,'summary.json'),JSON.stringify({records,qualification:'Real normal dirty readers and native Git dry-run on preserved finite input. Dry-run is diagnostic, not a successful write or an LLM acceptance.'},null,2)+'\n',{flag:'wx'});if(!before.equals(after))throw Error('Diagnostic Git dry-run changed the original index')
