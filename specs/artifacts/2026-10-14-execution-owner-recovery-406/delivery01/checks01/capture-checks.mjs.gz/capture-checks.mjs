import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import {gzipSync,gunzipSync} from 'node:zlib'
const root='.tmp-task-question-recovery-406',out='specs/artifacts/2026-10-14-execution-owner-recovery-406/delivery01/checks01'
fs.mkdirSync(out)
const files=[]
for(const stage of ['docs01','architecture01','owners01','fetch-before01','merge-before01'])
 for(const name of ['owner-start.json','owner.json','stdout.log','stderr.log'])files.push({source:`delivery-commands/${stage}/${name}`,destination:`${stage}/${name}.gz`})
for(const name of ['run-delivery-command.ts','commit-scope.mjs','capture-checks.mjs','final-scoped.stat','final-scope-review.json'])files.push({source:name,destination:name+'.gz'})
for(const row of files){
 const raw=fs.readFileSync(path.join(root,row.source)),target=path.join(out,row.destination)
 fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,gzipSync(raw),{flag:'wx'})
 assert(gunzipSync(fs.readFileSync(target)).equals(raw));row.originalBytes=raw.length;row.directBytesIdentical=true
}
fs.writeFileSync(path.join(out,'manifest.json'),JSON.stringify({capturedAt:Date.now(),files,boundary:'Original command/physical/output/request receipts; identity preservation only, no source-hash gate'},null,2),{flag:'wx'})
console.log(JSON.stringify({files:files.length,out}))
