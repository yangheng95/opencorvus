import fs from 'node:fs/promises'
import path from 'node:path'
import { NodeProcess } from '../packages/util/src/process-node'
import { expectedTestProcessSupervisor } from '../packages/opencorvus/script/test-process-supervisor'
const startedAt=Date.now(),deadlineAt=startedAt+600000
const [stage,kind,...args]=process.argv.slice(2)
if(!stage||!/^[a-z0-9-]+$/.test(stage)||!['bun','git','node'].includes(kind!))throw Error('Explicit owned delivery command required')
const scope=path.resolve(import.meta.dir,'delivery-commands',stage)
await fs.mkdir(scope,{recursive:false})
const supervisor=expectedTestProcessSupervisor()
if(!supervisor)throw Error('Original native supervisor required')
process.env.OPENCORVUS_PROCESS_SUPERVISOR=supervisor
const executable=kind==='bun'?process.execPath:kind==='node'?'C:/Program Files/nodejs/node.exe':'git'
const owner:any={startedAt,deadlineAt,parentPID:process.pid,executable,args,cwd:process.cwd(),requestStarted:false}
await fs.writeFile(path.join(scope,'owner-start.json'),JSON.stringify(owner,null,2))
let handle:any
try{
 if(Date.now()>=deadlineAt-60000)throw Error('Original setup reserve reached')
 owner.requestStarted=true
 const result=await NodeProcess.run({command:{executable,args},cwd:process.cwd(),env:process.env,
  ownership:'owned_tree',windowsHide:true,stdin:'ignore',deadlineAt,nothrow:true,
  onSpawned(value){handle=value;owner.pid=value.pid;owner.occurrenceID=value.occurrenceID}})
 owner.receipt=result.receipt
 await handle.settled;owner.physicalJoined=true
 await handle.outputSettled;owner.outputJoined=true
 owner.requestSettled=true
 await fs.writeFile(path.join(scope,'stdout.log'),result.stdout)
 await fs.writeFile(path.join(scope,'stderr.log'),result.stderr)
 process.exitCode=result.receipt.reason==='exited'?(result.receipt.exitCode??1):1
}catch(error){
 owner.error=String(error);owner.requestSettled=owner.requestStarted;process.exitCode=1
 if(handle&&!owner.physicalJoined){owner.receipt=await handle.terminate('aborted');await handle.settled;owner.physicalJoined=true}
 if(handle&&!owner.outputJoined){await handle.outputSettled;owner.outputJoined=true}
}finally{
 owner.endedAt=Date.now()
 await fs.writeFile(path.join(scope,'owner.json'),JSON.stringify(owner,null,2))
 console.log(JSON.stringify(owner))
}
