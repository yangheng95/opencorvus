import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import {execFileSync} from 'node:child_process'
const root='.tmp-task-question-recovery-406'
const git=(args,env=process.env,input)=>execFileSync('git',args,{env,input,encoding:'utf8',windowsHide:true,maxBuffer:128*1024*1024})
const full=['packages/opencorvus/script/check/control-lease-owners.ts','packages/opencorvus/src/permission/authority.ts',
 'packages/opencorvus/test/permission-two-mode.test.ts','packages/opencorvus/test/permission-execution-owner-process.test.ts',
 'packages/opencorvus/test/fixture/permission-execution-owner-process-worker.ts','packages/overlay/src/components/InteractionCard.tsx',
 'packages/overlay/src/components/ui/Checkbox.tsx','packages/overlay/src/styles/surfaces/card.css',
 'specs/current/architecture/security-permission.md','specs/current/architecture/07-panel-reactivity.md',
 'specs/records/2026-10/2026-10-14-execution-owner-recovery-406.md','specs/artifacts/2026-10-14-execution-owner-recovery-406']
const indexes=['specs/README.md','specs/artifacts/README.md','specs/records/2026-10/README.md']
const rows=Object.fromEntries(indexes.map(file=>{
 const matches=fs.readFileSync(file,'utf8').split(/\r?\n/).filter(line=>line.includes('[406 原执行者恢复与选项呈现]'))
 assert.equal(matches.length,1);return[file,matches[0]]
}))
const inserts={
 '#### 修复\n\n':'- 权限执行开始与原进程租约同时提交；另一个后端恢复时确认原执行者确已退出，避免活跃工具的真实结果被抢写为未知。恢复按原项目、尝试和租约收敛，租约自然到期不被当作进程死亡。\n\n- 问题选项的短标题与说明分行显示，并为实际选择控件提供独立名称和描述；说明可原生点击选择。键盘选择保留侧聊标题、目标和输入区的位置，现有技能与连接复选框使用当前语言名称。\n\n',
 '#### Fixed\n\n':'- Permission execution starts and its original process lease commit together. Recovery verifies that the original executor has exited before settling an unfinished attempt, preserving live tools\' real results. Recovery retains the exact project, attempt and lease; natural lease expiry is not treated as process death.\n\n- Question options show separate short labels and descriptions with distinct input names and supplemental descriptions. Descriptions support native click selection. Keyboard selection preserves the Side Chat header, goal and composer positions, and existing skill and connection checkboxes use names in the current language.\n\n'
}
function change(file,raw){
 let text=raw.replaceAll('\r\n','\n')
 if(file==='CHANGELOG.md'){
  for(const [heading,block] of Object.entries(inserts)){
   if(text.includes(block))continue
   const at=text.indexOf(heading);assert(at>=0)
   text=text.slice(0,at+heading.length)+block+text.slice(at+heading.length)
  }
 }else{
  const lines=text.split('\n'),at=lines.findIndex(line=>line.includes('[406 原执行者恢复与选项呈现]'))
  assert(at>=0);lines[at]=rows[file];text=lines.join('\n')
 }
 return text
}
const base=git(['rev-parse','HEAD']).trim()
assert.equal(git(['branch','--show-current']).trim(),'main')
const env={...process.env,GIT_INDEX_FILE:path.resolve(root,'index-final-'+Date.now())}
git(['read-tree',base],env);git(['add','-f','--',...full],env)
const update=(file,text,environment)=>{
 const object=git(['hash-object','-w','--stdin'],environment,text).trim()
 git(['update-index','--index-info'],environment,'100644 '+object+'\t'+file+'\n')
}
for(const file of [...indexes,'CHANGELOG.md'])update(file,change(file,git(['show',base+':'+file])),env)
git(['diff','--cached','--check'],env)
const paths=git(['diff','--cached','--name-only'],env).trim().split('\n')
assert(paths.every(file=>indexes.includes(file)||file==='CHANGELOG.md'||full.some(scope=>file===scope||file.startsWith(scope+'/'))))
fs.writeFileSync(root+'/final-scoped.patch',git(['diff','--cached','--binary'],env))
fs.writeFileSync(root+'/final-scoped.stat',git(['diff','--cached','--stat'],env))
fs.writeFileSync(root+'/final-scope-review.json',JSON.stringify({base,paths,indexes:rows,inserts,indexFile:env.GIT_INDEX_FILE},null,2))
console.log(JSON.stringify({base,paths:paths.length,indexFile:env.GIT_INDEX_FILE,mode:process.argv[2]??'prepare'}))
if(process.argv[2]!=='--commit')process.exit(0)
assert.equal(git(['rev-parse','HEAD']).trim(),base)
git(['commit','-q','-m','fix(permission): preserve execution owners and native question selection'],env)
const commit=git(['rev-parse','HEAD']).trim()
assert.equal(git(['rev-parse',commit+'^']).trim(),base)
fs.writeFileSync(root+'/final-commit.json',JSON.stringify({base,commit,paths,indexReconciled:false},null,2))
const whole=paths.filter(file=>!indexes.includes(file)&&file!=='CHANGELOG.md')
for(let at=0;at<whole.length;at+=100)git(['update-index','--index-info'],process.env,git(['ls-tree',commit,'--',...whole.slice(at,at+100)]).replaceAll(' blob ',' '))
for(const file of [...indexes,'CHANGELOG.md'])update(file,change(file,git(['show',':'+file])),process.env)
fs.writeFileSync(root+'/final-commit.json',JSON.stringify({base,commit,paths,indexReconciled:true},null,2))
console.log(JSON.stringify({base,commit,paths:paths.length,indexReconciled:true}))
