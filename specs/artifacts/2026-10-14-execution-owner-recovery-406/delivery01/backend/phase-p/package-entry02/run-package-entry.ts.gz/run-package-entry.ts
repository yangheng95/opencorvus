import fs from "node:fs/promises"
import path from "node:path"
import { NodeProcess } from "../../packages/util/src/process-node"
import { expectedTestProcessSupervisor } from "../../packages/opencorvus/script/test-process-supervisor"

// External diagnostic supervision only. The package test receives no special
// wrapper deadline and must declare its own case budget through its normal API.
const startedAt = Date.now(), deadlineAt = startedAt + 600000
const [stage, evidence] = process.argv.slice(2)
if (!stage || !/^[a-z0-9-]+$/.test(stage) || !evidence || !path.isAbsolute(evidence))
  throw Error("A fresh stage and explicit absolute evidence directory are required")
const scope = path.resolve(import.meta.dir, stage)
await fs.mkdir(scope)
await fs.mkdir(evidence)
const supervisor = expectedTestProcessSupervisor()
if (!supervisor) throw Error("Formal native process supervisor required")
process.env.OPENCORVUS_PROCESS_SUPERVISOR = supervisor
const childEnvironment: NodeJS.ProcessEnv = { ...process.env,
  OPENCORVUS_PROCESS_SUPERVISOR: supervisor,
  OPENCORVUS_PERMISSION_OWNER_EVIDENCE: evidence }
delete childEnvironment.OPENCORVUS_PERMISSION_OWNER_DEADLINE_AT
const args = ["run", "--cwd", "packages/opencorvus", "test", "test/permission-execution-owner-process.test.ts"]
const owner: any = { startedAt, deadlineAt, executable: process.execPath, args, cwd: process.cwd(), parentPID: process.pid,
  environment: { removed: ["OPENCORVUS_PERMISSION_OWNER_DEADLINE_AT"],
    supplied: { OPENCORVUS_PROCESS_SUPERVISOR: supervisor, OPENCORVUS_PERMISSION_OWNER_EVIDENCE: evidence },
    inheritedNames: Object.keys(process.env).filter(key => ![
      "OPENCORVUS_PERMISSION_OWNER_DEADLINE_AT", "OPENCORVUS_PROCESS_SUPERVISOR", "OPENCORVUS_PERMISSION_OWNER_EVIDENCE",
    ].includes(key)).sort() },
  dedicatedOuterDeadlinePassedToPackage: false, requestStarted: false }
await fs.writeFile(path.join(scope, "owner-start.json"), JSON.stringify(owner, null, 2))
for (const source of [import.meta.filename, "packages/opencorvus/src/permission/authority.ts",
  "packages/opencorvus/test/permission-execution-owner-process.test.ts",
  "packages/opencorvus/test/fixture/permission-execution-owner-process-worker.ts"])
  await fs.copyFile(source, path.join(scope, path.basename(source)))
let handle: any
try {
  if (Date.now() >= deadlineAt - 60000) throw Error("Original external owner setup consumed its close reserve")
  owner.requestStarted = true
  const result = await NodeProcess.run({ command: { executable: process.execPath, args }, cwd: process.cwd(),
    env: childEnvironment, ownership: "owned_tree", windowsHide: true, stdin: "ignore", deadlineAt, nothrow: true,
    onSpawned(value) { handle = value; owner.pid = value.pid; owner.occurrenceID = value.occurrenceID } })
  owner.receipt = result.receipt
  await handle.settled; owner.physicalJoined = true
  await handle.outputSettled; owner.outputJoined = true
  owner.requestSettled = true
  await fs.writeFile(path.join(scope, "stdout.log"), result.stdout)
  await fs.writeFile(path.join(scope, "stderr.log"), result.stderr)
  process.exitCode = result.receipt.exitCode ?? 1
} catch (error) {
  owner.error = String(error); owner.requestSettled = owner.requestStarted; process.exitCode = 1
  if (handle && !owner.physicalJoined) {
    owner.receipt = await handle.terminate("aborted")
    await handle.settled; owner.physicalJoined = true
  }
  if (handle && !owner.outputJoined) { await handle.outputSettled; owner.outputJoined = true }
} finally {
  owner.endedAt = Date.now()
  await fs.writeFile(path.join(scope, "owner.json"), JSON.stringify(owner, null, 2))
  console.log(JSON.stringify(owner))
}
