import fs from "node:fs/promises"
import path from "node:path"
import { NodeProcess } from "../../packages/util/src/process-node"
import { expectedTestProcessSupervisor } from "../../packages/opencorvus/script/test-process-supervisor"

const [stage, kind, ...files] = process.argv.slice(2)
if (!stage || !/^[a-z0-9-]+$/.test(stage) || !["test", "typecheck"].includes(kind!)) throw Error("Explicit bounded formal stage required")
const startedAt = Date.now(), deadlineAt = startedAt + 600000
const scope = path.resolve(import.meta.dir, stage)
await fs.mkdir(scope)
const supervisor = expectedTestProcessSupervisor()
if (!supervisor) throw Error("Formal native process supervisor required")
process.env.OPENCORVUS_PROCESS_SUPERVISOR = supervisor
const args = ["run", "--cwd", "packages/opencorvus", kind!, ...files]
const processChecker = path.resolve("packages/opencorvus/test/permission-execution-owner-process.test.ts")
const ownsProcessChecker = kind === "test" && files.some(file => path.resolve("packages/opencorvus", file) === processChecker)
if (ownsProcessChecker && files.length !== 1) throw Error("The permission process checker requires its own original wrapper deadline")
const childEnvironment = ownsProcessChecker
  ? { ...process.env, OPENCORVUS_PERMISSION_OWNER_DEADLINE_AT: String(deadlineAt) }
  : process.env
const owner: any = { startedAt, deadlineAt, executable: process.execPath, args, cwd: process.cwd(), parentPID: process.pid,
  ...(ownsProcessChecker ? { processCheckerDeadlineAt: deadlineAt } : {}) }
for (const source of ["packages/opencorvus/src/permission/authority.ts", "packages/opencorvus/test/permission-two-mode.test.ts"]) {
  await fs.copyFile(source, path.join(scope, path.basename(source)))
}
await fs.writeFile(path.join(scope, "owner-start.json"), JSON.stringify(owner, null, 2))
let handle: any
try {
  if (Date.now() >= deadlineAt - 60000) throw Error("Original wrapper setup consumed its close reserve")
  const result = await NodeProcess.run({ command: { executable: process.execPath, args }, cwd: process.cwd(),
    env: childEnvironment, ownership: "owned_tree", windowsHide: true, stdin: "ignore", deadlineAt, nothrow: true,
    onSpawned(h) { handle = h; owner.pid = h.pid; owner.occurrenceID = h.occurrenceID } })
  await fs.writeFile(path.join(scope, "stdout.log"), result.stdout)
  await fs.writeFile(path.join(scope, "stderr.log"), result.stderr)
  owner.receipt = result.receipt
  await handle.settled; await handle.outputSettled
  owner.physicalJoined = true; owner.outputJoined = true; owner.requestSettled = true
  process.exitCode = result.receipt.exitCode ?? 1
} catch (error) {
  owner.error = String(error); process.exitCode = 1
  if (handle) { owner.receipt = await handle.terminate("aborted"); await handle.settled; await handle.outputSettled; owner.physicalJoined = true; owner.outputJoined = true }
} finally {
  owner.endedAt = Date.now()
  await fs.writeFile(path.join(scope, "owner.json"), JSON.stringify(owner, null, 2))
  console.log(JSON.stringify(owner))
}
