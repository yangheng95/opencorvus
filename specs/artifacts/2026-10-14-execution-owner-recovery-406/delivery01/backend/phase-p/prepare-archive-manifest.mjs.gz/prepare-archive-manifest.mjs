import fs from 'node:fs/promises'
import path from 'node:path'
import assert from 'node:assert/strict'
import { fileURLToPath } from 'node:url'

const phase = path.dirname(fileURLToPath(import.meta.url))
const root = path.dirname(phase)
const output = path.join(phase, 'archive-preparation')
await fs.mkdir(output, { recursive: true })
const approvedDirectories = new Set(['before', 'red01', 'green01', 'related01',
  'types01', 'types02', 'types03', 'types04', 'types05', 'types06', 'handoff-preparation',
  'process-before-outer-deadline', 'process-before-public-route', 'process03-preparation',
  'process01', 'process02', 'process03', 'process-evidence01', 'process-evidence02', 'process-evidence03',
  'package-entry-preparation', 'package-entry01', 'package-entry02', 'package-evidence01', 'package-evidence02'])
const approvedPhaseFiles = new Set(['admission.json', 'before-status.txt', 'before-task.patch',
  'process-final-handoff.md', 'process01-checker-before.ts', 'process02-checker-before.ts',
  'process01-summary.json', 'process02-summary.json', 'process03-summary.json', 'package-entry02-summary.json',
  'run-formal.ts', 'run-package-entry.ts', 'source-freeze-check.json', 'prepare-archive-manifest.mjs'])
const analysisFiles = ['scratch406-analysis.md', 'retirement-timing-review.md', 'source-excerpts.json',
  'history.txt', 'history-excerpts.jsonl', 'callers-permission.txt', 'callers-question.txt',
  'tests-current.txt', 'analyzed-source-working-diff.patch', 'live01-causal-facts.json']
const normalized = value => value.split(path.sep).join('/')
const relative = value => normalized(path.relative(root, value))
const decoder = new TextDecoder('utf-8', { fatal: true })
async function readText(filename) { return decoder.decode(await fs.readFile(filename)).replace(/^\uFEFF/, '') }
async function walk(directory) {
  const result = []
  for (const item of await fs.readdir(directory, { withFileTypes: true })) {
    if (item.isSymbolicLink()) throw Error(`Symbolic link not admitted: ${relative(path.join(directory, item.name))}`)
    const filename = path.join(directory, item.name)
    if (item.isDirectory()) result.push(...await walk(filename))
    else if (item.isFile()) result.push(filename)
  }
  return result
}
const candidates = []
const excluded = []
for (const item of await fs.readdir(phase, { withFileTypes: true })) {
  if (item.name === 'archive-preparation') continue
  const filename = path.join(phase, item.name)
  if (item.isDirectory() && approvedDirectories.has(item.name)) candidates.push(...await walk(filename))
  else if (item.isFile() && approvedPhaseFiles.has(item.name)) candidates.push(filename)
  else excluded.push({ source: relative(filename), reason: item.name === 'before-all.patch'
    ? 'Unrelated concurrent worktree patch; exact task before-source and before-task.patch are retained.'
    : 'Outside the explicit Phase P directory/file inventory.' })
}
for (const name of analysisFiles) candidates.push(path.join(root, name))

const files = [], transformations = [], structuralFindings = [], suspiciousValuePatterns = []
let parsedJsonObjects = 0, byteReadbacks = 0
function inspect(value, source, pointer = '') {
  if (!value || typeof value !== 'object') return
  parsedJsonObjects++
  if (!Array.isArray(value)) {
    if (Array.isArray(value.messages) && (Object.hasOwn(value, 'model') || Object.hasOwn(value, 'stream')))
      structuralFindings.push({ source, pointer, kind: 'provider-request-shaped-object' })
    if (Object.hasOwn(value, 'provider') && Object.hasOwn(value, 'mcp') &&
      (Object.hasOwn(value, 'permission_mode') || Object.hasOwn(value, 'prompt_profile')))
      structuralFindings.push({ source, pointer, kind: 'full-config-shaped-object' })
  }
  for (const [key, item] of Object.entries(value)) inspect(item, source, `${pointer}/${key}`)
}
function inspectText(text, source) {
  for (const [kind, pattern] of [
    ['private-key', /-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/g],
    ['openai-token-shaped-value', /\bsk-(?:proj-)?[A-Za-z0-9_-]{24,}\b/g],
    ['bearer-value', /[Bb]earer\s+[A-Za-z0-9_.~+/-]{24,}/g],
  ]) {
    for (const match of text.matchAll(pattern)) suspiciousValuePatterns.push({ source, kind,
      line: text.slice(0, match.index).split('\n').length })
  }
}
for (const filename of candidates.sort()) {
  const source = relative(filename), basename = path.basename(filename)
  if (basename === 'config.json' || /(?:^|\/)(?:auth|models)\.json$/i.test(source) ||
    /(?:^|\/)(?:runtime|home)(?:\/|$)|\.(?:db|sqlite|sqlite3|exe|dll|zip)$/i.test(source)) {
    excluded.push({ source, reason: basename === 'config.json' ? 'Complete public configuration HTTP response excluded explicitly.'
      : 'Runtime/database/home/auth/models/binary content is outside the allowlist.' })
    continue
  }
  let text = await readText(filename)
  let actualSource = source, destination = source.startsWith('phase-p/') ? `backend/${source}` : `backend/analysis/${source}`
  if (basename.endsWith('-http.json')) {
    const receipts = JSON.parse(text)
    assert(Array.isArray(receipts), `Exact HTTP receipt array required: ${source}`)
    const omitted = receipts.flatMap((receipt, index) =>
      ['/global/config', '/config'].includes(receipt.route) && Object.hasOwn(receipt, 'body') ? [index] : [])
    if (omitted.length) {
      const kept = receipts.map((receipt, index) => {
        if (!omitted.includes(index)) return receipt
        const { body, ...metadata } = receipt
        return { ...metadata, bodyOmittedFromArchive: { reason: 'complete-public-config-response', originalReceiptIndex: index } }
      })
      const data = { derivativeOf: source, transformation: 'Only complete config response body fields omitted; all other original receipts preserved.',
        omittedConfigReceiptIndices: omitted, receipts: kept }
      const target = path.join(output, 'filtered-http', source.replace(/^phase-p\//, '').replace(/\.json$/, '.config-omitted.json'))
      await fs.mkdir(path.dirname(target), { recursive: true })
      const expectedBytes = Buffer.from(JSON.stringify(data, null, 2) + '\n')
      await fs.writeFile(target, expectedBytes)
      assert((await fs.readFile(target)).equals(expectedBytes), `Derivative direct bytes readback mismatch: ${source}`)
      byteReadbacks++
      const back = JSON.parse(await readText(target))
      for (let i = 0; i < receipts.length; i++) if (!omitted.includes(i)) assert.deepEqual(back.receipts[i], receipts[i])
      actualSource = relative(target)
      destination = `backend/${source.replace(/\.json$/, '.config-omitted.json')}`
      excluded.push({ source, reason: 'Contains complete public config response; use explicitly labelled derivative.', replacement: actualSource })
      transformations.push({ source, derivative: actualSource, omittedConfigReceiptIndices: omitted,
        originalReceiptCount: receipts.length, retainedReceiptCount: back.receipts.length,
        nonConfigReceiptsExactReadback: true, directBytesReadback: true })
      text = await readText(target)
    }
  }
  if (source === 'phase-p/related01/stdout.log') {
    const segments = text.split(/(?<=\n)/u), changed = []
    const mapped = segments.map((segment, index) => {
      const prefix = 'permission-message-evidence '
      if (!segment.startsWith(prefix)) return segment
      const value = JSON.parse(segment.slice(prefix.length))
      if (!Array.isArray(value.requests)) return segment
      const { requests, ...retained } = value
      const lineEnding = segment.endsWith('\r\n') ? '\r\n' : segment.endsWith('\n') ? '\n' : ''
      const transformed = { ...retained, archiveOmissions: [{ pointer: '/requests',
        reason: 'complete-provider-request-data', originalRequestCount: requests.length }] }
      const outputLine = prefix + JSON.stringify(transformed) + lineEnding
      const { archiveOmissions, ...back } = JSON.parse(outputLine.slice(prefix.length))
      assert.deepEqual(back, retained)
      changed.push({ line: index + 1, omittedPointer: '/requests', omittedRequestCount: requests.length,
        retainedNonProviderFactsExact: true })
      return outputLine
    })
    assert.equal(changed.length, 2, 'Reviewed related01 Provider evidence lines changed')
    const target = path.join(output, 'filtered-logs', 'related01-stdout.provider-requests-omitted.log')
    await fs.mkdir(path.dirname(target), { recursive: true })
    const expectedBytes = Buffer.from(mapped.join(''))
    await fs.writeFile(target, expectedBytes)
    assert((await fs.readFile(target)).equals(expectedBytes), 'Related log derivative direct bytes mismatch')
    byteReadbacks++
    actualSource = relative(target)
    destination = 'backend/phase-p/related01/stdout.provider-requests-omitted.log'
    excluded.push({ source, reason: 'Two original log objects contain four complete Provider requests; use labelled derivative.', replacement: actualSource })
    transformations.push({ source, derivative: actualSource, changedLines: changed, unmodifiedLinesBytePreserved: true,
      originalLineSegments: segments.length, retainedLineSegments: mapped.length, directBytesReadback: true })
    text = await readText(target)
  }
  if (basename === 'provider-requests.json') {
    const requests = JSON.parse(text)
    const allowedKeys = new Set(['provider', 'index', 'kind', 'bodyState', 'model', 'stream', 'declaredTools'])
    assert(Array.isArray(requests), `Provider metadata array required: ${source}`)
    for (const request of requests) for (const key of Object.keys(request))
      assert(allowedKeys.has(key), `Nonmetadata Provider field ${key}: ${source}`)
  }
  if (basename.endsWith('.json')) inspect(JSON.parse(text), actualSource)
  else if (basename.endsWith('.jsonl') || basename.endsWith('.log')) {
    for (const line of text.split(/\r?\n/)) {
      const at = line.indexOf('{')
      if (at < 0) continue
      try { inspect(JSON.parse(line.slice(at)), actualSource) } catch {}
    }
  }
  inspectText(text, actualSource)
  files.push({ source: actualSource, destination, category: source.startsWith('phase-p/') ? 'phase-p-public-evidence' : 'shared-mechanism-analysis' })
}
const scan = { status: structuralFindings.length || suspiciousValuePatterns.length ? 'review_required' : 'clear-for-root-review',
  scope: 'Explicit Phase P source inventory only. No auth/models read; no known-secret value scan claimed.',
  parsedJsonObjects, structuralFindings, suspiciousValuePatterns, directByteReadbacks: byteReadbacks,
  transformations, excluded,
  originalSafety: 'Original excluded config responses and logs remain unchanged in scratch; no artifacts copied to specs.',
  checksAre: 'Archive shape/identity checks, not substitute functional tests; no hash gate.' }
await fs.writeFile(path.join(output, 'scan.json'), JSON.stringify(scan, null, 2) + '\n')
if (scan.status !== 'clear-for-root-review') {
  console.log(JSON.stringify({ status: scan.status, findings: structuralFindings, suspicious: suspiciousValuePatterns }))
  process.exitCode = 1
} else {
  files.push({ source: 'phase-p/archive-preparation/scan.json', destination: 'backend/phase-p/archive-scan.json', category: 'archive-review' })
  files.push({ source: 'phase-p/archive-preparation/scan-before-log-omission.json', destination: 'backend/phase-p/archive-scan-before-log-omission.json', category: 'archive-review' })
  const liveFacts = [], caseClosures = []
  for (const group of ['process-evidence01', 'process-evidence02', 'process-evidence03', 'package-evidence02']) {
    for (const scenario of ['live-same-project', 'live-two-projects', 'dead-unexpired', 'dead-expired']) {
      const folder = path.join(phase, group, scenario)
      const cleanupPath = path.join(folder, 'cleanup.json')
      let cleanup
      try { cleanup = JSON.parse(await readText(cleanupPath)) }
      catch (error) { if (error.code !== 'ENOENT') throw error }
      const childFiles = (await fs.readdir(folder)).filter(name => name.endsWith('-physical-owner.json'))
      const children = await Promise.all(childFiles.map(async name => {
        const fact = JSON.parse(await readText(path.join(folder, name)))
        return { source: relative(path.join(folder, name)), pid: fact.pid, occurrenceID: fact.occurrenceID,
          startedAt: fact.startedAt, deadlineAt: fact.deadlineAt, endedAt: fact.endedAt,
          receipt: fact.receipt, physicalJoined: fact.physicalJoined, outputJoined: fact.outputJoined,
          requestSettled: fact.requestSettled }
      }))
      caseClosures.push({ group, scenario, children, cleanupReceipt: cleanup ? relative(cleanupPath) : null,
        closureFacts: cleanup ? Object.fromEntries(['physicalJoined', 'outputJoined', 'requestSettled',
          'providersClosed', 'providerResponsesJoined', 'resourceClosed', 'resourceHandlersJoined', 'errors']
          .filter(key => Object.hasOwn(cleanup, key)).map(key => [key, cleanup[key]])) : null,
        limitation: cleanup ? null : 'process02 dead-unexpired metadata export failed before resource.stop/cleanup; no normal case closure invented.' })
      if (!scenario.startsWith('live-')) continue
      for (const label of ['a', 'b']) {
        const filename = path.join(folder, `${label}-completed.json`), fact = JSON.parse(await readText(filename))
        const expected = Buffer.from(`owner,value\n${label.toUpperCase()},${label === 'a' ? 3 : 7}\n`)
        assert(Buffer.from(fact.snapshot.tool.state.output).equals(expected), `Original public Tool CSV bytes: ${relative(filename)}`)
        assert(Buffer.from(fact.snapshot.result.result.value.output).equals(expected), `Original durable result CSV bytes: ${relative(filename)}`)
        const request = fact.snapshot.request
        const toolMessage = fact.snapshot.messages.body.find(message => message.info.id === request.messageID)
        assert.equal(typeof toolMessage?.info?.time?.completed, 'number')
        liveFacts.push({ source: relative(filename), projectID: request.projectID, sessionID: request.sessionID,
          requestID: request.id, toolMessageID: request.messageID, toolMessageCompletedAt: toolMessage.info.time.completed,
          toolPartID: fact.snapshot.tool.id, toolStatus: fact.snapshot.tool.state.status,
          publicCsv: expected.toString(), bytes: expected.length, toolAndDurableResultExactBytes: true,
          promptHttpStatus: fact.promptResponse.status, naturalAssistantFinish: fact.completed.info.finish,
          ledgerEvents: fact.snapshot.ledger.map(row => row.event_type),
          formalBoundary: group === 'process-evidence01' ? 'Original formal live assertion stopped on expected stale; these are separately read original API/DB facts.'
            : 'Read from the original completed snapshot; duplicate runs do not add coverage.' })
      }
    }
  }
  await fs.writeFile(path.join(output, 'original-facts-index.json'), JSON.stringify({
    scope: 'Read-only original public evidence index, not a new process/test run.', originalProcess01LiveFacts: liveFacts.filter(f => f.source.includes('process-evidence01/')),
    allLiveFacts: liveFacts, caseClosures, functionalCoverageUnchanged: { tests: 55, assertions: 247 },
  }, null, 2) + '\n')
  files.push({ source: 'phase-p/archive-preparation/original-facts-index.json', destination: 'backend/phase-p/original-facts-index.json', category: 'archive-review' })
  files.push({ source: 'phase-p/archive-preparation/ROOT-REVIEW.md', destination: 'backend/phase-p/ROOT-REVIEW.md', category: 'archive-review' })
  files.push({ source: 'phase-p/archive-preparation/manifest.json', destination: 'backend/phase-p/archive-manifest.json', category: 'archive-review' })
  assert.equal(new Set(files.map(file => file.destination)).size, files.length, 'Archive destinations must be unique')
  for (const file of files) {
    assert(!path.isAbsolute(file.source) && !file.source.split('/').includes('..'), 'Source must remain within explicit scratch root')
    assert(!path.isAbsolute(file.destination) && !file.destination.split('/').includes('..'), 'Destination must remain within chosen artifact root')
  }
  const manifest = { status: 'frozen-for-root-review', sourceRoot: root,
    policy: { copyOnlyExactFiles: true, destinationRootChosenByRoot: true, archiveNotExecuted: true,
      excludeWholeRuntime: true, excludeConfigResponses: true, providerMetadataOnly: true,
      fixtureSourceApiKey: 'local-controlled-provider is a public fixture literal, not a credential',
      archiveIntegrity: 'Root should read source and copied/decompressed destination bytes and compare directly, without hash gates.' },
    evidenceBoundary: { distinctTests: 55, distinctAssertions: 247, repeatedEntrypointsNotAdded: true,
      process02: 'dead-unexpired resource.stop/cleanup path not reached after metadata failure; parent later exited; no invented closure.',
      packageEntry01: 'pre-child supervisor selection failure; no package case, Provider or resource service was started.',
      retirementTiming: 'Normal Ask Message retirement remains an independent unimplemented gap.', questionRecovery: 'Phase Q unimplemented.' },
    excluded, transformations, files: files.sort((a, b) => a.destination.localeCompare(b.destination)) }
  await fs.writeFile(path.join(output, 'manifest.json'), JSON.stringify(manifest, null, 2) + '\n')
  console.log(JSON.stringify({ status: manifest.status, files: files.length, excluded: excluded.length,
    derivatives: transformations.length, parsedJsonObjects, directByteReadbacks: byteReadbacks }))
}
