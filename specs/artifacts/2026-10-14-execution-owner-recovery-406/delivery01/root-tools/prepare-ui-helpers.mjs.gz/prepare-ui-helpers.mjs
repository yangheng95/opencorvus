import fs from 'node:fs/promises'
import path from 'node:path'
import {spawnSync} from 'node:child_process'
const directory=import.meta.dirname, repository=path.dirname(directory)
const before=path.join(directory,'ui-helper-source')
await fs.mkdir(before,{recursive:true})
const original=path.join(repository,'.tmp-task-question-recovery-405')
const read=async name=>{const bytes=await fs.readFile(path.join(original,name));try{await fs.writeFile(path.join(before,name),bytes,{flag:'wx'})}catch(error){if(error.code!=='EEXIST'||!bytes.equals(await fs.readFile(path.join(before,name))))throw error}return bytes.toString('utf8')}
function replace(source,from,to){if(source.split(from).length!==2)throw Error('Exact original helper text required: '+from);return source.replace(from,to)}
let driver=await read('manual-empty-expiry-driver.ts')
driver=driver.replaceAll('.tmp-task-question-recovery-405','.tmp-task-question-recovery-406').replaceAll('Owned fresh 405','Owned fresh 406')
driver=replace(driver,"const [directory,uiDirectory,scenario='read']=process.argv.slice(2)","import { QUESTION_OPTION_SCENARIOS } from './question-option-input.mjs'\nconst [directory,uiDirectory,scenario]=process.argv.slice(2)")
driver=replace(driver,"if(!['read','warm-read','warm-question','side-read','side-question'].includes(scenario))throw Error('Explicit owned scenario required')","if(!QUESTION_OPTION_SCENARIOS.includes(scenario))throw Error('Explicit 406 Question option scenario required')")
driver=replace(driver,'manual-empty-expiry-server.ts','manual-question-options-server.ts')
driver=replace(driver,'Own manual controlled streaming empty-header Question expiry UI; no real Provider qualification','Own manual 406 Question option layout and selection; no real Provider qualification')
await fs.writeFile(path.join(directory,'manual-question-options-driver.ts'),driver,{flag:'wx'})
await read('manual-empty-expiry-server.ts')
// The new server is a separately declared 406 input. Keep the original 405 source.
await fs.stat(path.join(directory,'manual-question-options-server.ts'))
let relay=await read('relay-driver.mjs')
relay=replace(relay,'owned 405','owned 406')
// Current text uses lower-case "owned" in the scope diagnostic; no algorithm changes.
await fs.writeFile(path.join(directory,'relay-driver.mjs'),relay,{flag:'wx'})
let patch=''
for(const [from,to] of [['manual-empty-expiry-driver.ts','manual-question-options-driver.ts'],['manual-empty-expiry-server.ts','manual-question-options-server.ts'],['relay-driver.mjs','relay-driver.mjs']]){
 const result=spawnSync('git',['diff','--no-index','--',path.join(before,from),path.join(directory,to)],{encoding:'utf8',windowsHide:true});if(![0,1].includes(result.status))throw Error(result.stderr);patch+=result.stdout
}
await fs.writeFile(path.join(directory,'ui-helper-changes.patch'),patch,{flag:'wx'})
await fs.writeFile(path.join(directory,'ui-helper-scope.json'),JSON.stringify({preparedAt:new Date().toISOString(),original:'.tmp-task-question-recovery-405',newSources:['manual-question-options-driver.ts','manual-question-options-server.ts','relay-driver.mjs','question-option-input.mjs','question-option-facts.mjs'],budgets:{serviceMs:600000,questionMs:120000,httpMs:30000,sidePromptMs:180000,closeReserveMs:60000},boundary:'Preparation only. No 405 file/request/deadline modified. No service, Provider, browser or UI test started.'},null,2)+'\n',{flag:'wx'})
