export const QUESTION_OPTION_SCENARIOS = ['main-single', 'main-multiple', 'side-single', 'side-multiple']
export const QUESTION_TIMEOUT_MS = 120000

export function questionOptionInput(scenario) {
  if (!QUESTION_OPTION_SCENARIOS.includes(scenario)) throw new Error('Explicit 406 Question option scenario required')
  const multiple = scenario.endsWith('-multiple')
  return {
    questions: [{
      header: 'Option layout 406',
      question: multiple ? 'Choose the public examples to record, or enter a custom answer.' : 'Choose one public example to record, or enter a custom answer.',
      options: [
        {value:'cedar',label:'Cedar',description:'Record the public Cedar example'},
        {value:'iris',label:'Iris',description:'Record the public Iris example'},
        {value:'maple-long',label:'Maple woodland planning archive selection',description:'Record this public Maple example with its complete explanation. The description should remain readable in the narrow Side conversation while the option label, selection control, and surrounding answer controls keep their own positions.'},
        {value:'no-description',label:'No description',description:''},
        {value:'unavailable',label:'Unavailable example',description:'This public example is unavailable for selection.',disabled:true},
      ],
      multiple,
      custom:true,
    }],
  }
}

export function questionOptionPrompt(scenario) {
  questionOptionInput(scenario)
  return scenario.startsWith('side-')
    ? 'Ask me to choose the public examples in this independent Side Chat, then record my exact answer.'
    : 'Ask me to choose the public examples, then record my exact answer.'
}
