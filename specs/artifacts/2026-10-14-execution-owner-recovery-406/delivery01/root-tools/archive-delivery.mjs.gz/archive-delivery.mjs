import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import {gzipSync,gunzipSync} from 'node:zlib'
const root=path.resolve('.tmp-task-question-recovery-406')
const output=path.resolve('specs/artifacts/2026-10-14-execution-owner-recovery-406/delivery01')
const manifest={capturedAt:Date.now(),purpose:'Exact original evidence and explicitly labelled privacy derivatives; direct identity comparison is not functional acceptance',files:[],excluded:[]}
const selected=new Map()
function select(source,destination){
 const absolute=path.resolve(root,source)
 assert(absolute.startsWith(root+path.sep)); assert(!fs.lstatSync(absolute).isSymbolicLink())
 const target=path.resolve(output,destination); assert(target.startsWith(output+path.sep))
 if(selected.has(destination)){assert.equal(selected.get(destination),source);return}
 selected.set(destination,source)
}
for(const spec of ['phase-p/archive-preparation/manifest.json','ui-implementation-archive-allowlist.json']){
 const sourceManifest=JSON.parse(fs.readFileSync(path.join(root,spec),'utf8'))
 for(const row of sourceManifest.files)select(row.source,row.destination)
}
const pages=['options-main-single-after01','options-main-multiple-after01','options-side-single-after01','options-side-multiple-after01',
 'options-side-single-before-focus02','options-side-single-before-focus03','options-side-single-u3-after01','options-side-multiple-u3-after01',
 'options-main-single-u3-after01','options-main-multiple-u3-after01']
const manualNames=/^(?:[0-9].*\.jpg|ready\.json|terminal\.json|global-chat-start\.json|public-model-catalog\.json|side-question-prompt(?:-response)?\.json|question-options-.*\.json|geometry-.*\.json|manual-.*\.(?:json|txt)(?:\.before-note-correction)?|capability-.*\.json|stop-requested|release-public-prompt)$/
for(const page of pages){
 for(const name of fs.readdirSync(path.join(root,page))){
  if(name==='public-global-config.json'||page==='options-main-multiple-after01'&&name==='capability-before.json'){
   manifest.excluded.push({source:page+'/'+name,reason:'Complete config/skill response excluded; original scratch is retained'});continue
  }
  if(manualNames.test(name))select(page+'/'+name,'ui-manual/'+page+'/'+name)
 }
 for(const suffix of ['launch.json','relay-launch.json','relay-config.json','physical-terminal.json','relay-physical-terminal.json','runtime-owner.json','stdout.log','stderr.log','relay-stdout.log','relay-stderr.log']){
  const source=page+'.'+suffix;if(fs.existsSync(path.join(root,source)))select(source,'ui-manual/owners/'+source)
 }
 const relay=page+'-relay'
 for(const name of ['owner.json','ready.json','terminal.json','events.jsonl'])if(fs.existsSync(path.join(root,relay,name)))select(relay+'/'+name,'ui-manual/'+relay+'/'+name)
 for(const directory of ['control-receipts','control-inbox'])if(fs.existsSync(path.join(root,relay,directory)))
  for(const name of fs.readdirSync(path.join(root,relay,directory)))select(relay+'/'+directory+'/'+name,'ui-manual/'+relay+'/'+directory+'/'+name)
}
for(const name of ['manual-question-options-driver.ts','manual-question-options-server.ts','question-option-input.mjs','question-option-facts.mjs','relay-driver.mjs','capture-capability.mjs','geometry-read-source.js','ui-helper-handoff.md','ui-helper-changes.patch','ui-helper-scope.json','ui-helper-syntax-review.json','ui-helper-prepare-failed01.json','prepare-ui-helpers.mjs','question-focus-scroll-readonly.md','non-question-checkbox-entry.md','checkbox-followup-readonly.md'])
 if(fs.existsSync(path.join(root,name)))select(name,'root-tools/'+name)
for(const directory of ['root-checker-before','root-architecture-before'])
 for(const name of fs.readdirSync(path.join(root,directory)))select(directory+'/'+name,'root-tools/'+directory+'/'+name)
for(const name of ['relay-driver.mjs','prepare-ui-helpers.failed01.mjs','manual-empty-expiry-server.ts','manual-empty-expiry-driver.ts'])
 select('ui-helper-source/'+name,'root-tools/ui-helper-source/'+name)
select('archive-delivery.mjs','root-tools/archive-delivery.mjs')
select('ui-implementation-archive-allowlist.json','ui-implementation/archive-allowlist.json')
select('ui-implementation-allowlist-review.json','ui-implementation/archive-review.json')
fs.mkdirSync(output,{recursive:false})
for(const [destination,source] of selected){
 const raw=fs.readFileSync(path.join(root,source))
 const plain=/\.(?:jpg|md)$/i.test(destination)
 const actualDestination=destination+(plain||destination.endsWith('.gz')?'':'.gz')
 const target=path.join(output,actualDestination)
 fs.mkdirSync(path.dirname(target),{recursive:true})
 fs.writeFileSync(target,plain?raw:gzipSync(raw),{flag:'wx'})
 const readback=fs.readFileSync(target)
 assert((plain?readback:gunzipSync(readback)).equals(raw),'Exact archive identity mismatch: '+source)
 manifest.files.push({source,destination:actualDestination,originalBytes:raw.length,storedBytes:readback.length,directBytesIdentical:true})
}
manifest.originalImages=manifest.files.filter(f=>f.destination.endsWith('.jpg')).length
manifest.originalBytes=manifest.files.reduce((n,f)=>n+f.originalBytes,0)
manifest.boundaries=['UI screenshots were personally viewed by Root; no UI automated test','Before-focus02 has no ArrowDown/answer qualification','Original failed checks and explicitly labelled filtered derivatives are retained','No runtime DB/home/auth/models/private bundle/full Provider body copied']
fs.writeFileSync(path.join(output,'manifest.json'),JSON.stringify(manifest,null,2),{flag:'wx'})
console.log(JSON.stringify({files:manifest.files.length,originalImages:manifest.originalImages,originalBytes:manifest.originalBytes,output}))
