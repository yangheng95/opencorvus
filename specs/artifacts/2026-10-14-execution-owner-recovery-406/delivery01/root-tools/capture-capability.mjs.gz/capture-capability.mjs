import fs from 'node:fs/promises'
import path from 'node:path'
import assert from 'node:assert/strict'
const [scope, label] = process.argv.slice(2)
assert.equal(path.dirname(path.resolve(scope)), import.meta.dirname)
assert(/^[a-z0-9-]+$/.test(label))
const ready = JSON.parse(await fs.readFile(path.join(scope, 'ready.json'), 'utf8'))
const remaining = ready.closeBy - Date.now()
assert(remaining > 0)
const responses = await Promise.all(['/chat/capability', '/config'].map(async route => {
  const url = new URL(route, ready.url)
  url.searchParams.set('directory', ready.session.directory)
  const response = await fetch(url, { headers: {'x-opencorvus-directory': ready.session.directory}, signal: AbortSignal.timeout(Math.min(30000, remaining)) })
  const raw = await response.json()
  const body = route === '/config' ? {mcp:raw.mcp, primary_assistant_capabilities:raw.primary_assistant_capabilities} : {scope:raw.scope, agent_id:raw.agent_id, mcp:raw.mcp, skills:{assigned_refs:raw.skills?.assigned_refs}}
  return {route, status:response.status, body, capture:'Exact selected public assignment/config fields; credentials and full skill bodies deliberately excluded'}
}))
const output = {observedAt:Date.now(), sessionID:ready.sessionID, directory:ready.session.directory, responses}
await fs.writeFile(path.join(scope, 'capability-' + label + '.json'), JSON.stringify(output, null, 2), {flag:'wx'})
for (const response of responses) assert.equal(response.status, 200)
console.log(JSON.stringify(output))
