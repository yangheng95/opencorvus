import fs from 'node:fs/promises'
import path from 'node:path'
import assert from 'node:assert/strict'
import {randomUUID} from 'node:crypto'
import {QUESTION_OPTION_SCENARIOS, QUESTION_TIMEOUT_MS, questionOptionPrompt} from './question-option-input.mjs'
const [scope,mode,pendingName,expectedAnswers]=process.argv.slice(2)
assert(scope&&path.isAbsolute(scope));assert.equal(path.dirname(path.resolve(scope)),import.meta.dirname)
assert(['side-prompt','pending','answered'].includes(mode),'Explicit public operation required')
const ready=JSON.parse(await fs.readFile(path.join(scope,'ready.json'),'utf8'))
assert(QUESTION_OPTION_SCENARIOS.includes(ready.scenario));assert.equal(ready.questionTimeoutMs,QUESTION_TIMEOUT_MS)
assert(Date.now()<ready.closeBy,'Original owned close reserve reached')
const side=ready.scenario.startsWith('side-')
const request=async(route,method='GET',body,maximum=30000)=>{
 const remaining=ready.closeBy-Date.now();assert(remaining>0,'Original owned close reserve reached')
 const response=await fetch(new URL(route,ready.url),{method,headers:{'content-type':'application/json','x-opencorvus-directory':ready.session.directory},...(body===undefined?{}:{body:JSON.stringify(body)}),signal:AbortSignal.timeout(Math.min(maximum,remaining))})
 const raw=await response.text();let value;try{value=JSON.parse(raw)}catch{value=raw}
 return {route,method,status:response.status,body:value}
}
let target=ready.session
if(side){
 const response=await request('/session');assert.equal(response.status,200)
 const candidates=response.body.filter(item=>item.parentID===undefined&&item.metadata?.sideChat?.sourceSessionID===ready.sessionID)
 assert.equal(candidates.length,1,'Exactly one real UI-created independent Side root required')
 target=candidates[0];assert.equal(target.projectID,ready.session.projectID);assert.equal(path.resolve(target.directory),path.resolve(ready.session.directory))
}
if(mode==='side-prompt'){
 assert(side,'Only a real UI-created Side receives this new visible API prompt')
 const body={messageID:'msg_'+randomUUID(),agent:'chat',model:{providerID:'side-fixture',modelID:'session-prompt-owner-model'},parts:[{type:'text',text:questionOptionPrompt(ready.scenario)}]}
 await fs.writeFile(path.join(scope,'side-question-prompt.json'),JSON.stringify({side:target,body},null,2)+'\n',{flag:'wx'})
 console.log(JSON.stringify({mainSessionID:ready.sessionID,sideSessionID:target.id,messageID:body.messageID,purpose:'Actual visible API prompt in real UI-created independent Side'}))
 try{
  const result=await request(`/session/${encodeURIComponent(target.id)}/message`,'POST',body,180000)
  await fs.writeFile(path.join(scope,'side-question-prompt-response.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'})
  assert.equal(result.status,200)
 }catch(error){await fs.writeFile(path.join(scope,'side-question-prompt-failure.json'),JSON.stringify({at:new Date().toISOString(),error:String(error),messageID:body.messageID,sideSessionID:target.id},null,2)+'\n',{flag:'wx'});throw error}
}else{
 const responses=await Promise.all([`/session/${encodeURIComponent(target.id)}/message`,`/session/${encodeURIComponent(target.id)}/conversation`,'/question'].map(route=>request(route)))
 const output=path.join(scope,`question-options-${mode}-${Date.now()}.json`)
 await fs.writeFile(output,JSON.stringify({observedAt:new Date().toISOString(),ready,target,mode,responses},null,2)+'\n',{flag:'wx'})
 for(const response of responses)assert.equal(response.status,200,response.route)
 const [messages,conversation,questions]=responses.map(response=>response.body)
 let question
 if(mode==='pending'){
  const selected=conversation.pendingQuestions.filter(item=>item.sessionID===target.id);assert.equal(selected.length,1)
  question=selected[0]
  const {orderKey,...canonical}=question;assert.equal(typeof orderKey,'string');assert.deepEqual(questions.find(item=>item.id===question.id),canonical)
  assert.deepEqual(question.questions,ready.questionInput.questions)
  assert.deepEqual(question.expiry,{origin:'deadline',timeoutMs:QUESTION_TIMEOUT_MS,timeExpires:question.timeCreated+QUESTION_TIMEOUT_MS})
  assert(Date.now()<question.expiry.timeExpires,'The actual pending observation is before its original expiry')
 }else{
  assert(pendingName&&path.basename(pendingName)===pendingName,'Exact original pending observation basename required')
  const original=JSON.parse(await fs.readFile(path.join(scope,pendingName),'utf8'))
  assert.equal(original.mode,'pending');assert.equal(original.target.id,target.id);assert.equal(original.ready.deadlineAt,ready.deadlineAt);assert.deepEqual(original.ready.occurrence,ready.occurrence)
  question=original.responses[1].body.pendingQuestions.find(item=>item.sessionID===target.id);assert(question)
 }
 assert.equal(question.sessionID,target.id);assert(question.tool?.messageID&&question.tool?.callID)
 const message=messages.find(item=>item.info.id===question.tool.messageID);assert(message);assert.equal(message.info.sessionID,target.id)
 const tool=message.parts.find(item=>item.type==='tool'&&item.tool==='question'&&item.callID===question.tool.callID);assert(tool)
 const accepted=JSON.parse(await fs.readFile(path.join(scope,side?'side-question-prompt.json':'global-chat-start.json'),'utf8'))
 const inputMessageID=side?accepted.body.messageID:accepted.acceptance.messageID
 const user=messages.find(item=>item.info.id===inputMessageID);assert(user);assert.equal(user.info.role,'user');assert.equal(user.info.sessionID,target.id);assert.equal(message.info.parentID,user.info.id)
 let final
 if(mode==='pending')assert.equal(tool.state.status,'running')
 else{
  assert(expectedAnswers,'Exact actual UI-submitted answer array JSON required')
  const answers=JSON.parse(expectedAnswers);assert(Array.isArray(answers)&&answers.length===question.questions.length&&answers.every(item=>Array.isArray(item)&&item.every(value=>typeof value==='string')))
  assert.equal(tool.state.status,'completed');assert.equal(tool.state.metadata.status,'answered');assert.deepEqual(tool.state.metadata.answers,answers)
  final=messages.findLast(item=>item.info.role==='assistant'&&item.info.parentID===user.info.id&&item.info.finish==='stop'&&Number.isFinite(item.info.time.completed));assert(final)
  assert.equal(final.info.sessionID,target.id);assert.deepEqual(final.info.acceptedInputMessageIDs,[user.info.id]);assert.deepEqual(final.parts.filter(item=>item.type==='text').map(item=>item.text),['provider reply 2']);assert.equal(conversation.board.status,'idle')
 }
 const result={output,mode,scenario:ready.scenario,mainSessionID:ready.sessionID,targetSessionID:target.id,questionID:question.id,originalTimeCreated:question.timeCreated,originalExpiry:question.expiry,toolMessageID:message.info.id,callID:tool.callID,toolState:tool.state,finalMessageID:final?.info.id,boardStatus:conversation.board.status,boundary:'Actual public API/Tool binding and exact answers only. Root owns UI input, names/descriptions, screenshots and visual acceptance; this is not a DOM/render/text test.'}
 await fs.writeFile(output.replace('.json','.check.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(result))
}
