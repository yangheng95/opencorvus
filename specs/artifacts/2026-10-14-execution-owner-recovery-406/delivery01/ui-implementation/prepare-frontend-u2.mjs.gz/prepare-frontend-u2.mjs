import fs from 'node:fs/promises'
import path from 'node:path'
import {spawnSync} from 'node:child_process'
const repository=path.dirname(import.meta.dirname), destination=path.join(import.meta.dirname,'frontend-u2')
const prior=path.join(import.meta.dirname,'frontend-u')
const files=JSON.parse(await fs.readFile(path.join(prior,'source-allowlist.json'),'utf8')).files
await fs.mkdir(destination,{recursive:false})
for(const file of files){const output=path.join(destination,'before',file);await fs.mkdir(path.dirname(output),{recursive:true});await fs.copyFile(path.join(repository,file),output)}
for(const [name,args] of [['source-before.patch',['diff','--',...files]],['index-before.patch',['diff','--cached','--',...files]],['status-before.txt',['status','--short']]]){
 const result=spawnSync('git',args,{cwd:repository,encoding:'utf8',windowsHide:true});if(result.status!==0)throw Error(result.stderr);await fs.writeFile(path.join(destination,name),result.stdout,{flag:'wx'})
}
await fs.writeFile(path.join(destination,'source-allowlist.json'),JSON.stringify({capturedAt:new Date().toISOString(),scope:'406 U2 only Checkbox aria-label forwarding; other two U1 sources preserved',changedFiles:['packages/overlay/src/components/ui/Checkbox.tsx'],completeUIFiles:files},null,2)+'\n',{flag:'wx'})
const build=path.join(import.meta.dirname,'ui-after'),index=path.join(build,'index.html')
await fs.mkdir(path.join(destination,'u1-build'))
const html=await fs.readFile(index),stat=await fs.stat(index)
await fs.writeFile(path.join(destination,'u1-build/index.html'),html,{flag:'wx'})
for(const [source,target] of [['handoff.json','handoff.json'],['validation-01/scope-final.json','scope-final.json']])await fs.copyFile(path.join(prior,source),path.join(destination,'u1-build',target))
await fs.writeFile(path.join(destination,'u1-build/identity.json'),JSON.stringify({capturedAt:new Date().toISOString(),directory:build,index,indexBytes:html.length,indexModifiedAt:stat.mtime.toISOString(),declaredAssets:[...html.toString('utf8').matchAll(/(?:src|href)="([^"]*assets\/[^\"]+)"/g)].map(match=>match[1]),boundary:'Original immutable U1 build index and original owned build receipts; metadata only, not a source hash or visual acceptance gate.'},null,2)+'\n',{flag:'wx'})
const runner=(await fs.readFile(path.join(prior,'run-validation.ts'),'utf8')).replace('.tmp-task-question-recovery-406/ui-after','.tmp-task-question-recovery-406/ui-after-u2')
await fs.writeFile(path.join(destination,'run-validation.ts'),runner,{flag:'wx'})
