import fs from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { spawnSync } from 'node:child_process'

const scratch = path.dirname(fileURLToPath(import.meta.url))
const root = path.resolve(scratch, '..')
const output = path.join(scratch, 'frontend-u3')
const files = [
  'packages/overlay/src/components/InteractionCard.tsx',
  'packages/overlay/src/components/ui/Checkbox.tsx',
  'packages/overlay/src/styles/surfaces/card.css',
]
await fs.mkdir(output, { recursive: false })
const git = (args) => {
  const result = spawnSync('git', args, { cwd: root, encoding: 'buffer', windowsHide: true })
  if (result.status !== 0) throw new Error(`Read-only git failed: ${result.stderr}`)
  return result.stdout
}
await fs.writeFile(path.join(output, 'status-before.txt'), git(['status', '--short']), { flag: 'wx' })
await fs.writeFile(path.join(output, 'source-before.patch'), git(['diff', '--', ...files]), { flag: 'wx' })
await fs.writeFile(path.join(output, 'index-before.patch'), git(['diff', '--cached', '--', ...files]), { flag: 'wx' })
for (const file of files) {
  const target = path.join(output, 'before', file)
  await fs.mkdir(path.dirname(target), { recursive: true })
  await fs.copyFile(path.join(root, file), target, 1)
}
const u2 = path.join(output, 'u2-build')
await fs.mkdir(u2)
const oldUI = path.join(scratch, 'ui-after-u2')
const oldIndex = await fs.readFile(path.join(oldUI, 'index.html'))
await fs.writeFile(path.join(u2, 'index.html'), oldIndex, { flag: 'wx' })
await fs.copyFile(path.join(scratch, 'frontend-u2/handoff.json'), path.join(u2, 'handoff.json'), 1)
await fs.copyFile(path.join(scratch, 'frontend-u2/validation-01/scope-final.json'), path.join(u2, 'scope-final.json'), 1)
await fs.writeFile(path.join(u2, 'identity.json'), JSON.stringify({
  capturedAt: new Date().toISOString(), uiDirectory: oldUI, indexBytes: oldIndex.length,
  assetReferences: [...oldIndex.toString('utf8').matchAll(/(?:src|href)="([^"]+)"/g)].map(match => match[1]),
  boundary: 'Saved actual prior build metadata and index; no variable-source hash acceptance gate.'
}, null, 2), { flag: 'wx' })
await fs.writeFile(path.join(output, 'source-allowlist.json'), JSON.stringify({
  capturedAt: new Date().toISOString(),
  scope: '406 U3: only add position:relative to the shared .interaction-card__option CSS rule',
  changedFiles: [files[2]], completeUIFiles: files,
  rootAuthorization: '406 spec Phase U3, paired real TabPanel scroll 0→195.333 with unchanged inner scroll',
  excluded: 'No inset, generic CSS, JS focus/scroll/state, SDK, UI tests, services, Providers, browsers, shared docs or Git writes.'
}, null, 2), { flag: 'wx' })
const previousRunner = await fs.readFile(path.join(scratch, 'frontend-u2/run-validation.ts'), 'utf8')
const oldOutput = '.tmp-task-question-recovery-406/ui-after-u2'
if (previousRunner.split(oldOutput).length !== 2) throw new Error('Expected unique old private output')
await fs.writeFile(path.join(output, 'run-validation.ts'), previousRunner.replace(oldOutput, '.tmp-task-question-recovery-406/ui-after-u3'), { flag: 'wx' })
console.log(JSON.stringify({ output, sourceFiles: files, changedFile: files[2], runnerDeadlineMilliseconds: 600000, oldUI, newUI: path.join(scratch, 'ui-after-u3') }))
