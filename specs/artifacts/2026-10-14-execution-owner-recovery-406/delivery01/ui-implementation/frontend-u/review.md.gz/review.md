# 406 Phase U source and supporting-check handoff

Exactly three authorized production files changed. Their original tracked and indexed diffs were both empty when captured. `before/`, `after/`, `source-allowlist.json` and `implementation.patch` preserve the exact scoped sources. No Question state, schema, reply, transport, i18n resource, RadioGroup, global selection-control stylesheet, SDK, other consumer or shared document was changed by this agent.

- InteractionCard native Radio now references its actual visible short-label span through its existing native attribute forwarding. Its original description ID/reference remains. Checkbox children now hold only the original short label and its description goes to the one registered primitive description slot. The obsolete caller-managed description ID path was removed.
- Checkbox uses the installed Kobalte Label and Description registries separately. Its existing optional caller Input ID is retained, otherwise a single mounted Solid unique ID supplies both Input and the Description's native label `for`. Description activation is browser-native; no click/key handler, hidden description or second selection state was added. Consumers without a description keep the original Label/Control content, with a stable generated Input ID.
- Base Question option styling now owns the grid structure already used by the Dialog. The Dialog retains its larger column gap, minimum hit height, padding and focus/hover styling. The control uses row 1 rather than spanning a guaranteed second row, and no two-row template is forced; only a real description creates row 2, so no-description inline rows do not reserve an empty row. Long content uses the existing minmax/min-inline-size and overflow wrapping. No pixel or DOM check is claimed here.

The installation and actual full source confirmed Kobalte Description supports its polymorphic label and native `for`; the package typecheck also passed. That is supporting API evidence, not proof of the browser's computed accessible name or pointer behavior. Root must inspect real Radio/Checkbox name and description, ordinary/Side/Dialog layout, description click exactly once, arrow/Space focus, disabled/empty/long cases and actual submitted values.

## Original check scope, now closed

`run-validation.ts` retains the original mature NodeProcess runner and exact commands. It ran only package-declaration typecheck, current CSS token checker and independent Node/Vite private build. No test suite or UI test ran.

- Original exec session **55842**, start chunk `8a4ff1`, final join chunk `d9eaf1`, exit **0**.
- Parent PID90684; started1791939288845; original fixed deadline1791939888845; finished1791939384308 (~95.5s). No extension.
- CSS tokens PID80436 / `9acb05a4-4c7e-47d0-a16e-5ed098e875ec`: exit0; 8794 references, 268 global tokens, 60 app stylesheets. The checker explicitly excludes selector-inheritance/visual correctness.
- Typecheck PID85928 / `4eb81af1-b1c9-45ee-bd53-1dd18f39e26a`: exit0.
- Node build PID76312 / `6d16f62f-fd59-4e62-a49e-583da804948f`: exit0, Vite reports 1m33s.
- All physical/output/request receipts are true and isolated runtime cleanup occurred afterwards. Full stdout/stderr/exits and start/final manifests remain in `validation-01/`. Original Radix directive, mixed import and large chunk warnings remain in build stderr.

Private output is `D:/myhexin-local/opencorvus/.tmp-task-question-recovery-406/ui-after`. The 405 bundles and shared dist-vite were not overwritten. Real UI acceptance is pending Root's fresh manual scope; no browser, product service or Provider was started by this agent.
