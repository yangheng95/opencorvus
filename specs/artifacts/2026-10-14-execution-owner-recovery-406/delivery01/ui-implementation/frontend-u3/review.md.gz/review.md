# 406 U3 implementation handoff

Root's fresh `options-side-single-before-focus03` actual geometry resolves the earlier read-only uncertainty: native ArrowDown Cedar→Iris changes the `#centerWorkbenchSideChat` scrollTop from 0 to 195.333328 while `.side-chat-panel__scroll` remains at 273.333343 and `#rightDockBody` remains 0. The panel's viewport rect is unchanged, while the inner transcript top moves 233.333343→38. The recorded offsetParent is null and is not replaced with an inferred DOM identity. The full ancestor styles and Input/Control rectangles support the containing-block mechanism already documented in `../question-focus-scroll-readonly.md`.

Implemented exactly one additional declaration in the existing shared `.interaction-card__option`: `position: relative`. This establishes the option as its absolute hidden input's containing block; the input and visible option now share the same local scroll ownership. Existing native focus/selection, short name/description, disabled semantics, fieldsets, drafts, state and replies are unchanged. No inset, generic primitive, JS focus/scroll interception or outer-overflow rule was added.

`before/` preserves all three current U2 sources and `source-before.patch`/`index-before.patch` preserve their pre-existing differences. `after/` preserves the final three sources. `implementation-u3.patch` is the single added declaration. `implementation-complete.patch` includes the combined U1/U2/U3 three-file delivery. InteractionCard and Checkbox were byte-identical before and after U3; this is bounded source-preservation evidence, not a UI correctness test. `u2-build/` preserves the old build's actual index and scope/handoff metadata; neither old private output was overwritten.

All supporting checks ran under the original single 600-second scope, parent 23680, started 1791943670659, deadline 1791944270659, finished 1791943737703:

- Overlay declaration typecheck: PID 87932 / d01ce74f-9ee3-464a-8c31-901620a92d9c, exit 0.
- Current CSS token checker: PID 90764 / a498c20a-78fa-4b3f-953b-9c166c9de34c, exit 0; 8,794 references, 268 global tokens. Its own output explicitly excludes selector inheritance from the static check.
- Isolated **Node.js** Vite build: PID 69752 / c1ef3f67-986d-43e7-bd79-67e271cd1e74, exit 0, reported 1m 5s. Output is `../ui-after-u3`; no shared dist-vite or SDK generation. Original stderr preserves dependency `use client`, mixed-import, and large-chunk warnings.

Each child receipt confirms physical, output and request settlement. The isolated runtime was removed only after all child joins. Original exec **80889** actually joined via write_stdin, chunk **396b5f**, exit **0**; start chunk **20abc0**. Commands, raw stdout/stderr, exit files, owner receipts, `scope-start.json`, `scope-final.json` and runner console are preserved without rerunning checks.

Root's final U3 Main single/multiple and Side single/multiple real pages, screenshots, native keyboard/visible-label interactions and actual Tool answers remain pending at this handoff. U1/U2 successful operations are not relabeled as U3 verification. No UI automated test was created, run or changed. No service, Provider or browser was started by this implementation/check scope.
