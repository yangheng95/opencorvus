$ErrorActionPreference = 'Stop'
$repoDirectory = 'D:/myhexin-local/opencorvus'
$bunDirectory = Join-Path $repoDirectory '.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64'
$env:PATH = $bunDirectory + ';' + $env:PATH
Set-Location -LiteralPath $repoDirectory
& (Join-Path $bunDirectory 'bun.exe') '.tmp-task-question-recovery-406/frontend-u3/run-validation.ts' 2>&1 | Tee-Object -FilePath '.tmp-task-question-recovery-406/frontend-u3/runner-console.log'
$validationExit = $LASTEXITCODE
Set-Content -LiteralPath '.tmp-task-question-recovery-406/frontend-u3/runner.exit' -Value $validationExit -NoNewline
exit $validationExit
