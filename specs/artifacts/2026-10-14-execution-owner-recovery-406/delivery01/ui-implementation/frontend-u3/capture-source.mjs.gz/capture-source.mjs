import fs from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { spawnSync } from 'node:child_process'

const output = path.dirname(fileURLToPath(import.meta.url))
const root = path.resolve(output, '../..')
const scope = JSON.parse(await fs.readFile(path.join(output, 'source-allowlist.json'), 'utf8'))
for (const file of scope.completeUIFiles) {
  const after = path.join(output, 'after', file)
  await fs.mkdir(path.dirname(after), { recursive: true })
  await fs.copyFile(path.join(root, file), after, 1)
}
const step = spawnSync('git', ['diff', '--no-index', '--', path.join(output, 'before', scope.changedFiles[0]), path.join(output, 'after', scope.changedFiles[0])], { cwd: root, encoding: 'buffer', windowsHide: true })
if (![0, 1].includes(step.status)) throw new Error(String(step.stderr))
await fs.writeFile(path.join(output, 'implementation-u3.patch'), step.stdout, { flag: 'wx' })
const complete = spawnSync('git', ['diff', '--', ...scope.completeUIFiles], { cwd: root, encoding: 'buffer', windowsHide: true })
if (complete.status !== 0) throw new Error(String(complete.stderr))
await fs.writeFile(path.join(output, 'implementation-complete.patch'), complete.stdout, { flag: 'wx' })
const frozenSourceIdentity = []
for (const file of scope.completeUIFiles.slice(0, 2)) {
  const before = await fs.readFile(path.join(output, 'before', file))
  const after = await fs.readFile(path.join(output, 'after', file))
  frozenSourceIdentity.push({ file, beforeBytes: before.length, afterBytes: after.length, sameBytes: before.equals(after) })
}
const report = { capturedAt: new Date().toISOString(), frozenSourceIdentity, stepDiff: 'implementation-u3.patch', completeDiff: 'implementation-complete.patch', boundary: 'Source preservation and bounded diff review only; not a UI correctness test.' }
await fs.writeFile(path.join(output, 'source-review.json'), JSON.stringify(report, null, 2), { flag: 'wx' })
console.log(JSON.stringify(report))
