import fs from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { spawnSync } from 'node:child_process'

const output = path.dirname(fileURLToPath(import.meta.url))
const root = path.resolve(output, '../..')
const scope = JSON.parse(await fs.readFile(path.join(output, 'validation-01/scope-final.json'), 'utf8'))
const allowlist = JSON.parse(await fs.readFile(path.join(output, 'source-allowlist.json'), 'utf8'))
const status = spawnSync('git', ['status', '--short'], { cwd: root, encoding: 'buffer', windowsHide: true })
if (status.status !== 0) throw new Error(String(status.stderr))
await fs.writeFile(path.join(output, 'status-after.txt'), status.stdout, { flag: 'wx' })
const identity = []
for (const file of allowlist.completeUIFiles) {
  const saved = await fs.readFile(path.join(output, 'after', file))
  const current = await fs.readFile(path.join(root, file))
  identity.push({ file, capturedBytes: saved.length, currentBytes: current.length, sameBytes: saved.equals(current) })
}
const handoff = {
  status: 'U3 source frozen; all supporting checks and original exec closed; Root real U3 acceptance pending',
  changedFiles: allowlist.changedFiles,
  completeUIFiles: allowlist.completeUIFiles,
  originalExec: { sessionID: 80889, startChunk: '20abc0', joinChunk: '396b5f', exitCode: 0 },
  parentPID: scope.parentPID, startedAt: scope.startedAt, originalDeadlineAt: scope.deadlineAt, finishedAt: scope.finishedAt,
  checks: scope.checks.map(check => ({ name: check.name, pid: check.pid, occurrenceID: check.occurrenceID, exitCode: check.receipt?.exitCode, physicalJoined: check.physicalJoined, outputJoined: check.outputJoined, requestSettled: check.requestSettled })),
  runtimeRemoved: scope.runtimeRemoved,
  runtimeRemovedAfterPhysicalJoin: scope.runtimeRemovedAfterPhysicalJoin,
  uiDirectory: scope.uiDirectory,
  indexBytes: (await fs.stat(path.join(scope.uiDirectory, 'index.html'))).size,
  stepDiff: 'implementation-u3.patch', completeDiff: 'implementation-complete.patch', priorBuild: 'u2-build/identity.json',
  frozenSourceIdentity: identity,
  boundary: 'Only local option position:relative added; no inset/global CSS/JavaScript/Question state/SDK change. Types/CSS/build are supporting checks, not real UI acceptance. Original U1/U2 and failed pre-fix page observations remain unchanged.'
}
await fs.writeFile(path.join(output, 'handoff.json'), JSON.stringify(handoff, null, 2), { flag: 'wx' })
console.log(JSON.stringify(handoff, null, 2))
