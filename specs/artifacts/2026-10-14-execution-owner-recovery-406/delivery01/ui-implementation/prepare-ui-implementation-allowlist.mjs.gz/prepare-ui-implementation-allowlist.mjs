import fs from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const base = path.dirname(fileURLToPath(import.meta.url))
const originalAnalysis = [
  'capture-ui-analysis.mjs',
  'scratch406-ui-analysis.md',
  'scratch406-ui-callers.json',
  'scratch406-ui-source-excerpts.json',
  'checkbox-followup-readonly.md',
  'non-question-checkbox-entry.md',
  'question-focus-scroll-readonly.md',
  'prepare-frontend-u.mjs',
  'prepare-frontend-u2.mjs',
  'prepare-u3.mjs',
]
const sources = [
  'packages/overlay/src/components/InteractionCard.tsx',
  'packages/overlay/src/components/ui/Checkbox.tsx',
  'packages/overlay/src/styles/surfaces/card.css',
]
const checkFiles = [
  'scope-start.json', 'scope-final.json',
  ...['typecheck', 'css-tokens', 'build'].flatMap(check => [
    `${check}-owner.json`, `${check}.stdout.log`, `${check}.stderr.log`, `${check}.exit`,
  ]),
]
const commonPhaseFiles = [
  'handoff.json', 'review.md', 'run-validation.ts', 'source-allowlist.json',
  'source-before.patch', 'index-before.patch', 'status-before.txt', 'status-after.txt',
  ...sources.flatMap(source => [`before/${source}`, `after/${source}`]),
  ...checkFiles.map(file => `validation-01/${file}`),
]
const phaseFiles = {
  'frontend-u': ['implementation.patch'],
  'frontend-u2': ['implementation-u2.patch', 'implementation-complete.patch', 'u1-build/identity.json'],
  'frontend-u3': ['implementation-u3.patch', 'implementation-complete.patch', 'u2-build/identity.json', 'capture-source.mjs', 'finalize-handoff.mjs', 'launch-validation.ps1', 'runner-console.log', 'runner.exit', 'source-review.json'],
}
const exact = [
  ...originalAnalysis.map(source => ({ source, category: 'analysis-and-preparation' })),
  ...Object.entries(phaseFiles).flatMap(([phase, extra]) => [...commonPhaseFiles, ...extra].map(file => ({ source: `${phase}/${file}`, category: phase }))),
  { source: 'ui-implementation-reading-summary.md', category: 'reading-guide' },
  { source: 'prepare-ui-implementation-allowlist.mjs', category: 'allowlist-preparation' },
]
const files = []
for (const item of exact) {
  const data = await fs.readFile(path.join(base, item.source))
  const isGuide = item.category === 'reading-guide'
  files.push({
    ...item,
    sourceBytes: data.length,
    destination: isGuide ? 'ui-implementation/README.md' : `ui-implementation/${item.source}.gz`,
    encoding: isGuide ? 'identity' : 'gzip',
  })
}
const scopes = []
for (const phase of Object.keys(phaseFiles)) {
  const final = JSON.parse(await fs.readFile(path.join(base, phase, 'validation-01/scope-final.json'), 'utf8'))
  const handoff = JSON.parse(await fs.readFile(path.join(base, phase, 'handoff.json'), 'utf8'))
  scopes.push({
    phase,
    originalExec: handoff.originalExec,
    parentPID: final.parentPID, startedAt: final.startedAt, deadlineAt: final.deadlineAt, finishedAt: final.finishedAt,
    checks: final.checks.map(check => ({ name: check.name, pid: check.pid, occurrenceID: check.occurrenceID, receipt: check.receipt, physicalJoined: check.physicalJoined, outputJoined: check.outputJoined, requestSettled: check.requestSettled })),
    runtimeRemoved: final.runtimeRemoved, runtimeRemovedAfterPhysicalJoin: final.runtimeRemovedAfterPhysicalJoin,
  })
}
const grouped = Object.fromEntries([...new Set(files.map(file => file.category))].map(category => [category, { files: files.filter(file => file.category === category).length, bytes: files.filter(file => file.category === category).reduce((sum, file) => sum + file.sourceBytes, 0) }]))
const report = {
  status: 'frozen-prepared-allowlist; archive not executed',
  preparedAt: new Date().toISOString(), sourceBase: base,
  proposedDestinationBase: 'Root-selected 406 evidence directory',
  fileCount: files.length, sourceBytes: files.reduce((sum, file) => sum + file.sourceBytes, 0), jpegCount: 0,
  grouped, scopes,
  policy: { exactSourcesOnly: true, copyExecuted: false, compressionExecuted: false, specsWritten: false, uiAutomation: false, credentialFilesRead: false,
    captureRequirement: 'For eventual gzip capture, compare decompressed original bytes with the allowed original input; do not use mutable-source hashes as a UI/functionality gate.' },
  excludes: ['Root ten options-* manual scopes and sibling lifecycle/log records', 'manual helper/server/provider/relay/checker sources and helper preparation evidence', 'all private ui-after* bundles/assets/index HTML', 'runtime home/DB/auth/models/full Provider payloads', 'backend Phase P evidence', 'specs/shared docs/peer diffs/Git indexes', 'duplicate prior handoff/scope-final copies already preserved under canonical stages'],
  files,
}
await fs.writeFile(path.join(base, 'ui-implementation-archive-allowlist.json'), JSON.stringify(report, null, 2), { flag: 'wx' })
console.log(JSON.stringify({ status: report.status, fileCount: report.fileCount, sourceBytes: report.sourceBytes, jpegCount: 0, grouped, scopeCount: scopes.length, processCount: scopes.reduce((sum, scope) => sum + scope.checks.length, 0), archiveExecuted: false }, null, 2))
