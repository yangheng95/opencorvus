# 406 U2 — existing Checkbox name forwarded to the native Input

U2 changes exactly two lines in `packages/overlay/src/components/ui/Checkbox.tsx`: split the existing `aria-label` prop out of Root's rest props, then pass that same reactive value to the sole Kobalte Input. The four current label-free callers keep their existing translated name and callbacks. No caller, translation, description, ID, selection event, hidden-input style, Radio or layout change was made in this step.

The Input is the semantic checkbox and Kobalte fieldProps already consumes aria-label. Removing the prop from the Root prevents continuing the old named-group/unnamed-input path. Current consumers with visible children still use their registered Label. U2 does not claim to explain or fix the earlier role-based No description click; the original only-Cedar result and its misleading intended screenshot filename remain unchanged.

Before editing, the full U1 three-file state and existing diff were captured under `before/`, `source-before.patch` and `index-before.patch`. `u1-build/` preserves the original index HTML, original build handoff/final receipt and declared asset identities. The original `ui-after` build directory remains intact. `implementation-u2.patch` is the exact two-line delta; `implementation-complete.patch` is the complete current three-file Phase U change. `after/` preserves those final sources.

## Actual supporting checks and closure

Only the same three supporting checks ran, under one fresh fixed 600-second NodeProcess scope. No UI or non-UI test suite, browser, product service, Provider or model was started.

- Original exec **13763**, start chunk `a07066`, final join chunk `7a4bdd`, exit **0**.
- Parent PID88432; original start1791940989490; deadline1791941589490; finish1791941048446. The original scope finished in about59 seconds; no extension.
- Typecheck PID67552, CSS token PID90092, Node/Vite build PID89444 each exited0 and joined physical/output/request. Exact occurrence IDs and command arguments are in `validation-01/*-owner.json` and the final manifest.
- CSS token graph: 8794 references,268 globals. Its own log explicitly excludes selector-inheritance/visual proof.
- All child output settled before parent isolated-runtime cleanup. Complete original stdout/stderr/exits are retained, including existing vendor directive/mixed import/chunk-size warnings.

New private UI: `D:/myhexin-local/opencorvus/.tmp-task-question-recovery-406/ui-after-u2`. Original U1 and 405 private builds and shared dist-vite were not overwritten. Root must use this new output for U2 actual English/Chinese named-input, existing visible-label, pointer/native keyboard and public configuration restoration acceptance. U1 screenshots cannot establish U2 acceptance.
