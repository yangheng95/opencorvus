import fs from 'node:fs/promises'
import path from 'node:path'
import {spawnSync} from 'node:child_process'
const root=path.dirname(import.meta.dirname), output=path.join(import.meta.dirname,'frontend-u')
const files=['packages/overlay/src/components/InteractionCard.tsx','packages/overlay/src/components/ui/Checkbox.tsx','packages/overlay/src/styles/surfaces/card.css']
await fs.mkdir(output,{recursive:false})
for(const file of files){const target=path.join(output,'before',file);await fs.mkdir(path.dirname(target),{recursive:true});await fs.copyFile(path.join(root,file),target)}
for(const [name,args] of [['source-before.patch',['diff','--',...files]],['index-before.patch',['diff','--cached','--',...files]],['status-before.txt',['status','--short']]]){const result=spawnSync('git',args,{cwd:root,encoding:'utf8',windowsHide:true});if(result.status!==0)throw Error(result.stderr);await fs.writeFile(path.join(output,name),result.stdout,{flag:'wx'})}
await fs.writeFile(path.join(output,'source-allowlist.json'),JSON.stringify({capturedAt:new Date().toISOString(),scope:'406 Phase U approved three production files only',files},null,2)+'\n',{flag:'wx'})
