import fs from 'node:fs/promises'
import path from 'node:path'
import { spawnSync } from 'node:child_process'
import { createRequire } from 'node:module'
const root = path.dirname(import.meta.dirname), output = import.meta.dirname
const require = createRequire(path.join(root, 'packages/overlay/package.json'))
const checkboxEntry = require.resolve('@kobalte/core/checkbox')
const chunks = path.resolve(path.dirname(checkboxEntry), '../chunk')
const selections = [
  ['packages/overlay/src/components/InteractionCard.tsx', [[28,64],[69,91],[130,209],[245,333],[414,437]]],
  ['packages/overlay/src/components/ui/RadioGroup.tsx', [[1,40]]],
  ['packages/overlay/src/components/ui/Checkbox.tsx', [[1,35]]],
  ['packages/overlay/src/styles/primitives/selection-control.css', [[1,27],[55,86],[121,138]]],
  ['packages/overlay/src/styles/surfaces/card.css', [[1165,1237],[1337,1419]]],
  ['packages/overlay/src/components/InteractionDialogHost.tsx', [[27,70]]],
  ['packages/overlay/src/components/CardParts.tsx', [[108,126]]],
  ['packages/overlay/src/components/SideChatPanel.tsx', [[485,501]]],
  ['packages/overlay/src/utils/question-interaction.ts', [[38,111]]],
  ['packages/opencorvus/src/question/types.ts', [[20,53]]],
  ['specs/current/architecture/07-panel-reactivity.md', [[233,262]]],
  ['specs/current/architecture/07-panel.md', [[715,733]]],
  [path.relative(root, path.join(chunks, 'KSJIJAOF.js')), [[39,69],[112,131],[191,218],[229,239]]],
  [path.relative(root, path.join(chunks, 'HYP2U57X.js')), [[1,30]]],
  [path.relative(root, path.join(chunks, 'YKGT7A57.js')), [[7,45],[61,104]]],
  [path.relative(root, path.join(chunks, '7ZHN3PYD.js')), [[1,45]]],
]
const excerpts = []
for (const [file, ranges] of selections) {
  const lines = (await fs.readFile(path.join(root, file), 'utf8')).split(/\r?\n/)
  excerpts.push({ file: file.replaceAll('\\','/'), ranges: ranges.map(([first,last]) => ({ first, last, lines: lines.slice(first-1,last).map((text,i)=>({line:first+i,text})) })) })
}
await fs.writeFile(path.join(output,'scratch406-ui-source-excerpts.json'),JSON.stringify({capturedAt:new Date().toISOString(),checkboxEntry,excerpts},null,2)+'\n')
const searches = [
  ['rg','-n','<InteractionCard|<Radio\\b|<RadioGroup\\b|<Checkbox\\b|inputAriaDescribedBy','packages/overlay/src'],
  ['rg','-n','interaction-card__option|oc-radio-label|oc-checkbox-label','packages/overlay/src'],
  ['rg','-n','InteractionCard|interaction-card|RadioGroup|Checkbox|selection-control|surfaces/card','packages','-g','*test*','-g','*spec*','-g','!*.json','-g','!*.snap'],
  ['rg','-n','questionInteraction|prepareQuestionInteractions|interactionToCardSeeds|collectDialogInteractions','packages/overlay/src'],
  ['rg','-n','interaction-card__option|inputAriaDescribedBy|consecutive-interaction-dialog|Question.*primitive','specs','-g','*.md'],
]
const results = searches.map(([executable,...args])=>{const r=spawnSync(executable,args,{cwd:root,encoding:'utf8',windowsHide:true});return {command:[executable,...args],exit:r.status,stdout:r.stdout,stderr:r.stderr}})
await fs.writeFile(path.join(output,'scratch406-ui-callers.json'),JSON.stringify({capturedAt:new Date().toISOString(),results},null,2)+'\n')
console.log(JSON.stringify({excerpts:excerpts.length,searches:results.map(x=>({command:x.command,exit:x.exit}))}))
