# 406 Question option layout and accessible-name investigation — read only

## Recall and scope

The user requested continuous evidence-led batches: investigation and recorded root-cause/impact analysis before implementation, real desktop interaction and original screenshots/manual review, focused positive non-UI checks, bounded ownership, then scoped delivery. Root delegated one read-only UI issue for 406: actual 405 Main/Side inline Question options appear as `CedarRecord...` / `IrisRecord...`, while the Dialog visibly separates short label and description; Root also reported the same joined accessible names. No new agent, browser, service, Provider, credential use, UI automation/test or production edit is authorized here. Root will read this report, write the 406 Recall/decision and authorize implementation separately.

405 commit `ba5f55cb3647385db64bc77a93260619e2ef3fb5` and its archives are not changed. Its separate transport recovery/history changes are retained. The backend Question/Permission recovery investigation is independent: this option rendering issue does not justify changing scheduling, publication, Task ownership, request schema or tool choice.

Read: current AGENTS; 07-panel Side Chat renderer contract and 07-panel-reactivity immutable Question/phase contracts; current InteractionCard, InteractionDialogHost, CardParts, SideChatPanel, Question normalizer/schema, RadioGroup/Checkbox primitives, selection-control.css and the interaction rules in card.css; actual installed Kobalte 0.13.11 checkbox/form-control implementation. Historical records read include primitive UI 2026-09-21 and 402/404/405. Repository definition/caller/style/test/history searches are saved with their commands in `scratch406-ui-callers.json`; 16 selected source excerpts with original line numbers and the actual installed resolution path are in `scratch406-ui-source-excerpts.json`. `capture-ui-analysis.mjs` records the read-only capture. No Git history rewrite/checkout/commit or new branch occurred; only the required workspace status was read. Exact introduction commit for the CSS split is therefore not claimed.

## Actual visual evidence and limits

I opened and manually read these original 405 JPEGs, without re-encoding, crop, screenshot comparison or browser action:

1. `../.tmp-task-question-recovery-405/side-question-after01/side-draft-before-cut.jpg`: the real Side pending card visibly renders `CedarRecord the public Cedar example` and `IrisRecord the public Iris example`. The short label and description have different weight/color but touch without spacing. The original header/body and editable draft are visible.
2. `../.tmp-task-question-recovery-405/empty-expiry-after01/pending-dialog-zh.jpg`: the real Main Dialog places `Cedar` above `Record the public Cedar example`, likewise Iris, with a clear text column, radio control and focus outline. Product chrome is Chinese and authored Question/option text remains English.

Root supplied the actual Main inline and AX (accessibility-tree) joined-name observation. This agent has not reopened that page or obtained a new AX snapshot; do not relabel the two images above as independently proving the Main inline or AX names. The same production component/style path explains the shared exposure. Dialog's visual spacing is proven by the original image; its semantic name/description separation is **not** independently proven and is suspect from the same label markup.

## Root cause: visual layout

- `InteractionCard.tsx:266–287` sends each native Radio two adjacent span children: short `.interaction-card__option-label` and optional `.interaction-card__option-desc`. The multi-select branch at 299–315 sends the same two spans to Checkbox.
- `ui/RadioGroup.tsx:25–36` wraps both children in one `.oc-radio-label` span inside the native label. `ui/Checkbox.tsx:25` wraps both inside one Kobalte Label with `.oc-checkbox-label`.
- `selection-control.css:1–9` makes the option root inline-flex with a gap between its **control and one label wrapper**. A flex gap does not separate the wrapper's two inline spans. Base `card.css:1195–1213` styles their color/font/wrapping but does not give those spans a block/grid relationship or a text gap.
- Dialog-only `card.css:1358–1419` supplies a two-column/two-row grid, makes the label wrapper `display:contents`, and explicitly positions short label at row 1 and description at row 2. That is why its screenshot reads correctly. The same structure is missing from the base inline rule.

This is not a missing space in the authored data. The public Question Option shape already contains separate `label` and `description` strings. The strict normalizer preserves them separately. Adding whitespace to those strings, using a `Cedar`/`Record` keyword patch, or translating model content would alter facts and leave the layout contract broken for wrapped/multiline descriptions.

## Root cause: semantic name versus description

Both spans currently belong to the same naming label. Radio is a native input inside a native label. Checkbox Input obtains `aria-labelledby` from the registered Kobalte Label, whose children contain **both** label and description. The existing `aria-describedby` additionally references the description; it does not remove it from the accessible name. CSS row spacing can improve pronunciation/spacing but cannot by itself establish a concise name plus separate description.

Important installed-library evidence:

- Actual Overlay resolution is `node_modules/.bun/@kobalte+core@0.13.11+ee58d66d663bac7b/node_modules/@kobalte/core/dist/checkbox/index.js`, which imports `chunk/KSJIJAOF.js`.
- Checkbox Input calls `createFormControlField` (`HYP2U57X.js`) and exposes its computed ARIA attributes. `createFormControl.getAriaLabelledBy` (`YKGT7A57.js:18–27`) combines caller `aria-labelledby` **and the registered Label ID**. Adding a wrapper `inputAriaLabelledBy` prop while leaving the long registered Label unchanged would still include the long text; it is not a root fix.
- `Checkbox.Description` is already publicly exported. It delegates to `FormControlDescription`, registers one description ID with the existing control owner and unregisters via the component cleanup. `getAriaDescribedBy` joins that registered description and any current error/explicit reference.
- `Checkbox.Label` uses the same form-control context to register the label ID and native `for` target. The mature Label/Description roles are separate; no second state or message source is needed.

The [WAI naming guidance](https://www.w3.org/WAI/ARIA/apg/practices/names-and-descriptions/) distinguishes concise names from supplemental descriptions and prefers visible text/native labels. The [Kobalte Checkbox documentation](https://kobalte.dev/docs/core/components/checkbox/) exposes Label and Description composition. The [HTML label contract](https://html.spec.whatwg.org/multipage/forms.html#the-label-element) provides activation through `for`; the proposal below uses that rather than adding a custom click/keyboard toggle. [WAI Radio](https://www.w3.org/WAI/ARIA/apg/patterns/radio/) and [Checkbox](https://www.w3.org/WAI/ARIA/apg/patterns/checkbox/) describe the keyboard contracts that must remain intact. Current docs inform semantics; the installed 0.13.11 code above is the implementation fact.

## Complete production impact

There are exactly three production JSX consumers of InteractionCard:

| Consumer | Current owner and exposure | Proposed effect |
| --- | --- | --- |
| `CardParts.tsx:122` | Main pending Question or Permission part. Main Chat/Work/Mission Session projections share it; Task uses its Board interaction owner. | Pending Question options use the corrected structure. Permission actions and resolved Question TextPart phases remain unchanged. |
| `InteractionDialogHost.tsx:64` | Same card with `surface="dialog"`; host retains keyed original interaction/dismissed-ID behavior. | Keep Dialog geometry/owner/actions; make its name/description relationship correct too. No keyed remount or draft migration. |
| `SideChatPanel.tsx:495` | Exact Side Session pending interactions and its explicit content-change callback. | Same option layout and semantics, important in the narrower Dock. No change to stream, request targeting or Main refresh. |

`Board.tsx` contains a comment about the shared renderer, not a fourth renderer. Native Radio/RadioGroup have only InteractionCard as production callers.

Shared Checkbox currently has eight JSX call sites across six files: InteractionCard; FileChangesView; two MailboxPanel controls; MissionCreateDialog; ContinuousGoalControl; two ConversationCapabilityPanel controls. Only InteractionCard passes `inputAriaDescribedBy`. Other callers include label-free accessible-name props and a Mission label with its own strong/small description composition. They must not be silently restructured or declared visually fixed by this batch. A new optional description slot should add markup only when supplied; existing `children`, root attributes, disabled/readOnly/indeterminate state and handlers remain intact. Root should sample one existing non-Question labeled Checkbox after any primitive edit. Any unrelated existing label-free naming concern is a separate unproven candidate, not permission to widen this fix.

Question Option schema (`question/types.ts`) requires string `value`, `label`, `description`; `disabled` is optional. Empty strings are currently legal. InteractionCard's internal interface permits optional description, so no-description rows must stay valid and not reserve a phantom text row. Do not add schema validation, label fallback, SDK generation or user/model-text rewriting. The option's stable `value`, not its label/description, remains the answer identity.

## Recommended minimal implementation — three production files

This is a proposal, not an implementation authorization.

1. **`InteractionCard.tsx`: keep the single renderer and current state.**
   - For Radio, give the existing visible short-label span a stable ID derived from the current `questionID()` and option index; pass native `aria-labelledby` to that ID. Keep the existing original description span ID and `aria-describedby` linkage. RadioProps already forwards these native input attributes, so RadioGroup.tsx does not need a new API or another renderer.
   - For Checkbox, pass `opt.description` into the primitive's optional description slot; its children hold only the original short-label span. Remove the now-replaced description-in-Label span and the caller-managed `inputAriaDescribedBy` reference. Keep current name, checked/disabled/data-selected/onChange, option values and per-instance question identity.
   - No changes to questions(), drafts/customText, `initialQuestionDrafts`, selection toggling, runAction/authority/selectEpoch, replies, default header/icon, countdown or resolved history.
2. **`ui/Checkbox.tsx`: use existing Kobalte Label/Description.**
   - Add one optional description content prop (a string is sufficient for the current Question contract). Render it using `KobalteCheckbox.Description`, separate from `KobalteCheckbox.Label`; the library owns description registration/cleanup. No dependency patch and no manually stored ARIA state.
   - Preserve clicking the visible description by rendering the Description polymorphically as a native `label` with `for` pointing to the same Input ID. Kobalte Description registers only the description ID, so the Input's explicit `aria-labelledby` remains the concise registered Label. This is native activation, not a new onClick/onKeyDown toggle. The proposed markup needs actual-browser confirmation before acceptance.
   - To provide a stable `for` target, resolve the existing optional `inputID` once per mounted Checkbox with a Solid `createUniqueId` default, pass it to Input and Description. It must not depend on checked state, locale or render count. Caller-supplied inputID remains exact. Input's existing hidden/control/label association and field registration remain owned by Kobalte.
   - `inputAriaDescribedBy` has one current caller and is replaced here by the registered Description. Its definition, split prop and Input forwarding become unused within the full repository; remove them together **if Root approves this exact replacement scope**. Do not leave two independent description sources for the same Question.
   - The Description branch is absent for all other current Checkbox callers. Keep their current Label markup. This avoids converting the entire Root to a label (which would risk double activation through the existing Control onClick).
3. **`styles/surfaces/card.css`: promote the existing structural layout.**
   - Reuse the Dialog's control/text two-column grid at the base `.interaction-card__option` level, with `minmax(0,1fr)`, explicit short-label/description rows and existing gap/typography tokens. Include the new direct `.oc-checkbox-description` slot in the same description row/style.
   - Apply the existing wrapper `display:contents` and control/text placement coherently to all Question surfaces. Keep a no-description option compact. Native hidden Input must not consume a grid cell; its existing absolute/visually-hidden style already prevents normal grid layout participation.
   - Dialog keeps only its intended larger column gap, padding, minimum hit height, hover/selected/focus treatment and pane sizing. Move rather than duplicate structural selectors. Base inline stays compact; it does not inherit Dialog's large padding/48px minimum.
   - Long authored label/description must wrap within the text column using existing overflow-wrap/min-inline-size tokens. No new global selection-control override or stylesheet ownership is necessary.

The alternative of just putting an explicit `aria-labelledby` on Kobalte Input is rejected by actual library concatenation. Appending literal spaces, relying on CSS-generated whitespace, or setting `aria-hidden` on the authored description would avoid the real semantic composition and is not recommended. Replacing native Radio wholesale or adding a second inline-specific Question component is unnecessary.

## Historical decisions and why earlier changes did not cover this

The September primitive record establishes shared primitive ownership and manual visual checks, but does not document accepting these pending Question option layouts. Current source implements a shared renderer while retaining a Dialog-only structural override. That is the concrete old-path gap; exact introduction commit is unknown in this no-history-command phase.

402 changed pending Permission projection and action-source refresh, 404 changed immutable Question snapshot/reconnect ownership, and 405 changed transient Side feedback plus resolved Question historical captions. Those contracts do not repair the **pending option children** or their base layout. The 405 Side screenshot exposes the existing pending row defect even though its exact draft and reply succeeded. Neither successful business completion nor an attractive Dialog proves inline layout/accessibility correctness.

## Tests found and authorized verification direction

Repository searches for the touched components/classes/primitives in test/spec paths found only `packages/overlay/test/side-chat-transport.test.ts:6`, an `import type InteractionData` used by pure transport/state tests. It does not render a component or inspect UI source and should not be deleted. No matching UI automation, render/DOM/snapshot/source-label test or exclusive fixture was found in this touched scope; there is therefore no evidenced UI test deletion list. None was run. Do not create a formatter/text or DOM assertion to test this UI change.

After Root's spec/approval, supporting checks can be current Overlay typecheck, relevant CSS token check and independent private Node/Vite build under the mature fixed owner. They do not replace the following Root manual desktop acceptance:

1. Use a fresh owned product `/ui`, controlled **streaming** Question producer and the original bounded driver. Start with the same real short Cedar/Iris label+description that exposed the bug. Inspect Dialog, dismiss it normally, inspect Main inline, then the real independent Side Question. Do not use a synthetic standalone component page.
2. Verify a concise actual control name (`Cedar`) and separately linked original description, plus visible two-line text. Capture actual AX and read-only DOM ID associations when useful; do not infer accessible-name success from a screenshot or a get-by-text match. Dialog shares this semantic check despite its already-good prior screenshot.
3. Use actual radio Tab/Shift+Tab/arrow/Space behavior, click label and description, then submit one exact option value. Check actual Question Tool answers/natural final with the existing public positive API checker. Verify disabled options remain truly disabled and custom text remains editable.
4. Use another legitimate Question with `multiple:true` to exercise the Kobalte path, descriptions and actual Space/click toggling; submit the exact selected values. This is necessary because only Radio has the observed 405 picture. Test description click specifically: native `label[for]` should toggle once, not twice.
5. Include a no-description row and a long wrapping label/description in a fresh natural Question input. Real narrow Side layout and ordinary desktop Main/Dialog must remain readable without horizontal text overflow; do not claim mobile coverage.
6. Switch product English/Chinese through actual Settings. Product controls/title/focus remain localized; authored option/header/body/answer remain literal. Sample one current non-Question Checkbox consumer (e.g. Continuous Goal Resume) for unchanged selection and label behavior if the shared wrapper is changed. Preserve a pending draft while inspecting; no language-key remount or alternate draft store.
7. Capture clear before/after JPEGs, manually inspect full target areas, and complete original page/service/Provider/parent cleanup. Fix actual layout findings, then recheck that same area; do not prolong original scopes or replace a missed visual window with typecheck success.

## Remaining unknowns / risks

No new UI page, AX dump, multi-select case, long-text case, description-click behavior, empty option label, disabled option, light theme, full-screen scenario, Task/Mission actual Question, screen reader or mobile acceptance was run by this investigation. Main inline and AX observations originate from Root, not a new automated reproduction. Proposed Description-as-label native activation plus Kobalte explicit name registration is source-supported but must be verified in the actual desktop browser. Its owner IDs must stay per-instance to avoid inline/Dialog duplicate IDs; current InteractionCard prefix already includes a Solid unique instance ID.

The report identifies a presentation/semantic issue with intact raw fields, not a new scheduling or terminal convergence failure. 406 backend owner/fence work remains independent. This scratch report is not a spec or a delivery approval; Root owns Recall, final allowed source scope, real before/after evidence, shared documents and scoped commit/push.
