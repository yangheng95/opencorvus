import fs from 'node:fs'
import assert from 'node:assert/strict'
import {execFileSync} from 'node:child_process'
const root='.tmp-task-question-recovery-406'
const git=(args,input)=>execFileSync('git',args,{input,encoding:'utf8',windowsHide:true,maxBuffer:64*1024*1024})
const receipt=JSON.parse(fs.readFileSync(root+'/final-commit.json','utf8'))
assert.equal(git(['rev-parse',receipt.commit+'^']).trim(),receipt.base)
const indexes=['specs/README.md','specs/artifacts/README.md','specs/records/2026-10/README.md','CHANGELOG.md']
const whole=receipt.paths.filter(file=>!indexes.includes(file))
const mode=new Map()
for(let at=0;at<whole.length;at+=80){
 const files=whole.slice(at,at+80),current=git(['ls-files','--stage','--',...files])
 const entries=text=>new Map(text.trim().split('\n').filter(Boolean).map(line=>{const [entry,file]=line.split('\t');return[file,entry]}))
 const before=entries(git(['ls-tree',receipt.base,'--',...files]).replaceAll(' blob ',' '))
 const after=entries(git(['ls-tree',receipt.commit,'--',...files]).replaceAll(' blob ',' '))
 for(const [file,entry] of entries(current)){
  const fields=entry.split(' ');assert.equal(fields[2],'0')
  const value=fields.slice(0,2).join(' ')
  assert(value===before.get(file)||value===after.get(file),'Unrelated staged change in owned path: '+file)
 }
 const owned=git(['ls-tree',receipt.commit,'--',...files]).replaceAll(' blob ',' ')
 git(['update-index','--index-info'],owned)
 for(const file of files)mode.set(file,'owned entry synchronized')
}
for(const file of indexes){
 const base=git(['show',receipt.base+':'+file]),after=git(['show',receipt.commit+':'+file])
 const ownPatch=git(['diff',receipt.base,receipt.commit,'--',file])
 if(base===after)continue
 try{git(['apply','--cached','--check','-'],ownPatch);git(['apply','--cached','-'],ownPatch);mode.set(file,'exact owned patch applied')}
 catch(error){
  const current=git(['show',':'+file])
  assert.equal(current,after,'Owned partial patch needs review; preserve staged content: '+file)
  mode.set(file,'already synchronized')
 }
}
receipt.indexReconciled=true
fs.writeFileSync(root+'/final-commit.json',JSON.stringify(receipt,null,2))
fs.writeFileSync(root+'/index-reconcile.json',JSON.stringify({at:Date.now(),base:receipt.base,commit:receipt.commit,paths:mode.size,details:Object.fromEntries(mode)},null,2))
console.log(JSON.stringify({commit:receipt.commit,paths:mode.size,indexReconciled:true}))
