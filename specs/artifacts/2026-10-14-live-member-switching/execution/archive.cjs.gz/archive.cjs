const fs=require('node:fs'),path=require('node:path'),z=require('node:zlib'),assert=require('node:assert/strict');
const scratch=__dirname,out=path.resolve('specs/artifacts/2026-10-14-live-member-switching');
const read=p=>JSON.parse(fs.readFileSync(p,'utf8'));
const write=(p,b)=>{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,b,{flag:'wx'})};
const json=(n,v)=>write(path.join(out,n),JSON.stringify(v,null,2)+'\n');
const copy=(a,b)=>write(b,fs.readFileSync(a)),zip=(a,b)=>write(b,z.gzipSync(fs.readFileSync(a)));
const f=read(path.join(scratch,'facts-final.json')),prior=read(path.join(scratch,'facts-prior-final.json')),old=read('.tmp-product-iteration/dual-member-sources-416/facts-after-final.json');
assert.equal(f.task.id,'tsk_g00VY0Dhzi00R4lvcuZT');assert.equal(prior.task.id,old.task.id);
for(const kind of ['messages','parts','tools','outcomes'])for(const item of old[kind])assert.deepEqual(prior[kind].find(x=>(x.id??x.requestPartID)===(item.id??item.requestPartID)),item);
for(const a of old.artifacts)assert.deepEqual(prior.artifacts.find(x=>x.id===a.id)?.payload,a.payload);
const price=f.messages.find(m=>m.id==='msg_g0VY0Dp700021hopL3FQ'),deliveryFirst=f.messages.find(m=>m.id==='msg_g0VY0E7aN00XIL565Aaz'),delivery=f.messages.find(m=>m.id==='msg_g0VY0E8aA00GpEgIGxvf');
const serialGap=deliveryFirst.time.created-price.time.completed;assert.equal(serialGap,13417);
const cancelled=f.events.find(e=>e.type==='task.cancelled');assert.equal(cancelled.payload.execution_epoch,1);
const cancellationError=f.messages.find(m=>m.id==='msg_hvkwraiDPBLPfci5GrKi');assert.equal(cancellationError.error.name,'UnknownError');
const observations=fs.readFileSync(path.join(scratch,'observations.jsonl'),'utf8').trim().split('\n').map(JSON.parse);
const windows=[['02-first-live-source',price],['03-live-source-line2',price],['04-price-live-reading',price],['07-delivery-live',delivery],['08-delivery-paused',delivery]].map(([name,message])=>{
 const o=observations.find(x=>x.name===name);assert.ok(Date.parse(o.startedAt)>=message.time.created);assert.ok(Date.parse(o.completedAt)<message.time.completed);
 return {screenshot:name+'.jpg',messageID:message.id,sessionID:message.sessionID,time:message.time,observation:o};
});
const returnObservation=observations.find(x=>x.name==='09-price-restored-during-peer');assert.ok(Date.parse(returnObservation.startedAt)>delivery.time.completed);
const sources=f.parts.filter(p=>p.type==='source-file').map(p=>{
 const message=f.messages.find(m=>m.id===p.messageID),tool=f.tools.find(t=>t.id===p.toolPartID);assert.equal(tool.tool,'read');assert.equal(f.outcomes.find(o=>o.requestPartID===tool.id)?.outcome,'completed');
 return {id:p.id,messageID:p.messageID,sessionID:message.sessionID,toolPartID:tool.id,path:p.path,range:p.range};
});
const dir='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/live-member-switching-417-live/evidence';
const native=read(path.join(dir,'native-host-settled.json')),cleanup=read(path.join(dir,'physical-terminal-and-pair-cleanup.json')),failure=read(path.join(dir,'failed.json'));
assert.equal(native.terminal.reason,'exited');assert.equal(native.terminal.exitCode,0);
for(const k of ['physicalCompletion','outputDrainComplete','requestCleanupComplete'])assert.equal(native[k],true);
assert.equal(cleanup.pairedCleanupComplete,true);assert.equal(failure.error.message,'TASK_TERMINAL_CANCELLED: task cancelled');
const audit=fs.readdirSync(dir).filter(n=>n.startsWith('provider-')&&n.endsWith('.json')).map(n=>({n,v:read(path.join(dir,n))})).filter(x=>Array.isArray(x.v.requests)&&x.v.observedAt).sort((a,b)=>Date.parse(a.v.observedAt)-Date.parse(b.v.observedAt)).at(-1);
const terminals={};for(const r of audit.v.requests){assert.equal(r.model,'gpt-6.1-sol');assert.equal(r.streaming,true);assert.equal(r.status,200);assert.equal(r.response_reader.state,'settled');const kind=r.response_reader.terminal.kind;terminals[kind]=(terminals[kind]??0)+1}assert.deepEqual(terminals,{eof:18,aborted:1});
const toolSurfaces=audit.v.requests.filter(r=>r.response_reader.requestContext?.streamRequest?.agentID==='orchestrator').map(r=>({assistantMessageID:r.response_reader.requestContext.activity.assistantMessageID,names:r.tool_declarations.entries.flatMap(e=>e.names.map(n=>n.value))}));
for(const surface of toolSurfaces)assert.ok(surface.names.includes('dispatch_agent'));
const contracts=fs.readFileSync(path.join(scratch,'shared-contracts.log'),'utf8');
const tests=[...contracts.matchAll(/^ (\d+) pass\r?$/gm)].reduce((n,m)=>n+Number(m[1]),0),expectCalls=[...contracts.matchAll(/^ (\d+) expect\(\) calls\r?$/gm)].reduce((n,m)=>n+Number(m[1]),0);assert.equal(tests,17);
for(const n of ['native-host-ready.json','native-host-settled.json','physical-terminal-and-pair-cleanup.json','launcher-child-exit.json','preflight-ready.json','authority-ready.json','public-shutdown.json','task-boundary-admitted.json','task-occurrence-admitted.json','failed.json'])copy(path.join(dir,n),path.join(out,'live',n));
copy(path.join(dir,audit.n),path.join(out,'live/provider-audit.json'));
json('persisted-check.json',{status:'failure-reproduced',taskID:f.task.id,projectID:f.task.project_id,databaseVersion:f.databaseVersion,serialGapMs:serialGap,price:price.time,deliveryFirst:deliveryFirst.time,delivery:delivery.time,liveWindows:windows,sources,toolSurfaces,cancelled,cancellationError,dispatchLineages:f.artifacts.filter(a=>a.kind==='dispatch_lineage').map(a=>({id:a.id,payload:a.payload})),priorTaskID:old.task.id,priorMessagesRetained:old.messages.length,boundary:'Actual recorded Task failed explicit overlap acceptance and was intentionally cancelled. Model and UI observations are not substitutes for physical overlap. Screenshot09 was corrected to completed-state restoration. Shared production-grant and cancellation-fence audit remains open.'});
json('execution-summary.json',{requests:audit.v.requests.length,terminals,native:native.terminal,physicalCompletion:true,pairedCleanupComplete:true,tests,expectCalls,build:{handle:95266,chunk:'77fe16',exitCode:0},nativeJoin:{handle:81176,chunk:'13bb98',exitCode:0},taskCreate:{chunk:'c730ae',exitCode:0},contractsJoin:{handle:12632,chunk:'450c73',exitCode:0},screenshots:14,closedTab:'39',businessOutcome:'Explicit parallel execution requirement unmet; owned diagnostic Task cancelled, not qualified as completed.'});
for(const n of fs.readdirSync(scratch)){
 if(/^\d\d-.*\.jpg$/.test(n))copy(path.join(scratch,n),path.join(out,n));
 else if(/^(facts-.*|task-(request|accepted|selection))\.json$/.test(n)||n==='observations.jsonl')zip(path.join(scratch,n),path.join(out,'facts',n+'.gz'));
 else if(/\.(ps1|cjs|ts|log|txt)$/.test(n)&&!n.startsWith('archive-check')&&!n.startsWith('commit')&&!n.startsWith('prepare-commit'))zip(path.join(scratch,n),path.join(out,'execution',n+'.gz'));
}
zip('.tmp-product-iteration/live-sol-task-guidance-413.ts',path.join(out,'execution/live-sol-task-guidance-413.ts.gz'));
for(const n of ['push.log','push-exit.json','remote-after-push-confirmed.txt','fetch-confirmed.log'])zip(path.join('.tmp-product-iteration/dual-member-sources-416',n),path.join(out,'previous-416',n+'.gz'));
console.log(JSON.stringify({status:'failure-reproduced',requests:audit.v.requests.length,terminals,tests,expectCalls,serialGapMs:serialGap,liveWindows:windows.length,priorMessagesRetained:old.messages.length,screenshots:14}));
