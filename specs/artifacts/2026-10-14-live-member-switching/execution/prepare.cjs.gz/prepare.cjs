const fs=require('node:fs'),path=require('node:path');
const root=__dirname;
for(const name of ['launch','settle','shutdown','create-task']){
 let code=fs.readFileSync('.tmp-product-iteration/dual-member-sources-416/'+name+'.ps1','utf8')
 .replaceAll('dual-member-sources-416','live-member-switching-417').replaceAll('18541','18545');
 if(name==='create-task')code=code.replaceAll('双成员来源 416','流中成员切换 417').replaceAll('product-experience-416','product-experience-417')
 .replace(/^\$taskRequest=.*$/m,"$taskRequest='请同时启动两位独立读取成员，不要等待第一位完成后才启动第二位：这两项互不依赖的读取应在同一轮安排并重叠运行。第一位只read本项目README.md第2行（offset=2,limit=1），第二位只read第3行（offset=3,limit=1）。每位直接向用户交付约1500字中文说明，分别只解释自己的价格或交付字段，清楚分段并包含6个小标题、原始行号和原文引用；保留仅用于界面测试的限定，把事实、含义、信息边界、展示建议、易误读之处和明确标为示例的表达分开，不编造原文没有的商业条款。各自必须实际独立读取，不能使用另一位转述。无需额外成员，不外部搜索、不运行shell、不修改文件、不人为等待；读取后持续输出自己的正文即可。这个Task用于实际观察两位成员运行时的切换、独立Sources和阅读位置。'");
 fs.writeFileSync(path.join(root,name+'.ps1'),code,{flag:'wx'});
}
fs.copyFileSync('.tmp-product-iteration/dual-member-sources-416/read-facts.ts',path.join(root,'read-facts.ts'),fs.constants.COPYFILE_EXCL);
let prior=fs.readFileSync(path.join(root,'read-facts.ts'),'utf8').replace("path.join(scratch,'task-selection.json')","'D:/myhexin-local/opencorvus/.tmp-product-iteration/dual-member-sources-416/task-selection.json'");
fs.writeFileSync(path.join(root,'read-prior-facts.ts'),prior,{flag:'wx'});
const bundle='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/live-member-switching-417-live-bundle';
fs.mkdirSync(path.join(bundle,'bin'),{recursive:true});fs.copyFileSync('.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64/bun.exe',path.join(bundle,'bin/bun.exe'),fs.constants.COPYFILE_EXCL);
for(const [file,url] of [
 ['specs/README.md','records/2026-10/2026-10-14-live-member-switching.md'],
 ['specs/records/2026-10/README.md','2026-10-14-live-member-switching.md'],
 ['specs/artifacts/README.md','2026-10-14-live-member-switching/README.md'],
]){
 const v=fs.readFileSync(file,'utf8'),lines=v.split(/\r?\n/);lines.splice(2,0,`- [流中成员切换](${url})：双成员运行中切换、Sources与阅读位置的真实验收。`,'');fs.writeFileSync(file,lines.join('\n'));
}
console.log(JSON.stringify({bundle,port:18545,maxRequests:48,nativeMaximumMs:600000}));
