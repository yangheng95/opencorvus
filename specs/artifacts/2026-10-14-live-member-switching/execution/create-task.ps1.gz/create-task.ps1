$ErrorActionPreference='Stop'
$taskDiag='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/live-member-switching-417-live'
$taskRun='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/member-live-rendering-412-fresh'
$taskScratch='D:/myhexin-local/opencorvus/.tmp-product-iteration/live-member-switching-417'
$taskReady=Get-Content -Raw -LiteralPath "$taskDiag/evidence/native-host-ready.json"|ConvertFrom-Json
$taskPreflight=Get-Content -Raw -LiteralPath "$taskDiag/evidence/preflight-ready.json"|ConvertFrom-Json
$taskAuthority=Get-Content -Raw -LiteralPath "$taskDiag/evidence/authority-ready.json"|ConvertFrom-Json
if($taskReady.occurrence -cne $taskPreflight.occurrence -or $taskReady.target.pid -ne $taskPreflight.pid -or $taskPreflight.preflight.actualModel -cne 'gpt-6.1-sol' -or !$taskPreflight.preflight.streaming -or $taskPreflight.preflight.credential -cne 'usable' -or $taskPreflight.preflight.catalog -cne 'projected'){throw 'Actual paired provider preflight required'}
if($taskAuthority.pid -ne $taskReady.target.pid -or $taskAuthority.admission.packageRevision.id -cne 'base' -or $taskAuthority.admission.packageRevision.scope -cne 'built_in'){throw 'Actual builtin Base target required'}
. 'D:/myhexin-local/opencorvus/.tmp-product-iteration/live-sol-long-source-reading-406-launch.ps1' -FunctionsOnly
if((Get-OwnedNativeState $taskReady.target) -cne 'exact_live'){throw 'Exact owned target required'}
$taskSelectionPath="$taskRun/live-member-switching-417-selection.json"
if(Test-Path -LiteralPath $taskSelectionPath){throw 'This occurrence already has an accepted Task'}
$taskRequest='请同时启动两位独立读取成员，不要等待第一位完成后才启动第二位：这两项互不依赖的读取应在同一轮安排并重叠运行。第一位只read本项目README.md第2行（offset=2,limit=1），第二位只read第3行（offset=3,limit=1）。每位直接向用户交付约1500字中文说明，分别只解释自己的价格或交付字段，清楚分段并包含6个小标题、原始行号和原文引用；保留仅用于界面测试的限定，把事实、含义、信息边界、展示建议、易误读之处和明确标为示例的表达分开，不编造原文没有的商业条款。各自必须实际独立读取，不能使用另一位转述。无需额外成员，不外部搜索、不运行shell、不修改文件、不人为等待；读取后持续输出自己的正文即可。这个Task用于实际观察两位成员运行时的切换、独立Sources和阅读位置。'
$taskRequestID=[Guid]::NewGuid().ToString()
$taskOriginal=@{};Get-ChildItem Env:|ForEach-Object {$taskOriginal[$_.Name]=$_.Value}
$taskEnv=@{};foreach($taskKey in @('PATH','SystemRoot','WINDIR','ComSpec','PATHEXT','LANG','LC_ALL','LC_CTYPE')){if($taskOriginal.ContainsKey($taskKey)){$taskEnv[$taskKey]=$taskOriginal[$taskKey]}}
$taskClient="$taskDiag/cli-home";New-Item -ItemType Directory -Path $taskClient,"$taskDiag/cli-temp","$taskDiag/cli-runtime" -Force|Out-Null
foreach($taskKey in @('USERPROFILE','APPDATA','LOCALAPPDATA','XDG_CONFIG_HOME','XDG_DATA_HOME','XDG_CACHE_HOME','XDG_STATE_HOME')){$taskEnv[$taskKey]=$taskClient}
$taskEnv.OPENCORVUS_HOME="$taskDiag/cli-runtime";$taskEnv.OPENCORVUS_DISABLE_EXTERNAL_SKILLS='1';$taskEnv.OPENCORVUS_DISABLE_AUTOUPDATE='1';$taskEnv.OPENCORVUS_TASK_PROCESS_MODE='native'
foreach($taskKey in @('TEMP','TMP','TMPDIR')){$taskEnv[$taskKey]="$taskDiag/cli-temp"}
$taskEnv.HOMEDRIVE='C:';$taskEnv.HOMEPATH=([IO.Path]::GetFullPath($taskClient)).Substring(2)
try{
 Get-ChildItem Env:|ForEach-Object {[Environment]::SetEnvironmentVariable($_.Name,$null,'Process')}
 foreach($taskKey in $taskEnv.Keys){[Environment]::SetEnvironmentVariable($taskKey,$taskEnv[$taskKey],'Process')}
 $taskSent=[DateTime]::UtcNow.ToString('o')
 @{requestID=$taskRequestID;request=$taskRequest;requestSentAt=$taskSent;directory="$taskRun/project"}|ConvertTo-Json|Set-Content -LiteralPath "$taskScratch/task-request.json"
 & 'D:/myhexin-local/opencorvus/.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64/bun.exe' 'D:/myhexin-local/opencorvus/packages/opencorvus/src/index.ts' task create --url http://127.0.0.1:18545 --dir "$taskRun/project" --pillar work --expert-squad base --request $taskRequest --title '流中成员切换 417' --model openai/gpt-6.1-sol --request-id $taskRequestID --source product-experience-417 --format json 1> "$taskScratch/task-accepted.json" 2> "$taskScratch/task-create.log"
 $taskExit=$LASTEXITCODE
 if($taskExit -ne 0){throw "Actual Task CLI exit $taskExit"}
 $taskAcceptedAt=[DateTime]::UtcNow.ToString('o');$taskAccepted=Get-Content -Raw -LiteralPath "$taskScratch/task-accepted.json"|ConvertFrom-Json
 if(!$taskAccepted.task_id -or $taskAccepted.project_id -cne $taskAuthority.admission.projectID -or [IO.Path]::GetFullPath($taskAccepted.directory) -cne [IO.Path]::GetFullPath("$taskRun/project")){throw 'Actual Task acceptance identity mismatch'}
 $taskSelection=@{occurrence=$taskReady.occurrence;taskID=$taskAccepted.task_id;projectID=$taskAccepted.project_id;directory=$taskAccepted.directory;productPillar='work';requestID=$taskRequestID;requestSentAt=$taskSent;acceptedObservedAt=$taskAcceptedAt}
 Write-OwnedLaunchFact "$taskScratch/task-selection.json" $taskSelection
 Write-OwnedLaunchFact $taskSelectionPath $taskSelection
 $taskSelection|ConvertTo-Json
}finally{
 Get-ChildItem Env:|ForEach-Object {[Environment]::SetEnvironmentVariable($_.Name,$null,'Process')}
 foreach($taskKey in $taskOriginal.Keys){[Environment]::SetEnvironmentVariable($taskKey,$taskOriginal[$taskKey],'Process')}
}
