#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

#[cfg(windows)]
mod windows_helper {
    use serde::{Deserialize, Serialize};
    use std::{
        env,
        ffi::c_void,
        fs,
        os::windows::ffi::OsStrExt,
        path::PathBuf,
        ptr::{null, null_mut},
    };
    use windows_sys::Win32::{
        Foundation::{
            CloseHandle, GetLastError, ERROR_INVALID_PARAMETER, ERROR_NO_MORE_FILES, FILETIME,
            HANDLE, INVALID_HANDLE_VALUE, NTSTATUS, WAIT_OBJECT_0, WAIT_TIMEOUT,
        },
        System::{
            Console::{GetStdHandle, STD_ERROR_HANDLE, STD_INPUT_HANDLE, STD_OUTPUT_HANDLE},
            Diagnostics::ToolHelp::{
                CreateToolhelp32Snapshot, Process32FirstW, Process32NextW, PROCESSENTRY32W,
                TH32CS_SNAPPROCESS,
            },
            JobObjects::{
                CreateJobObjectW, JobObjectBasicAccountingInformation,
                JobObjectExtendedLimitInformation, QueryInformationJobObject,
                SetInformationJobObject, TerminateJobObject, IsProcessInJob,
                JOBOBJECT_BASIC_ACCOUNTING_INFORMATION, JOBOBJECT_EXTENDED_LIMIT_INFORMATION,
                JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE,
            },
            LibraryLoader::{GetModuleHandleW, GetProcAddress},
            Threading::{
                CreateProcessW, DeleteProcThreadAttributeList, GetCurrentProcess,
                GetCurrentProcessId, GetExitCodeProcess, GetProcessTimes,
                InitializeProcThreadAttributeList, OpenProcess, ResumeThread, Sleep,
                TerminateProcess, UpdateProcThreadAttribute, WaitForSingleObject,
                CREATE_BREAKAWAY_FROM_JOB, CREATE_NO_WINDOW, CREATE_SUSPENDED,
                CREATE_UNICODE_ENVIRONMENT, EXTENDED_STARTUPINFO_PRESENT, PROCESS_INFORMATION,
                PROCESS_QUERY_LIMITED_INFORMATION, PROCESS_SYNCHRONIZE, PROCESS_TERMINATE,
                PROC_THREAD_ATTRIBUTE_JOB_LIST, STARTF_USESTDHANDLES, STARTUPINFOEXW,
                PROCESS_BASIC_INFORMATION,
            },
        },
    };

    use std::{io::{BufRead, Read, Write}, os::windows::io::{AsRawHandle, FromRawHandle}, sync::{Arc, Mutex, atomic::{AtomicBool, AtomicU64, AtomicUsize, Ordering}}, time::Instant};
    use windows_sys::Win32::{Foundation::{SetHandleInformation, HANDLE_FLAG_INHERIT}, Security::SECURITY_ATTRIBUTES, System::{Pipes::CreatePipe, Threading::PROC_THREAD_ATTRIBUTE_HANDLE_LIST}};

    #[derive(Deserialize)]
    #[serde(tag = "kind", rename_all = "snake_case")]
    enum Request {
        Shell {
            command: String,
            #[serde(default)]
            terminate_children_on_root_exit: bool,
            shell: String,
            cwd: Option<String>,
            cancel_file: String,
            ready_file: String,
            launch_failed_file: String,
            settled_file: String,
            request_id: String,
            owner_pid: u32,
            owner_process_instance_id: String,
            runtime_occurrence_id: String,
        },
        Command {
            executable: String,
            #[serde(default)]
            terminate_children_on_root_exit: bool,
            args: Vec<String>,
            #[serde(default)]
            detached: bool,
            cwd: Option<String>,
            cancel_file: String,
            ready_file: String,
            launch_failed_file: String,
            settled_file: String,
            request_id: String,
            owner_pid: u32,
            owner_process_instance_id: String,
            runtime_occurrence_id: String,
        },
    }

    struct LaunchRequest {
        application: String,
        terminate_children_on_root_exit: bool,
        command_line: String,
        cwd: Option<String>,
        cancel_file: String,
        ready_file: String,
        launch_failed_file: String,
        settled_file: String,
        request_id: String,
        owner_pid: u32,
        owner_process_instance_id: String,
        runtime_occurrence_id: String,
        detached: bool,
    }

    #[derive(Serialize)]
    struct HelperMarker<'a> {
        protocol: u32,
        request_id: &'a str,
        helper_pid: u32,
        helper_process_instance_id: &'a str,
        runtime_occurrence_id: &'a str,
    }

    #[derive(Serialize)]
    struct ReadyMarker<'a> {
        protocol: u32,
        detached: bool,
        request_id: &'a str,
        helper_pid: u32,
        target_pid: u32,
        target_process_instance_id: &'a str,
        runtime_occurrence_id: &'a str,
        #[serde(skip_serializing_if = "Option::is_none")]
        terminate_children_on_root_exit: Option<bool>,
    }

    const READY_PROTOCOL: u32 = 3;

    #[derive(Clone, Debug, Deserialize, Serialize, PartialEq)]
    #[serde(rename_all = "camelCase", deny_unknown_fields)]
    struct ProcessOwner {
        #[serde(rename = "occurrenceID")]
        occurrence_id: String,
        pid: u32,
        #[serde(rename = "processInstanceID")]
        process_instance_id: String,
    }

    #[derive(Deserialize)]
    #[serde(deny_unknown_fields)]
    struct TransferRequest {
        protocol: u32,
        request_id: String,
        expected_owner: ProcessOwner,
        successor: ProcessOwner,
    }

    #[derive(Deserialize)]
    #[serde(deny_unknown_fields)]
    struct RestartReady {
        protocol: u32,
        request_id: String,
        successor: ProcessOwner,
        url: String,
    }

    #[derive(Serialize)]
    struct TransferReceipt<'a> {
        protocol: u32,
        request_id: &'a str,
        outcome: &'static str,
        previous_owner: &'a ProcessOwner,
        successor: &'a ProcessOwner,
        helper: TransferHelper<'a>,
    }

    #[derive(Serialize)]
    #[serde(rename_all = "camelCase")]
    struct TransferHelper<'a> {
        pid: u32,
        #[serde(rename = "processInstanceID")]
        process_instance_id: &'a str,
    }

    fn commit_transfer_if_requested(
        request: &LaunchRequest,
        target: &SuspendedTarget,
        target_identity: &str,
        helper_identity: &str,
    ) -> Result<bool, String> {
        if !request.detached { return Ok(false); }
        let root = std::path::Path::new(&request.ready_file).parent()
            .ok_or_else(|| "Transfer request root is unavailable".to_string())?;
        let body = match fs::read(root.join("transfer-request.json")) {
            Ok(body) => body,
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(false),
            Err(error) => return Err(format!("Read transfer request failed: {error}")),
        };
        let transfer: TransferRequest = serde_json::from_slice(&body)
            .map_err(|error| format!("Invalid transfer request: {error}"))?;
        let owner = ProcessOwner { occurrence_id: request.runtime_occurrence_id.clone(),
            pid: request.owner_pid, process_instance_id: request.owner_process_instance_id.clone() };
        if transfer.protocol != 1 || transfer.request_id != request.request_id
            || transfer.expected_owner != owner || transfer.successor.pid != target.pid
            || transfer.successor.process_instance_id != target_identity
            || transfer.successor.occurrence_id.is_empty()
        { return Err("Transfer request identity does not match its physical owner/target".into()); }
        let ready: RestartReady = serde_json::from_slice(&fs::read(root.join("restart-ready.json"))
            .map_err(|error| format!("Read application Ready failed: {error}"))?)
            .map_err(|error| format!("Invalid application Ready: {error}"))?;
        if ready.protocol != 1 || ready.request_id != request.request_id
            || ready.successor != transfer.successor || ready.url.is_empty()
        { return Err("Transfer request does not match application Ready".into()); }
        let receipt = TransferReceipt { protocol: 1, request_id: &request.request_id, outcome: "committed",
            previous_owner: &owner, successor: &transfer.successor,
            helper: TransferHelper { pid: unsafe { GetCurrentProcessId() }, process_instance_id: helper_identity } };
        let destination = root.join("transfer-receipt.json");
        if destination.exists() { return Err("Transfer receipt already exists before native commit".into()); }
        let temporary = root.join(format!("transfer-receipt.{}.tmp", unsafe { GetCurrentProcessId() }));
        let mut file = fs::File::create(&temporary).map_err(|error| format!("Create transfer receipt failed: {error}"))?;
        serde_json::to_writer(&mut file, &receipt).map_err(|error| format!("Write transfer receipt failed: {error}"))?;
        file.sync_all().map_err(|error| format!("Flush transfer receipt failed: {error}"))?;
        drop(file);
        fs::rename(temporary, destination).map_err(|error| format!("Commit transfer receipt failed: {error}"))?;
        Ok(true)
    }

    #[derive(Serialize)]
    struct SettlementMarker<'a> {
        protocol: u32,
        request_id: &'a str,
        helper_pid: u32,
        target_pid: u32,
        active_processes: u32,
        runtime_occurrence_id: &'a str,
    }

    #[derive(Serialize)]
    struct PreTargetSettlementMarker<'a> {
        protocol: u32,
        request_id: &'a str,
        helper_pid: u32,
        stage: &'static str,
        active_processes: u32,
        runtime_occurrence_id: &'a str,
    }

    #[derive(Clone)]
    struct ProcessInfo {
        pid: u32,
        parent_pid: u32,
    }

    struct Handle(HANDLE);

    impl Drop for Handle {
        fn drop(&mut self) {
            if !self.0.is_null() && self.0 != INVALID_HANDLE_VALUE {
                unsafe {
                    CloseHandle(self.0);
                }
            }
        }
    }

    struct ProcessThreadAttributeList {
        _storage: Vec<usize>,
        _values: Vec<Box<[HANDLE]>>,
        pointer: *mut c_void,
    }

    impl ProcessThreadAttributeList {
        fn for_target(job: Option<HANDLE>, handles: Option<&StandardHandles>) -> Result<Option<Self>, String> {
            let mut values = Vec::new();
            let mut keys = Vec::new();
            if let Some(job) = job { keys.push(PROC_THREAD_ATTRIBUTE_JOB_LIST as usize); values.push(vec![job].into_boxed_slice()); }
            if let Some(handles) = handles {
                let mut inherited = vec![handles.input, handles.output, handles.error];
                inherited.sort_unstable(); inherited.dedup();
                keys.push(PROC_THREAD_ATTRIBUTE_HANDLE_LIST as usize); values.push(inherited.into_boxed_slice());
            }
            if values.is_empty() { return Ok(None); }
            let mut bytes = 0usize;
            unsafe { InitializeProcThreadAttributeList(null_mut(), values.len() as u32, 0, &mut bytes); }
            if bytes == 0 { return Err(format!("attribute size failed {}", unsafe {GetLastError()})); }
            let mut storage = vec![0usize; bytes.div_ceil(std::mem::size_of::<usize>())];
            let pointer = storage.as_mut_ptr() as *mut c_void;
            if unsafe {InitializeProcThreadAttributeList(pointer, values.len() as u32, 0, &mut bytes)} == 0 { return Err(format!("attribute init failed {}", unsafe{GetLastError()})); }
            let result = Self {_storage:storage, _values:values, pointer};
            for (key,value) in keys.iter().zip(result._values.iter()) {
                if unsafe{UpdateProcThreadAttribute(pointer,0,*key,value.as_ptr() as *const c_void,std::mem::size_of_val(value.as_ref()),null_mut(),null())} == 0 { return Err(format!("attribute {key} failed {}",unsafe{GetLastError()})); }
            }
            Ok(Some(result))
        }
    }

    impl Drop for ProcessThreadAttributeList {
        fn drop(&mut self) {
            unsafe {
                DeleteProcThreadAttributeList(self.pointer);
            }
        }
    }

    struct SuspendedTarget {
        job: Option<Handle>,
        process: Handle,
        thread: Handle,
        pid: u32,
    }

    struct StandardHandles {
        input: HANDLE,
        output: HANDLE,
        error: HANDLE,
    }

    fn inherited_standard_handles() -> Result<StandardHandles, String> {
        let handles = StandardHandles {
            input: unsafe { GetStdHandle(STD_INPUT_HANDLE) },
            output: unsafe { GetStdHandle(STD_OUTPUT_HANDLE) },
            error: unsafe { GetStdHandle(STD_ERROR_HANDLE) },
        };
        for (label, handle) in [
            ("stdin", handles.input),
            ("stdout", handles.output),
            ("stderr", handles.error),
        ] {
            if handle.is_null() || handle == INVALID_HANDLE_VALUE {
                let error = unsafe { GetLastError() };
                return Err(format!(
                    "Windows supervisor {label} handle is unavailable (win32={error})"
                ));
            }
        }
        Ok(handles)
    }

    fn wide_null(value: &str) -> Vec<u16> {
        std::ffi::OsStr::new(value)
            .encode_wide()
            .chain(std::iter::once(0))
            .collect()
    }

    fn quote_arg(value: &str) -> String {
        if value.is_empty() {
            return "\"\"".to_string();
        }
        let needs_quotes = value.chars().any(|c| c.is_whitespace() || c == '"');
        if !needs_quotes {
            return value.to_string();
        }
        let mut out = String::from("\"");
        let mut backslashes = 0;
        for ch in value.chars() {
            if ch == '\\' {
                backslashes += 1;
                continue;
            }
            if ch == '"' {
                out.push_str(&"\\".repeat(backslashes * 2 + 1));
                out.push('"');
                backslashes = 0;
                continue;
            }
            out.push_str(&"\\".repeat(backslashes));
            backslashes = 0;
            out.push(ch);
        }
        out.push_str(&"\\".repeat(backslashes * 2));
        out.push('"');
        out
    }

    fn shell_args(shell: &str, command: &str) -> Vec<String> {
        let name = PathBuf::from(shell)
            .file_stem()
            .and_then(|v| v.to_str())
            .unwrap_or("")
            .to_ascii_lowercase();
        match name.as_str() {
            "cmd" => vec!["/d".into(), "/s".into(), "/c".into(), command.into()],
            "powershell" | "pwsh" => vec!["-NoProfile".into(), "-Command".into(), command.into()],
            _ => vec!["-c".into(), command.into()],
        }
    }

    fn create_job() -> Result<Handle, String> {
        let job = unsafe { CreateJobObjectW(null(), null()) };
        if job.is_null() || job == INVALID_HANDLE_VALUE {
            return Err("CreateJobObjectW failed".into());
        }
        let mut info: JOBOBJECT_EXTENDED_LIMIT_INFORMATION = unsafe { std::mem::zeroed() };
        info.BasicLimitInformation.LimitFlags = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE;
        let ok = unsafe {
            SetInformationJobObject(
                job,
                JobObjectExtendedLimitInformation,
                &info as *const _ as *const c_void,
                std::mem::size_of::<JOBOBJECT_EXTENDED_LIMIT_INFORMATION>() as u32,
            )
        };
        if ok == 0 {
            unsafe {
                CloseHandle(job);
            }
            return Err("SetInformationJobObject(KILL_ON_JOB_CLOSE) failed".into());
        }
        Ok(Handle(job))
    }

    fn job_active_process_count(job: HANDLE) -> Result<u32, String> {
        let mut info: JOBOBJECT_BASIC_ACCOUNTING_INFORMATION = unsafe { std::mem::zeroed() };
        let queried = unsafe {
            QueryInformationJobObject(
                job,
                JobObjectBasicAccountingInformation,
                &mut info as *mut _ as *mut c_void,
                std::mem::size_of::<JOBOBJECT_BASIC_ACCOUNTING_INFORMATION>() as u32,
                null_mut(),
            )
        };
        if queried == 0 {
            let error = unsafe { GetLastError() };
            return Err(format!(
                "QueryInformationJobObject(active-process-zero) failed (win32={error})"
            ));
        }
        Ok(info.ActiveProcesses)
    }

    fn cancellation_requested(cancel_file: &str) -> bool {
        std::path::Path::new(cancel_file).exists()
    }

    /// Creation-time process identity in the exact format the runtime's
    /// process-occurrence observer computes, so a successor process can prove
    /// this process dead without any live settlement handshake.
    fn process_instance_id(process: HANDLE) -> Result<String, String> {
        let mut creation: FILETIME = unsafe { std::mem::zeroed() };
        let mut exit: FILETIME = unsafe { std::mem::zeroed() };
        let mut kernel: FILETIME = unsafe { std::mem::zeroed() };
        let mut user: FILETIME = unsafe { std::mem::zeroed() };
        let queried =
            unsafe { GetProcessTimes(process, &mut creation, &mut exit, &mut kernel, &mut user) };
        if queried == 0 {
            let error = unsafe { GetLastError() };
            return Err(format!("GetProcessTimes failed (win32={error})"));
        }
        let filetime = ((creation.dwHighDateTime as u64) << 32) | creation.dwLowDateTime as u64;
        const DOTNET_EPOCH_OFFSET: u64 = 504_911_232_000_000_000;
        Ok(format!("win32:{}", filetime + DOTNET_EPOCH_OFFSET))
    }

    fn terminate_job_once(job: HANDLE, cancellation_applied: &mut bool) -> Result<(), String> {
        if *cancellation_applied {
            return Ok(());
        }
        let terminated = unsafe { TerminateJobObject(job, 1) };
        if terminated == 0 {
            let error = unsafe { GetLastError() };
            return Err(format!("TerminateJobObject failed (win32={error})"));
        }
        *cancellation_applied = true;
        Ok(())
    }

    fn wait_for_job_active_process_zero(
        job: HANDLE,
        cancel_file: &str,
        owner: Option<HANDLE>,
        cancellation_applied: &mut bool,
    ) -> Result<(), String> {
        loop {
            if job_active_process_count(job)? == 0 {
                return Ok(());
            }
            let owner_dead = owner
                .map(|handle| unsafe { WaitForSingleObject(handle, 0) } == WAIT_OBJECT_0)
                .unwrap_or(false);
            if owner_dead || cancellation_requested(cancel_file) {
                terminate_job_once(job, cancellation_applied)?;
            }
            unsafe { Sleep(10) };
        }
    }

    fn launch_request(request: Request) -> LaunchRequest {
        match request {
            Request::Shell {
                command,
                terminate_children_on_root_exit,
                shell,
                cwd,
                cancel_file,
                ready_file,
                launch_failed_file,
                settled_file,
                request_id,
                owner_pid,
                owner_process_instance_id,
                runtime_occurrence_id,
            } => {
                let args = shell_args(&shell, &command);
                let command_line = std::iter::once(shell.as_str())
                    .chain(args.iter().map(String::as_str))
                    .map(quote_arg)
                    .collect::<Vec<_>>()
                    .join(" ");
                LaunchRequest {
                    application: shell,
                    terminate_children_on_root_exit,
                    command_line,
                    cwd,
                    cancel_file,
                    ready_file,
                    launch_failed_file,
                    settled_file,
                    request_id,
                    owner_pid,
                    owner_process_instance_id,
                    runtime_occurrence_id,
                    detached: false,
                }
            }
            Request::Command {
                executable,
                terminate_children_on_root_exit,
                args,
                detached,
                cwd,
                cancel_file,
                ready_file,
                launch_failed_file,
                settled_file,
                request_id,
                owner_pid,
                owner_process_instance_id,
                runtime_occurrence_id,
            } => {
                let command_line = std::iter::once(executable.as_str())
                    .chain(args.iter().map(String::as_str))
                    .map(quote_arg)
                    .collect::<Vec<_>>()
                    .join(" ");
                LaunchRequest {
                    application: executable,
                    terminate_children_on_root_exit,
                    command_line,
                    cwd,
                    cancel_file,
                    ready_file,
                    launch_failed_file,
                    settled_file,
                    request_id,
                    owner_pid,
                    owner_process_instance_id,
                    runtime_occurrence_id,
                    detached,
                }
            }
        }
    }

    fn create_suspended_target(
        request: &LaunchRequest,
        standard_handles: Option<&StandardHandles>,
        environment: Option<&[u16]>,
    ) -> Result<SuspendedTarget, String> {
        let job = if request.detached {
            None
        } else {
            Some(create_job()?)
        };
        let (process, thread, pid) =
            create_suspended_process(request, standard_handles, job.as_ref().map(|job| job.0), environment)?;
        Ok(SuspendedTarget {
            job,
            process,
            thread,
            pid,
        })
    }

    fn create_suspended_process(
        request: &LaunchRequest,
        standard_handles: Option<&StandardHandles>,
        job: Option<HANDLE>,
        environment: Option<&[u16]>,
    ) -> Result<(Handle, Handle, u32), String> {
        let attributes = ProcessThreadAttributeList::for_target(job, standard_handles)?;
        let mut command_line_w = wide_null(&request.command_line);
        let application_w = wide_null(&request.application);
        let cwd_w = request.cwd.as_deref().map(wide_null);
        let mut startup: STARTUPINFOEXW = unsafe { std::mem::zeroed() };
        startup.StartupInfo.cb = std::mem::size_of::<STARTUPINFOEXW>() as u32;
        if let Some(handles) = standard_handles {
            startup.StartupInfo.dwFlags = STARTF_USESTDHANDLES;
            startup.StartupInfo.hStdInput = handles.input;
            startup.StartupInfo.hStdOutput = handles.output;
            startup.StartupInfo.hStdError = handles.error;
        }
        startup.lpAttributeList = attributes
            .as_ref()
            .map(|attributes| attributes.pointer)
            .unwrap_or(null_mut());

        let creation_flags = CREATE_SUSPENDED
            | CREATE_NO_WINDOW
            | CREATE_UNICODE_ENVIRONMENT
            | if job.is_none() { CREATE_BREAKAWAY_FROM_JOB } else { 0 }
            | if attributes.is_some() { EXTENDED_STARTUPINFO_PRESENT } else { 0 };

        let mut process_info: PROCESS_INFORMATION = unsafe { std::mem::zeroed() };
        let created = unsafe {
            CreateProcessW(
                application_w.as_ptr(),
                command_line_w.as_mut_ptr(),
                null(),
                null(),
                i32::from(standard_handles.is_some()),
                creation_flags,
                environment.map(|value| value.as_ptr() as *const c_void).unwrap_or(null()),
                cwd_w.as_ref().map(|v| v.as_ptr()).unwrap_or(null()),
                &startup.StartupInfo,
                &mut process_info,
            )
        };
        if created == 0 {
            let err = unsafe { GetLastError() };
            return Err(format!(
                "CreateProcessW failed for {} (win32={err})",
                request.application
            ));
        }

        Ok((
            Handle(process_info.hProcess),
            Handle(process_info.hThread),
            process_info.dwProcessId,
        ))
    }

    fn prepare_target(request: &LaunchRequest, io: Option<&ScopeIo>) -> Result<(Handle, SuspendedTarget, String), String> {
        let helper_pid = unsafe { GetCurrentProcessId() };
        let helper_instance_id = process_instance_id(unsafe { GetCurrentProcess() })?;
        publish_helper_marker(request, helper_pid, &helper_instance_id)?;
        let helper_parent_pid = current_parent_pid()?;
        if helper_parent_pid != request.owner_pid {
            return Err(format!(
                "Windows supervisor owner PID {} does not match helper parent {}",
                request.owner_pid, helper_parent_pid
            ));
        }
        let owner_handle = unsafe {
            OpenProcess(
                PROCESS_SYNCHRONIZE | PROCESS_QUERY_LIMITED_INFORMATION,
                0,
                request.owner_pid,
            )
        };
        if owner_handle.is_null() || owner_handle == INVALID_HANDLE_VALUE {
            let error = unsafe { GetLastError() };
            return Err(format!(
                "OpenProcess(runtime owner {}) failed (win32={error})",
                request.owner_pid
            ));
        }
        let owner = Handle(owner_handle);
        let observed_owner_instance_id = process_instance_id(owner.0)?;
        if observed_owner_instance_id != request.owner_process_instance_id {
            return Err(format!(
                "Windows supervisor owner process instance {} does not match requested {}",
                observed_owner_instance_id, request.owner_process_instance_id
            ));
        }
        if request.detached {
            let mut contained = 0;
            if unsafe { IsProcessInJob(GetCurrentProcess(), null_mut(), &mut contained) } == 0 {
                return Err("Detached helper inherited Job containment could not be observed".into());
            }
            if contained != 0 {
                return Err("Detached helper remains inside an inherited containing Job".into());
            }
        }
        let standard_handles = if let Some(io) = io { StandardHandles {input:io.input.as_raw_handle(), output:io.output.0, error:io.error.0} } else { inherited_standard_handles()? };
        let target = create_suspended_target(request, Some(&standard_handles), io.map(|io| io.environment.as_slice()))?;
        Ok((owner, target, helper_instance_id))
    }

    fn run_request(request: Request) -> Result<u32, String> { run_request_with_io(request, None) }

    fn run_request_with_io(request: Request, io: Option<ScopeIo>) -> Result<u32, String> {
        let request = launch_request(request);
        if request.runtime_occurrence_id.is_empty() || request.owner_process_instance_id.is_empty()
        {
            return Err("runtime owner occurrence identity is missing".into());
        }
        let (owner, target, helper_instance_id) = match prepare_target(&request, io.as_ref()) {
            Ok(prepared) => prepared,
            Err(primary) => {
                if let Err(marker) = publish_pre_target_settlement_marker(&request) {
                    return Err(format!(
                        "{primary}; publish pre-target active-process-zero marker failed: {marker}"
                    ));
                }
                return Err(primary);
            }
        };

        drop(io); // Each target owns only its explicit inherited pipe ends.
        let target_instance_id = match process_instance_id(target.process.0) {
            Ok(value) => value,
            Err(error) => return Err(settle_target_after_failure(error, &request, &target)),
        };

        if let Err(error) = publish_ready_marker(
            &request.ready_file,
            &request.request_id,
            &request.runtime_occurrence_id,
            target.pid,
            &target_instance_id,
            request.terminate_children_on_root_exit,
            request.detached,
        ) {
            return Err(settle_target_after_failure(error, &request, &target));
        }

        let resumed = unsafe { ResumeThread(target.thread.0) };
        if resumed == u32::MAX {
            return Err(settle_target_after_failure(
                "ResumeThread failed".into(),
                &request,
                &target,
            ));
        }

        let mut cancellation_applied = false;
        let mut transferred = false;
        loop {
            let waited = unsafe { WaitForSingleObject(target.process.0, 20) };
            if waited == WAIT_OBJECT_0 {
                break;
            }
            if waited != WAIT_TIMEOUT {
                let error = unsafe { GetLastError() };
                return Err(settle_target_after_failure(
                    format!("WaitForSingleObject failed for target process (win32={error})"),
                    &request,
                    &target,
                ));
            }
            if transferred { continue; }
            let owner_dead = unsafe { WaitForSingleObject(owner.0, 0) } == WAIT_OBJECT_0;
            if owner_dead || cancellation_requested(&request.cancel_file) {
                if let Some(job) = target.job.as_ref() {
                    terminate_job_once(job.0, &mut cancellation_applied)?;
                } else {
                    terminate_process_handle(target.process.0, target.pid)?;
                    cancellation_applied = true;
                }
            } else if !cancellation_applied {
                transferred = match commit_transfer_if_requested(&request, &target, &target_instance_id, &helper_instance_id) {
                    Ok(committed) => committed,
                    Err(error) => return Err(settle_target_after_failure(error, &request, &target)),
                };
            }
        }
        let mut code = 1u32;
        let read_exit_code = unsafe { GetExitCodeProcess(target.process.0, &mut code) };
        if read_exit_code == 0 {
            let error = unsafe { GetLastError() };
            return Err(settle_target_after_failure(
                format!("GetExitCodeProcess failed for target process (win32={error})"),
                &request,
                &target,
            ));
        }
        if let Some(job) = target.job.as_ref() {
            if request.terminate_children_on_root_exit {
                terminate_job_once(job.0, &mut cancellation_applied)?;
            }
            if let Err(error) = wait_for_job_active_process_zero(
                job.0,
                &request.cancel_file,
                Some(owner.0),
                &mut cancellation_applied,
            ) {
                return Err(settle_target_after_failure(error, &request, &target));
            }
        }
        publish_settlement_marker(&request, target.pid)?;
        drop(target);
        Ok(code)
    }

    fn helper_marker_file(ready_file: &str) -> String {
        std::path::Path::new(ready_file)
            .with_file_name("helper.json")
            .to_string_lossy()
            .into_owned()
    }

    /// Published before any target exists so a successor can always prove this
    /// helper occurrence dead, even when the helper is killed mid-request.
    fn publish_helper_marker(
        request: &LaunchRequest,
        helper_pid: u32,
        helper_process_instance_id: &str,
    ) -> Result<(), String> {
        let helper_file = helper_marker_file(&request.ready_file);
        let temporary_file = format!("{helper_file}.{helper_pid}.tmp");
        let marker = HelperMarker {
            protocol: 1,
            request_id: &request.request_id,
            helper_pid,
            helper_process_instance_id,
            runtime_occurrence_id: &request.runtime_occurrence_id,
        };
        let mut file = fs::File::create(&temporary_file)
            .map_err(|error| format!("create helper marker failed: {error}"))?;
        if let Err(error) = serde_json::to_writer(&mut file, &marker) {
            let _ = fs::remove_file(&temporary_file);
            return Err(format!("serialize helper marker failed: {error}"));
        }
        if let Err(error) = file.sync_all() {
            let _ = fs::remove_file(&temporary_file);
            return Err(format!("flush helper marker failed: {error}"));
        }
        drop(file);
        if let Err(error) = fs::rename(&temporary_file, &helper_file) {
            let _ = fs::remove_file(&temporary_file);
            return Err(format!("publish helper marker failed: {error}"));
        }
        Ok(())
    }

    fn publish_ready_marker(
        ready_file: &str,
        request_id: &str,
        runtime_occurrence_id: &str,
        target_pid: u32,
        target_process_instance_id: &str,
        terminate_children_on_root_exit: bool,
        detached: bool,
    ) -> Result<(), String> {
        let helper_pid = unsafe { GetCurrentProcessId() };
        let temporary_file = format!("{ready_file}.{helper_pid}.tmp");
        let marker = ReadyMarker {
            protocol: READY_PROTOCOL,
            detached,
            request_id,
            helper_pid,
            target_pid,
            target_process_instance_id,
            runtime_occurrence_id,
            terminate_children_on_root_exit: terminate_children_on_root_exit.then_some(true),
        };
        let mut file = fs::File::create(&temporary_file)
            .map_err(|error| format!("create ready marker failed: {error}"))?;
        if let Err(error) = serde_json::to_writer(&mut file, &marker) {
            let _ = fs::remove_file(&temporary_file);
            return Err(format!("serialize ready marker failed: {error}"));
        }
        if let Err(error) = file.sync_all() {
            let _ = fs::remove_file(&temporary_file);
            return Err(format!("flush ready marker failed: {error}"));
        }
        drop(file);
        if let Err(error) = fs::rename(&temporary_file, ready_file) {
            let _ = fs::remove_file(&temporary_file);
            return Err(format!("publish ready marker failed: {error}"));
        }
        Ok(())
    }

    fn publish_settlement_marker(request: &LaunchRequest, target_pid: u32) -> Result<(), String> {
        let helper_pid = unsafe { GetCurrentProcessId() };
        let temporary_file = format!("{}.{}.tmp", request.settled_file, helper_pid);
        let marker = SettlementMarker {
            protocol: 1,
            request_id: &request.request_id,
            helper_pid,
            target_pid,
            active_processes: 0,
            runtime_occurrence_id: &request.runtime_occurrence_id,
        };
        let mut file = fs::File::create(&temporary_file)
            .map_err(|error| format!("create settlement marker failed: {error}"))?;
        if let Err(error) = serde_json::to_writer(&mut file, &marker) {
            let _ = fs::remove_file(&temporary_file);
            return Err(format!("serialize settlement marker failed: {error}"));
        }
        if let Err(error) = file.sync_all() {
            let _ = fs::remove_file(&temporary_file);
            return Err(format!("flush settlement marker failed: {error}"));
        }
        drop(file);
        if let Err(error) = fs::rename(&temporary_file, &request.settled_file) {
            let _ = fs::remove_file(&temporary_file);
            return Err(format!("publish settlement marker failed: {error}"));
        }
        Ok(())
    }

    fn publish_pre_target_settlement_marker(request: &LaunchRequest) -> Result<(), String> {
        let helper_pid = unsafe { GetCurrentProcessId() };
        let temporary_file = format!("{}.{}.tmp", request.launch_failed_file, helper_pid);
        let marker = PreTargetSettlementMarker {
            protocol: 1,
            request_id: &request.request_id,
            helper_pid,
            stage: "target_not_created",
            active_processes: 0,
            runtime_occurrence_id: &request.runtime_occurrence_id,
        };
        let mut file = fs::File::create(&temporary_file)
            .map_err(|error| format!("create pre-target settlement marker failed: {error}"))?;
        if let Err(error) = serde_json::to_writer(&mut file, &marker) {
            let _ = fs::remove_file(&temporary_file);
            return Err(format!(
                "serialize pre-target settlement marker failed: {error}"
            ));
        }
        if let Err(error) = file.sync_all() {
            let _ = fs::remove_file(&temporary_file);
            return Err(format!(
                "flush pre-target settlement marker failed: {error}"
            ));
        }
        drop(file);
        if let Err(error) = fs::rename(&temporary_file, &request.launch_failed_file) {
            let _ = fs::remove_file(&temporary_file);
            return Err(format!(
                "publish pre-target settlement marker failed: {error}"
            ));
        }
        Ok(())
    }

    fn settle_target_after_failure(
        primary: String,
        request: &LaunchRequest,
        target: &SuspendedTarget,
    ) -> String {
        let cleanup = if let Some(job) = target.job.as_ref() {
            let mut cancellation_applied = false;
            terminate_job_once(job.0, &mut cancellation_applied)
                .and_then(|()| {
                    wait_for_job_active_process_zero(job.0, "", None, &mut cancellation_applied)
                })
                .and_then(|()| publish_settlement_marker(request, target.pid))
        } else {
            terminate_process_handle(target.process.0, target.pid)
                .and_then(|()| publish_settlement_marker(request, target.pid))
        };
        match cleanup {
            Ok(()) => primary,
            Err(cleanup) => format!("{primary}; managed physical settlement failed: {cleanup}"),
        }
    }

    fn terminate_process_handle(process: HANDLE, pid: u32) -> Result<(), String> {
        let initial_state = unsafe { WaitForSingleObject(process, 0) };
        if initial_state == WAIT_OBJECT_0 {
            return Ok(());
        }
        let terminated = unsafe { TerminateProcess(process, 1) };
        if terminated == 0 {
            let error = unsafe { GetLastError() };
            let next_state = unsafe { WaitForSingleObject(process, 0) };
            if next_state == WAIT_OBJECT_0 {
                return Ok(());
            }
            return Err(format!(
                "TerminateProcess failed for pid {pid} (win32={error})"
            ));
        }
        let waited = unsafe { WaitForSingleObject(process, 1000) };
        if waited != WAIT_OBJECT_0 {
            return Err(format!(
                "process {pid} did not exit after TerminateProcess (wait={waited})"
            ));
        }
        Ok(())
    }

    fn current_parent_pid() -> Result<u32, String> {
        type QueryInformation =
            unsafe extern "system" fn(HANDLE, i32, *mut c_void, u32, *mut u32) -> NTSTATUS;
        // Ntdll is loaded for this process's lifetime; this is a borrowed module.
        let module = unsafe { GetModuleHandleW(wide_null("ntdll.dll").as_ptr()) };
        if module.is_null() {
            return Err(format!(
                "GetModuleHandleW(ntdll.dll) failed (win32={})",
                unsafe { GetLastError() }
            ));
        }
        let address = unsafe { GetProcAddress(module, b"NtQueryInformationProcess\0".as_ptr()) }
            .ok_or_else(|| {
                format!(
                    "NtQueryInformationProcess is unavailable (win32={})",
                    unsafe { GetLastError() }
                )
            })?;
        // The SDK supplies PROCESS_BASIC_INFORMATION; only the documented dynamic
        // entry point needs a function-pointer signature here.
        let query: QueryInformation = unsafe { std::mem::transmute(address) };
        let mut information: PROCESS_BASIC_INFORMATION = unsafe { std::mem::zeroed() };
        let expected_length = std::mem::size_of_val(&information) as u32;
        let mut returned_length = 0;
        let status = unsafe {
            query(
                GetCurrentProcess(),
                0,
                &mut information as *mut _ as *mut c_void,
                expected_length,
                &mut returned_length,
            )
        };
        if status < 0 {
            return Err(format!("NtQueryInformationProcess(ProcessBasicInformation) failed (ntstatus=0x{status:08x})"));
        }
        if returned_length != expected_length {
            return Err(format!("Windows parent process query returned {returned_length} bytes; expected {expected_length}"));
        }
        let helper_pid = unsafe { GetCurrentProcessId() };
        if information.UniqueProcessId != helper_pid as usize {
            return Err(format!(
                "Windows parent process query identity {} does not match helper {helper_pid}",
                information.UniqueProcessId
            ));
        }
        let parent_pid = u32::try_from(information.InheritedFromUniqueProcessId)
            .map_err(|_| "Windows parent process identifier is out of range".to_string())?;
        if parent_pid == 0 {
            return Err("Windows supervisor helper parent process is unavailable".into());
        }
        Ok(parent_pid)
    }

    fn snapshot_processes() -> Result<Vec<ProcessInfo>, String> {
        let snapshot = unsafe { CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0) };
        if snapshot == INVALID_HANDLE_VALUE {
            let err = unsafe { GetLastError() };
            return Err(format!("CreateToolhelp32Snapshot failed (win32={err})"));
        }
        let snapshot = Handle(snapshot);
        let mut entry: PROCESSENTRY32W = unsafe { std::mem::zeroed() };
        entry.dwSize = std::mem::size_of::<PROCESSENTRY32W>() as u32;

        let first = unsafe { Process32FirstW(snapshot.0, &mut entry) };
        if first == 0 {
            let err = unsafe { GetLastError() };
            return Err(format!("Process32FirstW failed (win32={err})"));
        }

        let mut processes = Vec::new();
        loop {
            processes.push(ProcessInfo {
                pid: entry.th32ProcessID,
                parent_pid: entry.th32ParentProcessID,
            });
            let next = unsafe { Process32NextW(snapshot.0, &mut entry) };
            if next == 0 {
                let error = unsafe { GetLastError() };
                if error == ERROR_NO_MORE_FILES {
                    break;
                }
                return Err(format!("Process32NextW failed (win32={error})"));
            }
        }
        Ok(processes)
    }

    fn descendant_pids(root_pid: u32, processes: &[ProcessInfo]) -> Vec<u32> {
        let mut result = Vec::new();
        let mut stack = vec![root_pid];
        while let Some(parent_pid) = stack.pop() {
            for process in processes
                .iter()
                .filter(|process| process.parent_pid == parent_pid)
            {
                if process.pid == root_pid || result.contains(&process.pid) {
                    continue;
                }
                result.push(process.pid);
                stack.push(process.pid);
            }
        }
        result
    }

    fn open_terminable_process(pid: u32) -> Result<Option<Handle>, String> {
        let handle = unsafe { OpenProcess(PROCESS_TERMINATE | PROCESS_SYNCHRONIZE, 0, pid) };
        if handle.is_null() {
            let err = unsafe { GetLastError() };
            if err == ERROR_INVALID_PARAMETER {
                return Ok(None);
            }
            return Err(format!("OpenProcess failed for pid {pid} (win32={err})"));
        }
        Ok(Some(Handle(handle)))
    }

    fn terminate_pid(pid: u32) -> Result<(), String> {
        let Some(process) = open_terminable_process(pid)? else {
            return Ok(());
        };

        terminate_process_handle(process.0, pid)
    }

    fn terminate_process_tree(pid: u32) -> Result<(), String> {
        let processes = snapshot_processes()?;
        let mut descendants = descendant_pids(pid, &processes);
        descendants.reverse();
        // Terminate the owner first so it cannot create more descendants while
        // cleanup walks the immutable snapshot. The remaining snapshotted
        // descendants are then terminated deepest-first.
        let mut targets = vec![pid];
        targets.extend(descendants);
        let failures = targets
            .into_iter()
            .filter_map(|target| terminate_pid(target).err())
            .collect::<Vec<_>>();
        if !failures.is_empty() {
            return Err(format!(
                "failed to terminate one or more process-tree members: {}",
                failures.join("; ")
            ));
        }
        Ok(())
    }

    #[cfg(test)]
    mod tests {
        use super::*;
        use std::{
            process::Command,
            thread,
            time::{Duration, Instant},
        };

        #[test]
        fn direct_parent_query_matches_the_independent_current_process_graph() {
            let helper_pid = unsafe { GetCurrentProcessId() };
            let observed = snapshot_processes()
                .expect("observe independent system process graph")
                .into_iter()
                .find(|process| process.pid == helper_pid)
                .expect("observe this current process");
            assert_eq!(
                current_parent_pid().expect("query current parent"),
                observed.parent_pid
            );
        }

        #[test]
        fn owner_admission_refusals_publish_correlated_pre_target_settlement() {
            let helper_pid = unsafe { GetCurrentProcessId() };
            let parent_pid = snapshot_processes()
                .expect("observe current process graph")
                .into_iter()
                .find(|process| process.pid == helper_pid)
                .expect("observe this test process")
                .parent_pid;
            let parent_handle =
                unsafe { OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, 0, parent_pid) };
            assert!(!parent_handle.is_null());
            let parent_identity =
                process_instance_id(Handle(parent_handle).0).expect("observe parent birth");
            let temporary =
                fs::canonicalize(env::temp_dir()).expect("resolve owned test temporary root");
            for (kind, owner_pid, owner_identity, expected_error) in [
                ("pid", helper_pid, "native-test-owner".to_string(), format!("Windows supervisor owner PID {helper_pid} does not match helper parent {parent_pid}")),
                ("birth", parent_pid, "win32:0".to_string(), format!("Windows supervisor owner process instance {parent_identity} does not match requested win32:0")),
            ] {
                let nonce = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).expect("current time").as_nanos();
                let directory = temporary.join(format!("opencorvus-parent-admission-{helper_pid}-{kind}-{nonce}"));
                fs::create_dir(&directory).expect("create exact owned test directory");
                let request_id = format!("owner-admission-{kind}");
                let outcome = (|| -> Result<(String, serde_json::Value), String> {
                    let request: Request = serde_json::from_value(serde_json::json!({
                        "kind":"command", "executable":"cmd.exe", "args":["/d","/s","/c","exit","0"],
                        "cwd":null, "cancel_file":directory.join("cancel"), "ready_file":directory.join("ready.json"),
                        "launch_failed_file":directory.join("launch-failed.json"), "settled_file":directory.join("settled.json"),
                        "request_id":request_id, "owner_pid":owner_pid, "owner_process_instance_id":owner_identity,
                        "runtime_occurrence_id":"native-parent-admission"
                    })).map_err(|error| error.to_string())?;
                    let error = run_request(request).err().ok_or_else(|| "Expected the declared owner admission error".to_string())?;
                    let marker = fs::read_to_string(directory.join("launch-failed.json")).map_err(|error| error.to_string())?;
                    let marker = serde_json::from_str(&marker).map_err(|error| error.to_string())?;
                    Ok((error, marker))
                })();
                assert_eq!(directory.parent(), Some(temporary.as_path()));
                fs::remove_dir_all(&directory).expect("remove exact owned test directory after native call returns");
                let (error, marker) = outcome.expect("owner refusal and original correlated pre-target fact");
                assert_eq!(error, expected_error);
                assert_eq!(marker, serde_json::json!({
                    "protocol":1, "request_id":request_id, "helper_pid":helper_pid,
                    "stage":"target_not_created", "active_processes":0,
                    "runtime_occurrence_id":"native-parent-admission"
                }));
            }
        }

        #[test]
        fn transfer_codecs_preserve_canonical_process_occurrence_id_fields() {
            let owner = serde_json::json!({"occurrenceID":"old-runtime","pid":41,"processInstanceID":"win32:101"});
            let successor = serde_json::json!({"occurrenceID":"new-runtime","pid":42,"processInstanceID":"win32:102"});
            let request: TransferRequest = serde_json::from_value(serde_json::json!({
                "protocol":1,"request_id":"request-1","expected_owner":owner,"successor":successor
            })).expect("decode current transfer request");
            assert_eq!(request.expected_owner, ProcessOwner { occurrence_id:"old-runtime".into(), pid:41, process_instance_id:"win32:101".into() });
            let ready: RestartReady = serde_json::from_value(serde_json::json!({
                "protocol":1,"request_id":"request-1","successor":successor,"url":"http://127.0.0.1:17888"
            })).expect("decode current application Ready");
            assert_eq!(ready.successor, request.successor);
            let receipt = TransferReceipt { protocol:1, request_id:"request-1", outcome:"committed",
                previous_owner:&request.expected_owner, successor:&request.successor,
                helper:TransferHelper { pid:43, process_instance_id:"win32:103" } };
            assert_eq!(serde_json::to_value(receipt).expect("encode committed receipt"), serde_json::json!({
                "protocol":1,"request_id":"request-1","outcome":"committed","previous_owner":owner,
                "successor":successor,"helper":{"pid":43,"processInstanceID":"win32:103"}
            }));
        }

        #[test]
        fn dropping_job_terminates_target_before_resume() {
            let executable = env::current_exe().expect("resolve current test executable");
            let request = LaunchRequest {
                application: executable.to_string_lossy().into_owned(),
                terminate_children_on_root_exit: false,
                command_line: quote_arg(&executable.to_string_lossy()),
                cwd: None,
                cancel_file: String::new(),
                ready_file: String::new(),
                launch_failed_file: String::new(),
                settled_file: String::new(),
                request_id: "native-job-ownership-test".into(),
                owner_pid: unsafe { GetCurrentProcessId() },
                owner_process_instance_id: "native-test-owner".into(),
                runtime_occurrence_id: "native-test-occurrence".into(),
                detached: false,
            };
            let target = create_suspended_target(&request, None)
                .expect("create suspended target atomically assigned to job");
            let SuspendedTarget {
                job,
                process,
                thread,
                pid,
            } = target;
            drop(thread);
            drop(job.expect("managed target owns a cleanup job"));

            let waited = unsafe { WaitForSingleObject(process.0, 2_000) };
            if waited != WAIT_OBJECT_0 {
                let cleanup = terminate_process_handle(process.0, pid);
                panic!(
                    "suspended target did not exit when its job closed (wait={waited}, cleanup={cleanup:?})"
                );
            }
        }

        #[test]
        fn managed_job_settles_only_after_every_assigned_process_exits() {
            let job = create_job().expect("create managed test job");
            let command = env::var("COMSPEC").expect("resolve Windows command interpreter");
            let root_request = LaunchRequest {
                application: command.clone(),
                terminate_children_on_root_exit: false,
                command_line: format!("{} /d /s /c exit 7", quote_arg(&command)),
                cwd: None,
                cancel_file: String::new(),
                ready_file: String::new(),
                launch_failed_file: String::new(),
                settled_file: String::new(),
                request_id: "native-job-root-test".into(),
                owner_pid: unsafe { GetCurrentProcessId() },
                owner_process_instance_id: "native-test-owner".into(),
                runtime_occurrence_id: "native-test-occurrence".into(),
                detached: false,
            };
            let descendant_request = LaunchRequest {
                application: command.clone(),
                terminate_children_on_root_exit: false,
                command_line: format!("{} /d /s /c ping 127.0.0.1 -n 2 >NUL", quote_arg(&command)),
                cwd: None,
                cancel_file: String::new(),
                ready_file: String::new(),
                launch_failed_file: String::new(),
                settled_file: String::new(),
                request_id: "native-job-descendant-test".into(),
                owner_pid: unsafe { GetCurrentProcessId() },
                owner_process_instance_id: "native-test-owner".into(),
                runtime_occurrence_id: "native-test-occurrence".into(),
                detached: false,
            };
            let (root, root_thread, root_pid) =
                create_suspended_process(&root_request, None, Some(job.0))
                    .expect("create managed root");
            let (descendant, descendant_thread, descendant_pid) =
                create_suspended_process(&descendant_request, None, Some(job.0))
                    .expect("create managed descendant");
            assert_ne!(unsafe { ResumeThread(root_thread.0) }, u32::MAX);
            assert_ne!(unsafe { ResumeThread(descendant_thread.0) }, u32::MAX);
            assert_eq!(
                unsafe { WaitForSingleObject(root.0, 2_000) },
                WAIT_OBJECT_0,
                "managed root {root_pid} did not exit"
            );
            let active_after_root =
                job_active_process_count(job.0).expect("query managed Job membership");
            assert!(
                active_after_root >= 1,
                "managed descendant {descendant_pid} must retain the Job after root exit; active={active_after_root}"
            );
            let mut cancellation_applied = false;
            wait_for_job_active_process_zero(job.0, "", None, &mut cancellation_applied)
                .expect("wait for managed Job active-process-zero");
            assert_eq!(
                unsafe { WaitForSingleObject(descendant.0, 0) },
                WAIT_OBJECT_0
            );
        }

        #[test]
        fn terminate_tree_reclaims_owner_and_snapshotted_descendants() {
            let mut owner = Command::new("cmd.exe")
                .args(["/C", "ping 127.0.0.1 -n 60 >NUL"])
                .spawn()
                .expect("spawn process-tree owner");
            let owner_pid = owner.id();
            let deadline = Instant::now() + Duration::from_secs(3);
            let descendants = loop {
                let processes = snapshot_processes().expect("snapshot spawned process tree");
                let descendants = descendant_pids(owner_pid, &processes);
                if !descendants.is_empty() || Instant::now() >= deadline {
                    break descendants;
                }
                thread::sleep(Duration::from_millis(20));
            };
            assert!(
                !descendants.is_empty(),
                "cmd process-tree owner did not publish a descendant"
            );

            terminate_process_tree(owner_pid).expect("terminate owner and descendants");
            let owner_status = owner.wait().expect("wait for terminated owner");
            assert_eq!(
                owner_status.code(),
                Some(1),
                "terminated owner must expose the TerminateProcess exit code"
            );
            for descendant in descendants {
                let state =
                    open_terminable_process(descendant).expect("inspect terminated descendant");
                if let Some(process) = state {
                    assert_eq!(
                        unsafe { WaitForSingleObject(process.0, 0) },
                        WAIT_OBJECT_0,
                        "descendant {descendant} remains running"
                    );
                }
            }
        }
    }

    #[derive(Deserialize)]
    struct ScopeQuery {
        request: Request,
        ceiling: String,
        inactivity_timeout_ms: u64,
        max_output_bytes: usize,
    }

    struct ScopeIo {
        input: fs::File,
        output: Handle,
        error: Handle,
        environment: Vec<u16>,
    }

    struct QueryActivity {
        start: Instant,
        last: AtomicU64,
        bytes: AtomicUsize,
        reason: Mutex<Option<String>>,
    }

    fn scope_pipe() -> Result<(fs::File, Handle), String> {
        let mut read = null_mut(); let mut write = null_mut();
        let attributes = SECURITY_ATTRIBUTES {nLength:std::mem::size_of::<SECURITY_ATTRIBUTES>() as u32,lpSecurityDescriptor:null_mut(),bInheritHandle:1};
        if unsafe{CreatePipe(&mut read, &mut write, &attributes, 0)}==0 {return Err(format!("CreatePipe failed {}",unsafe{GetLastError()}));}
        let read = Handle(read); let write = Handle(write);
        if unsafe{SetHandleInformation(read.0,HANDLE_FLAG_INHERIT,0)}==0 {return Err(format!("SetHandleInformation failed {}",unsafe{GetLastError()}));}
        let file=unsafe{fs::File::from_raw_handle(read.0)};
        std::mem::forget(read);
        Ok((file,write))
    }

    type ScopeOutput = Arc<Mutex<std::io::Stdout>>;

    #[derive(Serialize)]
    struct QueryStreamSummary {
        bytes: usize,
        chunks: u64,
    }

    fn emit_query_frame(output: &ScopeOutput, value: serde_json::Value) -> Result<(), String> {
        let mut output = output.lock().map_err(|_| "scope output poisoned")?;
        serde_json::to_writer(&mut *output, &value)
            .map_err(|error| format!("scope frame write failed: {error}"))?;
        output.write_all(b"\n").and_then(|_| output.flush())
            .map_err(|error| format!("scope frame flush failed: {error}"))
    }

    fn collect_query_bytes(
        mut input: fs::File,
        activity: Arc<QueryActivity>,
        maximum: usize,
        request_id: String,
        stream: &'static str,
        output: ScopeOutput,
    ) -> Result<QueryStreamSummary, String> {
        let mut summary = QueryStreamSummary { bytes: 0, chunks: 0 };
        let mut chunk = [0u8; 16384];
        loop {
            let count = input.read(&mut chunk).map_err(|error| format!("query pipe read failed: {error}"))?;
            if count == 0 {
                emit_query_frame(&output, serde_json::json!({
                    "kind": "stream_end", "request_id": request_id, "stream": stream,
                    "sequence": summary.chunks, "offset": summary.bytes,
                }))?;
                return Ok(summary);
            }
            // Activity belongs to actual target bytes, never control frames.
            activity.last.store(activity.start.elapsed().as_millis() as u64, Ordering::Release);
            let previous = activity.bytes.fetch_add(count, Ordering::AcqRel);
            let retained = count.min(maximum.saturating_sub(previous));
            if retained > 0 {
                if let Err(error) = emit_query_frame(&output, serde_json::json!({
                    "kind": "data", "request_id": request_id, "stream": stream,
                    "sequence": summary.chunks, "offset": summary.bytes, "bytes": &chunk[..retained],
                })) {
                    *activity.reason.lock().unwrap() = Some("output_delivery_error".into());
                    return Err(error);
                }
                summary.bytes += retained;
                summary.chunks += 1;
            }
            if previous.saturating_add(count) > maximum {
                *activity.reason.lock().unwrap() = Some("output_limit".into());
            }
        }
    }

    fn execute_scope_query(query: ScopeQuery, output_frames: ScopeOutput) -> serde_json::Value {
        let (request_id, cancel_file) = match &query.request {
            Request::Command { request_id, cancel_file, detached: false, .. } =>
                (request_id.clone(), cancel_file.clone()),
            _ => return serde_json::json!({"kind":"terminal", "error":"query_scope_requires_owned_command"}),
        };
        let execute = || -> Result<serde_json::Value, String> {
            let (stdout, output) = scope_pipe()?;
            let (stderr, error) = scope_pipe()?;
            let input = fs::OpenOptions::new().read(true).open("NUL")
                .map_err(|error| format!("NUL open failed: {error}"))?;
            if unsafe { SetHandleInformation(input.as_raw_handle(), HANDLE_FLAG_INHERIT, HANDLE_FLAG_INHERIT) } == 0 {
                return Err(format!("NUL inherit failed {}", unsafe { GetLastError() }));
            }
            let mut environment: Vec<_> = env::vars_os()
                .filter(|(key, _)| !key.to_string_lossy().eq_ignore_ascii_case("GIT_CEILING_DIRECTORIES"))
                .collect();
            environment.push(("GIT_CEILING_DIRECTORIES".into(), query.ceiling.into()));
            environment.sort_by_key(|(key, _)| key.to_string_lossy().to_uppercase());
            let mut block = Vec::new();
            for (key, value) in environment {
                block.extend(key.encode_wide()); block.push('=' as u16);
                block.extend(value.encode_wide()); block.push(0);
            }
            block.push(0);
            let activity = Arc::new(QueryActivity {
                start: Instant::now(), last: AtomicU64::new(0), bytes: AtomicUsize::new(0), reason: Mutex::new(None),
            });
            let finished = Arc::new(AtomicBool::new(false));
            let stdout = {
                let activity = activity.clone(); let output_frames = output_frames.clone(); let id = request_id.clone();
                std::thread::spawn(move || collect_query_bytes(stdout, activity, query.max_output_bytes, id, "stdout", output_frames))
            };
            let stderr = {
                let activity = activity.clone(); let output_frames = output_frames.clone(); let id = request_id.clone();
                std::thread::spawn(move || collect_query_bytes(stderr, activity, query.max_output_bytes, id, "stderr", output_frames))
            };
            let monitor = {
                let activity = activity.clone(); let finished = finished.clone();
                std::thread::spawn(move || -> Result<(), String> {
                    while !finished.load(Ordering::Acquire) {
                        let now = activity.start.elapsed().as_millis() as u64;
                        if now.saturating_sub(activity.last.load(Ordering::Acquire)) >= query.inactivity_timeout_ms {
                            let mut reason = activity.reason.lock().unwrap();
                            if reason.is_none() { *reason = Some("inactivity_timeout".into()); }
                        }
                        if activity.reason.lock().unwrap().is_some() {
                            fs::write(&cancel_file, b"scope-query-control")
                                .map_err(|error| format!("cancel publish failed: {error}"))?;
                            return Ok(());
                        }
                        std::thread::sleep(std::time::Duration::from_millis(20));
                    }
                    Ok(())
                })
            };
            let native = run_request_with_io(query.request, Some(ScopeIo { input, output, error, environment: block }));
            let stdout = stdout.join().map_err(|_| "stdout reader panicked")?;
            let stderr = stderr.join().map_err(|_| "stderr reader panicked")?;
            finished.store(true, Ordering::Release);
            let monitor = monitor.join().map_err(|_| "inactivity monitor panicked")?;
            let mut failures = Vec::new();
            if let Err(error) = &native { failures.push(error.clone()); }
            if let Err(error) = &stdout { failures.push(error.clone()); }
            if let Err(error) = &stderr { failures.push(error.clone()); }
            if let Err(error) = monitor { failures.push(error); }
            let reason = activity.reason.lock().unwrap().clone();
            let delivered = stdout.is_ok() && stderr.is_ok();
            Ok(serde_json::json!({
                "kind":"terminal", "request_id":request_id, "code":native.ok(),
                "error":reason, "native_errors":failures,
                "streams":{"stdout":stdout.ok(), "stderr":stderr.ok()},
                "output_joined":true, "output_delivery_complete":delivered,
            }))
        };
        match execute() {
            Ok(value) => value,
            Err(error) => serde_json::json!({"kind":"terminal", "request_id":request_id, "error":error}),
        }
    }

    fn query_scope() -> Result<(), String> {
        let mut workers = Vec::new();
        let mut seen = std::collections::BTreeSet::new();
        let output = Arc::new(Mutex::new(std::io::stdout()));
        for line in std::io::stdin().lock().lines() {
            let line = line.map_err(|error| format!("scope input failed: {error}"))?;
            let query: ScopeQuery = serde_json::from_str(&line)
                .map_err(|error| format!("scope request parse failed: {error}"))?;
            let id = match &query.request {
                Request::Command { request_id, detached: false, .. } => request_id.clone(),
                _ => return Err("scope requires owned command".into()),
            };
            if !seen.insert(id) { return Err("scope duplicate request identity".into()); }
            let output = output.clone();
            workers.push(std::thread::spawn(move || -> Result<(), String> {
                let result = execute_scope_query(query, output.clone());
                emit_query_frame(&output, result)
            }));
        }
        let failures: Vec<_> = workers.into_iter().filter_map(|worker| match worker.join() {
            Ok(Ok(())) => None, Ok(Err(error)) => Some(error), Err(_) => Some("scope query panicked".into()),
        }).collect();
        if failures.is_empty() { Ok(()) } else { Err(failures.join("; ")) }
    }


    pub fn main() {
        let mut args = env::args().skip(1);
        match (args.next().as_deref(), args.next()) {
            (Some("--query-scope"), None) => {
                match query_scope() { Ok(())=>std::process::exit(0),Err(error)=>{eprintln!("{error}");std::process::exit(125);} }
            }
            (Some("--detached-capability"), None) => {
                let mut contained = 0;
                let observed = unsafe { IsProcessInJob(GetCurrentProcess(), null_mut(), &mut contained) };
                let containment = if observed == 0 { "unobservable" } else if contained != 0 { "contained" } else { "independent" };
                println!("{}", serde_json::json!({ "protocol": READY_PROTOCOL, "containment": containment }));
                std::process::exit(0);
            }
            (Some("--version"), None) => {
                println!("{}", env!("CARGO_PKG_VERSION"));
                std::process::exit(0);
            }
            (Some("--request"), Some(request_path)) => {
                let body = match fs::read_to_string(&request_path) {
                    Ok(body) => body,
                    Err(err) => {
                        eprintln!("read request failed: {err}");
                        std::process::exit(2);
                    }
                };
                let request: Request = match serde_json::from_str(&body) {
                    Ok(request) => request,
                    Err(err) => {
                        eprintln!("parse request failed: {err}");
                        std::process::exit(2);
                    }
                };
                match run_request(request) {
                    Ok(code) => std::process::exit(code as i32),
                    Err(err) => {
                        eprintln!("opencorvus process supervisor failed: {err}");
                        std::process::exit(125);
                    }
                }
            }
            (Some("--process-instance-id"), Some(pid)) => {
                let pid = match pid.parse::<u32>() {
                    Ok(pid) if pid > 0 => pid,
                    _ => {
                        eprintln!("invalid process id for --process-instance-id");
                        std::process::exit(2);
                    }
                };
                let process = unsafe { OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, 0, pid) };
                if process.is_null() || process == INVALID_HANDLE_VALUE {
                    let error = unsafe { GetLastError() };
                    eprintln!("OpenProcess(identity {pid}) failed (win32={error})");
                    std::process::exit(125);
                }
                match process_instance_id(Handle(process).0) {
                    Ok(identity) => {
                        println!("{identity}");
                        std::process::exit(0);
                    }
                    Err(err) => {
                        eprintln!("read process identity failed: {err}");
                        std::process::exit(125);
                    }
                }
            }
            (Some("--kill-tree"), Some(pid)) => {
                let pid = match pid.parse::<u32>() {
                    Ok(pid) if pid > 0 => pid,
                    _ => {
                        eprintln!("invalid process id for --kill-tree");
                        std::process::exit(2);
                    }
                };
                match terminate_process_tree(pid) {
                    Ok(()) => std::process::exit(0),
                    Err(err) => {
                        eprintln!("opencorvus process tree cleanup failed: {err}");
                        std::process::exit(125);
                    }
                }
            }
            _ => {
                eprintln!(
                    "usage: opencorvus-process-supervisor --version | --request <json> | --process-instance-id <pid> | --kill-tree <pid>"
                );
                std::process::exit(2);
            }
        }
    }
}

#[cfg(windows)]
fn main() {
    windows_helper::main();
}

#[cfg(not(windows))]
fn main() {
    eprintln!("opencorvus-process-supervisor is only supported on Windows");
    std::process::exit(125);
}
