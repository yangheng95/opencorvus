import fs from 'node:fs/promises'
import path from 'node:path'
import assert from 'node:assert/strict'
const project='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/file-outcomes-after-01a133/project/scoped-project'
const requests=[]
async function request(route,params,expected=200){
  const url=new URL('http://127.0.0.1:18446/'+route)
  url.search=new URLSearchParams({...params,directory:project}).toString()
  const response=await fetch(url,{signal:AbortSignal.timeout(15000)})
  const raw=await response.text()
  const body=JSON.parse(raw)
  requests.push({route,params,status:response.status,requestID:response.headers.get('x-opencorvus-request-id'),rawBody:raw,body})
  assert.equal(response.status,expected,'Actual HTTP status '+url)
  return body
}
const expected=new Map([
  ['copy-case/a.txt','copy-case a.txt\r\n'],
  ['copy-case/b.txt','copy-case b.txt\r\n'],
  ['move-case/b.txt','move-case b.txt\r\n'],
  ['quarantine/delete-b.txt','delete-case b.txt\r\n'],
  ['quarantine/moved-a.txt','move-case a.txt\r\n'],
  ['../a.txt','copy-case a.txt\r\n'],
  ['../retired-move-rule/marker.txt','move-case rule directory\r\n'],
  ['../retired-copy-rule/marker.txt','copy-case rule directory\r\n'],
  ['outcomes-upload.txt','OUTCOMES UPLOAD\r\n'],
  ['note.md','SCOPED NOTE\r\n'],
])
const files=[]
for(const [file,content] of expected){
  const bytes=await fs.readFile(path.resolve(project,file))
  assert.deepEqual(bytes,Buffer.from(content,'utf8'),'Physical complete bytes '+file)
  const result=await request('file/content',{path:file})
  assert.equal(result.type,'text')
  assert.equal(result.content,content)
  assert.equal(typeof result.revision,'string')
  files.push({path:file,byteLength:bytes.length,content})
}
const deleted=await request('file/content',{path:'delete-case/a.txt'},404)
assert.equal(deleted.name,'FileNotFoundError')
assert.equal(deleted.data.path,'delete-case/a.txt')
assert.deepEqual(await request('file',{path:'delete-case'}),[])
const root=await request('file',{path:''})
assert.deepEqual(root.find(node=>node.path==='outcomes-upload.txt'),{
  name:'outcomes-upload.txt',path:'outcomes-upload.txt',absolute:path.resolve(project,'outcomes-upload.txt'),type:'file',ignored:false,
})
const parent=await request('file',{path:'..'})
assert.deepEqual(parent.find(node=>node.absolute===path.resolve(project,'../a.txt')),{
  name:'a.txt',path:path.join('..','a.txt'),absolute:path.resolve(project,'../a.txt'),type:'file',ignored:false,
})
assert.deepEqual(await request('find/file',{query:'outcomes-upload',type:'file',limit:'80'}),['outcomes-upload.txt'])
await fs.writeFile('specs/artifacts/2026-10-13-file-operation-outcomes/post/actual-api-and-bytes.json',JSON.stringify({project,phase:'Fresh native source CLI reading exact original after physical results',files,requests,verified:true},null,2)+'\n')
console.log(JSON.stringify({actualFiles:files.length,actualRequests:requests.length,verified:true}))
