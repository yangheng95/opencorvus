import fs from 'node:fs/promises'
import path from 'node:path'
import assert from 'node:assert/strict'
const run='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/file-links-before-01a133'
const facts=JSON.parse(await fs.readFile('.tmp-codex-link-plan-01a133/before/fixture.json','utf8'))
assert.equal(path.resolve(facts.owner.runRoot),path.resolve(run))
const root=facts.owner.project, requests=[]
async function request(file,status){const url=new URL('http://127.0.0.1:18447/file/content');url.search=new URLSearchParams({directory:root,path:file});const r=await fetch(url,{signal:AbortSignal.timeout(15000)}),rawBody=await r.text(),body=JSON.parse(rawBody);requests.push({file,status:r.status,requestID:r.headers.get('x-opencorvus-request-id'),rawBody,body});assert.equal(r.status,status,rawBody);return body}
const target=path.join(root,'moved-relative.md'),entry=await fs.lstat(target),linkText=await fs.readlink(target),original=facts.entries.find(x=>x.file==='link-cases/missing/relative-file.md')
assert.equal(entry.isSymbolicLink(),true);assert.equal(String(entry.ino),original.inode);assert.equal(String(entry.dev),original.device);assert.equal(linkText,original.linkText)
for(const file of ['link-cases/missing/relative-file.md','moved-relative.md'])assert.deepEqual(await request(file,404),{name:'FileNotFoundError',data:{path:file,message:`File entry not found: ${file}`}})
const bytes=await fs.readFile(path.join(root,'link-cases/missing/target.md'));assert.deepEqual(bytes,Buffer.from(facts.files['link-cases/missing/target.md']))
const content=await request('link-cases/missing/target.md',200);assert.equal(content.content,bytes.toString('utf8'));assert.equal(typeof content.revision,'string')
await fs.writeFile('.tmp-codex-link-plan-01a133/before/physical-http-check.json',JSON.stringify({entry:{path:target,inode:String(entry.ino),device:String(entry.dev),linkText},original,requests,bytesBase64:bytes.toString('base64'),boundary:'Published link entry retains identity/text while both old and dangling new content return true 404; original target complete bytes retained'},null,2))
console.log('Real before checker: same entry inode/text, 2 exact404 + complete target200')
