import fs from 'node:fs/promises'
import path from 'node:path'
import assert from 'node:assert/strict'
const fixture=JSON.parse(await fs.readFile('.tmp-codex-link-plan-01a133/after/fixture.json','utf8'))
assert.equal(fixture.owner.port,18448)
const original=fixture.entries.find(x=>x.file==='link-cases/broken-file.md'),full=path.join(fixture.owner.project,'link-cases/renamed-broken.md')
const entry=await fs.lstat(full),text=await fs.readlink(full)
assert.equal(entry.isSymbolicLink(),true);assert.equal(String(entry.ino),original.inode);assert.equal(String(entry.dev),original.device);assert.equal(text,original.linkText)
await fs.writeFile('.tmp-codex-link-plan-01a133/after/renamed-entry-identity.json',JSON.stringify({original,renamed:{full,inode:String(entry.ino),device:String(entry.dev),text}},null,2))
console.log('Actual renamed broken entry retains exact inode/device/readlink before its one UI Delete')
