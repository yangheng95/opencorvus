import fs from 'node:fs/promises'
import path from 'node:path'
import assert from 'node:assert/strict'
const [runRoot,port,phase]=process.argv.slice(2)
assert(['before','after'].includes(phase))
const expected='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/file-links-'+phase+'-01a133'
assert.equal(path.resolve(runRoot),path.resolve(expected))
const owner=JSON.parse(await fs.readFile(path.join(runRoot,'launch-owner.json'),'utf8'))
assert.equal(owner.port,Number(port));assert.equal(path.resolve(owner.project),path.resolve(runRoot,'project','scoped-project'))
const root=owner.project, evidence=path.resolve('.tmp-codex-link-plan-01a133',phase)
await fs.mkdir(evidence,{recursive:true})
for(const dir of ['link-cases','link-cases/missing','link-cases/retarget','targets','targets/dir'])await fs.mkdir(path.join(root,dir))
const files={'link-cases/missing/target.md':'MISSING MOVE OLD 资料\r\n','link-cases/retarget/new-target.md':'RETARGET OLD 资料\r\n','new-target.md':'RETARGET NEW 资料\r\n','targets/dir/marker.md':'JUNCTION TARGET RETAINED\r\n','link-cases/copy-target.md':'COPY LINK TARGET\r\n'}
for(const [file,text]of Object.entries(files))await fs.writeFile(path.join(root,file),text,{flag:'wx'})
const links=[['link-cases/missing/relative-file.md','target.md','file'],['link-cases/retarget/retarget-file.md','new-target.md','file'],['link-cases/healthy-junction',path.join(root,'targets/dir'),'junction'],['link-cases/broken-file.md','missing-owned-target.md','file'],['link-cases/copy-file.md','copy-target.md','file']]
for(const [file,target,type]of links)await fs.symlink(target,path.join(root,file),type)
await fs.appendFile(path.resolve(root,'../.gitignore'),'/scoped-project/moved-junction/\n')
const entries=[]
for(const [file]of links){const full=path.join(root,file),st=await fs.lstat(full);entries.push({file,full,type:{directory:st.isDirectory(),file:st.isFile(),link:st.isSymbolicLink()},inode:String(st.ino),device:String(st.dev),linkText:await fs.readlink(full)})}
const url=new URL(`http://127.0.0.1:${port}/coding/chat/session`);url.searchParams.set('directory',root)
const response=await fetch(url,{method:'POST',headers:{'content-type':'application/json'},body:'{}',signal:AbortSignal.timeout(15000)})
const rawBody=await response.text();assert.equal(response.status,201,rawBody)
await fs.writeFile(path.join(evidence,'fixture.json'),JSON.stringify({owner,files,links,entries,chat:{status:response.status,requestID:response.headers.get('x-opencorvus-request-id'),rawBody,body:JSON.parse(rawBody)}},null,2))
console.log(JSON.stringify({project:root,port,phase,chat:JSON.parse(rawBody),entries},null,2))
