import fs from 'node:fs/promises'
import path from 'node:path'
import assert from 'node:assert/strict'
const run='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/file-links-after-01a133'
const facts=JSON.parse(await fs.readFile('.tmp-codex-link-plan-01a133/after/fixture.json','utf8'))
assert.equal(path.resolve(facts.owner.runRoot),path.resolve(run))
const root=facts.owner.project, requests=[], files=[], entries=[]
async function request(route,params,status=200){const url=new URL('http://127.0.0.1:18448/'+route);url.search=new URLSearchParams({directory:root,...params});const r=await fetch(url,{signal:AbortSignal.timeout(15000)}),rawBody=await r.text(),body=JSON.parse(rawBody);requests.push({route,params,status:r.status,requestID:r.headers.get('x-opencorvus-request-id'),rawBody,body});assert.equal(r.status,status,rawBody);return body}
const list=await request('file',{path:''})
for(const [originalPath,target]of [['link-cases/missing/relative-file.md','moved-relative.md'],['link-cases/retarget/retarget-file.md','moved-retarget.md'],['link-cases/healthy-junction','moved-junction']]){
 const original=facts.entries.find(x=>x.file===originalPath),full=path.join(root,target),st=await fs.lstat(full),text=await fs.readlink(full)
 assert.equal(st.isSymbolicLink(),true);assert.equal(String(st.ino),original.inode);assert.equal(String(st.dev),original.device);assert.equal(text,original.linkText)
 const node={name:target,path:target,absolute:full,type:'file',ignored:false}
 assert.deepEqual(list.find(x=>x.path===target),node)
 entries.push({originalPath,target,inode:String(st.ino),device:String(st.dev),text,node})
}
const copied=path.join(root,'copied-file.md'),copyOriginal=facts.entries.find(x=>x.file==='link-cases/copy-file.md')
assert.equal((await fs.lstat(copied)).isSymbolicLink(),true);assert.equal(await fs.readlink(copied),copyOriginal.linkText);assert.equal(await fs.readlink(path.join(root,copyOriginal.file)),copyOriginal.linkText)
entries.push({target:'copied-file.md',text:await fs.readlink(copied),sourceText:await fs.readlink(path.join(root,copyOriginal.file))})
for(const [file,text]of Object.entries(facts.files)){const bytes=await fs.readFile(path.join(root,file));assert.deepEqual(bytes,Buffer.from(text));const content=await request('file/content',{path:file});assert.equal(content.content,text);assert.equal(typeof content.revision,'string');files.push({file,bytesBase64:bytes.toString('base64'),content})}
const retarget=await request('file/content',{path:'moved-retarget.md'});assert.equal(retarget.content,facts.files['new-target.md'])
for(const file of ['link-cases/missing/relative-file.md','moved-relative.md','copied-file.md','link-cases/renamed-broken.md','link-cases/broken-file.md'])assert.deepEqual(await request('file/content',{path:file},404),{name:'FileNotFoundError',data:{path:file,message:`File entry not found: ${file}`}})
const through=await request('file/content',{path:'moved-junction/marker.md'});assert.equal(through.content,facts.files['targets/dir/marker.md'])
await fs.writeFile('.tmp-codex-link-plan-01a133/after/physical-http-check.json',JSON.stringify({entries,files,requests,retarget,through,boundary:'Exact moved entry identity/readlink, copied original text, original and new target complete bytes, list-entry flags and separate current-content contracts; no mutation replay'},null,2))
console.log(`Same real after project: ${requests.length} requests, ${files.length} complete byte/content files, 3 exact moved link identities + copied text`)
