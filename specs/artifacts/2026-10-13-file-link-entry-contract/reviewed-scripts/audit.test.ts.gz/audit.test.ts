import { afterAll, expect, test } from "bun:test"
import fs from "node:fs/promises"
import path from "node:path"
import { Hono } from "../packages/opencorvus/node_modules/hono/dist/index.js"
import { Instance } from "../packages/opencorvus/src/project/instance"
import { FileRoutes } from "../packages/opencorvus/src/server/routes/file"
import { serverErrorResponse } from "../packages/opencorvus/src/server/error-handler"
import { Filesystem } from "../packages/opencorvus/src/util/filesystem"
import { memoryProject, resetMemoryDatabase } from "../packages/opencorvus/test/fixture/memory"

afterAll(resetMemoryDatabase)
const rows: unknown[] = []
const bytes = Buffer.from("Link plan exact 资料\r\n", "utf8")

async function observed(full: string) {
  const result: Record<string, unknown> = { full }
  try {
    const entry = await fs.lstat(full, { bigint: true })
    result.entry = { directory: entry.isDirectory(), file: entry.isFile(), link: entry.isSymbolicLink(), device: String(entry.dev), inode: String(entry.ino) }
    if (entry.isSymbolicLink()) result.linkText = await fs.readlink(full)
  } catch (error) { result.entryError = { code: (error as NodeJS.ErrnoException).code, message: (error as Error).message } }
  try {
    const target = await fs.stat(full, { bigint: true })
    result.target = { directory: target.isDirectory(), file: target.isFile(), device: String(target.dev), inode: String(target.ino) }
    result.physical = await fs.realpath(full)
    if (target.isFile()) result.bytesBase64 = (await fs.readFile(full)).toString("base64")
    if (target.isDirectory()) result.names = await fs.readdir(full)
  } catch (error) { result.targetError = { code: (error as NodeJS.ErrnoException).code, message: (error as Error).message } }
  return result
}

async function save(row: unknown) {
  rows.push(row)
  console.log("[owned link plan observation]", JSON.stringify(row))
  await fs.writeFile(path.join(import.meta.dir, "evidence.json"), JSON.stringify(rows, null, 2))
}

async function owned(seed: string) {
  const fixture = await memoryProject(seed)
  const owner = await fs.realpath(process.env.OPENCORVUS_TEST_PROCESS_ROOT!)
  const relative = path.relative(owner, fixture.path)
  if (path.isAbsolute(relative) || !relative.startsWith(`fixtures${path.sep}memory-`)) throw new Error("New owned fixture required")
  expect(await fs.readFile(path.join(fixture.path, ".opencorvus-test-project-identity"), "utf8")).toBe(seed)
  return fixture
}

test("observe exact cp link text and native dangling entry primitives in new managed roots", async () => {
  await using fixture = await owned("link-plan-source-01a133")
  await using external = await owned("link-plan-external-01a133")
  const source = path.join(fixture.path, "source 资料")
  const destination = path.join(fixture.path, "destination 资料")
  await fs.mkdir(source)
  await fs.mkdir(destination)
  await fs.mkdir(path.join(source, "local-dir"))
  await fs.mkdir(path.join(fixture.path, "absolute-dir"))
  await fs.writeFile(path.join(source, "file 资料.md"), bytes)
  await fs.writeFile(path.join(source, "local-dir", "marker.md"), bytes)
  await fs.writeFile(path.join(fixture.path, "absolute-dir", "marker.md"), bytes)
  for (const [name, target, type] of [
    ["relative-file", "file 资料.md", "file"],
    ["broken-file", "missing 资料.md", "file"],
    ["relative-dir", "local-dir", "dir"],
    ["absolute-junction", path.join(fixture.path, "absolute-dir"), process.platform === "win32" ? "junction" : "dir"],
    ["broken-junction", path.join(fixture.path, "missing-dir"), process.platform === "win32" ? "junction" : "dir"],
  ] as const) {
    const full = path.join(source, name)
    await fs.symlink(target, full, type)
    for (const verbatimSymlinks of [false, true]) {
      const copied = path.join(destination, `${name}-${verbatimSymlinks}`)
      let outcome: unknown = { status: "copied" }
      try { await fs.cp(full, copied, { recursive: false, force: false, errorOnExist: true, dereference: false, verbatimSymlinks }) }
      catch (error) { outcome = { status: "error", code: (error as NodeJS.ErrnoException).code, message: (error as Error).message } }
      await save({ label: "cp primitive", name, verbatimSymlinks, outcome, source: await observed(full), copied: await observed(copied) })
    }
  }
  const errors: unknown[] = []
  const app = new Hono().onError((error, c) => { errors.push({ name: error.name, message: error.message }); return serverErrorResponse(error, c) }).route("/", FileRoutes())
  const server = Bun.serve({ hostname: "127.0.0.1", port: 0, fetch: request => Instance.provide({ directory: fixture.path, fn: () => app.fetch(request) }) })
  const scope = await Instance.provide({ directory: fixture.path, fn: async () => ({ directory: Instance.directory, worktree: Instance.worktree, projectID: Instance.project.id }) })
  try {
    for (const action of ["move", "copy", "delete"] as const) {
      const file = `broken-external-${action}`
      const full = path.join(fixture.path, file)
      const linkText = path.join(external.path, "missing-external.md")
      await fs.symlink(linkText, full, "file")
      const errorsStart = errors.length
      const route = action === "delete" ? `/file/item?${new URLSearchParams({ path: file })}` : action === "copy" ? "/file/item/copy" : "/file/item"
      const response = await fetch(new URL(route, server.url), {
        method: action === "delete" ? "DELETE" : action === "copy" ? "POST" : "PATCH",
        ...(action === "delete" ? {} : { headers: { "content-type": "application/json" }, body: JSON.stringify({ path: file, newPath: `result-${action}` }) }),
        signal: AbortSignal.timeout(20_000),
      })
      await save({ label: "broken external declared target API", scope, action, input: { path: file, newPath: `result-${action}` }, response: { status: response.status, body: await response.json(), requestID: response.headers.get("x-opencorvus-request-id"), errors: errors.slice(errorsStart) }, source: await observed(full), target: await observed(path.join(fixture.path, `result-${action}`)) })
    }
  } finally { await server.stop(true) }
  for (const name of ["broken-file", "broken-junction"]) {
    const old = path.join(source, name)
    const next = path.join(destination, `${name}-native`)
    const before = await observed(old)
    await Filesystem.renameNoReplace(old, next)
    const moved = await observed(next)
    await fs.unlink(next)
    await save({ label: "native dangling rename then unlink", name, before, moved, removed: await observed(next), marker: await observed(path.join(source, "file 资料.md")) })
  }
  const copiedFolder = path.join(destination, "complete-folder")
  await fs.cp(source, copiedFolder, { recursive: true, force: false, errorOnExist: true, dereference: false, verbatimSymlinks: true })
  await save({ label: "complete folder verbatim copy", source: await observed(source), copied: await observed(copiedFolder), relativeLink: await observed(path.join(copiedFolder, "relative-file")), marker: await observed(path.join(copiedFolder, "file 资料.md")), relativeDirectoryLink: await observed(path.join(copiedFolder, "relative-dir")), directoryMarker: await observed(path.join(copiedFolder, "relative-dir", "marker.md")) })
}, 120_000)
