import assert from "node:assert/strict"
import fs from "node:fs/promises"
import path from "node:path"
import { Database as SQLite } from "bun:sqlite"
import { migrateSchema, schemaVersion } from "../../packages/opencorvus/src/storage/schema-migration"
import { queryAllFinalized } from "../../packages/opencorvus/src/storage/sqlite-statement"
import { readSchemaObjects } from "../../packages/opencorvus/src/storage/schema-contract"
import { SCHEMA_DDL } from "../../packages/opencorvus/src/storage/ddl"
import { DATABASE_MIGRATIONS } from "../../packages/opencorvus/src/storage/migrations"

// Preparation only. Root must approve the complete source and exact fresh scope.
const [role, runtime, evidence, rawDeadline, rawParentDeadline] = process.argv.slice(2)
const roles = ["seed", "hold-production", "hold-readonly", "candidate", "locked-reader", "new-reader", "old-reopen",
  "race-a", "race-b", "after-race", "followup-reader", "backup-fault", "validator-fault", "v1-reopen"]
assert(role && roles.includes(role), "Explicit owned worker role required")
assert(runtime && evidence && path.isAbsolute(runtime) && path.isAbsolute(evidence))
assert.equal(process.env.OPENCORVUS_HOME, runtime)
const startedAt = Date.now(), deadlineAt = Number(rawDeadline), parentDeadlineAt = Number(rawParentDeadline)
assert(Number.isSafeInteger(deadlineAt) && deadlineAt > startedAt && deadlineAt <= startedAt + 180000)
assert(Number.isSafeInteger(parentDeadlineAt) && deadlineAt <= parentDeadlineAt - 60000)
const closeBy = Math.min(deadlineAt - 15000, parentDeadlineAt - 60000)
const databasePath = path.join(runtime, "data", "opencorvus.db")
const read = queryAllFinalized
const revision = [...DATABASE_MIGRATIONS, { version: 2, name: "Owned lock mechanism only; no semantic change", ddl: SCHEMA_DDL }]
assert.equal(DATABASE_MIGRATIONS.at(-1)?.version, 1, "This exact experiment requires the current production v1 source")
const facts: Record<string, any> = { role, pid: process.pid, startedAt, deadlineAt, closeBy, parentDeadlineAt,
  executable: process.execPath, bunVersion: Bun.version, runtime, evidence, databasePath,
  rawCreated: false, rawClosed: "not_started", productionCreated: false, productionClosed: "not_started" }
let sqlite: SQLite | undefined
let production: typeof import("../../packages/opencorvus/src/storage/db") | undefined
let primary: { error: unknown } | undefined
const quote = (value: string) => `"${value.replaceAll('"', '""')}"`
function publicError(error: unknown): unknown {
  if (!(error instanceof Error)) return { value: String(error) }
  const value = error as Error & { code?: unknown; errno?: unknown; data?: unknown; backupPath?: unknown; path?: unknown; syscall?: unknown }
  return { name: value.name, message: value.message, ...(value.code === undefined ? {} : { code: value.code }),
    ...(value.errno === undefined ? {} : { errno: value.errno }), ...(value.data === undefined ? {} : { data: value.data }),
    ...(value.backupPath === undefined ? {} : { backupPath: value.backupPath }),
    ...(value.path === undefined ? {} : { path: value.path }), ...(value.syscall === undefined ? {} : { syscall: value.syscall }),
    ...(value.cause === undefined ? {} : { cause: publicError(value.cause) }),
    ...(error instanceof AggregateError ? { errors: error.errors.map(publicError) } : {}) }
}
function normalized(value: unknown): unknown {
  if (typeof value === "bigint") return { bigint: String(value) }
  if (value instanceof Uint8Array) return { bytes: Array.from(value) }
  if (Array.isArray(value)) return value.map(normalized)
  if (value && typeof value === "object") return Object.fromEntries(Object.entries(value).map(([key, child]) => [key, normalized(child)]))
  return value
}
function snapshot(query: <T>(sql: string) => T[]) {
  const objects = query<{ type: string; name: string; tbl_name: string; sql: string | null }>(
    "SELECT type,name,tbl_name,sql FROM sqlite_schema WHERE name NOT LIKE 'sqlite_%' ORDER BY type,name")
  const physical = new Map(query<{ schema: string; name: string; wr: number }>("PRAGMA table_list")
    .filter(table => table.schema === "main").map(table => [table.name, table]))
  const rows = objects.filter(object => object.type === "table").map(object => {
    const table = physical.get(object.name)
    assert(table, `Actual table metadata required: ${object.name}`)
    let fields = "*"
    if (table.wr === 0) {
      const columns = query<{ name: string }>(`PRAGMA table_xinfo(${quote(object.name)})`).map(column => column.name)
      const rowid = ["rowid", "_rowid_", "oid"].find(name => !columns.includes(name))
      assert(rowid && !columns.includes("__owned_probe_rowid"), `Unshadowed actual row identity required: ${object.name}`)
      fields = `${quote(rowid)} AS "__owned_probe_rowid", *`
    }
    return { name: object.name, values: query(`SELECT ${fields} FROM ${quote(object.name)}`).map(normalized)
      .sort((a, b) => JSON.stringify(a).localeCompare(JSON.stringify(b))) }
  })
  return { version: query<{ user_version: number }>("PRAGMA user_version")[0]!.user_version, objects, rows }
}
const rawSnapshot = () => snapshot(<T>(sql: string) => read<T>(sqlite!, sql))
async function write(name: string, value: unknown) {
  const target = path.join(evidence, name), pending = `${target}.${role}.pending`
  await fs.writeFile(pending, JSON.stringify(value, null, 2))
  await fs.rename(pending, target)
}
async function exists(name: string) {
  try { await fs.stat(path.join(evidence, name)); return true }
  catch (error) { if ((error as NodeJS.ErrnoException).code === "ENOENT") return false; throw error }
}
async function marker(name: string) {
  const requestDeadlineAt = Math.min(Date.now() + 30000, closeBy)
  for (;;) {
    if (await exists("stop")) throw Error("Original parent requested normal closure")
    if (await exists(name)) return
    if (Date.now() >= requestDeadlineAt) throw Error(`Original marker deadline elapsed: ${name}`)
    await Bun.sleep(25)
  }
}
function openRaw(readonly: boolean) {
  assert(Date.now() < closeBy, "Original raw-handle admission deadline")
  sqlite = new SQLite(databasePath, readonly ? { readonly: true } : { readwrite: true })
  facts.rawCreated = true; facts.rawClosed = false
  sqlite.exec("PRAGMA busy_timeout=5000")
  return sqlite
}
function restoreNormal() {
  sqlite!.exec("PRAGMA main.locking_mode=NORMAL")
  // The finalized access performs the physical release; the pragma alone is not evidence.
  const accessed = read(sqlite!, "SELECT instance_id,time_created FROM database_authority ORDER BY key")
  return { mode: read(sqlite!, "PRAGMA main.locking_mode"), accessed }
}
function migrate(rejectValidation = false) {
  return migrateSchema({ sqlite: sqlite!, databasePath, migrations: revision, currentDDL: SCHEMA_DDL,
    validate() {
      const current = rawSnapshot()
      assert.deepEqual({ ...current, version: 1 }, facts.original)
      assert.deepEqual(read(sqlite!, "PRAGMA quick_check"), [{ quick_check: "ok" }])
      facts.validation = { observedAt: Date.now(), version: current.version, sameHandle: true, snapshot: current }
      if (rejectValidation) throw new Error("OWNED_VALIDATION_REJECTED")
    },
  })
}
async function seedFacts() {
  return JSON.parse(await fs.readFile(path.join(evidence, "seed-ready.json"), "utf8"))
}
function observeBackup(backupPath: string) {
  const backup = new SQLite(backupPath, { readonly: true })
  facts.backupCreated = true; facts.backupClosed = false
  let primary: { error: unknown } | undefined
  try {
    facts.backup = snapshot(<T>(sql: string) => read<T>(backup, sql))
    assert.deepEqual(facts.backup, facts.original)
  } catch (error) { primary = { error } }
  try { backup.close(true); facts.backupClosed = true }
  catch (error) {
    throw new AggregateError([...(primary ? [primary.error] : []), error], "Original backup read and strict close failed",
      primary ? { cause: primary.error } : undefined)
  }
  if (primary) throw primary.error
}
await write(`${role}-started.json`, facts)
try {
  if (role === "seed" || role === "hold-production" || role === "old-reopen" || role === "v1-reopen") {
    production = await import("../../packages/opencorvus/src/storage/db")
    assert.equal(path.resolve(production.Database.Path()), path.resolve(databasePath))
    if (role === "old-reopen") {
      facts.productionInitializationAttempted = true
      let caught: unknown
      try { production.Database.Client() } catch (error) { caught = error }
      facts.reopenError = publicError(caught)
      await write("old-reopen-result.json", facts)
      assert(production.DatabaseUnavailableError.isInstance(caught))
      assert.equal(caught.data.code, "SCHEMA_VERSION_AHEAD")
      assert.equal(caught.data.operation, "Database.Client.schemaMigration")
    } else {
      facts.identity = production.Database.Identity()
      facts.productionCreated = true; facts.productionClosed = false
      facts.version = production.Database.allFinalized("PRAGMA user_version")
      facts.journal = production.Database.allFinalized("PRAGMA main.journal_mode")
      facts.sqlite = production.Database.allFinalized("SELECT sqlite_version() AS version, sqlite_source_id() AS source_id")
      facts.original = snapshot(production.Database.allFinalized)
      assert.deepEqual(facts.version, [{ user_version: 1 }])
      assert.deepEqual(facts.journal, [{ journal_mode: "wal" }])
      if (role === "v1-reopen") {
        const original = await seedFacts()
        assert.deepEqual(facts.identity, original.identity)
        assert.deepEqual(facts.original, original.original)
        await write("v1-reopen-result.json", facts)
      } else await write(role === "seed" ? "seed-ready.json" : "a-ready.json", facts)
      if (role === "hold-production") {
        await marker("a-close")
        facts.beforeClose = snapshot(production.Database.allFinalized)
        assert.deepEqual(facts.beforeClose, facts.original)
      }
    }
  } else if (role === "hold-readonly") {
    openRaw(true)
    facts.journal = read(sqlite!, "PRAGMA main.journal_mode")
    facts.original = rawSnapshot() // Real schema and row reads finish; this handle then remains idle.
    assert.equal(facts.original.version, 1)
    assert.deepEqual(facts.journal, [{ journal_mode: "wal" }])
    await write("a-ready.json", facts)
    await marker("a-close")
    facts.beforeClose = rawSnapshot()
    assert.deepEqual(facts.beforeClose, facts.original)
  } else if (role === "candidate") {
    openRaw(false)
    sqlite!.exec("PRAGMA main.locking_mode=NORMAL")
    facts.normalMode = read(sqlite!, "PRAGMA main.locking_mode")
    facts.journal = read(sqlite!, "PRAGMA main.journal_mode")
    facts.original = rawSnapshot() // NORMAL attachment is established before selecting EXCLUSIVE.
    assert.deepEqual(facts.journal, [{ journal_mode: "wal" }])
    assert.equal(facts.original.version, 1)
    facts.schemaObjects = readSchemaObjects(sqlite!).length
    await write("b-normal-attached.json", facts)
    sqlite!.exec("PRAGMA main.locking_mode=EXCLUSIVE")
    const blockedStartedAt = Date.now()
    let blocked: unknown
    try { facts.unexpectedReceipt = migrate() } catch (error) { blocked = error }
    facts.blocked = { startedAt: blockedStartedAt, endedAt: Date.now(), error: publicError(blocked),
      ...(facts.unexpectedReceipt ? { unexpectedReceipt: facts.unexpectedReceipt } : {}) }
    await write("b-blocked.json", facts.blocked)
    assert.equal((blocked as { code?: string })?.code, "SQLITE_BUSY")
    facts.afterBlockedNormal = restoreNormal()
    facts.blocked.version = schemaVersion(sqlite!)
    facts.blocked.snapshot = rawSnapshot()
    assert.deepEqual(facts.blocked.snapshot, facts.original)
    await write("b-waiting-owner-close.json", { normal: facts.afterBlockedNormal, blocked: facts.blocked })
    await marker("old-owner-joined")
    const originalOwnerReceipt = JSON.parse(await fs.readFile(path.join(evidence, "old-owner-joined"), "utf8"))
    assert.equal(originalOwnerReceipt.exitCode, 0)
    assert.equal(originalOwnerReceipt.physicalJoined, true)
    facts.oldOwnerReceipt = originalOwnerReceipt
    assert(Date.now() < closeBy, "Original migration admission deadline")
    sqlite!.exec("PRAGMA main.locking_mode=EXCLUSIVE")
    facts.receipt = migrate()
    facts.committed = rawSnapshot()
    assert.deepEqual({ from: facts.receipt.from, to: facts.receipt.to, version: facts.committed.version }, { from: 1, to: 2, version: 2 })
    assert.deepEqual({ ...facts.committed, version: 1 }, facts.original)
    assert.equal(typeof facts.receipt.backupPath, "string")
    const backup = new SQLite(facts.receipt.backupPath, { readonly: true })
    try {
      facts.backup = snapshot(<T>(sql: string) => read<T>(backup, sql))
      assert.deepEqual(facts.backup, facts.original)
    } finally { backup.close(true); facts.backupClosed = true }
    await write("b-exclusive-committed.json", facts)
    await marker("unlock") // Parent first joins an actual reader that encounters the retained file lock.
    facts.normalRelease = restoreNormal()
    assert.deepEqual(facts.normalRelease.mode, [{ locking_mode: "normal" }])
    await write("b-normal-released.json", facts.normalRelease)
    await marker("b-close") // Parent first proves another fresh reader succeeds while this same handle remains open.
    facts.finalSnapshot = rawSnapshot()
    assert.deepEqual(facts.finalSnapshot, facts.committed)
  } else if (role === "race-a" || role === "race-b") {
    openRaw(false)
    sqlite!.exec("PRAGMA main.locking_mode=NORMAL")
    facts.normalMode = read(sqlite!, "PRAGMA main.locking_mode")
    facts.journal = read(sqlite!, "PRAGMA main.journal_mode")
    facts.original = rawSnapshot()
    assert.deepEqual(facts.normalMode, [{ locking_mode: "normal" }])
    assert.deepEqual(facts.journal, [{ journal_mode: "wal" }])
    assert.deepEqual(facts.original, (await seedFacts()).original)
    facts.readyObservedAt = Date.now()
    await write(`${role}-ready.json`, facts)
    await marker("race-start") // Both real NORMAL attachments exist before either escalation starts.
    const start = JSON.parse(await fs.readFile(path.join(evidence, "race-start"), "utf8"))
    assert(start.mode === "followup" || start.mode === "guarded-race")
    assert.equal(start.attached.length, 2)
    assert.equal(start.attached.find((item: any) => item.role === role)?.pid, process.pid)
    if (start.mode === "guarded-race") {
      assert.equal(start.oldProductionOwner.role, "hold-production")
      assert.equal(start.oldProductionOwner.productionCreated, true)
      assert.equal(start.oldProductionOwner.identity, (await seedFacts()).identity)
      assert.equal(start.oldProductionOwner.originalVersion, 1)
      facts.oldProductionOwnerAtAdmission = start.oldProductionOwner
    }
    facts.exclusivePolicySetStartedAt = Date.now()
    sqlite!.exec("PRAGMA main.locking_mode=EXCLUSIVE")
    facts.exclusivePolicySetReturnedAt = Date.now() // SQL policy boundary, not an OS lock receipt.
    const attemptStartedAt = Date.now()
    let migrationError: unknown
    try { facts.receipt = migrate() } catch (error) { migrationError = error }
    const outcome = migrationError ? ((migrationError as { code?: string }).code === "SQLITE_BUSY" ? "busy" : "failed")
      : facts.receipt.from === 1 && facts.receipt.to === 2 ? "upgraded"
      : facts.receipt.from === 2 && facts.receipt.to === 2 ? "current" : "unexpected_receipt"
    facts.attempt = { role, pid: process.pid, startedAt: attemptStartedAt, endedAt: Date.now(),
      outcome,
      ...(facts.receipt ? { receipt: facts.receipt } : {}), ...(migrationError ? { error: publicError(migrationError) } : {}) }
    // A committed version remains committed even if subsequent evidence or NORMAL release fails.
    await write(`${role}-attempt.json`, facts.attempt)
    if (migrationError) {
      assert.equal((migrationError as { code?: string }).code, "SQLITE_BUSY")
      // Do not re-enter the competing source for evidence. Strict close releases this real owner.
    } else {
      assert(outcome === "upgraded" || outcome === "current", "Actual receipt must identify a real upgrade or current-version admission")
      facts.committed = rawSnapshot()
      assert.equal(facts.committed.version, 2)
      assert.deepEqual({ ...facts.committed, version: 1 }, facts.original)
      assert.equal(facts.validation.version, 2)
      assert.equal(facts.validation.sameHandle, true)
      assert.deepEqual(facts.validation.snapshot, facts.committed)
      if (outcome === "upgraded") {
        assert.equal(typeof facts.receipt.backupPath, "string")
        observeBackup(facts.receipt.backupPath)
      } else {
        assert.deepEqual(facts.receipt, { from: 2, to: 2 })
      }
      facts.normalReleaseStartedAt = Date.now()
      facts.normalRelease = restoreNormal()
      facts.normalReleaseReturnedAt = Date.now()
      assert.deepEqual(facts.normalRelease.mode, [{ locking_mode: "normal" }])
    }
  } else if (role === "after-race" || role === "followup-reader") {
    facts.original = (await seedFacts()).original
    if (role === "after-race") {
      const owners = JSON.parse(await fs.readFile(path.join(evidence, "race-owners-joined"), "utf8"))
      assert(owners.mode === "followup" || owners.mode === "guarded-race")
      assert.equal(owners.owners.length, owners.mode === "guarded-race" ? 3 : 2)
      assert(owners.expectedAfterFrom === 1 || owners.expectedAfterFrom === 2)
      for (const owner of owners.owners) {
        assert.deepEqual({ reason: owner.receipt.reason, exitCode: owner.receipt.exitCode,
          physical: owner.physicalJoined, output: owner.outputJoined, request: owner.requestSettled },
          { reason: "exited", exitCode: 0, physical: true, output: true, request: true })
      }
      facts.originalCompetitors = owners
    }
    openRaw(false)
    sqlite!.exec("PRAGMA main.locking_mode=NORMAL")
    facts.journal = read(sqlite!, "PRAGMA main.journal_mode")
    facts.before = rawSnapshot()
    assert.deepEqual(facts.journal, [{ journal_mode: "wal" }])
    assert.deepEqual({ ...facts.before, version: 1 }, facts.original)
    if (role === "followup-reader") assert.equal(facts.before.version, 2)
    else assert.equal(facts.before.version, facts.originalCompetitors.expectedAfterFrom)
    sqlite!.exec("PRAGMA main.locking_mode=EXCLUSIVE")
    facts.receipt = migrate()
    await write(`${role}-committed.json`, { receipt: facts.receipt, observedAt: Date.now() })
    facts.committed = rawSnapshot()
    assert.equal(facts.receipt.from, facts.before.version)
    assert.equal(facts.receipt.to, 2)
    assert.equal(facts.committed.version, 2)
    assert.deepEqual({ ...facts.committed, version: 1 }, facts.original)
    if (facts.receipt.from === 1) {
      assert.equal(typeof facts.receipt.backupPath, "string")
      observeBackup(facts.receipt.backupPath)
    }
    facts.normalRelease = restoreNormal()
    assert.deepEqual(facts.normalRelease.mode, [{ locking_mode: "normal" }])
    await write(`${role}-result.json`, facts)
  } else if (role === "backup-fault" || role === "validator-fault") {
    openRaw(false)
    sqlite!.exec("PRAGMA main.locking_mode=NORMAL")
    facts.journal = read(sqlite!, "PRAGMA main.journal_mode")
    facts.original = rawSnapshot()
    assert.deepEqual(facts.journal, [{ journal_mode: "wal" }])
    assert.deepEqual(facts.original, (await seedFacts()).original)
    if (role === "backup-fault") {
      const blocker = path.join(path.dirname(databasePath), "migration-backups")
      const body = "Owned public backup-path blocker; this is a file, not a backup directory.\n"
      await fs.writeFile(blocker, body, { flag: "wx" })
      const stat = await fs.stat(blocker)
      facts.backupBarrier = { path: blocker, isFile: stat.isFile(), size: stat.size, body: await fs.readFile(blocker, "utf8") }
      assert.equal(facts.backupBarrier.isFile, true)
      assert.equal(facts.backupBarrier.body, body)
    }
    sqlite!.exec("PRAGMA main.locking_mode=EXCLUSIVE")
    let migrationError: unknown
    try { facts.unexpectedReceipt = migrate(role === "validator-fault") } catch (error) { migrationError = error }
    facts.migrationError = publicError(migrationError)
    await write("fault-migration-error.json", facts)
    assert.equal((migrationError as { code?: string })?.code, "SCHEMA_MIGRATION_FAILED")
    assert(migrationError instanceof Error && migrationError.cause instanceof Error)
    if (role === "validator-fault") {
      assert.equal(migrationError.cause.message, "OWNED_VALIDATION_REJECTED")
      assert.equal(facts.validation.version, 2)
      const backupPath = (migrationError as Error & { backupPath?: string }).backupPath
      assert.equal(typeof backupPath, "string")
      observeBackup(backupPath!)
    } else {
      const code = (migrationError.cause as Error & { code?: string }).code
      assert(code === "EEXIST" || code === "ENOTDIR", "Actual mkdir on the owned file must return its filesystem type error")
    }
    facts.rolledBack = rawSnapshot()
    assert.deepEqual(facts.rolledBack, facts.original)
    await write("fault-rolled-back.json", facts)
    await marker("fault-unlock")
    facts.normalRelease = restoreNormal()
    assert.deepEqual(facts.normalRelease.mode, [{ locking_mode: "normal" }])
    await write("fault-normal-released.json", facts.normalRelease)
    await marker("fault-close")
    facts.beforeClose = rawSnapshot()
    assert.deepEqual(facts.beforeClose, facts.original)
  } else if (role === "locked-reader") {
    let error: unknown
    try { openRaw(true); facts.unexpectedRows = read(sqlite!, "SELECT instance_id FROM database_authority") }
    catch (caught) { error = caught }
    facts.lockError = publicError(error)
    await write("locked-reader-result.json", facts)
    assert.equal((error as { code?: string })?.code, "SQLITE_BUSY")
  } else if (role === "new-reader") {
    openRaw(false)
    facts.original = rawSnapshot()
    assert.equal(facts.original.version, 2)
    const originalV1 = JSON.parse(await fs.readFile(path.join(evidence, "a-ready.json"), "utf8")).original
    assert.deepEqual({ ...facts.original, version: 1 }, originalV1)
    facts.original = originalV1 // The only comparison authority is the real initial owner's complete snapshot.
    facts.receipt = migrate()
    assert.deepEqual(facts.receipt, { from: 2, to: 2 })
    facts.current = rawSnapshot()
    assert.deepEqual({ ...facts.current, version: 1 }, originalV1)
    await write("new-reader-result.json", facts)
  }
} catch (error) {
  primary = { error }; facts.error = publicError(error); process.exitCode = 1
} finally {
  const failures: unknown[] = []
  if (sqlite) {
    try { sqlite.close(true); facts.rawClosed = true; facts.rawClosedAt = Date.now() }
    catch (error) { failures.push(error) }
  }
  if (production) {
    try {
      facts.productionHadConnectionBeforeClose = production.Database.hasOpenConnection()
      production.Database.close()
      facts.productionClosed = facts.productionCreated || facts.productionHadConnectionBeforeClose ? true : "not_started"
      facts.productionCloseCalledAt = Date.now()
      facts.productionHasConnectionAfterClose = production.Database.hasOpenConnection()
    } catch (error) { failures.push(error) }
  }
  facts.endedAt = Date.now(); facts.cleanupErrors = failures.map(publicError)
  if (failures.length) {
    facts.aggregate = publicError(new AggregateError([...(primary ? [primary.error] : []), ...failures], "Owned SQLite cleanup failed"))
    process.exitCode = 1
  }
  try { await write(`${role}-terminal.json`, facts) }
  catch (error) {
    failures.push(error)
    facts.cleanupErrors = failures.map(publicError)
    facts.aggregate = publicError(new AggregateError([...(primary ? [primary.error] : []), ...failures],
      "Owned SQLite operation and terminal evidence failed"))
    process.exitCode = 1
  }
  if (primary || failures.length) console.error(new AggregateError(
    [...(primary ? [primary.error] : []), ...failures], "Owned SQLite worker failed; preserve primary and cleanup errors",
    primary ? { cause: primary.error } : undefined))
  console.log(JSON.stringify({ role, pid: process.pid, endedAt: facts.endedAt, error: facts.error ?? null,
    rawClosed: facts.rawClosed, productionClosed: facts.productionClosed, cleanupErrors: facts.cleanupErrors }))
}
