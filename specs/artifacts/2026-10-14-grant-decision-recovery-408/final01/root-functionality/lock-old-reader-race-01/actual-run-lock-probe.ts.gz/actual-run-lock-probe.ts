import assert from "node:assert/strict"
import fs from "node:fs/promises"
import path from "node:path"
import { NodeProcess } from "../../packages/util/src/process-node"
import { expectedTestProcessSupervisor } from "../../packages/opencorvus/script/test-process-supervisor"
import { createManagedTemporaryDirectory, removeManagedDirectoryTree } from "../../packages/util/src/runtime-directories"

// Preparation only. No database is opened in this parent process.
const [scopeArgument, rawOuterDeadline, modeArgument] = process.argv.slice(2)
const mode = modeArgument ?? "lock"
assert(mode === "lock" || mode === "followup" || mode === "guarded-race", "Explicit lock, followup or guarded-race driver mode required")
const scenarios = mode === "lock" ? ["production-idle", "readonly-idle"]
  : mode === "followup" ? ["normal-candidate-race", "backup-file-failure", "validator-failure"]
  : ["guarded-candidate-race"]
const maxConcurrentChildren = mode === "guarded-race" ? 3 : 2
assert(scopeArgument && path.isAbsolute(scopeArgument), "An explicit absolute fresh scope is required")
const scope = path.resolve(scopeArgument), preparationRoot = path.resolve(import.meta.dir)
assert.equal(path.dirname(scope), preparationRoot, "The owned scope must be a direct child of this preparation directory")
const startedAt = Date.now(), deadlineAt = Number(rawOuterDeadline), closeBy = deadlineAt - 60000
assert(Number.isSafeInteger(deadlineAt) && deadlineAt > startedAt && deadlineAt <= startedAt + 600000,
  "The original physical wrapper deadline is required")
assert((await fs.stat(scope)).isDirectory())
await fs.mkdir(path.join(scope, "driver-admitted"))
const supervisor = expectedTestProcessSupervisor()
assert(supervisor, "The mature Windows owned-tree supervisor is required")
process.env.OPENCORVUS_PROCESS_SUPERVISOR = supervisor
const repository = path.resolve(import.meta.dir, "../.."), packageDirectory = path.join(repository, "packages/opencorvus")
const worker = path.join(import.meta.dir, "lock-worker.ts")
const children: any[] = [], cases: any[] = []
const environmentNames = ["SystemRoot", "SYSTEMROOT", "WINDIR", "COMSPEC", "ComSpec", "PATH", "PATHEXT", "TEMP", "TMP",
  "USERPROFILE", "HOMEDRIVE", "HOMEPATH", "APPDATA", "LOCALAPPDATA"]
const baseEnvironment = Object.fromEntries(environmentNames.flatMap(key => process.env[key] === undefined ? [] : [[key, process.env[key]!]]))
const owner: any = { mode, scenarios, startedAt, deadlineAt, closeBy, pid: process.pid, executable: process.execPath, bunVersion: Bun.version,
  scope, repository, supervisor, inheritedEnvironmentNames: Object.keys(baseEnvironment), maxConcurrentChildren,
  candidateRevision: "scratch v2 with the same current DDL and no semantic callback; no business index" }
async function write(file: string, value: unknown) {
  const pending = `${file}.${process.pid}.pending`
  await fs.writeFile(pending, JSON.stringify(value, null, 2))
  await fs.rename(pending, file)
}
function errorFacts(error: unknown): unknown {
  if (!(error instanceof Error)) return { value: String(error) }
  const value = error as Error & { code?: unknown; errno?: unknown }
  return { name: value.name, message: value.message, stack: value.stack,
    ...(value.code === undefined ? {} : { code: value.code }), ...(value.errno === undefined ? {} : { errno: value.errno }),
    ...(value.cause === undefined ? {} : { cause: errorFacts(value.cause) }),
    ...(value instanceof AggregateError ? { errors: value.errors.map(errorFacts) } : {}) }
}
function admission() { assert(Date.now() < closeBy, "Original parent close reserve reached") }
async function mark(evidence: string, name: string, value: unknown) {
  admission()
  await fs.writeFile(path.join(evidence, name), JSON.stringify(value, null, 2), { flag: "wx" })
}
async function read(evidence: string, name: string) { return JSON.parse(await fs.readFile(path.join(evidence, name), "utf8")) }
async function wait(evidence: string, name: string) {
  const waitDeadline = Math.min(Date.now() + 30000, closeBy)
  for (;;) {
    try { return await read(evidence, name) }
    catch (error) { if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error }
    if (children.some(child => child.evidence === evidence && child.endedAt && child.status !== "passed"))
      throw Error(`An owned child failed before ${name}; retain its original error and receipt`)
    if (Date.now() >= waitDeadline) throw Error(`Original parent observation deadline elapsed: ${name}`)
    await Bun.sleep(25)
  }
}
function spawn(role: string, runtime: string, evidence: string) {
  admission()
  assert(children.filter(child => child.requestStarted && !child.requestSettled).length < maxConcurrentChildren,
    `At most ${maxConcurrentChildren} owned children may be active in explicit ${mode} mode`)
  const childStartedAt = Date.now(), childDeadlineAt = Math.min(childStartedAt + 180000, closeBy)
  const args = [`--config=${path.join(packageDirectory, "test/empty-bunfig.toml")}`,
    worker, role, runtime, evidence,
    String(childDeadlineAt), String(deadlineAt)]
  const child: any = { role, runtime, evidence, executable: process.execPath, args, cwd: packageDirectory,
    startedAt: childStartedAt, deadlineAt: childDeadlineAt, parentDeadlineAt: deadlineAt,
    requestStarted: false, requestSettled: false, physicalJoined: false, outputJoined: false, status: "preparing" }
  children.push(child)
  let handle: any
  const operation = (async () => {
    let primary: { error: unknown } | undefined
    const cleanupErrors: Array<{ step: string; error: unknown }> = []
    let output: { stdout: Uint8Array; stderr: Uint8Array } | undefined
    const cleanup = async (step: string, action: () => Promise<unknown>) => {
      try { await action() } catch (error) { cleanupErrors.push({ step, error }) }
    }
    try {
      await write(path.join(evidence, `${role}-spawn.json`), child)
      child.requestStarted = true; child.status = "running"
      const result = await NodeProcess.run({ command: { executable: process.execPath, args }, cwd: packageDirectory,
          env: { ...baseEnvironment, OPENCORVUS_PROCESS_SUPERVISOR: supervisor!, OPENCORVUS_HOME: runtime,
            OPENCORVUS_TEST_HOME: path.join(runtime, "owned-home"), OPENCORVUS_TEST_PROCESS_ROOT: path.dirname(runtime) },
          ownership: "owned_tree", windowsHide: true, stdin: "ignore", deadlineAt: childDeadlineAt, nothrow: true,
          onSpawned(value) { handle = value; child.pid = value.pid; child.occurrenceID = value.occurrenceID } })
        .finally(() => { child.requestSettled = true })
      child.receipt = result.receipt
      output = { stdout: result.stdout, stderr: result.stderr }
      child.settledReceipt = await handle.settled; child.physicalJoined = true
      await handle.outputSettled; child.outputJoined = true
      assert.equal(result.receipt.reason, "exited", `Owned ${role} must end by a normal process exit`)
      assert.equal(result.receipt.exitCode, 0, `Owned ${role} must exit successfully`)
      assert.deepEqual(child.settledReceipt, result.receipt, "Returned and physically settled receipts must identify the same outcome")
    } catch (error) { primary = { error } }
    finally {
      if (handle && !child.physicalJoined) {
        await cleanup("terminate exact owned handle", async () => {
          child.emergencyOwnHandle = true
          child.terminationReceipt = await handle.terminate("aborted")
        })
        await cleanup("observe original physical settlement", async () => {
          child.settledReceipt = await handle.settled; child.physicalJoined = true
          child.receipt ??= child.settledReceipt
        })
      }
      if (handle && !child.outputJoined) await cleanup("observe original output settlement", async () => {
        await handle.outputSettled; child.outputJoined = true
      })
      if (output) {
        await cleanup("persist stdout", () => fs.writeFile(path.join(evidence, `${role}-stdout.log`), output!.stdout))
        await cleanup("persist stderr", () => fs.writeFile(path.join(evidence, `${role}-stderr.log`), output!.stderr))
      }
      const closed = child.requestStarted && child.requestSettled && child.physicalJoined && child.outputJoined
      const normal = child.receipt?.reason === "exited" && child.receipt?.exitCode === 0
      if (!closed || !normal) cleanupErrors.push({ step: "validate actual terminal receipt and closure",
        error: new Error(`Owned ${role} closure contract failed: ${JSON.stringify({ receipt: child.receipt, closed })}`) })
      child.endedAt = Date.now()
      child.primaryError = primary ? errorFacts(primary.error) : null
      child.cleanupErrors = cleanupErrors.map(({ step, error }) => ({ step, error: errorFacts(error) }))
      child.status = !primary && cleanupErrors.length === 0 ? "passed" : "failed"
      await cleanup("persist child owner", () => write(path.join(evidence, `${role}-owner.json`), child))
      child.cleanupErrors = cleanupErrors.map(({ step, error }) => ({ step, error: errorFacts(error) }))
      if (cleanupErrors.length) child.status = "failed"
    }
    if (primary || cleanupErrors.length) throw new AggregateError(
      [...(primary ? [primary.error] : []), ...cleanupErrors.map(entry => entry.error)], `Owned ${role} failed`,
      primary ? { cause: primary.error } : undefined)
    return 0
  })()
  void operation.catch(() => undefined)
  return { child, operation }
}
let primary: { error: unknown } | undefined
const finalCleanupErrors: Array<{ step: string; error: unknown }> = []
try {
  await write(path.join(scope, "driver-owner-start.json"), owner)
  for (const source of [import.meta.filename, worker,
    path.join(packageDirectory, "src/storage/schema-migration.ts"), path.join(packageDirectory, "src/storage/db.ts"),
    path.join(packageDirectory, "src/storage/sqlite-statement.ts"), path.join(packageDirectory, "src/storage/schema-contract.ts"),
    path.join(packageDirectory, "src/storage/ddl.ts"), path.join(packageDirectory, "src/storage/checkpoint-worker.ts"),
    path.join(packageDirectory, "src/storage/migrations/index.ts"), path.join(packageDirectory, "src/storage/migrations/0001-baseline.sql")])
    await fs.copyFile(source, path.join(scope, `actual-${path.basename(source)}`))
  for (const scenario of scenarios) {
    admission()
    const evidence = path.join(scope, scenario)
    await fs.mkdir(evidence)
    const ownedRoot = await createManagedTemporaryDirectory(scope, `${scenario}-`)
    const runtime = path.join(ownedRoot, "runtime")
    const entry: any = { scenario, evidence, ownedRoot, runtime, startedAt: Date.now(), runtimeRemoved: false, passed: false }
    cases.push(entry)
    const operations: Promise<unknown>[] = []
    const run = (role: string) => { const current = spawn(role, runtime, evidence); operations.push(current.operation); return current }
    let casePrimary: { error: unknown } | undefined
    const cleanupErrors: Array<{ step: string; error: unknown }> = []
    const cleanup = async (step: string, action: () => Promise<unknown>) => {
      try { await action() } catch (error) { cleanupErrors.push({ step, error }) }
    }
    try {
      await fs.mkdir(runtime)
      if (mode === "followup" || mode === "guarded-race") {
        assert.equal(await run("seed").operation, 0)
        const initial = await read(evidence, "seed-ready.json")
        assert.equal(initial.original.version, 1)
        if (scenario === "normal-candidate-race" || scenario === "guarded-candidate-race") {
          const guard = mode === "guarded-race" ? run("hold-production") : undefined
          let guardReady: any
          if (guard) {
            guardReady = await wait(evidence, "a-ready.json")
            assert.deepEqual(guardReady.original, initial.original)
            assert.deepEqual(guardReady.identity, initial.identity)
            assert.equal(guardReady.productionCreated, true)
            assert.equal(guardReady.pid, guard.child.pid)
          }
          const first = run("race-a"), second = run("race-b")
          const attachedA = await wait(evidence, "race-a-ready.json")
          const attachedB = await wait(evidence, "race-b-ready.json")
          assert.deepEqual(attachedA.original, initial.original)
          assert.deepEqual(attachedB.original, initial.original)
          await mark(evidence, "race-start", { mode, observedAt: Date.now(),
            ...(guard ? { oldProductionOwner: { role: guard.child.role, pid: guard.child.pid,
              occurrenceID: guard.child.occurrenceID, identity: guardReady.identity,
              startedAt: guard.child.startedAt, deadlineAt: guard.child.deadlineAt,
              originalVersion: guardReady.original.version, journal: guardReady.journal,
              productionCreated: guardReady.productionCreated, requestStarted: guard.child.requestStarted,
              requestSettled: guard.child.requestSettled, physicalJoined: guard.child.physicalJoined } } : {}),
            attached: [attachedA, attachedB].map(value => ({ role: value.role, pid: value.pid,
              normalMode: value.normalMode, journal: value.journal })) })
          const exits = await Promise.all([first.operation, second.operation])
          assert.deepEqual(exits, [0, 0])
          const attempts = await Promise.all([read(evidence, "race-a-attempt.json"), read(evidence, "race-b-attempt.json")])
          entry.attempts = attempts
          // Ready proves the initial state, not an invariant lock during native escalation.
          // A later current-version admission is distinct from a real version upgrade.
          const busy = attempts.filter(value => value.outcome === "busy")
          const upgraded = attempts.filter(value => value.outcome === "upgraded")
          const current = attempts.filter(value => value.outcome === "current")
          const signature = attempts.map(value => value.outcome).sort().join("+")
          entry.competition = { busy: busy.length, upgraded: upgraded.length, current: current.length, signature }
          assert.equal(busy.length + upgraded.length + current.length, 2)
          assert(upgraded.length <= 1, "Fresh v1 with only these two writers can have at most one true upgrade")
          assert(["busy+busy", "busy+upgraded", "current+upgraded"].includes(signature),
            `Actual complete race result does not match its fresh-v1 writer contract: ${signature}`)
          if (guard) {
            assert.equal(signature, "busy+busy", "An independent live old production owner must exclude both real upgrades")
            await mark(evidence, "a-close", { reason: "Both actual new candidates returned SQLITE_BUSY and normally joined" })
            assert.equal(await guard.operation, 0)
            const terminal = await read(evidence, "hold-production-terminal.json")
            assert.deepEqual(terminal.beforeClose, initial.original)
            assert.deepEqual(terminal.identity, initial.identity)
            assert.equal(terminal.productionClosed, true)
            entry.oldProductionOwner = { pid: guard.child.pid, occurrenceID: guard.child.occurrenceID,
              identity: terminal.identity, beforeCloseVersion: terminal.beforeClose.version,
              closeCalledAt: terminal.productionCloseCalledAt, receipt: guard.child.receipt,
              physicalJoined: guard.child.physicalJoined, outputJoined: guard.child.outputJoined,
              requestSettled: guard.child.requestSettled }
          }
          const expectedAfterFrom = upgraded.length === 1 ? 2 : 1
          await mark(evidence, "race-owners-joined", { mode, observedAt: Date.now(), expectedAfterFrom,
            owners: [first.child, second.child, ...(guard ? [guard.child] : [])].map(child => ({
            role: child.role, pid: child.pid, occurrenceID: child.occurrenceID, receipt: child.receipt,
            physicalJoined: child.physicalJoined, outputJoined: child.outputJoined, requestSettled: child.requestSettled })) })
          assert.equal(await run("after-race").operation, 0)
          const after = await read(evidence, "after-race-result.json")
          assert.equal(after.receipt.from, expectedAfterFrom)
          assert.equal(after.receipt.to, 2)
          assert.deepEqual({ ...after.committed, version: 1 }, initial.original)
          assert.equal(await run("followup-reader").operation, 0)
          assert.equal(await run("old-reopen").operation, 0)
        } else {
          const fault = run(scenario === "backup-file-failure" ? "backup-fault" : "validator-fault")
          const rolledBack = await wait(evidence, "fault-rolled-back.json")
          entry.migrationFailure = rolledBack.migrationError
          assert.equal(rolledBack.migrationError.code, "SCHEMA_MIGRATION_FAILED")
          assert.deepEqual(rolledBack.rolledBack, initial.original)
          assert.equal(await run("locked-reader").operation, 0)
          await mark(evidence, "fault-unlock", { reason: "Real independent reader observed retained file lock after rollback" })
          const released = await wait(evidence, "fault-normal-released.json")
          assert.deepEqual(released.mode, [{ locking_mode: "normal" }])
          assert.equal(await run("v1-reopen").operation, 0)
          const reopened = await read(evidence, "v1-reopen-result.json")
          assert.deepEqual(reopened.original, initial.original)
          assert.deepEqual(reopened.identity, initial.identity)
          await mark(evidence, "fault-close", { reason: "Actual production v1 reopened and normally joined while candidate NORMAL handle remained open" })
          assert.equal(await fault.operation, 0)
        }
      } else {
      if (scenario === "readonly-idle") assert.equal(await run("seed").operation, 0)
      const old = run(scenario === "production-idle" ? "hold-production" : "hold-readonly")
      const initial = await wait(evidence, "a-ready.json")
      assert.equal(initial.original.version, 1)
      const candidate = run("candidate")
      await wait(evidence, "b-normal-attached.json")
      const blocked = await wait(evidence, "b-blocked.json")
      assert.equal(blocked.error.code, "SQLITE_BUSY")
      await wait(evidence, "b-waiting-owner-close.json")
      await mark(evidence, "a-close", { reason: "The actual new writer observed this original admitted peer blocking file-exclusive admission" })
      assert.equal(await old.operation, 0)
      const oldTerminal = await read(evidence, `${old.child.role}-terminal.json`)
      assert.deepEqual(oldTerminal.beforeClose, initial.original)
      assert.equal(old.child.physicalJoined, true)
      await mark(evidence, "old-owner-joined", { exitCode: old.child.receipt.exitCode, physicalJoined: old.child.physicalJoined,
        outputJoined: old.child.outputJoined, requestSettled: old.child.requestSettled,
        pid: old.child.pid, occurrenceID: old.child.occurrenceID, endedAt: old.child.endedAt })
      const committed = await wait(evidence, "b-exclusive-committed.json")
      assert.deepEqual(committed.original, initial.original)
      assert.equal(committed.receipt.to, 2)
      assert.equal(await run("locked-reader").operation, 0)
      await mark(evidence, "unlock", { reason: "A separately joined real reader observed the retained file-exclusive lock" })
      const normal = await wait(evidence, "b-normal-released.json")
      assert.deepEqual(normal.mode, [{ locking_mode: "normal" }])
      assert.equal(await run("new-reader").operation, 0)
      assert.equal(await run("old-reopen").operation, 0)
      await mark(evidence, "b-close", { reason: "New read and original old-build reopening contract both observed under the same released NORMAL handle" })
      assert.equal(await candidate.operation, 0)
      }
    } catch (error) {
      casePrimary = { error }
    } finally {
      // Only the exact managed fresh runtime is removed, after its real child tree exits.
      await cleanup("request normal child closure", () => fs.writeFile(path.join(evidence, "stop"),
        "The original parent is closing this owned scope.\n"))
      const settled = await Promise.allSettled(operations)
      entry.operationResults = settled.map(result => result.status === "fulfilled"
        ? { status: result.status, value: result.value }
        : { status: result.status, reason: errorFacts(result.reason) })
      for (const [index, result] of settled.entries()) {
        if (result.status === "rejected") cleanupErrors.push({ step: `observe child operation ${index}`, error: result.reason })
        else if (result.value !== 0) cleanupErrors.push({ step: `validate child operation ${index}`,
          error: new Error(`Owned child operation returned ${String(result.value)}`) })
      }
      const actual = children.filter(child => child.evidence === evidence)
      entry.children = actual
      entry.allPhysicalJoined = actual.every(child => child.physicalJoined === true)
      entry.allOutputJoined = actual.every(child => child.outputJoined === true)
      entry.allRequestsSettled = actual.every(child => child.requestStarted && child.requestSettled)
      entry.allNormalExits = actual.every(child => child.receipt?.reason === "exited" && child.receipt.exitCode === 0)
      for (const child of actual) {
        if (!(child.physicalJoined && child.outputJoined && child.requestStarted && child.requestSettled &&
            child.receipt?.reason === "exited" && child.receipt.exitCode === 0 && child.status === "passed")) {
          cleanupErrors.push({ step: `validate ${child.role} actual closure`, error: new Error(JSON.stringify({
            role: child.role, receipt: child.receipt, status: child.status, physicalJoined: child.physicalJoined,
            outputJoined: child.outputJoined, requestStarted: child.requestStarted, requestSettled: child.requestSettled })) })
        }
      }
      if (entry.allPhysicalJoined && entry.allOutputJoined && entry.allRequestsSettled) {
        await cleanup("remove exactly closed managed root", async () => {
          await removeManagedDirectoryTree(ownedRoot)
          entry.runtimeRemoved = true
        })
      }
      entry.endedAt = Date.now()
      entry.primaryError = casePrimary ? errorFacts(casePrimary.error) : null
      entry.cleanupErrors = cleanupErrors.map(({ step, error }) => ({ step, error: errorFacts(error) }))
      entry.passed = !casePrimary && cleanupErrors.length === 0 && actual.length > 0 && entry.allNormalExits &&
        entry.allPhysicalJoined && entry.allOutputJoined && entry.allRequestsSettled && entry.runtimeRemoved
      await cleanup("persist case owner", () => write(path.join(evidence, "case-owner.json"), entry))
      entry.cleanupErrors = cleanupErrors.map(({ step, error }) => ({ step, error: errorFacts(error) }))
      if (cleanupErrors.length) entry.passed = false
    }
    if (casePrimary || cleanupErrors.length) throw new AggregateError(
      [...(casePrimary ? [casePrimary.error] : []), ...cleanupErrors.map(entry => entry.error)],
      `Owned ${scenario} case failed`, casePrimary ? { cause: casePrimary.error } : undefined)
  }
} catch (error) { primary = { error }; process.exitCode = 1 }
finally {
  owner.endedAt = Date.now(); owner.cases = cases; owner.children = children
  owner.allPhysicalJoined = children.every(child => child.physicalJoined === true)
  owner.allOutputJoined = children.every(child => child.outputJoined === true)
  owner.allRequestsSettled = children.every(child => child.requestStarted && child.requestSettled)
  owner.allNormalExits = children.every(child => child.receipt?.reason === "exited" && child.receipt.exitCode === 0)
  owner.primaryError = primary ? errorFacts(primary.error) : null
  owner.status = !primary && cases.length === scenarios.length && cases.every(entry => entry.passed === true) &&
    owner.allPhysicalJoined && owner.allOutputJoined && owner.allRequestsSettled && owner.allNormalExits ? "passed" : "failed"
  owner.cleanupErrors = []
  try { await write(path.join(scope, "driver-owner.json"), owner) }
  catch (error) { finalCleanupErrors.push({ step: "persist driver owner", error }); owner.status = "failed" }
  owner.cleanupErrors = finalCleanupErrors.map(({ step, error }) => ({ step, error: errorFacts(error) }))
  if (owner.status !== "passed") process.exitCode = 1
  // The original output owner also retains diagnostics when an evidence write itself fails.
  console.log(JSON.stringify(owner))
}
