import assert from "node:assert/strict"
import fs from "node:fs/promises"
import path from "node:path"
import { NodeProcess } from "../../packages/util/src/process-node"
import { expectedTestProcessSupervisor } from "../../packages/opencorvus/script/test-process-supervisor"
import { createManagedTemporaryDirectory, removeManagedDirectoryTree } from "../../packages/util/src/runtime-directories"

// Thin original physical owner, following the reviewed run-formal pattern.
const [scopeArgument, modeArgument] = process.argv.slice(2)
assert(scopeArgument && path.isAbsolute(scopeArgument), "Explicit absolute fresh scope required")
const mode = modeArgument ?? "lock"
assert(mode === "lock" || mode === "import" || mode === "followup" || mode === "guarded-race",
  "Mode must be lock, import, followup or guarded-race")
const scope = path.resolve(scopeArgument)
assert.equal(path.dirname(scope), path.resolve(import.meta.dir))
const startedAt = Date.now(), deadlineAt = startedAt + 600000, closeBy = deadlineAt - 60000
await fs.mkdir(scope)
const supervisor = expectedTestProcessSupervisor()
const repository = path.resolve(import.meta.dir, "../..")
const packageDirectory = path.join(repository, "packages/opencorvus")
let args: string[] = []
let childDeadlineAt = deadlineAt
let ownedImportRoot: string | undefined
let importResultPath: string | undefined
const importEnvironment: Record<string, string> = {}
const environmentNames = ["SystemRoot", "SYSTEMROOT", "WINDIR", "COMSPEC", "ComSpec", "PATH", "PATHEXT", "TEMP", "TMP",
  "USERPROFILE", "HOMEDRIVE", "HOMEPATH", "APPDATA", "LOCALAPPDATA"]
const environment = Object.fromEntries(environmentNames.flatMap(key => process.env[key] === undefined ? [] : [[key, process.env[key]!]]))
const owner: any = { mode, startedAt, deadlineAt, closeBy, parentPID: process.pid, executable: process.execPath, bunVersion: Bun.version,
  args, cwd: packageDirectory, scope, inheritedEnvironmentNames: Object.keys(environment), requestStarted: false,
  requestSettled: false, physicalJoined: false, outputJoined: false, status: "preparing" }
let handle: any
let primary: { error: unknown } | undefined
let output: { stdout: Uint8Array; stderr: Uint8Array } | undefined
const cleanupErrors: Array<{ step: string; error: unknown }> = []
function errorFacts(error: unknown): unknown {
  if (!(error instanceof Error)) return { value: String(error) }
  const value = error as Error & { code?: unknown; errno?: unknown }
  return { name: value.name, message: value.message, stack: value.stack,
    ...(value.code === undefined ? {} : { code: value.code }), ...(value.errno === undefined ? {} : { errno: value.errno }),
    ...(value.cause === undefined ? {} : { cause: errorFacts(value.cause) }),
    ...(value instanceof AggregateError ? { errors: value.errors.map(errorFacts) } : {}) }
}
const cleanup = async (step: string, action: () => Promise<unknown>) => {
  try { await action() } catch (error) { cleanupErrors.push({ step, error }) }
}
async function writeOwner(name: string) {
  const target = path.join(scope, name), pending = `${target}.${process.pid}.pending`
  await fs.writeFile(pending, JSON.stringify(owner, null, 2))
  await fs.rename(pending, target)
}
try {
  assert(supervisor, "Mature Windows native owned-tree supervisor required")
  process.env.OPENCORVUS_PROCESS_SUPERVISOR = supervisor
  await fs.copyFile(import.meta.filename, path.join(scope, "actual-launch-lock-probe.ts"))
  if (mode === "import") {
    assert(Date.now() < closeBy, "Original import setup close reserve reached")
    ownedImportRoot = await createManagedTemporaryDirectory(scope, "import-runtime-")
    owner.ownedImportRoot = ownedImportRoot
    owner.runtimeRemoved = false
    const runtime = path.join(ownedImportRoot, "runtime")
    await fs.mkdir(runtime)
    await fs.mkdir(path.join(runtime, "owned-home"))
    importResultPath = path.join(scope, "import-result.json")
    Object.assign(importEnvironment, { OPENCORVUS_HOME: runtime,
      OPENCORVUS_TEST_HOME: path.join(runtime, "owned-home"), OPENCORVUS_TEST_PROCESS_ROOT: ownedImportRoot })
    childDeadlineAt = Math.min(Date.now() + 180000, closeBy)
    args = [`--config=${path.join(packageDirectory, "test/empty-bunfig.toml")}`,
      path.join(import.meta.dir, "import-qualification.ts"), runtime, importResultPath, String(childDeadlineAt)]
    owner.runtime = runtime
    owner.importResultPath = importResultPath
    owner.boundEnvironment = importEnvironment
    await fs.copyFile(path.join(import.meta.dir, "import-qualification.ts"), path.join(scope, "actual-import-qualification.ts"))
  } else {
    args = [`--config=${path.join(packageDirectory, "test/empty-bunfig.toml")}`,
      path.join(import.meta.dir, "run-lock-probe.ts"), scope, String(deadlineAt)]
    if (mode === "followup" || mode === "guarded-race") args.push(mode)
  }
  owner.args = args
  owner.childDeadlineAt = childDeadlineAt
  await writeOwner("owner-start.json")
  assert(Date.now() < closeBy && Date.now() < childDeadlineAt, "Original parent close reserve reached before admission")
  owner.requestStarted = true; owner.status = "running"
  const result = await NodeProcess.run({ command: { executable: process.execPath, args }, cwd: packageDirectory,
    env: { ...environment, OPENCORVUS_PROCESS_SUPERVISOR: supervisor, ...importEnvironment },
    ownership: "owned_tree", windowsHide: true, stdin: "ignore", deadlineAt: childDeadlineAt, nothrow: true,
    onSpawned(value) { handle = value; owner.pid = value.pid; owner.occurrenceID = value.occurrenceID } })
    .finally(() => { owner.requestSettled = true })
  owner.receipt = result.receipt
  output = { stdout: result.stdout, stderr: result.stderr }
  owner.settledReceipt = await handle.settled; owner.physicalJoined = true
  await handle.outputSettled; owner.outputJoined = true
  assert.equal(result.receipt.reason, "exited", "The original driver must end by a normal process exit")
  assert.equal(result.receipt.exitCode, 0, "The original driver must exit successfully")
  assert.deepEqual(owner.settledReceipt, result.receipt, "Returned and physically settled receipts must match")
  if (mode === "import") {
    owner.importQualification = JSON.parse(await fs.readFile(importResultPath!, "utf8"))
    assert.equal(owner.importQualification.status, "qualified_imports_only")
    assert.equal(owner.importQualification.connectionState, "uninitialized")
    assert.equal(owner.importQualification.pid, owner.pid)
    assert.equal(owner.importQualification.deadlineAt, childDeadlineAt)
  }
} catch (error) {
  primary = { error }
} finally {
  if (handle && !owner.physicalJoined) {
    await cleanup("terminate exact owned driver", async () => {
      owner.emergencyOwnHandle = true
      owner.terminationReceipt = await handle.terminate("aborted")
    })
    await cleanup("observe original driver physical settlement", async () => {
      owner.settledReceipt = await handle.settled; owner.physicalJoined = true
      owner.receipt ??= owner.settledReceipt
    })
  }
  if (handle && !owner.outputJoined) await cleanup("observe original driver output settlement", async () => {
    await handle.outputSettled; owner.outputJoined = true
  })
  if (output) {
    await cleanup("persist driver stdout", () => fs.writeFile(path.join(scope, "stdout.log"), output!.stdout))
    await cleanup("persist driver stderr", () => fs.writeFile(path.join(scope, "stderr.log"), output!.stderr))
  }
  const closed = owner.requestStarted && owner.requestSettled && owner.physicalJoined && owner.outputJoined
  const normal = owner.receipt?.reason === "exited" && owner.receipt.exitCode === 0
  if (owner.requestStarted && (!closed || !normal)) cleanupErrors.push({ step: "validate actual driver terminal contract",
    error: new Error(JSON.stringify({ receipt: owner.receipt, closed, normal })) })
  if (ownedImportRoot) {
    if (closed) await cleanup("remove exact closed import runtime", async () => {
      await removeManagedDirectoryTree(ownedImportRoot!)
      owner.runtimeRemoved = true
    })
    else owner.runtimeRetainedReason = owner.requestStarted ? "original ownership not fully joined" : "child not admitted"
  }
  owner.endedAt = Date.now()
  owner.primaryError = primary ? errorFacts(primary.error) : null
  owner.cleanupErrors = cleanupErrors.map(({ step, error }) => ({ step, error: errorFacts(error) }))
  owner.status = !primary && cleanupErrors.length === 0 && closed && normal ? "passed" : "failed"
  await cleanup("persist outer owner", () => writeOwner("owner.json"))
  owner.cleanupErrors = cleanupErrors.map(({ step, error }) => ({ step, error: errorFacts(error) }))
  if (cleanupErrors.length) owner.status = "failed"
  process.exitCode = owner.status === "passed" ? 0 : 1
  // Preserve actual diagnostics in original output even if the evidence file failed.
  console.log(JSON.stringify(owner))
}
