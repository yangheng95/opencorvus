import type { Argv } from "yargs"
import path from "path"
import { pathToFileURL } from "bun"
import { UI } from "../ui"
import { cmd } from "./cmd"
import { Flag } from "../../flag/flag"
import { bootstrap } from "../bootstrap"
import { EOL } from "os"
import { Filesystem } from "../../util/filesystem"
import { createOpenCorvusClient, type OpenCorvusClient, type ToolPart } from "@opencorvus-ai/sdk"
import { Identifier } from "../../id/id"
import { Provider } from "../../provider/provider"
import { PrimaryAssistantRegistry } from "../../agent/primary-assistant-registry"
import { CapabilityRules } from "../../capability/rules"
import { Tool } from "../../tool/tool"
import { GlobTool } from "../../tool/glob"
import { SearchCodeTool } from "../../tool/grep"
import { ListTool } from "../../tool/ls"
import { ReadTool } from "../../tool/read"
import { WebFetchTool } from "../../tool/webfetch"
import { EditTool } from "../../tool/edit"
import { WriteTool } from "../../tool/write"
import { ExternalCodeSearchTool } from "../../tool/codesearch"
import { WebSearchTool } from "../../tool/websearch"
import { SkillTool } from "../../tool/skill"
import { BashTool } from "../../tool/bash"
import { TodoTool } from "../../tool/todo"
import { Locale } from "../../util/locale"
import { createInProcessFetch } from "@/server/in-process-client"
import { renderToolFailureCause } from "@/session/tool-failure-cause"
import { inProcessRunClientOptions, runRequest } from "./run-client"
import { runFileMime } from "./run-file"
import { durablePendingPermissionsForSession } from "@/permission/pending-projection"
import { runErrorObject, writeRunError } from "../run-error"
import { FormatError } from "../error"

type ToolProps<T extends Tool.Info> = {
  input: Tool.InferParameters<T>
  metadata: Tool.InferMetadata<T>
  part: ToolPart
}

function props<T extends Tool.Info>(part: ToolPart): ToolProps<T> {
  const state = part.state
  return {
    input: state.input as Tool.InferParameters<T>,
    metadata: ("metadata" in state ? state.metadata : {}) as Tool.InferMetadata<T>,
    part,
  }
}

type Inline = {
  icon: string
  title: string
  description?: string
}

function inline(info: Inline) {
  const suffix = info.description ? UI.Style.TEXT_DIM + ` ${info.description}` + UI.Style.TEXT_NORMAL : ""
  UI.println(UI.Style.TEXT_NORMAL + info.icon, UI.Style.TEXT_NORMAL + info.title + suffix)
}

function block(info: Inline, output?: string) {
  UI.empty()
  inline(info)
  if (!output?.trim()) return
  UI.println(output)
  UI.empty()
}

function renderToolPartDefault(part: ToolPart) {
  const state = part.state
  const input = "input" in state ? state.input : undefined
  const title =
    ("title" in state && state.title ? state.title : undefined) ||
    (input && typeof input === "object" && Object.keys(input).length > 0 ? JSON.stringify(input) : "Unknown")
  inline({
    icon: "⚙",
    title: `${part.tool} ${title}`,
  })
}

function glob(info: ToolProps<typeof GlobTool>) {
  const root = info.input.path ?? ""
  const title = `Glob "${info.input.pattern}"`
  const suffix = root ? `in ${normalizePath(root)}` : ""
  const num = info.metadata.count
  const description =
    num === undefined ? suffix : `${suffix}${suffix ? " · " : ""}${num} ${num === 1 ? "match" : "matches"}`
  inline({
    icon: "✱",
    title,
    ...(description && { description }),
  })
}

function searchCode(info: ToolProps<typeof SearchCodeTool>) {
  const root = info.input.path ?? ""
  const title = `Search Code "${info.input.pattern}"`
  const suffix = root ? `in ${normalizePath(root)}` : ""
  const num = info.metadata.matches
  const description =
    num === undefined ? suffix : `${suffix}${suffix ? " · " : ""}${num} ${num === 1 ? "match" : "matches"}`
  inline({
    icon: "✱",
    title,
    ...(description && { description }),
  })
}

function list(info: ToolProps<typeof ListTool>) {
  const dir = info.input.path ? normalizePath(info.input.path) : ""
  inline({
    icon: "→",
    title: dir ? `List ${dir}` : "List",
  })
}

function read(info: ToolProps<typeof ReadTool>) {
  const file = normalizePath(info.input.filePath)
  const pairs = Object.entries(info.input).filter(([key, value]) => {
    if (key === "filePath") return false
    return typeof value === "string" || typeof value === "number" || typeof value === "boolean"
  })
  const description = pairs.length ? `[${pairs.map(([key, value]) => `${key}=${value}`).join(", ")}]` : undefined
  inline({
    icon: "→",
    title: `Read ${file}`,
    ...(description && { description }),
  })
}

function write(info: ToolProps<typeof WriteTool>) {
  block(
    {
      icon: "←",
      title: `Write ${normalizePath(info.input.filePath)}`,
    },
    info.part.state.status === "completed" ? info.part.state.output : undefined,
  )
}

function webfetch(info: ToolProps<typeof WebFetchTool>) {
  inline({
    icon: "%",
    title: `WebFetch ${info.input.url}`,
  })
}

function edit(info: ToolProps<typeof EditTool>) {
  const title = normalizePath(info.input.filePath)
  const diff = info.metadata.diff
  block(
    {
      icon: "←",
      title: `Edit ${title}`,
    },
    diff,
  )
}

function externalCodeSearch(info: ToolProps<typeof ExternalCodeSearchTool>) {
  inline({
    icon: "◇",
    title: `External Code Search "${info.input.query}"`,
  })
}

function websearch(info: ToolProps<typeof WebSearchTool>) {
  inline({
    icon: "◈",
    title: `Exa Web Search "${info.input.query}"`,
  })
}

function skill(info: ToolProps<typeof SkillTool>) {
  const rawInput = info.part.state.input
  const input: Record<string, unknown> =
    rawInput && typeof rawInput === "object" && !Array.isArray(rawInput) ? (rawInput as Record<string, unknown>) : {}
  const name = typeof input.name === "string" && input.name.trim().length > 0 ? input.name : "unknown"
  inline({
    icon: "→",
    title: `Skill "${name}"`,
  })
}

function bash(info: ToolProps<typeof BashTool>) {
  const output = info.part.state.status === "completed" ? info.part.state.output?.trim() : undefined
  block(
    {
      icon: "$",
      title: `${info.input.command}`,
    },
    output,
  )
}

function todo(info: ToolProps<typeof TodoTool>) {
  const todos =
    info.input.action === "write"
      ? info.input.todos
      : info.part.state.status === "completed"
        ? info.metadata.todos
        : []
  block(
    {
      icon: "#",
      title: "Todos",
    },
    todos
      .map(
        (item: { status: string; content: string }) => `${item.status === "completed" ? "[x]" : "[ ]"} ${item.content}`,
      )
      .join("\n"),
  )
}

function normalizePath(input?: string) {
  if (!input) return ""
  if (path.isAbsolute(input)) return path.relative(process.cwd(), input) || "."
  return input
}

export async function resolveRunAgent(agent?: string) {
  if (!agent) return undefined
  if (!PrimaryAssistantRegistry.isID(agent)) throw new Error(`agent "${agent}" is not a primary assistant`)
  return agent
}

export const RunCommand = cmd({
  command: "run [message..]",
  describe: "run opencorvus with a message",
  builder: (yargs: Argv) => {
    return yargs
      .positional("message", {
        describe: "message to send",
        type: "string",
        array: true,
        default: [],
      })
      .option("command", {
        describe: "the command to run, use message for args",
        type: "string",
      })
      .option("continue", {
        alias: ["c"],
        describe: "continue the last session",
        type: "boolean",
      })
      .option("session", {
        alias: ["s"],
        describe: "session id to continue",
        type: "string",
      })
      .option("fork", {
        describe: "fork the session before continuing (requires --continue or --session)",
        type: "boolean",
      })
      .option("share", {
        type: "boolean",
        describe: "share the session",
      })
      .option("model", {
        type: "string",
        alias: ["m"],
        describe: "model to use in the format of provider/model",
      })
      .option("agent", {
        type: "string",
        describe: "agent to use",
      })
      .option("format", {
        type: "string",
        choices: ["default", "json"],
        default: "default",
        describe: "format: default (formatted) or json (raw JSON events)",
      })
      .option("file", {
        alias: ["f"],
        type: "string",
        array: true,
        describe: "file(s) to attach to message",
      })
      .option("title", {
        type: "string",
        describe: "title for the session (uses truncated prompt if no value provided)",
      })
      .option("attach", {
        type: "string",
        describe: "attach to a running opencorvus server (e.g., http://localhost:7878)",
      })
      .option("dir", {
        type: "string",
        describe: "directory to run in, path on remote server if attaching",
      })
      .option("port", {
        type: "number",
        describe: "port for the local server (defaults to random port if no value provided)",
      })
      .option("variant", {
        type: "string",
        describe: "model variant (provider-specific reasoning effort, e.g., high, max, minimal)",
      })
      .option("thinking", {
        type: "boolean",
        describe: "show thinking blocks",
        default: false,
      })
  },
  handler: async (args) => {
    let sessionID: string | undefined
    try {
      let message = [...args.message, ...(args["--"] || [])]
        .map((arg) => (arg.includes(" ") ? `"${arg.replace(/"/g, '\\"')}"` : arg))
        .join(" ")

      const directory = (() => {
        if (!args.dir) return undefined
        if (args.attach) return args.dir
        try {
          process.chdir(args.dir)
          return process.cwd()
        } catch {
          throw new Error("Failed to change directory to " + args.dir)
        }
      })()

      const files: { type: "file"; url: string; filename: string; mime: string }[] = []
      if (args.file) {
        const list = Array.isArray(args.file) ? args.file : [args.file]

        for (const filePath of list) {
          const resolvedPath = path.resolve(process.cwd(), filePath)
          if (!(await Filesystem.exists(resolvedPath))) {
            throw new Error(`File not found: ${filePath}`)
          }

          const mime = await runFileMime(resolvedPath)

          files.push({
            type: "file",
            url: pathToFileURL(resolvedPath).href,
            filename: path.basename(resolvedPath),
            mime,
          })
        }
      }

      if (!process.stdin.isTTY) message += "\n" + (await Bun.stdin.text())

      if (message.trim().length === 0 && !args.command) {
        throw new Error("You must provide a message or a command")
      }

      if (args.fork && !args.continue && !args.session) {
        throw new Error("--fork requires --continue or --session")
      }

      const rules: CapabilityRules.Ruleset = [
        {
          permission: "question",
          action: "deny",
          pattern: "*",
        },
      ]
      function title() {
        if (args.title === undefined) return
        if (args.title !== "") return args.title
        return message.slice(0, 50) + (message.length > 50 ? "..." : "")
      }

      async function session(sdk: OpenCorvusClient, signal?: AbortSignal) {
        const baseID = args.continue
          ? (await runRequest("session.list", sdk.session.list({}, { signal }))).find((s) => !s.parentID)?.id
          : args.session

        if (baseID && args.fork) {
          const forked = await runRequest("session.fork", sdk.session.fork({ sessionID: baseID }, { signal }))
          return forked.id
        }

        if (baseID) return baseID

        const name = title()
        const result = await runRequest(
          "session.create",
          sdk.session.create({ kind: "assistant", title: name, permission: rules }, { signal }),
        )
        return result.id
      }

      async function execute(sdk: OpenCorvusClient) {
        const eventAbort = new AbortController()
        const requestAbort = new AbortController()
        const stallMs = (() => {
          const raw = Number(process.env.OPENCORVUS_RUN_STALL_TIMEOUT_MS ?? "300000")
          if (!Number.isFinite(raw)) return 300_000
          if (raw <= 0) return 0
          return Math.floor(raw)
        })()

        function tool(part: ToolPart) {
          try {
            if (part.tool === "bash") return bash(props<typeof BashTool>(part))
            if (part.tool === "glob") return glob(props<typeof GlobTool>(part))
            if (part.tool === "search_code") return searchCode(props<typeof SearchCodeTool>(part))
            if (part.tool === "list") return list(props<typeof ListTool>(part))
            if (part.tool === "read") return read(props<typeof ReadTool>(part))
            if (part.tool === "write") return write(props<typeof WriteTool>(part))
            if (part.tool === "webfetch") return webfetch(props<typeof WebFetchTool>(part))
            if (part.tool === "edit") return edit(props<typeof EditTool>(part))
            if (part.tool === "external_code_search") {
              return externalCodeSearch(props<typeof ExternalCodeSearchTool>(part))
            }
            if (part.tool === "websearch") return websearch(props<typeof WebSearchTool>(part))
            if (part.tool === "todo") return todo(props<typeof TodoTool>(part))
            if (part.tool === "skill") return skill(props<typeof SkillTool>(part))
            return renderToolPartDefault(part)
          } catch {
            return renderToolPartDefault(part)
          }
        }

        function emit(type: string, data: Record<string, unknown>) {
          if (args.format === "json") {
            process.stdout.write(JSON.stringify({ type, timestamp: Date.now(), sessionID, ...data }) + EOL)
            return true
          }
          return false
        }

        let error: unknown
        let last = Date.now()
        const messageID = Identifier.ascending("message")
        const connected = Promise.withResolvers<void>()

        async function loop() {
          const events = await sdk.event.subscribe(
            {},
            {
              signal: eventAbort.signal,
              sseMaxRetryAttempts: 1,
              onSseError(cause) {
                if (!eventAbort.signal.aborted) throw cause
              },
            },
          )
          const toggles = new Map<string, boolean>()
          const projectedPermissions = new Set<string>()
          const permissionRequested = (permission: {
            id: string
            sessionID: string
            toolName: string
            summary: string
          }) => {
            if (permission.sessionID !== sessionID || projectedPermissions.has(permission.id)) return
            projectedPermissions.add(permission.id)
            if (
              emit("permission_requested", {
                permission: {
                  requestID: permission.id,
                  toolName: permission.toolName,
                  summary: permission.summary,
                },
              })
            ) {
              return
            }
            UI.println(
              UI.Style.TEXT_WARNING_BOLD + "!",
              UI.Style.TEXT_NORMAL +
                `permission requested: ${permission.toolName} — ${permission.summary}; waiting for operator reply`,
            )
          }
          for (const permission of await durablePendingPermissionsForSession({
            sdk,
            sessionID: sessionID!,
            directory,
            signal: eventAbort.signal,
          })) {
            permissionRequested(permission)
          }
          // Track reasoning part IDs so their deltas are not emitted as text_delta.
          const reasoningPartIDs = new Set<string>()

          for await (const event of events.stream) {
            if (event.type === "server.connected") {
              connected.resolve()
              continue
            }
            const eventSessionID =
              "sessionID" in event.properties
                ? event.properties.sessionID
                : event.type === "message.updated"
                  ? event.properties.info.sessionID
                  : event.type === "message.part.updated"
                    ? event.properties.part.sessionID
                    : undefined
            if (eventSessionID === sessionID) last = Date.now()
            if (
              event.type === "message.updated" &&
              event.properties.info.role === "assistant" &&
              event.properties.info.sessionID === sessionID &&
              args.format !== "json" &&
              toggles.get("start") !== true
            ) {
              UI.empty()
              UI.println(`> ${event.properties.info.agent} · ${event.properties.info.modelID}`)
              UI.empty()
              toggles.set("start", true)
            }

            if (event.type === "message.part.updated") {
              const part = event.properties.part
              if (part.sessionID !== sessionID) continue

              if (part.type === "file") {
                if (emit("file", { part })) continue
              }

              if (part.type === "tool" && (part.state.status === "completed" || part.state.status === "error")) {
                if (emit("tool_use", { part })) continue
                if (part.state.status === "completed") {
                  tool(part)
                  continue
                }
                inline({
                  icon: "✗",
                  title: `${part.tool} failed`,
                })
                UI.error(renderToolFailureCause((part.state as any).failure))
              }

              if (part.type === "step-start") {
                if (emit("step_start", { part })) continue
              }

              if (part.type === "step-finish") {
                if (emit("step_finish", { part })) continue
              }

              if (part.type === "text" && part.time?.end) {
                if (emit("text", { part })) continue
                const text = part.text.trim()
                if (!text) continue
                if (!process.stdout.isTTY) {
                  process.stdout.write(text + EOL)
                  continue
                }
                UI.empty()
                UI.println(text)
                UI.empty()
              }

              if (part.type === "reasoning") {
                // Track this part ID so its deltas are skipped in the text_delta handler.
                reasoningPartIDs.add(part.id)
                if (part.time?.end && args.thinking) {
                  if (emit("reasoning", { part })) continue
                  const text = part.text.trim()
                  if (!text) continue
                  const line = `Thinking: ${text}`
                  if (process.stdout.isTTY) {
                    UI.empty()
                    UI.println(`${UI.Style.TEXT_DIM}\u001b[3m${line}\u001b[0m${UI.Style.TEXT_NORMAL}`)
                    UI.empty()
                    continue
                  }
                  process.stdout.write(line + EOL)
                }
              }
            }

            if (event.type === "message.part.delta") {
              const delta = event.properties
              if (delta.sessionID !== sessionID) continue
              // Skip reasoning deltas — they should not appear as chat text output.
              if (reasoningPartIDs.has(delta.partID)) continue
              if (emit("text_delta", delta)) continue
            }

            if (
              event.type === "agent.execution.lifecycle" &&
              event.properties.sessionID === sessionID &&
              event.properties.inputMessageID === messageID &&
              (event.properties.status.type === "terminal" || event.properties.status.type === "idle")
            ) {
              const status = event.properties.status
              if (status.type === "terminal" && (status.reason === "error" || status.reason === "aborted")) {
                error ??= new Error(status.error ?? `Run ${status.reason}`)
              }
              // Cancel while the reader still owns its lock, before iterator return.
              eventAbort.abort()
              break
            }

            if (event.type === "permission.asked") {
              permissionRequested(event.properties)
            }
          }
          if (!eventAbort.signal.aborted) throw new Error("Event stream ended before the run settled")
        }

        const agent = await resolveRunAgent(args.agent)

        sessionID = await session(sdk, stallMs > 0 ? AbortSignal.timeout(stallMs) : undefined)
        if (!sessionID) {
          throw new Error("Session not found")
        }
        const probe =
          stallMs <= 0
            ? undefined
            : setInterval(
                () => {
                  if (requestAbort.signal.aborted) return
                  const age = Date.now() - last
                  if (age < stallMs) return
                  const timeout = Math.floor(stallMs / 1000)
                  const elapsed = Math.floor(age / 1000)
                  const message = `Event stream stalled for ${elapsed}s (timeout ${timeout}s)`
                  error ??= { name: "event_stream_stalled", data: { message, timeout, elapsed } }
                  connected.reject(error)
                  requestAbort.abort(error)
                  eventAbort.abort(message)
                },
                Math.min(5000, Math.max(1000, Math.floor(stallMs / 6))),
              )

        const loopTask = loop().catch((cause) => {
          error ??= cause
          connected.reject(cause)
          requestAbort.abort(cause)
          eventAbort.abort()
        })
        let sendError: unknown
        let replyError: unknown
        try {
          await connected.promise
          if (args.command) {
            try {
              const result = await runRequest(
                "session.command",
                sdk.session.command(
                  {
                    sessionID,
                    messageID,
                    agent,
                    model: args.model,
                    command: args.command,
                    arguments: message,
                    variant: args.variant,
                  },
                  { signal: requestAbort.signal },
                ),
              )
              replyError = result.info.error
            } catch (cause) {
              sendError = cause
            }
          } else {
            const model = args.model ? Provider.parseModel(args.model) : undefined
            try {
              const result = await runRequest(
                "session.prompt",
                sdk.session.prompt(
                  {
                    sessionID,
                    messageID,
                    agent,
                    model,
                    variant: args.variant,
                    parts: [...files, { type: "text", text: message }],
                  },
                  { signal: requestAbort.signal },
                ),
              )
              // The completed reply belongs to this request's exact input;
              // session.error events have no input ID and can belong to a peer.
              if (result.info.role === "assistant") replyError = result.info.error
            } catch (cause) {
              sendError = cause
            }
          }

          if (sendError) eventAbort.abort("prompt request failed")
          await loopTask
        } finally {
          if (probe) clearInterval(probe)
          eventAbort.abort()
          await loopTask
        }
        if (replyError || sendError || error) {
          throw replyError ?? (requestAbort.signal.aborted ? error : sendError) ?? error
        }
      }

      if (args.attach) {
        const sdk = createOpenCorvusClient({
          baseUrl: args.attach,
          directory,
          username: Flag.OPENCORVUS_SERVER_USERNAME,
          password: Flag.OPENCORVUS_SERVER_PASSWORD,
        })
        return await execute(sdk)
      }

      await bootstrap(process.cwd(), async () => {
        const sdk = createOpenCorvusClient(inProcessRunClientOptions(process.cwd(), createInProcessFetch()))
        await execute(sdk)
      })
    } catch (cause) {
      if (args.format === "json") writeRunError(cause, sessionID)
      else UI.error(FormatError(cause) ?? String(runErrorObject(cause).data.message ?? runErrorObject(cause).name))
      process.exitCode = 1
    }
  },
})
