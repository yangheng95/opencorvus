import { afterEach, describe, expect, test } from "bun:test"
import { Bus } from "@/bus"
import { Config } from "@/config/config"
import { PermissionAuthority } from "@/permission/authority"
import { permissionDescriptor } from "@/permission/invocation"
import {
  PermissionExecutionResultTable,
  PermissionLedgerTable,
  PermissionPolicyTable,
} from "@/permission/permission.sql"
import { Identifier } from "@/id/id"
import { Instance } from "@/project/instance"
import { Project } from "@/project/project"
import { deleteProject } from "@/project/delete"
import { Session } from "@/session"
import { EngineService } from "@/task-api"
import { SessionPromptState } from "@/session/prompt/state"
import { SessionDeletionCleanupTestHooks } from "@/session/deletion-cleanup"
import { ToolPartOutcomeTable } from "@/session/session.sql"
import { Database, and, desc, eq } from "@/storage/db"
import { EngineControlActivationLeaseGrantTable } from "@/engine/engine.sql"
import { acquireControlLease, currentControlLease } from "@/engine/control-lease"
import { observeProcessLiveness } from "@/engine/process-liveness"
import { currentRuntimeOccurrenceID } from "@/runtime/process-occurrence"
import { randomUUID } from "node:crypto"
import { mkdtemp, realpath, rm, symlink, writeFile } from "node:fs/promises"
import { tmpdir } from "node:os"
import path from "node:path"
import { memoryProject, resetMemoryDatabase } from "./fixture/memory"

afterEach(async () => {
  await Instance.disposeAll()
  await resetMemoryDatabase()
})

function invocation(sessionID: string, call: string, args: unknown = { url: "https://example.test/approved" }) {
  return {
    projectID: Instance.project.id,
    sessionID,
    messageID: `msg_${call}`,
    toolCallID: `call_${call}`,
    providerKind: "builtin" as const,
    providerID: "builtin",
    toolName: "webfetch",
    args,
  }
}

function currentEffect(attemptID: string) {
  const lease = currentControlLease("effect", attemptID)
  if (!lease) throw new Error(`Execution ${attemptID} has no effect lease`)
  const grant = Database.use((db) => db.select().from(EngineControlActivationLeaseGrantTable)
    .where(eq(EngineControlActivationLeaseGrantTable.lease_id, lease.id))
    .orderBy(desc(EngineControlActivationLeaseGrantTable.ordinal)).get())
  if (!grant) throw new Error(`Execution ${attemptID} has no lease grant`)
  return { lease, grant }
}

describe("permission execution physical owners", () => {
  test("retains a live exact effect owner through bootstrap reconciliation and result commit", async () => {
    await using project = await memoryProject()
    await Instance.provide({ directory: project.path, fn: async () => {
      const session = await Session.create({ kind: "assistant", title: "Physical permission owner" })
      const entered = Promise.withResolvers<void>(), release = Promise.withResolvers<void>()
      const execution = PermissionAuthority.authorizeAndExecute(invocation(session.id, "live-effect"), async () => {
        entered.resolve()
        await release.promise
        return { output: "Exact live effect result" }
      })
      void execution.catch(() => undefined)
      try {
        await entered.promise
        const started = (await PermissionAuthority.history()).find((row) => row.event_type === "execution_started")!
        const admitted = currentEffect(started.attempt_id!)
        expect(admitted.lease.owner_occurrence_id).toBe(currentRuntimeOccurrenceID())
        expect(observeProcessLiveness(admitted.lease.owner_occurrence_id)).toBe("exact_live")
        expect(PermissionAuthority.reconcileInterruptedAttempts()).toBe(0)
        expect((await PermissionAuthority.history()).map((row) => row.event_type)).toEqual([
          "execution_started", "allowed_once", "requested",
        ])
        release.resolve()
        expect(await execution).toEqual({ output: "Exact live effect result" })
        const settled = currentEffect(started.attempt_id!)
        expect({ id: settled.lease.id, owner: settled.lease.owner_occurrence_id, grant: settled.grant }).toEqual({
          id: admitted.lease.id, owner: admitted.lease.owner_occurrence_id, grant: admitted.grant,
        })
        expect(settled.lease.expires_at).toBeLessThan(settled.grant.expires_at)
        expect((await PermissionAuthority.history()).map((row) => row.event_type)).toEqual([
          "stale", "execution_succeeded", "execution_started", "allowed_once", "requested",
        ])
      } finally { release.resolve(); await execution.catch(() => undefined) }
    } })
  })

  test("reconciles each Project's own execution facts while a different Project has a live effect", async () => {
    await using first = await memoryProject("permission-owner-first")
    await using second = await memoryProject("permission-owner-second")
    const entered = Promise.withResolvers<void>(), release = Promise.withResolvers<void>()
    let firstProjectID = ""
    const execution = Instance.provide({ directory: first.path, fn: async () => {
      firstProjectID = Instance.project.id
      const session = await Session.create({ kind: "assistant", title: "First Project effect" })
      return PermissionAuthority.authorizeAndExecute(invocation(session.id, "first-project-effect"), async () => {
        entered.resolve(); await release.promise; return "First Project public result"
      })
    } })
    void execution.catch(() => undefined)
    try {
      await entered.promise
      await Instance.provide({ directory: second.path, fn: async () => {
        expect(PermissionAuthority.reconcileInterruptedAttempts()).toBe(0)
        const session = await Session.create({ kind: "assistant", title: "Second Project effect" })
        expect(await PermissionAuthority.authorizeAndExecute(invocation(session.id, "second-project-effect"), async () => "Second Project public result"))
          .toBe("Second Project public result")
        const history = await PermissionAuthority.history()
        expect(history.map((row) => row.event_type)).toEqual([
          "stale", "execution_succeeded", "execution_started", "allowed_once", "requested",
        ])
        expect(history.find((row) => row.event_type === "requested")?.project_id).toBe(Instance.project.id)
      } })
      release.resolve()
      expect(await execution).toBe("First Project public result")
      await Instance.provide({ directory: first.path, fn: async () => {
        const history = await PermissionAuthority.history()
        expect(history.find((row) => row.event_type === "requested")?.project_id).toBe(firstProjectID)
        expect(history.map((row) => row.event_type)).toEqual([
          "stale", "execution_succeeded", "execution_started", "allowed_once", "requested",
        ])
      } })
    } finally { release.resolve(); await execution.catch(() => undefined) }
  })

  test("resumes the same MCP protocol task after an exact live owner's explicit lease handback", async () => {
    await using project = await memoryProject()
    await Instance.provide({ directory: project.path, fn: async () => {
      const session = await Session.create({ kind: "assistant", title: "MCP explicit handback" })
      const input = { ...invocation(session.id, "mcp-handback"), providerKind: "mcp" as const,
        providerID: "public-mcp-fixture", providerDigest: "public-mcp-fixture-v1" }
      const remote = { taskId: "public-task-406", status: "working" as const, ttl: null,
        createdAt: new Date().toISOString(), lastUpdatedAt: new Date().toISOString() }
      await expect(PermissionAuthority.authorizeAndExecute(input, async () => {
        expect(PermissionAuthority.requireMcpExecutionContext()).toEqual({ recovering: false, task: undefined })
        PermissionAuthority.recordMcpTask(remote)
        throw new Error("Public MCP transport released its original task")
      })).rejects.toThrow("Public MCP transport released its original task")
      const started = (await PermissionAuthority.history()).find((row) => row.event_type === "execution_started")!
      const handedBack = currentEffect(started.attempt_id!)
      expect(handedBack.lease.owner_occurrence_id).toBe(currentRuntimeOccurrenceID())
      expect(observeProcessLiveness(handedBack.lease.owner_occurrence_id)).toBe("exact_live")
      expect(handedBack.lease.expires_at).toBeLessThan(handedBack.grant.expires_at)
      expect(await PermissionAuthority.authorizeAndExecute(input, async () => {
        expect(PermissionAuthority.requireMcpExecutionContext()).toEqual({ recovering: true, task: remote })
        return { taskId: remote.taskId, output: "Original remote task result" }
      })).toEqual({ taskId: remote.taskId, output: "Original remote task result" })
      expect((await PermissionAuthority.history()).map((row) => row.event_type)).toEqual([
        "stale", "execution_succeeded", "mcp_task_created", "execution_started", "allowed_once", "requested",
      ])
    } })
  })

  for (const owner of ["missing", "opaque"] as const) {
    test(`preserves the complete ${owner}-owner started ledger as unproven recovery evidence`, async () => {
      await using project = await memoryProject()
      await Instance.provide({ directory: project.path, fn: async () => {
        const session = await Session.create({ kind: "assistant", title: `${owner} execution evidence` })
        let request: PermissionAuthority.Request | undefined
        using hook = PermissionAuthority.TestHooks.installAfterAuthorizationBeforeExecutionStart((value) => {
          request = value
          throw new Error("Controlled pre-execution admission boundary")
        })
        await expect(PermissionAuthority.authorizeAndExecute(invocation(session.id, `${owner}-evidence`), async () => "unused"))
          .rejects.toThrow("Controlled pre-execution admission boundary")
        const attempt = Identifier.deterministic("permission", `attempt\0${request!.id}`)
        const authorized = (await PermissionAuthority.history()).find((row) => row.event_type === "allowed_once")!
        Database.immediateTransaction((db) => {
          db.insert(PermissionLedgerTable).values({ id: Identifier.ascending("permission"), request_id: request!.id,
            event_type: "execution_started", attempt_id: attempt, source_event_id: authorized.id, time_created: Date.now() }).run()
          if (owner === "opaque") acquireControlLease({ target: "effect", targetID: attempt,
            ownerOccurrenceID: "opaque-historical-effect-owner", now: Date.now(), leaseMilliseconds: 120000 })
        })
        const before = await PermissionAuthority.history()
        expect(PermissionAuthority.reconcileInterruptedAttempts()).toBe(0)
        expect(await PermissionAuthority.history()).toEqual(before)
        expect(before.map((row) => row.event_type)).toEqual(["execution_started", "allowed_once", "requested"])
      } })
    })
  }

  test("retains an actual result serialization failure and the original started evidence", async () => {
    await using project = await memoryProject()
    await Instance.provide({ directory: project.path, fn: async () => {
      const session = await Session.create({ kind: "assistant", title: "Unrepresentable effect result" })
      await expect(PermissionAuthority.authorizeAndExecute(invocation(session.id, "serialization-boundary"), async () => 1n))
        .rejects.toBeInstanceOf(TypeError)
      const before = await PermissionAuthority.history()
      const started = before.find((row) => row.event_type === "execution_started")!
      expect(currentEffect(started.attempt_id!).lease.owner_occurrence_id).toBe(currentRuntimeOccurrenceID())
      expect(PermissionAuthority.reconcileInterruptedAttempts()).toBe(0)
      expect(await PermissionAuthority.history()).toEqual(before)
      expect(before.map((row) => row.event_type)).toEqual(["execution_started", "allowed_once", "requested"])
    } })
  })
})

async function nextRequest(run: () => Promise<unknown>) {
  let resolveRequest!: (request: PermissionAuthority.Request) => void
  const asked = new Promise<PermissionAuthority.Request>((resolve) => (resolveRequest = resolve))
  const stop = Bus.subscribe(PermissionAuthority.Event.Asked, ({ properties }) => resolveRequest(properties))
  const execution = run()
  const request = await asked
  stop()
  return { request, execution }
}

describe("two-mode permission authority", () => {
  test("one-time legacy permission config migration emits the canonical Full access or Ask me choice", () => {
    expect(Config.migrateLegacyPermissionConfig({ permission: "allow" })).toEqual({
      config: {
        permission_mode: "full_access",
        permission_migration: {
          version: 1,
          source_fields: ["permission"],
          permission_mode: "full_access",
          reason: "all_allow",
        },
      },
      migration: {
        sourceFields: ["permission"],
        permissionMode: "full_access",
        reason: "all_allow",
      },
    })
    expect(
      Config.migrateLegacyPermissionConfig({
        permission: { read: "allow", bash: "ask" },
        tool_permissions: { webfetch: "deny" },
      }),
    ).toEqual({
      config: {
        permission_mode: "ask",
        permission_migration: {
          version: 1,
          source_fields: ["permission", "tool_permissions"],
          permission_mode: "ask",
          reason: "restricted_or_mixed",
        },
      },
      migration: {
        sourceFields: ["permission", "tool_permissions"],
        permissionMode: "ask",
        reason: "restricted_or_mixed",
      },
    })
    expect(() => Config.migrateLegacyPermissionConfig({ permission: { bash: "sometimes" } })).toThrow(
      "Legacy permission configuration at permission.bash is malformed",
    )
  })

  test("uses Full access when permission mode is omitted", async () => {
    expect(Config.Info.parse({}).permission_mode).toBe("full_access")
    await using project = await memoryProject()
    await Instance.provide({
      directory: project.path,
      fn: async () => {
        const session = await Session.create({ kind: "assistant", title: "Default full access authority" })
        const result = await PermissionAuthority.authorizeAndExecute(
          invocation(session.id, "default-full-access"),
          async () => "default-result",
        )
        expect(result).toBe("default-result")
        const history = await PermissionAuthority.history()
        expect(history.map((row) => row.event_type)).toEqual([
          "stale",
          "execution_succeeded",
          "execution_started",
          "allowed_once",
          "requested",
        ])
        const identities = history.flatMap((row) =>
          [row.id, row.request_id, row.attempt_id, row.source_event_id, row.decision_slot, row.outcome_slot].filter(
            (value): value is string => Boolean(value),
          ),
        )
        expect(
          identities.every((id) => id.length <= Identifier.MAX_LENGTH && Identifier.isCanonical("permission", id)),
        ).toBe(true)
        const request = history.find((row) => row.event_type === "requested")!
        expect(
          [request.policy_revision, request.provider_digest, request.fingerprint].every(
            (value) => value?.length === 64,
          ),
        ).toBe(true)
      },
    })
  })

  test("legacy configuration is captured once by the Session permission policy fact", async () => {
    await using project = await memoryProject()
    await Instance.provide({
      directory: project.path,
      fn: async () => {
        await Config.updateProjectPatch({
          permission_mode: "full_access",
          permission_migration: {
            version: 1,
            source_fields: ["permission"],
            permission_mode: "full_access",
            reason: "all_allow",
          },
        })
        const session = await Session.create({ kind: "assistant", title: "Migrated permission config" })
        await PermissionAuthority.authorizeAndExecute(invocation(session.id, "migration-first"), async () => "one")
        await PermissionAuthority.authorizeAndExecute(invocation(session.id, "migration-second"), async () => "two")
        const policies = Database.use((db) => db.select().from(PermissionPolicyTable).all())
        expect(policies).toHaveLength(1)
        expect(policies[0]).toMatchObject({
          mode: "full_access",
          session_id: session.id,
          project_id: Instance.project.id,
        })
        await Config.updateProjectPatch({ permission_mode: "ask" })
        const changed = await Session.create({ kind: "assistant", title: "Changed permission mode" })
        const pending = await nextRequest(() =>
          PermissionAuthority.authorizeAndExecute(invocation(changed.id, "migration-mode-changed"), async () => "two"),
        )
        await PermissionAuthority.reply({
          requestID: pending.request.id,
          decision: "deny",
          actorID: "test-operator",
          autoReply: false,
        })
        await expect(pending.execution).rejects.toBeInstanceOf(PermissionAuthority.RejectedError)
        expect(Database.use((db) => db.select().from(PermissionPolicyTable).all())).toHaveLength(2)
      },
    })
  })

  test("Ask me records an exact project grant, reuses it, and asks again for changed arguments", async () => {
    await using project = await memoryProject()
    await Instance.provide({
      directory: project.path,
      fn: async () => {
        await Config.updateProjectPatch({ permission_mode: "ask" })
        const session = await Session.create({ kind: "assistant", title: "Ask authority" })
        const first = await nextRequest(() =>
          PermissionAuthority.authorizeAndExecute(invocation(session.id, "first"), async () => "first-result"),
        )
        expect(first.request).toMatchObject({
          mode: "ask",
          toolName: "webfetch",
          effectClass: "network_read",
          choices: ["allow_once", "allow_project", "deny"],
        })
        const resolved = await PermissionAuthority.reply({
          requestID: first.request.id,
          decision: "allow_project",
          actorID: "test-operator",
          autoReply: false,
        })
        expect(resolved).toMatchObject({ decision: "allow_project", request: { id: first.request.id } })
        expect(await first.execution).toBe("first-result")

        expect(
          await PermissionAuthority.authorizeAndExecute(invocation(session.id, "second"), async () => "grant-result"),
        ).toBe("grant-result")

        const reused = (await PermissionAuthority.history()).find((row) => row.event_type === "grant_used")!
        expect({ slot: reused.decision_slot, request: reused.request_id, actor: reused.actor_id }).toEqual({
          slot: reused.request_id, request: reused.request_id, actor: "saved-grant-policy",
        })
        expect(await PermissionAuthority.list()).toEqual([])

        const changed = await nextRequest(() =>
          PermissionAuthority.authorizeAndExecute(
            invocation(session.id, "changed", { url: "https://example.test/changed" }),
            async () => "changed-result",
          ),
        )
        await PermissionAuthority.reply({
          requestID: changed.request.id,
          decision: "deny",
          actorID: "test-operator",
          autoReply: false,
        })
        await expect(changed.execution).rejects.toBeInstanceOf(PermissionAuthority.RejectedError)

        expect((await PermissionAuthority.grants()).map((row) => row.decision_scope)).toEqual(["project"])
        expect((await PermissionAuthority.history()).map((row) => row.event_type)).toEqual([
          "denied",
          "requested",
          "execution_succeeded",
          "execution_started",
          "grant_used",
          "requested",
          "execution_succeeded",
          "execution_started",
          "grant_created",
          "requested",
        ])
      },
    })
  })

  test("Project deletion terminals reusable grants before a same-path Project occurrence asks again", async () => {
    await using project = await memoryProject()
    const original = await Project.fromDirectory(project.path)
    let grantID = ""
    await Instance.provide({
      directory: project.path,
      fn: async () => {
        await Config.updateProjectPatch({ permission_mode: "ask" })
        const session = await Session.create({ kind: "assistant", title: "Project grant before deletion" })
        const first = await nextRequest(() =>
          PermissionAuthority.authorizeAndExecute(invocation(session.id, "before-project-delete"), async () => "ran"),
        )
        await PermissionAuthority.reply({
          requestID: first.request.id,
          decision: "allow_project",
          actorID: "project-owner",
          autoReply: false,
        })
        await expect(first.execution).resolves.toBe("ran")
        grantID = (await PermissionAuthority.grants())[0]!.id
      },
    })

    await deleteProject(original.project, {
      actor: "user",
      source: "project.delete",
      surface: "api",
      requestID: "permission_project_generation_boundary",
      reason: "Delete the Project occurrence that owns a reusable permission grant",
    })
    const expired = Database.use((db) =>
      db
        .select()
        .from(PermissionLedgerTable)
        .where(and(eq(PermissionLedgerTable.event_type, "expired"), eq(PermissionLedgerTable.source_event_id, grantID)))
        .get(),
    )
    const recreated = await Project.fromDirectory(project.path)
    expect({
      expired: expired && { actor: expired.actor_id, source: expired.source_event_id },
      projectID: recreated.project.id,
    }).toEqual({
      expired: { actor: "project-deletion", source: grantID },
      projectID: original.project.id,
    })

    await Instance.provide({
      directory: project.path,
      fn: async () => {
        await Config.updateProjectPatch({ permission_mode: "ask" })
        const session = await Session.create({ kind: "assistant", title: "Project grant after recreation" })
        let resolveAsked!: (request: PermissionAuthority.Request) => void
        const asked = new Promise<PermissionAuthority.Request>((resolve) => (resolveAsked = resolve))
        const stop = Bus.subscribe(PermissionAuthority.Event.Asked, ({ properties }) => resolveAsked(properties))
        const execution = PermissionAuthority.authorizeAndExecute(
          invocation(session.id, "after-project-delete"),
          async () => "must-wait-for-new-owner",
        )
        const outcome = await Promise.race([
          asked.then((request) => ({ kind: "asked" as const, request })),
          execution.then((value) => ({ kind: "executed" as const, value })),
        ])
        stop()
        expect(outcome).toMatchObject({ kind: "asked", request: { projectID: original.project.id } })
        if (outcome.kind !== "asked") throw new Error("Recreated Project reused a deleted occurrence's grant")
        await PermissionAuthority.reply({
          requestID: outcome.request.id,
          decision: "deny",
          actorID: "new-project-owner",
          autoReply: false,
        })
        await expect(execution).rejects.toBeInstanceOf(PermissionAuthority.RejectedError)
      },
    })
  })

  test("Full access executes built-in and MCP calls while retaining auditable outcomes", async () => {
    await using project = await memoryProject()
    await Instance.provide({
      directory: project.path,
      fn: async () => {
        await Config.updateProjectPatch({ permission_mode: "full_access" })
        const session = await Session.create({ kind: "assistant", title: "Full authority" })
        expect(await PermissionAuthority.authorizeAndExecute(invocation(session.id, "builtin"), async () => 1)).toBe(1)
        expect(
          await PermissionAuthority.authorizeAndExecute(
            {
              ...invocation(session.id, "mcp", { query: "current docs" }),
              providerKind: "mcp",
              providerID: "controlled-local-mcp",
              providerDigest: "controlled-local-mcp-v1",
              toolName: "lookup",
            },
            async () => 2,
          ),
        ).toBe(2)
        expect((await PermissionAuthority.history()).map((row) => row.event_type).sort()).toEqual(
          [
            "stale",
            "execution_succeeded",
            "execution_started",
            "allowed_once",
            "requested",
            "stale",
            "execution_succeeded",
            "execution_started",
            "allowed_once",
            "requested",
          ].sort(),
        )
      },
    })
  })

  test("an event consumer can decide during publication without losing the authorization wake", async () => {
    await using project = await memoryProject()
    await Instance.provide({
      directory: project.path,
      fn: async () => {
        await Config.updateProjectPatch({ permission_mode: "ask" })
        const session = await Session.create({ kind: "assistant", title: "Synchronous permission reply" })
        const stop = Bus.subscribe(PermissionAuthority.Event.Asked, ({ properties }) =>
          PermissionAuthority.reply({
            requestID: properties.id,
            decision: "allow_once",
            actorID: "synchronous-test-operator",
            autoReply: false,
          }).then(() => undefined),
        )
        try {
          await expect(
            PermissionAuthority.authorizeAndExecute(invocation(session.id, "synchronous"), async () => "executed"),
          ).resolves.toBe("executed")
        } finally {
          stop()
        }
      },
    })
  })

  test("project-scoped permission authority resolves exact owned facts when unowned historical residue exists", async () => {
    await using project = await memoryProject()
    await Instance.provide({
      directory: project.path,
      fn: async () => {
        await Config.updateProjectPatch({ permission_mode: "ask" })
        const orphanRequestID = Identifier.ascending("permission")
        Database.transaction((db) =>
          db
            .insert(PermissionLedgerTable)
            .values({
              id: Identifier.ascending("permission"),
              request_id: orphanRequestID,
              event_type: "grant_created",
              decision_scope: "project",
              decision_slot: orphanRequestID,
              actor_id: "historical-owner",
              time_created: Date.now(),
            })
            .run(),
        )
        const session = await Session.create({ kind: "assistant", title: "Owned permission history" })
        let ownedRequestID = ""
        const stop = Bus.subscribe(PermissionAuthority.Event.Asked, ({ properties }) => {
          ownedRequestID = properties.id
          return PermissionAuthority.reply({
            requestID: properties.id,
            decision: "allow_once",
            actorID: "current-project-operator",
            autoReply: false,
          }).then(() => undefined)
        })
        let result: string
        try {
          result = await PermissionAuthority.authorizeAndExecute(
            invocation(session.id, "owned-with-orphan"),
            async () => "owned-result",
          )
        } finally {
          stop()
        }
        const history = await PermissionAuthority.history()
        expect({
          result,
          requests: [...new Set(history.map((row) => row.request_id))],
          events: history.map((row) => row.event_type).sort(),
        }).toEqual({
          result: "owned-result",
          requests: [ownedRequestID],
          events: ["allowed_once", "execution_started", "execution_succeeded", "requested"].sort(),
        })
      },
    })
  })

  test("reply and stale settlement converge on one durable typed decision", async () => {
    await using project = await memoryProject()
    await Instance.provide({
      directory: project.path,
      fn: async () => {
        await Config.updateProjectPatch({ permission_mode: "ask" })
        const session = await Session.create({ kind: "assistant", title: "Concurrent permission settlement" })
        const pending = await nextRequest(() =>
          PermissionAuthority.authorizeAndExecute(invocation(session.id, "concurrent-settlement"), async () => "ran"),
        )
        const [reply, stale] = await Promise.all([
          PermissionAuthority.reply({
            requestID: pending.request.id,
            decision: "allow_once",
            actorID: "concurrent-operator",
            autoReply: false,
          }),
          PermissionAuthority.settleStale(pending.request.id, "concurrent input invalidation"),
        ])
        expect(reply.eventID).toBe(stale.eventID)
        expect(reply.decision).toBe(stale.decision)
        const decisions = (await PermissionAuthority.history()).filter(
          (row) => row.decision_slot === pending.request.id,
        )
        expect(decisions).toHaveLength(1)
        if (reply.decision === "deny")
          await expect(pending.execution).rejects.toBeInstanceOf(PermissionAuthority.RejectedError)
        else await expect(pending.execution).resolves.toBe("ran")
      },
    })
  })

  test("Session deletion cancels a pending request and retains its authorization history", async () => {
    await using project = await memoryProject()
    await Instance.provide({
      directory: project.path,
      fn: async () => {
        await Config.updateProjectPatch({ permission_mode: "ask" })
        const session = await Session.create({ kind: "assistant", title: "Cancelled permission owner" })
        const pending = await nextRequest(() =>
          PermissionAuthority.authorizeAndExecute(invocation(session.id, "cancelled"), async () => "must-not-run"),
        )
        const rejected = pending.execution.catch((error) => error)
        await EngineService.deleteSession(session.id, { projectID: session.projectID })
        expect(await rejected).toBeInstanceOf(PermissionAuthority.RejectedError)
        expect((await PermissionAuthority.history()).map((row) => row.event_type)).toEqual(["cancelled", "requested"])
      },
    })
  })

  test("Session deletion fences a Permission admitted after real Prompt cancellation and settles its waiter", async () => {
    await using project = await memoryProject()
    await Instance.provide({
      directory: project.path,
      fn: async () => {
        await Config.updateProjectPatch({ permission_mode: "ask" })
        const session = await Session.create({ kind: "assistant", title: "Permission deletion admission race" })
        const owner = SessionPromptState.start(session.id, session.directory)
        if (!owner) throw new Error("Expected the real Session Prompt owner")
        let executed = false
        let permissionDisposition: Promise<unknown> | undefined
        let hookRuns = 0
        await using hook = SessionDeletionCleanupTestHooks.installBeforeManifestCreate(async (rootSessionID) => {
          if (rootSessionID !== session.id || hookRuns++ > 0) return
          const asked = nextRequest(() =>
            PermissionAuthority.authorizeAndExecute(invocation(session.id, "delete-race"), async () => {
              executed = true
              return "must-not-run"
            }),
          )
          const pending = await asked
          permissionDisposition = pending.execution
            .catch((error) => error)
            .finally(() => SessionPromptState.finish(session.id, owner, session.directory))
        })

        const deletion = await EngineService.deleteSession(session.id, { projectID: session.projectID })
        const settled = await permissionDisposition
        expect({
          deletion,
          permissionRejected: settled instanceof PermissionAuthority.RejectedError,
          history: (await PermissionAuthority.history()).map((row) => row.event_type),
          executed,
        }).toEqual({
          deletion: {
            ok: true,
            status: "physically_deleted",
            sessionID: session.id,
            sessionHistoryRetained: false,
            authorizationAuditRetained: true,
            cleanupOperationID: expect.any(String),
            residue: [],
          },
          permissionRejected: true,
          history: ["cancelled", "requested"],
          executed: false,
        })
      },
    })
  })

  test("scope fingerprints redact secrets and bind exact provider and arguments", async () => {
    await using project = await memoryProject()
    await Instance.provide({
      directory: project.path,
      fn: async () => {
        const first = (await permissionDescriptor({
          providerKind: "mcp",
          providerID: "fixture",
          providerDigest: "fixture-v1",
          toolName: "send",
          args: { token: "secret-value", destination: "alpha" },
        }))!
        const second = (await permissionDescriptor({
          providerKind: "mcp",
          providerID: "fixture",
          providerDigest: "fixture-v1",
          toolName: "send",
          args: { token: "secret-value", destination: "beta" },
        }))!
        expect((first.scope.resource as Record<string, unknown>).arguments).toEqual({
          token: "<redacted>",
          destination: "alpha",
        })
        expect(new Set([first.fingerprint, second.fingerprint]).size).toBe(2)
        expect(
          (await permissionDescriptor({
            providerKind: "mcp",
            providerID: "fixture",
            providerDigest: "fixture-v1",
            toolName: "send",
            args: {
              callbackUrl: "https://example.test/callback?code=secret-code&state=secret-state#fragment",
              accessTokenValue: "secret-value",
            },
          }))!.scope.resource,
        ).toEqual({
          scope_type: "provider",
          operation: "send",
          arguments: {
            callbackUrl: "https://example.test/callback?<redacted>#<redacted>",
            accessTokenValue: "<redacted>",
          },
          arguments_sha256: expect.any(String),
        })
        expect(
          (await permissionDescriptor({
            providerKind: "builtin",
            providerID: "builtin",
            toolName: "bash",
            args: { command: "echo safe" },
          }))!.projectGrantEligible,
        ).toBe(false)
        expect(
          (await permissionDescriptor({
            providerKind: "builtin",
            providerID: "builtin",
            toolName: "webfetch",
            args: { url: "https://EXAMPLE.test:443/docs?token=secret#private" },
          }))!.scope.resource,
        ).toEqual({
          scope_type: "network",
          operation: "webfetch",
          endpoint: {
            scheme: "https",
            hostname: "example.test",
            port: "443",
            pathname: "/docs",
            query_sha256: expect.any(String),
            fragment_present: true,
          },
          request_sha256: expect.any(String),
        })
        const structuredShell = (await permissionDescriptor({
          providerKind: "builtin",
          providerID: "builtin",
          toolName: "bash",
          args: {
            command: "TOKEN=secret env curl https://example.test/path?secret=value | tee output.txt > audit.log",
            workdir: project.path,
            background: true,
          },
        }))!
        expect(structuredShell.scope.resource).toMatchObject({
          scope_type: "shell",
          ast_sha256: expect.any(String),
          commands: [
            { executable: "curl", argument_sha256: expect.any(String) },
            { executable: "tee", argument_sha256: expect.any(String) },
          ],
          environment_names: ["TOKEN"],
          pipeline_count: 1,
          redirects: [{ operator_sha256: expect.any(String), target_sha256: expect.any(String) }],
          endpoints: ["https://example.test:443/path"],
          background: true,
        })
        const equivalentShell = (await permissionDescriptor({
          providerKind: "builtin",
          providerID: "builtin",
          toolName: "bash",
          args: {
            command:
              "TOKEN=secret   env curl https://example.test/path?secret=value | tee output.txt > audit.log # display-only spacing/comment",
            workdir: project.path,
            background: true,
          },
        }))!
        const changedShell = (await permissionDescriptor({
          providerKind: "builtin",
          providerID: "builtin",
          toolName: "bash",
          args: {
            command: "TOKEN=secret env curl https://other.example/path | tee output.txt > audit.log",
            workdir: project.path,
            background: true,
          },
        }))!
        expect(equivalentShell.fingerprint).toBe(structuredShell.fingerprint)
        expect(new Set([changedShell.fingerprint, structuredShell.fingerprint]).size).toBe(2)
        expect(
          (await permissionDescriptor({
            providerKind: "builtin",
            providerID: "builtin",
            toolName: "schedule",
            args: { action: "create", scope: "project", projectIds: ["beta", "alpha"], recurrence: "RRULE:FREQ=DAILY" },
          }))!.scope.resource,
        ).toMatchObject({
          scope_type: "schedule",
          action: "create",
          target_scope: "project",
          project_ids: ["alpha", "beta"],
          recurrence_sha256: expect.any(String),
        })
        await expect(
          permissionDescriptor({
            providerKind: "mcp",
            providerID: "unbound",
            toolName: "send",
            args: {},
          }),
        ).rejects.toThrow("Permission provider binding is required")
      },
    })
  })

  test("a project symlink read is authorized against its canonical external target", async () => {
    await using project = await memoryProject()
    const external = await mkdtemp(path.join(tmpdir(), "opencorvus-permission-external-"))
    try {
      const target = path.join(external, "controlled.txt")
      const linked = path.join(project.path, "linked-external")
      await writeFile(target, "controlled")
      await symlink(external, linked, process.platform === "win32" ? "junction" : "dir")
      const canonicalProject = await realpath(project.path)
      const canonicalTarget = await realpath(target)
      await Instance.provide({
        directory: project.path,
        fn: async () => {
          const descriptor = (await permissionDescriptor({
            providerKind: "builtin",
            providerID: "builtin",
            toolName: "read",
            args: { filePath: path.join(linked, "controlled.txt") },
          }))!
          expect(descriptor).toMatchObject({
            effectClass: "read_local",
            projectGrantEligible: true,
            scope: {
              resource: {
                scope_type: "filesystem",
                paths: [canonicalTarget],
                working_directory: canonicalProject,
              },
            },
          })
        },
      })
    } finally {
      await rm(external, { recursive: true, force: true })
    }
  })

  test("grant expiry and stale settlement produce durable typed lifecycles", async () => {
    await using project = await memoryProject()
    await Instance.provide({
      directory: project.path,
      fn: async () => {
        await Config.updateProjectPatch({ permission_mode: "ask" })
        const session = await Session.create({ kind: "assistant", title: "Permission lifecycle" })
        const grantRun = await nextRequest(() =>
          PermissionAuthority.authorizeAndExecute(invocation(session.id, "grant-expiry"), async () => "granted"),
        )
        await PermissionAuthority.reply({
          requestID: grantRun.request.id,
          decision: "allow_project",
          actorID: "test-operator",
          autoReply: false,
        })
        await expect(grantRun.execution).resolves.toBe("granted")
        const [grant] = await PermissionAuthority.grants()
        await PermissionAuthority.expire(grant.id, "operator-set expiry elapsed", "expiry-service")
        expect(await PermissionAuthority.grants()).toEqual([])

        const staleRun = await nextRequest(() =>
          PermissionAuthority.authorizeAndExecute(
            invocation(session.id, "stale", { url: "https://example.test/stale" }),
            async () => "must-not-run",
          ),
        )
        await PermissionAuthority.settleStale(staleRun.request.id, "Tool input changed before execution")
        await expect(staleRun.execution).rejects.toBeInstanceOf(PermissionAuthority.RejectedError)
        expect((await PermissionAuthority.history()).map((row) => row.event_type)).toContain("expired")
        expect((await PermissionAuthority.history()).map((row) => row.event_type)).toContain("stale")
      },
    })
  })

  test("an unknown execution outcome is explicitly reconciled without rewriting its history", async () => {
    await using project = await memoryProject()
    await Instance.provide({
      directory: project.path,
      fn: async () => {
        const session = await Session.create({ kind: "assistant", title: "Permission reconciliation" })
        await expect(PermissionAuthority.authorizeAndExecute(invocation(session.id, "reconcile-source"), async () => 1n))
          .rejects.toBeInstanceOf(TypeError)
        const source = (await PermissionAuthority.history()).find((row) => row.event_type === "execution_started")!
        const attemptID = source.attempt_id!
        Database.transaction((db) =>
          db
            .insert(PermissionLedgerTable)
            .values({
              ...source,
              id: Identifier.ascending("permission"),
              attempt_id: attemptID,
              event_type: "outcome_unknown",
              outcome_slot: attemptID,
              source_event_id: source.id,
              reason: "fixture interrupted outcome",
              metadata: null,
              time_created: Date.now(),
            })
            .run(),
        )
        const reconciled = await PermissionAuthority.reconcileExecution({
          attemptID,
          outcome: "execution_succeeded",
          actorID: "test-operator",
          reason: "verified controlled provider receipt",
        })
        expect(reconciled).toMatchObject({
          event_type: "execution_reconciled",
          attempt_id: attemptID,
          actor_id: "test-operator",
          metadata: { outcome: "execution_succeeded" },
        })
        expect((await PermissionAuthority.history()).map((row) => row.event_type)).toContain("outcome_unknown")
      },
    })
  })

  test("a completed execution replays the original Session-owned result and outcome identity", async () => {
    await using project = await memoryProject()
    await Instance.provide({
      directory: project.path,
      fn: async () => {
        const session = await Session.create({ kind: "assistant", title: "Permission result replay" })
        const input = invocation(session.id, "result-replay")
        let effects = 0
        const first = await PermissionAuthority.authorizeAndExecute(input, async () => { effects++; return { output: "durable result" } })
        const replay = await PermissionAuthority.authorizeAndExecute(input, async () => {
          effects += 1
          return { output: "duplicate" }
        })
        const outcome = (await PermissionAuthority.history()).find((row) => row.event_type === "execution_succeeded")!
        const stored = Database.use((db) => db.select().from(PermissionExecutionResultTable).get())!
        expect({ first, replay, effects, metadata: outcome.metadata, stored }).toEqual({
          first: { output: "durable result" },
          replay: { output: "durable result" },
          effects: 1,
          metadata: null,
          stored: {
            attempt_id: expect.any(String),
            result: { kind: "json", value: { output: "durable result" } },
            time_created: expect.any(Number),
          },
        })
        expect({ event: outcome.event_type, attempt: outcome.outcome_slot })
          .toEqual({ event: "execution_succeeded", attempt: stored.attempt_id })
      },
    })
  })

  test("projects a structured Permission result through the canonical Tool output boundary", async () => {
    await using project = await memoryProject()
    await Instance.provide({
      directory: project.path,
      fn: async () => {
        const now = Date.now()
        const session = await Session.create({ kind: "assistant", title: "Structured Permission Tool result" })
        const user = await Session.updateMessage({
          id: Identifier.ascending("message"),
          sessionID: session.id,
          role: "user",
          author: "user",
          time: { created: now },
          agent: "build",
          model: { providerID: "test", modelID: "permission-result" },
        })
        const assistant = await Session.updateMessage({
          id: Identifier.ascending("message"),
          sessionID: session.id,
          role: "assistant",
          author: "build",
          parentID: user.id,
          time: { created: now + 1 },
          agent: "build",
          providerID: "test",
          modelID: "permission-result",
          path: { cwd: project.path, root: project.path },
          cost: 0,
          tokens: { input: 0, output: 0, reasoning: 0, total: 0, cache: { read: 0, write: 0 } },
        })
        const callID = "structured-permission-result"
        const partID = Identifier.ascending("part")
        const running = await Session.updatePart({
          id: partID,
          sessionID: session.id,
          messageID: assistant.id,
          type: "tool",
          callID,
          tool: "dispatch_agent",
          state: {
            status: "running",
            input: { target: "request-interpreter" },
            time: { start: now + 2 },
          },
        })
        const result = { kind: "accepted", session_id: "ses_structured", dispatch_lineage_id: "art_structured" }
        await PermissionAuthority.authorizeAndExecute(
          {
            projectID: Instance.project.id,
            sessionID: session.id,
            messageID: assistant.id,
            toolCallID: callID,
            toolPartID: partID,
            providerKind: "projected",
            providerID: "dispatch_agent",
            providerDigest: "projection:dispatch-agent",
            toolName: "dispatch_agent",
            args: running.state.input,
          },
          async () => result,
        )
        const completed = await Session.updatePart({
          ...running,
          state: {
            status: "completed",
            input: running.state.input,
            output: JSON.stringify(result),
            title: "Accepted dispatch",
            metadata: {},
            time: { start: now + 2, end: now + 3 },
          },
        })
        const receipt = Database.use((db) =>
          db.select().from(ToolPartOutcomeTable).where(eq(ToolPartOutcomeTable.request_part_id, partID)).get(),
        )!
        expect({ completed, receipt }).toMatchObject({
          completed: {
            state: {
              status: "completed",
              output: JSON.stringify(result),
              title: "Accepted dispatch",
            },
          },
          receipt: {
            request_part_id: partID,
            data: {
              outcome: "completed",
              resultAttemptID: expect.stringMatching(/^per_/),
              title: "Accepted dispatch",
            },
          },
        })
      },
    })
  })
})
