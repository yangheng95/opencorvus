# 408 backend frozen handoff

All implementation is within Root's approved backend and later four-adapter scopes. No Git writes, shared spec/index/README/CHANGELOG edits, real credentials/models, UI automation or subdelegation were performed. Root owns schema-migration.ts and its physical tests, desktop/old-producer acceptance and final module checker/commit/push.

## Exact code scope

`paths.json` is the exact 24-path allowlist: 16 production paths and 8 backend test paths. All current files are copied here with `/` encoded as `__`; `implementation.patch` contains tracked changes only, so the new leaf, two revision2 files and two new test files are supplied as their complete source copies as well. `head.txt` and `status.txt` preserve the observed shared-worktree state; unrelated changes were not restored or included in this scope.

Production: permission/ledger-facts.ts; permission/authority.ts; permission/permission.sql.ts; permission/invocation.ts; session/tool-outcome-facts.ts; storage/db.ts; storage/migrations/index.ts; storage/migrations/0002-grant-decision-index.ts and .sql; engine/store.ts; engine/interaction.ts; protocol/session-mirror.ts; acp/agent.ts; cli/cmd/run.ts; channel/ingress.ts (all under packages/opencorvus/src), plus packages/channel-runtime/src/core.ts.

Tests: opencorvus/test/permission-two-mode.test.ts; permission-ledger-facts.test.ts; permission-ledger-migration.test.ts; permission-execution-owner-process.test.ts; server/task-board-validator.test.ts; acp-prompt-terminal.test.ts; cli/run-transport.test.ts; channel-runtime/test/subscribe-events-global.test.ts. Root's five controlled-input files and the physical-migration checker/worker were untouched.

`../baseline` preserves the original existing production sources and each touched test's preimage. The original empty scoped `git diff` command was piped to PowerShell Set-Content; an empty pipeline did not create the intended production-before.patch. This missing empty file is disclosed rather than retroactively fabricated. Exact original sources, HEAD and status are present. Adapter-before.patch was explicitly written with an empty-string-safe write and is present. No digest is used as a functional acceptance gate.

## Implementation

The low-level leaf owns the unchanged request/attempt formulas, pure project-grant eligibility, complete Request mapping, current/historical graph rules, and typed private errors. Per-request Client/Tx reads run in one read transaction/savepoint and explicitly qualify each referenced source-grant request graph using the same internal validator; startup/migration bulk validation executes inside the existing physical transaction. It does not import Database as a runtime value or introduce a cache, fallback or per-request whole-table scan.

Current saved-grant capture owns the real decision slot, original source grant and saved-grant-policy actor. Eligible-grant read, slot-targeted CAS, winner-owned Replied outbox and revocation/expiry writes use the original immediate transaction primitives. Only the targeted decision-slot conflict can return its actual winner; trigger/PK/other SQL errors propagate. Historical revision2 validates the entire original graph before appending actual-time private grant_decision_indexed facts, retaining original U/owner/scope/attempt/result bytes. Original U, not I, supplies decision time and execution authority. The immutable 0001 file is untouched; 0002 DDL was compared directly with current SCHEMA_DDL and was identical (326159 characters) before use.

Engine and Session projections use the canonical facts. Late Asked cannot recreate a pending Session permission after its decision. Task projection is invalidated from actual Asked materialization and actual Replied delivery; the two causal notifications in the reply-first case were audited across all subscribers and proven to reference the same canonical terminal. There is no notification shadow state or extra domain outcome. See ../../interaction-resolved-audit.md and its caller capture.

ACP rechecks current pending at queue head and preserves retry hydration after transport/API errors. CLI and Channel recheck immediately before pending emission. Channel ingress reports the actual returned winning decision/status. CLI's explicit `permission reply` command already used its returned Resolution and was not changed. See ../../external-permission-consumers-review.md.

## Final distinct positive qualification: 103 tests / 540 expectations

Every formal stage uses `functionality/run-formal.ts`, Bun1.4 and a fresh original 600000ms owned-tree scope. Full actual command arrays, PID/occurrence/deadline, normal exit and physical/output/request joins are in `formal-receipts.json` and each original owner file. Repeated runs below are not accumulated.

| Exact test file | Final stage | Tests / expects |
| --- | --- | --- |
| permission-two-mode | two-mode-final03 | 23 / 90 |
| permission-ledger-facts | error-contract04 | 3 / 18 |
| permission-ledger-migration | explicit-choices06 | 10 / 39 |
| permission-transport-hydration | projections01 | 1 / 4 |
| server/session-permission-projection | projections01 | 8 / 39 |
| engine-interaction-recovery | projections01 | 8 / 75 |
| server/task-board-validator | adapters02 | 7 / 35 |
| session/permission-message-settlement | retirement01 | 10 / 23 |
| session/permission-message-retirement | retirement01 | 10 / 107 |
| permission-continuation-recovery | retirement01 | 8 / 22 |
| permission-execution-owner-process | process02 | 4 / 58 |
| acp-prompt-terminal, exact `ACP Permission queue` pattern | acp-queue01 | 1 / 4 |
| cli/run-transport | adapters02 | 8 / 21 |
| channel-runtime/subscribe-events-global | channel-projection01 | 2 / 5 |

Core typecheck (`bun run --cwd packages/opencorvus typecheck`) types01/02/03 each exited0. Latest types03 original38728 joined709c82 predates only the final approved property-presence expression/test below. Channel's declared typecheck exited0 in channel-types01. Scoped diff-check0. Root's final actual clean-import/module and whole-source checks are separate and not claimed here.

Important qualification boundaries: migration tests use actual file WAL/migrateSchema/backup/rollback and current production opener; public error checks enter actual product handlers (SQL failure sanitized500, invalid current graph DATA_INTEGRITY503). The existing public TCP projection test uses a controlled streamed Provider and actual Session/read/approval/persistence. The four process cases use real independent OS owners and real public Prompt/webfetch/resource callbacks, including original120s natural expiry. ACP uses official JSON-RPC and real product HTTP/Authority; its new queue case does not run a model and the other14 ACP cases were intentionally filtered. CLI is an actual CLI child against a controlled transport fixture. Channel runtime is explicitly a local adapter/SDK-boundary fixture, not Slack/Telegram visual or model E2E. Task callback/order and Channel winner cases use the established Task fixture and actual Authority/Engine/Board/Channel code, not a real model Task execution.

## Original failures and corrections retained

* grant-red01: 22 pass/1 fail/90 expectations, original U slot/actor null. Originalexec24664 joined1a4a90 exit1.
* grant-green01: 22/1/92; saved-grant case passed, old reconciliation fixture fabricated a random attempt over a successful invocation. Corrected to an actual serialization failure's canonical start, same-attempt unknown observation and original reconciliation. No production identity rule relaxed.
* source-task03: migration8/33 passed; Task5/1/28, original single-invalidation expectation received two. Shared subscriber/wake audit completed before correction; final exact2/1 arrays also prove canonical ledger/order/owner, one execution callback/result and one real Replied outbox. No dedupe gate added.
* error-contract04: facts3/18 passed; migration8/1/35 failed only because checker expected the leaf error one cause level too early. Actual Database.recordUnavailable preserves a second typed wrapper; current opener/public503 and immutable graph passed in opener-error05 (9/37).
* cli-transport01: 7/1/21; complete canonical notice passed, directory assertion guessed attach's default cwd. Current `run --attach` deliberately leaves directory undefined without --dir. Fresh adapters02 supplies explicit --dir and passes all8/21.
* process01: 4/58 and all physical facts passed but eight worker stderr files contained the known Bun --tsconfig-override directory mismatch diagnostic. Root approved deleting only that test argv; worker and SQL/process budgets stayed identical. process02 repeats4/58 with all eight stderr files free of that diagnostic. Original01 is retained and never called toolchain-clean.

Four literal zero-reconcile assertions in the touched two-mode file represented five executions. They were removed while retaining the actual reconciliation calls and complete positive ledger/owner/result expectations; final23/90 passed. The touched Channel global-event test's obsolete zero-call negative assertion and stale narrative were replaced by current positive stream receipt/current-bound-adapter contracts.

## Physical receipts and safe evidence

`process-closures.json` records both process01 and process02's eight scenario receipts from original stdout. Each attempt has eight child occurrences: six normal exit0 plus two deliberate crash23, all physical/output/request joined. Four per-case Provider response/Provider server/resource handler/resource server closures are true with errors[]. The original stdout additionally records managedDirectoryRemoved. Scope01/02 fixed deadlines and source/argv snapshots remain in their own directories. No original scope was extended.

All 22 formal outer scopes have actual physical/output/request joins. `tool-exec-joins.json` records every original tool session and actual completion chunk, including the two commands completed without a yielded session. No owned service or checker remains active. Public archive suggestions are in the separate explicit manifest; exclude runtime/home/DB/auth/models/config.json, full Provider request payloads and large HTTP transcripts. Only existing provider-requests metadata is allowed. No user credential was read or copied.

The explicit public pattern scan read the allowlisted text files; its exact count is recorded in public-pattern-scan.json. Loose `sk-...` matches were inspected as substrings of public `task-*` technical identifiers (preceded by `ta`), with zero unresolved matches; private-key and long Bearer-token patterns had no findings. This is a pattern scan, not an actual known-user-credential comparison. Root retains sole ownership of any known-value credential scan.

## Still separately owned or unverified

### Final narrowly approved source-presence correction (before implementation)

Root approved one reader expression and one positive error contract after final review found `metadata?.choices ?? computedChoices` treated explicit `choices:null` as absent. The frozen contract distinguishes missing fields from present malformed values. Use the actual property-presence test and pass any present value to the existing PermissionRequest parser; explicit null must report private scope_material_invalid, with the original row retained. Only truly missing choices uses the unchanged computed choices. No schema/actor/identity/migration/physical behavior changes. Run only permission-ledger-migration.test.ts in a fresh original600s formal scope, then refresh the exact source/allowlist/joins and freeze again.

Implemented and production frozen at **2026-10-14T08:24:54.212Z**. Fresh explicit-choices06 original19264 joined108f46 exit0:10 tests/39 expectations, actual physical/output/request joined. Its original preimage pair is preserved in this review directory. No production source was changed afterward.

Root owns real old-producer version1→2 desktop acceptance, fresh two-read and natural Task UI, actual model qualification, final module topology/clean imports and current architecture/docs/commit/push. This handoff does not claim external ACP peer visual cancellation or Slack/Telegram delivery, all Task/Mission/model combinations, actual post-commit unlock fault, non-WAL idle-reader exclusion, physical filesystem aliases/custom VFS or compiled Bun1.3 migration. Historical pre-fix eligibility-read timing cannot be retroactively certified. Full current graph conflicts fail explicitly; they are not silently repaired or interpreted as permission.
