# 408 后台最终只读人工复核

2026-10-14。按 Root 本轮授权，全文复读 8 个触及测试及真实 process worker，读取最后正式 stdout/stderr、原失败日志、22 份原 owner/工具 join 回执，以及 process02 四场景的 8 个 child stderr、源码原像和原完成/恢复事实。只新增本报告和 [原事实阅读摘要](human-audit-observations.json)，未改源、重跑测试、启动服务或写 Git。

结论：本轮已声明的后台合同有对应真实输出，未发现需由此审查新增的阻断问题。8 个触及文件最终去重为 **58 tests / 270 expects**；加直接关联的 6 个既有文件 **45 / 270**，合计仍为 **103 / 540**，重复运行不增加覆盖。不能把这些结果扩大成所有错误图、所有并发组合或模型 Task 完成。

## 逐文件审查

| 文件 | 已证明的正向合同与实际入口 | 最后原结果 / 限制 |
|---|---|---|
| `permission-two-mode.test.ts` | 真实 Session/Authority、原 effect lease/OS owner、两个 Project、MCP 同 task handback、grant 使用/删除/过期、决定赢家、Session 删除、原 result replay；未知 owner 和序列化错误保留完整原 ledger。 | `two-mode-final03` **23/90**。大部分为 Authority callback；structured Tool 个案为合法 writer 夹具，不是模型派发。孤立历史残留个案验证 Project 范围读取，不证明该残留可通过 v2 全图 startup。 |
| `permission-ledger-facts.test.ts` | 真实 requested→G→U 的 slot/source/actor、自动 Replied outbox、实际 result/current pending；TEMP trigger 的真实 SQLite 错误、原 ledger/outbox 保持、Hono public sanitized 500、后续 loser 返回原 winner；revoke 后真实新 Asked。 | `error-contract04` 此文件 **3/18**，同 scope 的另一文件当时失败，不能把整个 scope 写为通过。这里 public request 是真实 handler 的进程内入口，不是 TCP。 |
| `permission-ledger-migration.test.ts` | 自有 file WAL v1→v2，原 rows/backup 保留、实际 index locator/原 U 权威；deterministic S 锚定多 U、冲突 rollback、NORMAL 释放、direct/Full-access、源 G 全图与局部 reader 同错误、nested savepoint、实际 Client 503 原 cause 链、显式 null choices 错误。 | `explicit-choices06` **10/39**。v1 ledger 为按生产身份公式建立的历史夹具；旧真实 producer 升级/桌面由 Root 独立证明，不能以本文件冒充。 |
| `permission-execution-owner-process.test.ts` | 正式包入口→8 个真实 OS child→公开 Session/message→受控流式 Provider→真实 webfetch/本地 CSV→公开 permission reply。四场景覆盖 live 同/跨 Project、crash23 后 unexpired/真实 120 秒 expired 的原 owner 恢复。 | `process02` **4/58**；本轮该文件只删除错误的 tsconfig override。4 个 live 原 Tool/result 精确为 A,3/B,7，原 POST200、自然 stop/exact input、五事件含 stale；两个 crash 是 outcome_unknown，非业务成功。 |
| `server/task-board-validator.test.ts` | reply-first 两顺序真实 Authority/Engine/Protocol；完整 canonical 2/1 ephemeral 通知、唯一 durable Replied、1 次实际 callback/result；Channel 真 Task Interaction 决定竞争；另有真实 TCP ETag/HEAD 与完整 Board/project 合同。 | `adapters02` **7/35**。Task 用 `persistEstablishedTask` 建立，是后台 Interaction 夹具；不能声称自然 Task admission/调度/完整报告完成。same-ms 个案显式 mock clock，仅局部时间/validator 合同。 |
| `acp-prompt-terminal.test.ts` | 官方 ACP JSON-RPC 两端 + 实际产品 HTTP + 原 Session/Authority；队头 A 持有时 B 已被另操作者否决，C 仍 pending，实际投给客户端的完整 scope 集合为 A/C，各原执行返回精确结果。 | `acp-queue01` **1/4，14 filtered**。已阅读全文，但其他 14 场景没有在本轮重验；新用例没有外部 LLM 请求、没有外部 ACP 客户端视觉。 |
| `cli/run-transport.test.ts` | 真 CLI child 对受控 HTTP/SSE 的超时/旧 occurrence/当前 reply/权限完整重读输出；显式 `--dir` 贯穿三次读取。 | `adapters02` **8/21**。服务器的消息/DTO 是 transport 夹具，不是实际产品授权 ledger 或模型 E2E。退出、stdout、stderr 均由原 child 观察。 |
| `channel-runtime/test/subscribe-events-global.test.ts` | 正向 global event receipt、绑定本地 adapter、当前 SDK revalidation 输入及完整当前权限通知。 | `channel-projection01` **2/5**。明确 `mock.module` SDK + local adapter，只证明适配边界；不是 Slack/Telegram 等外部服务或视觉验收。stderr 的两条 stream ended/reconnecting 与夹具有限 stream 对应。 |

以上错误类型/错误码、原状态全集与错误后可继续的断言属于正向合同。少量辅助空 pending/false 值是完整生命周期输出的一部分；本轮核心不是“不调用/旧事件不存在”。未运行 UI 自动化。

## 原日志与 physical 事实

- 最后正式日志已逐份读：`two-mode-final03`、`error-contract04`、`explicit-choices06`、`projections01`、`retirement01`、`process02`、`acp-queue01`、`adapters02`、`channel-projection01`、`types03`、`channel-types01`。最后 core 与 channel declared typecheck 原 exit0；core types03 先于最后那一处 choices presence 窄修，未伪称其已复验该新增表达式。Root 另报实际 4 clean imports/迁移 checker 通过，属于 Root 证据。
- process02 八份 stderr 全量读取/逐行解析，共 **421,749 bytes / 1,275 JSON records**，无未解析行。1,273 条 info；仅 dead-unexpired / dead-expired 各 1 条 `permission execution outcome unknown after recovery` warning，attempt 与原 recovered ledger 一致。八份 child stdout 均 0 bytes。不存在把这些 stderr 宣称为空或把 outcome_unknown 宣称成功。
- source 原像直接逐字节回读：四场景的 `actual-test.ts`、`actual-worker.ts`、`actual-authority.ts` 共 12 份与本次阅读时对应源一致。此项只证明实际运行源身份，不作为功能正确性的替代检查。
- 原 parent deadline **1791965421383**、closeBy **1791965361383**；四场景全部在原截止前结算。child 为 **6×exit0 + 2×deliberate exit23**，原 reason 均 exited，每个 physical/output/request 全部 joined；四组 Provider responses/servers、resource handlers/server 均 closed，原 stdout 明确 managedDirectoryRemoved=true，cleanup errors=[]。
- 22 个正式 wrapper 的原退出和工具 completion 均已保留于 [formal-receipts](formal-receipts.json)、[tool-exec-joins](tool-exec-joins.json)。失败 scope 也已实际结算；“all joined”与“all tests passed”不是同一结论。

## 原失败不可覆盖

1. `grant-red01` 22/1：实际第二次执行成功，但原 U actor/decision_slot 为 null，正是原产品缺口。
2. `grant-green01` 22/1：新 contract 已绿；旧 reconcile 测试把随机 attempt 接到已完成原 request，被完整图报 execution_attempt_invalid。后改为真实 serialization-failure 原 start，不放宽 reader。
3. `source-task03` migration8/33 通过，Task5/1：真实 reply-first 产生两条 canonical 投影失效通知。完整共享订阅审计后才改为完整 2/1 集合，并验证同权威/time/order/唯一 callback/result/outbox；没有加影子去重。
4. `error-contract04` facts3/18 通过，migration8/1：原 Db unavailable 的 cause 多一层 typed wrapper。后验证完整原链，未修改错误生产合同。
5. `cli-transport01` 7/1：真实当前通知已正确，checker 未给 `--dir` 却期待 cwd；fresh 场景补显式入口，未改 attach 默认目录。
6. `process01` 虽 4/58，但八 child stderr 有 Bun directory-mismatch 诊断。原 argv/source/log 保留；process02 去掉唯一 override，仍原 package cwd/worker/期限，日志恢复真实正常记录。

## 保留的覆盖边界与审查提示

- 没有穷举所有 private integrity reason、每种错误 index/owner 图；没有独立多 OS 同时 grant capture 对 revoke/expiry 的竞争测试。当前 evidence 是单事务实现、同步/异步 winner 正向与物理 execution owner 过程的组合；不能把后者当作 grant capture race 的直接证明。
- strict SQL 个案在已有 winner 后注入 denied INSERT 错误；它证明错误不被吞成赢家和完整原 facts 保持，未额外注入新 U/outbox commit 故障。ACP 的 SDK500 后重新 hydration 分支也未由新 queue 用例单独触发。
- 部分既有 fixture 的 sequential finally 并不覆盖“stop/close 自身再抛错”的全部组合；本次真实正常/预定 crash 回执已闭合，不能外推所有异常 cleanup 已验。
- Root 当前真实 Task 已通过批准入口，但本组后台断言未检查其阶段字段展示，也未让受控 Provider 产生完整 Task report。Root 正在修 producer 遗漏 phase；该问题不被上述绿色测试掩盖，不能宣称真实模型 Task 完整成功。
- 外部 ACP/CLI/channel 用户视觉不在本代理范围。Root 的旧数据升级/当前 fresh 桌面应独立链接，不能累加成本报告的真实模型或 UI 资格。

源和原证据保持冻结；本次只读审查没有提出扩大代码范围或再开验收服务。
