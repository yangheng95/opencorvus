import fs from "node:fs/promises"
import path from "node:path"
import assert from "node:assert/strict"
import { NodeProcess } from "../../packages/util/src/process-node"
import { expectedTestProcessSupervisor } from "../../packages/opencorvus/script/test-process-supervisor"

const [stage, kind, ...files] = process.argv.slice(2)
assert(stage && /^[a-z0-9-]+$/.test(stage) && ["test", "typecheck", "channel-test", "channel-typecheck"].includes(kind!))
const repository = path.resolve(import.meta.dir, "../..")
const scope = path.join(import.meta.dir, "implementation", stage)
const startedAt = Date.now(), deadlineAt = startedAt + 600000
await fs.mkdir(scope)
const supervisor = expectedTestProcessSupervisor()
assert(supervisor)
process.env.OPENCORVUS_PROCESS_SUPERVISOR = supervisor
const packageDirectory = kind!.startsWith("channel-") ? "packages/channel-runtime" : "packages/opencorvus"
const args = ["run", "--cwd", packageDirectory, kind!.replace("channel-", ""), ...files]
const owner: any = { startedAt, deadlineAt, parentPID: process.pid, executable: process.execPath, bunVersion: Bun.version,
  cwd: repository, args, requestStarted: false, requestSettled: false, physicalJoined: false, outputJoined: false }
const environment = { ...process.env }
if (files.includes("test/permission-execution-owner-process.test.ts")) {
  assert.equal(files.length, 1)
  environment.OPENCORVUS_PERMISSION_OWNER_DEADLINE_AT = String(deadlineAt)
}
let handle: Awaited<ReturnType<typeof NodeProcess.spawn>> | undefined
let primary: unknown
let output: { stdout: Uint8Array; stderr: Uint8Array } | undefined
const cleanupErrors: Array<{ step: string; error: unknown }> = []
const facts = (e: unknown): unknown => e instanceof Error ? { name: e.name, message: e.message, stack: e.stack,
  ...(e.cause ? { cause: facts(e.cause) } : {}), ...(e instanceof AggregateError ? { errors: e.errors.map(facts) } : {}) } : String(e)
const cleanup = async (step: string, action: () => Promise<unknown>) => {
  try { await action() } catch (error) { cleanupErrors.push({ step, error }) }
}
try {
  await fs.copyFile(import.meta.filename, path.join(scope, "actual-run-formal.ts"))
  for (const file of files.filter(file => file.endsWith(".test.ts"))) {
    await fs.copyFile(path.join(repository, packageDirectory, file), path.join(scope, path.basename(file)))
  }
  await fs.writeFile(path.join(scope, "owner-start.json"), JSON.stringify(owner, null, 2))
  assert(Date.now() < deadlineAt - 60000)
  owner.requestStarted = true
  const result = await NodeProcess.run({ command: { executable: process.execPath, args }, cwd: repository,
    env: environment, ownership: "owned_tree", windowsHide: true, stdin: "ignore", deadlineAt, nothrow: true,
    onSpawned(value) { handle = value; owner.pid = value.pid; owner.occurrenceID = value.occurrenceID } })
    .finally(() => { owner.requestSettled = true })
  output = { stdout: result.stdout, stderr: result.stderr }
  owner.receipt = result.receipt
  owner.settledReceipt = await handle!.settled; owner.physicalJoined = true
  await handle!.outputSettled; owner.outputJoined = true
  assert.equal(result.receipt.reason, "exited")
  assert.equal(result.receipt.exitCode, 0)
} catch (error) { primary = error }
finally {
  if (handle && !owner.physicalJoined) {
    await cleanup("terminate original owned handle", async () => { owner.terminationReceipt = await handle!.terminate("aborted") })
    await cleanup("join physical", async () => { owner.settledReceipt = await handle!.settled; owner.physicalJoined = true })
  }
  if (handle && !owner.outputJoined) await cleanup("join output", async () => { await handle!.outputSettled; owner.outputJoined = true })
  if (output) {
    await cleanup("write stdout", () => fs.writeFile(path.join(scope, "stdout.log"), output!.stdout))
    await cleanup("write stderr", () => fs.writeFile(path.join(scope, "stderr.log"), output!.stderr))
  }
  owner.endedAt = Date.now(); owner.primaryError = primary ? facts(primary) : null
  owner.cleanupErrors = cleanupErrors.map(x => ({ step: x.step, error: facts(x.error) }))
  owner.status = !primary && !cleanupErrors.length && owner.requestSettled && owner.physicalJoined && owner.outputJoined ? "passed" : "failed"
  await cleanup("write owner", () => fs.writeFile(path.join(scope, "owner.json"), JSON.stringify(owner, null, 2)))
  process.exitCode = owner.status === "passed" && cleanupErrors.length === 0 ? 0 : 1
  console.log(JSON.stringify({ ...owner, cleanupErrors: cleanupErrors.map(x => ({ step: x.step, error: facts(x.error) })) }))
}
