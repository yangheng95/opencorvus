# 408 Task permission projection invalidation audit

## Original observation and limits

`implementation/source-task03` original exec65115 joined68065f exit1. Migration 8/33 passed. Task checker 5 passed/1 failed/28 expects: the reply-first case's actual Board was HTTP200, answered, allow_task, original ledger resolution time; its next assertion expected one `interaction.resolved` and observed two events with the same interaction/request/ledger/status. The original source/stderr/owner remain unchanged. This report does not reclassify that run as passed.

The checker uses the established Task fixture and real Authority/Bus/Engine/Protocol/Board code plus a real execution callback. It does not run a Task LLM or create a ToolPart. Message/Provider effects therefore require source-path exclusion here, not a fabricated assertion about a nonexistent model call. Actual public TCP Prompt coverage passed separately in projections01; it is not this Task order scenario.

## Definitions and complete production subscription surface

Search input/output is `implementation/interaction-resolved-callers.txt`. Exact production producers are engine/interaction.ts projectPermissionTermination and resolvePermission. `ProtocolStore.dispatchEphemeral` (store.ts746) makes a new transport event/liveSequence, stores only the bounded in-memory live replay entry and calls dispatchEvent; it does not call appendEvent, Bus, Session writer, Permission reply, Task control or any model. dispatchEvent300 only invokes registered `subscribeEvents` callbacks matching aggregate/Task/Session/types (290).

All production `ProtocolStore.subscribeEvents` callers from the full repository search:

* engine/event-log.ts320: selected event timeline/NDJSON logging; resolved branch257 writes diagnostic lines only.
* server/routes/orchestrator.ts644: exact Task identity filter, cursor/liveCursor and SSE output. Ephemeral occurrences have separate liveSequence values; no execution admission or domain mutation.
* server/routes/session.ts1265/1269: session aggregate and an explicit Task lifecycle allowlist of agent.execution.lifecycle/session.error. Task interaction.resolved is outside both matching filters; it does not become a standalone Main/Side pending update or a Session wake.
* server/routes/work-ledger.ts378: mailbox/task-list projection notification, SSE writing only. Even if selected by a projection predicate, the callback does not issue a command or wake.

No Task/Mission/Session execution owner subscribes to this protocol event. The event model enum and event-log allowlist are declarations/logging, not execution consumers. Engine/interaction's only `requestTaskControlScanInBackground` call is the separate Question projection after its original typed control resolution (line511), not either Permission invalidation producer. Permission's real continuation resides in replyValidated1060–1062 (won decision and no physical waiter), original local waiter release, and the existing explicit recovery scan. None is reachable from dispatchEphemeral subscribers.

## UI and reconnect handling

Overlay event-policy.ts132–170 classifies interaction.* as Board invalidation and interaction.resolved as a tree projection. tree-writer.ts890 routes it to handleInteraction2078 which only rebuilds cards from current boardStore.board.interactions, not event payload or a reply action. services/events.ts's task-event routing schedules Board reload for the active Task. store/board.ts757 captures API authority/selectEpoch and coalesces refresh timers with its existing bounded debounce; loadBoard is a GET projection. Two transport notifications may cause one or two GETs depending on arrival timing; neither route starts a Tool or emits userInput. No new dedupe/cache is proposed.

Reconnection can replay both bounded live transport occurrences; both have the same original resolution orderKey and reread the same canonical Board. Restart loses ephemeral memory and hydrates the canonical stored decision; no extra persisted interaction outcome is introduced. Task/session/Project identities are checked by resolvePermission against the canonical request and Task row before dispatch; matchesEvent isolates exact Task streams. Parallel tasks and multiple Projects do not share a domain decision solely because they share the global subscription registry.

## Two causal projections, not two decisions

In the new deterministic reply-first fixture, the first real Asked subscriber calls the actual reply writer synchronously through decision/outbox commit before awaiting publication retry. The Engine Asked subscriber then reads the committed decision, materializes the one real request-backed interaction, and emits its current terminal projection. The original Replied publication still owns its durable Engine delivery; when that subscriber runs it validates the same ledger and emits the same terminal projection again. In the reverse registration order, Asked reads pending and materializes without a terminal invalidation; Replied later emits the only terminal projection. Both paths call the same canonical reader. The existing durable delivery contract is idempotent by occurrence, not a promise of exactly one ephemeral invalidation across different Asked/Replied causes or replay.

No duplicate userInput is manufactured: late Asked calls resolvePermission without userInput; only the winning Replied carries original input and assertResolvedReplay captures the immutable occurrence using original interaction identity/time. Current local test uses no userInput, so that last statement is source evidence; original engine-interaction-recovery positive user-input replay cases passed in projections01 separately.

## Positive checker correction proposed after this audit

Keep original failed expectation/source. For each actual order assert the complete canonical request/decision/start/success/result and one executed callback; retain the actual full notification array, and check every event's original Task/Session/request/interaction/ledger/orderKey plus exact terminal fields. Deterministic order-specific transport counts are 2 for reply-first and 1 for Asked-first; those are local observation expectations, not an exactly-once global contract. The reader/Board has one durable authority regardless. Do not add a shadow notification cache, a workflow gate or a synthetic terminal.

Remaining boundaries: this audit and local fixtures cannot prove external SSE consumer implementations, real model Task completion, or undocumented third-party clients. No UI automated tests were run. Root's real desktop/actual model evidence remains separately scoped.
