# 408 Permission ledger 生产收敛计划（待 Root 最终冻结）

## Recall、真实资格与未授权项

Root 本轮仅授权只读收敛方案/调用证据，未授权生产、正式测试、迁移执行或新服务。已重读408 Recall、historical-authority-index-contract、production-scope-and-desktop-plan、其39份原输入/调用/历史捕获，并对照当前 Authority、Db/migrator、Engine、protocol和直接调用者。旧报告中 INDEX 占位、未started U+其他slot的候选取舍，以Root本轮明确选择为准。此前原工具/源码和失败不修改。

当前只读输入见 [evidence manifest](production-ledger-evidence/manifest.json)：10项definition/caller/history命令、12份当前原source、原39文件清单及17个原完整source与当前逐字节相等的比较记录。身份比较只供准确定位分析输入，不是功能验收。一次猜测的interaction-writer.ts和channel runtime.ts/control路径搜索报不存在，随后按真实engine/store/interaction及channel-runtime/core.ts核对，不据这些检索失败判断缺功能。

Root已实际资格：followup02原ecb5f9/27855→34bc52退出0，23.56s/3cases/14workers；合法current+upgraded，以及原backup EEXIST/validator reject→rollbackv1/readerBUSY/NORMAL访问/旧productionv1重开。guarded01原449358/88031→14deb0退出0，11.18s/7workers，第三真实旧production live时两个候选BUSY5743/5700ms，旧owner正常join后1→2/backup/current2→2/oldAHEAD。D1原真实两read证明第二U slot=null、Tool finished仍cold pending，Root有原截图及闭合。它们分别是物理锁/旧格式现象资格，不是下面尚未实施的grant语义迁移/reader资格。

当前确定根因仍是同一链：`authorize:863–865`捕获G而append U不占slot；`decisionFor:576`、pending/retirement/recovery、Engine/store759只认slot；晚Asked不重读decision。43636df96引入U与scopeVersion2；e0801739确立重复requested保first owner；402/406修投影和physical owner、407修canonical Message原子退休，均未修U的决定身份。本批不能再加`slot || latest U`、回写旧U、双reader/新状态、假human/终态/时间。

## 1. 最终推荐的数据形状

只新增私有事件 `grant_decision_indexed`（下记I）和semantic revision2，数据库列/DDL形状与当前相同。I是原decision的单跳定位事实，不是approval、grant、execution或用户回复：

- `id=Identifier.ascending('permission')`、`time_created=Date.now()`是迁移实际产生的新事实；`request_id=RU`、`decision_slot=RU`、`source_event_id=U.id`。
- `actor_id='schema-migration'`、`metadata={migrationVersion:2}`；`decision_scope/attempt_id/outcome_slot/reason`及全部requested-owner列为null。不能复制G/U的scope/actor/原批准时间，不能把迁移时钟用作resolved时间。
- U仍引用原G；I只能直接引用同request的slotless U，不能I→I、I→G、I→S、I→缺失行。执行S仍引用原U，不能改为I。
- I产生于版本化迁移事务，不发Bus、不造Message/userInput、不释放不存在的旧waiter。新runtime直接U占slot；旧数据只有经I定位后才是current合法格式。

公开history的event_type本来为string，Resolution.eventID可返回原U，Interaction.response是现有record，因此这些内容本身不需SDK公共字段变化。正式schema生成是否零增量应按当前正式checker确认，不能手改SDK。

## 2. 一个低层实现、一个typed事实视图

推荐唯一新生产模块 `permission/ledger-facts.ts`。依赖仅：`import type { Database } from '@/storage/db'`、当前permission.sql表、轻量types/decision/Identifier、drizzle-orm、已存在的纯result envelope decoder及纯值比较。禁止runtime Db/Authority/Instance/Engine/Bus/Config/SessionLoop导入。

对外最小函数（名称可在Root批准后固定，不先写代码）：

| 函数 | 输入/输出与唯一职责 |
| --- | --- |
| `permissionRequestIdentity(input)`、`permissionAttemptIdentity(requestID)` | **搬走**现Authority原公式，非复制；Authority及tool-outcome-facts用同函数。身份材料和生成值不变。 |
| `readPermissionRequestFacts(db: Database.TxOrDb, requestID)` | 返回undefined仅当原请求图完全不存在；存在delta无R为明确错误。返回canonical requested row、原完整Request、slotLocator、original authority row、decision及autoReply，附本request的start/outcome/result/retirement事实供当前调用者使用。 |
| `validateCurrentPermissionLedger(db)` | 在原startup/migrator已有事务中一次装载完整ledger/results，调用同一纯图解析/校验内核，返回void或private typed error。没有业务修复副作用。 |
| `planHistoricalGrantDecisionIndexes(db)` | 只供revision2 callback；一次装载旧图、运行同内核的显式historical输入规则，完整验完后返回只含RU/U.id的计划。不是runtime可调用的slotless fallback。 |

内部仅一份pure `qualifyRequestGraph(material, format)`，格式选项只区分旧迁移输入与已发布current。current入口固定current，不根据查不到slot自动切历史模式。wholegraph和request loader只是不同读取范围，不是不同合法性规则。临时Map/数组属于一次同步计算，不跨请求缓存、不持久化第二套权威。

返回视图的存在关系是判别联合：pending必须`slotLocator/authority/decision`全无；decided必须三者齐全。直接slot的locator===authority；indexed的locator是I、authority是原U。`decision`严格由合法kind/scope映射；不能默认unknown→allow_once。`autoReply`在本批含义明确为**原grant_used捕获事实**，direct U/indexed U均true，其余false。现Full-access allowed_once/nullscope/actor full-access-policy合法，但它原本不发自动Replied，不能将其误作另一次saved-grant reuse。

### 原纯逻辑的必要搬移

现`requestFromRow`会runtime Database.use找owner，又通过重`invocation.ts`做eligibility；不能直接导入startup。将其原完整Request映射和choices构造移入leaf，使用已传入的canonical first requested与**现有PermissionRequest.parse**，不复制第二Request schema。Authority原helper变为调用单一reader/取其Request，删除原raw owner `.get()`和默认decisionFromRow路径。

`permissionProjectGrantEligible`当前在invocation303–319，是不依赖Instance的纯predicate；将该定义原样搬入leaf，invocation与Authority改import。它的filesystem/network canonicalization等重流程不搬。必要的effectClass类型使用type-only引用或现轻量Request类型，不在leaf导入invocation的runtime。原attempt公式在session/tool-outcome-facts56也存在，改引用同一函数，不能在新leaf形成第三份公式。

### 读取一致性与扫描成本

`TxOrDb`包含裸Client；多条SELECT如果没有snapshot，另一physical writer可在中间提交U/slot，造成混合视图。推荐per-request入口用传入db的现成**同步Drizzle transaction**取得读snapshot：Client为只读事务，已有Tx为nested savepoint；内部只select+pure resolve，不调用Database.effect/Bus/任何写入或新Client。startup/migration wholegraph已经处于原migrator事务，只直接装载后调用pure内核，不再套BEGIN。此选择必须以真实Client/Tx的类型和nested正向合同验证，不能把“函数名InTransaction”当已经有snapshot。

request loader依`permission_ledger_request_idx`读全部本R行、依decision_slot唯一键读其locator、依source PK获取I→U→G及G的全部requested/相关grant图、依确定attempt/outcome/result键读关联事实。单跳I+单跳G是固定边界，不递归追索任意source；行数与本请求及源grant历史相关，不每次全表扫描。完整跨request inbound孤儿/重复slot/attempt归wholegraph检测，不谎称一次局部读取扫描了所有别人的错误。

wholegraph一次读取全部rows（真实rowid顺序）和results，建立byID/byRequest/bySlot/byAttempt/Result Map；循环每组走同内核，预先检测全局重复ID/slot/start/outcome、orphan result。计算O(N+结果数+显式引用数)，不用N个全表查询。first requested按原rowid选取，不能按ID/time/latest代替；这个排序只选已定义的owner首观察，**不**用来仲裁授权。

## 3. 精确private错误合同

建议 `PermissionLedgerIntegrityError extends Error`，固定private code `PERMISSION_LEDGER_INTEGRITY`，reason为下列闭合union。只携带requestID/eventIDs/attemptID/field等真实非秘密定位；不把完整scope/参数写入错误。不是NamedError/public schema，不更改现HTTP响应格式。

| reason | 精确触发 |
| --- | --- |
| `event_kind_invalid` | 不在当前私有event allowlist的ledger类型。 |
| `event_shape_invalid` | ID/time/required/null owner形状或该事件角色字段不合法。 |
| `request_owner_missing` | 任一delta/result所属request缺canonical R。 |
| `request_owner_conflict` | 同R多个requested的权威材料矛盾。 |
| `request_identity_invalid` | 当前compact/canonical request ID或原deterministic公式不符。 |
| `scope_version_unsupported` | 无法按支持的baseline scope格式证明其原语义；不能悄悄用v2重解旧版本。 |
| `scope_material_invalid` | stored结构/owner字段/原choices不符合该版本原合同。 |
| `decision_slot_conflict` | 同slot多行，或一个R出现多个/外属slot locator。 |
| `decision_kind_invalid` | slot行类型不是六个direct kinds或I。 |
| `decision_scope_invalid` | direct kind对应scope/Task/eligibility/Full-access例外不符。 |
| `index_shape_invalid` | I的actor/metadata/列null形状/slot/R不符。 |
| `index_source_invalid` | I引用缺失、自身、另一I、错误kind或其他R。 |
| `grant_source_invalid` | U/V引用的G缺失/非grant_created/不拥有其原request槽。 |
| `grant_scope_mismatch` | U/G的Project/fingerprint/provider/结构scope/version或task范围不一致。 |
| `grant_capture_conflict` | 已有任何真实slot与另一distinct slotless U冲突，或slot实际authority与S.source不符。 |
| `grant_capture_ambiguous` | 多U没有唯一合法deterministic S精确锚定。 |
| `grant_capture_unindexed` | current格式存在slotless U而无合法I定位。 |
| `execution_attempt_invalid` | attempt公式/所属R/该事件所需attempt和outcome-slot不符。 |
| `execution_start_conflict` | 同R多个不一致start/不同attempt，不能因每attempt unique就通过。 |
| `execution_authority_mismatch` | S.source不是该R的canonical正向原authority，或指I/negative/外R。 |
| `execution_outcome_invalid` | outcome/unknown/reconciled源链/所属attempt或role不符。 |
| `execution_result_invalid` | success/result缺一、结果envelope非法、result无start/对应success或所属attempt不符。 |

同一明确错误应带原原因，不按SQLite英文文案匹配。普通runtime调用让private error按现serverErrorResponse变sanitized500+requestID，保服务器原cause。startup同validator捕获后用现DatabaseUnavailableError `DATA_INTEGRITY_ERROR`、operation `Database.Client.dataIntegrity.permissionLedger`包裹，HTTP仍503。旧v1语义callback错误由原migrator包`SCHEMA_MIGRATION_FAILED`并保backup/cause；不先在callback改成DATA_INTEGRITY_ERROR，以免混淆“当前坏图”与“升级失败”。

## 4. 完整图规则：owner、scope、source、attempt

### R和retained owner

每个R至少一个requested；所有requested必须相同project_id、session_id、task_id（包括null）、message_id、tool_call_id、mode、policy_revision、provider_kind/id/digest、tool_name、effect_class、scope_version、结构scope、fingerprint。ID/time/summary/metadata是各自观察，不能一律要求整行相等；原first requested的time/summary/metadata/choices作为展示来源。每条requested的ID/time合法，owner的request deterministic公式准确。delta的全部owner列仍null；不能为I复制完整owner。

Project/Session/Task/Message可能已经正常删除，ledger/results按现DDL保留。图验证以R为原owner，不要求当下mutable行存在、不join当前目录或当前选中Project来补identity。读取caller的Project/Session边界仍按已有route/lineage合同验证真实owner，不能因为header换了目录就把全局known-ID读取政策偷偷变更。按Project选出候选后仍加载完整R组验证，防矛盾duplicate被过滤隐藏。

scopeVersion2可按stored scope的provider_kind/id/digest、tool_name、effect_class对齐owner，再比较source/use两完整结构scope及fingerprint。不得重新realpath、访问当前文件、重算provider安装状态或用当前policy解释历史。Root已核grant引入与scopeVersion2为同43636df96；真正未知scopeVersion应明确unsupported，不伪装已迁移。fingerprint仍是原协议身份，不将它当本次功能验收hash。

scope eligibility复用搬移后的唯一pure predicate；metadata.choices实际存在时必须是合法Decision集合且授予的scope在原记录中被允许。optional旧metadata缺失不等于owner改变，沿原choices生成规则由storedTask/eligibility恢复**同一公开Request**，不是无条件允许all scopes。既有Full-access的choices生成也可能包含合法task/project项，不能凭模式名字新增“grant_created必须Ask”这一未经原producer保证的限制。

### Direct决定的allowlist

| authority.event_type | decision_scope/来源与结果 |
| --- | --- |
| `allowed_once` | invocation→allow_once；null仅接受owner full_access且actor full-access-policy的真实原policy branch。不能null默认任意approval。 |
| `grant_created` | task或project；task必须原R有Task，project必须stored版本/pure predicate及存在的choices支持。source_event_id为null，原G拥有自身request slot。 |
| `grant_used` | task或project，必须精确引用G，scope相同；Project和fingerprint、provider/tool/effect、scopeVersion/结构scope一致；task还要求两R同一个非空Task；project允许同Project跨Session/Task。直接current U拥有自己的request slot。 |
| `denied` | invocation，原actor/reason保留，decision=deny。 |
| `cancelled` / slot-owning `stale` | invocation，原系统/真实决定actor和reason，decision=deny；维持原Terminated身份。 |

上述direct的slot必须等于自身request_id，无attempt/outcome槽；negative/allowed/G不是另一event的定位器。slotless stale不是direct决定，不能抢原已批准slot或覆盖其scope/time。

### I、历史capture与唯一选择

先完整验证每条U自身G/owner/scope，以及所有slot/start/outcome/result材料，再决定是否加I。无slot、无U是合法pending；无slot+唯一合法U即便没有S也可索引，但只证明“捕获”，不能宣称effect已执行。多个合法U只有一个合法deterministic S且它.source精准属于其中一个U时才可选该U；不能按time/rowid/相同scope消歧。

**已有任何slot+另一distinct slotless U均是冲突，包括U未started。** 已有direct U自身不是distinct额外U；若还有旧slotless观察，仍冲突。一个已合法I→U的current图可以保留多条旧U观察，但必须同一唯一S锚定被索引U；I定位规则与历史选定规则一致，不能仅因已存在I就绕过歧义。已有合法I的再次验证/重开不追加第二I。

source G即使现在revoked/expired，已存在的真实U仍保其capture；V只影响未来capture。旧writer的eligible-read与U append并非同事务，原rows没有read发生时刻；不能用event时间或rowid证明历史撤销前后串行化，也不回填时间。此次迁移保可证真实capture，不签发历史linearizability保证。

### source allowlist和不能当FK的原审计链接

G的source为null；U只能source G；I只能source同R slotless U；revoked/expired只能source原G且沿G的R owner。S只能source该R正向canonical原authority（allowed_once/G/U），永不source I。outcome_unknown由原reconcile产生时source同attempt的S；execution_reconciled source原同attempt outcome_unknown且metadata.outcome为现有成功/失败枚举；不得把reconciliation变成第二outcome_slot或当新的Permission决定。

必须保留一个现存合法边界：slotless stale.source_event_id既可为full-access完整成功的execution_succeeded.id，也可由changed-identity分支记录尚未注册的新requestID（authority963/999），还可为空。这个字段没有持久discriminator。**不要按“先找ledger，找不到改找request”另造fallback reader，也不要一律当ledger FK。** 对slotless stale只验证其自身R/role/null decision槽和非空source的canonical Permission身份；source作为原opaque审计关联保留，不参与授权/index/执行authority解析。不由reason英文猜子类型。不能声称此不带discriminator的审计链接已被完整语义化。

### Attempt和Result

每R只接受原deterministic `attempt\0R`。唯一S属于该R，source是解析出的同一个正向原authority。无S但U已索引是合法未执行capture；当前live/dead lease判断依原406机制，validator不从missing OS记录造dead，不改effect lease。

execution_succeeded/execution_failed/outcome_unknown拥有outcome_slot=attempt，必须有同R/S且全局只有一个terminal winner。成功必须有同attempt PermissionExecutionResult，result存在也必须配原success；用原resultFromDurable验证envelope。未完成/明确failed/unknown不能借其他Tool结果变成功。已保留的result表无Session/Project cascade，当前src没有删除result路径；owner删除不放宽pair关系。Tool outcome reader仍负责accepted Tool的Project/Session/Message/call/tool与part/Source物化，不把ledger graph validator扩成第二Tool物化器。

MCP Task created/status有同deterministic attempt和实际S、无decision/outcome槽，保原metadata与当前MCP schema/lease/handback消费者；本层只核授权/attempt关联，不复制McpTask schema或宣布远端payload全验。execution_reconciled仍是unknown后的人工审计链，不能据它另行合成durable result；本批不重设计其现有恢复业务。原同source多次观察/矛盾reconciliation若超出当前graph角色约束，应保具体原件并报Root，不静默选latest或扩大本批控制流。

## 5. 当前写入：同一immediate事务、精确CAS、原outbox

`authorize`在descriptor/policy/原R注册后，用一段原Database.immediateTransaction同步读canonical current事实：已有正向winner复用原authority；negative抛原RejectedError；退休仍原StaleContinuation。没有winner才在**同db/同事务**查eligible G及其revoked/expired，再占R slot写新U并保G.source/scope/实际capture time。所有分支都统一返回事实视图的原authority，不把I用于S.source。

activeGrant改接传入db，源G也经同canonical graph确认，不跨两次Database.use读eligible再append。新capture、revoke、expire各自用原outer immediate从原G验证到delta提交；Project deletion已有同fenced事务的expired writer保留，capture读取其真实V。capture先commit则U有效且后V只挡未来；V先commit则本次无eligible G，进入真正pending。不得比较wall-clock给胜负。negative/manual decision同slot CAS，negative先赢则不执行，U先赢则后来operator attempt返回原allow赢家而不发布假的人类批准。

推荐删除`settleDecision`和`settleDecisionInTransaction`两段任意catch，保留一个同步事务内setter。使用现SQLite/Drizzle定向 `ON CONFLICT(decision_slot) DO NOTHING RETURNING`：有返回行才won=true；只有真实0行才读同canonical winner并won=false；0行却无合法winner是完整性错误。其他SQL异常（trigger、I/O、PK、schema、busy、outbox等）原样传播，不见到winner就吞，不按英文文案/泛unique code猜冲突列。普通wrapper由调用者在原immediate里调用此setter，不能保两份平行SQL。

用户reply、非user reply、自动U及cancel/stale都沿该setter；只有真正won的那一事务写原owned outbox。用户winner的真实userInput仍只在其Replied中；自动U的Replied固定autoReply:true、无userInput，建议实际系统actor标识`saved-grant-policy`写入新U并用于其通知（这是新增私有producer identity，待Root最终确认，不复制原grant的人类actor）。历史U原actor/null不回写，迁移不补通知。Full-access policy原是否发通知的合同不扩大。

原`Reply.autoReply`还能经Task API输入，但未作为ledger权威持久化；不能从它重构历史自动决定或新增镜像bool。本批canonical autoReply只证明U，其他现有显式API通知位仍是那次真实通知输入，不作为持久grant权限来源。若Root要求所有第三方输入autoReply都可持久重建，这是额外公共合同，不能暗借I实现。

commit后，winner拥有的Publication按原retry/drain观察；释放真实local waiter用canonical negative/positive结果。`authorize`自身正在执行的capture不另发resumeRequest；真正public reply无waiter仍沿原resume/407 strictretirement。loser不新增outbox/userInput，返回真实赢家Resolution；原winner outbox未delivery由既有Bus机制恢复，不由loser造第二条通知。发布/恢复失败保持原错误，已经commit的decision不回滚伪装不存在。

嵌套时仍用原Database savepoint/effects截断。原outer deferred并不会因嵌套immediate而升级为IMMEDIATE；同步read/write仍在同事务，冲突必须传播busy/typed error，不能宣称提前写锁或重试重排。所有新增outbox与U/decision在同writer，外层rollback应同时撤销它们及postcommit effect；不手清waiter/修改Bus队列。Bun真实SQL target-CAS与nested/trigger错误必须由正式检查器证明后才能交付。

## 6. revision2与startup：单一validator的两个真实入口

建议新增immutable `storage/migrations/0002-grant-decision-index.sql`（当前DDL原快照）和同名`.ts` semantic callback，registry追加version2；0001和现table schema/DDL形状不改。callback用原同handle创建的Drizzle视图（引入现ApplicationSchema以得到真正TxOrDb，不用as伪装），调用historical plan函数，**全图验完**后逐条插I。临时移除unique/index/trigger期间不依赖`.get()`或冲突仲裁，先检测全部slot/owner/attempt/引用再写。I实际id/time在写时产生，不backdate。后续目标对象重建和原migrator current validate必须确认完整图。

当前startup `assertCurrentDataIntegrity(sqlite, integrityDB, dbPath)`增加同一current validator入口，保持现legacy compact/Tool控制结果检查。current格式无locator的slotless U明确error；合法I保多旧观察但唯一真实source不变。迁移callback/validator无Bus/Instance/Project重建，不启动物理recovery。已经capture但未started的I在后续真正startup continuation里可能成为可恢复授权，这属于原生命周期验收：必须结合原Tool/Message/Task activation/原owner死亡或live保护，不把索引当恢复成功。

物理migrator由Root另管：复用已真实资格的NORMAL WAL attach→file EXCLUSIVE/actualBEGIN→同handlebackup/图验/commit→NORMAL+finalized真实访问后才暴露Client/安排checkpoint；fresh库与unsupported rollback模式/实际unlock失败的精确公共错误由Root冻结。锁experiment绿不等于代码已安装。db/migration与leaf值导入图必须跑正式module-topology（包括actual clean imports），不能仅AST无SCC推runtime通过，更不能放宽retained-budget。

## 7. 消费者统一与真实到达顺序

- Authority：原raw decisionFor/requestFromRow/pendingRequest/list/continuationReady/retireMessageContinuations/replay/reconcile相关使用canonical facts；history仍保完整原rows，不能把I替换成U丢失迁移事实。按request解析后使用原requested Project，沿现trueSessionProject退休，不引入ambient fallback。
- Session protocol：standalonePendingPermission先读同canonical facts，严格核 Asked完整Request与原owner，已有decision则不给pending投影；保现Task去重/非Task child准入。原Replied/Terminated仍是真实终态通知，cold/reconnect数组继续同源。原response的orderKey若需准确terminal time，取canonical原authority.time/id，不取I或delivery Date.now；不加公共time字段。
- Engine/store：把759原slot `.get()`及默认allow_once映射删除，使用传入db的canonical视图；原requested引用可为保留的合法同owner观察，但展示time/payload统一first R。time_resolved/time_updated/responseOrderKey来自原D/U，response.auto_reply由真实U派生。保Engine outcome与Permission决定双终态冲突校验。
- Engine/interaction：Replied不再只assertResolvedReplay后返回；读canonical真实winner/owner/Task/Session并使用现ephemeral `interaction.resolved`失效通知。用户发生记录保持原winning userInput。Replied先于Asked时没有Interaction就不造它；随后真实Asked正常materialize后同canonical投影为answered/rejected并按原真实决定通知。Asked先发生时Replied直接收敛。未发Asked的普通自动reuse没有Task卡是合法事实，不能补假卡拍照。
- Settings：显示I的中性索引标签及它自己的实际时间；operationStatus跳过bookkeeping I而取真实decision/execution事实，不能第二套I解析或猜unknown为允许。中/英同mounted视图、Task历史原canonical part复用与已批准的四UI路径由Root/UI agent独立实现实页。

外部ACP/CLI/channel共享现public list/reply返回值，但不是Main的同一个展示合同。bounded本地adapter修复应只在原queue head/实际操作前重新读canonical pending、返回真实winner，不把消失当已批准；ACP合作取消不等于peer Promise已结束，CLI历史notice不可假称已撤回，channel确认不能只复述用户尝试的always。相关精确路径为`acp/agent.ts`、`cli/cmd/run.ts`/`cli/cmd/permission.ts`、`channel-runtime/src/core.ts`；当前本计划不新增外部协议/消息能力。Root可冻结到独立本地adapter子范围，真实外部客户端视觉/撤框尚未验，不能宣称所有客户端都已通过。

## 8. 建议最终生产allowlist与明确不改项

后端必要语义集合（Root需再正式授权）：

1. 新`permission/ledger-facts.ts`；`permission/authority.ts`；`permission/permission.sql.ts`。
2. `permission/invocation.ts`仅搬原pure eligibility定义/改import；`session/tool-outcome-facts.ts`仅改共享attempt公式引用。若实际类型需要改现轻量types，只能先具体报Root，不能先复制McpTask/Request schema。
3. `storage/db.ts`接current validator；`storage/migrations/index.ts`及新`0002-grant-decision-index.ts/.sql`；`storage/schema-migration.ts`仅Root另授权的物理guard生命周期。
4. `engine/store.ts`、`engine/interaction.ts`、`protocol/session-mirror.ts`。

共13个后端路径，其中新leaf/新2个migration文件；不混入另一任务Git/process/channel配置生产。UI所需PermissionsPanel/en-US/zh-CN、已选Task-history四文件由Root/UI单独列精确allowlist；不由本backend先改。现permission/project-authority.ts/project/delete.ts不因I另写expiry路径，其同事务V与owner合同需正向资格。Question、SessionLoop/physical leases/ProcessFacade/Bus/ProtocolStore/DDL基线、公共schemas/SDK生成器不改。删除旧Authority两setter/rawslot/defaultmapper是真替换，不保兼容wrapper。

## 9. 正向正式与真实验收计划

本轮未运行任何下列检查。测试只能backend明确结果/状态/真实错误，不UI自动化、不以缺事件/不调用为核心。

| 资格 | 最小正式候选路径/明确输出 |
| --- | --- |
| 单源current reader与scope图 | 新`test/permission-ledger-facts.test.ts`：每个direct kind、Full-access null例外、current U、I→U、原time/identity；完整duplicate owner材料、删Project/Session后retained owner；每个private reason真实精确错误。 |
| 历史semantic迁移 | 扩`test/storage/schema-migration.test.ts`或独立`permission-ledger-migration.test.ts`（Root选1）：唯一U无S、S锚多U、任意slot+distinctU、完整计划验证后append、原全row/bytes/backup/time/rollback、v2 reopencurrent、currentbad DATA_INTEGRITY vs oldbadFAILEDcause。 |
| 当前capture/并发/错误 | `test/permission-two-mode.test.ts`：真实首grant+第二同scope U+slot+effect/result/407 stale；两caller同R同winner；U vs negative；U vs revoke/expire/Project deletion；sameTask多Session、不同Project；TEMP trigger真实SQL error与PK/slot冲突区别；outer/nested savepoint+真实outbox归属。 |
| pending/late Asked/Task | 现`permission-transport-hydration`、`server/session-permission-projection`、`engine-interaction-recovery`、`server/task-board-validator`：真实accepted Asked/replied交换delivery、cold/reconnect精确全集、Task原time/order/auto provenance及自然通知；不直接造frontend事件。 |
| normal/恢复闭环 | 现`session/permission-message-settlement`、`session/permission-message-retirement`、`permission-continuation-recovery`、真实`permission-execution-owner-process`：保存批准→真实Tool→completed+stale；capture未start、Tool result/Message间process cut、livepeer/unknown/dead原owner/MCP handback保原406合同。原407/source失败保留，不用旧通过数当新资格。 |
| 实际公开链 | controlled streaming Provider→公开SessionPrompt→真实外部public CSV read→真实permission user reply保存grant→第二read/结果/自然final→pending准确、history原G/U；真实HTTP sanitized500与DB503分开。不能用mock materializer或造completed消息。 |
| 物理升级 | Root复用现唯一owned process机制，最终实际v1 producer保留DB→v2 app open/semanticbackup/完整图；三方old cached/双新升级者、rollback/release/错误资格沿正式实际migrator。不能把scratch同DDL v2 probe直接当业务迁移。 |

正式runner仅Bun1.4按精确文件；触及过期负向核心测试须转为完整正向状态或删除，不能全量bun test。typecheck、正式schema/route/currentmodule-topology含clean imports均需按真实最终source重验，但不代真桌面。Root D1原closed真实数据可作为旧producer输入，不能从活用户DB迁移或写假grant；后态Main/Settings中英、Side与自然Task及必要exactSol独立bounded scopes。MCP App调用直接Authority而非普通wrapper，其Part依附原artifact Message；本batch需单独正向owner/result/retirement检查，否则保持未覆盖，不因普通Chat成功外推。

## 10. 尚待Root冻结/未知

本方案已给出推荐而非预写生产。待Root最终决定新U系统actor标识、per-request只读snapshot边界和上述两纯逻辑搬移；本轮不会自行扩大文件。历史旧eligible-read的撤销串行化不能补证；没有discriminator的slotless stale source只作审计关联；MCP remote payload/手工reconciliation更深业务不借本图校验重设计；actual semantic migration物理代码、postcommit unlock真实故障、外部ACP/channel视觉、全部Task/Mission/Provider组合仍未达成。

以原facts和source关系为依据：不由scope名称、model自述、终态标签或时钟排序推授权。所有当前图错误严格抛出，迁移失败原backup/rollback保留；所有provider执行/消息/批准来自原参与者。Root完成Recall/正式授权后才开始红→实现→绿及真实验收。
