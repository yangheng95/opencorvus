# 408 Task Permission history and pending title: current-locale plan

Read-only preparation following Root's explicit choice: if 408 exposes automatic provenance on existing Task Permission history, include its current-language rendering in the same batch. Reuse 405's canonical request/response phase parts and CardParts/TextPart path. No production, SDK, test or shared-document changes; no UI-test search/run, service, page, model or fabricated Task interaction. Root-authorized D1 tool-only corrections are tracked separately in `d1/review01-diff.patch`; their original inputs remain in `d1/review01-before/`.

Root's subsequent choices are now recorded: **missing/unknown Permission decisions produce an explicit error**; pending Task Permission heading is included at one precise `InteractionCard.tsx` presentation point using actual `payload.toolName` plus the existing localized label. Main/Side raw technical Tool names stay unchanged. Backend title remains original technical data and is never prefix-stripped. This expands the candidate frontend allowlist from three to four files only; still no production implementation authorization.

## 1. Proven current cause and exact path

`packages/overlay/src/utils/interaction.ts:106–121` already gives resolved **Questions** stable IDs `ctx:interaction:<id>:request|response` and an `interaction-question` part containing the original interaction and phase. CardParts formats it when mounted. Permissions instead fall through to `textSeed:50–64,124–135`, which calls `interactionRequestText` and `interactionResponseText` during tree construction, stores translated `text`, and derives identity from that text's hash and time.

`utils/transcript.ts:141–146` formats Permission automatic provenance with `t('interaction.auto_reply')`, then the actual scope label. Once stored in a text part, a later locale change cannot recover its original decision/automatic flag. The existing TextPart worker correctly reacts to locale changes but receives the **same pretranslated source string**, so it cannot translate that source back into facts. This is an upstream presentation-data problem, not a Markdown worker or i18n cache failure.

The request side has a second current-language issue: `engine/store.ts:684` and the permission producer in `engine/interaction.ts:327` create `Permission: <toolName>`. `interactionRequestText` currently trusts that title as display text. Its exact same raw Tool identity is already present as `payload.toolName` (`store.ts:692`, producer:335). The fix should format the product label at render time and retain the raw Tool name; no English-prefix stripping or translation of stored body/scope.

Current typed public Interaction type is `permission | question` (`engine/model.ts:301`). Production source search found the Permission producer in `EngineInteraction.upsertPermission`; the other two insertEngineInteractionRequest callers are Questions (real Question publication and Task activity reconciliation). Current Task Permission projection supplies real decision, `time.resolved`, and responseOrderKey from original ledger time. 408's backend canonical decision reader will also derive `response.auto_reply` from the **original grant_used**, never INDEX time/name or user text.

## 2. Full touched callers and ownership

| Definition or consumer | Current role / effect of proposed change |
| --- | --- |
| `utils/interaction.ts` `interactionToCardSeeds` | Sole conversion of Board/standalone interactions into conversation seeds. Pending IDs and parts remain exactly unchanged; only resolved Permission presentation gains original phase parts |
| `tree-writer.ts:3041` regroupTimelineSegments | Reads seed order keys as interaction boundaries. Preserve both exact request and response keys; the new part type does not change chronological boundaries |
| `tree-writer.ts:3816` rebuildInteractionCards | Seeds feed upsertInteractionCard and attach to the latest owning Session turn at or before the original order key. Preserve Session/Task ownership; no new Message wrapper |
| `tree-writer.ts:3878` validateConversationBoardInteractions | Checks seed identity uniqueness and order domains. Stable interaction+phase IDs remove content-dependent identity for resolved Permission; no need to edit or add a validator path |
| `tree-writer.ts:3756` upsertInteractionCard | Card ID comes from seed ID; original role/system, time/order and parts are stored. Existing alive-card pruning removes replaced old text-seed cards on rebuild; old IDs are transient UI data, not a new persistent migration |
| `CardParts.tsx:56,114–125` | Resolved Question phase part formats through existing TextPart. Generalize the same condition/helper to resolved Permission before the pending InteractionCard branch |
| `utils/transcript.ts` | Existing request/response formatting and current locale source. Existing labels cover permission request, exact scope decisions and Auto Reply; no new locale key is necessary for the smallest plan |
| `utils/interaction-dialog.ts` | Collects original interaction objects from both part types and deduplicates IDs; `pickDialogInteraction` selects only pending. Two resolved phase parts do not open a second Dialog or make a history row actionable |
| `InteractionDialogHost.tsx` | Keeps current pending selection/dismissal/reply lifecycle. No need to change its keyed Show or draft ownership |
| `utils/permission-interaction.ts` and Main/Side services | Standalone Permission is pending-only and is removed by real Replied/Terminated. Its payload currently has choices, while raw toolName is its title. This batch does not fabricate standalone answered history to reuse the new Task renderer |
| `transport-protocol/src/index.ts:674–675` | Both interaction part types already exist as renderable/display types. No new SDK/transport part type, phase schema or event is needed |
| `TextPart.tsx`, `text-part-model.ts`, `utils/i18n.ts` | Mature asynchronous Markdown pipeline; model tracks current text/localeSeq/revision, ignores stale worker responses and cleans up on unmount. `t()` reads `appStore.localeSeq` through localeValue. Existing reactive getter call is the correct boundary |

Search was restricted to production `src` trees and the named 405/current architecture records; no new or old UI tests were searched or run. Full original three sources and relevant caller excerpts will accompany this report in `task-history-source/`.

## 3. Proposed minimum implementation (not authorized by this report)

### `utils/interaction.ts`

Rename/generalize existing QuestionHistoryPhase/questionHistorySeed to a single interaction history helper for `question | permission`. It returns the same original `interaction` object and `phase`, with part type selected from the actual type (`interaction-question` / `interaction-permission`). Keep ID `ctx:interaction:<id>:<phase>`, system role, request/response orderKey and original time.

Keep pending branch exactly as delivered. Resolved Questions retain answered/rejected/expired validation and phase behavior; resolved Permissions accept current canonical answered/rejected states. Permission grant expiration remains grant history, not an invented Interaction expired status. Missing response order/time or unsupported status/type is an explicit current contract error, not a guessed phase/time.

Remove the superseded textSeed path and its formatter/hash imports from this module. All currently public Interaction types are now handled by the single existing phase-part path; retaining the generic text branch would preserve a second translated-history implementation. Current `clarification`/other-type wording in its header/doc comment does not match the current public closed type and should be corrected within this same edit.

### `utils/transcript.ts`

For a Permission request, derive the display product label from existing `t('interaction.icon.permission')`. Append the **original** nonempty `payload.toolName` as technical identity, e.g. `Permission request · read` / `权限请求 · read` using the same neutral separator. Preserve body/scope exactly as original formatter semantics (no translation or prefix stripping). The public Interaction payload is optional: if no actual Tool name is present, display only the localized generic label rather than invent a name or parse the old title. Current canonical Task producer always supplies the name; unsupported historical missing payload remains distinguishable in backend data, not repaired by UI text guessing.

Keep Question titles/body/answer content untouched. Format the Permission response from actual decision plus actual `response.auto_reply`, using existing t keys **at render time**. Root has selected replacing the current unknown/missing decision default-to-allow_once with an explicit decision contract error. `interactionReplyLabel` has only this production caller, so this stays within the same file; no new public schema or renderer. Validate the actual decision even for rejected status (which currently returns before reading it): answered requires a real allow decision, rejected requires deny; invalid/missing authority must never format as an approval. No UI formatter/text test should be added.

The only source caller of exported `hashText` is the textSeed path being removed. Source-wide `packages/**/src/**` search found no other caller. Remove that function/export header entry in the same transcript edit if the text-seed path is retired. This is scoped dead-code removal and immutable identity replacement; it is not a claim that every hash is an invalid acceptance gate or permission to remove unrelated protocol digests.

### `components/CardParts.tsx`

Rename questionHistoryText to a shared interactionHistoryText (or equivalent single existing helper), and extend the resolved phase Match to both known interaction types. Both request and response use the same `TextPart text={...}` reactive expression. Keep this Match before the pending InteractionCard branch. Preserve unknown-phase explicit error, original Markdown behavior, body spacing, system role and current TextPart worker ownership. No CSS, new renderer, replacement messages, locale key, selection control, CardTree or reply-service edit is required.

These changes alter derived rendering only. Do not write translated body/title back to Board, ledger, card source interaction or backend payload; do not add getLocale to tree-writer to rebuild identities on every language switch; do not key/remount on language or create per-locale caches.

### `components/InteractionCard.tsx` — Root-selected fourth file

Add optional `toolName?: string` to the existing payload presentation type. Replace only the displayed title accessor/JSX binding: for Permission with the existing structured payload Tool name, format that actual name with the current `t('interaction.icon.permission')`; otherwise preserve the original current title used by standalone Main/Side and Question. Main/Side normalizer currently places the technical Tool name in title and choices-only in payload, while canonical Task Permission supplies payload.toolName. This is real structured data selection, not an English-title test, endpoint rewrite or new Task owner field.

To avoid duplicating the product title formula between history and pending controls, extract the small Permission-title formatter into the already-touched transcript utility and call it from both existing presentation locations. No new module or stored title source is needed. Keep the current icon, its localized aria-label, Show structure, body, controls, reply route, mutex, drafts and afterReply capture unchanged. Backend producers remain untouched for this title concern: their original technical title/payload are still intact.

## 4. Lifecycle, language and semantic boundaries

The request/response pair has two stable presentation identities owned by one original interaction. Changing locale reruns the TextPart prop formatting through `t()`; it does not construct a new Request, choose another decision, reattach history to a newer Session turn, or submit a reply. Request/response order and times are supplied by backend, including the old original grant capture time after an approved INDEX; the renderer does not infer them.

Original user/model words, technical Tool IDs, scope JSON, Request IDs and human reply content stay original. `interaction.auto_reply` is the existing generic label (“Auto Reply” / “自动回复”), currently shared with automatic Question answers. Reusing it is the minimum consistent behavior; if product wording should explicitly say “saved approval applied”, that is an additional semantic-label decision with exact en/zh keys, not a reason to infer provenance from source grant actor/reason or to relabel all automatic Questions.

The selected fourth-file point addresses the current pending Task heading that formerly displayed the backend's English title directly. Root must visually verify both pending inline/Dialog title and resolved history during same-page language switches. Main/Side technical Tool title remains original; standalone settled permissions still leave the pending projection rather than gaining history cards. Historical incomplete payload does not authorize reconstructing a Tool name from English prose.

The stable IDs also avoid two same-time, same-translated-response Permission interactions colliding solely because their text hashes match. This is a source-level consequence, **not** an independently reproduced new defect or a reason for an extra UI test. Every positive behavior still needs Root's real page evidence where naturally reachable.

## 5. Support checks and real desktop acceptance

After Root approves exact source changes: focused overlay typecheck, private Node/Vite build under the existing owned deadline; no source-string/formatter/DOM/render/snapshot/browser test. These support compilation only. Backend canonical graph/error/provenance tests remain in the backend scope and are not replaced by UI checks.

Root's real Task page should first record a natural pending Permission and actual human resolution. Confirm both historical request and response, raw Tool name/body, scope label and original times. Switch English→Chinese→English in the same page/session and review actual screenshots, plus cold reopen ordering. Exercise natural answered and rejected rows where allowed; original pending controls/keyboard/Question draft behavior remains current.

An automatic grant reuse often emits **no Asked** and thus creates no Task Interaction. Do not seed an interaction, set auto_reply in a helper, rewrite a Board response or use a static text flag to fabricate its visual acceptance. If a real already-Asked request naturally settles by grant reuse, capture that real card and automatic response. Otherwise label the auto provenance/arrival-order path backend/protocol-qualified only and keep its specific desktop arrival unverified; a human-resolved Task history page does not replace that evidence.

D1 Main/Settings naturally verifies the actual grant graph and Settings records, but **cannot** alone qualify this Task history renderer because standalone Permission projection remains pending-only. Mobile/external ACP/channel and every Task/Mission workflow are not included by this small visual change.

## 6. State

The Root-selected candidate allowlist is exactly `utils/interaction.ts`, `utils/transcript.ts`, `components/CardParts.tsx` and the one heading presentation point in `components/InteractionCard.tsx`, including scoped removal of obsolete text-seed/hash code. Strict invalid-decision errors and pending Task title are selected as above; pending owner/data/reply/SDK contracts remain unchanged. All actual UI and automatic-arrival proof remains pending. No production file has been edited.

## 7. Final 408 implementation supplement — awaiting Root spec entry

User now requires completing the known issues in this batch and stopping; no next iteration. Root has selected the backend event `grant_decision_indexed` and revision2. Its sole purpose is to point at the original grant_used; its own timestamp is actual indexing/migration time, not permission capture time. This UI supplement does not select a winner or resolve source_event_id itself. Root owns the fixture/catalog/Memory repair and all physical/UI acceptance.

Current exact seven-file scope: the four files above, `components/settings/PermissionsPanel.tsx`, and one private event key in each `i18n/en-US.json` / `zh-CN.json`. All seven originals plus existing diff are saved in `implementation-before01/`. The five code files were clean at capture. Each language has seven peer additions (five channel keys and two project_runtime keys); those remain verbatim. No SDK, public type, backend, CSS, locale remount, new component or shared documentation edit is included.

Re-read current production source confirms all four-history-path observations still apply: only textSeed calls hashText in production; only the Permission response formatter calls interactionReplyLabel; tree-writer has three seed consumers, while dialog collection deduplicates the same original interaction and selects only pending. The one phase renderer dispatches through TextPart. Pending Question and Permission seeds, reply mutex/source/authority/selectEpoch, Question option/draft ownership and all U3 layout work remain unchanged.

Precise implementation:

1. Generalize `questionHistorySeed`/phase to the existing shared original-interaction history seed for known question/permission. Preserve exact `ctx:interaction:<id>:<phase>`, original request/response order and original authority times. Question allows answered/rejected/expired; Permission allows answered/rejected only. Unsupported type/status/time/order is an explicit contract error. Delete the replaced translated textSeed, its imports and the now-unreferenced hashText function/header. No parallel old text path.
2. Add one small `permissionRequestTitle(toolName)` formatter to the existing transcript utility: current `interaction.icon.permission` plus original nonempty technical name; absent structured name uses that localized generic label. Permission history calls it directly. The single pending InteractionCard title accessor calls it only when a real `payload.toolName` is present; standalone Main/Side choices-only payload retains original technical title, Question title unchanged. No stored-body changes or English-prefix stripping.
3. Permission responses accept only allow_once/allow_task/allow_project/deny. Missing or unknown decision throws an explicit contract error. Answered+deny or rejected+allow is also an explicit mismatch error; rejected cannot bypass inspecting the actual decision. Original `response.auto_reply === true` adds the current existing Auto Reply label. No guessed allow_once, no index timestamp or actor-based provenance inference.
4. CardParts extends its existing resolved-phase Match to interaction-permission, ahead of the pending InteractionCard Match, and uses the same reactive TextPart formatter for request/response. Unknown phase remains an explicit error. No second renderer or language-keyed owner.
5. PermissionsPanel adds `grant_decision_indexed` to its existing event-label map. The exact private key is `permissions.event.grant_decision_indexed`, proposed labels `Historical grant decision indexed` / `历史批准决定已索引`. It is a neutral timeline entry, not another approval/reply. Existing per-event `event.time_created` rendering already gives its true actual indexing date/time (localized visible time, exact ISO title); do not backdate or copy U's timestamp into I.
6. `operationStatus` preserves execution-first semantics. Its non-execution search skips both requested and grant_decision_indexed, then selects the actual requested row only if no business delta exists. An all-index/no-request group is an explicit incomplete-history error, not a fabricated approval. Current `PermissionAuthority.history` returns all project rows ordered by descending rowid without pagination, so a valid canonical indexed operation includes its requested/source/business rows. UI does not dereference I or derive scope from it. Existing approval-scope finder already explicitly uses allowed_once/grant_created/grant_used/denied and ignores I; retain it. Current project owner grouping remains unchanged.

Source evidence for added Settings scope: PermissionsPanel:42–59 eventLabels; 80–82 localized time; 131–150 execution-first status plus current broad latest-nonrequested branch (would incorrectly let new indexing overwrite an unexecuted operation's status); 305–359 status/approval/timeline rendering. Authority:1450–1458 returns complete newest-first history; route permission:56–68 exposes that array. The backend canonical validator owns graph completeness. The local UI event type remains its existing private string; closed public LedgerEvent is backend-owned and no SDK mutation is made here.

Support and verification: Root first records this exact supplement in spec, then implementation may begin. Only focused typecheck and mature private Node/Vite build are allowed if separately scheduled; no UI/formatter/source-text/DOM/render/snapshot tests and no existing UI-test scan. Root must use real development /ui for same-mounted Settings timeline/status/date language switches, natural Task pending/history and original actual automatic provenance when reachable. Before02 proves Main/Settings before facts but not Task history or same-mounted General. Code/build success alone does not close those visual requirements.
