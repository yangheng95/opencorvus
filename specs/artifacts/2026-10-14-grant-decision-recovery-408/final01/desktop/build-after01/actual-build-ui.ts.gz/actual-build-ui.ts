// Preparation only. Root approves and runs this one private Node/Vite build.
// Source: .tmp-message-retirement-407/build-ui.ts; no UI tests or Vite server.
import fs from 'node:fs/promises'
import path from 'node:path'
import assert from 'node:assert/strict'
import { bootstrapIsolatedTestRuntime, applyIsolatedTestUserEnvironment, removeIsolatedTestRuntime } from '../../packages/util/src/test-runtime-environment'
import { NodeProcess } from '../../packages/util/src/process-node'
import { expectedTestProcessSupervisor } from '../../packages/opencorvus/script/test-process-supervisor'

const root = path.resolve(import.meta.dir, '../..')
const stage = process.argv[2] ?? 'before'
assert(stage === 'before' || /^after\d{2}$/.test(stage), 'Explicit before or fresh afterNN build scope required')
const output = path.join(import.meta.dir, stage === 'before' ? 'build-before01' : `build-${stage}`)
const uiDirectory = path.join(root, `.tmp-grant-decision-recovery-408/ui-${stage}`)
const cwd = path.join(root, 'packages/overlay')
const startedAt = Date.now(), deadlineAt = startedAt + 600000, closeBy = deadlineAt - 60000
await fs.mkdir(output, { recursive: false })
const write = (name: string, value: unknown) => fs.writeFile(path.join(output, name), JSON.stringify(value, null, 2) + '\n', { flag: 'wx' })
const command = { executable: 'C:/Program Files/nodejs/node.exe', args: [
  '--max-old-space-size=8192', './node_modules/vite/bin/vite.js', 'build', '--config', 'vite.config.ts', '--outDir', uiDirectory,
] }
const owner: any = { parentPID: process.pid, startedAt, deadlineAt, closeBy, cwd, uiDirectory, output, command,
  childDeadlineAt: closeBy, ownership: 'owned_tree', requestKind: 'NodeProcess.run', requestStarted: false,
  requestSettled: false, admissionHandleObserved: false, admissionPromiseOutcome: 'not-observed',
  physicalJoined: false, outputJoined: false, handleSettledJoined: false, runtimeRemoved: false,
  scope: 'One current-workspace private Vite build only; no typecheck, tests, server, SDK generation or shared dist-vite',
  sourceConditions: 'Current vite.config.ts source + default client conditions; no tsconfig override or new config',
  outerExecJoin: 'Root observes original invoking exec join separately' }
let isolated: Awaited<ReturnType<typeof bootstrapIsolatedTestRuntime>> | undefined
let handle: Awaited<ReturnType<typeof NodeProcess.spawn>> | undefined
let primary: { error: unknown } | undefined
let bytes: { stdout: Uint8Array; stderr: Uint8Array } | undefined
const cleanupErrors: Array<{ step: string; error: unknown }> = []
function errorFacts(error: unknown): unknown {
  if (!(error instanceof Error)) return { value: String(error) }
  const value = error as Error & { code?: unknown }
  return { name: value.name, message: value.message, stack: value.stack,
    ...(value.code === undefined ? {} : { code: value.code }),
    ...(value.cause === undefined ? {} : { cause: errorFacts(value.cause) }),
    ...(value instanceof AggregateError ? { errors: value.errors.map(errorFacts) } : {}) }
}
const cleanup = async (step: string, action: () => Promise<unknown>) => {
  try { await action() } catch (error) { cleanupErrors.push({ step, error }) }
}
try {
  try { await fs.stat(uiDirectory); throw new Error('Preserve existing private UI output; fresh build target required') }
  catch (error) { if ((error as NodeJS.ErrnoException).code !== 'ENOENT') throw error }
  await fs.copyFile(import.meta.filename, path.join(output, 'actual-build-ui.ts'), 1)
  for (const name of ['package.json', 'vite.config.ts', 'tsconfig.json']) {
    await fs.copyFile(path.join(cwd, name), path.join(output, 'actual-overlay-' + name + '.txt'), 1)
  }
  await fs.stat(command.executable); await fs.stat(path.join(cwd, command.args[1]))
  isolated = await bootstrapIsolatedTestRuntime('runner')
  applyIsolatedTestUserEnvironment(isolated)
  owner.runtimeOwner = isolated
  const supervisor = expectedTestProcessSupervisor()
  assert(supervisor && (await fs.stat(supervisor)).size > 0, 'Existing prebuilt native supervisor is required')
  process.env.OPENCORVUS_PROCESS_SUPERVISOR = supervisor
  const environment = Object.fromEntries(Object.entries(process.env).filter(([name]) => /^(PATH|SystemRoot|WINDIR|ComSpec|PATHEXT|HOME|HOMEDRIVE|HOMEPATH|USERPROFILE|APPDATA|LOCALAPPDATA|TEMP|TMP|TMPDIR|XDG_CONFIG_HOME|XDG_DATA_HOME|XDG_CACHE_HOME|XDG_STATE_HOME|OPENCORVUS_(TEST_|HOME))/i.test(name)))
  environment.OPENCORVUS_PROCESS_SUPERVISOR = supervisor
  owner.environmentNames = Object.keys(environment).sort()
  await write('scope-start.json', owner)
  assert(Date.now() < closeBy, 'Original build admission deadline')
  owner.requestStarted = true
  const result = await NodeProcess.run({ command, cwd, env: environment, ownership: 'owned_tree', windowsHide: true,
    stdin: 'ignore', deadlineAt: closeBy, nothrow: true,
    onSpawned(value) {
      handle = value; owner.admissionHandleObserved = true; owner.admissionPromiseOutcome = 'fulfilled'
      owner.pid = value.pid; owner.occurrenceID = value.occurrenceID; owner.admittedAt = Date.now()
      console.log(JSON.stringify({ phase: 'started', pid: value.pid, occurrenceID: value.occurrenceID, deadlineAt: closeBy }))
    },
  }).finally(() => { owner.requestSettled = true; owner.requestSettledAt = Date.now() })
  bytes = { stdout: result.stdout, stderr: result.stderr }; owner.runReceipt = result.receipt
  assert(handle, 'Successful NodeProcess.run must expose the actual original handle')
  owner.physicalReceipt = await handle.terminal; owner.physicalJoined = true
  await handle.outputSettled; owner.outputJoined = true
  owner.settledReceipt = await handle.settled; owner.handleSettledJoined = true
  assert.deepEqual(owner.physicalReceipt, result.receipt); assert.deepEqual(owner.settledReceipt, result.receipt)
  assert.equal(result.receipt.reason, 'exited'); assert.equal(result.receipt.exitCode, 0)
  owner.indexFileBytes = (await fs.stat(path.join(uiDirectory, 'index.html'))).size
} catch (error) {
  primary = { error }
  // Preserve buffers explicitly exposed by the real Process error; no re-run.
  const failure = error as { stdout?: unknown; stderr?: unknown; result?: { stdout?: unknown; stderr?: unknown } }
  const original = failure?.result ?? failure
  if (!bytes && original?.stdout instanceof Uint8Array && original?.stderr instanceof Uint8Array) {
    bytes = { stdout: original.stdout, stderr: original.stderr }
  }
} finally {
  if (handle && !owner.physicalJoined) {
    await cleanup('settle original owned builder after failed run', async () => { owner.terminationReceipt = await handle!.terminate('aborted') })
    await cleanup('observe original builder physical receipt', async () => { owner.physicalReceipt = await handle!.terminal; owner.physicalJoined = true })
  }
  if (handle && !owner.outputJoined) await cleanup('observe original builder output settlement', async () => { await handle!.outputSettled; owner.outputJoined = true })
  if (handle && !owner.handleSettledJoined) await cleanup('observe original builder handle settlement', async () => { owner.settledReceipt = await handle!.settled; owner.handleSettledJoined = true })
  if (bytes) {
    await cleanup('persist complete original build stdout', () => fs.writeFile(path.join(output, 'build.stdout.log'), bytes!.stdout, { flag: 'wx' }))
    await cleanup('persist complete original build stderr', () => fs.writeFile(path.join(output, 'build.stderr.log'), bytes!.stderr, { flag: 'wx' }))
  }
  const closed = owner.requestStarted && owner.requestSettled && owner.admissionHandleObserved && owner.physicalJoined && owner.outputJoined && owner.handleSettledJoined
  const normal = owner.physicalReceipt?.reason === 'exited' && owner.physicalReceipt.exitCode === 0
  if (owner.requestStarted && (!closed || !normal)) cleanupErrors.push({ step: 'validate actual builder terminal', error: new Error(JSON.stringify({ closed, normal, receipt: owner.physicalReceipt })) })
  if (isolated) {
    if (!owner.requestStarted || closed) await cleanup('remove exact settled build environment', async () => { await removeIsolatedTestRuntime(isolated!); owner.runtimeRemoved = true })
    else owner.runtimeRetainedReason = 'Incomplete original process/request/output settlement'
  }
  owner.finishedAt = Date.now(); owner.closed = Boolean(closed)
  owner.primaryError = primary ? errorFacts(primary.error) : null
  owner.cleanupErrors = cleanupErrors.map(({ step, error }) => ({ step, error: errorFacts(error) }))
  owner.status = !primary && cleanupErrors.length === 0 && closed && normal ? 'built' : 'failed'
  await cleanup('persist actual build exit', () => fs.writeFile(path.join(output, 'build.exit'), String(owner.physicalReceipt?.exitCode ?? 1), { flag: 'wx' }))
  owner.cleanupErrors = cleanupErrors.map(({ step, error }) => ({ step, error: errorFacts(error) }))
  if (cleanupErrors.length) owner.status = 'failed'
  await cleanup('persist original build scope terminal', () => write('scope-final.json', owner))
  owner.cleanupErrors = cleanupErrors.map(({ step, error }) => ({ step, error: errorFacts(error) }))
  if (cleanupErrors.length) owner.status = 'failed'
  process.exitCode = owner.status === 'built' ? 0 : 1
  console.log(JSON.stringify(owner))
  if (primary || cleanupErrors.length) console.error(new AggregateError(
    [...(primary ? [primary.error] : []), ...cleanupErrors.map(entry => entry.error)],
    'Private UI build or original evidence settlement failed', primary ? { cause: primary.error } : undefined,
  ))
}
