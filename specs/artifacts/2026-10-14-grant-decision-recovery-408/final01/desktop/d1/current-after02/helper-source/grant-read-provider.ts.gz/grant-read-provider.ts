// Scratch-only adaptation of controlled-streaming-provider.ts.
// Two human turns: request 1 -> real read, request 2 -> final;
// request 3 -> the same real read scope, request 4 -> final. No decision API.
import { controlledMemoryReply, controlledProviderRequestKind } from '../../../packages/opencorvus/test/fixture/controlled-streaming-provider'

export function startGrantReadProvider(filePath: string, taskFilePath: string) {
  const observations: Array<Record<string, unknown>> = []
  let promptCount = 0
  const server = Bun.serve({
    hostname: '127.0.0.1', port: 0, idleTimeout: 255,
    async fetch(request) {
      const observedAt = Date.now()
      const body = await request.json() as any
      const messages = Array.isArray(body?.messages) ? body.messages : []
      const kind = controlledProviderRequestKind(messages)
      const ordinal = kind === 'prompt' ? ++promptCount : 0
      const record: Record<string, unknown> = {
        index: observations.length, kind, ordinal, observedAt, model: body?.model,
        stream: body?.stream, method: request.method, pathname: new URL(request.url).pathname,
        toolNames: Array.isArray(body?.tools) ? body.tools.map((tool: any) => tool?.function?.name) : [],
      }
      observations.push(record)
      if (request.method !== 'POST' || body?.stream !== true || (kind === 'prompt' && ordinal > 6)) {
        record.status = 400
        return Response.json({ error: { message: 'The bounded public fixture requires streaming POST: two Main read turns and one Task read turn.' } }, { status: 400 })
      }
      const readOrdinal = ordinal === 1 ? 1 : ordinal === 3 ? 2 : ordinal === 5 ? 3 : undefined
      if (readOrdinal && !(record.toolNames as string[]).includes('read')) {
        record.status = 400
        return Response.json({ error: { message: 'The real request did not project the read Tool.' } }, { status: 400 })
      }
      const toolCall = readOrdinal ? {
        index: 0, id: `call_public_grant_408_read_${readOrdinal}`, type: 'function',
        function: { name: 'read', arguments: JSON.stringify({ filePath: readOrdinal === 3 ? taskFilePath : filePath }) },
      } : undefined
      const content = kind === 'memory'
        ? controlledMemoryReply(messages)
        : `provider reply ${ordinal}`
      if (kind === 'memory') {
        const candidate = JSON.parse(content)
        record.memoryCandidate = { baseRevision: candidate.baseRevision, coveredOccurrenceIDs: candidate.coveredOccurrenceIDs,
          disposition: candidate.disposition, markdownLength: candidate.markdown.length }
      }
      const base = { id: `chatcmpl-public-grant-408-${record.index}`, object: 'chat.completion.chunk', created: Math.floor(Date.now() / 1000), model: 'session-prompt-owner-model' }
      const chunks = [
        { ...base, choices: [{ index: 0, delta: { role: 'assistant' }, finish_reason: null }] },
        { ...base, choices: [{ index: 0, delta: toolCall ? { tool_calls: [toolCall] } : { content }, finish_reason: null }] },
        { ...base, choices: [{ index: 0, delta: {}, finish_reason: toolCall ? 'tool_calls' : 'stop' }] },
      ]
      record.status = 200; record.responseConstructedAt = Date.now(); record.toolCallID = toolCall?.id
      record.boundary = 'Response construction is not proof that the model client consumed EOF. Actual Tool and final Message must be observed separately.'
      return new Response(`${chunks.map(chunk => `data: ${JSON.stringify(chunk)}\n\n`).join('')}data: [DONE]\n\n`, {
        headers: { 'content-type': 'text/event-stream', 'cache-control': 'no-cache', connection: 'close' },
      })
    },
  })
  return { server, observations, apiURL: `http://127.0.0.1:${server.port}/v1` }
}
