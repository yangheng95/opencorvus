// Prepared scratch. Adapted from the owned 404 Task driver; never auto-run.
import fs from 'node:fs/promises'
import path from 'node:path'
import os from 'node:os'
import assert from 'node:assert/strict'
import { bootstrapIsolatedTestRuntime, applyIsolatedTestUserEnvironment, removeIsolatedTestRuntime } from '../../../packages/util/src/test-runtime-environment'
import { NodeProcess } from '../../../packages/util/src/process-node'
import { prepareTestProcessSupervisor } from '../../../packages/opencorvus/script/prepare-test-process-supervisor'
import { createManagedTemporaryDirectory } from '../../../packages/util/src/runtime-directories'

const [scope, uiDirectory] = process.argv.slice(2)
const scratch = path.resolve(import.meta.dir), repo = path.resolve(scratch, '../../..')
assert(scope && uiDirectory && path.isAbsolute(scope) && path.isAbsolute(uiDirectory))
assert.equal(path.dirname(path.resolve(scope)), scratch)
await fs.stat(path.join(uiDirectory, 'index.html'))
const startedAt = Date.now(), deadlineAt = startedAt + 600000, closeBy = deadlineAt - 60000
await fs.mkdir(scope, { recursive: false })
await fs.mkdir(path.join(scope, 'helper-source'))
const write = (name: string, value: unknown) => fs.writeFile(path.join(scope, name), JSON.stringify(value, null, 2) + '\n', { flag: 'wx' })
for (const name of ['grant-read-driver.ts', 'grant-read-server.ts', 'grant-read-provider.ts', 'grant-read-control.mjs', 'grant-read-facts.mjs']) {
  await fs.copyFile(path.join(scratch, name), path.join(scope, 'helper-source', name), 1)
}
// Allocate outside the checkout BEFORE the temporary user environment changes TEMP.
// This exact separate owned directory intentionally survives parent cleanup.
const retainedRoot = await createManagedTemporaryDirectory(path.resolve(os.tmpdir()), 'opencorvus-grant-408-retained-')
const retainedRuntime = path.join(retainedRoot, 'runtime-root')
await write('driver-context.json', { parentPID: process.pid, startedAt, deadlineAt, closeBy, scope, uiDirectory, retainedRoot, retainedRuntime,
  purpose: '408 D1 original grant reuse before input; controlled streaming, human decisions and visible real messages',
  runtimeRetention: 'The exact separately owned retainedRoot and public input are preserved after physical close for later reviewed migration. Temporary user/tool environment is removed after join; no live DB copy or user runtime is used.' })
const isolated = await bootstrapIsolatedTestRuntime('runner')
applyIsolatedTestUserEnvironment(isolated)
await write('driver-runtime-owner.json', isolated)
let product: Awaited<ReturnType<typeof NodeProcess.spawn>> | undefined
let drains: Promise<PromiseSettledResult<void>[]> | undefined
let receipt: unknown, physicalJoined = false, outputJoined = false
const failures: string[] = []
try {
  const supervisor = prepareTestProcessSupervisor()
  const env = Object.fromEntries(Object.entries(process.env).filter(([name]) => /^(PATH|SystemRoot|WINDIR|ComSpec|PATHEXT|HOME|HOMEDRIVE|HOMEPATH|USERPROFILE|APPDATA|LOCALAPPDATA|TEMP|TMP|TMPDIR|XDG_CONFIG_HOME|XDG_DATA_HOME|XDG_CACHE_HOME|XDG_STATE_HOME|OPENCORVUS_(TEST_|HOME))/i.test(name)))
  if (supervisor) { env.OPENCORVUS_PROCESS_SUPERVISOR = supervisor; process.env.OPENCORVUS_PROCESS_SUPERVISOR = supervisor }
  assert(Date.now() < closeBy, 'Original preparation deadline')
  const command = { executable: path.join(repo, '.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64/bun.exe'),
    args: [path.join(scratch, 'grant-read-server.ts'), scope, uiDirectory, String(deadlineAt)] }
  product = await NodeProcess.spawn({ command, cwd: repo, ownership: 'owned_tree', windowsHide: true, stdin: 'ignore', env, deadlineAt })
  const drain = async (stream: any, name: string) => { if (stream) for await (const bytes of stream) await fs.appendFile(path.join(scope, name), bytes) }
  drains = Promise.allSettled([drain(product.stdout, 'stdout.log'), drain(product.stderr, 'stderr.log')])
  await write('product-launch.json', { command, cwd: repo, pid: product.pid, occurrence: product.occurrenceID,
    startedAt, deadlineAt, closeBy, environmentNames: Object.keys(env).sort() })
  receipt = await product.settled; physicalJoined = true
  for (const result of await drains) if (result.status === 'rejected') failures.push(`Output drain: ${String(result.reason)}`)
  await product.outputSettled; outputJoined = true
  const actual = receipt as { reason?: string; exitCode?: number }
  if (actual.reason !== 'exited' || actual.exitCode !== 0) failures.push(`Product terminal: ${JSON.stringify(receipt)}`)
} catch (error) { failures.push(String(error)) }
finally {
  if (product && !physicalJoined) {
    try { await write('stop-requested.json', { reason: 'Original driver error settlement', requestedAt: Date.now(), deadlineAt, productPID: product.pid, productOccurrence: product.occurrenceID }) } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== 'EEXIST') failures.push(`Stop request: ${String(error)}`)
    }
    try { receipt = await product.settled; physicalJoined = true } catch (error) { failures.push(`Physical join: ${String(error)}`) }
    if (drains) for (const result of await drains) if (result.status === 'rejected') failures.push(`Output drain: ${String(result.reason)}`)
    try { await product.outputSettled; outputJoined = true } catch (error) { failures.push(`Output join: ${String(error)}`) }
  }
  let temporaryEnvironmentRemoved = false
  if (!product || (physicalJoined && outputJoined)) {
    try { await removeIsolatedTestRuntime(isolated); temporaryEnvironmentRemoved = true } catch (error) { failures.push(`Temporary environment cleanup: ${String(error)}`) }
  }
  await write('driver-terminal.json', { startedAt, deadlineAt, closeBy, finishedAt: Date.now(), productPID: product?.pid,
    productOccurrence: product?.occurrenceID, receipt, physicalJoined, outputJoined, requestSettled: physicalJoined,
    temporaryEnvironmentRemoved, retainedRoot, retainedRuntime, failures,
    boundary: 'Runtime intentionally retained locally; this is not an archive or migration result.' })
  if (failures.length) { console.error(JSON.stringify(failures)); process.exitCode = 1 }
  else console.log(JSON.stringify({ closed: true, receipt, scope, retainedRoot, retainedRuntime }))
}
