import fs from 'node:fs/promises'
import path from 'node:path'
import assert from 'node:assert/strict'
const [scope,mode='observe']=process.argv.slice(2)
const ready=JSON.parse(await fs.readFile(path.join(scope,'ready.json'),'utf8'))
const accepted=JSON.parse(await fs.readFile(path.join(scope,'task-start.json'),'utf8'))
const taskID=accepted.acceptance.task_id, directory=accepted.acceptance.directory
const startedAt=Date.now(),deadlineAt=Math.min(startedAt+30000,ready.closeBy)
assert(deadlineAt>startedAt)
const responses=[]
for(const route of [`/task/${taskID}/board`,`/task/${taskID}/interactions`,'/permission/history','/permission']){
 const response=await fetch(new URL(route,ready.url),{headers:{'x-opencorvus-directory':directory},signal:AbortSignal.timeout(deadlineAt-Date.now())})
 responses.push({route,status:response.status,body:await response.json()})
}
await fs.writeFile(path.join(scope,`task-${mode}-${startedAt}.json`),JSON.stringify({taskID,directory,startedAt,deadlineAt,responses},null,2),{flag:'wx'})
for(const r of responses)assert.equal(r.status,200)
const interactions=responses[1].body
assert(Array.isArray(interactions))
const permission=interactions.find(x=>x.type==='permission')
assert(permission)
assert.equal(permission.status,'answered'); assert.equal(permission.response.decision,'allow_task')
const history=responses[2].body
const owner=history.find(x=>x.event_type==='requested'&&x.task_id===taskID)
assert(owner)
const decision=history.find(x=>x.decision_slot===owner.request_id)
assert.equal(decision.event_type,'grant_created');assert.equal(decision.decision_scope,'task')
assert.equal(permission.time.resolved,decision.time_created)
const failed=history.find(x=>x.request_id===owner.request_id&&x.event_type==='execution_failed')
assert(failed?.attempt_id); assert.equal(failed.outcome_slot,failed.attempt_id)
assert(failed.reason.startsWith('TaskProcessBoundaryError:'))
assert(failed.reason.includes(taskID)); assert(failed.reason.includes('outside exact process root'))
const started=history.find(x=>x.request_id===owner.request_id&&x.event_type==='execution_started')
assert.equal(started.attempt_id,failed.attempt_id);assert.equal(started.source_event_id,decision.id)
await fs.writeFile(path.join(scope,`task-${mode}-${startedAt}.check.json`),JSON.stringify({passed:true,taskID,permissionID:permission.id,requestID:owner.request_id,decisionID:decision.id,timeResolved:decision.time_created,taskStatus:responses[0].body.task?.status,boundary:'Actual local Task/Authority/Engine HTTP facts; no UI assertion or actual model completion claim'},null,2),{flag:'wx'})
console.log(JSON.stringify({taskID,permissionID:permission.id,requestID:owner.request_id,decisionID:decision.id,passed:true}))
if(mode==='cancel' && responses[0].body.task.status==='active'){
 const response=await fetch(new URL(`/task/${taskID}/cancel`,ready.url),{method:'POST',headers:{'content-type':'application/json','x-opencorvus-directory':directory},
 body:JSON.stringify({surface:'api',reason:'Root closes its bounded public 408 desktop fixture after actual permission acceptance; no model Task completion claim.'}),signal:AbortSignal.timeout(deadlineAt-Date.now())})
 const body=await response.json()
 await fs.writeFile(path.join(scope,`own-task-cancel-${startedAt}.json`),JSON.stringify({taskID,status:response.status,body,startedAt,deadlineAt},null,2),{flag:'wx'})
 assert.equal(response.status,202)
 console.log(JSON.stringify({taskID,cancellation:body}))
}
