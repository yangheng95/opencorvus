import fs from 'node:fs/promises'
import path from 'node:path'
import assert from 'node:assert/strict'
import { Database as SQLite } from 'bun:sqlite'
import { queryAllFinalized as all } from '../../../packages/opencorvus/src/storage/sqlite-statement'
const scope=path.resolve(import.meta.dir,'legacy-after01')
const ready=JSON.parse(await fs.readFile(path.join(scope,'ready.json'),'utf8'))
const closed=JSON.parse(await fs.readFile(path.join(scope,'driver-terminal.json'),'utf8'))
assert.equal(closed.status,'closed');assert.equal(closed.physicalReceipt.exitCode,0)
assert(closed.requestSettled&&closed.physicalJoined&&closed.outputJoined&&closed.handleSettledJoined)
const before=JSON.parse(await fs.readFile(path.join(scope,'before-upgrade.json'),'utf8'))
const dbPath=path.join(ready.runtime,'data/opencorvus.db')
const readFacts=(name:string)=>{
 const db=new SQLite(name,{readonly:true})
 try{return {version:all<any>(db,'PRAGMA user_version')[0].user_version,
 identity:all(db,'SELECT * FROM database_authority ORDER BY key'),ledger:all(db,'SELECT rowid,* FROM permission_ledger ORDER BY rowid'),
 results:all(db,'SELECT * FROM permission_execution_result ORDER BY attempt_id'),
 tableCounts:all<any>(db,"SELECT name FROM sqlite_schema WHERE type='table' ORDER BY name").map(row=>({name:row.name,rows:all<any>(db,`SELECT count(*) AS n FROM "${row.name.replaceAll('"','""')}"`)[0].n}))}
 }finally{db.close(true)}
}
const current=readFacts(dbPath)
assert.equal(before.version,1);assert.equal(current.version,2)
assert.deepEqual(current.identity,before.identity)
assert.deepEqual(current.ledger.slice(0,before.ledger.length),before.ledger)
assert.deepEqual(current.results,before.results)
const candidates=(await fs.readdir(path.join(ready.runtime,'data/migration-backups'))).filter(name=>name.endsWith('.sqlite'))
assert.equal(candidates.length,1)
const backupPath=path.join(ready.runtime,'data/migration-backups',candidates[0])
const backup=readFacts(backupPath)
assert.equal(backup.version,1);assert.deepEqual(backup.identity,before.identity)
assert.deepEqual(backup.ledger,before.ledger);assert.deepEqual(backup.results,before.results)
await fs.writeFile(path.join(scope,'closed-data-comparison.json'),JSON.stringify({passed:true,observedAt:Date.now(),sourceScope:scope,
 originalRows:before.ledger.length,originalResults:before.results.length,current,backup,backupPath,backupBytes:(await fs.stat(backupPath)).size,
 boundary:'Original closed public producer rows/identity/results exactly preserved and actual full v1 backup reopened. Table counts report real retained backup contents; binary DB/config/catalog/auth is excluded from archive. No hash acceptance.'},null,2),{flag:'wx'})
console.log(JSON.stringify({passed:true,originalRows:before.ledger.length,originalResults:before.results.length,backupTables:backup.tableCounts.length,version:current.version}))
