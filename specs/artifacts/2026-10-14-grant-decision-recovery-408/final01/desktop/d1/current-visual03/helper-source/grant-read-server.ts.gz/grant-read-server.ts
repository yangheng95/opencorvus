// Prepared only. Root must approve source before any execution.
import fs from 'node:fs/promises'
import path from 'node:path'
import assert from 'node:assert/strict'
import { phaseBConfig } from '../../../.tmp-native-shutdown-pending-permission-403/phase-b-input'

const [scope, uiDirectory, rawDeadline] = process.argv.slice(2)
const helperDirectory = path.resolve(import.meta.dir)
assert(scope && uiDirectory && path.isAbsolute(scope) && path.isAbsolute(uiDirectory))
assert.equal(path.dirname(path.resolve(scope)), helperDirectory)
const driver = JSON.parse(await fs.readFile(path.join(scope, 'driver-context.json'), 'utf8'))
const deadlineAt = Number(rawDeadline), closeBy = deadlineAt - 60000, startedAt = Date.now()
assert.equal(deadlineAt, driver.deadlineAt)
assert(Number.isSafeInteger(deadlineAt) && deadlineAt > startedAt && deadlineAt <= startedAt + 600000)
const write = (name: string, value: unknown) => fs.writeFile(path.join(scope, name), JSON.stringify(value, null, 2) + '\n', { flag: 'wx' })
assert(driver.retainedRoot && path.isAbsolute(driver.retainedRoot))
const runtime = path.join(driver.retainedRoot, 'runtime-root')
assert.equal(runtime, driver.retainedRuntime)
assert.equal(process.env.OPENCORVUS_TEST_PROCESS_ROOT, driver.retainedRoot)
assert.equal(process.env.OPENCORVUS_HOME, runtime)
const project = path.join(driver.retainedRoot, 'bootstrap-project')
const externalFile = path.join(driver.reuseScope ?? scope, 'public-external.csv')
const taskFile = path.join(driver.reuseScope ?? scope, 'public-task.csv')
assert((await fs.stat(runtime)).isDirectory(), 'Original bootstrap runtime must already exist')
if (driver.reuseScope) {
  assert((await fs.stat(project)).isDirectory())
  assert.equal(await fs.readFile(externalFile, 'utf8'), 'item,quantity\nCedar408,3\nIris408,4\n')
} else {
  await fs.mkdir(project, { recursive: false })
  await fs.writeFile(externalFile, 'item,quantity\nCedar408,3\nIris408,4\n', { flag: 'wx' })
  await fs.writeFile(taskFile, 'item,quantity\nTask408,5\n', { flag: 'wx' })
}
const catalog = path.join(runtime, 'data', 'models.json')
process.env.OPENCORVUS_MODELS_PATH = catalog
process.env.OPENCORVUS_PROJECT_DIR = project
process.env.OPENCORVUS_DISABLE_AUTOUPDATE = '1'
process.env.OPENCORVUS_DISABLE_EXTERNAL_SKILLS = '1'
process.env.OPENCORVUS_DISABLE_CLAUDE_CODE = '1'
process.env.OPENCORVUS_RUNTIME_MEMORY_METRICS_INTERVAL_MS = '300000'
let observed: any, provider: any, poll: ReturnType<typeof setInterval> | undefined
let closing: Promise<void> | undefined, preparationFailure: { error: unknown } | undefined
const errors: Array<{ step: string; error: unknown }> = []
function errorFacts(error: unknown): unknown {
  if (!(error instanceof Error)) return { value: String(error) }
  const value = error as Error & { code?: unknown }
  return { name: value.name, message: value.message, stack: value.stack,
    ...(value.code === undefined ? {} : { code: value.code }),
    ...(value.cause === undefined ? {} : { cause: errorFacts(value.cause) }),
    ...(value instanceof AggregateError ? { errors: value.errors.map(errorFacts) } : {}) }
}
const reserve = setTimeout(() => { void close('Original fixed close reserve reached', true) }, Math.max(1, closeBy - Date.now()))
async function close(reason: string, failed = false) {
  if (closing) return closing
  closing = (async () => {
    clearTimeout(reserve); if (poll) clearInterval(poll)
    if (observed) {
      try { await observed.server.stop(true) } catch (error) { errors.push({ step: 'product normal stop', error }) }
      try { await observed.recovery } catch (error) { errors.push({ step: 'original product recovery settlement', error }) }
    }
    if (provider) {
      try { await provider.server.stop(true) } catch (error) { errors.push({ step: 'controlled Provider normal stop', error }) }
    }
    let exitCode = failed || preparationFailure || errors.length ? 1 : 0
    try {
      await write('terminal.json', { reason, pid: process.pid, occurrence: observed?.occurrence, startedAt, deadlineAt, closeBy,
        finishedAt: Date.now(), preparationFailure: preparationFailure ? errorFacts(preparationFailure.error) : null,
        errors: errors.map(({ step, error }) => ({ step, error: errorFacts(error) })), requests: provider?.observations ?? [], exitCode,
        runtimeRetained: runtime, publicCSVRetained: externalFile,
        boundary: 'No model qualification. Only original driver NodeProcess receipt proves physical/output closure. Retained runtime is local input for a separately approved future migration; do not archive its DB/config wholesale.' })
    } catch (error) { errors.push({ step: 'persist original server terminal', error }); exitCode = 1 }
    if (preparationFailure || errors.length) console.error(new AggregateError(
      [...(preparationFailure ? [preparationFailure.error] : []), ...errors.map(entry => entry.error)],
      'D1 server preparation or settlement failed; preserve the original and every cleanup/evidence error',
      preparationFailure ? { cause: preparationFailure.error } : undefined,
    ))
    process.exit(exitCode)
  })()
  return closing
}
try {
  const { writeControlledProviderCatalog } = await import('../../../packages/opencorvus/test/fixture/controlled-streaming-provider')
  if (driver.reuseScope && path.basename(driver.reuseScope) === 'current-after02') {
    assert((await fs.stat(catalog)).size > 0)
    await write('catalog-input.json', { source: 'Original complete public controlled catalog retained with the closed current producer; actual /provider preflight follows', destination: catalog })
  } else await write('catalog-input.json', await writeControlledProviderCatalog(catalog))
  const { installProcessShims } = await import('../../../packages/opencorvus/src/runtime/shims')
  installProcessShims()
  const { startGrantReadProvider } = await import('./grant-read-provider')
  provider = startGrantReadProvider(externalFile, taskFile, Boolean(driver.reuseScope && path.basename(driver.reuseScope) === 'current-after02'))
  const config = phaseBConfig(provider.apiURL)
  config.prompt_profile.active = 'research-studio'
  config.provider['shutdown-fixture'].name = 'Public 408 grant reuse fixture'
  if (driver.reuseScope) {
    const { updateGlobalConfigPatch } = await import('../../../packages/opencorvus/src/config/update-global')
    await updateGlobalConfigPatch(config)
    await write('prestart-config-settlement.json', { input: 'Current public local fixture configuration through the production global PATCH mutator',
      model: config.model, profile: config.prompt_profile.active, settledAt: Date.now() })
  }
  const { freezeOverlayUiDirectory } = await import('../../../packages/opencorvus/src/server/overlay-ui')
  const { Instance } = await import('../../../packages/opencorvus/src/project/instance')
  const { listenWithRecoveredServerRuntime } = await import('../../../packages/opencorvus/src/cli/server-runtime')
  const { recoverStartedTaskExecutions, assertStartedTaskProjectRecoverySucceeded } = await import('../../../packages/opencorvus/src/engine/host-recovery')
  observed = await listenWithRecoveredServerRuntime({
    options: { hostname: '127.0.0.1', port: 0, randomPort: true, overlayUiSource: freezeOverlayUiDirectory({ directory: uiDirectory }) },
    recover: async () => { const result = await recoverStartedTaskExecutions({ scopeProjectWorktree: project }); assertStartedTaskProjectRecoverySucceeded(result) },
    disposeInstances: () => Instance.disposeAll(),
  })
  await observed.recovery
  assert(Date.now() < closeBy, 'Preparation must finish before original close reserve')
  const base = `http://127.0.0.1:${observed.server.port}`
  const response = await fetch(base + '/global/config', {
    method: driver.reuseScope ? 'GET' : 'PATCH', headers: { 'content-type': 'application/json', 'x-opencorvus-directory': project },
    ...(driver.reuseScope ? {} : { body: JSON.stringify(config) }), signal: AbortSignal.timeout(Math.max(1, Math.min(30000, closeBy - Date.now()))),
  })
  const configured = await response.json()
  await write('public-config-response.json', { status: response.status, configured })
  assert.equal(response.status, 200)
  const preflightDeadline = Math.min(Date.now() + 30000, closeBy)
  const preflight = await Promise.all(['/expert-squad/catalog', '/skill/mounts', '/provider'].map(async route => {
    assert(Date.now() < preflightDeadline)
    const result = await fetch(base + route, { headers: { 'x-opencorvus-directory': project }, signal: AbortSignal.timeout(preflightDeadline - Date.now()) })
    return { route, status: result.status, body: await result.json() }
  }))
  await write('public-preflight.json', { directory: project, preflight })
  for (const item of preflight) assert.equal(item.status, 200, item.route)
  assert.equal((preflight[0].body as any).active?.effective, 'research-studio')
  const projected = (preflight[2].body as any).all?.find((item: any) => item.id === 'shutdown-fixture')
  assert(projected?.models?.['session-prompt-owner-model'], 'Public controlled model is actually projected')
  await write('public-input.json', { externalFile, taskFile, csv: await fs.readFile(externalFile, 'utf8'), runtime, bootstrapProject: project,
    model: 'shutdown-fixture/session-prompt-owner-model', profile: 'research-studio', permissionMode: 'ask',
    suggestedFirstPrompt: `Read the public CSV at ${externalFile} and report its rows.`,
    suggestedSecondPrompt: `Read the same public CSV at ${externalFile} again and report its rows.`,
    actualSession: 'Created only by Root explicit public start action; second prompt is typed by Root in the visible same Session composer.' })
  await write('ready.json', { pid: process.pid, occurrence: observed.occurrence, startedAt, deadlineAt, closeBy,
    port: observed.server.port, url: base + '/ui', runtime, project, externalFile, uiDirectory, scenario: 'grant-read-d1', reuseScope: driver.reuseScope,
    provider: 'public controlled streaming, two Main read turns plus one Task read turn; no real Provider credential/model qualification',
    pageAcceptance: 'Root manual interaction and original screenshots only', sessionCreated: false })
  console.log(JSON.stringify({ ready: true, url: base + '/ui', deadlineAt, closeBy, externalFile }))
  let checking = false
  poll = setInterval(async () => {
    if (checking || closing) return
    checking = true
    try {
      const stop = JSON.parse(await fs.readFile(path.join(scope, 'stop-requested.json'), 'utf8'))
      const launch = JSON.parse(await fs.readFile(path.join(scope, 'product-launch.json'), 'utf8'))
      assert.equal(stop.deadlineAt, deadlineAt); assert.equal(stop.productPID, process.pid)
      assert.equal(stop.productOccurrence, launch.occurrence)
      await close('Root explicit owned stop after page closure')
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== 'ENOENT') { preparationFailure = { error }; await close('Owned control observation failed', true) }
    } finally { checking = false }
  }, 250)
} catch (error) {
  preparationFailure = { error }; console.error(error)
  await close('Preparation failed', true)
}
