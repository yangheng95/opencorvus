# 408 D1 desktop before input — prepared, not executed

Root must read/approve these sources before starting anything. **Root's actual counterevidence ruled out clock failure as the cause of the observed Git instance:** its original output grew continuously, and a separate silent Node case reached the real 10-second timeout at 10007 ms with the three joins collected in 55 ms. This does not qualify every Task/Mission end-to-end path, and D1 itself remains unexecuted. No shared clock change, heartbeat, alternate timer or polling workaround was added. This preparation has **not** opened a database, listener, Provider, browser or model; it has not run a test, build or UI automation. Five new helpers are self-contained scratch inputs using current repository primitives. The old 402/404/405/406 files and all archived lock inputs remain unchanged. The first frozen D1 source/README/manifest and locale plan remain in `review01-before/`; `review01-diff.patch` is not rewritten. The exact reviewed driver before its synchronous-observer correction is retained in `review02-before/`, with its new correction in `review02-driver.patch`.

## Root's selected historical semantics (recorded, not yet implemented)

- An existing decision slot plus **any different slotless grant_used**, even without an execution start, is an explicit authority conflict for automatic migration. No timestamp selection. This resolves the open policy in the prior report.
- A legitimate old capture is not erased because its source grant is revoked/expired today. This does not certify old eligibility-read/capture serialization.
- Duplicate requested observations are checked for owner material, retaining the first summary/metadata/time. No blanket equality over all wording/metadata.
- Event name, semantic version, final production allowlist and actual physical upgrade qualification remain unselected. This D1 helper creates real before facts only; it implements no index or migration.

## Source allowlist and reuse

| New file | Mature source / exact adaptation |
| --- | --- |
| [grant-read-driver.ts](grant-read-driver.ts) | Mature `NodeProcess.run` whole caller request with independent fulfilled-admission observation, physical terminal, output and handle-settled receipts. Original 600000 ms scope and parent temporary-user cleanup. One product child, with its controlled Provider in the same child. Retains a separate explicitly owned OS-temp runtime for future migration |
| [grant-read-server.ts](grant-read-server.ts) | 402/404 manual server's recovered production listener, private UI freeze, public config and natural stop. Config is Ask + existing research-studio with browser/computer MCP disabled, the already qualified 404 profile choice. No initial user message, Task or permission decision is inserted at startup |
| [grant-read-provider.ts](grant-read-provider.ts) | Current `test/fixture/controlled-streaming-provider.ts` streaming SSE frame construction and exact Memory request classifier. Main prompt ordinals 1 and 3 return the real declared `read` Tool, same filePath, distinct actual call IDs; 2 and 4 return original-style `provider reply 2/4` final text. More main requests fail the fixture's explicit 400 contract. No product decision API, user message or Tool result is fabricated |
| [grant-read-control.mjs](grant-read-control.mjs) | Existing explicit owner controls. `start` requires Root-provided actual visible user text and calls only public Global Chat creation; `observe` is read-only; `stop page-closed` requests original owner settlement after Root closes its page. No API for approve/reject/revoke/abort/model switching/second message |
| [grant-read-facts.mjs](grant-read-facts.mjs) | Existing pure HTTP Question-facts pattern, now precise Permission graph/output. Original public responses are written before checks. Validates actual external-file containment, first project grant, second grant use and original execution source; records actual pending arrays. No UI, DOM, screenshots, database reads or fake complete state |

The driver copies these five exact current sources to the fresh scope's `helper-source` before launching. Reference source copies and a change map are in `source-reference/` and `prepared-source-manifest.json`. Static source/reference checks do not qualify runtime behavior.

## Original scope, paths, ports and retention

- Proposed new scope: `D:/myhexin-local/opencorvus/.tmp-grant-decision-recovery-408/ui/d1/before01`. It must not exist; neither driver nor control overwrites a previous run.
- Proposed Root-built current private UI: `D:/myhexin-local/opencorvus/.tmp-grant-decision-recovery-408/ui-before`. This preparation **does not build it or assert it exists**. Root can supply the actual reviewed current private bundle as the second absolute argument; the driver requires its index.html. Product backend is current development source; `/ui` is served by that backend, not a separate Vite process.
- Product and Provider both bind `127.0.0.1` with port 0. Exact product port and `/ui` URL appear in `ready.json`; local Provider endpoint is persisted in the isolated public configuration. No fixed/global port or user window is used.
- Deadline starts before environment/supervisor preparation: `deadlineAt = startedAt + 600000`, `closeBy = deadlineAt - 60000`. Server accepts that same original deadline. Every control checks closeBy; a public observation batch and start HTTP request have at most 30000 ms, clipped to closeBy. No budget extension or new service occurrence is hidden in a retry.
- This is a new 600 s parent/manual-interaction scope with one service child sharing that exact deadline. It does not extend or reuse any earlier 180 s lock worker. The prebuilt owned-tree supervisor must exist; this helper does not start an implicit native build.
- A separate directory is created with existing `createManagedTemporaryDirectory(os.tmpdir(), 'opencorvus-grant-408-retained-')` before isolated user TEMP is rebound. `driver-context.json.retainedRoot` is the exact retained path. Its `runtime-root` owns the fresh DB/config/anonymous Project; `bootstrap-project` is also inside it. This keeps Project roots outside the repository ancestor and makes `scope/public-external.csv` genuinely external to the actual Session/Project worktree. The read-only checker verifies the actual canonical paths; path naming alone is not proof.
- The public CSV is exactly `item,quantity\nCedar408,3\nIris408,4\n`, created fresh with exclusive write. It is the only effect input. The empty public model catalog and synthetic local Provider config are new; no real auth/models/user database is copied or read.
- The parent's separate temporary home/config/tool environment is removed **only after** the original child physically settles and both output drains join. `retainedRoot` intentionally remains in place; the helper does not copy a live DB, mutate old data, run migration or create another schema reader. Its recorded exact path and public CSV are retained for Root's later separately approved reopen. They must not be swept into evidence archives or committed wholesale.
- NodeProcess launch occurrence and product `currentRuntimeProcessOccurrence()` are **different IDs**. The source correlates original PID/deadline and preserves both; control does not compare the UUIDs for equality or call `kill(0)` physical evidence. Only original `NodeProcess.settled` + output joins, followed by Root's original exec join, establish closure.
- `requestSettled` is set only in the original **NodeProcess.run Promise finally**. `onSpawned` proves the internal admission promise fulfilled and delivered its handle; if run rejects before this callback, admission remains explicitly not-observed rather than pretending no child exists. `handle.terminal`, `handle.outputSettled` and `handle.settled` are separately awaited/recorded. Parent cleanup requires actual full closure (or no run admission was attempted); a settled request is not itself proof of physical/output closure. Root's external exec join remains separately required.
- Main error, live stdout/stderr persistence errors, stop/termination/physical/output errors, temporary cleanup and terminal-write errors are retained separately with original Error/cause/stack data. A terminal-file write failure is also included in the final stderr AggregateError instead of masking the earlier failure; stdout emits the final in-memory owner facts. The server likewise preserves preparation, both normal stop attempts, recovery and terminal-write failures.
- Root's review02 correction matches the actual synchronous Process observer contract: both live stdout/stderr callbacks use synchronous `fs.appendFileSync`, return void, and retain the original write error in the existing catch. The prior async observer was never run. It would have left its file-write Promise outside run settlement; no new queue, shared Process edit or Provider/control/facts change is part of this correction.

## Exact commands (not executed)

Run using the existing `packages/opencorvus` working directory and its **natural existing tsconfig**, with the already present empty bunfig below. There is no tsconfig-override, copied config or newly created configuration. Root execution approval and a current private UI build are prerequisites. Root retains the returned original exec handle for its entire lifetime.

```powershell
$env:PATH='D:/myhexin-local/opencorvus/.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64;'+$env:PATH
Set-Location 'D:/myhexin-local/opencorvus/packages/opencorvus'
& 'D:/myhexin-local/opencorvus/.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64/bun.exe' '--config=D:/myhexin-local/opencorvus/packages/opencorvus/test/empty-bunfig.toml' 'D:/myhexin-local/opencorvus/.tmp-grant-decision-recovery-408/ui/d1/grant-read-driver.ts' 'D:/myhexin-local/opencorvus/.tmp-grant-decision-recovery-408/ui/d1/before01' 'D:/myhexin-local/opencorvus/.tmp-grant-decision-recovery-408/ui-before'
```

After `ready.json` is actually written, use Node (not Bun) for finite manual HTTP/control calls. Run these relative helper paths from repository root:

```powershell
Set-Location 'D:/myhexin-local/opencorvus'
& 'C:/Program Files/nodejs/node.exe' '.tmp-grant-decision-recovery-408/ui/d1/grant-read-control.mjs' 'D:/myhexin-local/opencorvus/.tmp-grant-decision-recovery-408/ui/d1/before01' status
& 'C:/Program Files/nodejs/node.exe' '.tmp-grant-decision-recovery-408/ui/d1/grant-read-control.mjs' 'D:/myhexin-local/opencorvus/.tmp-grant-decision-recovery-408/ui/d1/before01' start 'Read the public CSV at D:/myhexin-local/opencorvus/.tmp-grant-decision-recovery-408/ui/d1/before01/public-external.csv and report its rows.'
& 'C:/Program Files/nodejs/node.exe' '.tmp-grant-decision-recovery-408/ui/d1/grant-read-control.mjs' 'D:/myhexin-local/opencorvus/.tmp-grant-decision-recovery-408/ui/d1/before01' observe pending
```

This explicit start is a real human public API action with its text visible in the accepted conversation, not an automatic/background seed. `global-chat-start.request.json` stores the original requestID/body before sending. A lost HTTP response is an uncertain original request; do not issue a different requestID or rerun `start` to pretend it never happened. The exclusive file write preserves that original failure for Root to resolve with the actual public idempotency contract.

Root then opens the **actual ready URL**, selects the exact Session in `global-chat-start.json.acceptance.session`, captures the visible first Request and chooses **Allow for project** in the real Dialog/card. Wait for the actual read Tool and natural final. Then:

```powershell
& 'C:/Program Files/nodejs/node.exe' '.tmp-grant-decision-recovery-408/ui/d1/grant-read-control.mjs' 'D:/myhexin-local/opencorvus/.tmp-grant-decision-recovery-408/ui/d1/before01' observe first
```

In the same real Session composer, Root types the exact second suggested prompt from `public-input.json` and sends it. There is no helper POST for this second user message. After actual read/final:

```powershell
& 'C:/Program Files/nodejs/node.exe' '.tmp-grant-decision-recovery-408/ui/d1/grant-read-control.mjs' 'D:/myhexin-local/opencorvus/.tmp-grant-decision-recovery-408/ui/d1/before01' observe second
```

Root cold-selects/reopens the same Session in the real page, captures actual pending UI and original screenshots, then runs `observe snapshot` if useful. GET `/session/:id/conversation` itself is only a canonical cold response and **does not prove the visible page was cold-reopened**.

Settings: open the actual General/Permission records area, Refresh and expand these exact two operations. Capture the first `grant_created`, second original `grant_used`, actual executions and same-mounted English→Chinese→English labels/dates/scope. Do not call missing rows or a no-dialog path a success criterion; read actual Tool output/graph. Before index approval, no screenshot can be called migrated history. Prefer leaving the real grant unchanged for the later old-data upgrade; any revoke experiment needs its own recorded Root action and scope explanation.

Stop **before closeBy**, after Root has closed its own page and saved that real receipt:

```powershell
& 'C:/Program Files/nodejs/node.exe' '.tmp-grant-decision-recovery-408/ui/d1/grant-read-control.mjs' 'D:/myhexin-local/opencorvus/.tmp-grant-decision-recovery-408/ui/d1/before01' stop page-closed
```

Server uses the original recovered runtime's normal `server.stop(true)`, awaits recovery, stops its own controlled Provider, writes `terminal.json`, then exits. Driver joins original physical receipt and output, checks actual exited/0, removes only its temporary user environment, and writes `driver-terminal.json`. Root must then join the **original exec**. A reserve/deadline-triggered close is marked failed; a terminal-write/cleanup/drain failure remains an error. A stop-request file is never proof of physical closure or page closure.

## What the checker proves and what it does not

`observe pending/first/second` are finite positive HTTP/data contracts over the real accepted Session and exact CSV. They retain status/body for Session info, Messages, cold conversation, pending permissions, full public history, grants and current Project before evaluating facts. Completed read checks actual Tool status/output rows, start/source/success/attempt, and real final Message text/idle. `second` proves exact same scope/fingerprint/provider with a different Request and exact U→G/S→U graph. Both API pending sets are **recorded**, not asserted fixed, so the known before defect remains visible.

The check does not touch SQLite or synthesize rows. It does not assert UI text/DOM/layout, screenshots, model understanding, client EOF, all grant races, Task/Side/ACP/channel interop, migration success, or all locale rendering. A controlled final text is a fixture response, not evidence that the model understood the file; actual read output is the file evidence. Missing/premature protocol facts create a preserved `facts-*.failure.json`/`control-*.failure.json`; later successful observations do not overwrite them.

One uncertainty remains until execution: the product may make an additional non-Memory model request (e.g. an unrelated configured helper) beyond the fixture's four intended prompts. The recorder retains kind/model/stream/Tool names; it does not silently stretch the response sequence or infer those extra requests are completed business turns. Root must analyze any actual extra request instead of relabeling it as a passed two-read chain.

Allowed eventual evidence: five helper sources and precise source changes, public input/config/preflight API results, selected public Message/Permission facts, control requests/receipts, original stdout/stderr and original owner/terminal receipts, Root's original screenshots and review. Excluded: entire retained-runtime/DB/config directory, provider request bodies/messages, user credentials/models, private UI assets, unrelated prior scopes. Retained data stays local for the separately authorized migration input, not a delivery artifact.

Prepared source status only: no type/build/runtime checker or real UI has run for these new helpers. Root's review and explicit execution approval remain the next step.
