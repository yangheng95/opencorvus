// Explicit human owner controls only. No automatic UI or permission decisions.
import fs from 'node:fs/promises'
import path from 'node:path'
import assert from 'node:assert/strict'
import { randomUUID } from 'node:crypto'
import { fileURLToPath } from 'node:url'
import { observeGrantRead } from './grant-read-facts.mjs'

const [scope, command, value] = process.argv.slice(2)
assert(scope && path.isAbsolute(scope))
assert.equal(path.dirname(path.resolve(scope)), path.dirname(fileURLToPath(import.meta.url)))
assert(['status', 'start', 'observe', 'stop'].includes(command))
const json = async name => JSON.parse(await fs.readFile(path.join(scope, name), 'utf8'))
const [ready, driver, launch] = await Promise.all(['ready.json', 'driver-context.json', 'product-launch.json'].map(json))
assert.equal(ready.scenario, 'grant-read-d1'); assert.equal(ready.pid, launch.pid)
assert.equal(ready.deadlineAt, driver.deadlineAt); assert.equal(launch.deadlineAt, driver.deadlineAt)
assert.equal(ready.occurrence.pid, launch.pid)
assert(ready.occurrence.processInstanceID && ready.occurrence.occurrenceID)
// The runtime durable occurrence and NodeProcess launch occurrence are distinct
// real authorities; retain both and correlate their original PID/deadline.
assert(Date.now() < ready.closeBy, 'Original close reserve; no extension')
const write = (name, data) => fs.writeFile(path.join(scope, name), JSON.stringify(data, null, 2) + '\n', { flag: 'wx' })
const id = randomUUID(), requestedAt = Date.now()
const context = { id, command, requestedAt, productPID: launch.pid, productOccurrence: launch.occurrence, deadlineAt: ready.deadlineAt }
try {
  if (command === 'status') console.log(JSON.stringify({ ready, publicInput: await json('public-input.json'), remainingMs: ready.closeBy - Date.now() }, null, 2))
  if (command === 'start') {
    assert.equal(ready.reuseScope, undefined, 'Legacy scope observes the original accepted human messages')
    assert(value?.trim(), 'Explicit human-authored visible prompt text is required; no automatic seed message')
    const request = { requestID: id, model: 'shutdown-fixture/session-prompt-owner-model', text: value }
    await write('global-chat-start.request.json', { ...context, body: request })
    const response = await fetch(new URL('/global/chat/start', ready.url), {
      method: 'POST', headers: { 'content-type': 'application/json', 'x-opencorvus-directory': ready.project },
      body: JSON.stringify(request), signal: AbortSignal.timeout(Math.max(1, Math.min(30000, ready.closeBy - Date.now()))),
    })
    const acceptance = await response.json()
    await write('global-chat-start.json', { ...context, status: response.status, body: request, acceptance })
    assert.equal(response.status, 202); assert(acceptance.session?.id)
    console.log(JSON.stringify({ status: response.status, acceptance, boundary: 'Visible human input accepted through the public API; select this exact Session in the real page. Permission choice remains a real Root UI action.' }, null, 2))
  }
  if (command === 'observe') console.log(JSON.stringify(await observeGrantRead(scope, ready, value), null, 2))
  if (command === 'stop') {
    assert(value === 'page-closed', 'Root must close its page before asking for owned service settlement')
    await write('stop-requested.json', { ...context, pageClosure: 'Root explicitly reported page closed; actual page receipt is separate evidence' })
    console.log(JSON.stringify({ ...context, boundary: 'Stop requested only; await original driver terminal and original exec join.' }))
  }
} catch (error) {
  await write(`control-${id}.failure.json`, { ...context, error: String(error), failedAt: Date.now() })
  throw error
}
