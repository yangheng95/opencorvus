// Prepared scratch. Await Root run authorization; the observed Git clock suspicion
// was ruled out by real continuous-output and 10-second silent-Node evidence.
import fs from 'node:fs/promises'
import fsSync from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import { bootstrapIsolatedTestRuntime, applyIsolatedTestUserEnvironment } from '../../../packages/util/src/test-runtime-environment'
import { NodeProcess } from '../../../packages/util/src/process-node'
import { expectedTestProcessSupervisor } from '../../../packages/opencorvus/script/test-process-supervisor'

const [scope, uiDirectory] = process.argv.slice(2)
const scratch = path.resolve(import.meta.dir), repo = path.resolve(scratch, '../../..')
const packageDirectory = path.join(repo, 'packages/opencorvus')
const emptyBunfig = path.join(packageDirectory, 'test/empty-bunfig.toml')
assert(scope && uiDirectory && path.isAbsolute(scope) && path.isAbsolute(uiDirectory))
assert.equal(path.dirname(path.resolve(scope)), scratch)
const startedAt = Date.now(), deadlineAt = startedAt + 600000, closeBy = deadlineAt - 60000
await fs.mkdir(scope, { recursive: false })
const write = (name: string, value: unknown) => fs.writeFile(path.join(scope, name), JSON.stringify(value, null, 2) + '\n', { flag: 'wx' })
const owner: any = { parentPID: process.pid, startedAt, deadlineAt, closeBy, scope, uiDirectory, cwd: packageDirectory,
  emptyBunfig, tsconfig: 'Natural existing package tsconfig; no override or new config', requestKind: 'NodeProcess.run',
  requestStarted: false, requestSettled: false, admissionPromiseOutcome: 'not-observed',
  admissionHandleObserved: false, physicalJoined: false, outputJoined: false, handleSettledJoined: false,
  temporaryEnvironmentRemoved: false, outerExecJoin: 'Root must observe the original external exec join separately' }
let product: Awaited<ReturnType<typeof NodeProcess.spawn>> | undefined
let isolated: Awaited<ReturnType<typeof bootstrapIsolatedTestRuntime>> | undefined
let primary: { error: unknown } | undefined
const cleanupErrors: Array<{ step: string; error: unknown }> = []
function errorFacts(error: unknown): unknown {
  if (!(error instanceof Error)) return { value: String(error) }
  const value = error as Error & { code?: unknown; errno?: unknown }
  return { name: value.name, message: value.message, stack: value.stack,
    ...(value.code === undefined ? {} : { code: value.code }), ...(value.errno === undefined ? {} : { errno: value.errno }),
    ...(value.cause === undefined ? {} : { cause: errorFacts(value.cause) }),
    ...(value instanceof AggregateError ? { errors: value.errors.map(errorFacts) } : {}) }
}
const cleanup = async (step: string, action: () => Promise<unknown>) => {
  try { await action() } catch (error) { cleanupErrors.push({ step, error }) }
}
const observeOutput = (name: string) => (bytes: Uint8Array): void => {
  try { fsSync.appendFileSync(path.join(scope, name), bytes) }
  catch (error) { cleanupErrors.push({ step: `persist live ${name}`, error }); throw error }
}
try {
  await fs.stat(path.join(uiDirectory, 'index.html')); await fs.stat(emptyBunfig)
  await fs.mkdir(path.join(scope, 'helper-source'))
  for (const name of ['grant-read-driver.ts', 'grant-read-server.ts', 'grant-read-provider.ts', 'grant-read-control.mjs', 'grant-read-facts.mjs']) {
    await fs.copyFile(path.join(scratch, name), path.join(scope, 'helper-source', name), 1)
  }
  isolated = await bootstrapIsolatedTestRuntime('runner')
  applyIsolatedTestUserEnvironment(isolated)
  owner.retainedRoot = isolated.processRoot
  owner.retainedRuntime = isolated.runtimeRoot
  owner.retainedEnvironment = isolated
  await write('driver-context.json', { ...owner,
    purpose: '408 D1 original grant reuse before input; controlled streaming, human decisions and visible real messages',
    runtimeRetention: 'Retain this one original bootstrap environment, including ownerRoot/processRoot/runtime/home/tool/temp, after actual process/request/output joins for a later Root-approved migration and exact-owner cleanup.' })
  await write('driver-runtime-owner.json', isolated)
  const supervisor = expectedTestProcessSupervisor()
  assert(supervisor, 'Existing mature Windows owned-tree supervisor required')
  assert((await fs.stat(supervisor)).size > 0, 'Prebuilt supervisor required; this driver does not build a new one')
  process.env.OPENCORVUS_PROCESS_SUPERVISOR = supervisor
  const env = Object.fromEntries(Object.entries(process.env).filter(([name]) => /^(PATH|SystemRoot|WINDIR|ComSpec|PATHEXT|HOME|HOMEDRIVE|HOMEPATH|USERPROFILE|APPDATA|LOCALAPPDATA|TEMP|TMP|TMPDIR|XDG_CONFIG_HOME|XDG_DATA_HOME|XDG_CACHE_HOME|XDG_STATE_HOME|OPENCORVUS_(TEST_|HOME))/i.test(name)))
  env.OPENCORVUS_PROCESS_SUPERVISOR = supervisor
  const command = { executable: path.join(repo, '.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64/bun.exe'),
    args: [`--config=${emptyBunfig}`, path.join(scratch, 'grant-read-server.ts'), scope, uiDirectory, String(deadlineAt)] }
  owner.command = command; owner.environmentNames = Object.keys(env).sort()
  await write('driver-owner-start.json', owner)
  assert(Date.now() < closeBy, 'Original preparation deadline')
  owner.requestStarted = true
  const result = await NodeProcess.run({ command, cwd: packageDirectory, ownership: 'owned_tree', windowsHide: true,
    stdin: 'ignore', env, deadlineAt, nothrow: true,
    async onSpawned(handle) {
      // runProcess awaits facade.spawn before this callback. It exposes fulfilled
      // admission, not the private spawn promise's rejected/uncertain outcome.
      product = handle; owner.admissionHandleObserved = true; owner.admissionPromiseOutcome = 'fulfilled'
      owner.pid = handle.pid; owner.occurrenceID = handle.occurrenceID; owner.admittedAt = Date.now()
      await write('product-launch.json', { command, cwd: packageDirectory, pid: handle.pid, occurrence: handle.occurrenceID,
        startedAt, deadlineAt, closeBy, environmentNames: owner.environmentNames })
    }, onStdout: observeOutput('stdout.log'), onStderr: observeOutput('stderr.log'),
  }).finally(() => { owner.requestSettled = true; owner.requestSettledAt = Date.now() })
  owner.runReceipt = result.receipt
  assert(product, 'Successful whole run must have delivered its original admission handle')
  owner.physicalReceipt = await product.terminal; owner.physicalJoined = true
  await product.outputSettled; owner.outputJoined = true
  owner.settledReceipt = await product.settled; owner.handleSettledJoined = true
  assert.deepEqual(owner.physicalReceipt, result.receipt, 'Run and original physical receipt')
  assert.deepEqual(owner.settledReceipt, result.receipt, 'Run and original settled receipt')
  assert.equal(result.receipt.reason, 'exited'); assert.equal(result.receipt.exitCode, 0)
} catch (error) { primary = { error } }
finally {
  if (product && !owner.physicalJoined) {
    await cleanup('write exact owned emergency stop request', async () => {
      const target = path.join(scope, 'stop-requested.json')
      try { await write('stop-requested.json', { reason: 'Original driver error settlement', requestedAt: Date.now(), deadlineAt, productPID: product!.pid, productOccurrence: product!.occurrenceID }) }
      catch (error) {
        if ((error as NodeJS.ErrnoException).code !== 'EEXIST') throw error
        const existing = JSON.parse(await fs.readFile(target, 'utf8'))
        assert.equal(existing.deadlineAt, deadlineAt); assert.equal(existing.productPID, product!.pid)
        assert.equal(existing.productOccurrence, product!.occurrenceID)
      }
    })
    await cleanup('settle exact owned handle after failed run', async () => { owner.terminationReceipt = await product!.terminate('aborted') })
    await cleanup('observe original physical terminal', async () => { owner.physicalReceipt = await product!.terminal; owner.physicalJoined = true })
  }
  if (product && !owner.outputJoined) await cleanup('observe original output settlement', async () => { await product!.outputSettled; owner.outputJoined = true })
  if (product && !owner.handleSettledJoined) await cleanup('observe original complete handle settlement', async () => { owner.settledReceipt = await product!.settled; owner.handleSettledJoined = true })
  const closed = owner.requestStarted && owner.requestSettled && owner.admissionHandleObserved && owner.physicalJoined && owner.outputJoined && owner.handleSettledJoined
  const normal = owner.physicalReceipt?.reason === 'exited' && owner.physicalReceipt.exitCode === 0
  if (owner.requestStarted && (!closed || !normal)) cleanupErrors.push({ step: 'validate actual original terminal contract', error: new Error(JSON.stringify({ closed, normal, physicalReceipt: owner.physicalReceipt, admissionPromiseOutcome: owner.admissionPromiseOutcome })) })
  if (isolated) {
    owner.temporaryEnvironmentRetainedReason = closed
      ? 'Intentionally retain the entire original bootstrap environment after observed process/request/output joins for Root-approved migration; exact-owner cleanup remains deferred, not completed'
      : !owner.requestStarted
        ? 'Original bootstrap environment retained after preparation failure before any child request; Root must review before exact-owner cleanup'
        : 'Original process/request/output settlement was not completely observed; retain the entire original environment and ownership evidence'
  }
  owner.finishedAt = Date.now(); owner.closed = Boolean(closed)
  owner.primaryError = primary ? errorFacts(primary.error) : null
  owner.cleanupErrors = cleanupErrors.map(({ step, error }) => ({ step, error: errorFacts(error) }))
  owner.status = !primary && cleanupErrors.length === 0 && closed && normal ? 'closed' : 'failed'
  await cleanup('persist original driver terminal', () => write('driver-terminal.json', owner))
  owner.cleanupErrors = cleanupErrors.map(({ step, error }) => ({ step, error: errorFacts(error) }))
  if (cleanupErrors.length) owner.status = 'failed'
  process.exitCode = owner.status === 'closed' ? 0 : 1
  console.log(JSON.stringify(owner))
  if (primary || cleanupErrors.length) console.error(new AggregateError(
    [...(primary ? [primary.error] : []), ...cleanupErrors.map(entry => entry.error)],
    'D1 original execution or evidence settlement failed; retain all original errors and ownership',
    primary ? { cause: primary.error } : undefined,
  ))
}
