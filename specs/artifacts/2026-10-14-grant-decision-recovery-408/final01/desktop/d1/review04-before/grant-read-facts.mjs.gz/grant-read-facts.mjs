// Read-only public HTTP/data checker. No database, browser or decision mutation.
import fs from 'node:fs/promises'
import path from 'node:path'
import assert from 'node:assert/strict'

export async function observeGrantRead(scope, ready, mode) {
  assert(['pending', 'first', 'second', 'snapshot'].includes(mode))
  const startedAt = Date.now(), deadlineAt = Math.min(startedAt + 30000, ready.closeBy)
  assert(deadlineAt > startedAt, 'Original live observation window')
  const accepted = JSON.parse(await fs.readFile(path.join(scope, 'global-chat-start.json'), 'utf8'))
  assert.equal(accepted.status, 202)
  const session = accepted.acceptance.session
  assert(session?.id && path.isAbsolute(session.directory))
  const runtimeRelative = path.relative(ready.runtime, session.directory)
  assert(runtimeRelative && !runtimeRelative.startsWith('..') && !path.isAbsolute(runtimeRelative), 'Original anonymous Session under owned retained runtime')
  const routes = [`/session/${session.id}`, `/session/${session.id}/message`, `/session/${session.id}/conversation`, '/permission', '/permission/history', '/permission/grants', '/project/current']
  const responses = await Promise.all(routes.map(async route => {
    const remaining = deadlineAt - Date.now(); assert(remaining > 0)
    const response = await fetch(new URL(route, ready.url), {
      headers: { 'x-opencorvus-directory': session.directory }, signal: AbortSignal.timeout(remaining),
    })
    const text = await response.text(); let body
    try { body = JSON.parse(text) } catch { body = text }
    return { route, status: response.status, body }
  }))
  const output = `facts-${mode}-${startedAt}.json`
  await fs.writeFile(path.join(scope, output), JSON.stringify({ mode, startedAt, deadlineAt, observedAt: Date.now(),
    productOccurrence: ready.occurrence, session, responses }, null, 2) + '\n', { flag: 'wx' })
  try {
    for (const response of responses) assert.equal(response.status, 200, response.route)
    const [sessionFact, messages, conversation, pending, history, grants, projectFact] = responses.map(response => response.body)
    assert.equal(sessionFact.id, session.id)
    assert(Array.isArray(messages) && Array.isArray(pending) && Array.isArray(history) && Array.isArray(grants))
    assert(Array.isArray(conversation.pendingPermissions))
    assert.equal(projectFact.id, sessionFact.projectID)
    const actualFile = await fs.realpath(ready.externalFile)
    const outside = (root, target) => { const relative = path.relative(root, target); return relative.startsWith('..' + path.sep) || relative === '..' || path.isAbsolute(relative) }
    for (const root of [session.directory, projectFact.worktree]) assert(outside(await fs.realpath(root), actualFile), 'The actual public CSV is outside both canonical Session directory and Project worktree')
    const csv = await fs.readFile(ready.externalFile, 'utf8')
    assert.equal(csv, 'item,quantity\nCedar408,3\nIris408,4\n')
    const requestForCall = callID => [...history].reverse().find(event => event.event_type === 'requested' && event.session_id === session.id && event.tool_call_id === callID)
    const first = requestForCall('call_public_grant_408_read_1')
    assert(first, 'Actual original first read requested owner')
    assert.equal(first.mode, 'ask')
    assert.equal(first.tool_name, 'read')
    assert.equal(first.project_id, sessionFact.projectID)
    assert(first.metadata.choices.includes('allow_project'), 'Actual Request offers project scope')
    const result = { mode, output, sessionID: session.id, sessionDirectory: session.directory, projectID: sessionFact.projectID,
      firstRequestID: first.request_id, firstTimeCreated: first.time_created, actualProject: projectFact, actualExternalFile: actualFile,
      pendingRequestIDs: pending.filter(request => request.sessionID === session.id).map(request => request.id),
      coldPendingRequestIDs: conversation.pendingPermissions.map(request => request.id),
      boardStatus: conversation.board.status, grants: grants.map(grant => ({ id: grant.id, requestID: grant.request_id, scope: grant.decision_scope })),
      boundary: 'Real HTTP and immutable public facts only; Root supplies actual click, screenshots and visual review. This before checker records actual pending sets and does not assert that the known defect is fixed.' }
    if (mode === 'pending') {
      const original = pending.find(request => request.id === first.request_id)
      assert(original, 'Actual first request is pending before Root approval')
      assert(conversation.pendingPermissions.some(request => request.id === original.id), 'Cold snapshot carries actual pending first Request')
      assert.equal(original.timeCreated, first.time_created)
    }
    const completedRead = (owner, expectedFinal) => {
      const toolMessage = messages.find(message => message.info.id === owner.message_id)
      assert(toolMessage, 'Original accepted Tool message')
      const tool = toolMessage.parts.find(part => part.type === 'tool' && part.tool === 'read' && part.callID === owner.tool_call_id)
      assert(tool, 'Original accepted read Tool call')
      assert.equal(tool.state.status, 'completed')
      for (const line of csv.trimEnd().split('\n')) assert(tool.state.output.includes(line), `Actual read output contains public row ${line}`)
      const start = history.find(event => event.event_type === 'execution_started' && event.request_id === owner.request_id)
      const succeeded = history.find(event => event.event_type === 'execution_succeeded' && event.request_id === owner.request_id)
      assert(start?.attempt_id && succeeded, 'Actual start and success ledger facts')
      assert.equal(succeeded.attempt_id, start.attempt_id); assert.equal(succeeded.outcome_slot, start.attempt_id)
      const final = messages.findLast(message => message.info.role === 'assistant' && message.info.parentID === toolMessage.info.parentID &&
        message.info.finish === 'stop' && Number.isFinite(message.info.time.completed))
      assert(final, 'Natural final Message for the same accepted input')
      assert.deepEqual(final.parts.filter(part => part.type === 'text').map(part => part.text), [expectedFinal])
      return { toolPartID: tool.id, messageID: toolMessage.info.id, start, succeeded, finalMessageID: final.info.id }
    }
    if (mode === 'first' || mode === 'second') {
      const grant = history.find(event => event.event_type === 'grant_created' && event.request_id === first.request_id)
      assert(grant, 'Actual Root-created reusable grant')
      assert.equal(grant.decision_slot, first.request_id); assert.equal(grant.decision_scope, 'project')
      const execution = completedRead(first, 'provider reply 2')
      assert.equal(execution.start.source_event_id, grant.id)
      result.first = { grant, ...execution }
      assert.equal(conversation.board.status, 'idle')
      if (mode === 'second') {
        const second = requestForCall('call_public_grant_408_read_2')
        assert(second, 'Actual second accepted read Request')
        assert(first.request_id !== second.request_id, 'Distinct accepted human turn and Tool request identity')
        for (const field of ['project_id', 'session_id', 'provider_kind', 'provider_id', 'provider_digest', 'tool_name', 'effect_class', 'scope_version', 'fingerprint']) assert.equal(second[field], first[field], field)
        assert.deepEqual(second.scope, first.scope)
        const used = history.find(event => event.event_type === 'grant_used' && event.request_id === second.request_id)
        assert(used, 'Actual saved approval capture for second read')
        assert.equal(used.source_event_id, grant.id); assert.equal(used.decision_scope, 'project')
        const secondExecution = completedRead(second, 'provider reply 4')
        assert.equal(secondExecution.start.source_event_id, used.id)
        result.second = { request: second, grantUsed: used, ...secondExecution }
      }
    }
    await fs.writeFile(path.join(scope, output.replace('.json', '.check.json')), JSON.stringify({ passed: true, ...result }, null, 2) + '\n', { flag: 'wx' })
    return result
  } catch (error) {
    await fs.writeFile(path.join(scope, output.replace('.json', '.failure.json')), JSON.stringify({ passed: false, error: String(error), output, observedAt: Date.now() }, null, 2) + '\n', { flag: 'wx' })
    throw error
  }
}
