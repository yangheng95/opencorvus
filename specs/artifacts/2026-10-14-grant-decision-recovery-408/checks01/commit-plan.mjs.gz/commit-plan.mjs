import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import {execFileSync} from 'node:child_process'
const root=path.resolve('.tmp-grant-decision-recovery-408')
const stage=process.argv[3]??'plan'
assert(['plan','lock','qualification','followup','delivery'].includes(stage),'Explicit owned delivery stage required')
const message=stage==='delivery'?'fix(permission): preserve saved-grant authority through recovery and safe upgrades':stage==='plan'?'docs(iteration): retain message retirement delivery and plan grant authority recovery':stage==='lock'?'docs(iteration): retain grant upgrade lock evidence and resolver diagnosis':stage==='qualification'?'docs(iteration): qualify grant upgrade lock inputs with natural package configuration':'docs(iteration): preserve original concurrent upgrade failure and corrected qualification plan'
const git=(args,env=process.env,input)=>execFileSync('git',args,{env,input,encoding:'utf8',windowsHide:true,maxBuffer:32*1024*1024})
const full=['specs/records/2026-10/2026-10-14-grant-decision-recovery-408.md','specs/artifacts/2026-10-14-grant-decision-recovery-408']
if(stage==='delivery')full.push(...JSON.parse(fs.readFileSync(path.join(root,'functionality/implementation/review/paths.json'))),
 'packages/opencorvus/script/artifact-batch-check.ts','packages/opencorvus/script/cli-run-check.ts',
 'packages/opencorvus/test/controlled-streaming-provider.test.ts','packages/opencorvus/test/fixture/controlled-streaming-provider.ts','packages/opencorvus/test/global-chat-start-process.test.ts',
 'packages/opencorvus/src/storage/schema-migration.ts','packages/opencorvus/test/storage/schema-migration.test.ts','packages/opencorvus/test/fixture/schema-migration-process-worker.ts',
 'packages/overlay/src/components/CardParts.tsx','packages/overlay/src/components/InteractionCard.tsx','packages/overlay/src/components/settings/PermissionsPanel.tsx',
 'packages/overlay/src/utils/interaction.ts','packages/overlay/src/utils/transcript.ts','packages/overlay/src/i18n/en-US.json','packages/overlay/src/i18n/zh-CN.json',
 'specs/current/architecture/02-data.md','specs/current/architecture/security-permission.md','specs/current/architecture/07-panel-reactivity.md')
const partial=['specs/README.md','specs/artifacts/README.md','specs/records/2026-10/README.md']
const rows=Object.fromEntries(partial.map(file=>{
  const own=fs.readFileSync(file,'utf8').split(/\r?\n/).filter(line=>line.startsWith('- [408 保存批准决定与安全升级]'))
  assert.equal(own.length,1);return[file,own[0]]
}))
function applyOwn(text,line){
  text=text.replaceAll('\r\n','\n');const lines=text.split('\n')
  const matches=lines.map((value,index)=>value.startsWith('- [408 保存批准决定与安全升级]')?index:-1).filter(index=>index>=0)
  assert(matches.length<=1)
  if(matches.length){lines[matches[0]]=line;return lines.join('\n')}
  lines.splice(1,0,'',line);return lines.join('\n')
}
const base=git(['rev-parse','HEAD']).trim(),env={...process.env,GIT_INDEX_FILE:path.join(root,'index-plan-'+Date.now())}
assert.equal(git(['branch','--show-current']).trim(),'main');git(['read-tree',base],env);git(['add','-f','--',...full],env)
for(const [file,line]of Object.entries(rows)){
  const blob=git(['hash-object','-w','--stdin'],env,applyOwn(git(['show',base+':'+file]),line)).trim()
  git(['update-index','--index-info'],env,'100644 '+blob+'\t'+file+'\n')
}
// Generated published targets preserve SQLite's exact original object SQL.
// Whitespace there is not a functional or delivery gate; the formal migration
// checker and actual graph/migration tests remain mandatory.
git(['diff','--cached','--check',...(stage==='delivery'?['--','.',':(exclude)packages/opencorvus/src/storage/migrations/0002-grant-decision-index.sql']:[])],env)
const paths=git(['diff','--cached','--name-only'],env).trim().split('\n')
assert(paths.every(file=>partial.includes(file)||full.some(scope=>file===scope||file.startsWith(scope+'/'))))
fs.writeFileSync(path.join(root,stage+'-scoped.patch'),git(['diff','--cached','--binary'],env))
console.log(JSON.stringify({base,paths:paths.length,mode:process.argv[2]??'prepare'}))
if(process.argv[2]!=='--commit')process.exit(0)
assert.equal(git(['rev-parse','HEAD']).trim(),base)
git(['commit','-q','-m',message],env)
const commit=git(['rev-parse','HEAD']).trim();assert.equal(git(['rev-parse',commit+'^']).trim(),base)
const receipt={base,commit,paths,indexReconciled:false}
fs.writeFileSync(path.join(root,stage+'-commit.json'),JSON.stringify(receipt,null,2))
const tree=new Map(git(['ls-tree','-r',commit]).trim().split('\n').map(line=>{const [object,file]=line.split('\t');return[file,object.replace(' blob ',' ')]}))
const changes=paths.filter(file=>!partial.includes(file)).map(file=>tree.get(file)+'\t'+file+'\n')
for(const [file,line]of Object.entries(rows)){
  const blob=git(['hash-object','-w','--stdin'],process.env,applyOwn(git(['show',':'+file]),line)).trim()
  changes.push('100644 '+blob+'\t'+file+'\n')
}
git(['update-index','--index-info'],process.env,changes.join(''))
receipt.indexReconciled=true;fs.writeFileSync(path.join(root,stage+'-commit.json'),JSON.stringify(receipt,null,2))
console.log(JSON.stringify({commit,paths:paths.length,indexReconciled:true}))
