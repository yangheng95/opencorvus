import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import {gzipSync,gunzipSync} from 'node:zlib'
const stage=process.argv[2]??'lock01'
assert(['lock01','lock02','final01','checks01'].includes(stage))
const occurrence=stage==='lock01'?'lock-process-01':'lock-process-02'
const target=path.resolve('specs/artifacts/2026-10-14-grant-decision-recovery-408',stage)
const items=[]
function add(source,destination){assert(fs.lstatSync(source).isFile());items.push({source,destination})}
function tree(source,destination){for(const entry of fs.readdirSync(source,{withFileTypes:true})){
  assert(!entry.isSymbolicLink());const from=path.join(source,entry.name),to=destination+'/'+entry.name
  if(entry.isDirectory())tree(from,to);else add(from,to)
}}
if(stage==='checks01'){
  for(const name of ['cli408-check02','docs408-final01','architecture408-final01','prepare408-delivery01','prepare408-delivery02','migration408-final02','migration408-final03','archive408-final01'])
    tree(path.resolve('.tmp-task-question-recovery-406/delivery-commands',name),'commands/'+name)
  const cliRoot='C:/Users/hengu/AppData/Local/Temp/opencorvus-test-run-bFNkJe/runner-84736-CCvrnk'
  for(const name of ['results.json','lifecycle-facts.json','catalog-input.json']) add(path.join(cliRoot,name),'cli-original/'+name)
  const rootPaths=[...JSON.parse(fs.readFileSync('.tmp-grant-decision-recovery-408/functionality/implementation/review/paths.json')),
    'packages/opencorvus/script/cli-run-check.ts','packages/opencorvus/script/artifact-batch-check.ts',
    'packages/opencorvus/test/fixture/controlled-streaming-provider.ts','packages/opencorvus/test/controlled-streaming-provider.test.ts','packages/opencorvus/test/global-chat-start-process.test.ts',
    'packages/opencorvus/src/storage/schema-migration.ts','packages/opencorvus/test/storage/schema-migration.test.ts','packages/opencorvus/test/fixture/schema-migration-process-worker.ts',
    'packages/overlay/src/components/CardParts.tsx','packages/overlay/src/components/InteractionCard.tsx','packages/overlay/src/components/settings/PermissionsPanel.tsx',
    'packages/overlay/src/utils/interaction.ts','packages/overlay/src/utils/transcript.ts','packages/overlay/src/i18n/en-US.json','packages/overlay/src/i18n/zh-CN.json']
  for(const file of rootPaths)add(path.resolve(file),'current-closed-review-source/'+file)
  for(const name of ['commit-plan.mjs','capture-lock01.mjs'])add(path.resolve('.tmp-grant-decision-recovery-408',name),name)
}else if(stage==='final01'){
  const scratch=path.resolve('.tmp-grant-decision-recovery-408')
  const backend=JSON.parse(fs.readFileSync(path.join(scratch,'functionality/implementation/review/archive-allowlist.json')))
  for(const entry of backend.files)add(path.join(scratch,'functionality',entry.source),entry.destination)
  for(const name of ['HUMAN-AUDIT.md','human-audit-observations.json'])add(path.join(scratch,'functionality/implementation/review',name),'backend/implementation/review/'+name)
  for(const dir of ['lock-followup-02','lock-old-reader-race-01','followup02-before','race-review-before','physical-formal01-sources','physical-implementation-before01'])
    tree(path.join(scratch,'functionality',dir),'root-functionality/'+dir)
  for(const dir of ['build-before01','build-before-source','build-after01','build-after02','build-after03','implementation-before01','implementation-after01','phase-before01','reason-before01','task-history-source'])
    tree(path.join(scratch,'ui',dir),'desktop/'+dir)
  for(const dir of ['before01','before02','legacy-after01','current-after02','current-visual03','before02-catalog-source','catalog-memory-before','review01-before','review02-before','review03-before','review04-before','review05-before'])
    tree(path.join(scratch,'ui/d1',dir),'desktop/d1/'+dir)
  for(const name of ['build-ui.ts','task-permission-history-locale-plan.md','implementation-408.patch','implementation-review01.json'])
    add(path.join(scratch,'ui',name),'desktop/'+name)
  for(const name of ['grant-read-driver.ts','grant-read-server.ts','grant-read-provider.ts','grant-read-control.mjs','grant-read-facts.mjs','task-observe.mjs','legacy-closed-compare.ts','before02-catalog-analysis.md','before02-catalog-log-review.json'])
    add(path.join(scratch,'ui/d1',name),'desktop/d1/current-helpers/'+name)
  for(const name of ['fixture408-current01','fixture408-current02','physical408-formal01','physical408-formal02','overlay408-types01','overlay408-types02','topology408-final01','migration408-final01','core408-types04','cli408-check01','global408-check01'])
    tree(path.resolve('.tmp-task-question-recovery-406/delivery-commands',name),'root-checks/'+name)
  tree(path.join(scratch,'cli-context-before01'),'root-checks/cli-context-before01')
  add(path.join(scratch,'capture-lock01.mjs'),'capture-lock01.mjs')
}else{
tree(path.resolve('.tmp-grant-decision-recovery-408/functionality',occurrence),'original-run')
tree(path.resolve('.tmp-grant-decision-recovery-408/functionality/cleanup-before'),'preparation/cleanup-before')
for(const name of ['cleanup-run-lock-probe.ts.patch','cleanup-launch-lock-probe.ts.patch','cleanup-lock-worker.ts.patch',
  'cleanup-syntax-read.json','migration-callers.txt','migration-history.txt','preparation-head.txt','preparation-status.txt'])
  add(path.resolve('.tmp-grant-decision-recovery-408/functionality',name),'preparation/'+name)
for(const stage of ['docs408-initial01','architecture408-initial01','archive408-initial01','prepare408-plan01',
  'commit408-plan01','fetch408-plan01','merge408-plan01','fetch408-plan02','merge408-plan02','push408-plan01','verify408-plan-fetch01'])
  tree(path.resolve('.tmp-task-question-recovery-406/delivery-commands',stage),'initial-delivery/'+stage)
for(const name of ['plan-commit.json','commit-plan.mjs','plan-scoped.patch'])
  add(path.resolve('.tmp-grant-decision-recovery-408',name),'initial-delivery/'+name)
add(path.resolve('.tmp-grant-decision-recovery-408/ui/production-scope-and-desktop-plan.md'),'ui-preparation/production-scope-and-desktop-plan.md')
tree(path.resolve('.tmp-grant-decision-recovery-408/ui/source'),'ui-preparation/source')
add(path.resolve('packages/opencorvus/tsconfig.json'),'tooling-input/opencorvus-tsconfig.json')
add(path.resolve('packages/opencorvus/test/empty-bunfig.toml'),'tooling-input/empty-bunfig.toml')
add(path.resolve('.tmp-grant-decision-recovery-408/capture-lock01.mjs'),'capture-lock01.mjs')
if(stage==='lock02'){
  tree(path.resolve('.tmp-grant-decision-recovery-408/functionality/import-argv-01'),'import-qualification')
  tree(path.resolve('.tmp-grant-decision-recovery-408/functionality/followup-before'),'tooling/argv-before')
  tree(path.resolve('.tmp-grant-decision-recovery-408/functionality/import-mode-before'),'tooling/import-mode-before')
  for(const name of ['argv-launch-lock-probe.ts.patch','argv-run-lock-probe.ts.patch','argv-syntax-read.json',
    'import-mode-launch.patch','import-mode-syntax-read.json','import-qualification-plan.md'])
    add(path.resolve('.tmp-grant-decision-recovery-408/functionality',name),'tooling/'+name)
  for(const name of ['historical-authority-index-contract.md','capture-index-contract-source.ps1'])
    add(path.resolve('.tmp-grant-decision-recovery-408/ui',name),'historical-contract/'+name)
  tree(path.resolve('.tmp-grant-decision-recovery-408/ui/index-contract-source'),'historical-contract/source')
  for(const name of ['lock-commit.json','lock-scoped.patch'])
    add(path.resolve('.tmp-grant-decision-recovery-408',name),'lock01-delivery/'+name)
  for(const name of ['archive408-lock01','docs408-lock01','architecture408-lock01','prepare408-lock01',
    'commit408-lock01','fetch408-lock01','merge408-lock01','push408-lock01','verify408-lock-fetch01'])
    tree(path.resolve('.tmp-task-question-recovery-406/delivery-commands',name),'lock01-delivery/'+name)
}
}
for(const item of items)assert(!/(^|\/)(auth\.json|models\.json|runtime|private-bundle)(\/|$)|\.(sqlite|db|wal|shm|pending)$/i.test(item.destination))
if(stage==='lock01'||stage==='lock02'){
const outer=JSON.parse(fs.readFileSync(path.join('.tmp-grant-decision-recovery-408/functionality',occurrence,'owner.json')))
const driver=JSON.parse(fs.readFileSync(path.join('.tmp-grant-decision-recovery-408/functionality',occurrence,'driver-owner.json')))
assert.equal(outer.receipt.reason,'exited');assert.equal(outer.receipt.exitCode,0)
assert.equal(driver.cases.length,2);assert.equal(driver.children.length,11)
}
fs.mkdirSync(target,{recursive:false});const files=[]
for(const item of items){
  const raw=fs.readFileSync(item.source),isImage=/\.(jpg|jpeg|png)$/.test(item.destination),destination=item.destination+(isImage?'':'.gz'),file=path.join(target,destination)
  fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,isImage?raw:gzipSync(raw),{flag:'wx'})
  assert((isImage?fs.readFileSync(file):gunzipSync(fs.readFileSync(file))).equals(raw))
  files.push({source:item.source,destination,bytes:raw.length})
}
fs.writeFileSync(path.join(target,'manifest.json'),JSON.stringify({capturedAt:Date.now(),files,
  boundary:stage==='final01'?'Original backend implementation/checker successes and failures, physical WAL qualification, real old producer upgrade and current desktop screenshot review. current-after02 failed at original close reserve and Task boundary/fixture failures remain explicit; final current-visual03 was normally closed and joined. Controlled streamed Provider evidence is not GPT/model quality or external client visual acceptance. DB/auth/catalog/runtime/private UI bundle/full Provider payloads excluded. Gzip/image roundtrip proves capture storage identity only.':stage==='lock01'?'Original first WAL file-exclusive mechanism run, initial normal delivery receipts and read-only UI plan. Both cases and 11 workers joined; Bun tsconfig internal diagnostics are retained, tooling remains under investigation. No production patch, business migration, Provider or UI acceptance. Gzip roundtrip proves capture storage identity only.':'Original complete lock suite repeated after natural package cwd/tsconfig repair, its import qualification, source preimages/diffs, historical contract and lock01 normal delivery. Both cases and 11 workers joined; original stderr preserved. No production patch, business migration, Provider or UI acceptance. Gzip roundtrip proves capture storage identity only.'},null,2),{flag:'wx'})
console.log(JSON.stringify({target,files:files.length,bytes:files.reduce((sum,row)=>sum+row.bytes,0)}))
