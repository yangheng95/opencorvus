import assert from "node:assert/strict"
import fs from "node:fs/promises"
import path from "node:path"
import { NodeProcess } from "../../packages/util/src/process-node"
import { expectedTestProcessSupervisor } from "../../packages/opencorvus/script/test-process-supervisor"
import { createManagedTemporaryDirectory, removeManagedDirectoryTree } from "../../packages/util/src/runtime-directories"

// Preparation only. No database is opened in this parent process.
const [scopeArgument, rawOuterDeadline] = process.argv.slice(2)
assert(scopeArgument && path.isAbsolute(scopeArgument), "An explicit absolute fresh scope is required")
const scope = path.resolve(scopeArgument), preparationRoot = path.resolve(import.meta.dir)
assert.equal(path.dirname(scope), preparationRoot, "The owned scope must be a direct child of this preparation directory")
const startedAt = Date.now(), deadlineAt = Number(rawOuterDeadline), closeBy = deadlineAt - 60000
assert(Number.isSafeInteger(deadlineAt) && deadlineAt > startedAt && deadlineAt <= startedAt + 600000,
  "The original physical wrapper deadline is required")
assert((await fs.stat(scope)).isDirectory())
await fs.mkdir(path.join(scope, "driver-admitted"))
const supervisor = expectedTestProcessSupervisor()
assert(supervisor, "The mature Windows owned-tree supervisor is required")
process.env.OPENCORVUS_PROCESS_SUPERVISOR = supervisor
const repository = path.resolve(import.meta.dir, "../.."), packageDirectory = path.join(repository, "packages/opencorvus")
const worker = path.join(import.meta.dir, "lock-worker.ts")
const children: any[] = [], cases: any[] = []
const environmentNames = ["SystemRoot", "SYSTEMROOT", "WINDIR", "COMSPEC", "ComSpec", "PATH", "PATHEXT", "TEMP", "TMP",
  "USERPROFILE", "HOMEDRIVE", "HOMEPATH", "APPDATA", "LOCALAPPDATA"]
const baseEnvironment = Object.fromEntries(environmentNames.flatMap(key => process.env[key] === undefined ? [] : [[key, process.env[key]!]]))
const owner: any = { startedAt, deadlineAt, closeBy, pid: process.pid, executable: process.execPath, bunVersion: Bun.version,
  scope, repository, supervisor, inheritedEnvironmentNames: Object.keys(baseEnvironment), maxConcurrentChildren: 2,
  candidateRevision: "scratch v2 with the same current DDL and no semantic callback; no business index" }
async function write(file: string, value: unknown) { await fs.writeFile(file, JSON.stringify(value, null, 2)) }
await write(path.join(scope, "driver-owner-start.json"), owner)
for (const source of [import.meta.filename, worker,
  path.join(packageDirectory, "src/storage/schema-migration.ts"), path.join(packageDirectory, "src/storage/db.ts"),
  path.join(packageDirectory, "src/storage/sqlite-statement.ts"), path.join(packageDirectory, "src/storage/schema-contract.ts"),
  path.join(packageDirectory, "src/storage/ddl.ts"), path.join(packageDirectory, "src/storage/checkpoint-worker.ts"),
  path.join(packageDirectory, "src/storage/migrations/index.ts"), path.join(packageDirectory, "src/storage/migrations/0001-baseline.sql")])
  await fs.copyFile(source, path.join(scope, `actual-${path.basename(source)}`))
function admission() { assert(Date.now() < closeBy, "Original parent close reserve reached") }
async function mark(evidence: string, name: string, value: unknown) {
  admission()
  await fs.writeFile(path.join(evidence, name), JSON.stringify(value, null, 2), { flag: "wx" })
}
async function read(evidence: string, name: string) { return JSON.parse(await fs.readFile(path.join(evidence, name), "utf8")) }
async function wait(evidence: string, name: string) {
  const waitDeadline = Math.min(Date.now() + 30000, closeBy)
  for (;;) {
    try { return await read(evidence, name) }
    catch (error) { if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error }
    if (children.some(child => child.evidence === evidence && child.endedAt && child.receipt?.exitCode !== 0))
      throw Error(`An owned child failed before ${name}; retain its original error and receipt`)
    if (Date.now() >= waitDeadline) throw Error(`Original parent observation deadline elapsed: ${name}`)
    await Bun.sleep(25)
  }
}
function spawn(role: string, runtime: string, evidence: string) {
  admission()
  assert(children.filter(child => child.requestStarted && !child.requestSettled).length < 2, "At most two owned children may be active")
  const childStartedAt = Date.now(), childDeadlineAt = Math.min(childStartedAt + 180000, closeBy)
  const args = [`--config=${path.join(packageDirectory, "test/empty-bunfig.toml")}`,
    `--tsconfig-override=${path.join(packageDirectory, "tsconfig.json")}`, worker, role, runtime, evidence,
    String(childDeadlineAt), String(deadlineAt)]
  const child: any = { role, runtime, evidence, executable: process.execPath, args, cwd: packageDirectory,
    startedAt: childStartedAt, deadlineAt: childDeadlineAt, parentDeadlineAt: deadlineAt,
    requestStarted: true, requestSettled: false, physicalJoined: false, outputJoined: false }
  children.push(child)
  let handle: any
  const operation = (async () => {
    await write(path.join(evidence, `${role}-spawn.json`), child)
    try {
      const result = await NodeProcess.run({ command: { executable: process.execPath, args }, cwd: packageDirectory,
        env: { ...baseEnvironment, OPENCORVUS_PROCESS_SUPERVISOR: supervisor!, OPENCORVUS_HOME: runtime,
          OPENCORVUS_TEST_HOME: path.join(runtime, "owned-home"), OPENCORVUS_TEST_PROCESS_ROOT: path.dirname(runtime) },
        ownership: "owned_tree", windowsHide: true, stdin: "ignore", deadlineAt: childDeadlineAt, nothrow: true,
        onSpawned(value) { handle = value; child.pid = value.pid; child.occurrenceID = value.occurrenceID } })
      child.receipt = result.receipt
      await fs.writeFile(path.join(evidence, `${role}-stdout.log`), result.stdout)
      await fs.writeFile(path.join(evidence, `${role}-stderr.log`), result.stderr)
      await handle.settled; child.physicalJoined = true
      await handle.outputSettled; child.outputJoined = true
      return result.receipt.exitCode
    } catch (error) { child.error = String(error); throw error }
    finally {
      if (handle && !child.physicalJoined) {
        child.receipt = await handle.terminate("aborted")
        await handle.settled; child.physicalJoined = true; child.emergencyOwnHandle = true
      }
      if (handle && !child.outputJoined) { await handle.outputSettled; child.outputJoined = true }
      child.requestSettled = true; child.endedAt = Date.now()
      await write(path.join(evidence, `${role}-owner.json`), child)
    }
  })()
  void operation.catch(() => undefined)
  return { child, operation }
}
let primary: unknown
try {
  for (const scenario of ["production-idle", "readonly-idle"] as const) {
    admission()
    const evidence = path.join(scope, scenario)
    await fs.mkdir(evidence)
    const ownedRoot = await createManagedTemporaryDirectory(scope, `${scenario}-`)
    const runtime = path.join(ownedRoot, "runtime")
    await fs.mkdir(runtime)
    const entry: any = { scenario, evidence, ownedRoot, runtime, startedAt: Date.now(), runtimeRemoved: false }
    cases.push(entry)
    const operations: Promise<unknown>[] = []
    const run = (role: string) => { const current = spawn(role, runtime, evidence); operations.push(current.operation); return current }
    try {
      if (scenario === "readonly-idle") assert.equal(await run("seed").operation, 0)
      const old = run(scenario === "production-idle" ? "hold-production" : "hold-readonly")
      const initial = await wait(evidence, "a-ready.json")
      assert.equal(initial.original.version, 1)
      const candidate = run("candidate")
      await wait(evidence, "b-normal-attached.json")
      const blocked = await wait(evidence, "b-blocked.json")
      assert.equal(blocked.error.code, "SQLITE_BUSY")
      await wait(evidence, "b-waiting-owner-close.json")
      await mark(evidence, "a-close", { reason: "The actual new writer observed this original admitted peer blocking file-exclusive admission" })
      assert.equal(await old.operation, 0)
      const oldTerminal = await read(evidence, `${old.child.role}-terminal.json`)
      assert.deepEqual(oldTerminal.beforeClose, initial.original)
      assert.equal(old.child.physicalJoined, true)
      await mark(evidence, "old-owner-joined", { exitCode: old.child.receipt.exitCode, physicalJoined: old.child.physicalJoined,
        outputJoined: old.child.outputJoined, requestSettled: old.child.requestSettled,
        pid: old.child.pid, occurrenceID: old.child.occurrenceID, endedAt: old.child.endedAt })
      const committed = await wait(evidence, "b-exclusive-committed.json")
      assert.deepEqual(committed.original, initial.original)
      assert.equal(committed.receipt.to, 2)
      assert.equal(await run("locked-reader").operation, 0)
      await mark(evidence, "unlock", { reason: "A separately joined real reader observed the retained file-exclusive lock" })
      const normal = await wait(evidence, "b-normal-released.json")
      assert.deepEqual(normal.mode, [{ locking_mode: "normal" }])
      assert.equal(await run("new-reader").operation, 0)
      assert.equal(await run("old-reopen").operation, 0)
      await mark(evidence, "b-close", { reason: "New read and original old-build reopening contract both observed under the same released NORMAL handle" })
      assert.equal(await candidate.operation, 0)
      entry.passed = true
    } finally {
      // Only the exact managed fresh runtime is removed, after its real child tree exits.
      await fs.writeFile(path.join(evidence, "stop"), "The original parent is closing this owned scope.\n")
      entry.operationResults = await Promise.allSettled(operations)
      entry.endedAt = Date.now()
      if (children.filter(child => child.evidence === evidence).every(child => child.physicalJoined && child.outputJoined && child.requestSettled)) {
        await removeManagedDirectoryTree(ownedRoot)
        entry.runtimeRemoved = true
      }
      await write(path.join(evidence, "case-owner.json"), entry)
    }
  }
} catch (error) { primary = error; owner.error = String(error); process.exitCode = 1 }
finally {
  owner.endedAt = Date.now(); owner.cases = cases; owner.children = children
  owner.allPhysicalJoined = children.every(child => child.physicalJoined)
  owner.allOutputJoined = children.every(child => child.outputJoined)
  owner.allRequestsSettled = children.every(child => child.requestSettled)
  owner.status = primary === undefined ? "passed" : "failed"
  await write(path.join(scope, "driver-owner.json"), owner)
  console.log(JSON.stringify({ status: owner.status, startedAt, deadlineAt, endedAt: owner.endedAt,
    allPhysicalJoined: owner.allPhysicalJoined, allOutputJoined: owner.allOutputJoined,
    allRequestsSettled: owner.allRequestsSettled, error: owner.error ?? null }))
}
