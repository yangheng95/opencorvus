import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import {gzipSync,gunzipSync} from 'node:zlib'
const target=path.resolve('specs/artifacts/2026-10-14-grant-decision-recovery-408/lock01')
const items=[]
function add(source,destination){assert(fs.lstatSync(source).isFile());items.push({source,destination})}
function tree(source,destination){for(const entry of fs.readdirSync(source,{withFileTypes:true})){
  assert(!entry.isSymbolicLink());const from=path.join(source,entry.name),to=destination+'/'+entry.name
  if(entry.isDirectory())tree(from,to);else add(from,to)
}}
tree(path.resolve('.tmp-grant-decision-recovery-408/functionality/lock-process-01'),'original-run')
tree(path.resolve('.tmp-grant-decision-recovery-408/functionality/cleanup-before'),'preparation/cleanup-before')
for(const name of ['cleanup-run-lock-probe.ts.patch','cleanup-launch-lock-probe.ts.patch','cleanup-lock-worker.ts.patch',
  'cleanup-syntax-read.json','migration-callers.txt','migration-history.txt','preparation-head.txt','preparation-status.txt'])
  add(path.resolve('.tmp-grant-decision-recovery-408/functionality',name),'preparation/'+name)
for(const stage of ['docs408-initial01','architecture408-initial01','archive408-initial01','prepare408-plan01',
  'commit408-plan01','fetch408-plan01','merge408-plan01','fetch408-plan02','merge408-plan02','push408-plan01','verify408-plan-fetch01'])
  tree(path.resolve('.tmp-task-question-recovery-406/delivery-commands',stage),'initial-delivery/'+stage)
for(const name of ['plan-commit.json','commit-plan.mjs','plan-scoped.patch'])
  add(path.resolve('.tmp-grant-decision-recovery-408',name),'initial-delivery/'+name)
add(path.resolve('.tmp-grant-decision-recovery-408/ui/production-scope-and-desktop-plan.md'),'ui-preparation/production-scope-and-desktop-plan.md')
tree(path.resolve('.tmp-grant-decision-recovery-408/ui/source'),'ui-preparation/source')
add(path.resolve('packages/opencorvus/tsconfig.json'),'tooling-input/opencorvus-tsconfig.json')
add(path.resolve('packages/opencorvus/test/empty-bunfig.toml'),'tooling-input/empty-bunfig.toml')
add(path.resolve('.tmp-grant-decision-recovery-408/capture-lock01.mjs'),'capture-lock01.mjs')
for(const item of items)assert(!/(^|\/)(auth\.json|models\.json|runtime|private-bundle)(\/|$)|\.(sqlite|db|wal|shm|pending)$/i.test(item.destination))
const outer=JSON.parse(fs.readFileSync('.tmp-grant-decision-recovery-408/functionality/lock-process-01/owner.json'))
const driver=JSON.parse(fs.readFileSync('.tmp-grant-decision-recovery-408/functionality/lock-process-01/driver-owner.json'))
assert.equal(outer.receipt.reason,'exited');assert.equal(outer.receipt.exitCode,0)
assert.equal(driver.cases.length,2);assert.equal(driver.children.length,11)
fs.mkdirSync(target,{recursive:false});const files=[]
for(const item of items){
  const raw=fs.readFileSync(item.source),destination=item.destination+'.gz',file=path.join(target,destination)
  fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,gzipSync(raw),{flag:'wx'})
  assert(gunzipSync(fs.readFileSync(file)).equals(raw))
  files.push({source:item.source,destination,bytes:raw.length})
}
fs.writeFileSync(path.join(target,'manifest.json'),JSON.stringify({capturedAt:Date.now(),files,
  boundary:'Original first WAL file-exclusive mechanism run, initial normal delivery receipts and read-only UI plan. Both cases and 11 workers joined; Bun tsconfig internal diagnostics are retained, tooling remains under investigation. No production patch, business migration, Provider or UI acceptance. Gzip roundtrip proves capture storage identity only.'},null,2),{flag:'wx'})
console.log(JSON.stringify({target,files:files.length,bytes:files.reduce((sum,row)=>sum+row.bytes,0)}))
