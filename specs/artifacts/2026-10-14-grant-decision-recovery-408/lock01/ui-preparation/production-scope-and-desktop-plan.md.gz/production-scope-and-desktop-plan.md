# 408 current production scope, canonical decision contract and bounded desktop plan

Read-only preparation after reading the complete 408 Recall. HEAD at start: `5449398be8381d4ecd9e3669eb86ce4da3220a42`, including delivered 407. No production, tests, SDK, shared spec/docs or Git changes; no UI-test search/execution, service, browser, model, credential or database access. The exact historical indexing event name, semantic revision and lock implementation remain **unselected**. Only the scope and acceptance boundaries below are proposed for Root review.

This is a consolidation of the frozen 407-scratch grant projection, raw-adapter and migration-coordination reports, with current source rechecked. The old production behavior is still present: Authority's active-grant branch at `authority.ts:865` has no slot; standalone Asked only checks lineage; Task Replied does not emit exact resolved invalidation; Board directly reads the slot; Settings uses event labels plus outcome-prioritized grouped history. No old report's runtime counts become a new 408 result.

## 1. The smallest coherent delivery scope

The grant producer, canonical reader, cold/live consumers and accepted historical upgrade must form one delivery. Backend/protocol correctness can be qualified locally; external client visual behavior cannot be inferred from that. An implementation allowlist is not yet granted by this document.

| Tier | Candidate production paths | Why required / exact boundary |
| --- | --- | --- |
| Core current decision | `packages/opencorvus/src/permission/authority.ts` | One writer transaction reads the exact winner, validates current grant eligibility and claims grant_used. Winning capture owns real `Replied(autoReply:true)` in the existing outbox and releases actual local waiters. Preserve 407 retirement, actual effect source and physical owner; propagate real SQL errors. |
| Shared typed read | One small Permission-owned fact-reader module, final filename to be selected; replace current private direct slot reader and Engine direct read | One implementation resolves the original requested owner and original decision. Do not put Database/Engine imports into the currently light `permission/decision.ts` Zod enum without checking cycles; `permission/types.ts` already imports that enum. No second Request schema or copied scope/time source. |
| Session live | `packages/opencorvus/src/protocol/session-mirror.ts` | Re-read canonical facts immediately before projecting late Asked; original Request fields/summary/order remain intact. Keep durable non-Task lineage and exact Project admission. Replied/Terminated remain current actual events. |
| Task sole owner | `packages/opencorvus/src/engine/store.ts`, `packages/opencorvus/src/engine/interaction.ts` | Board derives decision, automatic provenance and time from the same canonical original. Real Replied validates its ledger/Task owner and reuses existing ephemeral `interaction.resolved` invalidation. Do not append EngineInteractionOutcome for Permission. Late Asked must first appear with its current derived terminal state if already decided. |
| Historical semantic upgrade, conditional on approval | `permission/permission.sql.ts` closed event union; `storage/migrations/index.ts` and a new immutable revision/semantic implementation; current integrity validator only if the exact new contract requires it | Event name/shape not selected. Preserve original ledger graph and original authorization time; new index occurrence, if approved, has its own time. Ambiguous facts yield explicit migration error. No edit of 0001. |
| Safe physical upgrade, conditional on qualification | Existing `storage/schema-migration.ts`; `storage/db.ts` initialization/cleanup ordering only if necessary | Qualify NORMAL WAL attach → actual database-file EXCLUSIVE → version re-read/backup/migrate/validate → NORMAL plus real release access. No new process census, shadow schema version or lock protocol is authorized. |
| Settings history and language, conditional on the new historical fact | `packages/overlay/src/components/settings/PermissionsPanel.tsx`, exact new keys in `i18n/en-US.json` and `zh-CN.json` | Localized neutral index-event description; the actual operation status must still represent original decision/execution. Keep both real timeline rows and their own times. Existing saved-approval-use labels remain correct. |
| Existing Main/Side reducers, expected unchanged | `services/tree-writer.ts`, `services/side-chat.ts`, `services/conversation.ts`, `utils/permission-interaction.ts`, `InteractionCard.tsx`, `InteractionDialogHost.tsx` | Their current pending-only Permission deletion and complete pending-array replacement already consume real Replied/Terminated. They need qualification, not a frontend tombstone or compensating HTTP reload. Source/directory/API authority/selectEpoch capture in user actions stays as delivered. |
| Raw adapter bounded correctness, only after explicit scope approval | `permission/pending-projection.ts`, `acp/agent.ts`, optionally read-only enumeration in `acp/session.ts`; `cli/cmd/run.ts`; `channel-runtime/src/core.ts`; `channel/ingress.ts` | Revalidate actual actionable pending requests, preserve true HTTP errors, format returned decision winner, and distinguish history notice from current waiting. ACP cancellation remains cooperative. Do not make third-party visual interoperability a fabricated local pass condition. |

No public schema change is necessary merely to use `Event.Replied.autoReply` or `Interaction.response.auto_reply`: both existing contracts already admit them. Public Permission history's event_type is string. A new private ledger event name alone does not require hand-editing generated SDK files. A newly required field/event chosen later would require full producer/consumer/OpenAPI/SDK review and the normal unique generation transaction.

## 2. Canonical reader contract matrix

The final function name is deliberately not prescribed. The reader should accept the actual synchronous database context and exact request identity, so decision capture and readers can use the same transaction rather than perform a second independent lookup. Existing `PermissionRequest`, `PermissionDecision` and `PermissionLedgerTable` row types are the source definitions. The result is a derived view of those facts, not another stored permission state.

| Contract element | Required source/output | Explicitly excluded |
| --- | --- | --- |
| Original request | Exactly one immutable requested owner: original Project/Task/Session/Message/call, scope/provider/fingerprint, choices, summary and timeCreated | Rebuilding an owner from a current selected UI Session, technical title or final Tool status; copied Request schema |
| Pending | Original requested owner exists and has no canonical decision slot under the current migrated format | `slot || latest grant_used`, frontend resolved-id cache, current active-grant eligibility used as an unstored decision |
| Current direct decision | The actual unique slot winner, validated as a legal decision event; exact original event id, decision value, scope, time and provenance | Unknown event types defaulting to allow_once; using whatever last ledger row happens to exist |
| Approved historical index | If Root chooses it, follow its explicit validated original-decision reference. Return the original authorization id/time/scope; expose index identity only where its own real history is relevant | Calling an index a new approval or grant, recursive best-effort fallback, copied/backdated migration time, ambiguous winner selection |
| Automatic saved approval | Derived from the real original grant_used capture and real source grant; new winning notification has autoReply:true | Inferring autoReply from English summary, selected model or migration event name; a second persisted boolean source |
| Rejection/termination | A real denied/cancelled/stale decision slot yields the current canonical negative decision/status and original time. Existing continuation-retirement stale without a decision slot remains its different fact role | Converting normal retirement into a new denied decision or emitting fake user reply |
| Time and ordering | Request order uses original request time/id. Task response order and resolved time use original decision time/id | Event delivery time, index time, current clock or Session order key substituted for a decision timestamp |
| User-authored input | Only actual winning user-reply outbox/occurrence input remains authored evidence | Copying source grant's operator text, inventing a new human approval on reuse or migration |
| Strict corruption/error | Missing owner, wrong source graph, illegal decision kind/scope/Project, ambiguous historical original or index conflict becomes a precise error | Silent omission from the pending list, guessed default scope, latest-row heuristics |
| Current grant eligibility | Writer checks active grant/revoke/expiry atomically at **new capture** | Re-evaluating today's revoked status to erase a historical captured authorization |
| Execution/recovery | Existing execution-start/result/physical-owner readers continue to own their distinct facts; the original decision authorizes them | Treating a successful Tool as permission authority, replaying an already executed effect, merging decision and execution state |

Consumer requirements:

| Consumer | What it needs from the single fact view | Correct resulting behavior |
| --- | --- | --- |
| Authority admission, pending/list, wait/replay, continuation retirement/recovery | Exact canonical original decision and owner | All paths agree on the actual winner; grant reuse is no longer falsely pending or excluded from 407 retirement |
| Session HTTP hydration and connected snapshot | Complete current pending Permission Request set, admitted by existing durable lineage | Empty/changed arrays replace pending projection; absence does not invent answered history |
| Session late Asked bridge | Current canonical decision check plus original Request validation | An obsolete Asked cannot recreate a pending Main/Side card; transport remains driven by real events |
| Main inline/Dialog and independent Side | Existing Replied/Terminated exact request/session and pending snapshot | Current pending card leaves; Question draft identity and original source authority remain unchanged |
| Task Board | Original decision value/time/provenance under existing Interaction request owner | Board, cold reopen and response order all agree. A new index is not the response occurrence |
| Task Replied notification | Validated current original decision + exact Task/Session/Project + existing Interaction when present | Existing `interaction.resolved` invalidates the correct Board. Notification does not become another decision row |
| Settings records | Full append-only ledger plus original requested owner | Real grant use and any neutral index remain visible; execution badge is not replaced by bookkeeping |
| ACP/CLI client read | Current exact-Session pending array through existing API | Canonical preflight only; absence cannot be called approved without a decision fact |
| Channel human action | Fresh Task Interaction + actual post-CAS winner | Existing command chooses current pending authority; confirmation describes actual result, not attempted action |

Important Task race boundary: if real Replied arrives before any Task Interaction exists, the current handler returns. Late Asked may subsequently materialize its request projection and read a terminal decision immediately. The implementation must cover both arrival orders without manufacturing a prompt or Engine outcome. Authentic userInput capture must remain tied to the original winning occurrence; an automatic capture supplies none.

## 3. UI language and history scope that must be decided before touching it

Settings is the smallest directly necessary frontend change if an index is chosen. Its labels call current `t()`, dates call current `localeTag()`, and expanding/refetching uses the original directory resource. Include English→Chinese→English on the **same mounted history**. The Settings resource is not subscribed to live Permission events: use its visible Refresh control; do not claim automatic refresh.

There is one known adjacent Task-history limitation worth deciding explicitly. `engine/store.ts:683` currently builds `Permission: <tool_name>`; resolved Permission history is converted into text seeds by `utils/interaction.ts`, which calls `interactionResponseText` before rendering. Unlike the 405 Question history part, it is not a reactive current-locale history part. Adding `response.auto_reply` can make the existing translated auto prefix visible, but does not itself guarantee that a language switch updates an already created text seed. Pending Dialog icon labels already use current locale; this does not cure historical text.

Minimum recommendation: include a real same-mounted Task history language check when the auto provenance becomes visible. If it fails and Root includes that region, reuse the existing canonical interaction-part/TextPart pattern (original phase identity and existing `t()`), not a second renderer or pretranslated stored body. Candidate additional files would be `utils/interaction.ts`, `utils/transcript.ts`, `components/CardParts.tsx`; original Question behavior remains untouched. If Task's technical heading is adjusted, derive the raw tool name from its canonical field at both existing producers, not by stripping an English substring. **None of this additional UI scope is approved now.** Alternatively keep it a named independent follow-up and do not claim all Task history language behavior is complete.

Do not enlarge 408 into all ACP/client/channel localization. Real external messages and client-rendered names require their own current language/configuration contracts. In this batch, the concrete index history labels and any newly touched local renderer must be truthful and localized, while existing unrelated client language gaps remain named boundaries.

## 4. Minimal independently reviewable desktop sequence

Use the existing mature owned runner and product `/ui`, never a standalone Vite server or browser automation test. Every new scope gets its own fixed 600 s parent, bounded children/HTTP requests and 60 s close reserve. Root owns all real UI interactions and screenshot review. These are plans, not results.

### D1 — Main saved approval, repeated real read, cold state and Settings

This can yield useful before/after evidence independently of a Task or external client:

1. Fresh owned data root/Project/Session with Ask effective before its first permission-bearing invocation. Permission mode is frozen per Session; changing a setting after a Full-access invocation is not a valid Ask setup.
2. Use a public, synthetic, non-secret CSV located **outside the actual canonical Project roots**, so the real built-in read produces a permission descriptor. `invocation.ts:341–350` deliberately exempts ordinary reads inside the Project; such an input would not exercise this bug. Confirm the real Request reports projectGrantEligible and offers allow_project; do not hardcode a choice the real schema does not offer.
3. A controlled streaming Provider can naturally return the declared read Tool for that real path. Root selects the real Allow for project action in the visible Main Dialog, observes actual Tool data and natural final/idle, and captures the original ledger grant. This is the human grant-creation baseline.
4. Send a second real prompt that reads the exact same public file/scope with a new natural Tool call. Confirm from real facts that request id changed while canonical fingerprint, provider and scope match. Root observes actual returned content and final result. Reuse is established by the genuine grant_used → execution_start source relationship, not by “no dialog appeared”.
5. Cold-select/reopen the same Session. Capture its complete pendingPermissions response and the visible conversation. The pre-fix old source can naturally leave the already executed second request pending on cold hydration; record what actually occurs, not an expected screenshot. After repair, exact pending-set contents and the actual Tool result must agree.
6. Open Settings → General → Permission records, expand the actual two operations and use Refresh. Capture original saved grant, saved approval use and actual execution result. If historical indexing is approved and qualified, the same **closed** before-scope data root can be reopened by the new source to exercise real original facts; both original grant-use and index timestamps must remain visible and distinct. Do not rewrite the old data or manufacture a history row for a screenshot.
7. On the same mounted history, switch English→Chinese→English and review event/operation labels, scope, dates, controls and error state, preserving authored scope/summary. Revoke only this scope's own saved grant during cleanup if Root chooses to verify revoke; preserve the real history and original sample file until needed evidence is captured.

This establishes the concrete shared defect with one normal desktop entry plus Settings. It does **not** by itself cover a deliberately reordered Asked event or a Task's automatic resolved notification.

### D2 — Independent Side consumer

Create the Side through the real Side Chat interface, with its actual independent Session and directory. Use its own synthetic file/fingerprint when a first-time visible decision is needed; otherwise explicitly prove an existing grant matches the Side's canonical fingerprint/working directory. Two Sessions in the same Project are not sufficient evidence that scopes match. Exercise a real first decision and exact subsequent reuse, then close/reopen the Side to inspect the canonical pending set and real Tool/final. Preserve Main's source and reading position; this checks existing exact-Side filtering and per-source ownership.

No new Side queue, manual deletion of cards, synthetic answered bubble or forced frontend HTTP reload is part of the fix. A cold Side test is not evidence for a warm late-Asked race. Root may run D2 as a second fresh 600 s scope rather than squeeze it into D1's closing reserve.

### D3 — Task Board representative, without manufacturing an automatic card

Use an actual public Task with its legal concrete Project/workspace and admitted profile. Put the synthetic target outside the **actual Task binding roots**, verify the real Request choices, and grant only its actual offered scope. A Task-scoped grant and a Project-scoped grant are separate contracts; do not assume a grant made in a Main working directory will match a Task capsule's scope.

Observe a real pending Task Permission and its natural resolution/Tool progress; cold Board uses the original request/decision clocks. A second grant-reused Tool may never emit Asked and therefore may correctly create no Permission Interaction at all. **Do not create a fake Task Interaction just to display Auto Reply.** Its real saved-approval-use remains verifiable in Settings and actual execution facts.

The harder “already mounted Task Permission settles automatically after a prior Asked” path requires a naturally reachable same-request contender/recovery scenario. A simple second prompt after saving the grant does not establish that scenario. First prove both arrival orders with the real backend/protocol checker. If Root's public harness cannot reach this exact state naturally, report Task notification as backend/protocol-qualified and the ordinary Task desktop as representative only; do not label the auto-resolution visual scenario passed. Never fake typeddecision, Taskcompleted, role messages, Bus UI events or manual Board state to fill the gap.

### D4 — Error path and migrated history, only after lock qualification

Use only a fresh owned prior-format sample created by the former real producer and close every owner before upgrade. Root's separately approved bounded storage experiment determines whether safe automatic migration is available. A real ambiguous/corrupt sample can qualify an explicit backend migration error; it must not enter a user database or silently render a repaired state. Desktop error visibility is a separate real startup/route observation if needed, not a reason to reset the sample.

No historical index screenshot is planned before the event semantics and lock qualification are approved. D1–D3 can be prepared while those decisions remain open, but the final delivery cannot claim historical recovery complete without them.

## 5. Local protocol coverage versus external interoperability

| Area | Can be completed locally under a later exact authorization | Cannot be claimed from that check |
| --- | --- | --- |
| Authority/ledger | Real SQLite winner, event/outbox, waiter, actual Tool/result, current pending set, replay/retirement; current and historical graph/error contracts | Model behavior, all real UI paths or external-client dismissal |
| Late Asked | Backend protocol checker with original real accepted Asked, real canonical decision and actual Bus retry/delivery ordering; exact Main/Side Session stream output and Task derived result | That a user naturally hit the ordering on one desktop page; no UI-generated fake event |
| Task resolved notification | Real canonical winner validates and emits existing task event with actual response order/time; Board conditional GET observes current state | Permanent staleness in every old run, or real automatic-history screenshot when no Asked existed |
| Main/Side/Settings | Root's real native interaction, original screenshots, manual visual review, actual public response and closure receipts | Raw ACP/CLI/channel or mobile coverage |
| ACP | Actual installed SDK 1.4.0 wire protocol, queue head/pre-reply canonical reads, exact cancellation request id, real peer response/connection close and HTTP error handling | Visual dismissal or queue release by a non-cooperating external client. Cooperative cancellation does not settle the Promise |
| CLI | Existing project `/event`, public canonical pending API, real emitted JSON/text and actual input's terminal/idle result | A native authorization widget—there is none—or replay of events the route does not retain |
| Channel action | Real channel ingress/Task API returns the actual decision winner and truthful confirmation; original incoming user text remains genuine | Delivery/formatting in Slack/Discord/other external clients or editing/deleting a prior notice; adapter has no such API |
| Channel relay | Original raw event routing and current-history notification semantics can be protocol-qualified | Reconnection completeness for all external bindings, all languages or all Project routes without separate evidence |
| Migration exclusion | Separately approved old/new physical process experiment for the actual WAL domain and explicit unsupported entry-state error | Arbitrary rollback/custom VFS safety or an unregistered user process having closed |

Existing ACP/CLI pending helper and Channel's fresh Task Interaction list are the proper consumers of the same facts. ACP can revalidate at the actual queue head and after an actual selected response; remove the ever-growing projected-id Set as an authority substitute if that adapter is modified, retaining only owned live request handles in the existing queue. Use the installed typed cancellation API; do not force-resolve, deny on disconnect, close a user's whole Session or introduce a timer. CLI/channel can distinguish a past request notice from a currently waiting claim; only a genuine settlement event justifies a named terminal notice. Channel's returned command result must describe its actual post-CAS winner, not “approved always” merely because the user typed always.

No external ACP app or outbound channel account is needed to prove the local Permission decision contract. If those interfaces are included in this delivery, label their local protocol acceptance precisely and retain external interaction/visual behavior as unknown. Avoid a broad “all clients repaired” completion claim.

## 6. Stop conditions, retained evidence and decision list

- The writer/index semantics and lock qualification remain Root decisions. Do not choose an event name, revision number, new response field or additional frontend renderer from this plan alone.
- A false pending list, wrong winner/time/scope, mismatched Task notification, migration error swallowed as success or fake userInput fails the core batch; a later successful Tool cannot mask it.
- A real Settings label/layout problem must be repaired and photographed again in its exact selected scope. Type/build/HTTP success is not its visual acceptance.
- If the auto Task display requires extra locale work, explicitly authorize the small existing renderer path or retain a named follow-up. Do not declare it complete from initial-language rendering alone.
- Before/after raw JSON, original screenshots and original failure logs remain tied to their real owner, source build and timestamps. Scope termination is physical/request/output closure under original deadlines; no runtime/database/auth/model payload dump in evidence.
- Capture the actual public CSV bytes and exact real Tool output, canonical request/decision/source-event relationships, HTTP pending/Board/history responses, language state, selected source and original process receipts. No checksum-only or negative-call gate substitutes for these behaviors.
- Final practical minimum: core backend/protocol + Main/Settings before/after + independent Side + ordinary Task representative; automatic Task arrival-order proof is separate. External ACP/channel visual interop, mobile, exhaustive providers and every Task/Mission workflow stay explicitly unverified unless separately exercised.

This is a reviewable scope/contract plan only. Root owns final spec, exact allowlist approval, real execution and delivery.
