import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import { gzipSync, gunzipSync } from 'node:zlib'

const prepared = path.resolve('.tmp-grant-decision-recovery-408/functionality')
const scope = path.join(prepared, 'lock-followup-01')
const target = path.resolve('specs/artifacts/2026-10-14-grant-decision-recovery-408/followup01')
const items = []
const add = (source, destination) => {
  assert(fs.lstatSync(source).isFile())
  items.push({ source, destination })
}
function tree(source, destination) {
  for (const entry of fs.readdirSync(source, { withFileTypes: true })) {
    const from = path.join(source, entry.name), to = destination + '/' + entry.name
    assert(!entry.isSymbolicLink())
    if (entry.isDirectory()) tree(from, to)
    else add(from, to)
  }
}
tree(scope, 'original-failed-run')
tree(path.join(prepared, 'followup02-before'), 'prepared-input/preimages')
for (const name of ['followup-plan.md', 'followup-handoff.json', 'followup-preparation-manifest.json',
  'followup-preservation.json', 'followup-status.txt', 'followup-syntax-read.json',
  'followup02-launch-lock-probe.ts.patch', 'followup02-run-lock-probe.ts.patch', 'followup02-lock-worker.ts.patch',
  'shared-deadline-boundary.md', 'shared-deadline-callers.txt', 'shared-deadline-direct-supervisor-callers.txt',
  'shared-deadline-source-excerpts.json', 'followup01-race-analysis.md']) {
  add(path.join(prepared, name), 'prepared-input/' + name)
}
for (const name of ['qualification-commit.json', 'qualification-scoped.patch']) {
  add(path.resolve('.tmp-grant-decision-recovery-408', name), 'lock02-delivery/' + name)
}
for (const name of ['archive408-lock02', 'docs408-qualification01', 'architecture408-qualification01',
  'prepare408-qualification01', 'commit408-qualification01', 'fetch408-qualification01',
  'merge408-qualification01', 'push408-qualification01', 'verify408-qualification-fetch01']) {
  tree(path.resolve('.tmp-task-question-recovery-406/delivery-commands', name), 'lock02-delivery/' + name)
}
add(import.meta.filename, 'capture-followup01.mjs')
for (const item of items) {
  assert(!/(^|\/)(auth\.json|models\.json|runtime|private-bundle)(\/|$)|\.(sqlite|db|wal|shm|pending)$/i.test(item.destination))
}
const outer = JSON.parse(fs.readFileSync(path.join(scope, 'owner.json')))
const driver = JSON.parse(fs.readFileSync(path.join(scope, 'driver-owner.json')))
assert.deepEqual({ reason: outer.receipt.reason, exitCode: outer.receipt.exitCode }, { reason: 'exited', exitCode: 1 })
assert.equal(driver.cases.length, 1)
assert.equal(driver.children.length, 3)
assert.equal(driver.status, 'failed')
for (const child of driver.children) {
  assert.deepEqual({ physical: child.physicalJoined, output: child.outputJoined, request: child.requestSettled },
    { physical: true, output: true, request: true })
}
fs.mkdirSync(target, { recursive: false })
const files = []
for (const item of items) {
  const raw = fs.readFileSync(item.source), destination = item.destination + '.gz', file = path.join(target, destination)
  fs.mkdirSync(path.dirname(file), { recursive: true })
  fs.writeFileSync(file, gzipSync(raw), { flag: 'wx' })
  assert(gunzipSync(fs.readFileSync(file)).equals(raw))
  files.push({ source: item.source, destination, bytes: raw.length })
}
fs.writeFileSync(path.join(target, 'manifest.json'), JSON.stringify({ capturedAt: Date.now(), files,
  boundary: 'Original first followup failed at the race checker after genuine from1/to2 and from2/to2 returns. One case and three workers ran; all original request/physical/output receipts joined. Later fault/reopen cases were never started. Preserves the failed original result and its complete input, analysis and preceding normal Git delivery. No production patch, semantic migration, credentials, raw DB/runtime, UI or model acceptance. Gzip roundtrip proves capture storage identity only.' }, null, 2), { flag: 'wx' })
console.log(JSON.stringify({ target, files: files.length, bytes: files.reduce((sum, row) => sum + row.bytes, 0) }))
