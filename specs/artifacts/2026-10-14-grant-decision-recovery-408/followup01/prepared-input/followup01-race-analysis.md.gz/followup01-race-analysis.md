# 408 followup01 双候选真实结果与检查器根因（只读）

## Recall 与当前边界

Root 要求只读核对 fresh `lock-followup-01` 全部原 ready/common marker/attempt/terminal/owner、实际冻结源码和当前 migrator，并查对应 SQLite/Bun 权威资料。不得重跑实验、改生产或辅助源码、覆盖首轮失败、制造 BUSY、延时或延长任何原 owner。此次只写本报告；操作为读文件、解析既有公开 JSON、完整对象比较和浏览官方资料，没有调用 SQLite 构造/SQL/Provider，也没有新进程实验。

已读原 `actual-lock-worker.ts`、`actual-run-lock-probe.ts`、`actual-schema-migration.ts`、当前对应源、SQLite finalized query 原语；完整读取 scope/case/三 child 的 owner、ready、attempt、terminal 与原 stderr。Root 原工具 `8e9d48` 为 **exit1**，仍然是一次失败的检查器执行，不能将其中两个 migrator 成功回执改写成 scope 通过。

结论先行：**确定的直接失败是 worker 把每个成功的迁移调用固定解释为 `from1/to2`；深层假设是把 ready 时的 NORMAL/v1 状态当作随后锁升级期间始终不变的 idle blocker，并据此要求至少一个 surfaced SQLITE_BUSY。该假设不成立。** 本轮真实结果是一个 `1→2` 升级和另一个 `2→2` 当前版本校验；两个候选都使用支持 scratch v2 的同一 registry，第二个不是旧 v1 decoder 获准继续读新格式。原期望错误并不证明历史 grant 迁移安全，独立旧版 reader 与两个候选同在的组合仍应补真实验收。

## 原 scope、真实三 worker 与时序

证据目录：[原 scope](lock-followup-01/owner.json)、[原 case](lock-followup-01/normal-candidate-race/case-owner.json)。完整父起点 `1791958078263`、固定 deadline `1791958678263`、结束 `1791958083714`（5451ms）；driver PID79256 / occurrence `92cc2a56-e50c-4073-a9d8-f96851029373`。原 request/physical/output 均 joined，driver/outer failed。只有一个 case 启动；不是预计三 case/十四 worker 都已测。

| 原事实 | 实际值与证据 |
| --- | --- |
| seed | PID87576 / occurrence166b031b-38b9-464a-a9f0-d489826f9b02；production Client 正常 v1/WAL，517对象/90表，identity853de0cd-198f-438c-b420-82376769f9ad；正常 close1791958079562，owner joined1791958079611，exited0。 |
| race-a ready | PID80316 / occurrence53701579-ba4c-4c79-8d0a-9a906324bea2；NORMAL、WAL、完整原 v1。ready 文件的 startedAt 是进程起点，不伪称为 ready 完成时刻。 |
| race-b ready | PID61964 / occurrencec6a40d44-a07e-4886-a12a-54c32f373c49；NORMAL、WAL、完整原 v1，同样没有独立 ready-complete 时间戳。 |
| common marker | [race-start](lock-followup-01/normal-candidate-race/race-start) observedAt1791958080030，父已读取两份 ready，记录两个真实 PID/原 NORMAL/WAL。它只证明共同准入前置，不是 OS 同时执行屏障或后续持续持锁证明。 |
| A 原调用 | [attempt](lock-followup-01/normal-candidate-race/race-a-attempt.json) started1791958080042、returned1791958080419，377ms，`from:1,to:2`，原真实 backupPath。validation observed1791958080407/version2；最终 committed 快照 version2。 |
| A 原释放 | [terminal](lock-followup-01/normal-candidate-race/race-a-terminal.json) 保存真实 backup v1/strict close、NORMAL pragma 加 actual authority SELECT；rawClosedAt1791958083422。NORMAL release 没有独立时间戳，不能把 rawClosedAt 当作该 SQL 的确切执行时间。owner joined1791958083466，exited0。 |
| B 原调用 | [attempt](lock-followup-01/normal-candidate-race/race-b-attempt.json) started1791958080044、returned1791958083609，3565ms，**`from:2,to:2`**；validation observed1791958083609/version2，完整 committed 快照 version2。 |
| B 原失败与关闭 | [stderr](lock-followup-01/normal-candidate-race/race-b-stderr.log) 精确断言 actual from2 vs expected from1，worker252；[terminal](lock-followup-01/normal-candidate-race/race-b-terminal.json) rawClosedAt1791958083630、cleanupErrors[]；owner joined1791958083669，exited1。 |

以原 JSON 完整对象进行只读比较，A/B ready.original 均与 seed 完全相等；A/B terminal.original 同样相等；两份实际 committed 在仅将 version2 比较为原 version1 后，对全部对象、表、rowid、正文与 bytes 的结构相等。A 的实际 backup 完整 v1 与 seed 相等。没有以源码摘要或重算 hash 代替该对象比较。

**未到达项**：B 在252行已经失败，未执行它后面的 backup/NORMAL-release 分支；不能补称 B 正常解锁 SQL 已通过，它只有真实 strict close。父等待两个 operation 时得到 B 原拒绝，尚未执行父的 busy计数与 `race-owners-joined`，因此那些父断言是静态发现的待修假设，不是本次第二个运行失败。`after-race`、`followup-reader`、`old-reopen`、backup-file-failure、validator-failure 全未启动。实际三 child exited0/0/1，三套物理/输出/request 均闭合，唯一 managed root 正常删除。后续候选范围不能计入覆盖数。

## 现有生产 migrator 与 worker 的真实顺序

`lock-worker.ts:223–261` 先 NORMAL 真读完整 v1，再等待 common marker，然后只设置 `PRAGMA main.locking_mode=EXCLUSIVE`，随后调用唯一 `migrateSchema`。`openRaw` 原 `busy_timeout=5000` 没变；没有 JavaScript retry/reopen。在 `migrate()` 的 validate 回调里才保存事务内完整 version2 快照。

`schema-migration.ts:175–286` 的次序是：校验声明 registry（两独立 memory DB）→ source `PRAGMA foreign_keys`→ source `PRAGMA foreign_keys=OFF`→ **事务前** `schemaVersion(source)`→ `BEGIN IMMEDIATE`→ **事务内再次** `from = schemaVersion(source)`→只在 from<target 时备份/应用升级→真实 schema/foreign-key/用户 validate→COMMIT→还原 foreign_keys。因此原 ready 的 v1、甚至该函数事务前局部 from，都不是返回 receipt.from 的最终事实；返回值来自进入原事务后的第二次读。`from===2` 时仍执行真实校验与事务提交，但不再做1→2升级或第二份迁移备份。

事务前 PRAGMA/版本查询都是真实 source 操作，但不是“已经获得文件 EXCLUSIVE”的证明。`queryAllFinalized` 原语会结束 statement；ready 阶段没有人为保留读事务。`locking_mode` 是连接策略设置，不是原生锁 receipt。本文没有为调查 monkeypatch `sqlite.exec`、增加 production hook 或抄另一份 migrator。

## 对应版本的 SQLite/Bun 依据与可推断程度

实际 seed 的 `sqlite_version()` 为3.53.2，source_id为 `2026-06-03 19:12:13 d6e03d8c777cfa2d35e3b60d8ec3e0187f3e9f99d8e2ee9cac695fd6fcdf1a24`。官方 [version-3.53.2 manifest.uuid](https://raw.githubusercontent.com/sqlite/sqlite/version-3.53.2/manifest.uuid) 的发布源码身份与原记录一致；这是核对真实 SQLite 来源，不是自行计算源码校验和门槛。Bun1.4.0 来自各原 owner；[Bun SQLite 文档](https://bun.com/docs/runtime/sqlite)说明其 Windows/Linux 构建使用静态 SQLite，接口同步。未用其他 Bun/SQLite 版本的结果替代本机事实。

1. [SQLite locking_mode 文档](https://www.sqlite.org/pragma.html#pragma_locking_mode)把策略切换和实际文件锁动作分开；NORMAL 回退后还需要真实访问才释放原锁。对应 [pragma.c653–689](https://raw.githubusercontent.com/sqlite/sqlite/version-3.53.2/src/pragma.c)只是调用 pager 的 mode 设置；不是 OS 排他锁收据。
2. [对应 pager.c6941–6951、5621–5645](https://raw.githubusercontent.com/sqlite/sqlite/version-3.53.2/src/pager.c)显示 mode 设置更新 exclusiveMode；WAL 写事务开始时需要真正提升文件锁，然后转换 WAL 子系统模式和取得写锁。故“两个 ready 是 NORMAL”不保证随后申请写事务的过程中两读锁都维持原样。
3. **本次关键遗漏是 Windows 锁转换**：[os_win.c3202–3212](https://raw.githubusercontent.com/sqlite/sqlite/version-3.53.2/src/os_win.c)在提升 EXCLUSIVE 时，先执行 `winUnlockReadLock`，然后请求共享字节范围上的排他锁；失败则尝试重新取得读锁。两候选都在主动升级，其各自的读锁可能在原生转换窗口被释放。一个真正保持 NORMAL/idle 的第三方连接没有在执行这一步。不能把两个升级者等同于两个永不变化的旧 idle 读者。
4. [btree.c3473–3543](https://raw.githubusercontent.com/sqlite/sqlite/version-3.53.2/src/btree.c)在合法的无先存事务状态下会通过现有 busy handler 重试内部锁获取；[busy_timeout 官方合同](https://www.sqlite.org/c3ref/busy_timeout.html)说明未耗尽等待预算之前，竞争不必作为最终 SQLITE_BUSY 返回。此处是 SQLite 原有 busy handler，不能描述成我们添加了 retry。

上述版本源码给出与原结果一致的机制解释：两新候选主动进行锁转换，A先在原事务里读1并升级；B的同一次真实 migrator 调用可以在库内等待，之后于原事务内读到2，完成2→2校验。A377ms返回后仍处理实际快照/备份证据与NORMAL释放，B3565ms返回且晚于A rawclose；与原5s busy策略相容。

**证据边界**：原工具没有 OS LockFileEx trace，也没有记录每条 pre-BEGIN SQL 的进入/返回时刻、VFS（Virtual File System，虚拟文件系统）名称和编译选项。因此不能声称已经观察到“B在某个精确微秒释放哪个 byte”或精确分配3565ms到某条 PRAGMA/BEGIN。可确定的是源码允许该原生转换、两个返回回执与事务内校验完全真实、B不是最终 BUSY、固定 from1 断言错误。官方release网页一次读取返回工具 Internal Error，本文不把那次失败当版本依据，实际身份来自 manifest.uuid 和原 SQL 记录。

## 与旧 cached reader 被错放行的区别

本次 seed 在两候选启动前已正常关闭。A/B 是具有 scratch v2 registry 的两个升级程序，自己的 v1 snapshot 只是待迁移输入；它们在事务里再次核对当前版本，随后只执行适合该版本的迁移/校验。B的2→2正是当前版本准入合同，**不是**不支持v2的原 production Client 继续执行业务。ready不是公共“旧版本业务已经准入”的无限期保证。

[WAL 文件锁矩阵](https://www.sqlite.org/walformat.html#locking_matrix)描述已 attached 连接的文件SHARED与EXCLUSIVE冲突；这一关系不等于主动切换锁策略的连接永远持同一锁。原 lock-process-01/02 中，真实旧 production cached idle 或 readonly idle 没有切 EXCLUSIVE，实际让新候选得到 BUSY；旧 owner正常close后才允许升级，之后旧v1 reopen返回SCHEMA_VERSION_AHEAD。这些原证据继续有效，不能因本轮新候选校验成功而抹掉，也不能由它们直接覆盖“两新升级者+独立旧 reader”的组合。

当前未发现这次运行证明“旧cached decoder在新格式上执行业务”。若后续独立旧reader保持live仍让候选真正升级，那会成为新的共享迁移安全红态，须保存整个原发生顺序、真实版本与旧reader调用，不可归因竞争正常或放宽预期。

## 需要修正的所有检查器分类，而非只改252行

| 当前错误假设 | 拟用的明确正向合同 |
| --- | --- |
| 所有 migrate 成功都叫一次1→2升级，并固定 from1 | 按原 receipt 分为 `upgraded`（1→2且真实backup）和 `current`（精确 `{from:2,to:2}` 且完整当前校验），原异常 `busy` 或明确 failed 分开保存。 |
| 两NORMAL ready意味着至少一个最终BUSY | 删除这一未经支持的必要条件；从完整两原 attempt 的合法组合判断，不制造BUSY、不延迟其中一人。 |
| 所有成功都必须产生backupPath | 只有真实1→2检查原backup完整v1与strictclose；2→2检查它的完整返回合同及原事务内validation，不要求不存在的第二次升级。 |
| `committed.length`可当作实际升级次数 | 用真实 `upgraded` 计数；最多1次真正升级。当前版本成功不增加版本转换数。 |
| 当前 post-closure阶段只从是否成功推from | 以完整原结果组合决定真实下一from，再用fresh opener的实际回执、完整source snapshot和最终version核对。 |

在鲜v1库且仅这两个写入候选的前提下，完整合法组合为（不限定A/B顺序）：

- `busy + busy`：两者正常close后，唯一新 `after-race` 原调用应1→2；不得称原竞争赢家已成功。
- `upgraded + busy`：真正升级恰好1次，post-closure原调用应2→2。
- `upgraded + current`：真正升级恰好1次，另一个按当前版本完成校验；post-closure原调用应2→2。**这正是01真实语义组合，但01整体仍失败，不重写原标记。**

`current+current`、`current+busy`、两个`upgraded`等与该鲜v1/唯一写入者前置不一致，不能泛化接受。三种合法组合都继续要求完整原schema/rowid/bytes保留、原validate真实version2、每个成功候选真实NORMAL+finalized访问和最终strictclose、所有原owner的physical/output/request闭合。只在原一切成功后才放行下一新occurrence；真正异常仍保留原typed error及所有cleanup错误。

最小工具修正只涉及现有worker的race成功分类/按receipt校验、driver完整组合核验与`after-race`预期推导；launcher原mode/预算和SQLite SQL策略不需要为此改变。为提高可观察性可在既有worker外边界记录EXCLUSIVE设置返回、migrate返回、NORMAL访问前后时刻，但这些仍不冒称VFS锁trace；不包裹/替换production SQL、不改busy_timeout、不加sleep或heartbeat。本报告尚未实施这些工具变更。

## 独立第三旧版 owner：有价值且需作为新鲜单独场景

要把资格扩展到“两个升级者竞争时仍保护已经准入的旧cached业务reader”，**必须有独立真实旧reader的组合证据，不能拿race-b代替**。修正双升级者分类本身不需要第三人；但在宣布该三方共享场景安全之前，应补此格。Root已允许本报告提出一个全新fresh scope的唯一三owner场景；这不是更改或延长失败01。

建议复用同一三文件，准备显式 `guarded-race` 模式（待Root另授实施/执行）：新scope `lock-old-reader-race-01`，独立原600s/child180s/phase30s/parent60s不变，**只有这个场景上限3个同时active scenario workers**。监督与driver仍是原所有权层，父不打开DB。

1. 原production seed正常创建/关闭鲜v1，保存完整snapshot/identity；fresh `hold-production` 原production Client真正打开同库并保持cached idle，保留真实1s checkpoint。它不改locking_mode、不进入新registry、不做升级。
2. 新A/B用修正后的同一race实现分别NORMAL真实读v1并ready；父在第三旧owner已ready时才发布原common marker。三者均真实独立process/occurrence，无假活跃或替代Map。
3. 第三旧owner持续live时，两候选必须真实返回**各自 SQLITE_BUSY**并正常close/join。这个BUSY预期来自独立保持SHARED的旧reader，而不是把正在转换的候选当固定blocker。若任一真实升级/current成功，原数据就是安全格失败，不改预期。
4. 两候选实际join后才给旧owner原normal-close marker；旧owner在关闭前真实重读完整v1、保持原identity，然后正常close/三个join。不得暂停checkpoint或直接杀旧owner以制造成功。
5. 再起唯一新 `after-race`，原migrator1→2/backupv1/fullvalidation；随后fresh current reader2→2和旧production-v1 reopen的SCHEMA_VERSION_AHEAD。预计7个总worker、最多3同时active、1个managed root；全部按原真实closure后清理。

上述独立新场景避免在原3case followup里暗增全局上限。Root可以先准修正后的原max2 followup新scope（包含仍未跑的backup/validator），再亲审三owner新mode，两个原outer各自固定，不并发复用同root。readonly旧reader已在原双owner01/02测过；三方readonly组合、rollback-journal、别名、compiled-native旧Bun、语义grant迁移仍不外推，不能把一个新三方case说成所有组合。

## 剩余共享资格与交付

本轮错误是检查器固定分类假设；原SQLite实际成功及failed worker是不同层事实。没有发现需立即改production migrator的证据，也没有证明未知post-commit unlock failure。该库内部busy等待不是新的host重试或工作流gate，保持原单一迁移者/事务内version事实。

Root另查的hostGit/进程deadline问题保持独立：caller不输出不能推出leaf静默或clock坏；Root新cold Host inactivity523ms/终态输出41ms、waitAsync298ms资格只覆盖原输入。此scope5451ms内自然失败并完整join，只增加正常失败收尾事实，不证明全runner timeout。未改Clock/Facade/Supervisor、不延原deadline。

首轮failed scope、三个actual sources及原stderr保持原样。本报告只提出精确下一工具修正和独立三owner输入，等待Root落spec/授权；没有新实验、生产修改、正式测试、模型/凭据/UI或Git写入。
