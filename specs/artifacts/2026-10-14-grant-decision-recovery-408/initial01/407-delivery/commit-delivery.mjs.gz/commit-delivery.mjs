import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import {execFileSync} from 'node:child_process'
const root=path.resolve('.tmp-message-retirement-407')
const git=(args,env=process.env,input)=>execFileSync('git',args,{env,input,encoding:'utf8',windowsHide:true,maxBuffer:64*1024*1024})
const full=['packages/opencorvus/src/permission/authority.ts','packages/opencorvus/src/session/index.ts',
  'packages/opencorvus/test/permission-execution-owner-process.test.ts',
  'packages/opencorvus/test/session/permission-message-retirement.test.ts',
  'packages/opencorvus/test/session/permission-message-settlement.test.ts',
  'packages/opencorvus/test/server/permission-retirement-reply.test.ts',
  'packages/opencorvus/test/permission-continuation-recovery.test.ts',
  'packages/opencorvus/test/session/permission-message-recovery.test.ts',
  'packages/opencorvus/test/session/fork-atomic-transcript.test.ts',
  'packages/opencorvus/test/session/tool-result-recovery.test.ts',
  'packages/overlay/test/projection-prerequisite-recovery.test.ts',
  'packages/overlay/test/tree-writer-incremental-projection.test.ts',
  'packages/overlay/test/tree-writer-review-stream.test.ts',
  'packages/overlay/test/tree-writer-message-facts.test.ts',
  'specs/current/architecture/02-data.md','specs/current/architecture/security-permission.md',
  'specs/records/2026-10/2026-10-14-message-continuation-retirement-407.md',
  'specs/artifacts/2026-10-14-message-continuation-retirement-407']
const partial=['CHANGELOG.md','specs/README.md','specs/artifacts/README.md','specs/records/2026-10/README.md']
const ownChinese='- 正常助手消息完成时同步关闭已成功工具的权限续行；静默写入、导入与相同完成重放共用原事务。退休写入失败保留真实错误并回滚本次消息发布，已提交的工具结果继续可恢复。'
const ownEnglish='- Completed assistant messages now retire successful permission continuations in the same transaction, including silent writes, imports and identical completion replay. Retirement failures propagate and roll back that Message publication while preserving previously committed Tool results for recovery.'
const rows=Object.fromEntries(partial.filter(file=>file!=='CHANGELOG.md').map(file=>{
  const list=fs.readFileSync(file,'utf8').split(/\r?\n/).filter(line=>line.startsWith('- [407 消息完成与续行退休]'))
  assert.equal(list.length,1);return[file,list[0]]
}))
function applyOwn(file,text){
  text=text.replaceAll('\r\n','\n')
  if(file==='CHANGELOG.md'){
    for(const [heading,line]of [['#### 修复',ownChinese],['#### Fixed',ownEnglish]]){
      assert(fs.readFileSync(file,'utf8').includes(line));if(text.includes(line))continue
      const at=text.indexOf(heading+'\n\n');assert(at>=0)
      text=text.slice(0,at+heading.length+2)+line+'\n\n'+text.slice(at+heading.length+2)
    }
    return text
  }
  const lines=text.split('\n'),matches=lines.map((line,index)=>line.startsWith('- [407 消息完成与续行退休]')?index:-1).filter(index=>index>=0)
  assert.equal(matches.length,1);lines[matches[0]]=rows[file];return lines.join('\n')
}
const base=git(['rev-parse','HEAD']).trim(),env={...process.env,GIT_INDEX_FILE:path.join(root,'index-delivery-'+Date.now())}
assert.equal(git(['branch','--show-current']).trim(),'main')
git(['read-tree',base],env);git(['add','-f','--',...full],env)
for(const file of partial){
  const blob=git(['hash-object','-w','--stdin'],env,applyOwn(file,git(['show',base+':'+file]))).trim()
  git(['update-index','--index-info'],env,'100644 '+blob+'\t'+file+'\n')
}
git(['diff','--cached','--check'],env)
const paths=git(['diff','--cached','--name-only'],env).trim().split('\n')
assert(paths.length>0);assert(paths.every(file=>partial.includes(file)||full.some(scope=>file===scope||file.startsWith(scope+'/'))))
const preparation={base,index:env.GIT_INDEX_FILE,paths,preparedAt:Date.now()}
fs.writeFileSync(path.join(root,'delivery-scoped.patch'),git(['diff','--cached','--binary'],env))
fs.writeFileSync(path.join(root,'delivery-preparation.json'),JSON.stringify(preparation,null,2))
console.log(JSON.stringify({base,paths:paths.length,mode:process.argv[2]??'prepare'}))
if(process.argv[2]!=='--commit')process.exit(0)
assert.equal(git(['rev-parse','HEAD']).trim(),base)
git(['commit','-q','-m','fix(permission): retire completed message continuations atomically'],env)
const commit=git(['rev-parse','HEAD']).trim();assert.equal(git(['rev-parse',commit+'^']).trim(),base)
const receipt={...preparation,commit,indexReconciled:false}
fs.writeFileSync(path.join(root,'delivery-commit.json'),JSON.stringify(receipt,null,2))
const tree=new Map(git(['ls-tree','-r',commit]).trim().split('\n').map(line=>{const [object,file]=line.split('\t');return[file,object.replace(' blob ',' ')]}))
const changes=paths.filter(file=>!partial.includes(file)).map(file=>(tree.get(file)??'0 '+'0'.repeat(40))+'\t'+file+'\n')
for(const file of partial){
  const blob=git(['hash-object','-w','--stdin'],process.env,applyOwn(file,git(['show',':'+file]))).trim()
  changes.push('100644 '+blob+'\t'+file+'\n')
}
git(['update-index','--index-info'],process.env,changes.join(''))
receipt.indexReconciled=true;receipt.endedAt=Date.now()
fs.writeFileSync(path.join(root,'delivery-commit.json'),JSON.stringify(receipt,null,2))
console.log(JSON.stringify({commit,paths:paths.length,indexReconciled:true}))
