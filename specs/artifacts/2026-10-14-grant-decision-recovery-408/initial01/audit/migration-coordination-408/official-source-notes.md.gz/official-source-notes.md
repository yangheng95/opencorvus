# Official read-only sources for the 408 coordination candidate

Read through the web tool on 2026-10-14. No local SQLite operation or process probe was executed.

- [SQLite WAL locking matrix](https://sqlite.org/walformat.html#locking_matrix), sections 2.3.1–2.3.2: file SHARED ownership continues for attached WAL connections, including idle/read-only clients. File EXCLUSIVE ownership conflicts with that ownership. Distinguish this from WAL_WRITE_LOCK.
- [SQLite locking_mode](https://www.sqlite.org/pragma.html#pragma_locking_mode): mode selection, real access, release after NORMAL plus actual access, and the importance of NORMAL before initial WAL attachment.
- [SQLite WAL shared-memory behavior](https://www.sqlite.org/wal.html#use_of_wal_without_shared_memory): initial EXCLUSIVE attachment uses a heap WAL index and cannot simply return to NORMAL while still WAL. NORMAL-first attachment permits later lock-mode switching.
- [SQLite transaction semantics](https://www.sqlite.org/lang_transaction.html): BEGIN EXCLUSIVE and BEGIN IMMEDIATE are equivalent under WAL; a read transaction preserves its snapshot.
- [SQLite user_version](https://www.sqlite.org/pragma.html#pragma_user_version): application-owned version metadata, not SQLite application-format enforcement.
- [Official SQLite upstream pager.c](https://raw.githubusercontent.com/sqlite/sqlite/master/src/pager.c), reviewed function sqlite3PagerBegin near lines 5677–5695: WAL/exclusiveMode attempts the database-file EXCLUSIVE lock and returns the actual acquisition error. pagerOpenWal near 7246 and sqlite3PagerLockingMode near 7005 explain the normal/shared versus initial-exclusive/heap distinction. This moving upstream source is supporting mechanism evidence, not the identified source version of Bun's embedded SQLite.

An earlier attempted SQLite Fossil pager URL returned no matching text; the official GitHub mirror above was subsequently opened and read. The main report records the outstanding exact-runtime experiments. No source hash or mutable-source digest is used as an acceptance condition.
