import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import {gzipSync,gunzipSync} from 'node:zlib'
const target=path.resolve('specs/artifacts/2026-10-14-grant-decision-recovery-408/initial01')
const items=[]
function add(source,destination){assert(fs.statSync(source).isFile());items.push({source,destination})}
function tree(source,destination){for(const entry of fs.readdirSync(source,{withFileTypes:true})){
  assert(!entry.isSymbolicLink());const from=path.join(source,entry.name),to=destination+'/'+entry.name
  if(entry.isDirectory())tree(from,to);else add(from,to)
}}
for(const stage of ['docs407-delivery01','architecture407-delivery01','prepare407-delivery01','commit407-delivery01',
  'fetch407-delivery01','merge407-delivery01','push407-delivery01','verify407-fetch01','verify407-ancestor01'])
  tree(path.resolve('.tmp-task-question-recovery-406/delivery-commands',stage),'407-delivery/'+stage)
for(const file of ['commit-delivery.mjs','delivery-preparation.json','delivery-commit.json'])
  add(path.resolve('.tmp-message-retirement-407',file),'407-delivery/'+file)
for(const file of ['grant-projection-408-analysis.md','raw-permission-adapters-408-analysis.md','grant-migration-coordination-408-analysis.md'])
  add(path.resolve('.tmp-message-retirement-407/ui',file),'audit/'+file)
for(const dir of ['grant-408','raw-adapters-408','migration-coordination-408'])
  tree(path.resolve('.tmp-message-retirement-407/ui',dir),'audit/'+dir)
add(path.resolve('.tmp-message-retirement-407/functionality/grant-used-followup.md'),'audit/grant-used-followup.md')
add(path.resolve('.tmp-grant-decision-recovery-408/capture-initial.mjs'),'capture-initial.mjs')
fs.mkdirSync(target,{recursive:false});const files=[]
for(const item of items){
  assert(!/(^|\/)(auth\.json|models\.json|runtime|private-bundle)(\/|$)/i.test(item.destination))
  const raw=fs.readFileSync(item.source),destination=item.destination+'.gz',file=path.join(target,destination)
  fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,gzipSync(raw),{flag:'wx'})
  assert(gunzipSync(fs.readFileSync(file)).equals(raw))
  files.push({source:item.source,destination,bytes:raw.length})
}
fs.writeFileSync(path.join(target,'manifest.json'),JSON.stringify({capturedAt:Date.now(),files,
  boundary:'407 actual delivery and frozen 408 read-only audits; no 408 implementation, lock experiment, migration, Provider or UI acceptance. Gzip roundtrip checks only archive identity.'},null,2),{flag:'wx'})
console.log(JSON.stringify({target,files:files.length,bytes:files.reduce((sum,row)=>sum+row.bytes,0)}))
