import assert from "node:assert/strict"
import fs from "node:fs/promises"
import path from "node:path"

// Root-reviewed preparation only; never call a database constructor or a migration here.
const [runtime, output, rawDeadline] = process.argv.slice(2)
assert(runtime && output && path.isAbsolute(runtime) && path.isAbsolute(output))
assert.equal(process.env.OPENCORVUS_HOME, runtime)
assert.equal(process.env.OPENCORVUS_TEST_HOME, path.join(runtime, "owned-home"))
const packageDirectory = path.resolve(import.meta.dir, "../../packages/opencorvus")
assert.equal(path.resolve(process.cwd()), packageDirectory)
const startedAt = Date.now(), deadlineAt = Number(rawDeadline)
assert(Number.isSafeInteger(deadlineAt) && deadlineAt > startedAt && deadlineAt <= startedAt + 180000)
const facts: Record<string, unknown> = { startedAt, deadlineAt, pid: process.pid, cwd: process.cwd(),
  executable: process.execPath, bunVersion: Bun.version, runtime,
  qualification: "Import and alias resolution only; no SQLite construction, migration, Client or query call" }
let database: typeof import("../../packages/opencorvus/src/storage/db") | undefined
let primary: { error: unknown } | undefined
const cleanupErrors: unknown[] = []
try {
  const { withTimeout } = await import("../../packages/opencorvus/src/util/await-with-timeout")
  const modules = await withTimeout(Promise.all([
    import("../../packages/util/src/process-node"),
    import("../../packages/util/src/runtime-directories"),
    import("../../packages/opencorvus/script/test-process-supervisor"),
    import("bun:sqlite"),
    import("../../packages/opencorvus/src/storage/schema-migration"),
    import("../../packages/opencorvus/src/storage/sqlite-statement"),
    import("../../packages/opencorvus/src/storage/schema-contract"),
    import("../../packages/opencorvus/src/storage/ddl"),
    import("../../packages/opencorvus/src/storage/migrations"),
    import("../../packages/opencorvus/src/storage/db"),
  ]), Math.min(30000, deadlineAt - Date.now()), "Original import qualification window")
  database = modules[9]
  facts.exports = {
    processRun: typeof modules[0].NodeProcess.run,
    managedDirectory: typeof modules[1].createManagedTemporaryDirectory,
    supervisorResolver: typeof modules[2].expectedTestProcessSupervisor,
    sqliteConstructor: typeof modules[3].Database,
    migration: typeof modules[4].migrateSchema,
    finalizedQuery: typeof modules[5].queryAllFinalized,
    schemaReader: typeof modules[6].readSchemaObjects,
    ddl: typeof modules[7].SCHEMA_DDL,
    declaredRevision: modules[8].DATABASE_MIGRATIONS.at(-1)?.version,
  }
  assert.deepEqual(facts.exports, { processRun: "function", managedDirectory: "function", supervisorResolver: "function",
    sqliteConstructor: "function", migration: "function", finalizedQuery: "function", schemaReader: "function",
    ddl: "string", declaredRevision: 1 })
  facts.connectionState = database.Database.hasOpenConnection() ? "open" : "uninitialized"
  assert.equal(facts.connectionState, "uninitialized", "Import qualification must remain a lazy, uninitialized database module")
  facts.databasePath = database.Database.Path()
  assert.equal(path.resolve(String(facts.databasePath)), path.join(runtime, "data", "opencorvus.db"))
  facts.dataDirectoryEntries = await fs.readdir(path.join(runtime, "data"))
} catch (error) {
  primary = { error }; process.exitCode = 1
  facts.primaryError = { name: error instanceof Error ? error.name : typeof error, message: String(error),
    ...(error instanceof Error ? { stack: error.stack } : {}) }
} finally {
  // Only an unexpected initialization in this exact owned root could require cleanup.
  if (database?.Database.hasOpenConnection()) {
    try { database.Database.close(); facts.unexpectedOwnedConnectionClosed = true }
    catch (error) { cleanupErrors.push(error) }
  }
  facts.endedAt = Date.now()
  facts.cleanupErrors = cleanupErrors.map(String)
  facts.status = !primary && cleanupErrors.length === 0 ? "qualified_imports_only" : "failed"
  try { await fs.writeFile(output, JSON.stringify(facts, null, 2), { flag: "wx" }) }
  catch (error) { cleanupErrors.push(error); facts.status = "failed"; facts.cleanupErrors = cleanupErrors.map(String) }
  if (primary || cleanupErrors.length) {
    process.exitCode = 1
    console.error(new AggregateError([...(primary ? [primary.error] : []), ...cleanupErrors], "Import qualification failed"))
  }
  console.log(JSON.stringify(facts))
}
