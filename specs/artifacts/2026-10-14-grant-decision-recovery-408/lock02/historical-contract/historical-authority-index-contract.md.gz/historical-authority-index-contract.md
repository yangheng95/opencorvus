# 408 single-hop historical authority index: read-only contract review

Prepared for Root; **not an implementation authorization**. The event name and semantic revision are deliberately unselected. `INDEX` below is a notation, not a proposed literal. Read the complete 408 Recall, prior grant/projection/raw-adapter/upgrade reports and the current authority, table, migration, Engine, protocol and Settings sources. No production, tests, SDK, shared docs/specs or Git changes; no database, service, browser, model, credential or UI-test access/run.

Initial source HEAD was `8da864d505ffdbf40ecc561f177730b60df42235`; concurrent authorized commits advanced HEAD to `fe0989e1456a58bbef73e5bc60167aa37163548a` before this capture. The 17 captured production paths have an empty tracked diff at capture. This is source identity/context, not a mutable-source digest gate. Exact copies, numbered excerpts, call-site searches, original history and status are in [index-contract-source](index-contract-source/); [capture script](capture-index-contract-source.ps1) records the bounded list. The capture initially failed on PowerShell's single nested-array flattening; the script was corrected to explicit range strings and the original source/query capture completed with exit 0. No application module or database was opened. Two guessed read paths (`05-permissions.md`, root `script/control-state-redundancy-check.ts`) were corrected to their actual locations below; those read failures are not product defects.

## 1. Recommendation and hard distinctions

The proposed representation is coherent **if** the migration first proves one original authority and the current reader follows only the explicit single reference. New `grant_used` directly claims the existing slot; historical `INDEX` claims that same slot and references the original slotless `grant_used`. Both yield the **same canonical original authority view**. The current reader must never search unindexed `grant_used` rows as a fallback, recursively chase indexes, infer approval from Tool success, or replace original scope/time with index fields.

The complete delivery also requires atomic new capture, one winner-owned Replied outbox, late Asked revalidation, Task Board's original-time projection and resolved invalidation, strict migration/current integrity errors, and truthful Settings history. A private enum addition and one producer field alone do not close this defect. Physical exclusivity and semantic version qualification remain Root/backend work; this report supplies no lock qualification result.

There are three distinct identities:

1. **Request owner**: the first immutable `requested` observation for request ID, including its original creation time. Multiple retained observations of that same owner are supported.
2. **Captured decision**: a real original `allowed_once`, `grant_created`, `grant_used`, `denied`, `cancelled` or slot-owning `stale` fact.
3. **Slot locator**: either that decision itself or a separately timed, append-only INDEX referencing an original `grant_used`. It is not another approval, execution, user reply or grant.

Execution starts/results and continuation retirement are different facts. Do not fold slotless retirement `stale`, grant revocation `expired`, or `outcome_unknown` into the request's decision union.

## 2. Current graph, exactly as produced

Source references are relative to `packages/opencorvus/src` unless stated otherwise.

| Fact | Existing producer and immutable link | What it proves |
| --- | --- | --- |
| `R0: requested` | `authority.ts:186–210, 982–1018`; request identity is deterministic Project/Session/Message/call/fingerprint; registration runs in immediate transaction | Exact accepted Permission invocation and initial request time, not a human choice |
| `G: grant_created` | `replyValidated:1174–1212`; `request_id=RG`, `decision_slot=RG`, scope task/project, real actor/reason | A saved scope was actually approved for its source request. The winning human branch owns the original authored userInput publication |
| `U: grant_used` | `authorize:863–865`; `request_id=RU`, `source_event_id=G.id`, copied actual grant scope; currently slot null | The old producer captured saved approval. It does not say an effect started or completed |
| `S: execution_started` | `authorizeAndExecute:1093–1118`; same request, deterministic attempt, `source_event_id=returned authority.id`; start + physical effect lease atomic | This exact original authority admitted that attempt. The reference is an explicit discriminator among multiple old captures |
| Terminal execution/result | `completeExecution`, outcome slot, `permission_execution_result`; `session/tool-outcome-facts.ts:37–71` checks exact accepted Tool identity and successful pair | Actual result/recovery evidence, not a replacement decision |
| `V: revoked/expired` | `revoke/expire:1472–1498`, `project-authority.ts:20–70` | Stops later reusable-grant admission. Does not erase an already captured U or backdate its time |
| Slot-owning denied/cancelled/stale | `settleDecision*`, `settlePendingTermination` | Exact invocation decision; Terminated carries the original winning ledger ID |
| Slotless stale retirement | `retireContinuation:1340–1344` | Original continuation is closed; it is not a new denial overwriting prior approval |

The source grant's request and the using request are usually different. A project grant can legitimately cross Session/Message/call and Task boundaries within the same Project and exact fingerprint. A task grant requires both stored owners to carry the same nonempty Task ID as well as the same Project/fingerprint. Do not require equal Session IDs for task grants: workers and children can use the same owning Task. Do not substitute the currently selected Task, current process occurrence, or later Task activation for this stored scope.

The current request has one deterministic attempt (`attempt\0${requestID}`), not a new attempt per retry. The unique start index is on attempt ID, so a malformed second, non-deterministic attempt under the same request is not excluded by SQL alone. A later changed scope/fingerprint produces a different Request/attempt; replay of the same Request reuses its start/result. The existing Tool result reader additionally rejects multiple successful Permission results for the same accepted Tool. INDEX cannot weaken any of these controls or change physical lease ownership.

## 3. Multiple requested observations: first owner, not a guessed decision

`requestedRows:1246–1260` explicitly says: keep the first immutable owner and the complete audit log. It orders by rowid then deduplicates request IDs. History commit `e080173922c92d7800ee3291f185ec18a0f4ae19` introduced that rule after the earlier writer could append another requested observation when the same already-decided request replayed. `assertRequestIdentity:583–607` currently checks the first row's deterministic identity and Project/Session/Message/call/fingerprint; it does not compare all retained requested rows. Current `.get()` callers are not explicit about ordering, unlike `requestedRows`.

The new common reader should make first-observation ordering explicit and validate duplicate **authority material**, not reject count > 1:

- For all requested observations of an ID: same Project, Session, Task (including null), Message, Tool call; same provider kind/id/digest, Tool/effect, scope version, actual structured scope and fingerprint; same Session-frozen mode and policy revision. The canonical deterministic Request ID must match its original identity inputs. A contradictory duplicate cannot be selected through a Project-filtered EXISTS or hidden by first-row deduplication.
- Each observation's event ID/time is its own fact and may differ. Never require duplicate row equality including id/time or choose the latest timestamp. The first observation's Request time and presentation snapshot remain authoritative.
- User-facing summary and optional metadata are not owner coordinates. Keep the first original values. Do not add a new blanket equality requirement on all metadata/user text or regenerate a first Request from a later observation. Grant-scope eligibility must be consistent with the original declared choices where they are recorded; lack of legacy optional metadata is not, by itself, evidence of a different owner. Any stronger admissibility requirement must be explicitly selected and qualified, not smuggled in as an owner test.

The comparison is actual immutable data validation, not source hashing. Existing fingerprints are real authorization protocol identities; any validation/reuse of their versioned digest must use the original scope contract. It must not run current filesystem canonicalization, resolve today's paths, or silently assume every historical scope version equals `2`. Matching source/use owner scope versions, structured scope and fingerprint can be checked without reinterpreting current resources. Scope versions outside the approved baseline contract must receive an explicit unsupported-graph result if the chosen migration cannot establish them.

## 4. Candidate current legal forms

### Direct current decision

`slot(R) = D` where `D.request_id=R`, `D.decision_slot=R`, and D is an allowed decision kind. The reader checks kind-specific scope rather than `else => allow_once`:

- `allowed_once`: invocation scope for explicit choices; current Full-access producer omits decision_scope and uses actor `full-access-policy`, so blanket requiring `invocation` would reject legitimate current facts.
- `grant_created`: task or project; source Request owns the same slot. A new reusable grant is created only by its actual current decision producer.
- `grant_used`: task or project copied from an exact valid G; same using Request owns the slot. G's own request has its actual grant-created decision.
- `denied/cancelled/stale`: actual negative decision kinds; existing termination-specific fields/owner are retained.

For grant capture, validate G is truly `grant_created`, belongs to its original source Request, has the expected slot, and has compatible stored scope/Project/fingerprint/Task. A U cannot use a revoked row, another U or INDEX as its source grant. A project-scope grant cannot arise from a task-only choice by interpreting null as project. The exact existing typed scope constraints and original recorded Request must be used, not a translated label.

### Historical indexed decision

```
Rusing(first requested observation)
  <- U(request_id=Rusing, event_type=grant_used, decision_slot=null)
       --source_event_id--> G(grant_created, decision_slot=Rgrant)
                              -> Rgrant(first requested observation)
  <- I(request_id=Rusing, event_type=INDEX, decision_slot=Rusing,
       source_event_id=U.id)
  <- optional S(execution_started, deterministic attempt, source_event_id=U.id)
```

I has a new real migration/materialization ID/time and explicit system provenance. It uses the existing delta-row shape: no copied full owner, no attempt/outcome slot, no invented userInput. Prefer no copied decision_scope: the original U owns scope. I references **exactly U**, never another I, G, S, a Tool receipt or the request row. The reader returns U's id/time/scope/actor/reason and `autoReply=true`; the slot locator I remains available only for integrity/audit diagnostics. That original id is what execution admission already references and what `Resolution.eventID` must continue to identify.

This is one declared current format with two legal slot kinds, not `slot || latest old U` compatibility code. Old-history inference happens only in the explicit semantic migration. At current-format runtime, a slotless U with no I/direct slot is an integrity violation of that adopted format, not a new pending request silently offered for another approval.

No retrospective `permission.replied`, operator message or Task userInput should be emitted just because migration indexes old evidence. Current cold projection reads the original result, and existing live readers start only after migration qualification. A new U's actual winning transaction does own the existing Replied outbox (`autoReply:true`) and real local waiter release, without copying a source human's authored text into a second approval.

## 5. Historical qualification and exact ambiguity boundaries

All references below must have valid canonical requested owners and grant-scope graph first. The migration can materialize all relevant rows once in its original transaction; that temporary working map is a migration computation, not another persisted authority.

| Historical graph | Proposed result |
| --- | --- |
| No slot, no U, no execution authority | Genuine pending requested identity; retain unchanged. A slotless retirement row remains its separate role and needs the existing continuation contract, not inferred approval |
| No slot, exactly one valid U, no S | Uniquely captured approval can be indexed. Execution is unstarted, not succeeded. Existing recovery may now discover this approved continuation; that user-visible consequence must be tested under original live-owner, original Tool identity, Task activation and retirement rules |
| No slot, exactly one valid U, valid S points to U | Index U. Preserve exact S/attempt/physical owner/result and original U time |
| No slot, multiple valid U, exactly one valid deterministic S points to one U | S identifies the admitted original capture; index that U and retain every other observed U as history. Equal times/scopes are irrelevant |
| No slot, multiple U and no S | Explicit ambiguity. No latest/earliest/lowest ID/equal-scope collapse; do not run the effect or guess an approval |
| No slot, S exists but source missing/wrong kind/wrong request/not among U | Explicit graph error. A successful result cannot repair the missing authority |
| Multiple starts with distinct attempts under one Request | Explicit attempt-identity conflict, even if SQL's per-attempt unique index permits it. Do not select the latest start |
| Existing ordinary slot and no conflicting original execution authority | Preserve original slot; do not append I or rewrite D. Valid unexecuted stray historical U are separately retained. See conflict policy immediately below |
| Existing direct slot D but S points to a different U | Definite dual-authority conflict: existing decision and actual admitted authority disagree. Unique slot prevents inserting I; automatic migration must stop with precise IDs, not rewrite or override D |
| Existing I references exact U and S, if present, agrees | Current valid indexed form, idempotent read/reopen; never append another I |
| I has a missing reference, wrong request/source kind, self reference, I→I, copied invalid shape or slot != request ID | Explicit current-format integrity error; only one hop is legal |
| Missing requested owner or duplicate observations with conflicting owner material | Explicit owner-integrity error. No owner synthesis from current Session/Task, Tool result, G owner or a summary |

**Existing slot plus unexecuted U needs an explicit Root choice.** Old code could capture U, then a different request-decision path claim an empty slot before execution starts. With no S, the rows prove two observations but not which one was consumed. The current canonical slot is structurally authoritative; preserving it without adding I is the narrowest migration, but it does not prove those unexecuted U represented a coherent historical decision. If the accepted contract requires exactly one coherent capture history, reject this case as a declared migration conflict. Do not claim the single-hop indexing mechanism resolves it automatically or compare their timestamps to choose. With S anchored to U, the contradiction is definite and must fail. This is a remaining semantic decision, not an implementation detail to improvise.

**Already revoked/expired source grant:** revalidate original graph and scope, not today's `activeGrant()`. An authentic old U retains its captured authority after later revocation, including if no execution start was written before the old process stopped. Rechecking the current active-grant set would retroactively erase a real capture. Project deletion expires reusable project grants in the same deletion transaction (`project/delete.ts:377`), while ledger owners remain.

However the old capture's eligibility read and append were separate transactions. Rows do not record the exact eligibility-read instant. A revoke that appears before U in row order could interleave after the old read but before the append. Neither row order nor wall-clock timestamps establish that the old writer serialized correctly; the migration cannot certify historical revoke/capture linearizability or invent a read timestamp. Preserve the authentic capture under the chosen historical-evidence rule, or explicitly stop that graph for manual reconciliation if Root requires stronger historical proof. The new writer must atomically serialize eligibility and capture with revoke/expiry; this fixes future behavior, not past proof.

## 6. All existing integrity surfaces and gaps

| Surface | Current real validation | Required treatment if INDEX is adopted |
| --- | --- | --- |
| `permission.sql.ts` | Private closed `PermissionEventType`; `event_type` SQL TEXT with TS `$type`, not SQL enum CHECK | Extend only the chosen private event contract; row graph validation remains necessary |
| SQL keys/check | PK id; unique nullable decision_slot/outcome_slot; partial unique attempt start; requested/full-owner versus delta/null-owner CHECK | These do not verify source kind, slot==request, exact owner, attempt formula or single-hop graph. Do not mistake a successful INSERT/foreign-key check for semantic validation |
| Owner retention | Current `permission_ledger.project_id` has **no FK**, as in immutable 0001; Session/Task IDs also no FK | Validate original retained owner without requiring current Project/Session/Task rows. Earlier DDL comment claiming ledger cascade is stale commentary, not schema behavior |
| Append-only guards | DDL no UPDATE; delete guard; execution result immutable | Add I, never mutate old U or its time. Current actual ledger retains owner after Project deletion; do not manufacture missing owners |
| `assertRequestIdentity` | First requested identity + compact deterministic input checks | Shared validation must handle every duplicate requested owner and return the canonical first identity, without a copied second Request schema |
| `assertAttemptIdentity` | Detects attempt rows bound to another request; success/result pair checks | Preserve and strengthen only the exact chosen graph relation needed for S anchoring; no new attempts introduced by migration |
| `authorizeAndExecute` | Reads returned authority ID and checks same request; start/result/physical lease admission | Returned canonical original U is intentional even if I owns slot. Do not assert original U must itself have decision_slot after dereference |
| `staleFor`, retirement/reconcile | Separate slotless retirement and execution outcomes | Do not treat a ledger event merely named stale/expired as the current decision without its legal role |
| Current Database `assertCurrentDataIntegrity:270–760` | Permission checks cover legacy compact ID lengths and old Tool-control result protocol; no complete permission grant/index graph check | Add one permission-owned graph validator to the existing startup callback for the adopted current format; same logic/reader basis as migration, no alternative history resolver |
| Schema migrator | Registry version/DDL shape, actual FK check, synchronous current-data validation, transaction and backup | FK check cannot validate these reference TEXT columns. Semantic callback must validate complete old graph before appending indexes; final current-format validation before COMMIT |
| Engine store | Exact immutable Task protocol owner, permission requested source, prohibits duplicate Engine outcome+Permission decision | Replace raw slot semantics with canonical fact view; verify source requested identity agrees with canonical owner, retaining the original first Request time |
| Engine Terminated | Exact original slot/ledger ID/status/Project/Session; existing ephemeral resolved event | Still validates real negative decision directly. INDEX is not a Terminated event and cannot enter this branch |
| Project expiry/identity convergence | Project expiry uses canonical ledger owner; identity convergence lists ledger as immutable authority | Neither should mutate index/original identity or require current selected directory as historical owner |
| `control-state-redundancy-check.ts` | Catalogs existing causal columns and validates owner-shape/immutable triggers | New event uses existing columns; no new stored scope/time/status mirror. Do not loosen checker or classify index as a new writable approval |

`storage/ddl.ts:4280–4286` has an outdated cascade explanation. I initially repeated that inference in commentary, then immediately corrected it after reading the actual complete table and baseline. Current `security-permission.md` explicitly states the non-cascading ledger owner contract. No production comment was edited in this investigation.

An important migration detail: `applyMigration:104–120` drops existing indexes, triggers and views **before** calling its semantic callback, then reconstructs the target objects afterwards. The callback cannot rely on the current decision-slot unique index to arbitrate its own historical selection. It must explicitly inspect all rows per original request/slot/attempt and validate the entire intended graph before appending one I per selected request. A `.get()` under that temporary migration state must not silently choose among duplicate slot candidates. The final recreated unique index and current data validator are additional checks, not substitutes for that original graph qualification. The schema-contract helper compares schema objects only; it does not inspect these event relationships.

## 7. Transaction type and dependency boundary

`Database.TxOrDb` is exactly `SQLiteTransaction<"sync", void, typeof ApplicationSchema> | SQLiteBunDatabase<typeof ApplicationSchema>` (`db.ts:820–824`). Engine's `projectInteractionRowInTransaction(db, row)` is actually passed this union from `Database.use`, transaction callbacks and list projections. It is not safe to declare a reader accepts only `ReturnType<Database.Client>` or open its own Client.

`Database.transaction` uses a normal/deferred outer Drizzle transaction; a nested call uses the existing context and savepoint. `immediateTransaction` uses `behavior: "immediate"` only when it is the outermost transaction; nested calls also reuse a savepoint. Calling immediateTransaction inside an existing deferred transaction does **not** retroactively reserve the writer before the first read. The reader accepts the caller's `db` and performs only synchronous reads. New capture must have its own correctly scoped outer immediate writer boundary before eligibility reads; when invoked inside an existing transaction, it must respect that original transaction and report actual contention/errors rather than imply an upgraded outer lock.

Recommended minimal module boundary: one new Permission-owned low-level fact module (name to select) using `import type { Database } from "@/storage/db"`, table row types/values, and `and/eq/asc/sql` directly from `drizzle-orm`. Existing `session/tool-outcome-facts.ts` demonstrates this exact type-only DB pattern. Return raw canonical owner/slot/original decision plus the derived decision/provenance; Authority can reconstruct the existing public Request through its established schema. Do not duplicate the PermissionRequest schema or pull runtime Instance/Task/Bus into the reader.

Avoid importing `PermissionAuthority` into Engine/store or Database validation. A concrete cycle would be `engine/store → permission/authority → engine/task-session-lineage → engine/task-execution-capsule-binding → engine/store` (the last module imports `listStartedIncompleteTaskIDs`). Authority also imports Bus, Config, Instance and control/physical ownership. Putting runtime DB code in existing `permission/decision.ts` would contaminate its current lightweight enum and consumers `permission/types.ts` / `engine/model.ts`. The low-level module can stay below both: permission.sql→Project SQL→schema.sql contains no runtime Client/Engine owner logic. Current request/attempt deterministic helpers can be moved, not copied, into that approved low-level boundary if shared validation needs them; do not create a second identity formula.

`requestFromRow` currently calls heavy `invocation.ts` for eligibility and uses Database.use internally. Do not import that helper into startup migration just to parse historical rows. A minimal row fact reader need not recanonicalize resources or query runtime policy. If Root requires moving full Request reconstruction too, separately account for extracting the already-pure eligibility predicate from the current high-level module and replacing the old definition; do not quietly add a new runtime cycle or different eligibility implementation.

## 8. Errors and public closed contracts

Existing private errors: missing request/source often generic Error; `PermissionIdentityCollisionError` has code `PERMISSION_IDENTITY_COLLISION`; RejectedError, StaleContinuationError, OutcomeUnknownError, ExecutionAlreadySucceededError have their own runtime classes. `decisionFromRow` currently defaults unknown nonnegative kinds to allow_once, which must not be used as the new graph validator.

The schema migrator's closed error codes are `SCHEMA_VERSION_AHEAD`, `SCHEMA_BASELINE_REQUIRED`, `SCHEMA_MIGRATION_REQUIRED`, `SCHEMA_MIGRATION_FAILED`. Its semantic callback accepts raw Bun SQLite. A callback graph error is wrapped as `SCHEMA_MIGRATION_FAILED` with original cause and preserved backup; explicit SchemaMigrationError retains its code. Current-version validation preserves a domain error when there was no upgrade. Database.Client wraps SchemaMigrationError into public `DatabaseUnavailableError` with operation/path/code; server maps that named error to HTTP 503. Ordinary private Error subclasses are sanitized HTTP 500 with request ID, **not** automatically typed HTTP 400/404. Permission route documentation's existing 400/404 declarations do not change that runtime fact.

Minimal recommendation: a precise permission-owned private integrity error/reason union for owner, source, slot, index and attempt defects; migration uses that original cause and exact nonsecret request/event IDs under the existing migration error/backup contract. Existing current integrity callback can wrap it as `DatabaseUnavailableError`/`DATA_INTEGRITY_ERROR` and explicit operation. No new public error class is necessary just to expose a new enum name. If Root wants the same detailed runtime error over Permission HTTP routes, that is a deliberate additional public contract requiring error-handler/schema review, not assumed by this report.

Suggested error **categories**, not selected public literals: missing/conflicting request owner; missing/wrong-kind source grant; scope/Project/Task mismatch; illegal slot kind/identity; missing/recursive/wrong-owner index reference; ambiguous historical capture; execution authority conflict; malformed/different deterministic attempt. Each positive error test should assert the exact selected typed category and implicated identities, not English substring matching or merely absence of writes.

Public `PermissionAuthority.LedgerEvent.event_type` is `z.string()` and `decision_scope` nullable string. `Resolution.eventID` already supports the original U ID. `permission.replied` has required autoReply and optional real userInput; it has **no ledger event ID**, so consumers must re-read canonical original authority rather than infer it from payload summary. Existing Interaction response schema is `z.record(z.string(), z.any()).optional()` (`engine/model.ts:306`) and permits the automatic provenance field used by the frontend. INDEX alone therefore does not require changing generated SDK/OpenAPI schemas. If actual public fields/error schemas are changed later, only the normal unique generation transaction may regenerate them.

## 9. Minimal complete production scope, pending Root approval

Paths are candidates, not permission to modify them now.

| Required scope | Files / concrete change |
| --- | --- |
| Canonical fact reader and current producer | One new `permission/<selected-facts-module>.ts`; `permission/authority.ts`; `permission/permission.sql.ts`. One reader; legal direct/index kinds; original owner/decision time and ID; atomic grant check+slot claim; exact unique-conflict recognition using existing driver error primitive; winner-owned Replied and waiters. Remove superseded raw-reader implementation rather than add fallback |
| Current integrity and versioned historical materialization | `storage/db.ts`; `storage/migrations/index.ts`; new immutable migration DDL snapshot plus semantic implementation (physical file structure selected by Root). Shared original graph rule; no change to `0001-baseline.sql`. A semantic-only revision still needs registry version even if SQL shape is identical |
| Safe old/new-process upgrade | `storage/schema-migration.ts` and initialization ordering in `storage/db.ts` only as separately qualified. No claim that BEGIN IMMEDIATE alone protects old readers |
| Current Session/Task projection | `protocol/session-mirror.ts`, `engine/store.ts`, `engine/interaction.ts`: one canonical read for late Asked and Board; original response time and auto provenance; exact real Task resolved invalidation. Main/Side reducers normally unchanged |
| Truthful new historical event UI | `packages/overlay/src/components/settings/PermissionsPanel.tsx` plus exact en-US/zh-CN keys: neutral index timeline row with its own actual time; operation badge selects real decision/execution, not newest bookkeeping row. No second index resolver in UI |
| Definitions/doc cleanup only if approved | DDL stale cascade comment, applicable architecture/version notes and Root-owned specs/indices/Changelog. No wholesale trigger/table redesign required merely for the event name |

Unchanged by the chosen graph alone: `permission/project-authority.ts` and Project delete scope, policy table, execution-result table/Tool outcome fact reader, physical lease tables, Task lifecycle/activation, Question producer/renderer, Main/Side interaction drafts, all SDK generated files. Their relevant contracts still require qualification. Raw ACP/CLI/channel behavior remains the separately reported bounded tier: re-read canonical pending before real actions, preserve true API errors/winner output; no queue/tombstone/client-cancel guarantee added here. External client visual cancellation is unqualified and not a prerequisite falsely satisfied by a local Main screenshot.

## 10. Focused positive qualification, after implementation authorization

No checks below were executed in this task. Existing backend paths identified in earlier investigations include `permission-two-mode.test.ts`, `permission-transport-hydration.test.ts`, `server/session-permission-projection.test.ts`, `engine-interaction-recovery.test.ts` and the schema migration checker. Root/backend should put each contract in its actual current backend owner; this is not authorization to retain or add UI tests.

1. **Direct producer**: an actual original user grant followed by a second exact-scope invocation yields one canonical U/slot, one real autoReply outbox, exact grant scope/owner, actual result and final Tool/Message retirement. Replay returns the same U ID/time/result. No old test-count substitution.
2. **Serial/parallel and outcomes**: two actual same-request contenders receive the same winner; grant capture versus real deny/cancel/stale and revoke/Project expiry serializes to one valid result. The returned negative winner produces the existing RejectedError, never effect admission. Inject a genuine non-unique storage error and assert that original error contract, not a swallowed winner. Nested transaction/savepoint rollback preserves original outbox ownership; a nested immediate call is not falsely claimed to upgrade a deferred transaction.
3. **Historical unique, unstarted**: exact old requested+source grant+single U, no S; migrate; read original U id/time/scope/autoReply; current continuation qualification uses original Tool/Prompt/Task facts. Actual execution and subsequent result have their own later times. This case must not be called already executed by the migration test.
4. **Historical anchored multiplicity**: old multiple U with a real S→specific U; migrate/read/Board use that exact U including deliberately different U/index timestamps. All old observations and source bytes remain their original facts. A same-time arrangement still resolves by explicit source reference.
5. **Owner observations**: repeated requested rows with same owner and distinct original id/time remain one Request with first time; changed Project/Session/Task/provider/scope material gives exact integrity error. Project-/Session-deleted history still validates against retained ledger owners, not current rows.
6. **Scope and revocation**: project grant same Project/fingerprint across Sessions; task grant across children of the same stored Task; other Task/Project yields the selected scope error/pending admission contract. Previously captured U plus later revoke/expiry still reads original approval while a fresh invocation follows current revoked policy. Original grant human text stays only on that original user occurrence.
7. **Current format strictness**: direct legal event kinds including Full-access null scope; valid I→U; each wrong-kind/missing/self/recursive/cross-request index maps to exact error. Multiple unanchored captures and definite S/slot conflict give precise migration failure with original backup/version/data. The unexecuted U+other-slot policy must first be explicitly chosen, then tested as that exact outcome.
8. **Attempts**: valid deterministic S and success/result pair; wrong attempt/owner/duplicate-start-per-request input gives selected error; real completed result recovery and MCP same-attempt handback retain current physical-owner rules. Multi-attempt corruption cannot be made valid by picking one start.
9. **Projection**: real Replied before/after Asked delivery, including already indexed/current U; Main/Side canonical pending arrays and late Asked converge; Task real interaction resolved notification and Board same original resolved time/automatic response across reopen. Actual userInput only on winning authored reply, never on automatic use/index materialization.
10. **Upgrade boundary**: current registry/schema/integrity, backup, rollback and restart checks under the separately qualified real exclusive-lock owner; old cached/opening process cases remain the actual process checker, not a transaction-only fixture. Current-version bad graph should reach its declared current integrity error; old-version bad graph should reach declared migration error/backup.

For desktop, reuse the earlier [bounded plan](production-scope-and-desktop-plan.md) after fresh before/after scopes: natural external read → real Allow Project → actual second exact-scope read, Settings Refresh/history same-mount English/Chinese, canonical pending cold/reconnect, and a real Task interaction when that path actually emits Asked. For migration history, use legitimate old-producer facts in a closed owned data root before upgrade; never insert a fake user grant into a live page. A successful automatic grant reuse may emit no Asked at all and therefore legitimately create no Task Interaction; that alone cannot qualify the race/invalidation path. ACP peer cancellation and other external client UIs remain unknown.

## 11. Remaining decisions and freeze

Root still needs to choose: INDEX literal and explicit metadata/provenance, semantic revision/file layout, strict policy for existing slot plus unexecuted historical U and pre-capture-looking revocation interleavings, exact private error categories/public exposure, and any newly exposed Task-history localization scope. Safe physical migration remains separately unqualified by this report. No benchmark, CPU/SQL bound or external interoperability result is invented.

The settled implementation direction is narrower: one same-transaction fact reader, one explicit single-hop locator, original decision identity/time/scope, no retrospective user/Bus facts, canonical duplicate-request owner validation, and one future serialized capture writer. This report and its source capture are frozen for Root review; no shared spec or product file was changed.
