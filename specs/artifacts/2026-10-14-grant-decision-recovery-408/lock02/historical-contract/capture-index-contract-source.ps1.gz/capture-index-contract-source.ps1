$ErrorActionPreference = 'Stop'
$repo = 'D:/myhexin-local/opencorvus'
$out = Join-Path $repo '.tmp-grant-decision-recovery-408/ui/index-contract-source'
[IO.Directory]::CreateDirectory($out) | Out-Null
$utf8 = [Text.UTF8Encoding]::new($false)
function Save-Text([string]$name, [string]$text) { [IO.File]::WriteAllText((Join-Path $out $name), $text, $utf8) }
$files = @(
  'packages/opencorvus/src/permission/permission.sql.ts',
  'packages/opencorvus/src/permission/authority.ts',
  'packages/opencorvus/src/permission/project-authority.ts',
  'packages/opencorvus/src/permission/types.ts',
  'packages/opencorvus/src/permission/decision.ts',
  'packages/opencorvus/src/permission/invocation.ts',
  'packages/opencorvus/src/engine/store.ts',
  'packages/opencorvus/src/engine/interaction.ts',
  'packages/opencorvus/src/storage/db.ts',
  'packages/opencorvus/src/storage/schema-migration.ts',
  'packages/opencorvus/src/storage/migrations/index.ts',
  'packages/opencorvus/src/session/tool-outcome-facts.ts',
  'packages/opencorvus/src/server/routes/permission.ts',
  'packages/opencorvus/src/server/error-handler.ts',
  'packages/opencorvus/src/protocol/session-mirror.ts',
  'packages/opencorvus/src/project/delete.ts',
  'packages/overlay/src/components/settings/PermissionsPanel.tsx'
)
$manifest = @()
foreach ($path in $files) {
  $name = $path.Replace('/','__') + '.txt'
  $source = Join-Path $repo $path
  $raw = [IO.File]::ReadAllBytes($source)
  [IO.File]::WriteAllBytes((Join-Path $out $name), $raw)
  $manifest += [ordered]@{ source=$path; capture=$name; bytes=$raw.Length; method='original bytes; read-only source capture, not an acceptance hash' }
}
$ranges = @(
  @{ path='packages/opencorvus/src/storage/ddl.ts'; ranges=@('3908:3944','4278:4307') },
  @{ path='packages/opencorvus/src/storage/migrations/0001-baseline.sql'; ranges=@('1036:1092','5690:5720') },
  @{ path='packages/opencorvus/src/storage/schema.ts'; ranges=@('1:44','108:130') },
  @{ path='packages/opencorvus/src/engine/engine.sql.ts'; ranges=@('1:27') },
  @{ path='packages/opencorvus/src/engine/model.ts'; ranges=@('1:43','338:360') },
  @{ path='packages/opencorvus/src/engine/task-session-lineage.ts'; ranges=@('1:45') },
  @{ path='packages/opencorvus/src/engine/task-execution-capsule-binding.ts'; ranges=@('1:23') },
  @{ path='packages/opencorvus/src/project/project.sql.ts'; ranges=@('1:36') },
  @{ path='packages/opencorvus/src/project/identity-convergence.ts'; ranges=@('70:102') },
  @{ path='packages/opencorvus/script/control-state-redundancy-check.ts'; ranges=@('339:353','467:473','524:530') },
  @{ path='specs/current/architecture/security-permission.md'; ranges=@('1:108') }
)
foreach ($entry in $ranges) {
  $lines = [IO.File]::ReadAllLines((Join-Path $repo $entry.path))
  $body = [Collections.Generic.List[string]]::new()
  $body.Add('SOURCE: ' + $entry.path)
  foreach ($segment in $entry.ranges) {
    $range = @($segment.Split(':') | ForEach-Object { [int]$_ })
    $body.Add(('LINES {0}-{1}' -f $range[0],$range[1]))
    for($i=$range[0]; $i -le [Math]::Min($range[1],$lines.Count); $i++) { $body.Add(('{0,5}: {1}' -f $i,$lines[$i-1])) }
  }
  Save-Text ($entry.path.Replace('/','__')+'.excerpt.txt') ($body -join "`n")
}
Push-Location $repo
try {
  Save-Text 'head.txt' ((& git rev-parse HEAD) -join "`n")
  Save-Text 'status.txt' ((& git status --short) -join "`n")
  Save-Text 'scoped-diff.txt' ((& git diff -- $files) -join "`n")
  Save-Text 'ledger-callers.txt' ((& rg -n 'PermissionLedgerTable|permission_ledger|PermissionEventType' packages/opencorvus/src packages/overlay/src packages/channel-runtime/src packages/opencorvus/script -g '!*.map') -join "`n")
  Save-Text 'slot-and-graph-callers.txt' ((& rg -n 'decision_slot|grant_used|settleDecision|requestFromRow|requestedRows|source_event_id' packages/opencorvus/src/permission packages/opencorvus/src/engine/store.ts packages/opencorvus/src/engine/interaction.ts packages/opencorvus/src/session/tool-outcome-facts.ts) -join "`n")
  Save-Text 'errors-and-registry.txt' ((& rg -n 'SchemaMigrationError|DATA_INTEGRITY_ERROR|DATA_MIGRATION_REQUIRED|PermissionIdentityCollisionError|PERMISSION_IDENTITY_COLLISION|DatabaseUnavailableError' packages/opencorvus/src/permission packages/opencorvus/src/storage packages/opencorvus/src/server) -join "`n")
  Save-Text 'grant-introduction.txt' ((& git log -3 --format='%H %s' -S 'grant_used' -- packages/opencorvus/src/permission/authority.ts) -join "`n")
  Save-Text 'requested-observation-history.txt' ((& git show e080173922c92d7800ee3291f185ec18a0f4ae19 -- packages/opencorvus/src/permission/authority.ts) -join "`n")
  Save-Text 'recent-history.txt' ((& git log -8 --format='%H %s' -- packages/opencorvus/src/permission/authority.ts packages/opencorvus/src/permission/permission.sql.ts packages/opencorvus/src/storage/schema-migration.ts) -join "`n")
} finally { Pop-Location }
Save-Text 'source-manifest.json' ($manifest | ConvertTo-Json -Depth 4)
Write-Output ([pscustomobject]@{ directory=$out; originalSourceFiles=$files.Count; excerptFiles=$ranges.Count; operation='source/query capture only; no module import, database, test or service' } | ConvertTo-Json)
