import assert from "node:assert/strict"
import fs from "node:fs/promises"
import path from "node:path"
import { NodeProcess } from "../../packages/util/src/process-node"
import { expectedTestProcessSupervisor } from "../../packages/opencorvus/script/test-process-supervisor"

// Thin original physical owner, following the reviewed run-formal pattern.
const [scopeArgument] = process.argv.slice(2)
assert(scopeArgument && path.isAbsolute(scopeArgument), "Explicit absolute fresh scope required")
const scope = path.resolve(scopeArgument)
assert.equal(path.dirname(scope), path.resolve(import.meta.dir))
const startedAt = Date.now(), deadlineAt = startedAt + 600000
await fs.mkdir(scope)
const supervisor = expectedTestProcessSupervisor()
const repository = path.resolve(import.meta.dir, "../..")
const packageDirectory = path.join(repository, "packages/opencorvus")
const args = [`--config=${path.join(packageDirectory, "test/empty-bunfig.toml")}`,
  `--tsconfig-override=${path.join(packageDirectory, "tsconfig.json")}`,
  path.join(import.meta.dir, "run-lock-probe.ts"), scope, String(deadlineAt)]
const environmentNames = ["SystemRoot", "SYSTEMROOT", "WINDIR", "COMSPEC", "ComSpec", "PATH", "PATHEXT", "TEMP", "TMP",
  "USERPROFILE", "HOMEDRIVE", "HOMEPATH", "APPDATA", "LOCALAPPDATA"]
const environment = Object.fromEntries(environmentNames.flatMap(key => process.env[key] === undefined ? [] : [[key, process.env[key]!]]))
const owner: any = { startedAt, deadlineAt, parentPID: process.pid, executable: process.execPath, bunVersion: Bun.version,
  args, cwd: repository, scope, inheritedEnvironmentNames: Object.keys(environment), requestStarted: false,
  requestSettled: false, physicalJoined: false, outputJoined: false, status: "preparing" }
let handle: any
let primary: { error: unknown } | undefined
let output: { stdout: Uint8Array; stderr: Uint8Array } | undefined
const cleanupErrors: Array<{ step: string; error: unknown }> = []
function errorFacts(error: unknown): unknown {
  if (!(error instanceof Error)) return { value: String(error) }
  const value = error as Error & { code?: unknown; errno?: unknown }
  return { name: value.name, message: value.message, stack: value.stack,
    ...(value.code === undefined ? {} : { code: value.code }), ...(value.errno === undefined ? {} : { errno: value.errno }),
    ...(value.cause === undefined ? {} : { cause: errorFacts(value.cause) }),
    ...(value instanceof AggregateError ? { errors: value.errors.map(errorFacts) } : {}) }
}
const cleanup = async (step: string, action: () => Promise<unknown>) => {
  try { await action() } catch (error) { cleanupErrors.push({ step, error }) }
}
async function writeOwner(name: string) {
  const target = path.join(scope, name), pending = `${target}.${process.pid}.pending`
  await fs.writeFile(pending, JSON.stringify(owner, null, 2))
  await fs.rename(pending, target)
}
try {
  assert(supervisor, "Mature Windows native owned-tree supervisor required")
  process.env.OPENCORVUS_PROCESS_SUPERVISOR = supervisor
  await fs.copyFile(import.meta.filename, path.join(scope, "actual-launch-lock-probe.ts"))
  await writeOwner("owner-start.json")
  assert(Date.now() < deadlineAt - 60000, "Original parent close reserve reached before admission")
  owner.requestStarted = true; owner.status = "running"
  const result = await NodeProcess.run({ command: { executable: process.execPath, args }, cwd: repository,
    env: { ...environment, OPENCORVUS_PROCESS_SUPERVISOR: supervisor },
    ownership: "owned_tree", windowsHide: true, stdin: "ignore", deadlineAt, nothrow: true,
    onSpawned(value) { handle = value; owner.pid = value.pid; owner.occurrenceID = value.occurrenceID } })
    .finally(() => { owner.requestSettled = true })
  owner.receipt = result.receipt
  output = { stdout: result.stdout, stderr: result.stderr }
  owner.settledReceipt = await handle.settled; owner.physicalJoined = true
  await handle.outputSettled; owner.outputJoined = true
  assert.equal(result.receipt.reason, "exited", "The original driver must end by a normal process exit")
  assert.equal(result.receipt.exitCode, 0, "The original driver must exit successfully")
  assert.deepEqual(owner.settledReceipt, result.receipt, "Returned and physically settled receipts must match")
} catch (error) {
  primary = { error }
} finally {
  if (handle && !owner.physicalJoined) {
    await cleanup("terminate exact owned driver", async () => {
      owner.emergencyOwnHandle = true
      owner.terminationReceipt = await handle.terminate("aborted")
    })
    await cleanup("observe original driver physical settlement", async () => {
      owner.settledReceipt = await handle.settled; owner.physicalJoined = true
      owner.receipt ??= owner.settledReceipt
    })
  }
  if (handle && !owner.outputJoined) await cleanup("observe original driver output settlement", async () => {
    await handle.outputSettled; owner.outputJoined = true
  })
  if (output) {
    await cleanup("persist driver stdout", () => fs.writeFile(path.join(scope, "stdout.log"), output!.stdout))
    await cleanup("persist driver stderr", () => fs.writeFile(path.join(scope, "stderr.log"), output!.stderr))
  }
  const closed = owner.requestStarted && owner.requestSettled && owner.physicalJoined && owner.outputJoined
  const normal = owner.receipt?.reason === "exited" && owner.receipt.exitCode === 0
  if (owner.requestStarted && (!closed || !normal)) cleanupErrors.push({ step: "validate actual driver terminal contract",
    error: new Error(JSON.stringify({ receipt: owner.receipt, closed, normal })) })
  owner.endedAt = Date.now()
  owner.primaryError = primary ? errorFacts(primary.error) : null
  owner.cleanupErrors = cleanupErrors.map(({ step, error }) => ({ step, error: errorFacts(error) }))
  owner.status = !primary && cleanupErrors.length === 0 && closed && normal ? "passed" : "failed"
  await cleanup("persist outer owner", () => writeOwner("owner.json"))
  owner.cleanupErrors = cleanupErrors.map(({ step, error }) => ({ step, error: errorFacts(error) }))
  if (cleanupErrors.length) owner.status = "failed"
  process.exitCode = owner.status === "passed" ? 0 : 1
  // Preserve actual diagnostics in original output even if the evidence file failed.
  console.log(JSON.stringify(owner))
}
