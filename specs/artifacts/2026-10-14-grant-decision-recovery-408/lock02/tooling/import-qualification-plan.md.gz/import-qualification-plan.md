# 408 argv diagnosis and import-only qualification plan

Status: prepared only, no import qualification or database rerun started. Root paused the followup lock/failure matrix. Its three first-run source files and README/manifest were copied to `followup-before/` before this change. The entire original lock-process-01 directory remains unchanged.

## Original observation and narrow hypothesis

Root's original80885 joined0/38ca9d. All11 workers exited0 and closed, and the two real WAL cases qualified their stated lock/version mechanism. However driver/worker stderr contains Bun's `Internal error: directory mismatch` for packages/opencorvus/tsconfig.json. Exit0 therefore did not establish clean tooling. This original diagnostic is retained; it is not filtered from logs or reclassified as a clean run.

The [upstream Bun issue28605](https://github.com/oven-sh/bun/issues/28605) reports the same additional diagnostic when using `--tsconfig-override`, in a different platform/version/workspace case. [Bun's TypeScript runtime documentation](https://bun.sh/docs/runtime/typescript) describes its built-in TypeScript handling. These sources support testing natural configuration discovery, not a claim that this local diagnosis is already proven. Current repository packageManager is bun@1.4.0; the experiment retains that exact runtime rather than changing its version.

Exact tool change only:

- launcher → driver: actual cwd and recorded cwd change from repository root to `packages/opencorvus`; remove `--tsconfig-override=<package>/tsconfig.json`.
- driver → worker: cwd was already the package directory and stays so; remove the same override argument.
- Keep the real existing empty Bun configuration argument, all executable/absolute script/role/runtime/evidence/deadline arguments, the same native Process owner, all600/180/30/60 budgets and every SQL/role/cleanup branch. No copied tsconfig or parallel configuration exists.

Precise diffs are `argv-launch-lock-probe.ts.patch` and `argv-run-lock-probe.ts.patch`. `lock-worker.ts` is unchanged from the actual first run. The original lock suite must be rerun in a **new scope** after qualification; original01 is never reused.

## Proposed no-DB import child

`import-qualification.ts` is one small scratch entry with all runtime/database imports deferred until explicit owned runtime/cwd/deadline checks. It imports the actual util owner, managed-directory and supervisor modules, Bun SQLite module, migrator, finalized query helper, schema/DDL/registry and production Database module. It calls no SQLite constructor, Database.Client/Identity, schemaVersion, migrator, schema validation or query. It checks the actual exported function surface and the lazy production module state `uninitialized`, and records actual owned data-directory entries. Runtime directory initialization during imports is permitted only inside the fresh own root.

Root's subsequent preparation authorization adds an explicit optional `import` mode to the **same** `launch-lock-probe.ts`; omitted mode continues to select the unchanged DB suite. The launcher creates one exact managed directory under the fresh scope and binds runtime/own test home/process root. It passes min(start+180s, original600s closeBy) to the import entry and native owner, preserves original stdout/stderr/receipts, and removes only that managed root after actual physical/output/request joins. Failure before admission or incomplete joins retains the root. No second launch framework or copied tsconfig exists.

Exact proposed command, **not run**:

```powershell
$bun408 = 'D:\myhexin-local\opencorvus\.tmp-product-iteration\sse-compression-305\bun140\bun-windows-x64\bun.exe'
$env:PATH = (Split-Path -Parent $bun408) + ';' + $env:PATH
& $bun408 run .tmp-grant-decision-recovery-408/functionality/launch-lock-probe.ts D:\myhexin-local\opencorvus\.tmp-grant-decision-recovery-408\functionality\import-argv-01 import
```

The exact allocated path/argv/mode/cwd and original deadlines will be recorded by that owner. Its import child's command has this shape:

```text
executable: D:\myhexin-local\opencorvus\.tmp-product-iteration\sse-compression-305\bun140\bun-windows-x64\bun.exe
cwd: D:\myhexin-local\opencorvus\packages\opencorvus
args:
  --config=D:\myhexin-local\opencorvus\packages\opencorvus\test\empty-bunfig.toml
  D:\myhexin-local\opencorvus\.tmp-grant-decision-recovery-408\functionality\import-qualification.ts
  <exact managed import-runtime-* directory>/runtime
  D:\myhexin-local\opencorvus\.tmp-grant-decision-recovery-408\functionality\import-argv-01\import-result.json
  <original child absolute deadline>
ownership: owned_tree; windowsHide: true; stdin: ignore; nothrow: true
```

Use only the same OS/path environment allowlist as the three current sources, plus actual supervisor path and exact `OPENCORVUS_HOME=<runtime>`, `OPENCORVUS_TEST_HOME=<runtime>/owned-home`, `OPENCORVUS_TEST_PROCESS_ROOT=<managed import root>`. No Provider/auth/models/user config variables are copied. Original parent physical deadline600s, child min(start+180s,parentCloseBy), import wait min30s/originalchilddeadline, parent60s close reserve remain bounded. Root owns actual invocation and original tool-level join; the launcher preserves the true native receipt/physical/output/request and complete stdout/stderr. The helper catches actual import errors and aggregates evidence-write/own-close errors; it has no recovery path that opens a database. An unexpected open connection is a failed qualification and only that own handle is normally closed. Successful receipt metadata must match the actual import result's PID and original child deadline before the launcher qualifies it.

The helper's `qualified_imports_only` output means only successful module resolution and observed lazy DB state. Root must inspect complete original stderr, not infer tooling cleanliness from exit0 or use a keyword-removal filter. If the Bun diagnostic remains, retain the new failure/diagnostic and investigate the actual resolver inputs; do not launch the full DB suite blindly.

## Subsequent original-suite rerun, not yet authorized here

Once Root qualifies the import and original source diff, use the **unchanged launcher command shape** with fresh `lock-process-02`. The same two original cases must reproduce their actual SQL/backup/NORMAL/old-reopen facts with all original receipts; only then can argv tooling be called qualified. All planned two-upgrader/backup/validator/unlock cases remain paused and no additional SQL scenario source was implemented.

Limitations: import-only success cannot prove lock behavior or semantic migration, and absent diagnostics in an import does not guarantee the subsequent full process graph is clean. Root's future rerun is necessary. Rollback-journal remains an explicitly unsupported exclusion candidate; physical aliases/compiled Native1.3, real dual-upgrader competition and failure branches are still unknown, not silently accepted.
