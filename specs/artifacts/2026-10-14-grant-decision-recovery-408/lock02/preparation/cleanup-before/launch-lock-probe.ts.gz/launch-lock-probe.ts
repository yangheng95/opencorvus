import assert from "node:assert/strict"
import fs from "node:fs/promises"
import path from "node:path"
import { NodeProcess } from "../../packages/util/src/process-node"
import { expectedTestProcessSupervisor } from "../../packages/opencorvus/script/test-process-supervisor"

// Thin original physical owner, following the reviewed run-formal pattern.
const [scopeArgument] = process.argv.slice(2)
assert(scopeArgument && path.isAbsolute(scopeArgument), "Explicit absolute fresh scope required")
const scope = path.resolve(scopeArgument)
assert.equal(path.dirname(scope), path.resolve(import.meta.dir))
const startedAt = Date.now(), deadlineAt = startedAt + 600000
await fs.mkdir(scope)
const supervisor = expectedTestProcessSupervisor()
assert(supervisor, "Mature Windows native owned-tree supervisor required")
process.env.OPENCORVUS_PROCESS_SUPERVISOR = supervisor
const repository = path.resolve(import.meta.dir, "../..")
const packageDirectory = path.join(repository, "packages/opencorvus")
const args = [`--config=${path.join(packageDirectory, "test/empty-bunfig.toml")}`,
  `--tsconfig-override=${path.join(packageDirectory, "tsconfig.json")}`,
  path.join(import.meta.dir, "run-lock-probe.ts"), scope, String(deadlineAt)]
const environmentNames = ["SystemRoot", "SYSTEMROOT", "WINDIR", "COMSPEC", "ComSpec", "PATH", "PATHEXT", "TEMP", "TMP",
  "USERPROFILE", "HOMEDRIVE", "HOMEPATH", "APPDATA", "LOCALAPPDATA"]
const environment = Object.fromEntries(environmentNames.flatMap(key => process.env[key] === undefined ? [] : [[key, process.env[key]!]]))
const owner: any = { startedAt, deadlineAt, parentPID: process.pid, executable: process.execPath, bunVersion: Bun.version,
  args, cwd: repository, scope, inheritedEnvironmentNames: Object.keys(environment), requestStarted: false }
await fs.copyFile(import.meta.filename, path.join(scope, "actual-launch-lock-probe.ts"))
await fs.writeFile(path.join(scope, "owner-start.json"), JSON.stringify(owner, null, 2))
let handle: any
try {
  assert(Date.now() < deadlineAt - 60000, "Original parent close reserve reached before admission")
  owner.requestStarted = true
  const result = await NodeProcess.run({ command: { executable: process.execPath, args }, cwd: repository,
    env: { ...environment, OPENCORVUS_PROCESS_SUPERVISOR: supervisor },
    ownership: "owned_tree", windowsHide: true, stdin: "ignore", deadlineAt, nothrow: true,
    onSpawned(value) { handle = value; owner.pid = value.pid; owner.occurrenceID = value.occurrenceID } })
  owner.receipt = result.receipt
  await handle.settled; owner.physicalJoined = true
  await handle.outputSettled; owner.outputJoined = true
  owner.requestSettled = true
  await fs.writeFile(path.join(scope, "stdout.log"), result.stdout)
  await fs.writeFile(path.join(scope, "stderr.log"), result.stderr)
  process.exitCode = result.receipt.exitCode ?? 1
} catch (error) {
  owner.error = String(error); owner.requestSettled = owner.requestStarted; process.exitCode = 1
  if (handle && !owner.physicalJoined) {
    owner.receipt = await handle.terminate("aborted"); await handle.settled; owner.physicalJoined = true
  }
  if (handle && !owner.outputJoined) { await handle.outputSettled; owner.outputJoined = true }
} finally {
  owner.endedAt = Date.now()
  await fs.writeFile(path.join(scope, "owner.json"), JSON.stringify(owner, null, 2))
  console.log(JSON.stringify(owner))
}
