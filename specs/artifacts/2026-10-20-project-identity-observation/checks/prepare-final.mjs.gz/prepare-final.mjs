import fs from 'node:fs'
const root=import.meta.dirname,base='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-20/'
const bundle=base+'identity-observation-438-final-bundle/bin'
if(fs.existsSync(bundle))throw Error('Fresh immutable publication required')
fs.mkdirSync(bundle,{recursive:true})
fs.copyFileSync(base+'identity-observation-438-before-bundle/bin/bun.exe',bundle+'/bun.exe')
fs.cpSync('packages/overlay/dist-vite',bundle+'/ui',{recursive:true})
for(const name of ['launch','settle','shutdown']){
 let source=fs.readFileSync(root+'/'+name+'-after.ps1','utf8')
  .replaceAll('identity-observation-438-after','identity-observation-438-final')
  .replaceAll('18653','18655')
 if(name==='launch')source=source.replaceAll('/settle-after.ps1','/settle-final.ps1')
 fs.writeFileSync(root+'/'+name+'-final.ps1',source,{flag:'wx'})
}
fs.writeFileSync(root+'/config-write-final.ts',fs.readFileSync(root+'/config-write-after.ts','utf8')
 .replace('phase === "after"','phase === "final"').replace('const port = 18653','const port = 18655')
 .replace('canonical-write-after.json','canonical-write-final.json'),{flag:'wx'})
console.log(JSON.stringify({phase:'final',port:18655,bundle}))
