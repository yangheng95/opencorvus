import fs from 'node:fs'
const root=import.meta.dirname
const read=name=>JSON.parse(fs.readFileSync(root+'/'+name,'utf8'))
const baseline=read('canonical-write-check.json'),intermediate=read('canonical-write-after.json'),final=read('canonical-write-final.json')
const cost=read('final-cost.json'),lifecycle=read('final-lifecycle.json'),cold=cost.requests[0]
const count=phase=>cold.summary.find(row=>row.phase===phase)?.count
const concurrent=lifecycle.server.filter(row=>row.status==='started'&&row.method==='GET'&&row.path==='/global/config'&&row.time>=final.at&&row.time<cold.request.time)
 .map(start=>lifecycle.server.find(row=>row.requestID===start.requestID&&row.status==='completed')).filter(Boolean)
const projects=cold.inventory[0].projects
const checks=[
 {name:'cold canonical write <=10000ms',actualMs:final.writeMs,passed:final.writeMs<=10000},
 {name:'restore canonical write <=5000ms',actualMs:final.restoreMs,passed:final.restoreMs<=5000},
 {name:'real concurrent page config read <=20000ms',samples:concurrent,passed:concurrent.length>0&&concurrent.every(row=>row.statusCode===200&&row.duration<=20000)},
 {name:'canonical accepted and completely restored with Ask',passed:final.accepted&&final.restored&&final.permissionMode==='ask'},
 {name:'complete registered Project candidate validation',projects,counts:{before:count('config.global.before'),after:count('config.global.after'),capabilities:count('config.validate.capabilities'),models:count('config.validate.models')},passed:count('config.global.before')===projects&&count('config.global.after')===projects&&count('config.validate.capabilities')===projects&&count('config.validate.models')===projects+1},
]
const result={status:checks.every(row=>row.passed)?'passed':'failed',baseline,intermediate,final,checks,qualification:'Before/after used page entry during restore; final preloaded a real Chat then used New chat during the first write. These are real individual qualifications, not identical manual-navigation A/B inputs.'}
fs.writeFileSync(root+'/benchmark-result.json',JSON.stringify(result,null,2),{flag:'wx'})
console.log(JSON.stringify({status:result.status,checks}))
process.exitCode=result.status==='passed'?0:1
