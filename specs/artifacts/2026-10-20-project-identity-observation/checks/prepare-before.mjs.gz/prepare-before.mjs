import fs from 'node:fs'
const root=import.meta.dirname,tag='identity-observation-438-before'
const bundle='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-20/'+tag+'-bundle/bin'
if(fs.existsSync(bundle))throw Error('Fresh immutable publication required')
fs.mkdirSync(bundle,{recursive:true})
fs.copyFileSync('.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64/bun.exe',bundle+'/bun.exe')
fs.cpSync('packages/overlay/dist-vite',bundle+'/ui',{recursive:true})
for(const name of ['launch.ps1','settle.ps1','shutdown.ps1','prepare-authority.mjs','config-write-check.ts','capture-cost.mjs']){
 const source=fs.readFileSync('.tmp-product-iteration/directory-admission-cost-437/'+name,'utf8')
  .replaceAll('directory-admission-cost-437','identity-observation-438')
  .replaceAll('18647','18651').replaceAll('qa-admission-437','qa-identity-438')
 fs.writeFileSync(root+'/'+name,source,{flag:'wx'})
}
console.log(JSON.stringify({tag,port:18651,businessInputs:0}))
