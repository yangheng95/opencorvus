import fs from 'node:fs'
const root=import.meta.dirname
const base='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-20/'
const bundle=base+'identity-observation-438-after-bundle/bin'
if(fs.existsSync(bundle))throw Error('Fresh immutable publication required')
fs.mkdirSync(bundle,{recursive:true})
fs.copyFileSync(base+'identity-observation-438-before-bundle/bin/bun.exe',bundle+'/bun.exe')
fs.cpSync('packages/overlay/dist-vite',bundle+'/ui',{recursive:true})
for(const name of ['launch','settle','shutdown']){
 let source=fs.readFileSync(root+'/'+name+'.ps1','utf8')
  .replaceAll('identity-observation-438-before','identity-observation-438-after')
  .replaceAll('identity-observation-438-after-authority','identity-observation-438-before-authority')
  .replaceAll('18651','18653')
 if(name==='launch')source=source.replaceAll('/settle.ps1','/settle-after.ps1')
 fs.writeFileSync(root+'/'+name+'-after.ps1',source,{flag:'wx'})
}
fs.writeFileSync(root+'/config-write-after.ts',fs.readFileSync(root+'/config-write-check.ts','utf8')
 .replace('phase === "before"','phase === "after"').replace('const port = 18651','const port = 18653')
 .replace('canonical-write-check.json','canonical-write-after.json'),{flag:'wx'})
console.log(JSON.stringify({port:18653,bundle,phase:'after',uiSource:'435 formal unchanged UI build'}))
