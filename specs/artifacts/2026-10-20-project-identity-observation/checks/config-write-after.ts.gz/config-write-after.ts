import fs from "node:fs/promises"
import assert from "node:assert/strict"
import { parse } from "../../packages/overlay/node_modules/jsonc-parser"
import { configure } from "../../packages/overlay/src/services/api"
import { patchGlobalConfig } from "../../packages/overlay/src/services/config"
import { loadConfigInfo } from "../../packages/overlay/src/services/config-load"
import { getHostTransport } from "../../packages/overlay/src/services/host-transport-runtime"
import { appStore, setAppStore } from "../../packages/overlay/src/store/app"
import { setSettingsStore } from "../../packages/overlay/src/store/settings"
import { setBoardStore } from "../../packages/overlay/src/store/board"

const root = import.meta.dir
const phase = process.argv[2]
assert(phase === "after")
const port = 18653
const evidence = `C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-20/identity-observation-438-${phase}/evidence`
const ready = JSON.parse(await fs.readFile(evidence + "/native-host-ready.json", "utf8"))
assert(ready.occurrence.startsWith(`identity-observation-438-${phase}-`))
const canonical = "C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/member-live-rendering-412-fresh/runtime/config/opencorvus.jsonc"
const original = parse(await fs.readFile(canonical, "utf8"))
assert.equal(original.permission_mode, "ask")
configure({ serverUrl: `http://127.0.0.1:${port}`, directory: "" })
setSettingsStore("directory", "")
setBoardStore({ board: null, selectedSource: null })
setAppStore("connected", true)
assert.equal(getHostTransport().kind, "browser")
const at = new Date().toISOString(), start = performance.now()
let accepted = false, restored = false, writeMs = 0, restoreMs = 0
try {
  const saved = await patchGlobalConfig({ username: "qa-identity-438" })
  writeMs = performance.now() - start
  assert.equal(saved.username, "qa-identity-438")
  assert.equal(saved.permission_mode, "ask")
  assert.deepEqual(await loadConfigInfo(), [])
  assert.equal(appStore.config?.username, "qa-identity-438")
  accepted = true
} finally {
  const restoreStart = performance.now()
  const saved = await patchGlobalConfig({ username: Object.hasOwn(original, "username") ? original.username : null })
  restoreMs = performance.now() - restoreStart
  assert.equal(saved.permission_mode, "ask")
  assert.deepEqual(parse(await fs.readFile(canonical, "utf8")), original)
  restored = true
  const result = { at, endedAt: new Date().toISOString(), phase, port, occurrence: ready.occurrence,
    transport: getHostTransport().kind, boundary: "Production config service -> production browser HostTransport -> original HTTP server -> canonical file; no mocked request, provider body, or UI automation",
    accepted, restored, writeMs, restoreMs, permissionMode: "ask", changedField: "username", dataRestoration: "Complete parsed canonical source equals the pre-check source" }
  await fs.writeFile(`${root}/canonical-write-after.json`, JSON.stringify(result, null, 2), { flag: "wx" })
  console.log(JSON.stringify(result))
}
