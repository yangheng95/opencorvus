import fs from 'node:fs'
const phase=process.argv[2]
if(!['before','after','verified','final'].includes(phase))throw Error('Explicit phase required')
const root=import.meta.dirname,source='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/member-live-rendering-412-fresh/runtime/log/dev.log'
const evidence=`C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-20/identity-observation-438-${phase}/evidence`
const ready=JSON.parse(fs.readFileSync(evidence+'/native-host-ready.json','utf8'))
const entries=fs.readFileSync(source,'utf8').split('\n').filter(Boolean).flatMap(line=>{try{return[JSON.parse(line)]}catch{return[]}})
 .filter(e=>Date.parse(e.time)>=Date.parse(ready.observedAtUtc))
const requests=entries.filter(e=>e.service==='server'&&e.data.method==='PATCH'&&e.data.path==='/global/config'&&e.data.status==='completed')
if(requests.length!==2)throw Error('Two original completed canonical writes required')
const result={phase,source,occurrence:ready.occurrence,requests:requests.map(r=>{
 const rows=entries.filter(e=>e.service==='skill-read-diagnostics'&&e.data.http?.requestID===r.data.requestID)
 const completed=rows.filter(e=>e.data.status==='completed'),summary=new Map()
 for(const {data:d} of completed){const item=summary.get(d.phase)||{phase:d.phase,count:0,totalMs:0,maxMs:0};item.count++;item.totalMs+=d.duration||0;item.maxMs=Math.max(item.maxMs,d.duration||0);summary.set(d.phase,item)}
 const started=entries.find(e=>e.service==='server'&&e.data.requestID===r.data.requestID&&e.data.status==='started')
 const inventory=entries.filter(e=>e.service==='config'&&e.message==='global mutation project inventory'&&e.time>=started.time&&e.time<=r.time).map(e=>e.data)
 return {request:{time:r.time,...r.data},inventory,summary:[...summary.values()].sort((a,b)=>b.totalMs-a.totalMs),spans:rows.map(({time,data:d})=>({time,status:d.status,phase:d.phase,spanID:d.spanID,parentSpanID:d.parentSpanID,outcome:d.outcome,duration:d.duration,disposition:d.disposition,stateLabel:d.stateLabel}))}
})}
fs.writeFileSync(root+'/'+phase+'-cost.json',JSON.stringify(result,null,2),{flag:'wx'})
console.log(JSON.stringify(result.requests.map(({request,inventory,summary})=>({request,inventory,phases:summary.filter(p=>p.phase.startsWith('config.'))})),null,2))
