import fs from 'node:fs'
const phase=process.argv[2],root=import.meta.dirname
if(!['before','after','final'].includes(phase))throw Error('Explicit phase required')
const evidence=`C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-20/identity-observation-438-${phase}/evidence`
const ready=JSON.parse(fs.readFileSync(evidence+'/native-host-ready.json','utf8'))
const rows=fs.readFileSync('C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/member-live-rendering-412-fresh/runtime/log/dev.log','utf8').split('\n').filter(Boolean).flatMap(l=>{try{return[JSON.parse(l)]}catch{return[]}}).filter(e=>e.time>=ready.observedAtUtc)
const server=rows.filter(e=>e.service==='server'&&['/config','/global/config'].includes(e.data.path)).map(({time,data:d})=>({time,requestID:d.requestID,method:d.method,path:d.path,status:d.status,statusCode:d.statusCode,duration:d.duration}))
const lifecycle=rows.filter(e=>['creating instance','disposing instance','converged idle Project runtimes'].includes(e.message)).map(({time,message,data})=>({time,message,data}))
fs.writeFileSync(root+'/'+phase+'-lifecycle.json',JSON.stringify({phase,occurrence:ready.occurrence,server,lifecycle},null,2),{flag:'wx'})
console.log(JSON.stringify({phase,requests:server.length,creating:lifecycle.filter(e=>e.message==='creating instance').length,convergence:lifecycle.filter(e=>e.message==='converged idle Project runtimes').map(e=>({time:e.time,retained:e.data.retained,active:e.data.active,disposed:e.data.disposed.length}))}))
