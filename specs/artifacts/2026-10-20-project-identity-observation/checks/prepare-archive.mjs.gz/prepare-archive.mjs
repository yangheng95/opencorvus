import fs from 'node:fs'
const root=import.meta.dirname
const source=fs.readFileSync('.tmp-product-iteration/config-write-cost-436/archive.mjs','utf8')
 .replaceAll('2026-10-20-config-write-cost','2026-10-20-project-identity-observation')
 .replaceAll('config-write-cost-436','identity-observation-438')
 .replace("['before','after','verified','final']","['before','after','final']")
 .replace('physicalScopes:4','physicalScopes:3')
fs.writeFileSync(root+'/archive.mjs',source,{flag:'wx'})
console.log('Prepared exact three-scope physical settlement archive and paired private retirement')
