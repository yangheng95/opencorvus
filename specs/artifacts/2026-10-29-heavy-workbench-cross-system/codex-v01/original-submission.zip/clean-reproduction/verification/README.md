# 真实执行证据

- commands.json：每条真实 argv、cwd、PID（Process Identifier，进程标识）、UTC 起止、退出码、原始标准输出/错误路径。
- checks.json：独立从原始 CSV 得到 reference，核对实际 SQLite 逐身份金额、逐身份 attempts、租户合计、完整性。
- summary.json：环境、总资源/运行摘要与未完成的外部双评。
- databases/：真实运行库与备份；ledger.sqlite 对应主业务四表中的首次输入，replay.sqlite 保存第二遍。
- legacy/：旧服务原始行为、首次库、三次重启累计库、失败重试库和按原行号推导的归因。
- generated-inputs/：从原始数据分片/排序/唯一化形成的演练输入，不是预写答案。
- rollout/observations.json：实际客户端通过 active.json 切换与恢复的状态。
- source-timeline.csv/input-audit.json/impact.csv：时间含义、原始行号、各租户影响。
- monitoring.json：真实 monitor 命令产生的 warning、critical 与 healthy。

故障退出 73/74 是隔离 worker 的预定崩溃点，monitor 退出 2 是可执行告警；其他命令应为 0。
独立评审未由执行者代签；阅读报告和真实库后由外部评估者完成。
