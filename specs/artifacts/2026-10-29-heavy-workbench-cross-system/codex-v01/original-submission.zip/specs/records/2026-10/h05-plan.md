# H05 事故修复方案（实施前）

## Recall

用户要求独立完成隔离支付汇总事故：业务身份是 (tenant,event_id)，整数最小货币单位，全部三租户保留，提供真实服务、事故报告、四表、四张 diagnostics 表、恢复上线手册、验证证据和 `python reproduce.py --inputs INPUT --output NEW_OUTPUT`。不得访问网络、外部模型、凭据、其他运行或源码；不得再次委托。原始服务保持作为证据。提交本地 Git，不 push。双人独立审查由后续外部评估者执行，本执行者不得代签。

已完整读取 TASK.md、task.json、inputs/context.json、source-notes.md、legacy_service.py、records.csv。全项目搜索 `Service|ingest|replay|totals|seen|received_at`，当前只有旧服务的构造、ingest、replay、close 四入口，无 Web、队列、Task/Mission/Session 调度器、其他配置、package.json 或已有测试。故 UI、外部 Provider、发布平台、项目隔离调度不适用；多数据库隔离与多租户隔离要验证。

初步真实命令：系统 Python 3.14.2；导入 inputs/legacy_service.py，在项目内临时 SQLite 数据库运行原序重放、同进程重放、close 后重开再重放，退出码 0。结果首次 alpha=21234、beta=15755、gamma=15691；同进程第二次不变；重启后依次 42468、31510、31382。后续 reproduce 将重新保存完整机器证据，临时探索不作为最终验收替代。

原始计算：823 次传输、720 个联合身份、103 个重复身份且每个多一次，alpha/beta/gamma 分别 275/274/274 次；每租户 240 身份、52680 单位，合计 158040。received_at 范围 2026-10-01T00:00:00Z 至 03:59:00Z，文件相邻时间倒退 410 次。事件业务时间、旧生产处理时间、事故发现时间均未知。context clock 只是模拟资料时钟。

## 问题深度与影响面

1. 可观察现象：旧服务首次合计仅正确金额的 1/3，跨租户漏记；重启重放持续重复累计。
2. 直接触发：legacy_service.py:17 只查询 event_id；:19 在 SQL（Structured Query Language，结构化查询语言）提交前把它写入内存 seen；:14 每次构造清空集合；:22 对持久 totals 做无身份累加。
3. 数据流根因：真实联合身份被压成全局身份，三个租户互相竞争；持久 totals 与易失 seen 无共同提交点。SQLite 事务仅保护 totals，无法保护进程内集合。成功后重启丢 seen 导致重加；seen 添加后写失败可能漏计；并发不同进程集合独立，可重复加。后两项先按代码推断，必须用独立数据库注入与多进程运行证实，不能冒称生产观测。
4. 旧路径未根治：同进程重放不变只说明集合还在；按接收时间排序会改变抢占租户，不能恢复被压缩身份。先加 seen 再提交事务仍有断点；仅把 seen 加租户也未解决持久性。
5. 定义/调用契约：保留 Service.ingest/replay/close 的自然入口；所有命令、重启、并发、迁移均调用同一 ingest。扩展结构化状态、导出、对账、备份和明确错误。最终金额只从持久 ledger 聚合视图计算，不保留另一份累计源。
6. 数据升级：旧数据库只有 totals，无法从它恢复身份。自动迁移命令必须用完整原始 archive 新建 v1 ledger，保留旧数据库完整备份及新旧差异，严禁把旧 totals 加到新账。目标库存在则返回明确错误以防覆盖。输入重复载荷金额相同；冲突金额的额外验证返回 AMOUNT_CONFLICT 并保持原交易。
7. 文档/交付：根目录四业务表从已运行服务导出；diagnostics 只是其对应计算；incident 区分输入事实、代码推断、演练观察、未知；runbook 提供执行命令、负责人角色、停止条件与恢复口径。
8. 风险：SQLite 本机多进程写入串行；未证明远程磁盘/真实断电/真实支付金额/外部资金结算。源档案完整性未知；重复率受重放影响，要区分 lifetime 与导入批次。所有未验证边界明确写入报告。

## 实施设计

- SQLite v1 ledger 主键 (tenant,event_id)，保存 amount、attempts、最早/最晚收到时间和首次处理时间。BEGIN IMMEDIATE 序列化读写；新业务插入、重复 attempt 更新在一个事务。totals 是 ledger SUM 视图，因此联合身份与其金额同时可见、同时恢复。事务失败完整 rollback。金额冲突返回明确错误类型。
- 使用 DELETE journal 与 synchronous=FULL，busy_timeout=30000；常规 SQLite 提交、备份 API（Application Programming Interface，应用程序接口），无需新依赖。
- 指标政策文件集中定义重复率 warning、对账金额/身份差异 critical、冲突 critical。monitor 命令输出逐租户金额与身份差异，退出码可执行。完整原始档案对账检测缺失、额外和金额错误；不能只比合计。
- reproduce 是真实命令编排器，保存 argv、cwd、起止 UTC、stdout/stderr、退出码。独立 reference 从 CSV 联合身份构建，禁止读取旧交付；逐身份、逐租户和 attempts 检查实际 SQLite 状态。
- 在本项目生成原始 legacy 单次/同进程/重启/多进程与写入失败证据；修复覆盖全量两遍、真实进程重启、中断前/提交后 crash、多进程竞争、反序/时间序、跨数据库隔离、冲突、legacy 自动重建与备份恢复。
- 切换演练以单个 active.json 文件原子替换数据库指针。写入暂停后备份正确 candidate，切换只读/写到新库；回滚服务版本/数据快照时将切换后档案重放到备份再启用，逐身份核对同一事实。禁止回滚到缺陷旧代码；旧 totals 仅用于审计。

## 验收与剩余工作

依序实现服务、测试/演练 worker、reproduce；运行本地单元/契约测试和全套真实演练；人工查看报告/表格；再用全新输出目录清洁复跑并对比业务四表，逐身份核对。保存运行证据、版本信息、责任表。末尾更新本方案真实结果，检查 Git 差异，提交全部本任务文件。外部双评留待独立评估者，不伪称完成。

## 实施结果与恢复 Recall

实现完成：service.py v1.0.0 使用联合主键 ledger 及 totals 视图，显式 journal_mode=DELETE/synchronous=FULL；6项正向契约测试；exercise_worker.py 仅在隔离库注入真实退出/写失败；reproduce.py 从原始 inputs 重建，不读取旧结果；verify_delivery.py 独立从原始 CSV 计算并检查业务四表、diagnostics、实际持久库和本地文档链接。所有输入原文件保持不变，没有创建分支、访问外网/凭据或再次委托。

第一轮：`python reproduce.py --inputs <本项目>/inputs --output <本项目>/delivery-build`，退出0。完整业务文件按要求放回项目根路径。证据在 verification/：38个真实子命令全部符合预期退出码（34个0、2个monitor告警2、1个崩溃73、1个崩溃74）；26项真实集成核对通过；6个非UI单元契约通过。初轮墙钟约65秒，数据库文件合计1400832字节；CPU（Central Processing Unit，中央处理器）与内存未单独采样，不能推算它们的用量。

第二轮：同一命令，输出全新 `<本项目>/clean-reproduction`，退出0；同样38命令、26核对、6单元通过。其全部原始验证证据另外保留于 verification/clean-run/，顶层标准输出在 verification/clean-run-transcript.txt。未读取第一轮业务表或数据库。外部两人独立审查未执行，仍为明确待办。

独立交付检查：`python verify_delivery.py --inputs <本项目>/inputs --output <本项目> --comparison <本项目>/clean-reproduction` 退出0，详细结果 verification/final-validation.json；对第二轮单独运行检查退出0，结果 verification/clean-validation.json。检查实际五个数据库的逐身份金额和attempts，全部业务四表、诊断四表和复跑值一致；不使用源码哈希或自算摘要门槛。

实测终态：三租户各240个联合身份/52680单位，总720/158040；原始传输823，重复身份103、额外传输103；二次重放1646总尝试、四进程并发3292总尝试，金额均158040。两个崩溃点分别恢复0/0与1/232，重投后恢复完整账本。切换后接收后缀，恢复快照并追平后保留全部720身份与原始823次尝试。原v0库完整备份并重建到v1，初始差额三租户31446/36925/36989。

人工复核：阅读生成的 incident.md 和 runbook.md，查看根目录 totals/replay 与原始金额、行号和库状态一致；发现并修正文档指针切换命令为 os.replace，与真实演练一致；澄清存储配置是显式设置。此为执行者复核，不是独立评审。新版本本地变更记录见 CHANGELOG.md，没有发布或推送行为。

剩余限制：外部独立双评待主流程；真实资金、断电/远程文件系统、真实生产负载及档案范围外完整性未验证。最终需本地Git提交；本项目无远端，按委托不push。恢复上下文时先读本Recall结果和verification/summary.json，不重跑已经通过且未受影响的用例。
