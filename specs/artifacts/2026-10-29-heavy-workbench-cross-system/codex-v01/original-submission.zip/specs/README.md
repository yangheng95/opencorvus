# 本项目规格

- [H05 实施与验收方案](records/2026-10/h05-plan.md)
- [2026-10 记录索引](records/2026-10/README.md)

本隔离输入项目没有 package.json 或文档检查器；文档链接由本项目的验证脚本核验。
