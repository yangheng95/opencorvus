import fs from 'node:fs'
const values=[]
const collect=value=>{if(!value||typeof value!=='object')return;for(const [key,item] of Object.entries(value)){if(item&&typeof item==='object')collect(item);else if(typeof item==='string'&&item.length>16&&/token|access|refresh|account_?id|key|secret/i.test(key))values.push(item)}}
for(const source of ['C:/Users/hengu/.codex/auth.json','C:/Users/hengu/AppData/Local/opencorvus/data/auth.json'])collect(JSON.parse(fs.readFileSync(source,'utf8')))
const entries=fs.readFileSync('C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/member-live-rendering-412-fresh/runtime/log/dev.log','utf8').split('\n').filter(Boolean).flatMap(line=>{try{return [JSON.parse(line)]}catch{return []}}).filter(entry=>Date.parse(entry.time)>=Date.parse('2026-10-19T13:55:30Z'))
let text=JSON.stringify(entries.filter(entry=>entry.data?.diagnosticID||entry.message==='request failed').slice(-14).map(({time,message,data})=>({time,message,id:data.diagnosticID,diagnostic:data.diagnosticMessage||data.message,path:data.path,status:data.statusCode})),null,2)
for(const value of values)text=text.replaceAll(value,'[redacted]')
if(process.argv.includes('--save'))fs.writeFileSync(import.meta.dirname+'/task-poison-facts.json',text,{flag:'wx'})
console.log(text)
