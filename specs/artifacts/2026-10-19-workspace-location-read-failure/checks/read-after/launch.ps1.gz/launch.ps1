$ErrorActionPreference='Stop'
$taskRun='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/member-live-rendering-412-fresh'
$taskDiag='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-19/workspace-location-read-failure-432-read-after'
$taskBun='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-19/workspace-location-read-failure-432-read-after-bundle/bin/bun.exe'
$taskWrapper='D:/myhexin-local/opencorvus/.tmp-product-iteration/live-sol-task-guidance-413.ts'
if(Test-Path -LiteralPath $taskDiag){throw 'Fresh diagnostic occurrence already exists'}
foreach($taskMember in @('auth.json','models.json')){if(Test-Path -LiteralPath ("$taskRun/runtime/data/"+$taskMember)){throw 'History reader expects the already-retired provider pair'}}
if(!(Test-Path -LiteralPath "$taskRun/runtime/data/opencorvus.db")){throw 'Existing 412 v1 database required'}
if(@(Get-NetTCPConnection -State Listen -LocalPort 18609 -ErrorAction SilentlyContinue).Count){throw 'Reader port occupied'}
if(!(Test-Path -LiteralPath ((Split-Path -Parent $taskBun)+'/ui/index.html'))){throw 'Owned UI bundle is incomplete'}
New-Item -ItemType Directory -Path "$taskDiag/evidence" -Force | Out-Null
$taskOccurrence='workspace-location-read-failure-432-read-after-'+[Guid]::NewGuid().ToString()
$taskDeadline=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()+600000
$taskOriginal=@{}
Get-ChildItem Env: | ForEach-Object {$taskOriginal[$_.Name]=$_.Value}
$taskEnvironment=@{}
foreach($taskName in @('PATH','SystemRoot','WINDIR','ComSpec','PATHEXT','LANG','LC_ALL','LC_CTYPE')){if($taskOriginal.ContainsKey($taskName)){$taskEnvironment[$taskName]=$taskOriginal[$taskName]}}
$taskEnvironment.OPENCORVUS_HOME="$taskRun/runtime"
$taskEnvironment.USERPROFILE="$taskRun/home"
$taskEnvironment.HOMEDRIVE='C:'
$taskEnvironment.HOMEPATH=([IO.Path]::GetFullPath("$taskRun/home")).Substring(2)
$taskEnvironment.APPDATA="$taskRun/appdata"
$taskEnvironment.LOCALAPPDATA="$taskRun/localappdata"
$taskEnvironment.OPENCORVUS_DISABLE_EXTERNAL_SKILLS='1'
$taskEnvironment.OPENCORVUS_DISABLE_AUTOUPDATE='1'
$taskEnvironment.OPENCORVUS_TASK_PROCESS_MODE='native'
$taskEnvironment.TEMP="$taskRun/runtime/tmp"
$taskEnvironment.TMP=$taskEnvironment.TEMP
$taskEnvironment.TMPDIR=$taskEnvironment.TEMP
try{
 Get-ChildItem Env: | ForEach-Object {[Environment]::SetEnvironmentVariable($_.Name,$null,'Process')}
 foreach($taskName in $taskEnvironment.Keys){[Environment]::SetEnvironmentVariable($taskName,$taskEnvironment[$taskName],'Process')}
 & $taskBun $taskWrapper --owned-host "$taskDiag/evidence" $taskOccurrence ([string]$taskDeadline) $taskBun "D:/myhexin-local/opencorvus/packages/opencorvus/src/index.ts" serve --hostname 127.0.0.1 --port "18609" --project-dir "$taskRun/project" --startup-receipt "$taskDiag/startup.json" --startup-occurrence $taskOccurrence --log-level INFO
 $taskExit=$LASTEXITCODE
 & 'D:/myhexin-local/opencorvus/.tmp-product-iteration/workspace-location-read-failure-432/read-after/settle.ps1' -DiagnosticRoot $taskDiag
}finally{
 Get-ChildItem Env: | ForEach-Object {[Environment]::SetEnvironmentVariable($_.Name,$null,'Process')}
 foreach($taskName in $taskOriginal.Keys){[Environment]::SetEnvironmentVariable($taskName,$taskOriginal[$taskName],'Process')}
}
@{childExitCode=$taskExit;observedAtUtc=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content -LiteralPath "$taskDiag/evidence/launcher-child-exit.json"
exit $taskExit






