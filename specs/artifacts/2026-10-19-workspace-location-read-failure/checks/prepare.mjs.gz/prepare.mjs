import fs from 'node:fs'
const phase=process.argv[2]
if(!['before','after','read-before','read-after','catalog-before','catalog-after','paired-before','paired-after','verified'].includes(phase))throw Error('Explicit phase required')
const root='.tmp-product-iteration/workspace-location-read-failure-432',tag='workspace-location-read-failure-432-'+phase,port=({before:18603,after:18605,'read-before':18607,'read-after':18609,'catalog-before':18611,'catalog-after':18613,'paired-before':18615,'paired-after':18617,verified:18619})[phase]
const base='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-19',bundle=base+'/'+tag+'-bundle/bin'
if(fs.existsSync(bundle))throw Error('Fresh publication required')
fs.mkdirSync(bundle,{recursive:true});fs.copyFileSync('.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64/bun.exe',bundle+'/bun.exe');fs.cpSync(['catalog-before','paired-before'].includes(phase)?base+'/workspace-location-read-failure-432-before-bundle/bin/ui':'packages/overlay/dist-vite',bundle+'/ui',{recursive:true})
fs.mkdirSync(root+'/'+phase,{recursive:true})
for(const name of ['launch.ps1','settle.ps1','shutdown.ps1']){
 let source=fs.readFileSync('.tmp-product-iteration/workspace-refresh-location-430/feedback/'+name,'utf8')
 source=source.replaceAll('workspace-refresh-location-430-feedback',tag).replaceAll('.tmp-product-iteration/workspace-refresh-location-430/feedback',root+'/'+phase).replaceAll('18597',String(port)).replaceAll('2026-10-15','2026-10-19')
 if(phase.startsWith('paired-')||phase==='verified')source=source.replaceAll('C:/Users/hengu/AppData/Local/opencorvus/data/auth.json',base+'/workspace-location-read-failure-432-authority/auth.json')
 if(name==='launch.ps1'&&(phase.startsWith('read-')||phase.startsWith('catalog-'))){
  const lines=source.split('\n'),index=lines.findIndex(line=>line.trim().startsWith('& $taskBun $taskWrapper --owned-host'))
  if(index<0)throw Error('Inspect actual launch entry')
  lines[index]=' & $taskBun $taskWrapper --owned-host "$taskDiag/evidence" $taskOccurrence ([string]$taskDeadline) $taskBun "D:/myhexin-local/opencorvus/packages/opencorvus/src/index.ts" serve --hostname 127.0.0.1 --port "'+port+'" --project-dir "$taskRun/project" --startup-receipt "$taskDiag/startup.json" --startup-occurrence $taskOccurrence --log-level INFO'
  source=lines.join('\n')
  if(phase.startsWith('catalog-')){
   source=source.replace(lines[index],` $taskCatalogSource='C:/Users/hengu/AppData/Local/opencorvus/data/models.json'
 $taskCatalogTarget="$taskRun/runtime/data/models.json"
 if((Get-Item -LiteralPath "$taskRun/runtime/data").Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Owned data must be physical'}
 Copy-Item -LiteralPath $taskCatalogSource -Destination $taskCatalogTarget -ErrorAction Stop
 @{staging='Complete catalog only; auth.json remains absent; no Provider request';source=$taskCatalogSource;target=$taskCatalogTarget;bytes=(Get-Item -LiteralPath $taskCatalogTarget).Length;observedAtUtc=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json|Set-Content -LiteralPath "$taskDiag/evidence/catalog-staging.json"
${lines[index]}`)
  }
 }
 fs.writeFileSync(root+'/'+phase+'/'+name,source)
}
if(phase==='before'){
 for(const file of ['services/init.ts','services/workspace-location.ts','services/connection.ts','services/task.ts','services/conversation-session.ts','main.tsx','components/App.tsx']){
  const target=root+'/original/'+file;fs.mkdirSync(target.substring(0,target.lastIndexOf('/')),{recursive:true});fs.copyFileSync('packages/overlay/src/'+file,target)
 }
 const artifact='specs/artifacts/2026-10-19-workspace-location-read-failure';fs.mkdirSync(artifact,{recursive:true});fs.writeFileSync(artifact+'/README.md','# 工作区链接读取失败证据\n\n[Recall与方案](../../records/2026-10/2026-10-19-workspace-location-read-failure.md)。仅真实页面与精确运行回执；执行后记录实际资格。\n')
 for(const [file,line] of [
  ['specs/README.md','- [工作区链接读取失败](records/2026-10/2026-10-19-workspace-location-read-failure.md)：资源读取错误与启动恢复。'],
  ['specs/records/2026-10/README.md','- [工作区链接读取失败](2026-10-19-workspace-location-read-failure.md)：真实错误、后续选择与Sources。'],
  ['specs/artifacts/README.md','- [工作区链接读取失败](2026-10-19-workspace-location-read-failure/README.md)：独立页面与物理收尾。'],
 ]){const text=fs.readFileSync(file,'utf8');if(text.includes(line))throw Error('Already indexed');fs.writeFileSync(file,text.trimEnd()+'\n\n'+line+'\n')}
}
console.log(JSON.stringify({phase,port,tag,budget:'600s / 180s inactivity / 12 streams',businessInputs:0}))
