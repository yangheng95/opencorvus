import fs from 'node:fs'
import zlib from 'node:zlib'
import path from 'node:path'
const root=import.meta.dirname,artifact='specs/artifacts/2026-10-19-workspace-location-read-failure'
fs.appendFileSync('specs/records/2026-10/2026-10-19-workspace-location-read-failure.md',`\n## 最终真实验收与边界\n\n正式verified 18619对未知Task显示原WorkspaceLocationError及Details（16/17），随后真实Mission草稿恢复且刷新保持正确owner（18/19）；真实已取消Task直接链接及刷新保留45秒原正文（20/21）。原Work历史完整显示（22），真实滚轮定位可见Source后点击README，实际第2—3行高亮（23）。切换当前界面为中文后再次访问未知Task，错误面同步中文，原错误事实保留（24）。未创建Task/Mission/消息或修改既有草稿。最终日志734条server request事件、27条完成的health 200；错误后monitor继续。本轮没有新成员流式生成，不能扩大为Rendering所有场景资格。\n\n聚焦真实SQLite/Server.App正向checker最终1 pass、5 expects（3 filtered）；官方generate、8包全新typecheck、正式Node Vite 80秒和renderer checker通过。docs:check、architecture-index、api:routes-check均exit0。schema仍2，无迁移文件修改。\n\n8个自有scope全部完成native physical/output/request结算，before预检因已过期原凭据exit1，其余7个公开shutdown200、launcher joined exit0。三个paired scope各2次实际gpt-6.1-sol流请求、HTTP200及reader EOF；无本轮业务输入。各scope auth/models已成对退休，额外私有authority两个文件也已精确删除；原Codex authority尺寸及mtime与准备前相同。归档不含凭据、DB或Provider原始body。\n\n图07只证明正文恢复，文件点击结果未资格、具体原因未知；图15虽文件名含normal，实际是中间版本被ghost Task污染后的失败页。两者保留原始失败，不计成功。未完整资格并发导航竞态、所有归档链接及新成员Rendering。用户最新指出Goal难发现及默认页布局异常，下一批单独调查入口、owner合同和实际首页视觉；本批不把导航修复宣称已解决该产品诉求。\n`)
fs.writeFileSync(artifact+'/README.md',`# 工作区定位失败与恢复证据（2026-10-19）\n\n对应[调查记录](../../records/2026-10/2026-10-19-workspace-location-read-failure.md)。生产入口独立端口18603、18607—18619，正式开发服务/ui；未操作用户18571页面。\n\n| 图 | 人工观察及资格 |\n|---|---|\n|01—03|无Provider环境；Work原历史/404空首页，Mission实际400模型不可用|\n|04|仅目录环境Mission仍400，不能作404证据|\n|05—06|中间修复Work404摘要和原Details|\n|07|仅正文恢复，文件未打开；原因未知|\n|08|完整凭据及模型环境，原Mission404空首页|\n|09—11|Mission404摘要、Details及真实中文设置|\n|12—13|中间版本原Source文件2—3行及正常取消Task|\n|14—15|中间未知Task错误及其污染后的Mission失败；15文件名normal不代表成功|\n|16—17|最终未知Task拒绝和WorkspaceLocationError原详情|\n|18—19|最终正常Mission原草稿及刷新|\n|20—21|最终正常Task直接链接及刷新|\n|22—23|最终Work历史及README2—3行高亮|\n|24|最终中文未知Task错误面|\n\nchecks/为脚本、原源码、构建/检查日志和只读请求事实的gzip副本；runtime/为8个scope物理结算、公开shutdown和成对清理回执。三个paired scope的Provider摘要仅保存model/streaming/status/response_reader（各2次真实gpt-6.1-sol流请求，reader EOF），不保存完整请求body、凭据或数据库。没有UI自动化测试；截图均由真实页面交互后人工查看。当前版本没有新成员流式生成资格，也未完成Goal/default页改版。\n`)
for(const name of ['docs-check.log','architecture-check.log','routes-check.log','finish.mjs'])fs.writeFileSync(artifact+'/checks/'+name+'.gz',zlib.gzipSync(fs.readFileSync(root+'/'+name)))
const walk=dir=>fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(dir,e.name)):[path.join(dir,e.name)])
const values=[]
function collect(obj){for(const [key,value] of Object.entries(obj)){if(value&&typeof value==='object')collect(value);else if(typeof value==='string'&&value.length>16&&/access|refresh|token|key|secret|password|account/i.test(key))values.push(value)}}
for(const file of ['C:/Users/hengu/.codex/auth.json','C:/Users/hengu/AppData/Local/opencorvus/data/auth.json'])collect(JSON.parse(fs.readFileSync(file,'utf8')))
if(!values.length)throw Error('Actual credential material required for memory-only disclosure review')
for(const file of walk(artifact)){
 if(file.endsWith('.jpg'))continue
 const bytes=fs.readFileSync(file),body=(file.endsWith('.gz')?zlib.gunzipSync(bytes):bytes).toString('utf8')
 for(const value of values)if(body.includes(value))throw Error('Credential disclosure: '+file)
}
console.log(JSON.stringify({artifactFiles:walk(artifact).length,disclosureReview:'passed',screenshots:24,scopes:8}))
