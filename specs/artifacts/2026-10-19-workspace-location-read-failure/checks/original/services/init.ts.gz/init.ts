// ── Init Service ──
// Application startup sequence:
// - Load overlay settings from the active host persistence source
// - Load i18n locale data
// - Configure the API client
// - Check server connection
// - Load initial board / tasks / meta / config
// - Restore last workspace
// - Set up a periodic reconnect loop

import {
  configure as configureApi,
  onApiError,
  captureApiAuthority,
  isApiAuthorityCurrent,
  type ApiAuthority,
} from "./api"
import { refreshConnectionWorkspace } from "./connection-projection"
import { checkConnection as checkServerConnection, startConnectionMonitor, stopConnectionMonitor } from "./connection"
import { startWorkLedgerSSE, stopSSE, stopWorkLedgerSSE } from "./sse"
import { loadAllLocales, setLocale, t } from "../utils/i18n"
import {
  loadSettings,
  settingsStore,
  setSettingsStore,
  saveSettings,
  bumpDirectoryEpoch,
  bumpWorkspaceEpoch,
} from "../store/settings"
import { boardStore, setBoardStore, loadTasks, clearTasksForMissingDirectory, activeTaskID } from "../store/board"
import { loadMeta } from "./meta"
import { loadExtensions } from "./extensions"
import {
  activeDirectory,
  ensureDefaultDirectory,
  ensureWorkspaceDirectory,
  isMissingProjectDirectoryError,
  leaveUnavailableProject,
  beginWorkspaceSelection,
} from "./workspace"
import { workspaceRestoreDirectory } from "../store/settings"
import { selectTask } from "./task"
import { workspaceLocationFromSearch, WorkspaceLocationError, type ClientWorkspaceLocation, type WorkspaceLocation } from "./workspace-location"
import { reportError, formatErrorDetails } from "./diagnostics"
import { CONFIG_INFO_LOAD_TIMEOUT_MILLISECONDS, loadConfigInfo } from "./config-load"
import { setAppStore, type ProjectLoadIssue } from "../store/app"
import { AppLog } from "../utils/log"
import { refreshProjectMemory } from "./project-memory"
import { restoreDraftComposerModel } from "./composer-model"

// ── Types ──

export interface InitOptions {
  /** Restore a Session or launcher through its explicit UI navigation lifecycle. */
  restoreClientLocation?: (location: ClientWorkspaceLocation, authority: ApiAuthority) => Promise<void>
  /**
   * Called once the initial connection check succeeds so the caller can
   * trigger any render-side updates that depend on live data.
   */
  onConnected?: () => void | Promise<void>
  /**
   * Called after settings are loaded into settingsStore, before API, locale,
   * connection, and data initialization continue.
   */
  onSettingsLoaded?: () => void | Promise<void>
  /**
   * Called on every successful reconnect (after an offline period).
   */
  onReconnect?: () => void | Promise<void>
  /**
   * Reconnect poll interval in ms. Defaults to 10 000 (10 s).
   */
  reconnectInterval?: number
}

let initLifecycleGeneration = 0
let stopMissingProjectDirectoryRecovery: (() => void) | undefined

function isCurrentInitLifecycle(generation: number): boolean {
  return generation === initLifecycleGeneration
}

function startMissingProjectDirectoryRecovery(): void {
  stopMissingProjectDirectoryRecovery?.()
  stopMissingProjectDirectoryRecovery = onApiError((error) => {
    const directory = [activeDirectory(), settingsStore.directory]
      .map((candidate) => candidate.trim())
      .find((candidate) => candidate && isMissingProjectDirectoryError(error, candidate))
    if (!directory) return
    void recoverMissingActiveDirectory(error, directory).catch((recoveryError) => {
      AppLog.error("project-load", "Failed to leave unavailable Project", {
        directory,
        error: recoveryError instanceof Error ? recoveryError.message : String(recoveryError),
      })
    })
  })
}

/**
 * Push current settings into the API client so subsequent fetch calls use
 * the correct server URL and credentials.
 * Push current settings into the API client.
 */
function syncApiConfig(): void {
  configureApi({
    serverUrl: settingsStore.serverUrl,
    username: settingsStore.username,
    password: settingsStore.password,
    directory: settingsStore.directory,
  })
}

/**
 * Load all initial data that requires a live server connection.
 * Load all initial data in parallel after connection is established.
 */
interface InitialDataResult {
  loaded: boolean
  reconcileCapabilities?: () => Promise<void>
}

async function recoverMissingActiveDirectory(error: unknown, directory: string): Promise<boolean> {
  if (!isMissingProjectDirectoryError(error, directory)) return false
  AppLog.warn("project-load", "Active Project directory disappeared; entering directory-free workspace", {
    directory,
  })
  await leaveUnavailableProject(directory)
  return true
}

async function loadInitialData(
  lifecycleGeneration: number,
  resolveInitialDirectory: () => Promise<boolean>,
): Promise<InitialDataResult> {
  const authority = captureApiAuthority()
  const workspaceEpoch = settingsStore.workspaceEpoch
  const owns = () =>
    isCurrentInitLifecycle(lifecycleGeneration) &&
    isApiAuthorityCurrent(authority) &&
    settingsStore.workspaceEpoch === workspaceEpoch
  if (workspaceEpoch === 0) await resolveInitialDirectory()
  if (!owns()) return { loaded: false }
  const directory = await ensureWorkspaceDirectory()
  if (!owns()) return { loaded: false }
  syncApiConfig()
  if (!directory) {
    clearTasksForMissingDirectory()
    setBoardStore({
      board: null,
      path: null,
      vcs: null,
      vcsDirectory: "",
      vcsLoading: false,
      vcsError: "",
      changes: [],
    })
    return { loaded: false }
  }
  // Opening a client observes its directory. Git initialization is an explicit
  // operator action and may change identity while another client owns work.
  const [tasksResult, metaResult] = await Promise.allSettled([loadTasks({ authority }), loadMeta(directory, authority)])
  if (!owns()) return { loaded: false }
  const unavailableDirectoryFailure = [tasksResult, metaResult].find(
    (result): result is PromiseRejectedResult =>
      result.status === "rejected" && isMissingProjectDirectoryError(result.reason, directory),
  )
  if (
    unavailableDirectoryFailure &&
    (await recoverMissingActiveDirectory(unavailableDirectoryFailure.reason, directory))
  ) {
    return { loaded: false }
  }
  void refreshProjectMemory({ authority, directory }).catch((error) => {
    if (owns()) AppLog.warn("project-memory", "Project MEMORY.MD status refresh failed", { error: String(error) })
  })
  if (settingsStore.directory.trim() !== directory) return { loaded: false }
  const issues: ProjectLoadIssue[] = []
  const appendFailure = (resource: ProjectLoadIssue["resource"], result: PromiseSettledResult<unknown>) => {
    if (result.status === "rejected") {
      issues.push({
        resource,
        message: result.reason instanceof Error ? result.reason.message : String(result.reason),
      })
    }
  }
  appendFailure("tasks", tasksResult)
  appendFailure("meta", metaResult)
  setAppStore("projectLoadIssues", issues)
  for (const issue of issues) {
    AppLog.error("project-load", `${issue.resource} load failed`, { directory, error: issue.message })
  }

  // Conversation readiness is owned by the Task list and metadata above.
  // Extension/config projections start only after restoration, then reconcile
  // their own stores independently; a slow package scan must not delay the
  // selected conversation.
  const reconcileCapabilities = async () => {
    const [extensionsResult, configResult] = await Promise.allSettled([
      loadExtensions({
        authority,
        directory,
        isCurrentDirectory: (candidate) => settingsStore.directory.trim() === candidate,
      }),
      loadConfigInfo(CONFIG_INFO_LOAD_TIMEOUT_MILLISECONDS, { authority }),
    ])
    if (!owns() || settingsStore.directory.trim() !== directory) return
    const capabilityIssues: ProjectLoadIssue[] = []
    const appendCapabilityFailure = (resource: ProjectLoadIssue["resource"], result: PromiseSettledResult<unknown>) => {
      if (result.status !== "rejected") return
      capabilityIssues.push({
        resource,
        message: result.reason instanceof Error ? result.reason.message : String(result.reason),
      })
    }
    appendCapabilityFailure("extensions", extensionsResult)
    appendCapabilityFailure("config", configResult)
    if (extensionsResult.status === "fulfilled") {
      capabilityIssues.push(
        ...extensionsResult.value.issues.map((issue) => ({
          resource: "extensions" as const,
          message: `${issue.resource}: ${issue.message}`,
        })),
      )
    }
    if (configResult.status === "fulfilled") {
      capabilityIssues.push(
        ...configResult.value.map((issue) => ({
          resource: "config" as const,
          message: `${issue.resource}: ${issue.message}`,
        })),
      )
    }
    const reconciled = [...issues, ...capabilityIssues]
    setAppStore("projectLoadIssues", reconciled)
    for (const issue of capabilityIssues) {
      AppLog.error("project-load", `${issue.resource} load failed`, { directory, error: issue.message })
    }
  }
  return { loaded: true, reconcileCapabilities }
}

// ── Public API ──

/**
 * Initialise the Solid overlay layer.
 * Call order:
 * 1. Load settings from the active host persistence source
 * 2. Apply settings to API client
 * 3. Load i18n (all supported locales)
 * 4. Apply locale from settings
 * 5. Check server connection
 * 6. If connected: load board + tasks, call onConnected
 * 7. Start periodic reconnect loop
 */
export async function initApp(options: InitOptions = {}): Promise<void> {
  const { onConnected, onSettingsLoaded, onReconnect, reconnectInterval = 10_000 } = options
  const lifecycleGeneration = ++initLifecycleGeneration
  // Capture before directory initialization can clear a prior workspace projection.
  const initialSearch = typeof window === "undefined" ? "" : window.location.search
  const resolveInitialDirectory = createInitialDirectoryResolver()

  // 1. Load settings into the Solid store
  await loadSettings()
  if (!isCurrentInitLifecycle(lifecycleGeneration)) return
  restoreDraftComposerModel()
  startMissingProjectDirectoryRecovery()
  await onSettingsLoaded?.()
  if (!isCurrentInitLifecycle(lifecycleGeneration)) return

  // 2. Push settings into the API client (server URL + auth)
  syncApiConfig()

  // 3. Load i18n locale bundles
  await loadAllLocales()
  if (!isCurrentInitLifecycle(lifecycleGeneration)) return

  // 4. Apply locale from settings
  await setLocale(settingsStore.locale)
  if (!isCurrentInitLifecycle(lifecycleGeneration)) return

  let initialLocation: { kind: "valid"; location: WorkspaceLocation | null } | { kind: "invalid" }
  try {
    initialLocation = { kind: "valid", location: workspaceLocationFromSearch(initialSearch) }
  } catch (error) {
    if (!(error instanceof WorkspaceLocationError)) throw error
    initialLocation = { kind: "invalid" }
    bumpWorkspaceEpoch()
    setAppStore("workspaceLocationError", error)
    reportError({
      id: "workspace-location:restore",
      title: t("workspace.location_open_failed_title"),
      message: t("workspace.location_open_failed_message"),
      details: formatErrorDetails(error),
    })
  }

  // 5. Check connection
  let startupAuthority: ApiAuthority | undefined
  const connected = await checkServerConnection({
    onHealthy: (authority) => {
      startupAuthority = authority
      return undefined
    },
  })
  if (!isCurrentInitLifecycle(lifecycleGeneration)) return

  if (connected && startupAuthority && isApiAuthorityCurrent(startupAuthority)) {
    startWorkLedgerSSE()
    // 6. Load initial data
    const initialData = await loadInitialData(lifecycleGeneration, resolveInitialDirectory)
    if (!isCurrentInitLifecycle(lifecycleGeneration)) return
    if (initialLocation.kind === "valid" && (initialData.loaded || initialLocation.location) && isApiAuthorityCurrent(startupAuthority)) {
      await restoreInitialWorkspaceLocation({
        authority: startupAuthority,
        location: initialLocation.location,
        restoreClientLocation: options.restoreClientLocation,
      })
    }
    if (!isCurrentInitLifecycle(lifecycleGeneration)) return
    if (isApiAuthorityCurrent(startupAuthority)) {
      void initialData.reconcileCapabilities?.()
      await onConnected?.()
    }
    if (!isCurrentInitLifecycle(lifecycleGeneration)) return
  }

  if (!isCurrentInitLifecycle(lifecycleGeneration)) return

  // 7. Start reconnect loop
  stopConnectionMonitor()
  startConnectionMonitor(async () => {
    if (!isCurrentInitLifecycle(lifecycleGeneration)) return
    syncApiConfig()
    const authority = captureApiAuthority()
    startWorkLedgerSSE()
    const initialData = await loadInitialData(lifecycleGeneration, resolveInitialDirectory)
    if (!isCurrentInitLifecycle(lifecycleGeneration)) return
    if (!isApiAuthorityCurrent(authority)) return
    if (initialData.loaded) await restoreInitialWorkspace(authority)
    if (!isCurrentInitLifecycle(lifecycleGeneration)) return
    if (!isApiAuthorityCurrent(authority)) return
    await refreshConnectionWorkspace(authority)
    if (!isCurrentInitLifecycle(lifecycleGeneration)) return
    void initialData.reconcileCapabilities?.()
    await onReconnect?.()
    if (!isCurrentInitLifecycle(lifecycleGeneration)) return
  }, reconnectInterval)
}

export function createInitialDirectoryResolver(
  resolve: () => Promise<boolean> = ensureDefaultDirectory,
): () => Promise<boolean> {
  let resolution: { promise: Promise<boolean>; authority: ApiAuthority } | undefined
  return () => {
    if (resolution && isApiAuthorityCurrent(resolution.authority)) return resolution.promise
    const authority = captureApiAuthority()
    const current = resolve().catch((error) => {
      if (resolution?.promise === current) resolution = undefined
      throw error
    })
    resolution = { promise: current, authority }
    return current
  }
}

/**
 * Tear down the reconnect loop.
 * Call on final page destruction or component cleanup.
 */
export function teardownApp(): void {
  initLifecycleGeneration += 1
  stopMissingProjectDirectoryRecovery?.()
  stopMissingProjectDirectoryRecovery = undefined
  stopConnectionMonitor()
  stopSSE()
  stopWorkLedgerSSE()
}

/**
 * Persist current settings through the active host and re-apply the API client.
 * Thin wrapper so callers don't need to import from multiple modules.
 */
export function persistAndSyncSettings(): void {
  void saveSettings().catch((error) => {
    console.error("[init] persist settings failed", error)
  })
  syncApiConfig()
}

// ── Workspace restoration ──

const RESTORABLE_RUNNING_TASK_STATUSES = new Set(["active"])

function taskIDFromItem(item: any): string {
  const id = item?.task?.id ?? item?.id
  return typeof id === "string" ? id.trim() : ""
}

function taskStatusFromItem(item: any): string {
  const status = item?.task?.status ?? item?.status
  return typeof status === "string" ? status.trim() : ""
}

export function initialRestoreTaskID(
  tasks: any[],
  savedTaskID: string,
  options: { selectRunningWhenUnmatched?: boolean } = {},
): string {
  const list = Array.isArray(tasks) ? tasks : []
  const saved = typeof savedTaskID === "string" ? savedTaskID.trim() : ""
  if (saved && list.some((item: any) => taskIDFromItem(item) === saved)) {
    return saved
  }
  if (options.selectRunningWhenUnmatched === false) return ""
  const running = list.find((item: any) => RESTORABLE_RUNNING_TASK_STATUSES.has(taskStatusFromItem(item)))
  return taskIDFromItem(running)
}

export async function restoreInitialWorkspaceLocation(
  options: {
    location: WorkspaceLocation | null
    authority: ApiAuthority
    restoreClientLocation?: InitOptions["restoreClientLocation"]
  },
): Promise<boolean> {
  const { authority, location } = options
  if (!isApiAuthorityCurrent(authority)) return false
  if (location) {
    if (location.kind === "task") await selectTask(location.taskID, { selectionEpoch: beginWorkspaceSelection(), authority })
    else {
      if (!options.restoreClientLocation) throw new Error("Workspace location requires its UI navigation owner")
      await options.restoreClientLocation(location, authority)
    }
    if (!isApiAuthorityCurrent(authority)) return false
    if (location.kind === "task" && activeTaskID() !== location.taskID) return false
    if ((location.kind === "conversation" || location.kind === "mission") && boardStore.selectedSource?.id !== location.sessionID) return false
    if (location.kind === "launcher" && boardStore.selectedSource) return false
    bumpWorkspaceEpoch()
    return true
  }
  return restoreInitialWorkspace(authority)
}

/**
 * Restore the last workspace state (task selection + directory) that was
 * persisted to settings before the overlay was last closed.
 * Returns true when a task was successfully re-selected, false otherwise.
 */
export async function restoreInitialWorkspace(authority = captureApiAuthority()): Promise<boolean> {
  if (!isApiAuthorityCurrent(authority)) return false
  const { workspaceTaskID, workspaceDirectory, directory: activeDir } = settingsStore
  const tasks = boardStore.tasks

  // Skip if a workspace selection is already in progress (epoch > 0).
  if (settingsStore.workspaceEpoch > 0) return false
  if (boardStore.selectedSource?.kind === "session") return false

  const base = activeDir || ""
  const directory = workspaceRestoreDirectory(workspaceDirectory || "")
  const moved = !!directory && !!base && directory !== base

  if (moved) {
    // Reflect directory change so reactive components see the updated value.
    setSettingsStore("directory", directory)
    syncApiConfig()
    bumpDirectoryEpoch()
  }

  const taskID = initialRestoreTaskID(tasks, workspaceTaskID || "", { selectRunningWhenUnmatched: !moved })

  if (taskID) {
    if (activeTaskID() !== taskID || !boardStore.board) {
      await selectTask(taskID, { selectionEpoch: beginWorkspaceSelection(), authority })
    }
    if (!isApiAuthorityCurrent(authority)) return false
    // body.dataset.workspace/connection is updated reactively by main.tsx createEffect.
    bumpWorkspaceEpoch()
    return true
  }

  if (moved) {
    // Could not find the task — roll back the directory change.
    setSettingsStore("directory", base)
    syncApiConfig()
    bumpDirectoryEpoch()
  }

  if ((workspaceTaskID || "").trim() || boardStore.selectedSource?.kind === "task" || boardStore.board?.task) {
    await selectTask("", { selectionEpoch: beginWorkspaceSelection(), authority })
  }
  return false
}
