import fs from 'node:fs'
const phase=process.argv[2]
if(!['read-before','read-after','catalog-before','catalog-after','paired-before','paired-after','verified'].includes(phase))throw Error('Explicit phase required')
const root=import.meta.dirname,evidence=`C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-19/workspace-location-read-failure-432-${phase}/evidence`
const ready=JSON.parse(fs.readFileSync(evidence+'/native-host-ready.json','utf8'))
const end=fs.existsSync(evidence+'/native-host-settled.json')?JSON.parse(fs.readFileSync(evidence+'/native-host-settled.json','utf8')).observedAtUtc:new Date().toISOString()
const source='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14/member-live-rendering-412-fresh/runtime/log/dev.log'
const entries=fs.readFileSync(source,'utf8').split('\n').filter(Boolean).flatMap(line=>{try{return [JSON.parse(line)]}catch{return []}}).filter(entry=>Date.parse(entry.time)>=Date.parse(ready.observedAtUtc)&&Date.parse(entry.time)<=Date.parse(end))
const requests=entries.filter(entry=>entry.service==='server'&&entry.message==='request').map(({time,data})=>({time,requestID:data.requestID,method:data.method,path:data.path,status:data.status,statusCode:data.statusCode,duration:data.duration}))
const failures=entries.filter(entry=>entry.data?.diagnosticID==='workspace-location:restore'||entry.data?.diagnosticID?.startsWith('runtime:')).map(({time,service,message,data})=>({time,service,message,data}))
const target=root+'/'+phase+'/request-facts.json'
if(fs.existsSync(target))throw Error('Fresh read receipt required')
fs.writeFileSync(target,JSON.stringify({source,boundary:'Original owned server request lifecycle and selected diagnostic facts; no request body or credential; read-only observation, no UI assertion',occurrence:ready.occurrence,start:ready.observedAtUtc,end,requests,failures},null,2))
console.log(JSON.stringify({phase,requestEvents:requests.length,failures:failures.map(({time,data})=>({time,id:data.diagnosticID,message:data.diagnosticMessage||data.message})),health:requests.filter(request=>request.path==='/global/health'&&request.status==='completed')}))
