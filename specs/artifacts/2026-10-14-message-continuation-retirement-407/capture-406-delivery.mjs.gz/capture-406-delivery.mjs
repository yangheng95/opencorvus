import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import {gzipSync,gunzipSync} from 'node:zlib'
const source='.tmp-task-question-recovery-406',target='specs/artifacts/2026-10-14-execution-owner-recovery-406/after-delivery01'
fs.mkdirSync(target)
const files=[]
for(const stage of ['commit01','reconcile01','reconcile02','reconcile03','fetch-final01','merge-final01','push01','fetch-after01'])
 for(const name of ['owner-start.json','owner.json','stdout.log','stderr.log'])files.push({source:`delivery-commands/${stage}/${name}`,destination:`${stage}/${name}.gz`})
for(const name of ['final-commit.json','index-reconcile.json','reconcile-index.mjs','reconcile-index01-before-atomic.mjs','reconcile-index02-before-combined.mjs'])files.push({source:name,destination:name+'.gz'})
for(const row of files){
 const bytes=fs.readFileSync(path.join(source,row.source)),out=path.join(target,row.destination)
 fs.mkdirSync(path.dirname(out),{recursive:true});fs.writeFileSync(out,gzipSync(bytes),{flag:'wx'})
 assert(gunzipSync(fs.readFileSync(out)).equals(bytes));row.originalBytes=bytes.length;row.directBytesIdentical=true
}
fs.writeFileSync(path.join(target,'manifest.json'),JSON.stringify({capturedAt:Date.now(),files,boundary:'Exact command/source identity capture; not a functional or source-hash gate'},null,2),{flag:'wx'})
console.log(JSON.stringify({files:files.length,target}))
