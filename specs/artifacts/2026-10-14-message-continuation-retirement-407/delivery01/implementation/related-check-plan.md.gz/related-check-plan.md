# Proposed related formal check input, not executed

After the concentrated writer suite and new public route contract are green, request one normal package invocation through the unchanged copied run-formal wrapper:

```text
bun run .tmp-message-retirement-407/implementation/run-formal.ts related01 test test/permission-continuation-recovery.test.ts test/session/permission-message-recovery.test.ts test/session/tool-result-recovery.test.ts test/session/tool-result-recovery-scopes.test.ts test/session/completed-failure-write.test.ts test/session/fork-atomic-transcript.test.ts test/storage/database-transaction-contract.test.ts
```

Use the same reviewed Bun1.4 absolute executable/PATH and original 600000ms owned_tree wrapper; no special process-checker deadline variable because these are normal selected files. Every original runner/output/physical receipt must be retained. This group is justified by the changed shared Message writer and strict recovery error contract:

- Continuation recovery: current stale/superseded/terminal/unresumable, per-item fault isolation, project/liveness and full-access contracts. Existing spy-based cases are local recovery contracts, not actual provider/process acceptance.
- Permission Message recovery: same-Message peer results, exact Prompt release generations, concurrent continuations, controlled streaming follow-up and existing real peer process. Do not infer Task or Mission coverage from it.
- Tool result recovery: actual ReadTool/result/source compound writer and explicit SQLite materialization failures, source identity and convergence.
- Tool result recovery scopes: existing Task-root activation/result case; its accepted Task fixture is a local control/activation contract, not public Task completion or model end-to-end proof.
- Completed failure/import and fork atomic transcript: silent/import/copy canonical writer callers and original error/evidence identity.
- Database transaction contract: nested savepoint rollback and ordered durable effects; no new database primitive.

No package-wide bun test, UI test, new SDK generation or types/module duplicate is included. Root owns final core/module checks. If these related files expose a changed same-contract expectation, save original source/error and report the exact input/current writer contract before touching it. Unknown/lacking Mission end-to-end and retained Task natural-final coverage remain explicit; a green focused group does not fill those cells.
