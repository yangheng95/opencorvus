import { afterEach, expect, test } from "bun:test"
import fs from "node:fs/promises"
import path from "node:path"
import { Config } from "../../src/config/config"
import { Identifier } from "../../src/id/id"
import { PermissionAuthority } from "../../src/permission/authority"
import { PermissionLedgerTable, PermissionExecutionResultTable } from "../../src/permission/permission.sql"
import { Instance } from "../../src/project/instance"
import { Server } from "../../src/server/server"
import { Session } from "../../src/session"
import { MessageStore } from "../../src/session/message-store"
import { SessionLoop } from "../../src/session/loop"
import { Database, asc, eq, sql } from "../../src/storage/db"
import { completedReadResult, resultRecoveryModel } from "../fixture/completed-read-result"
import { memoryProject, resetMemoryDatabase } from "../fixture/memory"
import { startControlledStreamingProvider } from "../fixture/controlled-streaming-provider"
import { BusPublicationOutboxTable } from "../../src/bus/bus.sql"
import { withTimeout } from "../../src/util/await-with-timeout"
import { SessionPrompt } from "../../src/session/prompt"
import { createExecutionCancellationOrigin } from "../../src/session/prompt/cancellation"
import { currentRuntimeProcessOccurrence } from "../../src/runtime/process-occurrence"
import { Log } from "../../src/util/log"

afterEach(async () => { await Instance.disposeAll(); await resetMemoryDatabase() })

test("a public no-waiter reply reports real retirement failure after its durable operator decision", async () => {
  const startedAt = Date.now(), originalDeadline = startedAt + 90000, closeBy = originalDeadline - 15000
  const root = process.env.OPENCORVUS_TEST_PROCESS_ROOT
  if (!root) throw Error("Formal isolated test process required")
  const external = process.env.OPENCORVUS_PERMISSION_RETIREMENT_EVIDENCE
  if (external && !path.isAbsolute(external)) throw Error("Explicit absolute evidence root required")
  const evidence = external ?? path.join(root, "permission-retirement-reply")
  await fs.mkdir(evidence, { recursive: false })
  const facts: Record<string, unknown> = { startedAt, originalDeadline, closeBy, pid: process.pid,
    occurrence: currentRuntimeProcessOccurrence(), evidence,
    providerCreated: false, providerClosed: "not_started", providerResponsesJoined: "not_started",
    listenerCreated: false, listenerClosed: "not_started", instanceCreated: false, instanceClosed: "not_started",
    originalExecutionStarted: false, originalExecutionJoined: "not_started",
    continuationStarted: false, continuationJoined: "not_started" }
  const write = (name: string, value: unknown) => fs.writeFile(path.join(evidence, name), JSON.stringify(value, null, 2))
  await write("scope-start.json", facts)
  const within = <T>(operation: Promise<T>, label: string, closing = false) =>
    withTimeout(operation, Math.max(1, (closing ? originalDeadline : closeBy) - Date.now()), label)
  await using project = await memoryProject()
  const source = path.join(path.dirname(project.path), `public-retirement-${Identifier.ascending("part")}.csv`)
  const provider = startControlledStreamingProvider()
  facts.providerCreated = true
  facts.providerClosed = false
  facts.providerURL = provider.apiURL
  const requests: Array<{ route: string; status: number; requestID: string | null; body: unknown }> = []
  let server: ReturnType<typeof Server.listen> | undefined
  let execution: Promise<unknown> | undefined
  let triggerInstalled = false
  let primaryError: unknown
  let originalRequest: PermissionAuthority.Request | undefined
  let continuation: Promise<unknown> | undefined
  const signal = () => AbortSignal.timeout(Math.max(1, Math.min(30000, originalDeadline - Date.now())))
  const release = setInterval(() => { for (const request of provider.requests) request.release() }, 5)
  async function captureFacts(name: string) {
    if (!originalRequest) return write(name, { request: null, state: "not_started" })
    const request = originalRequest
    const ledger = Database.use(db => db.select().from(PermissionLedgerTable)
      .where(eq(PermissionLedgerTable.request_id, request.id)).orderBy(asc(sql`rowid`)).all())
    const results = Database.use(db => ledger.filter(row => row.event_type === "execution_started")
      .map(row => db.select().from(PermissionExecutionResultTable)
        .where(eq(PermissionExecutionResultTable.attempt_id, row.attempt_id!)).get() ?? null))
    const outbox = Database.use(db => db.select().from(BusPublicationOutboxTable).where(sql`
      json_extract(${BusPublicationOutboxTable.properties}, '$.requestID') = ${request.id}
      OR json_extract(${BusPublicationOutboxTable.properties}, '$.info.id') = ${request.messageID}
      OR json_extract(${BusPublicationOutboxTable.properties}, '$.part.messageID') = ${request.messageID}
    `).orderBy(asc(BusPublicationOutboxTable.occurrence_id)).all())
    const message = await MessageStore.get({ sessionID: request.sessionID, messageID: request.messageID })
    await write(name, { observedAt: Date.now(), request, ledger, message, results, outbox })
  }
  async function captureLog(name: string) {
    await Log.flush()
    await fs.writeFile(path.join(evidence, name), await fs.readFile(Log.file()))
  }
  async function api(route: string, body?: unknown) {
    if (Date.now() >= originalDeadline - 15000) throw Error("Original route contract close reserve reached")
    const response = await fetch(new URL(route, server!.url), { method: body === undefined ? "GET" : "POST",
      headers: { "content-type": "application/json", "x-opencorvus-directory": project.path },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }), signal: signal(),
    })
    const result = { route, status: response.status, requestID: response.headers.get("x-opencorvus-request-id"), body: await response.json() }
    requests.push(result)
    await write("http-receipts.json", requests)
    return result
  }
  try {
    await within(fs.writeFile(source, "item,quantity\nMaple,3\nIris,4\n"), "Owned public source setup")
    await within(Config.updateGlobalPatch({
      model: `${resultRecoveryModel.providerID}/${resultRecoveryModel.id}`,
      small_model: `${resultRecoveryModel.providerID}/${resultRecoveryModel.id}`,
      permission_mode: "ask", prompt_profile: { active: "base" },
      enabled_providers: [resultRecoveryModel.providerID],
      mcp: { browser: { enabled: false }, computer: { enabled: false } },
      provider: { [resultRecoveryModel.providerID]: { name: "Public retirement contract", npm: "@ai-sdk/openai-compatible",
        api: provider.apiURL, options: { apiKey: "local-controlled-provider" }, models: {
          [resultRecoveryModel.id]: { name: "Public retirement contract", tool_call: true,
            modalities: { input: ["text"], output: ["text"] }, limit: { context: 1000000, output: 4096 } },
        },
      } },
    }), "Public controlled model projection")
    const accepted = Promise.withResolvers<PermissionAuthority.Request>()
    originalRequest = await within(Instance.provide({ directory: project.path, fn: async () => {
      facts.instanceCreated = true
      facts.instanceClosed = false
      execution = completedReadResult({ mode: "ask", filePath: source, approve: async request => {
        accepted.resolve(request)
      } }).catch(error => error)
      facts.originalExecutionStarted = true
      facts.originalExecutionJoined = false
      return await withTimeout(accepted.promise, Math.min(30000, originalDeadline - Date.now() - 15000), "Actual pending read")
    } }), "Preparing the actual original read")
    if (!originalRequest) throw Error("Actual pending permission required")
    const request = originalRequest
    // Same normal lifecycle as permission-transport-hydration: the original
    // execution is observed, the Instance lease has returned, and no private map is touched.
    await within(Instance.disposeAll(), "Original Instance disposal")
    const paused = await within(execution!, "Original paused execution")
    facts.originalExecutionJoined = true
    await write("original-pause.json", { name: paused instanceof Error ? paused.name : typeof paused, value: String(paused) })
    await captureFacts("after-original-disposal.json")
    expect(paused).toBeInstanceOf(PermissionAuthority.PermissionPausedError)
    server = Server.listen({ hostname: "127.0.0.1", port: 0, randomPort: true })
    facts.listenerCreated = true
    facts.listenerClosed = false
    facts.listenerURL = server.url.toString()
    facts.listenerCreatedAt = Date.now()
    const pending = await api("/permission")
    await captureFacts("before-pending-assertion.json")
    expect(pending.status).toBe(200)
    expect(pending.body).toEqual([request])
    await within(Instance.provide({ directory: project.path, fn: async () => {
      const original = await MessageStore.get({ sessionID: request.sessionID, messageID: request.messageID })
      await captureFacts("before-tool-assertion.json")
      expect(structuredClone(original.parts.find(part => part.type === "tool" && part.callID === request.toolCallID)))
        .toMatchObject({ type: "tool", state: { status: "running" } })
      Database.use(db => db.run(sql.raw(`CREATE TEMP TRIGGER public_retirement_cut BEFORE INSERT ON permission_ledger
        WHEN NEW.request_id = '${request.id}' AND NEW.event_type = 'stale'
        BEGIN SELECT RAISE(ABORT, 'PUBLIC_MESSAGE_RETIREMENT_COMMIT_CUT'); END`)))
      triggerInstalled = true
    } }), "Observe original Tool and install exact SQLite fault")
    const reply = await api(`/permission/${request.id}/reply`, { decision: "allow_once", message: "Read this public CSV once." })
    await within(captureLog("server-log-after-reply.jsonl"), "Preserve actual reply error log")
    await within(captureFacts("after-reply-before-assertions.json"), "Preserve actual reply canonical facts")
    expect(reply.status).toBe(500)
    expect(reply.requestID).toEqual(expect.any(String))
    expect(reply.body).toMatchObject({ name: "UnknownError" })
    continuation = Instance.provide({ directory: project.path, fn: async () => {
      const ledger = Database.use(db => db.select().from(PermissionLedgerTable)
        .where(eq(PermissionLedgerTable.request_id, request.id)).orderBy(asc(sql`rowid`)).all())
      await captureFacts("before-continuation-assertions.json")
      expect(ledger.map(row => row.event_type)).toEqual(["requested", "allowed_once", "execution_started", "execution_succeeded"])
      const decision = ledger[1]!
      expect(decision).toMatchObject({ request_id: request.id, decision_slot: request.id })
      const publication = Database.use(db => db.select().from(BusPublicationOutboxTable).where(sql`
        ${BusPublicationOutboxTable.event_type} = 'permission.replied'
        AND json_extract(${BusPublicationOutboxTable.properties}, '$.requestID') = ${request.id}
      `).all())
      expect(structuredClone(publication)).toMatchObject([{ properties: { requestID: request.id,
        decision: "allow_once", userInput: { text: "Read this public CSV once.", surface: "http.permission" } } }])
      const result = Database.use(db => db.select().from(PermissionExecutionResultTable)
        .where(eq(PermissionExecutionResultTable.attempt_id, ledger[2]!.attempt_id!)).get())
      expect(structuredClone(result)).toMatchObject({ result: { kind: "json", value: { output: expect.stringContaining("item,quantity") } } })
      Database.use(db => db.run(sql.raw("DROP TRIGGER public_retirement_cut")))
      triggerInstalled = false
      await write("decision-before-recovery.json", { request, ledger, publication, result, reply })
      expect(await SessionLoop.resumePermissionContinuation(request)).toBe("resumed")
      const after = await MessageStore.get({ sessionID: request.sessionID, messageID: request.messageID })
      expect(structuredClone(after.info)).toMatchObject({ id: request.messageID, time: { completed: expect.any(Number) } })
      const history = await PermissionAuthority.history()
      expect(history.filter(row => row.request_id === request.id).map(row => row.event_type))
        .toEqual(["stale", "execution_succeeded", "execution_started", "allowed_once", "requested"])
      expect((await Session.messages({ sessionID: request.sessionID })).map(message => message.info.id))
        .toContain(request.messageID)
      await write("recovered.json", { request, after, history })
    } })
    facts.continuationStarted = true
    facts.continuationJoined = false
    void continuation.catch(() => undefined)
    await within(continuation, "Original exact continuation")
    facts.continuationJoined = true
  } catch (error) {
    primaryError = error
    throw error
  } finally {
    const cleanupErrors: unknown[] = []
    const clean = async (label: string, fn: () => unknown | Promise<unknown>, flag?: string) => {
      try { await within(Promise.resolve().then(fn), label, true); if (flag) facts[flag] = true }
      catch (error) { cleanupErrors.push(error) }
    }
    await clean("Preserve actual failure facts before cleanup", () => captureFacts("before-cleanup.json"))
    await clean("Remove owned SQLite fault", () => { if (triggerInstalled) Database.use(db => db.run(sql.raw("DROP TRIGGER public_retirement_cut"))) })
    for (const request of provider.requests) request.release()
    clearInterval(release)
    await clean("Cancel exact owned Prompt", async () => {
      if (!originalRequest) return
      const cancellation = SessionPrompt.cancel(originalRequest.sessionID, project.path, createExecutionCancellationOrigin({
        actor: "runtime", source: "process.shutdown", surface: "test.permission-retirement-reply",
        reason: "The owned public retirement contract is closing", targetSessionID: originalRequest.sessionID,
        messageID: originalRequest.messageID, toolCallID: originalRequest.toolCallID,
      }))
      if (cancellation) await cancellation.finished
    })
    if (server) await clean("Original listener shutdown", () => server!.stop(true), "listenerClosed")
    if (facts.instanceCreated) await clean("Original Instance shutdown", () => Instance.disposeAll(), "instanceClosed")
    if (execution) await clean("Original read operation join", () => execution!, "originalExecutionJoined")
    if (continuation) await clean("Original continuation join", () => continuation!, "continuationJoined")
    facts.providerResponseCount = provider.requests.length
    if (provider.requests.length) {
      facts.providerResponsesJoined = false
      await clean("Owned Provider response join", async () => { await Promise.all(provider.requests.map(request => request.responded)) }, "providerResponsesJoined")
    }
    await clean("Owned Provider shutdown", () => provider.server.stop(true), "providerClosed")
    await clean("Owned source cleanup", () => fs.unlink(source), "sourceRemoved")
    await clean("Preserve actual isolated application log", () => captureLog("server-log-final.jsonl"))
    facts.endedAt = Date.now()
    facts.error = primaryError === undefined ? null : String(primaryError)
    facts.cleanupErrors = cleanupErrors.map(String)
    facts.providerRequests = provider.requests.map(request => ({ index: request.index, kind: request.kind,
      model: typeof request.body === "object" && request.body !== null && "model" in request.body ? request.body.model : undefined }))
    await write("http-receipts.json", requests)
    await write("scope-final.json", facts)
    if (cleanupErrors.length) throw new AggregateError(
      primaryError === undefined ? cleanupErrors : [primaryError, ...cleanupErrors], "Public retirement scope cleanup failed")
  }
}, 120000)
