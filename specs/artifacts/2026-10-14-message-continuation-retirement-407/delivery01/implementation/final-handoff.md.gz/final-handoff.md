# 407 backend final handoff

Status: production and tests frozen; no service, model call, credentials, SDK generator, browser or child process currently owned by this agent. Root owns final shared documents, artifact selection, type/module checks and Git. Ten exact changed files are enumerated in `final-source-allowlist.json`: two production files, six modified backend tests and two new backend tests. `final-tracked.patch` includes the eight tracked-file changes; the two new files are copied verbatim to `final-permission-message-retirement.test.ts` and `final-permission-retirement-reply.test.ts`. Original preimages and failed launch sources remain separate.

## Final behavioral evidence

| Formal run | Distinct output | Original completion |
| --- | --- | --- |
| focused-green03 | new local writer10/107 + Message settlement10/23 =20/130 | exec26948 join0, ea2bc6; all wrapper closure flags true |
| process-green01 | four actual controlled-streaming/process cases4/58 | exec57611 join0,173129; all eight original children and owned Provider/resource/handler/physical/output/request facts closed |
| public-reply04 | actual HTTP origin, genuine shutdown interruption, normal relisten, durable operator decision, exact SQL retirement500 and subsequent unresumable+stale;1/22 | exec93256 join0,b597e4; separate old/new listeners, original HTTP rejected-but-observed, continuation and three Provider replies closed; original90/75/30/120/600 bounds retained |
| related01 six green files + related-tool-publication02 |37/145; actual callback observes complete Tool+Source, recovery/fork/atomic/DB contracts | original65944 join1,ded247 retained for one old wait-boundary failure; selected file39835 join0,b20388 after approved correction; all wrapper physical/output/request flags true |

Total **62 independent tests / 355 assertions across11 selected files**, without counting repeated red/green attempts twice. No UI automation was created or run. All formal commands use the reviewed Bun1.4 executable and unchanged copied standard owned-tree wrapper. Exact argv/executable/PID/occurrence/start/deadline/end are in each original owner-start.json/owner.json; original tool-level joins are listed in original-exec-joins.json.

## Preserve failures and source boundaries

- process-red01:2pass2fail32; actual natural completed live Messages had four events before the407 hook. Four raw completed.info records correct the old summary's wrong message field; both original and corrected summaries retained.
- focused01/02 preserve original history DESC/orderKey preparation mistakes and the real unsupported bare-bundle late Source admission. Focused03 uses the accepted compound result writer without erasing Source identity/history.
- public01:0/1/8, missing isolated logger means its exact500 cause unknown. Public02:0/1/8, actual unbound Catalog error proven by original logger; the direct fixture was replaced by real public origin rather than binding private state.
- public03:0/1/14; actual target SQL cause reached but pino error.type was Error, not the expected SQLiteError. Public04 only corrects the typed serialized contract to actual type/code/errno/message. All real error/closure receipts retained.
- related01:36/1/145, original observations[] was insufficient to claim lost event. The DB idle wait did not join the separately owned Bus publication; direct real callback wait passed without product Bus/Database change. Read `related-publication-wait-review.md` for all production idle callers, shared lifecycle/retry/Project scope and historical boundaries.

## Evidence selection and limits

Use exact stage owner files/stderr and selected public JSON/log/source snapshots; do not copy runtime directories, databases, auth/models or complete Provider request bodies. In particular related01 stdout may contain existing permission-message-recovery fixture's full controlled Provider request logging; it is not an archive-safe metadata log. The public scope recorder only saves Provider index/kind/model metadata. Root controls final archive allowlist/redaction; this agent has not copied artifacts into specs.

`functionality/grant-used-followup.md` remains frozen408 investigation: missing grant_used decision-slot and immutable historical ambiguity are not fixed here. Existing MCP App coordination, retained Task-root and Mission natural-terminal E2E gaps remain explicit; this patch is not all-Ask recovery. Task local recovery suite is an actual accepted activation/result contract, not a successful public Task model run. The public no-waiter test intentionally preserves real cancellation/Tool error, and does not claim that its CSV executed. Real Sol/UI evidence belongs to Root, separately from these controlled scopes.

`functionality/stream-retry-readonly.md` records the permitted three-JSON review of Root's original Sol reset: one actual same-activity retry reached EOF/natural stop, the reset initiator and canonical ProviderActivity row remain unknown, and the original all-stream qualifier failure remains a failure. No Provider classifier/qualification/source was altered.

Final diff whitespace check passed. Root reported actual clean module imports/no SCC separately; no new cycle, module budget, schema/migration, grant field, policy, lease, Question, or shared fixture change was made. Final source typecheck and artifact/docs/commit/push receipts should use Root's original owners rather than duplicating them here.
