import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import {gzipSync,gunzipSync} from 'node:zlib'
const root=path.resolve('.tmp-message-retirement-407')
const target=path.resolve('specs/artifacts/2026-10-14-message-continuation-retirement-407/delivery01')
const items=[]
const add=(source,destination,selection='Original complete file')=>{
  assert(fs.statSync(source).isFile());items.push({source,destination,selection})
}
const tree=(source,destination)=>{
  for(const entry of fs.readdirSync(source,{withFileTypes:true})){
    assert(!entry.isSymbolicLink());const file=path.join(source,entry.name),to=destination+'/'+entry.name
    if(entry.isDirectory())tree(file,to)
    else if(to==='implementation/related01/stdout.log')items.push({source:file,destination:to,omit:true,
      selection:'Existing controlled Provider full request-body stdout excluded; complete stderr and original owner retained'})
    else if(entry.name==='config.json')items.push({source:file,destination:to,omit:true,
      selection:'Configuration body excluded; actual configuration admission remains in HTTP metadata'})
    else add(file,to,/http\.json$/.test(entry.name)?'HTTP originals with /global/config body reduced to admission metadata':'Original complete file')
  }
}
for(const file of ['check-sol-evidence.mjs','sol-business-evidence.json','root-original-exec-joins.json','archive-delivery.mjs'])add(path.join(root,file),file)
for(const file of ['production.patch','production-current.patch','existing-tests.patch','related-positive.patch',
  'focused-test-plan.md','related-check-plan.md','progress.md','original-exec-joins.json',
  'process-red-summary.json','process-red-corrected-summary.json','process-green-summary.json',
  'new-test-review.ts','public-reply-actual01.ts','public-reply-actual02.ts','public-origin-lifecycle-plan.md',
  'public-reply-public-origin-review.ts','public-origin.patch','public-reply-actual03.ts','public-reply-actual04.ts',
  'related-publication-wait-review.md','tool-publication-wait.patch','tool-result-recovery.before-publication-wait.ts',
  'tool-result-recovery.actual-publication02.ts','final-handoff.md','final-source-allowlist.json','final-tracked.patch',
  'final-permission-message-retirement.test.ts','final-permission-retirement-reply.test.ts','run-formal.ts'])
  add(path.join(root,'implementation',file),'implementation/'+file)
for(const dir of ['before','related-before','process-red01','process-green01','focused-green01','focused-green02',
  'focused-green03','types01','public-reply01','public-reply02','public-reply03','public-reply04',
  'public-reply-evidence01','public-reply-evidence02','public-reply-evidence03','public-reply-evidence04',
  'related01','related-actual01','related-tool-publication02',
  'process-red-evidence01','process-green-evidence01'])tree(path.join(root,'implementation',dir),'implementation/'+dir)
for(const file of ['packages/opencorvus/src/session/index.ts','packages/opencorvus/src/permission/authority.ts',
  'packages/opencorvus/test/session/permission-message-retirement.test.ts','packages/opencorvus/test/session/permission-message-settlement.test.ts',
  'packages/opencorvus/test/server/permission-retirement-reply.test.ts','packages/opencorvus/test/permission-execution-owner-process.test.ts',
  'packages/opencorvus/test/fixture/permission-execution-owner-process-worker.ts',
  'packages/opencorvus/test/permission-continuation-recovery.test.ts','packages/opencorvus/test/session/permission-message-recovery.test.ts',
  'packages/opencorvus/test/session/fork-atomic-transcript.test.ts',
  'packages/opencorvus/test/session/tool-result-recovery.test.ts'])add(path.resolve(file),'final-source/'+file)
tree(path.join(root,'ui/ui-test-removal'),'ui/ui-test-removal')
add(path.join(root,'functionality/stream-retry-readonly.md'),'audit/stream-retry-readonly.md')
add(path.join(root,'ui/grant-projection-408-analysis.md'),'audit/grant-projection-408-analysis.md')
tree(path.join(root,'ui/grant-408'),'audit/grant-408')
add(path.join(root,'ui/raw-permission-adapters-408-analysis.md'),'audit/raw-permission-adapters-408-analysis.md')
tree(path.join(root,'ui/raw-adapters-408'),'audit/raw-adapters-408')
for(const [name,prefix]of [['sol-manual01','message-retirement-407-live01'],['sol-manual02','message-retirement-407-replay01']]){
  for(const file of ['01-before-approval.jpg','02-natural-completion.jpg','chat-start.json','config-receipt.json',
    'conversation.json','messages.json','permission-history.json','provider-evidence-whitelist.json',
    prefix+'-physical-terminal-and-pair-cleanup.json',prefix+'-settlement-owner.json',prefix+'-shutdown-admission.json'])
    add(path.join(root,name,file),name+'/'+file)
  if(name==='sol-manual02')add(path.join(root,name,prefix+'-qualified-surface-completion.json'),name+'/'+prefix+'-qualified-surface-completion.json')
  const owned=path.join('C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-14',prefix,'evidence')
  for(const file of ['preflight-ready.json','native-host-settled.json','profile-selection-admitted.json'])
    add(path.join(owned,file),name+'/native/'+file)
}
for(const file of ['.tmp-product-iteration/live-sol-retirement-407-launch.ps1',
  '.tmp-product-iteration/live-sol-retirement-407-shutdown.ps1','.tmp-product-iteration/live-sol-source-reading-405.ts'])
  add(path.resolve(file),'sol-helper/'+path.basename(file))
for(const stage of ['module407-impl01','sol407-facts01'])
  tree(path.resolve('.tmp-task-question-recovery-406/delivery-commands',stage),'checks/'+stage)
tree(path.join(root,'build-ui01'),'checks/build-ui01')
fs.mkdirSync(target,{recursive:false});const manifest=[]
for(const item of items){
  assert(!/(^|\/)(auth\.json|models\.json|runtime|private-bundle)(\/|$)/i.test(item.destination))
  if(item.omit){manifest.push({source:item.source,destination:null,selection:item.selection});continue}
  let raw=fs.readFileSync(item.source)
  if(item.selection.startsWith('HTTP originals')){
    const data=JSON.parse(raw)
    assert(Array.isArray(data));let selected=0
    const reduced=data.map(entry=>{if(entry.route!=='/global/config')return entry;selected++
      const {body,...metadata}=entry;return {...metadata,configurationBody:'excluded; admission metadata preserved'}})
    raw=Buffer.from(JSON.stringify(reduced,null,2));item.selection+='; '+selected+' bodies excluded'
  }
  const originalImage=/\.jpg$/.test(item.destination),out=item.destination+(originalImage?'':'.gz')
  fs.mkdirSync(path.dirname(path.join(target,out)),{recursive:true})
  fs.writeFileSync(path.join(target,out),originalImage?raw:gzipSync(raw),{flag:'wx'})
  if(!originalImage)assert(gunzipSync(fs.readFileSync(path.join(target,out))).equals(raw))
  manifest.push({source:item.source,destination:out,bytes:raw.length,selection:item.selection})
}
fs.writeFileSync(path.join(target,'manifest.json'),JSON.stringify({capturedAt:Date.now(),files:manifest,
  boundary:'Frozen original runs and explicitly selected metadata. Failed runs retained. Gzip byte roundtrip only checks archive integrity, not functional correctness. No credentials, model catalog, runtime database, private bundle or full Sol Provider payload.'},null,2),{flag:'wx'})
console.log(JSON.stringify({target,files:manifest.length,bytes:manifest.reduce((sum,item)=>sum+(item.bytes??0),0)}))
