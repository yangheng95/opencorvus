# 407 authorized UI-test deletion — final scope

Root's final spec authorization supersedes the earlier partial-assertion idea. Source review showed that removing direct card assertions would leave actual card projection and RAF/paint fixtures in place. The final change therefore deletes 18 original test definitions across exactly four files, with no replacement UI automation.

Deleted in full:

- `packages/overlay/test/tree-writer-incremental-projection.test.ts` — 3 cases, 239 original lines, including its local frame queue, paint helper and card snapshots.
- `packages/overlay/test/tree-writer-review-stream.test.ts` — 2 cases, 87 original lines, including inline stream/card fixtures and immediate RAF stub.
- `packages/overlay/test/projection-prerequisite-recovery.test.ts` — 2 cases, 208 original lines, including actual projection setup, recovery stub, board/card state and frame/reset hooks. Root chose full retirement; the proposed narrow missing-Session subcase was not retained.

Reduced `packages/overlay/test/tree-writer-message-facts.test.ts` from 12 cases to the one original `history coverage and actor integrity have precise preparation errors` case. Its two original explicit-error assertions and the original plain `info` input helper remain. Imports now contain only Bun expect/test and the existing production prepare function. The other 11 cases and all RAF/paint/reset/apply/commit/i18n/card-tree setup are removed; the shared production locale resources are preserved.

The retained path only constructs local data and reaches original missing-transcript / missing-canonical-actor errors before commit, card projection or rendering. No new parser, data mirror, test hook, host mode, constructor-only replacement or bypass was introduced. This is a source-backed classification, not a test-run result: none of the four paths, including the retained case, was run.

Before the deletion, working and staged diffs for all four files were empty and the files matched the full read-only captures. Their complete originals and both original diff files are preserved under `before/`, `source-before.patch`, and `index-before.patch`. The complete final patch and exact status/stat are saved separately; unrelated work is preserved. Final diff: **4 files, 2 insertions, 765 deletions**.

Deletion removes automated checks of card segmentation/reference reuse/frame display equivalence, review card/reasoning projection, recovery through a projected card tree, and canonical data assertions that were inseparable from visible-writer fixtures in these tests. Those lost checks are not relabeled as backend/transport passes. Production Message/Part APIs and recovery behavior remain intact; UI behavior requires real page evidence. Genuine backend/transport tests outside the four authorized paths remain untouched.

No external fixture, baseline or dedicated active script/config was imported by these tests. Shared `run-unit-tests.ts` discovers the remaining `.test.ts` files normally; package scripts and CI are preserved. Historical specs, release statistics, logs, diffs and archived compiler configurations referencing old test paths are evidence, not active test fixtures, and were not rewritten. Root handles current spec/shared-doc statements and the scope commit/push.
