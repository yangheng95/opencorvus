import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
const root = path.resolve('.tmp-message-retirement-407')
const read = file => JSON.parse(fs.readFileSync(file, 'utf8'))
const out = []
for (const [name, prefix, expectedCount] of [
  ['sol-manual01','message-retirement-407-live01',6],
  ['sol-manual02','message-retirement-407-replay01',5],
]) {
  const scope=path.join(root,name), load=file=>read(path.join(scope,file))
  const start=load('chat-start.json'), messages=load('messages.json'), history=load('permission-history.json')
  const conversation=load('conversation.json'), config=load('config-receipt.json')
  assert.equal(start.status,202); assert.equal(messages.status,200)
  assert.equal(history.status,200); assert.equal(conversation.status,200)
  assert.equal(config.permission_mode,'ask'); assert.equal(config.model,'openai/gpt-6.1-sol')
  const session=start.acceptance.session
  assert.equal(messages.sessionID,session.id); assert.equal(history.sessionID,session.id)
  const rows=history.body.filter(row=>row.event_type==='requested')
  assert.equal(rows.length,1)
  const request=rows[0], ledger=history.body.filter(row=>row.request_id===request.request_id).reverse()
  assert.deepEqual(ledger.map(row=>row.event_type),['requested','allowed_once','execution_started','execution_succeeded','stale'])
  assert.equal(request.project_id,session.projectID); assert.equal(request.session_id,session.id)
  assert.equal(request.provider_kind,'builtin'); assert.equal(request.provider_id,'read'); assert.equal(request.tool_name,'read')
  assert.equal(ledger[1].decision_slot,request.request_id)
  assert.equal(ledger[2].source_event_id,ledger[1].id)
  assert.equal(ledger[3].attempt_id,ledger[2].attempt_id)
  assert.equal(ledger[3].outcome_slot,ledger[2].attempt_id)
  const msg=messages.body.find(entry=>entry.info.id===request.message_id)
  assert(msg); assert.equal(msg.info.role,'assistant'); assert.equal(msg.info.sessionID,session.id)
  assert.equal(msg.info.providerID,'openai'); assert.equal(msg.info.modelID,'gpt-6.1-sol')
  assert.equal(msg.info.finish,'tool-calls'); assert(Number.isSafeInteger(msg.info.time.completed))
  const tool=msg.parts.find(part=>part.type==='tool'&&part.callID===request.tool_call_id)
  assert(tool); assert.equal(tool.state.status,'completed'); assert.equal(tool.tool,'read')
  assert.equal(tool.messageID,msg.info.id); assert.equal(tool.sessionID,session.id)
  assert.equal(tool.state.metadata.preview,'item,quantity\nCedar407,3\nIris407,4')
  assert.equal(tool.state.metadata.totalLines,3)
  const source=msg.parts.find(part=>part.type==='source-file'&&part.toolPartID===tool.id)
  assert(source); assert.equal(source.path,tool.state.input.filePath)
  assert.equal(request.scope.resource.paths[0],source.path)
  assert(msg.info.time.completed>=tool.state.time.end)
  assert(ledger[4].time_created>=msg.info.time.completed)
  const finals=messages.body.filter(entry=>entry.info.role==='assistant'&&entry.info.finish==='stop')
  assert.equal(finals.length,1); const final=finals[0]
  assert.equal(final.info.parentID,msg.info.parentID); assert.equal(final.info.modelID,'gpt-6.1-sol')
  assert(final.info.time.completed>=msg.info.time.completed)
  assert(final.parts.some(part=>part.type==='text'&&part.text.length>0))
  assert.deepEqual(conversation.body.transcript.map(entry=>entry.info.id),messages.body.map(entry=>entry.info.id))
  const audit=load(prefix+'-final-provider-audit.json')
  const requests=audit.requests.map((item,index)=>({index,model:item.model,streaming:item.streaming,status:item.status,
    readerState:item.response_reader?.state,terminal:item.response_reader?.terminal,
    activity:item.response_reader?.requestContext?.activity}))
  assert.equal(requests.length,expectedCount)
  for(const item of requests){assert.equal(item.model,'gpt-6.1-sol');assert.equal(item.streaming,true)
    assert.equal(item.status,200);assert.equal(item.readerState,'settled');assert(item.activity?.id)}
  if(name==='sol-manual01'){
    assert.deepEqual(requests.map(item=>item.terminal.kind),['eof','eof','eof','eof','error','eof'])
    assert.equal(requests[4].terminal.error.code,'ECONNRESET')
    assert.equal(requests[4].activity.id,requests[5].activity.id)
    assert.equal(requests[4].activity.attempt,0);assert.equal(requests[5].activity.attempt,1)
  }else{
    assert.deepEqual(requests.map(item=>item.terminal.kind),['eof','eof','eof','eof','eof'])
    const qualified=load(prefix+'-qualified-surface-completion.json')
    assert.equal(qualified.qualification,'NativeService');assert.equal(qualified.physicalCompletion,true)
    assert.equal(qualified.providerEOFRequests,5)
  }
  const closure=load(prefix+'-physical-terminal-and-pair-cleanup.json')
  assert.equal(closure.nativeSettlement.terminal.exitCode,0)
  assert.equal(closure.physicalCompletion,true);assert.equal(closure.pairedCleanupComplete,true)
  assert.equal(closure.nativeSettlement.outputDrainComplete,true)
  assert.equal(closure.nativeSettlement.requestCleanupComplete,true)
  fs.writeFileSync(path.join(scope,'provider-evidence-whitelist.json'),JSON.stringify({
    provenance:prefix+'-final-provider-audit.json; selected physical metadata, no payload or credentials',
    pid:audit.pid,maxRequests:audit.maxRequests,exhausted:audit.exhausted,requests},null,2))
  out.push({scope:name,sessionID:session.id,projectID:session.projectID,requestID:request.request_id,
    toolMessageID:msg.info.id,toolPartID:tool.id,toolCallID:tool.callID,attemptID:ledger[2].attempt_id,
    messageCompletedAt:msg.info.time.completed,retiredAt:ledger[4].time_created,
    finalMessageID:final.info.id,finalCompletedAt:final.info.time.completed,
    actualProviderRequests:requests.length,physicalQualification:name==='sol-manual01'?'failed-read-error':'passed',
    businessFactContract:'passed',visualSemantics:'Root manual original screenshots; not checked by this script'})
}
assert.equal(out.reduce((sum,item)=>sum+item.actualProviderRequests,0),11)
fs.writeFileSync(path.join(root,'sol-business-evidence.json'),JSON.stringify({
  boundary:'Original captured public API/physical metadata validation, not a new model run or UI automation',
  scopes:out},null,2))
console.log(JSON.stringify({scopes:out,totalRequests:11}))
