# 407 Sol-manual01 stream reset: read-only shared-mechanism review

## Scope and actual evidence

Only the authorized public files `sol-manual01/provider-summary.json`, `messages.json`, `permission-history.json` and current source/history were read. No auth/models, full Provider payload, runtime database, new service or model was accessed. No product, classifier or qualifier was changed. The first PowerShell message projection incorrectly treated the receipt envelope as an array; its null console fields are not data evidence. The subsequent read uses the actual `messages.body` and original `provider-summary.requests` arrays. No bad projection was saved as a canonical fact.

Observed sequence from these original receipts:

| Fact | Exact identity/time |
| --- | --- |
| Permission-bearing read assistant | msg_g0VXzZQ2z00e0xwvlRKl, created1791949484665, actual Tool call_6fdcbccf75e2477ab044d7657e16483d |
| Original Permission | per_hMZPvNJlPRU5DjN19cSj, Project prj_hk2bQmX30jGRK8guskF8, Session ses_h413fU8qG954kngZ5QfY; asked1791949489421, allowed_once1791949593751 |
| Original effect | start1791949593817, execution_succeeded1791949593829, actual ReadTool output has the header/Cedar4073/Iris4074 and its Source Part |
| Tool-bearing Message conclusion | finish tool-calls, completed1791949593900; original request's stale1791949593905 |
| New answer Message | msg_g0VXzZsTb00XxqTEWuhS, created1791949593947; this is a different assistant from the read |
| Fifth physical request | actual model gpt-6.1-sol, streaming=true, HTTP200, logical activity act_g0VXzZsbD00t3cbL9Oc3, attempt0, same new answer Message; terminal kind error at1791949595780, fixed safe cause `{origin:read,type:TypeError,code:ECONNRESET}` |
| Sixth physical request | same exact model/activity/answer Message, attempt1; HTTP200 and reader EOF1791949600645 |
| Natural answer | finish stop, completed1791949600668, error absent; actual text lists Cedar407=3/Iris407=4 and total7 |

The allowed receipt set therefore proves one physical response read error followed by a successful second physical attempt of the **same logical answer activity**. It does not show a duplicate ReadTool, Permission replay, Message identity replacement, retired-request resumption or shutdown-triggered reset. The read's own Message and retirement were already complete before the new answer failed. Root's separate shutdown fact1791949738xxx is more than two minutes later; it is outside this three-file observation and is attributed to Root, not newly re-read here.

`provider-summary` lists six actual requests: five EOF and one read error. All have HTTP200, but HTTP200 is only headers success, not EOF. Its `exhausted:false`/maxRequests20 are preserved. Native exit0/shutdown200/pair cleanup and enclosing qualification exit1 were provided by Root; this report does not reinterpret the failed qualification as pass or modify its all-stream acceptance rule. Native process success, logical recovered answer success and physical all-request EOF qualification are different observed predicates.

**Unknown:** which host/socket/peer sent or caused TCP reset; whether a proxy, server, operating system, client transport, or other network component initiated it; the exact retry classifier event/reason/backoff emitted in this run; actual ProviderActivity SQL outcome row. These files deliberately omit full error messages and Provider payloads. A fixed code alone cannot prove the classifier's exact runtime branch because the classifier also considers typed causes/messages and abort reasons. Successful attempt1 is direct evidence of a retry; `network` is the compatible source path, not a captured classifier event here.

## One current retry owner and actual request binding

- `llm/api.ts:49–59,143` gives the AI SDK maxRetries=0. The SDK does not own a competing retry loop.
- `llm/activity.ts:498–555` allocates one logical activity id outside its attempt loop and emits one started event. Attempt starts at0. `737` emits done only after attemptFn returns and external/total cancellation checks pass. `747–749` prioritizes a real external abort; it becomes terminal aborted, rather than another normal retry.
- The classifier at `298–376` prioritizes marked abort, Host integrity, auth and semantic stream errors, then actual HTTP status and transport message/typed APICallError.cause. It recognizes ECONNRESET/socket-closed transport wording as network. HTTP200 does not itself make the body successful; SDK reader failures can retain their typed cause. Semantic Provider stream errors and Host faults are not retried as unknown.
- `396–440,763–819` grants retry to specific transient classes; default cap5, first-byte1, rate-limit15, one original activity total deadline. It calls the existing beforeRetry boundary, emits the real retry event, sleeps under original external/total signals and increments the same attempt counter. No new Session, Task, queue or changed tool selection is involved.
- `session/processor.ts:887–898,944–960` passes `{id:run.id,attempt:run.attempt,assistantMessageID:originalAssistant.id}` through each actual LLM.stream invocation. The exact Tool execute wrapper marks an effect as started before entering it, including SDK execution before its consumer Tool-call event.
- `util/provider-response-observation.ts` binds the observer to the exact Response via WeakMap; `util/stream-activity.ts:142–216` observes the original reader. The safe `origin:read` record describes where reader.read rejected; it is not a claim about which network endpoint sent the reset. The observer has a distinct observation-error path and cannot overwrite the physical stream result.
- Current architecture `06-provider.md:566,590` explicitly describes typed HTTP200 body errors, same-owner retry cleanup, immutable activity/attempt context and the distinction between physical bytes and semantic liveness.

## Same-Message safety and terminal facts

`processor.ts:774–885` owns an attempt-local set of actual created Parts, Tool call ids, execution-start flag and Message metadata snapshot. Before a retry it joins pending streamed/reasoning flushes. If that failed attempt has already entered Tool execution, `ProcessorUnsafeRetryError` prevents repeating it under a new Provider attempt. For ordinary non-causal Messages it removes only that attempt's original ephemeral/durable drafts through canonical writers; a causal Task-root Message retains its original Parts as occurrence history. The latter uses the actual `Session.isTaskRootCausalMessage` predicate, not a last-message or task-name guess. It clears per-attempt accumulators and restores Message metadata through the same writer. This does not run the finished previous Message's read again.

`recordProviderActivityEvent` is the unique canonical accepted-call writer. It receives events only from SessionProcessor's sink (`processor.ts:1543`) and the explicit abandoned-activity recovery writer. It ignores retry events: the SQL contract is one request per **logical activity**, and one terminal outcome whose `attempt_count` is the emitted total. The request is bound to the actual assistant Message and Session, and Task-root activation admission is checked. Terminal id is deterministic for that original request, with explicit conflicting-outcome rejection except the separately classified recovery-interruption/late-result observation. A replayed identical terminal is idempotent; a different real outcome is not silently chosen by latest time.

For this observed successful two-attempt activity the current source would emit terminal done with attempts2, producing one outcome data `{outcome:done,attempt_count:2}`. **The three permitted JSON files do not contain the SQL Request/Outcome rows, so that value is an expected canonical contract, not a checked database fact.** They do contain the final Message natural stop and original logical activity/attempt references. Root can obtain a later explicit selected canonical observation if that cell is needed; this report does not read a database outside its authorized input set.

`settleAbandonedProviderActivity` is only for recovery of original owner loss, not transient retry. Its production callers are Session's canonical recovered completion and SessionLoop's incomplete-assistant terminalization. It preserves original request identities and authors the explicit ProcessExecutionInterruptedError recovery fact. This current reset evidence shows neither that recovery event nor a conflicting outcome. Actual liveness/recovery decisions for Task and Mission remain their callers' responsibilities; this report does not bless expired leases as physical-death proof.

## Complete production entry/caller matrix

The whole-src exact search for `withLLMActivity(` yields only SessionProcessor and the `collectLLMText` implementation. Search for `collectLLMText(` yields title generation, Project Memory Organizer and VCS commit-message generation. SessionProcessor.create call sites are ordinary SessionLoop, exact Permission continuation and compaction. Thus the shared retry mechanism has these distinct boundaries:

| Entry | Retry/terminal/Project ownership |
| --- | --- |
| Main/Global Chat/Work/Side/ordinary child; public Session, CLI/ACP/channel/control | Normal SessionLoop→SessionProcessor→one logical activity; canonical Message/Session identity. A new assistant after a Tool step is distinct from the previous retired Tool Message. |
| Task root/worker/delegate | Same Processor and policy; actual activation fence and causal Part retention apply. Once an attempt starts Tool execution, its retry is unsafe and fails explicitly. This is a data/effect integrity boundary, not a workflow tool gate. |
| Mission | Same normal Processor retry; restart/interruption uses Mission's own original frontier/wake/owner recovery before generic continuation. No Mission-specific transient reset code path is introduced by 407. |
| Compaction | Existing direct Processor caller uses the same activity owner/attempt contract; separate compaction restart/frontier contract is not established by this ordinary Chat run. |
| Permission recovery | SessionLoop's exact persisted request reconstructs its original surface; Tool/result completion and Message retirement are independent from subsequent new logical answer activity. No actual permission continuation retry was observed in the reset pair. |
| Title and Memory helpers | collectLLMText forwards its real activity identity but does not invent an assistant Message or ProviderActivity SQL row. Reset of one helper is not evidence of failed Chat/Task effect; each helper has its own caller error contract. |
| VCS commit text helper | collectLLMText uses NonReplayableLLMActivityPolicy for externally visible deltas. It is deliberately a different replay-safety policy, not a second retry implementation. |

Serial later activities each receive a fresh activity id. Concurrent Sessions/Projects each have their own id and assistant relation; canonical Request insertion checks exact Message+Session and Task activation. Retry state is local to a single withLLMActivity invocation/Processor attempt scope and does not select another Project's latest activity. Restarts do not revive a JavaScript attempt counter: they recover the original durable Message/Tool/ProviderActivity graph and admit whatever new owned activity the existing lifecycle permits. An actual live-peer/restart/Task/Mission network-reset test was not run in this review, and the single ordinary Sol pair does not prove those cells.

## Existing evidence and safe next action

Current tests (not run by this audit): `test/llm/activity.test.ts` has exact transport socket-classification and typed-cause traversal plus idle/network sequences; `test/session/processor-llm-activity-retry.test.ts` exercises real Processor write/cleanup state with controlled stream input; `test/session/processor-retry-diagnostics.test.ts` retains original typed transport causes when an effect prevents replay; `test/provider-response-observation.test.ts` proves actual reader rejection produces the fixed origin/type/code facts while preserving the original error object; `test/provider-activity-fact-storage.test.ts` covers canonical logical request/outcome storage and terminal conflicts. These are separate evidence levels, not an actual independent Provider run.

Recent relevant history includes 3e9f3b59b (retained retry causes), 585c2914e (complete Tool result recovery), 3b0562c97 (SDK7 recovery and stream contracts); 407 changes neither classifier, attempt loop, SDK retry count nor physical reader. Its stale insert occurred before the failing answer activity. This is positive causal separation from the Permission retirement defect, not a diagnosis of the remote reset's cause.

Recommendation: preserve scope01 qualification failure and exact transport error as observed, retain the successful logical answer/retirement evidence with its narrower meaning, and use Root's independent fresh scope for the requested all-stream success criterion. Do not patch the qualifier, increase its original deadline, synthesize an EOF, retry the old scope from the Host, or attribute the reset to product shutdown/user cancellation without independent transport evidence. No product fix is justified from these three files alone.
