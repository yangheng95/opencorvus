# 408 raw Permission adapters: current authority, actionable requests and historical notices

Read-only supplement to [grant projection review](grant-projection-408-analysis.md). Root has not approved a historical indexing event or production/test changes. This report changes no production, tests, specs, shared documentation, SDK or Git state. No services, models, browser, user database or credentials were used. No UI automation was run or intentionally searched.

## Source identity and limits

Initial HEAD: `50cf35a83baa9467e59aa91f541fc0d53dd8756b`. The six adapter/reader/action files audited here had no working-tree diff at capture. The broader workspace contained Root/peer changes, including 407 Authority/Session work, which were left untouched. Exact current identity, status and empty scoped diff are [manifest.json](raw-adapters-408/manifest.json), [status.txt](raw-adapters-408/status.txt), and [scope-current-diff.patch](raw-adapters-408/scope-current-diff.patch). The installed ACP (Agent Client Protocol) SDK is **1.4.0**, resolved through `packages/opencorvus/node_modules/@agentclientprotocol/sdk` to `node_modules/.bun/@agentclientprotocol+sdk@1.4.0+68a1e3a0c4588df3/node_modules/@agentclientprotocol/sdk`. No new dependency version is assumed.

Twenty numbered repository/installed-dependency excerpts, successful caller queries, SDK metadata and history are in [raw-adapters-408](raw-adapters-408/). Capture script exited 0 (`df3c4f`). The first broad installed `dist` search incidentally returned `acp.test.js` JSON-RPC transport test matches because excluding test directories did not exclude a `.test.js` basename; that file was not opened or run, and subsequent queries used explicit runtime/declaration files. No UI test was identified by that result. Guessed absent `dist/client.d.ts`, `dist/schema/types.gen.ts`, `src/session/prompt.ts` and `src/engine/service.ts` paths were corrected to actual definitions, not used as proof of missing functionality.

**Correction to the preceding report:** ACP and channel subscribe to `/global/event`. CLI `run` uses the **project-scoped `/event`** via `sdk.event.subscribe`, not `/global/event`. Both are raw event streams, distinct from the Overlay's canonical Session connected snapshot. This does not change the late-Asked finding but matters for directory and reconnect scope.

## Existing canonical reader and actual action boundary

`permission/pending-projection.ts:3–13` already provides `durablePendingPermissionsForSession({sdk,sessionID,directory,signal})`. It calls public `sdk.permission.list` with `throwOnError:true`, then exact-filters `request.sessionID`. The API reads `PermissionAuthority.list`, whose authority is the decision slot. There is no additional Permission cache or choice policy in this helper. It is used by ACP load/fork/resume and CLI initial hydration. Fixing the canonical grant decision upstream is a prerequisite; until then the reader faithfully exposes the slotless-grant defect.

This helper is suitable for **rechecking the exact queued request just before presenting an actionable ACP dialog and again before submitting the returned client choice**. Select the original request id from the newly returned complete set and use that canonical Request's scope/choices/summary. A missing pending request means it no longer needs a decision; it does not distinguish approval, rejection, cancellation or deletion and cannot justify inventing any of those outcomes. API failure must remain a real error. The current helper has `response.data ?? []`; before using malformed/missing data as evidence to retire an active client request, the implementation should require the declared array contract rather than reinterpret a successful empty body as canonical absence. This is an input-integrity refinement of the same reader, not another lookup source.

Any precheck is a read, not a reservation. A decision can win between the read and the eventual HTTP reply. The backend's unique decision transaction and actual returned winner remain the final authority. This is data integrity around a human action, not a host rule deciding which model Tool to choose.

## ACP: actionable native permission request

### Current queue, response and recovery

`acp/agent.ts:290–291,602–677` has one per-Session Promise chain (`permissionQueues`) and one `projectedPermissionRequests` Set. On Asked:

1. It exact-finds a loaded Session, marks the request id in the Set and appends work after that Session's previous Promise.
2. When the queued callback finally runs it uses the **captured original Request** to invoke `connection.requestPermission`. It does not read current pending authority at this moment. A request can have settled while waiting behind another dialog.
3. The actual client result is either `selected` plus `optionId`, or `cancelled`. Selected goes directly to `sdk.permission.reply` with `actorID:"acp-operator"` and the captured Session directory. There is no second read after a slow client responds.
4. Transport failure and cancelled outcome remove the Set entry and do **not** deny the durable request. This deliberate behavior must stay. The outer catch after a reply failure, however, leaves the Set entry; selected/success also leaves it for the lifetime of the ACP agent. The Set is not canonical authority and must not become the proposed resolved tombstone.
5. The per-Session queue is removed only after its actual Promise settles. Other Sessions have independent chains. Connection close aborts `eventAbort`; the installed SDK rejects live outgoing requests on connection close.

The actual ACP `sdk.permission.reply` call also omits `throwOnError:true` and does not examine the returned response. The normal ACP command constructs its SDK without a throwing default. Generated `Permission.reply<ThrowOnError = false>` and client HTTP error handling return an `error` field unless configured to throw, so some actual HTTP failures can be ignored before the Set remains marked. This is narrower than claiming every failure reaches the outer catch. The additional exact declarations/runtime excerpt is [sdk-http-error-contract.txt](raw-adapters-408/sdk-http-error-contract.txt). Any touched action path must read the real reply response/winner or request throwing errors, preserving retryable pending authority instead of treating an HTTP error as success.

`handleEvent` handles Asked but no Permission Replied or Terminated. Normal `message.part.updated` Tool results are separately projected to genuine ACP `tool_call_update` completed/failed states; these are execution outcomes, not a permission-dialog result. Do not send `completed` just because authorization was captured.

Load (`:808`), fork (`:917`) and resume (`:958`) call `hydratePendingPermissions` through the shared reader after restoring actual history/model/mode. Each merely schedules the real permission queue; it does not fake a client selection. A newly constructed ACP agent has a new Set and reads the real pending set. The global event reconnect loop (`:319–333`) reconnects after a normally ended stream but performs no canonical pending hydration for already loaded Sessions; it is not the Overlay connected handshake. A thrown subscription error is logged by the outer start promise. Missing events during a gap are not replayed by `/global/event`.

`ACPSessionManager` owns the existing loaded Session map, with `tryGet`, `get`, create/load/restore and field setters. It currently has no public enumeration method. Supporting refresh of all already loaded Sessions after a global reconnect would require a small read-only enumeration of **that existing manager**, not a second map of Session authority. Captured Session/directory and connection identity must still be current when queued work starts or a late client answer returns. No Project-wide action should be inferred from an unrelated global event.

### Installed and official cancellation contract

The convenience API `AgentSideConnection.requestPermission(params)` (`dist/acp.d.ts:800`, `acp.js:1212`) accepts no cancellation options. However the **same installed class** exposes the typed generic public method:

```ts
connection.request(
  methods.client.session.requestPermission,
  actualPermissionParams,
  { cancellationSignal: ownedRequestController.signal },
)
```

`acp.d.ts:841–842` and `acp.js:1260–1263` prove this is an existing API, not an extension or private-field workaround. Its JSON-RPC layer sends `$/cancel_request` using its own actual outgoing request id. It is unnecessary and incorrect to guess a JSON-RPC id from the Permission request id.

The installed `SendRequestOptions` and `jsonrpc.js:468–478,543–584,832–864` are explicit: cancellation **sends a request to cancel, but does not settle the local Promise**. The peer's actual normal/cancel/error response still settles it. The connection's pending response registry is cleared on the actual response or connection close. The legacy client wrapper in `acp.js:1106–1112` passes only `ctx.params` to `implementation.requestPermission`, so a legacy client's handler does not receive the new per-request signal through that interface. App-style client handlers can receive `ctx.signal`; arbitrary existing clients may ignore cancellation.

Official current [ACP v1 request cancellation](https://agentclientprotocol.com/protocol/v1/cancellation) confirms cancellation is optional/cooperative, with a real normal or cancelled response. [ACP tool-call permissions](https://agentclientprotocol.com/protocol/v1/tool-calls#requesting-permission) separately requires a client that cancels its prompt turn to answer outstanding permission requests as cancelled. These are distinct mechanisms. `session/cancel` is **client-to-agent whole-turn cancellation**, not an agent command to dismiss a single obsolete dialog; OpenCorvus `ACP.cancel` calls actual `session.abort`. It must not be invoked to clear a grant-resolved permission prompt. The unversioned `/protocol/cancellation` URL returned 404; the versioned v1 page above was actually read. Current online TypeScript docs advertise a newer version, so installation files, not that site's current version number, establish the usable 1.4.0 API.

### Smallest supported ACP integration

- Preserve the existing per-Session Promise chain; do not add another queue. At its real head, read the exact current pending Request using the shared reader and original loaded Session directory/connection abort signal. If already settled, finish the queued operation without opening a new permission request.
- Track only an **owned live RPC cancellation handle**, not a cached decision. The existing per-request Set can become the ownership map for queued/running operations and be removed in their `finally`; do not add a permanent resolved-id collection alongside it. Duplicate live delivery can share/skip the same owned request while canonical reads prevent a settled request being recreated afterward.
- Register ownership before asynchronous pending read, and check that the owner/connection is still active before sending. This matters because the SDK still sends then cancels when given an already-aborted signal; an already-invalid operation should not be deliberately opened.
- On the exact Session/request's real Replied or Terminated, request cancellation of its already owned RPC. A reconnect canonical pending read can discover absence and request the same cancellation without naming an unproved terminal outcome. It must not invent a client response, deny a request, or write userInput.
- Await the genuine client response or actual connection close. Re-read pending authority before posting a selected choice. If still pending, validate the returned `optionId` against that canonical Request and call the existing reply route; otherwise finish the obsolete RPC as a transport operation without a new decision. The backend still decides a final concurrent race. Preserve actual selected-client evidence only when the canonical user reply wins.
- On reconnect/load/resume, reconcile current owned RPCs and pending work from the same shared reader. Do not add timeout-based settlement, force-resolve the Promise, manufacture a cancelled outcome, close the entire user connection, or unconditionally delete pending permission facts.

**Hard boundary:** this scheme gives correct authority and the mature cooperative cancellation request, but cannot guarantee visual dismissal or per-Session queue progress while a non-cooperating client leaves its request unresolved. That limit needs an actual client interoperability check. Claiming that a sent cancel equals a dismissed native dialog would be false. A full migration from the legacy ACP wrapper to the newer app API is not necessary merely to use typed outgoing request cancellation and is outside the minimum scope.

## CLI: a historical output stream, not an authorization widget

`cli/cmd/run.ts:430–488,578–605` subscribes to project `/event` with its existing abort owner, one configured retry and stream-stall handling. Before iterating events it hydrates pending requests for the selected Session. `permissionRequested` deduplicates ids and emits JSON `permission_requested` with request id/tool/summary or prints `permission requested: …; waiting for operator reply`. It does not render buttons, read an approval from stdin, or call permission.reply. Actual execution settlement is the exact invocation's `agent.execution.lifecycle` terminal/idle plus the prompt HTTP response, not an answer to that printed line.

Later Replied/Terminated are currently ignored by that printing branch. `server.connected` resolves the initial connection promise but does not rehydrate pending on a reconnect. The raw `/event` route registers its live listener before Connected and emits no historical Permission snapshot; the SDK's Last-Event-ID facility alone cannot turn this route into persisted replay.

Minimum correction depends on the promised output semantics:

- If keeping a **current waiting** claim, run the shared pending reader immediately before displaying that claim. Use the canonical current Request, exact Session/directory and `eventAbort.signal`; the async event loop can await this without creating a new queue. A reconnect can reread current pending in the existing Connected branch.
- If retaining all Asked as **history**, phrase the notice as a request occurrence and remove the unconditional claim that it is still waiting. Existing JSON `permission_requested` is already occurrence-shaped and should not be renamed casually; its current `timestamp` is emission time, not Permission.timeCreated. A true original-request timestamp should be an explicitly specified field, not a silently changed meaning.
- If a current waiting notice is shown, a later **actual** Replied/Terminated can emit a matching factual settlement notice keyed by the same request. This is a transport diagnostic derived from a real event, not a synthetic model/user Message. Reconnect absence only proves current pending absence, so it cannot print “approved” without a matching fact. Do not clear terminal history or keep a shadow approval map just to rewrite stdout.

No additional CLI approval action or model-routing rule is needed. The existing dedup Set is output bookkeeping, not authority; new pre-action reading must not rely on it to prove settlement.

## Channel: notice relay versus real human decision ingress

### Notice relay

`channel-runtime/src/core.ts:1069–1090` consumes raw global Asked, finds exact Session bindings, mirrors a system diagnostic and sends ordinary text through each adapter. It says the request is waiting. It stores no permission decision and has no Replied/Terminated branch. `ChannelAdapter` exposes `sendMessage(...):Promise<void>`, uploads, optional startThread and incoming-message callback; it exposes **no sent message id, edit/delete operation, action-button reply or cancellation API**. Do not promise an in-place dismissal/edit that this public interface cannot perform.

The reconnect loop (`:1269–1296`) is live subscription plus backoff, without pending/history hydration. Core's direct-Session bindings use `SessionCoordinator`; Task bindings are a separate existing mapping used by Task completion. Raw Asked uses `findSessions(asked.sessionID)`, not `findTaskBindingsForEvent`, so this audit does not establish that every Task worker/Mission permission notice reaches every bound channel. Do not infer delivery from a request's label. Exact Project/directory must be maintained: the runtime client has a configured directory while the stream is cross-instance; a canonical lookup cannot blindly use that default for any global event.

The channel package already depends on `@opencorvus-ai/sdk`, not on the core opencorvus package. Do not import `@/permission/pending-projection` across that reverse package boundary. For a bound Session notice the existing SDK `permission.list` is the same canonical API; exact Session filtering is not another authority. If Root chooses a common reusable client utility for all three adapters, move the existing helper into an appropriate already shared SDK/client layer and remove its old implementation atomically—do not duplicate it or add a wrapper chain. That is an optional broader package change, not required to prove the current ledger fix.

The minimum relay correction is analogous to CLI: either display a truthful historical Asked occurrence, or use a current pending read before claiming it still waits. A later genuine Replied/Terminated may be a separate factual notification with request identity; do not invent a user message or new approval. No existing adapter supports retracting the old message. Cold/reconnect completeness would require reading canonical current state for actual bindings; it is not provided by the global stream and should not be claimed as already fixed.

### The existing actionable channel path is elsewhere

`server/routes/channel.ts:112–136` sends actual incoming messages to `ChannelIngress.message`. `channel/ingress.ts:195–234,285–336` finds the durable current Task/thread binding, then **freshly calls `EngineService.listTaskInteractions(taskID)`** for every human message. This public service checks current Project ownership and derives Interaction status from the real ledger. It selects the first actual pending Interaction. Existing recognized Permission commands invoke `replyUserInteraction` / `rejectUserInteraction` with original channel text as userInput. Otherwise normal control-message processing continues. This is not a replay of the stale raw Asked object. A Task grant decision fixed at the canonical Engine reader therefore naturally removes it from actionable pending selection. Do not add another permission-command parser, second pending queue or model Tool-selection gate.

Important exact adjacent race: the channel return text currently says `Permission granted.`, `Permission granted (always).`, or `Permission rejected.` based on the **attempted command**, even though the Task service returns the current canonical winner after reply CAS. If another actor won in between list and reply, `result.status/response.decision` can differ from that attempted command. The existing Task service returns the correct Interaction; the channel confirmation should describe that actual result rather than claim the user won. This is a concrete consumer defect under the shared decision race, but no new live reproduction was run. It can be corrected locally without a new message fact or changed userInput—the actual incoming human text remains preserved only under its current winner contract.

The notice and action routes also differ in direct mode: when `channelProtocol` is false, incoming text is an ordinary Session prompt, not the Task Permission command route. Do not claim that replying “allow” to every raw notice already decides a standalone Session permission. The existing root/Task binding checks and strict cross-Project error (`ingress.ts:340–380`) must remain.

## History, minimal file scope and protocol changes

History evidence is [history.txt](raw-adapters-408/history.txt) and [pending-reader-history.patch](raw-adapters-408/pending-reader-history.patch). `43636df96` introduced the shared pending helper, exact Permission request/choice mapping, load/fork/resume hydration, and intentionally removed ACP denial on transport error/cancel. `8b182bc31` added the helper's owned abort signal for CLI settlement. The original ACP queue and channel direct Interaction route predate these changes (`65d0bfc98`). `7f11e6190` improved actual ACP failure/cancelled prompt responses but does not provide a Permission-specific request-cancellation owner. Current production caller search is [callers.txt](raw-adapters-408/callers.txt).

Recommended minimal **adapter** scope after Root decides 408's canonical producer/index design:

| File | Specific reason; no wider rewrite |
| --- | --- |
| `permission/pending-projection.ts` | Reuse one API reader; explicit array contract if absence will close an active RPC. Do not add grant-history fallback. |
| `acp/agent.ts` | Revalidate at queue head and before reply; replace ever-growing request Set with actual owned queued/RPC lifetime; typed cooperative cancel on real settlement; preserve one Session queue, real client result and error/abort behavior. |
| `acp/session.ts` only if reconnect completeness is included | Expose read-only existing loaded Session enumeration for canonical rehydration; no parallel Session/permission cache. |
| `cli/cmd/run.ts` | Truthful occurrence/current-waiting output and factual settlement handling; shared reader with original owner signal; no new approval UI. |
| `channel-runtime/src/core.ts` | Distinguish historical relay from current pending, preserve binding/directory; actual settlement notices if adopted; no edit/delete API assumptions. |
| `channel/ingress.ts` | Format current CAS winner returned by the real Task API instead of confirming the attempted command. Do not change recognized commands or general control routing in this grant fix. |

Using the current typed ACP request cancellation API needs **no dependency patch or upgrade**. Existing `permission.list`, Replied, Terminated and Task Interaction response already provide the relevant public contracts. A new CLI JSON settlement event would be an explicit output-contract addition with its own consumer review; it is not a new Permission ledger event or reason to regenerate the OpenCorvus SDK. Optional movement of the helper into public SDK source changes SDK runtime packaging, unlike merely consuming an existing generated method. Root should authorize that separately if chosen. Historical indexing remains undecided and receives no new recommendation or implementation here.

## Positive checks needed before claiming closure

These are proposed protocol/backend/manual checks, not executed tests:

1. ACP: an actual pending B waits behind actual pending A; B settles from the canonical grant winner before queue head. The reader returns the precise remaining set and the wire trace contains only the correct current actionable request. A selected client result is checked against actual current pending and the real reply winner.
2. ACP: while its real RPC is open, a canonical Replied/Terminated requests cancellation of the exact JSON-RPC request. A supporting peer returns a genuine cancelled response or `-32800`; a peer returning a late selected result still maps to the already winning backend decision. Assert real original wire ids, directory and outcomes. Test non-cooperation as an explicit uncompleted client request, not a fake local pass.
3. ACP load/resume and global reconnect: current pending set and exact loaded Session identities are preserved across multiple Sessions/Projects. A transport error is the explicit error, not a denial or empty snapshot. Connection close settles original outstanding requests through the SDK.
4. CLI: real pending/current settlement produces truthful original request/decision diagnostics and the original input's terminal/idle result. Reconnect does not claim an old request is pending merely because its Asked arrived late. JSON contract changes must be reviewed by consumers, not verified with source text assertions.
5. Channel: notice routing uses actual direct/Task binding and correct Project; actual incoming human command rereads current Task interactions. In a real conflicting decision race the reply text matches the returned canonical winner, while the authoritative ledger/userInput remains the real winner's facts. No outbound channel write is authorized for this investigation.
6. Actual native ACP client and actual external channel displays remain **unverified**. A protocol fixture cannot certify their visual dismissal, accessibility, localization or third-party behavior. No UI automation or fake terminal event should be introduced to fill that gap.

This report proves present code paths and identifies the smallest current-protocol integration. It does not claim all clients support cancellation, global streams replay missed requests, raw channel notices are actionable everywhere, or that any of these candidate changes has been implemented.
