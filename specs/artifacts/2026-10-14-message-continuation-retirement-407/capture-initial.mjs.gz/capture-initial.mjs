import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import {gzipSync,gunzipSync} from 'node:zlib'
const source='.tmp-message-retirement-407',target='specs/artifacts/2026-10-14-message-continuation-retirement-407'
fs.mkdirSync(target)
const files=[]
for(const name of fs.readdirSync(source+'/root-before'))files.push({source:'root-before/'+name,destination:'root-before/'+name+'.gz'})
for(const name of ['capture-406-delivery.mjs','capture-initial.mjs'])files.push({source:name,destination:name+'.gz'})
for(const row of files){const raw=fs.readFileSync(path.join(source,row.source)),out=path.join(target,row.destination);fs.mkdirSync(path.dirname(out),{recursive:true});fs.writeFileSync(out,gzipSync(raw),{flag:'wx'});assert(gunzipSync(fs.readFileSync(out)).equals(raw));row.originalBytes=raw.length}
fs.writeFileSync(target+'/manifest.json',JSON.stringify({capturedAt:Date.now(),files,boundary:'Initial source/reader evidence only; no 407 production or runtime qualification'},null,2))
console.log(JSON.stringify({files:files.length,target}))
