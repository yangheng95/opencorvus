import fs from 'node:fs'
import path from 'node:path'
import assert from 'node:assert/strict'
import { gzipSync, gunzipSync } from 'node:zlib'
const source='.tmp-message-retirement-407'
const target='specs/artifacts/2026-10-14-message-continuation-retirement-407/audit01'
const files=[]
function exact(relative) { assert(fs.statSync(path.join(source,relative)).isFile()); files.push(relative) }
function directory(relative) {
  for(const entry of fs.readdirSync(path.join(source,relative),{withFileTypes:true})) {
    assert(!entry.isSymbolicLink())
    const next=relative+'/'+entry.name
    if(entry.isDirectory()) directory(next)
    else { assert(entry.isFile()); exact(next) }
  }
}
for(const name of ['analysis.md','grant-used-followup.md','source-manifest.json','status-before.txt','status-after.txt',
  'callers-all-repository.txt','message-callers.txt','retirement-callers.txt','grant-decision-callers.txt',
  'history-grant-used.txt','history-completed-immutability.txt','history-retire-catch.txt','history-recent.txt',
  'history-e08017392.patch','history-86fbe0bca.patch']) exact('functionality/'+name)
directory('functionality/source')
for(const name of ['question-recovery-analysis.md','ui-test-scope-analysis.md','capture.json','source-excerpts.json',
  'callers.json','history.json','source-working-diff.patch']) exact('ui/'+name)
directory('ui/ui-test-scope')
exact('capture-audit.mjs')
fs.mkdirSync(target)
const rows=[]
for(const relative of files) {
  assert(!/(^|\/)(auth\.json|models\.json|runtime|private-bundle)(\/|$)/i.test(relative))
  const raw=fs.readFileSync(path.join(source,relative)),destination=relative+'.gz'
  const out=path.join(target,destination)
  fs.mkdirSync(path.dirname(out),{recursive:true})
  fs.writeFileSync(out,gzipSync(raw),{flag:'wx'})
  assert(gunzipSync(fs.readFileSync(out)).equals(raw))
  rows.push({source:relative,destination,originalBytes:raw.length})
}
fs.writeFileSync(target+'/manifest.json',JSON.stringify({capturedAt:Date.now(),files:rows,
  boundary:'Complete frozen read-only audits and exact original source/caller/history. No runtime, Provider, UI, test or migration acceptance.'},null,2),{flag:'wx'})
console.log(JSON.stringify({files:rows.length,originalBytes:rows.reduce((n,row)=>n+row.originalBytes,0),target}))
