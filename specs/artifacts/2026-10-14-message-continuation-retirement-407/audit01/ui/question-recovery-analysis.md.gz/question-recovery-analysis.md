# 407 Question 恢复与终态交付横审（只读，后续范围建议）

## Recall / 本轮边界

用户要求持续按批次并行调查、先完整根因与影响分析落盘，再经真实桌面、正向检查、范围提交和正常同步交付。任何恢复、调度、并发或终态异常必须横审共享机制，不能按专家团、标题、最后错误或模型自述降为局部问题。Root 已完成406范围提交与正常推送；407当前主修是 **normal Ask 的 Message 完成边界退休**，由另一 agent 审核。本稿仅给 Question 后续精确方案，不实施，不与该 writer 并写。

已读当前 AGENTS、406 Recall/完整冻结调查、405 red04公开事实/live01总结、当前07-panel-reactivity、02-data、03-control、security-permission、task-control-plane。当前AGENTS新增的版本化数据迁移约束也适用；本建议优先复用现有事实，不预设新增表或修改已交付迁移。

本轮输出：`capture.json` 记录实际读取 Git 身份和时间；`source-excerpts.json` 保存37生产文件的逐行摘录；`callers.json` 保存8组完整检索；`history.json` 保存5组历史查询及404原diff；`source-working-diff.patch` 在捕获时为空。Git身份仅记录来源，不作可变源码摘要验收。本轮未运行测试、UI（User Interface，用户界面）自动化、服务、Provider、模型或浏览器，没有读取凭据，没有修改生产、spec、共享文档或提交，也没有再次委托。

## 结论

当前仍有三个相连而不能互相替代的 Question 缺口：

1. Task bootstrap只从**已经存在的Interaction行**发现Question，不能完整发现已接受但尚未物化的 Asked；随后无条件 `Question.restore` 安装空waiter和计时器，未证明原物理执行者死亡，也没有恢复原业务调用。
2. 共享 ordinary Tool 中断 writer 已写真实不可变 Tool error，却没有从其精确 Question binding 补齐同一 Request 的 infrastructure terminal。原有 `abandonRecovered` 没有生产调用者，仅公开 Session/request/time 参数也不足以自行证明中断权威。
3. Task-root存在两层准入：expiry terminalizer和后继activation/reducer/acquire。只让第一层遇活owner时跳过，不能证明第二层不会按同一到期lease重新分类或接管。

406 Permission effect物理owner修复没有改变上述Question/Task入口。404修复了接受发布/terminal-first/重连唯一事实和前端对象身份；405修复了**已存在终态事实**的历史呈现；406 U3修复了选项语义与本地焦点几何。这些成果均不能代替一次尚未发生的合法 Question terminal。

## 已有真实运行证据，准确限界

- 405 `.tmp-task-question-recovery-405/red04-facts.json`：正式0 pass /1 fail /13断言，Task `tsk_g00VXydgZ60077jrfAyu` 真实202，Question `que_g0VXydjbi00suv3952UA` 已实际物化Interaction；原Tool绑定原assistant/call和activation→lease→runtime_process，producer83728退出23并真实join，recovery65960观察原owner `dead_or_reused`。Tool结算为结构化 `ProcessExecutionInterruptedError`，原 `time.end=1791935846811`；Question/Board仍pending。第14 Board断言未运行，Board pending来自独立完整API观察。该scope不能证明source-only恢复，也不证明Task业务完成。
- 405 `live01-summary.md` 与406选定causal事实：A86572仍 `exact_live`，B68708正常同runtime bootstrap后，B的公开Question完整集合实际包含A原Request和B自己的独立control。B control自身reply200、Tool实际答案与natural stop成功；正式测试只在child exits失败，完整集合断言未运行。A答案已持久，但原Permission outcome被B抢写unknown、A后续Tool报唯一约束冲突；这部分由406 P修复，不能据此宣称Q空waiter问题已根治。该scope没抓原effect lease行，不从现在源码反填。
- 404 source-only red03的固定ID输入没有真实Tool/activation物理链，只证明接受源发现/物化边界。固定ID本身不能证明有可重入业务continuation。
- 406最终U3四页面实证是Main/Side单多选的名称、说明、焦点与真实答案，且全部闭合；不构成Question进程死亡、A2A（Agent-to-Agent，代理间协作）恢复、Task/worker/Mission终态或跨Project恢复验收。
- 405旧摘要中red01原因曾被Root纠正为未知；本稿不继承“前三失败均已有同一根因”的过宽说法。

## 当前接受事实与唯一终态

`question/index.ts:441–541`：ordinary `Question.ask` 在 `Database.immediateTransaction` 中执行可选owner admission并接受原Asked outbox。同事务的post-commit effect先安装实际pending/waiter/timer，再进入Bus发布effect；失败事务不能先留下物理pending。原Request包含id、sessionID、timeCreated、questions、可选tool binding、automatic与expiry。不能复制第二Request/schema或重造创建时间。

`Question.publicationFacts:121–214` 从 `bus_publication_outbox` 读取精确Project/Session/request的唯一Asked和至多一个真实terminal；提供原askedOccurrenceID/terminalOccurrenceID时还核对其身份。正常四种终态共用 `bus-occurrence:question-terminal:<requestID>`：

| 真实入口 | 写入事实与时间 | 后继 |
|---|---|---|
| reply | replied；用户决定时的timeResolved，原answers/optional userInput | 提交后移除本地pending，等待实际Bus retry，再resolve原Promise |
| reject | rejected；origin=operator，真实决定timeResolved | 同slot，拒绝原Promise为QuestionRejectedError |
| automatic answer timer | replied；automatic=true，原automatic.timeExpires | 真实预授权答案，不等同expiry |
| unanswered timer | expired；origin=deadline，timeExpires/timeResolved均原deadline | QuestionExpiredError；普通askAndFormat形成真实expired Tool结果 |
| ordinary Instance disposal / setup abandon | abandoned；origin=infrastructure，当前实际关闭时间 | disposal不伪造用户拒绝；A2A setup失败走原abandon |

`Bus.publishOwnedExact`验证不可变输入，不能把另一个终态的同slot冲突吞成成功。新的恢复结算应在同一writer里先读原terminal；已有用户答复/拒绝/到期/关闭先胜，返回原事实及原时间，再由已有物理waiter结算，而不是重试时换一个 `Date.now()`。

`Question.pendingSnapshotReader:706–716` 只枚举本backend当前pending，然后对每项读取原接受/terminal；它是**可实际回答的物理集合**，不是全Project历史队列，也不是终态事实源。正常Main/Side同页重连保持此合同。

## 所有生产接受与决定入口

生产直接接受搜索只有以下家族（完整行号见callers）：

- builtin `tool/question.ts` → askAndFormat，绑定真实ctx.sessionID/messageID/callID；不接受abort作为Question terminal。
- `orchestrator/interaction-tools.ts` 的question工具；`orchestrator/analyze-intent-tool.ts` 的实际澄清；两者调用同askAndFormat，仍须原Tool binding，不从工具展示名猜。
- `tool/panel.ts` 的mission/work创建前确认。Question归属于**原caller Session/Tool**；未来要创建的Mission/Work尚不能成为它的恢复owner。
- `orchestrator/tools.ts:1902` 的 `respond_agent_coordination` /ask_user：唯一直接传deterministic requestID、exact Asked occurrence、同事务action admission、原Tool binding的生产分支。

普通公开决定包括server `/question` list/reply/reject；CLI question命令只是同公开API客户端。Task API的reply/reject/userInput分支调用同Question；channel ingress的真实消息通过EngineService.replyUserInteraction回填。ACP检索没有独立Question恢复或终态writer，不能假设它另有答案队列。所有对话种类的工具都落到上述接受点，不能给LLM加工具名白名单来规避恢复。

`EngineInteraction.subscribe` 对Asked及四终态全部调用同 `projectQuestion`。`projectQuestion:399–491` 在一个事务中核真实Task lineage/Project，补原request locator和实际outcome、原userInput记忆，引用原Bus事实；原terminal-first重试不会把已答行复活。`engine/store.ts:637–762` 读取同source/terminal occurrence再投影，不是第二答案源。

Task direct control-plane activity gate不是Question，请保留它现有独立owner分支，不把其external locator喂给Question.restore。Permission同样沿原ledger，不随本Q方案改写。

## 当前恢复错误与旧路径未根治原因

`EngineInteraction.reconcileRecoveredPendingWaiters:146–235` 对全表Interaction按id分页，再在内存中以Task.project_id筛选pending。Question分支先 `projectQuestion`，若无终态便直接 `await Question.restore`；**在此之后**才查看A2A action。

`Question.restore:411–438`虽然已严格复核原Request/time/terminal，但缺少执行归属证明。不存在当前pending时它写入 `durableContinuation:true, waiters:[], timer`。这会让B公开list声称有一个可回答请求，reply200只会resolve空数组；还可能让B独立计时器争写A的终态。只过滤GET/question/UI或取消其中一个timer都不根治“谁有权恢复业务”的缺口。

历史 `git log -S 'await Question.restore'` 定位 **627146cc3（2026-08-15）** 已引入该恢复方式，并非404才引入。404 `e70e3dc55` 把旧row payload读取收敛到publicationFacts/projectQuestion，修复真实晚Asked/terminal-first与身份，但明确保留物理恢复限制；并未创造普通JS调用栈，也没有原owner检查。当前恢复扫描只认已有Interaction：即使Bus subscriber现在已注册，已经完成投递但当时没有物化owner的历史Asked也不会因普通resume而重新排队。

### 接受源分页后的最小顺序

在现有Question publication边界增加**纯原接受事实分页reader**，按精确Project + Asked event type，稳定 `(time_created, occurrence_id)` 游标，每页有界；每项输出原完整Request和askedOccurrenceID，并复用同 `publicationFacts` 读实际terminal。不能只读unfinished delivery，也不能从waiter Map补猜历史。现有index是 `(project_id,time_created)`；需要测量的SQL成本/是否需新index仍未知，不先改schema。若最终需要index，依当前版本化迁移合同另批准。

bootstrap按顺序：原accepted page → 用真实Session ancestry/Task owner调用现有唯一projectQuestion物化request/已有terminal → 对仍pending的精确业务归属分类 → 原执行恢复/已证中断结算。活owner只保留事实；不是本backend可答waiter。普通Session source不得因这个Task扫描被泛化成“所有历史Question都可答”。

删除被替换的Project-only空waiter恢复与仅为其服务的 `retainedRecoverableQuestions`宽泛承诺/A2A平行分类；如真正A2A原工具重入已足够，删除通用restore而非保留fallback wrapper。当前 `abandonRecovered`全仓生产仅定义未调用，应在新的事实验证边界内部替换/收紧，而不是暴露任意requestID/time的恢复写入口。正式测试里restore相关旧合同需逐项迁至真实事实reconcile；已terminal保真/冲突明确错误的正向合同仍需保留。

## 普通Tool中断：合法terminal和原timestamp

共享 `SessionLoop.terminalizeRecoveredIncompleteAssistant:2688–2929` 由五类caller进入：SessionLoop取得真实Prompt后普通启动、session_control compaction helper、Mission精确frontier恢复、Task-root expired activation、worker abandoned dispatch。它按顺序尝试真实A2A/dispatch恢复、已提交Tool result、panel creation、scheduled effect；剩余不可恢复Tool才写结构化interruption。**不得把Question名称当新的执行白名单**，也不得先关闭本可按原immutable事实恢复的A2A。

ordinary中断写入的原Tool outcome是 `status:error`，结构化failure含 `kind:process-execution-interrupted`、`name:ProcessExecutionInterruptedError`、原originSite和精确session/message元数据，time.end按该writer实际值提交。`Session.updatePart:2423–2449`写唯一不可变ToolPartOutcome，已有不等价outcome明确报错。这里没有Question收敛调用。

建议在Question既有source域中建立一个受事实约束的内部reconcile：输入精确Project/Session/Message/Tool-part locator，读取原不可变Tool request/outcome，再查询所有绑定同原messageID+callID的已接受Question（不能假定一个Tool最多一个Question）。验证Request owner、原Tool identity、真实结构化interruption及原执行恢复权威。不是从错误展示字符串或“最后error”猜。

- 新Tool interruption提交后调用它，使同原Question terminal立即可投影。
- 先读取已提交outcome后进入一个immediate writer，重新核对同Request/outcome/source及已有Question terminal；仅在无terminal且普通不可恢复调用已合法中断时发布同slot `question.abandoned`，origin=infrastructure，**timeResolved必须是原Tool outcome.time.end**。不要使用recovery扫描时间、当前时间、lease到期本身或模型文本。
- 回放也必须覆盖“Tool outcome已commit，Question terminal前crash”：source-first分页重检同Tool outcome可补同一个terminal，不能只挂一次内存postcommit effect。
- 已有terminal先胜，保留真实answers/userInput/time；Bus发布/outcome重试仍原occurrence。缺物理死亡或缺合法Tool绑定，不生成Abandoned，不恢复空Promise，返回明确诊断和原事实。

如果实现只在新Tool update处补通知，却仍只扫描incomplete Message，会漏掉已completed Message的中断后cut；因此历史repair必须从accepted source/immutable outcome进入。既有Tool.end等于lease expiry的red04是原存储事实，Question应复用该合法已写值，不把相等当作物理死亡证据。

## Task活owner保护必须覆盖两层

**第一层：终态写入。** `task-root-ingress-delivery.ts:992–1052`仅找expires_at≤now的activation及未完成assistant，拿lease.expiresAt作completedAt，再调用共享terminalizer。现代码没读该lease原owner_occurrence_id的runtime_process/OS（Operating System，操作系统）身份。活owner暂停心跳/挂Question时过期不等于死。应复用已成熟 `observeProcessLiveness`，在事务外观察原exact lease.owner的物理receipt，再在writer边界复核same lease/activation/message；exact_live、unknown_live、缺opaque receipt均不授予中断，需明确重查/诊断。

**第二层：后继准入。** 同扫描1868后紧接 `projectTaskRootIngress`；reducer383只把未过期且未consumed的lease当leased，402按到期允许unknown activity分类。后续activate入口1075再次project，`acquireTaskRootIngressLease`唯一生产调用在1103，fact-store432/445又在writer中reduce当前和前序ingress，然后调用acquire/supersede。只在第一层skip不能保证这些后继入口不把活owner的过期lease当可推进事实。

后续方案必须明确：同exact prior activation未完成且owner仍活/未知时，扫描与最终acquire均停在原owner、安排已有driver heartbeat复查；到期只影响写fence，不产生物理死亡。不能绕过公共reducer/acquire而只做一次外层if。OS观察不可置于SQLite writer中；外部观察携带原lease/receipt身份，writer必须CAS（Compare-and-Set，比较并交换）复核。若原activation已由真实immutable completion/effect facts消费，则后继照原合同推进，不把仍运行的整个backend当作旧业务仍活。

当前还存在 `projectTaskRootIngress`诊断调用、前序FIFO归约和fact-store其他resolve路径。是否在现有事实reader/类型中提供有界物理观察，还是由两个明确写入口传入同一验证结果，需要Root在下一规格精确批准；不能新增一套“活owner缓存状态”或给过期lease伪续期。新增状态/公开projection枚举若必要，须先列消费者，不隐式承诺本稿已有可直接落地的六文件限制。

## 各执行轮次与并发横面

| 场景 | 当前权威与后续要求 |
|---|---|
| ordinary Main/Global Chat/Work/独立Side/non-Task child | Request.tool原Message/call；SessionPromptOwner保护真实Prompt。保留404物理pending+mandatory snapshot，不把新Project扫描扩成全局restore。正常有主时reply/reject保持原200/Tool结果。 |
| Task root普通Question | 原Message.activationID→exact task_root_ingress lease→owner_occurrence_id→runtime_process→OS；需上述两层保护。Task epoch/reopen/cancel/deleted仍由现有lifecycle事实决定，不用最新Task owner代替旧activation。 |
| Task worker | 原Tool/Message、WorkerTurnDescriptor、dispatch lineage与dispatch_admission。`dispatchDeliveryOwnerRecheckAt:1640`已有本进程registry与外部OS区分；`recordAbandonedDispatchSettlement:1680`才调用terminalizer。不得用该Session最新dispatch替旧调用。 |
| A2A ask_user | `respond_agent_coordination`原action/epoch/response/request和exact Tool，恢复重入原工具，原acceptanceEffects在同事务核action。保留真实pending或已有terminal；普通fixedID不等于A2A。 |
| Mission | `recoverMissionProcessSession`先lifecycle lease、原opened closure、exact dead Prompt/frontier与持久wake，再shared terminalizer。generic Session恢复不能先抢走它的dead owner证据。 |
| panel创建前确认 | Question属于原caller，不能借目标Mission/Work创建合同恢复原问答。 |
| 串行/同Tool多问/多请求 | 按原Request ID与真实Tool binding分别结算，保留原Question时序；不能以一个Session当前状态清掉全部Question。 |
| 并行/双backend | 本地waiter只本owner；源事实可被另一backend物化，但不授予回复Promise或timer。真实terminal同slot原子胜出；不得吞冲突或覆盖用户答案。 |
| 重试/重启 | 已terminal先投影；Tool-commit→Question-terminal cut由原source/outcome重扫补齐；A2A用sameaction重入；source-only不造可答Promise。 |
| 多Project | source SQL先project_id限定，Session完整durable ancestry和Task Project双核；当前全Interaction扫描后过滤成本不能冒称有界Project扫描。sharedruntime不同Project必须真实检查，无复制Question ID/任意directory路由。 |

## UI与公开传输：能交付什么，缺什么

| 当前消费者 | 唯一事实/行为 | 不能宣称 |
|---|---|---|
| Task Board冷/暖 | EngineInteraction→同source/outcome→Board.interactions；interaction.requested/resolved更新树；已有完整Board validator保持 | Tool error本身不会自动等价Question expired；不能从标题判断已解决 |
| Main standalone暖事件 | `handleStandaloneQuestion`接Asked和四terminal，strict adapter校验原Session/time/orderKey/origin；同原Request变resolved对象，request/response稳定phase历史 | 缺terminal时不能先隐藏为已完成；error不能做UI fallback |
| Main connected | mandatory pendingQuestions+Permissions一次reconcile，完整immutable Request复用owner；canonical absence移除pending而不造terminal，已获terminal历史保留 | Map移除不是一条新infrastructure事实 |
| Dialog | 从同card parts取pending，真实terminal/absence使其自然退出；组件草稿仍属当前原Request owner | 不能另设关闭状态来掩盖后端pending |
| Side | exact独立Session pending；四terminal先strict校验再删卡；connected同原Question复用，完成内容来自真实Message/Tool transcript | 当前Side没有独立resolved Question历史数组，不能宣传与Task冷历史完全一致 |
| Main standalone冷打开 | `/conversation`的pending只当前物理集合；`sessionConversationExecutionEvents`仅agent.execution.lifecycle；正常消息/Tool由transcript恢复 | 单独Question request/response历史并未由该冷hydrate完整重放。此代码边界尚未新实页，不据此扩当前407范围 |

405的 `interactionToCardSeeds` 为真实resolved Question创建原ID的request/response phase；CardParts用reactive本地化文本区分deadline/infrastructure/skip/answer，unknown origin报明确契约错误。空header在standalone用已有本地化Question标题；**Task `projectQuestion`及store目前仍有固定英文“Question” producer**，属于已知标题边界，不能说406 U3解决了整个Task语言。

Backend补出原合法terminal后，上述暖消费者和Task cold路径不需新SDK或前端状态。Standalone冷Question历史是否要变成正式产品合同，需要单独设计同源历史查询/传输并实页；不在本Q恢复修复里偷偷增加兼容字段、隐藏消息或手工重放。

## 最小后续实施切面与验收建议（尚未授权）

核心必需路径：`question/index.ts`（accepted页reader、同原Tool事实的terminal writer与移除unbound restore）；`engine/interaction.ts`（source-first物化、删除空waiter与平行A2A恢复分类）；`session/loop.ts`（合法ordinary Tool interruption后的同事实reconcile及已committed cut）；`engine/task-root-ingress-delivery.ts`（exact owner观察及入口准入）；`engine/task-root-fact-store.ts`，并可能 `task-root-ingress-reducer.ts` 的当前事实/归约合同以保护第二层。这里的“可能”必须先补精确调用和公共类型方案，不能先加新状态。

原则上不需要UI/SDK/schema变化；不改407正在实施的normal Ask Message退休writer，不重构generic Bus/Prompt/Mission/process primitive。若shared Session writer必须新增事务内钩子才能保持所需原子性，应先说明与407同文件/边界的冲突，等其冻结后另批准，不能并行改同语义终态。

现有正式checker可复用但本轮未运行：question-publication-projection.test.ts（Asked可见、terminal-first、reply/reject/expiry/abandon原事实及冲突）；question-process-recovery.test.ts（已提交reply的真实进程恢复）；question-process-projection.test.ts（ordinary无本地reply owner的404和实际新control全集）；task-root-ingress-reducer.test.ts；mission-process-recovery.test.ts/driver；agent-coordination-immutable-facts.test.ts；scheduler-tool-recovery与session/tool-result-recovery系。不能把现有普通Session reply404正向合同硬改成空waiter200。

后续正式阳性矩阵必须真实证明：

1. 原red04 public Task/合法profile/流式工具真实owner死后，同Tool immutable interruption→同Question infrastructure terminal→Board同Request/timeResolved=原Tool.end，原Asked/答案赢家/Project保持。
2. source-only已接受Asked先物化，无Tool权威返回明确未能恢复原因；有真实A2A action则exact工具重入可答，原expiry/time/input不变。不能让固定ID fixture假装普通业务续行。
3. 双backend同Project：A原alive Question+真实Tool仍由A回复完成，B独立control真实完成；完整公开pending集合体现当前物理owner；A既有Question与Permission结果都正常结算。另真实多Project串/并行隔离。
4. 活/unknown Task activation过期：真实读取旧owner与exact activation，第一层不写假interruption，第二层仍原owner不产生后继；实际dead再进入合法恢复。不能只测试纯reducer常量而称OS通过。
5. Tool outcome提交后crash-before-terminal、terminal提交后crash-before-projection、terminal先到/Asked重试，均保留同原terminal/time/userInput，不造第二source；已完成Message也能补齐前一种cut。
6. 真实A2A/worker/Mission/reopen/cancel路径各按原occurrence验证。未跑的格明确未满足，不用单Task通过推全系。
7. Root新的真实桌面Main/Dialog/Side/Task页检查实际pending→对应terminal、历史原time和中英文，无DOM/渲染/文案/像素自动化。普通UI选项U3成功不替后端恢复格。

检索发现已有 `packages/overlay/test/tree-writer-incremental-projection.test.ts`、`tree-writer-review-stream.test.ts`、`projection-prerequisite-recovery.test.ts` 使用requestAnimationFrame桩并断言卡片投影；另 `tree-writer-message-facts.test.ts`、pure event-policy/transport和type-only导入也命中。这些路径均未运行，不把它们当视觉证明；如后续触及其UI投影自动化范围，应按AGENTS删除对应测试/专用fixture而非更新UI断言。当前只读范围不擅自删除它们或扩大清理。

## 未知与明确未满足

本轮没有新的OS恢复、数据库写入、正式checker、模型或真实页面结果。accepted分页量级/SQL成本尚未benchmark；新的双层Task liveness输入如何贯穿reducer/最终writer尚待精确设计。缺/opaque原physical receipt不能猜死；没有Tool/真正continuation的source-onlyRequest不能伪可答。跨backend operator选择一个仅拥有Board事实但无Promise的backend，当前reply路由不会自动转发给A；本方案不新增路由旁路，该用户可操作性边界需要独立明确合同。Standalone冷终态历史、Task空header固定英文、基础设施终态实际视觉均不因本稿变成已通过。
