import { afterAll, beforeAll, beforeEach, expect, test } from "bun:test"
import {
  applyEvent,
  commitPreparedConversationView,
  prepareConversationView,
  projectedConversationMessageFacts,
  projectedConversationPartSnapshot,
  ingestPersistedConversationMessage,
  resetWriter,
} from "../src/services/tree-writer"
import { cardTreeStore, publishedCardTreeVersion } from "../src/store/card-tree"
import { getLocale, setLocaleData } from "../src/utils/i18n"
import english from "../src/i18n/en-US.json"
import chinese from "../src/i18n/zh-CN.json"

const originalFrame = globalThis.requestAnimationFrame
const originalCancelFrame = globalThis.cancelAnimationFrame
let sequence = 0
const frames = new Map<number, FrameRequestCallback>()
beforeAll(() => {
  setLocaleData(getLocale(), getLocale() === "zh-CN" ? chinese : english)
  globalThis.requestAnimationFrame = (callback) => {
    frames.set(++sequence, callback)
    return sequence
  }
  globalThis.cancelAnimationFrame = (id) => { frames.delete(id) }
})
afterAll(() => {
  if (originalFrame) globalThis.requestAnimationFrame = originalFrame
  else Reflect.deleteProperty(globalThis, "requestAnimationFrame")
  if (originalCancelFrame) globalThis.cancelAnimationFrame = originalCancelFrame
  else Reflect.deleteProperty(globalThis, "cancelAnimationFrame")
})
function settlePublication() {
  while (frames.size) {
    const callbacks = [...frames.values()]
    frames.clear()
    for (const callback of callbacks) callback(0)
  }
}
beforeEach(() => {
  resetWriter({ cause: "message-facts-data-contract" })
  settlePublication()
})
function info(id: string, sessionID = "ses_facts", created = 1000) {
  return {
    id, sessionID, role: "assistant", author: "assistant", agent: "assistant",
    agentID: "assistant", sessionAgentID: "assistant", resolvedRole: "assistant",
    channel: "assistant", originSource: "", parentSessionID: "", parentID: "msg_input",
    orderKey: `v1:${String(created).padStart(16, "0")}:0000000000000030:0000000000000000:message:${id}`,
    time: { created },
  }
}
function update(message: Omit<ReturnType<typeof info>, "time"> & { time: { created: number; completed?: number } } & Record<string, unknown>) {
  applyEvent({ type: "message.updated", orderKey: message.orderKey, properties: { info: message } })
}

test("live snapshots preserve all intervening canonical messages and actual qualification facts", () => {
  const accepted = ["msg_input"]
  update({ ...info("msg_edit"), acceptedInputMessageIDs: accepted, time: { created: 1000, completed: 1100 }, finish: "tool-calls" })
  update({ ...info("msg_read", "ses_facts", 1200), acceptedInputMessageIDs: ["msg_input"], finish: "stop", error: { name: "SessionError" } })
  update(info("msg_other", "ses_other", 1300))
  accepted.push("external_mutation")
  const facts = projectedConversationMessageFacts(["ses_facts", "ses_facts"])
  expect(facts.map((fact) => fact.id)).toEqual(["msg_edit", "msg_read"])
  expect(facts[0]).toEqual({
    id: "msg_edit", sessionID: "ses_facts", sessionAgentID: "assistant", agentID: "assistant",
    role: "assistant", orderKey: info("msg_edit").orderKey, time: 1000,
    acceptedInputMessageIDs: ["msg_input"], completed: 1100, finish: "tool-calls", hasError: false,
    stepParts: undefined, toolParts: undefined,
  })
  expect(facts[1].hasError).toBe(true)
  const copiedIDs = facts[0].acceptedInputMessageIDs as string[]
  copiedIDs.push("snapshot_mutation")
  expect(projectedConversationMessageFacts(["ses_facts"])[0].acceptedInputMessageIDs).toEqual(["msg_input"])
  expect(projectedConversationMessageFacts(["ses_other"])[0].id).toBe("msg_other")
})

test("metadata-only completion is published by the existing visible revision", () => {
  update(info("msg_pending"))
  settlePublication()
  const initialVersion = publishedCardTreeVersion()
  expect(projectedConversationMessageFacts(["ses_facts"])[0]).toMatchObject({ completed: undefined, acceptedInputMessageIDs: undefined, hasError: false })
  update({ ...info("msg_pending"), time: { created: 1000, completed: 1500 }, acceptedInputMessageIDs: [], finish: "stop" })
  settlePublication()
  expect(publishedCardTreeVersion()).toBeGreaterThan(initialVersion)
  expect(projectedConversationMessageFacts(["ses_facts"])[0]).toMatchObject({ completed: 1500, acceptedInputMessageIDs: [], finish: "stop", hasError: false })
})

test("history hydration supplies the same actual facts through its existing adapter", () => {
  const message = { ...info("msg_history"), acceptedInputMessageIDs: ["msg_input"], time: { created: 1000, completed: 1700 }, finish: "tool-calls" }
  const view = {
    messages: [{ messageID: message.id, inputMessageID: "msg_input", sessionID: message.sessionID, sessionAgentID: "assistant", agentID: "assistant", stage: "assistant", parentSessionID: "", orderKey: message.orderKey, time: 1000 }],
    sessions: [{ sessionID: message.sessionID, agentID: "assistant", messageIDs: [message.id] }],
  }
  commitPreparedConversationView(prepareConversationView(view, [{ info: message, parts: [] }]))
  settlePublication()
  expect(projectedConversationMessageFacts(["ses_facts"])[0]).toMatchObject({ id: "msg_history", acceptedInputMessageIDs: ["msg_input"], completed: 1700, finish: "tool-calls", hasError: false })
})

function part(message: ReturnType<typeof info>, id: string, type: string, time: number, extra: Record<string, unknown> = {}) {
  return { id, type, sessionID: message.sessionID, messageID: message.id,
    orderKey: `v1:${String(time).padStart(16, "0")}:0000000000000031:0000000000000000:part:${id}`, ...extra }
}
function partUpdate(message: ReturnType<typeof info>, value: ReturnType<typeof part>) {
  applyEvent({ type: "message.part.updated", orderKey: message.orderKey, properties: { ...message, part: value } })
}

test("step-first pending facts promote and preserve actual whole-message Tool membership", () => {
  const message = info("msg_steps")
  const start = part(message, "prt_start", "step-start", 1010)
  partUpdate(message, start)
  update({ ...message, acceptedInputMessageIDs: ["msg_input"] })
  const edit = part(message, "prt_edit", "tool", 1020, { tool: "edit", state: { status: "completed", time: { start: 1021, end: 1030 }, metadata: {} } })
  partUpdate(message, edit)
  partUpdate(message, edit)
  partUpdate(message, part(message, "prt_read", "tool", 1035, { tool: "read", state: { status: "completed", time: { start: 1036, end: 1040 }, metadata: {} } }))
  partUpdate(message, part(message, "prt_finish", "step-finish", 1050, { reason: "tool-calls" }))
  update({ ...message, acceptedInputMessageIDs: ["msg_input"], time: { created: 1000, completed: 1060 }, finish: "tool-calls" })
  settlePublication()
  const fact = projectedConversationMessageFacts([message.sessionID])[0]
  expect(fact.stepParts).toEqual([
    { id: "prt_start", orderKey: start.orderKey, type: "step-start", reason: undefined },
    { id: "prt_finish", orderKey: part(message, "prt_finish", "step-finish", 1050).orderKey, type: "step-finish", reason: "tool-calls" },
  ])
  expect(fact.toolParts?.map((tool) => ({ id: tool.id, tool: tool.tool, status: tool.status }))).toEqual([
    { id: "prt_edit", tool: "edit", status: "completed" }, { id: "prt_read", tool: "read", status: "completed" },
  ])
  expect(fact.completed).toBe(1060)
  expect(fact.toolParts?.[0].end).toBe(1030)
  const copiedFinish = fact.stepParts![1] as { id: string }
  copiedFinish.id = "external-copy-change"
  expect(projectedConversationMessageFacts([message.sessionID])[0].stepParts?.[1]).toEqual({
    id: "prt_finish", orderKey: part(message, "prt_finish", "step-finish", 1050).orderKey,
    type: "step-finish", reason: "tool-calls",
  })
  applyEvent({ type: "message.part.removed", properties: { sessionID: message.sessionID, messageID: message.id, partID: "prt_start", partType: "step-start" } })
  settlePublication()
  expect(projectedConversationMessageFacts([message.sessionID])[0].stepParts?.map((step) => step.id)).toEqual(["prt_finish"])
})

test("moved authoritative bundle supplies its current exact owner and replaces observed Parts", () => {
  const original = info("msg_move")
  update(original)
  partUpdate(original, part(original, "prt_old", "step-start", 1010))
  const moved = info("msg_move", "ses_target")
  const end = part(moved, "prt_target_finish", "step-finish", 1100, { reason: "stop" })
  applyEvent({ type: "message.moved", orderKey: moved.orderKey, properties: { sourceSessionID: original.sessionID, info: moved, parts: [end] } })
  settlePublication()
  expect(projectedConversationMessageFacts([original.sessionID, moved.sessionID]).map((fact) => ({ id: fact.id, sessionID: fact.sessionID, steps: fact.stepParts?.map((step) => step.id), tools: fact.toolParts }))).toEqual([
    { id: moved.id, sessionID: moved.sessionID, steps: ["prt_target_finish"], tools: [] },
  ])
})

test("full history retains an actual nondisplay intervening message and empty Tool bundle", () => {
  const message = info("msg_control")
  const control = part(message, "prt_control", "step-start", 1010)
  const view = { messages: [], sessions: [{ sessionID: message.sessionID, agentID: "assistant", messageIDs: [message.id] }] }
  commitPreparedConversationView(prepareConversationView(view, [{ info: message, parts: [control] }]))
  settlePublication()
  expect(projectedConversationMessageFacts([message.sessionID])[0]).toMatchObject({
    id: message.id, agentID: "assistant", toolParts: [], stepParts: [{ id: control.id, orderKey: control.orderKey, type: "step-start", reason: undefined }],
  })
})

test("history coverage and actor integrity have precise preparation errors", () => {
  const message = info("msg_missing")
  const view = { messages: [], sessions: [{ sessionID: message.sessionID, agentID: "assistant", messageIDs: [message.id] }] }
  expect(() => prepareConversationView(view, [])).toThrow("expected message msg_missing missing matching transcript payload")
  expect(() => prepareConversationView(view, [{ info: { ...message, sessionAgentID: "" }, parts: [] }])).toThrow("message msg_missing missing canonical session actor")
})

test("retained Part identity and Session drift produce explicit integrity errors", () => {
  const message = info("msg_identity")
  update(message)
  const start = part(message, "prt_identity", "step-start", 1010)
  partUpdate(message, start)
  expect(() => partUpdate(message, part(message, "prt_identity", "step-start", 1020))).toThrow("identity drift")
  expect(() => update(info(message.id, "ses_wrong"))).toThrow("Session owner drift")
})

function preparedBundle(message: ReturnType<typeof info>, parts: ReturnType<typeof part>[], display: boolean) {
  const view = {
    messages: display ? [{ messageID: message.id, inputMessageID: "msg_input", sessionID: message.sessionID, sessionAgentID: "assistant", agentID: "assistant", stage: "assistant", parentSessionID: "", orderKey: message.orderKey, time: message.time.created }] : [],
    sessions: [{ sessionID: message.sessionID, agentID: "assistant", messageIDs: [message.id] }],
  }
  return prepareConversationView(view, [{ info: message, parts }])
}

test("authoritative replay retires the incoming display member while retaining shared-card and older members", () => {
  const older = info("msg_older", "ses_facts", 900)
  const current = info("msg_replay", "ses_facts", 1000)
  const peer = info("msg_peer", "ses_facts", 1100)
  for (const message of [older, current, peer]) {
    ingestPersistedConversationMessage({ info: message, parts: [part(message, `prt_${message.id}`, "text", message.time.created + 1, { text: message.id })] })
  }
  const control = part(current, "prt_replay_control", "step-start", 1001)
  commitPreparedConversationView(preparedBundle(current, [control], false))
  settlePublication()
  expect(projectedConversationMessageFacts([current.sessionID]).map((fact) => fact.id).sort()).toEqual([older.id, current.id, peer.id].sort())
  expect(projectedConversationMessageFacts([current.sessionID]).find((fact) => fact.id === current.id)).toMatchObject({ toolParts: [], stepParts: [{ id: control.id, orderKey: control.orderKey, type: "step-start", reason: undefined }] })
  expect(projectedConversationPartSnapshot(peer.sessionID, `prt_${peer.id}`)?.text).toBe(peer.id)
  expect(projectedConversationPartSnapshot(older.sessionID, `prt_${older.id}`)?.text).toBe(older.id)
  const actualTexts = () => Object.values(cardTreeStore.cards).flatMap((card) => card.parts ?? [])
    .filter((value) => value.type === "text").map((value) => ({ id: value.id, text: value.text })).sort((a, b) => a.id.localeCompare(b.id))
  expect(actualTexts()).toEqual([{ id: `prt_${older.id}`, text: older.id }, { id: `prt_${peer.id}`, text: peer.id }])
  const replacement = part(current, "prt_replay_current", "text", 1002, { text: "current replacement" })
  commitPreparedConversationView(preparedBundle(current, [replacement], true))
  settlePublication()
  expect(projectedConversationPartSnapshot(current.sessionID, replacement.id)?.text).toBe("current replacement")
  expect(projectedConversationMessageFacts([current.sessionID]).find((fact) => fact.id === current.id)).toMatchObject({ stepParts: [], toolParts: [] })
  expect(projectedConversationPartSnapshot(peer.sessionID, `prt_${peer.id}`)?.text).toBe(peer.id)
  expect(actualTexts()).toEqual([
    { id: `prt_${older.id}`, text: older.id }, { id: `prt_${peer.id}`, text: peer.id },
    { id: replacement.id, text: "current replacement" },
  ].sort((a, b) => a.id.localeCompare(b.id)))
})

test("single persisted full bundle replaces current facts and validates owner before mutation", () => {
  const message = info("msg_single")
  ingestPersistedConversationMessage({ info: message, parts: [part(message, "prt_single_start", "step-start", 1001)] })
  ingestPersistedConversationMessage({ info: message, parts: [part(message, "prt_single_text", "text", 1002, { text: "fresh single bundle" })] })
  expect(projectedConversationMessageFacts([message.sessionID])[0]).toMatchObject({ stepParts: [], toolParts: [] })
  expect(projectedConversationPartSnapshot(message.sessionID, "prt_single_text")?.text).toBe("fresh single bundle")
  const wrong = info(message.id, "ses_wrong")
  expect(() => ingestPersistedConversationMessage({ info: wrong, parts: [] })).toThrow("current Session owner mismatch")
  expect(projectedConversationPartSnapshot(message.sessionID, "prt_single_text")?.text).toBe("fresh single bundle")
})

test("retained control removal validates its actual Message and Part type", () => {
  const message = info("msg_control_remove")
  update(message)
  partUpdate(message, part(message, "prt_remove", "step-start", 1010))
  expect(() => applyEvent({ type: "message.part.removed", properties: { sessionID: message.sessionID, messageID: "msg_wrong", partID: "prt_remove", partType: "step-start" } })).toThrow("retained owner/type mismatch")
  expect(projectedConversationMessageFacts([message.sessionID])[0].stepParts?.[0].type).toBe("step-start")
})

test("removal and reset expose the current canonical session membership", () => {
  update(info("msg_first"))
  update(info("msg_second", "ses_facts", 2000))
  applyEvent({ type: "message.removed", properties: { sessionID: "ses_facts", messageID: "msg_first" } })
  settlePublication()
  expect(projectedConversationMessageFacts(["ses_facts"]).map((fact) => fact.id)).toEqual(["msg_second"])
  resetWriter({ cause: "message-facts-new-selection" })
  update(info("msg_new", "ses_new", 3000))
  settlePublication()
  expect(projectedConversationMessageFacts(["ses_facts", "ses_new"]).map((fact) => fact.id)).toEqual(["msg_new"])
})
