# 407：四个既有测试的精确分类与删除边界（只读）

## 状态与结论

本稿按Root新增限制复核：**不能仅删除card-store断言，却继续保留RAF（requestAnimationFrame，浏览器动画帧）/paint fixture和实际卡片投影过程。** 我先前“保留两混合文件大部分数据断言”的初步建议因此撤回。以下为最终只读建议，未运行或修改任何测试、生产、spec或配置。

最小建议：整文件删除 `tree-writer-incremental-projection.test.ts`、`tree-writer-review-stream.test.ts`；另外两个文件删除所有投影/绘制fixture及依赖它们的用例。只可保留两条**在投影发生前结束的原错误合同**：

1. `projection-prerequisite-recovery.test.ts` 原第二例中的 **missing Session** 子例：真实 `message.removed` 输入在首次 `requireSessionProjection` 即抛结构化错误；保留其type guard、诊断文字可变、eventType/entity/id/sessionID检查。原Message/Part两子例及整个首例都需先创建卡片，删除。
2. `tree-writer-message-facts.test.ts:166–171` 原 `history coverage and actor integrity have precise preparation errors`：直接调用纯准备函数，两条原输入分别返回明确覆盖/actor错误，在任何commit、全局writer写入或卡片投影前结束。

此建议使原19个 `test()` 定义缩减为2个错误合同（第二文件原复合用例同时缩小到一个子例）。不会新增数据层、test hook、host旁路或替代renderer；不为保留旧测试抽取生产实现。若Root选择整删四文件，实际损失是上述两条仍可合法独立保留的错误合同，而不是消除更多UI运行依赖。

## 原源、搜索与捕获

`ui-test-scope/original/` 保存四个原文件完整字节；`original-sources.json` 保存全行号、全部imports与test声明；`capture.json`保存实际HEAD、各文件最后Git提交及原字节数。这些身份只定位原源，不是hash门槛。`original-working-diff.patch`在捕获时为空。

| 原文件（均在packages/overlay/test） | 原行数 | 原用例数 |
|---|---:|---:|
| tree-writer-incremental-projection.test.ts |239|3|
| tree-writer-review-stream.test.ts |87|2|
| projection-prerequisite-recovery.test.ts |208|2|
| tree-writer-message-facts.test.ts |248|12|

`reference-queries.json`保存完整tracked Git grep、非ignored工作区rg、四文件imports/fixture/IO检索、通用runner引用及数据API生产消费者；`dependency-excerpts.json`和补充`projection-call-chain.json`保存实际调用链。没有以测试文件名或import位置直接判UI性质。

## 为什么删除直接断言还不够

实际调用链（行号来自捕获原源）：

- `tree-writer.resetWriter:595–635`清理数据Map时还会替换cardTreeOrder、删除cardTreeStore.cards、flushCardStats并调用可见发布。`store/card-tree.ts:363–370`的发布直接调用RAF。因此混合文件的beforeEach/afterEach并非纯数据清理。
- `applyEvent:916–920`把message updated/part updated/removed交给 `applyVisibleCardTreeEvent`；该函数先执行handler，再scheduleCardTreeDisplayAggregates。
- `handleMessageUpdated:1117–1245`除了写Message索引，还调用 `ensureMessageTurnProjection`、状态投影、regroup/hierarchy；普通update fixture不可能只填canonical Map。
- `ingestPersistedConversationMessage:970–995`经 `applyVisibleCardTreeEvent(handleMessageUpdated)`及 `projectPersistedConversationPart`；不是一个数据专用入口。
- `commitPreparedConversationView:3479–3625`实际ensureMessageTurnProjection/upsertPart、重建层级、flushStats、可见发布；即使该次输入只有metadata，结尾仍走卡片投影/发布。
- `projectedConversationMessageFacts:722–747`本身复制原Message/step/Tool字段，具有真实数据消费者（file-change-summary）；但测试先用上列UI writer建状态，**getter的数据性不能使fixture变成非UI**。
- `projectedConversationPartSnapshot:750–758`更直接经partIndex定位cardTreeStore.cards的parts。其名称不是截图snapshot，但当前producer仍是卡片投影。
- `hostSchedulesFrames`在无RAF时令display aggregate同步结算；利用这个分支只是不模拟帧，仍然运行卡片投影。故不能把“删RAF桩后调用相同writer”称为满足不投影要求。
- `settlePublication()`手工反复执行帧callback就是paint fixture；i18n初始化为执行呈现路径准备正文，不是canonical字段/error合同所需。保留这些初始化不能用“未断言页面”解释为非UI。

## 逐文件/逐用例分类

### 1. tree-writer-incremental-projection.test.ts：整删239行

| 原起始行 | 实际断言 | 分类/删除影响 |
|---:|---|---|
|136|card.parts数组身份、重写/未重写card数、text/boundary在card内次序|UI增量卡片重用与显示分段；整例删除。其核心“其它card不变”也不应继续作负向UI门槛。|
|183|part-first事件生成的卡片parts序列|输入形状来自协议，但输出是UI卡片，仍是UI自动化；整例删除。|
|206|手工paint逐帧与合帧后的cardSnapshot：status/stage/orderKey/parts/subtreeCounts|明确绘制投影snapshot；整例删除。|

全部内部fixture（messageInfo/messageUpdated/partUpdated、projectedCards、partSignature、cardSnapshot、paint、frames、RAF/取消RAF覆写及reset hooks）只服务这三例，与整文件一起删除。该文件不export helper，不存在需要迁移给其他测试的公共fixture。

### 2. tree-writer-review-stream.test.ts：整删87行

| 原起始行 | 实际断言 | 分类/删除影响 |
|---:|---|---|
|33|review.stream.started生成integrity card的stage/agent/session/status|UI卡片投影。注释“来自真实wire shape”不等于验证后端publisher/HTTP传输；只有人工事件fixture。|
|56|review.stream.chunk在card.parts生成reasoning且拼接文本|UI reasoning内容投影；整例删除。|

同文件inline IDs/orderKey/RAF/reset都是专用fixture，整体删除。不删除实际review事件schema、后端writer或共享tree-writer。现有两例也没有实际启动后端，删后不能声称后端协议失去了两个端到端检查。

### 3. projection-prerequisite-recovery.test.ts：不能保留原recovery集成流程

原首例90–155在三个场景中调用 `routeSSEEvent`，确有值得保留的局部传输意图（recoverConversation参数与accepted taskSequence7）。但是其recovery stub调用 `projectConversation()`，其setup调用selectedTask/setBoardStore，实际执行message/part卡片投影；最后还断言cardID/part。只去掉最后两个字段不满足新限制。**整首例删除**，连同 `projectConversation`、selectedTask、scheduler stub、RAF hooks、afterEach reset和所有相应imports/常量删除。不能另stub writer来伪造同一路由恢复结果。

原第二例157–208包含三个错误来源：

- missing Session：`applyEvent(message.removed)` → `handleMessageRemoved:1702` → `requireSessionProjection:792`。由于该唯一test文件在既有package runner的独立进程启动，writer私有Map初始为空；该调用在第一个require即抛错，没有card mutation。`applyVisibleCardTreeEvent`的handler抛出后不会到其后schedule函数。此路径可以保留，**不调用resetWriter，不安装RAF，不设置board，不调用projectConversation**。
- missing Message / missing Part：原测试先projectConversation建立实际card/partIndex；没有现成独立数据准入能维持其当前实际producer含义。删除这两子例，不能改成手造Error后宣称验证了producer。

最小留下：Bun `expect/test`、原 `ProjectionPrerequisiteError/applyEvent/isProjectionPrerequisiteError` imports、该missing Session输入需要的两个ID常量、原try/catch、类型guard和修改diagnostic prose后仍识别的断言，以及原四字段expected对象。删除原第二例的reset/创建Message/Part及两条expected记录；标题需如实改为只覆盖missing Session structured protocol。这是保留原实际输入→明确错误的子合同，不是新constructor-only旁路。

不应保留taskID、orderKey、boardStore、cardTreeStore、SelectedTaskRecoveryScheduler、RAF保存/覆写/还原、before/after hooks。上述元素都只服务被删投影路径。

删除损失明确：原三种projection缺口到recovery调度的集成检查、missing Message/Part producer错误来源不再由此文件自动验证。不要把剩下一例标为整个Session/Message/Part恢复协议通过；真正状态恢复应在Root实际页面与后端/transport正式合同中按当前授权验收。

### 4. tree-writer-message-facts.test.ts：仅保留166–171纯准备错误case

| 原起始行 | 当前核心合同 | 最终分类 |
|---:|---|---|
|58|live Message字段、acceptedInput副本/Session范围|数据assert有价值，但由applyEvent真实建卡；删除原例。|
|79|metadata completion + visibleVersion|可见发布断言明确UI，且setup/update建卡；整例删除，不仅删version两行。|
|90|history commit后Message字段|commit会重建卡树；删除。|
|109|part-first step/Tool membership、副本/移除|applyEvent/partIndex/display producer；删除。|
|142|message.moved后owner/Part全集|actual writer包含退休/重建可见卡；删除。|
|155|nondisplay消息和空Tool bundle|虽然输入无显示正文，commit结尾仍regroup/rebuild/flush/publish；删除。|
|166|缺transcript匹配；缺canonical actor的prepare错误|**保留原完整case及两断言**。|
|173|保留Part ID与Session漂移错误|先update/partUpdate建卡；不能独立保留原producer含义；删除。|
|190|authoritative replay共享card/older members及Part数据|包含actualTexts卡片数组断言；去掉它仍运行commit/ingest投影；整例删除。|
|219|single bundle替换与owner错误|ingest实际建卡；删除。|
|230|control removal owner/type错误|setup运行actual writer和可见发布；删除。|
|238|removal/reset后Session membership|reset与applyEvent运行UI树；删除。|

纯准备例的独立性有明确源码依据：`prepareConversationView:3298–3473`只建局部Map/Set和准备对象。第一条输入在session membership loop读取不到transcript时即抛明确错误（约3347）；第二条在读取metadata-only原info时因空sessionAgentID抛错（约3362）。这两路径不调用commit/reset/applyEvent、不写全局message/session/card Map、不调用t/RAF，不依赖动画帧或语言。现成 `info` helper45–52只返回普通数据对象，可保留供此例使用。

最小留下Bun expect/test、prepareConversationView单一import、原info helper及166–171原case；其余imports、11例、update/part/partUpdate/preparedBundle、全部RAF/settlePublication、beforeEach reset、en/zhJSON imports和setLocaleData/getLocale初始化一起删除。**共享en/zh产品资源绝不能删除**，只是移除这些test-only imports。

保留的是公开hydrate输入完整性错误，不是产品文案断言：expected文字来自内部明确Error诊断，不是界面语言/DOM。它不宣称验证渲染、原名为message-facts的全部数据API或任何正向完整hydration。

## 模块加载与普通runner的边界

`tree-writer.ts`末尾注册board projection handler，并在已有board时重建。现有 `boardStore`初始`board:null`；`script/run-unit-tests.ts`对每个test文件启动独立Bun进程，不共享前一测试文件的board。上述两个保留case均不设置board，因此模块加载只注册原production handler，不进入其投影分支。这是现有生产初始化与既有runner事实，**不新增测试host、mock module或生产分支**。

当前没有运行以验证删后文件；这是源码可达路径审计，不把静态读当测试通过。Root实施时若普通环境实际出现另一初始化副作用，必须保留真实错误并重新分析，不补RAF/i18n/mock来凑通。若不愿保留依赖原module初始化的错误子例，整删对应混合文件是更大的可选删除范围，须明确上节所列错误合同损失；不能反向为了测试保留UIfixture。

## 专用fixture、baseline、脚本、配置和历史引用

- 四文件的所有构造器和模拟数据均inline，无任何 `./fixture`、snapshot文件、baseline、文件读取或浏览器fixture包import；后两文件只额外import共享production i18n JSON/服务/store/type。
- 全仓tracked exact名称引用命中35个文件，全部是历史spec、归档日志/diff/旧typecheck配置和release统计。**没有当前生产import或专门调用这四个路径的可执行runner/config**。完整列表在capture.json，原查询全文保留。
- 非ignored工作区rg查名称为exit1（无命中），它不能替代tracked搜索；Git grep已覆盖被默认ignore的历史spec/记录。
- `packages/overlay/package.json` test→test:unit→`script/run-unit-tests.ts`是共享入口；runner无参数时readdir筛 `.test.ts`，删除文件会自然退出发现集合，不需要改runner白名单或过滤器。
- `.github/workflows/test.yml` services任务执行overlay通用`bun run test`；它服务所有Overlay非UI数据/transport测试，不能删除。`.husky/pre-push`当前type/API/docs/架构/secret检查没有硬编码这四测试，保持。
- Overlay `tsconfig.json`只include src；原历史artifact内两份root touched-tests tsconfig不是当前compiler入口，不是仅服务现行测试的活配置。
- 历史记录、发布stats和旧失败/通过日志不是被本测试读取的fixture，不回写历史或删证据。新spec/删除记录应准确说明这些路径已退休，避免把旧历史验收重新当当前准入；若真实docs检查发现链接问题，再精确处理当前索引，不预先全仓改历史。
- 不删除共享tree-writer、card-tree、i18n、animation-frame、events或selected-task-recovery；它们都有产品消费者，不是测试专用代码。本轮也不扫描/修改其他测试。

## 删除影响与后续交接

必须停止的自动验证是卡片身份/部分数组重用、帧合并显示一致性、integrity reasoning卡片显示、UI层hydrate/重放/移除后的可见树与可见版本；这些只能由真实页面、原截图和人工复核验收。

canonical Message/Part数据API及SSE（Server-Sent Events，服务端事件推送）恢复调度本身仍是生产合同，不能因为其旧测试触UI就删实现；但当前四文件无法在不投影卡片的情况下保留它们现有集成验证。未来若业务真正需要纯数据边界，应由架构需求先独立分析，而不能为维持旧测试计数造第二事实源/专用旁路。现有其他纯backend/transport测试不在本次删除范围，也不需借机扩大检查。

最终允许清单尚须Root落spec并批准。本文/原源捕获不授权实施。当前没有执行UI测试、没有跑剩余错误case、没有改变四文件或任何共享配置。

## Root最终审阅决定与授权（覆盖上文待定方案）

Root亲读四原文件和reset/ingest/prepare/commit真实链后，已在407 spec落盘明确删除范围：**整删前三文件（incremental 3例、review 2例、prerequisite 2例）；message-facts删除11例及所有RAF/paint/reset/apply/commit/i18n/card-tree fixture，仅保留原history coverage/actor integrity一例、原info输入helper和prepare import。合计删除18个原test定义，保留1个原test中的两条明确错误断言。**

因此不实施前文提出的missing Session子例保留可能；Root选择整体退休原prerequisite文件，其结构化错误/路由恢复覆盖损失按前文如实保留，不另造constructor-only测试或旁路。Root确认两个prepare错误在原3344/3359之前只做局部Map/字段校验，不运行UI投影。

授权先保存四文件当前完整工作区/索引diff；若出现他人改动立即报告而非覆盖。仅这四测试删除/削减，不改生产、共享runner、历史spec/统计；不运行四路径、不新增测试或抽生产旁路、不提交/再委托。此节落盘后只读报告冻结；后续执行证据另存scratch，不再改写本次分类依据。
