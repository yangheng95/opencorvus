# 407 normal Message completion → Permission retirement：只读分析

## Recall 与边界

用户持续迭代目标要求先根因/共享影响、再规格、授权实现、真实路径验证和范围交付。406 dcc2469e29c640f59519cf5b08bcedc829fde956 已正常推送；本轮 Root 只授权在本 scratch 做只读调查，未授权生产/spec/正式测试/服务/模型/凭据/UI或子委托。

本分析保留406真正正向证据：process01两live场景A/B共四个原Tool Message已经completed，普通Ask ledger仍只有 requested/allowed_once/execution_started/execution_succeeded；process03与正常package-entry02四场景各4/58通过，证明执行owner修复，**不证明normal retirement**。406去重55/247保持，不把本次静态图/离线源码审查增加成测试。

当前完整源码快照见 source/ 与 source-manifest.json；目标authority.ts/session/index.ts原diff为空。并行compaction等dirty来源保留在status-before.txt，未修改它们。全仓调用检索在callers-all-repository.txt（650个匹配，含非生产fixture/diagnostic）；生产细分在message-callers.txt、retirement-callers.txt。已读security-permission与02-data的事务/Message/原输入/恢复契约。

**推荐：优先静态值import复用现有 PermissionAuthority.retireMessageContinuations，接在唯一 upsertMessageRow 的当前写入事务中；不新抽leaf、不建callback注册/队列/后提交状态。** 必须同时使该退休写入严格传播失败，覆盖immutable replay早return及silent原子bundle，并使用真实Message→Session的Project身份。下面单列新发现的 grant_used候选集合缺口：只补调用不会覆盖它，不能宣称全部Ask问题已修复。所有方案均未实施。

## 一、根因与已有执行/退休的不同合同

1. authority.ts:443–510的completeExecution先固定durable result，结果事务记录execution_succeeded并release原effect lease。Full access在该事务写stale；Ask刻意不写，保留Tool结果到Message结算之间的恢复入口。
2. authority.ts:1310–1327的唯一Message retirement读取原assistant完成时间，再按当前Project/Session/Message的requested、continuationReady及exact call/tool outcome追加stale。原语本身足够表达“Message已完成且此调用有真实结论”。
3. 当前生产调用仅resumeExactContinuation:1306和SessionLoop恢复:4859。正常processor:1746 → Session.updateMessage，finalizePrompt/PromptState.finish都不调用它；Instance:1397–1415每个cache entry只首扫一次。正常live waiter返回后不保证再扫，普通请求重复进入同暖Project也不补扫。
4. 旧385机制证明“再次恢复会收敛”，不是“正常完成会触发”。86fbe0bca刻意隔离每项恢复错误并把first-scan flag在await前置true；49028f70c给Full access同结果事务退休；e08017392把Ask退休推迟到完成Message，接线仍只在recovery。完整原patch已保存。

stale退休是已批准invocation的恢复终态，不是新operator deny、不撤销source grant，也不需要permission.terminated（后者属于赢得pending decision_slot的取消/stale）。实际pending卡由原decision移除，不能为退休合成Message/Reply/Task outcome。

## 二、运行时模块依赖：不能预设有环

当前 module-topology.ts:12 retainedComponentBudgets=[]。本轮直接提取该checker的5个pure AST函数，在当前tracked工作树源码构图，不执行产品import、SDK构建或checker clean-import阶段：

- 1163 production modules / 5936 runtime edges，原SCC=0。
- Authority→Session的静态runtime最短路径为null。
- 在内存图加入Session/index → permission/authority值import后，SCC仍0。
- 备选leaf依赖图也为0，但这**不是抽新模块的必要性证据**，因此不推荐先抽leaf。没有修改checker或预算。

精确算法、结果、时间和HEAD见module-topology-analysis.json与module-topology-pure-functions.ts.txt；inspect-module-edges.mjs只做源码AST。仍须实施后跑正式module-topology的真实clean-import，不能把当前结果说成runtime验收。

初始化审读：Authority:166使用createInstanceState注册accessor；project/instance-state.ts委托State.create，state.ts:104–125把init封在返回fn内，模块导入时不执行reconcileInterruptedAttempts。Authority→SessionLoop是type-only import，resumeRequest内部才dynamic import；没有发现new静态import导致顶层立即调用Session值的链。Config/Bus/SQL等既有依赖仍由正式checker实际import后验证。

## 三、唯一Message writer的全部直接调用与顺序

仅Session/index.ts:1557插入MessageTable。另两个raw UPDATE分别是beginAssistant清除已接受user.pendingDelivery、task-api/task-root-message.ts:92移动既有Task participant到同Task lineage Session；都不新增assistant.time.completed，不是漏掉的完成writer。移动记录保持原ID/Part身份，不可凭标题推成新执行轮次。

upsertMessageRow的10个实际调用位置如下（该函数定义1451不计caller）：

| caller | 完成/Part顺序 | 新hook必须遵守 |
| --- | --- | --- |
| updateMessage:1579 | 普通processor/loop/packaged acceptance/部分shell | insert/upsert后、outbox前同步退休。 |
| completeRecoveredToolMessage:1632 | exact Prompt generation；读取所有Tool outcome，waiting时不完成；结算真实Provider中断 | 调同upsert自然获得原子退休；保留原waiting与park/handoff。已有completed分支1599不进入upsert，旧recovery外部退休调用仍有用途。 |
| beginAssistantReplyWithCommit:1652 | 正常新assistant与accepted input batch/activation同事务；callback先清pendingDelivery并commit owner | 通常未completed，退休guard不动作；不得改输入接纳/Task fence。 |
| publishCompactionCheckpoint:1756 | 原已验证完成summary；同外事务写compaction Part | 权限Tool只按已存在真实outcome；marker失败会回滚Message+stale+outbox。不得碰peer compaction逻辑。 |
| saveMessage:1771 | silent header；目前无src生产caller（现存backend测试有调用） | 不以publishUpdated开关决定退休；silent也是canonical write。 |
| persistMessageBundleRows初写1840 | 新完成assistant先剥completion作FK target；已有Message可能先写完成值 | 全部在外immediate事务内，无外部可见的中途stale。 |
| persistMessageBundleRows最终1855 | Parts已写再写最终info | 必须覆盖已completed早return，否则初写时缺outcome的请求会漏。 |
| updateMessageAndPartWithCommit:2609 | beforeWrite精确fence→Part→Message→afterWrite，同事务 | 任何后续callback失败需连stale一起rollback。 |
| importSnapshot初写2693 | silent；新完成Message先降低为未完FK target | 不引入强制当前Instance Project的新契约。 |
| importSnapshot最终2702 | silent；写完全部parts后恢复完成info | 同上，需要immutable replay早return。 |

全部bundle上层：persistMessage、persistMessageWithCommit/InTransaction、persistClaimedMessagePair（同Session两个message一事务）、fork/side-copy、Task API输入/控制、Mission caller receipt、prompt/parts、CLI import。beginAssistant真实消费者为Catalog binding、SessionLoop、Mission execution-close。完整调用文件和行号已捕获，未只看普通Chat。

### immutable早return

upsert:1489–1495已有completed assistant会先做原payload精确相等校验；相等就设置persisted并return，跳过下面的insert、commit callback、outbox。不能删除这条不可变合同或为了退休重发Message事件。推荐在这个**已验证相等**分支同步调用同一retirement writer，然后按原样return；既有header/parts/时间保持原事实。另一调用点位于真实insert/upsert和原commit callback之后、Message Created/Updated outbox登记之前。两处都在同一个canonical函数里复用同一个writer，不是两套实现。

### bundle与fork/copy

首次新完成bundle用initialMessageForPartWrite去掉completed/finish/error等；原Part都写好后final upsert才完成。已有open Message的bundle可能初写先完成、后补Part；外事务确保途中不被别的进程读见，最终upsert的immutable分支再退休新写好的outcome。中途Part/commit失败整个outer transaction rollback，不能用aftercommit callback补救。

fork/Side在index:398–568一次事务分配新Session/Message/Part IDs，copySources只是证据，不复制permission ledger。精确Project+Session+Message限定使副本不消费原请求；同callID并不构成原执行身份。原Task retained activation未完成时不退休，真正终态进入相同upsert；不能在每个Tool结束提前写stale。

## 四、Project身份与silent import

旧retireMessage用Instance.project.id过滤，适合其原恢复caller（SessionLoop:4795先验证Session/Request/Instance Project）。新canonical writer还覆盖silent import：importSnapshot先按input.info.projectID做Project.assertDurableAdmissionOpen并持久化Session；CLI import只bootstrap(process.cwd)，当前代码没有规定导入Project必须等于ambient Instance。不能为了接线扩大成新implicit admission restriction。

推荐同一retireMessage查询把原MessageTable exact(id,session_id) JOIN实际SessionTable，使用该持久化project_id筛requested。不用Instance fallback，不推断最新Task或Session，只读本次Message的唯一关系。Message.session_id有Session FK/cascade，正常数据不可能无owner；没有Message/未完成仍按原no-op返回。

这个内部writer不是执行授权API；各入口原public/project/Task权限校验仍保留。既有恢复caller外层Project检查也不删除。不同Project即使同名路径也只有各自canonical requested被选中；Session删除保留permission ledger，不能据另一个当前Project归属去补造退休。

跨Project import的真正运行目前**未执行**；源码说明了不能盲依赖ambient的原因，需在正向测试中给两个真实Project、一个foreign ambient、原合法import/immutable replay与各自完整ledger结果。新导入历史无Permission请求时正常返回，不应新造任何授权事实。

## 五、严格原子性与错误合同

### 当前为何不严格

retireContinuation:1334–1344把staleFor/appendEvent的全部异常捕获并log后返回。若在完成Message事务里直接复用，appendEvent内savepoint可能rollback而异常被吞，外层仍提交completed和Message outbox；因此单加一行调用不满足目标。

Database:1718–1840现有primitive提供所需保证：事务callback必须同步；active transaction进入nested SAVEPOINT，内错先移除该savepoint新增effects并rollback，再原样throw。顶层immediate transaction才持有跨进程writer reservation并commit；Bus.publishOwnedInTransaction先同事务落outbox，再登记postcommit执行。无需新的callback注册、DB effect补写或队列。

推荐retireContinuation成为严格写入：移除内部吞错；把“读已有stale + append”放同immediate事务，保持并行/多process幂等。现有retireMessage外事务自然嵌套；现有appendEvent仍唯一事件构造/写入方式，保持原id/time/reason与retirement不占decision_slot语义。无需抽新模块或改变完整Permission Schema。

### 所有caller的失败传播

| caller | 变更后的实际错误与数据合同 |
| --- | --- |
| normal upsert | retirement写失败必须throw，完成Message和对应outbox一并rollback；此前已提交的Tool outcome/Permission result仍保留真实成功，不伪execution_failed。原Prompt/processor按现有error/ownership路径退出。 |
| 相等completed replay | 原已提交完成Message保持；本次stale事务失败可见，重放不改完成时间/不重发Message。 |
| resumeExactContinuation resumed | strict retirement失败直接reject，不能返回resumed并声称收敛。 |
| resumeExactContinuation unresumable | 保留实际Tool终态；退休失败reject而不声称已关闭。 |
| resumeExactContinuation catch StaleContinuation/TaskRootActivationSuperseded | 先退休；若退休也失败，应以AggregateError保留原typed错误和实际退休错误（而非让第二异常覆盖第一）。不得从错误名称猜已写入；recover日志的retired须对应真实事实/严格成功，不能用原typed错误单独冒充。 |
| recoverContinuation/startup | 现有每item try/catch仍返回failed并继续其他请求，错误与原账本保留，项目首扫仍不阻塞整个Project。不能恢复原内部吞错以迎合旧测试。 |
| SessionLoop恢复drain | 原try/finally释放exact Prompt；primaryFailure保留，其他已批准peer按原逻辑收敛。不得提前退休还在live owner写的Message。 |
| replyValidated（无live waiter） | decision/outbox已在前一个事务commit，然后await resume。退休失败会让原reply Promise reject；HTTP既有serverErrorResponse将非named DB/Aggregate错误映射500 UnknownError + request-id。**不能说operator决定被回滚**，也不把continuation失败改成200。 |
| replyValidated（正常live waiter） | 决定真实200与后续独立Prompt completion是不同阶段；后续writer失败按Prompt现有合同可见，不反悔已提交决定。 |
| Task reply/replyUser | task-api:2773/2846通过同Authority等待；同样可传播continuation错误。deny路径不进入resume，不新增拒绝行为。 |
| deletion cancelPendingForSessions:1676 | 并发输给允许且无waiter时恢复；strict失败保留并阻止后续不安全删除，不抹掉原成功effect。 |

reply重复提交已经赢过决定时won=false，不再resume（现有契约）；本次不添加“重试就强行再恢复”gate。后续恢复仍用原Project startup/真实机制。公开HTTP handler已有一般500合同，但具体新错误分支应聚焦验证，不能只靠手写异常。

retireMessage调用前的requestFromRow仍可能因原canonical row损坏而throw；旧代码这类throw本来就不在retireContinuation的catch内，保持数据完整性错误，不把坏记录解析成默认值。SQLbusy/connection unavailable保持Database.normalizeError既有语义，禁止catch后假成功。

### 源错误/结果必须分别保留

normal message completed不等同整个Session/Task完成，更不等同OS owner已死亡。仅选到exact Tool outcome且continuationReady的请求退休。convergenceFailure留下的缺失Tool outcome保持原缺失，不能用message.time.completed伪补完成。原失败/unknown execution不是success候选，既有Full access事务不改。Ask已retired后authorize同旧request会返回现有StaleContinuationError（authority:855），canonical结果仍由completedToolExecutionResult/recovery读取；不要为测试改成旧请求再次执行或给authorize加fallback。

## 六、额外已发现候选集合缺口：grant_used

本轮无服务/新测试，以下是当前源码与已有测试的具体证据：

- authorize:863–865找到activeGrant后，appendEvent('grant_used',{source_event_id,decision_scope})没有decision_slot。
- decisionFor:576–579只按decision_slot查；schema与0001-baseline没有自动补槽的trigger；appendEvent只对requested复制owner字段。
- continuationReady:1349需要decisionFor返回；list:1243/pendingRequest:775也只据这个row判pending。
- 因而共享Message hook即使正确运行，仍会跳过grant_used成功请求；live/cold pending投影还存在把已授权调用当pending的风险。既有permission-two-mode:337–393验证真实复用执行与精确历史（其中grant_used），没有验证该row的decision_slot、list或Message retirement。
- execution admission:1096–1104验证返回的authority.id确实属于该request，并使用它作为execution_started.source_event_id；并非凭decision_slot进行这一步。因此不能否认grant_used是已实际执行的授权事实，也不能仅在list或retire局部旁路它。

历史grant_used从43636df96存在。此问题贯穿allow_task/allow_project、复用、撤销/失效、同request并发、operator reply/cancel winner、重启和Project隔离。**不建议本次未分析事务winner就顺手补一个decision_slot字段，也不增加双读fallback或只靠execution_succeeded跳过原authorization条件。** 需要Root独立落完整grant admission/decision契约并授权真实正向复现后根治。407若先做normal完成接线，必须明确只覆盖现有可恢复候选（allow_once与原grant_created请求），不宣称所有grant-reused Ask已完成。

## 七、全共享路径/恢复与影响面

Main/Work/Side/child/public Session、GlobalChat→SessionWake、CLI/ACP SDK、ControlMessage/channel、Task root/worker/delegate、Mission都进入SessionPrompt/Loop/Processor；authority唯一入口是withTaskToolInvocation与MCP App host。normal completion的缺触发是共享writer问题，不能按一个专家包降级。

- Task retained activation：每个model Tool step仍是同一未完Message；只有原typed控制允许完成时才触发，fence逻辑不改。原stale activation只按当前accepted-activity结算合同处理。
- Mission：正常完成同writer；重启仍先recoverMissionProcessSession消费原dead-owner/frontier/wake，不用generic Prompt抢其证据。退休只依据原Tool结果；不新增Mission状态机。
- live本地/peer：未完成Message无退休；另一个进程读到已完成旧Message可安全幂等退休，即使同Session正在新Message上继续运行，不把它叫global dead。
- process cut：Tool result已存/Message未完保持原请求可扫描；完成Message+stale同事务则之后crash保留两事实；历史completed但stale尚未写通过原startup快路径或immutable同payload replay补同writer。没有新recovery队列。
- 串并行/多Project：现有exactContinuation和Prompt generation不改；新增事务只覆盖同一Message/current canonical Project。两进程写同Message由SQLiteimmediate和immutable合同串行，stale读+写同事务；不同Project的结果/slot不得混合。
- 删除：当前assertRequestsSettledForSessions允许已有execution终态，即使stale未写；历史成功后删除Message/Session可能使下次scan反复NotFound（406源码风险，未实际复现）。新normal写入可避免新增这类backlog，但不自动修已经删掉owner的历史行；不造stale或假Time/Request。Project deletion的grant expiry writer保持原独立契约。
- MCP App：直接Authority执行并更新真实Tool Part，Message有时早已completed；正常Message hook不保证覆盖“完成之后才追加的独立App Tool”的退休时机。这是另一准确边界，应先用实际App入口证明，不能声称本两文件覆盖每种后完成effect。本次不改App。

性能：existing requestedRows有SQL project/session/message条件，但当前permission ledger索引主要按Session/time与Project/time，没有message独立索引。新normal每次完成会调用原查询；实际代价未测，不据猜测新增DDL。若验收显示长Session扫描成为实耗，再按原plan扩索引/查询，而非host缓存。

## 八、最小实施/验证建议（当前未授权）

优先生产只Session/index.ts与permission/authority.ts：

1. 静态值import同Authority；唯一upsert的完成正常落库点和immutable相等早return点，同事务调用现有retireMessage writer。不按publish flag过滤；不注册callback/aftercommit shadow。
2. 同writer读Message JOIN Session的canonical Project；原Request/Tool完整匹配、候选条件、reason/time与复用结果保留。
3. 私有retireContinuation严格同事务检查+写入，删除吞错；原typed失败与退休失败同时发生时保留两者。已有recovery逐item隔离和reply可见错误保留，不降低写入保证。
4. 不删除当前recovery退休入口：已有completed earlyreturn/历史库仍用它们；这是同一个writer的合法caller，不是兼容fallback。等有精确证据证明某次重复调用无用途再收窄，不能借此扩大清理。

必须正式先红后绿的正向矩阵：

- 真实public Session→流式受控Provider→Permission AllowOnce→Tool/result→自然Message completed→完整五事件ledger（最后stale），同API completed reply原身份。复用406正式process checker，当前四事件期望在新契约下要改为五事件；dead未完成case仍原unknown合同。
- 同Message多Tool：第一条真实结果后Message仍open、全集明确保留其可恢复候选；最后结算完成时两请求各exact stale与完整原result。
- completed相同payload重放、silent save、existing/new persist bundle、atomic Message+Part+commit、silent import、fork/Side-copy，验证完整原payload/Part/时间、原请求归属与当前ledger全集。saveMessage不制造新产品调用者。
- SQLite受控写入失败：真实stale insert映射明确错误；读取原open Message、真实已完成Tool/result、原outbox全集证明事务rollback，再解除原测试故障用同canonical写入成功。不要以absence为核心，也不spy writer假造完成。
- direct reply无waiter恢复失败与normal live决定成功/后续完成失败的区别；原decision/userInput真实保留，HTTP公开500/RequestID与恢复每item隔离。原typed error+退休写失败两原因需可检查。
- Task retained Message、原accepted activation fence、Mission正式恢复、活peer、多Project并行与restart沿现有聚焦套件复验，不能用普通Session四case冒称全Task/Mission。
- 真实normal Message完成后的崩溃/重启与已完成历史重放正向过程；original deadlines/owner/输出/请求/关闭均沿成熟primitive，另Root审批首次helper。
- grant_used必须另行先正式复现decision/list/retirement及winner全合同；MCP App后完成Tool未知边界不外推。

支持检查：core types、正式module-topology（retainedBudgets仍空、真实clean-import）、现有database-transaction-contract、completed-failure-write、fork-atomic-transcript、permission-message-settlement/recovery/process、相关result/retention/Task控制。已触及test无UI自动化；本轮没有运行任何正式测试，也未建立新服务、调用模型或读取凭据。

范围与风险不能靠test绿色降级：grant_used与App边界、历史已删owner、import异Project、真正运行期import当前仍未验；Root须把它们明确纳后续规格或独立待办，不能包装成全部Ask恢复/所有终态已经根治。
