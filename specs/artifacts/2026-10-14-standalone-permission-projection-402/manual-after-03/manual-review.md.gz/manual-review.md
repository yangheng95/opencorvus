# Manual after 03：自定义 Question 回答与普通侧聊消息

仅整理 Root 已完成的真实页面与公开 API 事实，不新增页面、模型或测试。人工查看本目录三张原 JPEG，原字节保持，没有裁切或重编码。该轮使用受控流式 Provider，不是真实 Sol 样本。

主 Session `ses_hVSXwR9J8zg6X2k5Qt6G` 自然产生 Question。Root 在真实 Dialog 自定义框输入 **Public 402 draft Cedar**，未将它当成自动填写或后台注入的 UI 数据；[草稿原图](observations/question-dialog-draft-en.jpg) 可见该文本与 Answer/Skip 按钮。真实提交后，[完成原图](observations/question-answer-completed-en.jpg) 显示回答文本与 `provider reply 2`。[messages-after-answer.json](messages-after-answer.json) 对应 question Tool 为 completed，metadata.status=answered、answers=`[["Public 402 draft Cedar"]]`，随后 assistant finish=stop。这证明该题的自定义输入和提交链，不证明任何断开/重连后的草稿保留。

随后真实打开/创建 Side chat 并发送普通侧聊消息。侧 Session 为 `ses_-zUS2Qbfyzz7SKQFAtqK`；[Session 公开记录](sessions-after-side-chat.json) 显示 kind=assistant，metadata.sideChat.sourceSessionID 指向上述主 Session，inheritedMessageIDs 为三条参考历史。它是独立侧会话，不是 Main child Permission 样本。

[侧聊原图](observations/side-chat-message-completed-en.jpg) / [AX](observations/side-chat-message-completed-en.ax.txt) 可见 Reference history · 3 messages、新用户输入 `Please discuss the public 402 custom answer I just submitted.` 与 `provider reply 3`；[side-chat-messages.json](side-chat-messages.json) 的新增 assistant finish=stop。历史里的已完成 Question 是克隆参考历史，不能重复计作侧聊新触发 Question 或新的批准操作。本轮没有 Side chat Permission 决定验收。

没有执行 Question reconnect、older Permission 抢占当前 Question、切源恢复草稿或 Question child 准入验证；不得从“输入后成功提交”推导这些状态保持合同。也未验证双语、移动端或真实外部模型质量。

[page-closed.json](page-closed.json) 记录 tab 5 于 `2026-10-13T19:34:26.720Z` 关闭，早于 originalCloseBy；[terminal.json](terminal.json) 记录 owner PID 79220、occurrence `b31ee63e-8311-45d0-9a6d-89aeb8b99898`、server/provider stopped；[closure-review.json](closure-review.json) 确认原 scope exit 0、outputSettled=true、Native PID 已不在、outer runtime 已清理。物理关闭已证实，不扩大上述业务验收范围。
