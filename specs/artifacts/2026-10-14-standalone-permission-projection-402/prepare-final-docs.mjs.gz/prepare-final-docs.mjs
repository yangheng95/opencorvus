import fs from 'node:fs'
const scratch='.tmp-standalone-permission-projection-402'
const spec='specs/records/2026-10/2026-10-13-standalone-permission-projection-402.md'
const archive='specs/artifacts/2026-10-14-standalone-permission-projection-402'
const status=`2026-10-14 Root最终收敛状态：402生产、正向测试、完整SDK生成和最终私有UI已实现。真实Main warm/cold、本次允许/拒绝、两个并行非Task child、SideChat自身权限及Task既有单源审批分别有实际HTTP/ledger/桌面JPEG证据；真实GPT-6.1 Sol本次允许01与最终拒绝02都通过自然流式答复与精确Native正常退出/完整配对清理。Task外部文件读取受既有进程根约束拒绝，Task完整完成未达成；Work/Mission独立页面、Question真正重连草稿、大Board性能与已completed历史自动修复未验收，不外推。Scope05错过页面关闭预留、06加载并行修改的新旧Provider模块、checker字段假设错误均保留失败；Git基线准备和受控Memory空正文另列后续调查。当前正在整理明确公开归档、文档检查、范围提交和正常上游同步，尚未宣称已push。原方案与红态下文均为历史阶段，不是当前状态。\n\n恢复后先读本Recall及文末真实结果；后台标准Bun1.4使用包runner，前端只纯transport/state正向unit、typecheck、Node私有build，不运行UI自动化。关键重复命令：\`bun run --cwd packages/opencorvus test test/server/session-permission-projection.test.ts test/server/task-board-validator.test.ts test/server/permission-denial-continuation.test.ts test/config-global-defaults.test.ts\`、核心types、\`bun run docs:check\`。真实Native固定600秒/20请求/180秒无活动，关闭预留60秒，原owner关闭再移除auth/models复制；不增加预算。下一批先核Task Git边界与未完成的Work/Mission/Question独立交互，继续当前Goal，不重做已保存成功。\n\n`
let text=fs.readFileSync(spec,'utf8')
if(!text.includes('## Root最终真实验收与交付边界')){
 text=text.replace('## Recall\r\n\r\n','## Recall\r\n\r\n'+status.replaceAll('\n','\r\n'))
 text+=`\n\n## Root最终真实验收与交付边界（2026-10-14）

### 完整实现与聚焦正向检查

唯一Permission Request schema、canonical requested时间、必有pendingPermissions快照、真实Terminated通知、Task不可变ledger校验后现成invalidate、Main/Side共享adapter、提交前捕获原source/目录/selection authority已实施；Question公开合同不扩围。Board完整可见JSON一次物化并计算真实HTTP弱实体标签，同一物化返回200或由当前Hono中间件处理304。移除旧Board聚合计数签名。原Tool拒绝host停止gate和continue_loop_on_deny配置删除，真实Tool错误进入下一流式模型请求；保留真实abort、typed control和完整reply准入，不修写旧completed历史。

正式后台原组9文件71测试/301断言；deny组含9文件89测试/297断言，其中7相关文件79/247（Task-root多步3/7、精确取消4/9、approved恢复8/25、Tool settlement10/22及控制/producer/activity）。两组含重复，不相加为总覆盖。warm canonical summary组Permission8/39＋transport1/4，共9/43；SDK后原公开合同重复10/50；Bun matcher原错误已保留，clonefix后TCP3/30重新通过。前端两个纯transport/state文件27/66及renderer-surface检查通过；没有源码文案、DOM、组件、snapshot、Playwright或像素测试。最后当前共享工作树重复结果另见归档final-root-recheck，不将重复次数当新增覆盖。

完整SDK生成六目标事务已join0，所有stage/build/backup与generator owner关闭。唯一tracked SDK变化为types+83/-4与OpenAPI+311/-4；旧Config字段删除由唯一生成器产生。核心/SDK source/实际published declarations类型通过；最终Overlay types与Node私有构建通过，全部owner已join。实际使用ui-after-final；真实Sol02把它复制到自己Native exe相邻ui，原Sol01旧UI移到自有ui-first-allow-01保留。未覆盖共享dist、未新建branch/worktree、未启用用户Browser。

### 实际桌面与消息证据（原JPEG人工查看）

| Scope | 真实路径和结果 | 明确限制 |
| --- | --- | --- |
| manual-before-05 | 原Main Ask只有Running/无决定控件，展开read同样如此。 | 父owner最终清理；原child自删SQLite-shm发生EBUSY/natural1，保留。不是正常Native成功。 |
| manual-after-01 | 英文Dialog/inline、重载后重新选择原Session恢复pending，实际AllowOnce，read三行与真实流式provider reply2/stop。 | 受控Provider；首次Escape重载时重开原因未知，稳定后Escape正常；未称真实Question重连。 |
| sol-after-01 | Native Bun1.3.14，配对preflight usable/projected/exact gpt-6.1-sol/stream；中文Dialog本次允许，requested→allowed_once→execution_started→execution_succeeded，模型正确读取CEDAR402/Maple3/Iris4/合计7并引用文件。 | 本次允许，旧第一次UI。5个累计200/EOF请求含preflight/helper，不是5业务turn。原Target1852/Host47908 natural0，全部drain/请求/配对复制清理。 |
| manual-after-02 | warm正文被transport诊断summary覆盖，实际Reject后真实Tool denied、assistant tool-calls completed，SessionWake MissingDurableReply，最终Notrunning/error。 | 两个本批根因的原失败，不称成功或永久Running。 |
| manual-after-03 | 真实Question自定义输入Public 402 draft Cedar并提交，真实question答复/模型stop；独立SideChat root正常用户消息/模型stop。 | 只验证草稿输入/回答，未真正重连Question或草稿保留；Side普通消息不是Side权限。 |
| manual-after-04 | 旧缓存warm Side正文错误，关闭/reopen读取mandatory快照正确read(read_local)，实际Side AllowOnce、read/自然reply2。 | pre-summaryfix缓存，不称最终warm成功；完整三行当时部分在composer下方，HTTP/AX可核但图片未全呈现。 |
| manual-after-05 | 最终UI、隔离语言切换与Settings实际500；原服务在closeBy20:15:08.331Z正常停止，页面20:15:55.344Z才关闭。 | Root未完成批准且违反自己页面关闭预留；保留未完成/时序失败，未延deadline、未真实Sol。outer10QXEp/PID88776均已移除。 |
| manual-after-06 | 新页列表/work-ledger等500，SyntaxError运行时Provider导出缺失；保存错误截图，页面20:17:19.096Z关闭，原PID89100 natural0/outerNEHfNu删除。 | 三个Provider文件正在另一任务未提交修改；HEAD三者自洽，此进程先载旧operations后惰性载新route。当前磁盘补齐后fresh07通过；不改peer导入、伪称HEAD缺件或热修旧owner。 |
| manual-after-07 | 最终Main连接后release真实warm read，Dialog及inline均canonical read(read_local)，实际Reject→真实Tool failure→provider reply2/assistant stop→Notrunning，截图与原HTTP事实保存。 | Root两次checker错猜history camelCase/Tool.state.error；真实字段为snake_case/request_id绑定及Tool.state.failure.message。原输入/输出保留，显式saved-facts checker修复并通过，离线核对不是新E2E。PID86152自然0/parent清理。 |
| manual-after-08 | 公开API真实parent child-one/child-two并行stream；父会话连续Dialog先Reject再AllowOnce，两个child各自真实reply2/stop。UI创建独立Side root，公开可见用户输入显式side模型，warm权限canonical summary/AllowOnce→实际read三行，滚动后原图完整可见＋Sources/自然reply2。Task research-studio公开202，唯一board Permission answered/allow_once，现成Task Dialog含AllowforTask。 | 非实际delegate_agent调用；Side独立根parentID为空且sourceSessionID精确，未称child权限属于Side。Task外部D文件被C进程根TaskProcessBoundaryError拒绝，随后fixture普通文本缺真实调度control，active epoch1/idle/exhausted semantic_limit，未Task completed。早期Git基线错误和Memory空正文仍未知。 |
| sol-after-02 | 当前final source/final UI，Native真Sol精确preflight，实际英文Dialog Reject，per_h756VGiw2YWYJ5RFN9NT requested→denied，Tool明确拒绝；真实assistant msg_g0VXxnMDQ00HptnHsJ0T中文尊重决定/finish stop，Root人工查看原图。canonical checker0，累计5请求均实际gpt-6.1-sol/stream/200/EOF。 | 英文产品UI＋原用户/模型中文原文；不据模型自述推执行事实。原Target43048/Host43800 natural0，output/request settled、端口释放、auth2194B/models9155406B复制均removed/presentAfterfalse；原exec24600 join0在deadline1791923770626前。PowerShell脚本不保证设置LASTEXITCODE，原空exit文件保留，实际exec0与production physical receipt单独存证。 |

所有成功/失败Scope互不替代，只有自有隔离页面和服务；manual与真实Sol区别明确。截图保持FF D8原JPEG，不重新编码/裁切。原启动工具链修复、首SDK/末SDK、温热正文红绿与deny红绿均保留原输入/输出，不用源码摘要、换行或自算期望当功能门槛。

### 横审、风险与下一批

Settings /expert-squad/catalog与skill/mounts两个500为active Base完整投影要求其manifest Browser，而受控global配置明确禁用Browser。NativeChat的disabled空MCP投影合同不同；目录不是遍历inactive包，resolver/manifest/routes/mounts均无402差异。历史702e030d4禁用时拒provider替换合同保留。研究工作Task明确选已内置ResearchStudio，能力只有普通tool/platform sets，无需启Browser或虚假fallback；真实202已证明接纳，但不能证明所有Task完成。

Task边界、typed-control与文件guards横审覆盖全生产调用、Task/Session/Mission/worker、epoch/正常/终态/取消/恢复/串并行/多Project；实际Task AllowOnce不改变Task root authority，因此外部文件错误合法。其受控模型没有真实orchestrator调度决策，exhausted/semantic_limit是正常边界结果，不伪造completed。早于权限的Git HEAD '$GIT_DIR' too big与受控Memory空markdown独立记录未知根因，下一批先调查，不用本批permission修复解释。

未满足的扩展验收：Work/Mission各自桌面入口、真正Question reconnect/draft、真实Task全链完成、queued输入与全入口排列、大Board性能及cached Brief标题失效、已completed历史自动修复均未证明。已验证的是上述明确入口和同源数据契约，不能宣称全部模式/恢复/性能无缺陷。公开完整Board tag忠实已有可见Brief缓存；Task title变更200真实新title已验证，旧Brief缓存另列候选。

公开产物及准确输入/输出见[402归档](../../artifacts/2026-10-14-standalone-permission-projection-402/README.md)。仅明确allowlist公开日志/夹具/差异/报告和原JPEG，排除运行目录、数据库、auth/models内容、二进制/UIbundle、peer全仓diff与真实Provider raw payload；Native只保存已审计公开身份/reader/预算投影。当前Git交付完成后另补精确提交与push事实；Goal仍active，持续下一批。
`
 fs.writeFileSync(spec,text)
}
const ops=JSON.parse(fs.readFileSync(scratch+'/current-docs-ops.json','utf8'))
const add=(file,before,after)=>{if(!ops[file])ops[file]=[];if(!ops[file].some(item=>item[0]===before))ops[file].push([before,after]);let raw=fs.readFileSync(file,'utf8');const eol=raw.includes('\r\n')?'\r\n':'\n';raw=raw.replaceAll('\r\n','\n');if(raw.includes(before))raw=raw.replace(before,after);else if(!raw.includes(after))throw Error('Missing exact shared anchor '+file);fs.writeFileSync(file,raw.replaceAll('\n',eol))}
for(const [file,target]of [['specs/README.md','records/2026-10/'],['specs/records/2026-10/README.md','']])add(file,`- [402 独立会话权限批准投影](${target}2026-10-13-standalone-permission-projection-402.md)：Main Chat的hydrate/live/reconnect、真实排序与完整控制入口横审。`,`- [402 独立会话权限批准投影](${target}2026-10-13-standalone-permission-projection-402.md)：单源pending、canonical时间/正文、完整Board实体标签与拒绝后自然流式答复；真实Main/Side/child/Task审批及Sol允许/拒绝，未验收边界明确。`)
const artifactIndex='specs/artifacts/README.md'
const artifactBefore='- [403 Native关闭与重启收敛](2026-10-13-native-shutdown-pending-permission-403/README.md)：208个明确公开源、原红态与Native正常/失败终态，未复制运行数据或凭据。'
add(artifactIndex,artifactBefore,artifactBefore+'\n- [402 会话权限与拒绝收敛](2026-10-14-standalone-permission-projection-402/README.md)：明确红绿、原桌面JPEG、两次真实Sol公开事实及正常配对清理；未覆盖入口和Task边界独立保留。')
fs.writeFileSync(scratch+'/final-shared-ops.json',JSON.stringify(ops,null,2)+'\n')
fs.mkdirSync(archive,{recursive:true})
fs.writeFileSync(archive+'/README.md',`# 402 Standalone Permission projection evidence\n\nRoot与一层audit_functionality/audit_ui，2026-10-14。当前生产、正向测试和真实桌面/模型证据见[调查与验收](../../records/2026-10/2026-10-13-standalone-permission-projection-402.md)。\n\n## Evidence boundaries\n\n- Main原无批准入口、canonical请求时间/summary、完整Board实体标签及Tool拒绝停止gate分别先分析/落盘，再修复；红态与错误假设均保留。\n- manual-before/after为公开受控streaming fixture，原JPEG由Root实际操作/人工查看；没有UI自动化。07最终Main warm拒绝自然stop；08真实双child、独立Side AllowOnce三行可见与Task单一审批。\n- sol-after-01真实Native gpt-6.1-sol中文AllowOnce/文件三行/合计7；sol-after-02最终版本英文Reject/中文尊重决定/真实stop。完整auth/models配对仅在自有运行scope，exact preflight/actual streaming/ledger/Tool/assistant/physical/pair cleanup分别核验，归档不含凭据或模型目录内容。\n- 05页面错过关闭预留、06并行暂态模块、各原checker错误保留，不算成功。Task审批不改变进程根，外文件TaskProcessBoundaryError及无调度control的fixture不是Task completed；Git/Memory独立未知另列。\n- Work/Mission独立UI、Question真正重连草稿、全Task完成、大Board性能/Brief缓存及历史自动修复未验收。\n\n## Files\n\n[archive-manifest.json](archive-manifest.json)逐一列原公开source/原字节数与归档位置。文本用gzip原字节保存，JPEG直接复制；[archive-check.json](archive-check.json)仅证明这些不可变captured artifact字节与链接完好、界定的敏感模式扫描，不是mutable源码hash门槛或功能/UI验收。Implementation、warm-summary、denied-continuation/sdk-final、final-root-recheck为实际红绿/类型/完整生成事务；各组重复不相加。manual/sol各scope保留自己原身份/预算/时序/结果。\n\n选择排除auth.json、models.json内容、runtime/owned-temporary/database、exe、UI bundles、真实Provider raw payload、peer全仓diff与完整SDK baseline bundle。旧源码preimage/失败fixture仅历史证据，不是兼容实现或当前事实来源。\n`)
console.log(JSON.stringify({spec,archive,shared:Object.keys(ops)}))
