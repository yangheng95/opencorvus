# 402 前端实施自审

2026-10-14。Root 已正式授权六个行为文件、两个仅协议 fixture 文件，以及 InteractionDialogHost 三行旧说明。没有自行扩展 API/SDK、共享文档、spec、页面、服务、模型或 Git 操作。

当前九文件的精确编辑前预像在 `ui-before/`（新 permission-interaction.ts 原来不存在）；`ui-before-manifest.json` 记录路径和原字节长度。`save-ui-diff.mjs` 使用现有 diff 库比较预像与当前文件，生成 `ui-implementation.patch` / `ui-implementation-files.json`，仅用于改动范围人工复核，不作为功能或 UI 验收。

## 控制流复核

- 单一 standaloneInteractions Map 取代旧 Question 专名，resetWriter 原有清理仍清同一 Map；Question 的旧 `.has(id)` 改成相同集合语义的 `get(id)?.type === question`，其 root/knownMission 准入没有放开，回答/拒绝/responseOrderKey 处理不变。
- 新 normalizer 只校验显示所需 Request 字段、真实 interaction orderKey/timeCreated 与目录，投影权限卡；不复制后台策略 schema，不创建任务或决定。Main cold/connected/live 与 SideChat snapshot/live 均调用同一函数。
- Main HTTP hydrate 在原 resetWriter 批次中同时提交 Questions/Permissions。connected 只替换 Permission；Question 对象留在原 Map，原 history cancellation、transcript merge 和 projection deferral 保留。Task hydrate 不读取 Session 数组，Task live 权限原始事件不写 standalone Map。
- Main live 使用已验证 selectedSource.directory；权限 child 准入由服务器负责，前端不重新依赖 sessions Map 中是否已出现 child。Replied/Terminated 只删除匹配 request/session 的 Permission，未引入 resolved 时间、answer 消息或 Task 状态。
- SideChat 同一次 connected 先准备 transcript 和 mandatory 权限数组，再更新 base/live/pending；权限只取 exact target Session。原 Question connected/replay、已捕获 authority/generation/dispose 和显式 afterReply 保持。
- InteractionCard 点击开始在首个 await 前捕获 target/id/endpoint、复制 source、directory、authority、selectEpoch、显式 callback。原 helper 在同一同步调用链捕获同一 API authority；没有延迟派发。默认只有原 Task 仍当前且目录一致才 loadBoard({authority})；Session 留给正常事件/connected。SideChat 仍调用自身显式 callback，不按 Main source 再选择目标。
- 共享 type import 全部 erased：新 helper 对 InteractionCard/interaction-reply 没有运行时依赖；没有引入 tree-writer → conversation 的循环。
- InteractionDialogHost 仅替换三行“所有回复 loadBoard”错误说明，没有改变 Dialog open/dismiss/children 或增加另一回调。

## 已完成检查

使用 Root 指定 Bun 1.4.0，标准 `bun run test:unit test/side-chat-transport.test.ts test/subagent-conversation-service.test.ts` 正常隔离 runner/Native supervisor 完成 exit 0：2+25 个测试，3+63 个断言。日志 `transport-state-ui.log`、`transport-state-ui.exit`。测试编辑仅补旧 Permission Asked 的完整公开字段/interaction orderKey，以及 SideChat connected 的显式 pendingPermissions 空数组；没有改原断言、没有新增 UI 或源代码断言。

`bun run check:renderer-surface` exit 0，1 assignment/1 declared global。日志 `renderer-surface-ui.log` / `.exit`。这是既有公开全局对象安全面检查，不是组件或页面验收。

当前没有失败的正式检查输出；一次只读 rg 的 PowerShell 通配路径拼法错误已改用目录 + --glob 重查，没有产品或测试因此失败。

## 正式 SDK 后检查完成

Root 通知 SDK 唯一六目标生成/发布事务闭合后，使用当前 SDK 正式执行 Overlay typecheck 与隔离 Node/Vite build。两原 exec 均最终 join exit 0：typecheck session 19173 / final chunk 1b6d89；build session 37950 / final chunk b8766d。完整构建末尾为 `built in 1m 5s`，输出仅自有 `ui-after`，未启动页面或写共享 dist-vite。

精确可复用命令保存于 `run-ui-validation.ps1`；实际 executable/arguments/cwd/UTC 开始结束和 wrapper PID 在 `typecheck-ui-command.json` 与 `build-ui-command.json`；完整输出/退出码分别在 `typecheck-ui.log/.exit`、`build-ui.log/.exit`。`ui-validation-scope.json` 包含九文件范围、两命令与最终工具会话 join 回执、包装进程退出后的只读观察。构建保留依赖 `use client` directive 及大 chunk 警告，exit 为 0，没有据此扩展清理范围。

## 仍待 Root 真实验收

Root 负责真实后态页面、截图人工复核和已授权模型链路；本自审及 transport/state 检查不能证明 Main inline/Dialog、切源、重连、多个 pending、Question 草稿、Task/SideChat 或双语视觉已完成。没有启动页面、服务或 Provider，未操作用户浏览器。

额外只读身份复核已发送 Root：仅 Permission 替换且仍选中原 Question 时，seed/parts 持有原 interaction，Solid 1.9.14 浏览器 Store 的 raw→$PROXY 缓存及 keyed Show 保留组件；但旧 Question Asked 重放会创建新对象，且恢复更早 Permission 会改变 Dialog 最早候选。不得把 Map 保留对象扩大为完整重连或抢占后的草稿保留结论，Root 需分别真实验证。
