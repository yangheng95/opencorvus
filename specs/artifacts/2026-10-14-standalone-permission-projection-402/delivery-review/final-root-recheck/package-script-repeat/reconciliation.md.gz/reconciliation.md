# Core typecheck reconciliation

The package-declared repeat passed with **exit 0**, original exec session **80384 joined**, between **2026-10-13T20:56:09.410Z and 20:56:52.205Z**. No product, tests, dependencies, SDK outputs or Git state were changed by this audit.

## Command, working directory and compiler

- Original failed run: `node --max-old-space-size=8192 node_modules/typescript/bin/tsc --noEmit`, invoked with tool working directory `D:\myhexin-local\opencorvus\packages\opencorvus`. Its saved command/log/exit remain in the parent directory. Original exec 56306 joined exit 2.
- Repeat: actual Bun 1.4.0 at `.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64/bun.exe`, invoking `bun run --cwd packages/opencorvus typecheck` from repository root. The package script expands to exactly the same Node command, as shown by `typecheck.log` and the package source copied before the run.
- Observed real process chain: PowerShell 84012 → Bun 65064 → Node 88380. The Node executable was `C:\Program Files\nodejs\node.exe`, version v25.7.0. See `actual-process-observation.json`; this is the actual owned run, not a guess from PATH alone.
- Current TypeScript is **5.8.2**, resolved through the package symlink to `node_modules/.bun/typescript@5.8.2/node_modules/typescript`; root and package TypeScript links point to that same installation. Exact entry and module paths are in `compiler-resolution.json`.
- The selected config is `packages/opencorvus/tsconfig.json`, extending `@tsconfig/bun/tsconfig.json`. Its effective options include `noImplicitOverride: true`, `strict: true`, `skipLibCheck: true`, `noEmit: true`. Both `src/session/compaction.ts` and `src/session/llm.ts` are in the parsed file list. Parsing produced zero errors. Relevant configs and `NamedError` source/package export conditions are copied under `inputs/`.
- `git diff a168da234281546544bc7e8ad4974203a95146d8 HEAD -- packages/opencorvus/package.json packages/opencorvus/tsconfig.json packages/util/src/error.ts packages/util/package.json` is empty (`config-source-history.patch`). These tracked command/config/base-class sources did not change across the two HEADs. The original run did not capture its compiler binary version or the two peer sources atomically, so no claim is made that its full input was byte-identical to this repeat.

## Source timing and correction

The original typecheck command was recorded at 20:31:19 UTC and its log/exit at **20:32:08 UTC**. The old log reports TS4114 at `compaction.ts(97,18)` and TS2322 at `llm.ts(316,113)`.

The peer's two files were subsequently written at **20:37:09 UTC**. The saved post-failure observation at 20:37:17 UTC already contains:

```ts
override readonly name = value.name
readonly data = value.data
```

and:

```ts
maxOutputTokens: params.maxOutputTokens ?? maxOutputTokens
```

The initial audit mistakenly identified the old TS4114 by the newer source's line 97 (`data`). That attribution is withdrawn: the abstract `NamedError` base has `schema()` and `toObject()`, inherits `name` from `Error`, and declares no `data` property. Current `data` therefore needs no `override`. Because no atomic copy of the compiler's original source was taken, the old line number alone cannot establish which declaration occupied that line at compilation time. The corrected current `name` declaration and successful formal repeat establish the present behavior. `README-before-correction.md` retains the original inaccurate explanation, and the parent README now explicitly corrects it.

Root's `push-final01.log` was created at **20:50:28 UTC** and completed at 20:51:45 UTC, after those source writes. It records eight actual typecheck tasks, all cache misses, zero cached, and all successful in 52.057 s, before the separate API-route generated-output failure. This is consistent with the corrected current source; there is no evidence of a typecheck cache discrepancy.

Before the repeat, the two peer files and command/config/base-class inputs were saved. After original exec join, both peer files still matched those pre-run bytes (`join-and-input-observation.json`). This only documents the observed source timing for the compiler run; it is not a source-digest or byte-comparison correctness gate. The compiler's actual exit 0 is the typecheck result.

## Evidence and limits

- `command.txt`, `typecheck.log`, `typecheck.exit`, `owner-start.json`, `owner-completed.json`: actual repeat invocation and terminal result.
- `actual-process-observation.json`, `compiler-resolution.json`, `bun-version.txt`, `node-version.txt`: executable/compiler/config identity.
- `inputs/`, `peer-source-before.patch`, `status-before.txt`, `status-after.txt`, `head-before.txt`: current observed input and shared-worktree context.
- The previous focused formal backend result remains **22 tests / 113 assertions**, not repeated and not counted twice.
- This audit did not regenerate the SDK or address the independent Provider output/OpenAPI/docs publication mismatch in Root's push hook. Root owns that separate closure.
- No UI automation, real Provider, credentials, model catalogue or service was used.
