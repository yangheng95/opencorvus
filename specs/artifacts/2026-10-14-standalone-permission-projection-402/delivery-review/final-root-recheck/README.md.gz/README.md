# 402 final shared-worktree recheck

This is a repeat verification on HEAD `a168da234281546544bc7e8ad4974203a95146d8` and its shared worktree. It does not add distinct test coverage to the earlier 402 totals. No product, test, SDK, configuration, or shared documentation files were changed for this recheck. No real Provider, browser, or long-lived service was started.

## Focused formal tests

The formal package runner used Bun 1.4.0 with the saved PATH/command. Original exec session `16987` was joined with exit 0.

| File | Tests | Assertions |
| --- | ---: | ---: |
| `test/server/session-permission-projection.test.ts` | 8 | 39 |
| `test/server/task-board-validator.test.ts` | 4 | 24 |
| `test/server/permission-denial-continuation.test.ts` | 3 | 30 |
| `test/config-global-defaults.test.ts` | 7 | 20 |
| Total | 22 | 113 |

The actual log is `tests.log`, exit is `tests.exit`, and the four test sources plus the three Provider module files were captured under `inputs/` before running. `provider-module-before.patch` records the relevant shared Provider changes. These controlled-streaming/TCP tests are backend contracts, not real-model or desktop evidence.

## Core typecheck original result

Original exec session `56306` was joined with exit 2. `typecheck-core.log` preserves both reported errors:

- `src/session/compaction.ts(97,18)`: TS4114 on the then-current source. **Correction:** the first version of this handoff incorrectly mapped that old line number onto a later source version and called it the `data` member. `NamedError` has no base `data` member. The later source has `override readonly name` and does not need `override` on `data`.
- `src/session/llm.ts(316,113)`: TS2322, the new prepared-request input expected `number` while the supplied `params.maxOutputTokens` was `number | undefined`.

Both belong to parallel compaction/LLM edits. `peer-type-failure-observed/` contains **post-failure observed** source copies, a diff and observation timestamp, not a claim that these exact bytes were the compiler's earlier input: both source files were last written at 20:37:09 UTC, after the original compiler completed at 20:32:08 UTC. The snapshot already has `override readonly name` and `params.maxOutputTokens ?? maxOutputTokens`. The original compiler output remains authoritative for the failed run; it cannot be mapped blindly to later source line numbers. No peer source was changed by this task.

Current status: focused tests passed, and the authorized package-script repeat passed with exit 0. See `package-script-repeat/reconciliation.md`; the old failure and the original mistaken handoff are preserved, and the correction is explicit.

## Other read-only handoffs

- `../settings-active-projection-review.md`: Settings active capability contract, the transient Provider module diagnosis and correction, and Scope08 Task/child/SideChat source/fact boundaries.
- `../manual-after-07/checker-handoff.md`: successful offline checks against saved original public facts; independent from Root's actual desktop review.

Root owns the separate real GPT-6.1 Sol allow and deny scopes, their desktop checks and their physical/credential cleanup receipts. This repeated backend run does not merge or replace those scope facts.
