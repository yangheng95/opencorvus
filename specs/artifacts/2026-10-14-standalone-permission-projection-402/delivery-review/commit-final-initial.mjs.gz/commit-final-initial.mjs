import fs from 'node:fs'
import path from 'node:path'
import {execFileSync} from 'node:child_process'
const root='.tmp-standalone-permission-projection-402',artifact='specs/artifacts/2026-10-14-standalone-permission-projection-402'
const git=(args,env=process.env,input)=>execFileSync('git',args,{env,input,encoding:'utf8',maxBuffer:64*1024*1024,windowsHide:true})
const walk=dir=>fs.readdirSync(dir,{withFileTypes:true}).flatMap(item=>item.isDirectory()?walk(dir+'/'+item.name):[dir+'/'+item.name])
const sdk=['packages/sdk/js/src/gen/types.gen.ts','packages/sdk/openapi.json']
const backend=JSON.parse(fs.readFileSync(root+'/implementation/handoff.json','utf8')).sourceFiles.filter(file=>!sdk.includes(file))
const denied=JSON.parse(fs.readFileSync(root+'/denied-continuation/files.json','utf8'))
const ui=JSON.parse(fs.readFileSync(root+'/ui-implementation-files.json','utf8')).changes.map(item=>item.file)
const unique=[...new Set([...backend,...denied,...ui,'specs/records/2026-10/2026-10-13-standalone-permission-projection-402.md',...walk(artifact)])]
const ops=JSON.parse(fs.readFileSync(root+'/final-shared-ops.json','utf8'))
const apply=(raw,file)=>{
 let text=raw.replaceAll('\r\n','\n')
 for(const [before,after]of ops[file]){
  const oldContainsNew=before.includes(after)&&before!==after
  if(!oldContainsNew&&text.includes(after))continue
  const occurrences=text.split(before).length-1
  if(occurrences===1)text=text.replace(before,after)
  else if(occurrences===0&&text.includes(after))continue
  else throw Error('Ambiguous or missing exact Root hunk '+file)
 }
 return text
}
const sdkPatch=fs.readFileSync(root+'/denied-continuation/sdk-final/sdk-total-from-head.patch','utf8').replaceAll('\r\n','\n')
const applySdk=env=>{
 try{git(['apply','--cached','--check','--whitespace=nowarn','-'],env,sdkPatch);git(['apply','--cached','--whitespace=nowarn','-'],env,sdkPatch);return 'Exact saved Root generation patch applied'}
 catch(error){git(['apply','--cached','--reverse','--check','--whitespace=nowarn','-'],env,sdkPatch);return 'Exact saved Root generation patch already present, verified by reverse dry check'}
}
const base=git(['rev-parse','HEAD']).trim(),env={...process.env,GIT_INDEX_FILE:path.resolve(root+'/index-final-'+Date.now())}
git(['read-tree',base],env);git(['add','-f','--',...unique],env)
const sdkState=applySdk(env),entries=[]
for(const file of Object.keys(ops))entries.push('100644 '+git(['hash-object','-w','--stdin'],env,apply(git(['show',base+':'+file]),file)).trim()+'\t'+file)
if(entries.length)git(['update-index','--index-info'],env,entries.join('\n')+'\n')
const changed=git(['diff','--cached','--name-only'],env).trim().split('\n'),allowed=new Set([...unique,...sdk,...Object.keys(ops)])
if(changed.some(file=>!allowed.has(file)))throw Error('Out-of-scope staged path')
git(['diff','--cached','--check'],env)
fs.writeFileSync(root+'/final-scoped.patch',git(['diff','--cached','--binary'],env))
fs.writeFileSync(root+'/final-stage.json',JSON.stringify({base,index:env.GIT_INDEX_FILE,sdkState,changed,unique,shared:Object.keys(ops)},null,2)+'\n')
console.log(git(['diff','--cached','--stat'],env))
if(process.argv[2]!=='--commit'){console.log('Prepared review only');process.exit(0)}
if(git(['rev-parse','HEAD']).trim()!==base)throw Error('HEAD advanced; prepare again')
console.log(git(['commit','-m','fix(permission): project canonical pending requests and continue denied turns'],env))
const commit=git(['rev-parse','HEAD']).trim(),receipt={base,commit,paths:changed,sdkState,indexReconciled:false}
fs.writeFileSync(root+'/final-commit.json',JSON.stringify(receipt,null,2)+'\n')
if(git(['rev-parse',commit+'^']).trim()!==base)throw Error('Unexpected concurrent parent; inspect exact commit before reconciliation')
const updates=git(['ls-tree',commit,'--',...unique]).trim().split('\n').map(line=>line.replace(' blob ',' '))
for(const file of Object.keys(ops)){const current=git(['show',':'+file]),next=apply(current,file);if(next!==current)updates.push('100644 '+git(['hash-object','-w','--stdin'],process.env,next).trim()+'\t'+file)}
if(updates.length)git(['update-index','--index-info'],process.env,updates.join('\n')+'\n')
receipt.sdkIndexState=applySdk(process.env);receipt.indexReconciled=true
fs.writeFileSync(root+'/final-commit.json',JSON.stringify(receipt,null,2)+'\n')
console.log('Scoped commit and live index reconciliation complete '+commit)
