import fs from 'node:fs'
import zlib from 'node:zlib'
import path from 'node:path'
const scratch='.tmp-standalone-permission-projection-402',archive='specs/artifacts/2026-10-14-standalone-permission-projection-402'
const manifest=JSON.parse(fs.readFileSync(archive+'/archive-manifest.json','utf8'))
const old=manifest.files.find(item=>item.source===scratch+'/final-root-recheck/README.md')
const retained=scratch+'/final-root-recheck/package-script-repeat/README-before-correction.md'
if(old&&!zlib.gunzipSync(fs.readFileSync(archive+'/'+old.path)).equals(fs.readFileSync(old.source))){
 if(!zlib.gunzipSync(fs.readFileSync(archive+'/'+old.path)).equals(fs.readFileSync(retained)))throw Error('Original README preserved copy identity mismatch')
 old.originalSource=old.source;old.source=retained;old.sourceHistory='Actual preserved pre-correction input; original archive bytes unchanged'
}
const selected=['commit-final-initial.mjs','commit-final.mjs','stage-final-review.log','stage-final-review.exit','stage-final-review02.log','stage-final-review02.exit','final-commit.json','commit-final.exit','docs-final.log','docs-final.exit','push-final01.log','push-final01.exit','api-final02.log','api-final02.exit','docs-final02.log','docs-final02.exit','add-delivery-evidence.mjs','freeze-root-facts.mjs']
const dir='final-root-recheck/package-script-repeat'
for(const item of fs.readdirSync(scratch+'/'+dir,{withFileTypes:true}))if(item.isFile()&&!item.name.startsWith('status-'))selected.push(dir+'/'+item.name)
for(const item of fs.readdirSync(scratch+'/'+dir+'/inputs',{withFileTypes:true}))if(item.isFile())selected.push(dir+'/inputs/'+item.name)
selected.push('final-root-recheck/README.md')
for(const relative of selected){
 const source=scratch+'/'+relative,original=fs.readFileSync(source),destination='delivery-review/'+relative+'.gz',stored=zlib.gzipSync(original,{level:9}),target=archive+'/'+destination
 if(fs.existsSync(target))throw Error('Keep delivery original '+destination)
 fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,stored)
 manifest.files.push({source,path:destination,compression:'gzip',sourceBytes:original.length,archivedBytes:stored.length})
}
fs.writeFileSync(archive+'/archive-manifest.json',JSON.stringify(manifest,null,2)+'\n')
fs.appendFileSync(archive+'/README.md','\n## Delivery review\n\n实现提交 `b3958bebf`。首推送经过实际八包全cache miss类型检查/0，随后API生成差异失败；旧核心类型错误的行号归因已由同一包声明复验0及原时序更正。delivery-review保留原失败、精确SDK patch范围准备、Windows NUL pathspec工具修复与原公开输入输出；旧README原字节保留，manifest另指向实际存留的pre-correction input。当前api:routes-check与docs:check已重复通过（6规则/35文件、345 ops/26 groups），正常上游同步与重推仍需原回执确认。没有修改peer Provider、生成SDK或绕过hook。\n')
console.log(JSON.stringify({newFiles:selected.length,total:manifest.files.length}))
