# 402 ETag identity correction — read-only, not approved for implementation

Root rejected the status-count proposal. I withdraw that recommendation: aggregate counts do not identify the assignment of state to each request and can collide when equal-time/current sets differ. The earlier spec/report text proposing counts is historical and must not be used as implementation approval. Root prohibited further spec changes during this follow-up, so this correction is recorded only in scratch and reported directly.

No production, spec, shared document, service, browser, model or test was changed/run by this review. 401 image review is separately recorded in its own scratch.

## 1. Complete current boardTag input audit

`workbench/board.ts:379–447` currently concatenates:

| Domain | Current tag input |
| --- | --- |
| Task | id, time_created, time_updated, max_executor_groups |
| Session tree | count, max Session time_updated, max lifecycle seq/time, max session.error seq/time |
| Goals | count, max time_updated |
| Interactions | count, max projected time_updated |
| Artifacts | count, max time_updated |
| Channel bindings | count, max time_updated |
| Progress snapshots | count, max time_created |

This is a collection of coarse revisions, not an exact identity of the full HTTP representation. `buildBoard:75–174` also includes the actual Task/Interaction views, Project id/name/worktree, channels and payloads, invocation topology, executionProjection, processIncidents, artifact locators/payloads, overview, brief, goal-derived fields and lastSequence. Some depend on the counted rows, but their individual identities and values are absent from the coarse tag. In particular lastSequence is in the response but not boardTag. `compileBrief` reads/writes its existing brief snapshot if its input signature changes; a full-board identity change would touch this performance/side-effect path and should not be smuggled into 402.

Task Permission Interaction is already the current ledger projection (`store.ts:758–785`), so the source to fingerprint is available. No additional permission state table, fake timestamp or summary counter is needed.

## 2. Correct minimal identity for the touched Interaction domain

Reuse the actual public projection already served by `buildBoard`:

```text
listInteractions(task.id).toReversed().map(viewInteraction)
```

`viewInteraction` (`engine/store.ts:1470–1505`) supplies the real interaction id, Task/Session/external request identities, request/response order keys, type, status, title/body, payload, response, and created/updated/resolved times. Array order is the current Board order. Keeping those per-entry values distinguishes request/state swaps and equal-millisecond resolutions, unlike aggregate counts or a max ledger time.

Use the existing `util/canonical-digest.ts` primitive, with a new explicit domain such as `task-board-interactions-v1`, over this complete **JSON response projection**. That primitive recursively sorts object keys, preserves array order and computes SHA-256. `viewInteraction` intentionally has undefined properties; canonicalDigestSource rejects undefined, whereas the HTTP JSON serializer omits them. Therefore first materialize the same JSON-visible value (normal JSON serialization/parse), then canonicalize it. Do not hand-select a few fields or replace undefined by arbitrary nulls: the fingerprint should describe what this endpoint actually exposes.

Replace the old Interaction count/max-time pair in boardTag with that domain fingerprint. Other existing domain inputs remain as they are. This is a scoped correction of the Interaction component of the validator, including its existing Question/Permission consumers; **it is not a claim that every other Board domain now has a complete ETag**. Hashing actual protocol representation identity is permitted and meaningful. The prohibition on mutable source hashes as acceptance gates does not apply to a real HTTP conditional-request validator.

The relevant standard is [RFC 9110 ETag generation](https://www.rfc-editor.org/rfc/rfc9110.html#section-8.8.3.1): a representation-derived validator is an ordinary strategy; its equality has to match the intended representation equivalence. [If-None-Match](https://www.rfc-editor.org/rfc/rfc9110.html#section-13.1.2) determines whether a cached representation can be reused. Neither standard supports substituting a count that loses request identity.

## 3. Pair the computed identity with the response actually returned

Two current repeated reads matter:

- `compileBoard` calls boardTagForTask, which reads listInteractions; buildBoard reads listInteractions again. Concurrent ledger progress can produce a tag from one projection and a body from another.
- `/task/:id/board` awaits getBoardTag, sets that old tag as response header, then calls getBoard for a fresh body (`routes/orchestrator.ts:1310–1320`). Thus even fixing only tag contents leaves a potential 200 header/body mismatch.

For the scoped Interaction correction, materialize the ordered Interaction views once inside compileBoard and pass the same immutable local value to boardTagForTask and buildBoard. This is a single request-local read model, not persistent shadow state. The lightweight boardTag function can independently use the same projector when checking a conditional request.

For a 200 response, set the ETag from **that returned board's snapshotVersion**, not from the earlier preliminary tag check. A matching preliminary tag may still return 304 based on the current snapshot at that check; a nonmatching check followed by a newer body must return the newer body's version. This needs `server/routes/orchestrator.ts` in the proposed allowlist in addition to `workbench/board.ts`, while preserving public source/Project validation in EngineService.

If Root wants a complete validator for every Board field instead of a bounded Interaction-domain correction, the principled alternative is to build one full JSON response projection, compute its canonical semantic identity excluding only the self-referential snapshotVersion, then return that same projection plus its derived version. A semantic canonical validator should be marked weak unless the exact emitted serialization bytes are the hashed identity. This would replace the whole coarse tag function/fast path and requires separate review of every domain, brief materialization, query cost and getBoardTag callers. It is broader than the current approved investigation and is not an implicit implementation recommendation.

## 4. Positive backend contracts for the scoped proposal

Proposed acceptance must use the real Board endpoint and real Permission/Interaction projections, not merely compare a hand-built digest with itself:

- Same-ms pending Permission → authoritative cancelled/stale yields a conditional GET 200 containing the exact original interaction id, current projected rejected status and actual ledger time; a subsequent unchanged conditional GET yields 304.
- Two equal-time requests with the same aggregate status counts but different per-request projections yield their respective current body and distinct Interaction-domain identity. The setup must use legal immutable facts/recovery histories, not mutate a settled ledger row to force the scenario.
- A changed response payload/order/identity is reflected by the same public view source; unchanged JSON-visible data with different internal object key insertion ordering has equivalent canonical identity.
- A ledger change between the preliminary tag check and getBoard returns a 200 header equal to the actual body.snapshotVersion; the body and its Interaction fingerprint come from one materialized list.
- Task terminal live notification still follows the previously proposed dedicated Terminated subscriber and existing Task Board refresh path. No resolvePermission/userInput/outcome/Task-state write is introduced to alter the validator.

No such tests, source assertions, UI tests or runtime probes were run here. Root still needs to approve the exact scope and then validate the public contract. Other Board-domain cache collisions, raw conditional-header parsing/quoting and full-resource HTTP validator completeness should not be represented as repaired by an Interaction-only fingerprint.
