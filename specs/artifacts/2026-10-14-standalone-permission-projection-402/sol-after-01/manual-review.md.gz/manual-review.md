# Root真实Native Sol：修复后01

2026-10-14，原生Bun1.3.14与正式402 private UI相邻资源，成熟生产foreground ProcessFacade/ProcessSupervisor Windows Job。完整配对auth/models复制在同一自有runtime；只有成熟wrapper读取用于既有授权实际Provider，无凭据内容进入prompt/本说明。preflight-ready真实credential usable/catalog projected/actualModel gpt-6.1-sol/streaming true。原occurrence sol-402-a01-ce17815a-a98e-4e28-aa4c-9049cec8ce7b、Target1852、Host47908，原deadline1791919809271/closeBy1791919749271，20请求/180秒无活动预算保持。

Root公开53B CSV为batch/item/quantity、CEDAR402/Maple/3、CEDAR402/Iris/4。真实global/config ask→global/chat/start产生ses_hT15F5M9RJinMAmWLSyG/prj_hy5eXNTXb1bzqX9gl2fm。真实模型自然read tool call_92AurftSGBOMExXnrDyweyn3，Permission per_hLfOS1fdq3xK8R5gOEeZ/time1791919291016；真实HTTP pending/hydrate同ID/时间/interaction orderKey，原observation完整保存。

IAB4自有tab3真实/UI 1280×720。Root通过Appearance语言控件改此隔离origin为简体中文，返回选择上述会话。人工查看sol-main-permission-dialog-zh.jpg：中文权限请求/本次允许/始终允许精确范围/拒绝及提示，原技术scope/工具身份保留。实际点击Dialog“本次允许”，自然事实清卡并继续工具/模型。原JPEG未经裁切重编码，无DOM断言或UI自动测试。

真实checker-actual.ts exit0：只读绑定原数据库，真实用户文本/GlobalChat allocation/Session/Project/policy/不可变ledger/Tool输出/assistant模型身份/Provider公开projection核对。账本requested→allowed_once→execution_started→execution_succeeded，read完整三行输出，assistant msg_g0VXxWvqc00M6JdyF0yL finish stop。Root人工查看sol-main-answer-zh.jpg与实际答案：批次CEDAR402、Maple3、Iris4、合计7、原文件第2–3行引用均正确。五个实际请求均gpt-6.1-sol、stream true、200、reader settled/eof，包括同scope preflight/helper请求；不是五个业务turn或五项不同覆盖。未保存原Provider payload用于公开归档，仅保存明确投影。

Root先close tab3（page-closed.json）再正常公共shutdown。shutdown.exit0，原launch exec32239最终join/exit0；qualified-surface-completion为NativeService/5EOF/physical true。physical-terminal-and-pair-cleanup确认原Host/Target完整身份都已不在、端口释放，Native naturalexit0，outputDrain/requestCleanup均true；原配对auth2194B/models9155406B均removed/presentAfterfalse。全部在原deadline内，未延长、强杀、覆盖旧395失败或冒称Task/Mission/deny/Question/SideChat已通过。
