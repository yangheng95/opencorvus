import assert from 'node:assert/strict'
import fs from 'node:fs/promises'
import path from 'node:path'
import { randomUUID } from 'node:crypto'
import { fileURLToPath } from 'node:url'
const [root,mode]=process.argv.slice(2)
assert(root&&path.isAbsolute(root));assert.equal(path.dirname(path.resolve(root)),path.dirname(fileURLToPath(import.meta.url)))
assert(['start','observe'].includes(mode))
const json=async(name)=>JSON.parse(await fs.readFile(path.join(root,name),'utf8'))
const record=(name,value)=>fs.writeFile(path.join(root,name),JSON.stringify(value,null,2)+'\n',{flag:'wx'})
const owner=await json('provider-run/launch-owner.json'),preflight=await json('provider-run/evidence/preflight-ready.json'),native=await json('provider-run/evidence/native-host-ready.json')
assert.equal(path.resolve(owner.runtime),path.join(root,'provider-run/runtime'))
assert.equal(owner.qualificationKind,'NativeService');assert.equal(owner.requestBudget,20);assert.equal(owner.inactivityMilliseconds,180000);assert.equal(owner.handleAdmissionMilliseconds,600000)
assert(owner.nativeDeadlineAt>owner.targetBirthAtMs&&owner.nativeDeadlineAt-owner.targetBirthAtMs<=600000)
assert.equal(preflight.occurrence,owner.occurrence);assert.equal(native.occurrence,owner.occurrence);assert.equal(native.deadlineAt,owner.nativeDeadlineAt)
assert.deepEqual(owner.profileSelection,{kind:'builtin',namespace:'builtin',id:'base'})
assert.deepEqual({credential:preflight.preflight.credential,catalog:preflight.preflight.catalog,model:preflight.preflight.actualModel,streaming:preflight.preflight.streaming},{credential:'usable',catalog:'projected',model:'gpt-6.1-sol',streaming:true})
const base=`http://127.0.0.1:${owner.port}`,closeBy=owner.nativeDeadlineAt-60000,pageReserveAt=owner.nativeDeadlineAt-180000
const api=async(route,method='GET',body,directory)=>{
 assert(Date.now()<closeBy,'Original native close boundary')
 const response=await fetch(base+route,{method,headers:{'content-type':'application/json',...(directory?{'x-opencorvus-directory':directory}:{})},...(body===undefined?{}:{body:JSON.stringify(body)}),signal:AbortSignal.timeout(Math.min(15000,closeBy-Date.now()))})
 return {status:response.status,result:await response.json(),observedAt:new Date().toISOString()}
}
try{
 if(mode==='start'){
  assert(owner.nativeDeadlineAt-Date.now()>=240000,'Reserve original four-minute business/page window')
  const config=await api('/global/config','PATCH',{permission_mode:'ask'})
  assert.equal(config.status,200);assert.deepEqual({mode:config.result.permission_mode,profile:config.result.prompt_profile.active,model:config.result.model},{mode:'ask',profile:'base',model:'openai/gpt-6.1-sol'})
  await record('public-global-config-facts.json',{occurrence:owner.occurrence,mode:config.result.permission_mode,profile:config.result.prompt_profile.active,model:config.result.model})
  const publicPath=await fs.realpath(path.join(root,'public-external.csv'))
  assert.deepEqual(await fs.readFile(publicPath),Buffer.from('batch,item,quantity\nCEDAR402,Maple,3\nCEDAR402,Iris,4\n'))
  const request={requestID:randomUUID(),model:'openai/gpt-6.1-sol',text:`请用文件读取功能查看这份公开CSV：${publicPath}。它位于当前会话项目之外；如出现授权请求，请等待我在界面确认。读取后用中文说明批次代号、两行项目及各自数量、合计，并引用原文件。`}
  await record('global-chat-start-request.json',request)
  const accepted=await api('/global/chat/start','POST',request)
  await record('global-chat-start-response.json',accepted)
  assert.equal(accepted.status,202);assert.equal(accepted.result.requestID,request.requestID)
  const session=accepted.result.session,projects=await fs.realpath(path.join(owner.runtime,'data/projects')),directory=await fs.realpath(session.directory),relative=path.relative(projects,directory)
  assert(relative&&!relative.startsWith('..')&&!path.isAbsolute(relative))
  assert(path.relative(directory,publicPath).startsWith('..'))
  const ready={occurrence:owner.occurrence,sessionID:session.id,projectID:session.projectID,directory,initialMessageID:accepted.result.messageID,requestID:request.requestID,nativeDeadlineAt:owner.nativeDeadlineAt,pageReserveAt,closeBy,url:base+'/ui',publicPath}
  await record('ready.json',ready);console.log(JSON.stringify(ready,null,2))
 }else{
  const ready=await json('ready.json');assert.equal(ready.occurrence,owner.occurrence)
  const pending=await api('/permission','GET',undefined,ready.directory),messages=await api(`/session/${ready.sessionID}/message`,'GET',undefined,ready.directory),conversation=await api(`/session/${ready.sessionID}/conversation`,'GET',undefined,ready.directory)
  await record(`observation-${Date.now()}.json`,{occurrence:owner.occurrence,pending,messages,conversation})
  console.log(JSON.stringify({pending:pending.result.filter(item=>item.sessionID===ready.sessionID),messages:messages.result.map(item=>({id:item.info.id,role:item.info.role,finish:item.info.finish,completedAt:item.info.time.completed,error:item.info.error?.name})),snapshotPermissions:conversation.result.pendingPermissions,remainingMs:owner.nativeDeadlineAt-Date.now(),closeBy},null,2))
 }
}catch(error){await record(`helper-failure-${mode}-${Date.now()}.json`,{occurrence:owner.occurrence,error:String(error),nativeDeadlineAt:owner.nativeDeadlineAt,closeBy,boundary:'Failure does not settle original native owner'});throw error}
