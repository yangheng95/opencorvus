# 402 实时 Permission summary 修复证据

Root 已在 402 spec“实时权限正文覆盖”节完整批准后实施。本范围仅 `packages/opencorvus/src/protocol/session-mirror.ts` 和 `packages/opencorvus/test/server/session-permission-projection.test.ts`。没有修改前端九文件、SDK、mapper 诊断文案、权限终态/processor/loop/config、共享文档或 Git。

生产仅调整两个既有 payload 组装顺序：先写现有 diagnostic summary，再展开 canonical mapped.payload；Task 分支仍最后赋 canonical taskID。真正 Request.summary 不再被英文 envelope 描述覆盖；其它没有业务 summary 的 mapped 事件继续使用原诊断值。ProtocolStore 仍由同一 payload.summary 产生事件摘要，没有第二字段或前端补偿。

测试在现有实际 live Asked case 中读真实 Authority Request、HTTP cold conversation、第二个真实 ordered Session connection snapshot，再比较完整公开 Request 与 summary。完整 Request 用现成 PermissionAuthority.Request schema 投影，预期值来自原 Bus Asked 的真实 canonical Request，而非重新生成摘要。第二条流在局部 finally 中 abort/cancel，原 stale/outbox/执行清理仍保持。

## 红绿与类型结果

- 先只改测试，原生产保持。`red.log`：8 pass / 1 fail / 39 断言，唯一完整 Request 差异是 warm summary：预期 `write (write_local)`，实际 `Permission requested: write`。原 mapper-only transport 检查继续通过。原 exec session 63426 最终 chunk 1e3fbc，exit 1。
- 再修改两个生产组装点。`green.log`：9 pass / 0 fail / 43 断言；暖流完整 Request、warm/envelope/cold/connected summary 一致，原 stale/outbox、两个 Project、连接切换和真实 TCP allow_once 路径继续通过。原 exec session 51094 最终 chunk a7b8d4，exit 0。
- 核心 `bun run typecheck`：exit 0，原 exec session 93019 最终 chunk abcf39。

所有命令用 Root 指定 Bun 1.4.0 和现有标准 isolated runner；没有直接运行裸全量 bun test。`run-check.ps1` 保存可复用命令，三个 `*-command.json` 保存实际程序/参数/cwd/时间/包装 PID，`.log` 为完整输出，`.exit` 为实际退出码。三个原 exec 最终退出且输出关闭；`handoff.json` 保留工具会话回执和事后包装进程不存在的只读观察。标准 runner 的实际每文件 DONE 行和 finally 按原 settlementConfirmed 清理隔离运行根，无新增停止或终态逻辑。

## 有界输入与差异

- `scope-before.json` 与 `before/`：实施前两文件原字节。
- `red-test-input.ts`：红测实际测试输入；对应生产为 before/session-mirror.ts。
- `green-session-mirror.ts`、`green-session-permission-projection.test.ts`：本次绿测的同一源输入。
- `summary-fix.patch` 与 `scope-changes.json`：相对于本子步骤前态的精确差异，生产 2 增/2 删，测试 32 增/1 删。差异只供范围复核，不代替功能测试或视觉验收。

Root 后续重新取得 Main/SideChat 冷暖正文真实页面证据；没有因此重构建前端。自然 deny 后 Session durable terminal 异常仍属另一个共享后台审计，本处测试通过不能冒称该完整 deny 链已修复。
