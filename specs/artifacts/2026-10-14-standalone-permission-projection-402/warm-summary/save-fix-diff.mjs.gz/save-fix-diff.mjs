import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
const root = 'D:/myhexin-local/opencorvus';
const scope = path.join(root, '.tmp-standalone-permission-projection-402/warm-summary');
const require = createRequire(path.join(root, 'packages/overlay/package.json'));
const { createTwoFilesPatch, diffLines } = require('diff');
const manifest = JSON.parse(fs.readFileSync(path.join(scope, 'scope-before.json'), 'utf8'));
const changes = [];
let patch = '';
for (const item of manifest.files) {
  const before = fs.readFileSync(path.join(scope, item.before), 'utf8');
  const after = fs.readFileSync(path.join(root, item.file), 'utf8');
  patch += createTwoFilesPatch(`a/${item.file}`, `b/${item.file}`, before, after);
  fs.writeFileSync(path.join(scope, `green-${path.basename(item.file)}`), after, { flag: 'wx' });
  const segments = diffLines(before, after);
  changes.push({ file: item.file, added: segments.filter(item => item.added).reduce((sum, item) => sum + item.count, 0), removed: segments.filter(item => item.removed).reduce((sum, item) => sum + item.count, 0) });
}
fs.writeFileSync(path.join(scope, 'summary-fix.patch'), patch, { flag: 'wx' });
fs.writeFileSync(path.join(scope, 'scope-changes.json'), JSON.stringify({ capturedAt: new Date().toISOString(), changes }, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify(changes));
