param(
  [Parameter(Mandatory = $true)]
  [ValidateSet('red', 'green', 'typecheck')]
  [string]$Stage
)

$summaryRoot = 'D:/myhexin-local/opencorvus'
$summaryScope = Join-Path $summaryRoot '.tmp-standalone-permission-projection-402/warm-summary'
$summaryWorkdir = Join-Path $summaryRoot 'packages/opencorvus'
$summaryLog = Join-Path $summaryScope ($Stage + '.log')
$summaryExitFile = Join-Path $summaryScope ($Stage + '.exit')
$summaryRecord = Join-Path $summaryScope ($Stage + '-command.json')
foreach ($summaryOutput in @($summaryLog, $summaryExitFile, $summaryRecord)) {
  if (Test-Path -LiteralPath $summaryOutput) { throw "Refusing to replace original evidence: $summaryOutput" }
}
$env:PATH = (Join-Path $summaryRoot '.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64;') + $env:PATH
Set-Location -LiteralPath $summaryWorkdir
$summaryExecutable = (Get-Command bun).Source
if ($Stage -eq 'typecheck') {
  $summaryArguments = @('run', 'typecheck')
} else {
  $summaryArguments = @('run', 'test', 'test/server/session-permission-projection.test.ts', 'test/permission-transport-hydration.test.ts')
}
$summaryMetadata = [ordered]@{
  stage = $Stage
  executable = $summaryExecutable
  arguments = $summaryArguments
  cwd = $summaryWorkdir
  wrapperPid = $PID
  startedAt = [DateTime]::UtcNow.ToString('o')
  status = 'running'
}
[System.IO.File]::WriteAllText($summaryRecord, ($summaryMetadata | ConvertTo-Json -Depth 5))
& $summaryExecutable @summaryArguments *> $summaryLog
$summaryExitCode = $LASTEXITCODE
$summaryMetadata.status = 'exited'
$summaryMetadata.finishedAt = [DateTime]::UtcNow.ToString('o')
$summaryMetadata.exitCode = $summaryExitCode
[System.IO.File]::WriteAllText($summaryRecord, ($summaryMetadata | ConvertTo-Json -Depth 5))
[System.IO.File]::WriteAllText($summaryExitFile, [string]$summaryExitCode)
Get-Content -LiteralPath $summaryLog -Tail 90
exit $summaryExitCode
