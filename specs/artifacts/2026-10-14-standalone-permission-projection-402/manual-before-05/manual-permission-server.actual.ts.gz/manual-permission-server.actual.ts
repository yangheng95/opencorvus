import fs from 'node:fs/promises'
import path from 'node:path'
import { randomUUID } from 'node:crypto'
import { bootstrapIsolatedTestRuntime, applyIsolatedTestUserEnvironment, removeIsolatedTestRuntime } from '../packages/util/src/test-runtime-environment'
import { phaseBConfig, phaseBSessionCreate, phaseBMessage } from '../.tmp-native-shutdown-pending-permission-403/phase-b-input'
const [directory,uiDirectory,originalDeadline]=process.argv.slice(2)
if(!directory||!uiDirectory||!path.isAbsolute(directory)||!path.isAbsolute(uiDirectory))throw Error('Explicit absolute scope and private UI required')
if(path.dirname(path.resolve(directory))!==path.resolve('.tmp-standalone-permission-projection-402'))throw Error('Owned 402 scope only')
await fs.mkdir(directory,{recursive:false})
const isolated=await bootstrapIsolatedTestRuntime('runner')
applyIsolatedTestUserEnvironment(isolated)
const project=path.join(directory,'project'),runtime=isolated.runtimeRoot,externalFile=path.join(directory,'public-external.csv')
await fs.mkdir(project,{recursive:true})
await fs.writeFile(externalFile,'item,quantity\nCedar402,3\nIris402,4\n',{flag:'wx'})
const catalog=path.join(directory,'public-model-catalog.json')
await fs.writeFile(catalog,'{}\n',{flag:'wx'})
process.env.OPENCORVUS_HOME=runtime
process.env.OPENCORVUS_MODELS_PATH=catalog
process.env.OPENCORVUS_PROJECT_DIR=project
process.env.OPENCORVUS_DISABLE_AUTOUPDATE='1'
process.env.OPENCORVUS_DISABLE_EXTERNAL_SKILLS='1'
process.env.OPENCORVUS_DISABLE_CLAUDE_CODE='1'
process.env.OPENCORVUS_RUNTIME_MEMORY_METRICS_INTERVAL_MS='300000'
const {startControlledStreamingProvider}=await import('../packages/opencorvus/test/fixture/controlled-streaming-provider')
const provider=startControlledStreamingProvider({firstPromptToolCall:{name:'read',arguments:{filePath:externalFile}}})
const {installProcessShims}=await import('../packages/opencorvus/src/runtime/shims')
installProcessShims()
const {freezeOverlayUiDirectory}=await import('../packages/opencorvus/src/server/overlay-ui')
const {Instance}=await import('../packages/opencorvus/src/project/instance')
const {listenWithRecoveredServerRuntime}=await import('../packages/opencorvus/src/cli/server-runtime')
const {recoverStartedTaskExecutions,assertStartedTaskProjectRecoverySucceeded}=await import('../packages/opencorvus/src/engine/host-recovery')
const startedAt=Date.now(),deadlineAt=Number(originalDeadline),closeBy=deadlineAt-60000
if(!Number.isSafeInteger(deadlineAt)||deadlineAt<=startedAt||deadlineAt>startedAt+600000)throw Error('Original owned physical deadline required')
const observed=await listenWithRecoveredServerRuntime({options:{hostname:'127.0.0.1',port:0,randomPort:true,overlayUiSource:freezeOverlayUiDirectory({directory:uiDirectory})},recover:async()=>{const recovery=await recoverStartedTaskExecutions({scopeProjectWorktree:project});assertStartedTaskProjectRecoverySucceeded(recovery)},disposeInstances:()=>Instance.disposeAll()})
await observed.recovery
const base=`http://127.0.0.1:${observed.server.port}`
const headers={'content-type':'application/json','x-opencorvus-directory':project}
const release=setInterval(()=>{for(const request of provider.requests)request.release()},25)
const configResponse=await fetch(base+'/global/config',{method:'PATCH',headers,body:JSON.stringify(phaseBConfig(provider.apiURL))})
const configured=await configResponse.json()
await fs.writeFile(path.join(directory,'public-global-config.json'),JSON.stringify({status:configResponse.status,configured},null,2))
if(configResponse.status!==200)throw Error('Owned public fixture configuration failed')
const body={requestID:randomUUID(),model:'shutdown-fixture/session-prompt-owner-model',text:`Read the public CSV at ${externalFile} and report its rows.`}
const created=await fetch(base+'/global/chat/start',{method:'POST',headers,body:JSON.stringify(body)})
const acceptance=await created.json() as any
const session=acceptance.session
if(created.status!==202||!session?.id||!path.resolve(session.directory).startsWith(path.resolve(runtime)+path.sep))throw Error('Real public Global Chat creation failed')
await fs.writeFile(path.join(directory,'global-chat-start.json'),JSON.stringify({status:created.status,body,acceptance},null,2))
await fs.writeFile(path.join(directory,'ready.json'),JSON.stringify({pid:process.pid,occurrence:observed.occurrence,startedAt,deadlineAt,closeBy,port:observed.server.port,url:base+'/ui',project,runtime,sessionID:session.id,session,uiDirectory,provider:'public controlled streaming fixture; no real Provider qualification',pageAcceptance:'Root manual only; no UI test'},null,2))
console.log(JSON.stringify({ready:true,url:base+'/ui',sessionID:session.id,deadlineAt,closeBy}))
let closing=false
async function close(reason:string){
 if(closing)return;closing=true;clearInterval(poll);clearTimeout(deadline)
 try{
  await observed.server.stop(true);await observed.recovery
  clearInterval(release);for(const request of provider.requests)request.release();await provider.server.stop(true)
  const requests=provider.requests.map(({index,kind,body})=>({index,kind,model:(body as any)?.model,stream:(body as any)?.stream}))
  await fs.writeFile(path.join(directory,'terminal.json'),JSON.stringify({reason,pid:process.pid,occurrence:observed.occurrence,finishedAt:Date.now(),requests,physical:'process natural exit follows output drain in original owned NodeProcess',serverAndProviderStopped:true},null,2))
  await removeIsolatedTestRuntime(isolated);process.exit(0)
 }catch(error){console.error(error);process.exit(1)}
}
const poll=setInterval(async()=>{try{await fs.stat(path.join(directory,'stop-requested'));void close('Own manual page closed')}catch(error){if((error as NodeJS.ErrnoException).code!=='ENOENT')void close('Owned stop observation failed')}},500)
const deadline=setTimeout(()=>void close('Original fixed close reserve reached'),closeBy-Date.now())
