import fs from 'node:fs/promises'
import path from 'node:path'
import { bootstrapIsolatedTestRuntime,applyIsolatedTestUserEnvironment,removeIsolatedTestRuntime } from '../packages/util/src/test-runtime-environment'
import { NodeProcess } from '../packages/util/src/process-node'
import { prepareTestProcessSupervisor } from '../packages/opencorvus/script/prepare-test-process-supervisor'
const [directory,uiDirectory,scenario='read']=process.argv.slice(2)
if(!['read','warm-read','warm-question','side-read'].includes(scenario))throw Error('Explicit owned scenario required')
if(!path.isAbsolute(directory)||path.dirname(path.resolve(directory))!==path.resolve('.tmp-standalone-permission-projection-402'))throw Error('Owned fresh 402 scope only')
try{await fs.stat(directory);throw Error('Keep original scope')}catch(error){if((error as NodeJS.ErrnoException).code!=='ENOENT')throw error}
const isolated=await bootstrapIsolatedTestRuntime('runner')
applyIsolatedTestUserEnvironment(isolated)
const supervisor=prepareTestProcessSupervisor()
const env=Object.fromEntries(Object.entries(process.env).filter(([name])=>/^(PATH|SystemRoot|WINDIR|ComSpec|PATHEXT|HOME|HOMEDRIVE|HOMEPATH|USERPROFILE|APPDATA|LOCALAPPDATA|TEMP|TMP|TMPDIR|XDG_CONFIG_HOME|XDG_DATA_HOME|XDG_CACHE_HOME|XDG_STATE_HOME|OPENCORVUS_(TEST_|HOME))/i.test(name)))
if(supervisor){env.OPENCORVUS_PROCESS_SUPERVISOR=supervisor;process.env.OPENCORVUS_PROCESS_SUPERVISOR=supervisor}
const startedAt=Date.now(),deadlineAt=startedAt+600000
await fs.writeFile(directory+'.runtime-owner.json',JSON.stringify(isolated,null,2),{flag:'wx'})
let handle: Awaited<ReturnType<typeof NodeProcess.spawn>>|undefined
try {
handle=await NodeProcess.spawn({command:{executable:path.resolve('.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64/bun.exe'),args:[path.resolve('.tmp-standalone-permission-projection-402/manual-permission-server.ts'),directory,uiDirectory,String(deadlineAt),scenario]},ownership:'owned_tree',windowsHide:true,stdin:'ignore',env,deadlineAt})
await fs.writeFile(directory+'.launch.json',JSON.stringify({pid:handle.pid,occurrence:handle.occurrenceID,startedAt,deadlineAt,closeBy:deadlineAt-60000,purpose:'Own manual controlled streaming Main permission UI; no real Provider qualification'},null,2))
const drain=async(stream:any,suffix:string)=>{if(stream)for await(const bytes of stream)await fs.appendFile(directory+'.'+suffix,bytes)}
const drains=Promise.all([drain(handle.stdout,'stdout.log'),drain(handle.stderr,'stderr.log')])
const receipt=await handle.settled;await drains
await fs.writeFile(directory+'.physical-terminal.json',JSON.stringify(receipt,null,2))
await handle.outputSettled
console.log(JSON.stringify(receipt))
if(receipt.reason!=='exited'||receipt.exitCode!==0)process.exitCode=1
}finally{if(handle)await handle.settled;await removeIsolatedTestRuntime(isolated)}
