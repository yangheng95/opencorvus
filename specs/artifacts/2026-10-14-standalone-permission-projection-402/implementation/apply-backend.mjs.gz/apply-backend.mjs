import fs from "node:fs/promises"
import path from "node:path"
const root = path.resolve(import.meta.dirname, "../..")
const src = p => path.join(root, "packages/opencorvus/src", p)
async function edit(p, transform) { const before = await fs.readFile(src(p), "utf8"); const after = transform(before.replaceAll("\r\n", "\n")); if (after === before.replaceAll("\r\n", "\n")) throw new Error(`No change: ${p}`); await fs.writeFile(src(p), after) }
function replace(s, a, b) { if (!s.includes(a)) throw new Error(`Missing source: ${a.slice(0,100)}`); return s.replace(a,b) }

const authority = (await fs.readFile(src("permission/authority.ts"), "utf8")).replaceAll("\r\n", "\n")
const invocation = (await fs.readFile(src("permission/invocation.ts"), "utf8")).replaceAll("\r\n", "\n")
const identity = authority.slice(authority.indexOf("  export const Identity ="), authority.indexOf("  export const Decision ="))
const request = authority.slice(authority.indexOf("  export const Request ="), authority.indexOf("  export const LedgerEvent ="))
const provider = invocation.slice(invocation.indexOf("export const PermissionProviderKind ="), invocation.indexOf("export const ToolInvocationProviderKind ="))
await fs.writeFile(src("permission/types.ts"), `import z from "zod"\nimport { Identifier } from "@/id/id"\nimport { PermissionDecision } from "./decision"\n\n${provider}\n${identity.replace(/^  /gm, "").replaceAll("Identity", "PermissionIdentity").replaceAll("Mode", "PermissionMode").replaceAll('ref: "PermissionPermission', 'ref: "Permission')}\n${request.replace(/^  /gm, "").replaceAll("Request", "PermissionRequest").replaceAll("id: Identity", "id: PermissionIdentity").replaceAll("mode: Mode", "mode: PermissionMode").replaceAll("choices: Decision.array()", "choices: PermissionDecision.array()").replaceAll('ref: "PermissionPermissionRequest"', 'ref: "PermissionRequest"')}`)
await edit("permission/invocation.ts", s => replace(s, provider, 'import { PermissionProviderKind } from "./types"\nexport { PermissionProviderKind } from "./types"\n'))
await edit("permission/authority.ts", s => {
  s = replace(s, 'import { PermissionDecision } from "./decision"', 'import { PermissionDecision } from "./decision"\nimport { PermissionIdentity, PermissionMode, PermissionRequest } from "./types"')
  s = replace(s, identity, '  export const Identity = PermissionIdentity\n  export const Mode = PermissionMode\n  export type Mode = z.infer<typeof Mode>\n\n')
  s = replace(s, request, '  export const Request = PermissionRequest\n  export type Request = z.infer<typeof Request>\n\n')
  s = replace(s, '    Asked: BusEvent.define("permission.asked", Request),', '    Asked: BusEvent.define("permission.asked", Request),\n    Terminated: BusEvent.define("permission.terminated", z.object({\n      projectID: z.string().min(1),\n      sessionID: z.string().min(1),\n      requestID: Identity,\n      ledgerEventID: Identity,\n      status: z.enum(["cancelled", "stale"]),\n    })),')
  const at = '  async function releaseDecisionWaiters(request: Request, settled: LedgerRow): Promise<number> {'
  s = replace(s, at, `  async function settlePendingTermination(
    request: Request,
    status: "cancelled" | "stale",
    extra: Partial<typeof PermissionLedgerTable.$inferInsert>,
  ): Promise<{ settled: LedgerRow; won: boolean }> {
    let publication: Bus.Publication | undefined
    const result = Database.transaction((db) => {
      const decision = settleDecisionInTransaction(db, request, status, extra)
      if (decision.won) {
        publication = Bus.publishOwnedInTransaction(Event.Terminated, {
          projectID: request.projectID,
          sessionID: request.sessionID,
          requestID: request.id,
          ledgerEventID: decision.settled.id,
          status,
        })
      }
      return decision
    })
    if (publication) await publication.retry()
    return result
  }

${at}`)
  s = replace(s, 'const { settled } = settleDecision(request, "stale", {', 'const { settled } = await settlePendingTermination(request, "stale", {')
  s = replace(s, 'const { settled, won } = settleDecision(request, "cancelled", {', 'const { settled, won } = await settlePendingTermination(request, "cancelled", {')
  return s
})
await edit("engine/task-session-lineage.ts", s => replace(s, 'function loadAndCache(sessionID: string) {', `/** Permission cards in Session conversations exclude the existing Task owner.
 * Question and transcript admission keep their own established contracts. */
export function isStandalonePermissionSession(sessionID: string, projectID: string): boolean {
  const lineage = sessionLineageIdentity(sessionID)
  return Boolean(lineage && lineage.projectID === projectID && taskIDForSession(sessionID) === undefined)
}

function loadAndCache(sessionID: string) {`))
await edit("engine/model.ts", s => {
  s = replace(s, 'import z from "zod"', 'import z from "zod"\nimport { PermissionRequest } from "@/permission/types"')
  s = replace(s, 'export const SessionPendingQuestion =', 'export const SessionPendingPermission = PermissionRequest.extend({ orderKey: z.string().min(1) })\n\nexport const SessionPendingQuestion =')
  s = replace(s, 'export const SessionConversationConnectionSnapshot = z\n  .object({', 'export const SessionConversationConnectionSnapshot = z\n  .object({\n    pendingPermissions: SessionPendingPermission.array(),')
  s = replace(s, '  "permission.replied",', '  "permission.replied",\n  "permission.terminated",')
  s = replace(s, '  pendingQuestions: SessionPendingQuestion.array(),', '  pendingQuestions: SessionPendingQuestion.array(),\n  pendingPermissions: SessionPendingPermission.array(),')
  return s
})
await edit("protocol/session-mirror.ts", s => {
  s = replace(s, 'import { sessionRole, taskIDForSession }', 'import { isStandalonePermissionSession, sessionRole, taskIDForSession }')
  s = replace(s, 'import { currentProjectDirectory }', 'import { Instance } from "@/project/instance"\nimport { currentProjectDirectory }')
  s = replace(s, 'export function pendingPermissionSessionEvent', `export function permissionRequestOrderKey(request: Pick<PermissionAuthority.Request, "id" | "timeCreated">): string {
  return timelineOrderKey({ domain: "interaction", time: request.timeCreated, id: request.id })
}

export function standalonePendingPermission(request: PermissionAuthority.Request, projectID: string) {
  if (request.projectID !== projectID) return
  const owner = taskIDForSession(request.sessionID)
  if (owner !== request.taskID) throw new Error("Permission " + request.id + " Task ownership differs from durable Session lineage")
  if (!isStandalonePermissionSession(request.sessionID, projectID)) return
  return { ...request, orderKey: permissionRequestOrderKey(request) }
}

export function pendingPermissionSessionEvent`)
  s = replace(s, 'if (event.type === PermissionAuthority.Event.Asked.type) {\n    const payload = stampSessionEventPayload(sessionID, props)', 'if (event.type === PermissionAuthority.Event.Asked.type) {\n    const request = PermissionAuthority.Request.parse(props)\n    const payload = stampSessionEventPayload(sessionID, props, permissionRequestOrderKey(request))')
  s = replace(s, '  if (event.type === Question.Event.Asked.type) {', `  if (event.type === PermissionAuthority.Event.Terminated.type) {
    return {
      type: "permission.terminated",
      summary: "Permission " + String(props.status),
      payload: stampSessionEventPayload(sessionID, props),
    }
  }
  if (event.type === Question.Event.Asked.type) {`)
  s = replace(s, '  const mapped = mapSessionBusEvent(event, { sessionID })', `  if (event.type === PermissionAuthority.Event.Asked.type) {
    if (!standalonePendingPermission(PermissionAuthority.Request.parse(event.properties), Instance.project.id)) return
  } else if (event.type === PermissionAuthority.Event.Replied.type || event.type === PermissionAuthority.Event.Terminated.type) {
    if (!isStandalonePermissionSession(sessionID, Instance.project.id)) return
    if (event.type === PermissionAuthority.Event.Terminated.type && event.properties.projectID !== Instance.project.id) return
  }
  const mapped = mapSessionBusEvent(event, { sessionID })`)
  return s
})
await edit("server/routes/session.ts", s => {
  s = replace(s, '  pendingPermissionSessionEvent,', '  standalonePendingPermission,')
  const begin=s.indexOf('function pendingPermissionProtocolSessionEvent('), end=s.indexOf('const SessionConfigResponse =',begin)
  if(begin<0||end<0)throw new Error('pending permission helper bounds')
  s=s.slice(0,begin)+`async function pendingPermissionsForConversation(projectID: string, sessionIDs: ReadonlySet<string>) {
  return (await PermissionAuthority.list()).flatMap((request) => {
    if (!sessionIDs.has(request.sessionID)) return []
    const projected = standalonePendingPermission(request, projectID)
    return projected ? [projected] : []
  })
}

`+s.slice(end)
  s=replace(s,'          pendingQuestions,','          pendingQuestions,\n          pendingPermissions: await pendingPermissionsForConversation(session.projectID, sessionIDSet),')
  s=replace(s,'            history: connectionConversation.history,','            history: connectionConversation.history,\n            pendingPermissions: await pendingPermissionsForConversation(session.projectID, sessionTreeIDs),')
  s=replace(s,'          const pendingPermissionEvents = (await PermissionAuthority.list())\n            .filter((item) => sessionTreeIDs.has(item.sessionID))\n            .map(pendingPermissionProtocolSessionEvent)\n','')
  s=replace(s,'          for (const event of pendingPermissionEvents) await writeData(JSON.stringify(event))\n','')
  return s
})
await edit("engine/interaction.ts", s => {
  s=replace(s,'import { Log } from "@/util/log"','import { Log } from "@/util/log"\nimport { ProtocolStore } from "@/protocol/store"\nimport { timelineInteractionResponseOrderKey } from "@/timeline/order"')
  s=replace(s,'    Bus.subscribe(Question.Event.Asked,',`    Bus.subscribe(PermissionAuthority.Event.Terminated, ({ properties }) => projectPermissionTermination(properties), {
      durableID: "engine.interaction.permission-terminated", effect: "idempotent_by_occurrence",
    })
    Bus.subscribe(Question.Event.Asked,`)
  s=replace(s,'async function resolvePermission(input:',`async function projectPermissionTermination(input: z.infer<typeof PermissionAuthority.Event.Terminated.properties>) {
  const fact = Database.use((db) => {
    const terminal = db.select().from(PermissionLedgerTable).where(eq(PermissionLedgerTable.id, input.ledgerEventID)).get()
    const requested = db.select().from(PermissionLedgerTable).where(and(
      eq(PermissionLedgerTable.request_id, input.requestID), eq(PermissionLedgerTable.event_type, "requested"),
    )).get()
    if (!terminal || !requested || terminal.request_id !== input.requestID || terminal.decision_slot !== input.requestID
      || terminal.event_type !== input.status || requested.project_id !== input.projectID || requested.session_id !== input.sessionID) {
      throw new Error("Permission " + input.requestID + " terminal notification differs from its immutable ledger authority")
    }
    return { terminal, requested }
  })
  const interaction = findInteractionByExternal(input.requestID)
  if (!interaction) return
  const task = Database.use(db => db.select().from(EngineTaskTable).where(eq(EngineTaskTable.id, interaction.task_id)).get())
  if (interaction.request_type !== "permission" || interaction.session_id !== input.sessionID || task?.project_id !== input.projectID
    || interaction.task_id !== fact.requested.task_id || interaction.status !== "rejected" || interaction.time_resolved !== fact.terminal.time_created) {
    throw new Error("Permission " + input.requestID + " terminal notification differs from its Task interaction owner")
  }
  ProtocolStore.dispatchEphemeral({
    type: "interaction.resolved", aggregate: "task", taskID: interaction.task_id, sessionID: input.sessionID,
    source: "interaction.permission.terminated",
    orderKey: timelineInteractionResponseOrderKey({ id: interaction.id, timeResolved: fact.terminal.time_created }),
    payload: { taskID: interaction.task_id, interactionID: interaction.id, requestType: "permission", status: interaction.status,
      requestID: input.requestID, ledgerEventID: input.ledgerEventID, summary: "Permission " + input.status },
  })
}

async function resolvePermission(input:`)
  return s
})
await edit("workbench/board.ts", s => {
  s=replace(s,'import { Log } from "@/util/log"','import { Log } from "@/util/log"\nimport { canonicalDigestSource } from "@/util/canonical-digest"')
  s=replace(s,'  EngineInteractionOutcomeTable,\n','')
  s=replace(s,'  const tag = boardTagForTask(task)\n  const lastSequence = latestTaskProtocolSequence(task.id)\n  return buildBoard(task, tag, taskDirectory(task), lastSequence)','  const lastSequence = latestTaskProtocolSequence(task.id)\n  const board: ReturnType<typeof buildBoard> = JSON.parse(JSON.stringify(buildBoard(task, taskDirectory(task), lastSequence)))\n  const digest = canonicalDigestSource("opencorvus.task-board-json.v1", board).sha256\n  return { ...board, snapshotVersion: `W/"task-board-v1:${digest}"` }')
  const a=s.indexOf('export function boardTag('), b=s.indexOf('function buildBoard(',a)
  if(a<0||b<0)throw new Error('boardTag bounds');s=s.slice(0,a)+s.slice(b)
  s=replace(s,'  snapshotVersion: string,\n','');s=replace(s,'    snapshotVersion,\n','')
  const c=s.indexOf('function taskSessionTreeVersion('),d=s.indexOf('function clipBoard(',c)
  if(c<0||d<0)throw new Error('tag helpers bounds');s=s.slice(0,c)+s.slice(d)
  return s
})
await edit("task-api/index.ts", s => {
  s=replace(s,'import { compileBoard, boardTag }','import { compileBoard }')
  s=replace(s,`  /** The Board projection's ETag. Read-only for the same reason getBoard is. */
  export async function getBoardTag(taskID: string) {
    requireTaskInCurrentProject(taskID)
    return boardTag({ taskID })
  }

`,'')
  return s
})
await edit("server/routes/orchestrator.ts", s => {
  s='import { etag } from "hono/etag"\n'+s
  const a=s.indexOf('      "/task/:taskID/board",'),b=s.indexOf('    .get(',a)
  let route=s.slice(a,b)
  route=replace(route,'          ...errors(404),','          304: { description: "Current task board is unchanged; ETag identifies the complete JSON projection" },\n          ...errors(404),')
  route=replace(route,'      async (c) => {','      etag({ weak: true }),\n      async (c) => {')
  const old=route.slice(route.indexOf('        const etag ='),route.indexOf('\n      },'))
  route=replace(route,old,'        const board = await EngineService.getBoard(taskID)\n        c.header("ETag", board.snapshotVersion)\n        return c.json(board)')
  return s.slice(0,a)+route+s.slice(b)
})
