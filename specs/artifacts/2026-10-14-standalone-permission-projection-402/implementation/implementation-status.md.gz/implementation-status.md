# 402 后台实现与当前验证交接

当前阶段：生产与后台正式合同已实现，SDK整次六目标事务仍等Root独占窗口；未做真实模型/UI，不归档或Git提交，不编辑spec/shared。原11个批准生产文件之外没有改生产。四个测试文件为两个新增集中后台合同与两个确实过期的原正向期望。

## 精确文件

生产：permission/types.ts（新增唯一轻量schema）；permission/invocation.ts；permission/authority.ts；engine/model.ts；engine/task-session-lineage.ts；protocol/session-mirror.ts；server/routes/session.ts；engine/interaction.ts；workbench/board.ts；task-api/index.ts；server/routes/orchestrator.ts（均位于packages/opencorvus/src）。

测试：packages/opencorvus/test/server/session-permission-projection.test.ts、server/task-board-validator.test.ts（新增）；server/session-event-connection-snapshot.test.ts（一个mandatory数组fixture）；orchestrator-initial-task-render.test.ts（expectedRoutineToolIDs补已发布56e1c0a06的3个continuous-goal工具）。不是新增/运行UI自动化，两个现有文件均已检查负向核心断言，无.not/泛化拒绝连接等新增保留路径。

## 最终行为

- Request Identity/Mode/ProviderKind/完整Request仅一份轻量schema，原Authority/Invocation同对象导出；公开schema本身未放宽。Scope不猜shape。
- Root额外批准的canonical注册事务从private authorize移至唯一authorizeAndExecute调用者，位置仍assertAttemptIdentity后/authorize前。existing直接返回已有Request；new只requestFromRow新LedgerRow。同一个canonical对象供Asked、后续hook/context/结果，旧ledger时间未重写、ID/policy/slot/lease不变。原试验existing类型错误已撤回，未遗留第二注册块。
- Session hydrate/connected两个必有pendingPermissions集合来自原Project/Session树+真实非Task Permission lineage；Asked与snapshot请求排序同源。connected旧Permission重发删除；Question全部原准入/回答/草稿/重发行为不动。
- cancelled/stale仅真实decision_slot事务赢家产生owned Terminated outbox，败给其它决定沿原结果；普通Stop/continuation退休策略不改。Task subscriber核对原ledger与已有Interaction，仅现成ephemeral interaction.resolved失效，不写第二outcome/userInput/Task状态。
- Board一次物化全部JSON可见对象并用唯一canonicalDigestSource产生规范弱实体标签；同对象增加snapshotVersion返回。旧boardTag/getBoardTag/专用SQL查询删除；route只getBoard一次，现成Hono etag处理条件，非自行比较/第二digest。brief现有派生缓存不重写。

## 正式结果（去重，不叠加重复覆盖）

全部以Bun1.4 PATH、packages/opencorvus既有正式隔离runner执行；各最后有效日志对应exit0。

| 文件（test/下） | pass | assertions | 当前有效日志 |
| --- | ---: | ---: | --- |
| server/session-permission-projection.test.ts | 8 | 36 | final-permission.log |
| server/task-board-validator.test.ts | 4 | 24 | final-board.log |
| permission-two-mode.test.ts | 17 | 56 | related-initial.log |
| permission-transport-hydration.test.ts | 1 | 4 | related-initial.log |
| engine-interaction-recovery.test.ts | 7 | 74 | related-initial.log |
| server/session-event-connection-snapshot.test.ts | 11 | 37 | corrected-contracts.log |
| permission-continuation-recovery.test.ts | 8 | 25 | related-initial.log |
| session/permission-message-settlement.test.ts | 10 | 22 | related-initial.log |
| orchestrator-initial-task-render.test.ts | 5 | 23 | corrected-contracts.log |
| distinct总计 | 71 | 301 | 9文件；重复不增加计数 |

core typecheck-initial、typecheck-expanded、typecheck-final均exit0；最终句柄64549已join。新3文件经过现有prettier，格式命令exit0，最终限定diff check0。SDK尚未执行，不能据core类型通过说SDK/UI构建通过。

## 实际路径与证据界限

Session集中套件进入真实Authority、Bus owned outbox、canonical ledger、Task及Session公开handler。覆盖首请求同ID/time/orderKey、root+child集合、两Project、同pending重复请求、完成后原result重放、stale/cancel赢家、真实新child cutover的connected先于buffered Asked、断开期间真实deny后重连当前空集合。

其中一个用例是真实TCP Server.listen→公开POST/session→公开POST/message→成熟本地stream:true Provider fixture→SessionProcessor实际read外部公开CSV→hydrate pending→公开Permission allow_once→实际完成Tool与assistant→公开history持久化读取。Provider和应用均finally正常stop，应用stop在Instance.provide完成后外层执行，公开fixture key仅local-controlled-provider，未使用任何用户auth/models/真实模型。

Board集中套件真实TCP测200/body/snapshotVersion/ETag、未变304、列表/星号/强写法弱比较、HEAD、CORS/Vary/request-id；其它真实handler合同覆盖Task真实Permission同ms stale ledger→Task失效→旧tag200/current Interaction、公开Task-ID读取与内部Project区别、未知Task404、Project名称与Task标题合法更新→新200，重复完整响应稳定。Task测试是canonical fixture，不冒称真实Task模型执行。没有运行大Board/高并发性能或所有Mission/Task/UI组合，保持未知。

## 原失败与根因已区分

1. red.log：原Session3fail/6assert明确缺pending数组/Terminated；Board首TCP case夹具在Instance.provide内await server.stop形成自身lease闭环、60s错误；第二例Project真实变化仍旧304。原checker源码task-board-before-owner-fix.test.ts保留。
2. red-board-owner-fixed.log：把fixture准备的provide先完成，再外层listener/stop，正常收尾，仅两个真实产品合同红。完整生产stop/lease范围审查在request-time-authority-review.md尾，原403/Instance不改。
3. green-initial：抓到Asked与ledger二次Date.now差2–3ms。原live测试未显式初始化生产bridge，造成无asked，是fixture缺前置；用现有ensureSessionProtocolBridge修test，不改产品初始化。Root完整分析后批准单次canonical绑定，原trial .ts/.patch与未覆盖重放局限保留。
4. green-board-expanded/canonical-and-project-boundary：错误把other目录header当Task-ID GET授权scope。实际无条件200原owner正文、星号304已留精确ID。全41实际调用/45rg命中与65d0bfc98/ea8ec4fa1历史见task-read-authority-review.md、task-read-call-matrix.json、task-entry-callers.txt。Root先补spec后批准改验收；生产helper/route分类未改。
5. related-initial的SSE旧fixture漏新必有数组；Task render旧完整tool期望漏当前3个连续Goal工具。只改这些过期期望，最终两个文件绿；不是新生产调度/Provider失败。
6. final-focused的cutover test hook原假定继承Instance；真实SSE callback无该上下文，故Session.create失败。保存原test，改用明确自有目录Instance.provide，生产不变。最终cutover绿。
7. final-focused另一个扩大预期发现真实Brief旧缓存：updateTaskTitle→setEngineTaskTitle仅写title，而compileBrief签名只Task.id/time_updated/Goals，所以title变化后Brief仍旧标题。原源码/log保留。402最终方案明确排除Brief缓存策略重写；本批测试只验证当前新title/完整版本和重复响应稳定，不锁定“旧Brief必须保持”或虚报Brief已修。该事实供后续独立调查。

## 收尾与剩余

本阶段所有exec/run test句柄已join（最后Board83386、Permission3734、core64549），没有持有页面/模型或常驻服务；服务仅正式测试owned process内，正常stop/finally与runner物理边界负责收尾。最早scope红60s自锁原错误保留，不声称那一轮正常产品退出。

SDK需要Root给整次build独占窗口（固定.tmp-sdk-build在最终publication锁之前）；先保存peer最新gen状态，按已批准六目标事务运行，不拆复制、不混他人MySQL删除。Root负责overlay类型/私有UI构建、真实Sol/桌面、公开归档/共享架构与Git交付。此记录仅自有scratch，没有更新spec或共享索引。

## SDK完整发布与生成后复验（最终追加，覆盖上文待窗口状态）

Root给出整次独占窗口后，先保存HEAD `3c6bf0420a717ba3fa06db394a39086fbc93ff2f`及六目标现状（sdk-before/head.txt、status.txt、targets.json和targets/精确副本）。此时peer MySQL删除已进入HEAD，SDK tracked无dirty，未做任何还原。仅执行Bun1.4 PATH下 `bun run --cwd packages/sdk/js build`，保留原OpenAPI/source生成、stream取消修补、required body处理、格式化、tsc及完整六目标publication事务，无手工复制生成结果/修改生成器。

实际sdk-build.exit=0，原exec37107已join。sdk-publication-observation.json记录六目标存在、三个事务临时目录已清理、没有观测到活动生成进程；build脚本真实返回在六目标publication完成之后。tracked差异精确为 `packages/sdk/js/src/gen/types.gen.ts` +83行、`packages/sdk/openapi.json` +311行，均新PermissionTerminated、两个必有pendingPermissions数组、Session协议枚举与Board304响应；sdk.gen.ts、defaults、route-policy、platform-artifact IDs无tracked差异。sdk-generated.patch完整保留当前生成增量。

生成后只重验必要公开合同：permission-transport-hydration 1/4、session-permission-projection 8/36、task-board-validator 4/24，共13pass/64assert/exit0（post-sdk-public.log/.exit）。它们已在总覆盖中，不增加distinct71/301。发布后的SDK source独立tsc --noEmit exit0（typecheck-post-sdk-published），核心source tsc --noEmit exit0（typecheck-post-sdk-core）；最终diffcheck0。最后exec47102/88645和所有原服务均join，无403/402自有活动应用/Provider/模型/浏览器。

最终本agent可提交文件是11生产+4后台测试+2真实生成文件，共17；Root继续拥有spec/shared/UI/build/模型/归档/Git。根/前端均已通知SDK窗口释放，公开shape不再变更。真实Sol与桌面仍未由本agent执行，不能用上述受控fixture/HTTP/类型冒称。
