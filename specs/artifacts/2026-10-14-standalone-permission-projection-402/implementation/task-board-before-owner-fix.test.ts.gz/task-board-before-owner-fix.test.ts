import { afterEach, expect, test } from "bun:test"
import { prepareTaskProcessBinding } from "@/engine/task-execution-capsule-binding"
import { Identifier } from "@/id/id"
import { Instance } from "@/project/instance"
import { Project } from "@/project/project"
import { Server } from "@/server/server"
import { Session } from "@/session"
import { memoryProject, resetMemoryDatabase } from "../fixture/memory"
import { persistEstablishedTask } from "../fixture/engine-task"

afterEach(async () => { await Instance.disposeAll(); await resetMemoryDatabase() })

async function taskFixture() {
  const revision = { scope: "built_in" as const, projectID: null, namespace: "builtin", id: "board-validator-contract", version: "2026.10.14.1", packageDigest: "a".repeat(64) }
  const root = Session.prepareRootNext({ kind: "root", directory: Instance.directory, title: "Board validator", metadata: { configOverlay: { prompt_profile: { active: revision.id } } } })
  const taskID = Identifier.ascending("task"), now = Date.now()
  persistEstablishedTask({ taskID, rootSession: root, now, title: "Board validator", request: "Public board contract", productPillar: "work", source: "test", priority: "normal", metadata: {}, projectID: Instance.project.id, packageRevision: revision, executionCapsuleBinding: await prepareTaskProcessBinding({ mode: "native", taskID, projectID: Instance.project.id, rootDirectory: Instance.directory, packageRevisionSHA256: revision.packageDigest, timeCreated: now }) })
  return { taskID, root }
}

test("real HTTP Board uses its complete weak entity tag for GET lists, wildcard, weak comparison and HEAD", async () => {
  await using project = await memoryProject()
  await Instance.provide({ directory: project.path, fn: async () => {
    const { taskID } = await taskFixture()
    const server = Server.listen({ hostname: "127.0.0.1", port: 0, randomPort: true })
    const url = new URL(`/task/${taskID}/board`, server.url)
    const headers = { "x-opencorvus-directory": project.path, origin: "http://localhost:5173" }
    try {
      const first = await fetch(url, { headers }), board = await first.json() as any
      expect(first.status).toBe(200)
      const tag = first.headers.get("etag")!
      expect({ tag, version: board.snapshotVersion }).toEqual({ tag: expect.stringMatching(/^W\/"task-board-v1:[a-f0-9]{64}"$/), version: tag })
      for (const condition of [tag, `"another", ${tag}`, "*", tag.slice(2)]) {
        const response = await fetch(url, { headers: { ...headers, "if-none-match": condition } })
        expect({ status: response.status, etag: response.headers.get("etag"), body: await response.text(), cors: response.headers.get("access-control-allow-origin"), vary: response.headers.get("vary"), requestID: response.headers.get("x-opencorvus-request-id") }).toMatchObject({ status: 304, etag: tag, body: "", cors: headers.origin, vary: expect.stringContaining("Origin"), requestID: expect.any(String) })
      }
      const different = await fetch(url, { headers: { ...headers, "if-none-match": 'W/"different"' } })
      expect({ status: different.status, body: await different.json() }).toEqual({ status: 200, body: board })
      const head = await fetch(url, { method: "HEAD", headers })
      expect({ status: head.status, etag: head.headers.get("etag"), body: await head.text() }).toEqual({ status: 200, etag: tag, body: "" })
    } finally { await server.stop(true) }
  } })
}, 60_000)

test("actual Project public fields change the Board response and invalidate its previous HTTP validator", async () => {
  await using project = await memoryProject()
  await Instance.provide({ directory: project.path, fn: async () => {
    const { taskID } = await taskFixture()
    const headers = { "x-opencorvus-directory": project.path }
    const first = await Server.App().request(`/task/${taskID}/board`, { headers })
    const before = await first.json() as any, tag = first.headers.get("etag")!
    await Project.update({ projectID: Instance.project.id, name: "Public project revised" })
    const response = await Server.App().request(`/task/${taskID}/board`, { headers: { ...headers, "if-none-match": tag } })
    expect(response.status).toBe(200)
    const after = await response.json() as any
    expect({ name: after.project.name, taskID: after.task.id, version: after.snapshotVersion }).toEqual({ name: "Public project revised", taskID, version: response.headers.get("etag") })
    expect(before.project.id).toBe(after.project.id)
  } })
}, 60_000)
