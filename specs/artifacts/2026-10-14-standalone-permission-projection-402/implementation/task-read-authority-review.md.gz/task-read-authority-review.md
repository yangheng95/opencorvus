# 402 Board 条件请求的跨 Project 准入复核（只读，红例保留）

当前未修改scope11外的任何生产文件，也没有在Board route加局部准入或改该红例期望。早期消息把Board误归PersistedProjectContext，是未读完整外层的中途错误推断；以下以真实入口与历史纠正，不将标题或helper命名当授权合同。

## 实测原事实

canonical-and-project-boundary.log在两个自有git Project完成注册后记录：Task `tsk_g00VXxQ8g100DNEFYJR0`，请求目录header对应`prj_hBQoNvoDnGqMvNJ3ubMj`。不带条件时实际200，正文Task仍该ID、正文Project为原owner `prj_hqT21tgOoMZFHQHUpC0q`；同请求带`If-None-Match:*`实际304空正文。原“期望404”断言仍红。所有数据来自新公开fixture，不能称用户数据泄漏。相同套件其它三例通过：TCP规范弱标签/各种条件/HEAD/CORS与request-id，Task同毫秒真实stale→ephemeral通知→条件GET200/current Interaction，Project名称变化→200新正文。

## 真实入口：不是captured persisted authority丢失

`packages/transport-protocol/src/index.ts:959–984`定义TASK_RECORD_READ_ROUTE，显式把GET Task identity、status、bindings、progress、events、brief、board、transcript、operator-model-context、interactions、conversation系列认定为`routeRequiresProjectDirectory=false`。Server.ts约889–897先读取header但见此false即next，不进入下方projectRouteContextKind，也不创建Instance或PersistedProjectContext。由后续全局AppRoutes执行Task读取。

因此本次不存在“captured PersistedProjectContext已经建立但Instance.current没有读到”的事实。原持久scope只用于明确DELETE Project/Session/Goal/Task/Mission路径（server/project-route-context.ts:58–97）；其`PersistedProjectContext.provide`用Project.findByRegisteredDirectory保存独立Context。Task DELETE现有路由显式将该projectID送EngineService.deleteTask，后者在原task及再次读取时核对options.projectID；不依赖当前Instance。它不能作为GET Board当前授权header的证据。

`engine/task-project-read.ts:6–20`明确三种行为：真实Task不存在由requireTask抛NotFound；非法project_id=global明确TaskGlobalProjectBindingError；存在Instance.current时核对其project.id，不存在时按Task ID返回原资源。routes/orchestrator的requireRouteTaskInCurrentProject:100同样显式允许!current。它们当前有意兼容“无执行Project上下文的历史读取”与“有明确Instance的内部执行调用”，不是一个刚出现的未初始化fallback。本次不增加任何新的无scope放行。

## 历史与架构

git -S TASK_RECORD_READ_ROUTE的现存最早基线为65d0bfc98，内容已包含GET免目录规则；ea8ec4fa1（2026-08-28）抽出task-project-read时逐字保留if(current)条件。当前未找到把目录header定义为上述Task ID记录读取授权边界的产品文档。02-data.md Project Storage Namespace明确project.id是后端namespace，Project内/全局范围由领域查询决定；可选directory查询不是额外所有权。07-panel读取面另有全局Work Ledger和Task导航，不能据“当前Project”标题倒推所有Task ID GET都必须绑header。

这只说明现有读合同及其风险边界，不据历史自动证明安全政策一定合适。若产品要新增显式全局/Project record-read authority，属于一套共享公开入口设计，不能在本批Board局部导入PersistedContext或无条件Instance.project.id制造新初始化依赖。Root需决定402验收是否遵守原明确Task-ID read契约，或另开完整授权方案。

## 全仓调用矩阵与控制路径

原rg的45行含定义/import/type引用；TypeScript AST确认**41个实际调用**，精确文件/行/函数在task-read-call-matrix.json。只有engine/task-file-reference.ts和task-api/index.ts调用（定义文件另1）。其二级EngineService生产入口在task-entry-callers.txt，原全文命中task-read-callers.txt。

| 调用组（全部实际函数） | 入口与当前额外authority |
| --- | --- |
| getTask/getProgress/getBrief/getBoard/listTaskInteractions/getTaskOperatorModelContext | 上述免目录GET、全局历史/Task导航；需要真实Task记录，不要求启动Project执行模型。存在内部Instance则仍按helper校验 |
| getTaskTrace/listProtocolEvents/getTaskRootIngressDebug/getCrossTaskArtifactImportMappings/searchArtifactCatalog | 对应Task路由/Artifact与Project archive/read投影。是否免目录由具体route表而非函数名决定；Project archive/Artifact执行检查仍各自原入口。Conversation turn-artifacts和Task project archive为实际内部消费者 |
| requireGoalInCurrentProject/requireInteractionInCurrentProject/requireSessionTraceTaskInCurrentProject | 先解析Goal/Interaction/Session真实owner再helper；执行/修改routes要求Project runtime，不为Board把它们改成无scope权限 |
| mergeTaskFileRef（2次）/prepareTaskAttachmentAppends | Task附件写入；除原helper外还校验AttachmentStore URL Project=Task.project_id、真实元数据/字节身份，写事务内重读owner |
| appendAndWakeTaskOperatorMessage（2次）/messageContext/handleTaskMessage/injectMessage/operatorSteerAgentSession | 自然operator输入与Task occurrence；正常POST路由保留Project runtime，另有root lineage/execution epoch/可见输入事实；本批未改这些准入 |
| materializeClaimedSchedulerMessageToTask | 真实delivery必须leased+exact leaseOwner、task_scheduler类型、目标Task execution epoch；Scheduler实际owner上下文，不由Board GET调用 |
| deleteTask（2次）/setTaskArchived（2次）/deleteSession | deleteTask显式options.projectID从持久路由传入，重读时再核对；Session delete本身显式Project+真实Session树。Archival原执行入口及occurrence权限保留 |
| updateTaskChecks/updateTaskBudget/updateTaskTitle/setTaskPinned | 对应mutation POST/PATCH，不在GET record bypass；由Instance runtime+真实Task owner约束 |
| requestTaskCancellation（2次）/joinTaskCancellation/cancelTaskOnce | 原控制取消与physical settlement/occurrence；原传入owner约束和403生命周期不改 |
| extendMissionTaskAcceptance/resumeMissionTask（2次） | 原helper之后显式assertTaskRootSessionLineageInCurrentProject及requireMissionTaskLineageAuthority(projectID=Instance.project.id)，绑定Mission/importer/真实Tool/epoch/ledger；不是无scope裸读 |
| deliverContinuousGoalMessage | 真实连续Goal owner/Message/Task receipt关系；不是HTTP Board读入口 |

冷/暖读取都走同route表，不会因Instance缓存有该Project就自动创建当前AsyncLocalContext；并行请求的header本身不会串写一个全局“当前Project”。内部任务/恢复通过各自Instance或明确Project传入，不能将本次全局Task-ID GET行为外推成这些控制准入失效。没有从这次只读检查确认新的Task/Mission调度/恢复异常；未运行全部41调用路径，不能声称逐个动态验证过。

## 建议待Root决定

保持现有生产scope。若Root确认原GET合同，建议把验收拆成三个真实正向合同：指定Task ID免目录（含无效/其它header）仍200原owner正文/当前tag；未知Task即使星号仍明确NotFound404，不能在资源查验前304；在明确Instance Project作用域内调用EngineService.getBoard，foreign Task保留NotFoundError。原“header自身是Board授权scope”的错误验收应有完整调查记录后才改，不静默skip。若Root要改变公开准入，则必须先统一41实际调用与读/写scope输入合同，不允许这里先补局部fallback或悄然强制Project初始化。

SDK/生成仍未运行，scope11外只读。此文件及原红/日志为Root审阅素材，等待明确决定。
