# Root真实桌面：修复后01

2026-10-14，1280×720桌面，IAB4自有tab2，真实http://127.0.0.1:53454/ui/；当前402私有build正式exit0后启动。公开受控流式Provider，无用户凭据，不能算真实Sol。原native67224/processInstance win32:639275158323039120，固定原deadline1791919632213、closeBy1791919572213。

Root实际选择自然Global Chat ses_hl3FD4A7AusBxvWPBo5T，公开Permission per_h0B8rnJjsozLx2AUDj4i/time1791919047936。人工查看原图main-pending-dialog-en.jpg：Permission request标题、read、scope及Allow Once/Always Allow Exact Scope/Reject均可见；长路径保持真实技术身份，JSON自身横向滚动。Escape后Main行内有同一请求和三个按钮，原图main-pending-inline-en.jpg。没有DOM断言/自动化测试/截图基线。

真实reload后先到Home，Root再选择原会话，冷HTTP/connected恢复同一待请求，原图main-cold-restored-en.jpg。第一次在页面还收敛时按Escape后弹窗仍出现，稳定后再按Escape成功得到行内状态，main-cold-inline-en.jpg；这次观察不能证明特定是哪一个hydrate/event重建导致第一次弹窗再开，保留候选而不猜根因。没有将reload前草稿或Question行为计为通过。

实际点击行内Allow Once，自然Replied清卡，Tool完整读取item,quantity/Cedar402,3/Iris402,4，真实source-file产生，助手finish stop/time.completed1791919142522；messages-after-allow.json原HTTP响应保存。Root展开Tool并人工查看main-allow-completed-en.jpg，页面Not running、Output三行可见。Provider最终文字固定provider reply 2，不计为模型内容正确性。

Root保存五张原JPEG，不裁切/重编码；最终AX仅观察辅助。tab2已先关闭，page-closed.json记录；随后stop-requested触发原server.stop/recovery及Provider正常关闭。原unified exec4961最终exit0，NodeProcess settled自然exited/exit0，outputSettled/drain完成，terminal.json三次实际stream:true公开请求。closure-review.json独立CIM确认原PID已不在、原外层runtime不存在。此实际重跑验证了先物理退出再由唯一外层删除运行目录的工具修复；原before05 exit1/EBUSY仍保留。

只证明此次英文Main冷恢复、Dialog/inline、Allow Once、实际Tool/assistant完成和正常闭合；中文、deny、warmAsked、多个pending、切源、回复期间切源、Question草稿、Task/SideChat尚待各自真实页面。
