# 402 final SDK transaction

Root granted the exclusive window after all denial-stage source tests joined. Baseline HEAD: `2494f5da532487059d4e4c1215840716c19814fe`. Existing 402 changes were types +83 and OpenAPI +311; they were preserved. Six targets were copied to `baseline/` for direct comparison before running the unchanged build; no restore or manual publication occurred.

Only generation command: `bun run --cwd packages/sdk/js build`, Bun 1.4.0. Original build owner 48218 exited 0 and was joined. It ran the original OpenAPI generation, Hey API client generation, stream cancellation/required body fixes, formatting, staged tsc and six-target publication transaction. `build.command.txt`, `build.log`, `build.exit` are original output.

`publication-observation.json` is produced by the saved `observe-publication.mjs`, comparing actual bytes and file inventories against all six baseline targets, without checksum gates. Observed changes are exactly:

- `js/src/gen/types.gen.ts`: delete the old Config option and description (four lines).
- `js/dist/gen/types.gen.d.ts`: corresponding published declaration deletion.
- `openapi.json`: delete the old Config property (four lines).

The other files in `js/dist`, `js/src/gen`, plus defaults, route policy and platform Tool IDs are byte-equal to baseline. File sets are intact. Three temporary paths `.tmp-sdk-build`, `.tmp-sdk-artifacts`, `.tmp-sdk-artifacts-backup` were all absent after the normal transaction; exact SDK-generation process observation is `[]`. No hand-written generated output or generator change.

Current SDK tracked changes against HEAD: `types.gen.ts +83/-4`, `openapi.json +311/-4`. `sdk-total-from-head.patch` shows the complete current 402 result. The three `*-delta-from-baseline.patch` files show only this final configuration removal.

## Post-publication checks

| Check | Evidence | Result |
|---|---|---|
| Core tsc | typecheck-core.* | exit 0, owner 12579 joined |
| SDK published source tsc | typecheck-sdk.* | exit 0 (command completed within initial tool call) |
| Actual published dist declarations tsc | typecheck-published-declarations.* | exit 0 (command completed within initial tool call) |
| Formal TCP + Config suite | public-check.* | 10 pass / 50 assertions / exit 0, owner 20891 joined |
| Root-requested matcher evidence preservation | permission-denial-before-clonefix.test.ts, test-clonefix.patch | two test-only structuredClone changes; production/SDK unchanged |
| Formal TCP after clone change | public-after-clonefix.* | 3 pass / 30 assertions / exit 0, owner 31182 joined |

Counts are reruns of existing denial-stage cases, not additional distinct coverage. Test formatting and tracked diff whitespace checks also passed. No owned generation/test process or server remains from this stage. This is backend/SDK evidence, not new real Sol or UI acceptance.

For a compact public archive, the command/log/exit files, three delta patches, total SDK patch, publication/process observations, observer source, before-clone test and clone patch are sufficient. `baseline/` contains about 9 MB of generated public files used for comparison and need not be archived. No runtime database, auth or model directory was copied or accessed.
