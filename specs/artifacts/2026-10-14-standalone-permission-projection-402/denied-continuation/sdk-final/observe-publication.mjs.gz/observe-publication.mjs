import fs from "node:fs/promises"
import path from "node:path"

const evidence = path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:\/)/, "$1"))
const sdk = path.resolve("packages/sdk")
const targets = ["js/dist", "js/src/gen", "js/src/defaults.ts", "js/src/route-policy.ts", "js/src/platform-artifact-tool-ids.ts", "openapi.json"]

async function files(root, relative) {
  const result = new Map()
  async function visit(file) {
    const absolute = path.join(root, file)
    const stat = await fs.stat(absolute)
    if (stat.isDirectory()) {
      for (const entry of await fs.readdir(absolute)) await visit(path.join(file, entry))
    } else result.set(file.replaceAll("\\", "/"), await fs.readFile(absolute))
  }
  await visit(relative)
  return result
}

const observed = []
for (const target of targets) {
  const before = await files(path.join(evidence, "baseline"), target)
  const after = await files(sdk, target)
  observed.push({
    target,
    fileCount: after.size,
    bytes: [...after.values()].reduce((total, buffer) => total + buffer.length, 0),
    added: [...after.keys()].filter((file) => !before.has(file)),
    removed: [...before.keys()].filter((file) => !after.has(file)),
    modified: [...after.keys()].filter((file) => before.has(file) && !before.get(file).equals(after.get(file))),
  })
}
const temporaryPaths = []
for (const name of [".tmp-sdk-build", ".tmp-sdk-artifacts", ".tmp-sdk-artifacts-backup"]) {
  const target = `js/${name}`
  const present = await fs.stat(path.join(sdk, target)).then(() => true, (error) => {
    if (error.code === "ENOENT") return false
    throw error
  })
  temporaryPaths.push({ target, present })
}
const result = { observedAt: new Date().toISOString(), targets: observed, temporaryPaths }
await fs.writeFile(path.join(evidence, "publication-observation.json"), JSON.stringify(result, null, 2) + "\n")
console.log(JSON.stringify(result, null, 2))
