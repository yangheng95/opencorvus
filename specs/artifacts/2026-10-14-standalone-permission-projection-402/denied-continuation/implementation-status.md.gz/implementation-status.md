# Denied Tool continuation — bounded implementation evidence

Root approved the completed shared analysis in the final 402 spec section before implementation. Scope is exactly two production files and two backend tests; no edits to SessionLoop/completed-reply/Permission policy, the separately frozen warm-summary files, SDK generators, UI, specs or shared documents. No credential/model service was used. Test Provider API key is the literal public fixture value `local-controlled-provider`.

Production:

- `packages/opencorvus/src/session/processor.ts`: 12 deleted lines remove the inherited denial-only stop state, config read and unused imports. Ordinary Tool-error persistence/projection remains, as do actual Prompt abort, assistant failure, compaction, typed park/handoff and Task-root continuation retention.
- `packages/opencorvus/src/config/config.ts`: removes the one obsolete experimental field. Existing nested unknown-key normalization is unchanged.

Tests:

- New `packages/opencorvus/test/server/permission-denial-continuation.test.ts`: real TCP listener, real public Session creation and message, real streamed first read, public deny, next physical Provider request with the same call's error, model-streamed final and canonical persisted reply; same-input replay; next input; two real Projects in parallel (deny/allow); public abort while read waits. Each owned listener is stopped outside Instance.provide and providers/requests/projects are joined/cleaned in finally. The fixture drives HTTP streaming and is not real Sol or desktop evidence.
- `packages/opencorvus/test/config-global-defaults.test.ts`: one positive canonical-source/effective experimental normalization case, including current declared values. No copied schema or custom old-key migration.

Original source/current relevant differences saved under `preimage/` before modification. `head.txt`, `workspace-status.txt` and empty initial-scope.patch distinguish peer work. Actual command lines accompany every result.

## Red and checker correction

- `red.log/.exit`: formal Bun 1.4 isolated runner, exit 1. TCP 1 pass / 2 fail / 15 assertions (both denial chains HTTP 500; real abort passed). Config 6 pass / 1 fail / 20 assertions, old option still in effective output. Exec owner 14100 joined with exit 1.
- `green.log/.exit`: first post-fix run, exit 1. The real HTTP final matched the expected successful shape, then the local test parsed the same object after Bun's asymmetric matcher had replaced number/array fields with matcher objects. This is a checker failure, not a persisted Message protocol change. Original helper saved `preimage/permission-denial-continuation-green01.test.ts`.
- Correction limited to the test helper: parse the actual HTTP body first and assert a separate structured clone. No product behavior or expected final contract was weakened. Exec owner 27696 joined exit 1.
- `green02.log/.exit`: same formal test command, **10 passed / 0 failed / 50 assertions** (TCP 3/30; Config 7/20), exit 0. Exec owner 33956 joined exit 0. No repeat coverage added to totals.

## Final source verification before SDK

`related.log/.exit` completed **79 passed / 247 assertions / exit 0**, seven distinct files. Actual process-cut cases run their existing owned subprocess checker; no copied runtime or bypass. Exec owner 69225 joined exit 0. Per-file structured counts are in `related-results.json`:

| File | Pass | Assertions |
|---|---:|---:|
| session/task-root-multistep-assistant | 3 | 7 |
| session/prompt-cancellation-occurrence | 4 | 9 |
| permission-continuation-recovery | 8 | 25 |
| session/permission-message-settlement | 10 | 22 |
| tool-result-control-protocol | 36 | 121 |
| session/processor-producer-boundary | 12 | 45 |
| session/processor-llm-activity-retry | 6 | 18 |

This denial-stage verification is **9 distinct files, 89 passes, 297 assertions**, including the two new/expanded focused files. It overlaps earlier 402 coverage and must not be added blindly to the overall 402 distinct total. Config's six pre-existing cases and related repeats remain repeats.

`typecheck.log/.exit` core tsc exit 0; exec owner 84048 joined exit 0. Test formatting and tracked diff whitespace checks exit 0. No owned process or service remains from this stage. All four formal command owners (original red 14100, first post-fix checker failure 27696, final focused green 33956, related 69225) have terminal exit receipts. Core type owner is separately joined.

`files.json` is the exact four-file source/test allowlist. `source-and-config-test.patch` holds tracked changes, with the new test at its explicit path. SDK remains ungenerated pending Root's next exclusive full-transaction window; no generated files were altered by this stage.

## Final SDK window completed

The prior paragraph is the source-stage boundary. Root then granted the exclusive final SDK window. `sdk-final/README.md` and its original logs/observations show complete unchanged build exit 0; six targets published, three temporary paths removed and generation processes zero. Relative to the saved 402 SDK baseline, only the obsolete Config option was deleted in generated source/declaration/OpenAPI. Current total tracked SDK delta remains the original 402 protocol additions plus this removal.

Post-publication core, SDK source and actual dist declarations typechecks all exited 0. Same two public suites rechecked 10/50 exit 0. Root requested independent clones for the saved Provider followup and canonical Tool assertion: two test-only lines changed; original input and patch preserved. Final TCP-only rerun is 3/30 exit 0. Owners 48218 (build), 12579 (core), 20891 (public) and 31182 (final narrow rerun) all joined exit 0. SDK source/declaration commands completed within their initial tool results. No new distinct test count or real-model/UI claim.

## Limits

New TCP tests prove controlled streaming backend behavior, not actual GPT-6.1 Sol or UI. Task-root retained-message primitive and real Tool control regressions are separate evidence; this does not claim a new actual model-driven Task/Mission/child denial run. No automatic rewrite/recovery of old already-completed denied messages was added. Root owns final desktop/model checks, shared docs, SDK window, archive, commit and upstream push.
