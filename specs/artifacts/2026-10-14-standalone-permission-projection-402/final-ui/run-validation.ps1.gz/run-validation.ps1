param(
  [Parameter(Mandatory = $true)]
  [ValidateSet('typecheck', 'build')]
  [string]$Check
)

$finalUiRoot = 'D:/myhexin-local/opencorvus'
$finalUiScratch = Join-Path $finalUiRoot '.tmp-standalone-permission-projection-402'
$finalUiScope = Join-Path $finalUiScratch 'final-ui'
$finalUiWorkdir = Join-Path $finalUiRoot 'packages/overlay'
$finalUiLog = Join-Path $finalUiScope ($Check + '.log')
$finalUiExitFile = Join-Path $finalUiScope ($Check + '.exit')
$finalUiRecord = Join-Path $finalUiScope ($Check + '-command.json')
foreach ($finalUiOutput in @($finalUiLog, $finalUiExitFile, $finalUiRecord)) {
  if (Test-Path -LiteralPath $finalUiOutput) { throw "Refusing to replace final validation evidence: $finalUiOutput" }
}
$env:PATH = (Join-Path $finalUiRoot '.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64;') + $env:PATH
Set-Location -LiteralPath $finalUiWorkdir
if ($Check -eq 'typecheck') {
  $finalUiExecutable = (Get-Command bun).Source
  $finalUiArguments = @('run', 'typecheck')
} else {
  $finalUiExecutable = (Get-Command node).Source
  $finalUiArguments = @('--max-old-space-size=8192', './node_modules/vite/bin/vite.js', 'build', '--config', 'vite.config.ts', '--outDir', (Join-Path $finalUiScratch 'ui-after-final'))
}
$finalUiMetadata = [ordered]@{
  check = $Check
  executable = $finalUiExecutable
  arguments = $finalUiArguments
  workingDirectory = $finalUiWorkdir
  log = $finalUiLog
  wrapperPid = $PID
  startedAt = [DateTime]::UtcNow.ToString('o')
  status = 'running'
}
[System.IO.File]::WriteAllText($finalUiRecord, ($finalUiMetadata | ConvertTo-Json -Depth 4))
& $finalUiExecutable @finalUiArguments *> $finalUiLog
$finalUiExitCode = $LASTEXITCODE
$finalUiMetadata.finishedAt = [DateTime]::UtcNow.ToString('o')
$finalUiMetadata.status = 'exited'
$finalUiMetadata.exitCode = $finalUiExitCode
[System.IO.File]::WriteAllText($finalUiRecord, ($finalUiMetadata | ConvertTo-Json -Depth 4))
[System.IO.File]::WriteAllText($finalUiExitFile, [string]$finalUiExitCode)
Get-Content -LiteralPath $finalUiLog -Tail 18
exit $finalUiExitCode
