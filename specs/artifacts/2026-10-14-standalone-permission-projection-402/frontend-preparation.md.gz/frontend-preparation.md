# 402 前端实施准备（只读冻结）

2026-10-14。按 Root 最新准备消息，只读取当前源、402 Recall/文末最终方案、已存调查和相关非 UI 测试；本文件为自有 scratch。没有修改生产、测试、spec 或共享文件，没有运行类型检查、构建、测试、页面、服务、模型、凭据操作或 Git 操作。仍等待 Root 明确实施授权。本文不是 UI/功能验收。

## 当前授权合同

采用文末最终方案，历史中“Question child 同时放宽”“只增 Interaction 状态计数/摘要”“Session 回复后重新 HTTP hydrate”均不是本次实现。Main Permission 接收后台通过持久 lineage/Project/真实 Task 所有者验证的非 Task child；Question 当前准入、回答/拒绝事实和草稿保留。Task 交互仍唯一来自 board.interactions。Standalone Permission 为 pending-only，正常 Replied 与真实 cancelled/stale Terminated 结束 pending，不构造回答消息或用户拒绝。

Board 完整弱 ETag、终态事务/outbox、Task 失效通知、后端 schema 和 SDK 六目标生成事务由 Root/audit_functionality 负责。前端将 snapshotVersion 当 opaque string，无需修改缓存解析或另加条件请求路径。

## 精确六个生产文件

| 文件（均相对 packages/overlay/src） | 最小改动与保留合同 |
| --- | --- |
| `utils/permission-interaction.ts`（新） | 唯一 Request + interaction orderKey + owning directory → pending InteractionData 正规化器；无队列、无 API、无第二状态源。供 Main 冷/重连/实时及 SideChat 共用。 |
| `services/tree-writer.ts` | 扩展已有 standalone Map（当前名 standaloneQuestionInteractions）供两种交互使用；提供 Permission prepare/commit/replace 操作；Asked 写同 ID，Replied/Terminated 移除对应 Permission；删除两个现有 Permission noop 分支。Question handler 的准入和已答事实不改。 |
| `services/conversation.ts` | Session HTTP hydrate 和 ordered connected 强制读取 pendingPermissions；先完整 prepare/validate，再于现有批次提交。connected 只替换 Map 内 Permission，保留 Question 与原 history/读位合同；Task hydrate 不要求 Session 字段。 |
| `services/side-chat.ts` | connected 从新 mandatory 数组恢复 exact target Session 权限；Asked 复用同 normalizer；Terminated 按 exact Session/request 移除。保留已有 captured authority/generation/dispose 与原 Question 流合同。 |
| `services/event-policy.ts` | 将 permission.terminated 加入实际 projected event 集合；Task 仍通过已有 interaction.* 失效路径，不另建 Board 刷新事件。 |
| `components/InteractionCard.tsx` | 一个点击时所有者快照覆盖 Main inline/Dialog 默认后处理；Task 原作用域仍当前才 loadBoard({authority})，Session 沿自然事件/connected 收敛；保留 SideChat 显式 afterReply。原问题表单、permission choice 和 reply API 不复制。 |

不需要修改 CardParts.tsx:112、InteractionDialogHost.tsx:64、SideChatPanel.tsx:486 三个调用点；它们已共享同一组件。也无需修改 services/events.ts、sse.ts、subagent-conversation.ts、interaction-reply.ts 或 store/board.ts。任何新增第七个生产文件应先向 Root 报实际必要性，不能静默扩大。

## mandatory pendingPermissions 全消费者

1. **Main HTTP hydrate**：conversation.ts:674–751。source.kind=session 时 `requireArray(data.pendingPermissions, ...)`；Task 用空的准备集合，不对其公开响应添加此要求。用已验证 requestDirectory/responseDirectory 为 Permission 捕获 directory。在 mutate 之前共享正规化，并将 preparedQuestions + preparedPermissions 一起送既有 `validateConversationBoardInteractions`，验证真正卡片排序/身份。现有 deferConversationTreeProjection/batch 中 resetWriter 后提交两个集合，不能把 Permission 放在稍后的第二异步批次。
2. **Main ordered connected**：conversation.ts:447–469；sse.ts:448–496 已有捕获 authority、generation/handle 所有者与 source 类型检查。严格读取 `envelope.conversationSnapshot.pendingPermissions`，用 `conversationSourceDirectory(source)` 的已注册目录。完成所有准备后，在同一 defer/batch 内替换 Permission 子集和 commitPreparedConversationView。不调用 resetWriter、不更换 Question 对象、不取消用户草稿、不再发 HTTP 读。缺数组/畸形项是明确协议错误，不能 `?? []`、过滤掉畸形项或从旧 Asked 重放补齐。
3. **SideChat ordered connected**：side-chat.ts:80–95。先用现有 parseSubagentConversation 生成 prepared transcript，再严格 prepare pendingPermissions，二者都成功才替换 base/live/pending 并通知。snapshot 是 Session 树投影，权限最终仅选 `request.sessionID === target.sessionID`；target.directory 是现成 owning directory。Question 当前 connected 清 pending、后续原 Question replay 的行为不是本次重构对象；不可让新增权限恢复覆盖 warm Question 操作。后台删除旧 Permission Asked 重发与这里接新数组必须同批完成。
4. **subagent parser 审核后保留原状**：subagent-conversation.ts:579–699 的 loader/parser 只物化 transcript/view/timeline 与 target identity，返回 SubagentConversationTranscript，没有 interaction/pending 输出。它同时解析 Task child HTTP payload 和 Session child payload；前者不会新增 pendingPermissions。强迫这一通用 transcript parser 读取该字段会扩大并破坏 Task 子会话合同。SideChat 调 parser 后自己的权限投影是消费者；Main 子会话 Permission 由后台 verified child → Main map 负责，Task 子会话仍原 Task interaction。没有额外隐藏的全响应强 schema parser 需要同步。

全仓 `rg pendingQuestions|conversationSnapshot|pendingPermissions packages/overlay/src packages/sdk/js/src/gen/types.gen.ts` 当前只命中上述 Main/SideChat 消费以及生成 schema（当前尚无新数组）。无需在无交互输出的 transcript/history parser 搭建第二权限状态。

## Map、排序与源目录

tree-writer.ts:518/613/1244/2084–2219/3929 是现有 Map 定义、清理、派生与 Question 更新。Permission 扩展复用此 Map/interactionToCardSeeds/现有 regroup 与 hierarchy rebuild。connected replace 必须先删除该 Map 中 type=permission 的条目，再插入当前 prepared Permission；Question pending/answered/rejected 对象保持。全 resetWriter 原有清 Map 时机仍生效。

共享 normalizer 验证实际显示和身份所需字段：非空 id/projectID/sessionID/toolName/summary、scope 为对象、合法 choices、正整数 timeCreated、orderKey 属 interaction 且时间等于 timeCreated、必需 owning directory。不得给缺失字段造时间、id 或默认工具名。批量 prepare 拒绝重复 request ID；live Asked 以原 ID 幂等。输出保留真实 sessionID/orderKey/time.created/type=permission/status=pending/replyEndpoint=permission 和原 summary/scope 内容，复用既有渲染与国际化操作按钮。完整 PermissionRequest schema 仍后端单源，前端不要另写完整策略校验器或 import Authority 模块。

Permission live 必须要求 Main selectedSource.kind=session；不复制 isSelectedStandaloneSession(root-id) 或 knownMission 前端临时 Map 准入。其 child 范围信任 backend 已验证 Session 流，原 sse 所有者负责阻止退休连接写入。终态仅移除匹配 request ID/sessionID 的 Permission，不能删除同 ID Question 或合成 answered 状态。

Main live directory 可直接使用已选 Session source.directory 的严格值：conversation-session.ts:353–418 要求 inputDirectory，取得服务端 session.directory 后建立最终 source 并调用 hydrate/SSE；现有 project-directory.ts:10–15 也把它作为 Session 唯一 owning directory。缺目录时明确错误。无需在 tree-writer 引入 conversation/currentTraceDirectory，避免 conversation → tree-writer → conversation 循环；也不用 settings 当前目录或 child 原 cwd 作为权限请求作用域。冷/connected 路径使用各自已验证来源目录传 normalizer。

## 点击时 source/directory/authority/selectEpoch 捕获

InteractionCard.tsx:129–177 的现有 runAction 在请求成功后无条件默认 loadBoard；store/board.ts:347–355 在无 Task 时清 board。这是具体要替换的路径。三个真实调用点中只有 SideChatPanel 提供显式 callback。

在 runAction 的 try 内、首个 await 之前获取一个局部不可变动作快照：interaction id、replyEndpoint、已解析 replyTarget.directory、复制的 selectedSource(kind/id/directory)、boardStore.selectEpoch、captureApiAuthority()、原显式 afterReply 引用。不要保留可变 store proxy 当快照，也不要完成后重新选择 replyTarget。Permission/reject/question submit 通过该次捕获 target/endpoint 调原 helper，原 Question answers 从当前表单在同一次同步点击中获取。

默认成功后处理只按捕获 source 分支：Session 完成 API 后交自然事件，不调用 loadBoard/hydrate/reset；Task 要求 captured authority 仍 current、selectEpoch 相同、kind/id 相同、owning directory 相同，随后同一同步段调用 `loadBoard({authority})`。loadBoard 本身继续用现成 epoch/authority/request guard。不得在 await 后用 activeTaskID 为旧响应选择新 Task。SideChat 的原显式 afterReply 仍由其目标组件持有，不能套用 Main selectEpoch 决定是否刷新另一个主会话；其 callback 当前仅 `follow?.contentChanged()`，不是权限 HTTP 重读。

**为何不需第七个 interaction-reply.ts 改动**：当前 lockedRequest 在无既有 promise 时同步执行 async fn，fn 在首个 await 前直接调用 apiJson；api.ts:260–264 在首个 await 前同步 captureApiAuthority/assert。因此 click 捕获到发起原 reply API 中间没有让出事件循环，现有 API 捕获就是同一次 authority，响应也再次 assert。若重复 ID 已在飞，则复用既有 promise；这是原互斥合同，不在本批新造第二请求。实现时必须保持此同步调用链，不插入 await/延迟队列后才调用 reply helper。若以后需要显式跨异步传 authority，须正式扩展 helper 参数，不假称当前 target 已带 authority。

本准备不建议扩展组件焦点/错误/草稿重建机制。尤其不要为简单默认 afterReply 改动重置 drafts 或重挂载 InteractionCard；实际慢请求切源、错误与重复操作由 Root 后态页核对。

## 触及测试分类与必要后续数据修改

定向检索实际命中两文件，均已读相关内容；没有发现 DOM/组件渲染、Playwright、截图基线、UI 源码文案断言等应删除的 UI 自动化。因此本准备没有合理的 UI 测试/专用 fixture 删除清单，不可仅凭 imports InteractionData 或文件名 side-chat 误删传输测试。

- `packages/overlay/test/side-chat-transport.test.ts`：HostTransport request/openStream 注入，验证真实服务函数输出的请求 path/query/body 和事件→interaction 状态。旧 permission.asked fixture:62–75 缺 projectID/timeCreated/interaction orderKey；新的严格协议下须按当前公开 Request 和事件补齐真实合法输入。保留 API allow_once/deny 与原 Question 状态输出。这是非 UI transport/state 合同，不能冒充页面或端到端。
- `packages/overlay/test/subagent-conversation-service.test.ts`：纯 transcript/transport/authority 状态服务测试；803–829 的 SideChat connected snapshot fixture 当前缺 mandatory pendingPermissions，需要在这次 Session connected 输入补明确数组。其通用 payload 同时用于 Task child 测试，不可给全部 parser 强加 Session 权限字段要求。文件内的 snapshot 是协议快照术语，不是组件 snapshot testing。

此两文件不在上述六个生产文件内，本阶段禁止修改/运行。Root 实施时需显式分配其聚焦非 UI 夹具更新与正向状态验证；不要为了旧 fixture 在产品加 missing-array fallback。UI 层不新增任何源码文字、组件、DOM、浏览器自动化测试；正常真实 UI 验证归 Root。

## 私有类型/构建准备（尚未运行）

先等待后台 schema 和 SDK 完整生成事务完成，再运行以下已存在的工具链。依赖工具沿 Root 使用 Bun 1.4.0 路径，不使用系统默认 1.3.14。工作目录为 `D:\myhexin-local\opencorvus\packages\overlay`。

```powershell
$env:PATH = 'D:/myhexin-local/opencorvus/.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64;' + $env:PATH
bun run typecheck
node --max-old-space-size=8192 ./node_modules/vite/bin/vite.js build --config vite.config.ts --outDir 'D:/myhexin-local/opencorvus/.tmp-standalone-permission-projection-402/ui-after'
bun run check:renderer-surface
```

分别将输出/exit 落自有 scratch 的 typecheck-ui.log、build-ui.log、renderer-surface-ui.log 及对应 exit 文件。独立 outDir 避免写共享 dist-vite；本命令只是编译，绝不启动 Vite server。renderer-surface 是已有公共全局对象安全面检查，不是 UI 文案/组件验收。此命令与当前 401 build-root.log 的实际 Node build 路径一致。没有执行任何命令，不能预写通过状态。

## 实施前交接与真实验收边界

须等 backend 明确：两个 mandatory 数组的最终 generated type、Asked 的 interaction-domain orderKey、Terminated 真实字段与 Session child 过滤、Permission connected replay 已删除、Task 同 ledger 失效通知完成。UI 不能在过渡阶段双读旧 replay 和新快照。SDK 生成文件由后端事务交付，UI 不手改。

Root 后续逐项真实页面：自然 Main inline/Dialog pending、Allow once/deny 与 Tool/自然消息终态；冷选中及 reconnect、多个 pending、合法 Permission child、Task 原卡和 SideChat exact 自身；动作在飞切 source/directory/API authority/selection 后不能把新源当旧默认刷新；Question 回答/拒绝/草稿与读位；中英布局/动作/错误。后台状态测试、静态审查和私有构建均不替代这些真实证据。本准备未证明任何一项 UI 通过，未新增 child Question 范围。
