# 402 完整 Board 响应校验器审查（只读，待 Root 纳入 spec）

## 当前决定与范围

Root 最新决定采用完整 JSON 语义资源的弱 Entity Tag（ETag，实体标签），形如 `W/"task-board-v1:<digest>"`。这是完整 Board 条件请求方案，取代此前被撤回的状态计数与仅 Interaction 域指纹方案；不保留 coarse tag、旧版本 fallback 或第二个校验实现。此稿只写 scratch，不修改生产/spec/共享文件，不运行 probe、服务、模型、UI 自动化或其他测试。

## 全仓定义、消费者与历史

当前生产调用链只有一条并行 tag 查询：

`server/routes/orchestrator.ts:1310 GET /task/:id/board → EngineService.getBoardTag → task-api/index.ts:2222 → workbench/board.ts:64 boardTag → boardTagForTask:379`。

同一路由不匹配时再 `EngineService.getBoard → compileBoard`，后者又算一次tag，再调用buildBoard。`boardTagForTask`只有compileBoard和boardTag两个调用点；全仓没有其他getBoardTag/boardTag生产或测试消费者。删除getBoardTag导出、对应import、boardTag、boardTagForTask及其专用taskSessionTreeVersion是完整替换，而不是留下可并行继续调用的旧事实来源。

`compileBoard`另有真实生产调用：task-api.getProgress、task-api.getBoard；orchestrator路由的taskConversationBoard（会话hydrate）；mission/projection的missionStatusRecord；Task project archive通过EngineService.getBoard间接使用。它们仍得到相同Board数据shape和非空snapshotVersion，只是版本的构造变为唯一完整响应身份。`getProgress`当前还额外读取pending Interactions，这是其已有业务投影，不能因为本批删除tag就无分析顺带改写。

前端snapshotVersion消费者仅把它当非空opaque string：`store/board.ts:180–186`校验，`setSnapshotVersion:875–890`要求与当前board.snapshotVersion精确相同；没有按pipe拆分或推导字段。`boardEtag:58/379/396/866`保存响应ETag原字符串，并原样送回If-None-Match；与snapshotVersion分别存储，不解析其语法。clearBoard/workspace切换清空二者，原ApiAuthority/selectEpoch/单请求owner仍有效。新版本可直接让body.snapshotVersion与HTTP ETag都使用同一个 `W/"..."` 字符串，不需要前端改造或兼容旧pipe字符串；旧缓存首次请求自然得到200和新标签。

公共模型`engine/model.ts:765`和SDK两处生成字段都是`string`，没有pipe格式或长度固定假设。OpenAPI当前Board route只显式描述200；304是现有行为但没有明确响应文档。本次若补304/header文档应由同一SDK生成事务产生对应变化；仅改变opaque string值本身不需要手改SDK类型。402新增权限schema仍需完整SDK事务，不能混为“validator无需生成所以402无需生成”。

历史：`627146cc3`把Interaction projection和当前标签来源收敛到不可变事实；`1f52b298a`删除Board曾承诺但无效的sync接口并建立当前路由；brief缓存当前主体可追溯`65d0bfc98`。随后Board内容扩展包括`49028f70c`运行/故障表面、`70df9fbbf`流请求来源等；不能把最初部分count/time列表当新增完整响应字段的可靠身份。

检索命中了Overlay三个服务/状态测试：`history-composer-isolation.test.ts`、`git-init-current.test.ts`、`projection-prerequisite-recovery.test.ts`。只读其入口可见它们导入store/service/transport，未运行；没有据文件名把它们当真实页面验收。另`opencorvus/test/orchestrator-initial-task-render.test.ts:288`直接解析compileBoard，是当前相关后台数据调用线索。本审查不新增、修改或运行这些测试，也不扩展成UI测试清理。

## 当前完整响应与旧tag缺失的信息

旧tag由Task identity/time/budget、Session树count/max-time/lifecycle/error序号、Goals count/max-time、Interaction count/max-time、Artifact count/max-time、channel count/max-time、progress snapshot count/max-time拼成未加引号的pipe字符串。它既丢失每个条目的身份和值，也未按HTTP entity-tag语法加引号。

实际buildBoard还返回：完整Task/Project公开字段、Interaction每个ID/状态/请求与响应/时间、channel身份及payload、artifact身份/locator/压缩后的payload、requirements/architect/goals派生字段、sessionInvocationTopology、executionProjection、processIncidents、overview、brief、lastSequence。完整响应才能辨识这些实际值、数组顺序、同毫秒修改和等计数身份变化。不能继续维护逐个新字段添加计数的白名单。

## 推荐唯一实现

1. `compileBoard`只构建一次不含snapshotVersion的完整自然Board对象。buildBoard删除snapshotVersion参数/返回字段；保留所有现有业务投影、Project/Task校验及数组顺序，不另从数据库读一遍来算版本。
2. 按现有HTTP JSON序列化语义得到JSON可见值：对象undefined字段省略，数组规则保持JSON语义。`viewInteraction`等当前确有undefined，不能直接传给会拒绝undefined的canonicalDigestSource；也不能手工将它们一律替换成null。这个request-local JSON物化是实际返回值的副本，不是持久或可漂移的第二Board缓存。
3. 用现有`util/canonical-digest.ts`的`canonicalDigestSource("opencorvus.task-board-json.v1", jsonVisibleBoard).sha256`产生域隔离指纹。输入是全部JSON可见响应，仅排除自指snapshotVersion。object key canonical排序只用于身份；数组顺序保留，因为它是响应含义。版本设为一个固定规范的弱实体标签，例如 `W/"task-board-v1:<64 hex>"`。
4. 返回同一个已物化JSON对象加该snapshotVersion。保留自然JSON字段输出顺序，不为强标签另做全响应canonical重排。没有旧tag分支、源码hash验收门、字段计数、wall-clock版本、fake Task更新时间或业务状态变更。
5. GET route只调用一次EngineService.getBoard，在同一返回对象上取版本、处理条件请求及返回200 body。删除原getBoardTag调用和手写相等判断。原Project/Task准入仍在getBoard中，不能在验证资源存在/权限之前因`If-None-Match:*`提前304。

单次完整JSON物化保证“版本与所返回内容同源”；它不自动等于所有跨进程SQL读取都在同一SQLite时间点。现有buildBoard是同步多查询且compileBrief可能写派生缓存；本批不要未经分析给每个GET加BEGIN IMMEDIATE长持写锁，也不要暗改Task occurrence/恢复。HTTP身份应准确描述实际物化结果；若另需加强跨查询事务快照，必须单独审查缓存写入和锁影响。

## 复用安装Hono条件请求实现

实际安装消费者是Hono 4.13.7（`packages/opencorvus/node_modules/hono`规范化至`.bun/hono@4.13.7/node_modules/hono`）。其`hono/etag`源码在GET/HEAD等可用响应上执行、接受If-None-Match列表和`*`、比较时剥离`W/`作弱比较，匹配分支设置空304。此前“默认保留指定头”的概括不够精确，下面补齐实际Context赋值链，不能把`RETAINED_304_HEADERS`常量当成运行证据。handler已设置ETag时它直接使用，不再生成第二个digest。因此可仅在Board路由使用`etag({weak:true})`，handler先设置**已含W/与引号的snapshotVersion**再返回同一个board；`weak:true`不会自动改写一个已存在的强标签，不能漏写前缀。

官方[Hono ETag说明](https://hono.dev/docs/middleware/builtin/etag)与安装源码吻合；以安装实现为准，不升级依赖。其默认body摘要分支在本设计下不执行，唯一版本仍由compileBoard完整投影产生。不得一边保留旧手写304，一边再套middleware。

### 304响应头的完整源码链（未运行HTTP验证）

Root指出etag匹配分支确实先执行`c.res = new Response(null, {status:304,headers:{ETag}})`，随后遍历的是新`c.res.headers`，不是局部变量`res.headers`。因此该middleware本身没有显式从旧res复制任何头，也不会凭空补出cache-control/content-location/date/expires/vary。

进一步读取安装版真实Context后，不能据此推断旧头一定丢失：`dist/hono-base.js`实际构建`new Context`；`dist/context.js:119–137`的`set res(_res)`会将旧`this.#res.headers`复制到新Response，跳过content-type。etag之前的`const res = c.res`保证旧Context Response已存在。赋值通过该setter后，新response才进入etag的过滤循环；已有且在retained列表内的头可因此留下，非retained头会被删。CJS Context具有相同逻辑。这是已读取的完整静态控制流，不是由常量名字推定，更不是已运行的HTTP结果。

当前Board路由自己只设置ETag并以c.json产生200 Content-Type，没有设置Cache-Control、Content-Location、Expires或Vary，也没有在应用代码中设置Date。因此本批不存在“这些已设置的Board cache头都必须恢复”的已证实输入；Date是否由真实Bun HTTP层添加仍待实际HTTP核对，不能由Hono常量承诺。

当前部署有两个真实Hono Context：`AppRoutes(root)`返回新的Project Hono（routes/app.ts:156），server.ts:924调用`projectApp.fetch`；内部Board/etag处理完后，外层server在返回的Response上明确重设自己的`x-opencorvus-request-id`（926）。外层CORS在next之前将Access-Control-Allow-Origin（条件允许时）和Access-Control-Expose-Headers写入**外层Context**；外层compose接收Project Response时同样经过Context.res setter，将这些外层头合并进去。CORS在next之后只明确追加`Vary: Origin`，**并不在after-next重新创建Allow-Origin或Expose-Headers**，它们依赖前述外层Context合并。把所有头概括成“CORS after-next会补齐”也是不准确的。

| 当前Board所需/相关头 | 可核对生产来源 | 本次证据边界 |
| --- | --- | --- |
| ETag | Board给出当前版本；etag匹配分支新304明确设置 | 仍需实际200/304确认同版本 |
| Content-Type | 200 c.json；304无响应正文，Context setter跳过旧content-type | 需HTTP确认最终304，不以源码代替 |
| x-opencorvus-request-id | 外层server在Project fetch完成后明确写入 | 检查200/304均与原请求诊断ID一致 |
| Access-Control-Allow-Origin | 外层cors在next之前按允许来源设置，外层Context setter合并 | 只对合法Origin适用；不等于允许任意Origin |
| Access-Control-Expose-Headers | 外层cors在next之前设置ETag/request-id等，外层Context setter合并 | 检查实际跨Origin可见的值 |
| Vary: Origin | 外层cors after-next追加 | 必须实际确认304仍含Origin且不覆盖已有Vary项 |
| Cache-Control/Content-Location/Expires | 当前Board路径未设置 | 不新增缓存策略，也不冒称已恢复这些头 |
| Date | 当前应用代码未主动设置，可能由HTTP运行时生成 | 此次未探测，待Root真实HTTP |

结论是“安装Context setter加middleware过滤的静态链可解释既有保留头与外层CORS/请求ID如何传递”，不是“Hono常量保证了运行正确”。Root后续必须用实际Server HTTP入口核对上述200/304头，不能只直接调用内层EngineRoutes并据缺外层头判产品故障，也不能只测裸middleware就宣称完整Server链合格。本轮未运行服务或测试。

## 压缩与Vary

已读server.ts完整middleware注册顺序：鉴权→request ID/log→Origin准入→CORS→目录/Project上下文→Project routes。未发现覆盖Board JSON的通用`hono/compress`或其他压缩middleware。当前可核实的HTTP压缩位于`server/sse.ts`，只包SSE stream：先建立流，再添加`Vary: Accept-Encoding`，按协商gzip或identity，gzip时设置Content-Encoding并删除Content-Length。Board普通JSON不走该函数，不能把305的SSE gzip验收扩展成Board gzip事实。

采用weak semantic ETag允许同JSON语义在不同压缩表征下共用标签；这不免除真正进行encoding协商的服务/代理保留`Vary: Accept-Encoding`。当前不新增Board压缩或虚构该Vary需求；若部署层另有压缩，实际HTTP检查应确认其Content-Encoding/Vary与语义标签相容。强标签则需要每个选定编码表征的byte identity，不能直接把排序后的语义digest声称为实际wire byte校验。

依据：[RFC 9110 §8.8](https://www.rfc-editor.org/rfc/rfc9110.html#section-8.8)区分语义弱校验与强表征身份；[§13.1.2](https://www.rfc-editor.org/rfc/rfc9110.html#section-13.1.2)要求If-None-Match使用弱比较并支持列表/星号。这里哈希描述真实协议响应，是有效资源身份；与无效源码摘要门槛不同。

## compileBrief副作用、稳定性与只读措辞

`compileBrief`并非完全无写入：命中snapshot.inputs.signature则返回已存content/time_created；未命中会recallMemory并插入WorkbenchBriefSnapshotTable，返回该次写入的now。signature只含Task id/time_updated与Goal count/max-time，没有随每次GET更改。新完整GET在原本可能被coarse tag挡住的304检查前也会调用它，因此首次/失配请求可能生成派生缓存；必须如实把“不会推进Task业务状态”与“完全无DB写入”分开。

不要为了让摘要每次不同而刷新brief时间，也不要为了304跳过当前真实brief。两条正常返回均有updatedAt，`buildBoard`当前`brief.updatedAt ?? Date.now()`后备在现有类型/实现下无必要；若删除只限这处已证实的旧后备，不扩大brief签名或记忆缓存改造。缓存签名自身粗粒度可能留有其他内容刷新边界，完整Board validator只是忠实反映当前返回brief，并不等于修复所有brief生成政策。

重复未变GET应得到同一缓存brief时间与同一snapshotVersion。首次两并发cold读取是否会重复物化缓存、相应SQL锁/耗时，本审查未跑probe，不能报已解决。当前没有建议变更compileBrief缓存机制本身。

## lastSequence与版本语义

lastSequence已经在Board响应中，当前旧tag漏掉它。完整版本必须包含它；真实Task protocol事件导致它改变，即使可见正文同样，也应更新版本，因为客户端用它作为重放/单调边界。不要为了提高304命中率把它排除。已有taskSequence较新则丢弃旧Board响应的前端保护保留。

sessionInvocationTopology、executionProjection、incidents或Project metadata改变也会进入完整身份，不再依赖某个旧计数“碰巧”被更新。相同毫秒、两个请求状态分配不同、数组重排、同数量Artifact替换均由实际字段区别。无需添加事件序号影子缓存，也不改Task状态或permission决定。

## 成本与尚未测量事项

没有benchmark/probe，以下只是代码路径成本分析：

- 旧200 route最多重复三次listInteractions：预检查tag一次、compileBoard里的tag一次、buildBoard一次；新方案一次buildBoard可删掉这些重复与所有旧tag专用聚合SQL。
- 旧304只有coarse tag路径；新304必须构建完整Board，额外读取/投影goals、artifacts、channels、topology/execution/incidents、brief等。准确性优先，不能保留已知false304“快路径”。
- 当前listInteractions本身扫描全部Interaction requests再投影/filter Task，可能具有跨Task的查询放大；本批不顺手重写它。完整body依然一次使用该现有函数。
- 完整JSON序列化/物化/规范排序/摘要至少与响应字节数线性相关，对象key排序另有开销；会同时保留原对象、JSON文本/可见对象、canonical字节等临时内存。不能给出未经测量的毫秒或MB预算。
- 现有artifact摘要有字符串/数组/深度限制，但Interaction数量、payload、Task request等并非统一总量上限，不能声称Board有固定小体积。Mission状态中逐Task调用compileBoard也将计算版本，需留意大Mission的CPU成本。
- 性能、SQLite查询数、并发cache生成和大Board尺寸仍未实际测量。若后续需要优化，只能从可证明等价的真实内容/不可变资源版本入手，不能恢复计数标签或双读旧路径。

## 精确范围与删除影响

最小validator生产范围为：

1. `workbench/board.ts`：完整响应一次物化/版本；删boardTag、boardTagForTask、taskSessionTreeVersion和由删除确实变成未使用的imports；buildBoard不接收旧version参数。
2. `task-api/index.ts`：删除boardTag import和getBoardTag导出，保留getBoard的Project准入与单次compileBoard；准确说明既有brief派生缓存边界。
3. `server/routes/orchestrator.ts`：Board路由单一getBoard，设置同一弱ETag/body版本，使用route-scoped Hono etag处理条件请求，删旧parallel preflight/manual比较。若同步描述304及ETag header，仍在此处。

没有前端字符串解析适配、数据库schema、Task调度、Provider/permission政策或新依赖需求。canonical-digest和Hono只复用，不再造新的通用hash工具。生成schema的snapshotVersion类型不变；304/header文档和402其余新schema按既有完整SDK生成事务同步，不能手工改gen文件。

删除旧tag专用helpers后：EngineGoalTable仍用于其他函数类型/查询，EngineInteractionRequestTable仍用于Board helper输入类型，不能按名字批量删；EngineInteractionOutcomeTable当前只在import出现，是否同本次清理应以真实使用清单和Root批准为准。删除范围必须仅为替换所产生的死路径，不做整文件无关整理。

## 正向后台与HTTP验收计划

不以重算同一个digest证明自己正确，必须验证公开路径的明确输出：

- 真实Project/Task首个GET：200、完整TaskBoard、标准`W/"..."` ETag，header与body.snapshotVersion相同；随后用原tag条件GET：304空body并有同一ETag。
- If-None-Match列表包含当前tag、`*`、与其同opaque值的强写法均按GET弱比较返回304；不同tag返回200当前body。HEAD沿框架GET fallback时返回同tag/无body，实际HTTP检查确认。
- same-ms真实Permission pending→cancelled/stale、同数量但每request状态分配不同、Question真实回答变化，均返回200并包含正确原ID/响应/ledger时间。构造必须遵守不可变决定合同，不直接改已settled ledger行造case。
- Task字段、Project name/worktree、channel payload、artifact内容/locator、goal-derived字段、execution/incidents、brief实际输出以及lastSequence发生合法变化后，旧tag条件GET返回200对应新值。相同JSON语义仅对象key插入顺序不同仍可304；数组顺序改变则200。
- 两Project/Task的请求先走真实准入：错Project维持明确404/当前错误合同，不能因星号绕过；授权请求返回自己的Board与tag。
- 每个200的header和body来自同一物化结果；在真实并发写入下返回版本与其body一致。避免加只检查“某函数调用一次”的负向/镜像测试。
- 重复未变GET保持brief缓存时间；首次缺cache的真实输出及缓存记录可核对，不能声称数据库完全无写入。并发和大Board成本未测时保留明确未知。
- 实际HTTP记录Content-Type、ETag、304 body、CORS允许来源/Expose-Headers、Vary:Origin及request-id。Board当前无内置encoding协商；SSE保留原独立gzip/Vary合同，不把它纳入新Board功能承诺。

以上都是待Root批准后的backend/HTTP正向合同；没有运行UI自动化、源码文案/DOM/截图差异测试，也没有把本次静态审查或401 UI资格当成402运行验收。
