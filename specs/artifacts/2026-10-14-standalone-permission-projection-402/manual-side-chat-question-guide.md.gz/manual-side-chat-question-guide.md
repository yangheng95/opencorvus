# 402 Side chat / Question 手动验收入口核对

2026-10-14。仅只读当前生产定义与调用，供 Root 在其已授权真实页面/受控流式 Provider scope 中操作。未启动页面、服务、模型或 SDK，未运行 UI/组件/DOM/源码断言测试，未调用任何下述 HTTP API，未修改生产/spec/共享文件/Git。下述交互路径来自代码，不冒充实页结果。

## Side chat：最小真实步骤

1. 在主聊天选择已有真实 Session，使聊天标题栏存在 **Side chat / 侧聊** 图标按钮。精确入口是 `components/App.tsx:487–490`：`aria-label`/`title=t(side_chat.title)`、`data-ui=open-side-chat`。不必从 Settings 或创建 Task 寻找。
2. 点击该按钮。`main.tsx:616` 的 openRightDockPanel(side-chat) 调用 requestSideChat；`:481–501` 捕获主来源并打开 Side chat 面板，request.intent=open。Session 直接取 selectedSource.id；Task 则取 `rootTaskSessionID()`（store/board.ts:795 的真实 Task 根 Session），目录为当前 activeDirectory，携带 captureApiAuthority。
3. 面板先 GET 源 Session 的 side-chat 列表。若已有侧聊，默认选择列表首项（服务端 time_created 降序）；open 意图只聚焦当前侧聊，不再创建。若没有，会自动创建并选择新侧聊。若验收要求 fresh，点击面板顶部 plus 按钮 **New side chat / 新建侧聊**；它只调用 create，没有隐式发送模型消息。`SideChatPanel.tsx:144–221,381–392`。
4. 等候连接完成，在 **Ask a side question… / 问一个相关问题…** 文本框输入自然请求。点击 **Send side question / 发送侧聊问题**，或 Enter；Shift+Enter 换行，IME composing 不发送。发送按钮要求有选定 sideID、已连接、非空文本，文件编辑保留态会禁用本区操作。`SideChatPanel.tsx:301–343,523–576`。
5. 应观察新的 side Session 自身产生 Question/Permission；其交互卡位于侧聊正文，`SideChatPanel.tsx:485` 直接渲染 InteractionCard，并保留显式 `afterReply=follow.contentChanged`。这是 side 自己的请求，不是批准 Main 的旧请求。

附加已存在入口：Ctrl+Alt+S（macOS Meta+Alt+S）调用同 requestSideChat(open)，见 main.tsx:3130；主 composer `/side` 打开/复用，`/side <文字>` 或“在侧聊中提问”引用操作使用 fork 意图，创建新侧聊并仅预填文字，仍需在侧聊真实发送。`ChatComposer.tsx:611,1050`、main.tsx:494–500。最小验收优先显式按钮，避免将命令预填当成已经向 Provider 发送。

## 公开 API 和 Session 关系

这些是当前相对于服务 API 根的路径，directory 使用 URLSearchParams 正确编码，不手拼 query：

| 动作 | 实际路径/体 | 代码证据 |
| --- | --- | --- |
| 列源侧聊 | `GET session/<sourceSessionID>/side-chat?directory=<owningDirectory>` | services/side-chat.ts:25–29；server/routes/session.ts:1846；chat/side-chat.ts:14 |
| 创建独立侧聊 | `POST session/<sourceSessionID>/side-chat?directory=<owningDirectory>`，无请求 JSON 体 | services/side-chat.ts:31；session route:1862–1880 → Session.fork({sessionID,purpose:side-chat}) |
| 侧聊流 | `GET session/<newSideID>/events?directory=<owningDirectory>` | SideChatPanel.tsx:267、services/side-chat.ts:74；本批 connected 强制 pendingPermissions 且只取 exact sideID |
| 发送侧聊新输入 | `POST session/<newSideID>/message?directory=<owningDirectory>`，`{messageID:<composer真实生成>,agent:"chat",parts:[{type:"text",text:<真实输入>}]}` | SideChatPanel.tsx:306–331；timeoutMilliseconds=null，原流式执行合同 |

`session/index.ts:402–450` 明确：purpose=side-chat 生成 **独立 assistant 根 Session，parentID=undefined**；directory=original.directory，保留 original.permission 和当前源 EffectiveConfig.overlay 的 configOverlay。它不是主会话的 durable child，不承担主 Task ownership；即使由 Task 主面板启动也是独立根。因此 Side chat 不能替代本批 Main 合法 child Permission 的验收样本。

`:456–478` 只复制至最近真实完成的 assistant response，同时保留其 accepted user inputs；当前尚未完成的 tool-call turn/待批准不复制。`:548–555` 将 `metadata.sideChat={sourceSessionID:original.id,inheritedMessageIDs:[真实克隆消息ID...]}` 与新的 Session/引用历史在同一事务提交。列表按同 Project、未归档、未删除、匹配 metadata.sourceSessionID 返回。

`chat/side-chat-identity.ts:18–25` 拒绝 archived/nested 来源；其实际系统提示明确参考历史不是活动请求或授权，不恢复主会话未完成工具，不启动/通信子 agent。Root 可从创建返回的新 id、kind、parentID 和 metadata 查证真实关系；本报告没有猜测本轮运行 ID。

## Question：最小合法参数和草稿操作

真实 tool id 为 `question`。`tool/question.ts:6–17` 使用参数 `{questions: z.array(Question.Info).min(1).max(4)}`，execute 以 ctx.sessionID、真实 messageID/callID 调 Question.askAndFormat。`question/types.ts:34–41` 每题要求 question/header/options；options 没有 min 限制。每个非空选项需 value、label、description，disabled 可选。multiple/custom 可选。

最小自由文本参数（custom 可省略，默认 UI 允许自定义；验收建议显式保留）：

```json
{
  "questions": [
    {
      "header": "402 draft",
      "question": "Which label should I use?",
      "options": [],
      "custom": true
    }
  ]
}
```

这是让受控流式 Provider 发出的真实 tool call 参数，不是直接构造 Question UI 或绕过工具调用。不要在 tool args 添加 requestID、sessionID、automatic 或 expiry；这些不在 QuestionTool 参数 schema，由当前实际执行上下文/配置产生。

若另需真实选择控件，可给 options 加完整项：`[{"value":"alpha","label":"Alpha","description":"Use the first label"},{"value":"beta","label":"Beta","description":"Use the second label"}]`。`multiple:true` 显示 checkbox；默认显示 radio。返回的是 value，自定义文本附加到同题 answers 数组；askAndFormat 将已选 value 格式化成 `label [value]`，不是把可见 label 当稳定回复值。工具说明文件目前“arrays of labels”表述不能覆盖实际 schema/回复代码，本轮不扩大说明修订。

Main Dialog 标题 **Question / 提问**，由 InteractionDialogHost.tsx:41–64 的同 InteractionCard 渲染。对上面的参数，textarea 的无障碍名由 legend 合成为 **402 draft: Which label should I use?**；placeholder 为 **Or type a custom answer… / 或输入自定义回答…**。精确代码：InteractionCard.tsx:249–332、questionLabel:419–425。options=[] 时 rows=3，输入调用 setCustomAt；`custom:false` 则没有该 textarea。

手动序列：等待真实 Question Dialog → 在该 Dialog 内的文本框输入独特草稿（如 `DRAFT-402-A`）但不点击提交 → 截图/读取当前实际输入 → Root 按目标场景触发自然 Permission 更新或重连 → 重新观察同一 Dialog 的该输入。最终用 **Answer / 回复** 按钮提交；InteractionCard.tsx:186–206 将当前自定义文本组为 `answers:[["DRAFT-402-A"]]`，interaction-reply.ts:64–76 发送 `POST question/<requestID>/reply?directory=...`。**Skip / 跳过**走原 reject 端点；不是保存草稿。

InteractionCard 的 textarea 没有 composer 的 Enter-submit handler；普通 Enter 是文本编辑，不应拿“按了 Enter”当成已经提交。Dialog 与 inline 是两个组件、各自 `customText/drafts` signal；不要用关闭 Dialog 后 inline 为空来宣称同一组件的输入丢失。Escape/遮罩是显式 dismiss，会销毁当前 Dialog owner。

## 本轮实际观察边界

- 与 Root 已讨论一致：仅 Permission 子集变化且同 Question 仍被选中，原 Question 引用/代理/组件可保持；完整 reconnect 的既有 Question Asked 重放会产生新对象；更早 Permission 进入 oldest 仲裁也可改选 Dialog。三种场景分开取证，不以其中之一替代其它。
- Question tool 是 builtin observation-only（permission/invocation.ts），不会靠调用自身额外产生 Permission；要测 Permission 必须由同 scope 中真实需要许可的工具请求产生，不伪造 Asked 事件。
- global-tools.ts:13–19 的现成提供条件为 OPENCORVUS_CLIENT 属 app/cli/desktop 或启用既有 question flag；flag 默认 client=cli（flag.ts:127–129）。Root 应看实际 Provider 请求 tools 中确有 question；本报告不改运行环境或增加工具发现绕行。普通 chat native profile 原本允许 question（primary-assistant-registry.ts:113–118）。
- askAndFormat 仅在现有 experimental.auto_question=true 时为普通题设置未答 expiry；工具 args 无定时配置。不要编造所有 Question 都有自动倒计时。无此实际配置/运行事实时，保留原 scope 截止并由 Root 正常完成/拒绝和物理关闭。
- Side chat 已创建但尚未输入发送时不产生新的模型 turn；继承参考历史也不能计作本轮新的模型或批准成功证据。
