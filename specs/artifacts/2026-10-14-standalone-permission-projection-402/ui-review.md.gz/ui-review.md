# 402 独立前端复核：pending权限、恢复与回复归属

只读范围：Root最新402“pending-only Permission”推荐、当前tree-writer/conversation/SideChat/InteractionCard/reply/event/recovery链、直接Permission terminal代码及相关历史。未修改生产、测试、402/398规格或共享文档；未启动页面/服务/模型、未读凭据、未运行UI自动化、不提交、不再委托。此报告是源码和契约反馈，不是已完成真实UI验收。

## 结论

复用一份standalone交互Map、同一Permission normalizer及现有InteractionCard/interaction-reply是合理最小方向；pending-only可沿SideChat已有合同，不需要给Permission新增timeResolved或伪造已答Message。但有两项不能按“现有代码已经处理”放过：

1. **Main/弹窗成功回复后的默认loadBoard会清空Session board。** 必须纳入本批源码范围修正默认回调归属，不能声称InteractionCard行为可完全不变。
2. **cancel/stale没有已证实的Session主动重读链。** 当前ledger terminal函数不发permission.replied，现有selected-task-recovery明确只服务Task；Session lifecycle、stop请求均不刷新pending。仅asked/replied加hydrate/connected仍可能留住在线已取消卡，不能将这一范围算完成。

两项已分别同步Root和audit_functionality。以下给精确调用证据与建议，不抢先实现未知后端通知。

## 1. 当前单一Map与新增Permission所需字段

`tree-writer.ts:515–518`的standaloneQuestionInteractions是唯一当前standalone交互Map；`:613`随resetWriter清空，`:1244`参与消息到达后的交互层级重建，`:3927–3929`与board.interactions共同进入rebuildInteractionCards。应按批准方案重命名/扩展这一Map，不能另外建Permission队列。

Question normalizer `:2102–2138`校验id/sessionID、interaction domain orderKey、timeCreated为正且与key时间一致；Permission应达到相同严格程度。SideChat目前`:113–123`只构建id/type/title/body/status/choices/replyEndpoint/directory，没有sessionID/orderKey/time；直接搬这个对象到Main会在`utils/interaction.ts:52–87`及`tree-writer.ts:3816–3823`的seed校验失败。共享normalizer至少返回：

- 原Request.id、sessionID、timeCreated及服务器给定orderKey，明确type=permission/status=pending；Request.projectID/taskID用于准入归属，不能从id或tool名称猜。
- title=原toolName，body使用原summary和整个scope的JSON，保留真实技术身份；资源路径在scope.resource.paths，不能并读scope.paths。
- payload.choices原样从Request合法choices投影，replyEndpoint=permission，directory由已验证selected source/SideChat target传入，不能临回复时借当前另一个Project目录。

`InteractionData`公开TS接口目前没有time/orderKey/sessionID，但实际Question对象携带它们。宜为归一化的投影对象增加精确类型或在共享pure helper定义完整交互投影类型，不继续用any掩盖Main与SideChat字段差异。可以把现有Question/新增Permission正规化放同一轻量模块供tree-writer与SideChat调用，Map仍只有tree-writer一个；SideChat自身已存在的局部pending Map属于独立会话视图，不是第二份Main授权事实。

`prepareStandaloneQuestionInteractions`会拒绝快照重复id；新快照也应按完整输入先prepare/validate，再进入batch提交。不能边读边删旧卡，解析失败应保留当前可见状态并正常报诊断。

## 2. warm事件过滤不能照抄Question的根Session判定

`handleStandaloneQuestion:2161–2176`目前准入条件是选中根sessionID、已知stage=mission或Map里已有id。`isSelectedStandaloneSession:2084–2089`是**根id相等**，不是任意已知子Session。因此将这个条件原样复制到Permission，会出现冷快照接纳合法session树子请求、warm非Mission子请求却被丢弃的不一致。

Permission必须按后端明确的当前Project/完整Session树和Task归属合同准入：Task source不注入standalone；Session source接纳该stream已验证的非Task请求，taskID不为空则保持原Task board入口。不要用“sessions Map中暂时不存在就丢弃”替代后端作用域，因为合法asked可能在前端子消息投影前到达。已有`sse.ts:343–351/466`的ApiAuthority+streamGeneration+handle所有权负责旧连接拒绝；新helper应明确接收source上下文，不能靠全局任意permission.list填卡。

SideChat `:108`仍精确event.session_id===target.sessionID，新snapshot也须过滤同一个target Session，不能把返回session树的子请求放入自己的主卡。SideChat从Task发起也不会继承Task parent：`Session.fork:428–441`对purpose=side-chat明确parentID=undefined、kind=assistant，只以metadata.sideChat.sourceSessionID关联原历史。该既有事实支持保留SideChat独立权限边界；不能为了Main修复重新挂接Task身份。

## 3. hydrate/connected的替换边界与实时竞态

`conversation.ts:655–744`的hydrate已有prepare/validate→batch/resetWriter→commit→events原子流程，并通过ApiAuthority、replayEpoch、abort及selected source判定退役旧响应。新增必有pendingPermissions数组应在`:687`附近解析，和Question一起参与`:700`的duplicate/orderKey校验，然后在reset后提交；Task source传空standalone列表，保留board.interactions唯一来源。

`mergeSessionConnectionSnapshot:447–469`目前只增量commit transcript/view/history，**不resetWriter**。这里是重连时替换当前source的pending Permission集合的成熟接入点：先prepare全部新权限，再仅删除旧Map中type=permission的条目、插入当前集合、同batch重建层级。保留Question answered/rejected事实和未答Question现有对象，不把整个Map清空或整棵writer重置。回复后Permission完全从Map移除，不能设answered后让通用seed生成需要timeResolved的双气泡。

Root推荐的SSE cutover顺序有真实基础：`server/routes/session.ts:1294–1368`先订阅→读tail/pending→drain已接收prefix→connected→pending replay→释放buffer。新pendingPermissions应进入同一connected snapshot，用同一个Request/timeCreated/orderKey物化；后续asked重复按id upsert、replied按id移除。不得在connected之后又插入一个可能旧的独立HTTP权限快照，把snapshot后已经决定或新建的请求覆盖回去。

如果增加HTTP重读，只有ApiAuthority/selectEpoch还不够：同source HTTP请求期间的asked/replied不会改变selectEpoch，旧快照可能覆盖更新的live Map。现有完整hydrate有reset/replay机制但会影响挂载状态；本批应优先沿有序Session stream快照/通知收敛，若必须HTTP重读，要先设计同source事件缓冲/切换界限，不创建靠本地时钟猜新的权限事实。

## 4. 确定问题：默认afterReply不能用于Main Session

调用链：

- `CardParts.tsx:107–113`直接`<InteractionCard interaction={...}/>`；`InteractionDialogHost.tsx:62`同样不传afterReply。
- `InteractionCard.tsx:151–169`的runAction在fn成功后执行`props.afterReply ? props.afterReply() : loadBoard()`。
- `store/board.ts:339–355`的loadBoard取得activeTaskID；无Task时立即`setBoardStore("board", null)`、清snapshotVersion并return。它既不是Session pending刷新，也不是无副作用no-op。
- `SideChatPanel.tsx:485–487`已传`afterReply={() => follow?.contentChanged()}`，因此避开这个Task默认分支；它的实际权限移除来自同requestID的permission.replied，不依赖该afterReply做authoritative重读。

最小改法建议是让**默认回复后处理明确按点击开始时的source归属**，Main inline/dialog共用同一个实现：捕获source id/kind、directory、ApiAuthority与selectEpoch；HTTP完成后仅在原作用域仍当前时执行对应UI收尾。Task保留loadBoard({authority})；Session不调用loadBoard、不resetWriter，正常决定交给已提交permission.replied及有序connected替换删除pending。SideChat保留原显式afterReply归属。可以在InteractionCard统一默认路径增加这一判断，或由Main两个调用点共享一个明确的source-aware回调；不能让两个调用点分别复制刷新逻辑。

不建议仅靠`activeTaskID()`在await后决定分支：用户期间切到另一个Task可能导致旧Session回复刷新新Task。也不建议为了保持InteractionCard零diff而在loadBoard里普遍兼容Session，这会扩大所有任务Board调用者的契约。

`interaction-reply.ts`本身已按请求id互斥，permission分支只POST真实`permission/:id/reply`、body.decision，deny走同endpoint；无须新增批准API或发明自动回复。后续若统一callback，reply target应在动作开始捕获，不能在完成后用currentTraceDirectory补一个新目录。网络/服务错误时保留当前错误反馈，不能未经authority确认就把pending乐观删掉。

## 5. cancel/stale：当前没有自动收敛保证

已证实的后台事实（完整终态发布审查由audit_functionality负责）：

- `PermissionAuthority.cancelPendingForSessions:1563–1641`提交cancelled并释放waiters，没有Bus.publish(permission.replied)。
- `settleStale:1451–1468`提交stale并释放waiters；`retireContinuation:1290–1298`追加stale；也没有同事件。

对应前端没有隐含补偿：

- `events.ts:326–334`的agent.execution.lifecycle只更新agent view，只有匹配activeTaskID才scheduleBoard。
- `scheduleSelectedTaskRecovery:169–183`没有taskID直接return；`selected-task-recovery.ts:126–145`明确要求Task id并验证activeTaskID。
- `chat.ts:157–181`与`conversation-session.ts:491–509`的Session abort成功不重读conversation/pending。
- `tree-writer`普通message/part/lifecycle处理不会清理standalone Map；因此工具进入terminal不等于卡已移除。
- `deleteConversationSession:534–548`在同source正常删除后确实resetProjection/clearBoard/stopSSE；**整Session删除**已能清Map，但不能推给取消单个运行、stale或后台另一个客户端的决定。
- `performSessionSseReconnect:316–330`会重开原Session stream，connected快照可修离线间隙；在线heartbeat持续到达不会为了cancel/stale自动重连，35秒watchdog也不是合法状态同步机制。

因此最终实现必须给每个已提交pending terminal一个实际可消费的当前投影失效/移除事实，或者严格证明所有路径现有通知必定触发同源快照读取。不能将“下次切会话/重连会消失”当在线取消完成，不能加定时poll/全局class扫描/工具状态猜权限id，更不能把system cancellation冒成自然user reply。需要audit_functionality的唯一ledger发布方案后再固定这部分；本报告不提前指定新permissions.changed协议。

## 6. pending-only与自然用户决定的可见性

当前真正HTTP权限决定不是前端合成消息：`server/routes/permission.ts:29–43`建立`userInput:{surface:'http.permission',text:...,structured:{decision}}`并调用replyUser；`authority.ts:1137–1183`只由赢得ledger决定事务的那个调用发布带userInput的Replied，重复调用不产生第二用户决定。现有normalizer和pending-only移除应保留这条真实路由，不调用通用“发聊天消息”来补一个批准气泡。

但必须准确描述可见性：**pending-only不会在Main聊天正文保留一张已答Permission卡片**，实际用户决定/时间仍可通过唯一ledger的Settings历史查看，工具执行结果由原Tool Part/后续真实答复展示。`PermissionsPanel.tsx:115–120/130–149/300–356`读取directory-scoped history/grants，并展示allowed_once/grant/denied/cancelled/stale及真实time_created；这是现有自然事实可见入口。SideChat也已在Replied删除pending，没有新的已答气泡。

`07-panel-reactivity.md:405`当前概括“visible interaction resolved后有两时间位置”；402选择pending-only时Root应明确将此段适用范围限定为Question/Task保留的resolved交互，写清standalone Permission仅pending的例外。不能既移除Permission，又宣称所有交互决定仍有聊天中的请求/答复双位置。无需为这项文档澄清新增timeResolved。

## 7. SideChat、Dialog及共享影响风险

- SideChat `:81–90`connected当前先clear整个pending，然后等待服务器后续pending asked事件恢复。若402把权限只放snapshot而删除旧pendingPermissionEvents重发，SideChat必须在此从snapshot.pendingPermissions正规化其exact session请求；否则Main恢复而SideChat重连丢批准入口。Question原重发/answered边界不要顺手改。
- `parseSubagentConversation`主要消费transcript/view/history；它不会因为新JSON属性存在就自动显示权限。新增公开数组需要Core/SDK生成以及两个明确interaction消费接线，不能以类型可解析代替UI可达。
- Dialog收集 `utils/interaction-dialog.ts`按id去重，选择pending最早time.created；保持同id对象/卡片关联，connected刷新不要清Question草稿或因无关Permission变化重建已打开Question。`InteractionDialogHost`使用keyed Show，这是需要真实同实例交互确认的风险，当前未做UI测量，不能直接断言已经回归。
- Dialog同毫秒多个pending仅按time排序、相等依赖插入顺序；timeline本身按orderKey严格排序。若402承诺同时请求的弹窗首项也必须cold/warm一致，应复用现有canonical comparator，而不是给请求改时间。此为静态同值排序边界，尚未实页复现，不要求借此扩大本批所有弹窗布局。
- InteractionCard许可按钮直接过滤原choices，中文/英文按钮与图标名称使用现有i18n，正文保留真实tool/summary/scope。当前表单busy/error状态及per-id mutex可复用；不要在两个表面各写一个按钮。

## 8. 历史与建议最小验证

standaloneQuestionInteractions可追溯65d0bfc98；SideChat及它的afterReply扩展在`3d77ee1cc`加入。`85bcc029e`补Session connected的完整消息/字段恢复，`677f7afd1`确立连接/选择authority；402应沿这些所有者机制，不能因permission新增另一个epoch事实。这里的loadBoard问题是旧默认调用不适用新Main Session批准入口，不是normalizer字符串错误。

Root实际桌面应至少留证：当前GlobalChat pending内联与Dialog都能真实Allow once/deny；dismiss弹窗后内联仍可答；答复后Session board/title/目录/当前正文保持；点击后立刻切另一Session/Project，旧完成不清新board；cold/warm/离线决定后重连只显示当前pending；在线stop和真正stale经已批准通知收敛；多请求一项已决定时另一项仍可答；Question草稿与已答记录保留；Task board只有一张，SideChat自己请求仍可答。自然Tool输出和最终答案按实际取得声明，不能用Settings Requested或API手动批准冒充。

后台正向协议检查应覆盖新必有数组、请求orderKey、合法Session树/Project/Task排除、snapshot与buffer实时边界和cancel/stale终态；本只读任务没有新增或运行任何测试。Root的真实Scope与正常物理收尾继续独立于395旧失败证据。
