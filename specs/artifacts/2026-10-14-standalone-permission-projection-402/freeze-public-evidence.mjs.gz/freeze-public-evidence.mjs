import fs from 'node:fs'
import path from 'node:path'
import zlib from 'node:zlib'
const scratch='.tmp-standalone-permission-projection-402',archive='specs/artifacts/2026-10-14-standalone-permission-projection-402'
const selected=new Set()
const add=(relative)=>{const source=scratch+'/'+relative;if(!fs.existsSync(source))throw Error('Missing approved evidence '+relative);if(!fs.statSync(source).isFile())throw Error('File required');selected.add(source)}
const direct=(directory,filter)=>{for(const item of fs.readdirSync(scratch+'/'+directory,{withFileTypes:true}))if(item.isFile()&&filter(item.name))add(directory+'/'+item.name)}
const text=/\.(?:json|txt|md|log|exit|patch|ts|mjs|ps1|csv)$/
for(const dir of ['implementation','denied-continuation','denied-continuation/sdk-final','warm-summary','final-ui','final-root-recheck'])direct(dir,name=>text.test(name)&&!/(?:peer-sdk-before|baseline-tracked|status-|workspace-status)/.test(name))
direct('final-root-recheck/peer-type-failure-observed',name=>text.test(name))
for(const name of ['etag-identity-review.md','full-board-validator-review.md','denied-tool-continuation-review.md','settings-active-projection-review.md','task-terminal-ui-review.md','task-child-public-entry-review.md','manual-side-chat-question-guide.md','ui-review.md','frontend-preparation.md','ui-implementation-review.md','ui-implementation-files.json','ui-implementation.patch','current-docs-ops.json','final-shared-ops.json','manual-evidence-index.json','profile-selection.json','manual-permission-driver.ts','manual-permission-server.ts','public-entry-402.mjs','manual-facts-402.mjs','live-402.mjs','check-live-402.ts','live-402-deny.mjs','check-live-402-deny.ts','launch-sol.ps1','prepare-final-docs.mjs','freeze-public-evidence.mjs'])add(name)
for(const scope of ['manual-before-05',...Array.from({length:8},(_,i)=>'manual-after-0'+(i+1))]){
 direct(scope,name=>text.test(name)||name.endsWith('.jpg'))
 if(fs.existsSync(scratch+'/'+scope+'/observations'))direct(scope+'/observations',name=>name.endsWith('.jpg')||name.endsWith('.ax.txt'))
 for(const suffix of ['launch.json','runtime-owner.json','physical-terminal.json','stdout.log','stderr.log'])add(scope+'.'+suffix)
}
for(const scope of ['sol-after-01','sol-after-02']){
 direct(scope,name=>text.test(name)||name.endsWith('.jpg'))
 if(fs.existsSync(scratch+'/'+scope+'/observations'))direct(scope+'/observations',name=>name.endsWith('.jpg')||name.endsWith('.ax.txt'))
 for(const name of ['launch-owner.json','evidence/preflight-ready.json','evidence/native-host-ready.json','evidence/managed-parent-ready.json','evidence/authority-ready.json','evidence/provider-pair-staging.json'])add(scope+'/provider-run/'+name)
 const prefix=scope.endsWith('01')?'sol-402-a01':'sol-402-a02'
 for(const name of ['physical-terminal-and-pair-cleanup','qualified-surface-completion','shutdown-admission','settlement-owner'])add(scope+'/evidence/'+prefix+'-'+name+'.json')
}
const files=[]
for(const source of [...selected].sort()){
 const relative=source.slice(scratch.length+1)
 if(/(?:^|\/)(?:runtime|project|owned-temporary|native-sol-assets|ui-after|auth\.json|models\.json)(?:\/|$)|\.(?:db|exe)$/.test(relative))throw Error('Excluded evidence '+relative)
 const original=fs.readFileSync(source),jpeg=relative.endsWith('.jpg'),destination=relative+(jpeg?'':'.gz'),stored=jpeg?original:zlib.gzipSync(original,{level:9})
 if(jpeg&&(original[0]!==255||original[1]!==216||original[2]!==255))throw Error('Original JPEG required')
 const target=path.resolve(archive,destination);if(!target.startsWith(path.resolve(archive)+path.sep))throw Error('Archive boundary')
 fs.mkdirSync(path.dirname(target),{recursive:true});if(fs.existsSync(target)&&!fs.readFileSync(target).equals(stored))throw Error('Frozen evidence differs '+destination)
 fs.writeFileSync(target,stored);files.push({source,path:destination,compression:jpeg?'none':'gzip',sourceBytes:original.length,archivedBytes:stored.length})
}
fs.writeFileSync(archive+'/archive-manifest.json',JSON.stringify({iteration:402,selection:'Explicit public report/input/output allowlist and exact original JPEGs. No runtime, database, auth/models contents, executables, UI bundles, peer workspace diff, SDK baseline bundle or real Provider raw payload.',generatedDocuments:['README.md','archive-check.json'],files},null,2)+'\n')
fs.writeFileSync(archive+'/archive-check.json','{}\n')
console.log(JSON.stringify({files:files.length,jpeg:files.filter(item=>item.compression==='none').length,sourceBytes:files.reduce((sum,item)=>sum+item.sourceBytes,0),archiveBytes:files.reduce((sum,item)=>sum+item.archivedBytes,0)}))
