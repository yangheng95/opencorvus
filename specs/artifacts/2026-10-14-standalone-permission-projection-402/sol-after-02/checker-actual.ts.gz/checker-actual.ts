import assert from 'node:assert/strict'
import fs from 'node:fs/promises'
import path from 'node:path'
import { createRequire } from 'node:module'
import { Database } from 'bun:sqlite'
const root=process.argv[2]
assert(root&&path.isAbsolute(root));assert.equal(path.dirname(path.resolve(root)),import.meta.dir)
const json=async(name:string)=>JSON.parse(await fs.readFile(path.join(root,name),'utf8'))
const owner=await json('provider-run/launch-owner.json'),ready=await json('ready.json'),first=await json('global-chat-start-request.json'),accepted=await json('global-chat-start-response.json')
assert.equal(path.resolve(owner.runtime),path.join(root,'provider-run/runtime'));assert.equal(ready.occurrence,owner.occurrence)
assert.equal(accepted.status,202);assert.equal(accepted.result.requestID,first.requestID);assert.equal(accepted.result.session.id,ready.sessionID);assert.equal(accepted.result.messageID,ready.initialMessageID)
const projects=await fs.realpath(path.join(owner.runtime,'data/projects')),directory=await fs.realpath(ready.directory),relative=path.relative(projects,directory),publicPath=await fs.realpath(path.join(root,'public-external.csv'))
assert(relative&&!relative.startsWith('..')&&!path.isAbsolute(relative));assert(path.relative(directory,publicPath).startsWith('..'))
const expectedBytes=Buffer.from('batch,item,quantity\nCEDAR402,Maple,3\nCEDAR402,Iris,4\n')
assert.deepEqual(await fs.readFile(publicPath),expectedBytes)
process.env.OPENCORVUS_HOME=owner.runtime;process.env.OPENCORVUS_DISABLE_AUTOUPDATE='1'
const {projectToolPartInTransaction}=await import('../packages/opencorvus/src/session/tool-part-facts')
const {ToolPartRequestTable}=await import('../packages/opencorvus/src/session/session.sql')
const require=createRequire(path.join(import.meta.dir,'../packages/opencorvus/package.json'))
const {drizzle}=await import(require.resolve('drizzle-orm/bun-sqlite'))
const db=new Database(path.join(owner.runtime,'data/opencorvus.db'),{readonly:true})
let canonical:any
try{
 db.exec('BEGIN')
 const session=db.query('SELECT * FROM session WHERE id=?').get(ready.sessionID) as any
 const allocation=db.query("SELECT * FROM global_creation_allocation WHERE kind='global_chat_start' AND request_id=?").get(first.requestID)
 const messages=db.query('SELECT id,data FROM message WHERE session_id=? ORDER BY time_created,id').all(ready.sessionID).map((row:any)=>({id:row.id,...JSON.parse(row.data)}))
 const parts=db.query('SELECT p.id,p.message_id,p.data FROM part p JOIN message m ON m.id=p.message_id WHERE m.session_id=? ORDER BY p.time_created,p.id').all(ready.sessionID).map((row:any)=>({id:row.id,messageID:row.message_id,...JSON.parse(row.data)}))
 const outputDB=drizzle({client:db}),ids=new Set(messages.map((item:any)=>item.id))
 const tools=outputDB.select().from(ToolPartRequestTable).all().filter((row:any)=>ids.has(row.message_id)).map((row:any)=>projectToolPartInTransaction(outputDB as any,row))
 const policy=db.query('SELECT session_id,project_id,mode,revision FROM permission_policy WHERE session_id=?').get(ready.sessionID)
 const ledger=db.query('SELECT * FROM permission_ledger WHERE request_id IN (SELECT request_id FROM permission_ledger WHERE session_id=?) ORDER BY time_created,id').all(ready.sessionID)
 canonical={session,allocation,messages,parts,tools,policy,ledger}
}finally{db.exec('ROLLBACK');db.close()}
const files=(await fs.readdir(owner.evidence)).filter((name:string)=>/^provider-.*-\d+\.json$/.test(name))
const audits=await Promise.all(files.map(async(name:string)=>({name,value:JSON.parse(await fs.readFile(path.join(owner.evidence,name),'utf8'))})))
audits.sort((a,b)=>Date.parse(a.value.observedAt)-Date.parse(b.value.observedAt)||Number(a.name.match(/-(\d+)\.json$/)![1])-Number(b.name.match(/-(\d+)\.json$/)![1]))
const actualAudit=audits.at(-1)?.value;assert(actualAudit)
const audit={pid:actualAudit.pid,maxRequests:actualAudit.maxRequests,exhausted:actualAudit.exhausted,requests:actualAudit.requests.map((request:any)=>({model:request.model,streaming:request.streaming,status:request.status,readerState:request.response_reader?.state,terminal:request.response_reader?.terminal?.kind,sessionID:request.response_reader?.requestContext?.sessionID}))}
await fs.writeFile(path.join(root,`check-observation-${Date.now()}.json`),JSON.stringify({observedAt:new Date().toISOString(),occurrence:owner.occurrence,canonical,audit,publicFile:{path:publicPath,bytes:expectedBytes.length}},null,2),{flag:'wx'})
assert.equal(canonical.session.project_id,ready.projectID);assert.equal(canonical.session.directory,ready.directory)
assert.equal(canonical.allocation.accepted_target_id,ready.sessionID);assert.equal(canonical.allocation.accepted_project_id,ready.projectID)
assert.equal(canonical.messages.find((item:any)=>item.id===ready.initialMessageID)?.role,'user')
assert.deepEqual(canonical.parts.filter((item:any)=>item.messageID===ready.initialMessageID&&item.type==='text').map((item:any)=>item.text),[first.text])
assert.deepEqual({session:canonical.policy.session_id,project:canonical.policy.project_id,mode:canonical.policy.mode},{session:ready.sessionID,project:ready.projectID,mode:'ask'})
const requested=canonical.ledger.find((item:any)=>item.event_type==='requested'&&item.tool_name==='read'&&JSON.parse(item.scope).resource.paths.some((candidate:string)=>path.resolve(candidate)===publicPath))
assert(requested,'Real external-file read owns canonical Ask request');assert.equal(requested.project_id,ready.projectID);assert.equal(requested.effect_class,'read_local')
const events=canonical.ledger.filter((item:any)=>item.request_id===requested.request_id).map((item:any)=>item.event_type)
let cursor=-1
for(const expected of ['requested','denied']){const at=events.indexOf(expected,cursor+1);assert(at>cursor,`Actual Permission sequence reaches ${expected}`);cursor=at}
const tool=canonical.tools.find((item:any)=>item.callID===requested.tool_call_id&&item.messageID===requested.message_id)
assert.equal(tool.tool,'read');assert.equal(tool.state.status,'error');assert.equal(path.resolve(directory,tool.state.input.filePath),publicPath)
assert.equal(tool.state.failure.message,'The operator denied this Tool call.')
const final=canonical.messages.findLast((item:any)=>item.role==='assistant'&&item.parentID===ready.initialMessageID&&item.finish==='stop'&&Number.isFinite(item.time.completed))
assert(final,'Actual assistant reaches completed stop');assert.equal(final.providerID,'openai');assert.equal(final.modelID,'gpt-6.1-sol')
const answer=canonical.parts.filter((item:any)=>item.messageID===final.id&&item.type==='text').map((item:any)=>item.text).join('\n');assert(answer.length>0)
assert.equal(audit.pid,owner.nativeTarget.pid);assert.equal(audit.maxRequests,20);assert.equal(audit.exhausted,false);assert(audit.requests.length>0&&audit.requests.length<=20)
for(const request of audit.requests)assert.deepEqual({model:request.model,streaming:request.streaming,status:request.status,reader:request.readerState,terminal:request.terminal},{model:'gpt-6.1-sol',streaming:true,status:200,reader:'settled',terminal:'eof'})
assert(audit.requests.some((item:any)=>item.sessionID===ready.sessionID))
const result={observedAt:new Date().toISOString(),occurrence:owner.occurrence,sessionID:ready.sessionID,projectID:ready.projectID,permission:{requestID:requested.request_id,toolCallID:tool.callID,events,mode:requested.mode},publicBytes:expectedBytes.length,model:'openai/gpt-6.1-sol',requests200EOF:audit.requests.length,assistantID:final.id,answer,boundary:'Actual native/model/HTTP/ledger/tool/assistant facts; Root separately reviews UI and answer and joins original physical/pair settlement'}
await fs.writeFile(path.join(root,'live-check.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(result,null,2))
