# Manual after 04：旧 warm 说明、冷态恢复与 Side Allow Once

本记录依据 Root 已保存真实 public JSON/JPEG/AX 与原关闭回执。人工查看本目录三张原 JPEG，没有裁切、重编码或改变原观察；没有重跑页面/模型。此为受控流式 Provider scope，不是真实 Sol 验收。

侧 Session `ses_-zUS2OsHvzzYLRWWDcjM` 的源为 `ses_hGon6UOPBJyuQsxraMeZ`，[side-chat-created.json](side-chat-created.json) 保存独立 assistant 身份、metadata.sideChat.sourceSessionID 与两条 inherited reference messages。新侧聊请求的公开输入/响应保存在 [side-public-message-request.json](side-public-message-request.json) / [side-public-message-response.json](side-public-message-response.json)；不把公开 API 发起消息描述为同次通过 composer 键入发送的证据。

Root 明确报告这次 warm 卡仍为 summary 修复前形成/缓存的旧错误投影；保留 [原 warm 截图](observations/side-warm-permission-before-summary-fix.jpg)，不能将它记为修复后的新 warm Asked 通过。该保存图已经滚到权限 JSON 与按钮位置，摘要标题位于可见范围上方，不能仅凭文件名声称像素中完整显示了错误摘要。

Root 关闭并重新打开 Side chat 后，冷态重新取得同一待批准请求；[cold AX](observations/side-cold-restored-permission-en.ax.txt) 明确记录 `read (read_local)`，并保留 [cold 原图](observations/side-cold-restored-permission-en.jpg)。这是界面关闭/重开后的冷态恢复，不是浏览器网络自动重连或 Question 草稿重连验收。

Root 随后在真实 Side chat 权限卡点击 Allow Once。Permission `per_hOU6PDKwU37w6F09ZFtX` 的[公开历史](permission-history-after-side-allow.json) 依次保留 requested、allowed_once、execution_started、execution_succeeded。[side-messages-after-allow.json](side-messages-after-allow.json) 的 read Tool completed，实际 output 与 preview 为：

```text
item,quantity
Cedar402,3
Iris402,4
```

同一公开消息记录随后有 assistant finish=stop / `provider reply 2`；[conversation 公开快照](side-conversation-after-allow.json) 与[完成 AX](observations/side-read-completed-en.ax.txt) 保存该状态。因此真实 Allow Once→read→回复有数据与页面操作支持。

严格视觉边界：[完成截图](observations/side-read-completed-en.jpg) 可见完成 read、Input/Output 标题；输出内容当时在 composer 下方，被当前视口遮住。AX 与公开 output 包含三行，**不能宣称三行在此截图中全部可见**，也不能把它等同后来重新滚动取到的可见三行截图。本轮仍不是最终 warm summary 修复复验。

[page-closed.json](page-closed.json) 记录 tab 6 于 `2026-10-13T19:41:11.503Z` 关闭，早于 originalCloseBy；[terminal.json](terminal.json) 记录 owner PID 89556、occurrence `dcf44111-035b-44ec-a8ce-6abcc19f8ac7` 与 server/provider stopped；[closure-review.json](closure-review.json) 确认原 scope exit 0、originalOutputSettled=true、Native PID 已不在、outer runtime 已清理，以及 public-message exec 73059 已 join exit 0。

未用该轮证明 Deny 修复、Question/reconnect 草稿、Main child、多 pending、Task 完整闭环、双语或移动端。没有读取 Native Provider 原始载荷、用户 auth/models 或运行数据库。
