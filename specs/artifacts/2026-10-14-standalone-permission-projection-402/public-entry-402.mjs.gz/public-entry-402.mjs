import assert from 'node:assert/strict'
import fs from 'node:fs/promises'
import path from 'node:path'
import { randomUUID } from 'node:crypto'
import { fileURLToPath } from 'node:url'
const [root,mode]=process.argv.slice(2)
assert(root&&path.isAbsolute(root));assert.equal(path.dirname(path.resolve(root)),path.dirname(fileURLToPath(import.meta.url)))
assert(['child-one','child-two','child-one-resume','child-two-resume','side','task','observe'].includes(mode))
const json=async(name)=>JSON.parse(await fs.readFile(path.join(root,name),'utf8'))
const record=(name,value)=>fs.writeFile(path.join(root,name),JSON.stringify(value,null,2)+'\n',{flag:'wx'})
const ready=await json('ready.json'),base=new URL(ready.url).origin
assert.equal(ready.scenario,'side-read');assert(ready.closeBy>Date.now())
const directory=await fs.realpath(ready.session.directory),runtime=await fs.realpath(ready.runtime)
const relative=path.relative(runtime,directory);assert(relative&&!relative.startsWith('..')&&!path.isAbsolute(relative))
const api=async(route,method='GET',body)=>{
 assert(ready.closeBy>Date.now(),'Original close boundary')
 const response=await fetch(base+route,{method,headers:{'content-type':'application/json','x-opencorvus-directory':directory},...(body===undefined?{}:{body:JSON.stringify(body)}),signal:AbortSignal.timeout(Math.min(ready.closeBy-Date.now(),mode==='observe'?15000:180000))})
 return {status:response.status,result:await response.json(),observedAt:new Date().toISOString()}
}
try{
 if(mode.startsWith('child-')){
  const childName=mode.replace(/-resume$/,'')
  const create={kind:'assistant',parentID:ready.sessionID,title:`Public ${childName} permission`}
  let accepted
  if(mode.endsWith('-resume'))accepted=await json(`${childName}-created.json`)
  else {await record(`${childName}-create-request.json`,create);accepted=await api('/session','POST',create);await record(`${childName}-created.json`,accepted)}
  assert.equal(accepted.status,200);assert.equal(accepted.result.parentID,ready.sessionID);assert.equal(accepted.result.projectID,ready.session.projectID)
  assert.equal(path.resolve(accepted.result.directory),directory)
  const file=await fs.realpath(path.join(root,'public-external.csv'));const relativeFile=path.relative(directory,file);assert(relativeFile.startsWith('..')||path.isAbsolute(relativeFile))
  const body={messageID:`msg_${randomUUID()}`,agent:'chat',model:{providerID:`${childName}-fixture`,modelID:'session-prompt-owner-model'},parts:[{type:'text',text:`Read the public CSV at ${file} and report its rows in this child conversation.`}]}
  await record(`${childName}-message-request.json`,body)
  console.log(JSON.stringify({pendingRealChild:accepted.result.id,mode,originalCloseBy:ready.closeBy}))
  const response=await api(`/session/${accepted.result.id}/message`,'POST',body);await record(`${childName}-message-response.json`,response);assert.equal(response.status,200)
 }else if(mode==='side'){
  const sessions=await api('/session');await record('side-root-sessions.json',sessions)
  const side=sessions.result.find(item=>item.parentID===undefined&&item.metadata?.sideChat?.sourceSessionID===ready.sessionID)
  assert(side,'Real UI-created independent Side Chat root')
  assert.equal(side.projectID,ready.session.projectID);assert.equal(path.resolve(side.directory),directory)
  const file=await fs.realpath(path.join(root,'public-external.csv'))
  const body={messageID:`msg_${randomUUID()}`,agent:'chat',model:{providerID:'side-fixture',modelID:'session-prompt-owner-model'},parts:[{type:'text',text:`Read the public CSV at ${file} in this independent Side Chat and report its rows.`}]}
  await record('side-message-request.json',body)
  console.log(JSON.stringify({sideSessionID:side.id,sourceSessionID:ready.sessionID,originalCloseBy:ready.closeBy}))
  const response=await api(`/session/${side.id}/message`,'POST',body);await record('side-message-response.json',response);assert.equal(response.status,200)
 }else if(mode==='task'){
  const file=await fs.realpath(path.join(root,'public-external.csv'))
  const body={requestID:randomUUID(),title:'Public Task 402 permission',request:`Read the public CSV at ${file} and report its rows.`,productPillar:'work',promptProfile:'research-studio',model:'task-fixture/session-prompt-owner-model'}
  await record('task-create-request.json',body)
  const accepted=await api('/task?init-git=true','POST',body);await record('task-created.json',accepted)
  assert.equal(accepted.status,202);assert.equal(path.resolve(accepted.result.directory),directory)
  console.log(JSON.stringify({acceptedTask:accepted.result,originalCloseBy:ready.closeBy,boundary:'Real Task acceptance is not completed Task qualification'}))
 }else{
  const pending=await api('/permission'),parent=await api(`/session/${ready.sessionID}/conversation`)
  const observations={observedAt:new Date().toISOString(),pending,parent,closeBy:ready.closeBy}
  for(const name of ['child-one','child-two'])try{const created=await json(`${name}-created.json`);observations[name]={created,messages:await api(`/session/${created.result.id}/message`),conversation:await api(`/session/${created.result.id}/conversation`)}}catch(error){if(error.code!=='ENOENT')throw error}
  try{const accepted=await json('task-created.json');observations.task={accepted,board:await api(`/task/${accepted.result.task_id}/board`)}}catch(error){if(error.code!=='ENOENT')throw error}
  await record(`entries-observation-${Date.now()}.json`,observations)
  console.log(JSON.stringify({pending:pending.result.map(item=>({id:item.id,sessionID:item.sessionID,taskID:item.taskID,summary:item.summary,timeCreated:item.timeCreated})),parent:parent.result.pendingPermissions?.map(item=>({id:item.id,sessionID:item.sessionID,summary:item.summary})),task:observations.task?.board?.result?.interactions,remainingMs:ready.deadlineAt-Date.now()},null,2))
 }
}catch(error){await record(`public-entry-failure-${mode}-${Date.now()}.json`,{error:String(error),closeBy:ready.closeBy,boundary:'Failure does not settle original runtime owner'});throw error}
