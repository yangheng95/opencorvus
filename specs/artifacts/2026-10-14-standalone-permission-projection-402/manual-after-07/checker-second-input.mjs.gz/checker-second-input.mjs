import fs from 'node:fs/promises'
import path from 'node:path'
import assert from 'node:assert/strict'
const [root,mode='observe']=process.argv.slice(2)
assert(path.isAbsolute(root));assert.equal(path.dirname(path.resolve(root)),import.meta.dirname)
const ready=JSON.parse(await fs.readFile(path.join(root,'ready.json'),'utf8'))
assert(Date.now()<ready.closeBy)
const api=async(route)=>{const response=await fetch(new URL(route,ready.url),{headers:{'x-opencorvus-directory':ready.session.directory},signal:AbortSignal.timeout(15000)});assert.equal(response.status,200);return await response.json()}
const [messages,conversation,history]=await Promise.all(['/session/'+ready.sessionID+'/message','/session/'+ready.sessionID+'/conversation','/permission/history'].map(api))
const facts={observedAt:new Date().toISOString(),ready,messages,conversation,history}
await fs.writeFile(path.join(root,'public-facts-'+Date.now()+'.json'),JSON.stringify(facts,null,2),{flag:'wx'})
if(mode==='deny'){
 const requested=history.find(item=>item.session_id===ready.sessionID&&item.event_type==='requested'&&item.tool_name==='read')
 assert(requested,'Actual requested ledger binds read and original Session')
 const denied=history.find(item=>item.request_id===requested.request_id&&item.event_type==='denied')
 assert(denied,'Actual immutable ledger records user denial')
 const final=messages.findLast(item=>item.info.role==='assistant'&&item.info.finish==='stop'&&Number.isFinite(item.info.time.completed))
 assert(final,'Natural streaming assistant final reply completes')
 const errorTool=messages.flatMap(item=>item.parts).find(part=>part.type==='tool'&&part.tool==='read'&&part.state.status==='error')
 assert.equal(errorTool.state.error,'The operator denied this Tool call.')
 assert.deepEqual(conversation.pendingPermissions,[])
 console.log(JSON.stringify({denied,assistantID:final.info.id,finish:final.info.finish,reply:final.parts.filter(part=>part.type==='text').map(part=>part.text),toolError:errorTool.state.error,pendingPermissions:conversation.pendingPermissions},null,2))
}
