import fs from 'node:fs/promises'
import path from 'node:path'
import assert from 'node:assert/strict'
const [root, mode = 'observe', savedInput] = process.argv.slice(2)
assert(root && path.isAbsolute(root), 'An absolute owned scope is required')
assert.equal(path.dirname(path.resolve(root)), import.meta.dirname)
assert(['observe', 'deny', 'deny-saved'].includes(mode), 'Use an explicit supported observation mode')
const ready = JSON.parse(await fs.readFile(path.join(root, 'ready.json'), 'utf8'))
let facts
let factsPath
if (mode === 'deny-saved') {
  assert(savedInput && path.isAbsolute(savedInput), 'Offline verification requires the exact absolute saved input')
  assert.equal(path.dirname(path.resolve(savedInput)), path.resolve(root))
  assert.match(path.basename(savedInput), /^public-facts-\d+\.json$/)
  factsPath = savedInput
  facts = JSON.parse(await fs.readFile(factsPath, 'utf8'))
  assert.deepEqual(facts.ready, ready, 'Saved public observation belongs to this original owned scope')
  assert(Number.isFinite(Date.parse(facts.observedAt)), 'Saved observation has its actual timestamp')
  assert(Date.parse(facts.observedAt) < ready.closeBy, 'The original observation preceded its original close reserve')
} else {
  assert.equal(savedInput, undefined, 'Online observation does not accept saved facts')
  assert(Date.now() < ready.closeBy)
  const api = async (route) => {
    const response = await fetch(new URL(route, ready.url), {
      headers: { 'x-opencorvus-directory': ready.session.directory },
      signal: AbortSignal.timeout(15000),
    })
    assert.equal(response.status, 200)
    return await response.json()
  }
  const [messages, conversation, history] = await Promise.all([
    '/session/' + ready.sessionID + '/message',
    '/session/' + ready.sessionID + '/conversation',
    '/permission/history',
  ].map(api))
  facts = { observedAt: new Date().toISOString(), ready, messages, conversation, history }
  factsPath = path.join(root, 'public-facts-' + Date.now() + '.json')
  await fs.writeFile(factsPath, JSON.stringify(facts, null, 2), { flag: 'wx' })
}

if (mode === 'deny' || mode === 'deny-saved') {
  const { messages, conversation, history } = facts
  const start = JSON.parse(await fs.readFile(path.join(root, 'global-chat-start.json'), 'utf8'))
  assert.equal(start.status, 202)
  assert.equal(start.acceptance.session.id, ready.sessionID)
  assert.equal(start.acceptance.session.projectID, ready.session.projectID)
  assert.equal(start.acceptance.session.directory, ready.session.directory)
  const user = messages.find(item => item.info.id === start.acceptance.messageID)
  assert(user, 'Original accepted input is present in the real public transcript')
  assert.equal(user.info.role, 'user')
  assert.equal(user.info.sessionID, ready.sessionID)
  assert.equal(user.info.extra.wake_reason.requestID, start.acceptance.requestID)
  assert.equal(user.parts.filter(part => part.type === 'text').map(part => part.text).join('\n'), start.body.text)

  const requestedRows = history.filter(item =>
    item.session_id === ready.sessionID && item.project_id === ready.session.projectID &&
    item.event_type === 'requested' && item.tool_name === 'read')
  assert.equal(requestedRows.length, 1, 'One exact read invocation owns the canonical request')
  const requested = requestedRows[0]
  assert.equal(requested.mode, 'ask')
  assert.equal(requested.summary, 'read (read_local)')
  assert.deepEqual(requested.scope.resource.paths, [path.join(root, 'public-external.csv')])
  const deniedRows = history.filter(item => item.request_id === requested.request_id && item.event_type === 'denied')
  assert.equal(deniedRows.length, 1, 'The original requested row owns one persisted denial decision')
  const denied = deniedRows[0]
  assert.equal(denied.decision_slot, requested.request_id)
  assert.equal(denied.decision_scope, 'invocation')
  assert.equal(denied.actor_id, 'local-operator')
  assert(denied.time_created >= requested.time_created)

  const toolMessage = messages.find(item => item.info.id === requested.message_id)
  assert(toolMessage, 'The requested ledger binds an actual assistant Message')
  assert.equal(toolMessage.info.role, 'assistant')
  assert.equal(toolMessage.info.sessionID, ready.sessionID)
  assert.equal(toolMessage.info.parentID, user.info.id)
  assert.deepEqual(toolMessage.info.acceptedInputMessageIDs, [user.info.id])
  const errorTool = toolMessage.parts.find(part => part.type === 'tool' && part.callID === requested.tool_call_id)
  assert(errorTool, 'The exact requested call owns a real persisted Tool Part')
  assert.equal(errorTool.tool, 'read')
  assert.equal(errorTool.state.status, 'error')
  assert.equal(errorTool.state.failure.kind, 'tool-execution')
  assert.equal(errorTool.state.failure.originSite, 'session.processor.tool-error')
  assert.equal(errorTool.state.failure.message, 'The operator denied this Tool call.')
  assert.equal(errorTool.state.input.filePath, path.join(root, 'public-external.csv'))
  assert(errorTool.state.time.end >= denied.time_created)

  const final = messages.findLast(item => item.info.role === 'assistant' && item.info.parentID === user.info.id &&
    item.info.finish === 'stop' && Number.isFinite(item.info.time.completed))
  assert(final, 'A natural streamed final completes the exact original input')
  assert.equal(final.info.sessionID, ready.sessionID)
  assert.deepEqual(final.info.acceptedInputMessageIDs, [user.info.id])
  assert(final.info.time.created >= errorTool.state.time.end)
  assert(final.info.time.completed >= final.info.time.created)
  const reply = final.parts.filter(part => part.type === 'text').map(part => part.text)
  assert.deepEqual(reply, ['provider reply 2'])
  assert.equal(conversation.board.kind, 'session')
  assert.equal(conversation.board.sessionID, ready.sessionID)
  assert.equal(conversation.board.status, 'idle')
  assert.deepEqual(conversation.pendingPermissions, [])
  assert.deepEqual(conversation.transcript.find(item => item.info.id === final.info.id), final)

  const result = {
    verification: mode === 'deny-saved' ? 'offline-original-public-facts' : 'live-public-facts',
    input: factsPath,
    observedAt: facts.observedAt,
    checkedAt: new Date().toISOString(),
    sessionID: ready.sessionID,
    projectID: ready.session.projectID,
    inputMessageID: user.info.id,
    requestedLedgerID: requested.id,
    requestID: requested.request_id,
    summary: requested.summary,
    deniedLedgerID: denied.id,
    actorID: denied.actor_id,
    toolAssistantID: toolMessage.info.id,
    toolPartID: errorTool.id,
    toolCallID: errorTool.callID,
    toolFailure: errorTool.state.failure,
    finalAssistantID: final.info.id,
    finalFinish: final.info.finish,
    completedAt: final.info.time.completed,
    reply,
    conversationStatus: conversation.board.status,
    pendingPermissions: conversation.pendingPermissions,
    visualEvidence: 'Root performed and manually reviewed the real UI; this checker does not validate screenshots',
    providerEvidence: 'Controlled streaming fixture; no real GPT-6.1 Sol claim',
  }
  const resultPath = path.join(root, path.parse(factsPath).name + '.denial-check.json')
  await fs.writeFile(resultPath, JSON.stringify(result, null, 2) + '\n', { flag: 'wx' })
  console.log(JSON.stringify({ resultPath, ...result }, null, 2))
}
