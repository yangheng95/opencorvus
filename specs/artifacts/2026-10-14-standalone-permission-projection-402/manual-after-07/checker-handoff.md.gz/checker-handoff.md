# Original public-facts denial verification

Root performed the real final Main warm-page interaction: `read (read_local)` was visible, Dialog Reject produced the original Tool failure, the controlled Provider streamed `provider reply 2`, and the UI reached Not running. Root's original JPEG/AX/page-closed evidence remains separate. This checker only verifies the saved public API facts; it does not render or validate screenshots, access SQLite, start a service, or call a Provider.

The actual successful offline command is in `check-offline02.command.txt`, output in `check-offline02.log`, exit **0** in `check-offline02.exit`. Result: `public-facts-1791922789614.denial-check.json`. Input was the exact unchanged original `public-facts-1791922789614.json`, observed at 2026-10-13T20:19:49.612Z. The explicit `deny-saved` mode requires an absolute scope and exact snapshot path; it never falls back to HTTP. Online modes still require their original close reserve.

Verified exact chain:

- GlobalChat 202 acceptance and its request text -> user `msg_h4Q0tEKi4y2WPcMu1oF5`, Session `ses_hOWRsgzm92LR8DFjiG6z`, Project `prj_hQflBcoQF8dMi1SPTOg7`.
- Requested owner `per_g0VXxl5QT00qbHmJVkv3`, request `per_hCeJPTgFCv6yjixCeV93`, Ask/read/read_local and exact public file -> denied decision `per_g0VXxl8p500D0GXg8Te6` by local-operator. Denied rows carry sparse deltas; ownership is joined through `request_id`, not inferred from null decision-row Session fields.
- Tool assistant `msg_g0VXxkzos00himHRwa8a`, call `call_controlled_recovery_next`, Part `prt_g0VXxl5Oz00uQGBTZ13o`; actual `state.failure.message` is `The operator denied this Tool call.`
- Later natural assistant `msg_g0VXxl8tz00hcAQTXm01` accepts the same original input, finish stop, completed 1791922727369 and actual text `provider reply 2`.
- Conversation contains the exact original final fields/Parts plus its declared role projection, board idle and pendingPermissions `[]`.

All original input snapshots remain. `checker-initial-input.mjs` preserves Root's first erroneous camelCase ledger lookup. `checker-second-input.mjs` preserves Root's next version with corrected snake_case request linkage but obsolete `Tool.state.error`. The two original live command stderr logs were not present as files in this scope when inspected; Root's original tool-console failures remain their evidence. No reconstructed stderr is labelled original.

The first offline extension also had a checker-only failure, preserved in `check-offline.log/.exit` (exit 1) and `checker-offline01-input.mjs`: it assumed conversation transcript equals the raw Message object exactly. Source `conversation/transport.ts:134` and route session.ts:1149 deliberately enrich info with channel/resolvedRole/agentID/sessionAgentID/originSource. The corrected checker validates every original Message field and the complete Parts array, then validates those exact projection fields separately. `checker-final-input.mjs` is the successful version. No public facts or expected Tool denial/final reply were changed.

The Node checks ended within their initial tool results, with no background process. Original scope server/Provider physical closure is Root's `terminal.json` and adjacent physical-terminal receipt, not an offline checker claim. This controlled fixture is not GPT-6.1 Sol evidence.
