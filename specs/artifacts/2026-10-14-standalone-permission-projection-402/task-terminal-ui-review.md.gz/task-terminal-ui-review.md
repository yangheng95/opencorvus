# 402 Task terminal projection and child admission review

2026-10-14, read-only audit_ui follow-up requested by Root. Only this scratch report and the 402 spec may change. No production, test, SDK generation, service, browser, model, credential or Git mutation was performed. Existing 401 production work is frozen and Root owns its build/real UI.

## 1. Ledger projection is current, but an open Task needs an actual notification

`engine/store.ts:758–785` reads the winning `PermissionLedgerTable.decision_slot` whenever it projects a permission Interaction. `cancelled` and `stale` project to the existing Interaction status `rejected`, response `{decision:'deny'}`, and `time_resolved/time_updated` from that ledger row. This is an existing display projection; it does not mean a human denied it. An EngineInteractionOutcome row alongside the ledger decision is explicitly rejected as duplicate terminal authority.

`EngineInteraction.subscribe` currently observes Permission Asked/Replied only (`engine/interaction.ts:32–38`). Asked creates the one source-backed Interaction. Replied's `resolvePermission:352–365` only checks the already projected decision and optionally captures authored user evidence through `assertResolvedReplay`; it does not emit a Task refresh or append an outcome. Calling it for Terminated is semantically wrong, even if `userInput` is omitted.

The Session mirror is not a hidden Task bridge: `protocol/session-mirror.ts:255–292` normally dispatches only assistant/mission Session events as `aggregate:'session'`; the special root/config path is unrelated. The selected Task SSE subscribes to `aggregate:'task', taskID` (`server/routes/orchestrator.ts:615–646`). Thus adding Terminated only to Session stream/Main/SideChat cannot update an already visible Task permission card.

Existing mature Task notification route is:

`task-scoped interaction.resolved → task SSE → tree-writer.handleInteraction (reproject current board) → event-policy interaction.* invalidation → events.handleEventStreamEvent → scheduleBoard → current GET /task/:id/board → listInteractions → ledger projection`.

Evidence: tree-writer 888/2078, event-policy 127–131, events 402/525, board.loadBoard 339–417, workbench/board 56–78. `handleInteraction` alone reprojects the old board; the subsequent board fetch is essential. Existing authority/selectEpoch ownership in loadBoard rejects old-source HTTP responses.

## 2. Minimal Task consumer, without another terminal writer

Add one dedicated Terminated subscriber in `engine/interaction.ts`, alongside existing Permission subscribers, using the Bus durable occurrence contract. The handler must:

1. Read `ledgerEventID` and its immutable requested fact, validate request/session/project/status and the actual winning `decision_slot`. The terminal ledger row does not duplicate all owner fields, so project/session validation uses its referenced requested fact, not absent terminal columns.
2. Resolve the existing permission Interaction by external request ID. Ordinary standalone requests have no such Interaction and need no Task notification. If it exists, validate its permission type/session and Task Project, and use its existing projected `rejected` status/time. This must not insert a missing Task Interaction or fabricate ownership.
3. Use the existing `ProtocolStore.dispatchEphemeral` to emit `interaction.resolved` for that actual Task and interaction. The event is a projection invalidation from the real ledger, not a new decision record. Include the real terminal ledger identity/status in diagnostic metadata only if the existing event payload contract permits it; do not invent `userInput`. Derive its order key from the immutable terminal fact/time, not a synthetic user reply. The normal Interaction status payload can be `rejected`, because that is exactly the current store projection; its summary should say permission terminated/cancelled/stale rather than operator rejected.
4. Preserve Replied/userInput and the existing Permission release/resume contract. Do not call resolvePermission, resolveEngineInteractionRequest, write EngineInteractionOutcome, update EngineTask status/time, or enqueue a fake Task message to force repaint.

Why ephemeral is appropriate: `protocol/store.ts:738–790` already documents this primitive for events whose authority lives elsewhere, supplies a real task liveSequence/liveEpoch and replay buffer, and Task SSE accepts it. Re-delivery can issue another harmless invalidation without duplicating terminal state. Cold/restart Task load rereads the same ledger. This does not require a new persisted protocol decision or another permission table. Session mirror and this Task observer are distinct projections of one owned ledger event.

The handler is only a display notification; it must not claim to fix ordinary Session Stop cancellation or Task scheduler transitions. Actual waiter rejection/control progress stay on the original Authority paths. If tests reveal a controller edge failure, audit it separately using real occurrence facts rather than adding a status write here.

## 3. Necessary Board cache edge to review before claiming Task closure

`workbench/board.ts:391–398,426–447` stamps interactions with only row count and maximum `time_updated`. The server returns 304 solely on this tag (`routes/orchestrator.ts:1310–1318`), and loadBoard sends its current If-None-Match. A pending→rejected decision committed in the same millisecond as the request can have identical count/max-time; the actual permission state has changed while the old ETag remains valid by current code. No runtime reproduction was performed here; this is a concrete same-input arithmetic consequence of the source.

An ephemeral notification or even a new durable interaction event does not itself alter this tag: latestTaskProtocolSequence is used in board payload but omitted from boardTag, and publishing a protocol event does not update the Task. Do not silently rely on time advancing or force Task status/time.

Proposed bounded addition to `workbench/board.ts`: retain current count/max-time and append counts for the actual projected Interaction statuses (`pending`, `answered`, `rejected`, `expired`) to the interaction tag. A real terminal transition necessarily changes those counts even at equal milliseconds. This is a compact version of the existing data projection, not a hash of mutable source or a shadow state. It improves the touched shared Interaction terminal contract, including Question, without changing records. A backend conditional-GET case with same-ms request/decision should establish 200 + current rejected interaction + exact ledger resolution time. Root must approve this extra production file; it is not yet implemented.

Do not expand this into arbitrary Board caching redesign or promise all other same-ms board domains are fixed.

## 4. Real child Session admission and the missing non-Task predicate

No current production function named/serving a shared nonTask interaction predicate was found. Existing pieces are:

- `sessionLineageIdentity` (`engine/task-session-lineage.ts:36`) reads the durable ancestor chain and rejects cycles, broken parents and cross-project corruption.
- `taskIDForSession:131` finds the real Task owner through ancestors.
- `includeSessionTreeEvent` (`server/routes/session.ts:120–135`) checks the selected ancestor and Project, and learns child IDs from durable lineage; it does not exclude Task ownership.
- hydrate uses `Session.treeInProject` (route 172–175), but pendingQuestions currently only filters tree membership (1107), and replay pending question/permission filters only that set (1340–1344).
- Main `isSelectedStandaloneSession`/handleStandaloneQuestion (tree-writer 2084/2161) uses root equality or a known Mission session exception. That is not a valid child/tree admission contract and cannot be copied for Permission.

Smallest shared producer predicate belongs in existing `engine/task-session-lineage.ts`: for a supplied expected Project, a real Session has matching durable lineage and `taskIDForSession(sessionID) === undefined`. Missing/foreign leaves are false; broken/cross-project lineage retains the existing explicit error. No role-name heuristics, request-name parsing or frontend Map membership.

Use that one predicate for pending Question/Permission hydration and replay in `server/routes/session.ts`, and for Question/Permission event admission in `protocol/session-mirror.ts` before Session dispatch. Keep generic transcript/agent lifecycle tree handling unchanged. Permission additionally validates its canonical Request.projectID and absence of its authoritative Task owner; an inconsistent claimed taskID versus durable lineage is an explicit integrity error, not a guessed fallback. Task-owned interactions continue through EngineInteraction/board exactly once.

Main live handler may then accept the current authority-owned Session stream's admitted child interactions. It still requires selected source.kind=session and current SSE generation/ApiAuthority; terminal removals remain exact request ID. It must not require the child to have arrived in frontend sessions Map first. Question uses this same entry predicate, while preserving answered/rejected cards and draft behavior. SideChat remains exact target session in live and snapshot.

Concrete natural child producer: `tool/delegate-agent.ts:124–129` creates `kind:'assistant', parentID:parent.id` under conversation execution, so child Permission is genuinely reachable and should be admitted. That same tool explicitly disables `question` (line28); it is not evidence that its child can naturally prompt a Question. A backend lawful child Session/Question contract can use the real Question API and durable parent identity, but must not claim an actual delegate Question UI sample occurred. The current bridge's assistant/mission role scope covers this actual local child kind; no need to extend all worker roles to Session streams.

## 5. Exact implementation allowlist proposal

Backend required files:

1. `packages/opencorvus/src/permission/types.ts` (new single schema module, remove moved definitions at source).
2. `packages/opencorvus/src/permission/invocation.ts` (ProviderKind re-export from the same schema).
3. `packages/opencorvus/src/permission/authority.ts` (Request re-export; one decision writer; Terminated schema/owned outbox publication).
4. `packages/opencorvus/src/engine/model.ts` (required pendingPermissions in both public snapshots, same Request schema; Session protocol enum).
5. `packages/opencorvus/src/engine/task-session-lineage.ts` (shared non-Task interaction admission).
6. `packages/opencorvus/src/protocol/session-mirror.ts` (same request orderKey, terminal mapping, non-Task interaction admission).
7. `packages/opencorvus/src/server/routes/session.ts` (hydrate/connected current arrays, tree/Project admission and same snapshot cutover).
8. `packages/opencorvus/src/engine/interaction.ts` (Task terminal invalidation observer only).
9. `packages/opencorvus/src/workbench/board.ts` (proposed bounded Interaction status counts in ETag; needs Root acceptance).

Frontend required files:

10. `packages/overlay/src/services/tree-writer.ts` (one existing standalone Map, shared Question/Permission admission, pending permission upsert/remove/replace).
11. `packages/overlay/src/services/conversation.ts` (same prepare/commit snapshot contract; connected only replaces Permission items).
12. `packages/overlay/src/services/side-chat.ts` (consume new connected snapshot and same Permission normalizer, exact Session).
13. `packages/overlay/src/services/event-policy.ts` (Terminated known/projected event).
14. `packages/overlay/src/components/InteractionCard.tsx` (one source-aware default afterReply for inline and Dialog; preserve explicit SideChat callback).
15. One new shared helper `packages/overlay/src/utils/permission-interaction.ts` for the already duplicated Main/SideChat Request→InteractionData conversion. This is a single implementation imported by both, not a separate pending queue; if Root elects an already suitable shared module, use that one instead, without two implementations.

Existing `CardParts.tsx`, `InteractionDialogHost.tsx`, `interaction-reply.ts`, routes/permission, Settings, task reducer, Task status schema, ProtocolStore, Bus, CLI and ACP should not need production edits for this design. `events.ts` already handles task interaction.* invalidation. No patch/package dependency change is required.

Expected tracked generated changes: `packages/sdk/openapi.json` and `packages/sdk/js/src/gen/types.gen.ts`. New response properties/Event union normally require no SDK method-route implementation change; actual generator output decides. Do not manually patch those outputs or blanket-authorize unrelated generator drift.

SDK transaction is `packages/sdk/js/script/build.ts` invoked by that package's build script: generate-openapi under source conditions; generate client in `.tmp-sdk-build`; preserve stream-cancel/required-body adjustments; format; tsc; only then `replaceGeneratedArtifactsAfterSuccessfulBuild`. Its full six publication targets are `js/dist`, `js/src/gen`, `js/src/defaults.ts`, `js/src/route-policy.ts`, `js/src/platform-artifact-tool-ids.ts`, and `openapi.json` relative to `packages/sdk`. Whole transaction must run even if only two tracked files change; do not call its internals for partial copy. Existing generation-transaction implementation need not change. No SDK build was run by this audit.

Relevant positive backend files: `packages/opencorvus/test/permission-two-mode.test.ts`, `permission-transport-hydration.test.ts`, `engine-interaction-recovery.test.ts`, `server/session-event-connection-snapshot.test.ts`; add a focused backend Task Board conditional-GET case in an appropriate existing server/workbench suite if no direct suite exists. These are proposed test edits for Root's approved implementation, not changes made by this audit. Do not add/modify/run overlay component/DOM/source-text/UI tests.

## 6. Positive backend acceptance, with actual public paths

- Real pending Request → cold GET and connected snapshot expose the same ID/Session/timeCreated/interaction orderKey; warm Asked produces that same canonical order key. Same Request delivered by overlap upserts one identity.
- True non-Task child in the selected ancestor/Project yields Question/Permission snapshots and live events; actual Task-owned Request remains represented by its one original Task Interaction. Foreign Project/sibling requests produce the explicitly scoped collection; corrupt lineage yields its current explicit error contract.
- True cancelled/stale decision winner atomically owns Terminated outbox; payload uses that ledger's ID and status. Retry/concurrent paths converge to the actual same ledger decision. Retirement-only stale of an already approved continuation retains its separate meaning.
- Existing Task permission + real terminal ledger → actual Task SSE interaction invalidation + GET board's current rejected state, exact ledger time and original interaction ID. Conditional GET with a same-ms decision returns changed current data under the corrected tag. Permission authority remains the same ledger, and user memory evidence comes only from real Replied inputs.
- Stream snapshot/read/buffer races expose the current collection and preserve an event after the snapshot. Connected replacement removes offline-terminal Permission while preserving independent Questions. No secondary HTTP permissions fetch is introduced.
- Actual allow_once/deny still use original HTTP reply and userInput publication, with original tool execution/error outputs. Terminated does not imply user rejection or a synthetic Session message. Ordinary Stop remains outside this cancellation policy.
- SDK generated required arrays and event union compile through the real transaction, then relevant backend/SDK/overlay type checks and Root's actual desktop interaction follow. Static inspection here proves call paths only; UI/model qualification remains unperformed.

## 7. Outstanding limits

Root must choose/approve the Board tag addition and exact shared helper location before implementation. No real Task terminal SSE, same-ms HTTP or child Question UI run was performed. Actual ordinary Stop lifecycle, all Task controller behavior, all Mission/Work/SideChat permutations and cross-project concurrency cannot be declared verified from this review. Root's live/model scope and physical closure remain separately required.
