# Read-only Task / SideChat / nonTask child entry preparation

No services, model requests, credentials, UI, tests or product changes by this audit. Preserved when Root redirected work to actual Main denial failure. References inspected at current 402 working tree; APIs below are source contracts, not a claim that the scenario ran.

## Normal Task

- `engine/model.ts:164-207` CreateTaskInput requires request, productPillar and promptProfile. Legal product pillar for this task is work. model is `provider/model`; title/requestID optional. Budget, if used, only has `maxExecutorGroups`, not fabricated request/time/token fields.
- Public `POST /task` in server/routes/orchestrator.ts:186 validates this schema and invokes real creator `{actor:'user'}`. Return 202 is `{task_id,project_id,directory}`. Owned empty directory initialization follows the normal `init-git=true` admission; use actual returned owner thereafter.
- Minimal body: `{requestID:<fresh UUID>,title:'Public Task permission',request:'Read the public CSV at <owned external absolute path> and report rows.',productPillar:'work',promptProfile:'base',model:'shutdown-fixture/session-prompt-owner-model'}` with exact own directory header. Keep normal Ask config and file outside that Task's own directory.
- task-api/index.ts:1922 creation -> actual root Session (~2015) -> persist Task/creator authority -> requestAcceptedTaskReconciliation:1645. Normal Orchestrator/controller creates actual tool call and Permission, with Task lineage producing one Task interaction.
- `installProcessShims` declares actual native deployment (runtime/shims.ts:40); existing owned manual harness already installs it. Do not create fake task/process binding.
- UI can select the real Work ledger Task. Pending/decision/tool evidence can be examined via real board/interactions/Permission data. Current simple controlled Provider's text reply may not supply the Task-root control decision; do not promise completed Task or force status. Real pending interaction and normally stopped owner are a narrower truthful scenario.

## NonTask child versus SideChat

1. A natural nonTask parent can be made by normal GlobalChat start (Root's mature harness). Public `POST /session` accepts `{kind:'assistant',parentID:<known nonTask parent>,title:'Public child permission'}` under its actual directory. Session.create schema index.ts:373 and prepareNext:624 check real lineage. It creates a user/API child, not proof delegate_agent ran.
2. Then normal `POST /session/:child/message` with fresh stable messageID, agent chat, explicit legal model and text requesting own external public CSV. Parent Session stream can project the child's actual Permission through durable nonTask tree. Do not inject metadata or fake Tool parts.
3. Actual `delegate_agent` (tool/delegate-agent.ts:172) creates its own assistant child/metadata and forwards parent exact model. A real parent delegate tool followed by child read requires two model Tool steps; the existing first-step-only fixture cannot simulate both naturally. Use an already-authorized script-capable Provider fixture or actual model if separately approved, not host tool-selection gate.
4. Public `POST /session/:source/side-chat` (session route:1862-1880) requires no body, verifies source project and uses Session.fork purpose side-chat. The product sets metadata and returns actual Session.Info. This **sets parentID undefined** and kind assistant: it is independent root, not a child-tree example. It can originate from a Task source without inheriting Task ownership.
5. SideChatPanel.tsx:320 itself uses normal Session message agent chat. Helper may explicitly choose a valid controlled Provider model in that same public message schema. Never write side-chat metadata manually. Ordinary `/fork` keeps parentID but rejects Task-bound source; SideChat has its explicit distinct contract.

## Mature controlled Provider limitation and useful composition

`test/fixture/controlled-streaming-provider.ts` emits the configured firstPromptToolCall only for its first non-memory prompt. Memory classification is exact MEMORY_PROMPT + request-language (or explicit memory model), and later prompt requests emit plain text. It exposes real requests and caller-controlled release; abort releases held requests. No change to this test fixture is proposed.

If a navigable parent first model turn consumes this only Tool step, do not falsely assume a later child/SideChat call will read. Root can use two independent controlled Provider instances: A creates the normal parent with a plain answer; B's first legal explicit-model child/side-chat message makes actual read. Both ordinary exact models must be publicly configured, own bounded owner/close handles and no credentials. This is controlled streaming evidence, not real Sol or true delegate-agent evidence. Root chooses final scope; no helper was changed or started here.
