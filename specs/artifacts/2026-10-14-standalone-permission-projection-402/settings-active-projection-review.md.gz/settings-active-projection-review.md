# Settings active projection: read-only review and no-Browser Task candidates

Inspected 2026-10-14 for Root's ongoing 402 acceptance. This report is the only new file. No production, fixture, test, shared documentation, configuration, runtime process, model, credential or browser changes. No tests or services were started. Root owns actual scope closure and later candidate execution.

## Recall and actual input

Root observed two HTTP 500 responses before selecting the actual GlobalChat in `manual-after-05`: `GET /skill/mounts` and `GET /expert-squad/catalog`. The request directory is the owned scratch `manual-after-05/project`, not the separately allocated GlobalChat project.

- `manual-after-05/ready.json`: PID 88776, physical occurrence `8676231e-405a-44ee-9140-5c8671c72280`, port 55138, original deadline 1791922568331, closeBy 1791922508331. No extension is proposed.
- Default owned Project in log: `prj_h6etWe5hEebkpNUOrzEw`.
- Actual GlobalChat Session `ses_h0HqI9SeJmMhifR0XWa3`, Project `prj_hLaqo4hkNtY4AQtDDmUa`, allocated under the owned runtime. Its real metadata configOverlay contains active `base`, matching Root's observed effective profile.
- `manual-after-05/public-global-config.json` is HTTP 200 and shows configured `prompt_profile.active=base`, `permission_mode=ask`, and both `mcp.browser.enabled=false` / `mcp.computer.enabled=false`. The only model is the explicit public controlled streaming fixture. This is not a missing real Provider credential.
- `.tmp-native-shutdown-pending-permission-403/phase-b-input.ts:4-10` is the shared public fixture constructor and explicitly authors that same Base plus disabled-MCP combination.
- `manual-after-05.stderr.log:309/311` has exact error `Active expert squad projects default MCP server default/mcp/browser, which configuration has disabled.` First request ID `baa87b6d-0cc4-4a9e-bff0-9f3e3db42f63`; second `1dfd4627-a5d0-4db7-b634-78c40ba56fdc`. These are the actual server errors, not inference from an English error name.

## Conclusion

The currently configured **active Base package** declares Browser MCP capabilities. The fixture explicitly disables the provider required by those declarations. This configuration is accepted for the native Chat contract but cannot describe a complete Base Task/scheduler/worker projection. The two reads request that active projection and fail for the same reason. They are not attempting to execute an unrelated inactive package. Normal Chat admission does not prove Base Task readiness.

Do not silently enable Browser, substitute a builtin provider, edit Base's manifest, change the profile implicitly, or weaken projection checks to make this scope pass. Keep the original 500 and the native-Chat-only acceptance boundary. A later product issue may improve how Settings exposes an unavailable active projection; this audit does not establish a requirement to return a partial catalog or introduce a fallback.

## Exact definitions and callers

1. `agent/prompt-profile.ts:28-35` `PromptProfile.activeID` returns the materialized config active identity. It does not select an available alternative.
2. `expert-squad/prompt-profile-resolver.ts:680-724` `packageForActiveProfile` uses an explicit pinned revision if supplied; otherwise `PromptProfile.activeID(input.config)` and the matching builtin/external package. No iteration over all inactive packages occurs here.
3. `expert-squad/builtin/base/expert-squad.jsonc:19-40` declares its shared set with seventeen `default/mcp/browser/tool/...` refs. Scheduler at :46-48 selects that set; Developer at :102-104 and Tester at :112-114 select it too. Thus Base itself is sufficient to explain the reported scheduler failure.
4. `defaultMcpServersForRefs` at resolver :1112-1134 looks up the exact server named by each selected ref. Missing config is an error. Computer uses its existing enabled-declaration parser; a shorthand disabled declaration without a `type` causes the exact observed throw at :1128. It never starts Browser at this point.
5. Entire production same-semantic call set: scheduler resolution :1433 and worker resolution :1652. Both feed `resolvePackageCapabilitySet` :1765-1779, which resolves the selected scheduler, every selected package worker and universal Build. This is shared active capability materialization, not a Settings-only guard.
6. `server/routes/expert-squad.ts:468-474` publicly describes `/catalog` as **only the active runtime projection**, with bounded search/exact inspection for inactive packages and creation-time pinning for Tasks. `resolvedCatalog` :305-330 reads current Project Config when no sessionID; with sessionID it validates the project and uses the real Session effective config / pinned Task package revision.
7. `PromptProfileResolver.catalog` :3361-3385 first resolves exactly that active package, builds one context, then resolves the active capability set. `resolveSkillProjectionForContext` gets that same set; inactive selector packages are only considered later as declaration/selector entries. The observed failure happens before that later stage.
8. `server/routes/skill.ts:42-72` `/mounts` calls `SkillMount.matrix`. `skill/mounts.ts:449-476` derives active identity from effective config or a pinned Task revision. In project scope an explicit `expertSquadID` can intentionally request another projection; this request had none. The matrix calls `resolveSkillProjection`, whose :2566 path needs that selected package's complete capabilities before assembling per-agent skills.

## Native Chat, config and declaration-read contracts differ

- `config/config.ts:754-766` materializes builtin Browser/Computer declarations only when the named entries are absent. An explicit `{enabled:false}` is preserved. Removing it to inherit an enabled builtin is a capability/configuration change, not a read-only fix.
- `mcp/browser/builtin.ts:91-105` explicitly recognizes both shorthand and typed enabled:false Browser declarations as disabled. `Config.Info` accepts the supported disable declaration.
- Native conversation scope `mcp/host-session-runtime.ts:151-156` returns no runtime scope when missing/disabled, and repeats the canonical Browser interpretation before creating its owner. `test/mcp/browser-configured-declaration.test.ts:32-59` has a positive disabled-declaration and assigned-disabled empty-Conversation projection contract. It was read, not run here.
- Therefore Chat using platform read can be a valid controlled test while Base's complete package projection is unavailable. The model's permitted native read does not need Browser, and the later actual permission/read flow remains a separate scope fact.
- `/expert-squad/search` returns bounded declaration entries; `/inspect` and `/settings/detail` read exact package declarations, not a complete active runtime projection. Source routes :495, :528 and :599, resolver `catalogInspection` :3158 and `settingsDetail` :3298 support this distinction. These are existing distinct public products, not suggested fallbacks for failed `/catalog`.
- Long-form `{type:'local', ..., enabled:false}` must not be used to evade the observed shorthand guard. The current helper's generic branch tests presence of type, while native scope tests enabled too; uniform handling of all projected disabled forms is a separate unexecuted boundary. It is not authorization to bypass provider-off intent.

## History, effect and 402 causality

- Retained baseline `65d0bfc98` already required named default MCP declarations.
- Commit `702e030d4` (2026-08-26) explicitly deleted the old substitution of Computer's builtin localConfig and added the disabled-declaration error. Its diff states that projection must report the configured provider, not substitute one.
- `c6e1569e88` then used Computer's dedicated enabled configured declaration parser.
- `specs/records/2026-08/2026-08-25-architecture-debt-remediation.md:780` records the same decision: default configuration materializes the provider it runs; native conversation preserves explicit disable; Expert-Squad projection rejects a reference to a disabled configured provider instead of substituting one.
- The active-only catalog description is current, not an inference from naming. Later bounded inactive discovery/inspection is intentionally separate.
- Current diffs for resolver, Base manifest, SkillMount, both read routes and host-session runtime are empty. 402 touched permission projection/reply continuation and one unrelated experimental config field. No permission request, decision, processor or denied Tool path appears in either actual 500 stack. These errors can affect the Settings skill/active-package panels and composer references for any similarly configured Project/Session, and would also block a real selected Base Task projection. They do not establish a new queue, recovery or termination defect.
- The fixture's empty model catalog also logs unrelated provider availability diagnostics. Those messages are not the cause of these exact two 500 responses and are not evidence of missing user credentials.

## No-Browser candidate 1: current embedded Research Studio

This is the best existing package candidate for a public CSV evidence/permission Task. It is a **static candidate, not a completed test**.

- `expert-squad/builtin/research-studio/expert-squad.jsonc:4` identity `research-studio`, version `2026.10.12.1`; product_pillars at :9 permit both code and work.
- Scheduler :28-36 explicitly grants `orchestrator-base`, `scheduler-transport`, platform `read`, `dispatch_agent` and `browser_preview_capture`. The latter is a platform tool declaration, not Browser MCP; merely projecting it does not require enabling `mcp.browser` or opening a browser. The intended test calls only ordinary read through the real model/Tool surface.
- All manifest workers refer to platform base sets and declared skills; there are no default MCP refs or package MCP declarations. Do not rely on a string-absence check alone: `agent/platform-capability-sets.ts:17-35` constructs members as `kind:'tool', source:'platform'`; the complete definitions at :50-87 contain platform tool IDs, not hidden MCP leaves. Resolver universalBuild at :518-524 is only the same platform build-base reference.
- `expert-squad/builtin/index.ts:37-48` imports this exact embedded manifest and resources. It is a current builtin, so no installation, renamed mirror, raw manifest edit or user filesystem package is necessary.
- It does require its declared package/default skills (including `design-taste-frontend` for Writer). Their availability must be checked through the existing full projection using the owned normal configuration before claiming Task readiness; this audit did not execute that preflight.
- Normal Task selection can remain explicit and isolated: `POST /task` with `productPillar:'work'`, `promptProfile:'research-studio'`, the public fixture model, stable new requestID and natural request to inspect the owned external public CSV. `task-api/index.ts:1527-1563` merges the explicitly selected profile into a **creation preview** and pins that exact revision; it does not rewrite global Base. Use real returned Task/Project/directory and normal lifecycle/Permission endpoints. No direct DB insertion or fake Task/message.
- Global Base may still make the default Project Settings `/catalog` unavailable; selecting a different Task package is not a repair of that separate default projection. Task-session scoped catalog uses the actual pinned package as designed.
- The mature `test/fixture/controlled-streaming-provider.ts` supports one first-prompt Tool call, then real streamed text. With a fresh independent provider its first call can be ordinary `read` already present in the selected scheduler projection. It can prove a real Task waiting on a real Permission and actual decision/Tool evidence. Its generic subsequent text may fail to produce the necessary Task-root decision control. Do not claim completed Task, teach a gate to emit workflow tools, or stamp completion. Full Task completion requires separately reviewed natural provider behavior and canonical control receipts.

Base, Advanced and Dynamic are unsuitable no-Browser substitutes: Advanced workers and Dynamic Builder still explicitly require Browser, and the resolver resolves the full worker set. Choosing only their scheduler names does not remove that requirement.

## No-Browser candidate 2: canonical SDK-owned minimal fixture package

If Root wants a narrower controlled Task package than Research Studio, the current reusable primitive is the public SDK `writeExpertSquadPackage`, followed by normal package validation/import and explicit Task selection. Existing legal schema-2 fixture shapes are `test/expert-squad/catalog-index.test.ts:28-56` (`scalePackageDefinition`) and `test/expert-squad/builtin-collision-authority.test.ts:32-59` (`definition`). They provide a declared orchestrator projection, empty package capability sets/workers/workflows, README and selector files without MCP.

Those fixtures are declaration/collision tests, **not ready-made read Task end-to-end cases**: their scheduler refs are empty. A separately approved owned package must explicitly declare the actual ordinary read and necessary current scheduler/control transport capabilities via that same SDK. Then public `/expert-squad/import-folder` (:1159-1190), using `sourceDirectory` and `installationScope:'project'`, produces the normal validation/installation receipt. No copying an invalid runtime fixture, hidden capability patch or fake Task registration is appropriate.

Research Studio needs fewer new moving parts and is the recommended next scope candidate. `squad-sdk` also has no Browser MCP but its declared purpose is creating/importing expert packages, so it is not recommended merely to test a CSV read. No package was created, installed or selected by this audit.

## Separate manual-after-06 runtime export observation

Root interrupted this report with a fresh scope's HTTP 500 SyntaxError for `ProviderConnectionTestResult`. This is independent of the active Base/MCP mismatch:

- `manual-after-06/ready.json`: actual PID 89100, occurrence `add89c9a-93a2-44bb-a4d3-a67670281e0e`, startedAt 1791922596964 (20:16:36.964Z), port 55960.
- stderr :208 onward at 20:16:52Z reports the missing runtime export across Work ledger, events, mailbox and other routes.
- Current disk `provider/operations.ts:26-37` contains **export const** Zod schema plus a same-name TypeScript type. Current `server/routes/provider.ts:8/:297` and `global.ts:21/:881` import and use that actual schema value in route resolvers. They cannot be fixed with `import type`.
- All three are currently dirty peer files, with LastWriteTimeUtc 20:16:43Z. `git show HEAD` for all three confirms the committed versions are mutually consistent: neither operation export nor route import exists. `2494f5da5` contains Overlay/provider observation work, not these backend files. My earlier provisional message that HEAD was broken was withdrawn after reading the actual HEAD route sources; no action was based on it.
- The source timestamps after process startup and before the failure are consistent with a cached old operations module plus newly loaded route source during concurrent writes. Exact module evaluation order/author remains to be confirmed by Root/peer; timestamps alone are not proof. This is not proof that current stable disk source still fails, and no fresh import/process check was run here.
- Minimal next action is coordination with the owner of the three backend changes, preserving their complete schema/response contract, then a new bounded scope after the source is stable and verified. Do not duplicate the schema in each route, erase its runtime import, overwrite peer work, or claim an existing process will heal from edited disk. Preserve scope06 failure and its original physical close separately.

## Follow-up: actual manual-after-08 Task and shared boundary audit

This section records the later original `manual-after-08/entries-observation-1791923085819.json`, `task-create-request.json`, `task-created.json`, `terminal.json`, and adjacent actual stderr. No service/checker/Provider/UI was run for this read-only follow-up. Root separately performed the screenshots and manual visual review.

### Actual positive boundaries and remaining failure

- Public Task 202 accepted `tsk_g00VXxmQGn003mlBGdsM`, Project `prj_h1vZ7H8U1sv4ocr8Xsbs`, exact allocated C: runtime directory ending `e09c4484-72b8-41fa-ba4c-075216766262`. Request selected `research-studio`, work, task-fixture/session-prompt-owner-model. Board has the actual pinned built_in research-studio revision `2026.10.12.1` and native process binding. This proves the no-Browser candidate was actually admitted without changing global Base.
- Board HTTP 200 has one Permission Interaction `int_g0VXxmR9r00NnSlnaLgZ`, external Request `per_hXAZOTTXMHNNjqfHIExC`, Orchestrator Session `ses_-zUS2DZ7dzztui3y5IXU`. It is answered with the actual `allow_once` response and created/resolved times 1791923034525 / 1791923069196. Root saw the normal Task-scoped choices and used Allow once. This is permission projection/decision evidence, not successful file access.
- The actual input path is the owned D: scratch `manual-after-08/public-external.csv`, outside that Task's declared C: process root. Artifact `art_g0VXxmag100nE4sR3KBP` retains the exact read occurrence (assistant `msg_ht6fBbqekGzmCU5vI3xA`, Part `prt_g0VXxmR9Y00nYL5asmOg`, call `call_controlled_recovery_next`) and `TaskProcessBoundaryError` with both actual paths. No file output is claimed.
- Task remains **active, opened epoch 1**, while its latest execution occurrence is **idle** (Protocol sequence 16). `Not running` means the physical occurrence stopped, not business Task completion.
- Canonical `task_root_ingress_disposition` artifact `art_hhAb9Oq9iClhR7C2OEaX` is **exhausted**, bound to ingress `art_hSk4zPOCWQokGR9ijHsz` / epoch 1. Infrastructure fact `art_hvoxe3Ah41vSx31QJ2ve` reports `semantic_limit`; the original artifact says a new explicit operator input or Task retry is the exit. No completed/cancelled Task lifecycle was inferred.
- Original terminal receipt reports four actual task-fixture prompt requests, all stream:true. Its original controlled fixture has one first read call, then `provider reply 2/3/4`; Root saw the actual later text. No real Task decision Tool is produced by that fixture after read. This is not a model-derived workflow verdict.

### Why operator approval does not change the structural Task root

`tool/task-tool-invocation.ts:35-68` first calls the shared `PermissionAuthority.authorizeAndExecute` with the exact Project/Session/Message/call/Part. After approval it executes the ordinary Tool under that authority. The decision authorizes the operation attempt; it does not rewrite Task process identity or filesystem root.

`ReadTool` (`tool/read.ts:61-83`) resolves the actual path and calls `assertExternalDirectory` before reading content. The only producer of the observed message is `tool/external-directory.ts:21-29`. Its :76-88 path requires the real Tool execution authority, looks up that Task's native/capsule binding, resolves both target and root through actual ancestors/realpath, and enforces `Filesystem.contains(root,candidate)`. The Task branch precedes the optional conversation bypass flag; approval does not disable it.

The complete direct callers are read, write, edit, apply_patch (original and moved path), glob, grep and ls. `executionFiles` separately selects the Task file host from explicit execution authority; process operations likewise use explicit Task process authority. Native and capsule use their respective real declared workspace root, not a guessed Session directory or caller-provided taskID. `session/loop.ts:279-289` resolves actual Session authority against the projected runtime identity; its extra metadata explicitly drops an untrusted taskID.

This affects every Task root/worker/Task descendant, including Tasks created by a Mission; it is not Research-Studio-specific. A standalone Mission or conversation follows its own conversation authority. Real nonTask child and independent SideChat therefore have different filesystem structural ownership despite sharing the same operator Permission mechanism. No universal approval bypass should be inferred.

History confirms this is pre-402: `fdb795d1b` (2026-09-14) established the exact native/capsule Task path branch. `specs/records/2026-10/2026-10-08-source-file-boundary.md` records the same actual native C: Task versus external D: input failure, distinguishes authorization from structural integrity and explicitly refuses a source bypass. Existing backend `test/task-process-file-boundary.test.ts` defines its positive exact-path/error contract; it was read, not run here.

### Why four plain replies do not complete a Task

The shared current architecture `task-control-plane.md:146-160, :235-240` requires an assistant-owned decision receipt for one Task-root ingress; a bounded semantic limit is an explicit exceptional terminal ingress disposition, not a successful Task decision. `no_action` is a real non-mutating decision with its own receipt, not plain text.

- `orchestrator/decision-tool-names.ts:9-18, :103-120` recognizes only real completed decision Tools (`dispatch_agent(s)`, respond_agent_coordination, manage_task, question, wait, no_action) and validates their effect. Ordinary read and text are not such receipts.
- `session/loop.ts:231-242` counts real non-tool-calls StepFinish Parts as decision gaps. :1952-1969 retains the same Task-root assistant until a real decision or the immutable semantic limit, and :2195-2205 supplies the existing explicit decision-repair context. It does not parse a model's prose into a decision.
- `engine/task-root-ingress-reducer.ts:236-239, :434-439` derives semantic exhaustion from immutable boundaries and policy. :305-334 classifies exhausted as operator-gated infrastructure evidence, so waiting is not an unbounded automatic retry.
- `task-root-ingress-delivery.ts:1354-1420` rereads the same facts transactionally and records the actual exhausted disposition plus the surfaced infrastructure fact. It neither fabricates success nor changes the business Task to completed merely because a Session is idle.

This is the same mechanism for explicit API Task, Global Task, Mission-created Task, package schedulers and later/replayed root ingresses. Task/ingress/epoch identities are part of the durable evidence; old outcomes do not become decisions in a later reopen. Normal decision receipts resolve the exact ingress, cancellation uses its actual current lifecycle boundary, dead-owner recovery terminalizes its abandoned physical occurrence before reducing or admitting a successor, and exhausted dispositions release later explicit FIFO inputs without a timer-driven spin. The current architecture documents these shared serial/restart/parallel boundaries. This scope's actual active epoch/idle/exhausted facts agree with that mechanism; it does not establish all restart/concurrency cases passed.

### Actual parallel nonTask evidence and causal exclusion

The same saved observation contains both real children of `ses_h0PutjPFeP4IYaaYLNXO`:

- Child one `ses_-zUS2EG8TzzPqOU7yF9p`, original user `msg_027268b4-222c-4ced-9426-6cfc78aab0ae`: actual read Tool failed with operator denial, then final `msg_g0VXxm2eM00lBQoxbPjk`, finish stop, completed 1791922941108 and text provider reply 2, pendingPermissions `[]`.
- Child two `ses_-zUS2EFjLzz10UVsiM7c`, original user `msg_63f90678-8a46-4d6b-a89e-1981ac37cc89`: actual read completed with three CSV lines (Cedar402,3 and Iris402,4), then final `msg_g0VXxm4LF00jVZM1i7NK`, finish stop, completed 1791922947520, pendingPermissions `[]`.
- These are real public child Sessions with separate controlled Providers, not a claim that delegate_agent ran. Root separately observed the SideChat independent-root AllowOnce output and screenshots; its request/response JSON and original terminal Provider entries remain evidence, not a second Task projection.

The Task failure is **TaskProcessBoundaryError**, not PermissionAuthority.RejectedError, and occurs **after allowed_once**. The removed denial gate would not have matched that error even before 402. The observed post-error model requests also prove this Task was not stopped by that gate. Permission requested/answered identity and sole Task card are intact; path binding and typed Task decision reducers have no current 402 diff. Therefore these two precise outcomes can be excluded from the Permission projection/denial-stop root cause using actual facts and the shared call graph, rather than a single package success. This does not claim full Task read/completion acceptance or broader native qualification.

### Independent additional scope evidence must remain visible

The Board also records **before the Permission** a separate `engine-git` prepare-baseline infrastructure error: artifact `art_g0VXxmQrn00IRj7ncHCS`, time 1791923033406, `Git HEAD inspection failed for repository .: fatal: '$GIT_DIR' too big`. The Task was then actually admitted to the model/Permission path. Exact Git environment/path-limit/root cause was not inspected; no assumption that it is harmless, fixture-only, caused by permission, or repaired is justified.

The later stderr contains a Project Memory organizer validation failure for empty markdown. It is likewise retained as its own actual background-work fact, not proof of the Task path/control cause. This audit did not rerun or widen either infrastructure investigation. They prevent a claim that the whole Task scope was fault-free.

For a later successful Task file test, input must enter its actual owned workspace through the normal supported input/attachment contract. Ordinary in-project reads may then require no Ask decision; forcing a read outside the Task root to manufacture Permission is not a valid successful-read oracle. A separate permitted effect inside the Task root and an explicitly declared capability can exercise Task Permission without violating root integrity. Complete Task acceptance additionally needs a natural real decision/control outcome. No config, input, workflow, code or service was changed here to obtain either result.
