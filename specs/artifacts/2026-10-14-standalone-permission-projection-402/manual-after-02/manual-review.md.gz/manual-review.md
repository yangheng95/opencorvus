# Manual after 02：warm 摘要错误与拒绝后业务失败

本记录依据 Root 已完成的真实桌面操作、原 JPEG/无障碍树（AX）、公开 Session/Permission JSON 与关闭回执整理。该轮是受控流式 Provider，不能算真实 Sol 验收，也不能标为业务通过。整理时人工查看本目录三张原 JPEG；没有重跑页面、修改观察、裁切或重编码图片。

实际主 Session 为 `ses_h1AT53KqE83EnjjSN0B3`，Permission 为 `per_hLx9HLMTNmA8CrBdDeDd`。先在真实主页面连接、等待放行公开请求，再收到 warm Permission 并显示决定控件。原 [warm 截图](observations/main-warm-permission-en.jpg) 清楚显示 `Permission requested: read`；[原公开 ledger](permission-history-after-deny.json) 的 requested 事实是 `read (read_local)`。这是原 warm summary 覆盖现象，不能把该图当作后来摘要修复通过证据。[连接阶段截图](observations/main-connected-before-release.jpg) / [AX](observations/main-connected-before-release.ax.txt) 只记录放行前状态。

Root 在真实决定控件拒绝后，公开 ledger 出现 `denied`。但页面随后显示 `The operator denied this Tool call.` 和 `Session … completed without a durable reply …`；见 [业务失败截图](observations/main-deny-terminal-error-en.jpg) / [AX](observations/main-deny-terminal-error-en.ax.txt)。[公开 messages](messages-after-deny.json) 保存 read Tool `status=error`、assistant `finish=tool-calls`；[公开 conversation](conversation-after-deny.json) 保存对应 terminal error。结论是决定控件有效并产生真实 denied 事实，之后发生 MissingDurableReply 业务失败；不是正常拒绝后完整回复，也不是整个 Deny 端到端通过。该原失败必须保留，不用后续修复结果覆盖。

物理关闭与业务失败分别记录：[page-closed.json](page-closed.json) 记录 tab 4 于 `2026-10-13T19:27:34.145Z` 关闭，早于记录的 originalCloseBy；[terminal.json](terminal.json) 记录 owner PID 68348、occurrence `98ab51fd-16f7-4f9b-90d2-f3e47efe6424` 与 server/provider stopped；[closure-review.json](closure-review.json) 记录原关闭会话 exit 0、outputSettled=true、Native PID 已不在、outer runtime 已清理。这仅证明该 scope 收尾，不修饰其业务失败。

此轮未证明 Question 草稿/重连、Side chat、Main child、多 pending、完整 Allow Once、双语或移动端。公开 CSV 是本 scope 的 `public-external.csv`，未读取用户 Provider 原始载荷、auth/models 或运行数据库。
