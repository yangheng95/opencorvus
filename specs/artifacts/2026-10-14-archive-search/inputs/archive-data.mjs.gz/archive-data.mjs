import fs from 'node:fs/promises'
import path from 'node:path'
import assert from 'node:assert/strict'
const [stage,mode='create']=process.argv.slice(2),root=path.resolve('.tmp-codex-archive-search-01a133',stage)
const ready=JSON.parse(await fs.readFile(path.join(root,'ready.json'),'utf8')),base=`http://127.0.0.1:${ready.port}`,receipts=[]
async function call(url,method='GET',body,expected=200){
 const response=await fetch(base+url,{method,headers:body?{'Content-Type':'application/json'}:undefined,body:body?JSON.stringify(body):undefined})
 const actual=await response.json();receipts.push({method,url,status:response.status,body,response:actual})
 assert.equal(response.status,expected,`${method} ${url}`);return actual
}
let items
if(mode==='create'){
 items=[]
 const inputs=[{title:'归档_50%\\旧记录',project:'A'},{title:'归档_50%\\跨项目',project:'B'},...Array.from({length:105},(_,i)=>({title:`分页项目A ${String(i+1).padStart(3,'0')}`,project:'A'}))]
 for(const input of inputs){
  const directory=ready.projects.find(p=>p.label===input.project).directory,query='?'+new URLSearchParams({directory})
  const {session}=await call('/coding/chat/session'+query,'POST',{},201)
  await call(`/coding/chat/session/${session.id}`+query,'PATCH',{title:input.title})
  const archived=await call(`/coding/chat/session/${session.id}/archive`+query,'PATCH',{archived:true})
  assert.equal(archived.session.title,input.title);assert.equal(typeof archived.session.time.archived,'number')
  items.push({...input,directory,id:session.id,archivedAt:archived.session.time.archived})
 }
 await fs.writeFile(path.join(root,'archive-inputs.json'),JSON.stringify(items,null,2)+'\n')
}else items=JSON.parse(await fs.readFile(path.join(root,'archive-inputs.json'),'utf8'))
const first=await call('/work-ledger/archive?limit=100')
assert.equal(first.rows.length,100);assert.equal(typeof first.nextCursor.rowKey,'string')
const cursor=first.nextCursor,second=await call('/work-ledger/archive?'+new URLSearchParams({limit:'100',cursorPinned:String(cursor.pinned),cursorUpdated:String(cursor.updated),cursorRowKey:cursor.rowKey}))
assert.deepEqual([...first.rows,...second.rows].map(r=>r.id).sort(),items.map(i=>i.id).sort())
const query='归档_50%\\',filtered=await call('/work-ledger/archive?'+new URLSearchParams({search:query,limit:'100'}))
assert.deepEqual(filtered.rows.map(r=>({id:r.id,title:r.title,directory:r.directory})).sort((a,b)=>a.id.localeCompare(b.id)),items.slice(0,2).map(({id,title,directory})=>({id,title,directory})).sort((a,b)=>a.id.localeCompare(b.id)))
await fs.writeFile(path.join(root,`archive-${mode}-receipts.json`),JSON.stringify({mode,receipts,total:items.length,firstPage:first.rows.length,secondPage:second.rows.length,targets:filtered.rows.map(r=>({id:r.id,title:r.title,directory:r.directory}))},null,2)+'\n')
console.log(JSON.stringify({stage,mode,actualHTTP:receipts.length,total:items.length,first:first.rows.length,second:second.rows.length,targets:filtered.rows.map(r=>r.title)}))
