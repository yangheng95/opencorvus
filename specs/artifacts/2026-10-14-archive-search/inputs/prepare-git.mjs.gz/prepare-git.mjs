import fs from 'node:fs'
const prior='.tmp-codex-automation-timestamp-locale-01a133',root='.tmp-codex-archive-search-01a133'
let stage=fs.readFileSync(prior+'/stage-final.mjs','utf8').replaceAll(prior,root).replaceAll('2026-10-14-automation-timestamp-locale','2026-10-14-archive-search')
stage=stage.replace("const sources=['packages/overlay/src/components/settings/ScheduledAutomationsPanel.tsx','packages/overlay/src/services/automation-recurrence.ts','packages/overlay/test/scheduled-automations.test.ts']","const sources=['packages/overlay/src/components/settings/ArchivePanel.tsx']")
stage=stage.replaceAll('#### 修复','#### 调整').replaceAll('#### Fixed','#### Changed')
if(stage.includes('ScheduledAutomationsPanel')||stage.includes('automation-recurrence'))throw Error('Foreign source scope in private index')
fs.writeFileSync(root+'/stage-final.mjs',stage)
let commit=fs.readFileSync(prior+'/commit-final.mjs','utf8').replaceAll(prior,root).replace('fix(overlay): localize scheduled dates and recurrence descriptions','feat(overlay): search all archived work through the canonical ledger')
fs.writeFileSync(root+'/commit-final.mjs',commit)
console.log('Prepared scoped private-index staging and normal commit with precise shared-patch reconciliation.')
