import fs from 'node:fs/promises'
import path from 'node:path'
import assert from 'node:assert/strict'
const root=path.resolve('.tmp-codex-archive-search-01a133/after'),ready=JSON.parse(await fs.readFile(root+'/ready.json','utf8')),items=JSON.parse(await fs.readFile(root+'/archive-inputs.json','utf8')),receipts=[]
async function get(url){const response=await fetch(`http://127.0.0.1:${ready.port}`+url);const body=await response.json();receipts.push({url,status:response.status,response:body});assert.equal(response.status,200);return body}
const restored=items[0],remaining=items[1],query=new URLSearchParams({search:'归档_50%\\',limit:'100'})
const archive=await get('/work-ledger/archive?'+query),active=await get('/work-ledger?'+query)
assert.deepEqual(archive.rows.map(r=>({id:r.id,title:r.title,directory:r.directory,archived:r.archived})),[{id:remaining.id,title:remaining.title,directory:remaining.directory,archived:remaining.archivedAt}])
assert.deepEqual(active.rows.filter(r=>r.kind==='chat').map(r=>({id:r.id,title:r.title,directory:r.directory})),[{id:restored.id,title:restored.title,directory:restored.directory}])
const {session}=await get(`/coding/chat/session/${restored.id}?`+new URLSearchParams({directory:restored.directory}))
assert.equal(session.id,restored.id);assert.equal(session.title,restored.title);assert.equal(session.time.archived??null,null)
const paged=new URLSearchParams({search:'分页项目A',limit:'100'}),first=await get('/work-ledger/archive?'+paged),cursor=first.nextCursor
assert.equal(first.rows.length,100);paged.set('cursorPinned',String(cursor.pinned));paged.set('cursorUpdated',String(cursor.updated));paged.set('cursorRowKey',cursor.rowKey)
const second=await get('/work-ledger/archive?'+paged)
assert.equal(second.rows.length,5);assert.deepEqual([...first.rows,...second.rows].map(r=>r.id).sort(),items.slice(2).map(r=>r.id).sort())
await fs.writeFile(root+'/restore-readback-receipts.json',JSON.stringify({receipts,restored:{id:restored.id,title:restored.title,state:'active'},remaining:{id:remaining.id,title:remaining.title,state:'archived'},queryPages:[first.rows.length,second.rows.length]},null,2)+'\n')
console.log(JSON.stringify({actualHTTP:receipts.length,restored:restored.id,remaining:remaining.id,queryPages:[first.rows.length,second.rows.length]}))
