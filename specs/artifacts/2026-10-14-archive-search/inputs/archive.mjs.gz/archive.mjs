import fs from 'node:fs'
import path from 'node:path'
import {gzipSync} from 'node:zlib'
const scratch='.tmp-codex-archive-search-01a133',artifact='specs/artifacts/2026-10-14-archive-search',manifest=[]
const capture=(from,to)=>{const bytes=fs.readFileSync(from);fs.mkdirSync(path.dirname(to),{recursive:true});fs.writeFileSync(to,gzipSync(bytes));manifest.push({source:from,destination:to.slice(artifact.length+1),originalBytes:bytes.length})}
for(const stage of ['before','after']){
 const root=`${scratch}/${stage}`,out=`${artifact}/runs/${stage}`
 for(const name of fs.readdirSync(root))if(name.endsWith('.json')&&name!=='privacy-ready.json')capture(`${root}/${name}`,`${out}/${name}.gz`)
 for(const name of fs.readdirSync(root+'/redacted-logs'))capture(`${root}/redacted-logs/${name}`,`${out}/logs/${name}.gz`)
}
for(const name of ['setup.mjs','runtime.ts','launch.ps1','privacy.ts','archive-data.mjs','restore-readback.mjs','ArchivePanel.before.tsx','run.mjs','archive.mjs','prepare-git.mjs','stage-final.mjs','commit-final.mjs'])capture(`${scratch}/${name}`,`${artifact}/inputs/${name}.gz`)
const checks=['before-parent','after-parent','privacy-before','privacy-after','search-business','overlay-typecheck','ui-build','i18n-check','docs-plan','docs-current','architecture-current','docs-final','architecture-final','data-before','data-before-readback','data-after','restore-readback']
for(const name of checks){if(fs.readFileSync(`${scratch}/${name}.exit`,'utf8').trim()!=='0')throw Error('Original checker incomplete '+name);for(const ext of ['log','exit'])capture(`${scratch}/${name}.${ext}`,`${artifact}/checks/${name}.${ext}.gz`)}
const prior='.tmp-codex-automation-timestamp-locale-01a133'
for(const name of ['commit-first.log','commit-first.exit'])if(fs.existsSync(`${scratch}/${name}`))capture(`${scratch}/${name}`,`${artifact}/checks/${name}.gz`)
for(const name of ['fetch-resume','merge-resume','lease-resume','push-resume'])for(const ext of ['log','exit'])capture(`${prior}/${name}.${ext}`,`${artifact}/previous-delivery/${name}.${ext}.gz`)
for(const name of ['resume-review.json','resume-push-receipt.json','push-resume.mjs'])capture(`${prior}/${name}`,`${artifact}/previous-delivery/${name}.gz`)
fs.writeFileSync(artifact+'/manifest.json',JSON.stringify({capturedAt:new Date().toISOString(),purpose:'Lossless original evidence capture; not a source checksum or a functional acceptance gate',files:manifest},null,2)+'\n')
fs.writeFileSync(artifact+'/README.md',`# 第22批：归档工作搜索证据

对应[Recall、实施前根因/影响与最终资格](../../records/2026-10/2026-10-14-archive-search.md)。Root独立操作并亲看12张未编辑原PNG；零UI自动化、真实凭据和模型调用。

- [screenshots](screenshots/README.md)：01/02修前100项与旧页目标；03搜索布局；04字面中文/_%/反斜线跨Project目标；05/06英文空结果/清除；07查询分页105；08中文双目标；09恢复过渡busy；10真实settled后原查询/剩余记录与焦点；11/12中文空结果/清除。09不能代替10的完成资格。
- [runs](runs/README.md)：before PID90472/18658–59、after PID77892/18660–61。各107条真实空Chat定义通过公开创建/命名/归档；正式checker共656 HTTP，UI请求另计。GET读回100+7及精确目标；UI恢复后GET证明原目标active、另一Project目标原archived时间、查询100+5精确集合。没有伪消息、运行或模型结果。
- [checks](checks/README.md)：纯后端search原runner4/18，类型、Node构建1m29s、语言目录2300键、docs345/26、架构19及两轮API/隐私/父进程退出均0。原build warnings保留。非UI检查不能代替原图人工复核。
- [inputs](inputs/README.md)：修前唯一组件、沿前批成熟生命周期的隔离运行器、正式HTTP checker原件；没有UI自动化脚本。假auth/models整对只在本任务隔离HOME内生成，绝不归档其内容。
- [previous-delivery](previous-delivery/README.md)：B19/B20/B21及其记录现已确认upstream；恢复后的原checker18owners/23sites通过，本任务正常push实际0（899ffcb33..356cb5ba9，全部原hook通过）。此前阻塞原件保持在B21交付目录，不改写历史失败。

两个自有页面均关闭。两轮正常settlement、父真实exit0、双端口0后精确删除自有假auth/models同对；完整后台原日志328259/356328字节、stdout/stderr各0，隐私checker0。原件无损gzip见[捕获清单](manifest.json)。仅桌面中英Chat/跨Project查询、分页和恢复资格；未独立操作Task/Mission恢复、永久删除、模型或调度。精确提交与正常push按后续真实回执结算。
`)
for(const [name,title,description]of [['screenshots','原始桌面截图','12原PNG由Root亲自查看；09为过渡、10为真实完成。'],['runs','正式API与物理生命周期','公开创建/查询/恢复后的真实事实及完整日志，未归档凭据。'],['checks','原检查回执','实际stdout/stderr及exit，原warnings不删除。'],['inputs','原输入与隔离运行器','只自有页面/服务的生命周期和正式HTTP checker，无UI自动化。'],['previous-delivery','前三批正常推送结算','恢复后实际fetch/merge、原租约checker与本任务正常push0。']]){fs.mkdirSync(`${artifact}/${name}`,{recursive:true});fs.writeFileSync(`${artifact}/${name}/README.md`,`# ${title}\n\n${description} 见[主说明](../README.md)。\n`)}
const arch='specs/current/architecture/07-panel.md',text=fs.readFileSync(arch,'utf8').replaceAll('\r\n','\n'),start=text.indexOf('## Archive queries\n'),end=text.indexOf('## Command palette queries\n',start)
if(start<0||end<0)throw Error('Own architecture insertion unavailable')
const shared=[{file:arch,anchor:'## Command palette queries\n',paragraph:text.slice(start,end)},{file:'CHANGELOG.md',zh:'- 归档页支持搜索全部已归档工作；查询覆盖未加载的分页记录，清除搜索恢复列表，恢复记录后保留当前查询。',en:'- Search all archived work from Settings, including records beyond the loaded page. Clearing search restores the list, and restoring a record keeps the current query.'}]
for(const locale of ['en-US','zh-CN']){
 const file=`packages/overlay/src/i18n/${locale}.json`,lines=fs.readFileSync(file,'utf8').replaceAll('\r\n','\n').split('\n'),beforeText=lines.find(x=>x.startsWith('  "archive.empty":'))
 const additions=['archive.search_placeholder','archive.no_results'].map(key=>lines.find(x=>x.startsWith(`  "${key}":`)))
 if(!beforeText||additions.some(x=>!x))throw Error('Own locale patch incomplete')
 shared.push({file,beforeText,afterText:[beforeText,...additions].join('\n')})
}
fs.writeFileSync(scratch+'/shared-final.json',JSON.stringify(shared,null,2)+'\n')
console.log(JSON.stringify({artifact,originalCaptures:manifest.length,shared:shared.map(x=>x.file)}))
