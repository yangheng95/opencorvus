import fs from 'node:fs'
const prior='.tmp-codex-automation-timestamp-locale-01a133',root='.tmp-codex-archive-search-01a133'
fs.mkdirSync(root,{recursive:true})
for(const name of ['runtime.ts','launch.ps1','privacy.ts','run.mjs']){
 let text=fs.readFileSync(`${prior}/${name}`,'utf8').replaceAll(prior,root).replaceAll('automation timestamp locale','archive search').replaceAll('18654','18658').replaceAll('18655','18659').replaceAll('18656','18660').replaceAll('18657','18661')
 fs.writeFileSync(`${root}/${name}`,text)
}
fs.mkdirSync('specs/artifacts/2026-10-14-archive-search/screenshots',{recursive:true})
console.log('Prepared owned archive-search runtime from the prior qualified lifecycle; ports 18658/59 and 18660/61.')
