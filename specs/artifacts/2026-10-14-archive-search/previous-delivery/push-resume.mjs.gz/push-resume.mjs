import fs from 'node:fs'
import {execFileSync} from 'node:child_process'
const root='.tmp-codex-automation-timestamp-locale-01a133'
const git=args=>execFileSync('git',args,{encoding:'utf8',maxBuffer:64*1024*1024}).trim()
const own=['e3c3d1aa73bfc2b071180d85a21773bdcc4b79b7','0fe812062088fc2aa6bc5f388d6e03b6ac078ae6','8c42e5d39806cd844a7f072439580e8e32b1402f','3b4f968014e3acd60f3537368a057d085c850369']
const head=git(['rev-parse','HEAD']),upstream=git(['rev-parse','@{upstream}'])
const branch=git(['branch','--show-current']),remote=git(['config','--get',`branch.${branch}.remote`]),mergeRef=git(['config','--get',`branch.${branch}.merge`])
const pending=git(['rev-list','--reverse',`${upstream}..${head}`]).split('\n').filter(Boolean)
for(const sha of own)git(['merge-base','--is-ancestor',sha,upstream])
for(const sha of pending){
  if(sha!=='356cb5ba96077a43ff3e212ce9e43d5078224ff1')throw Error('Unreviewed pending commit '+sha)
  const paths=git(['diff-tree','--no-commit-id','--name-only','-r',sha]).split('\n')
  if(paths.some(p=>!p.startsWith('specs/')))throw Error('Reviewed documentation scope changed')
}
for(const label of ['fetch-resume','merge-resume','lease-resume'])if(fs.readFileSync(`${root}/${label}.exit`,'utf8').trim()!=='0')throw Error('Original check incomplete: '+label)
const review={head,upstream,branch,remote,mergeRef,pending,ownCommitsAlreadyUpstream:own,at:new Date().toISOString(),ownership:'Only pending 356cb5ba9 is the independently user-authorized iteration task documentation: original 406 physical delivery/normal-push receipts and the 407 analysis plan. All paths reviewed as specs only. No new delegation, messages, or approval inferred from that plan.',qualification:'Root B19/B20/B21 implementation, positive contracts, real page interactions and 11/9/12 original screenshots remain qualified by their immutable artifacts. These four own commits are now confirmed upstream. Original lease checker passes 18 owners/23 sites. Earlier failures remain preserved. Normal push still runs all original hooks.'}
fs.writeFileSync(`${root}/resume-review.json`,JSON.stringify(review,null,2)+'\n')
let status=0
try{execFileSync('git',['push',remote,`${head}:${mergeRef}`],{stdio:'inherit',maxBuffer:64*1024*1024})}catch(e){status=e.status??1}
fs.writeFileSync(`${root}/resume-push-receipt.json`,JSON.stringify({...review,actualNormalPushExit:status,observedHeadAfter:git(['rev-parse','HEAD'])},null,2)+'\n')
process.exitCode=status
