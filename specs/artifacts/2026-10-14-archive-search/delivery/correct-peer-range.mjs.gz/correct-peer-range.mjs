import fs from 'node:fs'
import {execFileSync} from 'node:child_process'
const file='specs/records/2026-10/2026-10-13-compaction-stress.md',scratch='.tmp-codex-archive-search-01a133'
if(execFileSync('git',['diff','HEAD','--',file],{encoding:'utf8'}))throw Error('Original record acquired an independent working change')
const before=fs.readFileSync(file,'utf8'),matches=before.split('[26,80)').length-1
if(matches!==3)throw Error('Expected exactly the three reviewed explanatory range tokens')
fs.writeFileSync(scratch+'/compaction-record.before.md',before)
fs.writeFileSync(file,before.replaceAll('[26,80)','[27,81)'))
console.log('Corrected three explanatory range tokens from the unchanged original record; original report and source stay unchanged.')
