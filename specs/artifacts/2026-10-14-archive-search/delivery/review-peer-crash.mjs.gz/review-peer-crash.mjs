import fs from 'node:fs'
import assert from 'node:assert/strict'
import {gunzipSync} from 'node:zlib'
import {execFileSync} from 'node:child_process'
const sha='a169819b823871bd18efc98908dcd6ec5743ddb2',base='specs/artifacts/2026-10-13-compaction-stress/',git=args=>execFileSync('git',args,{maxBuffer:64*1024*1024})
const report=JSON.parse(gunzipSync(git(['show',sha+':'+base+'user-excerpt-crash-matrix.json.gz'])).toString()),codes={streaming:81,summary_saved:82,checkpoint_transaction:83,checkpoint_saved:84}
assert.equal(report.status,'passed');assert.equal(report.remoteModelRequests,0)
assert.deepEqual(report.cases.map(c=>`${c.cut}/${c.kind}`).sort(),Object.keys(codes).flatMap(c=>['manual','automatic'].map(k=>`${c}/${k}`)).sort())
const rows=report.cases.map(c=>{
 assert.equal(c.status,'passed');assert.equal(c.settlementConfirmed,true)
 assert.deepEqual(c.phases.map(p=>({mode:p.mode,exit:p.exitCode,settled:p.settlementConfirmed})),[{mode:'cut',exit:codes[c.cut],settled:true},{mode:'recover',exit:0,settled:true},{mode:'inspect',exit:0,settled:true}])
 const source=c.source,part=source.correction.parts.find(p=>p.type==='text'),quote=source.correctionExcerpt
 const recovered=c.phases[1].events.find(e=>e.stage==='recovered'),inspected=c.phases[2].events.find(e=>e.stage==='inspect')
 assert.deepEqual(inspected.snapshot,recovered.after);assert.equal(recovered.after.control.status,'consumed')
 assert.equal(source.correction.info.role,'user');assert.equal(part.text.slice(quote.offset,quote.offset+quote.text.length),quote.text)
 const selection=recovered.after.selection,s=selection.sources[0]
 assert.deepEqual({offset:s.offset,end:s.end,messageID:s.messageID,partID:s.partID,role:s.originalRole,author:s.originalAuthor},{offset:quote.offset,end:quote.offset+quote.text.length,messageID:source.correction.info.id,partID:part.id,role:'user',author:'user'})
 assert.deepEqual(recovered.after.retained,[{...source.correction,parts:source.correction.parts.map(p=>p.type==='text'?{...p,text:quote.text}:p)}])
 const summaries=c.requests.filter(q=>q.body.tools.some(t=>t.function.name==='ReadCompactionEvidence'))
 const modes=c.cut==='checkpoint_saved'?['cut']:['cut','recover']
 assert.deepEqual(summaries.map(q=>[q.mode,q.helperStep]),modes.flatMap(m=>['select','notes','summary'].map(s=>[m,s])))
 for(const q of c.requests){assert.equal(q.body.stream,true);assert.equal(q.body.model,'checkpoint')}
 return {cut:c.cut,kind:c.kind,requests:c.requests.length,phases:c.phases.length,range:{offset:s.offset,end:s.end},quote:quote.text}
})
const result={sha,status:'original_mechanics_verified',cases:rows.length,phases:rows.reduce((n,r)=>n+r.phases,0),requests:rows.reduce((n,r)=>n+r.requests,0),rows,scope:'Read-only immutable original physical reports. Scripted loopback mechanics; not model reasoning, UI, or Root B22 model usage.'}
fs.writeFileSync('.tmp-codex-archive-search-01a133/peer-crash-review.json',JSON.stringify(result,null,2)+'\n')
console.log(JSON.stringify({...result,rows:undefined,ranges:rows.map(r=>r.range)}))
