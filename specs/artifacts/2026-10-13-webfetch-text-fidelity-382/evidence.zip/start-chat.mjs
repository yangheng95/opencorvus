import assert from "node:assert/strict"
import fs from "node:fs/promises"
import path from "node:path"
import { fileURLToPath } from "node:url"

const root = path.dirname(fileURLToPath(import.meta.url))
const preflight = JSON.parse(await fs.readFile(path.join(root, "provider-run/evidence/preflight-ready.json"), "utf8"))
assert.deepEqual(preflight.preflight.credential, "usable")
assert.deepEqual(preflight.preflight.catalog, "projected")
assert.equal(preflight.preflight.actualModel, "gpt-6.1-sol")
assert.equal(preflight.preflight.streaming, true)
const input = {
  requestID: crypto.randomUUID(),
  model: "openai/gpt-6.1-sol",
  text: "请使用 webfetch，以 markdown 格式分别读取 http://127.0.0.1:18497/article.html 和 http://127.0.0.1:18497/article.md 。这是两份公开的排版样本，请根据实际读取结果，简短比较显式换行、缩进代码和代码中的空行，并在回答中给出两份来源的 Markdown 链接。只需读取并解释这两份文档。",
}
await fs.writeFile(path.join(root, "chat-input.json"), JSON.stringify(input, null, 2) + "\n", { flag: "wx" })
const response = await fetch("http://127.0.0.1:18496/global/chat/start", {
  method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(input), signal: AbortSignal.timeout(15000),
})
const accepted = await response.json()
await fs.writeFile(path.join(root, "chat-accepted.json"), JSON.stringify({ status: response.status, ...accepted }, null, 2) + "\n", { flag: "wx" })
assert.equal(response.status, 202)
console.log(JSON.stringify({ status: response.status, sessionID: accepted.session.id, directory: accepted.session.directory,
  messageID: accepted.messageID, requestID: accepted.requestID }))
