import fs from "node:fs/promises"
import path from "node:path"
import { fileURLToPath } from "node:url"
const root = path.dirname(fileURLToPath(import.meta.url))
const chat = JSON.parse(await fs.readFile(path.join(root, "chat-accepted.json"), "utf8"))
const url = new URL(`http://127.0.0.1:18496/session/${chat.session.id}/message`)
url.searchParams.set("directory", chat.session.directory)
const response = await fetch(url, { signal: AbortSignal.timeout(15000) })
if (!response.ok) throw new Error(`Observed message request HTTP ${response.status}`)
const messages = await response.json()
await fs.writeFile(path.join(root, `chat-observation-${Date.now()}.json`), JSON.stringify(messages, null, 2) + "\n", { flag: "wx" })
console.log(JSON.stringify(messages.map((entry) => ({ id: entry.info.id, role: entry.info.role, parentID: entry.info.parentID,
  time: entry.info.time, finish: entry.info.finish, error: entry.info.error,
  parts: entry.parts.map((part) => ({ type: part.type, tool: part.tool, state: part.state?.status, text: part.type === "text" ? part.text : undefined })) })), null, 2))
