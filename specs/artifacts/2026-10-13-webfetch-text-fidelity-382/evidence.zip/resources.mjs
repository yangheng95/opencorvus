import http from "node:http"
import fs from "node:fs/promises"
import path from "node:path"
import { fileURLToPath } from "node:url"

const root = path.dirname(fileURLToPath(import.meta.url))
const port = 18497
const startedAt = Date.now()
const maximumMs = 720000
const html = "<!doctype html><html><head><title>382 Line-break sample</title></head><body><p>First line<br>Second line</p><pre>    first \t\n\n\n\n      second  </pre><p>After.</p></body></html>"
const markdown = "---\r\ntitle: 382 Markdown sample\r\n---\r\n\r\n    indented code\r\n    next\r\n\r\nFirst line  \r\nSecond line\r\n\r\n```text\r\n  first \t\r\n\r\n\r\n\r\n  second  \r\n```\r\n"
const documents = {
  "/article.html": { contentType: "text/html; charset=utf-8", body: html,
    expected: "382 Line-break sample\n\nFirst line  \nSecond line\n\n    first \t\n\n\n\n      second  \n\nAfter.", title: "382 Line-break sample" },
  "/article.md": { contentType: "text/markdown; charset=utf-8", body: markdown, expected: markdown, title: "382 Markdown sample" },
}
await fs.writeFile(path.join(root, "resource-documents-02.json"), JSON.stringify(documents, null, 2) + "\n", { flag: "wx" })
const requests = []
let stopping
const close = (reason) => {
  if (stopping) return stopping
  clearTimeout(timer)
  stopping = new Promise((resolve, reject) => server.close((error) => error ? reject(error) : resolve()))
    .then(() => fs.writeFile(path.join(root, "resource-settled.json"), JSON.stringify({ pid: process.pid,
      parentPID: process.ppid, startedAt, stoppedAt: Date.now(), reason, requests, port, maximumMs }, null, 2) + "\n", { flag: "wx" }))
    .then(() => console.log(JSON.stringify({ resourceService: "closed", pid: process.pid, reason, requests: requests.length })))
  server.closeIdleConnections()
  return stopping
}
const server = http.createServer((request, response) => {
  const url = new URL(request.url, `http://127.0.0.1:${port}`)
  requests.push({ method: request.method, path: url.pathname, at: Date.now() })
  if (request.method === "POST" && url.pathname === "/owned-shutdown-382") {
    response.writeHead(200, { "content-type": "application/json" }).end('{"ok":true}')
    response.once("finish", () => void close("explicit-owner-shutdown"))
    return
  }
  const doc = documents[url.pathname]
  if (request.method !== "GET" || !doc) {
    response.writeHead(404, { "content-type": "text/plain" }).end("Resource not found")
    return
  }
  response.writeHead(200, { "content-type": doc.contentType }).end(doc.body)
})
server.listen(port, "127.0.0.1", async () => {
  await fs.writeFile(path.join(root, "resource-owner.json"), JSON.stringify({ pid: process.pid, parentPID: process.ppid,
    startedAt, deadlineAt: startedAt + maximumMs, port, purpose: "Owned public text fidelity inputs", maximumMs }, null, 2) + "\n", { flag: "wx" })
  console.log(JSON.stringify({ resourceService: "ready", pid: process.pid, port, deadlineAt: startedAt + maximumMs }))
})
const timer = setTimeout(() => void close("fixed-resource-maximum"), maximumMs)
