import assert from "node:assert/strict"
import fs from "node:fs/promises"
import path from "node:path"
import { createHash } from "node:crypto"
import { createRequire } from "node:module"
import { Database } from "bun:sqlite"
const root = process.argv[2]
assert(root && path.isAbsolute(root), "Required absolute scope root")
assert.equal(path.dirname(path.resolve(root)), import.meta.dir)
const mode = process.argv[3]
const responseReceipt = process.argv[4]
assert(mode === "observe" || mode === "check")
assert(responseReceipt && path.basename(responseReceipt) === responseReceipt && responseReceipt.endsWith(".json"), "Required explicit response receipt filename")
const json = async (name: string) => JSON.parse(await fs.readFile(path.join(root, name), "utf8"))
const owner = await json("provider-run/launch-owner.json")
assert.equal(path.resolve(owner.runtime), path.join(root, "provider-run/runtime"))
const created = await json("session-created.json")
const globalRequest = await json("global-chat-start-request.json")
const globalAccepted = await json("global-chat-start-response.json")
const firstCompleted = await json("global-chat-first-completed.json")
const sent = await json("public-message-request.json")
const resources = await json("public-resources.json")
const mcpOwner = await json("mcp-owner.json")
assert.equal(created.occurrence, owner.occurrence)
assert.equal(created.mcpOccurrence, mcpOwner.occurrence)
assert.equal(created.messageID, sent.messageID)
assert.equal(globalAccepted.status, 202)
assert.equal(globalAccepted.result.requestID, globalRequest.requestID)
assert.equal(globalAccepted.result.session.id, created.session.id)
assert.equal(globalAccepted.result.session.projectID, created.session.projectID)
assert.equal(globalAccepted.result.session.directory, created.session.directory)
assert.equal(globalAccepted.result.messageID, created.initialMessageID)
const projectsRoot = await fs.realpath(path.join(owner.runtime, "data/projects"))
const projectDirectory = await fs.realpath(created.session.directory)
const relativeProject = path.relative(projectsRoot, projectDirectory)
assert(relativeProject && !relativeProject.startsWith("..") && !path.isAbsolute(relativeProject), "Actual Global Chat project must be inside this native scope")
// Scope all production import initialization to the already-owned runtime.
process.env.OPENCORVUS_HOME = owner.runtime
process.env.OPENCORVUS_DISABLE_AUTOUPDATE = "1"
const { ProjectRuntimePaths } = await import("../packages/opencorvus/src/project/runtime-paths")
const { projectToolPartInTransaction } = await import("../packages/opencorvus/src/session/tool-part-facts")
const { ToolPartRequestTable } = await import("../packages/opencorvus/src/session/session.sql")
const { attachmentNameFromUrl } = await import("../packages/opencorvus/src/storage/attachment-reference")
const { CredentialRedactor } = await import("../packages/opencorvus/script/real-provider-audit")
const redactor = new CredentialRedactor()
// Root runs this only after paired staging. Secrets stay in memory, never in evidence.
redactor.collect(JSON.parse(await fs.readFile(path.join(owner.runtime, "data/auth.json"), "utf8")))
const headers = { "x-opencorvus-directory": created.session.directory }
const get = async (route: string) => {
  const response = await fetch(`http://127.0.0.1:18506${route}`, { headers, signal: AbortSignal.timeout(10000) })
  const value = await response.json()
  return { status: response.status, result: value }
}
const publicSession = await get(`/session/${created.session.id}`)
const publicUser = await get(`/session/${created.session.id}/message/${sent.messageID}`)
const require = createRequire(path.join(import.meta.dir, "../packages/opencorvus/package.json"))
const { drizzle } = await import(require.resolve("drizzle-orm/bun-sqlite"))
const dbPath = path.join(owner.runtime, "data/opencorvus.db")
const db = new Database(dbPath, { readonly: true })
let canonical: any
try {
  db.exec("BEGIN")
  const session = db.query("SELECT * FROM session WHERE id=?").get(created.session.id) as any
  assert(session)
  const allocation = db.query("SELECT * FROM global_creation_allocation WHERE kind='global_chat_start' AND request_id=?").get(globalRequest.requestID) as any
  const messages = db.query("SELECT id,session_id,data FROM message WHERE session_id=? ORDER BY time_created,id").all(session.id).map((row: any) => ({ id: row.id, sessionID: row.session_id, ...JSON.parse(row.data) }))
  const parts = db.query("SELECT p.id,p.message_id,m.session_id,p.data FROM part p JOIN message m ON m.id=p.message_id WHERE m.session_id=? ORDER BY p.time_created,p.id").all(session.id).map((row: any) => ({ id: row.id, sessionID: row.session_id, messageID: row.message_id, ...JSON.parse(row.data) }))
  const outputDB = drizzle({ client: db })
  const messageIDs = new Set(messages.map((message: any) => message.id))
  const tools = outputDB.select().from(ToolPartRequestTable).all().filter((row: any) => messageIDs.has(row.message_id)).map((row: any) => projectToolPartInTransaction(outputDB as any, row))
  canonical = { observedAt: new Date().toISOString(), session, allocation, messages, parts, tools, publicSession, publicUser }
} finally { db.exec("ROLLBACK"); db.close() }
const names = (await fs.readdir(owner.evidence)).filter((name) => /^provider-.*-\d+\.json$/.test(name))
const audits = await Promise.all(names.map(async (name) => ({ name, value: JSON.parse(await fs.readFile(path.join(owner.evidence, name), "utf8")) })))
audits.sort((a, b) => Date.parse(a.value.observedAt) - Date.parse(b.value.observedAt) || Number(a.name.match(/-(\d+)\.json$/)![1]) - Number(b.name.match(/-(\d+)\.json$/)![1]))
const audit = audits.at(-1)?.value
const record = (name: string, value: any) => fs.writeFile(path.join(root, name), redactor.redact(JSON.stringify(value, null, 2)) + "\n", { flag: "wx" })
if (mode === "observe") {
  await record(`observation-${Date.now()}.json`, { canonical, audit })
  console.log(redactor.redact(JSON.stringify({ sessionID: canonical.session.id, messages: canonical.messages.map((message: any) => ({ id: message.id, role: message.role, finish: message.finish, time: message.time })), tools: canonical.tools.map((part: any) => ({ tool: part.tool, state: part.state.status })), publicUserStatus: publicUser.status, requests: audit?.requests.length, remainingMs: owner.nativeDeadlineAt - Date.now() }, null, 2)))
} else {
  // Save the actual observation before assertions, including failed acceptance attempts.
  await record(`check-input-${Date.now()}.json`, { canonical, audit })
  const result = await json(responseReceipt)
  assert.equal(result.status, 200)
  assert.equal(publicSession.status, 200)
  assert.equal(publicUser.status, 200)
  assert.equal(canonical.session.project_id, created.session.projectID)
  assert.equal(publicSession.result.id, canonical.session.id)
  assert.equal(publicSession.result.projectID, canonical.session.project_id)
  assert.equal(canonical.session.directory, created.session.directory)
  const metadata = JSON.parse(canonical.session.metadata)
  assert.equal(metadata.conversation.surface, "right-sidebar")
  assert.equal(metadata.conversation.experience, "chat")
  assert.equal(metadata.globalChatStart.requestID, globalRequest.requestID)
  assert.equal(metadata.globalChatStart.messageID, created.initialMessageID)
  assert.equal(canonical.allocation.accepted_target_id, created.session.id)
  assert.equal(canonical.allocation.accepted_project_id, created.session.projectID)
  assert.equal(canonical.allocation.materialized_project_id, created.session.projectID)
  assert.equal(canonical.allocation.directory, created.session.directory)
  const firstUser = canonical.messages.find((message: any) => message.id === created.initialMessageID)
  assert.equal(firstUser.role, "user")
  assert.deepEqual(canonical.parts.filter((part: any) => part.messageID === firstUser.id && part.type === "text").map((part: any) => part.text), [globalRequest.text])
  const firstAssistant = canonical.messages.find((message: any) => message.id === firstCompleted.firstAssistant.info.id)
  assert.equal(firstAssistant.parentID, firstUser.id)
  assert.equal(firstAssistant.providerID, "openai")
  assert.equal(firstAssistant.modelID, "gpt-6.1-sol")
  assert.equal(firstAssistant.finish, "stop")
  assert(Number.isFinite(firstAssistant.time.completed))
  assert.equal(publicUser.result.info.id, sent.messageID)
  assert.equal(publicUser.result.info.role, "user")
  const user = canonical.messages.find((message: any) => message.id === sent.messageID)
  assert.equal(user.role, "user")
  const userParts = canonical.parts.filter((part: any) => part.messageID === sent.messageID)
  assert.deepEqual(publicUser.result.parts.map((part: any) => part.id), userParts.map((part: any) => part.id))
  const actualParts = userParts.map((part: any) => part.type === "text" ? { type: part.type, text: part.text } : { type: part.type, filename: part.filename, mime: part.mime, source: part.source, presentation: part.presentation })
  const expectedParts: any[] = [{ type: "text", text: sent.parts[0].text }]
  for (const resource of resources) {
    expectedParts.push({ type: "text", text: `Reading MCP resource: ${resource.filename} (${resource.uri})` })
    const input = sent.parts.find((part: any) => part.source?.uri === resource.uri)
    for (const content of resource.contents) {
      if (typeof content.text === "string") expectedParts.push({ type: "text", text: content.text })
      else {
        expectedParts.push({ type: "text", text: `[Binary content: ${content.mimeType}]` })
        expectedParts.push({ type: "file", filename: resource.filename, mime: content.mimeType, source: input.source, presentation: undefined })
      }
    }
  }
  expectedParts.push({ type: "file", filename: "public-upload.csv", mime: "text/csv", source: undefined, presentation: "attachment-index" })
  assert.deepEqual(actualParts, expectedParts)
  const namespace = createHash("sha256").update(path.resolve(dbPath).toLowerCase()).digest("hex")
  const files = userParts.filter((part: any) => part.type === "file")
  assert.equal(files.length, 3)
  const upload = await json("upload-receipt.json")
  const attachmentFacts: any[] = []
  for (const part of files) {
    assert.equal(part.sessionID, canonical.session.id)
    assert.equal(part.messageID, sent.messageID)
    const ref = attachmentNameFromUrl(part.url)!
    assert(ref)
    assert.equal(ref.projectID, canonical.session.project_id)
    const absolutePath = path.join(ProjectRuntimePaths.attachmentBlobRoot(created.session.directory), namespace, ref.name)
    const bytes = await fs.readFile(absolutePath)
    assert.deepEqual(bytes, await fs.readFile(path.join(root, part.filename)))
    const metadata = JSON.parse(await fs.readFile(absolutePath + ".metadata.json", "utf8"))
    assert.equal(metadata.size, bytes.length)
    assert.equal(metadata.mime, part.mime)
    assert.equal(metadata.url, part.url)
    if (part.filename === "public-upload.csv") assert.equal(part.url, upload.result.url)
    const served = await fetch(`http://127.0.0.1:18506${part.url}`, { headers, signal: AbortSignal.timeout(10000) })
    assert.equal(served.status, 200)
    assert.deepEqual(Buffer.from(await served.arrayBuffer()), bytes)
    attachmentFacts.push({ partID: part.id, filename: part.filename, url: part.url, absolutePath, bytes: bytes.length, exactPublicSample: true, publicHTTPExactBytes: true, metadata })
  }
  const calls = (await fs.readFile(path.join(root, "mcp-read-calls.jsonl"), "utf8")).trim().split("\n").map((line) => JSON.parse(line))
  assert.deepEqual(calls.map((call) => call.uri).sort(), resources.map((resource: any) => resource.uri).sort())
  for (const call of calls) {
    assert.equal(call.occurrence, mcpOwner.occurrence)
    assert.equal(call.pid, mcpOwner.pid)
    assert.deepEqual(call.contents, resources.find((resource: any) => resource.uri === call.uri).contents)
  }
  const finalAssistant = canonical.messages.find((message: any) => message.id === result.result.info.id)
  assert(finalAssistant)
  assert.equal(finalAssistant.role, "assistant")
  assert.equal(finalAssistant.providerID, "openai")
  assert.equal(finalAssistant.modelID, "gpt-6.1-sol")
  assert.equal(finalAssistant.parentID, sent.messageID)
  assert.equal(finalAssistant.finish, "stop")
  assert(Number.isFinite(finalAssistant.time.completed))
  const publicAssistant = await get(`/session/${canonical.session.id}/message/${finalAssistant.id}`)
  assert.equal(publicAssistant.status, 200)
  assert.equal(publicAssistant.result.info.time.completed, finalAssistant.time.completed)
  const reply = canonical.parts.filter((part: any) => part.messageID === finalAssistant.id && part.type === "text").map((part: any) => part.text).join("\n")
  assert(reply.trim().length > 0)
  const replyFacts = { expectedReviewCode: "MOSS-393-PUBLIC", expectedMixedRows: [{ item: "Maple", quantity: 3 }, { item: "Iris", quantity: 4 }], expectedMixedTotal: 7, expectedUploadRows: [{ item: "Notebook", quantity: 7 }, { item: "Pen", quantity: 5 }], expectedUploadTotal: 12, review: "Root must inspect visible Chinese answer, totals, empty-resource descriptions and actual references; byte truth comes from independent store checks" }
  assert.equal(audit.pid, owner.nativeTarget.pid)
  assert.equal(audit.model, "gpt-6.1-sol")
  assert.equal(audit.maxRequests, 20)
  assert(audit.requests.length > 0 && audit.requests.length <= 20)
  for (const request of audit.requests) {
    assert.equal(request.model, "gpt-6.1-sol"); assert.equal(request.streaming, true); assert.equal(request.status, 200)
    assert.equal(request.response_reader.state, "settled"); assert.equal(request.response_reader.terminal.kind, "eof")
  }
  assert(Date.now() < Math.min(owner.nativeDeadlineAt, mcpOwner.deadlineAt))
  const evidence = { observedAt: new Date().toISOString(), acceptance: "backend-global-chat-public-followup-passed", responseReceipt, sessionID: canonical.session.id, projectID: canonical.session.project_id, directory: created.session.directory, initialMessageID: firstUser.id, initialAssistantID: firstAssistant.id, globalChatAllocationID: canonical.allocation.id, messageID: sent.messageID, assistantID: finalAssistant.id, exactOrderedUserParts: userParts.length, actualSDKResourceReads: calls.length, attachmentFacts, providerRequests: audit.requests.length, allRequestsExactModelStreamingHTTP200EOF: true, nativeDeadlineAt: owner.nativeDeadlineAt, mcpDeadlineAt: mcpOwner.deadlineAt, closeBy: created.closeBy, replyFacts, boundary: "Actual Global Chat first turn followed by the public Session resource/canonical attachment route and completed real assistant. No Task/Mission qualification, ACP/App, data/file live sample, browser or physical-close claim." }
  await record("live-canonical.json", { ...canonical, publicAssistant })
  await record("live-provider-audit.json", audit)
  await record("live-check.json", evidence)
  await fs.writeFile(path.join(root, "visible-answer.txt"), redactor.redact(reply), { flag: "wx" })
  console.log(JSON.stringify(evidence, null, 2))
}
