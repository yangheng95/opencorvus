import assert from 'node:assert/strict';import fs from 'node:fs/promises';import path from 'node:path';import {randomUUID} from 'node:crypto';const root=process.argv[2];assert(root&&path.isAbsolute(root));const json=async n=>JSON.parse(await fs.readFile(path.join(root,n),'utf8'));const record=(n,v)=>fs.writeFile(path.join(root,n),JSON.stringify(v,null,2)+'\n',{flag:'wx'});const owner=await json('provider-run/launch-owner.json'),mcpOwner=await json('mcp-owner.json'),accepted=(await json('global-chat-start-response.json')).result,session=accepted.session;const first=await json('global-chat-first-completed.json');assert.equal(first.firstAssistant.info.finish,'stop');assert.equal(first.firstAssistant.info.modelID,'gpt-6.1-sol');assert.equal(session.metadata.configOverlay.prompt_profile.active,'base');const deadlineAt=Math.min(owner.nativeDeadlineAt,mcpOwner.deadlineAt),pageReservedAt=deadlineAt-180000,closeBy=deadlineAt-60000;assert(deadlineAt-Date.now()>=180000);const headers={'x-opencorvus-directory':session.directory};const api=async(route,method='GET',body)=>{const r=await fetch('http://127.0.0.1:18506'+route,{method,headers:{...headers,'content-type':'application/json'},...(body?{body:JSON.stringify(body)}:{}),signal:AbortSignal.timeout(15000)});const value=await r.json();assert.equal(r.status,200);return value};const config=await api('/config');assert.deepEqual(config.mcp.public_user_resources,await json('mcp-config.json'));await record('config-surface-facts.json',{rawProjectProfile:config.prompt_profile.active,sessionOverlayProfile:session.metadata.configOverlay.prompt_profile.active,actualFirstModel:first.firstAssistant.info.modelID,rootApproval:'Continue first follow-up after correcting helper surface assertion; no config/profile/metadata change'});
const connected = await api("/mcp/public_user_resources/connect", "POST")
assert.equal(connected, true)
const statuses = await api("/mcp")
assert.equal(statuses.public_user_resources.status, "connected")
await record("mcp-connect-precondition.json", { observedAt: new Date().toISOString(), status: statuses.public_user_resources })
const bytes = await fs.readFile(path.join(root, "public-upload.csv"))
const uploadResponse = await fetch("http://127.0.0.1:18506/attachment?filename=public-upload.csv", { method: "POST", headers: { ...headers, "content-type": "text/csv" }, body: bytes, signal: AbortSignal.timeout(30000) })
const uploaded = await uploadResponse.json()
await record("upload-receipt.json", { observedAt: new Date().toISOString(), status: uploadResponse.status, result: uploaded })
assert.equal(uploadResponse.status, 200)
assert.equal(uploaded.size, bytes.length)
assert.equal(uploaded.mime, "text/csv")
assert.equal(uploaded.filename, "public-upload.csv")
assert.match(uploaded.url, /^\/attachment\//)
const messageID = `msg_${randomUUID()}`
const resources = await json("public-resources.json")
const request = {
  messageID, agent: "chat", model: { providerID: "openai", modelID: "gpt-6.1-sol" },
  parts: [
    { type: "text", text: await fs.readFile(path.join(root, "user-request.txt"), "utf8") },
    ...resources.map((resource) => ({ type: "file", mime: resource.mime, filename: resource.filename, url: resource.uri, source: { type: "resource", clientName: "public_user_resources", uri: resource.uri, text: { value: resource.uri, start: 0, end: resource.uri.length } } })),
    { type: "file", mime: uploaded.mime, filename: uploaded.filename, url: uploaded.url, presentation: "attachment-index" },
  ],
}
await record("session-created.json", { occurrence: owner.occurrence, mcpOccurrence: mcpOwner.occurrence, observedAt: new Date().toISOString(), session, messageID, initialMessageID: accepted.messageID, globalRequestID: accepted.requestID, nativeDeadlineAt: owner.nativeDeadlineAt, mcpDeadlineAt: mcpOwner.deadlineAt, pageReservedAt, closeBy, url: "http://127.0.0.1:18506/ui" })
await record("public-message-request.json", request)
console.log(JSON.stringify({ readyForPage: true, sessionID: session.id, projectID: session.projectID, directory: session.directory, messageID, url: "http://127.0.0.1:18506/ui", nativeDeadlineAt: owner.nativeDeadlineAt, mcpDeadlineAt: mcpOwner.deadlineAt, pageReservedAt, closeBy }))
assert(deadlineAt - Date.now() >= 180000, "Attachment follow-up requires three original minutes")
const requestSentAt = new Date().toISOString()
try {
  const response = await fetch(`http://127.0.0.1:18506/session/${session.id}/message`, { method: "POST", headers: { ...headers, "content-type": "application/json" }, body: JSON.stringify(request), signal: AbortSignal.timeout(pageReservedAt - Date.now()) })
  const text = await response.text()
  let value
  try { value = JSON.parse(text) } catch { value = { unparsedBody: text } }
  await record("public-message-response.json", { requestSentAt, observedAt: new Date().toISOString(), status: response.status, sessionID: session.id, messageID, result: value })
  assert.equal(response.status, 200)
  assert.equal(value.info.role, "assistant")
  assert.equal(value.info.providerID, "openai")
  assert.equal(value.info.modelID, "gpt-6.1-sol")
  assert.equal(value.info.finish, "stop")
  assert(Number.isFinite(value.info.time.completed))
  console.log(JSON.stringify({ messageComplete: true, sessionID: session.id, assistantID: value.info.id, remainingMs: deadlineAt - Date.now(), pageReservedAt }))
} catch (error) {
  await record("public-message-failure.json", { requestSentAt, observedAt: new Date().toISOString(), sessionID: session.id, messageID, error: String(error), deadlineAt, pageReservedAt, boundary: "HTTP wait ended; this is not evidence that the model owner was cancelled. Root must settle original owners." })
  throw error
}
