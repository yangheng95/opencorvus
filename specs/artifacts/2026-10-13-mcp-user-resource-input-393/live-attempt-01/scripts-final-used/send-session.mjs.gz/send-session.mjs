import assert from "node:assert/strict"
import fs from "node:fs/promises"
import path from "node:path"
import { fileURLToPath } from "node:url"
import { randomUUID } from "node:crypto"
const root = process.argv[2]
assert(root && path.isAbsolute(root), "Required absolute scope root")
assert.equal(path.dirname(path.resolve(root)), path.dirname(fileURLToPath(import.meta.url)))
const json = async (name) => JSON.parse(await fs.readFile(path.join(root, name), "utf8"))
const record = (name, value) => fs.writeFile(path.join(root, name), JSON.stringify(value, null, 2) + "\n", { flag: "wx" })
const owner = await json("provider-run/launch-owner.json")
assert.equal(path.resolve(owner.runtime), path.join(root, "provider-run/runtime"))
const preflight = await json("provider-run/evidence/preflight-ready.json")
const mcpOwner = await json("mcp-owner.json")
const mcpReady = await json("mcp-ready.json")
assert.equal(owner.port, 18506)
assert.equal(owner.qualificationKind, "NativeService")
assert.equal(owner.requestBudget, 20)
assert.equal(owner.inactivityMilliseconds, 180000)
assert.equal(owner.profileSelection.kind, "builtin")
assert.equal(owner.profileSelection.id, "base")
assert.equal(preflight.occurrence, owner.occurrence)
assert.deepEqual({ credential: preflight.preflight.credential, catalog: preflight.preflight.catalog, actualModel: preflight.preflight.actualModel, streaming: preflight.preflight.streaming }, { credential: "usable", catalog: "projected", actualModel: "gpt-6.1-sol", streaming: true })
assert.equal(mcpReady.occurrence, mcpOwner.occurrence)
assert.equal(mcpReady.pid, mcpOwner.pid)
assert.equal(mcpOwner.port, 18507)
assert.equal(mcpOwner.lifetimeMilliseconds, 600000)
const deadlineAt = Math.min(owner.nativeDeadlineAt, mcpOwner.deadlineAt)
const closeBy = deadlineAt - 60000
const pageReservedAt = deadlineAt - 180000
assert(deadlineAt - Date.now() >= 180000, "First actual business request requires three original minutes")
await record("send-intent.json", { occurrence: owner.occurrence, mcpOccurrence: mcpOwner.occurrence, startedAt: new Date().toISOString(), deadlineAt, pageReservedAt, closeBy })
const globalRequest = {
  requestID: randomUUID(), model: "openai/gpt-6.1-sol",
  text: "我想核对两份公开CSV和几个公开资源，稍后会把资料发来。请先简短确认可以根据原始内容核对各行数据、合计和引用。",
}
await record("global-chat-start-request.json", globalRequest)
const globalResponse = await fetch("http://127.0.0.1:18506/global/chat/start", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(globalRequest), signal: AbortSignal.timeout(30000) })
const accepted = await globalResponse.json()
await record("global-chat-start-response.json", { status: globalResponse.status, observedAt: new Date().toISOString(), result: accepted })
assert.equal(globalResponse.status, 202)
assert.equal(accepted.requestID, globalRequest.requestID)
const session = accepted.session
assert.equal(session.kind, "assistant")
assert.equal(session.metadata.conversation.surface, "right-sidebar")
assert.equal(session.metadata.conversation.experience, "chat")
const projectsRoot = await fs.realpath(path.join(owner.runtime, "data/projects"))
const directory = await fs.realpath(session.directory)
const relativeProject = path.relative(projectsRoot, directory)
assert(relativeProject && !relativeProject.startsWith("..") && !path.isAbsolute(relativeProject), "Global Chat must be allocated inside this native scoped runtime projects")
assert.equal(path.resolve(session.directory).toLowerCase(), directory.toLowerCase())
const ready = { occurrence: owner.occurrence, mcpOccurrence: mcpOwner.occurrence, sessionID: session.id, projectID: session.projectID, directory: session.directory, initialMessageID: accepted.messageID, requestID: accepted.requestID, nativeDeadlineAt: owner.nativeDeadlineAt, mcpDeadlineAt: mcpOwner.deadlineAt, pageReservedAt, closeBy, url: "http://127.0.0.1:18506/ui" }
await record("global-chat-ready.json", ready)
console.log(JSON.stringify({ readyForPage: true, ...ready }))
const headers = { "x-opencorvus-directory": session.directory }
const api = async (route, method = "GET", body) => {
  const response = await fetch(`http://127.0.0.1:18506${route}`, { method, headers: { ...headers, "content-type": "application/json" }, ...(body ? { body: JSON.stringify(body) } : {}), signal: AbortSignal.timeout(30000) })
  const value = await response.json()
  assert.equal(response.status, 200, `${method} ${route}: ${response.status} ${JSON.stringify(value)}`)
  return value
}
// Wait for the real first turn before the attachment follow-up. Never synthesize it.
try {
  let firstAssistant
  while (Date.now() < pageReservedAt) {
    const messages = await api(`/session/${session.id}/message`)
    firstAssistant = messages.find((message) => message.info.role === "assistant" && message.info.parentID === accepted.messageID && Number.isFinite(message.info.time.completed))
    if (firstAssistant) break
    await new Promise((resolve) => setTimeout(resolve, Math.min(3000, Math.max(1, pageReservedAt - Date.now()))))
  }
  assert(firstAssistant, "First Global Chat turn must actually complete before the reserved page window")
  assert.equal(firstAssistant.info.providerID, "openai")
  assert.equal(firstAssistant.info.modelID, "gpt-6.1-sol")
  assert.equal(firstAssistant.info.finish, "stop")
  await record("global-chat-first-completed.json", { observedAt: new Date().toISOString(), firstAssistant })
} catch (error) {
  await record("global-chat-first-failure.json", { observedAt: new Date().toISOString(), error: String(error), ...ready })
  throw error
}
const mcp = await json("mcp-config.json")
await api("/config", "PATCH", { mcp: { public_user_resources: mcp } })
const config = await api("/config")
assert.equal(config.prompt_profile.active, "base")
assert.deepEqual(config.mcp.public_user_resources, mcp)
await record("project-default-fact.json", { project: session.directory, projectID: session.projectID, nativeProject: owner.project, promptProfile: config.prompt_profile.active, mcp: { public_user_resources: config.mcp.public_user_resources } })
const connected = await api("/mcp/public_user_resources/connect", "POST")
assert.equal(connected, true)
const statuses = await api("/mcp")
assert.equal(statuses.public_user_resources.status, "connected")
await record("mcp-connect-precondition.json", { observedAt: new Date().toISOString(), status: statuses.public_user_resources })
const bytes = await fs.readFile(path.join(root, "public-upload.csv"))
const uploadResponse = await fetch("http://127.0.0.1:18506/attachment?filename=public-upload.csv", { method: "POST", headers: { ...headers, "content-type": "text/csv" }, body: bytes, signal: AbortSignal.timeout(30000) })
const uploaded = await uploadResponse.json()
await record("upload-receipt.json", { observedAt: new Date().toISOString(), status: uploadResponse.status, result: uploaded })
assert.equal(uploadResponse.status, 200)
assert.equal(uploaded.size, bytes.length)
assert.equal(uploaded.mime, "text/csv")
assert.equal(uploaded.filename, "public-upload.csv")
assert.match(uploaded.url, /^\/attachment\//)
const messageID = `msg_${randomUUID()}`
const resources = await json("public-resources.json")
const request = {
  messageID, agent: "chat", model: { providerID: "openai", modelID: "gpt-6.1-sol" },
  parts: [
    { type: "text", text: await fs.readFile(path.join(root, "user-request.txt"), "utf8") },
    ...resources.map((resource) => ({ type: "file", mime: resource.mime, filename: resource.filename, url: resource.uri, source: { type: "resource", clientName: "public_user_resources", uri: resource.uri, text: { value: resource.uri, start: 0, end: resource.uri.length } } })),
    { type: "file", mime: uploaded.mime, filename: uploaded.filename, url: uploaded.url, presentation: "attachment-index" },
  ],
}
await record("session-created.json", { occurrence: owner.occurrence, mcpOccurrence: mcpOwner.occurrence, observedAt: new Date().toISOString(), session, messageID, initialMessageID: accepted.messageID, globalRequestID: accepted.requestID, nativeDeadlineAt: owner.nativeDeadlineAt, mcpDeadlineAt: mcpOwner.deadlineAt, pageReservedAt, closeBy, url: "http://127.0.0.1:18506/ui" })
await record("public-message-request.json", request)
console.log(JSON.stringify({ readyForPage: true, sessionID: session.id, projectID: session.projectID, directory: session.directory, messageID, url: "http://127.0.0.1:18506/ui", nativeDeadlineAt: owner.nativeDeadlineAt, mcpDeadlineAt: mcpOwner.deadlineAt, pageReservedAt, closeBy }))
assert(deadlineAt - Date.now() >= 180000, "Attachment follow-up requires three original minutes")
const requestSentAt = new Date().toISOString()
try {
  const response = await fetch(`http://127.0.0.1:18506/session/${session.id}/message`, { method: "POST", headers: { ...headers, "content-type": "application/json" }, body: JSON.stringify(request), signal: AbortSignal.timeout(pageReservedAt - Date.now()) })
  const text = await response.text()
  let value
  try { value = JSON.parse(text) } catch { value = { unparsedBody: text } }
  await record("public-message-response.json", { requestSentAt, observedAt: new Date().toISOString(), status: response.status, sessionID: session.id, messageID, result: value })
  assert.equal(response.status, 200)
  assert.equal(value.info.role, "assistant")
  assert.equal(value.info.providerID, "openai")
  assert.equal(value.info.modelID, "gpt-6.1-sol")
  assert.equal(value.info.finish, "stop")
  assert(Number.isFinite(value.info.time.completed))
  console.log(JSON.stringify({ messageComplete: true, sessionID: session.id, assistantID: value.info.id, remainingMs: deadlineAt - Date.now(), pageReservedAt }))
} catch (error) {
  await record("public-message-failure.json", { requestSentAt, observedAt: new Date().toISOString(), sessionID: session.id, messageID, error: String(error), deadlineAt, pageReservedAt, boundary: "HTTP wait ended; this is not evidence that the model owner was cancelled. Root must settle original owners." })
  throw error
}
