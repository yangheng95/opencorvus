import assert from "node:assert/strict"
import fs from "node:fs/promises"
import path from "node:path"
import { fileURLToPath } from "node:url"
import { randomUUID } from "node:crypto"
const root = process.argv[2]
assert(root && path.isAbsolute(root), "Required absolute scope root")
assert.equal(path.dirname(path.resolve(root)), path.dirname(fileURLToPath(import.meta.url)))
const owner = JSON.parse(await fs.readFile(path.join(root, "mcp-owner.json"), "utf8"))
assert.equal(path.resolve(owner.stopFile), path.join(root, "mcp-stop.json"))
assert.equal(owner.port, 18507)
assert.equal(process.argv[3], "PageClosed", "Root must have closed its page before normal MCP stop")
const stage = path.join(root, `mcp-stop-${randomUUID()}.stage`)
try {
  await fs.writeFile(stage, JSON.stringify({ occurrence: owner.occurrence, reason: "page-closed", requestedAt: new Date().toISOString() }, null, 2) + "\n", { flag: "wx" })
  // Atomic, exclusive publication prevents the owner seeing partial JSON.
  await fs.link(stage, owner.stopFile)
} finally { await fs.unlink(stage) }
console.log(JSON.stringify({ stopRequested: true, occurrence: owner.occurrence, pid: owner.pid, stopFile: owner.stopFile, mcpDeadlineAt: owner.deadlineAt, boundary: "Root must join the original MCP handle and inspect mcp-terminal.json" }))
