import assert from "node:assert/strict"
import fs from "node:fs/promises"
import path from "node:path"
import { createRequire } from "node:module"
import { randomUUID } from "node:crypto"
const root = path.join(import.meta.dir, "live-attempt-01")
const require = createRequire(path.join(import.meta.dir, "../packages/opencorvus/package.json"))
const { McpServer } = await import(require.resolve("@modelcontextprotocol/sdk/server/mcp.js"))
const { WebStandardStreamableHTTPServerTransport } = await import(require.resolve("@modelcontextprotocol/sdk/server/webStandardStreamableHttp.js"))
const { Client } = await import(require.resolve("@modelcontextprotocol/sdk/client/index.js"))
const { StreamableHTTPClientTransport } = await import(require.resolve("@modelcontextprotocol/sdk/client/streamableHttp.js"))
const resources = JSON.parse(await fs.readFile(path.join(root, "public-resources.json"), "utf8"))
const occurrence = randomUUID()
const startedAt = Date.now()
const deadlineAt = startedAt + 600000
const stopFile = path.join(root, "mcp-stop.json")
const servers = new Set<any>()
const transports = new Set<any>()
const closeFacts: any[] = []
let client: any
let clientTransport: any
let http: ReturnType<typeof Bun.serve> | undefined
let timer: ReturnType<typeof setTimeout> | undefined
let poll: ReturnType<typeof setInterval> | undefined
let reason = "startup-failure"
let failure: string | undefined
let resolveStop!: (reason: string) => void
const stopped = new Promise<string>((resolve) => { resolveStop = resolve })
const record = (name: string, value: any) => fs.writeFile(path.join(root, name), JSON.stringify(value, null, 2) + "\n", { flag: "wx" })
const close = async (kind: string, value: any) => {
  if (!value) return
  try { await value.close(); closeFacts.push({ kind, outcome: "closed" }) }
  catch (error) { closeFacts.push({ kind, outcome: "failed", error: String(error) }); process.exitCode = 1 }
}
try {
  await fs.access(stopFile).then(() => { throw new Error("Fresh MCP scope already has a stop request") }, (error) => { if (error.code !== "ENOENT") throw error })
  http = Bun.serve({ hostname: "127.0.0.1", port: 18507, idleTimeout: 0, async fetch(request) {
    const url = new URL(request.url)
    if (url.pathname === "/health") return Response.json({ occurrence, pid: process.pid, deadlineAt })
    if (url.pathname !== "/mcp") return new Response("Not found", { status: 404 })
    const server = new McpServer({ name: "public-user-resource-input-393", version: "1.0.0" })
    servers.add(server)
    for (const resource of resources) server.registerResource(resource.name, resource.uri, {
      title: resource.filename, description: "Read-only public resource sample.", mimeType: resource.mime,
    }, async () => {
      await fs.appendFile(path.join(root, "mcp-read-calls.jsonl"), JSON.stringify({ occurrence, pid: process.pid, uri: resource.uri, at: new Date().toISOString(), contents: resource.contents }) + "\n")
      return { contents: resource.contents }
    })
    const transport = new WebStandardStreamableHTTPServerTransport({ sessionIdGenerator: undefined, enableJsonResponse: true })
    transports.add(transport)
    await server.connect(transport)
    return transport.handleRequest(request)
  } })
  assert.equal(http.port, 18507)
  timer = setTimeout(() => resolveStop("fixed-deadline"), Math.max(0, deadlineAt - Date.now()))
  let checking = false
  poll = setInterval(async () => {
    if (checking) return
    checking = true
    try {
      const stop = JSON.parse(await fs.readFile(stopFile, "utf8"))
      assert.equal(stop.occurrence, occurrence, "Stop request must name this owner")
      assert.equal(stop.reason, "page-closed")
      resolveStop("owned-stop-file")
    } catch (error: any) { if (error.code !== "ENOENT") { failure = String(error); resolveStop("stop-file-error") } }
    finally { checking = false }
  }, 250)
  const owner = { occurrence, pid: process.pid, parentPID: process.ppid, startedAt, deadlineAt, lifetimeMilliseconds: 600000, idleTimeout: 0, port: http.port, stopFile }
  await record("mcp-owner.json", owner)
  client = new Client({ name: "public-resource-inventory-selfcheck", version: "1.0.0" })
  clientTransport = new StreamableHTTPClientTransport(new URL("http://127.0.0.1:18507/mcp"), { fetch: (input: any, init: any) => fetch(input, { ...init, signal: AbortSignal.any([...(init?.signal ? [init.signal] : []), AbortSignal.timeout(10000)]) }) })
  await client.connect(clientTransport)
  const listed = await client.listResources({}, { timeout: 10000 })
  assert.deepEqual(listed.resources.map((value: any) => value.uri).sort(), resources.map((value: any) => value.uri).sort())
  await close("inventory-client", client); client = undefined
  await close("inventory-client-transport", clientTransport); clientTransport = undefined
  assert(closeFacts.every((fact) => fact.outcome === "closed"))
  await record("mcp-ready.json", { ...owner, observedAt: new Date().toISOString(), resources: listed.resources, selfcheck: "official SDK listResources only; no resource reads" })
  console.log(JSON.stringify({ ready: true, ...owner }))
  reason = await stopped
} catch (error) { failure = String(error); process.exitCode = 1 }
finally {
  clearTimeout(timer); clearInterval(poll)
  await close("inventory-client-finally", client)
  await close("inventory-client-transport-finally", clientTransport)
  for (const server of servers) await close("mcp-server", server)
  for (const transport of transports) await close("mcp-server-transport", transport)
  if (http) {
    try { await http.stop(true); closeFacts.push({ kind: "http", outcome: "closed" }) }
    catch (error) { closeFacts.push({ kind: "http", outcome: "failed", error: String(error) }); process.exitCode = 1 }
  }
  if (reason !== "owned-stop-file" || failure) process.exitCode = 1
  await record("mcp-terminal.json", { occurrence, pid: process.pid, startedAt, deadlineAt, closedAt: new Date().toISOString(), reason, failure, closeFacts, exitCode: process.exitCode ?? 0 })
  console.log(JSON.stringify({ occurrence, pid: process.pid, reason, exitCode: process.exitCode ?? 0, ownerClosed: true }))
}
