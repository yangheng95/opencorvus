# 393 prepared helpers (not an executed acceptance)

All commands below are for Root review and execution. Preparation has no service, credentials, model or browser. `prepare-live.mjs` only creates eight public sample/config files once with `wx`.

## Fixed ownership

- App18506: Root's reviewed private393 copy of the original mature NativeService launcher; Base;600000ms physical deadline/20 cumulative requests/180000ms inactivity. Root alone stages paired auth+models, preflights, launches, owns CUA and closes. The launcher copy changes only the private Bun+UI location and original helper root as approved.
- MCP18507: `mcp-resources.ts`, own600000ms, `idleTimeout:0`, stop file names exact occurrence. Official SDK selfcheck lists resources only. Each actual resources/read is public and logged. Finally closes Client/Client transport/McpServer/Server transports/HTTP and writes `mcp-terminal.json`. Root retains and joins the original execution handle; no detached Start-Process needed.
- Fresh run only. No helper reruns a model request, changes messageID, imports a package, or creates a Task/Mission. Existing output receipts make accidental reruns fail with EEXIST.

## Commands from repository root

Use `& '.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64/bun.exe'` as `$bun393` below, or the same reviewed Bun1.4 executable. Root may run the preparation script once if the sample files have not already been prepared; do not rerun it over existing samples.

```powershell
$bun393 = Join-Path $PWD '.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64/bun.exe'
$live393 = Join-Path $PWD '.tmp-mcp-user-resource-input-393/live-attempt-01'
# Preparation only; already executed by the helper author if prepare.log exists.
node .tmp-mcp-user-resource-input-393/prepare-live.mjs
# Root starts its private native launcher with:
# RunRoot=$live393/provider-run; EvidenceRoot=$live393/provider-live;
# Port=18506; EvidencePrefix=mcp-user-resource-input-393-live-01;
# ProfileSelectionPath=$live393/builtin.json; RequestBudget=20;
# QualificationKind=NativeService.
# Root separately starts and retains this MCP owner handle (no model inside):
& $bun393 .tmp-mcp-user-resource-input-393/mcp-resources.ts
```

Wait for native `provider-run/evidence/preflight-ready.json` and `mcp-ready.json` with exact owner occurrences. Root runs the next script separately while both owners remain active:

```powershell
node .tmp-mcp-user-resource-input-393/send-session.mjs
```

It verifies credential/catalog/model/stream **receipts**, Base and both deadlines; configures only the unique project MCP entry; uploads the public CSV through `/attachment`; creates a real public assistant Session and writes `session-created.json` + `public-message-request.json` before sending one public message. Ready stdout contains the actual Session/Project/messageID and original deadlines; open `http://127.0.0.1:18506/ui` and choose the recorded Session. `session-created.json` remains readable while POST is awaiting the real answer. The original earlier deadline minus120000ms reserves the page/download window; HTTP timeout is not a model cancellation. Root must stop normally within original owner deadlines.

```powershell
& $bun393 .tmp-mcp-user-resource-input-393/check-live.ts observe
& $bun393 .tmp-mcp-user-resource-input-393/check-live.ts check
```

`observe` records running facts. `check` requires the successful real HTTP response, completed assistant, ordered canonical user parts (including two empty text pieces), three SDK reads, three exact files (CSV0/MCP CSV32/uploadCSV34 bytes), actual public HTTP bytes, exact model streamingHTTP200EOF. Check reads only the copied scoped auth **in memory** for CredentialRedactor; it neither copies credentials nor archives raw auth. Its production imports initialize only against the already-owned runtime. It does not substitute a fixture response or write the product database. Inspect `visible-answer.txt` against `replyFacts` in `live-check.json`; this manual answer assessment remains Root-owned.

Root's page plan: inspect user resource reading prefixes/empty resource descriptions, mixed report text, three visible CSV attachments, actual answer; download the emptyCSV and ordinary upload or mixedCSV and compare with public samples. There is no current MCP input-picker UI; input was authored via the actual public API, not by browser automation. No ACP/App/dataURL/fileURL real-model claim.

After Root closes its own page:

```powershell
node .tmp-mcp-user-resource-input-393/stop-mcp.mjs PageClosed
& .tmp-product-iteration/live-sol-shutdown.ps1 -RunRoot (Join-Path $live393 'provider-run') -EvidenceRoot (Join-Path $live393 'provider-live') -EvidencePrefix 'mcp-user-resource-input-393-live-01' -Reason 'root-manual' -PageClosed
```

Root joins both original handles, verifies normal MCP terminal and all close outcomes, native physical output/request EOF and paired credential cleanup, and checks both ports released. Never kill user processes or extend deadlines. Fixed-deadline/failure receipts remain failures, not normal-close success. Archive only an explicit public allowlist after root review; never copy the entire runtime.
