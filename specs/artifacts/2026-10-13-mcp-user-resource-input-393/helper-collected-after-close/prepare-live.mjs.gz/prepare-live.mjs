import fs from "node:fs/promises"
import path from "node:path"
import { fileURLToPath } from "node:url"
import assert from "node:assert/strict"
const root = process.argv[2]
assert(root && path.isAbsolute(root), "Required absolute scope root")
assert.equal(path.dirname(path.resolve(root)), path.dirname(fileURLToPath(import.meta.url)))
await fs.mkdir(root, { recursive: true })
const csv = "item,quantity\r\nMaple,3\r\nIris,4\r\n"
const upload = "item,quantity\r\nNotebook,7\r\nPen,5\r\n"
const resources = [
  { name: "public-empty-text", uri: "reports://public/empty-text", filename: "public-empty.txt", mime: "text/plain", contents: [{ uri: "reports://public/empty-text", mimeType: "text/plain", text: "" }] },
  { name: "public-empty-csv", uri: "reports://public/empty.csv", filename: "public-empty.csv", mime: "text/csv", contents: [{ uri: "reports://public/empty.csv", mimeType: "text/csv", blob: "" }] },
  { name: "public-mixed-report", uri: "reports://public/mixed", filename: "public-mixed.csv", mime: "text/csv", contents: [
    { uri: "reports://public/mixed/header.txt", mimeType: "text/plain", text: "Public resource report.\r\nreview_code=MOSS-393-PUBLIC\r\n" },
    { uri: "reports://public/mixed/empty.txt", mimeType: "text/plain", text: "" },
    { uri: "reports://public/mixed/rows.csv", mimeType: "text/csv", blob: Buffer.from(csv).toString("base64") },
    { uri: "reports://public/mixed/tail.txt", mimeType: "text/plain", text: "End of public resource report." },
  ] },
]
const files = {
  "public-resources.json": JSON.stringify(resources, null, 2) + "\n",
  "mcp-config.json": JSON.stringify({ type: "remote", transport: "streamable-http", url: "http://127.0.0.1:18507/mcp", oauth: false, timeout: 15000 }, null, 2) + "\n",
  "builtin.json": JSON.stringify({ kind: "builtin", id: "base", namespace: "builtin" }, null, 2) + "\n",
  "public-empty.txt": "", "public-empty.csv": "", "public-mixed.csv": csv, "public-upload.csv": upload,
  "user-request.txt": "请根据本消息所附的三个公开MCP资源和普通上传CSV，用中文简短核对：报告的 review_code，混合资源CSV每行 item/quantity 及合计，上传CSV每行 item/quantity 及合计，以及空文本和空CSV的实际情况。请以真实正文及附件内容为依据，必要时读取附件，并列出可核对的资源或附件引用。不修改项目文件。\n",
}
for (const [name, content] of Object.entries(files)) await fs.writeFile(path.join(root, name), content, { flag: "wx" })
console.log(JSON.stringify({ prepared: true, root, publicResources: resources.length, servicesStarted: 0, credentialAccess: false }))
