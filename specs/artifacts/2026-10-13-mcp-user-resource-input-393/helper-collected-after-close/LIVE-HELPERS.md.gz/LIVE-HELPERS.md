# 393 scope02: real Global Chat then public attachment follow-up

Preparation only. Root owns all actual services, credentials, model, CUA and shutdown. Scope01 is already physically closed and paired-cleaned; its current post-recovery helper sources are frozen in `live-attempt-01/helper-snapshot-after-close`. Original failure receipts and root's earlier source preimages remain separate. Never reuse that owner or pair.

Every current helper requires an **absolute scope root**. `check-live.ts` additionally requires the explicit response-receipt filename; there is no scope/runtime/response fallback. The pure fixture generator uses exclusive writes and must run only once for a fresh root.

## Root commands, from repository root

```powershell
$bun393 = Join-Path $PWD '.tmp-product-iteration/sse-compression-305/bun140/bun-windows-x64/bun.exe'
$live393 = Join-Path $PWD '.tmp-mcp-user-resource-input-393/live-attempt-02'
# Pure preparation; skip if helper author already generated the eight samples.
node .tmp-mcp-user-resource-input-393/prepare-live.mjs $live393
```

Root's private launcher uses `RunRoot=$live393/provider-run`, `EvidenceRoot=$live393/provider-live`, Port18506, EvidencePrefix `mcp-user-resource-input-393-live-02`, ProfileSelectionPath `$live393/builtin.json`, RequestBudget20, QualificationKind NativeService. Keep the approved private Bun+392 UI and original helper-root adaptations only. Original600000ms physical limit/180000ms inactivity/20 cumulative requests include preflight and both real user turns. Paired auth+complete models staging/preflight/normal close are exclusively Root-owned.

Root starts the SDK resource service separately and retains its original handle:

```powershell
& $bun393 .tmp-mcp-user-resource-input-393/mcp-resources.ts $live393
```

Port18507, own600000ms, idleTimeout0. Wait for `mcp-ready.json` plus exact native `provider-run/evidence/preflight-ready.json`. Official SDK selfcheck only lists resources. All actual resources/read calls are counted independently. Normal stop is exact-occurrence atomic stop-file publication; finally closes Client/Client transport/McpServer/Server transports/HTTP and writes `mcp-terminal.json`.

```powershell
node .tmp-mcp-user-resource-input-393/send-session.mjs $live393
```

This verifies the owner/preflight/model/Base receipts and at least180 seconds remain before the first business request. It POSTs `/global/chat/start` with exactly `{requestID,text,model:"openai/gpt-6.1-sol"}` and expects202 `{requestID,session,messageID}`. No mode/target/directory field is legal. Global Chat creates its own normal project under this native runtime's `data/projects`; the script realpaths and verifies that boundary. The returned Session naturally has right-sidebar/chat identity. It does not mutate metadata or create Task/Mission.

`global-chat-ready.json` and immediate stdout provide actual Session/Project/directory/first-messageID, URL, original deadlines, pageReservedAt and closeBy. Root can immediately open `http://127.0.0.1:18506/ui`, use Work ledger and select this real Chat/project. Session ID is the Chat identity; there is no invented second Chat ID. The script polls public Session messages every3s for the real initial assistant completed/stop, rather than synthesizing or replaying a reply.

Then all project headers use **returned session.directory**, not native.project. The script PATCHes the unique MCP config, verifies Base, performs actual `POST /mcp/public_user_resources/connect` and requires GET/mcp connected, uploads34 public CSV bytes to `/attachment`, and records a stable second messageID. Only then it POSTs the second message to the same public `/session/:id/message` route under review, using original ResourceSource parts and uploaded canonical reference, with no private byteProject field. No automatic retry.

Both first and second business submissions require at least180000ms before the earlier original owner deadline. The second HTTP wait ends at original earlier deadline minus180000ms, leaving two minutes for CUA/downloads plus the final minute for physical close. Root should proactively close by `closeBy` (earlier deadline minus60000ms), never extend deadlines. HTTP timeout is not model-owner cancellation; preserve failure and let Root settle the original owners.

```powershell
& $bun393 .tmp-mcp-user-resource-input-393/check-live.ts $live393 observe public-message-response.json
& $bun393 .tmp-mcp-user-resource-input-393/check-live.ts $live393 check public-message-response.json
```

Checker verifies the real202 allocation/Session/project inside the native runtime, immutable first input and actual completed first reply, then the public follow-up's13 canonical ordered Parts, two empty texts, three actual SDK reads, real CSV0/32/34 bytes+metadata and public HTTP bytes. Store root follows the returned Chat directory; database follows native runtime. Provider audit must have1–20 exactSol streamingHTTP200/EOF requests. It reads only the scoped copied auth into CredentialRedactor memory, never copies or archives secrets; no TEST_HOME marker is added. `observe` and `check` require the second input to have been sent; before that read `global-chat-ready.json`.

`visible-answer.txt` plus `replyFacts` require Root's manual answer assessment: review_code MOSS-393-PUBLIC, Maple3/Iris4 total7, Notebook7/Pen5 total12, empty resource descriptions and actual references. Model byte claims never replace the independent file evidence. Page must show the real selected Chat, both user turns, resource text/empty handling, all three CSV attachments and actual final answer. Download emptyCSV and at least one nonempty CSV, copy only public samples into this scope, and compare bytes. No MCP input-picker/ACP/App/dataURL/fileURL UI claim.

After Root closes its own page:

```powershell
node .tmp-mcp-user-resource-input-393/stop-mcp.mjs $live393 PageClosed
& .tmp-product-iteration/live-sol-shutdown.ps1 -RunRoot (Join-Path $live393 'provider-run') -EvidenceRoot (Join-Path $live393 'provider-live') -EvidencePrefix 'mcp-user-resource-input-393-live-02' -Reason 'root-manual' -PageClosed
```

Join both original handles. Inspect MCP owned-stop-file/exit0 and all close outcomes, native physical/output/request completion and paired auth/models deletion, both ports released. No user process intervention or deadline extension. Archive only a reviewed explicit public allowlist, never the entire runtime.
