import fs from "node:fs/promises"
import path from "node:path"
import assert from "node:assert/strict"
import { fileURLToPath } from "node:url"

const scratch = path.dirname(fileURLToPath(import.meta.url))
const evidence = path.join(scratch, "before")
const runRoot = "C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/owner-search-before-01a133"
const project = path.join(runRoot, "project", "scoped-project")
const baseURL = "http://127.0.0.1:18449"
const fixture = JSON.parse(await fs.readFile(path.join(evidence, "fixture.json"), "utf8"))
assert.equal(path.resolve(fixture.owner.runRoot), path.resolve(runRoot))
assert.equal(path.resolve(fixture.owner.project), path.resolve(project))
assert.equal(fixture.owner.port, 18449)
const rootEntry = await fs.lstat(project)
assert.equal(rootEntry.isDirectory(), true)
assert.equal(rootEntry.isSymbolicLink(), false)
const summary = { readOnly: true, project, occurrence: fixture.owner.occurrence, startedAt: new Date().toISOString(), stages: [] }
let section

async function persist(name, value) {
  await fs.writeFile(path.join(evidence, name), JSON.stringify(value, null, 2))
}
async function physical(relative) {
  const full = path.join(project, relative)
  const result = { path: relative, full }
  try {
    const entry = await fs.lstat(full, { bigint: true })
    result.entry = { file: entry.isFile(), directory: entry.isDirectory(), symbolicLink: entry.isSymbolicLink(), device: String(entry.dev), inode: String(entry.ino) }
    if (entry.isFile()) result.bytesBase64 = (await fs.readFile(full)).toString("base64")
  } catch (error) { result.error = { name: error.name, code: error.code, message: error.message } }
  section.physical.push(result)
  return result
}
async function get(route, query) {
  const url = new URL(route, baseURL)
  for (const [key, value] of Object.entries({ directory: project, ...query })) url.searchParams.set(key, value)
  const response = await fetch(url, { signal: AbortSignal.timeout(20_000) })
  const rawBody = await response.text()
  const result = { method: "GET", url: url.toString(), request: query, status: response.status, headers: Object.fromEntries(response.headers), rawBody, body: JSON.parse(rawBody) }
  section.requests.push(result)
  return result
}
function expected(relative) {
  const entry = fixture.entries.find((entry) => entry.file === relative)
  assert.ok(entry, `Saved original identity missing for ${relative}`)
  return entry
}
async function originalFile(current, original) {
  const initial = expected(original)
  const observed = await physical(current)
  assert.deepEqual(observed.entry, { file: true, directory: false, symbolicLink: false, device: initial.device, inode: initial.inode })
  assert.equal(observed.bytesBase64, initial.bytesBase64)
  const response = await get("/file/content", { path: current })
  assert.equal(response.status, 200)
  assert.equal(response.body.type, "text")
  assert.equal(Buffer.from(response.body.content, "utf8").toString("base64"), initial.bytesBase64)
  assert.equal(typeof response.body.revision, "string")
}
async function missingContent(relative) {
  await physical(relative)
  const response = await get("/file/content", { path: relative })
  assert.equal(response.status, 404)
  assert.equal(response.body.name, "FileNotFoundError")
  assert.equal(response.body.data.path, relative)
}
function node(relative) {
  const full = path.join(project, relative)
  return { name: path.basename(full), path: path.relative(project, full), absolute: full, type: "file", ignored: false }
}
async function stage(label, filename, fn) {
  section = { label, project, occurrence: fixture.owner.occurrence, requests: [], physical: [], startedAt: new Date().toISOString() }
  try { await fn(); section.outcome = "verified" }
  catch (error) { section.outcome = "failed"; section.error = { name: error.name, message: error.message, stack: error.stack }; throw error }
  finally { section.finishedAt = new Date().toISOString(); await persist(filename, section); summary.stages.push({ label, outcome: section.outcome, requests: section.requests.length, evidence: filename }) }
}

try {
  await stage("actual before batch move", "check-move.json", async () => {
    await missingContent("batch-source/a.txt")
    await originalFile("batch-target/a.txt", "batch-source/a.txt")
    await originalFile("batch-source/b.txt", "batch-source/b.txt")
    await missingContent("batch-target/b.txt")
    const source = await get("/file", { path: "batch-source" })
    assert.equal(source.status, 200)
    assert.deepEqual(source.body, [node("batch-source/b.txt")])
    const target = await get("/file", { path: "batch-target" })
    assert.equal(target.status, 200)
    assert.deepEqual(target.body, [node("batch-target/a.txt")])
  })
  // Root authorized this read after the real file chooser upload completed.
  await stage("actual uploaded bytes and public search", "check-search.json", async () => {
    const inputBytes = await fs.readFile(fixture.upload.file)
    assert.equal(inputBytes.toString("utf8"), fixture.upload.content)
    const uploaded = await physical("search-b.txt")
    assert.equal(uploaded.entry.file, true)
    assert.equal(uploaded.entry.symbolicLink, false)
    assert.equal(uploaded.bytesBase64, inputBytes.toString("base64"))
    const content = await get("/file/content", { path: "search-b.txt" })
    assert.equal(content.status, 200)
    assert.equal(content.body.type, "text")
    assert.equal(Buffer.from(content.body.content, "utf8").toString("base64"), inputBytes.toString("base64"))
    assert.equal(typeof content.body.revision, "string")
    await originalFile("search-a.txt", "search-a.txt")
    const search = await get("/find/file", { query: "search-", type: "file", limit: "200" })
    assert.equal(search.status, 200)
    assert.deepEqual([...search.body].sort(), ["search-a.txt", "search-b.txt"])
    const listed = await get("/file", { path: "" })
    assert.equal(listed.status, 200)
    for (const relative of ["search-a.txt", "search-b.txt"]) assert.deepEqual(listed.body.find((entry) => entry.name === relative), node(relative))
  })
  summary.outcome = "verified"
} catch (error) {
  summary.outcome = "failed"
  summary.error = { name: error.name, message: error.message, stack: error.stack }
  process.exitCode = 1
} finally {
  summary.finishedAt = new Date().toISOString()
  await persist("check-summary.json", summary)
  console.log(JSON.stringify(summary))
}
