import fs from 'node:fs/promises'
import path from 'node:path'
import assert from 'node:assert/strict'
const [runRoot,port,phase]=process.argv.slice(2)
assert(['before','after'].includes(phase))
const expected='C:/Users/hengu/.codex/opencorvus-product-iteration/2026-10-13/owner-search-'+phase+'-01a133'
assert.equal(path.resolve(runRoot),path.resolve(expected))
const owner=JSON.parse(await fs.readFile(path.join(runRoot,'launch-owner.json'),'utf8'))
assert.equal(owner.port,Number(port));assert.equal(path.resolve(owner.project),path.resolve(runRoot,'project/scoped-project'))
const root=owner.project,evidence=path.resolve('.tmp-codex-owner-search-01a133',phase)
await fs.mkdir(evidence,{recursive:true})
for(const dir of ['batch-source','batch-target','keep-expanded'])await fs.mkdir(path.join(root,dir))
const files={'batch-source/a.txt':'OWNER FIRST A 资料\r\n','batch-source/b.txt':'OWNER SECOND B 资料\r\n','keep-expanded/marker.txt':'OWNER EXPANDED MARKER\r\n','search-a.txt':'SEARCH ORIGINAL A\r\n'}
for(const[file,text]of Object.entries(files))await fs.writeFile(path.join(root,file),text,{flag:'wx'})
const extra=path.join(runRoot,'extra-inputs');await fs.mkdir(extra);await fs.writeFile(path.join(extra,'search-b.txt'),'SEARCH UPLOADED B\r\n',{flag:'wx'})
const entries=[]
for(const file of Object.keys(files)){const full=path.join(root,file),st=await fs.lstat(full);entries.push({file,full,inode:String(st.ino),device:String(st.dev),bytesBase64:(await fs.readFile(full)).toString('base64')})}
const url=new URL(`http://127.0.0.1:${port}/coding/chat/session`);url.searchParams.set('directory',root)
const response=await fetch(url,{method:'POST',headers:{'content-type':'application/json'},body:'{}',signal:AbortSignal.timeout(15000)}),rawBody=await response.text();assert.equal(response.status,201,rawBody)
await fs.writeFile(path.join(evidence,'fixture.json'),JSON.stringify({owner,files,entries,upload:{file:path.join(extra,'search-b.txt'),content:'SEARCH UPLOADED B\r\n'},chat:{status:response.status,requestID:response.headers.get('x-opencorvus-request-id'),rawBody,body:JSON.parse(rawBody)}},null,2))
console.log(JSON.stringify({project:root,port,phase,chat:JSON.parse(rawBody)},null,2))
